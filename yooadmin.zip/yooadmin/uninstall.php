<?php
/**
 * @package YOOAdmin
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

$yooadmin_options = get_option('yooadmin_options', []);
if (empty($yooadmin_options['delete_data_on_uninstall'])) {
    return;
}

$yooadmin_plugin_dir = dirname(__FILE__);
if (is_readable($yooadmin_plugin_dir . '/includes/core/data-cleanup.php')) {
    require_once $yooadmin_plugin_dir . '/includes/core/data-cleanup.php';
}

if (function_exists('yooadmin_purge_core_stored_data')) {
    yooadmin_purge_core_stored_data();
}
