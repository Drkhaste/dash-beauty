<?php
/**
 * YOOAdmin - Plugin config (defaults, options, feature flags)
 *
 * @package YOOAdmin
 * @since 1.0.0
 *
 * This file defines lightweight runtime configuration:
 * - Defaults (colors, branding, behavior)
 * - Feature flags
 * - Safe getters (single source of truth)
 * - Public filters to allow overrides
 *
 * Keep this file minimal — no heavy logic here.
 */

defined('ABSPATH') || exit;

/**
 * Default options for the plugin (can be filtered).
 * Stored as a single array under `yooadmin_options`.
 */
function yooadmin_default_options() {
    $defaults = [
        // Branding
        'brand_name'        => defined('YOOADMIN_BRAND_NAME') ? YOOADMIN_BRAND_NAME : 'YOOPixel',
        'brand_site'        => defined('YOOADMIN_SITE_URL')   ? YOOADMIN_SITE_URL   : 'https://www.yooadmin.io',
        'panel_title'       => defined('YOOADMIN_PANEL_TITLE') ? YOOADMIN_PANEL_TITLE : 'YOOAdmin',
        // Empty = resolve via {@see yooadmin_logo_url()} + theme {@see YOOAdmin_Admin_Theme_Manager::filter_default_logo_url()}.
        // Do not pre-fill YOOADMIN_LOGO_URL here or the theme default logo is never used.
        'logo_url'          => '',

        // Theme / UI
        'color_primary'     => defined('YOOADMIN_COLOR_PRIMARY')   ? YOOADMIN_COLOR_PRIMARY   : '#eda934',
        'color_secondary'   => defined('YOOADMIN_COLOR_SECONDARY') ? YOOADMIN_COLOR_SECONDARY : '#2C3E50',
        'clean_view'        => false, // default off
        'focus_mode'        => false, // default off

        // Behavior

        'wp_settings_experience' => 1,  // style native WP settings screens (requires Focus Mode)
        'plugin_install_basic'   => 1,  // style native plugins.php + plugin-install.php (requires Focus Mode)
        'users_redirect'      => 1,     // redirect users.php to YOOAdmin experience
        'posts_redirect'      => 1,     // redirect edit.php (posts) to YOOAdmin experience
        'comments_redirect'   => 1,     // redirect edit-comments.php to YOOAdmin experience
        'pages_redirect'      => 1,     // redirect edit.php?post_type=page to YOOAdmin experience
        'categories_redirect' => 1,     // redirect edit-tags.php?taxonomy=category to YOOAdmin experience
        'network_settings_redirect' => 1, // redirect network settings.php to YOOAdmin manager (multisite)
        'network_sites_redirect'    => 1, // redirect network sites.php to YOOAdmin manager (multisite)
        'network_site_info_redirect' => 1,
        'network_update_center_redirect' => 1, // redirect network update-core.php to YOOUpdate Center (multisite)
        'network_setup_redirect'           => 1, // redirect network setup.php to YOOAdmin setup page (multisite)
        'network_upgrade_redirect'         => 1, // redirect network upgrade.php to YOOAdmin upgrade page (multisite)
        'sync_native_menu'    => true,  // hydrate custom sidebar from #adminmenu
        'popup_enabled'     => true,  // enable quick actions popup
        'wc_spa_guard'      => true,  // hard-load heavy wc-admin routes
        'assets_header_guard'=> true, // header height sync

        // Future proof
        'telemetry'         => false, // keep disabled for free tier
        'beta_features'     => false, // gated features in future
        
        // Optional feature (free, enabled/disabled from Settings, no license required)
        'convert_banners_to_notifications' => 1, // Convert admin notices to notifications (default enabled)

        // Notifications retention / cleanup (Phase 3)
        'notif_auto_cleanup'    => 1,   // master toggle for scheduled cleanup
        'notif_retention_days'  => 45,  // delete READ notifications older than N days (0 = never)
        'notif_max_per_user'    => 200, // keep only newest N notifications per user (0 = unlimited)
        'notif_tombstone_days'  => 90,  // prune permanent dismissal records older than N days (0 = keep)

        // Uninstall / Data Cleanup (off by default; must be opted in)
        'delete_data_on_uninstall' => 0,

        'login_page_enabled'              => 1,
        'login_page_logo_source'          => 'branding',
        'login_page_image_side'           => 'left',
        'login_page_image_url'            => '',
        'login_page_content_page_id'      => 0,
        'login_page_logo_url'             => '',
        'login_page_logo_dark_url'        => '',
        'login_page_logo_max_w'           => 220,

        'login_security_enabled'              => 0,
        'login_turnstile_site_key'            => '',
        'login_turnstile_secret_key'          => '',
        'login_turnstile_protect_lostpassword' => 1,
        'login_turnstile_display'              => 'minimal',
        'login_turnstile_wp_login'             => 1,
        'login_turnstile_standalone'           => 1,
        'login_turnstile_comments'              => 0,
        'login_turnstile_comments_skip_logged_in' => 1,

        'login_rate_limit_enabled'              => 1,
        'login_rate_limit_wp_login'             => 1,
        'login_rate_limit_standalone'           => 1,
        'login_rate_limit_comments'             => 0,
        'login_rate_limit_comments_max'           => 8,
        'login_rate_limit_comments_window'      => 15 * MINUTE_IN_SECONDS,
        'login_rate_limit_login_max'            => 10,
        'login_rate_limit_login_window'         => 15 * MINUTE_IN_SECONDS,
        'login_rate_limit_lostpassword_max'     => 5,
        'login_rate_limit_lostpassword_window'  => 15 * MINUTE_IN_SECONDS,
        'login_rate_limit_resetpass_max'        => 10,
        'login_rate_limit_resetpass_window'     => 15 * MINUTE_IN_SECONDS,

        'login_prevent_user_enumeration'        => 0,
        'login_user_enum_author_archives'       => 'redirect_home',
        'login_user_enum_hide_rss_author'       => 1,

        'login_hidden_entry_enabled'            => 0,
        'login_hidden_entry_slug'               => '',

        'login_two_factor_enabled'              => 0,
        'login_two_factor_method_totp'          => 1,
        'login_two_factor_method_email'         => 1,
        'login_two_factor_method_backup_codes'  => 1,
        'login_two_factor_default_primary'      => 'totp',
        'login_two_factor_email_resend_cooldown' => 60,
        'login_two_factor_email_resend_max'      => 5,

        'login_email_change_recovery_enabled'   => 1,

        'maintenance_mode_enabled'                    => 0,
        'maintenance_mode_show_header_badge_when_off' => 0,
        'maintenance_mode_appearance_mode'      => 'dark',
        'maintenance_mode_image_url'            => '',
        'maintenance_mode_image_id'             => 0,
        'maintenance_mode_bg_overlay_opacity'   => 50,
        'maintenance_mode_bg_blur'              => 50,
        'maintenance_mode_card_overlay_opacity' => 50,
        'maintenance_mode_title'                => '',
        'maintenance_mode_message'              => '',
        'maintenance_mode_titles'               => [],
        'maintenance_mode_messages'             => [],
        'maintenance_mode_enabled_locales'      => [],
    ];

    return apply_filters('yooadmin_default_options', $defaults);
}

/**
 * Feature flags (separate from options; can be toggled at runtime).
 */
function yooadmin_feature_flags() {
    $flags = [
        'settings_page'     => true,   // will expose admin settings page
        'dashboard_widgets' => true,   // allow custom dashboard cards
        'login_customizer'  => true,   // customize wp-login
        'wc_friendly'       => true,   // WooCommerce safe behaviors
        'pro_gate'          => false,  // reserved for premium add-ons
    ];

    return apply_filters('yooadmin_feature_flags', $flags);
}

/**
 * Get merged options:
 * - Reads `yooadmin_options` (array) if present.
 * - Falls back to legacy single keys if needed (soft-compat).
 * - Merges with defaults (defaults win only when key missing).
 */
function yooadmin_get_options() {
    static $cached = null;
    if (is_array($cached)) {
        return $cached;
    }

    $defaults = yooadmin_default_options();
    $stored   = get_option('yooadmin_options');
    $stored   = is_array($stored) ? $stored : [];

    // Soft-compat for legacy single keys (do not overwrite explicit values)
    $legacy_map = [
        'yooadmin_primary_color'   => 'color_primary',
        'yooadmin_secondary_color' => 'color_secondary',
        'yooadmin_focus_active'    => 'focus_mode',
    ];
    foreach ($legacy_map as $legacy_key => $opt_key) {
        if (!array_key_exists($opt_key, $stored)) {
            $legacy_val = get_option($legacy_key, null);
            if ($legacy_val !== null) {
                $stored[$opt_key] = $legacy_val;
            }
        }
    }

    // Final merged (stored wins over defaults)
    // IMPORTANT: Use array_merge instead of wp_parse_args to preserve 0 and false values
    // wp_parse_args treats 0 and false as "missing" and replaces them with defaults
    $cached = array_merge($defaults, $stored);

    // Legacy: login_page_policy (removed) → login_page_enabled when enabled key missing
    if (!array_key_exists('login_page_enabled', $stored) && array_key_exists('login_page_policy', $stored)) {
        $cached['login_page_enabled'] = ($stored['login_page_policy'] !== 'off') ? 1 : 0;
    }

    if (!array_key_exists('login_page_logo_source', $stored)) {
        $cached['login_page_logo_source'] = 'branding';
    }

    /**
     * Filter final options bag.
     * @param array $cached
     */
    $cached = apply_filters('yooadmin_options', $cached);

    return $cached;
}

/**
 * Helper: get a single option by key with default fallback.
 */
function yooadmin_get_option($key, $default = null) {
    $opts = yooadmin_get_options();
    $val  = array_key_exists($key, $opts) ? $opts[$key] : $default;

    /**
     * Filter a specific option value right before returning.
     * @param mixed  $val
     * @param string $key
     */
    return apply_filters('yooadmin_option', $val, $key);
}

/**
 * Plugin Install Basic toggle — read stored preference (default on when unset).
 *
 * @return bool
 */
function yooadmin_plugin_install_basic_option_enabled(): bool {
    $stored = (array) get_option('yooadmin_options', []);

    if (!array_key_exists('plugin_install_basic', $stored)) {
        return true;
    }

    return (int) $stored['plugin_install_basic'] === 1;
}

/**
 * One-time fix when Plus is off but Plugin Basic was left at 0 after a Plus cycle.
 */
function yooadmin_maybe_restore_plugin_install_basic_without_plus(): void
{
    if (!is_admin()) {
        return;
    }

    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    if (is_plugin_active('yooadmin-plus/yooadmin-plus.php')) {
        return;
    }

    $opts = get_option('yooadmin_options', []);
    if (!is_array($opts)) {
        return;
    }

    $needs_fix = !empty($opts['plugins_redirect'])
        || !array_key_exists('plugin_install_basic', $opts)
        || (int) $opts['plugin_install_basic'] === 0;

    if (!$needs_fix) {
        return;
    }

    if (function_exists('yooadmin_plus_apply_lite_plugin_restore_to_options')) {
        yooadmin_plus_apply_lite_plugin_restore_to_options();

        return;
    }

    $opts['plugins_redirect']      = 0;
    $opts['plugin_install_basic']  = 1;

    update_option('yooadmin_options', $opts, false);
    wp_cache_delete('yooadmin_options', 'options');

    $user_id = get_current_user_id();
    if ($user_id > 0) {
        wp_cache_delete('yooadmin_options_' . $user_id, 'yooadmin_settings');
    }
}

add_action('admin_init', 'yooadmin_maybe_restore_plugin_install_basic_without_plus', 4);

/**
 * Helper: expose feature flags.
 */
function yooadmin_has_feature($flag) {
    $flags = yooadmin_feature_flags();
    $val   = !empty($flags[$flag]);

    /**
     * Filter a specific feature flag result.
     * @param bool   $val
     * @param string $flag
     */
    return apply_filters('yooadmin_feature', $val, $flag);
}

/**
 * (Optional) Early sanity checks: PHP / WP versions.
 * Keep it silent for now; admin notices can be added later in admin layer.
 */
add_action('plugins_loaded', function () {
    if (defined('YOOADMIN_MIN_PHP') && version_compare(PHP_VERSION, YOOADMIN_MIN_PHP, '<')) {
        // add_action('admin_notices', ...);
    }
    global $wp_version;
    if (defined('YOOADMIN_MIN_WP') && isset($wp_version) && version_compare($wp_version, YOOADMIN_MIN_WP, '<')) {
        // add_action('admin_notices', ...);
    }
}, 5);
