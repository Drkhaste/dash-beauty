<?php
/**
 * YOOAdmin - Core constants and paths
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/* -------------------------------------------------------------------------
 * 0) Plugin identity (version, file, paths, urls)
 * ---------------------------------------------------------------------- */
// If not set elsewhere, read Version from plugin header to avoid drift
if (!defined('YOOADMIN_VERSION')) {
    (function () {
        $main = dirname(__DIR__) . '/yooadmin.php';
        $ver  = '1.0.0';
        if (file_exists($main)) {
            if (!function_exists('get_plugin_data')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $data = get_plugin_data($main, false, false);
            if (!empty($data['Version'])) {
                $ver = (string) $data['Version'];
            }
        }
        define('YOOADMIN_VERSION', $ver);
    })();
}

/**
 * Resolve plugin root file from this config/ folder.
 * Adjusts safely if the file is moved with the plugin.
 */
if (!defined('YOOADMIN_PLUGIN_FILE'))  define('YOOADMIN_PLUGIN_FILE', dirname(__DIR__) . '/yooadmin.php');
if (!defined('YOOADMIN_DIR'))          define('YOOADMIN_DIR', plugin_dir_path(YOOADMIN_PLUGIN_FILE));
if (!defined('YOOADMIN_URL'))          define('YOOADMIN_URL', plugin_dir_url(YOOADMIN_PLUGIN_FILE));

/* -------------------------------------------------------------------------
 * 1) Internal directories
 * ---------------------------------------------------------------------- */
if (!defined('YOOADMIN_INCLUDES_DIR')) define('YOOADMIN_INCLUDES_DIR', YOOADMIN_DIR . 'includes/');
if (!defined('YOOADMIN_ADMIN_DIR'))    define('YOOADMIN_ADMIN_DIR',    YOOADMIN_INCLUDES_DIR . 'admin/');
if (!defined('YOOADMIN_FRONTEND_DIR')) define('YOOADMIN_FRONTEND_DIR', YOOADMIN_INCLUDES_DIR . 'frontend/');
if (!defined('YOOADMIN_HELPERS_DIR'))  define('YOOADMIN_HELPERS_DIR',  YOOADMIN_INCLUDES_DIR . 'helpers/');
if (!defined('YOOADMIN_SECURITY_DIR')) define('YOOADMIN_SECURITY_DIR', YOOADMIN_INCLUDES_DIR . 'security/');
if (!defined('YOOADMIN_TEMPLATES_DIR'))define('YOOADMIN_TEMPLATES_DIR',YOOADMIN_DIR . 'templates/');
if (!defined('YOOADMIN_ASSETS_DIR'))   define('YOOADMIN_ASSETS_DIR',   YOOADMIN_DIR . 'assets/');

/* -------------------------------------------------------------------------
 * 2) Branding & presentation
 * ---------------------------------------------------------------------- */
if (!defined('YOOADMIN_BRAND_NAME'))   define('YOOADMIN_BRAND_NAME', 'YOOPixel');
if (!defined('YOOADMIN_SITE_URL'))     define('YOOADMIN_SITE_URL', 'https://www.yooadmin.io');
if (!defined('YOOADMIN_PANEL_TITLE'))  define('YOOADMIN_PANEL_TITLE', 'YOOAdmin');

/* Default brand visuals (can be overridden by options later) */
if (!defined('YOOADMIN_COLOR_PRIMARY'))   define('YOOADMIN_COLOR_PRIMARY', '#eda934');
if (!defined('YOOADMIN_COLOR_SECONDARY')) define('YOOADMIN_COLOR_SECONDARY', '#2C3E50');
// Default admin logo (bundled logo.png in assets/images)
if (!defined('YOOADMIN_LOGO_URL'))        define('YOOADMIN_LOGO_URL', YOOADMIN_URL . 'assets/images/logo.png');

/* -------------------------------------------------------------------------
 * 3) Slugs, text-domain, dynamic endpoints
 * ---------------------------------------------------------------------- */
if (!defined('YOOADMIN_TD'))            define('YOOADMIN_TD', 'yooadmin'); // text domain
if (!defined('YOOADMIN_SETTINGS_SLUG'))   define('YOOADMIN_SETTINGS_SLUG', 'yooadmin-settings');
if (!defined('YOOADMIN_OPTION_PREFIX'))   define('YOOADMIN_OPTION_PREFIX', 'yooadmin_');
if (!defined('YOOADMIN_CAP_MANAGE'))      define('YOOADMIN_CAP_MANAGE', 'manage_yooadmin');

/* Optional dynamic resources (e.g., generated CSS) */
if (!defined('YOOADMIN_DYNAMIC_CSS_URL')) define('YOOADMIN_DYNAMIC_CSS_URL', YOOADMIN_URL . 'includes/helpers/dynamic-styles.php');

/* -------------------------------------------------------------------------
 * 4) Requirements / security
 * ---------------------------------------------------------------------- */
if (!defined('YOOADMIN_MIN_PHP')) define('YOOADMIN_MIN_PHP', '7.4');
if (!defined('YOOADMIN_MIN_WP'))  define('YOOADMIN_MIN_WP',  '6.0');

/* -------------------------------------------------------------------------
 * 5) Legacy aliases (backward compatibility with older code)
 *    Map former YOOPIXEL_* constants to the new YOOADMIN_* equivalents.
 *    Remove once all references are migrated.
 * ---------------------------------------------------------------------- */
if (!defined('YOOPIXEL_VERSION'))        define('YOOPIXEL_VERSION',        YOOADMIN_VERSION);
if (!defined('YOOPIXEL_PLUGIN_FILE'))    define('YOOPIXEL_PLUGIN_FILE',    YOOADMIN_PLUGIN_FILE);
if (!defined('YOOPIXEL_PLUGIN_DIR'))     define('YOOPIXEL_PLUGIN_DIR',     YOOADMIN_DIR);
if (!defined('YOOPIXEL_PLUGIN_URL'))     define('YOOPIXEL_PLUGIN_URL',     YOOADMIN_URL);

if (!defined('YOOPIXEL_INCLUDES_DIR'))   define('YOOPIXEL_INCLUDES_DIR',   YOOADMIN_INCLUDES_DIR);
if (!defined('YOOPIXEL_ADMIN_DIR'))      define('YOOPIXEL_ADMIN_DIR',      YOOADMIN_ADMIN_DIR);
if (!defined('YOOPIXEL_FRONTEND_DIR'))   define('YOOPIXEL_FRONTEND_DIR',   YOOADMIN_FRONTEND_DIR);
if (!defined('YOOPIXEL_HELPERS_DIR'))    define('YOOPIXEL_HELPERS_DIR',    YOOADMIN_HELPERS_DIR);
if (!defined('YOOPIXEL_SECURITY_DIR'))   define('YOOPIXEL_SECURITY_DIR',   YOOADMIN_SECURITY_DIR);
if (!defined('YOOPIXEL_TEMPLATES_DIR'))  define('YOOPIXEL_TEMPLATES_DIR',  YOOADMIN_TEMPLATES_DIR);

if (!defined('YOOPIXEL_PRIMARY_COLOR'))   define('YOOPIXEL_PRIMARY_COLOR',   YOOADMIN_COLOR_PRIMARY);
if (!defined('YOOPIXEL_SECONDARY_COLOR')) define('YOOPIXEL_SECONDARY_COLOR', YOOADMIN_COLOR_SECONDARY);
if (!defined('YOOPIXEL_LOGO_URL'))        define('YOOPIXEL_LOGO_URL',        YOOADMIN_LOGO_URL);

if (!defined('YOOPIXEL_DYNAMIC_CSS_URL')) define('YOOPIXEL_DYNAMIC_CSS_URL', YOOADMIN_DYNAMIC_CSS_URL);
if (!defined('YOOPIXEL_SETTINGS_PAGE_SLUG')) define('YOOPIXEL_SETTINGS_PAGE_SLUG', YOOADMIN_SETTINGS_SLUG);

if (!defined('YOOPIXEL_MIN_PHP_VERSION')) define('YOOPIXEL_MIN_PHP_VERSION', YOOADMIN_MIN_PHP);
if (!defined('YOOPIXEL_MIN_WP_VERSION'))  define('YOOPIXEL_MIN_WP_VERSION',  YOOADMIN_MIN_WP);
