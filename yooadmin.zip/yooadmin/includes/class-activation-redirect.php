<?php
/**
 * YOOAdmin - Activation redirect (to setup wizard)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Activation Redirect Class
 */
class YOOAdmin_Activation_Redirect {
    
    /**
     * Initialize
     */
    public static function init() {
        add_action('admin_init', [__CLASS__, 'redirect_after_activation']);
    }
    
    /**
     * Redirect after activation
     */
    public static function redirect_after_activation() {
        // Check if activation redirect is pending
        if (!get_transient('yooadmin_activation_redirect')) {
            return;
        }
        
        // Delete transient immediately to prevent redirect loop
        delete_transient('yooadmin_activation_redirect');
        
        // Don't redirect if:
        // 1. Doing AJAX
        if (wp_doing_ajax()) {
            return;
        }
        
        // 2. Activating multiple plugins
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flag check, no state change.
        if (isset($_GET['activate-multi'])) {
            return;
        }
        
        // 3. Not an admin
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // 4. Wizard already completed
        if (get_option('yooadmin_wizard_completed')) {
            return;
        }
        
        // 5. Wizard dismissed
        if (get_option('yooadmin_wizard_dismissed')) {
            return;
        }
        
        // Redirect to wizard immediately (page is registered in class-setup-wizard.php)
        wp_safe_redirect(admin_url('admin.php?page=yooadmin-setup'));
        exit;
    }
}

// Initialize
YOOAdmin_Activation_Redirect::init();

