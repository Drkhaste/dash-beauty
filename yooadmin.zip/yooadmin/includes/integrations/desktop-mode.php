<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_desktop_mode_plugin_file')) {
    function yooadmin_desktop_mode_plugin_file(): string
    {
        return defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    }
}

if (!function_exists('yooadmin_desktop_mode_available')) {
    function yooadmin_desktop_mode_available(): bool
    {
        return function_exists('desktop_mode_is_enabled')
            && function_exists('desktop_mode_is_chromeless_request')
            && function_exists('desktop_mode_register_icon');
    }
}

if (!function_exists('yooadmin_is_desktop_focus_integration_active')) {
    function yooadmin_is_desktop_focus_integration_active(): bool
    {
        return function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();
    }
}

if (!function_exists('yooadmin_should_bridge_command_palette_to_desktop')) {
    /**
     * Route breadcrumbs ⌘K/Ctrl+K to the Desktop Mode shell palette (postMessage),
     * not the in-iframe WordPress command palette.
     */
    function yooadmin_should_bridge_command_palette_to_desktop(): bool
    {
        if (!yooadmin_desktop_mode_available() || !desktop_mode_is_enabled()) {
            return false;
        }
        if (!yooadmin_is_desktop_focus_integration_active()) {
            return false;
        }
        if (function_exists('desktop_mode_is_classic_request') && desktop_mode_is_classic_request()) {
            return false;
        }

        return true;
    }
}

if (!function_exists('yooadmin_desktop_mode_editor_icon_url')) {
    function yooadmin_desktop_mode_editor_icon_url(): string
    {
        if (function_exists('yooadmin_studio_hub_block_editor_gutenberg_site_icon_url')) {
            $url = (string) yooadmin_studio_hub_block_editor_gutenberg_site_icon_url(512);
            if ($url !== '') {
                return $url;
            }
        }

        if (function_exists('yooadmin_studio_hub_get_admin_favicon_fallback_url')) {
            $url = (string) yooadmin_studio_hub_get_admin_favicon_fallback_url();
            if ($url !== '') {
                return $url;
            }
        }

        $base = yooadmin_desktop_mode_plugin_file();
        foreach (['assets/images/favicon.svg', 'assets/images/favicon.ico'] as $rel) {
            $abs = plugin_dir_path($base) . $rel;
            if (file_exists($abs)) {
                $href = plugins_url($rel, $base);
                $ver  = @filemtime($abs);
                return $ver ? $href . '?ver=' . $ver : $href;
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_desktop_mode_icon_target_url')) {
    function yooadmin_desktop_mode_icon_target_url(): string
    {
        $url = function_exists('yooadmin_dashboard_url')
            ? yooadmin_dashboard_url()
            : admin_url('admin.php?page=yooadmin-dashboard');

        return add_query_arg('yoo', 'on', $url);
    }
}

if (!function_exists('yooadmin_register_desktop_mode_icon')) {
    function yooadmin_register_desktop_mode_icon(): void
    {
        if (!yooadmin_desktop_mode_available() || !is_user_logged_in()) {
            return;
        }

        if (!function_exists('desktop_mode_is_enabled') || !desktop_mode_is_enabled()) {
            return;
        }

        $args = [
            'title'        => _x('YOOAdmin', 'desktop wallpaper shortcut label', 'yooadmin'),
            // Valid URL required at registration; stripped from shell payload so click exits Desktop Mode.
            'url'          => yooadmin_desktop_mode_icon_target_url(),
            'position'     => 12,
            'pinned'       => true,
            'capabilities' => ['read'],
        ];

        $icon_url = yooadmin_desktop_mode_editor_icon_url();
        $args['icon'] = $icon_url !== '' ? $icon_url : 'dashicons-admin-home';
        $args = apply_filters('yooadmin_desktop_mode_icon_args', $args);

        desktop_mode_register_icon('yooadmin-panel', $args);
    }
}

if (!function_exists('yooadmin_filter_desktop_mode_icons_strip_yooadmin_url')) {
    /**
     * Strip the icon URL from the shell payload so Desktop Mode does not
     * open an in-shell window on click. Exit is handled in JS via the
     * same save-desktop-mode flow as the admin-bar toggle.
     */
    function yooadmin_filter_desktop_mode_icons_strip_yooadmin_url(array $registry): array
    {
        if (!isset($registry['yooadmin-panel']) || !is_array($registry['yooadmin-panel'])) {
            return $registry;
        }

        $registry['yooadmin-panel']['url']    = '';
        $registry['yooadmin-panel']['window'] = '';

        return $registry;
    }
}

if (!function_exists('yooadmin_desktop_mode_loading_logo_url')) {
    /**
     * Logo shown in Desktop Mode window loading spinners.
     */
    function yooadmin_desktop_mode_loading_logo_url(): string
    {
        $logo = function_exists('yooadmin_logo_url') ? (string) yooadmin_logo_url() : '';
        if ($logo === '' && function_exists('yooadmin_logo_default_url')) {
            $logo = (string) yooadmin_logo_default_url();
        }
        if ($logo !== '') {
            return esc_url($logo);
        }

        $icon = yooadmin_desktop_mode_editor_icon_url();
        if ($icon !== '') {
            return esc_url($icon);
        }

        if (function_exists('yooadmin_get_admin_menu_icon_data_uri')) {
            return (string) yooadmin_get_admin_menu_icon_data_uri();
        }

        return '';
    }
}

if (!function_exists('yooadmin_desktop_mode_loading_logo_dark_url')) {
    /**
     * Dark logo for loading spinners on light window backgrounds.
     */
    function yooadmin_desktop_mode_loading_logo_dark_url(): string
    {
        $base = yooadmin_desktop_mode_plugin_file();
        $rel  = 'assets/images/logo-dark.png';
        $abs  = plugin_dir_path($base) . $rel;
        if (!file_exists($abs)) {
            return '';
        }

        $href = plugins_url($rel, $base);
        $ver  = @filemtime($abs);

        return $ver ? esc_url($href . '?ver=' . $ver) : esc_url($href);
    }
}

if (!function_exists('yooadmin_render_desktop_surface_breadcrumbs_brand')) {
    function yooadmin_render_desktop_surface_breadcrumbs_brand(): void
    {
        if (!yooadmin_should_use_desktop_surface_breadcrumbs()) {
            return;
        }

        $icon_url = yooadmin_desktop_mode_editor_icon_url();
        if ($icon_url === '') {
            return;
        }
        ?>
        <button
            type="button"
            class="yp-breadcrumbs-brand yp-breadcrumbs-brand__button"
            aria-label="<?php esc_attr_e('YOOAdmin', 'yooadmin'); ?>"
            title="<?php esc_attr_e('YOOAdmin', 'yooadmin'); ?>"
        >
            <img
                src="<?php echo esc_url($icon_url); ?>"
                alt=""
                class="yp-breadcrumbs-brand__icon"
                width="36"
                height="36"
                decoding="async"
            />
        </button>
        <?php
    }
}

if (!function_exists('yooadmin_strip_breadcrumb_home_item')) {
    function yooadmin_strip_breadcrumb_home_item(string $html): string
    {
        $html = trim($html);
        if ($html === '' || !class_exists('DOMDocument')) {
            return $html;
        }

        $doc = new DOMDocument();
        libxml_use_internal_errors(true);
        $ok = $doc->loadHTML('<?xml encoding="utf-8" ?>' . $html);
        libxml_clear_errors();
        if (!$ok) {
            return $html;
        }

        $xp = new DOMXPath($doc);
        $nav  = $xp->query("//nav[contains(concat(' ', normalize-space(@class), ' '), ' yp-breadcrumbs ')]")->item(0);
        $home = $xp->query("//li[contains(concat(' ', normalize-space(@class), ' '), ' is-home ')]");

        if (!$nav || !$home) {
            return $html;
        }

        for ($i = $home->length - 1; $i >= 0; $i--) {
            $li = $home->item($i);
            if ($li && $li->parentNode) {
                $li->parentNode->removeChild($li);
            }
        }

        $remaining = $xp->query('.//li', $nav);
        if (!$remaining || $remaining->length === 0) {
            return '';
        }

        return (string) $doc->saveHTML($nav);
    }
}

if (!function_exists('yooadmin_is_desktop_mode_shell_parent')) {
    function yooadmin_is_desktop_mode_shell_parent(): bool
    {
        if (!yooadmin_desktop_mode_available() || !desktop_mode_is_enabled()) {
            return false;
        }
        if (function_exists('desktop_mode_is_classic_request') && desktop_mode_is_classic_request()) {
            return false;
        }

        return !desktop_mode_is_chromeless_request();
    }
}

if (!function_exists('yooadmin_should_use_desktop_surface_breadcrumbs')) {
    function yooadmin_should_use_desktop_surface_breadcrumbs(): bool
    {
        if (!yooadmin_is_desktop_mode_shell_parent() || !yooadmin_is_desktop_focus_integration_active()) {
            return false;
        }

        return true;
    }
}

if (!function_exists('yooadmin_should_load_desktop_popup_guard')) {
    function yooadmin_should_load_desktop_popup_guard(): bool
    {
        if (!yooadmin_desktop_mode_available() || !desktop_mode_is_enabled() || !is_admin()) {
            return false;
        }

        return yooadmin_is_desktop_focus_integration_active();
    }
}

if (!function_exists('yooadmin_enqueue_desktop_exit_icon_script')) {
    /**
     * Wire YOOAdmin desktop icon / breadcrumbs brand to exit Desktop Mode.
     *
     * @param string[] $deps Extra script dependencies.
     */
    function yooadmin_enqueue_desktop_exit_icon_script(array $deps = []): void
    {
        $base = yooadmin_desktop_mode_plugin_file();
        $dir  = plugin_dir_path($base);
        $url  = plugin_dir_url($base);

        $icon_js_rel  = 'assets/js/admin/desktop-mode-yooadmin-icon.js';
        $icon_js_path = $dir . $icon_js_rel;
        if (!file_exists($icon_js_path)) {
            return;
        }

        $icon_js_deps = array_values(array_unique(array_merge(['wp-hooks'], $deps)));
        if (wp_script_is('yooadmin-focus-toggle', 'registered') || wp_script_is('yooadmin-focus-toggle', 'enqueued')) {
            $icon_js_deps[] = 'yooadmin-focus-toggle';
        }

        wp_enqueue_script(
            'yooadmin-desktop-mode-yooadmin-icon',
            $url . $icon_js_rel,
            $icon_js_deps,
            (string) filemtime($icon_js_path),
            true
        );
        wp_localize_script(
            'yooadmin-desktop-mode-yooadmin-icon',
            'yooadminDesktopIcon',
            [
                'iconId'  => 'yooadmin-panel',
                'url'     => esc_url(yooadmin_desktop_mode_icon_target_url()),
                'ajaxUrl' => esc_url(admin_url('admin-ajax.php')),
                'nonce'   => wp_create_nonce('save-desktop-mode'),
            ]
        );
    }
}

if (!function_exists('yooadmin_enqueue_desktop_shell_assets')) {
    function yooadmin_enqueue_desktop_shell_assets(): void
    {
        if (!yooadmin_is_desktop_mode_shell_parent()
            || !yooadmin_desktop_mode_available()
            || !function_exists('desktop_mode_is_enabled')
            || !desktop_mode_is_enabled()) {
            return;
        }

        $base = yooadmin_desktop_mode_plugin_file();
        $dir  = plugin_dir_path($base);
        $url  = plugin_dir_url($base);

        $css_rel  = 'assets/css/admin/desktop-mode-surface.css';
        $css_path = $dir . $css_rel;
        if (file_exists($css_path)) {
            $css_deps = ['desktop-mode'];
            foreach (['yooadmin-studio-hub-late', 'yooadmin-studio-hub-dashboard', 'yooadmin-settings'] as $handle) {
                if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
                    $css_deps[] = $handle;
                }
            }
            wp_enqueue_style(
                'yooadmin-desktop-mode-surface',
                $url . $css_rel,
                array_values(array_unique($css_deps)),
                (string) filemtime($css_path)
            );
        }

        $dark_js_rel  = 'assets/js/admin/desktop-mode-surface-dark.js';
        $dark_js_path = $dir . $dark_js_rel;
        if (file_exists($dark_js_path)) {
            wp_enqueue_script(
                'yooadmin-desktop-mode-surface-dark',
                $url . $dark_js_rel,
                ['desktop-mode'],
                (string) filemtime($dark_js_path),
                true
            );
        }

        yooadmin_enqueue_desktop_exit_icon_script(['desktop-mode']);

        $loading_js_rel  = 'assets/js/admin/desktop-mode-loading-brand.js';
        $loading_js_path = $dir . $loading_js_rel;
        if (file_exists($loading_js_path)) {
            wp_enqueue_script(
                'yooadmin-desktop-mode-loading-brand',
                $url . $loading_js_rel,
                ['desktop-mode', 'wp-hooks'],
                (string) filemtime($loading_js_path),
                true
            );
            wp_localize_script(
                'yooadmin-desktop-mode-loading-brand',
                'yooadminDesktopLoadingBrand',
                [
                    'logoUrl'      => yooadmin_desktop_mode_loading_logo_url(),
                    'logoDarkUrl'  => yooadmin_desktop_mode_loading_logo_dark_url(),
                    'spinnerColor' => '#eda934',
                ]
            );
        }
    }
}

if (!function_exists('yooadmin_enqueue_desktop_integration_assets')) {
    function yooadmin_enqueue_desktop_integration_assets(): void
    {
        $base = yooadmin_desktop_mode_plugin_file();
        $dir  = plugin_dir_path($base);
        $url  = plugin_dir_url($base);

        if (yooadmin_should_load_desktop_popup_guard()) {
            $rel  = 'assets/js/admin/desktop-mode-popup-guard.js';
            $path = $dir . $rel;
            if (file_exists($path)) {
                $deps = ['yooadmin-popup'];
                foreach (['yooadmin-studio-hub-dashboard', 'yooadmin-studio-hub-late', 'yooadmin-network-popup'] as $handle) {
                    if (wp_script_is($handle, 'registered') || wp_script_is($handle, 'enqueued')) {
                        $deps[] = $handle;
                    }
                }
                wp_enqueue_script(
                    'yooadmin-desktop-popup-guard',
                    $url . $rel,
                    array_values(array_unique($deps)),
                    (string) filemtime($path),
                    true
                );
            }
        }

        if (
            yooadmin_desktop_mode_available()
            && function_exists('desktop_mode_is_enabled')
            && desktop_mode_is_enabled()
            && yooadmin_should_use_desktop_surface_breadcrumbs()
        ) {
            yooadmin_enqueue_desktop_exit_icon_script();
        }

        if (!yooadmin_should_use_desktop_surface_breadcrumbs()) {
            return;
        }

        $js_rel  = 'assets/js/admin/desktop-mode-surface-layout.js';
        $js_path = $dir . $js_rel;
        if (file_exists($js_path)) {
            wp_enqueue_script(
                'yooadmin-desktop-surface-layout',
                $url . $js_rel,
                [],
                (string) filemtime($js_path),
                true
            );
        }
    }
}

if (!function_exists('yooadmin_enqueue_desktop_chromeless_assets')) {
    function yooadmin_enqueue_desktop_chromeless_assets(): void
    {
        if (!yooadmin_desktop_mode_available()
            || !function_exists('desktop_mode_is_enabled')
            || !desktop_mode_is_enabled()
            || !desktop_mode_is_chromeless_request()
            || !yooadmin_is_desktop_focus_integration_active()) {
            return;
        }

        $base = yooadmin_desktop_mode_plugin_file();
        $dir  = plugin_dir_path($base);
        $url  = plugin_dir_url($base);

        $js_rel  = 'assets/js/admin/desktop-mode-chromeless-color-sync.js';
        $js_path = $dir . $js_rel;
        $css_rel  = 'assets/css/admin/desktop-mode-chromeless-dark-bridge.css';
        $css_path = $dir . $css_rel;

        if (file_exists($css_path)) {
            wp_enqueue_style(
                'yooadmin-desktop-chromeless-dark-bridge',
                $url . $css_rel,
                ['desktop-mode-chromeless'],
                (string) filemtime($css_path)
            );
        }

        if (!file_exists($js_path)) {
            return;
        }

        wp_enqueue_script(
            'yooadmin-desktop-chromeless-color-sync',
            $url . $js_rel,
            [],
            (string) filemtime($js_path),
            true
        );
    }
}

add_filter(
    'admin_body_class',
    static function (string $classes): string {
        if (yooadmin_is_desktop_mode_shell_parent()) {
            $classes .= ' yooadmin-desktop-shell';
        }

        if (yooadmin_should_use_desktop_surface_breadcrumbs()) {
            $classes .= ' yooadmin-desktop-surface';
        }

        return $classes;
    },
    20
);

add_filter(
    'yooadmin_should_inject_shell_footer',
    static function (bool $inject): bool {
        if (yooadmin_should_use_desktop_surface_breadcrumbs()) {
            return false;
        }

        return $inject;
    },
    10
);

add_action('desktop_mode_mode_init', 'yooadmin_enqueue_desktop_shell_assets', 20);
add_action('desktop_mode_chromeless_styles', 'yooadmin_enqueue_desktop_chromeless_assets', 20);
add_action('admin_enqueue_scripts', 'yooadmin_enqueue_desktop_integration_assets', 100000);
add_action('init', 'yooadmin_register_desktop_mode_icon', 25);
add_filter('desktop_mode_icons', 'yooadmin_filter_desktop_mode_icons_strip_yooadmin_url', 20);
