<?php
defined('ABSPATH') || exit;

/**
 * Whether the current admin screen is WooCommerce-related and must keep its assets.
 *
 * Checks the enqueue hook suffix AND the resolved screen, because the product
 * editor runs on post.php / post-new.php (hook does NOT contain "product") while
 * its screen id / post_type IS a WooCommerce type.
 */
if (!function_exists('yooadmin_wc_optimizer_is_wc_screen')) {
    function yooadmin_wc_optimizer_is_wc_screen($hook = ''): bool {
        $hook = (string) $hook;
        if ($hook !== '' && (
            strpos($hook, 'woocommerce') !== false ||
            strpos($hook, 'wc-') !== false ||
            strpos($hook, 'product') !== false ||
            strpos($hook, 'shop_') !== false
        )) {
            return true;
        }

        if (!function_exists('get_current_screen')) {
            return false;
        }

        $screen = get_current_screen();
        if (!$screen) {
            return false;
        }

        $wc_post_types = ['product', 'product_variation', 'shop_order', 'shop_coupon', 'shop_subscription'];
        if (isset($screen->post_type) && in_array($screen->post_type, $wc_post_types, true)) {
            return true;
        }

        if (function_exists('wc_get_screen_ids') && isset($screen->id)
            && in_array($screen->id, wc_get_screen_ids(), true)) {
            return true;
        }

        $id = isset($screen->id) ? (string) $screen->id : '';
        if ($id !== '' && (
            strpos($id, 'woocommerce') !== false ||
            strpos($id, 'wc-') !== false ||
            strpos($id, 'product') !== false ||
            strpos($id, 'shop_') !== false
        )) {
            return true;
        }

        return false;
    }
}

add_action('admin_init', function() {
    if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
        return;
    }
    
    $opts = get_option('yooadmin_options', []);
    $load_globally = isset($opts['load_woocommerce_globally']) ? (bool)$opts['load_woocommerce_globally'] : false;
    
    if ($load_globally || !class_exists('WooCommerce')) {
        return;
    }
    
    add_action('admin_enqueue_scripts', function($hook) {
        if (yooadmin_wc_optimizer_is_wc_screen($hook)) {
            return;
        }

        global $wp_scripts, $wp_styles;

        if (isset($wp_scripts->registered)) {
            foreach ($wp_scripts->registered as $handle => $script) {
                if (strpos($handle, 'wc-') === 0 ||
                    strpos($handle, 'woocommerce') !== false ||
                    (isset($script->src) && strpos($script->src, 'woocommerce') !== false)) {
                    wp_dequeue_script($handle);
                    wp_deregister_script($handle);
                }
            }
        }

        if (isset($wp_styles->registered)) {
            foreach ($wp_styles->registered as $handle => $style) {
                if (strpos($handle, 'wc-') === 0 ||
                    strpos($handle, 'woocommerce') !== false ||
                    (isset($style->src) && strpos($style->src, 'woocommerce') !== false)) {
                    wp_dequeue_style($handle);
                    wp_deregister_style($handle);
                }
            }
        }
    }, 999);
    
    add_action('admin_head', function() {
        global $pagenow;

        if ($pagenow === 'index.php' || !yooadmin_wc_optimizer_is_wc_screen()) {
            remove_action('admin_notices', 'woothemes_updater_notice');
            remove_action('admin_notices', 'woocommerce_admin_notices');

            remove_meta_box('woocommerce_dashboard_status', 'dashboard', 'normal');
            remove_meta_box('woocommerce_dashboard_recent_reviews', 'dashboard', 'normal');
        }
    }, 999);
}, 20);
