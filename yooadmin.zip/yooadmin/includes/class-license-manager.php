<?php

defined('ABSPATH') || exit;

class YOOAdmin_License_Manager {
    
    private $api_url;
    
    private $management_api_url;
    
    private $grace_period_duration = 604800;
    
    private $force_update_period = 2592000;
    
    private static $instance = null;
    
    private $cached_license_data = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->api_url = 'https://www.yooadmin.io/wp-json/yoopixel-api/v1/';
        $this->management_api_url = function_exists('yooadmin_filter_management_api_url')
            ? yooadmin_filter_management_api_url('https://www.yooadmin.io/wp-json/yoopixel/v1/')
            : 'https://www.yooadmin.io/wp-json/yoopixel/v1/';
    }

    /**
     * @return string
     */
    public static function get_license_portal_connect_url(): string {
        $portal_connect_url = '';
        if (function_exists('yooadmin_filter_license_portal_connect_url')) {
            $portal_connect_url = yooadmin_filter_license_portal_connect_url('');
        }
        if ($portal_connect_url !== '') {
            return $portal_connect_url;
        }
        if (apply_filters('yooadmin_license_use_site_portal', false)) {
            $portal_page_id = (int) get_option('yoopixel_portal_page_id');
            if ($portal_page_id) {
                $portal_base_url = get_permalink($portal_page_id);
                if ($portal_base_url && function_exists('yooadmin_is_allowed_outbound_url') && yooadmin_is_allowed_outbound_url($portal_base_url)) {
                    $portal_connect_url = trailingslashit($portal_base_url) . 'panel-connect/';
                }
            }
            if ($portal_connect_url === '' && class_exists('\YOOPixel\Management\Frontend\Portal')) {
                $portal_connect_url = \YOOPixel\Management\Frontend\Portal::get_portal_url('panel-connect');
                if ($portal_connect_url !== '' && function_exists('yooadmin_is_allowed_outbound_url') && !yooadmin_is_allowed_outbound_url($portal_connect_url)) {
                    $portal_connect_url = '';
                }
            }
        }
        if ($portal_connect_url === '') {
            $portal_base = function_exists('yooadmin_filter_portal_base_url')
                ? yooadmin_filter_portal_base_url('https://www.yooadmin.io/')
                : trailingslashit('https://www.yooadmin.io/');
            $portal_connect_url = $portal_base . 'portal/panel-connect/';
        }
        return $portal_connect_url;
    }

    public function get_license_view_context(): array {
        $license_data    = $this->get_license_data();
        $is_active       = $this->is_license_active();
        $portal_profile  = $this->get_portal_profile();

        yooadmin_bust_license_type_option_caches();
        $all_license_types = yooadmin_get_effective_license_types();
        $license_type_labels = [];
        $license_type_colors = [];

        foreach ($all_license_types as $type_key => $type_config) {
            $license_type_labels[$type_key] = $type_config['name'] ?? ucfirst($type_key);
            $license_type_colors[$type_key] = $type_config['color'] ?? '#95a5a6';
        }

        $current_license_type = $license_data['license_type'] ?? null;
        
        if (!empty($current_license_type) && !isset($license_type_labels[$current_license_type])) {
            $found_match = false;
            $original_license_type = $current_license_type;
            $normalized_current = strtolower(str_replace(['-', '_', ' '], '', $current_license_type));
            
            foreach ($all_license_types as $type_key => $type_config) {
                if (strtolower($type_key) === strtolower($current_license_type)) {
                    $current_license_type = $type_key;
                    $found_match = true;
                    break;
                }
            }
            
            if (!$found_match) {
            }
            
            if ($found_match && isset($all_license_types[$current_license_type])) {
                $license_type_labels[$current_license_type] = $all_license_types[$current_license_type]['name'] ?? ucfirst($current_license_type);
                $license_type_colors[$current_license_type] = $all_license_types[$current_license_type]['color'] ?? '#95a5a6';
            }
        }

        $license_page_url = admin_url('admin.php?page=yooadmin-license');
        if (class_exists('\YOOPixel\Management\Frontend\Portal')) {
            $get_license_url = \YOOPixel\Management\Frontend\Portal::get_portal_url('register');
        } else {
            $portal_base = function_exists('yooadmin_filter_portal_base_url')
                ? yooadmin_filter_portal_base_url('https://www.yooadmin.io/')
                : trailingslashit('https://www.yooadmin.io/');
            $get_license_url = $portal_base . 'portal/register/';
        }
        $get_license_url = add_query_arg([
            'return_url' => urlencode($license_page_url),
            'source'     => 'yooadmin',
        ], $get_license_url);

        if (class_exists('\YOOPixel\Management\Frontend\Portal')) {
            $portal_login_url = \YOOPixel\Management\Frontend\Portal::get_portal_url('login');
        } else {
            $portal_base = function_exists('yooadmin_filter_portal_base_url')
                ? yooadmin_filter_portal_base_url('https://www.yooadmin.io/')
                : trailingslashit('https://www.yooadmin.io/');
            $portal_login_url = $portal_base . 'portal/login/';
        }
        $portal_login_url = add_query_arg([
            'redirect_to' => urlencode($license_page_url),
            'source'      => 'yooadmin',
        ], $portal_login_url);

        $portal_connect_url = self::get_license_portal_connect_url();

        $context = [
            'license_data'         => $license_data,
            'is_active'            => $is_active,
            'license_type_labels'  => $license_type_labels,
            'license_type_colors'  => $license_type_colors,
            'current_license_type' => $current_license_type,
            'all_license_types'    => $all_license_types,
            'portal_profile'       => $portal_profile,
            'site_domain'          => $this->normalize_domain(get_site_url()),
            'get_license_url'      => $get_license_url,
            'portal_login_url'     => $portal_login_url,
            'portal_connect_url'   => $portal_connect_url,
        ];

        return apply_filters('yooadmin_license_view_context', $context);
    }
    
    private function build_management_api_url(string $path = ''): string {
        $base = trailingslashit($this->management_api_url);
        $path = ltrim($path, '/');
        return $base . $path;
    }
    
    private function get_management_request_headers(): array {
        $plugin_version = defined('YOOADMIN_VERSION') ? YOOADMIN_VERSION : '1.0.0';
        
        return [
            'Accept'       => 'application/json',
            'Content-Type' => 'application/json',
            'User-Agent'   => 'YOOAdmin/' . $plugin_version . '; ' . get_site_url(),
        ];
    }

    /**
     * @param array<string, mixed> $args
     * @return array<string, mixed>
     */
    private function remote_http_args(array $args): array {
        return array_merge(['sslverify' => true], $args);
    }
    
    public function fetch_portal_session(string $token, string $domain = ''): array {
        $token = trim($token);
        
        if ($token === '') {
            return [
                'success' => false,
                'message' => __('Missing session token.', 'yooadmin'),
            ];
        }
        
        $endpoint = 'panel/session/' . rawurlencode($token);
        $url      = $this->build_management_api_url($endpoint);
        
        if ($domain !== '') {
            $url = add_query_arg(
                ['domain' => rawurlencode($domain)],
                $url
            );
        }
        
        $response = wp_remote_get($url, $this->remote_http_args([
            'timeout' => 20,
            'headers' => $this->get_management_request_headers(),
        ]));
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
            ];
        }
        
        $code = (int) wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!is_array($data)) {
            return [
                'success' => false,
                /* translators: %d: HTTP response code */
                'message' => sprintf(__('Unexpected response (%d).', 'yooadmin'), $code),
            ];
        }
        
        if (empty($data['ok'])) {
            $message = '';
            if (!empty($data['message'])) {
                $message = (string) $data['message'];
            } elseif (!empty($data['msg'])) {
                $message = (string) $data['msg'];
            } elseif (!empty($data['error'])) {
                $message = (string) $data['error'];
            }
            
            if ($message === '') {
                $message = __('Unable to load portal session.', 'yooadmin');
            }
            
            return [
                'success' => false,
                'message' => $message,
                'data'    => $data,
            ];
        }
        
        $user     = isset($data['user']) && is_array($data['user']) ? $this->sanitize_portal_user($data['user']) : [];
        $licenses = isset($data['licenses']) && is_array($data['licenses']) ? $this->sanitize_portal_licenses($data['licenses']) : [];
        
        return [
            'success'    => true,
            'user'       => $user,
            'licenses'   => $licenses,
            'expires_at' => isset($data['expires_at']) ? sanitize_text_field((string) $data['expires_at']) : null,
            'raw'        => $data,
        ];
    }

    public function start_portal_session(): array {
        $url = $this->build_management_api_url('panel/session/start');

        $payload = [
            'nonce' => wp_create_nonce('yoopxl_panel_session'),
        ];

        $response = wp_remote_post($url, $this->remote_http_args([
            'timeout' => 15,
            'headers' => $this->get_management_request_headers(),
            'body'    => wp_json_encode($payload),
        ]));

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
            ];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!is_array($data)) {
            $status = (int) wp_remote_retrieve_response_code($response);
            return [
                'success' => false,
                /* translators: %d: HTTP status code */
                'message' => sprintf(__('Unexpected response (%d).', 'yooadmin'), $status),
            ];
        }

        if (empty($data['ok']) || empty($data['token'])) {
            $message = '';

            if (!empty($data['message'])) {
                $message = (string) $data['message'];
            } elseif (!empty($data['msg'])) {
                $message = (string) $data['msg'];
            } elseif (!empty($data['error'])) {
                $message = (string) $data['error'];
            }

            if ($message === '') {
                $message = __('Unable to create portal session. Please try again.', 'yooadmin');
            }

            return [
                'success' => false,
                'message' => $message,
                'data'    => $data,
            ];
        }

        return [
            'success'    => true,
            'token'      => sanitize_text_field((string) $data['token']),
            'expires_at' => isset($data['expires_at']) ? sanitize_text_field((string) $data['expires_at']) : null,
        ];
    }
    
    public function logout_portal_session(string $token): array {
        $token = trim($token);
        
        if ($token === '') {
            return [
                'success' => false,
                'message' => __('Missing session token.', 'yooadmin'),
            ];
        }
        
        $url = $this->build_management_api_url('panel/session/' . rawurlencode($token) . '/logout');
        
        $response = wp_remote_post($url, $this->remote_http_args([
            'timeout' => 15,
            'headers' => $this->get_management_request_headers(),
        ]));
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
            ];
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (is_array($data) && !empty($data['ok'])) {
            return [
                'success' => true,
            ];
        }
        
        return [
            'success' => false,
            'message' => isset($data['message']) ? (string) $data['message'] : __('Failed to end portal session.', 'yooadmin'),
        ];
    }
    
    public function store_portal_profile(array $profile): void {
        $sanitized = $this->sanitize_portal_user($profile);
        
        if (empty($sanitized)) {
            return;
        }
        
        $license_data = $this->get_license_data();
        $sanitized['synced_at'] = current_time('mysql');
        $license_data['portal_profile'] = $sanitized;
        
        $this->save_license_data($license_data);
    }
    
    public function clear_portal_profile(): void {
        $license_data = $this->get_license_data();
        
        if (array_key_exists('portal_profile', $license_data)) {
            unset($license_data['portal_profile']);
            
            if (empty($license_data)) {
                delete_option('yooadmin_license_data');
            } else {
                $this->save_license_data($license_data);
            }
        }
    }
    
    public function get_portal_profile(): ?array {
        $license_data = $this->get_license_data();
        $profile      = $license_data['portal_profile'] ?? null;
        
        if (!is_array($profile) || empty($profile)) {
            return null;
        }
        
        $sanitized = $this->sanitize_portal_user($profile);
        
        if (empty($sanitized)) {
            return null;
        }
        
        if (!empty($profile['synced_at'])) {
            $sanitized['synced_at'] = sanitize_text_field((string) $profile['synced_at']);
        }
        
        return $sanitized;
    }
    
    private function sanitize_portal_user(array $user): array {
        if (empty($user)) {
            return [];
        }
        
        return [
            'id'           => isset($user['id']) ? (int) $user['id'] : 0,
            'display_name' => isset($user['display_name']) ? sanitize_text_field((string) $user['display_name']) : '',
            'email'        => isset($user['email']) ? sanitize_email((string) $user['email']) : '',
            'avatar_url'   => isset($user['avatar_url']) ? esc_url_raw((string) $user['avatar_url']) : '',
        ];
    }
    
    private function sanitize_portal_licenses(array $licenses): array {
        $sanitized = [];
        
        foreach ($licenses as $license) {
            if (!is_array($license)) {
                continue;
            }
            
            $activation_code = isset($license['activation_code']) ? sanitize_text_field((string) $license['activation_code']) : '';
            
            if ($activation_code === '') {
                continue;
            }
            
            $usage = [];
            if (isset($license['usage']) && is_array($license['usage'])) {
                $usage = [
                    'used' => isset($license['usage']['used']) ? (int) $license['usage']['used'] : 0,
                    'max'  => isset($license['usage']['max']) ? (int) $license['usage']['max'] : 0,
                ];
            }
            
            $sanitized[] = [
                'id'                     => isset($license['id']) ? (int) $license['id'] : 0,
                'activation_code'        => $activation_code,
                'activation_code_masked' => isset($license['activation_code_masked']) ? sanitize_text_field((string) $license['activation_code_masked']) : '',
                'product_name'           => isset($license['product_name']) ? sanitize_text_field((string) $license['product_name']) : '',
                'license_type'           => isset($license['license_type']) ? sanitize_text_field((string) $license['license_type']) : '',
                'status'                 => isset($license['status']) ? sanitize_text_field((string) $license['status']) : '',
                'domain'                 => isset($license['domain']) ? sanitize_text_field((string) $license['domain']) : '',
                'domain_status'          => isset($license['domain_status']) ? sanitize_text_field((string) $license['domain_status']) : '',
                'eligible'               => !empty($license['eligible']),
                'expires_at'             => isset($license['expires_at']) ? sanitize_text_field((string) $license['expires_at']) : null,
                'support_expires_at'     => isset($license['support_expires_at']) ? sanitize_text_field((string) $license['support_expires_at']) : null,
                'updates_expires_at'     => isset($license['updates_expires_at']) ? sanitize_text_field((string) $license['updates_expires_at']) : null,
                'usage'                  => $usage,
            ];
        }
        
        return $sanitized;
    }
    
    public function init() {
        add_action('wp_ajax_yooadmin_activate_license', [$this, 'ajax_activate_license']);
        add_action('wp_ajax_yooadmin_deactivate_license', [$this, 'ajax_deactivate_license']);
        add_action('wp_ajax_yooadmin_check_license', [$this, 'ajax_check_license']);
        add_action('wp_ajax_yooadmin_refresh_license_view', [$this, 'ajax_refresh_license_view']);
        add_action('init', [$this, 'maybe_check_license_status']);
        if (class_exists('YOOAdmin_Webhook_Receiver')) {
            \YOOAdmin_Webhook_Receiver::get_instance();
        }
    }
    
    public function get_license_data_for_template() {
        return [
            'license_data' => $this->get_license_data(),
            'is_active' => $this->is_license_active(),
        ];
    }
    
    public function maybe_check_license_status() {
        if ( ! is_admin() && ! wp_doing_cron() && ! ( defined( 'WP_CLI' ) && constant( 'WP_CLI' ) ) ) {
            return;
        }

        $license_data = $this->get_license_data();
        
        $current_status = $license_data['status'] ?? 'inactive';
        if ($current_status === 'inactive') {
            return;
        }

        // On the license page: always check live (no grace period)
        $is_license_page = is_admin()
            && isset( $_GET['page'] ) // phpcs:ignore WordPress.Security.NonceVerification
            && sanitize_key( wp_unslash( $_GET['page'] ) ) === 'yooadmin-license'; // phpcs:ignore WordPress.Security.NonceVerification
        if ( $is_license_page && ! empty( $license_data['jwt_token'] ) ) {
            $this->check_license_status();
            return;
        }
        
        if (in_array($current_status, ['suspended', 'revoked', 'expired'])) {
            $last_check = $license_data['last_checked'] ?? '';
            $check_interval = 15 * MINUTE_IN_SECONDS;
            
            if (!empty($last_check)) {
                $last_check_time = strtotime($last_check);
                $time_since_check = time() - $last_check_time;
                
                if ($time_since_check < $check_interval) {
                    return;
                }
            }
            
            if (!empty($license_data['activation_code'])) {
                
                $secret_result = $this->get_secret_for_hmac($license_data['activation_code'], $license_data['site_url']);
                
                if ($secret_result['success'] && !empty($secret_result['secret_key'])) {
                    $refresh_result = $this->refresh_jwt_with_hmac($license_data['activation_code'], $license_data['site_url'], $secret_result['secret_key']);
                    
                    if ($refresh_result['success']) {
                    }
                }
            }
            
            return;
        }
        
        if (empty($license_data['jwt_token']) && !empty($license_data['activation_code'])) {
            
            $secret_result = $this->get_secret_for_hmac($license_data['activation_code'], $license_data['site_url']);
            
            if ($secret_result['success'] && !empty($secret_result['secret_key'])) {
                $refresh_result = $this->refresh_jwt_with_hmac($license_data['activation_code'], $license_data['site_url'], $secret_result['secret_key']);
            }
            
            return;
        }
        
        if (empty($license_data['jwt_token'])) {
            return;
        }
        
        if ($this->is_force_update_required()) {
            $result = $this->check_license_status();
            
        } elseif ($this->is_in_grace_period()) {
        } else {
            $result = $this->check_license_status();
        }
    }
    
    public function ajax_refresh_license_view() {
        check_ajax_referer('yooadmin_license_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'yooadmin')]);
        }

        $context = $this->get_license_view_context();

        $html = $this->render_license_status_markup($context);

        wp_send_json_success([
            'html'     => $html,
            'license'  => $context['license_data'],
            'isActive' => $context['is_active'],
            'is_active' => $context['is_active'],
            'status' => $context['license_data']['status'] ?? 'inactive',
        ]);
    }

    public function render_license_status_markup(array $context): string {
        $template = apply_filters(
            'yooadmin_license_status_template',
            trailingslashit(YOOADMIN_DIR) . 'templates/admin/partials/license-status.php'
        );

        if (!file_exists($template)) {
            return '';
        }

        extract($context, EXTR_SKIP);

        ob_start();
        include $template;
        return (string) ob_get_clean();
    }
    
    public function ajax_activate_license() {
        check_ajax_referer('yooadmin_license_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'yooadmin')]);
        }
        
        $activation_code = isset($_POST['activation_code']) ? sanitize_text_field(wp_unslash($_POST['activation_code'])) : '';
        
        if (empty($activation_code)) {
            wp_send_json_error(['message' => __('Activation code is required.', 'yooadmin')]);
        }
        
        $result = $this->activate_license($activation_code);
        
        if ($result['success']) {
            update_option('yooadmin_license_status_changed', true);
            delete_option('yooadmin_previous_license_status');
            
            if (function_exists('yooadmin_get_integration')) {
                $integration = yooadmin_get_integration();
                if ($integration && method_exists($integration, 'get_notifications')) {
                    $user_id = get_current_user_id();
                    if (isset($integration->cache) && $integration->cache) {
                        $integration->cache->clear();
                    }
                    $integration->get_notifications($user_id);
                }
            }
            
            yooadmin_bust_license_type_option_caches();
            $all_license_types = yooadmin_get_effective_license_types();
            
            $response = [
                'message' => __('Account connected successfully!', 'yooadmin'),
                'license' => $result['license'],
                'all_license_types' => $all_license_types,
            ];
            
            wp_send_json_success($response);
        } else {
            wp_send_json_error([
                'message' => $result['message'] ?? __('License activation failed.', 'yooadmin'),
            ]);
        }
    }

    public function ajax_deactivate_license() {
        check_ajax_referer('yooadmin_license_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'yooadmin')]);
        }
        
        $result = [
            'success' => false,
            'api_success' => false,
            'api_error' => null
        ];
        try {
            $result = $this->deactivate_license();
        } catch (\Throwable $e) {
            $result['api_error'] = $e->getMessage();
        }
        
        update_option('yooadmin_license_status_changed', true);
        delete_option('yooadmin_previous_license_status');
        
        if (function_exists('yooadmin_get_integration')) {
            $integration = yooadmin_get_integration();
            if ($integration && method_exists($integration, 'get_notifications')) {
                $user_id = get_current_user_id();
                if (method_exists($integration, 'clear_all_caches')) {
                    $integration->clear_all_caches();
                }
                $integration->get_notifications($user_id);
            }
        }
        
        $message = __('License deactivated successfully!', 'yooadmin');
        if (!$result['api_success'] && $result['api_error']) {
        }
        
        wp_send_json_success([
            'message' => $message,
            'api_success' => $result['api_success'],
            'api_error' => $result['api_error']
        ]);
    }
    
    public function ajax_check_license() {
        check_ajax_referer('yooadmin_license_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'yooadmin')]);
        }
        
        $result = $this->check_license_status();
        
        if ($result['success']) {
            wp_send_json_success([
                'message' => __('License is valid.', 'yooadmin'),
                'license' => $result['license'],
            ]);
        } else {
            $license_data = $this->get_license_data();
            $status = $license_data['status'] ?? 'inactive';
            
            if ($status === 'expired') {
                $message = __('This license has expired. Please renew your subscription to restore access.', 'yooadmin');
            } elseif ($status === 'suspended') {
                $message = __('License is suspended. Please contact support.', 'yooadmin');
            } elseif ($status === 'revoked') {
                $message = __('License has been revoked.', 'yooadmin');
            } else {
                $message = $result['message'] ?? __('License check failed.', 'yooadmin');
            }
            
            if (!empty($result['reason'])) {
                $message .= ' ' . $result['reason'];
            }
            
            wp_send_json_error([
                'message' => $message,
                'status' => $status,
                'reason' => $result['reason'] ?? '',
                'reload' => true,
            ]);
        }
    }
    
    public function activate_license($activation_code) {
        $site_url = get_site_url();
        
        delete_option('yooadmin_license_data');

        $attach_response = wp_remote_post($this->api_url . 'attach-domain-for-activation', $this->remote_http_args([
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode([
                'activation_code' => $activation_code,
                'site_url' => $site_url,
            ]),
            'timeout' => 30,
        ]));

        if (is_wp_error($attach_response)) {
            return [
                'success' => false,
                'message' => __('Connection error: ', 'yooadmin') . $attach_response->get_error_message(),
            ];
        }

        $attach_body = wp_remote_retrieve_body($attach_response);
        $attach_data = json_decode($attach_body, true);
        if (!is_array($attach_data) || empty($attach_data['ok'])) {
            $attach_error_code = is_array($attach_data) ? (string) ($attach_data['error'] ?? '') : '';
            $attach_error = is_array($attach_data) ? ($attach_data['msg'] ?? '') : '';
            if ($attach_error === '' && $attach_error_code !== '') {
                if ($attach_error_code === 'domain_in_use') {
                    $attach_error = __('This domain is already registered to another account.', 'yooadmin');
                } elseif ($attach_error_code === 'usage_limit') {
                    $attach_error = __('License usage limit reached for this activation code.', 'yooadmin');
                } elseif ($attach_error_code === 'domain_on_other_license') {
                    $attach_error = __('This domain is attached to another license in your account. Remove it there first.', 'yooadmin');
                } elseif ($attach_error_code === 'suspended') {
                    $attach_error = __('This license is suspended.', 'yooadmin');
                } elseif ($attach_error_code === 'revoked') {
                    $attach_error = __('This license has been revoked.', 'yooadmin');
                } elseif ($attach_error_code === 'invalid_code') {
                    $attach_error = __('Activation code does not exist.', 'yooadmin');
                }
            }
            return [
                'success' => false,
                'message' => $attach_error !== '' ? $attach_error : __('Failed to attach this domain to the license.', 'yooadmin'),
            ];
        }
        
        $endpoint_url = $this->api_url . 'get-secret-for-activation';
        
        $request_body = [
            'activation_code' => $activation_code,
            'site_url' => $site_url,
        ];
        
        $secret_response = wp_remote_post($endpoint_url, $this->remote_http_args([
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode($request_body),
            'timeout' => 30,
        ]));
        
        if (is_wp_error($secret_response)) {
            return [
                'success' => false,
                'message' => __('Connection error: ', 'yooadmin') . $secret_response->get_error_message(),
            ];
        }
        
        $secret_body = wp_remote_retrieve_body($secret_response);
        $secret_data = json_decode($secret_body, true);
        
        if (!isset($secret_data['ok']) || !$secret_data['ok']) {
            $error_msg = $secret_data['msg'] ?? __('Failed to verify license.', 'yooadmin');
            
            return [
                'success' => false,
                'message' => $error_msg,
                'debug' => $secret_data['debug'] ?? null,
            ];
        }
        
        $secret_key = $secret_data['secret_key'] ?? '';
        if (empty($secret_key)) {
            return [
                'success' => false,
                'message' => __('Failed to retrieve license key.', 'yooadmin'),
            ];
        }
        
        $timestamp = time();
        $nonce = bin2hex(random_bytes(16));
        $normalized_site_url = $this->normalize_url_for_hmac($site_url);
        $message = "{$activation_code}|{$normalized_site_url}|{$timestamp}|{$nonce}";
        $hmac = hash_hmac('sha256', $message, $secret_key);
        
        $plugin_version = defined('YOOADMIN_VERSION') ? YOOADMIN_VERSION : '1.3.0';
        $webhook_url = rest_url('yooadmin/v1/webhook');
        
        $response = wp_remote_post($this->api_url . 'activate', $this->remote_http_args([
            'headers' => [
                'Content-Type' => 'application/json',
                'User-Agent' => 'YOOAdmin/' . $plugin_version . '; ' . $site_url,
            ],
            'body' => wp_json_encode([
                'activation_code' => $activation_code,
                'site_url' => $site_url,
                'webhook_url' => $webhook_url,
                'ts' => $timestamp,
                'nonce' => $nonce,
                'hmac' => $hmac,
            ]),
            'timeout' => 30,
        ]));
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
            ];
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['ok']) || !$data['ok']) {
            return [
                'success' => false,
                'message' => $data['msg'] ?? __('Activation failed.', 'yooadmin'),
            ];
        }
        
        $resp_license_type = isset($data['license']['license_type']) ? strtolower((string)$data['license']['license_type']) : null;
        
        if (empty($resp_license_type) && !empty($data['jwt'])) {
            $jwt_parts = explode('.', $data['jwt']);
            if (count($jwt_parts) === 3) {
                $payload = json_decode(base64_decode(strtr($jwt_parts[1], '-_', '+/')), true);
                if (isset($payload['license_type'])) {
                    $resp_license_type = strtolower((string)$payload['license_type']);
                }
            }
        }

        $license_data = [
            'activation_code' => $activation_code,
            'jwt_token' => $data['jwt'] ?? '',
            'client_name' => $data['license']['client_name'] ?? '',
            'client_email' => $data['license']['client_email'] ?? '',
            'site_url' => $data['license']['site_url'] ?? $site_url,
            'site_type' => $data['license']['site_type'] ?? 'single',
            'license_type' => $resp_license_type,
            'status' => $data['license']['status'] ?? 'inactive',
            'max_usage' => $data['license']['max_usage'] ?? 0,
            'usage_count' => $data['license']['usage_count'] ?? 0,
            'support_start' => $data['license']['support_start'] ?? null,
            'support_end' => $data['license']['support_end'] ?? null,
            'expires_at' => $data['license']['expires_at'] ?? null,
            'activated_at' => current_time('mysql'),
            'last_checked' => current_time('mysql'),
        ];
        
        $license_data['last_successful_check'] = time();
        $license_data['server_timestamp'] = time();
        
        if (!empty($data['all_license_types']) && is_array($data['all_license_types'])) {
            yooadmin_set_api_license_types_cache($data['all_license_types']);
        }
        
        $saved = $this->save_license_data($license_data);
        
        if ($saved === false) {
            return [
                'success' => false,
                'message' => __('License activated on server but failed to save locally. Please try again.', 'yooadmin'),
            ];
        }
        
        $this->get_webhook_secret();
        
        return [
            'success' => true,
            'license' => $license_data,
        ];
    }
    
    public function deactivate_license() {
        $license_data = get_option('yooadmin_license_data');
        
        $api_success = false;
        $api_error = null;
        
        
        try {
            if (!empty($license_data['activation_code'])) {
                $activation_code = $license_data['activation_code'];
                $site_url = get_site_url();
                
                $secret_endpoint = 'https://www.yooadmin.io/wp-json/yoopixel-api/v1/get-secret-for-activation';
                
                $secret_response = wp_remote_post($secret_endpoint, $this->remote_http_args([
                    'headers' => [
                        'Content-Type' => 'application/json',
                    ],
                    'body' => wp_json_encode([
                        'activation_code' => $activation_code,
                        'site_url' => $site_url,
                    ]),
                    'timeout' => 15,
                ]));
                
                if (!is_wp_error($secret_response)) {
                    $secret_body = wp_remote_retrieve_body($secret_response);
                    $secret_data = json_decode($secret_body, true);
                    
                    if (isset($secret_data['ok']) && $secret_data['ok'] && !empty($secret_data['secret_key'])) {
                        $secret_key = $secret_data['secret_key'];
                        
                        $ts = time();
                        $nonce = bin2hex(random_bytes(16));
                        $message = $activation_code . '|' . $site_url . '|' . $ts . '|' . $nonce;
                        $hmac = hash_hmac('sha256', $message, $secret_key);
                        
                        $revoke_url = 'https://www.yooadmin.io/wp-json/yoopixel-api/v1/revoke';
                        
                        $response = wp_remote_post($revoke_url, $this->remote_http_args([
                            'body' => [
                                'activation_code' => $activation_code,
                                'site_url' => $site_url,
                                'ts' => $ts,
                                'nonce' => $nonce,
                                'hmac' => $hmac,
                                'reason' => 'License deactivated by user'
                            ],
                            'timeout' => 15,
                            'headers' => [
                                'User-Agent' => 'YOOAdmin/' . YOOADMIN_VERSION . ' (WordPress/' . get_bloginfo('version') . ')'
                            ]
                        ]));
                        
                        if (is_wp_error($response)) {
                            $api_error = $response->get_error_message();
                        } else {
                            $body = wp_remote_retrieve_body($response);
                            $response_data = json_decode($body, true);
                            
                            if (isset($response_data['ok']) && $response_data['ok']) {
                                $api_success = true;
                            } else {
                                $api_error = isset($response_data['error']) ? $response_data['error'] : 'Unknown API error';
                            }
                        }
                    } else {
                        $api_error = 'Failed to get secret_key from server';
                    }
                } else {
                    $api_error = $secret_response->get_error_message();
                }
            }
        } catch (\Throwable $e) {
            $api_error = $e->getMessage();
        }
        
        delete_option('yooadmin_license_data');
        wp_cache_delete('yooadmin_license_data', 'options');
        $this->cached_license_data = null;
        
        return [
            'success' => true,
            'api_success' => $api_success,
            'api_error' => $api_error
        ];
    }
    
    public function check_license_status() {
        $license_data = $this->get_license_data();
        $current_status = $license_data['status'] ?? 'inactive';
        if ($current_status === 'inactive') {
            return [
                'success' => false,
                'message' => __('License is inactive. Please activate your license.', 'yooadmin'),
                'status' => 'inactive',
            ];
        }
        
        if (empty($license_data['jwt_token'])) {
            return [
                'success' => false,
                'message' => __('No license activated.', 'yooadmin'),
            ];
        }
        
        $check_url = $this->api_url . 'check';
        $activation_code = $license_data['activation_code'] ?? '';
        $site_url = $license_data['site_url'] ?? get_site_url();
        $ts = time();
        $nonce = bin2hex(random_bytes(16));
        $secret_result = $this->get_secret_for_hmac($activation_code, $site_url);

        if (empty($secret_result['success'])) {
            return [
                'success' => false,
                'message' => __('Unable to verify license (missing secret). Please try again later.', 'yooadmin'),
            ];
        }

        $secret_key = $secret_result['secret_key'] ?? '';
        if (!empty($secret_key) && empty($license_data['secret_key'])) {
            $license_data['secret_key'] = $secret_key;
            $this->save_license_data($license_data);
        }
        if (empty($secret_key)) {
            return [
                'success' => false,
                'message' => __('Unable to verify license (empty secret).', 'yooadmin'),
            ];
        }

        $normalized_site_url = $this->normalize_url_for_hmac($site_url);
        $message = $activation_code . '|' . $normalized_site_url . '|' . $ts . '|' . $nonce;
        $hmac = hash_hmac('sha256', $message, $secret_key);

        $response = wp_remote_post($check_url, $this->remote_http_args([
            'timeout' => 30,
            'body' => [
                'activation_code' => $activation_code,
                'site_url' => $site_url,
                'ts' => $ts,
                'nonce' => $nonce,
                'hmac' => $hmac
            ]
        ]));
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
                'transient_failure' => true,
            ];
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        $api_data = $data['data'] ?? $data;
        
        if (!isset($data['ok']) || !$data['ok']) {
            if (!empty($data['error']) && in_array($data['error'], ['invalid_token', 'license_changed']) && !empty($license_data['activation_code'])) {
                
                $secret_result = $this->get_secret_for_hmac($license_data['activation_code'], $license_data['site_url']);
                
                if ($secret_result['success'] && !empty($secret_result['secret_key'])) {
                    $refresh_result = $this->refresh_jwt_with_hmac($license_data['activation_code'], $license_data['site_url'], $secret_result['secret_key']);
                    
                    if ($refresh_result['success']) {
                        return $refresh_result;
                    }
                }
            }
            
            $is_token_error = !empty($api_data['error']) && in_array($api_data['error'], ['invalid_token', 'expired', 'license_changed'], true);

            if ($is_token_error) {
                return [
                    'success' => false,
                    'message' => $api_data['msg'] ?? __('License token is invalid or expired. Please refresh.', 'yooadmin'),
                    'status' => $license_data['status'] ?? 'unknown',
                    'reason' => $api_data['reason'] ?? '',
                    'token_error' => true,
                ];
            }

            // Domain removed: keep data, just deactivate
            if (!empty($api_data['error']) && $api_data['error'] === 'domain_removed') {
                $license_data['status'] = 'inactive';
                $license_data['last_checked'] = current_time('mysql');
                $this->save_license_data($license_data);
                return ['success' => false, 'status' => 'inactive', 'deactivated' => true];
            }

            $blocked = !empty($api_data['error']) && in_array($api_data['error'], ['suspended', 'revoked', 'expired', 'inactive', 'deleted'], true);
            if ($blocked) {
                $license_data['status'] = ($api_data['error'] === 'deleted') ? 'inactive' : $api_data['error'];
                if (!empty($api_data['reason'])) {
                    $license_data['status_reason'] = $api_data['reason'];
                }
                if (!empty($api_data['msg'])) {
                    $license_data['status_message'] = $api_data['msg'];
                }
                if (isset($api_data['server_timestamp'])) {
                    $license_data['server_timestamp'] = intval($api_data['server_timestamp']);
                } else {
                    $license_data['server_timestamp'] = time();
                }
                $license_data['last_checked'] = current_time('mysql');
                $this->save_license_data($license_data);

                $message = $api_data['reason'] ?? ($api_data['msg'] ?? __('License check failed.', 'yooadmin'));
                return [
                    'success' => false,
                    'message' => $message,
                    'status' => $license_data['status'],
                    'reason' => $api_data['reason'] ?? '',
                ];
            }

            return [
                'success' => false,
                'message' => $api_data['msg'] ?? __('License check failed.', 'yooadmin'),
                'transient_failure' => true,
            ];
        }
        
        $license_data['status'] = $api_data['license']['status'] ?? 'inactive';
        
        if ($license_data['status'] === 'active') {
            unset($license_data['status_reason']);
            unset($license_data['status_message']);
        }
        
        if (!empty($api_data['jwt_token'])) {
            $license_data['jwt_token'] = $api_data['jwt_token'];
        }
        
        if (isset($api_data['license']['license_type'])) {
            $license_data['license_type'] = strtolower((string) $api_data['license']['license_type']);
        } elseif (!empty($api_data['jwt_token'])) {
            $from_jwt = $this->license_type_from_jwt_token($api_data['jwt_token']);
            if ($from_jwt !== null) {
                $license_data['license_type'] = $from_jwt;
            }
        }
        
        if (!empty($api_data['all_license_types']) && is_array($api_data['all_license_types'])) {
            yooadmin_set_api_license_types_cache($api_data['all_license_types']);
        }
        if (isset($api_data['license']['max_usage'])) {
            $license_data['max_usage'] = $api_data['license']['max_usage'];
        }
        if (isset($api_data['license']['usage_count'])) {
            $license_data['usage_count'] = $api_data['license']['usage_count'];
        }
        if (isset($api_data['license']['expires_at'])) {
            $license_data['expires_at'] = $api_data['license']['expires_at'];
        }
        if (isset($api_data['license']['support_start'])) {
            $license_data['support_start'] = $api_data['license']['support_start'];
        }
        if (isset($api_data['license']['support_end'])) {
            $license_data['support_end'] = $api_data['license']['support_end'];
        }
        if (empty($license_data['activated_at'])) {
            $license_data['activated_at'] = current_time('mysql');
        }
        $license_data['last_checked'] = current_time('mysql');
        $license_data['last_successful_check'] = time();
        $license_data['server_timestamp'] = time();
        $this->save_license_data($license_data);
        
        return [
            'success' => true,
            'license' => $license_data,
        ];
    }
    
    public function get_webhook_secret() {
        $license_data = $this->get_license_data();
        
        if (empty($license_data['activation_code']) || empty($license_data['site_url'])) {
            return '';
        }
        
        if (!empty($license_data['secret_key'])) {
            return $license_data['secret_key'];
        }
        
        $secret_result = $this->get_secret_for_hmac(
            $license_data['activation_code'],
            $license_data['site_url']
        );
        
        if (!empty($secret_result['secret_key'])) {
            $license_data['secret_key'] = $secret_result['secret_key'];
            $this->save_license_data($license_data);
            return $secret_result['secret_key'];
        }
        
        return '';
    }
    
    private function normalize_url_for_hmac($url) {
        $url = strtolower(trim($url));
        $url = preg_replace('#^https?://#', '', $url);
        $url = preg_replace('#^www\.#', '', $url);
        $url = rtrim($url, '/');
        return $url;
    }

    /**
     * Read license_type from JWT payload (yoopixel/v1/check includes it even when license[] omits it on older APIs).
     *
     * @param string $jwt_token
     * @return string|null
     */
    private function license_type_from_jwt_token($jwt_token) {
        if (empty($jwt_token) || !is_string($jwt_token)) {
            return null;
        }
        $parts = explode('.', $jwt_token);
        if (count($parts) !== 3) {
            return null;
        }
        $payload_raw = base64_decode(strtr($parts[1], '-_', '+/'), true);
        if ($payload_raw === false) {
            return null;
        }
        $payload = json_decode($payload_raw, true);
        if (!is_array($payload) || !isset($payload['license_type'])) {
            return null;
        }
        return strtolower((string) $payload['license_type']);
    }
    
    private function get_secret_for_hmac($activation_code, $site_url) {
        $secret_url = 'https://www.yooadmin.io/wp-json/yoopixel/v1/get-secret-for-activation';
        
        $response = wp_remote_post($secret_url, $this->remote_http_args([
            'body' => [
                'activation_code' => $activation_code,
                'site_url' => $site_url
            ],
            'timeout' => 15
        ]));
        
        if (is_wp_error($response)) {
            return ['success' => false];
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!empty($data['error']) && in_array($data['error'], ['suspended', 'revoked', 'expired', 'invalid_code', 'deleted'])) {
            
            $license_data = $this->get_license_data();
            
            if ($data['error'] === 'invalid_code' || $data['error'] === 'deleted') {
                $license_data['status'] = 'inactive';
                $license_data['status_message'] = $data['error'] === 'deleted' ? 'License has been deleted.' : 'License has been removed from server.';
                delete_option('yooadmin_license_data');
                
                return [
                    'success' => false,
                    'invalid_code' => true,
                    'deactivated' => true
                ];
            }
            
            $license_data['status'] = $data['error'];
            
            if (!empty($data['reason'])) {
                $license_data['status_reason'] = $data['reason'];
            }
            
            if (!empty($data['msg'])) {
                $license_data['status_message'] = $data['msg'];
            }
            
            if (isset($data['server_timestamp'])) {
                $license_data['server_timestamp'] = intval($data['server_timestamp']);
            } else {
                $license_data['server_timestamp'] = time();
            }
            
            $license_data['last_checked'] = current_time('mysql');
            $this->save_license_data($license_data);
            
            return [
                'success' => false,
                'suspended_or_revoked' => true
            ];
        }
        
        if (isset($data['ok']) && $data['ok'] && !empty($data['secret_key'])) {
            return [
                'success' => true,
                'secret_key' => $data['secret_key']
            ];
        }

        // Domain removed from client_sites: deactivate without deleting data
        if (!empty($data['error']) && $data['error'] === 'domain_mismatch') {
            $license_data = $this->get_license_data();
            $license_data['status'] = 'inactive';
            $license_data['last_checked'] = current_time('mysql');
            $this->save_license_data($license_data);
            return ['success' => false, 'deactivated' => true, 'domain_mismatch' => true];
        }
        
        return ['success' => false];
    }
    
    private function refresh_jwt_with_hmac($activation_code, $site_url, $secret_key) {
        $ts = time();
        $nonce = bin2hex(random_bytes(16));
        $normalized_site_url = $this->normalize_url_for_hmac($site_url);
        $message = $activation_code . '|' . $normalized_site_url . '|' . $ts . '|' . $nonce;
        $hmac = hash_hmac('sha256', $message, $secret_key);
        $check_url = 'https://www.yooadmin.io/wp-json/yoopixel/v1/check';
        
        $response = wp_remote_post($check_url, $this->remote_http_args([
            'body' => [
                'activation_code' => $activation_code,
                'site_url' => $site_url,
                'ts' => $ts,
                'nonce' => $nonce,
                'hmac' => $hmac
            ],
            'timeout' => 30
        ]));
        
        if (is_wp_error($response)) {
            return ['success' => false];
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['ok']) || !$data['ok']) {
            $license_data = $this->get_license_data();
            $license_data['status'] = $data['error'] ?? 'inactive';
            
            if (!empty($data['reason'])) {
                $license_data['status_reason'] = $data['reason'];
            }
            
            if (!empty($data['msg'])) {
                $license_data['status_message'] = $data['msg'];
            }
            
            $license_data['last_checked'] = current_time('mysql');
            $this->save_license_data($license_data);
            
            return [
                'success' => false,
                'message' => $data['msg'] ?? 'License check failed',
                'status' => $license_data['status'],
                'reason' => $data['reason'] ?? ''
            ];
        }
        
        if (!empty($data['jwt_token'])) {
            $license_data = $this->get_license_data();
            $license_data['jwt_token'] = $data['jwt_token'];
            $license_data['status'] = $data['license']['status'] ?? 'active';
            
            if (isset($data['license']['license_type'])) {
                $license_data['license_type'] = strtolower((string) $data['license']['license_type']);
            } else {
                $from_jwt = $this->license_type_from_jwt_token($data['jwt_token']);
                if ($from_jwt !== null) {
                    $license_data['license_type'] = $from_jwt;
                }
            }
            
            if ($license_data['status'] === 'active') {
                unset($license_data['status_reason']);
                unset($license_data['status_message']);
            }
            
            $license_data['last_checked'] = current_time('mysql');
            $license_data['last_successful_check'] = time();
            if (isset($data['server_timestamp'])) {
                $license_data['server_timestamp'] = intval($data['server_timestamp']);
            } else {
                $license_data['server_timestamp'] = time();
            }
            $this->save_license_data($license_data);
        }
        
        return [
            'success' => true,
            'license' => $data['license'] ?? []
        ];
    }
    
    public function get_license_data() {
        if ($this->cached_license_data !== null) {
            return $this->cached_license_data;
        }
        
        $stored = get_option('yooadmin_license_data', []);
        
        if (isset($stored['encrypted']) && isset($stored['signature'])) {
            if (!$this->verify_license_data_signature($stored['encrypted'], $stored['signature'])) {
                $this->cached_license_data = [];
                return [];
            }
            
            $data = $this->decrypt_license_data($stored['encrypted']);
            if ($data === false) {
                $this->cached_license_data = [];
                return [];
            }
            
            $this->cached_license_data = $data;
            return $data;
        }
        
        if (!empty($stored) && is_array($stored)) {
            $this->cached_license_data = $stored;
            return $stored;
        }
        
        $this->cached_license_data = [];
        return [];
    }
    
    public function update_license_status_from_webhook($new_status, $extra_data = []) {
        $license_data = $this->get_license_data();
        if (empty($license_data)) {
            return false;
        }
        $license_data['status'] = sanitize_text_field($new_status);
        $license_data['last_checked'] = current_time('mysql');
        $license_data['last_successful_check'] = time();
        if (!empty($extra_data['suspension_source'])) {
            $license_data['suspension_source'] = sanitize_text_field($extra_data['suspension_source']);
        } elseif ($new_status === 'active') {
            unset($license_data['suspension_source']);
        }
        return $this->save_license_data($license_data);
    }

    private function save_license_data($license_data) {
        $encrypted = $this->encrypt_license_data($license_data);
        if ($encrypted === false) {
            return false;
        }
        
        $signature = $this->generate_license_data_signature($encrypted);
        if ($signature === false) {
            return false;
        }
        
        $server_timestamp = $license_data['server_timestamp'] ?? time();
        $stored = [
            'encrypted' => $encrypted,
            'signature' => $signature,
            'server_timestamp' => $server_timestamp,
            'version' => '3.2.0'
        ];
        
        $this->cached_license_data = null;
        
        return update_option('yooadmin_license_data', $stored);
    }
    
    private function encrypt_license_data($data) {
        if (!is_array($data)) {
            return false;
        }
        
        $json = wp_json_encode($data);
        if ($json === false) {
            return false;
        }
        
        $key = $this->get_encryption_key();
        if ($key === false) {
            return false;
        }
        
        $iv_length = openssl_cipher_iv_length('AES-256-CBC');
        $iv = openssl_random_pseudo_bytes($iv_length);
        if ($iv === false) {
            return false;
        }
        
        $encrypted = openssl_encrypt($json, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        if ($encrypted === false) {
            return false;
        }
        
        return base64_encode($iv . $encrypted);
    }
    
    private function decrypt_license_data($encrypted) {
        if (empty($encrypted)) {
            return false;
        }
        
        $data = base64_decode($encrypted, true);
        if ($data === false) {
            return false;
        }
        
        $key = $this->get_encryption_key();
        if ($key === false) {
            return false;
        }
        
        $iv_length = openssl_cipher_iv_length('AES-256-CBC');
        if (strlen($data) < $iv_length) {
            return false;
        }
        
        $iv = substr($data, 0, $iv_length);
        $encrypted_data = substr($data, $iv_length);
        $decrypted = openssl_decrypt($encrypted_data, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        if ($decrypted === false) {
            return false;
        }
        
        $result = json_decode($decrypted, true);
        if (!is_array($result)) {
            return false;
        }
        
        return $result;
    }
    
    private function get_encryption_key() {
        $site_salt = defined('AUTH_SALT') ? AUTH_SALT : 'yooadmin-default-salt';
        $constant_salt = 'yooadmin-license-encryption-v3.2.0';
        $key = hash_pbkdf2('sha256', $site_salt . $constant_salt, 'yooadmin-license-key', 10000, 32, true);
        
        return $key;
    }
    
    private function generate_license_data_signature($encrypted_data) {
        $key = $this->get_encryption_key();
        if ($key === false) {
            return false;
        }
        
        $hmac_key = hash('sha256', $key . 'yooadmin-hmac-key-v3.2.0', true);
        
        return hash_hmac('sha256', $encrypted_data, $hmac_key);
    }
    
    private function verify_license_data_signature($encrypted_data, $signature) {
        $expected_signature = $this->generate_license_data_signature($encrypted_data);
        if ($expected_signature === false) {
            return false;
        }
        
        return hash_equals($expected_signature, $signature);
    }
    
    private function is_in_grace_period() {
        $license_data = $this->get_license_data();
        $current_status = $license_data['status'] ?? 'inactive';
        if (in_array($current_status, ['suspended', 'revoked', 'expired', 'inactive'], true)) {
            return false;
        }
        
        $last_successful_check = $license_data['last_successful_check'] ?? null;
        if (empty($last_successful_check)) {
            return false;
        }
        
        $stored = get_option('yooadmin_license_data', []);
        $server_timestamp = $stored['server_timestamp'] ?? time();
        $grace_period_end = $last_successful_check + $this->grace_period_duration;
        $in_grace = $server_timestamp <= $grace_period_end;
        
        if ($in_grace) {
            $remaining = $grace_period_end - $server_timestamp;
        }
        
        return $in_grace;
    }
    
    private function is_force_update_required() {
        $license_data = $this->get_license_data();
        
        $last_successful_check = $license_data['last_successful_check'] ?? null;
        if (empty($last_successful_check)) {
            return true;
        }
        
        $stored = get_option('yooadmin_license_data', []);
        $server_timestamp = $stored['server_timestamp'] ?? time();
        
        $force_update_time = $last_successful_check + $this->force_update_period;
        
        return $server_timestamp > $force_update_time;
    }
    
    private function invalidate_license($reason = 'security_breach') {
        delete_option('yooadmin_license_data');
        
        $this->log_security_event('license_invalidated', [
            'reason' => $reason,
            'ip' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown',
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : 'unknown',
            'timestamp' => time()
        ]);
    }
    
    private function log_security_event($event_type, $data = []) {
        $log_entry = [
            'event' => $event_type,
            'timestamp' => time(),
            'data' => $data
        ];
        
        $log = get_option('yooadmin_security_log', []);
        if (!is_array($log)) {
            $log = [];
        }
        
        $log[] = $log_entry;
        
        if (count($log) > 100) {
            $log = array_slice($log, -100);
        }
        
        update_option('yooadmin_security_log', $log);
    }
    
    public function has_license() {
        $license_data = $this->get_license_data();
        return !empty($license_data) && !empty($license_data['activation_code']);
    }
    
    public function is_license_active() {
        $license_data = $this->get_license_data();
        
        if (empty($license_data)) {
            return false;
        }
        
        if (isset($license_data['status']) && in_array($license_data['status'], ['suspended', 'revoked', 'expired'])) {
            return false;
        }
        
        if (empty($license_data['jwt_token'])) {
            return false;
        }
        
        $current_site_url = $this->normalize_domain(get_site_url());
        $licensed_site_url = $this->normalize_domain($license_data['site_url'] ?? '');
        
        if (!empty($licensed_site_url) && $current_site_url !== $licensed_site_url) {
            return false;
        }
        
        $status = $license_data['status'] ?? '';
        if ($status !== 'active') {
            return false;
        }
        
        if (!empty($license_data['expires_at'])) {
            $expires = strtotime($license_data['expires_at']);
            if ($expires < time()) {
                return false;
            }
        }
        
        return true;
    }
    
    private function normalize_domain($url) {
        $parsed = wp_parse_url(trim($url));
        if (!empty($parsed['host'])) {
            return strtolower($parsed['host']);
        }
        $url = strtolower(trim($url));
        $url = preg_replace('#^https?://#', '', $url);
        $url = preg_replace('#^www\.#', '', $url);
        $url = preg_replace('#/.*$#', '', $url);
        $url = preg_replace('#:\d+$#', '', $url);
        return trim($url);
    }
    
    public function get_license_type() {
        $license_data = $this->get_license_data();
        
        if (!$this->is_license_active()) {
            return null;
        }
        
        $license_type = $license_data['license_type'] ?? null;
        
        if (!empty($license_type)) {
            $license_type = strtolower($license_type);
        }
        
        if (!empty($license_type)) {
            yooadmin_bust_license_type_option_caches();
            $all_license_types = yooadmin_get_effective_license_types();
            
            $found_key = null;
            foreach ($all_license_types as $key => $type) {
                if (strtolower($key) === $license_type) {
                    $found_key = strtolower($key);
                    break;
                }
            }
            
            if ($found_key !== null) {
                return $found_key;
            }
        }
        
        return null;
    }
    
    public function get_jwt_token() {
        $license_data = $this->get_license_data();
        return $license_data['jwt_token'] ?? '';
    }
    
    public function require_fresh_license_check($operation = 'critical_operation') {
        $license_data = $this->get_license_data();
        
        if (!$this->is_license_active()) {
            return [
                'success' => false,
                'message' => __('License is not active. Please activate your license first.', 'yooadmin')
            ];
        }
        
        if (empty($license_data['jwt_token'])) {
            return [
                'success' => false,
                'message' => __('No license token found. Please activate your license.', 'yooadmin')
            ];
        }
        
        $check_url = $this->api_url . 'check';
        $response = wp_remote_get($check_url, $this->remote_http_args([
            'headers' => [
                'Authorization' => 'Bearer ' . $license_data['jwt_token'],
            ],
            'timeout' => 15,
        ]));
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => __('Unable to verify license with server. Please check your connection and try again.', 'yooadmin')
            ];
        }
        
        $body = wp_remote_retrieve_body($response);
        $code = (int) wp_remote_retrieve_response_code($response);
        $data = json_decode($body, true);
        
        if (!isset($data['ok']) || !$data['ok']) {
            $error_msg = $data['error'] ?? $data['message'] ?? 'License verification failed';
            return [
                'success' => false,
                'message' => __('License verification failed: ', 'yooadmin') . $error_msg
            ];
        }
        
        return [
            'success' => true
        ];
    }
    
    private function get_license_hierarchy() {
        yooadmin_bust_license_type_option_caches();
        $types = yooadmin_get_effective_license_types();
        $hierarchy = [];
        $sorted_types = $types;
        uasort($sorted_types, function($a, $b) {
            $order_a = isset($a['order']) ? (int)$a['order'] : 999;
            $order_b = isset($b['order']) ? (int)$b['order'] : 999;
            return $order_a <=> $order_b;
        });
        
        $level = 0;
        foreach ($sorted_types as $key => $type) {
            $hierarchy[$key] = $level;
            $level++;
        }
        
        return $hierarchy;
    }
}
