<?php
/**
 * Activity log — public helpers.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_activity_storage')) {
    function yooadmin_activity_storage(): YOOAdmin_Activity_Storage {
        static $storage = null;
        if (null === $storage) {
            $storage = new YOOAdmin_Activity_Storage();
        }
        return $storage;
    }
}

if (!function_exists('yooadmin_activity_page_capability')) {
    function yooadmin_activity_page_capability(): string {
        return (string) apply_filters('yooadmin_activity_page_capability', 'read');
    }
}

if (!function_exists('yooadmin_activity_user_can_view_all')) {
    function yooadmin_activity_user_can_view_all(): bool {
        return current_user_can('manage_options') || current_user_can('edit_others_posts');
    }
}

if (!function_exists('yooadmin_activity_get_categories')) {
    /**
     * @return array<string, string>
     */
    function yooadmin_activity_get_categories(): array {
        return apply_filters(
            'yooadmin_activity_categories',
            [
                'all'     => __('All', 'yooadmin'),
                'content' => __('Content', 'yooadmin'),
                'comment' => __('Comments', 'yooadmin'),
                'user'    => __('Users', 'yooadmin'),
                'system'  => __('System', 'yooadmin'),
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_get_time_ranges')) {
    /**
     * @return array<string, string>
     */
    function yooadmin_activity_get_time_ranges(): array {
        return apply_filters(
            'yooadmin_activity_time_ranges',
            [
                'all'   => __('All time', 'yooadmin'),
                'today' => __('Today', 'yooadmin'),
                '7d'    => __('Last 7 days', 'yooadmin'),
                '30d'   => __('Last 30 days', 'yooadmin'),
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_build_post_title')) {
    function yooadmin_activity_build_post_title(WP_Post $post, string $action_slug): string {
        $label = $post->post_type === 'page' ? __('Page', 'yooadmin') : __('Post', 'yooadmin');
        $name = get_the_title($post);
        if ($name === '') {
            $name = __('(no title)', 'yooadmin');
        }

        switch ($action_slug) {
            case 'post_published':
                /* translators: 1: post type label, 2: post title */
                return sprintf(__('%1$s published: %2$s', 'yooadmin'), $label, $name);
            case 'post_trashed':
                /* translators: 1: post type label, 2: post title */
                return sprintf(__('%1$s trashed: %2$s', 'yooadmin'), $label, $name);
            default:
                /* translators: 1: post type label, 2: post title */
                return sprintf(__('%1$s updated: %2$s', 'yooadmin'), $label, $name);
        }
    }
}

if (!function_exists('yooadmin_activity_build_comment_title')) {
    function yooadmin_activity_build_comment_title(WP_Comment $comment, string $action_slug): string {
        $author = $comment->comment_author !== '' ? $comment->comment_author : __('Guest', 'yooadmin');
        switch ($action_slug) {
            case 'comment_spam':
                /* translators: %s: comment author name */
                return sprintf(__('Comment marked as spam by %s', 'yooadmin'), $author);
            case 'comment_approved':
                /* translators: %s: comment author name */
                return sprintf(__('Comment approved from %s', 'yooadmin'), $author);
            default:
                /* translators: %s: comment author name */
                return sprintf(__('New comment from %s', 'yooadmin'), $author);
        }
    }
}

if (!function_exists('yooadmin_activity_log')) {
    /**
     * @param array<string, mixed> $data
     * @param bool                 $allow_custom_timestamp Backfill only.
     */
    function yooadmin_activity_log(array $data, bool $allow_custom_timestamp = false): int {
        if (!apply_filters('yooadmin_activity_logging_enabled', true, $data)) {
            return 0;
        }

        if ($allow_custom_timestamp && isset($data['created_at'])) {
            return yooadmin_activity_storage()->insert_with_timestamp($data);
        }

        return yooadmin_activity_storage()->insert($data);
    }
}

if (!function_exists('yooadmin_activity_query_args_from_request')) {
    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    function yooadmin_activity_query_args_from_request(array $input): array {
        $category = isset($input['category']) ? sanitize_key((string) $input['category']) : 'all';
        $range = isset($input['range']) ? sanitize_key((string) $input['range']) : 'all';
        $user_id = isset($input['user_id']) ? absint($input['user_id']) : 0;
        $page = isset($input['page']) ? absint($input['page']) : 1;
        $per_page = isset($input['per_page']) ? absint($input['per_page']) : 20;
        $search = isset($input['search']) ? sanitize_text_field((string) $input['search']) : '';

        $allowed_categories = array_keys(yooadmin_activity_get_categories());
        if (!in_array($category, $allowed_categories, true)) {
            $category = 'all';
        }

        $allowed_ranges = array_keys(yooadmin_activity_get_time_ranges());
        if (!in_array($range, $allowed_ranges, true)) {
            $range = 'all';
        }

        $args = [
            'category'  => $category,
            'range'     => $range,
            'user_id'   => $user_id,
            'page'      => max(1, $page),
            'per_page'  => max(1, min(50, $per_page)),
            'search'    => $search,
        ];

        if (!yooadmin_activity_user_can_view_all()) {
            $args['restrict_user_id'] = get_current_user_id();
            $args['user_id'] = 0;
        } elseif ($user_id > 0) {
            $allowed_ids = array_map(
                static function (array $user): int {
                    return (int) ($user['id'] ?? 0);
                },
                yooadmin_activity_get_filter_users()
            );
            if ($allowed_ids && !in_array($user_id, $allowed_ids, true)) {
                $args['user_id'] = 0;
            }
        }

        return apply_filters('yooadmin_activity_query_args', $args, $input);
    }
}

if (!function_exists('yooadmin_activity_format_row')) {
    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    function yooadmin_activity_format_row(array $row): array {
        $user_id = absint($row['user_id'] ?? 0);
        $user = $user_id > 0 ? get_userdata($user_id) : false;
        $display_name = '';
        if ($user instanceof WP_User) {
            $display_name = $user->display_name !== '' ? $user->display_name : $user->user_login;
        }

        $category = sanitize_key((string) ($row['category'] ?? 'system'));
        $icons = [
            'content' => 'dashicons-admin-post',
            'comment' => 'dashicons-admin-comments',
            'user'    => 'dashicons-admin-users',
            'system'  => 'dashicons-admin-generic',
        ];

        $created = isset($row['created_at']) ? strtotime((string) $row['created_at'] . ' UTC') : false;
        $time_label = $created ? human_time_diff($created, current_time('timestamp')) . ' ' . __('ago', 'yooadmin') : '';

        $title = (string) ($row['title'] ?? '');
        $action_label = $title;
        $subject = '';
        if (preg_match('/^(.+?):\s*(.+)$/u', $title, $parts)) {
            $action_label = trim((string) $parts[1]);
            $subject = trim((string) $parts[2]);
        }

        return [
            'id'             => absint($row['id'] ?? 0),
            'title'          => $title,
            'action_label'   => $action_label,
            'subject'        => $subject,
            'url'            => (string) ($row['url'] ?? ''),
            'category'       => $category,
            'category_label' => yooadmin_activity_get_categories()[ $category ] ?? ucfirst($category),
            'icon'           => $icons[ $category ] ?? 'dashicons-marker',
            'user_id'        => $user_id,
            'user_name'      => $display_name,
            'time_label'     => $time_label,
            'created_at'     => (string) ($row['created_at'] ?? ''),
        ];
    }
}

if (!function_exists('yooadmin_activity_get_recent')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_activity_get_recent(int $limit = 5): array {
        $limit = max(1, min(10, $limit));
        $args = yooadmin_activity_query_args_from_request(
            [
                'category'  => 'all',
                'range'     => '30d',
                'page'      => 1,
                'per_page'  => $limit,
            ]
        );

        $rows = yooadmin_activity_storage()->query($args);
        $items = [];
        foreach ($rows as $row) {
            if (is_array($row)) {
                $items[] = yooadmin_activity_format_row($row);
            }
        }

        return apply_filters('yooadmin_activity_recent_items', $items, $limit);
    }
}

if (!function_exists('yooadmin_activity_get_filter_users')) {
    /**
     * @return array<int, array{id: int, label: string}>
     */
    function yooadmin_activity_get_filter_users(): array {
        if (!yooadmin_activity_user_can_view_all()) {
            return [];
        }

        $user_ids = yooadmin_activity_storage()->get_distinct_user_ids();
        if (!$user_ids) {
            return [];
        }

        $out = [];
        foreach ($user_ids as $uid) {
            $user = get_userdata((int) $uid);
            if (!($user instanceof WP_User)) {
                continue;
            }
            $label = $user->display_name !== '' ? $user->display_name : $user->user_login;
            $out[] = [
                'id'    => (int) $user->ID,
                'label' => $label,
            ];
        }

        usort(
            $out,
            static function (array $a, array $b): int {
                return strcasecmp((string) ($a['label'] ?? ''), (string) ($b['label'] ?? ''));
            }
        );

        return $out;
    }
}
