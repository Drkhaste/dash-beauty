<?php
/**
 * Activity log — database storage.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Table name is prefix + fixed suffix; WHERE built from whitelisted placeholders via prepare_sql().
// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Dynamic placeholder count matched in prepare_sql() switch.
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is {$wpdb->prefix} + fixed plugin suffix; values passed through $wpdb->prepare().

class YOOAdmin_Activity_Storage {

    /**
     * @return string
     */
    public function table_name(): string {
        global $wpdb;
        return $wpdb->prefix . 'yooadmin_activity';
    }

    public function maybe_create_tables(): void {
        global $wpdb;

        $table = $this->table_name();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $charset_collate = $wpdb->get_charset_collate();
        $sql             = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            blog_id bigint(20) unsigned NOT NULL DEFAULT 0,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            category varchar(20) NOT NULL DEFAULT 'system',
            action_slug varchar(64) NOT NULL DEFAULT '',
            object_type varchar(32) NOT NULL DEFAULT '',
            object_id bigint(20) unsigned NOT NULL DEFAULT 0,
            title varchar(255) NOT NULL DEFAULT '',
            url varchar(500) NOT NULL DEFAULT '',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY blog_created (blog_id, created_at),
            KEY user_created (user_id, created_at),
            KEY category_created (category, created_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * @param array<string, mixed> $data
     */
    public function insert(array $data): int {
        global $wpdb;

        $this->maybe_create_tables();
        $table = $this->table_name();

        $blog_id = (int) ($data['blog_id'] ?? get_current_blog_id());
        $user_id = (int) ($data['user_id'] ?? get_current_user_id());
        $category = sanitize_key((string) ($data['category'] ?? 'system'));
        $action_slug = sanitize_key((string) ($data['action_slug'] ?? 'event'));
        $object_type = sanitize_key((string) ($data['object_type'] ?? ''));
        $object_id = absint($data['object_id'] ?? 0);
        $title = wp_strip_all_tags((string) ($data['title'] ?? ''));
        $url = esc_url_raw((string) ($data['url'] ?? ''));

        if ($title === '') {
            return 0;
        }

        $allowed_categories = [ 'content', 'comment', 'user', 'system' ];
        if (!in_array($category, $allowed_categories, true)) {
            $category = 'system';
        }

        if (strlen($title) > 255) {
            $title = mb_substr($title, 0, 252) . '...';
        }

        $inserted = $wpdb->insert(
            $table,
            [
                'blog_id'     => $blog_id,
                'user_id'     => $user_id,
                'category'    => $category,
                'action_slug' => $action_slug,
                'object_type' => $object_type,
                'object_id'   => $object_id,
                'title'       => $title,
                'url'         => $url,
                'created_at'  => current_time('mysql', true),
            ],
            [ '%d', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s' ]
        );

        return $inserted ? (int) $wpdb->insert_id : 0;
    }

    /**
     * @param array<string, mixed> $args
     * @return array<int, array<string, mixed>>
     */
    public function query(array $args): array {
        global $wpdb;

        $this->maybe_create_tables();
        $table = $this->table_name();

        $where = $this->build_where_clause($args);
        $per_page = max(1, min(50, absint($args['per_page'] ?? 20)));
        $page = max(1, absint($args['page'] ?? 1));
        $offset = ($page - 1) * $per_page;

        $sql = "SELECT * FROM {$table} WHERE {$where['sql']} ORDER BY created_at DESC, id DESC LIMIT %d OFFSET %d";
        $prepared = $this->prepare_sql(
            $sql,
            array_merge($where['values'], [ $per_page, $offset ])
        );

        if ($prepared === '') {
            return [];
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Dynamic WHERE clause.
        $rows = $wpdb->get_results($prepared, ARRAY_A);

        return is_array($rows) ? $rows : [];
    }

    /**
     * @param array<string, mixed> $args
     */
    public function count(array $args): int {
        global $wpdb;

        $this->maybe_create_tables();
        $table = $this->table_name();
        $where = $this->build_where_clause($args);

        $sql      = "SELECT COUNT(*) FROM {$table} WHERE {$where['sql']}";
        $prepared = $this->prepare_sql($sql, $where['values']);

        if ($prepared === '') {
            return 0;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Dynamic WHERE clause.
        $total = $wpdb->get_var($prepared);

        return max(0, (int) $total);
    }

    /**
     * Prepare SQL with a bounded set of placeholders (Plugin Check–friendly).
     *
     * @param string               $sql    Query with % placeholders.
     * @param array<int, mixed>    $values Sanitized values from build_where_clause().
     * @return string Empty string when placeholder count is out of range.
     */
    private function prepare_sql(string $sql, array $values): string {
        global $wpdb;

        $count = count($values);
        if ($count < 1 || $count > 8) {
            return '';
        }

        switch ($count) {
            case 1:
                return (string) $wpdb->prepare($sql, $values[0]);
            case 2:
                return (string) $wpdb->prepare($sql, $values[0], $values[1]);
            case 3:
                return (string) $wpdb->prepare($sql, $values[0], $values[1], $values[2]);
            case 4:
                return (string) $wpdb->prepare($sql, $values[0], $values[1], $values[2], $values[3]);
            case 5:
                return (string) $wpdb->prepare($sql, $values[0], $values[1], $values[2], $values[3], $values[4]);
            case 6:
                return (string) $wpdb->prepare($sql, $values[0], $values[1], $values[2], $values[3], $values[4], $values[5]);
            case 7:
                return (string) $wpdb->prepare($sql, $values[0], $values[1], $values[2], $values[3], $values[4], $values[5], $values[6]);
            case 8:
                return (string) $wpdb->prepare($sql, $values[0], $values[1], $values[2], $values[3], $values[4], $values[5], $values[6], $values[7]);
            default:
                return '';
        }
    }

    /**
     * @param array<string, mixed> $args
     * @return array{sql: string, values: array<int, mixed>}
     */
    private function build_where_clause(array $args): array {
        global $wpdb;

        $parts = [ 'blog_id = %d' ];
        $values = [ (int) get_current_blog_id() ];

        $category = isset($args['category']) ? sanitize_key((string) $args['category']) : '';
        if ($category !== '' && $category !== 'all') {
            $parts[] = 'category = %s';
            $values[] = $category;
        }

        $user_id = isset($args['user_id']) ? absint($args['user_id']) : 0;
        if ($user_id > 0) {
            $parts[] = 'user_id = %d';
            $values[] = $user_id;
        } elseif (!empty($args['restrict_user_id'])) {
            $parts[] = 'user_id = %d';
            $values[] = absint($args['restrict_user_id']);
        }

        $range = isset($args['range']) ? sanitize_key((string) $args['range']) : 'all';
        $since = $this->range_to_mysql($range);
        if ($since !== '') {
            $parts[] = 'created_at >= %s';
            $values[] = $since;
        }

        $search = isset($args['search']) ? sanitize_text_field((string) $args['search']) : '';
        if ($search !== '') {
            $parts[] = 'title LIKE %s';
            $values[] = '%' . $wpdb->esc_like($search) . '%';
        }

        return [
            'sql'    => implode(' AND ', $parts),
            'values' => $values,
        ];
    }

    /**
     * Distinct user IDs that appear in the activity log.
     *
     * @return array<int, int>
     */
    public function get_distinct_user_ids(int $limit = 100): array {
        global $wpdb;

        $this->maybe_create_tables();
        $table = $this->table_name();
        $limit = max(1, min(200, $limit));

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT user_id FROM {$table} WHERE blog_id = %d AND user_id > 0 ORDER BY user_id DESC LIMIT %d",
                (int) get_current_blog_id(),
                $limit
            )
        );

        if (!is_array($rows)) {
            return [];
        }

        return array_values(array_filter(array_map('absint', $rows)));
    }

    private function range_to_mysql(string $range): string {
        $now = current_time('timestamp');
        switch ($range) {
            case 'today':
                return gmdate('Y-m-d H:i:s', (int) strtotime('today', $now));
            case '7d':
                return gmdate('Y-m-d H:i:s', $now - WEEK_IN_SECONDS);
            case '30d':
                return gmdate('Y-m-d H:i:s', $now - (30 * DAY_IN_SECONDS));
            default:
                return '';
        }
    }

    public function backfill_if_empty(): void {
        if ((int) get_option('yooadmin_activity_backfill_done', 0) === 1) {
            return;
        }

        $this->maybe_create_tables();
        if ($this->count([ 'range' => 'all' ]) > 0) {
            update_option('yooadmin_activity_backfill_done', 1, false);
            return;
        }

        if (!function_exists('yooadmin_activity_log')) {
            return;
        }

        $posts = get_posts(
            [
                'post_type'      => [ 'post', 'page' ],
                'post_status'    => [ 'publish', 'draft', 'pending', 'private' ],
                'posts_per_page' => 8,
                'orderby'        => 'modified',
                'order'          => 'DESC',
                // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.SuppressFilters_suppress_filters -- One-time admin backfill; avoid front-end query filters.
                'suppress_filters' => true,
            ]
        );

        foreach ($posts as $post) {
            if (!($post instanceof WP_Post)) {
                continue;
            }
            yooadmin_activity_log(
                [
                    'user_id'     => (int) $post->post_author,
                    'category'    => 'content',
                    'action_slug' => $post->post_status === 'publish' ? 'post_published' : 'post_updated',
                    'object_type' => $post->post_type,
                    'object_id'   => (int) $post->ID,
                    'title'       => yooadmin_activity_build_post_title($post, $post->post_status === 'publish' ? 'post_published' : 'post_updated'),
                    'url'         => get_edit_post_link($post->ID, 'raw') ?: '',
                    'created_at'  => get_post_modified_time('Y-m-d H:i:s', true, $post),
                ],
                true
            );
        }

        $comments = get_comments(
            [
                'number'  => 5,
                'status'  => 'approve',
                'orderby' => 'comment_date_gmt',
                'order'   => 'DESC',
            ]
        );

        foreach ($comments as $comment) {
            if (!($comment instanceof WP_Comment)) {
                continue;
            }
            yooadmin_activity_log(
                [
                    'user_id'     => (int) $comment->user_id,
                    'category'    => 'comment',
                    'action_slug' => 'comment_approved',
                    'object_type' => 'comment',
                    'object_id'   => (int) $comment->comment_ID,
                    'title'       => yooadmin_activity_build_comment_title($comment, 'comment_approved'),
                    'url'         => admin_url('comment.php?action=editcomment&c=' . (int) $comment->comment_ID),
                    'created_at'  => $comment->comment_date_gmt,
                ],
                true
            );
        }

        update_option('yooadmin_activity_backfill_done', 1, false);
    }

    /**
     * Insert with optional explicit created_at (backfill only).
     *
     * @param array<string, mixed> $data
     */
    public function insert_with_timestamp(array $data): int {
        global $wpdb;

        $this->maybe_create_tables();
        $table = $this->table_name();

        $created_at = isset($data['created_at']) ? gmdate('Y-m-d H:i:s', strtotime((string) $data['created_at'])) : current_time('mysql', true);
        unset($data['created_at']);

        $id = $this->insert($data);
        if ($id <= 0) {
            return 0;
        }

        $wpdb->update(
            $table,
            [ 'created_at' => $created_at ],
            [ 'id' => $id ],
            [ '%s' ],
            [ '%d' ]
        );

        return $id;
    }
}
