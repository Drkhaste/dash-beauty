<?php
/**
 * Activity log — event hooks.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_activity_logger_init')) {
    function yooadmin_activity_logger_init(): void {
        add_action('transition_post_status', 'yooadmin_activity_on_transition_post_status', 10, 3);
        add_action('wp_insert_comment', 'yooadmin_activity_on_insert_comment', 10, 2);
        add_action('wp_set_comment_status', 'yooadmin_activity_on_comment_status', 10, 2);
        add_action('user_register', 'yooadmin_activity_on_user_register', 10, 1);
        add_action('delete_user', 'yooadmin_activity_on_delete_user', 10, 1);
        add_action('wp_login', 'yooadmin_activity_on_wp_login', 10, 2);
        add_action('activated_plugin', 'yooadmin_activity_on_activated_plugin', 10, 2);
        add_action('deactivated_plugin', 'yooadmin_activity_on_deactivated_plugin', 10, 2);
        add_action('switch_theme', 'yooadmin_activity_on_switch_theme', 10, 3);
    }
}

if (!function_exists('yooadmin_activity_should_skip_logging')) {
    function yooadmin_activity_should_skip_logging(): bool {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return true;
        }
        if (defined('WP_IMPORTING') && WP_IMPORTING) {
            return true;
        }
        if (wp_doing_cron()) {
            return true;
        }

        return (bool) apply_filters('yooadmin_activity_skip_logging', false);
    }
}

if (!function_exists('yooadmin_activity_on_transition_post_status')) {
    /**
     * @param string  $new_status New status.
     * @param string  $old_status Old status.
     * @param WP_Post $post       Post object.
     */
    function yooadmin_activity_on_transition_post_status($new_status, $old_status, $post): void {
        if (yooadmin_activity_should_skip_logging() || !($post instanceof WP_Post)) {
            return;
        }

        if (wp_is_post_revision($post->ID) || wp_is_post_autosave($post->ID)) {
            return;
        }

        if (!in_array($post->post_type, [ 'post', 'page' ], true)) {
            return;
        }

        if ($new_status === $old_status) {
            return;
        }

        $action = 'post_updated';
        if ($new_status === 'publish' && $old_status !== 'publish') {
            $action = 'post_published';
        } elseif ($new_status === 'trash') {
            $action = 'post_trashed';
        } elseif ($new_status === 'draft' && $old_status === 'publish') {
            $action = 'post_updated';
        }

        yooadmin_activity_log(
            [
                'user_id'     => get_current_user_id(),
                'category'    => 'content',
                'action_slug' => $action,
                'object_type' => $post->post_type,
                'object_id'   => (int) $post->ID,
                'title'       => yooadmin_activity_build_post_title($post, $action),
                'url'         => get_edit_post_link($post->ID, 'raw') ?: '',
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_on_insert_comment')) {
    /**
     * @param int        $comment_id Comment ID.
     * @param WP_Comment $comment    Comment object.
     */
    function yooadmin_activity_on_insert_comment($comment_id, $comment): void {
        if (yooadmin_activity_should_skip_logging() || !($comment instanceof WP_Comment)) {
            return;
        }

        if ((string) $comment->comment_approved === 'spam') {
            return;
        }

        yooadmin_activity_log(
            [
                'user_id'     => get_current_user_id(),
                'category'    => 'comment',
                'action_slug' => 'comment_added',
                'object_type' => 'comment',
                'object_id'   => (int) $comment_id,
                'title'       => yooadmin_activity_build_comment_title($comment, 'comment_added'),
                'url'         => admin_url('comment.php?action=editcomment&c=' . (int) $comment_id),
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_on_comment_status')) {
    /**
     * @param int|string $comment_id Comment ID.
     * @param string     $status     New status.
     */
    function yooadmin_activity_on_comment_status($comment_id, $status): void {
        if (yooadmin_activity_should_skip_logging()) {
            return;
        }

        $comment = get_comment($comment_id);
        if (!($comment instanceof WP_Comment)) {
            return;
        }

        if ($status === 'approve') {
            $action = 'comment_approved';
        } elseif ($status === 'spam') {
            $action = 'comment_spam';
        } else {
            return;
        }

        yooadmin_activity_log(
            [
                'user_id'     => get_current_user_id(),
                'category'    => 'comment',
                'action_slug' => $action,
                'object_type' => 'comment',
                'object_id'   => (int) $comment_id,
                'title'       => yooadmin_activity_build_comment_title($comment, $action),
                'url'         => admin_url('comment.php?action=editcomment&c=' . (int) $comment_id),
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_on_user_register')) {
    /**
     * @param int $user_id User ID.
     */
    function yooadmin_activity_on_user_register($user_id): void {
        if (yooadmin_activity_should_skip_logging()) {
            return;
        }

        $user = get_userdata((int) $user_id);
        if (!($user instanceof WP_User)) {
            return;
        }

        yooadmin_activity_log(
            [
                'user_id'     => get_current_user_id(),
                'category'    => 'user',
                'action_slug' => 'user_registered',
                'object_type' => 'user',
                'object_id'   => (int) $user_id,
                /* translators: %s: username */
                'title'       => sprintf(__('New user registered: %s', 'yooadmin'), $user->user_login),
                'url'         => admin_url('user-edit.php?user_id=' . (int) $user_id),
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_on_delete_user')) {
    /**
     * @param int $user_id User ID.
     */
    function yooadmin_activity_on_delete_user($user_id): void {
        if (yooadmin_activity_should_skip_logging()) {
            return;
        }

        yooadmin_activity_log(
            [
                'user_id'     => get_current_user_id(),
                'category'    => 'user',
                'action_slug' => 'user_deleted',
                'object_type' => 'user',
                'object_id'   => (int) $user_id,
                'title'       => __('User account deleted', 'yooadmin'),
                'url'         => admin_url('users.php'),
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_on_wp_login')) {
    /**
     * @param string  $user_login Username.
     * @param WP_User $user       User object.
     */
    function yooadmin_activity_on_wp_login($user_login, $user): void {
        if (yooadmin_activity_should_skip_logging() || !($user instanceof WP_User)) {
            return;
        }

        if (!user_can($user, 'edit_posts')) {
            return;
        }

        yooadmin_activity_log(
            [
                'user_id'     => (int) $user->ID,
                'category'    => 'user',
                'action_slug' => 'user_login',
                'object_type' => 'user',
                'object_id'   => (int) $user->ID,
                /* translators: %s: display name */
                'title'       => sprintf(__('%s signed in', 'yooadmin'), $user->display_name ?: $user_login),
                'url'         => admin_url('profile.php'),
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_on_activated_plugin')) {
    /**
     * @param string $plugin Plugin file.
     * @param bool   $network_wide Network wide.
     */
    function yooadmin_activity_on_activated_plugin($plugin, $network_wide): void {
        unset($network_wide);
        if (yooadmin_activity_should_skip_logging()) {
            return;
        }

        if (!function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
        $name = isset($data['Name']) && $data['Name'] !== '' ? $data['Name'] : basename((string) $plugin, '.php');

        yooadmin_activity_log(
            [
                'user_id'     => get_current_user_id(),
                'category'    => 'system',
                'action_slug' => 'plugin_activated',
                'object_type' => 'plugin',
                'object_id'   => 0,
                /* translators: %s: plugin name */
                'title'       => sprintf(__('Plugin activated: %s', 'yooadmin'), $name),
                'url'         => admin_url('plugins.php'),
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_on_deactivated_plugin')) {
    /**
     * @param string $plugin Plugin file.
     * @param bool   $network_wide Network wide.
     */
    function yooadmin_activity_on_deactivated_plugin($plugin, $network_wide): void {
        unset($network_wide);
        if (yooadmin_activity_should_skip_logging()) {
            return;
        }

        if (!function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
        $name = isset($data['Name']) && $data['Name'] !== '' ? $data['Name'] : basename((string) $plugin, '.php');

        yooadmin_activity_log(
            [
                'user_id'     => get_current_user_id(),
                'category'    => 'system',
                'action_slug' => 'plugin_deactivated',
                'object_type' => 'plugin',
                'object_id'   => 0,
                /* translators: %s: plugin name */
                'title'       => sprintf(__('Plugin deactivated: %s', 'yooadmin'), $name),
                'url'         => admin_url('plugins.php'),
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_on_switch_theme')) {
    /**
     * @param string   $new_name Theme name.
     * @param WP_Theme $new_theme Theme object.
     * @param WP_Theme $old_theme Old theme.
     */
    function yooadmin_activity_on_switch_theme($new_name, $new_theme, $old_theme): void {
        unset($old_theme);
        if (yooadmin_activity_should_skip_logging()) {
            return;
        }

        $name = is_object($new_theme) && method_exists($new_theme, 'get') ? (string) $new_theme->get('Name') : (string) $new_name;

        yooadmin_activity_log(
            [
                'user_id'     => get_current_user_id(),
                'category'    => 'system',
                'action_slug' => 'theme_switched',
                'object_type' => 'theme',
                'object_id'   => 0,
                /* translators: %s: theme name */
                'title'       => sprintf(__('Theme switched to %s', 'yooadmin'), $name),
                'url'         => admin_url('themes.php'),
            ]
        );
    }
}
