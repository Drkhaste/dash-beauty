<?php
/**
 * Activity log — bootstrap.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/storage.php';
require_once __DIR__ . '/logger.php';
require_once __DIR__ . '/ajax.php';

add_action('init', 'yooadmin_activity_bootstrap', 20);

/**
 * Register table, backfill, and logger hooks.
 */
function yooadmin_activity_bootstrap(): void {
    if (!apply_filters('yooadmin_activity_enabled', true)) {
        return;
    }

    yooadmin_activity_storage()->maybe_create_tables();
    yooadmin_activity_storage()->backfill_if_empty();
    yooadmin_activity_logger_init();
}
