<?php
/**
 * Activity log — AJAX handlers.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_activity_ajax_verify')) {
    function yooadmin_activity_ajax_verify(): void {
        if (!current_user_can(yooadmin_activity_page_capability())) {
            wp_send_json_error([ 'message' => __('Forbidden', 'yooadmin') ], 403);
        }

        if (!check_ajax_referer('yooadmin_activity', 'nonce', false)) {
            wp_send_json_error([ 'message' => __('Invalid security token.', 'yooadmin') ], 403);
        }
    }
}

if (!function_exists('yooadmin_activity_ajax_filter')) {
    function yooadmin_activity_ajax_filter(): void {
        yooadmin_activity_ajax_verify();

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in yooadmin_activity_ajax_verify().
        $input = [
            'category'  => isset($_POST['category']) ? sanitize_key(wp_unslash($_POST['category'])) : 'all',
            'range'     => isset($_POST['range']) ? sanitize_key(wp_unslash($_POST['range'])) : 'all',
            'user_id'   => isset($_POST['user_id']) ? absint(wp_unslash($_POST['user_id'])) : 0,
            'page'      => isset($_POST['page']) ? absint(wp_unslash($_POST['page'])) : 1,
            'per_page'  => isset($_POST['per_page']) ? absint(wp_unslash($_POST['per_page'])) : 20,
        ];
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $args = yooadmin_activity_query_args_from_request($input);
        $rows = yooadmin_activity_storage()->query($args);
        $total = yooadmin_activity_storage()->count($args);
        $per_page = (int) $args['per_page'];
        $page = (int) $args['page'];
        $total_pages = $per_page > 0 ? (int) ceil($total / $per_page) : 1;

        $items = [];
        foreach ($rows as $row) {
            if (is_array($row)) {
                $items[] = yooadmin_activity_format_row($row);
            }
        }

        ob_start();
        $activity_items = $items;
        include yooadmin_activity_template_path('items-list.php');
        $html = (string) ob_get_clean();

        wp_send_json_success(
            [
                'html'         => $html,
                'total'        => $total,
                'page'         => $page,
                'total_pages'  => $total_pages,
                'has_more'     => $page < $total_pages,
            ]
        );
    }
}

if (!function_exists('yooadmin_activity_template_path')) {
    function yooadmin_activity_template_path(string $filename): string {
        $base = defined('YOOADMIN_DIR')
            ? trailingslashit((string) YOOADMIN_DIR)
            : trailingslashit(dirname(__DIR__, 2)) . '/';

        return $base . 'templates/yoopixel/admin/pages/activity/' . ltrim($filename, '/');
    }
}

add_action('wp_ajax_yooadmin_filter_activity', 'yooadmin_activity_ajax_filter');
