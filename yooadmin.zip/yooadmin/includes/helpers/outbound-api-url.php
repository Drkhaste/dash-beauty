<?php
/**
 * Validate outbound API / portal URLs after apply_filters (SSRF / token-leak hardening).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_get_default_outbound_api_hosts')) {
    /**
     * @return string[]
     */
    function yooadmin_get_default_outbound_api_hosts(): array
    {
        return [
            'yooadmin.io',
            'www.yooadmin.io',
            'yoopixel.com',
            'www.yoopixel.com',
        ];
    }
}

if (!function_exists('yooadmin_get_allowed_outbound_api_hosts')) {
    /**
     * Hostnames allowed for license / management API requests (lowercase, no scheme).
     *
     * @return string[]
     */
    function yooadmin_get_allowed_outbound_api_hosts(): array
    {
        $hosts = yooadmin_get_default_outbound_api_hosts();

        /**
         * Extra hostnames for managed / white-label deployments (e.g. portal.client.com).
         *
         * @param string[] $hosts Hostnames without scheme or path.
         */
        $extra = apply_filters('yooadmin_allowed_outbound_api_hosts', []);

        if (is_array($extra)) {
            foreach ($extra as $host) {
                if (!is_string($host)) {
                    continue;
                }
                $host = strtolower(trim($host));
                if ($host !== '') {
                    $hosts[] = $host;
                }
            }
        }

        $site_host = wp_parse_url(home_url(), PHP_URL_HOST);
        if (is_string($site_host) && $site_host !== '') {
            $hosts[] = strtolower($site_host);
        }

        return array_values(array_unique($hosts));
    }
}

if (!function_exists('yooadmin_is_local_development_host')) {
    function yooadmin_is_local_development_host(string $host): bool
    {
        $host = strtolower(trim($host));

        return in_array($host, ['localhost', '127.0.0.1', '::1'], true);
    }
}

if (!function_exists('yooadmin_is_allowed_outbound_url')) {
    /**
     * Whether an outbound HTTPS URL may be used for license/API/portal calls.
     */
    function yooadmin_is_allowed_outbound_url(string $url): bool
    {
        $url = trim($url);
        if ($url === '') {
            return false;
        }

        $parts = wp_parse_url($url);
        if (!is_array($parts) || empty($parts['host'])) {
            return false;
        }

        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host   = strtolower((string) $parts['host']);

        if ($scheme === 'https') {
            // HTTPS always allowed when host matches.
        } elseif ($scheme === 'http' && yooadmin_is_local_development_host($host)) {
            // Local dev only.
        } else {
            return false;
        }

        $allowed = yooadmin_get_allowed_outbound_api_hosts();

        return in_array($host, $allowed, true);
    }
}

if (!function_exists('yooadmin_sanitize_outbound_api_url')) {
    /**
     * Return $url when allowed; otherwise $fallback (also validated, else default SaaS URL).
     */
    function yooadmin_sanitize_outbound_api_url(string $url, string $fallback): string
    {
        $url      = esc_url_raw(trim($url));
        $fallback = esc_url_raw(trim($fallback));

        if ($url !== '' && yooadmin_is_allowed_outbound_url($url)) {
            return $url;
        }

        if ($fallback !== '' && yooadmin_is_allowed_outbound_url($fallback)) {
            return $fallback;
        }

        return 'https://www.yooadmin.io/wp-json/yoopixel/v1/';
    }
}

if (!function_exists('yooadmin_sanitize_portal_base_url')) {
    function yooadmin_sanitize_portal_base_url(string $url, string $fallback = 'https://www.yooadmin.io/'): string
    {
        $url      = esc_url_raw(trim($url));
        $fallback = esc_url_raw(trim($fallback));

        if ($url !== '' && yooadmin_is_allowed_outbound_url($url)) {
            return trailingslashit($url);
        }

        if ($fallback !== '' && yooadmin_is_allowed_outbound_url($fallback)) {
            return trailingslashit($fallback);
        }

        return 'https://www.yooadmin.io/';
    }
}

if (!function_exists('yooadmin_filter_portal_base_url')) {
    /**
     * apply_filters + outbound host validation for yooadmin_portal_base.
     */
    function yooadmin_filter_portal_base_url(string $default = 'https://www.yooadmin.io/'): string
    {
        $filtered = apply_filters('yooadmin_portal_base', $default);

        return yooadmin_sanitize_portal_base_url(is_string($filtered) ? $filtered : $default, $default);
    }
}

if (!function_exists('yooadmin_filter_management_api_url')) {
    function yooadmin_filter_management_api_url(string $default = 'https://www.yooadmin.io/wp-json/yoopixel/v1/'): string
    {
        $filtered = apply_filters('yooadmin_management_api_url', $default);

        return yooadmin_sanitize_outbound_api_url(is_string($filtered) ? $filtered : $default, $default);
    }
}

if (!function_exists('yooadmin_filter_license_portal_connect_url')) {
    function yooadmin_filter_license_portal_connect_url(string $default = ''): string
    {
        $filtered = apply_filters('yooadmin_license_portal_connect_url', $default);
        if (!is_string($filtered) || $filtered === '') {
            return '';
        }

        return yooadmin_is_allowed_outbound_url($filtered) ? esc_url_raw($filtered) : '';
    }
}
