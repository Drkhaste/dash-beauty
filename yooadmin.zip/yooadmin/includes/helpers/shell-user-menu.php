<?php
/**
 * YOOAdmin shell header user menu — mirror admin-bar user-actions (User Switching, etc.).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_user_switching_session_is_active')) {
    /**
     * True when viewing the admin as a different user than the original (User Switching).
     */
    function yooadmin_user_switching_session_is_active(): bool
    {
        if (!class_exists('user_switching') || !is_user_logged_in()) {
            return false;
        }

        $old_user = user_switching::get_old_user();
        if (!$old_user instanceof WP_User) {
            return false;
        }

        return (int) get_current_user_id() !== (int) $old_user->ID;
    }
}

if (!function_exists('yooadmin_clear_stale_user_switching_session')) {
    /**
     * Drop orphaned User Switching cookies after Switch Off + normal login (same account).
     */
    function yooadmin_clear_stale_user_switching_session(): void
    {
        if (!class_exists('user_switching') || !function_exists('user_switching_clear_olduser_cookie')) {
            return;
        }

        if (!is_user_logged_in()) {
            return;
        }

        $old_user = user_switching::get_old_user();
        if (!$old_user instanceof WP_User) {
            return;
        }

        if ((int) get_current_user_id() === (int) $old_user->ID) {
            user_switching_clear_olduser_cookie(true);
        }
    }
}

if (!function_exists('yooadmin_user_switching_finalize_authenticated_session')) {
    /**
     * Clear User Switching stack after a fresh login (standalone login / 2FA completion).
     */
    function yooadmin_user_switching_finalize_authenticated_session(int $user_id = 0): void
    {
        unset($user_id);

        if (function_exists('user_switching_clear_olduser_cookie')) {
            user_switching_clear_olduser_cookie(true);
        }
    }
}

if (!function_exists('yooadmin_filter_shell_user_switching_action_links')) {
    /**
     * @param array<int, array{id:string,label:string,href:string,class:string}> $items
     * @return array<int, array{id:string,label:string,href:string,class:string}>
     */
    function yooadmin_filter_shell_user_switching_action_links(array $items): array
    {
        if (yooadmin_user_switching_session_is_active()) {
            return $items;
        }

        return array_values(array_filter($items, static function (array $item): bool {
            return ($item['id'] ?? '') !== 'switch-back';
        }));
    }
}

if (!function_exists('yooadmin_users_experience_redirect_enabled')) {
    function yooadmin_users_experience_redirect_enabled(): bool
    {
        $opts = (array) get_option('yooadmin_options', []);

        if (array_key_exists('users_redirect', $opts)) {
            return !empty($opts['users_redirect']);
        }

        return true;
    }
}

if (!function_exists('yooadmin_shell_user_menu_profile_url')) {
    function yooadmin_shell_user_menu_profile_url(): string
    {
        if (
            yooadmin_users_experience_redirect_enabled()
            && function_exists('yooadmin_profile_page_url')
        ) {
            return yooadmin_profile_page_url(get_current_user_id());
        }

        return get_edit_profile_url(get_current_user_id());
    }
}

if (!function_exists('yooadmin_url_targets_users_list')) {
    function yooadmin_url_targets_users_list(string $url): bool
    {
        return str_contains($url, 'page=yooadmin-users')
            || preg_match('#/users\.php(?:\?|$)#', $url) === 1;
    }
}

if (!function_exists('yooadmin_user_switching_redirect_url_for_user')) {
    /**
     * Landing page after switch — must match the target user's capabilities.
     */
    function yooadmin_user_switching_redirect_url_for_user(WP_User $user): string
    {
        if ($user->ID <= 0) {
            return admin_url();
        }

        if (user_can($user, 'list_users') && yooadmin_users_experience_redirect_enabled()) {
            return admin_url('admin.php?page=yooadmin-users');
        }

        if (!user_can($user, 'read')) {
            return home_url('/');
        }

        $slug = apply_filters('yooadmin_dashboard_page_slug', 'yooadmin-dashboard');
        $dashboard_url = admin_url('admin.php?page=' . sanitize_key((string) $slug));

        if (yooadmin_users_experience_redirect_enabled()) {
            return $dashboard_url;
        }

        $opts = (array) get_option('yooadmin_options', []);
        if (!empty($opts['redirect_dashboard'])) {
            return $dashboard_url;
        }

        /** @var string $url */
        return (string) apply_filters('yooadmin_user_switching_redirect_url_for_user', admin_url(), $user);
    }
}

if (!function_exists('yooadmin_user_switching_sanitize_redirect_for_user')) {
    function yooadmin_user_switching_sanitize_redirect_for_user(string $url, WP_User $user): string
    {
        $url = yooadmin_normalize_switch_action_url($url);

        if ($url === '') {
            return yooadmin_user_switching_redirect_url_for_user($user);
        }

        if (yooadmin_url_targets_users_list($url) && !user_can($user, 'list_users')) {
            return yooadmin_user_switching_redirect_url_for_user($user);
        }

        if (preg_match('/[?&]page=yooadmin-users-new\b/', $url) && !user_can($user, 'create_users')) {
            return yooadmin_user_switching_redirect_url_for_user($user);
        }

        // yooadmin-user mirrors user-edit.php (edit_user), not profile.php — subscribers cannot land here.
        if (preg_match('/[?&]page=yooadmin-user\b/', $url)) {
            $target_id = (int) $user->ID;
            if (preg_match('/[?&]user_id=(\d+)/', $url, $matches)) {
                $target_id = (int) $matches[1];
            }

            if (!user_can($user, 'edit_user', $target_id)) {
                return yooadmin_user_switching_redirect_url_for_user($user);
            }
        }

        return $url;
    }
}

if (!function_exists('yooadmin_user_switching_default_redirect_url')) {
    function yooadmin_user_switching_default_redirect_url(?WP_User $user = null): string
    {
        if (!$user instanceof WP_User) {
            $user = wp_get_current_user();
        }

        if ($user instanceof WP_User && $user->ID > 0) {
            return yooadmin_user_switching_redirect_url_for_user($user);
        }

        return admin_url();
    }
}

if (!function_exists('yooadmin_map_core_admin_url_to_yooadmin')) {
    function yooadmin_map_core_admin_url_to_yooadmin(string $url): string
    {
        if ($url === '') {
            return $url;
        }

        $parts = wp_parse_url($url);
        if (!is_array($parts)) {
            return $url;
        }

        $path = isset($parts['path']) ? (string) $parts['path'] : '';
        $query = [];
        if (!empty($parts['query'])) {
            parse_str((string) $parts['query'], $query);
        }

        if (preg_match('#/users\.php$#', $path) && yooadmin_users_experience_redirect_enabled()) {
            $mapped = admin_url('admin.php?page=yooadmin-users');
            foreach ($query as $key => $value) {
                $mapped = add_query_arg(sanitize_key((string) $key), $value, $mapped);
            }

            return $mapped;
        }

        if (
            preg_match('#/profile\.php$#', $path)
            && yooadmin_users_experience_redirect_enabled()
            && function_exists('yooadmin_profile_page_url')
        ) {
            return yooadmin_profile_page_url(get_current_user_id());
        }

        if (
            preg_match('#/user-edit\.php$#', $path)
            && yooadmin_users_experience_redirect_enabled()
            && function_exists('yooadmin_profile_page_url')
            && !empty($query['user_id'])
        ) {
            return yooadmin_profile_page_url((int) $query['user_id']);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_normalize_switch_action_url')) {
    /**
     * Decode HTML entities so add_query_arg / esc_url are not applied twice.
     */
    function yooadmin_normalize_switch_action_url(string $url): string
    {
        if ($url === '') {
            return $url;
        }

        return html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}

if (!function_exists('yooadmin_append_yooadmin_redirect_to_switch_url')) {
    function yooadmin_append_yooadmin_redirect_to_switch_url(string $url, ?WP_User $target_user = null): string
    {
        if ($url === '' || stripos($url, 'switch_to') === false) {
            return $url;
        }

        $url = yooadmin_normalize_switch_action_url($url);
        $redirect = $target_user instanceof WP_User
            ? yooadmin_user_switching_redirect_url_for_user($target_user)
            : yooadmin_user_switching_default_redirect_url();

        return add_query_arg('redirect_to', $redirect, remove_query_arg('redirect_to', $url));
    }
}

if (!function_exists('yooadmin_ensure_admin_bar_nodes_cached')) {
    function yooadmin_ensure_admin_bar_nodes_cached(): void
    {
        global $wp_admin_bar, $yooadmin_toolbar_nodes;

        if (is_array($yooadmin_toolbar_nodes) && $yooadmin_toolbar_nodes) {
            return;
        }

        if (!is_admin() || !is_user_logged_in()) {
            return;
        }

        if (!is_object($wp_admin_bar)) {
            require_once ABSPATH . WPINC . '/class-wp-admin-bar.php';
            $wp_admin_bar = new WP_Admin_Bar();
        }

        if (!did_action('admin_bar_init')) {
            /** @var WP_Admin_Bar $wp_admin_bar */
            // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core admin bar bootstrap.
            do_action('admin_bar_init');
        }

        if (method_exists($wp_admin_bar, 'add_menus')) {
            $wp_admin_bar->add_menus();
        }

        if (function_exists('yooadmin_cache_toolbar_nodes')) {
            yooadmin_cache_toolbar_nodes($wp_admin_bar);
        }
    }
}

if (!function_exists('yooadmin_get_shell_admin_bar_user_action_nodes')) {
    /**
     * Plugin-provided links under admin-bar "user-actions" (Switch back, Switch off, etc.).
     *
     * @return array<int, array{id:string,label:string,href:string,class:string}>
     */
    function yooadmin_get_shell_admin_bar_user_action_nodes(): array
    {
        if (!is_user_logged_in()) {
            return [];
        }

        yooadmin_ensure_admin_bar_nodes_cached();

        global $yooadmin_toolbar_nodes;

        $nodes = is_array($yooadmin_toolbar_nodes) ? $yooadmin_toolbar_nodes : [];
        $skip_ids = ['user-info', 'logout'];
        $items = [];

        foreach ($nodes as $node) {
            if (!$node || !is_object($node)) {
                continue;
            }

            $parent = isset($node->parent) ? (string) $node->parent : '';
            $id = isset($node->id) ? (string) $node->id : '';
            if ($parent !== 'user-actions' || $id === '' || in_array($id, $skip_ids, true)) {
                continue;
            }

            $raw_title = isset($node->title) ? (string) $node->title : '';
            $label = function_exists('yooadmin_extract_toolbar_display_label')
                ? yooadmin_extract_toolbar_display_label($raw_title)
                : trim(wp_strip_all_tags($raw_title));
            if ($label === '') {
                continue;
            }

            $href = isset($node->href) ? (string) $node->href : '';
            if ($href === '') {
                continue;
            }

            $href = yooadmin_normalize_switch_action_url($href);
            $href = yooadmin_map_core_admin_url_to_yooadmin($href);
            $href = yooadmin_append_yooadmin_redirect_to_switch_url($href);

            $meta = is_array($node->meta ?? null) ? $node->meta : [];
            $items[] = [
                'id'    => $id,
                'label' => $label,
                'href'  => $href,
                'class' => isset($meta['class']) ? (string) $meta['class'] : '',
            ];
        }

        if ($items === [] && class_exists('user_switching')) {
            $items = yooadmin_get_user_switching_shell_menu_fallback_links();
        }

        $items = yooadmin_filter_shell_user_switching_action_links($items);

        /** @var array<int, array{id:string,label:string,href:string,class:string}> $items */
        return (array) apply_filters('yooadmin_shell_user_menu_action_links', $items);
    }
}

if (!function_exists('yooadmin_get_user_switching_shell_menu_fallback_links')) {
    /**
     * @return array<int, array{id:string,label:string,href:string,class:string}>
     */
    function yooadmin_get_user_switching_shell_menu_fallback_links(): array
    {
        if (!class_exists('user_switching')) {
            return [];
        }

        $links = [];
        if (yooadmin_user_switching_session_is_active()) {
            $old_user = user_switching::get_old_user();
            if ($old_user instanceof WP_User) {
                $links[] = [
                    'id'    => 'switch-back',
                    'label' => user_switching::switch_back_message($old_user),
                    'href'  => yooadmin_append_yooadmin_redirect_to_switch_url(
                        user_switching::switch_back_url($old_user)
                    ),
                    'class' => '',
                ];
            }
        }

        if (current_user_can('switch_off') && method_exists('user_switching', 'switch_off_url')) {
            $links[] = [
                'id'    => 'switch-off',
                'label' => __('Switch Off', 'yooadmin'),
                'href'  => yooadmin_append_yooadmin_redirect_to_switch_url(user_switching::switch_off_url()),
                'class' => '',
            ];
        }

        return $links;
    }
}

if (!function_exists('yooadmin_render_shell_admin_bar_user_action_links')) {
    function yooadmin_render_shell_admin_bar_user_action_links(): void
    {
        foreach (yooadmin_get_shell_admin_bar_user_action_nodes() as $link) {
            if (empty($link['href']) || empty($link['label'])) {
                continue;
            }

            $class = 'yp-user-dropdown__plugin-link';
            if (!empty($link['class'])) {
                $class .= ' ' . sanitize_html_class((string) $link['class']);
            }
            if (!empty($link['id'])) {
                $class .= ' yp-user-dropdown__plugin-link--' . sanitize_html_class((string) $link['id']);
            }

            echo '<a class="' . esc_attr($class) . '" href="' . esc_url((string) $link['href']) . '">';
            echo '<span class="dashicons dashicons-randomize" aria-hidden="true"></span> ';
            echo esc_html((string) $link['label']);
            echo '</a>';
        }
    }
}

if (!function_exists('yooadmin_filter_user_row_actions_switch_redirect')) {
    function yooadmin_filter_user_row_actions_switch_redirect(array $actions, WP_User $user): array
    {
        if (!class_exists('user_switching') || !method_exists('user_switching', 'maybe_switch_url')) {
            return $actions;
        }

        $link = user_switching::maybe_switch_url($user);
        if (!$link) {
            return $actions;
        }

        $link = yooadmin_append_yooadmin_redirect_to_switch_url($link, $user);

        $actions['switch_to_user'] = sprintf(
            '<a href="%s">%s</a>',
            esc_url($link),
            esc_html__('Switch&nbsp;To', 'yooadmin')
        );

        return $actions;
    }
}

if (!function_exists('yooadmin_filter_user_switching_redirect_to')) {
    function yooadmin_filter_user_switching_redirect_to($redirect_to, $redirect_type, $new_user, $old_user)
    {
        unset($redirect_type, $old_user);

        $redirect_to = yooadmin_map_core_admin_url_to_yooadmin((string) $redirect_to);

        $target = $new_user instanceof WP_User ? $new_user : wp_get_current_user();

        if (
            $redirect_to === ''
            || yooadmin_url_targets_users_list($redirect_to)
            || preg_match('#/users\.php(?:\?|$)#', $redirect_to)
            || preg_match('#/user-edit\.php(?:\?|$)#', $redirect_to)
            || preg_match('#/wp-admin/?$#', $redirect_to)
            || preg_match('/[?&]page=yooadmin-user\b/', $redirect_to)
            || preg_match('/[?&]page=yooadmin-users-new\b/', $redirect_to)
        ) {
            return $target instanceof WP_User && $target->ID > 0
                ? yooadmin_user_switching_redirect_url_for_user($target)
                : yooadmin_user_switching_default_redirect_url();
        }

        if ($target instanceof WP_User && $target->ID > 0) {
            return yooadmin_user_switching_sanitize_redirect_for_user($redirect_to, $target);
        }

        return $redirect_to;
    }
}

if (!function_exists('yooadmin_preserve_focus_on_user_switch')) {
    function yooadmin_preserve_focus_on_user_switch(int $user_id, int $old_user_id): void
    {
        unset($user_id);

        if ($old_user_id <= 0 || !function_exists('yooadmin_set_focus_cookie')) {
            return;
        }

        $pref = function_exists('yooadmin_get_user_focus_preference')
            ? yooadmin_get_user_focus_preference($old_user_id)
            : '';

        if ($pref === 'on' || ($pref === '' && function_exists('yooadmin_get_focus_cookie') && yooadmin_get_focus_cookie() !== 'off')) {
            yooadmin_set_focus_cookie('on');
        }
    }
}

if (!function_exists('yooadmin_preserve_focus_on_user_switch_back')) {
    function yooadmin_preserve_focus_on_user_switch_back(int $user_id): void
    {
        if ($user_id <= 0 || !function_exists('yooadmin_set_focus_cookie')) {
            return;
        }

        $pref = function_exists('yooadmin_get_user_focus_preference')
            ? yooadmin_get_user_focus_preference($user_id)
            : '';

        if ($pref === 'on' || ($pref === '' && get_option('yooadmin_focus_policy', 'auto') !== 'off')) {
            yooadmin_set_focus_cookie('on');
        }
    }
}

if (!function_exists('yooadmin_keep_focus_while_user_switched')) {
    function yooadmin_keep_focus_while_user_switched(bool $enabled): bool
    {
        if ($enabled || !class_exists('user_switching')) {
            return $enabled;
        }

        $old_user = user_switching::get_old_user();
        if (!$old_user instanceof WP_User) {
            return $enabled;
        }

        $admin_pref = function_exists('yooadmin_get_user_focus_preference')
            ? yooadmin_get_user_focus_preference((int) $old_user->ID)
            : '';

        if ($admin_pref === 'on') {
            return true;
        }

        if ($admin_pref === '' && function_exists('yooadmin_get_focus_cookie') && yooadmin_get_focus_cookie() === 'on') {
            return true;
        }

        return $enabled;
    }
}

add_filter('user_switching_redirect_to', 'yooadmin_filter_user_switching_redirect_to', 20, 4);
add_filter('user_row_actions', 'yooadmin_filter_user_row_actions_switch_redirect', 15, 2);
add_filter('ms_user_row_actions', 'yooadmin_filter_user_row_actions_switch_redirect', 15, 2);
add_action('switch_to_user', 'yooadmin_preserve_focus_on_user_switch', 5, 2);
add_action('switch_back_user', 'yooadmin_preserve_focus_on_user_switch_back', 5, 1);
add_filter('yooadmin_focus_enabled', 'yooadmin_keep_focus_while_user_switched', 20);
add_action('wp_login', 'yooadmin_clear_stale_user_switching_session', 25);
add_action('init', 'yooadmin_clear_stale_user_switching_session', 5);
