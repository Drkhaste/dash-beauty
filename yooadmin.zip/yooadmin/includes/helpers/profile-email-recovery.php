<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_email_recovery_is_reverting')) {
    function yooadmin_email_recovery_is_reverting(): bool
    {
        return !empty($GLOBALS['yooadmin_email_recovery_reverting']);
    }
}

if (!function_exists('yooadmin_email_recovery_meta_key')) {
    function yooadmin_email_recovery_meta_key(): string
    {
        return '_yooadmin_email_change_recovery';
    }
}

if (!function_exists('yooadmin_email_recovery_hash_key')) {
    function yooadmin_email_recovery_hash_key(string $key): string
    {
        if (function_exists('yooadmin_fast_hash')) {
            return yooadmin_fast_hash($key);
        }

        return wp_hash_password($key);
    }
}

if (!function_exists('yooadmin_email_recovery_verify_key')) {
    function yooadmin_email_recovery_verify_key(string $key, string $hash): bool
    {
        if (function_exists('yooadmin_verify_fast_hash')) {
            return yooadmin_verify_fast_hash($key, $hash);
        }

        return wp_check_password($key, $hash);
    }
}

if (!function_exists('yooadmin_email_recovery_is_enabled')) {
    function yooadmin_email_recovery_is_enabled(): bool
    {
        if (!function_exists('yooadmin_get_options')) {
            return true;
        }

        $opts = yooadmin_get_options();

        if (!array_key_exists('login_email_change_recovery_enabled', $opts)) {
            return true;
        }

        return !empty($opts['login_email_change_recovery_enabled']);
    }
}

if (!function_exists('yooadmin_email_recovery_expiration')) {
    function yooadmin_email_recovery_expiration(): int
    {
        /** @var int $seconds */
        $seconds = (int) apply_filters('yooadmin_email_recovery_expiration', 2 * DAY_IN_SECONDS);

        return max(HOUR_IN_SECONDS, min(7 * DAY_IN_SECONDS, $seconds));
    }
}

if (!function_exists('yooadmin_email_recovery_rate_limit_storage_key')) {
    function yooadmin_email_recovery_rate_limit_storage_key(): string
    {
        $ip = function_exists('yooadmin_get_request_client_ip')
            ? yooadmin_get_request_client_ip()
            : (isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR'])) : '');

        if ($ip === '') {
            return '';
        }

        return 'yooadmin_email_recovery_rl_' . md5($ip);
    }
}

if (!function_exists('yooadmin_email_recovery_rate_limit_is_blocked')) {
    function yooadmin_email_recovery_rate_limit_is_blocked(): bool
    {
        $key = yooadmin_email_recovery_rate_limit_storage_key();
        if ($key === '') {
            return false;
        }

        return (int) get_transient($key) >= 10;
    }
}

if (!function_exists('yooadmin_email_recovery_rate_limit_record_attempt')) {
    function yooadmin_email_recovery_rate_limit_record_attempt(): void
    {
        $key = yooadmin_email_recovery_rate_limit_storage_key();
        if ($key === '') {
            return;
        }

        $count = (int) get_transient($key);
        set_transient($key, $count + 1, 15 * MINUTE_IN_SECONDS);
    }
}

if (!function_exists('yooadmin_email_recovery_rate_limit_clear')) {
    function yooadmin_email_recovery_rate_limit_clear(): void
    {
        $key = yooadmin_email_recovery_rate_limit_storage_key();
        if ($key !== '') {
            delete_transient($key);
        }
    }
}

if (!function_exists('yooadmin_email_recovery_rate_limit_allows')) {
    /**
     * @deprecated 1.5.14 Use yooadmin_email_recovery_rate_limit_is_blocked() for reads.
     */
    function yooadmin_email_recovery_rate_limit_allows(): bool
    {
        if (yooadmin_email_recovery_rate_limit_is_blocked()) {
            return false;
        }

        yooadmin_email_recovery_rate_limit_record_attempt();

        return true;
    }
}

if (!function_exists('yooadmin_email_recovery_login_grace_key')) {
    function yooadmin_email_recovery_login_grace_key(string $login): string
    {
        $login = sanitize_user($login, true);

        return $login !== '' ? 'yooadmin_email_recovery_login_grace_' . md5($login) : '';
    }
}

if (!function_exists('yooadmin_email_recovery_grant_login_grace')) {
    function yooadmin_email_recovery_grant_login_grace(string $login): void
    {
        $login = sanitize_user($login, true);
        if ($login === '') {
            return;
        }

        $grace_key = yooadmin_email_recovery_login_grace_key($login);
        if ($grace_key !== '') {
            set_transient($grace_key, 1, 30 * MINUTE_IN_SECONDS);
        }

        yooadmin_email_recovery_rate_limit_clear();

        if (function_exists('yooadmin_login_rate_limit_clear')) {
            yooadmin_login_rate_limit_clear('login', $login);
        }
    }
}

if (!function_exists('yooadmin_email_recovery_login_has_grace')) {
    function yooadmin_email_recovery_login_has_grace(string $login): bool
    {
        $grace_key = yooadmin_email_recovery_login_grace_key($login);

        return $grace_key !== '' && get_transient($grace_key) !== false;
    }
}

if (!function_exists('yooadmin_email_recovery_consume_login_grace')) {
    function yooadmin_email_recovery_consume_login_grace(string $login): void
    {
        $grace_key = yooadmin_email_recovery_login_grace_key($login);
        if ($grace_key !== '') {
            delete_transient($grace_key);
        }
    }
}

if (!function_exists('yooadmin_email_recovery_issue_for_change')) {
    /**
     * @return string
     */
    function yooadmin_email_recovery_issue_for_change(int $user_id, string $old_email, string $new_email): string
    {
        if (yooadmin_email_recovery_is_reverting() || !yooadmin_email_recovery_is_enabled() || $user_id <= 0) {
            return '';
        }

        $old_email = sanitize_email($old_email);
        $new_email = sanitize_email($new_email);

        if (!is_email($old_email) || !is_email($new_email) || strcasecmp($old_email, $new_email) === 0) {
            return '';
        }

        $key = wp_generate_password(20, false);
        if ($key === '') {
            return '';
        }

        $record = [
            'hash'      => time() . ':' . yooadmin_email_recovery_hash_key($key),
            'old_email' => $old_email,
            'new_email' => $new_email,
            'issued'    => time(),
        ];

        update_user_meta($user_id, yooadmin_email_recovery_meta_key(), $record);

        /**
         * Fires when an email-change recovery key is generated.
         *
         * @param int    $user_id   User ID.
         * @param string $old_email Previous email address.
         * @param string $new_email New email address.
         */
        do_action('yooadmin_email_recovery_key_issued', $user_id, $old_email, $new_email);

        return $key;
    }
}

if (!function_exists('yooadmin_email_recovery_action_url')) {
    function yooadmin_email_recovery_action_url(string $key, string $login): string
    {
        $args = [
            'action' => 'yooadmin_recover_email',
            'key'    => $key,
            'login'  => $login,
        ];

        if (function_exists('yooadmin_standalone_login_public_url')) {
            $url = add_query_arg($args, yooadmin_standalone_login_public_url());
        } elseif (function_exists('yooadmin_native_2fa_core_wp_login_url')) {
            $url = yooadmin_native_2fa_core_wp_login_url($args);
        } else {
            $url = network_site_url('wp-login.php', 'login');
            $url = add_query_arg($args, $url);
        }

        /** @var string $url */
        return (string) apply_filters('yooadmin_email_recovery_url', $url, $key, $login);
    }
}

if (!function_exists('yooadmin_email_recovery_url')) {
    function yooadmin_email_recovery_url(string $key, string $login): string
    {
        return yooadmin_email_recovery_action_url($key, $login);
    }
}

if (!function_exists('yooadmin_email_recovery_is_request')) {
    function yooadmin_email_recovery_is_request(): bool
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public recovery entry; POST verified separately.
        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash((string) $_REQUEST['action'])) : '';

        return $action === 'yooadmin_recover_email';
    }
}

if (!function_exists('yooadmin_email_recovery_is_public_login_request')) {
    function yooadmin_email_recovery_is_public_login_request(): bool
    {
        if (function_exists('yooadmin_hidden_login_entry_is_secret_request')
            && yooadmin_hidden_login_entry_is_secret_request()) {
            return true;
        }

        return function_exists('yooadmin_standalone_login_is_this_request')
            && yooadmin_standalone_login_is_this_request();
    }
}

if (!function_exists('yooadmin_email_recovery_get_record')) {
    /**
     * @return array<string, mixed>|null
     */
    function yooadmin_email_recovery_get_record(int $user_id): ?array
    {
        $record = get_user_meta($user_id, yooadmin_email_recovery_meta_key(), true);

        return is_array($record) ? $record : null;
    }
}

if (!function_exists('yooadmin_email_recovery_verify')) {
    /**
     * @return WP_User|WP_Error
     */
    function yooadmin_email_recovery_verify(string $key, string $login)
    {
        if (yooadmin_email_recovery_rate_limit_is_blocked()) {
            return new WP_Error(
                'yooadmin_email_recovery_rate_limited',
                __('Too many recovery attempts. Please try again later.', 'yooadmin')
            );
        }

        $key = preg_replace('/[^a-z0-9]/i', '', $key);
        if ($key === '') {
            return new WP_Error(
                'yooadmin_email_recovery_invalid_key',
                __('This recovery link is invalid.', 'yooadmin')
            );
        }

        $login = sanitize_user($login, true);
        if ($login === '') {
            return new WP_Error(
                'yooadmin_email_recovery_invalid_key',
                __('This recovery link is invalid.', 'yooadmin')
            );
        }

        $user = get_user_by('login', $login);
        if (!$user instanceof WP_User) {
            return new WP_Error(
                'yooadmin_email_recovery_invalid_key',
                __('This recovery link is invalid.', 'yooadmin')
            );
        }

        $record = yooadmin_email_recovery_get_record((int) $user->ID);
        if ($record === null || empty($record['hash']) || !is_string($record['hash'])) {
            return new WP_Error(
                'yooadmin_email_recovery_invalid_key',
                __('This recovery link is invalid or has already been used.', 'yooadmin')
            );
        }

        if (!str_contains($record['hash'], ':')) {
            delete_user_meta((int) $user->ID, yooadmin_email_recovery_meta_key());

            return new WP_Error(
                'yooadmin_email_recovery_invalid_key',
                __('This recovery link is invalid.', 'yooadmin')
            );
        }

        [$issued_at, $hash] = explode(':', $record['hash'], 2);
        $issued_at          = (int) $issued_at;
        $expires_at         = $issued_at + yooadmin_email_recovery_expiration();

        if ($issued_at <= 0 || !yooadmin_email_recovery_verify_key($key, $hash)) {
            return new WP_Error(
                'yooadmin_email_recovery_invalid_key',
                __('This recovery link is invalid.', 'yooadmin')
            );
        }

        if (time() >= $expires_at) {
            delete_user_meta((int) $user->ID, yooadmin_email_recovery_meta_key());

            return new WP_Error(
                'yooadmin_email_recovery_expired_key',
                __('This recovery link has expired.', 'yooadmin')
            );
        }

        $expected_new = sanitize_email((string) ($record['new_email'] ?? ''));
        if ($expected_new === '' || strcasecmp($user->user_email, $expected_new) !== 0) {
            delete_user_meta((int) $user->ID, yooadmin_email_recovery_meta_key());

            return new WP_Error(
                'yooadmin_email_recovery_stale',
                __('This recovery link is no longer valid for this account.', 'yooadmin')
            );
        }

        return $user;
    }
}

if (!function_exists('yooadmin_email_recovery_execute')) {
    /**
     * @return true|WP_Error
     */
    function yooadmin_email_recovery_execute(WP_User $user, string $key)
    {
        $verified = yooadmin_email_recovery_verify($key, $user->user_login);
        if (is_wp_error($verified)) {
            return $verified;
        }

        $record = yooadmin_email_recovery_get_record((int) $user->ID);
        if ($record === null) {
            return new WP_Error(
                'yooadmin_email_recovery_invalid_key',
                __('This recovery link is invalid or has already been used.', 'yooadmin')
            );
        }

        $old_email = sanitize_email((string) ($record['old_email'] ?? ''));
        if (!is_email($old_email)) {
            delete_user_meta((int) $user->ID, yooadmin_email_recovery_meta_key());

            return new WP_Error(
                'yooadmin_email_recovery_invalid_key',
                __('This recovery link is invalid.', 'yooadmin')
            );
        }

        $suppress_email = static function (): bool {
            return false;
        };

        add_filter('send_email_change_email', $suppress_email, 100);
        add_filter('send_password_change_email', $suppress_email, 100);

        $GLOBALS['yooadmin_email_recovery_reverting'] = true;

        $updated = wp_update_user(
            [
                'ID'         => (int) $user->ID,
                'user_email' => $old_email,
            ]
        );

        unset($GLOBALS['yooadmin_email_recovery_reverting']);

        remove_filter('send_email_change_email', $suppress_email, 100);
        remove_filter('send_password_change_email', $suppress_email, 100);

        if (is_wp_error($updated)) {
            return $updated;
        }

        delete_user_meta((int) $user->ID, yooadmin_email_recovery_meta_key());
        delete_user_meta((int) $user->ID, '_new_email');

        wp_update_user(
            [
                'ID'                  => (int) $user->ID,
                'user_activation_key' => '',
            ]
        );

        $sessions = WP_Session_Tokens::get_instance((int) $user->ID);
        $sessions->destroy_all();

        /**
         * Fires after a successful email-change recovery.
         *
         * @param int    $user_id   User ID.
         * @param string $old_email Restored email address.
         * @param string $new_email Revoked email address.
         */
        do_action(
            'yooadmin_email_recovery_completed',
            (int) $user->ID,
            $old_email,
            sanitize_email((string) ($record['new_email'] ?? ''))
        );

        if (function_exists('yooadmin_branded_email_send_recovery_success_notice')) {
            yooadmin_branded_email_send_recovery_success_notice($user, $old_email);
        }

        return true;
    }
}

if (!function_exists('yooadmin_email_recovery_post_success_redirect_url')) {
    /**
     * Login destination after a successful email recovery.
     *
     * Standalone/custom login page when enabled; otherwise hidden-entry URL or core wp-login.php.
     */
    function yooadmin_email_recovery_post_success_redirect_url(string $login = ''): string
    {
        $args = ['yooadmin_email_recovered' => '1'];
        $login = sanitize_user($login, true);
        if ($login !== '') {
            $args['recovered_login'] = $login;
        }

        if (
            function_exists('yooadmin_custom_login_uses_standalone_page')
            && yooadmin_custom_login_uses_standalone_page()
            && function_exists('yooadmin_standalone_login_public_url')
        ) {
            return add_query_arg($args, yooadmin_standalone_login_public_url());
        }

        if (
            function_exists('yooadmin_hidden_login_entry_is_enabled')
            && yooadmin_hidden_login_entry_is_enabled()
            && function_exists('yooadmin_hidden_login_entry_should_block_visitor')
            && yooadmin_hidden_login_entry_should_block_visitor()
        ) {
            if (function_exists('yooadmin_hidden_login_entry_grant_wp_login_access')) {
                $token = yooadmin_hidden_login_entry_grant_wp_login_access();
                if ($token !== '') {
                    $args['yooadmin_hl_gate'] = $token;
                }
            }

            if (function_exists('yooadmin_hidden_login_entry_url')) {
                return add_query_arg($args, yooadmin_hidden_login_entry_url());
            }
        }

        if (function_exists('yooadmin_native_2fa_core_wp_login_url')) {
            return yooadmin_native_2fa_core_wp_login_url($args);
        }

        return add_query_arg($args, network_site_url('wp-login.php', 'login'));
    }
}

if (!function_exists('yooadmin_email_recovery_get_restore_email')) {
    function yooadmin_email_recovery_get_restore_email(WP_User $user): string
    {
        $record = yooadmin_email_recovery_get_record((int) $user->ID);
        if ($record === null) {
            return '';
        }

        $email = sanitize_email((string) ($record['old_email'] ?? ''));

        return is_email($email) ? $email : '';
    }
}

if (!function_exists('yooadmin_email_recovery_render_confirm_markup')) {
    function yooadmin_email_recovery_render_confirm_markup(
        string $action_url,
        string $key,
        string $login,
        string $error = '',
        string $restore_email = ''
    ): void {
        $restore_email = sanitize_email($restore_email);
        if (!is_email($restore_email)) {
            $restore_email = '';
        }

        if ($restore_email !== '') {
            $message = __(
                'If you did not authorize the email change on your account, you can restore your previous email address shown below. All active sessions will be signed out.',
                'yooadmin'
            );
        } else {
            $message = __(
                'If you did not authorize the email change on your account, you can restore your previous email address. All active sessions will be signed out.',
                'yooadmin'
            );
        }

        if (function_exists('yooadmin_branded_public_security_page_render')) {
            yooadmin_branded_public_security_page_render(
                [
                    'title'         => __('Recover account', 'yooadmin'),
                    'message'       => $message,
                    'restore_email' => $restore_email,
                    'email_label'   => __('Email to restore', 'yooadmin'),
                    'error'         => $error,
                    'action_url'    => $action_url,
                    'hidden_fields' => [
                        'action' => 'yooadmin_recover_email',
                        'key'    => $key,
                        'login'  => $login,
                    ],
                    'nonce_action'  => 'yooadmin_recover_email',
                    'nonce_name'    => 'yooadmin_recover_email_nonce',
                    'submit_label'  => __('Recover my account', 'yooadmin'),
                ]
            );
        }

        $title = __('Recover account', 'yooadmin');

        echo '<!DOCTYPE html><html ';
        language_attributes();
        echo '><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
        echo '<meta name="robots" content="noindex,nofollow"><title>' . esc_html($title) . '</title></head><body>';
        echo '<h1>' . esc_html($title) . '</h1>';

        if ($error !== '') {
            echo '<p>' . esc_html($error) . '</p>';
        } else {
            echo '<p>' . esc_html($message) . '</p>';

            if ($restore_email !== '') {
                echo '<p><strong>' . esc_html__('Email to restore', 'yooadmin') . '</strong></p>';
                echo '<p dir="ltr">' . esc_html($restore_email) . '</p>';
            }

            echo '<form method="post" action="' . esc_url($action_url) . '">';
            echo '<input type="hidden" name="action" value="yooadmin_recover_email" />';
            echo '<input type="hidden" name="key" value="' . esc_attr($key) . '" />';
            echo '<input type="hidden" name="login" value="' . esc_attr($login) . '" />';
            wp_nonce_field('yooadmin_recover_email', 'yooadmin_recover_email_nonce');
            echo '<p><button type="submit">' . esc_html__('Recover my account', 'yooadmin') . '</button></p>';
            echo '</form>';
        }

        echo '</body></html>';
    }
}

if (!function_exists('yooadmin_email_recovery_maybe_handle_standalone_request')) {
    function yooadmin_email_recovery_maybe_handle_standalone_request(): void
    {
        if (!yooadmin_email_recovery_is_enabled() || !yooadmin_email_recovery_is_request()) {
            return;
        }

        if (!yooadmin_email_recovery_is_public_login_request()) {
            return;
        }

        $locale = function_exists('yooadmin_custom_login_get_login_locale')
            ? yooadmin_custom_login_get_login_locale()
            : null;
        if (function_exists('switch_to_locale') && is_string($locale) && $locale !== '') {
            switch_to_locale($locale);
        }
        if (function_exists('yooadmin_load_yooadmin_textdomain')) {
            yooadmin_load_yooadmin_textdomain($locale);
        }

        $method = isset($_SERVER['REQUEST_METHOD'])
            ? strtoupper(sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_METHOD'])))
            : 'GET';

        if ($method === 'POST') {
            yooadmin_email_recovery_handle_post();
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only step; POST uses nonce.
        $login = isset($_REQUEST['login']) ? sanitize_user(wp_unslash((string) $_REQUEST['login']), true) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Key verified before showing the form.
        $key   = isset($_REQUEST['key']) ? sanitize_text_field(wp_unslash((string) $_REQUEST['key'])) : '';

        $verified      = yooadmin_email_recovery_verify($key, $login);
        $error         = is_wp_error($verified) ? $verified->get_error_message() : '';
        $restore_email = ($verified instanceof WP_User) ? yooadmin_email_recovery_get_restore_email($verified) : '';

        status_header(200);
        nocache_headers();
        yooadmin_email_recovery_render_confirm_markup(
            yooadmin_email_recovery_action_url($key, $login),
            $key,
            $login,
            $error,
            $restore_email
        );
        exit;
    }
}

add_action('template_redirect', 'yooadmin_email_recovery_maybe_handle_standalone_request', -1);

if (!function_exists('yooadmin_email_recovery_login_init')) {
    function yooadmin_email_recovery_login_init(): void
    {
        if (!yooadmin_email_recovery_is_enabled()) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public recovery entry; POST verified separately.
        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash((string) $_REQUEST['action'])) : '';
        if ($action !== 'yooadmin_recover_email') {
            return;
        }

        $locale = function_exists('yooadmin_custom_login_get_login_locale')
            ? yooadmin_custom_login_get_login_locale()
            : null;
        if (function_exists('switch_to_locale') && is_string($locale) && $locale !== '') {
            switch_to_locale($locale);
        }
        if (function_exists('yooadmin_load_yooadmin_textdomain')) {
            yooadmin_load_yooadmin_textdomain($locale);
        }

        $method = isset($_SERVER['REQUEST_METHOD'])
            ? strtoupper(sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_METHOD'])))
            : 'GET';

        if ($method === 'POST') {
            yooadmin_email_recovery_handle_post();
            return;
        }

        add_action('login_form_yooadmin_recover_email', 'yooadmin_email_recovery_render_confirm_form');
    }
}

add_action('login_init', 'yooadmin_email_recovery_login_init', 1);

if (!function_exists('yooadmin_email_recovery_render_confirm_form')) {
    function yooadmin_email_recovery_render_confirm_form(): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only step; POST uses nonce.
        $login = isset($_REQUEST['login']) ? sanitize_user(wp_unslash((string) $_REQUEST['login']), true) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Key verified before showing the form.
        $key   = isset($_REQUEST['key']) ? sanitize_text_field(wp_unslash((string) $_REQUEST['key'])) : '';

        $verified      = yooadmin_email_recovery_verify($key, $login);
        $error         = is_wp_error($verified) ? $verified->get_error_message() : '';
        $restore_email = ($verified instanceof WP_User) ? yooadmin_email_recovery_get_restore_email($verified) : '';

        yooadmin_email_recovery_render_confirm_markup(
            yooadmin_email_recovery_action_url($key, $login),
            $key,
            $login,
            $error,
            $restore_email
        );
        exit;
    }
}

if (!function_exists('yooadmin_email_recovery_handle_post')) {
    function yooadmin_email_recovery_handle_post(): void
    {
        if (yooadmin_email_recovery_rate_limit_is_blocked()) {
            wp_die(esc_html__('Too many recovery attempts. Please try again later.', 'yooadmin'));
        }

        $nonce = isset($_POST['yooadmin_recover_email_nonce'])
            ? sanitize_text_field(wp_unslash((string) $_POST['yooadmin_recover_email_nonce']))
            : '';

        if ($nonce === '' || !wp_verify_nonce($nonce, 'yooadmin_recover_email')) {
            wp_die(esc_html__('Security check failed. Please open the recovery link from your email again.', 'yooadmin'));
        }

        $login = isset($_POST['login']) ? sanitize_user(wp_unslash((string) $_POST['login']), true) : '';
        $key   = isset($_POST['key']) ? sanitize_text_field(wp_unslash((string) $_POST['key'])) : '';

        $user = get_user_by('login', $login);
        if (!$user instanceof WP_User) {
            wp_die(esc_html__('This recovery link is invalid.', 'yooadmin'));
        }

        $result = yooadmin_email_recovery_execute($user, $key);
        if (is_wp_error($result)) {
            yooadmin_email_recovery_rate_limit_record_attempt();
            wp_die(esc_html($result->get_error_message()));
        }

        yooadmin_email_recovery_grant_login_grace($user->user_login);

        $redirect = yooadmin_email_recovery_post_success_redirect_url($user->user_login);

        wp_safe_redirect($redirect);
        exit;
    }
}

if (!function_exists('yooadmin_email_recovery_login_message')) {
    /**
     * @param string $message Existing login message.
     */
    function yooadmin_email_recovery_login_message($message): string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash flag.
        if (!isset($_GET['yooadmin_email_recovered'])) {
            return $message;
        }

        if (function_exists('yooadmin_load_yooadmin_textdomain')) {
            yooadmin_load_yooadmin_textdomain();
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only flash flag.
        if (isset($_GET['recovered_login'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only flash flag.
            $recovered_login = sanitize_user(wp_unslash((string) $_GET['recovered_login']), true);
        } else {
            $recovered_login = '';
        }

        if ($recovered_login !== '') {
            $notice = '<p class="message">' . esc_html(
                sprintf(
                    /* translators: %s: WordPress username */
                    __('Your account email was restored. Sign in with username %s and your password.', 'yooadmin'),
                    $recovered_login
                )
            ) . '</p>';
        } else {
            $notice = '<p class="message">' . esc_html__(
                'Your account email was restored. Please sign in with your username and password.',
                'yooadmin'
            ) . '</p>';
        }

        return $notice . $message;
    }
}

add_filter('login_message', 'yooadmin_email_recovery_login_message');

if (!function_exists('yooadmin_email_recovery_consume_login_grace_on_two_factor')) {
    function yooadmin_email_recovery_consume_login_grace_on_two_factor($user): void
    {
        if ($user instanceof WP_User && function_exists('yooadmin_email_recovery_consume_login_grace')) {
            yooadmin_email_recovery_consume_login_grace($user->user_login);
        }
    }
}
add_action('yooadmin_standalone_login_two_factor_complete_login', 'yooadmin_email_recovery_consume_login_grace_on_two_factor', 10, 1);
