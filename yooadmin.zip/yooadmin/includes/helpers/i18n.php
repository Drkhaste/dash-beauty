<?php
/**
 * YOOAdmin textdomain loading (locale fallbacks for ar / ar_SA / ar_EG, etc.)
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_get_textdomain_locale_candidates')) {
    /**
     * Locale candidates for yooadmin-{locale}.mo (exact, then language prefix).
     *
     * @return string[]
     */
    function yooadmin_get_textdomain_locale_candidates(string $locale): array {
        $locale = trim(str_replace('-', '_', $locale));
        if ($locale === '' || $locale === 'site-default') {
            return ['en_US'];
        }

        $candidates = [$locale];
        if (preg_match('/^([a-z]{2,3})_/i', $locale, $matches)) {
            $candidates[] = strtolower($matches[1]);
        }

        return array_values(array_unique($candidates));
    }
}

if (!function_exists('yooadmin_find_textdomain_mofile')) {
    /**
     * Locate the first readable yooadmin .mo for a locale.
     */
    function yooadmin_find_textdomain_mofile(string $locale): string {
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
        if ($base_file === '') {
            return '';
        }

        $rel = dirname(plugin_basename($base_file));
        foreach (yooadmin_get_textdomain_locale_candidates($locale) as $candidate) {
            $paths = [];
            if (defined('WP_PLUGIN_DIR')) {
                $paths[] = WP_PLUGIN_DIR . '/' . $rel . '/languages/yooadmin-' . $candidate . '.mo';
            }
            if (defined('WP_LANG_DIR')) {
                $paths[] = WP_LANG_DIR . '/plugins/yooadmin-' . $candidate . '.mo';
            }

            foreach ($paths as $path) {
                if (is_readable($path)) {
                    return $path;
                }
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_admin_locale_uses_english_ui')) {
    /**
     * Whether the locale is treated as the plugin's source language (no translate CTA).
     */
    function yooadmin_admin_locale_uses_english_ui(string $locale): bool {
        $locale = trim(str_replace('-', '_', $locale));
        if ($locale === '' || $locale === 'en_US') {
            return true;
        }

        return strpos($locale, 'en_') === 0;
    }
}

if (!function_exists('yooadmin_admin_locale_has_yooadmin_translation')) {
    /**
     * Whether a readable yooadmin language pack exists for the locale.
     */
    function yooadmin_admin_locale_has_yooadmin_translation(string $locale): bool {
        if (yooadmin_admin_locale_uses_english_ui($locale)) {
            return true;
        }

        return function_exists('yooadmin_find_textdomain_mofile')
            && yooadmin_find_textdomain_mofile($locale) !== '';
    }
}

if (!function_exists('yooadmin_get_admin_locale_display_name')) {
    /**
     * Human-readable language name for notifications (native name when available).
     */
    function yooadmin_get_admin_locale_display_name(string $locale): string {
        $locale = yooadmin_sanitize_locale_name(str_replace('-', '_', $locale));
        if ($locale === '') {
            return $locale;
        }

        if (!function_exists('wp_get_available_translations')) {
            require_once ABSPATH . 'wp-admin/includes/translation-install.php';
        }

        $translations = wp_get_available_translations();
        if (isset($translations[ $locale ]['native_name'])) {
            return (string) $translations[ $locale ]['native_name'];
        }

        if (function_exists('locale_get_display_name')) {
            $name = locale_get_display_name($locale, $locale);
            if (is_string($name) && $name !== '') {
                return $name;
            }
        }

        return $locale;
    }
}

if (!function_exists('yooadmin_get_wordpress_translate_project_url')) {
    /**
     * GlotPress project URL for contributing YOOAdmin translations.
     */
    function yooadmin_get_wordpress_translate_project_url(string $locale): string {
        $locale = yooadmin_sanitize_locale_name(str_replace('-', '_', $locale));

        if ($locale === '' || yooadmin_admin_locale_uses_english_ui($locale)) {
            return 'https://translate.wordpress.org/projects/wp-plugins/yooadmin/';
        }

        return sprintf(
            'https://translate.wordpress.org/locale/%s/default/wp-plugins/yooadmin/',
            rawurlencode($locale)
        );
    }
}

if (!function_exists('yooadmin_should_show_translation_contribute_notification')) {
    /**
     * Whether to queue the translation-contribute notification for the current user.
     */
    function yooadmin_should_show_translation_contribute_notification(?int $user_id = null): bool {
        if (!is_admin() && !(defined('REST_REQUEST') && REST_REQUEST)) {
            return false;
        }

        if ($user_id === null) {
            $user_id = get_current_user_id();
        }

        if ($user_id <= 0) {
            return false;
        }

        if (!function_exists('yooadmin_get_admin_ui_locale')) {
            return false;
        }

        $locale = yooadmin_get_admin_ui_locale();
        if (yooadmin_admin_locale_uses_english_ui($locale)) {
            return false;
        }

        if (yooadmin_admin_locale_has_yooadmin_translation($locale)) {
            return false;
        }

        /**
         * Filter whether the translation-contribute notification is collected.
         *
         * @param bool   $show    Default true when locale has no yooadmin pack.
         * @param string $locale  Admin UI locale.
         * @param int    $user_id User ID.
         */
        return (bool) apply_filters('yooadmin_show_translation_contribute_notification', true, $locale, $user_id);
    }
}

if (!function_exists('yooadmin_load_yooadmin_textdomain')) {
    /**
     * Load the yooadmin textdomain for a locale (with language-prefix fallback).
     */
    function yooadmin_load_yooadmin_textdomain(?string $locale = null): void {
        if (!function_exists('load_textdomain') || !function_exists('unload_textdomain')) {
            return;
        }

        if ($locale === null) {
            if (function_exists('yooadmin_get_admin_ui_locale')) {
                $locale = yooadmin_get_admin_ui_locale();
            } elseif (did_action('after_setup_theme') && function_exists('determine_locale')) {
                $locale = determine_locale();
            } else {
                $locale = get_locale();
            }
        }

        $mofile = yooadmin_find_textdomain_mofile((string) $locale);
        if ($mofile === '') {
            return;
        }

        if (is_textdomain_loaded('yooadmin')) {
            unload_textdomain('yooadmin');
        }

        load_textdomain('yooadmin', $mofile);
    }
}

if (!function_exists('yooadmin_localize_notification_action_text')) {
    /**
     * Translate default English action labels stored in the DB.
     */
    function yooadmin_localize_notification_action_text($text): string
    {
        $value = is_string($text) ? trim($text) : '';
        if ($value === '' || strcasecmp($value, 'View') === 0 || strcasecmp($value, 'Open link') === 0) {
            return __('View', 'yooadmin');
        }
        return is_string($text) ? $text : '';
    }
}

if (!function_exists('yooadmin_translate_notification_action_fields')) {
    /**
     * @param array<string, mixed> $notification
     * @return array<string, mixed>
     */
    function yooadmin_translate_notification_action_fields(array $notification): array
    {
        if (!empty($notification['action_text']) && is_string($notification['action_text'])) {
            $notification['action_text'] = yooadmin_localize_notification_action_text($notification['action_text']);
        }

        if (!isset($notification['meta'])) {
            return $notification;
        }

        $meta = $notification['meta'];
        if (is_string($meta) && $meta !== '') {
            $decoded = json_decode($meta, true);
            $meta = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($meta)) {
            return $notification;
        }

        if (!empty($meta['action_text']) && is_string($meta['action_text'])) {
            $meta['action_text'] = yooadmin_localize_notification_action_text($meta['action_text']);
        }

        if (!empty($meta['actions']) && is_array($meta['actions'])) {
            foreach ($meta['actions'] as $index => $action) {
                if (is_array($action) && isset($action['text'])) {
                    $meta['actions'][ $index ]['text'] = yooadmin_localize_notification_action_text($action['text']);
                }
            }
        }

        if (!empty($meta['urls']) && is_array($meta['urls'])) {
            foreach ($meta['urls'] as $index => $url_item) {
                if (is_array($url_item) && isset($url_item['text'])) {
                    $meta['urls'][ $index ]['text'] = yooadmin_localize_notification_action_text($url_item['text']);
                }
            }
        }

        $notification['meta'] = $meta;
        return $notification;
    }
}

if (!function_exists('yooadmin_translate_notification_for_display')) {
    /**
     * Localize known plugin notification copy at render time (DB may store English).
     *
     * @param array<string, mixed> $notification
     * @return array<string, mixed>
     */
    function yooadmin_translate_notification_for_display(array $notification): array {
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $meta = isset($notification['meta']) && is_array($notification['meta']) ? $notification['meta'] : [];
        $meta_id = isset($meta['id']) ? (string) $meta['id'] : '';
        $source_type = isset($notification['source_type']) ? (string) $notification['source_type'] : '';

        $catalog_by_meta = [
            'yooadmin_user_welcome' => [
                'title'   => __('Welcome to YOOAdmin!', 'yooadmin'),
                'message' => __('Thanks for joining! Explore our features and settings.', 'yooadmin'),
            ],
            'yooadmin_translation_contribute' => [
                'title'   => __('Help translate YOOAdmin', 'yooadmin'),
                'message' => '', // Filled below with locale from meta.
            ],
        ];

        if ($meta_id !== '' && isset($catalog_by_meta[ $meta_id ])) {
            $notification['title'] = $catalog_by_meta[ $meta_id ]['title'];
            if ($meta_id === 'yooadmin_translation_contribute') {
                $contrib_locale = isset($meta['locale']) ? (string) $meta['locale'] : '';
                $language_name  = $contrib_locale !== '' && function_exists('yooadmin_get_admin_locale_display_name')
                    ? yooadmin_get_admin_locale_display_name($contrib_locale)
                    : $contrib_locale;
                $notification['message'] = sprintf(
                    /* translators: %s: language name. */
                    __('Your admin language (%s) does not have a YOOAdmin translation yet. You can contribute on WordPress.org and help bring YOOAdmin to more users.', 'yooadmin'),
                    $language_name
                );
            } else {
                $notification['message'] = $catalog_by_meta[ $meta_id ]['message'];
            }
            return yooadmin_translate_notification_action_fields($notification);
        }

        if ($source_type === 'translation' && $meta_id === 'yooadmin_translation_contribute') {
            $contrib_locale = isset($meta['locale']) ? (string) $meta['locale'] : '';
            $language_name  = $contrib_locale !== '' && function_exists('yooadmin_get_admin_locale_display_name')
                ? yooadmin_get_admin_locale_display_name($contrib_locale)
                : $contrib_locale;
            $notification['title']   = __('Help translate YOOAdmin', 'yooadmin');
            $notification['message'] = sprintf(
                /* translators: %s: language name. */
                __('Your admin language (%s) does not have a YOOAdmin translation yet. You can contribute on WordPress.org and help bring YOOAdmin to more users.', 'yooadmin'),
                $language_name
            );
            return yooadmin_translate_notification_action_fields($notification);
        }

        if ($source_type === 'user_welcome') {
            $notification['title']   = __('Welcome to YOOAdmin!', 'yooadmin');
            $notification['message'] = __('Thanks for joining! Explore our features and settings.', 'yooadmin');
            return yooadmin_translate_notification_action_fields($notification);
        }

        // Legacy rows saved before __() wrappers (match English source strings).
        $title = isset($notification['title']) ? (string) $notification['title'] : '';
        if ($title === 'Welcome to YOOAdmin!') {
            $notification['title']   = __('Welcome to YOOAdmin!', 'yooadmin');
            $notification['message'] = __('Thanks for joining! Explore our features and settings.', 'yooadmin');
        }

        return yooadmin_translate_notification_action_fields($notification);
    }
}

if (!function_exists('yooadmin_translate_notifications_for_display')) {
    /**
     * @param array<int, array<string, mixed>> $notifications
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_translate_notifications_for_display(array $notifications): array {
        foreach ($notifications as $index => $notification) {
            if (!is_array($notification)) {
                continue;
            }

            if (($notification['type'] ?? '') === 'group' && !empty($notification['items']) && is_array($notification['items'])) {
                $notification['items'] = yooadmin_translate_notifications_for_display($notification['items']);
                $notifications[ $index ] = $notification;
                continue;
            }

            $notifications[ $index ] = yooadmin_translate_notification_for_display($notification);
        }

        return $notifications;
    }
}

if (!function_exists('yooadmin_get_modern_color_picker_i18n')) {
    /**
     * Strings for the modern color picker popover (theme settings + setup wizard).
     *
     * @return array<string, string>
     */
    function yooadmin_get_modern_color_picker_i18n(): array
    {
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        return [
            'chooseColor'                => __('Choose color', 'yooadmin'),
            'palette'                    => __('Palette', 'yooadmin'),
            'hex'                        => __('HEX', 'yooadmin'),
            'reset'                      => __('Reset', 'yooadmin'),
            'customColor'                => __('Custom color', 'yooadmin'),
            'customSaturationBrightness' => __('Custom color saturation and brightness', 'yooadmin'),
            'colorHue'                   => __('Color hue', 'yooadmin'),
            'hexColor'                   => __('Hex color', 'yooadmin'),
        ];
    }
}
