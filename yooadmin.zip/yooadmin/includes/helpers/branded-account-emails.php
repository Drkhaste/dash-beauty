<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

yooadmin_require_if_exists(__DIR__ . '/branded-email-template.php');

if (!function_exists('yooadmin_branded_email_send_card')) {
    /**
     * @param array<string, mixed> $card_args Passed to yooadmin_branded_email_render_card().
     */
    function yooadmin_branded_email_send_card(string $to, string $subject, array $card_args, int $user_id = 0): bool
    {
        if ($to === '' || !is_email($to)) {
            return false;
        }

        if ($user_id > 0 && function_exists('yooadmin_load_yooadmin_textdomain')) {
            $locale = function_exists('get_user_locale') ? get_user_locale($user_id) : null;
            yooadmin_load_yooadmin_textdomain($locale);
        }

        $body = '';
        if (function_exists('yooadmin_branded_email_render_card')) {
            $body = yooadmin_branded_email_render_card($card_args);
        }

        if ($body === '') {
            $headline = (string) ($card_args['headline'] ?? '');
            $cta_url  = (string) ($card_args['cta_url'] ?? '');
            $body     = $headline;
            if ($cta_url !== '') {
                $body .= "\n\n" . $cta_url;
            }
        }

        $headers = ['Content-Type: text/html; charset=UTF-8'];

        return (bool) wp_mail($to, $subject, $body, $headers);
    }
}

if (!function_exists('yooadmin_branded_email_password_reset_url')) {
    function yooadmin_branded_email_password_reset_url(string $user_login, string $key, WP_User $user): string
    {
        $url = function_exists('yooadmin_login_password_reset_url')
            ? yooadmin_login_password_reset_url($user_login, $key, $user)
            : network_site_url(
                'wp-login.php?login=' . rawurlencode($user_login) . '&key=' . rawurlencode($key) . '&action=rp&wp_lang=' . rawurlencode(get_user_locale($user)),
                'login'
            );

        /** @var string $url */
        return (string) apply_filters('yooadmin_branded_email_password_reset_url', $url, $user_login, $key, $user);
    }
}

if (!function_exists('yooadmin_branded_email_send_profile_change_request')) {
    function yooadmin_branded_email_send_profile_change_request(WP_User $user, string $new_email, string $confirm_url): bool
    {
        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $subject   = sprintf(
            /* translators: %s: site name */
            __('[%s] Email change request', 'yooadmin'),
            $site_name
        );

        $card_args = [
            'headline'      => __('Confirm your new email address', 'yooadmin'),
            'intro'         => sprintf(
                /* translators: %s: username */
                __('Hi %s, you requested to change the email address on your account. Click the button below to confirm this change.', 'yooadmin'),
                $user->user_login
            ),
            'badge_label'   => __('Account', 'yooadmin'),
            'badge_tone'    => 'warning',
            'details_title' => __('Change details', 'yooadmin'),
            'rows'          => [
                [
                    'label' => __('Account', 'yooadmin'),
                    'value' => $user->user_login,
                ],
                [
                    'label' => __('New email', 'yooadmin'),
                    'value' => $new_email,
                ],
                [
                    'label' => __('Site', 'yooadmin'),
                    'value' => $site_name,
                ],
            ],
            'cta_label'     => __('Confirm email change', 'yooadmin'),
            'cta_url'       => $confirm_url,
            'footer_note'   => sprintf(
                /* translators: %s: site name */
                __('If you did not request this change, you can safely ignore this email. Sent by %s security.', 'yooadmin'),
                $site_name
            ),
        ];

        /** @var array<string, mixed> $card_args */
        $card_args = apply_filters('yooadmin_profile_new_email_card_args', $card_args, $user, $new_email, $confirm_url);

        return yooadmin_branded_email_send_card($new_email, $subject, $card_args, (int) $user->ID);
    }
}

if (!function_exists('yooadmin_branded_email_profile_changed_card_args')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_branded_email_profile_changed_card_args(string $username, string $old_email, string $new_email, int $user_id = 0): array
    {
        $site_name   = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $admin_email = (string) get_option('admin_email');

        $rows = [
            [
                'label' => __('Account', 'yooadmin'),
                'value' => $username,
            ],
            [
                'label' => __('Previous email', 'yooadmin'),
                'value' => $old_email,
            ],
            [
                'label' => __('New email', 'yooadmin'),
                'value' => $new_email,
            ],
            [
                'label' => __('Changed at', 'yooadmin'),
                'value' => wp_date(get_option('date_format') . ' ' . get_option('time_format')),
            ],
        ];

        if ($admin_email !== '' && is_email($admin_email)) {
            $rows[] = [
                'label' => __('Site administrator', 'yooadmin'),
                'value' => $admin_email,
                'url'   => 'mailto:' . $admin_email,
            ];
        }

        $card_args = [
            'headline'      => __('Your account email was changed', 'yooadmin'),
            'intro'         => sprintf(
                /* translators: %s: username */
                __('Hi %s, the email address on your account was updated. If you made this change, no further action is needed.', 'yooadmin'),
                $username
            ),
            'badge_label'   => __('Security alert', 'yooadmin'),
            'badge_tone'    => 'warning',
            'details_title' => __('Change details', 'yooadmin'),
            'rows'          => $rows,
            'footer_note'   => sprintf(
                /* translators: %s: site name */
                __('If you did not authorize this change, contact your site administrator immediately. Sent by %s security.', 'yooadmin'),
                $site_name
            ),
        ];

        $user_obj = $user_id > 0 ? get_user_by('id', $user_id) : false;

        /** @var array<string, mixed> $card_args */
        return apply_filters(
            'yooadmin_profile_email_changed_card_args',
            $card_args,
            $user_obj instanceof WP_User ? $user_obj : null,
            $old_email,
            $new_email
        );
    }
}

if (!function_exists('yooadmin_branded_email_filter_email_change')) {
    /**
     * @param array<string, string> $email_change_email
     * @param array<string, mixed>  $user
     * @param array<string, mixed>  $userdata
     * @return array<string, string>
     */
    function yooadmin_branded_email_filter_email_change($email_change_email, $user, $userdata): array
    {
        if (!function_exists('yooadmin_branded_email_render_card')) {
            return $email_change_email;
        }

        $user_id   = (int) ($user['ID'] ?? 0);
        $username  = (string) ($user['user_login'] ?? '');
        $old_email = (string) ($user['user_email'] ?? '');
        $new_email = (string) ($userdata['user_email'] ?? $old_email);

        if ($old_email === '' || $new_email === '' || strcasecmp($old_email, $new_email) === 0) {
            return $email_change_email;
        }

        if ($user_id > 0 && function_exists('yooadmin_load_yooadmin_textdomain')) {
            yooadmin_load_yooadmin_textdomain(get_user_locale($user_id));
        }

        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $card_args = yooadmin_branded_email_profile_changed_card_args($username, $old_email, $new_email, $user_id);

        if (
            !(function_exists('yooadmin_email_recovery_is_reverting') && yooadmin_email_recovery_is_reverting())
            && function_exists('yooadmin_email_recovery_is_enabled')
            && yooadmin_email_recovery_is_enabled()
            && function_exists('yooadmin_email_recovery_issue_for_change')
            && function_exists('yooadmin_email_recovery_url')
        ) {
            $plain_key = yooadmin_email_recovery_issue_for_change($user_id, $old_email, $new_email);
            if ($plain_key !== '') {
                $recovery_url = yooadmin_email_recovery_url($plain_key, $username);
                $ttl_hours    = (int) max(1, (int) ceil(
                    (function_exists('yooadmin_email_recovery_expiration')
                        ? yooadmin_email_recovery_expiration()
                        : (2 * DAY_IN_SECONDS)) / HOUR_IN_SECONDS
                ));

                $card_args['intro'] = sprintf(
                    /* translators: %s: username */
                    __('Hi %s, the email address on your account was updated. If you did not authorize this change, use the button below to restore your previous email and sign out all sessions.', 'yooadmin'),
                    $username
                );
                $card_args['cta_label'] = __('Recover my account', 'yooadmin');
                $card_args['cta_url']   = $recovery_url;
                $card_args['footer_note'] = sprintf(
                    /* translators: 1: site name, 2: number of hours */
                    _n(
                        'This recovery link expires in %2$d hour. Sent by %1$s security.',
                        'This recovery link expires in %2$d hours. Sent by %1$s security.',
                        $ttl_hours,
                        'yooadmin'
                    ),
                    $site_name,
                    $ttl_hours
                );
            }
        }

        $body = yooadmin_branded_email_render_card($card_args);

        if ($body === '') {
            return $email_change_email;
        }

        $email_change_email['subject'] = sprintf(
            /* translators: %s: site name */
            __('[%s] Your account email was changed', 'yooadmin'),
            $site_name
        );
        $email_change_email['message'] = $body;
        $email_change_email['headers'] = 'Content-Type: text/html; charset=UTF-8';

        return $email_change_email;
    }
}

add_filter('email_change_email', 'yooadmin_branded_email_filter_email_change', 10, 3);

if (!function_exists('yooadmin_branded_email_filter_password_reset')) {
    /**
     * @param array<string, string> $defaults
     * @return array<string, string>
     */
    function yooadmin_branded_email_filter_password_reset($defaults, $key, $user_login, $user_data): array
    {
        if (!function_exists('yooadmin_branded_email_render_card') || !$user_data instanceof WP_User) {
            return $defaults;
        }

        if (function_exists('yooadmin_load_yooadmin_textdomain')) {
            yooadmin_load_yooadmin_textdomain(get_user_locale($user_data));
        }

        $site_name  = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $reset_url  = yooadmin_branded_email_password_reset_url($user_login, (string) $key, $user_data);
        if (function_exists('yooadmin_branded_email_wrap_action_url')) {
            $reset_url = yooadmin_branded_email_wrap_action_url($reset_url);
        }
        $remote_ip  = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR'])) : '';

        $rows = [
            [
                'label' => __('Account', 'yooadmin'),
                'value' => $user_login,
            ],
            [
                'label' => __('Email', 'yooadmin'),
                'value' => $user_data->user_email,
            ],
        ];

        if ($remote_ip !== '' && !is_user_logged_in()) {
            $rows[] = [
                'label' => __('IP address', 'yooadmin'),
                'value' => $remote_ip,
            ];
        }

        $card_args = [
            'headline'      => __('Reset your password', 'yooadmin'),
            'intro'         => sprintf(
                /* translators: %s: username */
                __('Someone requested a password reset for the account %s. If this was you, use the button below to choose a new password.', 'yooadmin'),
                $user_login
            ),
            'badge_label'   => __('Account security', 'yooadmin'),
            'badge_tone'    => 'warning',
            'details_title' => __('Reset details', 'yooadmin'),
            'rows'          => $rows,
            'cta_label'     => __('Reset password', 'yooadmin'),
            'cta_url'       => $reset_url,
            'footer_note'   => sprintf(
                /* translators: %s: site name */
                __('If you did not request a reset, you can ignore this email. Sent by %s security.', 'yooadmin'),
                $site_name
            ),
        ];

        /** @var array<string, mixed> $card_args */
        $card_args = apply_filters('yooadmin_password_reset_email_card_args', $card_args, $user_data, $key, $user_login);

        $body = yooadmin_branded_email_render_card($card_args);
        if ($body === '') {
            return $defaults;
        }

        $subject = sprintf(
            /* translators: %s: site name */
            __('[%s] Password reset', 'yooadmin'),
            $site_name
        );

        $defaults['subject'] = $subject;
        $defaults['message'] = $body;
        $defaults['headers'] = 'Content-Type: text/html; charset=UTF-8';

        return $defaults;
    }
}

add_filter('retrieve_password_notification_email', 'yooadmin_branded_email_filter_password_reset', 10, 4);

if (!function_exists('yooadmin_branded_email_filter_new_user_notification')) {
    /**
     * Brand the “set your password” email sent when a new user account is created.
     *
     * @param array<string, string> $email
     * @return array<string, string>
     */
    function yooadmin_branded_email_filter_new_user_notification(array $email, WP_User $user, string $blogname): array
    {
        if (!function_exists('yooadmin_branded_email_render_card') || !$user instanceof WP_User) {
            return $email;
        }

        if (function_exists('yooadmin_load_yooadmin_textdomain')) {
            yooadmin_load_yooadmin_textdomain(get_user_locale($user));
        }

        $key = get_password_reset_key($user);
        if (is_wp_error($key)) {
            return $email;
        }

        $site_name = wp_specialchars_decode($blogname, ENT_QUOTES);
        $reset_url = yooadmin_branded_email_password_reset_url($user->user_login, (string) $key, $user);
        if (function_exists('yooadmin_branded_email_wrap_action_url')) {
            $reset_url = yooadmin_branded_email_wrap_action_url($reset_url);
        }

        $card_args = [
            'headline'      => __('Set your password', 'yooadmin'),
            'intro'         => sprintf(
                /* translators: 1: username, 2: site name */
                __('Hi %1$s, an account was created for you on %2$s. Use the button below to choose your password and sign in.', 'yooadmin'),
                $user->user_login,
                $site_name
            ),
            'badge_label'   => __('Welcome', 'yooadmin'),
            'badge_tone'    => 'success',
            'details_title' => __('Account details', 'yooadmin'),
            'rows'          => [
                [
                    'label' => __('Username', 'yooadmin'),
                    'value' => $user->user_login,
                ],
                [
                    'label' => __('Email', 'yooadmin'),
                    'value' => $user->user_email,
                ],
                [
                    'label' => __('Site', 'yooadmin'),
                    'value' => $site_name,
                ],
            ],
            'cta_label'     => __('Set your password', 'yooadmin'),
            'cta_url'       => $reset_url,
            'footer_note'   => sprintf(
                /* translators: %s: site name */
                __('If you did not expect this email, you can ignore it. Sent by %s.', 'yooadmin'),
                $site_name
            ),
        ];

        /** @var array<string, mixed> $card_args */
        $card_args = apply_filters('yooadmin_new_user_email_card_args', $card_args, $user, $blogname);

        $body = yooadmin_branded_email_render_card($card_args);
        if ($body === '') {
            return $email;
        }

        $email['subject'] = sprintf(
            /* translators: %s: site name */
            __('[%s] Set your password', 'yooadmin'),
            $site_name
        );
        $email['message'] = $body;
        $email['headers']  = 'Content-Type: text/html; charset=UTF-8';

        return $email;
    }
}

add_filter('wp_new_user_notification_email', 'yooadmin_branded_email_filter_new_user_notification', 10, 3);

if (!function_exists('yooadmin_branded_email_send_recovery_success_notice')) {
    function yooadmin_branded_email_send_recovery_success_notice(WP_User $user, string $restored_email): bool
    {
        if ($restored_email === '' || !is_email($restored_email)) {
            return false;
        }

        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $subject   = sprintf(
            /* translators: %s: site name */
            __('[%s] Your account email was restored', 'yooadmin'),
            $site_name
        );

        $card_args = [
            'headline'      => __('Your account email was restored', 'yooadmin'),
            'intro'         => sprintf(
                /* translators: %s: username */
                __('Hi %s, your previous email address was restored and all other sessions were signed out. If you did not perform this action, reset your password immediately.', 'yooadmin'),
                $user->user_login
            ),
            'badge_label'   => __('Account recovered', 'yooadmin'),
            'badge_tone'    => 'success',
            'details_title' => __('Recovery details', 'yooadmin'),
            'rows'          => [
                [
                    'label' => __('Account', 'yooadmin'),
                    'value' => $user->user_login,
                ],
                [
                    'label' => __('Restored email', 'yooadmin'),
                    'value' => $restored_email,
                ],
                [
                    'label' => __('Recovered at', 'yooadmin'),
                    'value' => wp_date(get_option('date_format') . ' ' . get_option('time_format')),
                ],
            ],
            'footer_note'   => sprintf(
                /* translators: %s: site name */
                __('Sent by %s security.', 'yooadmin'),
                $site_name
            ),
        ];

        /** @var array<string, mixed> $card_args */
        $card_args = apply_filters('yooadmin_email_recovery_success_card_args', $card_args, $user, $restored_email);

        return yooadmin_branded_email_send_card($restored_email, $subject, $card_args, (int) $user->ID);
    }
}
