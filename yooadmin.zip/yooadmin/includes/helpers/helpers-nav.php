<?php
/**
 * YOOAdmin - Navigation/UI helpers
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

if (!function_exists('yooadmin_cache_toolbar_nodes')) {
    /**
     * Cache admin-bar nodes once all menu items have been registered so our template
     * can reuse them later without relying on timing.
     */
    function yooadmin_cache_toolbar_nodes($wp_admin_bar): void
    {
        if (!is_object($wp_admin_bar) || !method_exists($wp_admin_bar, 'get_nodes')) {
            return;
        }
        $nodes = $wp_admin_bar->get_nodes();
        if (is_array($nodes) && $nodes) {
            $GLOBALS['yooadmin_toolbar_nodes'] = $nodes;
        }
    }
    add_action('admin_bar_menu', 'yooadmin_cache_toolbar_nodes', PHP_INT_MAX);
}

if (!function_exists('yooadmin_maybe_inject_dashboard_notes_toolbar_shortcut')) {
    /**
     * WP Dashboard Notes only registers its admin-bar node on core dashboard.php.
     * Mirror it in YOOAdmin breadcrumbs on every admin screen when the plugin is active.
     *
     * @param array<int, array<string, mixed>> $shortcuts
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_maybe_inject_dashboard_notes_toolbar_shortcut(array $shortcuts): array
    {
        if (!is_admin() || !is_user_logged_in()) {
            return $shortcuts;
        }

        if (!class_exists('WP_Dashboard_Notes', false) && empty($GLOBALS['wp_dashboard_notes'])) {
            return $shortcuts;
        }

        foreach ($shortcuts as $shortcut) {
            if (is_array($shortcut) && ($shortcut['id'] ?? '') === 'wpdn-add-note') {
                return $shortcuts;
            }
        }

        $shortcuts[] = [
            'id'          => 'wpdn-add-note',
            'label'       => _x('Note', 'short toolbar label: add dashboard note', 'yooadmin'),
            'href'        => '#',
            'tooltip'     => __('Add a new note', 'yooadmin'),
            'icon_class'  => 'dashicons dashicons-welcome-write-blog',
            'icon_markup' => '',
            'badge'       => '',
            'target'      => '',
            'onclick'     => 'void(0)',
            'children'    => [],
            'position'    => 95,
        ];

        return $shortcuts;
    }

    add_filter('yooadmin_toolbar_shortcuts', 'yooadmin_maybe_inject_dashboard_notes_toolbar_shortcut', 15);
}

defined('ABSPATH') || exit;

/**
 * - All functions are guard-wrapped with function_exists to avoid redeclaration.
 * - Hooks/filters included for customization:
 *      - filter: yooadmin_dashboard_slug (string)
 *      - filter: yooadmin_logo_rel      (string) relative path under assets/
 *      - filter: yooadmin_menu_exclude  (array)  list of top slugs to hide in SSR fallback
 */

/* ------------------------------------------------------------------------
 * Basic helpers (idempotent, guarded)
 * --------------------------------------------------------------------- */

/** Dashboard URL (single source of truth; slug filterable) */
if (!function_exists('yooadmin_dashboard_url')) {
    function yooadmin_dashboard_url(): string
    {
        $slug = apply_filters('yooadmin_dashboard_slug', 'yooadmin-dashboard');
        $slug = is_string($slug) && $slug !== '' ? $slug : 'yooadmin-dashboard';
        return admin_url('admin.php?page=' . $slug);
    }
}

/** Brand logo URL (safe fallback to bundled image; path filterable) */
if (!function_exists('yooadmin_logo_url')) {
    function yooadmin_logo_url(): string
    {
        // Resolve plugin base file (robust for symlinks)
        $base_file = defined('YOOADMIN_PLUGIN_FILE')
            ? YOOADMIN_PLUGIN_FILE
            : dirname(__DIR__, 2) . '/yooadmin.php';

        $dir = plugin_dir_path($base_file);
        $url = plugin_dir_url($base_file);

        // Default relative asset; allow override via filter
        // Uses custom logo.png in assets/images
        $rel = apply_filters('yooadmin_logo_rel', 'assets/images/logo.png');
        $rel = is_string($rel) && $rel !== '' ? $rel : 'assets/images/logo.png';

        $path = $dir . $rel;
        if (file_exists($path)) {
            return esc_url($url . ltrim($rel, '/'));
        }
        return '';
    }
}

/** Current user meta (display + avatar) */
if (!function_exists('yooadmin_current_user_meta')) {
    function yooadmin_current_user_meta(): array
    {
        $name = '';
        if (function_exists('wp_get_current_user')) {
            $u = wp_get_current_user();
            if ($u && is_object($u)) {
                $name = (string)($u->display_name ?: $u->user_login);
            }
        }
        $user_id = (int) get_current_user_id();
        $avatar_args = ['size' => 72];

        return [
            'display' => esc_html($name ?: __('User', 'yooadmin')),
            'avatar' => esc_url(get_avatar_url($user_id, $avatar_args)),
            'avatar_is_placeholder' => function_exists('yooadmin_user_avatar_is_placeholder')
                ? yooadmin_user_avatar_is_placeholder($user_id, $avatar_args)
                : false,
        ];
    }
}

/** Focus mode effective state (delegates to central policy if available) */
if (!function_exists('yooadmin_focus_mode_enabled')) {
    function yooadmin_focus_mode_enabled(): bool
    {
        // Prefer a central resolver (keeps policy in one place)
        if (function_exists('yooadmin_should_inject_shell')) {
            // If shell injection allowed, consider focus = ON
            return (bool)yooadmin_should_inject_shell();
        }
        // Legacy cookie fallback (compatible with older builds)
        if (isset($_COOKIE['yoo_focus'])) {
            $pref = sanitize_text_field(wp_unslash($_COOKIE['yoo_focus']));
            return ($pref !== 'off');
        }
        // Default to enabled
        return true;
    }
}

/* ------------------------------------------------------------------------
 * Breadcrumbs (server-rendered fallback)
 * - Minimal logic, keeps Woo SPA simple.
 * --------------------------------------------------------------------- */

/** Build a lightweight WP breadcrumb trail */
if (!function_exists('yooadmin_build_wp_trail')) {
    function yooadmin_build_wp_trail(): array
    {
        global $menu, $submenu;

        $trail = [];
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only breadcrumb
        $page_param = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        $script = isset($_SERVER['PHP_SELF']) ? basename(wp_parse_url(sanitize_text_field(wp_unslash($_SERVER['PHP_SELF'])), PHP_URL_PATH) ?: '') : '';

        // YOOAdmin Users pages (hidden from menu but need breadcrumbs)
        if (in_array($page_param, ['yooadmin-users', 'yooadmin-users-new', 'yooadmin-user'], true)) {
            $trail[] = [
                'label' => __('Users', 'yooadmin'),
                'url' => admin_url('admin.php?page=yooadmin-users'),
            ];

            if ($page_param === 'yooadmin-users-new') {
                $trail[] = [
                    'label' => __('Add New User', 'yooadmin'),
                    'url' => admin_url('admin.php?page=yooadmin-users-new'),
                ];
            }
            elseif ($page_param === 'yooadmin-user') {
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only breadcrumb display, no state change.
                $user_id = isset($_GET['user_id']) ? absint($_GET['user_id']) : get_current_user_id();
                if ($user_id <= 0) {
                    $user_id = get_current_user_id();
                }
                $user = get_userdata($user_id);
                $is_own_profile = $user && (int) $user->ID === (int) get_current_user_id();

                if (!$is_own_profile && current_user_can('list_users')) {
                    $label = $user ? $user->display_name : __('User Profile', 'yooadmin');
                    $trail[] = [
                        'label' => $label,
                        'url' => '',
                    ];
                } else {
                    array_pop($trail);
                    $trail[] = [
                        'label' => __('My Profile', 'yooadmin'),
                        'url' => '',
                    ];
                }
            }

            return $trail;
        }

        // YOOAdmin Posts pages (hidden from menu but need breadcrumbs)
        if ($page_param === 'yooadmin-posts') {
            $trail[] = [
                'label' => __('Posts', 'yooadmin'),
                'url' => admin_url('admin.php?page=yooadmin-posts'),
            ];
            return $trail;
        }

        if ($page_param === 'yooadmin-comments') {
            $trail[] = [
                'label' => __('Comments', 'yooadmin'),
                'url' => admin_url('admin.php?page=yooadmin-comments'),
            ];
            return $trail;
        }

        // YOOAdmin Pages pages (hidden from menu but need breadcrumbs)
        if ($page_param === 'yooadmin-pages') {
            $trail[] = [
                'label' => __('Pages', 'yooadmin'),
                'url' => admin_url('admin.php?page=yooadmin-pages'),
            ];
            return $trail;
        }

        // YOOAdmin Categories pages (hidden from menu but need breadcrumbs)
        if ($page_param === 'yooadmin-categories') {
            $trail[] = [
                'label' => __('Categories', 'yooadmin'),
                'url' => admin_url('admin.php?page=yooadmin-categories'),
            ];
            return $trail;
        }

        $hidden_trail = apply_filters('yooadmin_hidden_page_breadcrumb_trail', null, $page_param);
        if (is_array($hidden_trail)) {
            return $hidden_trail;
        }

        if (is_multisite() && is_network_admin()) {
            $network_td = function_exists('yooadmin_multisite_text_domain')
                ? yooadmin_multisite_text_domain()
                : 'yooadmin';

            $network_sites_slug = function_exists('yooadmin_network_sites_page_slug')
                ? yooadmin_network_sites_page_slug()
                : 'yooadmin-network-sites';

            if ($page_param === $network_sites_slug) {
                $trail[] = [
                    'label' => __('Sites', 'yooadmin'),
                    'url'   => '',
                ];
                return $trail;
            }

            $editor_slugs = function_exists('yooadmin_network_site_editor_page_slugs')
                ? array_values(yooadmin_network_site_editor_page_slugs())
                : [];

            if ($editor_slugs && in_array($page_param, $editor_slugs, true)) {
                return function_exists('yooadmin_network_site_editor_build_breadcrumb_trail')
                    ? yooadmin_network_site_editor_build_breadcrumb_trail()
                    : $trail;
            }
        }

        // WooCommerce SPA: show (WooCommerce / First Section)
        if ($page_param === 'wc-admin') {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only breadcrumb display, no state change.
            $path = isset($_GET['path']) ? sanitize_text_field((string)wp_unslash($_GET['path'])) : '';
            $label = 'WooCommerce';
            $trail[] = [
                'label' => $label,
                'url' => admin_url('admin.php?page=wc-admin'),
            ];
            if ($path) {
                $first = strtok(trim($path, "/ \t\n\r\0\x0B"), '/');
                if ($first) {
                    $trail[] = [
                        'label' => ucwords(str_replace(['-', '_'], ' ', $first)),
                        'url' => admin_url('admin.php?page=wc-admin&path=/' . $first),
                    ];
                }
            }
            return $trail;
        }

        // Post types (edit.php / post-new.php / post.php)
        if (function_exists('get_current_screen')) {
            $screen = get_current_screen();
            if ($screen && in_array($screen->base, ['post', 'post-new', 'edit'], true)) {
                $pt = $screen->post_type ?: 'post';
                $obj = get_post_type_object($pt);
                if ($obj) {
                    $trail[] = [
                        'label' => esc_html($obj->labels->menu_name ?? $obj->labels->name ?? ucfirst($pt)),
                        'url' => admin_url('edit.php' . ($pt !== 'post' ? ('?post_type=' . $pt) : '')),
                    ];
                    if ($screen->base === 'post-new') {
                        $trail[] = [
                            'label' => esc_html($obj->labels->add_new ?? __('Add New', 'yooadmin')),
                            'url' => admin_url('post-new.php' . ($pt !== 'post' ? ('?post_type=' . $pt) : '')),
                        ];
                    }
                    elseif ($screen->base === 'post') {
                        $trail[] = [
                            'label' => esc_html($obj->labels->edit_item ?? __('Edit', 'yooadmin')),
                            'url' => '',
                        ];
                    }
                    return $trail;
                }
            }
        }

        // Generic: fast match against $menu/$submenu
        if (!is_array($menu)) {
            return $trail;
        }

        $clean = static function (string $raw): string {
            // Strip badges like "<span class='update-plugins'><span>5</span></span>"
            $title = trim(wp_strip_all_tags($raw));
            $title = preg_replace('/\s*\d+\s*$/u', '', $title);
            $title = preg_replace('/\s*\d+\s+.*$/u', '', $title);
            $title = preg_replace('/\s+Comments\s+in\s+moderation.*$/iu', '', $title);
            return (string)$title;
        };

        $slug_base = static function (string $slug): string {
            if ($slug === '')
                return '';
            $p = strcspn($slug, '?&');
            return ($p < strlen($slug)) ? substr($slug, 0, $p) : $slug;
        };

        $resolve_url = static function (string $slug) use ($slug_base): string {
            if (function_exists('yooadmin_resolve_admin_menu_slug_to_url')) {
                return yooadmin_resolve_admin_menu_slug_to_url($slug, 'admin_url');
            }
            if ($slug === '') {
                return admin_url();
            }
            if (preg_match('#^https?://#i', $slug)) {
                return $slug;
            }
            if (strpos($slug, '/') !== false) {
                return admin_url('admin.php?page=' . $slug);
            }
            if (stripos($slug, 'admin.php') === 0 || strpos($slug, '.php') !== false) {
                return admin_url($slug);
            }
            if (strpos($slug, '=') !== false && strpos($slug, '.php') === false) {
                return admin_url('admin.php?page=' . $slug);
            }
            $b = $slug_base($slug);
            return admin_url('admin.php?page=' . $b);
        };

        $match_top = null;
        $match_sub = null;

        foreach ($menu as $m) {
            $top_title_raw = isset($m[0]) ? (string)$m[0] : '';
            $top_slug = isset($m[2]) ? (string)$m[2] : '';
            if ($top_title_raw === '' || $top_slug === '')
                continue;

            $top_title = $clean($top_title_raw);
            $top_url = $resolve_url($top_slug);
            $top_b = $slug_base($top_slug);

            if (isset($submenu[$top_slug]) && is_array($submenu[$top_slug])) {
                $first_submenu_url = $top_url;
                if (!empty($submenu[$top_slug][0][2])) {
                    $first_submenu_url = $resolve_url((string)$submenu[$top_slug][0][2]);
                }
                
                foreach ($submenu[$top_slug] as $row) {
                    $sub_title_raw = (string)($row[0] ?? '');
                    $sub_slug = (string)($row[2] ?? '');
                    if ($sub_title_raw === '' || $sub_slug === '')
                        continue;

                    $sub_title = $clean($sub_title_raw);
                    $sub_b = $slug_base($sub_slug);

                    $is_match = $page_param
                        ? ($page_param === $sub_slug || $page_param === $sub_b)
                        : ($script === $sub_slug || $script === $sub_b);

                    if ($is_match) {
                        $match_top = [
                            'label' => $top_title,
                            'url'   => $first_submenu_url,
                        ];
                        $match_sub = ['label' => $sub_title, 'url' => $resolve_url($sub_slug)];
                        break 2;
                    }
                }
            }

            // Top-level match
            $is_match_top = $page_param
                ? ($page_param === $top_slug || $page_param === $top_b)
                : ($script === $top_slug || $script === $top_b);

            if ($is_match_top) {
                $match_top = [
                    'label' => $top_title,
                    'url'   => $top_url,
                ];
                break;
            }
        }

        if ($match_top) {
            $trail[] = $match_top;
            if ($match_sub)
                $trail[] = $match_sub;
        }

        return $trail;
    }
}

/** Echo breadcrumbs under header (progressive enhancement) */
if (!function_exists('yooadmin_render_breadcrumbs')) {
    function yooadmin_render_breadcrumbs(?string $home_url = null): void
    {
        $home_url = $home_url ?: yooadmin_dashboard_url();

        $items = [];
        $items[] = ['label' => __('Home', 'yooadmin'), 'url' => esc_url($home_url)];

        $wp_trail = yooadmin_build_wp_trail();
        foreach ($wp_trail as $p) {
            $lbl = (string)($p['label'] ?? '');
            if ($lbl === '')
                continue;
            $items[] = [
                'label' => $lbl,
                'url'   => (string)($p['url'] ?? ''),
            ];
        }

        if (!$items)
            return;

        echo '<nav class="yp-breadcrumbs" aria-label="' . esc_attr__('Breadcrumb', 'yooadmin') . '"><ol>';
        $last = count($items) - 1;
        foreach ($items as $i => $it) {
            $label = esc_html($it['label']);
            $url = esc_url($it['url']);
            $is_home = ($i === 0);
            $is_last = ($i === $last);

            echo '<li class="yp-bc-item' . ($is_home ? ' is-home' : '') . '">';
            if ($is_home) {
                echo '<span class="dashicons dashicons-admin-home yp-bc-home-icon" aria-hidden="true"></span>';
            }
            if (!$is_last && $url) {
                echo '<a class="yp-bc-link" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
            }
            else {
                echo '<span class="yp-bc-current" aria-current="page">' . esc_html($label) . '</span>';
            }
            echo '</li>';
        }
        echo '</ol></nav>';
    }
}

/* ------------------------------------------------------------------------
 * Sidebar menu (server-rendered fallback)
 * - Minimal clone of #adminmenu for non-JS environments.
 * - JS (yooadmin-menus.js) may overwrite/enhance this at runtime.
 * --------------------------------------------------------------------- */

/** Echo a vertical WP admin menu (safe SSR fallback) */
if (!function_exists('yooadmin_render_sidebar_menu')) {
    function yooadmin_render_sidebar_menu(): void
    {
        if (!is_user_logged_in())
            return;
        global $menu, $submenu;

        if (!is_array($menu))
            return;

        // Allow integrators to hide certain top-level slugs from SSR fallback
        $exclude = apply_filters('yooadmin_menu_exclude', []);
        $exclude = is_array($exclude) ? array_map('strval', $exclude) : [];

        echo '<ul class="yps-nav">';

        $i = 0;
        foreach ($menu as $m) {
            $raw_title = isset($m[0]) ? (string)$m[0] : '';
            $cap = isset($m[1]) ? (string)$m[1] : '';
            $slug = isset($m[2]) ? (string)$m[2] : '';
            $classes = isset($m[4]) ? (string)$m[4] : '';
            $icon = isset($m[6]) ? (string)$m[6] : (isset($m[5]) ? (string)$m[5] : '');

            if ($raw_title === '' || strpos($classes, 'wp-menu-separator') !== false)
                continue;
            if ($cap && !current_user_can($cap))
                continue;
            if ($slug && in_array($slug, $exclude, true))
                continue;

            // Clean title (strip badges)
            $title = trim(wp_strip_all_tags($raw_title));
            $title = preg_replace('/\s*\d+\s*$/u', '', $title);
            $title = preg_replace('/\s*\d+\s+.*$/u', '', $title);
            $title = preg_replace('/\s+Comments\s+in\s+moderation.*$/iu', '', $title);

            // Resolve URL
            if ($slug) {
                if (function_exists('yooadmin_admin_menu_url')) {
                    $url = yooadmin_admin_menu_url($slug);
                } elseif (preg_match('#^https?://#i', $slug)) {
                    $url = $slug;
                }
                elseif (stripos($slug, 'admin.php') === 0 || strpos($slug, '.php') !== false) {
                    $url = admin_url($slug);
                }
                else {
                    $url = admin_url('admin.php?page=' . $slug);
                }
            }
            else {
                $url = function_exists('yooadmin_admin_menu_url') ? yooadmin_admin_menu_url('') : admin_url();
            }

            $has_sub = isset($submenu[$slug]) && is_array($submenu[$slug]) && count($submenu[$slug]);
            $sub_id = 'yps-sub-' . (++$i);

            echo '<li class="yps-item' . ($has_sub ? ' has-sub' : '') . '">';

            // Row (icon + link + expander)
            echo '<div class="yps-row">';

            echo '<a class="yps-link" href="' . esc_url($url) . '" data-menu-slug="' . esc_attr($slug) . '">';

            // Icon (dashicons or leave a slot — JS may patch)
            if (is_string($icon) && strpos($icon, 'dashicons-') === 0) {
                echo '<span class="dashicons ' . esc_attr($icon) . '" aria-hidden="true"></span>';
            }
            else {
                echo '<span class="yps-icon-slot" data-slug="' . esc_attr($slug) . '"></span>';
            }

            echo '<span class="yps-text">' . esc_html($title) . '</span>';
            echo '</a>';

            if ($has_sub) {
                echo '<button class="yps-expander" type="button" aria-controls="' . esc_attr($sub_id) . '" aria-expanded="false">'
                    . '<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>'
                    . '</button>';
            }
            echo '</div>';

            // Submenu
            if ($has_sub) {
                echo '<ul id="' . esc_attr($sub_id) . '" class="yps-sub" hidden>';
                foreach ($submenu[$slug] as $sub) {
                    $sub_title_raw = isset($sub[0]) ? (string)$sub[0] : '';
                    $sub_cap = isset($sub[1]) ? (string)$sub[1] : '';
                    $sub_slug = isset($sub[2]) ? (string)$sub[2] : '';
                    if ($sub_title_raw === '')
                        continue;
                    if ($sub_cap && !current_user_can($sub_cap))
                        continue;

                    $sub_title = trim(wp_strip_all_tags($sub_title_raw));
                    $sub_title = preg_replace('/\s*\d+\s*$/u', '', $sub_title);

                    if ($sub_slug) {
                        if (function_exists('yooadmin_admin_menu_url')) {
                            $sub_url = yooadmin_admin_menu_url($sub_slug);
                        } elseif (preg_match('#^https?://#i', $sub_slug)) {
                            $sub_url = $sub_slug;
                        }
                        elseif (stripos($sub_slug, 'admin.php') === 0 || strpos($sub_slug, '.php') !== false) {
                            $sub_url = admin_url($sub_slug);
                        }
                        else {
                            $sub_url = admin_url('admin.php?page=' . $sub_slug);
                        }
                    }
                    else {
                        $sub_url = function_exists('yooadmin_admin_menu_url') ? yooadmin_admin_menu_url('') : admin_url();
                    }

                    echo '<li class="yps-sub-item"><a class="yps-sub-link" href="' . esc_url($sub_url) . '">'
                        . esc_html($sub_title) . '</a></li>';
                }
                echo '</ul>';
            }

            echo '</li>';
        }

        echo '</ul>';
    }
}

/* ------------------------------------------------------------------------
 * Admin toolbar icon markup (SVG/img; plugins like Yoast do not use dashicons)
 * --------------------------------------------------------------------- */

if (!function_exists('yooadmin_kses_toolbar_icon_markup')) {
    /**
     * Sanitize toolbar icon fragment (img or inline SVG).
     *
     * @param string $html Raw fragment.
     * @return string Safe HTML.
     */
    function yooadmin_kses_toolbar_icon_markup(string $html): string
    {
        $fill_attrs = ['fill' => true, 'class' => true, 'style' => true];
        $allowed = [
            'img' => [
                'src' => true, 'alt' => true, 'class' => true,
                'width' => true, 'height' => true,
                'loading' => true, 'decoding' => true, 'style' => true,
            ],
            // Some plugin icons (Yoast) render as empty placeholder elements
            // (e.g. <div id="yoast-ab-icon" class="yoast-logo svg">...</div>)
            // and are later painted via admin-bar CSS/JS.
            'div' => ['id' => true, 'class' => true, 'style' => true, 'aria-hidden' => true],
            'span' => ['class' => true, 'style' => true, 'aria-hidden' => true],
            'svg' => [
                'xmlns' => true, 'width' => true, 'height' => true,
                'viewbox' => true, 'viewBox' => true,
                'preserveaspectratio' => true, 'preserveAspectRatio' => true,
                'class' => true, 'fill' => true, 'style' => true,
                'aria-hidden' => true, 'role' => true, 'focusable' => true,
                'xml:space' => true, 'xmlns:xlink' => true,
            ],
            'path' => array_merge($fill_attrs, [
                'd' => true, 'fill-rule' => true, 'clip-rule' => true,
                'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true,
            ]),
            'circle' => array_merge($fill_attrs, ['cx' => true, 'cy' => true, 'r' => true]),
            'ellipse' => array_merge($fill_attrs, ['cx' => true, 'cy' => true, 'rx' => true, 'ry' => true]),
            'g' => array_merge($fill_attrs, ['transform' => true, 'id' => true]),
            'rect' => array_merge($fill_attrs, ['x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true, 'ry' => true]),
            'title' => [],
            'use' => ['href' => true, 'xlink:href' => true],
            'polygon' => array_merge($fill_attrs, ['points' => true]),
            'polyline' => array_merge($fill_attrs, ['points' => true]),
            'line' => ['x1' => true, 'x2' => true, 'y1' => true, 'y2' => true, 'stroke' => true, 'stroke-width' => true, 'class' => true],
            'defs' => [],
            'linearGradient' => ['id' => true, 'x1' => true, 'x2' => true, 'y1' => true, 'y2' => true, 'gradientUnits' => true],
            'radialGradient' => ['id' => true, 'cx' => true, 'cy' => true, 'r' => true, 'gradientUnits' => true],
            'stop' => ['offset' => true, 'stop-color' => true, 'stop-opacity' => true, 'style' => true],
            'mask' => ['id' => true],
            'clipPath' => ['id' => true],
        ];

        return wp_kses($html, $allowed);
    }
}

if (!function_exists('yooadmin_svg_data_uri_decode_to_raw_svg')) {
    /**
     * Decode data:image/svg+xml... to raw SVG markup (handles charset;base64, and url-encoded forms).
     *
     * @param string $data_uri Full data URI.
     * @return string Raw SVG or empty.
     */
    function yooadmin_svg_data_uri_decode_to_raw_svg(string $data_uri): string
    {
        $data_uri = trim($data_uri);
        if ($data_uri === '' || stripos($data_uri, 'data:image/svg+xml') !== 0) {
            return '';
        }
        // Base64 (Yoast often uses: data:image/svg+xml;charset=utf-8;base64,...)
        // Must run before comma-based decode — data:image/svg+xml;base64,XXX also has a comma.
        if (preg_match('/;base64,\s*(.+)$/is', $data_uri, $m)) {
            $b64 = preg_replace('/\s+/', '', $m[1]);
            if ($b64 === '') {
                return '';
            }
            $decoded = base64_decode($b64, true);
            if ($decoded !== false && stripos($decoded, '<svg') !== false) {
                return $decoded;
            }

            return '';
        }
        // Percent-encoded / plain after first comma: data:image/svg+xml,... or data:image/svg+xml;charset=utf8,...
        if (preg_match('/^data:image\/svg\+xml[^,]*,(.+)$/is', $data_uri, $m)) {
            $payload = rawurldecode($m[1]);
            if (stripos($payload, '<svg') !== false) {
                return $payload;
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_svg_markup_to_themed_inline')) {
    /**
     * Theme a raw SVG string: currentColor fills, kses-safe output.
     *
     * @param string $svg Raw SVG markup.
     * @return string Inline SVG or empty.
     */
    function yooadmin_svg_markup_to_themed_inline(string $svg): string
    {
        $svg = trim($svg);
        if ($svg === '' || stripos($svg, '<svg') === false) {
            return '';
        }
        if (strlen($svg) > 65536) {
            return '';
        }

        // Remove XML declaration and DOCTYPE.
        $svg = (string) preg_replace('/<\?xml[^>]*\?>/i', '', $svg);
        $svg = (string) preg_replace('/<!DOCTYPE[^>]*>/i', '', $svg);

        // Remove embedded <style> blocks entirely (kses would strip them).
        $svg = (string) preg_replace('/<style\b[^>]*>[\s\S]*?<\/style>/i', '', $svg);

        // Remove empty <defs>.
        $svg = (string) preg_replace('/<defs\b[^>]*>\s*<\/defs>/i', '', $svg);

        $svg = (string) preg_replace(
            '/\bfill\s*:\s*(?!none\b)(?:#[0-9a-fA-F]{3,8}|rgb[a]?\([^)]+\)|white|black)\b/ui',
            'fill:currentColor',
            $svg
        );

        $svg = (string) preg_replace('/\bfill\s*=\s*"(?!none")[^"]*"/i', 'fill="currentColor"', $svg);
        $svg = (string) preg_replace("/\\bfill\\s*=\\s*'(?!none')[^']*'/i", "fill='currentColor'", $svg);

        $svg = (string) preg_replace_callback(
            '/<svg\b([^>]*)>/i',
            static function (array $m): string {
                $attrs = $m[1];
                $attrs = (string) preg_replace('/\s+width\s*=\s*"[^"]*"/i', '', $attrs);
                $attrs = (string) preg_replace('/\s+height\s*=\s*"[^"]*"/i', '', $attrs);
                if (!preg_match('/\bxmlns\s*=/i', $attrs)) {
                    $attrs = ' xmlns="http://www.w3.org/2000/svg"' . $attrs;
                }
                if (!preg_match('/\bpreserveAspectRatio\s*=/i', $attrs)) {
                    $attrs .= ' preserveAspectRatio="xMidYMid meet"';
                }
                if (!preg_match('/\bfill\s*=/i', $attrs)) {
                    $attrs .= ' fill="currentColor"';
                }
                if (!preg_match('/\bfocusable\s*=/i', $attrs)) {
                    $attrs .= ' focusable="false"';
                }
                if (!preg_match('/\baria-hidden\s*=/i', $attrs)) {
                    $attrs .= ' aria-hidden="true"';
                }

                return '<svg' . $attrs . '>';
            },
            $svg,
            1
        );

        $svg = trim($svg);
        if ($svg === '' || stripos($svg, '<svg') === false) {
            return '';
        }

        $out = function_exists('yooadmin_kses_toolbar_icon_markup')
            ? yooadmin_kses_toolbar_icon_markup($svg)
            : wp_kses_post($svg);

        return function_exists('yooadmin_svg_fix_kses_lowercased_attrs')
            ? yooadmin_svg_fix_kses_lowercased_attrs($out)
            : $out;
    }
}

if (!function_exists('yooadmin_svg_fix_kses_lowercased_attrs')) {
    /**
     * wp_kses() lowercases attribute names on <svg> — breaks viewBox and breaks scaling (thin line).
     *
     * @param string $html Kses-safe fragment (usually one <svg>...</svg>).
     * @return string
     */
    function yooadmin_svg_fix_kses_lowercased_attrs(string $html): string
    {
        if ($html === '' || stripos($html, '<svg') === false) {
            return $html;
        }
        $html = (string) preg_replace('/\bviewbox=/i', 'viewBox=', $html);
        $html = (string) preg_replace('/\bpreserveaspectratio=/i', 'preserveAspectRatio=', $html);

        return $html;
    }
}

if (!function_exists('yooadmin_svg_data_uri_to_themed_inline')) {
    /**
     * Decode a data:image/svg+xml URI into a themed inline SVG.
     *
     * @param string $data_uri  Full data URI string.
     * @return string           Inline SVG markup, or empty string on failure.
     */
    function yooadmin_svg_data_uri_to_themed_inline(string $data_uri): string
    {
        $raw = function_exists('yooadmin_svg_data_uri_decode_to_raw_svg')
            ? yooadmin_svg_data_uri_decode_to_raw_svg($data_uri)
            : '';
        if ($raw === '') {
            return '';
        }

        $themed = function_exists('yooadmin_svg_markup_to_themed_inline')
            ? yooadmin_svg_markup_to_themed_inline($raw)
            : '';
        if ($themed !== '') {
            return $themed;
        }

        // Fallback: theming may fail for some SVGs (e.g. size/attr edge cases).
        // We still want to show the original icon, so sanitize raw SVG and return it.
        if (function_exists('yooadmin_kses_toolbar_icon_markup')) {
            // Minimal tint: force any remaining fill values to follow currentColor.
            $tinted = (string) preg_replace(
                '/\bfill\s*:\s*(?!none\b)(?:#[0-9a-fA-F]{3,8}|rgb[a]?\([^)]+\)|white|black)\b/ui',
                'fill:currentColor',
                $raw
            );
            $tinted = (string) preg_replace('/\bfill\s*=\s*"(?!none")[^"]*"/i', 'fill="currentColor"', $tinted);
            $tinted = (string) preg_replace("/\\bfill\\s*=\\s*'(?!none')[^']*'/i", "fill='currentColor'", $tinted);

            $fallback = yooadmin_kses_toolbar_icon_markup($tinted);
            if ($fallback !== '') {
                return function_exists('yooadmin_svg_fix_kses_lowercased_attrs')
                    ? yooadmin_svg_fix_kses_lowercased_attrs($fallback)
                    : $fallback;
            }
        }

        $fallback = function_exists('wp_kses_post')
            ? wp_kses_post((string) preg_replace(
                '/\bfill\s*:\s*(?!none\b)(?:#[0-9a-fA-F]{3,8}|rgb[a]?\([^)]+\)|white|black)\b/ui',
                'fill:currentColor',
                $raw
            ))
            : '';

        return $fallback !== ''
            ? (function_exists('yooadmin_svg_fix_kses_lowercased_attrs') ? yooadmin_svg_fix_kses_lowercased_attrs($fallback) : $fallback)
            : '';
    }
}

if (!function_exists('yooadmin_extract_toolbar_icon_markup')) {
    /**
     * Pull an icon from admin-bar title/meta HTML (img, svg, or non-empty ab-icon span).
     *
     * @param string $html Title or meta HTML.
     * @return string Sanitized markup or empty string.
     */
    function yooadmin_extract_toolbar_icon_markup(string $html): string
    {
        $html = trim($html);
        if ($html === '') {
            return '';
        }

        // Yoast: on some pages the icon placeholder exists without inline background-image.
        // The real painting is done later by Yoast admin-bar CSS/JS based on id/class.
        if (preg_match('/<div\b[^>]*\bid\s*=\s*["\']yoast-ab-icon["\'][^>]*>[\s\S]*?<\/div>/i', $html, $m)) {
            $out = yooadmin_kses_toolbar_icon_markup($m[0]);
            if ($out !== '') {
                return $out;
            }
        }

        // Decode entities (sometimes double-encoded). Do not strip whitespace inside data: URIs
        // (base64 may wrap); [^"\')\s]+ wrongly stopped on spaces/newlines.
        $normalize_css_fragment = static function (string $s): string {
            $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');

            return str_replace("\xc2\xa0", ' ', $s);
        };

        // ── Prefer data-URI / CSS background icons (same mechanism as wp-admin-bar: style + url(data:...)). ──
        if (function_exists('yooadmin_svg_data_uri_to_themed_inline')) {
            $decoded_all = $normalize_css_fragment($html);
            // Match url("data:..."), url(&quot;data:...&quot;) before decode, or mixed; allow whitespace in base64.
            if (preg_match(
                '/background-image\s*:\s*url\s*\(\s*(?:&quot;|"|\'|)(data:image\/svg\+xml[^"\')]+)/i',
                $decoded_all,
                $bg_all_m
            )) {
                $data_uri = trim($bg_all_m[1], "\"' \t\n\r\0\x0B");
                $inline = yooadmin_svg_data_uri_to_themed_inline($data_uri);
                if ($inline !== '') {
                    return $inline;
                }
            }
        }

        // ── Inline <svg> (skip score/traffic-light SVGs; Yoast puts those before the real bar icon). ──
        if (preg_match_all('/<svg\b[^>]*>[\s\S]*?<\/svg>/i', $html, $svg_blocks)) {
            foreach ($svg_blocks[0] as $svg_block) {
                if (strlen($svg_block) > 65536) {
                    continue;
                }
                if (preg_match('/Yoast_SEO_(negative|positive)_icon|traffic-light/i', $svg_block)) {
                    continue;
                }
                if (function_exists('yooadmin_svg_markup_to_themed_inline')) {
                    $themed = yooadmin_svg_markup_to_themed_inline($svg_block);
                    if ($themed !== '') {
                        return $themed;
                    }
                }

                return yooadmin_kses_toolbar_icon_markup($svg_block);
            }
        }

        // ── <img> tags ──────────────────────────────────────────────────────
        if (preg_match_all('/<img\b[^>]*>/i', $html, $matches)) {
            foreach ($matches[0] as $tag) {
                // Skip Yoast score/traffic-light graphics.
                if (preg_match('/Yoast_SEO_(negative|positive)_icon|traffic|score|traffic-light/i', $tag)) {
                    continue;
                }
                // data:image/svg+xml → convert to themed inline SVG.
                if (preg_match('/\bsrc\s*=\s*["\']?(data:image\/svg\+xml[^"\'>]+)/i', $tag, $src_m)
                    && function_exists('yooadmin_svg_data_uri_to_themed_inline')
                ) {
                    $inline = yooadmin_svg_data_uri_to_themed_inline(trim($src_m[1], '"\''));
                    if ($inline !== '') {
                        return $inline;
                    }
                }
                $out = yooadmin_kses_toolbar_icon_markup($tag);
                if ($out === '') {
                    continue;
                }
                if (function_exists('yooadmin_normalize_toolbar_img_src_in_markup')) {
                    $out = yooadmin_normalize_toolbar_img_src_in_markup($out);
                }

                return $out;
            }
        }

        // ── Opening tag only: span/div with ab-icon / yoast-logo / id=*ab-icon* (Yoast uses
        // <div id="yoast-ab-icon" class="ab-item yoast-logo svg" style="..."> + inner <span> — matching
        // full element with </span> breaks and misses background-image on the div).
        $open_patterns = [
            '/<(?:span|div)\b[^>]*\bclass\s*=\s*["\'][^"\']*(?:ab-icon|yoast-logo|wpseo-admin-bar|wpseo-logo)[^"\']*["\'][^>]*>/i',
            '/<(?:span|div)\b[^>]*\bid\s*=\s*["\'][^"\']*ab-icon[^"\']*["\'][^>]*>/i',
        ];
        foreach ($open_patterns as $op) {
            if (preg_match($op, $html, $m)) {
                $decoded_tag = $normalize_css_fragment($m[0]);
                if (preg_match(
                    '/background-image\s*:\s*url\s*\(\s*(?:&quot;|"|\'|)(data:image\/svg\+xml[^"\')]+)/i',
                    $decoded_tag,
                    $bg_m
                ) && function_exists('yooadmin_svg_data_uri_to_themed_inline')
                ) {
                    $data_uri = trim($bg_m[1], "\"' \t\n\r\0\x0B");
                    $inline = yooadmin_svg_data_uri_to_themed_inline($data_uri);
                    if ($inline !== '') {
                        return $inline;
                    }
                }
            }
        }

        // ── Any element with inline style containing background SVG data URI (plugin-agnostic). ──
        if (function_exists('yooadmin_svg_data_uri_to_themed_inline')
            && preg_match_all('/<[a-z][a-z0-9]*\b[^>]*\bstyle\s*=\s*(["\'])([^"\']*)\1/is', $html, $style_tags, PREG_SET_ORDER)
        ) {
            foreach ($style_tags as $st) {
                $style_val = $normalize_css_fragment($st[2]);
                if (preg_match(
                    '/background-image\s*:\s*url\s*\(\s*(?:&quot;|"|\'|)(data:image\/svg\+xml[^"\')]+)/i',
                    $style_val,
                    $bg_m
                )) {
                    $data_uri = trim($bg_m[1], "\"' \t\n\r\0\x0B");
                    $inline = yooadmin_svg_data_uri_to_themed_inline($data_uri);
                    if ($inline !== '') {
                        return $inline;
                    }
                }
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_toolbar_extract_icon_from_subtree')) {
    /**
     * Depth-first: find first extractable icon in admin-bar subtree (icons may be nested).
     *
     * @param array<string, array<int, object>> $nodes_by_parent
     */
    function yooadmin_toolbar_extract_icon_from_subtree(string $root_id, array $nodes_by_parent, int $depth = 0): string
    {
        if ($depth > 24 || $root_id === '' || !isset($nodes_by_parent[$root_id]) || !function_exists('yooadmin_extract_toolbar_icon_markup')) {
            return '';
        }
        foreach ($nodes_by_parent[$root_id] as $child) {
            if (!$child || !is_object($child)) {
                continue;
            }
            $t = isset($child->title) ? (string) $child->title : '';
            if ($t !== '') {
                $m = yooadmin_extract_toolbar_icon_markup($t);
                if ($m !== '') {
                    return $m;
                }
            }
            $cm = is_array($child->meta ?? null) ? $child->meta : [];
            $mh = isset($cm['html']) ? (string) $cm['html'] : '';
            if ($mh !== '') {
                $m = yooadmin_extract_toolbar_icon_markup($mh);
                if ($m !== '') {
                    return $m;
                }
            }
            $cid = isset($child->id) ? (string) $child->id : '';
            if ($cid !== '') {
                $sub = yooadmin_toolbar_extract_icon_from_subtree($cid, $nodes_by_parent, $depth + 1);
                if ($sub !== '') {
                    return $sub;
                }
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_resolve_toolbar_asset_src')) {
    /**
     * Resolve admin-bar img src to a loadable URL (absolute, under WP_PLUGIN_DIR, or basename search).
     *
     * @param string $src Raw src attribute.
     * @return string Escaped URL.
     */
    function yooadmin_resolve_toolbar_asset_src(string $src): string
    {
        $src = trim($src);
        if ($src === '') {
            return '';
        }
        // data:image/... must stay raw — esc_url() often strips or breaks long data: URIs (broken toolbar icons).
        if (preg_match('#^data:image/#i', $src)) {
            return $src;
        }
        if (preg_match('#^https?://#i', $src) || preg_match('#^data:#i', $src) || preg_match('#^//#', $src)) {
            return esc_url($src);
        }
        if ($src[0] === '/') {
            return esc_url(site_url($src));
        }

        $path = ltrim(str_replace('\\', '/', $src), '/');
        if (defined('WP_PLUGIN_DIR')) {
            $full = WP_PLUGIN_DIR . '/' . $path;
            if (is_readable($full)) {
                $slug = explode('/', $path)[0];
                $rel_from_plugin = substr($path, strlen($slug) + 1);
                $plugin_root = WP_PLUGIN_DIR . '/' . $slug;
                $mains = glob($plugin_root . '/*.php');
                $stub = ($mains && isset($mains[0])) ? $mains[0] : $plugin_root . '/index.php';

                return esc_url(plugins_url($rel_from_plugin, $stub));
            }
        }

        if (defined('ABSPATH')) {
            $abs_try = wp_normalize_path(ABSPATH . $path);
            if (is_readable($abs_try)) {
                return esc_url(site_url('/' . $path));
            }
        }

        $bn = basename($path);
        if ($bn !== '' && strlen($bn) < 200 && defined('WP_PLUGIN_DIR')) {
            foreach ([1, 2, 3] as $depth) {
                $pattern = WP_PLUGIN_DIR . str_repeat('/*', $depth) . '/' . $bn;
                foreach (glob($pattern) ?: [] as $file_full) {
                    if (!is_readable($file_full)) {
                        continue;
                    }
                    $rel = str_replace(WP_PLUGIN_DIR . '/', '', wp_normalize_path($file_full));
                    $parts = explode('/', $rel);
                    $slug = $parts[0];
                    $plugin_root = WP_PLUGIN_DIR . '/' . $slug;
                    $rel_from_plugin = implode('/', array_slice($parts, 1));
                    $mains = glob($plugin_root . '/*.php');
                    $stub = ($mains && isset($mains[0])) ? $mains[0] : $plugin_root . '/index.php';

                    return esc_url(plugins_url($rel_from_plugin, $stub));
                }
            }
        }

        return esc_url(site_url('/' . $path));
    }
}

if (!function_exists('yooadmin_normalize_toolbar_img_src_in_markup')) {
    /**
     * Turn relative img src (plugin-relative paths) into absolute URLs so mirrored toolbar icons load.
     *
     * @param string $html Single <img> tag or fragment containing one img.
     * @return string HTML with normalized src.
     */
    function yooadmin_normalize_toolbar_img_src_in_markup(string $html): string
    {
        if ($html === '' || !preg_match('/\bsrc\s*=\s*(["\'])([^"\']+)\1/i', $html, $m)) {
            return $html;
        }
        $src = trim($m[2]);
        if ($src === '') {
            return $html;
        }
        if (preg_match('#^data:image/#i', $src)) {
            return $html;
        }
        $new = function_exists('yooadmin_resolve_toolbar_asset_src')
            ? yooadmin_resolve_toolbar_asset_src($src)
            : esc_url(site_url('/' . ltrim($src, '/')));

        return preg_replace('/\bsrc\s*=\s*(["\'])([^"\']+)\1/i', 'src="' . esc_attr($new) . '"', $html, 1);
    }
}

if (!function_exists('yooadmin_wrap_toolbar_icon_svg_data_tint')) {
    /**
     * Wrap SVG data-URI icons so color follows dashboard brand (--_yp-primary) via CSS mask.
     * Supports <img src="data:image/svg+xml..."> and <span style="background-image:url(data:...)">.
     *
     * @param string $html Kses-safe fragment (single img, or span with bg, etc.).
     * @return string HTML with optional .yp-toolbar-theme-tint wrapper.
     */
    function yooadmin_wrap_toolbar_icon_svg_data_tint(string $html): string
    {
        $html = trim($html);
        if ($html === '') {
            return '';
        }

        $mask_style = static function (string $data_src): string {
            $css_var = '--yp-icon-url: url(' . wp_json_encode($data_src, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . ')';

            return ' style="' . esc_attr($css_var) . '"';
        };

        if (preg_match('/<img\b[^>]*\bsrc\s*=\s*(["\'])([^"\']+)\1/i', $html, $im)) {
            $src = $im[2];
            if (stripos($src, 'data:image/svg+xml') === 0) {
                return '<span class="yp-toolbar-theme-tint"' . $mask_style($src) . '>' . $html . '</span>';
            }

            return $html;
        }

        // Parse style on original HTML: decoding the whole span first turns url(&quot;data:...&quot;) into
        // nested quotes and breaks [^"\']* — use attribute-safe match, then decode the style value only.
        if (preg_match('/<span\b[^>]*\bstyle\s*=\s*(["\'])([^"\']*)\1/is', $html, $sm)) {
            $style = $sm[2];
            $style_decoded = html_entity_decode($style, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $style_decoded = html_entity_decode($style_decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if (preg_match('/background-image\s*:\s*url\s*\(\s*(?:&quot;|"|\'|)([^)]+)\)/i', $style_decoded, $um)) {
                $raw = trim($um[1]);
                $raw = trim($raw, "\"' \t\n\r\0\x0B");
                if (stripos($raw, 'data:image/svg+xml') === 0) {
                    return '<span class="yp-toolbar-theme-tint"' . $mask_style($raw) . ' aria-hidden="true"></span>';
                }
            }
        }
        $decoded = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $decoded = html_entity_decode($decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        // HTML entities in url(): url(&quot;data:image/svg+xml;base64,...&quot;)
        if (preg_match('/data:image\/svg\+xml[^"\'>]+/i', $decoded, $dm)) {
            $raw = trim($dm[0], '");');
            if (stripos($raw, 'data:image/svg+xml') === 0) {
                return '<span class="yp-toolbar-theme-tint"' . $mask_style($raw) . ' aria-hidden="true"></span>';
            }
        }

        return $html;
    }
}

if (!function_exists('yooadmin_toolbar_strip_ab_label_markup')) {
    /**
     * Remove admin-bar text labels from mirrored icon HTML (label lives in aria/tooltip/menu rows).
     *
     * @param string $html Icon fragment from #wpadminbar title/meta.
     * @return string Markup without .ab-label spans.
     */
    function yooadmin_toolbar_strip_ab_label_markup(string $html): string
    {
        $html = trim($html);
        if ($html === '') {
            return '';
        }
        $html = preg_replace('/<span[^>]*\bab-label\b[^>]*>[\s\S]*?<\/span>/iu', '', $html);

        return trim($html);
    }
}

if (!function_exists('yooadmin_toolbar_icon_markup_final')) {
    /**
     * Final stage: sanitize toolbar icon HTML.
     * If an <img src="data:image/svg+xml..."> slipped through extraction unchanged,
     * convert it to a themed inline SVG; otherwise just run kses.
     *
     * @param string $html Icon fragment.
     * @return string Safe HTML.
     */
    function yooadmin_toolbar_icon_markup_final(string $html): string
    {
        $html = trim($html);
        if ($html === '' || !function_exists('yooadmin_kses_toolbar_icon_markup')) {
            return '';
        }
        if (function_exists('yooadmin_toolbar_strip_ab_label_markup')) {
            $html = yooadmin_toolbar_strip_ab_label_markup($html);
        }
        if ($html === '') {
            return '';
        }
        // Catch any remaining <img src="data:image/svg+xml..."> not converted during extraction.
        if (function_exists('yooadmin_svg_data_uri_to_themed_inline')
            && preg_match('/\bsrc\s*=\s*["\']?(data:image\/svg\+xml[^"\'>]+)/i', $html, $m)
        ) {
            $inline = yooadmin_svg_data_uri_to_themed_inline(trim($m[1], '"\''));
            if ($inline !== '') {
                return $inline;
            }
        }
        $out = yooadmin_kses_toolbar_icon_markup($html);
        if ($out === '' && preg_match('/<svg\b/i', $html)) {
            $out = wp_kses_post($html);
        }

        return function_exists('yooadmin_svg_fix_kses_lowercased_attrs')
            ? yooadmin_svg_fix_kses_lowercased_attrs($out)
            : $out;
    }
}

if (!function_exists('yooadmin_extract_toolbar_display_label')) {
    /**
     * Human label for admin-bar node title HTML (avoids "SEO 00 notifications" from merged spans).
     *
     * @param string $raw_html Node title HTML.
     * @return string Plain text label.
     */
    function yooadmin_extract_toolbar_display_label(string $raw_html): string
    {
        $raw_html = trim($raw_html);
        if ($raw_html === '') {
            return '';
        }
        if (preg_match_all('/<span[^>]*class="[^"]*\bab-label\b[^"]*"[^>]*>(.*?)<\/span>/is', $raw_html, $matches)) {
            foreach ($matches[1] as $part) {
                $t = trim(wp_strip_all_tags($part));
                if ($t === '' || preg_match('/^\d+$/u', $t)) {
                    continue;
                }
                $t = preg_replace('/\s*\d+\s*notifications?\s*/iu', '', $t);

                return trim($t);
            }
        }

        $plain = trim(wp_strip_all_tags($raw_html));
        $plain = preg_replace('/\bSEO\s*\d+\s*notifications?\b/iu', 'SEO', $plain);
        $plain = preg_replace('/\s+\d+\s+notifications?\s*/iu', ' ', $plain);
        $plain = preg_replace('/\s+/', ' ', $plain);

        return trim($plain);
    }
}

if (!function_exists('yooadmin_normalize_toolbar_badge')) {
    /**
     * Toolbar badges are numeric counts only (comments, updates). Plain-text ab-label titles are ignored.
     */
    function yooadmin_normalize_toolbar_badge(string $badge): string
    {
        $badge = trim($badge);
        if ($badge === '' || !preg_match('/^\d+$/u', $badge)) {
            return '';
        }
        if ((int) $badge === 0) {
            return '';
        }

        return $badge;
    }
}

if (!function_exists('yooadmin_extract_toolbar_badge_from_html')) {
    /**
     * Extract a numeric admin-bar badge from title/meta HTML (ab-count or numeric ab-label only).
     *
     * @param string $source Node title or meta HTML.
     */
    function yooadmin_extract_toolbar_badge_from_html(string $source): string
    {
        $source = trim($source);
        if ($source === '') {
            return '';
        }
        if (preg_match('/<span[^>]*class="[^"]*ab-count[^"]*"[^>]*>(.*?)<\/span>/is', $source, $match)) {
            $value = trim(wp_strip_all_tags($match[1]));
            if ($value !== '' && preg_match('/^\d+$/u', $value)) {
                return $value;
            }
        }
        if (preg_match('/<span[^>]*class="[^"]*ab-label[^"]*"[^>]*>(.*?)<\/span>/is', $source, $match)) {
            $value = trim(wp_strip_all_tags($match[1]));
            if ($value !== '' && preg_match('/^\d+$/u', $value)) {
                return $value;
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_sanitize_toolbar_href')) {
    /**
     * Normalize admin-bar hrefs (relative admin.php, query-only) for the mirrored toolbar.
     *
     * @param string $href Raw href from WP_Admin_Bar node.
     * @return string Safe URL or empty or #.
     */
    function yooadmin_sanitize_toolbar_href(string $href): string
    {
        $href = trim($href);
        if ($href === '' || $href === '#') {
            return $href;
        }
        $lower = strtolower($href);
        if (strpos($lower, 'javascript:') === 0) {
            return '#';
        }
        if (preg_match('#^https?://#i', $href)) {
            return esc_url($href);
        }
        if ($href[0] === '/') {
            return esc_url(site_url($href));
        }
        if (strpos($href, '?') === 0) {
            return esc_url(admin_url('admin.php' . $href));
        }

        return esc_url(admin_url($href));
    }
}

if (!function_exists('yooadmin_resolve_toolbar_node_icon_fallback')) {
    /**
     * Optional hook only; no bundled plugin file paths. Use `yooadmin_toolbar_node_icon_fallback`.
     *
     * @param string $node_id Admin bar node id.
     * @param string $meta_class Meta class string.
     * @return string Sanitized img/svg markup or empty.
     */
    function yooadmin_resolve_toolbar_node_icon_fallback(string $node_id, string $meta_class): string
    {
        return (string) apply_filters('yooadmin_toolbar_node_icon_fallback', '', $node_id, $meta_class);
    }
}

/* ------------------------------------------------------------------------
 * Admin toolbar shortcuts (plugin buttons surfaced in header)
 * --------------------------------------------------------------------- */

if (!function_exists('yooadmin_sanitize_toolbar_children_hrefs')) {
    /**
     * @param array<int, array<string, mixed>> $children
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_sanitize_toolbar_children_hrefs(array $children): array
    {
        foreach ($children as $i => $row) {
            if (!is_array($row)) {
                continue;
            }
            $ch = isset($row['href']) ? (string) $row['href'] : '';
            if ($ch !== '' && function_exists('yooadmin_sanitize_toolbar_href')) {
                $children[$i]['href'] = yooadmin_sanitize_toolbar_href($ch);
            }
            if (!empty($row['children']) && is_array($row['children'])) {
                $children[$i]['children'] = yooadmin_sanitize_toolbar_children_hrefs($row['children']);
            }
        }

        return $children;
    }
}

if (!function_exists('yooadmin_toolbar_branch_from_parent')) {
    /**
     * Recursively mirror admin-bar nodes (handles flyout / third-level menus).
     *
     * @param array<string, array<int, object>> $nodes_by_parent
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_toolbar_branch_from_parent(
        string $parent_id,
        array $nodes_by_parent,
        array $excluded,
        callable $find_dashicon,
        callable $resolve_position,
        callable $extract_badge
    ): array {
        if ($parent_id === '' || empty($nodes_by_parent[$parent_id])) {
            return [];
        }
        $child_nodes = $nodes_by_parent[$parent_id];
        usort(
            $child_nodes,
            static function ($a, $b) use ($resolve_position): int {
                return $resolve_position($a) <=> $resolve_position($b);
            }
        );

        $children = [];
        foreach ($child_nodes as $child) {
            if (!$child || !is_object($child)) {
                continue;
            }
            $child_id = isset($child->id) ? (string) $child->id : '';
            if ($child_id === '' || in_array($child_id, $excluded, true)) {
                continue;
            }

            $nested = yooadmin_toolbar_branch_from_parent(
                $child_id,
                $nodes_by_parent,
                $excluded,
                $find_dashicon,
                $resolve_position,
                $extract_badge
            );

            $child_html = isset($child->title) ? (string) $child->title : '';
            $child_label = function_exists('yooadmin_extract_toolbar_display_label')
                ? yooadmin_extract_toolbar_display_label($child_html)
                : trim(wp_strip_all_tags($child_html));
            if ($child_label === '') {
                $child_label = trim(wp_strip_all_tags($child_html));
            }
            if ($child_label === '' && empty($nested)) {
                continue;
            }
            if ($child_label === '') {
                $child_label = ucwords(str_replace(['-', '_'], ' ', $child_id));
            }

            $child_meta = is_array($child->meta ?? null) ? $child->meta : [];
            $child_target = isset($child_meta['target']) && $child_meta['target'] === '_blank' ? '_blank' : '';
            $child_meta_class = isset($child_meta['class']) ? (string) $child_meta['class'] : '';

            $child_icon = $find_dashicon($child_meta_class);
            if ($child_icon === '') {
                $child_icon = $find_dashicon($child_html);
            }
            $child_badge = $extract_badge($child_html);

            $child_icon_markup = '';
            if (function_exists('yooadmin_extract_toolbar_icon_markup')) {
                $child_icon_markup = yooadmin_extract_toolbar_icon_markup($child_html);
                if ($child_icon_markup === '' && isset($child_meta['html'])) {
                    $child_icon_markup = yooadmin_extract_toolbar_icon_markup((string) $child_meta['html']);
                }
            }
            if (function_exists('apply_filters')) {
                $child_icon_markup = apply_filters('yooadmin_toolbar_node_icon_markup', $child_icon_markup, $child, $child_id, $child_meta_class);
            }
            $child_icon_markup = is_string($child_icon_markup) ? trim($child_icon_markup) : '';
            if ($child_icon_markup !== '' && function_exists('yooadmin_normalize_toolbar_img_src_in_markup')) {
                $child_icon_markup = yooadmin_normalize_toolbar_img_src_in_markup($child_icon_markup);
            }

            $children[] = [
                'id' => $child_id,
                'label' => $child_label,
                'href' => isset($child->href) ? (string) $child->href : '',
                'target' => $child_target,
                'icon_class' => $child_icon,
                'icon_markup' => $child_icon_markup,
                'badge' => $child_badge,
                'children' => $nested,
            ];
        }

        return $children;
    }
}

if (!function_exists('yooadmin_render_toolbar_menu_level')) {
    /**
     * Render one level of mirrored toolbar dropdown (supports nested flyouts).
     *
     * @param array<int, array<string, mixed>> $children
     */
    function yooadmin_render_toolbar_menu_level(array $children): void
    {
        foreach ($children as $child) {
            if (!is_array($child)) {
                continue;
            }
            $nested = isset($child['children']) && is_array($child['children']) ? $child['children'] : [];
            $has_nested = !empty($nested);
            $child_href = (string) ($child['href'] ?? '');
            $child_label = (string) ($child['label'] ?? '');
            $child_target = (string) ($child['target'] ?? '');
            $child_icon = (string) ($child['icon_class'] ?? '');
            $child_markup = (string) ($child['icon_markup'] ?? '');
            $child_badge = (string) ($child['badge'] ?? '');
            $child_rel = $child_target === '_blank' ? 'noopener noreferrer' : '';

            if ($child_label === '' && !$has_nested) {
                continue;
            }
            if ($child_label === '') {
                $child_label = ucwords(str_replace(['-', '_'], ' ', (string) ($child['id'] ?? '')));
            }

            if ($has_nested) {
                echo '<div class="yp-toolbar-menu-item has-submenu">';
            }

            $child_id = (string) ($child['id'] ?? '');
            echo '<a class="yp-toolbar-menu-link" role="menuitem" href="' . esc_url($child_href !== '' ? $child_href : '#') . '"';
            if ($child_id !== '') {
                echo ' data-admin-bar-id="' . esc_attr($child_id) . '"';
            }
            if ($child_target === '_blank') {
                echo ' target="_blank" rel="' . esc_attr($child_rel) . '"';
            }
            if ($has_nested) {
                echo ' aria-haspopup="true" aria-expanded="false"';
            }
            echo '>';

            $show_row_icons = apply_filters('yooadmin_toolbar_dropdown_show_row_icons', false);
            if ($show_row_icons && $child_markup !== '' && function_exists('yooadmin_kses_toolbar_icon_markup')) {
                echo '<span class="yp-toolbar-menu-icon yp-toolbar-menu-icon-inline" aria-hidden="true">';
                echo function_exists('yooadmin_toolbar_icon_markup_final')
                    ? yooadmin_toolbar_icon_markup_final($child_markup) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- kses
                    : yooadmin_kses_toolbar_icon_markup($child_markup); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- kses
                echo '</span>';
            } elseif ($show_row_icons && $child_icon !== '') {
                echo '<span class="yp-toolbar-menu-icon ' . esc_attr($child_icon) . '" aria-hidden="true"></span>';
            }
            echo '<span class="yp-toolbar-menu-text">' . esc_html($child_label) . '</span>';
            if ($child_badge !== '') {
                echo '<span class="yp-toolbar-menu-badge">' . esc_html($child_badge) . '</span>';
            }
            echo '</a>';

            if ($has_nested) {
                echo '<div class="yp-toolbar-submenu" role="menu">';
                yooadmin_render_toolbar_menu_level($nested);
                echo '</div></div>';
            }
        }
    }
}

if (!function_exists('yooadmin_render_toolbar_shortcut_icon')) {
    /**
     * Echo toolbar shortcut icon markup (dashicons, SVG, or admin-bar fragment).
     *
     * @param array<string, mixed> $shortcut Shortcut row.
     */
    function yooadmin_render_toolbar_shortcut_icon(array $shortcut): void
    {
        $icon_markup = (string) ($shortcut['icon_markup'] ?? '');
        $icon_class  = (string) ($shortcut['icon_class'] ?? '');
        $icon_rendered = '';

        if ($icon_markup !== '' && function_exists('yooadmin_kses_toolbar_icon_markup')) {
            $icon_rendered = function_exists('yooadmin_toolbar_icon_markup_final')
                ? yooadmin_toolbar_icon_markup_final($icon_markup)
                : yooadmin_kses_toolbar_icon_markup($icon_markup);
            if ($icon_rendered === '' && preg_match('/<svg\b/i', $icon_markup)) {
                $icon_rendered = wp_kses_post($icon_markup);
            }
        }

        if ($icon_rendered !== '') {
            echo $icon_rendered; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- kses / trusted admin-bar fragment
            return;
        }
        if ($icon_class !== '') {
            echo '<span class="' . esc_attr($icon_class) . '"></span>';
            return;
        }
        if ((string) ($shortcut['id'] ?? '') === 'yooadmin-extended-settings') {
            echo '<span class="dashicons dashicons-admin-settings" aria-hidden="true"></span>';
            return;
        }
        if (in_array((string) ($shortcut['id'] ?? ''), ['view', 'preview', 'view-site'], true)) {
            echo '<span class="dashicons dashicons-welcome-view-site" aria-hidden="true"></span>';
            return;
        }
        $sid = (string) ($shortcut['id'] ?? '');
        if ($sid !== '' && (stripos($sid, 'wpseo') !== false || stripos($sid, 'yoast') !== false)) {
            echo '<span class="yoast-logo svg yp-toolbar-yoast-fallback" aria-hidden="true"></span>';
            return;
        }
        echo '<span class="dashicons dashicons-admin-settings" aria-hidden="true"></span>';
    }
}

if (!function_exists('yooadmin_render_toolbar_shortcut_item')) {
    /**
     * Render one top-level breadcrumbs-toolbar shortcut (icon button + optional flyout).
     *
     * @param array<string, mixed> $shortcut Shortcut row.
     */
    function yooadmin_render_toolbar_shortcut_item(array $shortcut): void
    {
        $href          = (string) ($shortcut['href'] ?? '');
        $label         = (string) ($shortcut['label'] ?? '');
        $tooltip       = (string) ($shortcut['tooltip'] ?? $label);
        $badge         = (string) ($shortcut['badge'] ?? '');
        $target        = (string) ($shortcut['target'] ?? '');
        $rel           = $target === '_blank' ? 'noopener noreferrer' : '';
        $children      = isset($shortcut['children']) && is_array($shortcut['children']) ? $shortcut['children'] : [];
        $has_children  = !empty($children);
        $shortcut_id   = (string) ($shortcut['id'] ?? '');
        $trigger_class = 'yp-toolbar-trigger';
        if ($shortcut_id === 'wpdn-add-note') {
            $trigger_class .= ' wpdn-add-note';
        }
        ?>
        <div class="yp-toolbar-item<?php echo $has_children ? ' has-children' : ''; ?>" data-toolbar-id="<?php echo esc_attr($shortcut_id); ?>">
            <a class="<?php echo esc_attr($trigger_class); ?>"
               href="<?php echo $href !== '' ? esc_url($href) : '#'; ?>"
               <?php if (!empty($shortcut['id'])) : ?>
                   data-admin-bar-id="<?php echo esc_attr((string) $shortcut['id']); ?>"
               <?php endif; ?>
               <?php if ($tooltip !== '') : ?>
                   title="<?php echo esc_attr($tooltip); ?>"
               <?php endif; ?>
               aria-label="<?php echo esc_attr($label !== '' ? $label : $tooltip); ?>"
               <?php if ($target === '_blank') : ?>
                   target="_blank" rel="<?php echo esc_attr($rel); ?>"
               <?php endif; ?>>
                <span class="yp-toolbar-content">
                    <span class="yp-toolbar-icon" aria-hidden="true">
                        <?php yooadmin_render_toolbar_shortcut_icon($shortcut); ?>
                    </span>
                    <?php if ($badge !== '') : ?>
                        <span class="yp-toolbar-badge"><?php echo esc_html($badge); ?></span>
                    <?php endif; ?>
                </span>
            </a>
            <?php if ($has_children) : ?>
                <?php $child_n = count($children); ?>
                <div class="yp-toolbar-menu<?php echo $child_n > 8 ? ' yp-toolbar-menu--cols' : ''; ?>" role="menu" data-children="<?php echo (int) $child_n; ?>">
                    <?php
                    if (function_exists('yooadmin_render_toolbar_menu_level')) {
                        yooadmin_render_toolbar_menu_level($children);
                    }
                    ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}

if (!function_exists('yooadmin_render_toolbar_overflow_menu_items')) {
    /**
     * Render overflow shortcuts inside the “more” toolbar menu.
     *
     * @param array<int, array<string, mixed>> $shortcuts Overflow shortcut rows.
     */
    function yooadmin_render_toolbar_overflow_menu_items(array $shortcuts): void
    {
        foreach ($shortcuts as $shortcut) {
            if (!is_array($shortcut)) {
                continue;
            }
            $href         = (string) ($shortcut['href'] ?? '');
            $label        = (string) ($shortcut['label'] ?? '');
            $tooltip      = (string) ($shortcut['tooltip'] ?? '');
            $badge        = (string) ($shortcut['badge'] ?? '');
            $target       = (string) ($shortcut['target'] ?? '');
            $rel          = $target === '_blank' ? 'noopener noreferrer' : '';
            $children     = isset($shortcut['children']) && is_array($shortcut['children']) ? $shortcut['children'] : [];
            $has_children = !empty($children);

            if ($label === '') {
                $label = $tooltip;
            }
            if ($label === '' && !$has_children) {
                continue;
            }
            if ($label === '') {
                $label = ucwords(str_replace(['-', '_'], ' ', (string) ($shortcut['id'] ?? '')));
            }

            if ($has_children) {
                echo '<div class="yp-toolbar-menu-item has-submenu">';
            }

            $shortcut_id = (string) ($shortcut['id'] ?? '');
            echo '<a class="yp-toolbar-menu-link" role="menuitem" href="' . esc_url($href !== '' ? $href : '#') . '"';
            if ($shortcut_id !== '') {
                echo ' data-admin-bar-id="' . esc_attr($shortcut_id) . '"';
            }
            if ($target === '_blank') {
                echo ' target="_blank" rel="' . esc_attr($rel) . '"';
            }
            if ($has_children) {
                echo ' aria-haspopup="true" aria-expanded="false"';
            }
            echo '>';
            echo '<span class="yp-toolbar-menu-icon yp-toolbar-menu-icon-inline" aria-hidden="true">';
            yooadmin_render_toolbar_shortcut_icon($shortcut);
            echo '</span>';
            echo '<span class="yp-toolbar-menu-text">' . esc_html($label) . '</span>';
            if ($badge !== '') {
                echo '<span class="yp-toolbar-menu-badge">' . esc_html($badge) . '</span>';
            }
            echo '</a>';

            if ($has_children && function_exists('yooadmin_render_toolbar_menu_level')) {
                echo '<div class="yp-toolbar-submenu" role="menu">';
                yooadmin_render_toolbar_menu_level($children);
                echo '</div></div>';
            }
        }
    }
}

if (!function_exists('yooadmin_is_command_palette_available')) {
    /**
     * Whether WordPress 7+ command palette assets can be used in YOOAdmin.
     */
    function yooadmin_is_command_palette_available(): bool
    {
        if (!is_admin() || !is_user_logged_in() || !yooadmin_command_palette_is_available()) {
            return false;
        }
        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        return true;
    }
}

if (!function_exists('yooadmin_get_command_palette_shortcut_label')) {
    /**
     * Keyboard hint for the command palette trigger (Ctrl+K or ⌘K).
     */
    function yooadmin_get_command_palette_shortcut_label(): string
    {
        $apple_pattern = 'Macintosh|Mac OS X|Mac_PowerPC';
        $user_agent    = isset($_SERVER['HTTP_USER_AGENT'])
            ? sanitize_text_field(wp_unslash((string) $_SERVER['HTTP_USER_AGENT']))
            : '';
        $is_apple_os   = (bool) preg_match("/{$apple_pattern}/i", $user_agent);

        return $is_apple_os
            ? _x('⌘K', 'keyboard shortcut to open the command palette', 'yooadmin')
            : _x('Ctrl+K', 'keyboard shortcut to open the command palette', 'yooadmin');
    }
}

if (!function_exists('yooadmin_render_command_palette_trigger')) {
    /**
     * Render a compact command palette trigger outside mirrored admin-bar shortcuts.
     *
     * @param array<string, mixed> $args Optional id, class, role attrs.
     */
    function yooadmin_render_command_palette_trigger(array $args = []): void
    {
        if (!yooadmin_is_command_palette_available()) {
            return;
        }

        $shortcut = yooadmin_get_command_palette_shortcut_label();
        $id       = isset($args['id']) ? sanitize_html_class((string) $args['id']) : 'yooadmin-command-palette-trigger';
        $classes  = ['yp-command-palette-trigger'];
        $role     = isset($args['role']) ? sanitize_key((string) $args['role']) : '';

        if (!empty($args['class'])) {
            $extra_classes = preg_split('/\s+/', (string) $args['class']);
            if (is_array($extra_classes)) {
                foreach ($extra_classes as $class) {
                    $class = sanitize_html_class($class);
                    if ($class !== '') {
                        $classes[] = $class;
                    }
                }
            }
        }
        $classes = array_values(array_unique($classes));
        ?>
        <button type="button"
                class="<?php echo esc_attr(implode(' ', $classes)); ?>"
                <?php if ($id !== '') : ?>
                    id="<?php echo esc_attr($id); ?>"
                <?php endif; ?>
                aria-label="<?php esc_attr_e('Open command palette', 'yooadmin'); ?>"
                title="<?php esc_attr_e('Open command palette', 'yooadmin'); ?>"
                <?php if ($role !== '') : ?>
                    role="<?php echo esc_attr($role); ?>"
                <?php endif; ?>
                data-apple-shortcut="<?php echo esc_attr(_x('⌘K', 'keyboard shortcut to open the command palette', 'yooadmin')); ?>">
            <span class="yp-command-palette-trigger__icon dashicons dashicons-search" aria-hidden="true"></span>
            <kbd class="yp-command-palette-trigger__kbd"><?php echo esc_html($shortcut); ?></kbd>
        </button>
        <?php
    }
}

if (!function_exists('yooadmin_get_toolbar_overflow_only_shortcut_ids')) {
    /**
     * Shortcut IDs that always render inside the ⋮ overflow menu (never on the bar).
     *
     * @return string[]
     */
    function yooadmin_get_toolbar_overflow_only_shortcut_ids(): array
    {
        $ids = [
            'yooadmin-preview-store',
            'yooadmin-extended-preview-store',
        ];

        /**
         * @param string[] $ids
         */
        $ids = apply_filters('yooadmin_toolbar_overflow_only_shortcut_ids', $ids);

        return is_array($ids) ? array_values(array_filter(array_map('strval', $ids))) : [];
    }
}

if (!function_exists('yooadmin_demote_toolbar_shortcuts_to_overflow')) {
    /**
     * Move matching shortcuts from the visible bar list into overflow.
     *
     * @param array<int, array<string, mixed>> $visible
     * @param array<int, array<string, mixed>> $overflow
     * @param string[]                          $demote_ids
     * @return array{0: array<int, array<string, mixed>>, 1: array<int, array<string, mixed>>}
     */
    function yooadmin_demote_toolbar_shortcuts_to_overflow(array $visible, array $overflow, array $demote_ids): array
    {
        if ($demote_ids === []) {
            return [$visible, $overflow];
        }

        $demote_lookup = array_fill_keys($demote_ids, true);
        $keep_visible  = [];
        $demoted       = [];

        foreach ($visible as $shortcut) {
            if (!is_array($shortcut)) {
                continue;
            }

            $id = (string) ($shortcut['id'] ?? '');
            if ($id !== '' && isset($demote_lookup[ $id ])) {
                $demoted[] = $shortcut;
                continue;
            }

            $keep_visible[] = $shortcut;
        }

        if ($demoted === []) {
            return [$visible, $overflow];
        }

        return [array_values($keep_visible), array_merge($demoted, $overflow)];
    }
}

if (!function_exists('yooadmin_split_toolbar_shortcuts_for_display')) {
    /**
     * Split breadcrumbs-toolbar shortcuts: YOOAdmin shortcuts on the bar, plugin mirrors in overflow.
     *
     * Bar: custom YOOAdmin shortcuts (Plugins, Settings, Preview Site) up to $max_visible.
     * Overflow menu: preview store, mirrored admin-bar shortcuts, and custom rows over the cap.
     *
     * @param array<int, array<string, mixed>> $mirrored_shortcuts From yooadmin_collect_toolbar_shortcuts().
     * @param array<int, array<string, mixed>> $custom_shortcuts    YOOAdmin shortcuts (header.php).
     * @param int                             $max_visible         Max icons on the bar.
     * @return array{0: array<int, array<string, mixed>>, 1: array<int, array<string, mixed>>}
     */
    function yooadmin_split_toolbar_shortcuts_for_display(array $mirrored_shortcuts, array $custom_shortcuts, int $max_visible): array
    {
        $mirrored_shortcuts = array_values($mirrored_shortcuts);
        $custom_shortcuts   = array_values($custom_shortcuts);
        $max_visible        = max(1, $max_visible);

        $visible  = array_slice($custom_shortcuts, 0, $max_visible);
        $overflow = array_merge(
            array_slice($custom_shortcuts, $max_visible),
            $mirrored_shortcuts
        );

        [$visible, $overflow] = yooadmin_demote_toolbar_shortcuts_to_overflow(
            $visible,
            $overflow,
            yooadmin_get_toolbar_overflow_only_shortcut_ids()
        );

        /**
         * Adjust bar vs overflow split after default logic.
         *
         * @param array{0: array<int, array<string, mixed>>, 1: array<int, array<string, mixed>>} $split [visible, overflow].
         * @param array<int, array<string, mixed>> $mirrored_shortcuts
         * @param array<int, array<string, mixed>> $custom_shortcuts
         * @param int $max_visible
         */
        $split = apply_filters(
            'yooadmin_toolbar_shortcuts_display_split',
            [$visible, $overflow],
            $mirrored_shortcuts,
            $custom_shortcuts,
            $max_visible
        );

        if (!is_array($split) || !isset($split[0], $split[1]) || !is_array($split[0]) || !is_array($split[1])) {
            return [$visible, $overflow];
        }

        [$visible, $overflow] = yooadmin_demote_toolbar_shortcuts_to_overflow(
            array_values($split[0]),
            array_values($split[1]),
            yooadmin_get_toolbar_overflow_only_shortcut_ids()
        );

        return [$visible, $overflow];
    }
}

if (!function_exists('yooadmin_get_default_toolbar_shortcuts')) {
    /**
     * Built-in toolbar shortcuts when the admin bar mirror yields none (capability-aware).
     *
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_get_default_toolbar_shortcuts(): array
    {
        $update_counts = wp_get_update_data();
        $updates_badge = isset($update_counts['counts']['total'])
            ? (string) (int) $update_counts['counts']['total']
            : '';

        $comments_badge = '';
        $comments       = wp_count_comments();
        if ($comments && isset($comments->moderated)) {
            $comments_badge = (string) (int) $comments->moderated;
        }

        $updates_href = function_exists('yooadmin_update_center_admin_url')
            ? yooadmin_update_center_admin_url()
            : admin_url('update-core.php');

        $new_children = [];
        if (current_user_can('edit_posts')) {
            $new_children[] = [
                'id'         => 'yooadmin-new-post',
                'label'      => __('Post', 'yooadmin'),
                'href'       => admin_url('post-new.php'),
                'target'     => '',
                'icon_class' => '',
                'badge'      => '',
            ];
        }
        if (current_user_can('edit_pages')) {
            $new_children[] = [
                'id'         => 'yooadmin-new-page',
                'label'      => __('Page', 'yooadmin'),
                'href'       => admin_url('post-new.php?post_type=page'),
                'target'     => '',
                'icon_class' => '',
                'badge'      => '',
            ];
        }
        if (current_user_can('upload_files')) {
            $new_children[] = [
                'id'         => 'yooadmin-new-media',
                'label'      => __('Media', 'yooadmin'),
                'href'       => admin_url('media-new.php'),
                'target'     => '',
                'icon_class' => '',
                'badge'      => '',
            ];
        }

        $shortcuts = [];

        if (
            current_user_can('update_core')
            || current_user_can('update_plugins')
            || current_user_can('update_themes')
            || current_user_can('update_languages')
        ) {
            $shortcuts[] = [
                'id'         => 'yooadmin-updates',
                'label'      => __('Updates', 'yooadmin'),
                'href'       => $updates_href,
                'tooltip'    => __('WordPress Updates', 'yooadmin'),
                'icon_class' => 'dashicons dashicons-update',
                'badge'      => $updates_badge !== '0' ? $updates_badge : '',
                'target'     => '',
                'children'   => [],
            ];
        }

        if ($new_children !== []) {
            $shortcuts[] = [
                'id'         => 'yooadmin-new',
                'label'      => '',
                'href'       => '#',
                'tooltip'    => __('Add New', 'yooadmin'),
                'icon_class' => 'dashicons dashicons-plus-alt',
                'badge'      => '',
                'target'     => '',
                'children'   => $new_children,
            ];
        }

        if (current_user_can('moderate_comments') || current_user_can('edit_posts')) {
            $comments_href = admin_url('edit-comments.php');
            $nav_opts      = (array) get_option('yooadmin_options', []);
            $comments_redirect = !array_key_exists('comments_redirect', $nav_opts)
                || !empty($nav_opts['comments_redirect']);
            if ($comments_redirect && function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled()) {
                $comments_href = admin_url('admin.php?page=yooadmin-comments');
            }
            $shortcuts[] = [
                'id'         => 'yooadmin-comments',
                'label'      => __('Comments', 'yooadmin'),
                'href'       => $comments_href,
                'tooltip'    => __('Comments', 'yooadmin'),
                'icon_class' => 'dashicons dashicons-admin-comments',
                'badge'      => $comments_badge !== '0' ? $comments_badge : '',
                'target'     => '',
                'children'   => [],
            ];
        }

        /**
         * @param array<int, array<string, mixed>> $shortcuts
         */
        $shortcuts = apply_filters('yooadmin_default_toolbar_shortcuts', $shortcuts);

        if (function_exists('yooadmin_filter_toolbar_shortcuts_by_capability')) {
            $shortcuts = yooadmin_filter_toolbar_shortcuts_by_capability($shortcuts);
        }

        return $shortcuts;
    }
}

if (!function_exists('yooadmin_toolbar_shortcuts_from_link_items')) {
    /**
     * Convert simple link rows into toolbar shortcut rows.
     *
     * @param array<int, array{title?: string, label?: string, url: string, icon?: string}> $items
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_toolbar_shortcuts_from_link_items(array $items): array
    {
        $shortcuts = [];

        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            $label = isset($item['title']) ? (string) $item['title'] : (isset($item['label']) ? (string) $item['label'] : '');
            $url   = isset($item['url']) ? (string) $item['url'] : '';
            $icon  = isset($item['icon']) ? trim((string) $item['icon']) : 'dashicons-admin-links';
            if ($label === '' || $url === '' || $icon === '') {
                continue;
            }

            $shortcuts[] = [
                'id'          => 'yooadmin-link-' . sanitize_key((string) $index . '-' . $label),
                'label'       => $label,
                'href'        => $url,
                'tooltip'     => $label,
                'icon_class'  => strpos($icon, 'dashicons') === 0 ? $icon : 'dashicons-' . ltrim($icon, 'dashicons-'),
                'icon_markup' => '',
                'badge'       => '',
                'target'      => '',
                'children'    => [],
            ];
        }

        if (function_exists('yooadmin_filter_toolbar_shortcuts_by_capability')) {
            $shortcuts = yooadmin_filter_toolbar_shortcuts_by_capability($shortcuts);
        }

        return $shortcuts;
    }
}

if (!function_exists('yooadmin_collect_toolbar_shortcuts')) {
    /**
     * Collect a curated list of admin-bar shortcut buttons (typically injected by plugins)
     * so they can be mirrored inside the YOOAdmin header.
     *
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_collect_toolbar_shortcuts(): array
    {
        if (!is_user_logged_in()) {
            return [];
        }

        global $wp_admin_bar, $yooadmin_toolbar_nodes;
        if (!is_object($wp_admin_bar) || !method_exists($wp_admin_bar, 'get_nodes')) {
            return [];
        }

        // Prefer cache from admin_bar_menu @ PHP_INT_MAX (full tree). Do NOT call
        // admin_bar_menu early from here — plugins gate on is_admin_bar_showing() etc.
        $nodes = [];
        if (is_array($yooadmin_toolbar_nodes) && $yooadmin_toolbar_nodes) {
            $nodes = $yooadmin_toolbar_nodes;
        } else {
            $nodes = $wp_admin_bar->get_nodes();
        }
        if (!is_array($nodes) || !$nodes) {
            return [];
        }

        $nodes_by_parent = [];
        $top_candidates = [];
        foreach ($nodes as $node) {
            if (!$node || !is_object($node)) {
                continue;
            }
            $parent = isset($node->parent) ? (string)$node->parent : '';
            $id = isset($node->id) ? (string)$node->id : '';
            if ($id === '') {
                continue;
            }
            $nodes_by_parent[$parent][] = $node;
            if ($parent === '' || $parent === 'top-secondary') {
                $top_candidates[$id] = $node;
            }
        }

        $default_excluded = [
            'wp-logo',
            'site-name',
            'my-sites',
            'my-account',
            'user-actions',
            'search',
            'menu-toggle',
            'updates',
            'yooadmin-notifications',
            'notifications',
            'yooadmin-focus-toggle',
            'command-palette',
        ];

        /**
         * Allow integrators to hide specific admin-bar nodes from the mirrored shortcuts.
         *
         * @param string[] $excluded Node IDs to skip entirely.
         */
        $excluded = apply_filters('yooadmin_toolbar_excluded_ids', $default_excluded);
        $excluded = is_array($excluded) ? array_map('strval', $excluded) : $default_excluded;

        $shortcuts = [];

        $find_dashicon = static function ($source, $node = null): string {
            if (!is_string($source) || $source === '') {
                return '';
            }
            // Only match dashicons-* inside class="..." attributes.
            // Never match on URLs, data attributes, ids, or unrelated markup
            // (e.g. "yoast-ab-icon" id contains "ab-icon", "dashicons-menu" can appear in CSS strings).
            // Also skip generic non-icon dashicons: dashicons-menu renders a hamburger.
            $skip_generic = ['dashicons-menu', 'dashicons-before', 'dashicons-marker'];
            if (stripos($source, 'dashicons') !== false) {
                if (preg_match_all('/class\s*=\s*["\']([^"\']*)["\']/i', $source, $cm)) {
                    foreach ($cm[1] as $classes) {
                        if (preg_match('/\b(dashicons-[a-z0-9-]+)\b/i', $classes, $match)) {
                            $dc = strtolower($match[1]);
                            if (in_array($dc, $skip_generic, true)) {
                                continue;
                            }
                            if (strpos($dc, 'dashicons-menu') === 0) {
                                continue;
                            }
                            return 'dashicons ' . $dc;
                        }
                    }
                }
                // Plain class string from meta (no class=" wrapper), e.g. "menupop dashicons-admin-site".
                if (!preg_match('/\bclass\s*=/i', $source) && preg_match('/\b(dashicons-[a-z0-9-]+)\b/i', $source, $match)) {
                    $dc = strtolower($match[1]);
                    if (!in_array($dc, $skip_generic, true) && strpos($dc, 'dashicons-menu') !== 0) {
                        return 'dashicons ' . $dc;
                    }
                }
            }
            // Do NOT fall back to ab-icon — that class depends on WP admin-bar CSS
            // which is not present in YOOAdmin header; it just renders blank or wrong icon.
            return '';
        };

        $extract_badge = static function ($source): string {
            return function_exists('yooadmin_extract_toolbar_badge_from_html')
                ? yooadmin_extract_toolbar_badge_from_html((string) $source)
                : '';
        };

        $resolve_position = static function ($node): int {
            if (isset($node->position)) {
                return (int)$node->position;
            }
            if (isset($node->meta['position'])) {
                return (int)$node->meta['position'];
            }
            if (isset($node->menu_order)) {
                return (int)$node->menu_order;
            }
            return 0;
        };

        $top_nodes = array_values($top_candidates);
        usort(
            $top_nodes,
        static function ($a, $b) use ($resolve_position): int {
            return $resolve_position($a) <=> $resolve_position($b);
        }
        );

        foreach ($top_nodes as $node) {
            if (!$node || !is_object($node)) {
                continue;
            }

            $id = isset($node->id) ? (string)$node->id : '';
            if ($id === '' || in_array($id, $excluded, true)) {
                continue;
            }

            $fresh = $wp_admin_bar->get_node($id);
            if ($fresh && is_object($fresh)) {
                $node = $fresh;
            }

            $meta = is_array($node->meta ?? null) ? $node->meta : [];
            $meta_class = isset($meta['class']) ? (string)$meta['class'] : '';
            $meta_html = isset($meta['html']) ? (string)$meta['html'] : '';

            $raw_html = isset($node->title) ? (string)$node->title : '';
            $label = function_exists('yooadmin_extract_toolbar_display_label')
                ? yooadmin_extract_toolbar_display_label($raw_html)
                : trim(wp_strip_all_tags($raw_html));
            if ($label === '') {
                $label = trim(wp_strip_all_tags($raw_html));
            }
            $tooltip = isset($meta['title']) && is_string($meta['title']) ? trim($meta['title']) : $label;
            if ($label === '') {
                $label = ucwords(str_replace(['-', '_'], ' ', $id));
            }
            if ($tooltip === '') {
                $tooltip = $label;
            }

            $href      = isset($node->href) ? (string) $node->href : '';
            $raw_href  = $href;
            $target    = isset($meta['target']) && $meta['target'] === '_blank' ? '_blank' : '';
            $onclick   = isset($meta['onclick']) ? trim((string) $meta['onclick']) : '';
            if ($onclick === '' && $raw_href !== '' && stripos($raw_href, 'javascript:') === 0) {
                $onclick = $raw_href;
            }

            $is_yoast_like_early = (stripos($id, 'wpseo') !== false || stripos($id, 'yoast') !== false
                || stripos($meta_class, 'wpseo') !== false || stripos($meta_class, 'yoast') !== false);

            $icon_class = $find_dashicon($meta_class, $node);
            if ($icon_class === '') {
                $icon_class = $find_dashicon($meta_html, $node);
            }
            // Yoast title HTML is huge and may mention unrelated dashicon class names — do not scan it.
            if ($icon_class === '' && !$is_yoast_like_early) {
                $icon_class = $find_dashicon($raw_html, $node);
            }

            // Map common WordPress admin bar node IDs to dashicons
            if ($icon_class === '' || stripos($icon_class, 'ab-icon') !== false) {
                $icon_map = [
                    'comments' => 'dashicons-admin-comments',
                    'new-content' => 'dashicons-plus-alt',
                    'updates' => 'dashicons-update',
                    'new-post' => 'dashicons-admin-post',
                    'new-page' => 'dashicons-admin-page',
                    'new-media' => 'dashicons-admin-media',
                    'new-user' => 'dashicons-admin-users',
                    'woocommerce-site-visibility-badge' => 'dashicons-visibility',
                    'wpdn-add-note' => 'dashicons-welcome-write-blog',
                    'desktop-mode-toggle' => 'dashicons-desktop',
                    'desktop-fullscreen' => 'dashicons-fullscreen-alt',
                    'desktop-layout-menu' => 'dashicons-grid-view',
                    'desktop-bug-report' => 'dashicons-buddicons-replies',
                    'desktop-help' => 'dashicons-editor-help',
                    // View / preview current post or page (title often has empty .ab-icon when mirrored outside #wpadminbar)
                    'view' => 'dashicons-welcome-view-site',
                    'preview' => 'dashicons-welcome-view-site',
                    'view-site' => 'dashicons-welcome-view-site',
                ];
                if (isset($icon_map[$id])) {
                    $icon_class = 'dashicons ' . $icon_map[$id];
                }
            }

            $icon_markup = '';
            $is_yoast_node = (stripos($id, 'wpseo') !== false || stripos($id, 'yoast') !== false
                || stripos($meta_class, 'wpseo') !== false || stripos($meta_class, 'yoast') !== false);
            if (function_exists('yooadmin_extract_toolbar_icon_markup')) {
                $icon_markup = yooadmin_extract_toolbar_icon_markup($raw_html);
                if ($icon_markup === '') {
                    $icon_markup = yooadmin_extract_toolbar_icon_markup($meta_html);
                }
                // Some plugins (e.g. Yoast SEO) place the icon inside a child node
                // (e.g. yoast-ab-icon) rather than in the parent title/meta.
                // Scan subtree recursively — icons may be nested.
                if ($icon_markup === '' && !empty($nodes_by_parent[$id])) {
                    $icon_markup = yooadmin_toolbar_extract_icon_from_subtree($id, $nodes_by_parent);
                }
            }
            // Icon node may exist on $wp_admin_bar but be missing from get_nodes() snapshot (parent wiring).
            if ($icon_markup === '' && $is_yoast_node && is_object($wp_admin_bar) && method_exists($wp_admin_bar, 'get_node')
                && function_exists('yooadmin_extract_toolbar_icon_markup')
            ) {
                foreach (['yoast-ab-icon', 'yoast-seo-ab-icon'] as $ab_try) {
                    $ab_node = $wp_admin_bar->get_node($ab_try);
                    if ($ab_node && isset($ab_node->title) && (string) $ab_node->title !== '') {
                        $icon_markup = yooadmin_extract_toolbar_icon_markup((string) $ab_node->title);
                        if ($icon_markup !== '') {
                            break;
                        }
                    }
                }
            }
            if ($icon_markup === '' && function_exists('yooadmin_resolve_toolbar_node_icon_fallback')) {
                $icon_markup = yooadmin_resolve_toolbar_node_icon_fallback($id, $meta_class);
            }

            // Google Site Kit: toolbar icon is applied via stylesheet on #wpadminbar only (empty span in node HTML).
            if ($icon_markup === ''
                && (stripos($id, 'googlesitekit') !== false
                    || stripos($id, 'google-site-kit') !== false
                    || stripos($id, 'sitekit') !== false
                    || stripos($meta_class, 'googlesitekit') !== false)
            ) {
                $icon_markup = '<span class="yp-toolbar-site-kit-icon yp-toolbar-ab-bg-sync" aria-hidden="true"></span>';
            }

            /**
             * Filter resolved icon HTML for a mirrored toolbar shortcut (after extraction / fallbacks).
             *
             * @param string $icon_markup Sanitized HTML or empty.
             * @param object $node Admin bar node.
             * @param string $id Node id.
             * @param string $meta_class Meta class.
             */
            $icon_markup = apply_filters('yooadmin_toolbar_node_icon_markup', $icon_markup, $node, $id, $meta_class);
            $icon_markup = is_string($icon_markup) ? trim($icon_markup) : '';
            if ($icon_markup !== '' && function_exists('yooadmin_normalize_toolbar_img_src_in_markup')) {
                $icon_markup = yooadmin_normalize_toolbar_img_src_in_markup($icon_markup);
            }

            // Yoast: if we still have no custom markup, drop misleading ab-icon / wrong dashicons (use template generic or SVG fallback only).
            if ($is_yoast_node && $icon_markup === '' && stripos($icon_class, 'ab-icon') !== false) {
                $icon_class = '';
            }

            $badge = $extract_badge($meta_html);
            if ($badge === '') {
                $badge = $extract_badge($raw_html);
            }
            if ($badge === '' && preg_match('/\b(\d+)\s*notifications?\b/iu', $raw_html, $bn)) {
                $badge = $bn[1];
            }
            if (function_exists('yooadmin_normalize_toolbar_badge')) {
                $badge = yooadmin_normalize_toolbar_badge($badge);
            }

            // Simplify labels for specific nodes
            if ($id === 'comments' && $badge !== '') {
                $label = $badge; // Show only the number
                $badge = ''; // Don't show badge separately
            }
            elseif ($id === 'new-content') {
                $label = ''; // Hide label for New menu (has submenu)
                $badge = ''; // Hide "New"/"جديد" badge extracted from ab-label
            }
            elseif ($id === 'wpdn-add-note') {
                $badge = '';
                $label = _x('Note', 'short toolbar label: add dashboard note', 'yooadmin');
                $tooltip = isset($meta['title']) && is_string($meta['title']) && trim($meta['title']) !== ''
                    ? trim(wp_strip_all_tags($meta['title']))
                    : trim(wp_strip_all_tags($raw_html));
                if ($tooltip === '') {
                    $tooltip = $label;
                }
            }
            elseif (stripos($id, 'notification') !== false) {
                // Exclude notification nodes entirely (we have our own custom notification shortcut)
                continue;
            }

            if (stripos($id, 'wpseo') !== false || stripos($id, 'yoast') !== false) {
                if (isset($meta['title']) && is_string($meta['title']) && trim(wp_strip_all_tags($meta['title'])) !== '') {
                    $mt = trim(wp_strip_all_tags($meta['title']));
                    if (stripos($mt, 'notification') === false && strlen($mt) < 80) {
                        $label = $mt;
                    }
                }
                $label = trim(preg_replace('/\bSEO\s*\d+\s*notifications?\b/iu', 'SEO', $label));
                $label = trim(preg_replace('/\s+\d+\s+notifications?\s*/iu', '', $label));
                $label = trim(preg_replace('/\s+/', ' ', $label));
                if (preg_match('/^SEO\b/iu', $label) || preg_match('/^SEO\b/iu', trim(wp_strip_all_tags($raw_html)))) {
                    $label = 'SEO';
                }
            }

            $children = [];
            if (!empty($nodes_by_parent[$id]) && function_exists('yooadmin_toolbar_branch_from_parent')) {
                $children = yooadmin_toolbar_branch_from_parent(
                    $id,
                    $nodes_by_parent,
                    $excluded,
                    $find_dashicon,
                    $resolve_position,
                    $extract_badge
                );
            }
            if (function_exists('yooadmin_sanitize_toolbar_children_hrefs')) {
                $children = yooadmin_sanitize_toolbar_children_hrefs($children);
            }

            // Skip nodes without usable interaction
            if ($href === '' && empty($children) && $onclick === '') {
                continue;
            }

            if (function_exists('yooadmin_sanitize_toolbar_href')) {
                $href = $href !== '' ? yooadmin_sanitize_toolbar_href($href) : '';
            }

            // Mirrored toolbar: native title tooltip is redundant (Site Kit opens a real flyout on hover).
            if (stripos($id, 'googlesitekit') !== false
                || stripos($id, 'google-site-kit') !== false
                || stripos($id, 'sitekit') !== false
                || stripos($meta_class, 'googlesitekit') !== false
            ) {
                $tooltip = '';
            }

            $shortcuts[] = [
                'id' => $id,
                'label' => $label,
                'href' => $href,
                'tooltip' => $tooltip,
                'icon_class' => $icon_class,
                'icon_markup' => $icon_markup,
                'badge' => $badge,
                'target' => $target,
                'onclick' => $onclick,
                'children' => $children,
                'position' => $resolve_position($node),
            ];
        }

        if (!$shortcuts) {
            return [];
        }

        usort(
            $shortcuts,
        static function (array $a, array $b): int {
            return ($a['position'] ?? 0) <=> ($b['position'] ?? 0);
        }
        );

        /**
         * Filter the final shortcuts list before rendering.
         *
         * @param array<int, array<string, mixed>> $shortcuts
         */
        $shortcuts = apply_filters('yooadmin_toolbar_shortcuts', $shortcuts);

        if (function_exists('yooadmin_filter_toolbar_shortcuts_by_capability')) {
            $shortcuts = yooadmin_filter_toolbar_shortcuts_by_capability($shortcuts);
        }

        return $shortcuts;
    }
}