<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_branded_public_security_page_bootstrap_locale')) {
    function yooadmin_branded_public_security_page_bootstrap_locale(): void
    {
        $locale = function_exists('yooadmin_custom_login_get_login_locale')
            ? yooadmin_custom_login_get_login_locale()
            : (function_exists('determine_locale') ? determine_locale() : get_locale());

        if (function_exists('switch_to_locale')) {
            switch_to_locale($locale);
        }

        if (function_exists('yooadmin_load_yooadmin_textdomain')) {
            yooadmin_load_yooadmin_textdomain($locale);
        }
    }
}

if (!function_exists('yooadmin_branded_public_security_page_print_color_bootstrap')) {
    function yooadmin_branded_public_security_page_print_color_bootstrap(): void
    {
        $mode = function_exists('yooadmin_custom_login_get_color_mode')
            ? yooadmin_custom_login_get_color_mode()
            : 'auto';

        if (!in_array($mode, ['light', 'dark', 'auto'], true)) {
            $mode = 'auto';
        }

        printf(
            '<script id="yooadmin-public-security-color-mode">(function(){var m=%1$s;var eff="light";if(m==="dark"){eff="dark";}else if(m==="auto"){try{eff=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(e){eff="light";}}document.documentElement.setAttribute("data-yoo-login-color-mode",m);document.documentElement.setAttribute("data-yoo-login-color-mode-effective",eff);})();</script>' . "\n",
            wp_json_encode($mode)
        );
    }
}

if (!function_exists('yooadmin_branded_public_security_page_print_inline_vars')) {
    function yooadmin_branded_public_security_page_print_inline_vars(): void
    {
        if (!function_exists('yooadmin_custom_login_get_style_vars')) {
            return;
        }

        $effective = function_exists('yooadmin_custom_login_resolve_effective_color_mode')
            ? yooadmin_custom_login_resolve_effective_color_mode()
            : 'light';

        $vars = yooadmin_custom_login_get_style_vars($effective);

        if (function_exists('yooadmin_custom_login_resolve_logo')) {
            $resolved       = yooadmin_custom_login_resolve_logo($effective);
            $resolved_light = yooadmin_custom_login_resolve_logo('light');
            $resolved_dark  = yooadmin_custom_login_resolve_logo('dark');
            $logo_w         = (int) ($resolved['max_w'] ?? 150);

            $vars['--yoo-maintenance-logo-max-w'] = max(60, $logo_w) . 'px';

            if (!empty($resolved['url'])) {
                $vars['--yoo-login-logo-url'] = 'url(\'' . esc_url((string) $resolved['url'], ['http', 'https']) . '\')';
            }

            if (!empty($resolved_light['url'])) {
                $vars['--yoo-login-logo-url-light'] = 'url(\'' . esc_url((string) $resolved_light['url'], ['http', 'https']) . '\')';
            }

            if (!empty($resolved_dark['url'])) {
                $vars['--yoo-login-logo-url-dark'] = 'url(\'' . esc_url((string) $resolved_dark['url'], ['http', 'https']) . '\')';
            }
        }

        $css = 'body.yooadmin-public-security-page{';
        foreach ($vars as $key => $value) {
            if (in_array($key, ['--yoo-login-logo-url', '--yoo-login-logo-url-light', '--yoo-login-logo-url-dark', '--yoo-sl-welcome-bg-image'], true)) {
                $css .= $key . ':' . $value . ';';
                continue;
            }
            $css .= $key . ':' . esc_html((string) $value) . ';';
        }
        $css .= '}';

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted theme variables.
        echo '<style id="yooadmin-public-security-vars">' . $css . '</style>' . "\n";

        if (function_exists('yooadmin_maintenance_print_overlay_css_vars')) {
            yooadmin_maintenance_print_overlay_css_vars();
        }
    }
}

if (!function_exists('yooadmin_branded_public_security_page_print_scripts')) {
    function yooadmin_branded_public_security_page_print_scripts(): void
    {
        if (!defined('YOOADMIN_PLUGIN_FILE')) {
            return;
        }

        if (!wp_style_is('dashicons', 'registered')) {
            wp_register_style(
                'dashicons',
                includes_url('css/dashicons.min.css'),
                [],
                get_bloginfo('version')
            );
        }
        wp_enqueue_style('dashicons');
        wp_print_styles('dashicons');

        $js_rel  = 'assets/js/public/yoo-security-action.js';
        $js_path = plugin_dir_path(YOOADMIN_PLUGIN_FILE) . $js_rel;
        if (!is_readable($js_path)) {
            return;
        }

        $cfg = [
            'i18n' => [
                'recovering' => __('Recovering your account…', 'yooadmin'),
                'dismiss'    => __('Dismiss', 'yooadmin'),
            ],
        ];

        wp_register_script(
            'yooadmin-security-action',
            plugin_dir_url(YOOADMIN_PLUGIN_FILE) . $js_rel,
            [],
            (string) filemtime($js_path),
            [
                'in_footer' => true,
                'strategy'  => 'defer',
            ]
        );
        wp_enqueue_script('yooadmin-security-action');
        wp_add_inline_script(
            'yooadmin-security-action',
            'window.yooadminSecurityAction=' . wp_json_encode($cfg) . ';',
            'before'
        );
        wp_print_scripts('yooadmin-security-action');
    }
}

if (!function_exists('yooadmin_branded_public_security_page_resolve_logo_pack')) {
    /**
     * @return array{url:string,max_w:int,light_url:string,dark_url:string,use_dual:bool}
     */
    function yooadmin_branded_public_security_page_resolve_logo_pack(): array
    {
        $light = function_exists('yooadmin_custom_login_resolve_logo_light')
            ? yooadmin_custom_login_resolve_logo_light()
            : ['url' => '', 'max_w' => 150];
        $dark = function_exists('yooadmin_custom_login_resolve_logo')
            ? yooadmin_custom_login_resolve_logo('dark')
            : ['url' => '', 'max_w' => 150];

        $light_url = trim((string) ($light['url'] ?? ''));
        $dark_url  = trim((string) ($dark['url'] ?? ''));
        $max_w     = max(60, (int) ($light['max_w'] ?? $dark['max_w'] ?? 150));
        $display   = $light_url !== '' ? $light_url : $dark_url;

        return [
            'url'       => $display,
            'max_w'     => $max_w,
            'light_url' => $light_url,
            'dark_url'  => $dark_url,
            'use_dual'  => ($light_url !== '' && $dark_url !== '' && $light_url !== $dark_url),
        ];
    }
}

if (!function_exists('yooadmin_branded_public_security_page_render')) {
    /**
     * @param array<string, mixed> $args {
     *     @type string               $title         Page title.
     *     @type string               $message       Intro copy.
     *     @type string               $restore_email Optional email address shown on recovery pages.
     *     @type string               $email_label   Label above $restore_email.
     *     @type string               $error         Optional error message.
     *     @type string               $action_url   Form POST target.
     *     @type array<string, string> $hidden_fields Hidden inputs.
     *     @type string               $nonce_action Nonce action.
     *     @type string               $nonce_name   Nonce field name.
     *     @type string               $submit_label Submit button label.
     * }
     */
    function yooadmin_branded_public_security_page_render(array $args): void
    {
        if (!defined('YOOADMIN_DIR')) {
            return;
        }

        yooadmin_branded_public_security_page_bootstrap_locale();

        status_header(200);
        nocache_headers();

        if (!headers_sent()) {
            header('X-Robots-Tag: noindex, nofollow', true);
        }

        $GLOBALS['yooadmin_security_action_page'] = $args;

        $tpl = YOOADMIN_DIR . 'templates/public/branded-security-action.php';
        if (!is_readable($tpl)) {
            return;
        }

        require $tpl;
        exit;
    }
}
