<?php
/**
 * YOOAdmin - Dynamic styles (CSS variables from options)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Text domain hardcoded as 'yooadmin' for WordPress.org compliance

/* ----------------------------------------------------------------------------
 * Sanitizers
 * ---------------------------------------------------------------------------- */

/**
 * Sanitize a HEX color (#RRGGBB). Falls back to $fallback on failure.
 *
 * @param string $value
 * @param string $fallback
 * @return string
 */
if (!function_exists('yooadmin_sanitize_hex')) {
	function yooadmin_sanitize_hex($value, $fallback = '#000000') {
		$value = trim((string) $value);

		// Prefer WP core when available.
		if (function_exists('sanitize_hex_color')) {
			$san = sanitize_hex_color($value);
			return $san ? $san : $fallback;
		}

		// Minimal strict #RRGGBB.
		return (preg_match('/^#([0-9a-f]{6})$/i', $value)) ? strtoupper($value) : $fallback;
	}
}

/**
 * Sanitize a positive CSS size ending with px (e.g., "20px").
 *
 * @param string|int $value
 * @param string     $fallback
 * @return string
 */
if (!function_exists('yooadmin_sanitize_px')) {
	function yooadmin_sanitize_px($value, $fallback = '20px') {
		$v = is_numeric($value) ? (int) $value : (int) preg_replace('/[^0-9]/', '', (string) $value);
		if ($v <= 0 || $v > 256) { // sensible bounds
			return $fallback;
		}
		return $v . 'px';
	}
}

/* ----------------------------------------------------------------------------
 * Options (Brand)
 * ---------------------------------------------------------------------------- */

/**
 * Read brand color options and normalize to valid values.
 *
 * Option shape (array option: yooadmin_brand). All keys are optional:
 * [
 *   'primary'                 => '#eda934',
 *   'secondary'               => '#5A5A5A',
 *   'accent'                  => '#1E1E1E',
 *   'background'              => '#FFFFFF',
 *   'text'                    => '#111111',
 *   // Header
 *   'header_bg'               => '#4B4B4B',
 *   'header_fg'               => '#FFFFFF',
 *   'header_submenu_bg'       => '#4B4B4B',
 *   'header_submenu_link'     => '#eda934',
 *   // Sidebar
 *   'sidebar_bg'              => '#4B4B4B',
 *   'sidebar_fg'              => '#FFFFFF',
 *   'sidebar_sub_fg'          => '#F1F1F1',
 *   // Cards / Dashboard
 *   'card_icon_color'         => '#eda934',
 *   'card_text'               => '#606060',
 *   'card_text_hover'         => '#eda934',
 *   // Sizes
 *   'menu_icon_size'          => '22px',
 *   'card_icon_size'          => '40px'
 * ]
 *
 * @return array
 */
if (!function_exists('yooadmin_get_brand_options')) {
	function yooadmin_get_brand_options() {
		// Theme Settings / Studio Hub persist palette in yooadmin_colors (canonical).
		$colors = (array) get_option('yooadmin_colors', []);
		$legacy = (array) get_option('yooadmin_brand', []);
		$opt    = !empty($colors) ? array_merge($legacy, $colors) : $legacy;

		// Base brand
		$primary    = yooadmin_sanitize_hex($opt['primary']    ?? '#eda934', '#eda934');
		$secondary  = yooadmin_sanitize_hex($opt['secondary']  ?? '#5A5A5A', '#5A5A5A');
		$accent     = yooadmin_sanitize_hex($opt['accent']     ?? '#1E1E1E', '#1E1E1E');
		$background = yooadmin_sanitize_hex($opt['background'] ?? '#FFFFFF', '#FFFFFF');
		$text       = yooadmin_sanitize_hex($opt['text']       ?? '#111111', '#111111');

		// Header
		$header_bg           = yooadmin_sanitize_hex($opt['header_bg']           ?? '#4B4B4B', '#4B4B4B');
		$header_fg           = yooadmin_sanitize_hex($opt['header_fg']           ?? '#FFFFFF', '#FFFFFF');
		$header_submenu_bg   = yooadmin_sanitize_hex($opt['header_submenu_bg']   ?? '#4B4B4B', '#4B4B4B');
		$header_submenu_link = yooadmin_sanitize_hex($opt['header_submenu_link'] ?? $primary,  $primary);

		// Sidebar
		$sidebar_bg   = yooadmin_sanitize_hex($opt['sidebar_bg']   ?? '#4B4B4B', '#4B4B4B');
		$sidebar_fg   = yooadmin_sanitize_hex($opt['sidebar_fg']   ?? '#FFFFFF', '#FFFFFF');
		$sidebar_sub_fg = yooadmin_sanitize_hex($opt['sidebar_sub_fg'] ?? '#F1F1F1', '#F1F1F1');

		// Cards / Dashboard
		$card_icon_color  = yooadmin_sanitize_hex($opt['card_icon_color']  ?? $primary,  $primary);
		$card_text        = yooadmin_sanitize_hex($opt['card_text']        ?? '#606060', '#606060');
		$card_text_hover  = yooadmin_sanitize_hex($opt['card_text_hover']  ?? $primary,  $primary);

		// Sizes
		$menu_icon_size = yooadmin_sanitize_px($opt['menu_icon_size'] ?? '22px', '22px');
		$card_icon_size = yooadmin_sanitize_px($opt['card_icon_size'] ?? '40px', '40px');

		return compact(
			'primary','secondary','accent','background','text',
			'header_bg','header_fg','header_submenu_bg','header_submenu_link',
			'sidebar_bg','sidebar_fg','sidebar_sub_fg',
			'card_icon_color','card_text','card_text_hover',
			'menu_icon_size','card_icon_size'
		);
	}
}

/* ----------------------------------------------------------------------------
 * CSS variables builder
 * ---------------------------------------------------------------------------- */

/**
 * Build :root CSS variables string from brand options.
 *
 * @return array{css:string,signature:string}
 */
if (!function_exists('yooadmin_build_css_variables')) {
	function yooadmin_build_css_variables() {
		$b = yooadmin_get_brand_options();

		// Slightly darker primary for hover states (600 tone)
		// If you later store it in options, this line keeps backward compatibility.
		$primary_600 = $b['primary'];
		try {
			// Simple darken ~12% (works only for #RRGGBB).
			if (preg_match('/^#([0-9A-F]{6})$/i', $b['primary'])) {
				$hex = substr($b['primary'], 1);
				$r = max(0, hexdec(substr($hex, 0, 2)) - 30);
				$g = max(0, hexdec(substr($hex, 2, 2)) - 30);
				$b6 = max(0, hexdec(substr($hex, 4, 2)) - 30);
				$primary_600 = sprintf('#%02X%02X%02X', $r, $g, $b6);
			}
		} catch (\Throwable $e) {}

		$vars = [
			// New canonical tokens
			'--yooadmin-brand-source'           => $b['primary'],
			'--yooadmin-primary'              => $b['primary'],
			'--yooadmin-primary-600'          => $primary_600,
			'--yooadmin-primary-hover'        => $primary_600,
			'--yooadmin-secondary'            => $b['secondary'],
			'--yooadmin-accent'               => $b['accent'],
			'--yooadmin-bg'                   => $b['background'],
			'--yooadmin-text'                 => $b['text'],

			// Header
			'--yp-header-bg'                  => $b['header_bg'],
			'--yp-header-fg'                  => $b['header_fg'],
			'--yp-header-submenu-bg'          => $b['header_submenu_bg'],
			'--yp-header-submenu-link'        => $b['header_submenu_link'],

			// Sidebar
			'--yp-sidebar-bg'                 => $b['sidebar_bg'],
			'--yp-sidebar-fg'                 => $b['sidebar_fg'],
			'--yp-sidebar-sub-fg'             => $b['sidebar_sub_fg'],
			'--yp-menu-icon-size'             => $b['menu_icon_size'],

			// Dashboard / Cards
			'--yp-card-icon-color'            => $b['card_icon_color'],
			'--yp-card-icon-size'             => $b['card_icon_size'],
			'--yp-card-text'                  => $b['card_text'],
			'--yp-card-text-hover'            => $b['card_text_hover'],

			// Surfaces / text neutrals used in current CSS
			'--yp-surface'                    => '#f8fafd',
			'--yp-text-600'                   => '#606060',
			'--yp-text-500'                   => '#555555',
			'--yp-border'                     => '#e0e0e0',
		];

		// Legacy aliases to keep existing styles working
		$vars['--yp-primary']   = $b['primary'];
		$vars['--yp-primary-600'] = $primary_600;

		$lines = [];
		foreach ($vars as $k => $v) {
			$lines[] = sprintf('  %s: %s;', $k, $v);
		}

		$css = ":root{\n" . implode("\n", $lines) . "\n}\n";
		$signature = md5($css);

		return [
			'css'       => $css,
			'signature' => $signature,
		];
	}
}

if (!function_exists('yooadmin_get_brand_css_vars_block')) {
	/**
	 * Inner :root variable declarations (without wrapper) for scoped inline CSS.
	 */
	function yooadmin_get_brand_css_vars_block(): string {
		if (!function_exists('yooadmin_build_css_variables')) {
			return '';
		}

		$brand_vars = yooadmin_build_css_variables();
		$raw_css    = isset($brand_vars['css']) ? trim((string) $brand_vars['css']) : '';
		if ($raw_css === '' || !preg_match('/^:root\s*\{(.+)\}\s*$/s', $raw_css, $matches)) {
			return '';
		}

		return trim((string) $matches[1]);
	}
}

if (!function_exists('yooadmin_get_brand_primary_600_hex')) {
	/**
	 * Darkened primary used for button/toggle hover (matches build_css_variables).
	 */
	function yooadmin_get_brand_primary_600_hex(): string {
		$b         = yooadmin_get_brand_options();
		$primary   = sanitize_hex_color((string) ($b['primary'] ?? '')) ?: '#eda934';
		$primary_600 = $primary;

		if (preg_match('/^#([0-9A-F]{6})$/i', $primary)) {
			$hex = substr($primary, 1);
			$r   = max(0, hexdec(substr($hex, 0, 2)) - 30);
			$g   = max(0, hexdec(substr($hex, 2, 2)) - 30);
			$b6  = max(0, hexdec(substr($hex, 4, 2)) - 30);
			$primary_600 = sprintf('#%02X%02X%02X', $r, $g, $b6);
		}

		return $primary_600;
	}
}

if (!function_exists('yooadmin_get_brand_primary_hover_gradient_css')) {
	/**
	 * Solid brand hover gradient (hex) for !important inline overrides.
	 */
	function yooadmin_get_brand_primary_hover_gradient_css(): string {
		$hover = yooadmin_get_brand_primary_600_hex();

		return 'linear-gradient(180deg, ' . $hover . ' 0%, ' . $hover . ' 100%)';
	}
}

if (!function_exists('yooadmin_get_latin_font_family_name')) {
	function yooadmin_get_latin_font_family_name(): string {
		$opts = (array) get_option('yooadmin_options', []);

		if (!empty($opts['google_fonts_enable'])) {
			$family = isset($opts['google_fonts_family']) ? sanitize_text_field($opts['google_fonts_family']) : '';
			if ($family !== '') {
				return $family;
			}
		}

		return 'Montserrat';
	}
}

if (!function_exists('yooadmin_get_latin_font_family_css_value')) {
	function yooadmin_get_latin_font_family_css_value(): string {
		$family = yooadmin_get_latin_font_family_name();

		if (preg_match('/[^a-zA-Z0-9_-]/', $family)) {
			return "'" . str_replace("'", "\\'", $family) . "'";
		}

		return $family;
	}
}

if (!function_exists('yooadmin_build_latin_font_variable_css')) {
	function yooadmin_build_latin_font_variable_css(): string {
		$value = yooadmin_get_latin_font_family_css_value();

		return ":root, body.wp-admin { --yooadmin-latin-font-family: {$value}; }\n";
	}
}

if (!function_exists('yooadmin_get_admin_ui_locale')) {
	/**
	 * Locale for YOOAdmin admin UI strings (user profile language when logged in).
	 *
	 * Must not require is_admin(): Studio Hub loads dashboard cards via REST
	 * (/wp-json/yooadmin/v1/...) where is_admin() is false.
	 */
	function yooadmin_get_admin_ui_locale(): string {
		if (is_user_logged_in() && function_exists('get_user_locale')) {
			return (string) get_user_locale();
		}

		return (string) get_locale();
	}
}

if (!function_exists('yooadmin_is_arabic_admin_ui')) {
	function yooadmin_is_arabic_admin_ui(): bool {
		return strpos(yooadmin_get_admin_ui_locale(), 'ar') === 0;
	}
}

if (!function_exists('yooadmin_site_has_arabic_language_pack')) {
	function yooadmin_site_has_arabic_language_pack(): bool {
		$installed = get_available_languages();
		if (!is_array($installed)) {
			$installed = [];
		}

		foreach ($installed as $locale) {
			if (strpos((string) $locale, 'ar') === 0) {
				return true;
			}
		}

		$site_locale = get_locale();

		return is_string($site_locale) && strpos($site_locale, 'ar') === 0;
	}
}

if (!function_exists('yooadmin_should_enqueue_tajawal_font')) {
	/**
	 * Always load Tajawal on YOOAdmin screens. Notification bodies may stay in
	 * Arabic after the user switches the admin UI back to English.
	 */
	function yooadmin_should_enqueue_tajawal_font(): bool {
		return true;
	}
}

if (!function_exists('yooadmin_load_admin_ui_textdomain')) {
	function yooadmin_load_admin_ui_textdomain(?string $locale = null): void {
		if ($locale === null && function_exists('yooadmin_get_admin_ui_locale')) {
			$locale = yooadmin_get_admin_ui_locale();
		}
		if ($locale === null || $locale === '' || $locale === 'site-default') {
			if (did_action('after_setup_theme') && function_exists('determine_locale')) {
				$locale = determine_locale();
			} else {
				$locale = get_locale();
			}
		}

		if (function_exists('yooadmin_load_yooadmin_textdomain')) {
			yooadmin_load_yooadmin_textdomain((string) $locale);
			return;
		}

		if (!function_exists('load_textdomain') || !function_exists('unload_textdomain')) {
			return;
		}

		if (is_textdomain_loaded('yooadmin')) {
			unload_textdomain('yooadmin');
		}

		$mofile = function_exists('yooadmin_find_textdomain_mofile')
			? yooadmin_find_textdomain_mofile((string) $locale)
			: '';
		if ($mofile !== '') {
			load_textdomain('yooadmin', $mofile);
		}
	}
}

add_action(
	'admin_init',
	static function (): void {
		yooadmin_load_admin_ui_textdomain();
	},
	0
);

add_action(
	'admin_menu',
	static function (): void {
		yooadmin_load_admin_ui_textdomain();
	},
	0
);

add_action(
	'rest_api_init',
	static function (): void {
		if (is_user_logged_in()) {
			yooadmin_load_admin_ui_textdomain();
		}
	},
	0
);

if (!function_exists('yooadmin_with_admin_ui_locale')) {
	/**
	 * Run a callback under the current user's admin UI locale (REST/AJAX safe).
	 *
	 * @template T
	 * @param callable(): T $callback
	 * @return T
	 */
	function yooadmin_with_admin_ui_locale(callable $callback) {
		$switched = false;

		if (function_exists('switch_to_locale') && function_exists('yooadmin_get_admin_ui_locale')) {
			$locale = yooadmin_get_admin_ui_locale();
			if ($locale !== '' && $locale !== 'site-default') {
				switch_to_locale($locale);
				$switched = true;
			}
		}

		if (function_exists('yooadmin_load_admin_ui_textdomain')) {
			yooadmin_load_admin_ui_textdomain();
		}

		try {
			return $callback();
		} finally {
			if ($switched && function_exists('restore_previous_locale')) {
				restore_previous_locale();
			}
		}
	}
}

if (!function_exists('yooadmin_translate_admin_ui')) {
	/**
	 * Translate for the current user's admin UI language (not site default).
	 */
	function yooadmin_translate_admin_ui(string $text): string {
		if (!yooadmin_is_arabic_admin_ui()) {
			return $text;
		}

		if (!function_exists('switch_to_locale') || !function_exists('restore_previous_locale')) {
			// phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText -- Runtime admin UI string passed to locale-aware wrapper.
			return __($text, 'yooadmin');
		}

		$locale = yooadmin_get_admin_ui_locale();
		switch_to_locale($locale);
		yooadmin_load_admin_ui_textdomain($locale);
		// phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText -- Runtime admin UI string passed to locale-aware wrapper.
		$translated = __($text, 'yooadmin');
		restore_previous_locale();

		return $translated;
	}
}

add_filter(
	'admin_body_class',
	static function (string $classes): string {
		if (yooadmin_is_arabic_admin_ui()) {
			$classes .= ' yooadmin-arabic-ui';
		}

		return $classes;
	},
	15
);

if (!function_exists('yooadmin_get_admin_language_option_lang')) {
	function yooadmin_get_admin_language_option_lang(string $value): string {
		if ($value === '' || $value === 'en_US') {
			return 'en';
		}

		if ($value === 'site-default') {
			$site_locale = get_locale();

			return (is_string($site_locale) && strpos($site_locale, 'ar') === 0) ? 'ar' : 'en';
		}

		if (strpos($value, 'ar') === 0) {
			return 'ar';
		}

		return 'en';
	}
}

