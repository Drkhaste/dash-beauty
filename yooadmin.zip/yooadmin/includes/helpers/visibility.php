<?php
/**
 * YOOAdmin - Visibility rules (data-only)
 *
 * @package YOOAdmin
 * @since 1.0.0
 *
 * Option schema (yooadmin_visibility):
 *  [
 *    'version'        => 1,
 *    'default_policy' => 'allow_all' | 'deny_all',
 *    'rules'          => [
 *       '{key}' => [
 *          'policy' => 'allow_all' | 'deny_all' | 'inherit',
 *          'roles'  => ['administrator','shop_manager', ...],
 *          'users'  => [1, 25, 33]  // user IDs
 *       ],
 *       ...
 *    ],
 *  ]
 *
 * Evaluation logic:
 *  - If no rule for key -> use default_policy.
 *  - If rule.policy = allow_all -> visible.
 *  - If rule.policy = deny_all  -> hidden.
 *  - If rule.policy = inherit   -> visible if current user in rule.users OR has any role in rule.roles; otherwise default.
 *
 * @package   YOOAdminPanel
 * @since     1.0.0
 */

defined('ABSPATH') || exit;

// Text domain hardcoded as 'yooadmin' for WordPress.org compliance

/* ----------------------------------------------------------------------------
 * OPTION NAMES
 * ---------------------------------------------------------------------------- */

if (!defined('YOOADMIN_VISIBILITY_OPTION')) {
    define('YOOADMIN_VISIBILITY_OPTION', 'yooadmin_visibility');
}

// Optional legacy read-only import key (do not write to it)
if (!defined('YOOPIXEL_VISIBILITY_OPTION')) {
    define('YOOPIXEL_VISIBILITY_OPTION', 'yoopixel_admin_ui_visibility');
}

/* ----------------------------------------------------------------------------
 * DEFAULT SCHEMA
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_visibility_default')) {
    /**
     * Default schema for visibility settings.
     *
     * @return array
     */
    function yooadmin_visibility_default() {
        return [
            'version'        => 1,
            'default_policy' => 'allow_all', // allow_all | deny_all
            'rules'          => [
                // Example:
                // 'woocommerce' => ['policy' => 'inherit', 'roles' => ['shop_manager'], 'users' => []],
            ],
        ];
    }
}

/* ----------------------------------------------------------------------------
 * READ / MERGE (with legacy import if present)
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_visibility_get')) {
    /**
     * Get current visibility configuration.
     * Performs a best-effort import from legacy option if the new one is empty.
     *
     * @return array
     */
    function yooadmin_visibility_get() {
        $opt = get_option(YOOADMIN_VISIBILITY_OPTION, []);

        // Import from legacy once if new option empty
        if (empty($opt)) {
            $legacy = get_option(YOOPIXEL_VISIBILITY_OPTION, []);
            if (!empty($legacy) && is_array($legacy)) {
                $opt = [
                    'version'        => 1,
                    'default_policy' => isset($legacy['default']) ? (string) $legacy['default'] : 'allow_all',
                    'rules'          => isset($legacy['rules']) ? (array) $legacy['rules'] : [],
                ];
            }
        }

        // Merge with defaults; lock version to 1
        $opt = wp_parse_args($opt, 'yooadmin');
        $opt['version'] = 1;

        // Normalize types
        $opt['default_policy'] = in_array($opt['default_policy'], ['allow_all','deny_all'], true)
            ? $opt['default_policy']
            : 'allow_all';

        if (!is_array($opt['rules'])) {
            $opt['rules'] = [];
        } else {
            foreach ($opt['rules'] as $k => &$rule) {
                $rule = is_array($rule) ? $rule : [];
                $policy = isset($rule['policy']) ? (string) $rule['policy'] : 'inherit';
                $rule['policy'] = in_array($policy, ['allow_all','deny_all','inherit'], true) ? $policy : 'inherit';
                $rule['roles']  = array_values(array_filter(array_map('strval', (array) ($rule['roles'] ?? []))));
                $rule['users']  = array_values(array_filter(array_map('intval', (array) ($rule['users'] ?? []))));
            }
            unset($rule);
        }

        return $opt;
    }
}

/* ----------------------------------------------------------------------------
 * SAVE
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_visibility_set')) {
    /**
     * Persist visibility configuration (requires manage_options).
     *
     * @param array $schema
     * @return bool
     */
    function yooadmin_visibility_set(array $schema) {
        if (!current_user_can('manage_options')) {
            return false;
        }

        // Merge + normalize
        $schema = wp_parse_args($schema, 'yooadmin');
        $schema['version'] = 1;

        // Safety normalization (same as get)
        $schema['default_policy'] = in_array($schema['default_policy'], ['allow_all','deny_all'], true)
            ? $schema['default_policy']
            : 'allow_all';

        if (!is_array($schema['rules'])) {
            $schema['rules'] = [];
        } else {
            foreach ($schema['rules'] as $k => &$rule) {
                $rule = is_array($rule) ? $rule : [];
                $policy = isset($rule['policy']) ? (string) $rule['policy'] : 'inherit';
                $rule['policy'] = in_array($policy, ['allow_all','deny_all','inherit'], true) ? $policy : 'inherit';
                $rule['roles']  = array_values(array_filter(array_map('strval', (array) ($rule['roles'] ?? []))));
                $rule['users']  = array_values(array_filter(array_map('intval', (array) ($rule['users'] ?? []))));
            }
            unset($rule);
        }

        return update_option(YOOADMIN_VISIBILITY_OPTION, $schema, false);
    }
}

/* ----------------------------------------------------------------------------
 * EVALUATION
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_is_visible')) {
    /**
     * Decide if a given key should be visible for a user.
     *
     * @param string   $key     Menu/page/feature key (e.g., 'woocommerce', 'plugins.php', 'yooadmin-dashboard').
     * @param int|null $user_id Optional. Defaults to current user.
     * @return bool             true=show, false=hide.
     */
    function yooadmin_is_visible($key, $user_id = null) {
        $cfg  = yooadmin_visibility_get();

        // If missing key, fallback to default policy
        $rule = isset($cfg['rules'][$key]) ? (array) $cfg['rules'][$key] : null;
        $default = ($cfg['default_policy'] === 'deny_all') ? false : true;

        if (!$rule) {
            return $default;
        }

        $policy = isset($rule['policy']) ? (string) $rule['policy'] : 'inherit';

        if ($policy === 'allow_all') {
            return true;
        }
        if ($policy === 'deny_all') {
            return false;
        }

        // Inherit: evaluate by users/roles then fallback to default
        $user_id = $user_id ?: get_current_user_id();
        $user    = $user_id ? get_userdata($user_id) : null;
        $roles   = is_object($user) ? (array) ($user->roles ?? []) : [];

        $allowed_users = array_map('intval', (array) ($rule['users'] ?? []));
        $allowed_roles = array_map('strval', (array) ($rule['roles'] ?? []));

        if (!empty($allowed_users) && in_array((int) $user_id, $allowed_users, true)) {
            return true;
        }
        if (!empty($allowed_roles) && !empty(array_intersect($roles, $allowed_roles))) {
            return true;
        }

        return $default;
    }
}

