<?php
/**
 * Documents and asserts YOOAdmin REST route permission requirements.
 *
 * Audited routes (yooadmin/v1): all require authentication and an appropriate capability
 * except the license webhook, which validates HMAC / bearer tokens.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_rest_route_audit_manifest')) {
    /**
     * @return array<string, array{cap: string, note: string}>
     */
    function yooadmin_rest_route_audit_manifest(): array
    {
        return [
            '/yooadmin/v1/notifications'                    => ['cap' => 'logged_in+nonce', 'note' => 'YP notifications'],
            '/yooadmin/v1/notifications/feed'               => ['cap' => 'logged_in+nonce', 'note' => 'YP notifications feed'],
            '/yooadmin/v1/notifications/banner'             => ['cap' => 'logged_in+nonce', 'note' => 'Banner capture'],
            '/yooadmin/v1/notifications/counts'             => ['cap' => 'logged_in+nonce', 'note' => 'Counts'],
            '/yooadmin/v1/banner-notifications'              => ['cap' => 'manage_options', 'note' => 'Settings compatibility'],
            '/yooadmin/v1/settings'                         => ['cap' => 'manage_options', 'note' => 'Admin settings keys only'],
            '/yooadmin/v1/webhook'                          => ['cap' => 'signed_webhook', 'note' => 'License server webhook'],
            '/yooadmin/v1/studio-hub/layout'                => ['cap' => 'logged_in+layout_cap', 'note' => 'Studio Hub layout'],
            '/yooadmin/v1/studio-hub/layout/visibility'     => ['cap' => 'logged_in+layout_cap', 'note' => 'Studio Hub visibility'],
            '/yooadmin/v1/studio-hub/widgets'               => ['cap' => 'read', 'note' => 'Widget catalog'],
            '/yooadmin/v1/studio-hub/widgets/*/render'      => ['cap' => 'read', 'note' => 'Widget render'],
        ];
    }
}

if (!function_exists('yooadmin_rest_route_audit_assert_registered_permissions')) {
    /**
     * In debug mode, log YOOAdmin REST routes missing permission_callback.
     */
    function yooadmin_rest_route_audit_assert_registered_permissions(): void
    {
        if (!defined('WP_DEBUG') || !WP_DEBUG) {
            return;
        }

        $server = rest_get_server();
        if (!$server) {
            return;
        }

        $routes = $server->get_routes();
        foreach ($routes as $route => $handlers) {
            if (strpos($route, '/yooadmin/v1') !== 0) {
                continue;
            }

            if (!is_array($handlers)) {
                continue;
            }

            foreach ($handlers as $handler) {
                if (!is_array($handler)) {
                    continue;
                }

                if (!isset($handler['permission_callback'])) {
                    // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                    error_log('[YOOAdmin REST audit] Missing permission_callback on route: ' . $route);
                }
            }
        }
    }
}

add_action('rest_api_init', 'yooadmin_rest_route_audit_assert_registered_permissions', 9999);
