<?php
/**
 * Cloudflare Turnstile for YOOAdmin login (optional).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_login_turnstile_is_configured')) {
    /**
     * Site + secret keys saved and security toggle on.
     *
     * @return bool
     */
    function yooadmin_login_turnstile_is_configured(): bool
    {
        if (!function_exists('yooadmin_get_options')) {
            return false;
        }

        $opts = yooadmin_get_options();
        if (empty($opts['login_security_enabled'])) {
            return false;
        }

        $site = isset($opts['login_turnstile_site_key']) ? trim((string) $opts['login_turnstile_site_key']) : '';
        $secret = isset($opts['login_turnstile_secret_key']) ? trim((string) $opts['login_turnstile_secret_key']) : '';

        return $site !== '' && $secret !== '';
    }
}

if (!function_exists('yooadmin_login_turnstile_keys_gap_from_options')) {
    /**
     * Which Turnstile keys are missing (ignores login_security_enabled).
     *
     * @param array<string, mixed> $opts
     * @return 'none'|'site'|'secret'|'both'
     */
    function yooadmin_login_turnstile_keys_gap_from_options(array $opts): string
    {
        $site   = isset($opts['login_turnstile_site_key']) ? trim((string) $opts['login_turnstile_site_key']) : '';
        $secret = isset($opts['login_turnstile_secret_key']) ? trim((string) $opts['login_turnstile_secret_key']) : '';

        $has_site   = $site !== '';
        $has_secret = $secret !== '';

        if ($has_site && $has_secret) {
            return 'none';
        }
        if (!$has_site && !$has_secret) {
            return 'both';
        }

        return $has_site ? 'secret' : 'site';
    }
}

if (!function_exists('yooadmin_login_turnstile_keys_gap')) {
    /**
     * @return 'none'|'site'|'secret'|'both'
     */
    function yooadmin_login_turnstile_keys_gap(): string
    {
        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];

        return yooadmin_login_turnstile_keys_gap_from_options($opts);
    }
}

if (!function_exists('yooadmin_login_turnstile_keys_complete_in_options')) {
    /**
     * @param array<string, mixed> $opts
     */
    function yooadmin_login_turnstile_keys_complete_in_options(array $opts): bool
    {
        return yooadmin_login_turnstile_keys_gap_from_options($opts) === 'none';
    }
}

if (!function_exists('yooadmin_login_turnstile_preview_keys_after_form')) {
    /**
     * Keys as they would be after merging a settings form with stored options.
     *
     * @param array<string, mixed> $value    Submitted yooadmin_options fields.
     * @param array<string, mixed> $existing Stored options before merge.
     * @return array{site: string, secret: string}
     */
    function yooadmin_login_turnstile_preview_keys_after_form(array $value, array $existing): array
    {
        $site   = isset($existing['login_turnstile_site_key']) ? trim((string) $existing['login_turnstile_site_key']) : '';
        $secret = isset($existing['login_turnstile_secret_key']) ? trim((string) $existing['login_turnstile_secret_key']) : '';

        if (isset($value['login_turnstile_site_key'])) {
            $site_in = trim((string) $value['login_turnstile_site_key']);
            if ($site_in !== '') {
                $site = sanitize_text_field($site_in);
            }
        }

        if (isset($value['login_turnstile_secret_key'])) {
            $secret_in = trim((string) $value['login_turnstile_secret_key']);
            if ($secret_in !== '') {
                $secret = sanitize_text_field($secret_in);
            }
        }

        return [
            'site'   => $site,
            'secret' => $secret,
        ];
    }
}

if (!function_exists('yooadmin_login_security_effective_enabled')) {
    /**
     * Login security is only considered on when Turnstile keys are complete.
     *
     * @param array<string, mixed> $opts
     */
    function yooadmin_login_security_effective_enabled(array $opts): bool
    {
        return !empty($opts['login_security_enabled'])
            && yooadmin_login_turnstile_keys_complete_in_options($opts);
    }
}

if (!function_exists('yooadmin_login_turnstile_client_config')) {
    /**
     * Data for settings UI / AJAX validation scripts.
     *
     * @param array<string, mixed>|null $opts
     * @return array{keysComplete: bool, hasSecret: bool, gap: string, enableBlocked: string, saveBlocked: string}
     */
    function yooadmin_login_turnstile_client_config(?array $opts = null): array
    {
        if ($opts === null) {
            $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
        }

        $gap = yooadmin_login_turnstile_keys_gap_from_options($opts);
        $secret = isset($opts['login_turnstile_secret_key']) ? trim((string) $opts['login_turnstile_secret_key']) : '';

        return [
            'keysComplete'  => $gap === 'none',
            'hasSecret'     => $secret !== '',
            'gap'           => $gap,
            'enableBlocked' => __('Add both Turnstile keys (site and secret) before turning on login security.', 'yooadmin'),
            'saveBlocked'   => __('Add both Turnstile keys before enabling login security.', 'yooadmin'),
        ];
    }
}

if (!function_exists('yooadmin_login_turnstile_repair_inconsistent_options')) {
    /**
     * Persistently disable login security when keys were wiped but the toggle stayed on.
     */
    function yooadmin_login_turnstile_repair_inconsistent_options(): void
    {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        $opts = get_option('yooadmin_options', []);
        if (!is_array($opts) || empty($opts['login_security_enabled'])) {
            return;
        }

        if (yooadmin_login_turnstile_keys_complete_in_options($opts)) {
            return;
        }

        $opts['login_security_enabled']             = 0;
        $opts['login_turnstile_protect_lostpassword'] = 0;
        update_option('yooadmin_options', $opts, false);
        wp_cache_delete('yooadmin_options_' . get_current_user_id(), 'yooadmin_settings');
    }
}

add_action('admin_init', 'yooadmin_login_turnstile_repair_inconsistent_options', 5);

if (!function_exists('yooadmin_login_turnstile_is_wp_login_screen')) {
    /**
     * Whether the current request is rendering wp-login.php.
     *
     * @return bool
     */
    function yooadmin_login_turnstile_is_wp_login_screen(): bool
    {
        if (defined('WP_LOGIN') && WP_LOGIN) {
            return true;
        }

        global $pagenow;

        return isset($pagenow) && $pagenow === 'wp-login.php';
    }
}

if (!function_exists('yooadmin_login_turnstile_is_standalone_login_screen')) {
    /**
     * @return bool
     */
    function yooadmin_login_turnstile_is_standalone_login_screen(): bool
    {
        return function_exists('yooadmin_standalone_login_is_this_request')
            && yooadmin_standalone_login_is_this_request();
    }
}

if (!function_exists('yooadmin_login_turnstile_wp_login_enabled')) {
    /**
     * Turnstile on native wp-login.php (when login security is configured).
     *
     * @return bool
     */
    function yooadmin_login_turnstile_wp_login_enabled(): bool
    {
        if (!yooadmin_login_turnstile_is_configured()) {
            return false;
        }

        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];

        return !isset($opts['login_turnstile_wp_login']) || !empty($opts['login_turnstile_wp_login']);
    }
}

if (!function_exists('yooadmin_login_turnstile_standalone_enabled')) {
    /**
     * Turnstile on the YOOAdmin standalone login page.
     *
     * @return bool
     */
    function yooadmin_login_turnstile_standalone_enabled(): bool
    {
        if (!yooadmin_login_turnstile_is_configured()) {
            return false;
        }

        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];

        return !isset($opts['login_turnstile_standalone']) || !empty($opts['login_turnstile_standalone']);
    }
}

if (!function_exists('yooadmin_login_turnstile_is_login_request_context')) {
    /**
     * Login / lost-password / reset flows (classic POST, AJAX, or branded page).
     *
     * @return bool
     */
    function yooadmin_login_turnstile_is_login_request_context(): bool
    {
        if (yooadmin_login_turnstile_is_wp_login_screen()) {
            return yooadmin_login_turnstile_wp_login_enabled();
        }

        if (yooadmin_login_turnstile_is_standalone_login_screen()) {
            return yooadmin_login_turnstile_standalone_enabled();
        }

        if (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Action slug for routing only.
            $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash((string) $_REQUEST['action'])) : '';
            if (in_array($action, ['yooadmin_sl_login', 'yooadmin_sl_lostpassword', 'yooadmin_sl_resetpass'], true)) {
                return yooadmin_login_turnstile_standalone_enabled();
            }
        }

        /**
         * @param bool $apply Whether Turnstile applies to the current request.
         */
        return (bool) apply_filters('yooadmin_login_turnstile_is_login_request_context', false);
    }
}

if (!function_exists('yooadmin_login_turnstile_should_apply')) {
    /**
     * Server-side verification (independent of Focus Mode / custom login UI).
     *
     * @return bool
     */
    function yooadmin_login_turnstile_should_apply(): bool
    {
        if (!yooadmin_login_turnstile_is_configured()) {
            return false;
        }

        return yooadmin_login_turnstile_is_login_request_context();
    }
}

if (!function_exists('yooadmin_login_turnstile_should_render')) {
    /**
     * Show Turnstile UI on wp-login.php or the standalone login page when configured.
     *
     * @return bool
     */
    function yooadmin_login_turnstile_should_render(): bool
    {
        if (!yooadmin_login_turnstile_is_configured()) {
            return false;
        }

        if (yooadmin_login_turnstile_is_wp_login_screen()) {
            return yooadmin_login_turnstile_wp_login_enabled();
        }

        if (yooadmin_login_turnstile_is_standalone_login_screen()) {
            return yooadmin_login_turnstile_standalone_enabled();
        }

        return false;
    }
}

if (!function_exists('yooadmin_login_turnstile_should_render_wp_login')) {
    /**
     * @return bool
     */
    function yooadmin_login_turnstile_should_render_wp_login(): bool
    {
        return yooadmin_login_turnstile_should_render() && yooadmin_login_turnstile_is_wp_login_screen();
    }
}

if (!function_exists('yooadmin_login_turnstile_site_key')) {
    function yooadmin_login_turnstile_site_key(): string
    {
        if (!yooadmin_login_turnstile_is_configured()) {
            return '';
        }

        $opts = yooadmin_get_options();

        return trim((string) ($opts['login_turnstile_site_key'] ?? ''));
    }
}

if (!function_exists('yooadmin_login_turnstile_protect_lostpassword')) {
    function yooadmin_login_turnstile_protect_lostpassword(): bool
    {
        if (!yooadmin_login_turnstile_is_configured()) {
            return false;
        }

        $opts = yooadmin_get_options();

        return !isset($opts['login_turnstile_protect_lostpassword']) || !empty($opts['login_turnstile_protect_lostpassword']);
    }
}

if (!function_exists('yooadmin_login_turnstile_display_mode')) {
    /**
     * Turnstile widget presentation on the login form.
     *
     * @return string minimal|compact|standard
     */
    function yooadmin_login_turnstile_display_mode(): string
    {
        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
        $mode = isset($opts['login_turnstile_display']) ? sanitize_key((string) $opts['login_turnstile_display']) : 'minimal';

        if (!in_array($mode, ['minimal', 'compact', 'standard'], true)) {
            return 'minimal';
        }

        return $mode;
    }
}

if (!function_exists('yooadmin_login_turnstile_client_language')) {
    /**
     * Turnstile widget language code (ISO 639-1). See Cloudflare supported languages.
     *
     * @return string e.g. ar, en, en-US
     */
    function yooadmin_login_turnstile_client_language(): string
    {
        $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
        if (!is_string($locale) || $locale === '') {
            $locale = 'en_US';
        }

        $locale = str_replace('_', '-', $locale);
        $short  = strtolower(substr($locale, 0, 2));

        $language = $short;
        if ($short === 'en' && strpos($locale, '-') !== false) {
            $language = $locale;
        }

        /**
         * Filter Turnstile widget language for the login screen.
         *
         * @param string $language Cloudflare language code.
         * @param string $locale   WordPress locale.
         */
        return (string) apply_filters('yooadmin_login_turnstile_language', $language, $locale);
    }
}

if (!function_exists('yooadmin_login_turnstile_client_render_config')) {
    /**
     * Client-side Turnstile.render() options for the standalone login form.
     *
     * @return array{theme:string,size:string,appearance:string,language:string}
     */
    function yooadmin_login_turnstile_client_render_config(): array
    {
        $mode = yooadmin_login_turnstile_display_mode();
        $effective = function_exists('yooadmin_custom_login_resolve_effective_color_mode')
            ? yooadmin_custom_login_resolve_effective_color_mode()
            : 'light';
        $theme = ($effective === 'dark') ? 'dark' : 'light';
        $language = yooadmin_login_turnstile_client_language();

        if ($mode === 'standard') {
            return [
                'theme'      => $theme,
                'size'       => 'normal',
                'appearance' => 'always',
                'language'   => $language,
            ];
        }

        if ($mode === 'compact') {
            return [
                'theme'      => $theme,
                'size'       => 'normal',
                'appearance' => 'interaction-only',
                'language'   => $language,
            ];
        }

        return [
            'theme'      => $theme,
            'size'       => 'normal',
            'appearance' => 'interaction-only',
            'language'   => $language,
        ];
    }
}

if (!function_exists('yooadmin_login_turnstile_request_token')) {
    /**
     * Read Turnstile token from POST (AJAX or classic form).
     */
    function yooadmin_login_turnstile_request_token(): string
    {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Token read for captcha verify on login POST.
        if (!isset($_POST['cf-turnstile-response'])) {
            return '';
        }

        return sanitize_text_field(wp_unslash((string) $_POST['cf-turnstile-response']));
        // phpcs:enable WordPress.Security.NonceVerification.Missing
    }
}

if (!function_exists('yooadmin_login_turnstile_verify_token')) {
    /**
     * @param string $token Turnstile response token.
     * @return bool
     */
    function yooadmin_login_turnstile_verify_token(string $token): bool
    {
        if (!yooadmin_login_turnstile_is_configured()) {
            return true;
        }

        $token = trim($token);
        if ($token === '') {
            return false;
        }

        $opts = yooadmin_get_options();
        $secret = trim((string) ($opts['login_turnstile_secret_key'] ?? ''));
        if ($secret === '') {
            return false;
        }

        $body = [
            'secret'   => $secret,
            'response' => $token,
        ];

        if (function_exists('yooadmin_get_request_client_ip')) {
            $ip = yooadmin_get_request_client_ip();
            if ($ip !== '' && $ip !== '0.0.0.0') {
                $body['remoteip'] = $ip;
            }
        }

        $response = wp_remote_post(
            'https://challenges.cloudflare.com/turnstile/v0/siteverify',
            [
                'timeout' => 12,
                'body'    => $body,
            ]
        );

        if (is_wp_error($response)) {
            return false;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            return false;
        }

        $decoded = json_decode((string) wp_remote_retrieve_body($response), true);

        return is_array($decoded) && !empty($decoded['success']);
    }
}

if (!function_exists('yooadmin_login_turnstile_mark_verified')) {
    function yooadmin_login_turnstile_mark_verified(): void
    {
        if (!defined('YOOADMIN_LOGIN_TURNSTILE_OK')) {
            define('YOOADMIN_LOGIN_TURNSTILE_OK', true);
        }
    }
}

if (!function_exists('yooadmin_login_turnstile_is_verified')) {
    function yooadmin_login_turnstile_is_verified(): bool
    {
        return defined('YOOADMIN_LOGIN_TURNSTILE_OK') && YOOADMIN_LOGIN_TURNSTILE_OK;
    }
}

if (!function_exists('yooadmin_login_turnstile_verify_request_or_fail')) {
    /**
     * @return true|WP_Error
     */
    function yooadmin_login_turnstile_verify_request_or_fail()
    {
        if (!yooadmin_login_turnstile_should_apply()) {
            return true;
        }

        if (yooadmin_login_turnstile_is_verified()) {
            return true;
        }

        if (!yooadmin_login_turnstile_verify_token(yooadmin_login_turnstile_request_token())) {
            return new WP_Error(
                'yooadmin_turnstile_failed',
                __('Security verification failed. Please complete the challenge and try again.', 'yooadmin')
            );
        }

        yooadmin_login_turnstile_mark_verified();

        return true;
    }
}

if (!function_exists('yooadmin_login_turnstile_authenticate_check')) {
    /**
     * Block wp-login.php POST when Turnstile is required but missing/invalid.
     *
     * @param WP_User|WP_Error|null $user     User or error.
     * @param string                $username Username.
     * @param string                $password Password.
     * @return WP_User|WP_Error|null
     */
    function yooadmin_login_turnstile_authenticate_check($user, $username, $password)
    {
        if (!yooadmin_login_turnstile_should_apply()) {
            return $user;
        }

        if (yooadmin_login_turnstile_is_verified()) {
            return $user;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Login POST body.
        if (!isset($_POST['log'])) {
            return $user;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $check = yooadmin_login_turnstile_verify_request_or_fail();
        if (is_wp_error($check)) {
            return $check;
        }

        return $user;
    }
}

add_filter('authenticate', 'yooadmin_login_turnstile_authenticate_check', 25, 3);

if (!function_exists('yooadmin_login_turnstile_render_markup')) {
    /**
     * Turnstile status row + widget host (standalone + wp-login.php).
     *
     * @param string $context login|lostpassword|resetpass
     */
    function yooadmin_login_turnstile_render_markup(string $context): void
    {
        if (!yooadmin_login_turnstile_should_render() || yooadmin_login_turnstile_site_key() === '') {
            return;
        }

        $context = sanitize_key($context);
        if (!in_array($context, ['login', 'lostpassword', 'resetpass'], true)) {
            $context = 'login';
        }
        ?>
        <div class="yoo-sl-turnstile-wrap is-pending" data-yoo-turnstile-wrap="<?php echo esc_attr($context); ?>" data-yoo-turnstile-state="pending">
            <p class="yoo-sl-turnstile-status" role="status" aria-live="polite">
                <span class="yoo-sl-turnstile-status__icon dashicons dashicons-shield-alt" aria-hidden="true"></span>
                <span class="yoo-sl-turnstile-status__spinner" aria-hidden="true"></span>
                <span class="yoo-sl-turnstile-status__text" dir="auto"><?php esc_html_e('Security verification in progress…', 'yooadmin'); ?></span>
            </p>
            <div class="yoo-sl-turnstile-host">
                <span class="yoo-sl-turnstile" data-yoo-turnstile-context="<?php echo esc_attr($context); ?>" aria-hidden="false"></span>
            </div>
            <button type="button" class="yoo-sl-turnstile-retry" hidden>
                <?php esc_html_e('Try again', 'yooadmin'); ?>
            </button>
        </div>
        <?php
    }
}

if (!function_exists('yooadmin_login_turnstile_get_script_config')) {
    /**
     * Client config for yoo-standalone-login.js (Turnstile + optional AJAX).
     *
     * @param bool $include_ajax Include standalone AJAX login endpoints.
     * @return array<string, mixed>
     */
    function yooadmin_login_turnstile_get_script_config(bool $include_ajax = false): array
    {
        $config = [
            'turnstile' => [
                'enabled'             => yooadmin_login_turnstile_should_render() && yooadmin_login_turnstile_site_key() !== '',
                'siteKey'             => yooadmin_login_turnstile_site_key(),
                'protectLostPassword' => yooadmin_login_turnstile_protect_lostpassword(),
                'language'            => yooadmin_login_turnstile_client_language(),
                'render'              => yooadmin_login_turnstile_client_render_config(),
                'displayMode'         => yooadmin_login_turnstile_display_mode(),
            ],
            'i18n'    => [
                'captchaRequired'   => __('Please complete the security check.', 'yooadmin'),
                'securityChecking'  => __('Security verification in progress…', 'yooadmin'),
                'securityVerified'  => __('Security verification complete', 'yooadmin'),
                'securityFailed'    => __('Security verification failed. Please try again.', 'yooadmin'),
                'securityChallenge' => __('Please complete the security check below.', 'yooadmin'),
                'securityTimeout'   => __('Security check timed out. Try again or disable VPN/proxy.', 'yooadmin'),
                'securityBlocked'   => __('Security service could not load. Check your connection or VPN.', 'yooadmin'),
                'securityRetry'     => __('Try again', 'yooadmin'),
                'network'           => __('Network error. Please try again.', 'yooadmin'),
                'badResponse'       => __('Unexpected response. Please refresh the page.', 'yooadmin'),
                'dismiss'           => __('Dismiss', 'yooadmin'),
                'sessionExpired'    => __('Your session has expired. Please refresh the page and try again.', 'yooadmin'),
                'emptyUsername'     => __('The username field is empty.', 'yooadmin'),
                'emptyPassword'     => __('The password field is empty.', 'yooadmin'),
                'emptyResetUser'    => __('Enter a username or email address.', 'yooadmin'),
                'showPassword'      => __('Show password', 'yooadmin'),
                'hidePassword'      => __('Hide password', 'yooadmin'),
                'twoFactorRequired'  => __('Two-factor authentication required.', 'yooadmin'),
                'twoFactorVerify'    => __('Verify', 'yooadmin'),
                'twoFactorBack'      => __('Back to sign in', 'yooadmin'),
                'twoFactorExpired'   => __('Your verification session expired. Please sign in again.', 'yooadmin'),
                'twoFactorResent'    => __('A new verification code has been sent.', 'yooadmin'),
                'twoFactorResend'    => __('Resend code', 'yooadmin'),
                /* translators: %d: number of seconds to wait before the code can be resent. */
                'twoFactorResendWait'=> __('Resend code (%ds)', 'yooadmin'),
                'twoFactorCodeLabel' => __('Authentication code', 'yooadmin'),
                /* translators: 1: position of the current digit, 2: total number of digits. */
                'twoFactorDigit'     => __('Digit %1$d of %2$d', 'yooadmin'),
                'twoFactorIncomplete'=> __('Enter the full 6-digit code.', 'yooadmin'),
            ],
        ];

        if ($include_ajax) {
            $config['ajaxUrl'] = function_exists('yooadmin_admin_ajax_url')
                ? yooadmin_admin_ajax_url()
                : admin_url('admin-ajax.php');
            $config['nonce']   = wp_create_nonce('yooadmin_sl_ajax');
            $config['actions'] = [
                'login'             => 'yooadmin_sl_login',
                'lostpassword'      => 'yooadmin_sl_lostpassword',
                'resetpass'         => 'yooadmin_sl_resetpass',
                'validate_2fa'      => 'yooadmin_sl_validate_2fa',
                'two_factor_challenge' => 'yooadmin_sl_two_factor_challenge',
            ];
        }

        return $config;
    }
}

if (!function_exists('yooadmin_login_turnstile_wp_login_enqueue')) {
    function yooadmin_login_turnstile_wp_login_enqueue(): void
    {
        if (!yooadmin_login_turnstile_should_render_wp_login()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
        if ($base_file === '') {
            return;
        }

        $base_url = plugin_dir_url($base_file);
        $base_dir = plugin_dir_path($base_file);

        wp_enqueue_style('dashicons');

        $css_rel = 'assets/css/login/yoo-standalone-login.css';
        $css_abs = $base_dir . $css_rel;
        if (is_readable($css_abs)) {
            wp_enqueue_style(
                'yooadmin-wp-login-turnstile',
                $base_url . $css_rel,
                ['dashicons'],
                (string) filemtime($css_abs)
            );
            $inline = 'body.login{--yoo-login-primary:#eda934;--yoo-login-text:#0f172a;--yoo-login-panel-bg:#fff;}'
                . 'body.login #loginform.yoo-sl-form--awaiting-turnstile .submit input,'
                . 'body.login #lostpasswordform.yoo-sl-form--awaiting-turnstile .submit input,'
                . 'body.login #resetpassform.yoo-sl-form--awaiting-turnstile .submit input{opacity:.55;cursor:not-allowed;}';
            wp_add_inline_style('yooadmin-wp-login-turnstile', $inline);
        }

        $js_rel = 'assets/js/login/yoo-standalone-login.js';
        $js_abs = $base_dir . $js_rel;
        if (is_readable($js_abs)) {
            wp_enqueue_script(
                'yooadmin-wp-login-turnstile',
                $base_url . $js_rel,
                [],
                (string) filemtime($js_abs),
                true
            );
        }

        if (function_exists('yooadmin_enqueue_cloudflare_turnstile_script')) {
            yooadmin_enqueue_cloudflare_turnstile_script();
        }
    }
}

if (!function_exists('yooadmin_login_turnstile_wp_login_print_color_bootstrap')) {
    function yooadmin_login_turnstile_wp_login_print_color_bootstrap(): void
    {
        if (!yooadmin_login_turnstile_should_render_wp_login()) {
            return;
        }

        $mode = 'auto';
        if (function_exists('yooadmin_custom_login_get_color_mode')) {
            $mode = yooadmin_custom_login_get_color_mode();
        }
        if (!in_array($mode, ['light', 'dark', 'auto'], true)) {
            $mode = 'auto';
        }

        printf(
            '<script id="yooadmin-login-turnstile-color-mode">(function(){var m=%1$s;var eff="light";if(m==="dark"){eff="dark";}else if(m==="auto"){try{eff=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(e){eff="light";}}document.documentElement.setAttribute("data-yoo-login-color-mode",m);document.documentElement.setAttribute("data-yoo-login-color-mode-effective",eff);})();</script>' . "\n",
            wp_json_encode($mode)
        );
    }
}

if (!function_exists('yooadmin_login_turnstile_wp_login_print_script_config')) {
    function yooadmin_login_turnstile_wp_login_print_script_config(): void
    {
        if (!yooadmin_login_turnstile_should_render_wp_login()) {
            return;
        }

        echo '<script>window.yooadminSlAjax = '
            . wp_json_encode(
                yooadmin_login_turnstile_get_script_config(false),
                JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
            )
            . ';</script>' . "\n";
    }
}

if (!function_exists('yooadmin_login_turnstile_wp_login_render_login')) {
    function yooadmin_login_turnstile_wp_login_render_login(): void
    {
        yooadmin_login_turnstile_render_markup('login');
    }
}

if (!function_exists('yooadmin_login_turnstile_wp_login_render_lostpassword')) {
    function yooadmin_login_turnstile_wp_login_render_lostpassword(): void
    {
        if (!yooadmin_login_turnstile_protect_lostpassword()) {
            return;
        }

        yooadmin_login_turnstile_render_markup('lostpassword');
    }
}

if (!function_exists('yooadmin_login_turnstile_wp_login_render_resetpass')) {
    function yooadmin_login_turnstile_wp_login_render_resetpass(): void
    {
        yooadmin_login_turnstile_render_markup('resetpass');
    }
}

if (!function_exists('yooadmin_login_turnstile_lostpassword_post_check')) {
    /**
     * @param WP_Error      $errors     Error container.
     * @param WP_User|false $user_data  User object or false.
     */
    function yooadmin_login_turnstile_lostpassword_post_check($errors, $user_data): void
    {
        unset($user_data);

        if (!yooadmin_login_turnstile_protect_lostpassword() || !yooadmin_login_turnstile_should_apply()) {
            return;
        }

        if (!is_wp_error($errors)) {
            return;
        }

        $check = yooadmin_login_turnstile_verify_request_or_fail();
        if (is_wp_error($check)) {
            $errors->add('yooadmin_turnstile_failed', $check->get_error_message());
        }
    }
}

if (!function_exists('yooadmin_login_turnstile_wp_login_body_class')) {
    /**
     * @param string[] $classes Login body classes.
     * @return string[]
     */
    function yooadmin_login_turnstile_wp_login_body_class(array $classes): array
    {
        if (yooadmin_login_turnstile_should_render_wp_login()) {
            $classes[] = 'yooadmin-wp-login-turnstile';
        }

        return $classes;
    }
}

if (!function_exists('yooadmin_login_turnstile_wp_login_bootstrap')) {
    function yooadmin_login_turnstile_wp_login_bootstrap(): void
    {
        if (!yooadmin_login_turnstile_should_render_wp_login()) {
            return;
        }

        add_action('login_enqueue_scripts', 'yooadmin_login_turnstile_wp_login_enqueue', 20);
        add_action('login_head', 'yooadmin_login_turnstile_wp_login_print_color_bootstrap', 5);
        add_action('login_footer', 'yooadmin_login_turnstile_wp_login_print_script_config', 1);
        add_action('login_form', 'yooadmin_login_turnstile_wp_login_render_login', 50);
        add_action('lostpassword_form', 'yooadmin_login_turnstile_wp_login_render_lostpassword', 50);
        add_action('resetpass_form', 'yooadmin_login_turnstile_wp_login_render_resetpass', 50);
        add_filter('login_body_class', 'yooadmin_login_turnstile_wp_login_body_class', 20, 1);
    }
}

if (!function_exists('yooadmin_wp_login_security_footer_should_show')) {
    /**
     * Show YOOAdmin security attribution on wp-login.php when a scoped feature is active.
     *
     * @return bool
     */
    function yooadmin_wp_login_security_footer_should_show(): bool
    {
        if (!yooadmin_login_turnstile_is_wp_login_screen()) {
            return false;
        }

        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];

        $turnstile = yooadmin_login_turnstile_is_configured() && yooadmin_login_turnstile_wp_login_enabled();
        $rate_limit = !empty($opts['login_rate_limit_enabled'])
            && (!isset($opts['login_rate_limit_wp_login']) || !empty($opts['login_rate_limit_wp_login']));

        return $turnstile || $rate_limit;
    }
}

if (!function_exists('yooadmin_wp_login_security_footer_url')) {
    /**
     * @return string
     */
    function yooadmin_wp_login_security_footer_url(): string
    {
        $url = defined('YOOADMIN_SITE_URL') ? (string) YOOADMIN_SITE_URL : 'https://www.yooadmin.io';

        /**
         * @param string $url Footer link target for YOOAdmin branding on wp-login.php.
         */
        return (string) apply_filters('yooadmin_wp_login_security_footer_url', $url);
    }
}

if (!function_exists('yooadmin_wp_login_render_security_footer')) {
    /**
     * Footer credit on wp-login.php when YOOAdmin login security is active.
     */
    function yooadmin_wp_login_render_security_footer(): void
    {
        if (!yooadmin_wp_login_security_footer_should_show()) {
            return;
        }

        $brand = 'YOOAdmin';
        $link  = yooadmin_wp_login_security_footer_url();
        $text  = sprintf(
            /* translators: %s: YOOAdmin brand name (linked). */
            __('Login security provided by %s', 'yooadmin'),
            '<a class="yoo-wp-login-security-footer__brand" href="' . esc_url($link) . '" target="_blank" rel="noopener noreferrer">' . esc_html($brand) . '</a>'
        );
        ?>
        <div class="yoo-wp-login-security-footer" role="contentinfo">
            <p class="yoo-wp-login-security-footer__line">
                <span class="yoo-wp-login-security-footer__icon dashicons dashicons-shield-alt" aria-hidden="true"></span>
                <span class="yoo-wp-login-security-footer__text"><?php echo wp_kses($text, ['a' => ['class' => [], 'href' => [], 'target' => [], 'rel' => []]]); ?></span>
            </p>
        </div>
        <?php
    }
}

if (!function_exists('yooadmin_wp_login_security_footer_bootstrap')) {
    function yooadmin_wp_login_security_footer_bootstrap(): void
    {
        if (!yooadmin_login_turnstile_is_wp_login_screen()) {
            return;
        }

        add_action('login_footer', 'yooadmin_wp_login_render_security_footer', 12);

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
        if ($base_file === '') {
            return;
        }

        add_action('login_enqueue_scripts', static function () use ($base_file): void {
            if (!yooadmin_wp_login_security_footer_should_show()) {
                return;
            }

            $base_url = plugin_dir_url($base_file);
            $base_dir = plugin_dir_path($base_file);
            $css_rel  = 'assets/css/login/yoo-standalone-login.css';
            $css_abs  = $base_dir . $css_rel;
            if (!is_readable($css_abs)) {
                return;
            }

            wp_enqueue_style('dashicons');
            if (!wp_style_is('yooadmin-wp-login-turnstile', 'enqueued')) {
                wp_enqueue_style(
                    'yooadmin-wp-login-security-footer',
                    $base_url . $css_rel,
                    ['dashicons'],
                    (string) filemtime($css_abs)
                );
            }
        }, 19);
    }
}

add_action('login_init', 'yooadmin_login_turnstile_wp_login_bootstrap', 5);
add_action('login_init', 'yooadmin_wp_login_security_footer_bootstrap', 5);
add_action('lostpassword_post', 'yooadmin_login_turnstile_lostpassword_post_check', 0, 2);

if (!function_exists('yooadmin_login_turnstile_validate_password_reset_check')) {
    /**
     * Block wp-login.php reset-password POST when Turnstile is required but missing/invalid.
     *
     * @param WP_Error      $errors Error container.
     * @param WP_User|false $user   User object or false.
     */
    function yooadmin_login_turnstile_validate_password_reset_check($errors, $user): void
    {
        unset($user);

        if (!yooadmin_login_turnstile_should_apply()) {
            return;
        }

        if (!is_wp_error($errors)) {
            return;
        }

        $check = yooadmin_login_turnstile_verify_request_or_fail();
        if (is_wp_error($check)) {
            $errors->add('yooadmin_turnstile_failed', $check->get_error_message());
        }
    }
}

add_action('validate_password_reset', 'yooadmin_login_turnstile_validate_password_reset_check', 0, 2);
