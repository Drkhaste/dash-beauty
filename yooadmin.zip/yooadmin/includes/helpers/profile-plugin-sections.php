<?php
/**
 * YOOAdmin custom profile — render third-party profile sections (e.g. Two-Factor).
 *
 * WordPress plugins register settings on show_user_profile / edit_user_profile.
 * The YOOAdmin profile template is standalone, so those hooks must be fired explicitly.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Profile URL on the YOOAdmin users screen.
 */
function yooadmin_profile_plugin_sections_url(int $user_id): string {
    if (function_exists('yooadmin_profile_page_url')) {
        return yooadmin_profile_page_url($user_id);
    }

    $args = ['page' => 'yooadmin-user'];
    if ($user_id > 0 && $user_id !== get_current_user_id()) {
        $args['user_id'] = $user_id;
    }

    return add_query_arg($args, admin_url('admin.php'));
}

/**
 * Deep-linkable profile tab URL.
 *
 * @param int    $user_id Profile user ID.
 * @param string $tab_key Tab key (account, password, security, sessions).
 */
function yooadmin_profile_tab_url(int $user_id, string $tab_key): string {
    $tab_key = sanitize_key($tab_key);
    $url     = yooadmin_profile_plugin_sections_url($user_id);

    if ($tab_key === '' || $tab_key === 'account') {
        return $url;
    }

    return add_query_arg('profile_tab', $tab_key, $url);
}

if (!function_exists('yooadmin_profile_2fa_revalidated_result_url')) {
    /**
     * Profile URL after successful 2FA revalidation (flash flag for toast UI).
     */
    function yooadmin_profile_2fa_revalidated_result_url(string $redirect_to = ''): string {
        if ($redirect_to === '') {
            $user_id = get_current_user_id();
            $redirect_to = $user_id > 0 && function_exists('yooadmin_profile_tab_url')
                ? yooadmin_profile_tab_url($user_id, 'security')
                : admin_url();
        }

        $redirect_to = wp_validate_redirect($redirect_to, admin_url());

        return add_query_arg('yooadmin_2fa_revalidated', '1', $redirect_to);
    }
}

/**
 * Whether the user is on an external 2FA system.
 */
function yooadmin_profile_user_has_external_2fa(WP_User $user): bool {
    if (class_exists('YOOAdmin_2FA_Core')) {
        return YOOAdmin_2FA_Core::user_has_external_2fa($user->ID);
    }

    if (function_exists('yooadmin_profile_two_factor_is_available') && yooadmin_profile_two_factor_is_available()) {
        return Two_Factor_Core::is_user_using_two_factor($user->ID);
    }

    return false;
}

/**
 * Whether a profile hook has at least one callback outside the skipped classes.
 *
 * @param string   $hook         Hook name.
 * @param string[] $skip_classes Class names to ignore.
 * @param WP_User  $user         Profile user.
 */
function yooadmin_profile_hook_has_non_skipped_callbacks(string $hook, array $skip_classes, WP_User $user): bool {
    global $wp_filter;

    if (!isset($wp_filter[$hook]) || !($wp_filter[$hook] instanceof WP_Hook)) {
        return false;
    }

    $callbacks = $wp_filter[$hook]->callbacks ?? [];
    if (!is_array($callbacks)) {
        return false;
    }

    foreach ($callbacks as $hooks) {
        if (!is_array($hooks)) {
            continue;
        }
        foreach ($hooks as $registered) {
            $callable = $registered['function'] ?? null;
            if (!is_callable($callable)) {
                continue;
            }

            $class  = '';
            $method = '';
            if (is_array($callable) && isset($callable[0], $callable[1])) {
                $class = is_object($callable[0]) ? get_class($callable[0]) : (string) $callable[0];
                $method = (string) $callable[1];
                if (in_array($class, $skip_classes, true)) {
                    continue;
                }
            }

            /** @var bool $skip_callback */
            $skip_callback = (bool) apply_filters(
                'yooadmin_profile_skip_plugin_section_callback',
                false,
                $callable,
                $class,
                $method,
                $user
            );
            if ($skip_callback) {
                continue;
            }

            return true;
        }
    }

    return false;
}

/**
 * Whether non-2FA third-party profile hooks would render in the Security tab.
 *
 * @param WP_User $user Profile user.
 */
function yooadmin_profile_has_third_party_security_hooks(WP_User $user): bool {
    if (!function_exists('yooadmin_profile_avatar_wp_hooks_in_security_tab')
        || !yooadmin_profile_avatar_wp_hooks_in_security_tab($user->ID)) {
        return false;
    }

    $skip_classes = ['Two_Factor_Core'];
    if (function_exists('yooadmin_profile_avatar_plugin_skip_classes')) {
        $skip_classes = array_values(array_unique(array_merge(
            $skip_classes,
            yooadmin_profile_avatar_plugin_skip_classes()
        )));
    }

    $is_own_profile = ($user->ID === get_current_user_id());
    $hooks          = $is_own_profile ? ['show_user_profile'] : ['edit_user_profile'];

    foreach ($hooks as $hook) {
        if (yooadmin_profile_hook_has_non_skipped_callbacks($hook, $skip_classes, $user)) {
            return true;
        }
    }

    return false;
}

/**
 * Whether plugin profile sections should render for this user.
 *
 * @param WP_User $user Profile user.
 */
function yooadmin_profile_has_plugin_sections(WP_User $user): bool {
    if (!($user instanceof WP_User) || $user->ID <= 0) {
        return false;
    }

    if (!current_user_can('edit_user', $user->ID)) {
        return false;
    }

    $has = yooadmin_profile_should_render_two_factor_sections($user)
        || yooadmin_profile_has_third_party_security_hooks($user);

    /** @var bool $has */
    return (bool) apply_filters('yooadmin_profile_has_plugin_sections', $has, $user);
}

/**
 * Core WordPress profile URL (profile.php / user-edit.php).
 *
 * @param int $user_id Profile user ID.
 */
function yooadmin_wp_core_profile_url(int $user_id): string {
    if ($user_id <= 0 || $user_id === get_current_user_id()) {
        return admin_url('profile.php');
    }

    return admin_url('user-edit.php?user_id=' . $user_id);
}

/**
 * Whether YOOAdmin should render its two-factor profile UI for this user.
 *
 * @param WP_User $user Profile user.
 */
function yooadmin_profile_should_render_two_factor_sections(WP_User $user): bool {
    if (!($user instanceof WP_User) || $user->ID <= 0) {
        return false;
    }

    if (!current_user_can('edit_user', $user->ID)) {
        return false;
    }

    $show_native = class_exists('YOOAdmin_2FA_Core') && YOOAdmin_2FA_Core::should_show_native_profile($user);
    $show_wp_tf  = function_exists('yooadmin_profile_two_factor_is_available')
        && yooadmin_profile_two_factor_is_available()
        && yooadmin_profile_user_has_external_2fa($user);

    return $show_native || $show_wp_tf;
}

/**
 * Render YOOAdmin two-factor profile sections.
 *
 * @param WP_User $user           User being edited.
 * @param bool    $is_own_profile Own profile vs editing another user.
 */
function yooadmin_profile_render_two_factor_sections(WP_User $user, bool $is_own_profile): bool {
    if (!yooadmin_profile_should_render_two_factor_sections($user)) {
        return false;
    }

    $external_2fa = yooadmin_profile_user_has_external_2fa($user);
    $show_native  = class_exists('YOOAdmin_2FA_Core') && YOOAdmin_2FA_Core::should_show_native_profile($user);

    if ($external_2fa) {
        if (function_exists('yooadmin_profile_two_factor_is_available') && yooadmin_profile_two_factor_is_available()) {
            if (function_exists('yooadmin_profile_two_factor_render')) {
                yooadmin_profile_two_factor_render($user, $is_own_profile);
                return true;
            }
        }
    }

    if ($show_native && function_exists('yooadmin_native_2fa_profile_render')) {
        yooadmin_native_2fa_profile_render($user, $is_own_profile);
        return true;
    }

    return false;
}

/**
 * Prepare profile context constants used by legacy profile plugins.
 *
 * @param bool $is_own_profile Whether this is the current user's profile.
 */
function yooadmin_profile_plugin_sections_prepare_context(bool $is_own_profile): void {
    if ($is_own_profile && !defined('IS_PROFILE_PAGE')) {
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- Intentionally sets the WordPress core constant so legacy profile plugins behave correctly on the custom profile screen.
        define('IS_PROFILE_PAGE', true);
    }
}

/**
 * Render registered third-party profile sections.
 *
 * @param WP_User $user           User being edited.
 * @param bool    $is_own_profile Own profile vs editing another user.
 */
function yooadmin_profile_render_plugin_sections(WP_User $user, bool $is_own_profile): void {
    if (!yooadmin_profile_has_plugin_sections($user)) {
        return;
    }

    yooadmin_profile_plugin_sections_prepare_context($is_own_profile);

    /**
     * Fires before third-party profile sections are rendered on the YOOAdmin profile page.
     *
     * @param WP_User $user           User being edited.
     * @param bool    $is_own_profile Own profile screen.
     */
    do_action('yooadmin_profile_before_plugin_sections', $user, $is_own_profile);

    yooadmin_profile_render_two_factor_sections($user, $is_own_profile);

    $skip_hooks = ['Two_Factor_Core'];
    $run_wp_hooks = !function_exists('yooadmin_profile_avatar_wp_hooks_in_security_tab')
        || yooadmin_profile_avatar_wp_hooks_in_security_tab($user->ID);

    if ($run_wp_hooks) {
        if ($is_own_profile) {
            yooadmin_profile_plugin_sections_run_profile_hooks('show_user_profile', $user, $skip_hooks);
        } else {
            yooadmin_profile_plugin_sections_run_profile_hooks('edit_user_profile', $user, $skip_hooks);
        }
    }

    /**
     * Fires after third-party profile sections are rendered on the YOOAdmin profile page.
     *
     * @param WP_User $user           User being edited.
     * @param bool    $is_own_profile Own profile screen.
     */
    do_action('yooadmin_profile_after_plugin_sections', $user, $is_own_profile);
}

/**
 * Persist third-party profile section submissions (e.g. Two-Factor provider toggles).
 *
 * @param int  $user_id          User ID.
 * @param bool $is_own_profile   Own profile vs editing another user.
 */
function yooadmin_profile_save_plugin_sections(int $user_id, bool $is_own_profile): void {
    if ($user_id <= 0 || !current_user_can('edit_user', $user_id)) {
        return;
    }

    if ($is_own_profile) {
        // Core hooks send_confirmation_on_profile_email() on personal_options_update and
        // expects $_POST['user_id'] — absent on the YOOAdmin security-only form.
        remove_action('personal_options_update', 'send_confirmation_on_profile_email');
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Firing the WordPress core hook so third-party profile plugins save their fields.
        do_action('personal_options_update', $user_id);
        add_action('personal_options_update', 'send_confirmation_on_profile_email');
    } else {
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Firing the WordPress core hook so third-party profile plugins save their fields.
        do_action('edit_user_profile_update', $user_id);
    }
}

/**
 * Enqueue assets commonly required by profile security plugins.
 */
function yooadmin_profile_enqueue_plugin_section_assets(): void {
    if (!function_exists('wp_enqueue_script')) {
        return;
    }

    wp_enqueue_script('wp-api-request');
    wp_enqueue_script('wp-api');

    if (function_exists('yooadmin_native_2fa_profile_enqueue_assets')) {
        yooadmin_native_2fa_profile_enqueue_assets();
    }

    if (function_exists('yooadmin_profile_two_factor_enqueue_assets')) {
        yooadmin_profile_two_factor_enqueue_assets();
    }
}

/**
 * Whether a profile hook has a callback from one of the given class names.
 *
 * @param string   $hook    Hook name.
 * @param string[] $classes Class names to match exactly.
 */
function yooadmin_profile_hook_has_callback_class(string $hook, array $classes): bool {
    global $wp_filter;

    if ($classes === [] || !isset($wp_filter[$hook]) || !($wp_filter[$hook] instanceof WP_Hook)) {
        return false;
    }

    $callbacks = $wp_filter[$hook]->callbacks ?? [];
    if (!is_array($callbacks)) {
        return false;
    }

    foreach ($callbacks as $hooks) {
        if (!is_array($hooks)) {
            continue;
        }
        foreach ($hooks as $registered) {
            $callable = $registered['function'] ?? null;
            if (!is_array($callable) || !isset($callable[0])) {
                continue;
            }

            $class = is_object($callable[0]) ? get_class($callable[0]) : (string) $callable[0];
            if (in_array($class, $classes, true)) {
                return true;
            }
        }
    }

    return false;
}

/**
 * Run profile hooks while skipping classes rendered by YOOAdmin.
 *
 * @param string   $hook          Hook name.
 * @param WP_User  $user          Profile user.
 * @param string[] $skip_classes  Class names to skip.
 * @param string[] $allow_classes When non-empty, only callbacks from these classes run.
 */
function yooadmin_profile_plugin_sections_run_profile_hooks(
    string $hook,
    WP_User $user,
    array $skip_classes,
    array $allow_classes = []
): void {
    global $wp_filter;

    if (!isset($wp_filter[$hook]) || !($wp_filter[$hook] instanceof WP_Hook)) {
        return;
    }

    $callbacks = $wp_filter[$hook]->callbacks ?? [];
    if (!is_array($callbacks)) {
        return;
    }

    foreach ($callbacks as $priority => $hooks) {
        if (!is_array($hooks)) {
            continue;
        }
        foreach ($hooks as $registered) {
            $callable = $registered['function'] ?? null;
            if (!is_callable($callable)) {
                continue;
            }

            $class  = '';
            $method = '';
            if (is_array($callable) && isset($callable[0], $callable[1])) {
                $class = is_object($callable[0]) ? get_class($callable[0]) : (string) $callable[0];
                $method = (string) $callable[1];
                if (in_array($class, $skip_classes, true)) {
                    continue;
                }
                if ($allow_classes !== [] && !in_array($class, $allow_classes, true)) {
                    continue;
                }
            } elseif ($allow_classes !== []) {
                continue;
            }

            /** @var bool $skip_callback */
            $skip_callback = (bool) apply_filters(
                'yooadmin_profile_skip_plugin_section_callback',
                false,
                $callable,
                $class,
                $method,
                $user
            );
            if ($skip_callback) {
                continue;
            }

            call_user_func($callable, $user);
        }
    }
}

/**
 * Point legacy profile.php / user-edit.php links to the YOOAdmin profile screen.
 *
 * @param string      $url    Complete URL.
 * @param string      $path   Path relative to the site URL.
 * @param string|null $scheme Scheme.
 */
function yooadmin_profile_plugin_sections_filter_self_admin_url($url, $path, $scheme = null): string {
    unset($scheme);

    $path = (string) $path;
    if ($path !== 'profile.php' && strpos($path, 'user-edit.php') !== 0) {
        return (string) $url;
    }

    if (!is_admin()) {
        return (string) $url;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Profile context detection.
    $user_id = isset($_GET['user_id']) ? absint(wp_unslash((string) $_GET['user_id'])) : 0;
    $on_yoo_profile = isset($_GET['page']) && sanitize_key(wp_unslash((string) $_GET['page'])) === 'yooadmin-user';
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    if (!$on_yoo_profile && $path === 'profile.php' && is_user_logged_in()) {
        $user_id = get_current_user_id();
        return yooadmin_profile_plugin_sections_url($user_id);
    }

    if (!$on_yoo_profile) {
        return (string) $url;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Profile user id from query.
    if ($user_id <= 0) {
        $user_id = get_current_user_id();
    }

    return yooadmin_profile_plugin_sections_url($user_id);
}
add_filter('self_admin_url', 'yooadmin_profile_plugin_sections_filter_self_admin_url', 20, 3);

/**
 * Render two-factor settings on core profile.php / user-edit.php when users redirect is off.
 *
 * @param WP_User $user Profile user.
 */
function yooadmin_wp_core_profile_render_two_factor_sections(WP_User $user): void {
    if (function_exists('yooadmin_profile_uses_yooadmin_profile_page') && yooadmin_profile_uses_yooadmin_profile_page()) {
        return;
    }

    if (!yooadmin_profile_should_render_two_factor_sections($user)) {
        return;
    }

    global $pagenow;

    $is_own_profile = ($pagenow === 'profile.php');

    yooadmin_profile_plugin_sections_prepare_context($is_own_profile);

    echo '<div class="yoo-wp-core-profile-2fa yoo-profile-plugin-sections yooadmin-user-profile">';
    echo '<div class="yoo-profile-plugin-section">';
    echo '<div class="yoo-profile-plugin-section__body">';
    echo '<h2 id="yooadmin-two-factor-auth">';
    esc_html_e('Two-Factor Authentication', 'yooadmin');
    echo '</h2>';
    yooadmin_profile_render_two_factor_sections($user, $is_own_profile);
    echo '</div></div></div>';
}
add_action('show_user_profile', 'yooadmin_wp_core_profile_render_two_factor_sections', 15);
add_action('edit_user_profile', 'yooadmin_wp_core_profile_render_two_factor_sections', 15);

/**
 * Avoid duplicate two-factor UI from the WordPress Two-Factor plugin on core profile screens.
 */
function yooadmin_wp_core_profile_suppress_wordpress_two_factor_duplicates(): void {
    if (!is_admin() || !class_exists('Two_Factor_Core')) {
        return;
    }

    if (function_exists('yooadmin_profile_uses_yooadmin_profile_page') && yooadmin_profile_uses_yooadmin_profile_page()) {
        return;
    }

    global $pagenow;

    if ($pagenow !== 'profile.php' && $pagenow !== 'user-edit.php') {
        return;
    }

    $user_id = ($pagenow === 'profile.php') ? get_current_user_id() : 0;
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only profile user id from URL.
    if ($user_id <= 0 && isset($_GET['user_id'])) {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only profile user id from URL.
        $user_id = absint(wp_unslash((string) $_GET['user_id']));
    }

    $user = $user_id > 0 ? get_user_by('id', $user_id) : false;
    if (!($user instanceof WP_User) || !yooadmin_profile_should_render_two_factor_sections($user)) {
        return;
    }

    remove_action('show_user_profile', ['Two_Factor_Core', 'user_two_factor_options']);
    remove_action('edit_user_profile', ['Two_Factor_Core', 'user_two_factor_options']);
    remove_action('personal_options_update', ['Two_Factor_Core', 'user_two_factor_options_update']);
    remove_action('edit_user_profile_update', ['Two_Factor_Core', 'user_two_factor_options_update']);
}
add_action('admin_init', 'yooadmin_wp_core_profile_suppress_wordpress_two_factor_duplicates', 20);

/**
 * Enqueue two-factor assets on core profile screens.
 *
 * @param string $hook_suffix Current admin page hook suffix.
 */
function yooadmin_wp_core_profile_enqueue_two_factor_assets(string $hook_suffix): void {
    if (!in_array($hook_suffix, ['profile.php', 'user-edit.php'], true)) {
        return;
    }

    if (function_exists('yooadmin_profile_uses_yooadmin_profile_page') && yooadmin_profile_uses_yooadmin_profile_page()) {
        return;
    }

    $user_id = ($hook_suffix === 'profile.php') ? get_current_user_id() : 0;
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only profile user id from URL.
    if ($user_id <= 0 && isset($_GET['user_id'])) {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only profile user id from URL.
        $user_id = absint(wp_unslash((string) $_GET['user_id']));
    }

    $user = $user_id > 0 ? get_user_by('id', $user_id) : false;
    if (!($user instanceof WP_User) || !yooadmin_profile_should_render_two_factor_sections($user)) {
        return;
    }

    yooadmin_profile_enqueue_plugin_section_assets();
    yooadmin_wp_core_profile_enqueue_users_page_script();
}

/**
 * Tooltip positioning and other profile helpers on core profile screens.
 */
function yooadmin_wp_core_profile_enqueue_users_page_script(): void {
    $base = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
    if ($base === '') {
        return;
    }

    $js_path = plugin_dir_path($base) . 'assets/js/admin/users-page.js';
    if (!is_readable($js_path)) {
        return;
    }

    if (wp_script_is('yooadmin-users', 'enqueued') || wp_script_is('yooadmin-users', 'done')) {
        return;
    }

    wp_enqueue_script(
        'yooadmin-users',
        plugin_dir_url($base) . 'assets/js/admin/users-page.js',
        ['jquery'],
        (string) filemtime($js_path),
        true
    );
}
add_action('admin_enqueue_scripts', 'yooadmin_wp_core_profile_enqueue_two_factor_assets');
