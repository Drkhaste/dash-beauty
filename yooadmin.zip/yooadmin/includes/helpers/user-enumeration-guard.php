<?php
/**
 * Optional protection against WordPress user / author enumeration.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_user_enum_get_opts')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_user_enum_get_opts(): array
    {
        if (function_exists('yooadmin_get_options')) {
            return yooadmin_get_options();
        }

        $opts = get_option('yooadmin_options', []);

        return is_array($opts) ? $opts : [];
    }
}

if (!function_exists('yooadmin_prevent_user_enumeration_is_enabled')) {
    function yooadmin_prevent_user_enumeration_is_enabled(): bool
    {
        $opts = yooadmin_user_enum_get_opts();

        return !empty($opts['login_prevent_user_enumeration']);
    }
}

if (!function_exists('yooadmin_user_enum_author_archive_mode')) {
    /**
     * @return string redirect_home|disable_404
     */
    function yooadmin_user_enum_author_archive_mode(): string
    {
        $opts = yooadmin_user_enum_get_opts();
        $mode = isset($opts['login_user_enum_author_archives'])
            ? sanitize_key((string) $opts['login_user_enum_author_archives'])
            : 'redirect_home';

        return in_array($mode, ['redirect_home', 'disable_404'], true) ? $mode : 'redirect_home';
    }
}

if (!function_exists('yooadmin_user_enum_hide_rss_author_enabled')) {
    function yooadmin_user_enum_hide_rss_author_enabled(): bool
    {
        if (!yooadmin_prevent_user_enumeration_is_enabled()) {
            return false;
        }

        $opts = yooadmin_user_enum_get_opts();

        return !isset($opts['login_user_enum_hide_rss_author']) || !empty($opts['login_user_enum_hide_rss_author']);
    }
}

if (!function_exists('yooadmin_user_enum_filter_feed_author')) {
    /**
     * @param string $author Author display name.
     * @return string
     */
    function yooadmin_user_enum_filter_feed_author(string $author): string
    {
        if (!yooadmin_user_enum_hide_rss_author_enabled() || !is_feed()) {
            return $author;
        }

        return '';
    }
}

if (!function_exists('yooadmin_user_enum_stats_option_key')) {
    function yooadmin_user_enum_stats_option_key(): string
    {
        return 'yooadmin_user_enum_block_stats';
    }
}

if (!function_exists('yooadmin_user_enum_stats_default')) {
    /**
     * @return array{total:int,by_type:array<string,int>,since:int,last_at:int}
     */
    function yooadmin_user_enum_stats_default(): array
    {
        $now = time();

        return [
            'total'   => 0,
            'by_type' => [],
            'since'   => $now,
            'last_at' => 0,
        ];
    }
}

if (!function_exists('yooadmin_user_enum_stats_get')) {
    /**
     * Blocked enumeration attempt counters (no PII stored).
     *
     * @return array{total:int,by_type:array<string,int>,since:int,last_at:int}
     */
    function yooadmin_user_enum_stats_get(): array
    {
        $stats = get_option(yooadmin_user_enum_stats_option_key(), null);

        if (!is_array($stats)) {
            return yooadmin_user_enum_stats_default();
        }

        $stats['total'] = isset($stats['total']) ? max(0, (int) $stats['total']) : 0;
        $stats['since'] = isset($stats['since']) ? (int) $stats['since'] : time();
        $stats['last_at'] = isset($stats['last_at']) ? (int) $stats['last_at'] : 0;
        $stats['by_type'] = isset($stats['by_type']) && is_array($stats['by_type']) ? $stats['by_type'] : [];

        foreach ($stats['by_type'] as $type => $count) {
            $stats['by_type'][ (string) $type ] = max(0, (int) $count);
        }

        return $stats;
    }
}

if (!function_exists('yooadmin_user_enum_stats_clear')) {
    function yooadmin_user_enum_stats_clear(): void
    {
        update_option(yooadmin_user_enum_stats_option_key(), yooadmin_user_enum_stats_default(), false);
    }
}

if (!function_exists('yooadmin_user_enum_client_fingerprint')) {
    /**
     * One-way fingerprint for rate-limiting duplicate log writes (not reversible to IP).
     */
    function yooadmin_user_enum_client_fingerprint(): string
    {
        $ip = '';

        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $forwarded = sanitize_text_field(wp_unslash((string) $_SERVER['HTTP_X_FORWARDED_FOR']));
            $parts     = explode(',', $forwarded);
            $ip        = trim((string) ($parts[0] ?? ''));
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR']));
        }

        $ip = sanitize_text_field($ip);

        return hash_hmac('sha256', $ip !== '' ? $ip : 'unknown', wp_salt('auth'));
    }
}

if (!function_exists('yooadmin_user_enum_record_block')) {
    /**
     * Increment blocked-attempt counter when enumeration protection fires.
     *
     * @param string $type rest_users|author_query|author_archive
     */
    function yooadmin_user_enum_record_block(string $type): void
    {
        if (!yooadmin_prevent_user_enumeration_is_enabled()) {
            return;
        }

        $allowed = ['rest_users', 'author_query', 'author_archive'];
        if (!in_array($type, $allowed, true)) {
            return;
        }

        $debounce_key = 'yooadmin_ue_log_' . md5($type . yooadmin_user_enum_client_fingerprint());
        if (get_transient($debounce_key)) {
            return;
        }

        set_transient($debounce_key, 1, 30);

        $stats = yooadmin_user_enum_stats_get();
        $stats['total']++;
        $stats['by_type'][ $type ] = isset($stats['by_type'][ $type ]) ? ((int) $stats['by_type'][ $type ]) + 1 : 1;
        $stats['last_at'] = time();

        update_option(yooadmin_user_enum_stats_option_key(), $stats, false);
    }
}

if (!function_exists('yooadmin_user_enum_stats_type_label')) {
    function yooadmin_user_enum_stats_type_label(string $type): string
    {
        switch ($type) {
            case 'rest_users':
                return __('REST users API', 'yooadmin');
            case 'author_query':
                return __('?author= probes', 'yooadmin');
            case 'author_archive':
                return __('Author archive URLs', 'yooadmin');
            default:
                return $type;
        }
    }
}

if (!function_exists('yooadmin_user_enum_applies_to_visitor')) {
    function yooadmin_user_enum_applies_to_visitor(): bool
    {
        if (!yooadmin_prevent_user_enumeration_is_enabled()) {
            return false;
        }

        return !is_user_logged_in();
    }
}

if (!function_exists('yooadmin_user_enum_block_request')) {
    /**
     * @param string $type author_query|author_archive
     */
    function yooadmin_user_enum_block_request(string $type = 'author_archive'): void
    {
        yooadmin_user_enum_record_block($type);

        if (yooadmin_user_enum_author_archive_mode() === 'redirect_home') {
            wp_safe_redirect(home_url('/'), 302);
            exit;
        }

        global $wp_query;

        if ($wp_query instanceof WP_Query) {
            $wp_query->set_404();
        }

        add_filter('redirect_canonical', '__return_false', 100);

        if (function_exists('yooadmin_public_site_error_render_404')) {
            yooadmin_public_site_error_render_404();
        }

        exit;
    }
}

if (!function_exists('yooadmin_user_enum_is_wp_users_rest_route')) {
    function yooadmin_user_enum_is_wp_users_rest_route(string $route): bool
    {
        return (bool) preg_match('#^/wp/v2/users(?:/|$)#', $route);
    }
}

if (!function_exists('yooadmin_user_enum_rest_pre_dispatch')) {
    /**
     * @param mixed           $result  Response to replace dispatch, or null.
     * @param WP_REST_Server  $server  Server.
     * @param WP_REST_Request $request Request.
     * @return mixed
     */
    function yooadmin_user_enum_rest_pre_dispatch($result, $server, $request)
    {
        unset($server);

        if (!yooadmin_user_enum_applies_to_visitor() || !($request instanceof WP_REST_Request)) {
            return $result;
        }

        $route = (string) $request->get_route();
        if (!yooadmin_user_enum_is_wp_users_rest_route($route)) {
            return $result;
        }

        yooadmin_user_enum_record_block('rest_users');

        return new WP_Error(
            'yooadmin_rest_users_forbidden',
            __('User data is not available.', 'yooadmin'),
            ['status' => 403]
        );
    }
}

if (!function_exists('yooadmin_user_enum_rest_prepare_user')) {
    /**
     * Defense in depth: strip identifying fields from any user REST response for visitors.
     *
     * @param WP_REST_Response $response Response.
     * @param WP_User          $user     User.
     * @param WP_REST_Request  $request  Request.
     * @return WP_REST_Response
     */
    function yooadmin_user_enum_rest_prepare_user($response, $user, $request)
    {
        unset($user, $request);

        if (!yooadmin_user_enum_applies_to_visitor() || !($response instanceof WP_REST_Response)) {
            return $response;
        }

        $data = $response->get_data();
        if (!is_array($data)) {
            return $response;
        }

        $strip = [
            'id',
            'name',
            'url',
            'description',
            'link',
            'slug',
            'avatar_urls',
            'meta',
        ];

        foreach ($strip as $key) {
            unset($data[ $key ]);
        }

        $response->set_data($data);

        return $response;
    }
}

if (!function_exists('yooadmin_user_enum_request_has_author_probe')) {
    /**
     * Whether the request includes an ?author= probe (any value, including empty).
     */
    function yooadmin_user_enum_request_has_author_probe(): bool
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public enumeration probe.
        if (array_key_exists('author', $_GET) || array_key_exists('author_name', $_GET)) {
            return true;
        }

        $uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_URI'])) : '';

        return $uri !== '' && (bool) preg_match('/[?&]author(?:_name)?(?:=[^&]*)?(?=&|$)/i', $uri);
    }
}

if (!function_exists('yooadmin_user_enum_block_author_query')) {
    function yooadmin_user_enum_block_author_query(): void
    {
        if (!yooadmin_user_enum_applies_to_visitor()) {
            return;
        }

        if (yooadmin_user_enum_request_has_author_probe()) {
            yooadmin_user_enum_block_request('author_query');
        }
    }
}

if (!function_exists('yooadmin_user_enum_redirect_canonical')) {
    /**
     * Stop ?author=ID redirects that reveal nicename slugs.
     *
     * @param string|false $redirect_url  Redirect URL.
     * @param string       $requested_url Requested URL.
     * @return string|false
     */
    function yooadmin_user_enum_redirect_canonical($redirect_url, $requested_url)
    {
        if (!yooadmin_user_enum_applies_to_visitor()) {
            return $redirect_url;
        }

        if (is_string($requested_url) && preg_match('/[?&]author(?:_name)?=/', $requested_url)) {
            return false;
        }

        if (is_string($redirect_url) && preg_match('#/author/#', $redirect_url)) {
            return false;
        }

        return $redirect_url;
    }
}

if (!function_exists('yooadmin_user_enum_template_redirect')) {
    function yooadmin_user_enum_template_redirect(): void
    {
        if (!yooadmin_user_enum_applies_to_visitor()) {
            return;
        }

        if (is_author()) {
            yooadmin_user_enum_block_request('author_archive');
        }
    }
}

if (!function_exists('yooadmin_user_enum_disable_user_sitemaps')) {
    /**
     * @param WP_Sitemaps_Provider|false $provider Provider instance.
     * @param string                     $name     Provider name.
     * @return WP_Sitemaps_Provider|false
     */
    function yooadmin_user_enum_disable_user_sitemaps($provider, $name)
    {
        if (!yooadmin_prevent_user_enumeration_is_enabled() || $name !== 'users') {
            return $provider;
        }

        return false;
    }
}

if (!function_exists('yooadmin_user_enum_strip_rest_author_refs')) {
    /**
     * @param array<string, mixed> $data REST entity data.
     * @return array<string, mixed>
     */
    function yooadmin_user_enum_strip_rest_author_refs(array $data): array
    {
        unset($data['author']);

        if (isset($data['_embedded']) && is_array($data['_embedded'])) {
            unset($data['_embedded']['author']);
        }

        return $data;
    }
}

if (!function_exists('yooadmin_user_enum_rest_prepare_post')) {
    /**
     * @param WP_REST_Response $response Response.
     * @param WP_Post          $post     Post.
     * @param WP_REST_Request  $request  Request.
     * @return WP_REST_Response
     */
    function yooadmin_user_enum_rest_prepare_post($response, $post, $request)
    {
        unset($post, $request);

        if (!yooadmin_user_enum_applies_to_visitor() || !($response instanceof WP_REST_Response)) {
            return $response;
        }

        $response->set_data(yooadmin_user_enum_strip_rest_author_refs((array) $response->get_data()));

        return $response;
    }
}

if (!function_exists('yooadmin_user_enum_xmlrpc_methods')) {
    /**
     * @param array<string, callable> $methods XML-RPC methods.
     * @return array<string, callable>
     */
    function yooadmin_user_enum_xmlrpc_methods(array $methods): array
    {
        if (!yooadmin_prevent_user_enumeration_is_enabled()) {
            return $methods;
        }

        unset($methods['wp.getUsers'], $methods['wp.getAuthors']);

        return $methods;
    }
}

if (!function_exists('yooadmin_user_enum_bootstrap')) {
    function yooadmin_user_enum_bootstrap(): void
    {
        if (!yooadmin_prevent_user_enumeration_is_enabled()) {
            return;
        }

        add_filter('rest_pre_dispatch', 'yooadmin_user_enum_rest_pre_dispatch', 10, 3);
        add_filter('rest_prepare_user', 'yooadmin_user_enum_rest_prepare_user', 50, 3);
        add_filter('rest_prepare_post', 'yooadmin_user_enum_rest_prepare_post', 50, 3);
        add_filter('rest_prepare_page', 'yooadmin_user_enum_rest_prepare_post', 50, 3);
        add_action('init', 'yooadmin_user_enum_block_author_query', 1);
        add_filter('redirect_canonical', 'yooadmin_user_enum_redirect_canonical', 10, 2);
        add_action('template_redirect', 'yooadmin_user_enum_template_redirect', 1);
        add_filter('wp_sitemaps_add_provider', 'yooadmin_user_enum_disable_user_sitemaps', 10, 2);
        add_filter('xmlrpc_methods', 'yooadmin_user_enum_xmlrpc_methods', 10, 1);
        add_filter('the_author', 'yooadmin_user_enum_filter_feed_author', 10, 1);
        add_filter('comment_author_rss', 'yooadmin_user_enum_filter_feed_author', 10, 1);
    }
}

add_action('plugins_loaded', 'yooadmin_user_enum_bootstrap', 20);
