<?php
/**
 * Login security score for the Studio Hub dashboard widget.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_login_security_dashboard_score_get')) {
    /**
     * @return array{
     *   percent: int,
     *   active: int,
     *   total: int,
     *   enabled: bool,
     *   status_key: string,
     *   status_label: string,
     *   tips: array<int, string>,
     *   items: array<int, array{key: string, label: string, on: bool}>,
     *   settings_url: string
     * }
     */
    function yooadmin_login_security_dashboard_score_get(): array
    {
        $settings_url = admin_url('admin.php?page=yooadmin-settings#tab-login-security');
        $empty = [
            'percent'       => 0,
            'active'        => 0,
            'total'         => 0,
            'enabled'       => false,
            'status_key'    => 'unavailable',
            'status_label'  => __('Login security is not available.', 'yooadmin'),
            'tips'          => [],
            'items'         => [],
            'settings_url'  => $settings_url,
        ];

        if (!function_exists('yooadmin_has_feature') || !yooadmin_has_feature('login_customizer')) {
            return $empty;
        }

        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
        $security_on = !empty($opts['login_security_enabled']);

        $turnstile_on = $security_on
            && function_exists('yooadmin_login_turnstile_is_configured')
            && yooadmin_login_turnstile_is_configured()
            && (
                (function_exists('yooadmin_login_turnstile_wp_login_enabled') && yooadmin_login_turnstile_wp_login_enabled())
                || (function_exists('yooadmin_login_turnstile_standalone_enabled') && yooadmin_login_turnstile_standalone_enabled())
            );

        $rate_limit_on = function_exists('yooadmin_login_rate_limit_is_active')
            ? yooadmin_login_rate_limit_is_active()
            : (
                !empty($opts['login_rate_limit_enabled'])
                && (
                    !isset($opts['login_rate_limit_wp_login']) || !empty($opts['login_rate_limit_wp_login'])
                    || !isset($opts['login_rate_limit_standalone']) || !empty($opts['login_rate_limit_standalone'])
                )
            );

        $items = [
            [
                'key'   => 'turnstile',
                'label' => __('Turnstile', 'yooadmin'),
                'on'    => $turnstile_on,
            ],
            [
                'key'   => 'rate_limit',
                'label' => __('Rate limiting', 'yooadmin'),
                'on'    => $rate_limit_on,
            ],
            [
                'key'   => 'user_enum',
                'label' => __('Username protection', 'yooadmin'),
                'on'    => !empty($opts['login_prevent_user_enumeration']),
            ],
            [
                'key'   => 'hidden_login',
                'label' => __('Hidden login URL', 'yooadmin'),
                'on'    => function_exists('yooadmin_hidden_login_entry_is_enabled') && yooadmin_hidden_login_entry_is_enabled(),
            ],
            [
                'key'   => 'two_factor',
                'label' => __('Two-Factor', 'yooadmin'),
                'on'    => function_exists('yooadmin_login_security_two_factor_is_active')
                    ? yooadmin_login_security_two_factor_is_active()
                    : !empty($opts['login_two_factor_enabled']),
            ],
        ];

        $total  = count($items);
        $active = 0;
        foreach ($items as $item) {
            if (!empty($item['on'])) {
                $active++;
            }
        }

        $percent = $total > 0 ? (int) round(($active / $total) * 100) : 0;

        $status = yooadmin_login_security_dashboard_score_status($percent, $security_on);
        $tips   = yooadmin_login_security_dashboard_score_tips($security_on, $items);

        return [
            'percent'      => $percent,
            'active'       => $active,
            'total'        => $total,
            'enabled'      => $security_on,
            'status_key'   => $status['key'],
            'status_label' => $status['label'],
            'tips'         => $tips,
            'items'        => $items,
            'settings_url' => $settings_url,
        ];
    }
}

if (!function_exists('yooadmin_login_security_dashboard_score_status')) {
    /**
     * @return array{key: string, label: string}
     */
    function yooadmin_login_security_dashboard_score_status(int $percent, bool $security_on): array
    {
        if ($percent <= 0 && !$security_on) {
            return [
                'key'   => 'off',
                'label' => __('Security is off', 'yooadmin'),
            ];
        }

        if ($percent >= 100) {
            return [
                'key'   => 'full',
                'label' => __('Fully protected', 'yooadmin'),
            ];
        }

        if ($percent >= 67) {
            return [
                'key'   => 'good',
                'label' => __('Good protection', 'yooadmin'),
            ];
        }

        if ($percent >= 34) {
            return [
                'key'   => 'partial',
                'label' => __('Partial protection', 'yooadmin'),
            ];
        }

        return [
            'key'   => 'low',
            'label' => __('Needs attention', 'yooadmin'),
        ];
    }
}

if (!function_exists('yooadmin_login_security_dashboard_score_tips')) {
    /**
     * @param array<int, array{key: string, label: string, on: bool}> $items
     * @return array<int, string>
     */
    function yooadmin_login_security_dashboard_score_tips(bool $security_on, array $items): array
    {
        $tips = [];

        $any_on = false;
        foreach ($items as $item) {
            if (!empty($item['on'])) {
                $any_on = true;
                break;
            }
        }

        if (!$security_on && !$any_on) {
            $tips[] = __('Turn on login security for Turnstile, or enable rate limiting, username protection, or a hidden login URL below.', 'yooadmin');
            return $tips;
        }

        foreach ($items as $item) {
            if (!empty($item['on'])) {
                continue;
            }

            switch ($item['key']) {
                case 'turnstile':
                    $gap = function_exists('yooadmin_login_turnstile_keys_gap')
                        ? yooadmin_login_turnstile_keys_gap()
                        : 'both';
                    if ($gap === 'site') {
                        $tips[] = __('Turnstile site key is missing — add it in Security settings.', 'yooadmin');
                    } elseif ($gap === 'secret') {
                        $tips[] = __('Turnstile secret key is missing — add it in Security settings.', 'yooadmin');
                    } else {
                        $tips[] = __('Add Turnstile keys and apply them to your login screens.', 'yooadmin');
                    }
                    break;
                case 'rate_limit':
                    $tips[] = __('Enable rate limiting to slow brute-force attempts.', 'yooadmin');
                    break;
                case 'user_enum':
                    $tips[] = __('Block username discovery via REST, author URLs, and feeds.', 'yooadmin');
                    break;
                case 'hidden_login':
                    $tips[] = __('Hide default login URLs and use a secret path to sign in.', 'yooadmin');
                    break;
                case 'two_factor':
                    $tips[] = __('Enable two-factor authentication to protect sign-ins with a second step.', 'yooadmin');
                    break;
            }

            if (count($tips) >= 2) {
                break;
            }
        }

        if ($tips === []) {
            $tips[] = __('All core login protections are active. Review settings when you change login flows.', 'yooadmin');
        }

        return $tips;
    }
}

if (!function_exists('yooadmin_studio_hub_login_security_widget_section_id')) {
    function yooadmin_studio_hub_login_security_widget_section_id(): string
    {
        return 'widget-aside-studio-login-security';
    }
}

if (!function_exists('yooadmin_studio_hub_should_show_login_security_widget')) {
    function yooadmin_studio_hub_should_show_login_security_widget(): bool
    {
        return function_exists('yooadmin_has_feature')
            && yooadmin_has_feature('login_customizer')
            && current_user_can('manage_options');
    }
}

if (!function_exists('yooadmin_studio_hub_login_security_widget_removed')) {
    /**
     * @param array<string, mixed> $layout
     */
    function yooadmin_studio_hub_login_security_widget_removed(array $layout): bool
    {
        $removed = isset($layout['removedWidgetIds']) && is_array($layout['removedWidgetIds'])
            ? array_map('strval', $layout['removedWidgetIds'])
            : [];

        return in_array('studio-login-security', $removed, true);
    }
}

if (!function_exists('yooadmin_studio_hub_cleanup_login_security_widget')) {
    /**
     * @param array<string, mixed> $layout
     * @return array<string, mixed>
     */
    function yooadmin_studio_hub_cleanup_login_security_widget(array $layout): array
    {
        $strip_ids = ['widget-main-studio-login-security', 'widget-aside-studio-login-security'];
        $widgets   = isset($layout['widgetSections']) && is_array($layout['widgetSections'])
            ? $layout['widgetSections']
            : [];

        foreach ($widgets as $sid => $meta) {
            if (in_array((string) $sid, $strip_ids, true)) {
                unset($widgets[ $sid ]);
                continue;
            }
            if (is_array($meta) && (string) ( $meta['widgetId'] ?? '' ) === 'studio-login-security') {
                unset($widgets[ $sid ]);
            }
        }

        $layout['widgetSections'] = $widgets;

        foreach (['mainOrder', 'asideOrder'] as $order_key) {
            if (empty($layout[ $order_key ]) || !is_array($layout[ $order_key ])) {
                continue;
            }
            $layout[ $order_key ] = array_values(
                array_filter(
                    $layout[ $order_key ],
                    static function ($id) use ($strip_ids): bool {
                        return !in_array((string) $id, $strip_ids, true);
                    }
                )
            );
        }

        return $layout;
    }
}

if (!function_exists('yooadmin_studio_hub_patch_layout_login_security_widget')) {
    /**
     * @param array<string, mixed> $layout
     * @return array<string, mixed>
     */
    function yooadmin_studio_hub_patch_layout_login_security_widget(array $layout): array
    {
        if (!yooadmin_studio_hub_should_show_login_security_widget()) {
            return $layout;
        }

        if (yooadmin_studio_hub_login_security_widget_removed($layout)) {
            return yooadmin_studio_hub_cleanup_login_security_widget($layout);
        }

        $section_id = yooadmin_studio_hub_login_security_widget_section_id();
        $widgets    = isset($layout['widgetSections']) && is_array($layout['widgetSections'])
            ? $layout['widgetSections']
            : [];

        $legacy_ids = ['widget-main-studio-login-security', $section_id];

        foreach ($widgets as $sid => $meta) {
            if (!is_array($meta) || (string) ( $meta['widgetId'] ?? '' ) !== 'studio-login-security') {
                continue;
            }
            if ($sid !== $section_id) {
                unset($widgets[ $sid ]);
            }
        }

        $widgets[ $section_id ] = [
            'placement' => 'aside',
            'widgetId'  => 'studio-login-security',
            'title'     => function_exists('yooadmin_studio_hub_localized_widget_section_title')
                ? yooadmin_studio_hub_localized_widget_section_title('studio-login-security')
                : __('Login security', 'yooadmin'),
            'icon'      => 'dashicons-shield',
        ];
        $layout['widgetSections'] = $widgets;

        $main = isset($layout['mainOrder']) && is_array($layout['mainOrder']) ? $layout['mainOrder'] : [];
        $layout['mainOrder'] = array_values(
            array_filter(
                $main,
                static function ($id) use ($legacy_ids): bool {
                    return !in_array((string) $id, $legacy_ids, true);
                }
            )
        );

        $aside = isset($layout['asideOrder']) && is_array($layout['asideOrder']) ? $layout['asideOrder'] : [];
        $aside = array_values(
            array_filter(
                $aside,
                static function ($id) use ($legacy_ids, $section_id): bool {
                    $id = (string) $id;
                    if ($id === $section_id) {
                        return false;
                    }

                    return !in_array($id, $legacy_ids, true);
                }
            )
        );

        if (!in_array($section_id, $aside, true)) {
            $anchor = array_search('studio-workspace-notes', $aside, true);
            if ($anchor !== false) {
                array_splice($aside, (int) $anchor + 1, 0, [ $section_id ]);
            } else {
                array_unshift($aside, $section_id);
            }
        }

        $layout['asideOrder'] = array_values($aside);

        return $layout;
    }
}

if (!function_exists('yooadmin_studio_hub_migrate_default_login_security_widget')) {
    /**
     * @param array<string, mixed> $layout
     * @return array<string, mixed>
     */
    function yooadmin_studio_hub_migrate_default_login_security_widget(array $layout): array
    {
        if (yooadmin_studio_hub_login_security_widget_removed($layout)) {
            $layout = yooadmin_studio_hub_cleanup_login_security_widget($layout);
            $layout['loginSecurityWidgetDefaultAdded'] = true;
            $layout['loginSecurityWidgetPlacement']     = 'aside';

            return $layout;
        }

        $placement_ok = isset($layout['loginSecurityWidgetPlacement'])
            && (string) $layout['loginSecurityWidgetPlacement'] === 'aside';

        if ($placement_ok && !empty($layout['loginSecurityWidgetDefaultAdded'])) {
            return $layout;
        }

        if (!yooadmin_studio_hub_should_show_login_security_widget()) {
            $layout = yooadmin_studio_hub_cleanup_login_security_widget($layout);
            $layout['loginSecurityWidgetDefaultAdded']   = true;
            $layout['loginSecurityWidgetPlacement']      = 'aside';

            return $layout;
        }

        if (yooadmin_studio_hub_login_security_widget_removed($layout)) {
            $layout = yooadmin_studio_hub_cleanup_login_security_widget($layout);
            $layout['loginSecurityWidgetDefaultAdded']  = true;
            $layout['loginSecurityWidgetPlacement']     = 'aside';

            return $layout;
        }

        $before = wp_json_encode($layout);
        $layout = yooadmin_studio_hub_patch_layout_login_security_widget($layout);
        if (wp_json_encode($layout) !== $before) {
            $layout['__layout_migrated'] = true;
        }

        $layout['loginSecurityWidgetDefaultAdded']  = true;
        $layout['loginSecurityWidgetPlacement']     = 'aside';

        return $layout;
    }
}

add_filter(
    'yooadmin_studio_hub_layout_defaults',
    static function (array $layout): array {
        return yooadmin_studio_hub_patch_layout_login_security_widget($layout);
    }
);

add_filter(
    'yooadmin_user_can_view_dashboard_card',
    static function (bool $can, string $id): bool {
        if ($id === 'studio-login-security') {
            return yooadmin_studio_hub_should_show_login_security_widget();
        }

        return $can;
    },
    10,
    2
);
