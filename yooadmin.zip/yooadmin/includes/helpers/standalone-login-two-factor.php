<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

$yooadmin_2fa_handlers_dir = __DIR__ . '/standalone-login-two-factor/handlers/';
if (function_exists('yooadmin_require_if_exists')) {
    yooadmin_require_if_exists($yooadmin_2fa_handlers_dir . 'wp2fa.php');
    yooadmin_require_if_exists($yooadmin_2fa_handlers_dir . 'wordfence-login-security.php');
    yooadmin_require_if_exists($yooadmin_2fa_handlers_dir . 'google-authenticator.php');
} else {
    foreach (['wp2fa.php', 'wordfence-login-security.php', 'google-authenticator.php'] as $yooadmin_2fa_handler_file) {
        $yooadmin_2fa_handler_path = $yooadmin_2fa_handlers_dir . $yooadmin_2fa_handler_file;
        if (file_exists($yooadmin_2fa_handler_path)) {
            require_once $yooadmin_2fa_handler_path;
        }
    }
}

/**
 * Standalone login AJAX action slugs handled by this module.
 *
 * @return string[]
 */
function yooadmin_standalone_login_two_factor_ajax_actions(): array {
    $actions = [
        'yooadmin_sl_login',
        'yooadmin_sl_validate_2fa',
        'yooadmin_sl_two_factor_challenge',
    ];

    /** @var string[] $actions */
    return apply_filters('yooadmin_standalone_login_two_factor_ajax_actions', $actions);
}

/**
 * Current standalone-login AJAX action (empty when not applicable).
 */
function yooadmin_standalone_login_current_ajax_action(): string {
    if (!function_exists('wp_doing_ajax') || !wp_doing_ajax()) {
        return '';
    }

    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Action slug only; nonce verified in handlers.
    return isset($_POST['action']) ? sanitize_key(wp_unslash($_POST['action'])) : '';
    // phpcs:enable WordPress.Security.NonceVerification.Missing
}

/**
 * Whether the current request is the standalone login AJAX sign-in action.
 */
function yooadmin_standalone_login_is_ajax_auth_request(): bool {
    return yooadmin_standalone_login_current_ajax_action() === 'yooadmin_sl_login';
}

/**
 * Whether the current request is any standalone-login 2FA-related AJAX action.
 */
function yooadmin_standalone_login_is_two_factor_ajax_request(): bool {
    $action = yooadmin_standalone_login_current_ajax_action();

    return $action !== '' && in_array($action, yooadmin_standalone_login_two_factor_ajax_actions(), true);
}

function yooadmin_standalone_login_two_factor_suspend_external_login_handlers(): void {
    if (!yooadmin_standalone_login_is_two_factor_ajax_request()) {
        return;
    }

    if (class_exists('Two_Factor_Core')) {
        remove_action('wp_login', ['Two_Factor_Core', 'wp_login'], PHP_INT_MAX);
    }

    if (class_exists('\WP2FA\Authenticator\Login')) {
        remove_action('wp_login', ['\WP2FA\Authenticator\Login', 'wp_login'], 20);
    }

    if (class_exists('GoogleAuthenticator') && !empty(GoogleAuthenticator::$instance)) {
        $ga = GoogleAuthenticator::$instance;
        if (is_object($ga) && has_filter('authenticate', [$ga, 'check_otp'])) {
            remove_filter('authenticate', [$ga, 'check_otp'], 50);
        }
    }

    /**
     * Fires after default 2FA plugin login handlers are suspended for standalone AJAX.
     */
    do_action('yooadmin_standalone_login_two_factor_suspend_external_login_handlers');
}
add_action('plugins_loaded', 'yooadmin_standalone_login_two_factor_suspend_external_login_handlers', 100);

/**
 * Suspend external 2FA handlers immediately before standalone AJAX handlers run.
 */
function yooadmin_standalone_login_two_factor_register_ajax_suspend_hooks(): void {
    foreach (yooadmin_standalone_login_two_factor_ajax_actions() as $action) {
        add_action('wp_ajax_nopriv_' . $action, 'yooadmin_standalone_login_two_factor_suspend_external_login_handlers', 0);
        add_action('wp_ajax_' . $action, 'yooadmin_standalone_login_two_factor_suspend_external_login_handlers', 0);
    }
}
add_action('init', 'yooadmin_standalone_login_two_factor_register_ajax_suspend_hooks', 0);

/**
 * @return string[]
 */
function yooadmin_standalone_login_two_factor_core_login_actions(): array {
    $actions = ['validate_2fa', 'revalidate_2fa'];

    /** @var string[] $actions */
    return apply_filters('yooadmin_standalone_login_two_factor_core_login_actions', $actions);
}

/**
 * @param string[] $bypass Action slugs.
 * @return string[]
 */
function yooadmin_standalone_login_two_factor_bypass_redirect_actions(array $bypass): array {
    foreach (yooadmin_standalone_login_two_factor_core_login_actions() as $action) {
        if (!in_array($action, $bypass, true)) {
            $bypass[] = $action;
        }
    }

    return $bypass;
}
add_filter('yooadmin_standalone_login_bypass_redirect_actions', 'yooadmin_standalone_login_two_factor_bypass_redirect_actions');

/**
 * @param bool                 $must_use Whether core wp-login must be used.
 * @param array<string, mixed> $query    Parsed query args.
 */
function yooadmin_standalone_login_two_factor_hidden_login_allow(bool $must_use, array $query): bool {
    if ($must_use) {
        return true;
    }

    $action = isset($query['action']) ? sanitize_key((string) $query['action']) : '';
    if (!in_array($action, yooadmin_standalone_login_two_factor_core_login_actions(), true)) {
        return false;
    }

    // Revalidate should use the branded standalone screen when it is enabled.
    if ($action === 'revalidate_2fa'
        && function_exists('yooadmin_custom_login_uses_standalone_page')
        && yooadmin_custom_login_uses_standalone_page()) {
        return false;
    }

    return true;
}
add_filter('yooadmin_hidden_login_entry_must_use_core_wp_login', 'yooadmin_standalone_login_two_factor_hidden_login_allow', 10, 2);

/**
 * Send wp-login.php revalidate requests to the branded standalone login URL.
 *
 * @param string[] $allowed Action slugs.
 * @return string[]
 */
function yooadmin_standalone_login_two_factor_get_redirect_actions(array $allowed): array {
    if (!function_exists('yooadmin_custom_login_uses_standalone_page') || !yooadmin_custom_login_uses_standalone_page()) {
        return $allowed;
    }

    if (!in_array('revalidate_2fa', $allowed, true)) {
        $allowed[] = 'revalidate_2fa';
    }

    return $allowed;
}
add_filter('yooadmin_standalone_login_get_redirect_actions', 'yooadmin_standalone_login_two_factor_get_redirect_actions');

/**
 * Point generated revalidate links to the branded standalone login URL.
 *
 * @param string      $url     Complete URL.
 * @param string      $path    Path relative to site URL.
 * @param string|null $scheme  Scheme.
 * @param int|null    $blog_id Blog ID.
 */
function yooadmin_standalone_login_two_factor_filter_site_url_login($url, $path, $scheme, $blog_id): string {
    unset($scheme, $blog_id);

    if (!function_exists('yooadmin_custom_login_uses_standalone_page') || !yooadmin_custom_login_uses_standalone_page()) {
        return (string) $url;
    }

    $path = (string) $path;
    if ($path === '' || stripos($path, 'wp-login.php') === false) {
        return (string) $url;
    }

    $parts = wp_parse_url((string) $url);
    $query = [];
    if (!empty($parts['query'])) {
        parse_str((string) $parts['query'], $query);
    }

    $action = isset($query['action']) ? sanitize_key((string) $query['action']) : '';
    if ($action !== 'revalidate_2fa') {
        return (string) $url;
    }

    $dest = function_exists('yooadmin_standalone_login_public_url')
        ? yooadmin_standalone_login_public_url()
        : (function_exists('yooadmin_standalone_login_url') ? yooadmin_standalone_login_url() : (string) $url);

    if ($query !== []) {
        $dest = add_query_arg($query, $dest);
    }

    return $dest;
}
add_filter('site_url', 'yooadmin_standalone_login_two_factor_filter_site_url_login', 11, 4);

/**
 * Whether the user must complete a second authentication step.
 *
 * @param WP_User $user Authenticated user (password verified).
 */
function yooadmin_standalone_login_user_requires_two_factor(WP_User $user): bool {
    if (!($user instanceof WP_User) || $user->ID <= 0) {
        return false;
    }

    foreach (yooadmin_standalone_login_two_factor_handlers() as $handler) {
        if (!is_array($handler)) {
            continue;
        }
        $requires = $handler['requires'] ?? null;
        if (is_callable($requires) && call_user_func($requires, $user)) {
            return true;
        }
    }

    /** @var bool $requires */
    return (bool) apply_filters('yooadmin_standalone_login_user_requires_two_factor', false, $user);
}

/**
 * Handlers that do not use wp-auth-nonce sessions.
 *
 * @param array<string, mixed> $session Session payload.
 */
function yooadmin_standalone_login_two_factor_session_requires_nonce(array $session): bool {
    $handler = isset($session['handler']) ? sanitize_key((string) $session['handler']) : '';
    $no_nonce = ['wordfence-login-security', 'google-authenticator'];

    /** @var string[] $no_nonce */
    $no_nonce = apply_filters('yooadmin_standalone_login_two_factor_handlers_without_nonce', $no_nonce);

    return !in_array($handler, $no_nonce, true);
}

/**
 * @param array<string, mixed> $request Field values.
 * @param array<string, mixed> $extras  Extra superglobal values.
 * @return array{POST: array<string, mixed>, REQUEST: array<string, mixed>}
 */
function yooadmin_standalone_login_two_factor_stage_request(array $request, array $extras = []): array {
    $backup = [
        // Snapshot of superglobals so the caller can restore them after staging; the request is nonce-verified by the calling login/AJAX handler.
        'POST'    => $_POST,    // phpcs:ignore WordPress.Security.NonceVerification.Missing
        'REQUEST' => $_REQUEST, // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    ];

    foreach (array_merge($request, $extras) as $key => $value) {
        if (!is_string($key)) {
            continue;
        }
        $_POST[$key]    = $value;
        $_REQUEST[$key] = $value;
    }

    return $backup;
}

/**
 * @param array{POST: array<string, mixed>, REQUEST: array<string, mixed>} $backup Backup snapshot.
 */
function yooadmin_standalone_login_two_factor_restore_request(array $backup): void {
    $_POST    = $backup['POST'];
    $_REQUEST = $backup['REQUEST'];
}

/**
 * Error codes from wp_signon() that should start inline 2FA.
 *
 * @return string[]
 */
function yooadmin_standalone_login_two_factor_wp_signon_intercept_codes(): array {
    $codes = [];

    if (function_exists('yooadmin_standalone_login_two_factor_wordfence_intercept_codes')) {
        $codes = array_merge($codes, yooadmin_standalone_login_two_factor_wordfence_intercept_codes());
    }
    if (function_exists('yooadmin_standalone_login_two_factor_google_authenticator_intercept_codes')) {
        $codes = array_merge($codes, yooadmin_standalone_login_two_factor_google_authenticator_intercept_codes());
    }

    /** @var string[] $codes */
    return array_values(array_unique(apply_filters('yooadmin_standalone_login_two_factor_wp_signon_intercept_codes', $codes)));
}

/**
 * Send inline 2FA JSON after password verification.
 *
 * @param WP_User $user        User.
 * @param bool    $remember    Remember me.
 * @param string  $redirect_to Redirect target.
 */
function yooadmin_standalone_login_two_factor_ajax_begin_response(WP_User $user, bool $remember, string $redirect_to): void {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    yooadmin_standalone_login_two_factor_suspend_external_login_handlers();

    $session = yooadmin_standalone_login_two_factor_begin($user, $remember, $redirect_to);
    if (is_wp_error($session)) {
        wp_send_json_error(
            [
                'code'    => $session->get_error_code(),
                'message' => $session->get_error_message(),
            ],
            500
        );
    }

    $payload = [
        'two_factor_required' => true,
        'session'             => $session,
        'message'             => __('Two-factor authentication required.', 'yooadmin'),
    ];

    if (function_exists('yooadmin_standalone_login_create_ajax_nonce')) {
        $payload['nonce'] = yooadmin_standalone_login_create_ajax_nonce();
    }

    wp_send_json_success($payload);
}

/**
 * Renew session after a failed 2FA attempt (when supported).
 *
 * @param array<string, mixed> $session Session.
 * @param WP_User              $user    User.
 * @param array<string, mixed> $request Request fields.
 * @return array<string, mixed>|null
 */
function yooadmin_standalone_login_two_factor_renew_session_after_failure(array $session, WP_User $user, array $request): ?array {
    $handler_key = isset($session['handler']) ? sanitize_key((string) $session['handler']) : '';
    $provider    = isset($request['provider']) ? sanitize_key((string) $request['provider']) : (isset($session['provider']) ? sanitize_key((string) $session['provider']) : '');
    $remember    = !empty($session['remember']);
    $redirect_to = isset($session['redirect_to']) ? (string) $session['redirect_to'] : admin_url();

    if ($handler_key === 'wordpress-two-factor' && class_exists('Two_Factor_Core')) {
        if (($session['mode'] ?? '') === 'revalidate') {
            $refreshed = yooadmin_standalone_login_two_factor_wp_revalidate_challenge(
                $user,
                wp_create_nonce('two_factor_revalidate_' . $user->ID),
                $provider,
                false,
                $redirect_to
            );

            return is_array($refreshed) ? $refreshed : null;
        }

        $login_nonce = Two_Factor_Core::create_login_nonce($user->ID);
        if (!is_array($login_nonce) || empty($login_nonce['key'])) {
            return null;
        }

        $refreshed = yooadmin_standalone_login_two_factor_wp_challenge(
            $user,
            $login_nonce['key'],
            $provider,
            $remember,
            $redirect_to
        );

        return is_array($refreshed) ? $refreshed : null;
    }

    if ($handler_key === 'wp-2fa' && class_exists('\WP2FA\Authenticator\Login')) {
        $login_nonce = \WP2FA\Authenticator\Login::create_login_nonce($user->ID);
        if (!is_array($login_nonce) || empty($login_nonce['key'])) {
            return null;
        }

        $refreshed = yooadmin_standalone_login_two_factor_wp2fa_challenge(
            $user,
            $login_nonce['key'],
            $provider,
            $remember,
            $redirect_to
        );

        return is_array($refreshed) ? $refreshed : null;
    }

    $refreshed = yooadmin_standalone_login_two_factor_refresh_challenge($session, $provider);

    return is_array($refreshed) ? $refreshed : null;
}

/**
 * Registered 2FA handler callbacks (filterable).
 *
 * Each handler: [
 *   'requires'  => callable(WP_User): bool
 *   'begin'     => callable(WP_User, bool, string): array|WP_Error
 *   'challenge' => callable(WP_User, string, string, bool, string): array|WP_Error  // user, nonce, provider, remember, redirect
 *   'validate'  => callable(WP_User, string, string, array, bool, string): true|WP_Error|array
 * ]
 *
 * @return array<string, array<string, callable>>
 */
function yooadmin_standalone_login_two_factor_handlers(): array {
    $handlers = [];

    if (class_exists('Two_Factor_Core')) {
        $handlers['wordpress-two-factor'] = [
            'requires'  => 'yooadmin_standalone_login_two_factor_wp_requires',
            'begin'     => 'yooadmin_standalone_login_two_factor_wp_begin',
            'challenge' => 'yooadmin_standalone_login_two_factor_wp_challenge',
            'validate'  => 'yooadmin_standalone_login_two_factor_wp_validate',
        ];
    }

    /** @var array<string, array<string, callable>> $handlers */
    return apply_filters('yooadmin_standalone_login_two_factor_handlers', $handlers);
}

/**
 * @param WP_User $user User object.
 */
function yooadmin_standalone_login_two_factor_wp_requires(WP_User $user): bool {
    return Two_Factor_Core::is_user_using_two_factor($user->ID);
}

/**
 * @param WP_User $user        User.
 * @param bool    $remember    Remember me.
 * @param string  $redirect_to Redirect target.
 * @return array<string, mixed>|WP_Error
 */
/**
 * Begin inline 2FA revalidation for a logged-in user (profile security settings).
 *
 * @param WP_User $user        Current user.
 * @param string  $redirect_to Redirect after successful revalidation.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_begin_revalidate(WP_User $user, string $redirect_to) {
    /**
     * Short-circuit revalidate begin (return array|WP_Error to handle fully).
     *
     * @param array<string, mixed>|WP_Error|null $payload
     * @param WP_User                            $user
     * @param string                             $redirect_to
     */
    $payload = apply_filters('yooadmin_standalone_login_two_factor_begin_revalidate', null, $user, $redirect_to);
    if ($payload instanceof WP_Error) {
        return $payload;
    }
    if (is_array($payload) && $payload !== []) {
        return $payload;
    }

    if (!class_exists('Two_Factor_Core') && !(class_exists('YOOAdmin_2FA_Core') && YOOAdmin_2FA_Core::is_user_using_2fa($user->ID))) {
        return new WP_Error('two_factor_unavailable', __('Two-factor authentication is not available.', 'yooadmin'));
    }

    if (!is_user_logged_in() || get_current_user_id() !== $user->ID) {
        return new WP_Error(
            'two_factor_reauth_required',
            __('You must be signed in to revalidate your session.', 'yooadmin')
        );
    }

    if (!Two_Factor_Core::is_user_using_two_factor($user->ID)) {
        return new WP_Error(
            'two_factor_not_enabled',
            __('Two-factor authentication is not enabled for this account.', 'yooadmin')
        );
    }

    $provider = Two_Factor_Core::get_provider_for_user($user);
    if (!$provider) {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $auth_nonce = wp_create_nonce('two_factor_revalidate_' . $user->ID);
    $challenge  = yooadmin_standalone_login_two_factor_wp_build_challenge($user, $provider, $auth_nonce);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    $redirect_to = wp_validate_redirect($redirect_to, admin_url());

    return [
        'handler'     => 'wordpress-two-factor',
        'mode'        => 'revalidate',
        'user_id'     => $user->ID,
        'auth_nonce'  => $auth_nonce,
        'provider'    => $provider->get_key(),
        'remember'    => false,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @param WP_User $user        User.
 * @param bool    $remember    Remember me.
 * @param string  $redirect_to Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp_begin(WP_User $user, bool $remember, string $redirect_to) {
    Two_Factor_Core::destroy_current_session_for_user($user);
    wp_clear_auth_cookie();

    $login_nonce = Two_Factor_Core::create_login_nonce($user->ID);
    if (!is_array($login_nonce) || empty($login_nonce['key'])) {
        return new WP_Error(
            'two_factor_nonce_failed',
            __('Two-factor authentication could not be started. Please try again.', 'yooadmin')
        );
    }

    $provider = Two_Factor_Core::get_provider_for_user($user);
    if (!$provider) {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $challenge = yooadmin_standalone_login_two_factor_wp_build_challenge($user, $provider, $login_nonce['key']);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'wordpress-two-factor',
        'user_id'     => $user->ID,
        'auth_nonce'  => $login_nonce['key'],
        'provider'    => $provider->get_key(),
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @param WP_User $user        User.
 * @param string  $auth_nonce  Login nonce.
 * @param string  $provider_key Provider key.
 * @param bool    $remember    Remember me.
 * @param string  $redirect_to Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp_challenge(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    bool $remember,
    string $redirect_to
) {
    if (!Two_Factor_Core::verify_login_nonce($user->ID, $auth_nonce)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $provider = Two_Factor_Core::get_provider_for_user($user, $provider_key !== '' ? $provider_key : null);
    if (!$provider) {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $challenge = yooadmin_standalone_login_two_factor_wp_build_challenge($user, $provider, $auth_nonce);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'wordpress-two-factor',
        'user_id'     => $user->ID,
        'auth_nonce'  => $auth_nonce,
        'provider'    => $provider->get_key(),
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @param object  $provider Two Factor provider instance.
 * @param WP_User $user     User.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp_build_challenge(WP_User $user, $provider, string $auth_nonce) {
    if (!is_object($provider) || !method_exists($provider, 'get_key')) {
        return new WP_Error('two_factor_provider_missing', __('Two-factor provider not available.', 'yooadmin'));
    }

    $provider_key = $provider->get_key();
    $available    = Two_Factor_Core::get_available_providers_for_user($user);
    if (is_wp_error($available)) {
        return $available;
    }

    $alternates = [];
    foreach ($available as $key => $backup_provider) {
        if ($key === $provider_key) {
            continue;
        }
        $alternates[] = [
            'provider' => $key,
            'label'    => $backup_provider->get_alternative_provider_label(),
        ];
    }

    $fields  = [];
    $actions = [];
    $lead    = '';
    $fragment = '';

    /**
     * Filters inline 2FA challenge payload before the default WordPress Two Factor mapping.
     *
     * Return a non-empty array to replace the built challenge for this provider.
     *
     * @param array<string, mixed>|null $challenge   Pre-built challenge or null.
     * @param WP_User                   $user        User.
     * @param object                    $provider    Provider instance.
     * @param string                    $auth_nonce  Login nonce.
     */
    $filtered = apply_filters('yooadmin_standalone_login_two_factor_build_challenge', null, $user, $provider, $auth_nonce);
    if (is_array($filtered) && $filtered !== []) {
        return $filtered;
    }

    switch ($provider_key) {
        case 'Two_Factor_Totp':
            $lead = __('Enter the code from your authenticator app.', 'yooadmin');
            $fields[] = [
                'name'         => 'authcode',
                'label'        => __('Authentication code', 'yooadmin'),
                'type'         => 'text',
                'inputmode'    => 'numeric',
                'autocomplete' => 'one-time-code',
                'placeholder'  => '123 456',
                'required'     => true,
            ];
            break;

        case 'Two_Factor_Email':
            ob_start();
            $provider->authentication_page($user);
            $fragment = (string) ob_get_clean();
            $lead     = __('A verification code has been sent to your email address.', 'yooadmin');
            $fields[] = [
                'name'         => 'two-factor-email-code',
                'label'        => __('Verification code', 'yooadmin'),
                'type'         => 'text',
                'inputmode'    => 'numeric',
                'autocomplete' => 'one-time-code',
                'placeholder'  => '',
                'required'     => true,
            ];
            $actions[] = [
                'name'  => 'two-factor-email-code-resend',
                'label' => __('Resend code', 'yooadmin'),
                'type'  => 'secondary',
            ];
            break;

        case 'Two_Factor_Backup_Codes':
            $lead = __('Enter one of your recovery codes.', 'yooadmin');
            $fields[] = [
                'name'         => 'two-factor-backup-code',
                'label'        => __('Recovery code', 'yooadmin'),
                'type'         => 'text',
                'inputmode'    => 'text',
                'autocomplete' => 'one-time-code',
                'placeholder'  => __('8-character code', 'yooadmin'),
                'required'     => true,
                'pin'          => false,
            ];
            break;

        default:
            ob_start();
            $provider->authentication_page($user);
            $fragment = (string) ob_get_clean();
            $lead     = method_exists($provider, 'get_label') ? (string) $provider->get_label() : '';
            break;
    }

    return [
        'title'           => __('Two-factor authentication', 'yooadmin'),
        'lead'            => $lead,
        'provider'        => $provider_key,
        'provider_label'  => method_exists($provider, 'get_label') ? (string) $provider->get_label() : '',
        'fields'          => $fields,
        'actions'         => $actions,
        'alternates'      => $alternates,
        'fragment'        => $fragment,
    ];
}

/**
 * @param WP_User              $user        User.
 * @param string               $auth_nonce  Nonce.
 * @param string               $provider_key Provider.
 * @param array<string, mixed> $request     Submitted fields.
 * @param bool                 $remember    Remember me.
 * @param string               $redirect_to Redirect target.
 * @return true|array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp_validate(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    array $request,
    bool $remember,
    string $redirect_to
) {
    if (!Two_Factor_Core::verify_login_nonce($user->ID, $auth_nonce)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $provider = Two_Factor_Core::get_provider_for_user($user, $provider_key !== '' ? $provider_key : null);
    if (!$provider) {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $backup = yooadmin_standalone_login_two_factor_stage_request(
        $request,
        [
            'wp-auth-id'    => (string) $user->ID,
            'wp-auth-nonce' => $auth_nonce,
            'provider'      => $provider->get_key(),
            'rememberme'    => $remember ? '1' : '',
            'redirect_to'   => $redirect_to,
        ]
    );

    $result = Two_Factor_Core::process_provider($provider, $user, true);

    yooadmin_standalone_login_two_factor_restore_request($backup);

    if ($result === false && !empty($request['two-factor-email-code-resend'])) {
        $challenge = yooadmin_standalone_login_two_factor_wp_build_challenge($user, $provider, $auth_nonce);
        if (is_wp_error($challenge)) {
            return $challenge;
        }

        return [
            'resent'    => true,
            'message'   => __('A new verification code has been sent.', 'yooadmin'),
            'challenge' => $challenge,
            'provider'  => $provider->get_key(),
        ];
    }

    if ($result === true) {
        Two_Factor_Core::delete_login_nonce($user->ID);
        delete_user_meta($user->ID, Two_Factor_Core::USER_RATE_LIMIT_KEY);
        delete_user_meta($user->ID, Two_Factor_Core::USER_FAILED_LOGIN_ATTEMPTS_KEY);

        remove_filter('send_auth_cookies', '__return_false', PHP_INT_MAX);
        wp_set_auth_cookie($user->ID, $remember);

        if (function_exists('yooadmin_user_switching_finalize_authenticated_session')) {
            yooadmin_user_switching_finalize_authenticated_session((int) $user->ID);
        }

        /** @noinspection PhpUndefinedClassInspection */
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Firing the Two Factor plugin's own hook for compatibility; name is owned by that plugin.
        do_action('two_factor_user_authenticated', $user, $provider);

        return true;
    }

    if (is_wp_error($result)) {
        return $result;
    }

    return new WP_Error(
        'two_factor_invalid',
        __('Invalid verification code. Please try again.', 'yooadmin')
    );
}

/**
 * @param WP_User              $user        User.
 * @param string               $auth_nonce  Revalidate nonce.
 * @param string               $provider_key Provider.
 * @param array<string, mixed> $request     Submitted fields.
 * @param bool                 $remember    Unused for revalidate.
 * @param string               $redirect_to Redirect target.
 * @return true|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp_revalidate(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    array $request,
    bool $remember,
    string $redirect_to
) {
    unset($remember, $redirect_to);

    if (!wp_verify_nonce($auth_nonce, 'two_factor_revalidate_' . $user->ID)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $provider = Two_Factor_Core::get_provider_for_user($user, $provider_key !== '' ? $provider_key : null);
    if (!$provider) {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $backup = yooadmin_standalone_login_two_factor_stage_request(
        $request,
        [
            'provider' => $provider->get_key(),
        ]
    );

    $result = Two_Factor_Core::process_provider($provider, $user, true);

    yooadmin_standalone_login_two_factor_restore_request($backup);

    if ($result === true) {
        Two_Factor_Core::update_current_user_session(
            [
                'two-factor-provider' => $provider->get_key(),
                'two-factor-login'    => time(),
            ]
        );

        /** @noinspection PhpUndefinedClassInspection */
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Firing the Two Factor plugin's own hook for compatibility; name is owned by that plugin.
        do_action('two_factor_user_revalidated', $user, $provider);

        return true;
    }

    if (is_wp_error($result)) {
        return $result;
    }

    return new WP_Error(
        'two_factor_invalid',
        __('Invalid verification code. Please try again.', 'yooadmin')
    );
}

/**
 * @param WP_User $user        User.
 * @param string  $auth_nonce  Revalidate nonce.
 * @param string  $provider_key Provider key.
 * @param bool    $remember    Unused.
 * @param string  $redirect_to Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp_revalidate_challenge(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    bool $remember,
    string $redirect_to
) {
    unset($remember);

    if (!wp_verify_nonce($auth_nonce, 'two_factor_revalidate_' . $user->ID)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $provider = Two_Factor_Core::get_provider_for_user($user, $provider_key !== '' ? $provider_key : null);
    if (!$provider) {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $challenge = yooadmin_standalone_login_two_factor_wp_build_challenge($user, $provider, $auth_nonce);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'wordpress-two-factor',
        'mode'        => 'revalidate',
        'user_id'     => $user->ID,
        'auth_nonce'  => $auth_nonce,
        'provider'    => $provider->get_key(),
        'remember'    => false,
        'redirect_to' => wp_validate_redirect($redirect_to, admin_url()),
        'challenge'   => $challenge,
    ];
}

/**
 * Begin inline 2FA after password verification.
 *
 * @param WP_User $user        User.
 * @param bool    $remember    Remember me.
 * @param string  $redirect_to Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_begin(WP_User $user, bool $remember, string $redirect_to) {
    $payload = null;

    /**
     * Short-circuit inline 2FA begin (return array|WP_Error to handle fully).
     *
     * @param array<string, mixed>|WP_Error|null $payload
     * @param WP_User                            $user
     * @param bool                               $remember
     * @param string                             $redirect_to
     */
    $payload = apply_filters('yooadmin_standalone_login_two_factor_begin', $payload, $user, $remember, $redirect_to);
    if ($payload instanceof WP_Error) {
        return $payload;
    }
    if (is_array($payload) && $payload !== []) {
        return $payload;
    }

    foreach (yooadmin_standalone_login_two_factor_handlers() as $handler) {
        if (!is_array($handler)) {
            continue;
        }
        $requires = $handler['requires'] ?? null;
        $begin    = $handler['begin'] ?? null;
        if (!is_callable($requires) || !is_callable($begin)) {
            continue;
        }
        if (!call_user_func($requires, $user)) {
            continue;
        }

        $built = call_user_func($begin, $user, $remember, $redirect_to);
        if ($built instanceof WP_Error) {
            return $built;
        }
        if (is_array($built) && $built !== []) {
            $payload = $built;
            break;
        }
    }

    if (!is_array($payload) || $payload === []) {
        return new WP_Error(
            'two_factor_unavailable',
            __('Two-factor authentication is required but could not be started. Please contact the site administrator.', 'yooadmin')
        );
    }

    /** @var array<string, mixed> $payload */
    return apply_filters('yooadmin_standalone_login_two_factor_begin_result', $payload, $user, $remember, $redirect_to);
}

/**
 * Resolve handler key for a session payload.
 *
 * @param array<string, mixed> $session Session payload.
 */
function yooadmin_standalone_login_two_factor_resolve_handler(array $session): ?array {
    $handler_key = isset($session['handler']) ? sanitize_key((string) $session['handler']) : '';
    $handlers    = yooadmin_standalone_login_two_factor_handlers();

    if ($handler_key !== '' && isset($handlers[$handler_key]) && is_array($handlers[$handler_key])) {
        return $handlers[$handler_key];
    }

    foreach ($handlers as $handler) {
        if (is_array($handler)) {
            return $handler;
        }
    }

    return null;
}

/**
 * @param array<string, mixed> $session Session from begin/challenge.
 * @param string               $provider_key Provider to switch to.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_refresh_challenge(array $session, string $provider_key = '') {
    $user_id = isset($session['user_id']) ? absint($session['user_id']) : 0;
    $user    = $user_id > 0 ? get_user_by('id', $user_id) : false;
    if (!$user instanceof WP_User) {
        return new WP_Error('two_factor_user_missing', __('User not found.', 'yooadmin'));
    }

    $auth_nonce  = isset($session['auth_nonce']) ? (string) $session['auth_nonce'] : '';
    $remember    = !empty($session['remember']);
    $redirect_to = isset($session['redirect_to']) ? (string) $session['redirect_to'] : admin_url();
    $provider_key = $provider_key !== '' ? $provider_key : (isset($session['provider']) ? (string) $session['provider'] : '');

    if (($session['mode'] ?? '') === 'revalidate') {
        $handler_key = isset($session['handler']) ? sanitize_key((string) $session['handler']) : '';
        if ($handler_key === 'yooadmin-native-2fa' && function_exists('yooadmin_native_2fa_revalidate_challenge')) {
            return yooadmin_native_2fa_revalidate_challenge(
                $user,
                isset($session['auth_nonce']) ? (string) $session['auth_nonce'] : '',
                $provider_key,
                false,
                $redirect_to
            );
        }

        return yooadmin_standalone_login_two_factor_wp_revalidate_challenge(
            $user,
            wp_create_nonce('two_factor_revalidate_' . $user->ID),
            $provider_key,
            false,
            $redirect_to
        );
    }

    $handler = yooadmin_standalone_login_two_factor_resolve_handler($session);
    $callable = is_array($handler) ? ($handler['challenge'] ?? null) : null;
    if (!is_callable($callable)) {
        return new WP_Error('two_factor_unavailable', __('Two-factor authentication is not available.', 'yooadmin'));
    }

    return call_user_func($callable, $user, $auth_nonce, $provider_key, $remember, $redirect_to);
}

/**
 * @param array<string, mixed> $session Session from begin/challenge.
 * @param array<string, mixed> $request Submitted fields.
 * @return true|array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_validate_session(array $session, array $request) {
    $user_id = isset($session['user_id']) ? absint($session['user_id']) : 0;
    $user    = $user_id > 0 ? get_user_by('id', $user_id) : false;
    if (!$user instanceof WP_User) {
        return new WP_Error('two_factor_user_missing', __('User not found.', 'yooadmin'));
    }

    $auth_nonce  = isset($session['auth_nonce']) ? (string) $session['auth_nonce'] : '';
    $provider    = isset($request['provider']) ? sanitize_key((string) $request['provider']) : (isset($session['provider']) ? sanitize_key((string) $session['provider']) : '');
    $remember    = !empty($session['remember']);
    $redirect_to = isset($session['redirect_to']) ? (string) $session['redirect_to'] : admin_url();

    /**
     * Filters 2FA validation input before handler dispatch.
     *
     * @param array<string, mixed> $request
     * @param array<string, mixed> $session
     * @param WP_User              $user
     */
    $request = apply_filters('yooadmin_standalone_login_two_factor_validate_request', $request, $session, $user);

    if (($session['mode'] ?? '') === 'revalidate') {
        $handler_key = isset($session['handler']) ? sanitize_key((string) $session['handler']) : '';
        if ($handler_key === 'yooadmin-native-2fa' && function_exists('yooadmin_native_2fa_revalidate_validate')) {
            $result = yooadmin_native_2fa_revalidate_validate(
                $user,
                $auth_nonce,
                $provider,
                $request,
                $remember,
                $redirect_to
            );
        } else {
            $result = yooadmin_standalone_login_two_factor_wp_revalidate(
                $user,
                $auth_nonce,
                $provider,
                $request,
                $remember,
                $redirect_to
            );
        }
    } else {
        $handler  = yooadmin_standalone_login_two_factor_resolve_handler($session);
        $callable = is_array($handler) ? ($handler['validate'] ?? null) : null;
        if (!is_callable($callable)) {
            return new WP_Error('two_factor_unavailable', __('Two-factor authentication is not available.', 'yooadmin'));
        }

        $result = call_user_func($callable, $user, $auth_nonce, $provider, $request, $remember, $redirect_to);
    }

    /** @var true|array<string, mixed>|WP_Error $result */
    return apply_filters('yooadmin_standalone_login_two_factor_validate_result', $result, $session, $request, $user);
}

/**
 * Intercept wp_login during standalone AJAX before Two Factor plugin redirects/exits.
 *
 * @param string  $user_login Username.
 * @param WP_User $user       User object.
 */
function yooadmin_standalone_login_two_factor_handle_wp_login(string $user_login, $user): void {
    unset($user_login);

    if (!yooadmin_standalone_login_is_ajax_auth_request()) {
        return;
    }

    if (!($user instanceof WP_User)) {
        return;
    }

    if (!yooadmin_standalone_login_user_requires_two_factor($user)) {
        return;
    }

    if (class_exists('Two_Factor_Core')) {
        remove_action('wp_login', ['Two_Factor_Core', 'wp_login'], PHP_INT_MAX);
    }
    if (class_exists('\WP2FA\Authenticator\Login')) {
        remove_action('wp_login', ['\WP2FA\Authenticator\Login', 'wp_login'], 20);
    }

    $redirect_to = admin_url();
    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified in AJAX handler.
    $remember = !empty($_POST['rememberme']);
    if (isset($_POST['redirect_to']) && is_string($_POST['redirect_to'])) {
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Validated by wp_validate_redirect().
        $redirect_to = wp_validate_redirect(wp_unslash($_POST['redirect_to']), admin_url());
    }
    // phpcs:enable WordPress.Security.NonceVerification.Missing

    if (is_string($redirect_to) && strpos($redirect_to, 'wp-admin') !== false) {
        $redirect_to = add_query_arg('yooadmin_login', '1', $redirect_to);
    }

    yooadmin_standalone_login_two_factor_ajax_begin_response($user, $remember, $redirect_to);
}

/**
 * AJAX: validate inline 2FA code.
 */
function yooadmin_standalone_login_ajax_validate_two_factor(): void {
    if (!function_exists('yooadmin_standalone_login_ajax_verify_nonce')) {
        wp_send_json_error(['code' => 'forbidden', 'message' => __('Not allowed.', 'yooadmin')], 403);
    }

    yooadmin_standalone_login_ajax_verify_nonce();

    if (!function_exists('yooadmin_standalone_login_ajax_is_allowed') || !yooadmin_standalone_login_ajax_is_allowed()) {
        wp_send_json_error(['code' => 'forbidden', 'message' => __('Not allowed.', 'yooadmin')], 403);
    }

    // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; the session is server-generated JSON that is decoded then structurally validated, and each field is cast/verified on use.
    $session_raw = isset($_POST['session']) ? wp_unslash($_POST['session']) : '';
    if (is_string($session_raw) && $session_raw !== '') {
        $session = json_decode($session_raw, true);
    } else {
        $session = isset($_POST['session']) && is_array($_POST['session']) ? wp_unslash($_POST['session']) : [];
    }

    $session_valid = is_array($session)
        && !empty($session['user_id'])
        && (!yooadmin_standalone_login_two_factor_session_requires_nonce($session) || !empty($session['auth_nonce']));
    if (!$session_valid) {
        wp_send_json_error(
            [
                'code'    => 'invalid_session',
                'message' => __('Your verification session expired. Please sign in again.', 'yooadmin'),
            ]
        );
    }

    $request = [];
    foreach ($_POST as $key => $value) {
        if (in_array($key, ['action', 'nonce', 'session'], true)) {
            continue;
        }
        if (is_string($key) && (is_string($value) || is_numeric($value))) {
            $request[$key] = (string) $value;
        }
    }
    // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

    $result = yooadmin_standalone_login_two_factor_validate_session($session, $request);
    if (is_wp_error($result)) {
        $code = $result->get_error_code();
        if ($code === 'two_factor_expired') {
            wp_send_json_error(
                [
                    'code'    => $code,
                    'message' => $result->get_error_message(),
                    'restart' => true,
                ]
            );
        }

        $error_payload = [
            'code'    => $code,
            'message' => $result->get_error_message(),
        ];

        $user = get_user_by('id', absint($session['user_id']));
        if ($user instanceof WP_User) {
            $refreshed = yooadmin_standalone_login_two_factor_renew_session_after_failure($session, $user, $request);
            if (is_array($refreshed)) {
                $error_payload['session'] = $refreshed;
            }
        }

        wp_send_json_error($error_payload);
    }

    if (is_array($result)) {
        wp_send_json_success($result);
    }

    $redirect_to = isset($session['redirect_to']) ? (string) $session['redirect_to'] : admin_url();
    $redirect_to = wp_validate_redirect($redirect_to, admin_url());

    if (($session['mode'] ?? '') === 'revalidate') {
        $redirect_to = function_exists('yooadmin_profile_2fa_revalidated_result_url')
            ? yooadmin_profile_2fa_revalidated_result_url($redirect_to)
            : add_query_arg('yooadmin_2fa_revalidated', '1', $redirect_to);
    }

    /**
     * Fires after successful inline 2FA on the standalone login page.
     *
     * @param WP_User $user
     * @param string  $redirect_to
     * @param array   $session
     */
    $user = get_user_by('id', absint($session['user_id']));
    if ($user instanceof WP_User && ($session['mode'] ?? '') !== 'revalidate') {
        do_action('yooadmin_standalone_login_two_factor_complete_login', $user, $redirect_to, $session);
    }

    wp_send_json_success(['redirect' => $redirect_to]);
}

/**
 * AJAX: refresh inline 2FA challenge (switch provider / resend).
 */
function yooadmin_standalone_login_ajax_two_factor_challenge(): void {
    if (!function_exists('yooadmin_standalone_login_ajax_verify_nonce')) {
        wp_send_json_error(['code' => 'forbidden', 'message' => __('Not allowed.', 'yooadmin')], 403);
    }

    yooadmin_standalone_login_ajax_verify_nonce();

    if (!function_exists('yooadmin_standalone_login_ajax_is_allowed') || !yooadmin_standalone_login_ajax_is_allowed()) {
        wp_send_json_error(['code' => 'forbidden', 'message' => __('Not allowed.', 'yooadmin')], 403);
    }

    // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; the session is server-generated JSON that is decoded then structurally validated, and each field is cast/verified on use.
    $session_raw = isset($_POST['session']) ? wp_unslash($_POST['session']) : '';
    if (is_string($session_raw) && $session_raw !== '') {
        $session = json_decode($session_raw, true);
    } else {
        $session = isset($_POST['session']) && is_array($_POST['session']) ? wp_unslash($_POST['session']) : [];
    }

    $provider = isset($_POST['provider']) ? sanitize_key(wp_unslash($_POST['provider'])) : '';
    $resend   = !empty($_POST['resend']);

    if ($resend) {
        $provider = isset($session['provider']) ? sanitize_key((string) $session['provider']) : $provider;
    }
    // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

    $session_valid = is_array($session)
        && !empty($session['user_id'])
        && (!yooadmin_standalone_login_two_factor_session_requires_nonce($session) || !empty($session['auth_nonce']));
    if (!$session_valid) {
        wp_send_json_error(
            [
                'code'    => 'invalid_session',
                'message' => __('Your verification session expired. Please sign in again.', 'yooadmin'),
                'restart' => true,
            ]
        );
    }

    if ($resend) {
        $user = get_user_by('id', absint($session['user_id']));
        if (!$user instanceof WP_User) {
            wp_send_json_error(['code' => 'two_factor_user_missing', 'message' => __('User not found.', 'yooadmin')]);
        }

        $resend_request = ['provider' => $provider];
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified above.
        foreach ($_POST as $key => $value) {
            if (in_array($key, ['action', 'nonce', 'session', 'resend', 'provider'], true)) {
                continue;
            }
            if (is_string($key) && (is_string($value) || is_numeric($value))) {
                $resend_request[$key] = (string) $value;
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $result = yooadmin_standalone_login_two_factor_validate_session($session, $resend_request);
        if (is_wp_error($result)) {
            $payload = [
                'code'    => $result->get_error_code(),
                'message' => $result->get_error_message(),
            ];
            $error_data = $result->get_error_data();
            if (is_array($error_data) && isset($error_data['retry_after'])) {
                $payload['retry_after'] = (int) $error_data['retry_after'];
            }
            wp_send_json_error($payload);
        }
        if (is_array($result)) {
            wp_send_json_success($result);
        }
    }

    $refreshed = yooadmin_standalone_login_two_factor_refresh_challenge($session, $provider);
    if (is_wp_error($refreshed)) {
        $payload = [
            'code'    => $refreshed->get_error_code(),
            'message' => $refreshed->get_error_message(),
        ];
        if ($refreshed->get_error_code() === 'two_factor_expired') {
            $payload['restart'] = true;
        }
        wp_send_json_error($payload);
    }

    wp_send_json_success($refreshed);
}

/**
 * Register 2FA AJAX handlers for guests and logged-in users.
 *
 * Deferred to `init` because this file loads before custom-login-standalone.php;
 * registering at parse time only attached nopriv handlers (revalidate runs while logged in).
 */
function yooadmin_standalone_login_two_factor_register_ajax_handlers(): void {
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;

    $pairs = [
        'yooadmin_sl_validate_2fa'        => 'yooadmin_standalone_login_ajax_validate_two_factor',
        'yooadmin_sl_two_factor_challenge'  => 'yooadmin_standalone_login_ajax_two_factor_challenge',
    ];

    foreach ($pairs as $action => $callback) {
        if (function_exists('yooadmin_standalone_login_register_ajax_handler')) {
            yooadmin_standalone_login_register_ajax_handler($action, $callback);
            continue;
        }

        add_action('wp_ajax_nopriv_' . $action, $callback);
        add_action('wp_ajax_' . $action, $callback);
    }
}
add_action('init', 'yooadmin_standalone_login_two_factor_register_ajax_handlers', 0);

/**
 * Bootstrap inline 2FA hooks.
 */
function yooadmin_standalone_login_two_factor_bootstrap(): void {
    add_action('wp_login', 'yooadmin_standalone_login_two_factor_handle_wp_login', 5, 2);
}
add_action('plugins_loaded', 'yooadmin_standalone_login_two_factor_bootstrap', 25);
