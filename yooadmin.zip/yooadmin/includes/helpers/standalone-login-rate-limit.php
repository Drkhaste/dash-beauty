<?php
/**
 * Login rate limiting (wp-login.php and standalone AJAX).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_get_request_client_ip')) {
    function yooadmin_get_request_client_ip(): string
    {
        if (empty($_SERVER['REMOTE_ADDR'])) {
            return '0.0.0.0';
        }

        $ip = sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR']));

        return preg_match('/^[a-f0-9:.]+$/i', $ip) ? $ip : '0.0.0.0';
    }
}

if (!function_exists('yooadmin_login_rate_limit_get_opts')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_login_rate_limit_get_opts(): array
    {
        if (function_exists('yooadmin_get_options')) {
            return yooadmin_get_options();
        }

        $opts = get_option('yooadmin_options', []);

        return is_array($opts) ? $opts : [];
    }
}

if (!function_exists('yooadmin_login_rate_limit_is_enabled')) {
    function yooadmin_login_rate_limit_is_enabled(): bool
    {
        $opts = yooadmin_login_rate_limit_get_opts();

        return !empty($opts['login_rate_limit_enabled']);
    }
}

if (!function_exists('yooadmin_login_rate_limit_is_active')) {
    /**
     * Rate limiting is on and applies to at least one login surface.
     */
    function yooadmin_login_rate_limit_is_active(): bool
    {
        if (!yooadmin_login_rate_limit_is_enabled()) {
            return false;
        }

        $opts = yooadmin_login_rate_limit_get_opts();
        $wp_login = !isset($opts['login_rate_limit_wp_login']) || !empty($opts['login_rate_limit_wp_login']);
        $standalone = !isset($opts['login_rate_limit_standalone']) || !empty($opts['login_rate_limit_standalone']);

        return $wp_login || $standalone;
    }
}

if (!function_exists('yooadmin_login_rate_limit_should_apply_standalone')) {
    function yooadmin_login_rate_limit_should_apply_standalone(): bool
    {
        if (!yooadmin_login_rate_limit_is_enabled()) {
            return false;
        }

        $opts = yooadmin_login_rate_limit_get_opts();

        return !isset($opts['login_rate_limit_standalone']) || !empty($opts['login_rate_limit_standalone']);
    }
}

if (!function_exists('yooadmin_login_rate_limit_key')) {
    function yooadmin_login_rate_limit_key(string $action, string $identifier = ''): string
    {
        $action = sanitize_key($action);
        $id     = sanitize_key(strtolower($identifier));

        return 'yooadmin_rl_' . $action . '_' . md5(yooadmin_get_request_client_ip() . '|' . $id);
    }
}

if (!function_exists('yooadmin_login_rate_limit_allows')) {
    function yooadmin_login_rate_limit_allows(string $action, int $max_attempts, int $window_seconds, string $identifier = ''): bool
    {
        if ($max_attempts <= 0 || $window_seconds <= 0) {
            return true;
        }

        $key    = yooadmin_login_rate_limit_key($action, $identifier);
        $record = get_transient($key);

        if (!is_array($record)) {
            return true;
        }

        return (int) ($record['count'] ?? 0) < $max_attempts;
    }
}

if (!function_exists('yooadmin_login_rate_limit_record_failure')) {
    function yooadmin_login_rate_limit_record_failure(string $action, int $window_seconds, string $identifier = ''): void
    {
        if ($window_seconds <= 0) {
            return;
        }

        $key    = yooadmin_login_rate_limit_key($action, $identifier);
        $record = get_transient($key);
        $count  = is_array($record) ? (int) ($record['count'] ?? 0) : 0;

        set_transient($key, ['count' => $count + 1], $window_seconds);
    }
}

if (!function_exists('yooadmin_login_rate_limit_clear')) {
    function yooadmin_login_rate_limit_clear(string $action, string $identifier = ''): void
    {
        delete_transient(yooadmin_login_rate_limit_key($action, $identifier));
    }
}

if (!function_exists('yooadmin_login_rate_limit_remaining_seconds')) {
    function yooadmin_login_rate_limit_remaining_seconds(string $action, string $identifier = ''): int
    {
        $key     = yooadmin_login_rate_limit_key($action, $identifier);
        $timeout = get_option('_transient_timeout_' . $key);

        if (!is_numeric($timeout)) {
            return 0;
        }

        return max(0, (int) $timeout - time());
    }
}

if (!function_exists('yooadmin_login_rate_limit_exceeded_message')) {
    /**
     * User-facing rate-limit message (distinct from wrong-password errors).
     *
     * @param string $action     login|lostpassword|resetpass
     * @param string $identifier Username or empty for IP-only buckets.
     */
    function yooadmin_login_rate_limit_exceeded_message(string $action, string $identifier = ''): string
    {
        $action = sanitize_key($action);
        $remaining = yooadmin_login_rate_limit_remaining_seconds($action, $identifier);
        $minutes   = max(1, (int) ceil($remaining / 60));

        if ($action === 'lostpassword') {
            /* translators: %d: minutes to wait before trying again. */
            $message = __('Too many password recovery requests. Please wait about %d minutes before trying again. This is not a sign-in or password error.', 'yooadmin');

            return sprintf($message, $minutes);
        }

        if ($action === 'resetpass') {
            /* translators: %d: minutes to wait before trying again. */
            $message = __('Too many password save attempts. Please wait about %d minutes before trying again.', 'yooadmin');

            return sprintf($message, $minutes);
        }

        if ($action === 'comment') {
            /* translators: %d: minutes to wait before trying again. */
            $message = __('Too many comment attempts. Please wait about %d minutes before trying again.', 'yooadmin');

            return sprintf($message, $minutes);
        }

        /* translators: %d: minutes to wait before trying again. */
        $message = __('Too many sign-in attempts. Please wait about %d minutes before trying again. This is not caused by an incorrect password.', 'yooadmin');

        return sprintf($message, $minutes);
    }
}

if (!function_exists('yooadmin_login_rate_limit_exceeded_response')) {
    function yooadmin_login_rate_limit_exceeded_response(string $action = 'login', string $identifier = ''): void
    {
        wp_send_json_error(
            [
                'code'    => 'rate_limited',
                'message' => yooadmin_login_rate_limit_exceeded_message($action, $identifier),
            ],
            429
        );
    }
}

if (!function_exists('yooadmin_login_rate_limit_settings')) {
    /**
     * @return array{login_max: int, login_window: int, lostpassword_max: int, lostpassword_window: int, resetpass_max: int, resetpass_window: int}
     */
    function yooadmin_login_rate_limit_settings(): array
    {
        $defaults = [
            'login_max'            => 10,
            'login_window'         => 15 * MINUTE_IN_SECONDS,
            'lostpassword_max'     => 5,
            'lostpassword_window'  => 15 * MINUTE_IN_SECONDS,
            'resetpass_max'        => 10,
            'resetpass_window'     => 15 * MINUTE_IN_SECONDS,
        ];

        if (!yooadmin_login_rate_limit_is_enabled()) {
            return [
                'login_max'           => 0,
                'login_window'        => 60,
                'lostpassword_max'    => 0,
                'lostpassword_window' => 60,
                'resetpass_max'       => 0,
                'resetpass_window'    => 60,
            ];
        }

        $opts = yooadmin_login_rate_limit_get_opts();

        $settings = [
            'login_max'           => isset($opts['login_rate_limit_login_max'])
                ? (int) $opts['login_rate_limit_login_max']
                : $defaults['login_max'],
            'login_window'        => isset($opts['login_rate_limit_login_window'])
                ? (int) $opts['login_rate_limit_login_window']
                : $defaults['login_window'],
            'lostpassword_max'    => isset($opts['login_rate_limit_lostpassword_max'])
                ? (int) $opts['login_rate_limit_lostpassword_max']
                : $defaults['lostpassword_max'],
            'lostpassword_window' => isset($opts['login_rate_limit_lostpassword_window'])
                ? (int) $opts['login_rate_limit_lostpassword_window']
                : $defaults['lostpassword_window'],
            'resetpass_max'       => isset($opts['login_rate_limit_resetpass_max'])
                ? (int) $opts['login_rate_limit_resetpass_max']
                : $defaults['resetpass_max'],
            'resetpass_window'    => isset($opts['login_rate_limit_resetpass_window'])
                ? (int) $opts['login_rate_limit_resetpass_window']
                : $defaults['resetpass_window'],
        ];

        /**
         * @param array<string, int> $settings Rate limit settings.
         */
        $settings = apply_filters('yooadmin_login_rate_limit_settings', $settings);

        if (!is_array($settings)) {
            $settings = [];
        }

        return [
            'login_max'           => max(1, (int) ($settings['login_max'] ?? $defaults['login_max'])),
            'login_window'        => max(60, (int) ($settings['login_window'] ?? $defaults['login_window'])),
            'lostpassword_max'    => max(1, (int) ($settings['lostpassword_max'] ?? $defaults['lostpassword_max'])),
            'lostpassword_window' => max(60, (int) ($settings['lostpassword_window'] ?? $defaults['lostpassword_window'])),
            'resetpass_max'       => max(1, (int) ($settings['resetpass_max'] ?? $defaults['resetpass_max'])),
            'resetpass_window'    => max(60, (int) ($settings['resetpass_window'] ?? $defaults['resetpass_window'])),
        ];
    }
}

// Backward-compatible aliases (standalone AJAX).
if (!function_exists('yooadmin_standalone_login_rate_limit_key')) {
    function yooadmin_standalone_login_rate_limit_key(string $action, string $identifier = ''): string
    {
        return yooadmin_login_rate_limit_key($action, $identifier);
    }
}

if (!function_exists('yooadmin_standalone_login_rate_limit_allows')) {
    function yooadmin_standalone_login_rate_limit_allows(string $action, int $max_attempts, int $window_seconds, string $identifier = ''): bool
    {
        if (!yooadmin_login_rate_limit_should_apply_standalone()) {
            return true;
        }

        if (
            $action === 'login'
            && $identifier !== ''
            && function_exists('yooadmin_email_recovery_login_has_grace')
            && yooadmin_email_recovery_login_has_grace($identifier)
        ) {
            return true;
        }

        return yooadmin_login_rate_limit_allows($action, $max_attempts, $window_seconds, $identifier);
    }
}

if (!function_exists('yooadmin_standalone_login_rate_limit_record_failure')) {
    function yooadmin_standalone_login_rate_limit_record_failure(string $action, int $window_seconds, string $identifier = ''): void
    {
        if (!yooadmin_login_rate_limit_should_apply_standalone()) {
            return;
        }

        if (
            $action === 'login'
            && $identifier !== ''
            && function_exists('yooadmin_email_recovery_login_has_grace')
            && yooadmin_email_recovery_login_has_grace($identifier)
        ) {
            return;
        }

        yooadmin_login_rate_limit_record_failure($action, $window_seconds, $identifier);
    }
}

if (!function_exists('yooadmin_standalone_login_rate_limit_clear')) {
    function yooadmin_standalone_login_rate_limit_clear(string $action, string $identifier = ''): void
    {
        yooadmin_login_rate_limit_clear($action, $identifier);
    }
}

if (!function_exists('yooadmin_standalone_login_rate_limit_exceeded_response')) {
    function yooadmin_standalone_login_rate_limit_exceeded_response(string $action = 'login', string $identifier = ''): void
    {
        yooadmin_login_rate_limit_exceeded_response($action, $identifier);
    }
}

if (!function_exists('yooadmin_standalone_login_rate_limit_settings')) {
    function yooadmin_standalone_login_rate_limit_settings(): array
    {
        return yooadmin_login_rate_limit_settings();
    }
}
