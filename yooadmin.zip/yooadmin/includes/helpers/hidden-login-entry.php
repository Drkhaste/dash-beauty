<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_hidden_login_entry_is_enabled')) {
    function yooadmin_hidden_login_entry_is_enabled(): bool
    {
        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];

        return !empty($opts['login_hidden_entry_enabled']) && yooadmin_hidden_login_entry_get_slug() !== '';
    }
}

if (!function_exists('yooadmin_hidden_login_entry_reserved_slugs')) {
    /**
     * @return string[]
     */
    function yooadmin_hidden_login_entry_reserved_slugs(): array
    {
        return [
            'wp-admin',
            'wp-login',
            'wp-login.php',
            'wp-content',
            'wp-includes',
            'wp-json',
            'yooadmin-login',
            'admin',
            'login',
            'author',
            'feed',
            'xmlrpc.php',
        ];
    }
}

if (!function_exists('yooadmin_hidden_login_entry_sanitize_slug')) {
    function yooadmin_hidden_login_entry_sanitize_slug(string $raw): string
    {
        $slug = sanitize_title($raw);
        $slug = trim((string) $slug, '-');

        if ($slug === '' || strlen($slug) < 3) {
            return '';
        }

        if (strlen($slug) > 40) {
            $slug = substr($slug, 0, 40);
        }

        if (in_array($slug, yooadmin_hidden_login_entry_reserved_slugs(), true)) {
            return '';
        }

        return $slug;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_get_slug')) {
    function yooadmin_hidden_login_entry_get_slug(): string
    {
        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
        $raw  = isset($opts['login_hidden_entry_slug']) ? (string) $opts['login_hidden_entry_slug'] : '';

        return yooadmin_hidden_login_entry_sanitize_slug($raw);
    }
}

if (!function_exists('yooadmin_hidden_login_entry_uses_pretty_permalinks')) {
    function yooadmin_hidden_login_entry_uses_pretty_permalinks(): bool
    {
        return (string) get_option('permalink_structure', '') !== '';
    }
}

if (!function_exists('yooadmin_hidden_login_entry_slug_input_prefix')) {
    function yooadmin_hidden_login_entry_slug_input_prefix(): string
    {
        return user_trailingslashit(home_url('/'));
    }
}

if (!function_exists('yooadmin_hidden_login_entry_url')) {
    /**
     * @param string $redirect Optional redirect_to target after login.
     */
    function yooadmin_hidden_login_entry_url(string $redirect = ''): string
    {
        $slug = yooadmin_hidden_login_entry_get_slug();
        if ($slug === '') {
            return home_url('/');
        }

        if (yooadmin_hidden_login_entry_uses_pretty_permalinks()) {
            $url = user_trailingslashit(home_url('/' . $slug . '/'));
        } else {
            $url = add_query_arg(
                [
                    'yooadmin_secret_login' => '1',
                    'hl'                    => $slug,
                ],
                home_url('/')
            );
        }

        if ($redirect !== '') {
            $validated = wp_validate_redirect($redirect, '');
            if (is_string($validated) && $validated !== '') {
                if (yooadmin_hidden_login_entry_url_matches_secret_route($validated)) {
                    $parts = wp_parse_url($validated);
                    $query = [];
                    if (!empty($parts['query'])) {
                        parse_str((string) $parts['query'], $query);
                    }

                    return $query !== [] ? add_query_arg($query, $url) : $validated;
                }

                $url = add_query_arg('redirect_to', $validated, $url);
            }
        }

        return $url;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_url_matches_secret_route')) {
    function yooadmin_hidden_login_entry_url_matches_secret_route(string $candidate): bool
    {
        $candidate = esc_url_raw($candidate);
        if ($candidate === '' || !yooadmin_hidden_login_entry_is_enabled()) {
            return false;
        }

        $slug = yooadmin_hidden_login_entry_get_slug();
        if ($slug === '') {
            return false;
        }

        $parts = wp_parse_url($candidate);
        if (!is_array($parts)) {
            return false;
        }

        $path = isset($parts['path']) ? untrailingslashit((string) $parts['path']) : '';
        if ($path !== '') {
            $expected = untrailingslashit((string) wp_parse_url(home_url('/' . $slug . '/'), PHP_URL_PATH));
            if ($expected !== '' && strcasecmp($path, $expected) === 0) {
                return true;
            }
        }

        if (!empty($parts['query'])) {
            parse_str((string) $parts['query'], $query);
            if (
                isset($query['yooadmin_secret_login'])
                && (string) $query['yooadmin_secret_login'] === '1'
                && isset($query['hl'])
                && yooadmin_hidden_login_entry_sanitize_slug((string) $query['hl']) === $slug
            ) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_should_block_visitor')) {
    function yooadmin_hidden_login_entry_should_block_visitor(): bool
    {
        if (!yooadmin_hidden_login_entry_is_enabled()) {
            return false;
        }

        return !is_user_logged_in();
    }
}

if (!function_exists('yooadmin_hidden_login_entry_request_path')) {
    function yooadmin_hidden_login_entry_request_path(): string
    {
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Parsed path only.
        $req = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
        $path = wp_parse_url(sanitize_text_field((string) $req), PHP_URL_PATH);

        return is_string($path) ? untrailingslashit($path) : '';
    }
}

if (!function_exists('yooadmin_hidden_login_entry_is_secret_request')) {
    function yooadmin_hidden_login_entry_is_secret_request(): bool
    {
        if (!yooadmin_hidden_login_entry_is_enabled()) {
            return false;
        }

        $slug = yooadmin_hidden_login_entry_get_slug();
        if ($slug === '') {
            return false;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login route detection.
        if (isset($_GET['yooadmin_secret_login']) && '1' === sanitize_text_field(wp_unslash($_GET['yooadmin_secret_login']))) {
            if ((string) get_option('permalink_structure', '') === '') {
                $hl_raw = isset($_GET['hl']) ? sanitize_text_field(wp_unslash((string) $_GET['hl'])) : '';
                $hl     = $hl_raw !== '' ? yooadmin_hidden_login_entry_sanitize_slug($hl_raw) : '';

                return $hl === $slug;
            }

            return true;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if ((string) get_option('permalink_structure', '') === '') {
            return false;
        }

        $expected = wp_parse_url(home_url('/' . $slug . '/'), PHP_URL_PATH);
        if (!is_string($expected) || $expected === '') {
            return false;
        }

        return strcasecmp(yooadmin_hidden_login_entry_request_path(), untrailingslashit($expected)) === 0;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_is_wp_admin_request')) {
    function yooadmin_hidden_login_entry_is_wp_admin_request(): bool
    {
        if (is_admin()) {
            return true;
        }

        $path = yooadmin_hidden_login_entry_request_path();
        if ($path !== '' && preg_match('#/wp-admin(/|$)#i', $path)) {
            return true;
        }

        $script = isset($_SERVER['PHP_SELF']) ? basename(sanitize_text_field(wp_unslash($_SERVER['PHP_SELF']))) : '';

        return in_array($script, ['admin.php', 'index.php', 'admin-post.php'], true)
            && $path !== ''
            && preg_match('#/wp-admin(/|$)#i', $path);
    }
}

if (!function_exists('yooadmin_hidden_login_entry_send_404')) {
    /**
     * Same decoy response as blocked wp-admin: maintenance page when enabled, else branded/theme 404.
     */
    function yooadmin_hidden_login_entry_send_404(): void
    {
        if (
            function_exists('yooadmin_maintenance_mode_is_enabled')
            && yooadmin_maintenance_mode_is_enabled()
            && function_exists('yooadmin_maintenance_mode_user_can_bypass')
            && !yooadmin_maintenance_mode_user_can_bypass()
            && function_exists('yooadmin_maintenance_render_page')
        ) {
            yooadmin_maintenance_render_page();
        }

        if (function_exists('yooadmin_public_site_render_theme_404')) {
            yooadmin_public_site_render_theme_404();
        }

        if (function_exists('yooadmin_public_site_error_render_404')) {
            yooadmin_public_site_error_render_404();
        }

        status_header(404);
        nocache_headers();
        exit;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_gate_ttl')) {
    function yooadmin_hidden_login_entry_gate_ttl(): int
    {
        return (int) apply_filters('yooadmin_hidden_login_entry_gate_ttl', 20 * MINUTE_IN_SECONDS);
    }
}

if (!function_exists('yooadmin_hidden_login_entry_access_cookie_name')) {
    function yooadmin_hidden_login_entry_access_cookie_name(): string
    {
        return 'yooadmin_hl_gate';
    }
}

if (!function_exists('yooadmin_hidden_login_entry_gate_transient_key')) {
    function yooadmin_hidden_login_entry_gate_transient_key(string $token): string
    {
        return 'yooadmin_hl_gt_' . wp_hash($token, 'yooadmin_hl_gate_t');
    }
}

if (!function_exists('yooadmin_hidden_login_entry_issue_gate_token')) {
    function yooadmin_hidden_login_entry_issue_gate_token(): string
    {
        $token = wp_generate_password(32, false, false);
        set_transient(
            yooadmin_hidden_login_entry_gate_transient_key($token),
            time(),
            yooadmin_hidden_login_entry_gate_ttl()
        );

        return $token;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_verify_gate_token')) {
    function yooadmin_hidden_login_entry_verify_gate_token(string $token): bool
    {
        $token = sanitize_text_field($token);

        return $token !== ''
            && strlen($token) >= 20
            && get_transient(yooadmin_hidden_login_entry_gate_transient_key($token)) !== false;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_current_gate_token')) {
    function yooadmin_hidden_login_entry_current_gate_token(): string
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing -- Gate token routing only.
        if (!empty($_POST['yooadmin_hl_gate']) && is_string($_POST['yooadmin_hl_gate'])) {
            return sanitize_text_field(wp_unslash($_POST['yooadmin_hl_gate']));
        }

        if (!empty($_GET['yooadmin_hl_gate']) && is_string($_GET['yooadmin_hl_gate'])) {
            return sanitize_text_field(wp_unslash($_GET['yooadmin_hl_gate']));
        }

        $name = yooadmin_hidden_login_entry_access_cookie_name();
        if (!empty($_COOKIE[ $name ]) && is_string($_COOKIE[ $name ])) {
            return sanitize_text_field(wp_unslash($_COOKIE[ $name ]));
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing

        return '';
    }
}

if (!function_exists('yooadmin_hidden_login_entry_persist_gate_token')) {
    function yooadmin_hidden_login_entry_persist_gate_token(string $token): void
    {
        if ($token === '' || headers_sent()) {
            return;
        }

        $name    = yooadmin_hidden_login_entry_access_cookie_name();
        $expires = time() + yooadmin_hidden_login_entry_gate_ttl();
        $secure  = is_ssl();

        setcookie($name, $token, $expires, COOKIEPATH, COOKIE_DOMAIN, $secure, true);
        if (SITECOOKIEPATH !== COOKIEPATH) {
            setcookie($name, $token, $expires, SITECOOKIEPATH, COOKIE_DOMAIN, $secure, true);
        }

        $_COOKIE[ $name ] = $token;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_grant_wp_login_access')) {
    /**
     * Issue a short-lived gate token after a secret-login entry request.
     */
    function yooadmin_hidden_login_entry_grant_wp_login_access(): string
    {
        if (!yooadmin_hidden_login_entry_is_enabled()) {
            return '';
        }

        $token = yooadmin_hidden_login_entry_issue_gate_token();
        yooadmin_hidden_login_entry_persist_gate_token($token);

        return $token;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_has_wp_login_access')) {
    function yooadmin_hidden_login_entry_has_wp_login_access(): bool
    {
        if (!yooadmin_hidden_login_entry_is_enabled()) {
            return true;
        }

        if (!yooadmin_hidden_login_entry_should_block_visitor()) {
            return true;
        }

        return yooadmin_hidden_login_entry_verify_gate_token(
            yooadmin_hidden_login_entry_current_gate_token()
        );
    }
}

if (!function_exists('yooadmin_hidden_login_entry_append_gate_to_args')) {
    /**
     * @param array<string, scalar|null> $args Query arguments.
     * @return array<string, scalar|null>
     */
    function yooadmin_hidden_login_entry_append_gate_to_args(array $args, string $token = ''): array
    {
        if ($token === '') {
            $token = yooadmin_hidden_login_entry_current_gate_token();
        }
        if ($token === '' || !yooadmin_hidden_login_entry_verify_gate_token($token)) {
            $token = yooadmin_hidden_login_entry_grant_wp_login_access();
        }

        if ($token !== '') {
            $args['yooadmin_hl_gate'] = $token;
        }

        return $args;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_print_gate_field')) {
    function yooadmin_hidden_login_entry_print_gate_field(): void
    {
        if (!yooadmin_hidden_login_entry_is_enabled() || !yooadmin_hidden_login_entry_should_block_visitor()) {
            return;
        }

        $token = yooadmin_hidden_login_entry_current_gate_token();
        if ($token === '' || !yooadmin_hidden_login_entry_verify_gate_token($token)) {
            return;
        }

        echo '<input type="hidden" name="yooadmin_hl_gate" value="' . esc_attr($token) . '" />';
    }
}

if (!function_exists('yooadmin_hidden_login_entry_is_two_factor_wp_login_request')) {
    function yooadmin_hidden_login_entry_is_two_factor_wp_login_request(): bool
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing -- Public 2FA step routing.
        $action = '';
        if (isset($_REQUEST['action']) && is_string($_REQUEST['action'])) {
            $action = sanitize_key(wp_unslash($_REQUEST['action']));
        }

        if (!in_array($action, ['validate_2fa', 'revalidate_2fa'], true)) {
            return false;
        }

        if ($action === 'revalidate_2fa' && is_user_logged_in()) {
            return true;
        }

        $user_id    = !empty($_REQUEST['wp-auth-id']) ? absint($_REQUEST['wp-auth-id']) : 0;
        $auth_nonce = !empty($_REQUEST['wp-auth-nonce']) ? sanitize_text_field(wp_unslash((string) $_REQUEST['wp-auth-nonce'])) : '';

        return $user_id > 0 && $auth_nonce !== '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
    }
}

if (!function_exists('yooadmin_hidden_login_entry_wp_login_is_allowed')) {
    function yooadmin_hidden_login_entry_wp_login_is_allowed(): bool
    {
        if (!yooadmin_hidden_login_entry_should_block_visitor()) {
            return true;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- wp-login.php routing.
        if (isset($_GET['key']) || isset($_GET['login'])) {
            return true;
        }

        if (yooadmin_hidden_login_entry_is_two_factor_wp_login_request()) {
            return true;
        }

        if (yooadmin_hidden_login_entry_has_wp_login_access()) {
            return true;
        }

        $method_raw = isset($_SERVER['REQUEST_METHOD']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'])) : 'GET';
        if (strtoupper($method_raw) === 'POST') {
            // phpcs:disable WordPress.Security.NonceVerification.Missing -- Public login/recovery handoff; nonces are verified in dedicated handlers.
            if (!empty($_POST['wp-auth-nonce']) && !empty($_POST['wp-auth-id'])) {
                return true;
            }

            if (
                isset($_POST['yooadmin_recover_email_nonce'])
                && isset($_POST['key'])
                && isset($_POST['login'])
            ) {
                return true;
            }
            // phpcs:enable WordPress.Security.NonceVerification.Missing

            return false;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return false;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_register_rewrites')) {
    function yooadmin_hidden_login_entry_register_rewrites(): void
    {
        if (!yooadmin_hidden_login_entry_is_enabled()) {
            return;
        }

        $slug = yooadmin_hidden_login_entry_get_slug();
        if ($slug === '' || (string) get_option('permalink_structure', '') === '') {
            return;
        }

        add_rewrite_rule('^' . preg_quote($slug, '#') . '/?$', 'index.php?yooadmin_secret_login=1', 'top');
    }
}

if (!function_exists('yooadmin_hidden_login_entry_query_vars')) {
    /**
     * @param string[] $vars
     * @return string[]
     */
    function yooadmin_hidden_login_entry_query_vars(array $vars): array
    {
        $vars[] = 'yooadmin_secret_login';

        return $vars;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_parse_request')) {
    /**
     * @param WP $wp WordPress environment.
     */
    function yooadmin_hidden_login_entry_parse_request($wp): void
    {
        if (!($wp instanceof WP) || is_admin() || !yooadmin_hidden_login_entry_is_enabled()) {
            return;
        }
        if ((string) get_option('permalink_structure', '') === '') {
            return;
        }
        if (!empty($wp->query_vars['yooadmin_secret_login'])) {
            return;
        }
        if (!yooadmin_hidden_login_entry_is_secret_request()) {
            return;
        }

        $wp->query_vars['yooadmin_secret_login'] = '1';
    }
}

if (!function_exists('yooadmin_hidden_login_entry_pre_handle_404')) {
    /**
     * @param bool     $preempt  Whether to short-circuit 404.
     * @param WP_Query $wp_query Main query.
     * @return bool
     */
    function yooadmin_hidden_login_entry_pre_handle_404($preempt, $wp_query)
    {
        if ($preempt || !($wp_query instanceof WP_Query) || !$wp_query->is_main_query()) {
            return $preempt;
        }
        if (!yooadmin_hidden_login_entry_is_secret_request()) {
            return $preempt;
        }

        return true;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_get_rewrite_signature')) {
    function yooadmin_hidden_login_entry_get_rewrite_signature(): string
    {
        return md5(
            implode(
                '|',
                [
                    defined('YOOADMIN_VERSION') ? (string) YOOADMIN_VERSION : '0',
                    (string) get_option('permalink_structure', ''),
                    yooadmin_hidden_login_entry_is_enabled() ? '1' : '0',
                    yooadmin_hidden_login_entry_get_slug(),
                ]
            )
        );
    }
}

if (!function_exists('yooadmin_hidden_login_entry_maybe_flush_rewrite_rules')) {
    function yooadmin_hidden_login_entry_maybe_flush_rewrite_rules(): void
    {
        $opt = 'yooadmin_hidden_login_entry_rewrite_signature';
        $sig = yooadmin_hidden_login_entry_get_rewrite_signature();
        if (get_option($opt, '') === $sig) {
            return;
        }

        if (function_exists('yooadmin_standalone_login_flush_rewrite_rules')) {
            yooadmin_standalone_login_flush_rewrite_rules();
        } else {
            flush_rewrite_rules(false);
        }

        update_option($opt, $sig, false);
    }
}

if (!function_exists('yooadmin_hidden_login_entry_maybe_block_wp_login')) {
    function yooadmin_hidden_login_entry_maybe_block_wp_login(): void
    {
        if (!yooadmin_hidden_login_entry_should_block_visitor()) {
            return;
        }
        if (yooadmin_hidden_login_entry_wp_login_is_allowed()) {
            return;
        }

        yooadmin_hidden_login_entry_send_404();
    }
}

if (!function_exists('yooadmin_hidden_login_entry_maybe_block_wp_admin')) {
    function yooadmin_hidden_login_entry_maybe_block_wp_admin(): void
    {
        if (!yooadmin_hidden_login_entry_should_block_visitor()) {
            return;
        }

        if (defined('DOING_AJAX') && DOING_AJAX) {
            return;
        }
        if (defined('DOING_CRON') && DOING_CRON) {
            return;
        }
        if (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
            return;
        }

        $script = isset($_SERVER['PHP_SELF']) ? basename(sanitize_text_field(wp_unslash($_SERVER['PHP_SELF']))) : '';
        if (in_array($script, ['admin-ajax.php', 'async-upload.php'], true)) {
            return;
        }

        if (!yooadmin_hidden_login_entry_is_wp_admin_request()) {
            return;
        }

        yooadmin_hidden_login_entry_send_404();
    }
}

if (!function_exists('yooadmin_hidden_login_entry_filter_auth_redirect_to_login')) {
    /**
     * @param string $location Redirect target.
     * @param int    $status   HTTP status.
     * @return string
     */
    function yooadmin_hidden_login_entry_filter_auth_redirect_to_login($location, $status)
    {
        unset($status);

        if (!yooadmin_hidden_login_entry_should_block_visitor()) {
            return $location;
        }

        if (!yooadmin_hidden_login_entry_is_wp_admin_request()) {
            return $location;
        }

        if (!is_string($location) || $location === '') {
            return $location;
        }

        $login_url = wp_login_url();
        $secret    = yooadmin_hidden_login_entry_url();
        $targets   = array_filter([$login_url, $secret]);

        foreach ($targets as $target) {
            if ($target === '' || strpos($location, $target) !== 0) {
                continue;
            }

            yooadmin_hidden_login_entry_grant_wp_login_access();

            if ($secret !== '' && strpos($location, $secret) !== 0) {
                wp_safe_redirect($secret);
                exit;
            }

            return $location;
        }

        return $location;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_block_public_login_routes')) {
    function yooadmin_hidden_login_entry_block_public_login_routes(): void
    {
        if (!yooadmin_hidden_login_entry_should_block_visitor()) {
            return;
        }
        if (yooadmin_hidden_login_entry_is_secret_request()) {
            return;
        }

        if (function_exists('yooadmin_standalone_login_is_this_request') && yooadmin_standalone_login_is_this_request()) {
            yooadmin_hidden_login_entry_send_404();
        }
    }
}

if (!function_exists('yooadmin_hidden_login_entry_filter_login_url')) {
    /**
     * @param string $login_url    Login URL.
     * @param string $redirect     Redirect target.
     * @param bool   $force_reauth Force reauth.
     */
    function yooadmin_hidden_login_entry_filter_login_url($login_url, $redirect, $force_reauth): string
    {
        if (!yooadmin_hidden_login_entry_is_enabled()) {
            return (string) $login_url;
        }

        $url = yooadmin_hidden_login_entry_url(is_string($redirect) ? $redirect : '');
        if ($force_reauth) {
            $url = add_query_arg('reauth', '1', $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_bootstrap')) {
    function yooadmin_hidden_login_entry_bootstrap(): void
    {
        add_action('init', 'yooadmin_hidden_login_entry_register_rewrites', 8);
        add_filter('query_vars', 'yooadmin_hidden_login_entry_query_vars');
        add_action('parse_request', 'yooadmin_hidden_login_entry_parse_request', 0);
        add_filter('pre_handle_404', 'yooadmin_hidden_login_entry_pre_handle_404', 10, 2);
        add_action('init', 'yooadmin_hidden_login_entry_maybe_flush_rewrite_rules', 998);
        add_action('login_init', 'yooadmin_hidden_login_entry_maybe_block_wp_login', 0);
        add_action('login_form', 'yooadmin_hidden_login_entry_print_gate_field', 1);
        add_action('lostpassword_form', 'yooadmin_hidden_login_entry_print_gate_field', 1);
        add_action('resetpass_form', 'yooadmin_hidden_login_entry_print_gate_field', 1);
        add_action('init', 'yooadmin_hidden_login_entry_maybe_block_wp_admin', 1);
        add_action('admin_init', 'yooadmin_hidden_login_entry_maybe_block_wp_admin', 0);
        add_action('template_redirect', 'yooadmin_hidden_login_entry_block_public_login_routes', -1);
        add_filter('wp_redirect', 'yooadmin_hidden_login_entry_filter_auth_redirect_to_login', 0, 2);
        add_filter('login_url', 'yooadmin_hidden_login_entry_filter_login_url', 10, 3);

        if (yooadmin_hidden_login_entry_is_enabled()) {
            add_filter('site_url', 'yooadmin_hidden_login_entry_filter_site_url_login', 10, 4);
        }

        add_action('wp_logout', 'yooadmin_hidden_login_entry_on_wp_logout', 20);
    }
}

if (!function_exists('yooadmin_hidden_login_entry_must_use_core_wp_login')) {
    /**
     * @param array<string, string> $query Parsed query args from the login URL.
     */
    function yooadmin_hidden_login_entry_must_use_core_wp_login(array $query): bool
    {
        if (
            function_exists('yooadmin_login_prefers_standalone_for_query')
            && yooadmin_login_prefers_standalone_for_query($query)
        ) {
            return false;
        }

        if (isset($query['action'])) {
            $action = sanitize_key((string) $query['action']);
            $core_actions = [
                'logout',
                'lostpassword',
                'retrievepassword',
                'rp',
                'resetpass',
                'checkemail',
                'confirm_admin_email',
                'postpass',
                'register',
                'validate_2fa',
                'revalidate_2fa',
            ];

            if (in_array($action, $core_actions, true)) {
                return true;
            }
        }

        if (isset($query['key']) || isset($query['login']) || isset($query['reauth'])) {
            return true;
        }

        if (isset($query['yooadmin_email_recovered']) || isset($query['yooadmin_2fa_revalidated'])) {
            return true;
        }

        if (!empty($query['yooadmin_hl_gate'])) {
            return true;
        }

        if (isset($query['action']) && sanitize_key((string) $query['action']) === 'yooadmin_recover_email') {
            return true;
        }

        return (bool) apply_filters('yooadmin_hidden_login_entry_must_use_core_wp_login', false, $query);
    }
}

if (!function_exists('yooadmin_hidden_login_entry_filter_site_url_login')) {
    /**
     * @param string      $url     Complete URL.
     * @param string      $path    Path relative to site URL.
     * @param string|null $scheme  Scheme.
     * @param int|null    $blog_id Blog ID.
     */
    function yooadmin_hidden_login_entry_filter_site_url_login($url, $path, $scheme, $blog_id): string
    {
        unset($blog_id);
        $path = (string) $path;
        if ($path === '' || stripos($path, 'wp-login.php') === false) {
            return (string) $url;
        }

        if ($scheme === 'login_post') {
            return (string) $url;
        }

        $parts = wp_parse_url((string) $url);
        $query = [];
        if (!empty($parts['query'])) {
            parse_str((string) $parts['query'], $query);
        }

        if (yooadmin_hidden_login_entry_must_use_core_wp_login($query)) {
            return (string) $url;
        }

        $dest = yooadmin_hidden_login_entry_url();
        if ($query !== []) {
            $dest = add_query_arg($query, $dest);
        }

        return $dest;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_on_wp_logout')) {
    function yooadmin_hidden_login_entry_on_wp_logout(): void
    {
        $path   = COOKIEPATH ?: '/';
        $domain = COOKIE_DOMAIN;
        $secure = is_ssl();

        if (!headers_sent()) {
            setcookie('yoo_focus', '', time() - YEAR_IN_SECONDS, $path, $domain, $secure, true);
        }
        unset($_COOKIE['yoo_focus']);
    }
}

if (!function_exists('yooadmin_hidden_login_entry_core_wp_login_url')) {
    /**
     * @param array<string, scalar|null> $args Query arguments.
     */
    function yooadmin_hidden_login_entry_core_wp_login_url(array $args = []): string
    {
        $url = home_url('/wp-login.php', 'login');

        if ($args !== []) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_build_core_login_redirect_args')) {
    /**
     * @return array<string, string>
     */
    function yooadmin_hidden_login_entry_build_core_login_redirect_args(): array
    {
        $args = [];

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login query args.
        if (
            function_exists('yooadmin_profile_is_public_email_confirm_request')
            && yooadmin_profile_is_public_email_confirm_request()
            && function_exists('yooadmin_public_login_request_url')
        ) {
            $args['redirect_to'] = yooadmin_public_login_request_url();
        } elseif (isset($_GET['redirect_to'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- wp_validate_redirect().
            $maybe = wp_validate_redirect(wp_unslash($_GET['redirect_to']), admin_url());
            if (is_string($maybe) && $maybe !== '') {
                $args['redirect_to'] = $maybe;
            }
            if (
                isset($args['redirect_to'])
                && function_exists('yooadmin_public_login_merge_orphaned_query_arg')
            ) {
                $args['redirect_to'] = yooadmin_public_login_merge_orphaned_query_arg($args['redirect_to'], 'newuseremail');
            }
        }

        foreach ($_GET as $key => $value) {
            if (!is_string($key) || $key === 'redirect_to' || !is_scalar($value)) {
                continue;
            }

            $safe_key = sanitize_key($key);
            if ($safe_key === '') {
                continue;
            }

            $args[ $safe_key ] = sanitize_text_field(wp_unslash((string) $value));
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return $args;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_render_core_login_page')) {
    function yooadmin_hidden_login_entry_render_core_login_page(): void
    {
        if (is_user_logged_in()) {
            $redirect = admin_url();
            $args     = yooadmin_hidden_login_entry_build_core_login_redirect_args();
            if (!empty($args['redirect_to'])) {
                $redirect = $args['redirect_to'];
            }
            wp_safe_redirect($redirect);
            exit;
        }

        $token = yooadmin_hidden_login_entry_grant_wp_login_access();
        $args  = yooadmin_hidden_login_entry_append_gate_to_args(
            yooadmin_hidden_login_entry_build_core_login_redirect_args(),
            $token
        );
        wp_safe_redirect(yooadmin_hidden_login_entry_core_wp_login_url($args));
        exit;
    }
}

if (!function_exists('yooadmin_hidden_login_entry_on_options_updated')) {
    /**
     * @param mixed $old_value Previous options.
     * @param mixed $new_value New options.
     */
    function yooadmin_hidden_login_entry_on_options_updated($old_value, $new_value): void
    {
        unset($old_value, $new_value);
        delete_option('yooadmin_hidden_login_entry_rewrite_signature');
    }
}
add_action('update_option_yooadmin_options', 'yooadmin_hidden_login_entry_on_options_updated', 10, 2);
add_action('plugins_loaded', 'yooadmin_hidden_login_entry_bootstrap', 21);
