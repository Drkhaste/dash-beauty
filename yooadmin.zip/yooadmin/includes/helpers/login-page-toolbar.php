<?php
/**
 * Standalone login page toolbar (appearance + language for logged-out visitors).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_login_toolbar_locale_is_usable')) {
    function yooadmin_login_toolbar_locale_is_usable(string $locale): bool
    {
        if ($locale === '' || $locale === 'site-default') {
            return false;
        }

        if ($locale === 'en_US') {
            return true;
        }

        $installed = get_available_languages();
        if (!is_array($installed)) {
            $installed = [];
        }

        return in_array($locale, $installed, true);
    }
}

if (!function_exists('yooadmin_login_toolbar_resolve_visitor_locale')) {
    /**
     * Locale for standalone login (wp-login.php wp_lang logic is not applied there by core).
     */
    function yooadmin_login_toolbar_resolve_visitor_locale(): ?string
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login language switch.
        if (isset($_GET['yoo_reset_lang']) && sanitize_text_field(wp_unslash((string) $_GET['yoo_reset_lang'])) === '1') {
            $site = get_locale();
            return is_string($site) && $site !== '' ? $site : 'en_US';
        }

        $wp_lang_get = isset($_GET['wp_lang'])
            ? sanitize_text_field(wp_unslash((string) $_GET['wp_lang']))
            : '';
        if ($wp_lang_get !== '') {
            $lang = yooadmin_sanitize_locale_name($wp_lang_get);
            if (yooadmin_login_toolbar_locale_is_usable($lang)) {
                return $lang;
            }
        }

        $wp_lang_cookie = isset($_COOKIE['wp_lang'])
            ? sanitize_text_field(wp_unslash((string) $_COOKIE['wp_lang']))
            : '';
        if ($wp_lang_cookie !== '') {
            $lang = yooadmin_sanitize_locale_name($wp_lang_cookie);
            if (yooadmin_login_toolbar_locale_is_usable($lang)) {
                return $lang;
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return null;
    }
}

if (!function_exists('yooadmin_login_toolbar_pre_determine_locale')) {
    function yooadmin_login_toolbar_pre_determine_locale($locale)
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Early locale; read-only.
        $has_lang_pref = !empty($_GET['wp_lang'])
            || !empty($_GET['yoo_reset_lang'])
            || !empty($_COOKIE['wp_lang']);
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if (!$has_lang_pref) {
            return $locale;
        }

        $is_login = function_exists('yooadmin_standalone_login_is_this_request')
            && yooadmin_standalone_login_is_this_request();
        $is_login_ajax = function_exists('yooadmin_standalone_login_is_ajax_request')
            && yooadmin_standalone_login_is_ajax_request();
        $is_recovery = function_exists('yooadmin_email_recovery_is_request')
            && yooadmin_email_recovery_is_request()
            && function_exists('yooadmin_email_recovery_is_public_login_request')
            && yooadmin_email_recovery_is_public_login_request();
        $is_maintenance = function_exists('yooadmin_maintenance_mode_is_enabled')
            && yooadmin_maintenance_mode_is_enabled()
            && !(function_exists('yooadmin_maintenance_request_is_excluded') && yooadmin_maintenance_request_is_excluded());
        if (!$is_login && !$is_maintenance && !$is_login_ajax && !$is_recovery) {
            return $locale;
        }

        $resolved = yooadmin_login_toolbar_resolve_visitor_locale();
        if ($resolved !== null) {
            return $resolved;
        }

        return $locale;
    }
}
add_filter('pre_determine_locale', 'yooadmin_login_toolbar_pre_determine_locale', 1);

if (!function_exists('yooadmin_login_toolbar_sync_language_cookie')) {
    function yooadmin_login_toolbar_sync_language_cookie(): void
    {
        $is_login = function_exists('yooadmin_standalone_login_is_this_request')
            && yooadmin_standalone_login_is_this_request();
        $is_recovery = function_exists('yooadmin_email_recovery_is_request')
            && yooadmin_email_recovery_is_request()
            && function_exists('yooadmin_email_recovery_is_public_login_request')
            && yooadmin_email_recovery_is_public_login_request();
        $is_maintenance = function_exists('yooadmin_maintenance_mode_is_enabled')
            && yooadmin_maintenance_mode_is_enabled()
            && !(function_exists('yooadmin_maintenance_request_is_excluded') && yooadmin_maintenance_request_is_excluded());
        if (!$is_login && !$is_maintenance && !$is_recovery) {
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login language cookie (same as wp-login.php).
        $secure = is_ssl();

        if (isset($_GET['yoo_reset_lang']) && sanitize_text_field(wp_unslash((string) $_GET['yoo_reset_lang'])) === '1') {
            setcookie('wp_lang', '', time() - YEAR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, $secure, true);
            $target = remove_query_arg(['yoo_reset_lang', 'wp_lang'], yooadmin_login_toolbar_get_request_url());
            wp_safe_redirect($target);
            exit;
        }

        if (isset($_GET['wp_lang'])) {
            $wp_lang_get = sanitize_text_field(wp_unslash((string) $_GET['wp_lang']));
            $lang        = yooadmin_sanitize_locale_name($wp_lang_get);
            if (yooadmin_login_toolbar_locale_is_usable($lang)) {
                setcookie('wp_lang', $lang, 0, COOKIEPATH, COOKIE_DOMAIN, $secure, true);
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
    }
}
add_action('template_redirect', 'yooadmin_login_toolbar_sync_language_cookie', 0);

if (!function_exists('yooadmin_login_toolbar_get_appearance_choices')) {
    /**
     * @return array<string, array{label: string, icon: string}>
     */
    function yooadmin_login_toolbar_get_appearance_choices(): array
    {
        $svg_light = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('light', 14) : '';
        $svg_dark  = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('dark', 14) : '';
        $icon_auto = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('auto', 14) : '';

        return [
            'light' => [
                'label' => __('Light', 'yooadmin'),
                'icon'  => $svg_light,
            ],
            'dark'  => [
                'label' => __('Dark', 'yooadmin'),
                'icon'  => $svg_dark,
            ],
            'auto'  => [
                'label' => __('Auto', 'yooadmin'),
                'icon'  => $icon_auto,
            ],
        ];
    }
}

if (!function_exists('yooadmin_login_toolbar_get_language_locales')) {
    /**
     * Locale codes available on the login screen (site default + packs).
     *
     * @return string[]
     */
    function yooadmin_login_toolbar_get_language_locales(): array
    {
        if (function_exists('yooadmin_get_site_admin_language_locales')) {
            return yooadmin_get_site_admin_language_locales();
        }

        $installed = get_available_languages();
        if (!is_array($installed)) {
            $installed = [];
        }

        $site_locale = get_locale();
        if (!is_string($site_locale) || $site_locale === '') {
            $site_locale = 'en_US';
        }

        $locales = array_unique(array_merge(['en_US'], $installed, [$site_locale]));
        $normalized = [];

        foreach ($locales as $locale) {
            $locale = yooadmin_sanitize_locale_name((string) $locale);
            if ($locale !== '') {
                $normalized[] = $locale;
            }
        }

        return array_values(array_unique($normalized));
    }
}

if (!function_exists('yooadmin_login_toolbar_should_show_language')) {
    function yooadmin_login_toolbar_should_show_language(): bool
    {
        $locales = yooadmin_login_toolbar_get_language_locales();

        return count($locales) > 1;
    }
}

if (!function_exists('yooadmin_login_toolbar_get_language_options')) {
    /**
     * @return array<int, array{value: string, label: string, wp_lang: string}>
     */
    function yooadmin_login_toolbar_get_language_options(): array
    {
        if (!yooadmin_login_toolbar_should_show_language()) {
            return [];
        }

        $installed = get_available_languages();
        if (!is_array($installed)) {
            $installed = [];
        }

        if (!function_exists('wp_get_available_translations')) {
            require_once ABSPATH . 'wp-admin/includes/translation-install.php';
        }

        $translations = wp_get_available_translations();
        $site_locale  = get_locale();
        if (!is_string($site_locale) || $site_locale === '') {
            $site_locale = 'en_US';
        }

        $options = [
            [
                'value'   => 'site-default',
                'label'   => _x('Site Default', 'default site language', 'yooadmin'),
                'wp_lang' => '',
            ],
        ];

        $seen = ['site-default' => true];

        if (!isset($seen['en_US'])) {
            $options[] = [
                'value'   => 'en_US',
                'label'   => 'English (United States)',
                'wp_lang' => 'en_US',
            ];
            $seen['en_US'] = true;
        }

        foreach ($installed as $locale) {
            $locale = yooadmin_sanitize_locale_name((string) $locale);
            if ($locale === '' || isset($seen[$locale])) {
                continue;
            }

            $label = $locale;
            if (isset($translations[$locale]['native_name'])) {
                $label = (string) $translations[$locale]['native_name'];
            }

            $seen[$locale] = true;
            $options[]     = [
                'value'   => $locale,
                'label'   => $label,
                'wp_lang' => $locale,
            ];
        }

        if ($site_locale !== '' && $site_locale !== 'en_US' && !isset($seen[$site_locale])) {
            $label = $site_locale;
            if (isset($translations[$site_locale]['native_name'])) {
                $label = (string) $translations[$site_locale]['native_name'];
            }
            $options[] = [
                'value'   => $site_locale,
                'label'   => $label,
                'wp_lang' => $site_locale,
            ];
        }

        /**
         * Filter login toolbar language menu options.
         *
         * @param array<int, array{value: string, label: string, wp_lang: string}> $options
         */
        return apply_filters('yooadmin_login_toolbar_language_options', $options);
    }
}

if (!function_exists('yooadmin_login_toolbar_get_selected_language_value')) {
    function yooadmin_login_toolbar_get_selected_language_value(): string
    {
        $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
        if (!is_string($locale) || $locale === '') {
            $locale = 'en_US';
        }

        $site_locale = get_locale();
        if (!is_string($site_locale) || $site_locale === '') {
            $site_locale = 'en_US';
        }

        foreach (yooadmin_login_toolbar_get_language_options() as $option) {
            $wp_lang = (string) ($option['wp_lang'] ?? '');
            if ($wp_lang !== '' && $wp_lang === $locale) {
                return (string) $option['value'];
            }
        }

        if ($locale === $site_locale) {
            return 'site-default';
        }

        if ($locale === 'en_US') {
            return 'en_US';
        }

        return 'site-default';
    }
}

if (!function_exists('yooadmin_login_toolbar_get_request_url')) {
    function yooadmin_login_toolbar_get_request_url(): string
    {
        if (function_exists('yooadmin_standalone_login_is_this_request')
            && yooadmin_standalone_login_is_this_request()
            && function_exists('yooadmin_standalone_login_get_request_url')) {
            return remove_query_arg(
                ['wp_lang', 'yoo_reset_lang'],
                yooadmin_standalone_login_get_request_url()
            );
        }

        if (function_exists('yooadmin_hidden_login_entry_is_enabled')
            && yooadmin_hidden_login_entry_is_enabled()
            && function_exists('yooadmin_hidden_login_entry_url')) {
            $url = yooadmin_hidden_login_entry_url();
        } elseif (function_exists('yooadmin_standalone_login_url')) {
            $url = yooadmin_standalone_login_url();
        } else {
            $url = wp_login_url();
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Preserve public login query args (same as wp-login.php).
        if (!empty($_GET)) {
            $allowed = [
                'redirect_to',
                'action',
                'key',
                'login',
                'error',
                'loggedout',
                'reauth',
                'wp_lang',
                'yooadmin_secret_login',
                'hl',
            ];
            foreach ($_GET as $key => $value) {
                $key = sanitize_key((string) $key);
                if (!in_array($key, $allowed, true)) {
                    continue;
                }
                if (is_array($value)) {
                    continue;
                }
                $url = add_query_arg($key, sanitize_text_field(wp_unslash((string) $value)), $url);
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return $url;
    }
}

if (!function_exists('yooadmin_login_toolbar_build_language_switch_url')) {
    function yooadmin_login_toolbar_build_language_switch_url(string $value): string
    {
        $base = yooadmin_login_toolbar_get_request_url();
        $base = remove_query_arg('wp_lang', $base);

        if ($value === 'site-default' || $value === '') {
            return add_query_arg('yoo_reset_lang', '1', remove_query_arg(['wp_lang', 'yoo_reset_lang'], $base));
        }

        $wp_lang = $value;
        foreach (yooadmin_login_toolbar_get_language_options() as $option) {
            if ((string) ($option['value'] ?? '') === $value) {
                $wp_lang = (string) ($option['wp_lang'] ?? $value);
                break;
            }
        }

        if ($wp_lang === '' || $wp_lang === 'site-default') {
            return $base;
        }

        return add_query_arg('wp_lang', $wp_lang, $base);
    }
}

if (!function_exists('yooadmin_login_toolbar_get_script_config')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_login_toolbar_get_script_config(): array
    {
        $default_mode = function_exists('yooadmin_custom_login_get_color_mode')
            ? yooadmin_custom_login_get_color_mode()
            : 'auto';

        $logo_light = function_exists('yooadmin_custom_login_resolve_logo')
            ? yooadmin_custom_login_resolve_logo('light')
            : ['url' => '', 'max_w' => 220];
        $logo_dark = function_exists('yooadmin_custom_login_resolve_logo')
            ? yooadmin_custom_login_resolve_logo('dark')
            : $logo_light;

        return [
            'defaultAppearance'   => $default_mode,
            'sessionStorageKey'   => 'yoo_login_appearance_override',
            'cssVarsLight'        => function_exists('yooadmin_custom_login_get_style_vars')
                ? yooadmin_custom_login_get_style_vars('light')
                : [],
            'cssVarsDark'         => function_exists('yooadmin_custom_login_get_style_vars')
                ? yooadmin_custom_login_get_style_vars('dark')
                : [],
            'logoLightUrl'        => (string) ($logo_light['url'] ?? ''),
            'logoDarkUrl'         => (string) ($logo_dark['url'] ?? ''),
            'logoMaxW'            => max(20, (int) ($logo_light['max_w'] ?? 220)),
            'useDualLogos'        => ($logo_light['url'] ?? '') !== '' && ($logo_dark['url'] ?? '') !== ''
                && ($logo_light['url'] ?? '') !== ($logo_dark['url'] ?? ''),
            'i18n'                => [
                'appearance' => __('Login appearance', 'yooadmin'),
                'language'     => __('Language', 'yooadmin'),
            ],
        ];
    }
}

if (!function_exists('yooadmin_login_toolbar_render')) {
    function yooadmin_login_toolbar_render(): void
    {
        $appearance_choices = yooadmin_login_toolbar_get_appearance_choices();
        $default_mode       = function_exists('yooadmin_custom_login_get_color_mode')
            ? yooadmin_custom_login_get_color_mode()
            : 'auto';
        if (!in_array($default_mode, ['light', 'dark', 'auto'], true)) {
            $default_mode = 'auto';
        }

        $show_lang    = yooadmin_login_toolbar_should_show_language();
        $lang_options = $show_lang ? yooadmin_login_toolbar_get_language_options() : [];
        $lang_selected = yooadmin_login_toolbar_get_selected_language_value();
        $lang_menu_id  = 'yoo-login-lang-menu';

        ?>
        <div class="yoo-login-toolbar yoo-login-toolbar--fixed" data-yoo-login-toolbar>
            <div class="yoo-login-toolbar__group yoo-login-toolbar__appearance">
                <div class="ysh-appearance ysh-appearance--login-toolbar" data-yoo-login-appearance-root>
                    <div class="ysh-appearance__menu ysh-appearance__menu--inline" role="group" aria-label="<?php esc_attr_e('Login appearance', 'yooadmin'); ?>">
                        <?php foreach ($appearance_choices as $mode_key => $choice) : ?>
                            <button
                                type="button"
                                class="ysh-appearance__option<?php echo $default_mode === $mode_key ? ' is-active' : ''; ?>"
                                data-yoo-login-appearance="<?php echo esc_attr($mode_key); ?>"
                                title="<?php echo esc_attr($choice['label']); ?>"
                                aria-pressed="<?php echo $default_mode === $mode_key ? 'true' : 'false'; ?>"
                            >
                                <?php echo $choice['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Inline SVG from plugin. ?>
                                <span class="screen-reader-text"><?php echo esc_html($choice['label']); ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php if ($show_lang && $lang_options !== []) : ?>
                <div class="yoo-login-toolbar__group yoo-login-toolbar__lang" data-yoo-login-lang-switcher>
                    <button type="button"
                            class="yoo-login-toolbar__lang-toggle"
                            aria-expanded="false"
                            aria-haspopup="true"
                            aria-controls="<?php echo esc_attr($lang_menu_id); ?>"
                            title="<?php esc_attr_e('Language', 'yooadmin'); ?>">
                        <span class="yoo-login-toolbar__lang-icon dashicons dashicons-translation" aria-hidden="true"></span>
                        <span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
                        <span class="screen-reader-text"><?php esc_html_e('Language', 'yooadmin'); ?></span>
                    </button>
                    <div class="yoo-login-toolbar__lang-menu"
                         id="<?php echo esc_attr($lang_menu_id); ?>"
                         role="menu"
                         aria-label="<?php esc_attr_e('Choose language', 'yooadmin'); ?>"
                         hidden>
                        <?php foreach ($lang_options as $option) : ?>
                            <?php
                            $value     = (string) $option['value'];
                            $label     = (string) $option['label'];
                            $is_active = ($lang_selected === $value);
                            $href      = yooadmin_login_toolbar_build_language_switch_url($value);
                            $option_lang = function_exists('yooadmin_get_admin_language_option_lang')
                                ? yooadmin_get_admin_language_option_lang($value)
                                : '';
                            ?>
                            <a class="yoo-login-toolbar__lang-option<?php echo $is_active ? ' is-active' : ''; ?>"
                               role="menuitem"
                               href="<?php echo esc_url($href); ?>"
                               lang="<?php echo esc_attr($option_lang); ?>"
                               title="<?php echo esc_attr($label); ?>"
                               <?php echo $is_active ? 'aria-current="true"' : ''; ?>>
                                <?php echo esc_html($label); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}

if (!function_exists('yooadmin_login_toolbar_enqueue_assets')) {
    /**
     * Register and enqueue login toolbar assets (standalone login / wp-login).
     */
    function yooadmin_login_toolbar_enqueue_assets(): void
    {
        if (!function_exists('wp_enqueue_style') || !function_exists('wp_enqueue_script')) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
        if ($base_file === '') {
            return;
        }

        $base_url = plugin_dir_url($base_file);
        $base_dir = plugin_dir_path($base_file);

        $css_rel = 'assets/css/login/yoo-login-toolbar.css';
        $css_abs = $base_dir . $css_rel;
        if (is_readable($css_abs)) {
            wp_enqueue_style(
                'yooadmin-login-toolbar',
                $base_url . $css_rel,
                [],
                (string) filemtime($css_abs)
            );
        }

        $js_rel = 'assets/js/login/yoo-login-toolbar.js';
        $js_abs = $base_dir . $js_rel;
        if (is_readable($js_abs)) {
            wp_enqueue_script(
                'yooadmin-login-toolbar',
                $base_url . $js_rel,
                [],
                (string) filemtime($js_abs),
                true
            );
            if (function_exists('wp_script_add_data')) {
                wp_script_add_data('yooadmin-login-toolbar', 'strategy', 'defer');
            }
        }

        $config = yooadmin_login_toolbar_get_script_config();
        $config_json = wp_json_encode(
            $config,
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        if ($config_json !== false && wp_script_is('yooadmin-login-toolbar', 'registered')) {
            wp_add_inline_script(
                'yooadmin-login-toolbar',
                'window.yooadminLoginToolbar = ' . $config_json . ';',
                'before'
            );
            wp_add_inline_script(
                'yooadmin-login-toolbar',
                '(function(){var c=window.yooadminLoginToolbar;if(!c)return;var k=c.sessionStorageKey||"yoo_login_appearance_override";var m;try{m=sessionStorage.getItem(k);}catch(e){return;}if(m!=="light"&&m!=="dark"&&m!=="auto")return;var eff=m==="dark"?"dark":(m==="light"?"light":(function(){try{return window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(e){return"light";}})());document.documentElement.setAttribute("data-yoo-login-color-mode",m);document.documentElement.setAttribute("data-yoo-login-color-mode-effective",eff);})();',
                'before'
            );
        }
    }
}

if (!function_exists('yooadmin_login_toolbar_print_assets')) {
    function yooadmin_login_toolbar_print_assets(): void
    {
        yooadmin_login_toolbar_enqueue_assets();

        if (function_exists('wp_print_styles')) {
            wp_print_styles(['yooadmin-login-toolbar']);
        }
        if (function_exists('wp_print_scripts')) {
            wp_print_scripts(['yooadmin-login-toolbar']);
        }
    }
}

if (!function_exists('yooadmin_login_toolbar_should_show_cf_attribution')) {
    function yooadmin_login_toolbar_should_show_cf_attribution(): bool
    {
        return function_exists('yooadmin_login_turnstile_should_render')
            && yooadmin_login_turnstile_should_render();
    }
}

if (!function_exists('yooadmin_login_toolbar_render_cf_attribution')) {
    function yooadmin_login_toolbar_render_cf_attribution(): void
    {
        if (!yooadmin_login_toolbar_should_show_cf_attribution()) {
            return;
        }

        $tip = __(
            'This site uses Cloudflare Turnstile to help block automated sign-in attempts. You may be asked to complete a short check.',
            'yooadmin'
        );
        ?>
        <span class="yoo-sl-footer-item yoo-sl-cf-attribution"
              title="<?php echo esc_attr($tip); ?>">
            <span class="yoo-sl-footer-ic yoo-sl-cf-attribution__icon dashicons dashicons-shield-alt" aria-hidden="true"></span>
            <span class="yoo-sl-footer-txt yoo-sl-cf-attribution__text"><?php esc_html_e('Protected by Cloudflare', 'yooadmin'); ?></span>
        </span>
        <?php
    }
}
