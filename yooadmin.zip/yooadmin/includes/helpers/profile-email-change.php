<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_profile_page_url')) {
    function yooadmin_profile_page_url(int $user_id = 0): string
    {
        $url = admin_url('admin.php?page=yooadmin-user');
        $uid = $user_id > 0 ? $user_id : get_current_user_id();

        if ($uid > 0 && $uid !== get_current_user_id()) {
            $url = add_query_arg('user_id', $uid, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_profile_uses_yooadmin_profile_page')) {
    /**
     * Whether the YOOAdmin profile screen is active (vs core profile.php).
     */
    function yooadmin_profile_uses_yooadmin_profile_page(): bool
    {
        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : get_option('yooadmin_options', []);

        if (is_array($opts) && array_key_exists('users_redirect', $opts)) {
            return !empty($opts['users_redirect']);
        }

        return true;
    }
}

if (!function_exists('yooadmin_profile_public_login_base_url')) {
    function yooadmin_profile_public_login_base_url(): string
    {
        if (function_exists('yooadmin_standalone_login_public_url')) {
            return yooadmin_standalone_login_public_url();
        }

        if (function_exists('yooadmin_native_2fa_core_wp_login_url')) {
            return yooadmin_native_2fa_core_wp_login_url();
        }

        return wp_login_url();
    }
}

if (!function_exists('yooadmin_profile_is_public_email_confirm_request')) {
    function yooadmin_profile_is_public_email_confirm_request(): bool
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public confirmation entry.
        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash((string) $_REQUEST['action'])) : '';

        return $action === 'yooadmin_confirm_email';
    }
}

if (!function_exists('yooadmin_profile_is_public_login_request')) {
    function yooadmin_profile_is_public_login_request(): bool
    {
        if (function_exists('yooadmin_hidden_login_entry_is_secret_request')
            && yooadmin_hidden_login_entry_is_secret_request()) {
            return true;
        }

        if (function_exists('yooadmin_standalone_login_is_this_request')
            && yooadmin_standalone_login_is_this_request()) {
            return true;
        }

        global $pagenow;

        return isset($pagenow) && $pagenow === 'wp-login.php';
    }
}

if (!function_exists('yooadmin_profile_email_confirm_admin_destination')) {
    function yooadmin_profile_email_confirm_admin_destination(int $user_id, string $hash): string
    {
        if (yooadmin_profile_uses_yooadmin_profile_page()) {
            return admin_url(
                'admin.php?' . http_build_query(
                    [
                        'page'         => 'yooadmin-user',
                        'newuseremail' => strtolower($hash),
                    ],
                    '',
                    '&',
                    PHP_QUERY_RFC3986
                )
            );
        }

        return add_query_arg('newuseremail', strtolower($hash), admin_url('profile.php'));
    }
}

if (!function_exists('yooadmin_profile_email_confirm_url')) {
    function yooadmin_profile_email_confirm_url(int $user_id, string $hash): string
    {
        $hash = sanitize_text_field($hash);
        if (!preg_match('/^[a-f0-9]{32}$/i', $hash)) {
            return yooadmin_profile_uses_yooadmin_profile_page()
                ? yooadmin_profile_page_url($user_id)
                : admin_url('profile.php');
        }

        $use_public_action = (bool) apply_filters('yooadmin_profile_email_confirm_use_public_action', true, $user_id, $hash);

        if ($use_public_action) {
            $url = add_query_arg(
                [
                    'action'       => 'yooadmin_confirm_email',
                    'newuseremail' => strtolower($hash),
                ],
                yooadmin_profile_public_login_base_url()
            );

            /** @var string $url */
            return (string) apply_filters('yooadmin_profile_email_confirm_url', $url, $user_id, $hash);
        }

        $destination = yooadmin_profile_email_confirm_admin_destination($user_id, $hash);

        /** @var bool $wrap */
        $wrap = (bool) apply_filters('yooadmin_profile_email_confirm_wrap_login_url', false, $destination, $user_id);

        if ($wrap && function_exists('yooadmin_branded_email_wrap_action_url')) {
            return yooadmin_branded_email_wrap_action_url($destination);
        }

        return $destination;
    }
}

if (!function_exists('yooadmin_profile_email_confirmation_result_url')) {
    function yooadmin_profile_email_confirmation_result_url(int $user_id, bool $success): string
    {
        $base = yooadmin_profile_uses_yooadmin_profile_page()
            ? yooadmin_profile_page_url($user_id)
            : admin_url('profile.php');

        return add_query_arg($success ? 'email_updated' : 'email_error', '1', $base);
    }
}

if (!function_exists('yooadmin_profile_parse_email_confirmation_hash')) {
    function yooadmin_profile_parse_email_confirmation_hash(): string
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public confirmation link from email.
        if (isset($_GET['newuseremail'])) {
            $hash = sanitize_text_field(wp_unslash((string) $_GET['newuseremail']));
            if (preg_match('/^[a-f0-9]{32}$/i', $hash)) {
                return strtolower($hash);
            }
        }

        $haystacks = [];

        if (isset($_GET['page'])) {
            $haystacks[] = sanitize_key(wp_unslash((string) $_GET['page']));
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if (isset($_SERVER['REQUEST_URI'])) {
            $haystacks[] = sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_URI']));
        }

        foreach ($haystacks as $haystack) {
            if (preg_match('/(?:^|[?&;])newuseremail=([a-f0-9]{32})/i', html_entity_decode($haystack, ENT_QUOTES | ENT_HTML5, 'UTF-8'), $matches)) {
                return strtolower($matches[1]);
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_profile_is_email_confirmation_request')) {
    function yooadmin_profile_is_email_confirmation_request(): bool
    {
        if (!is_admin()) {
            return false;
        }

        if (yooadmin_profile_parse_email_confirmation_hash() !== '') {
            return true;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash((string) $_GET['page'])) : '';

        global $pagenow;

        return $page === 'yooadmin-user' || $pagenow === 'profile.php';
    }
}

if (!function_exists('yooadmin_profile_maybe_handle_email_confirmation_request')) {
    function yooadmin_profile_maybe_handle_email_confirmation_request(): void
    {
        if (!is_admin() || !is_user_logged_in() || !yooadmin_profile_is_email_confirmation_request()) {
            return;
        }

        $hash = yooadmin_profile_parse_email_confirmation_hash();
        if ($hash === '') {
            return;
        }

        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return;
        }

        $ok = yooadmin_profile_confirm_email_change($user_id, $hash);

        wp_safe_redirect(yooadmin_profile_email_confirmation_result_url($user_id, $ok));
        exit;
    }
}

add_action('admin_init', 'yooadmin_profile_maybe_handle_email_confirmation_request', 1);

if (!function_exists('yooadmin_profile_maybe_handle_public_email_confirmation')) {
    function yooadmin_profile_maybe_handle_public_email_confirmation(): void
    {
        if (!yooadmin_profile_is_public_email_confirm_request() || !yooadmin_profile_is_public_login_request()) {
            return;
        }

        if (!is_user_logged_in()) {
            return;
        }

        $hash = yooadmin_profile_parse_email_confirmation_hash();
        $user_id = get_current_user_id();

        if ($hash === '' || $user_id <= 0) {
            wp_safe_redirect(yooadmin_profile_email_confirmation_result_url($user_id, false));
            exit;
        }

        $ok = yooadmin_profile_confirm_email_change($user_id, $hash);

        wp_safe_redirect(yooadmin_profile_email_confirmation_result_url($user_id, $ok));
        exit;
    }
}

add_action('template_redirect', 'yooadmin_profile_maybe_handle_public_email_confirmation', -2);
add_action('login_init', 'yooadmin_profile_maybe_handle_public_email_confirmation', 0);

if (!function_exists('yooadmin_profile_email_confirmation_admin_notices')) {
    /**
     * Flash notices on core profile.php when the YOOAdmin profile screen is disabled.
     */
    function yooadmin_profile_email_confirmation_admin_notices(): void
    {
        if (!is_admin() || yooadmin_profile_uses_yooadmin_profile_page()) {
            return;
        }

        global $pagenow;
        if ($pagenow !== 'profile.php') {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status flags after redirect.
        if (isset($_GET['email_updated'])) {
            echo '<div class="notice notice-success is-dismissible"><p>';
            esc_html_e('Your email address has been updated.', 'yooadmin');
            echo '</p></div>';
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status flags after redirect.
        if (isset($_GET['email_error'])) {
            echo '<div class="notice notice-error is-dismissible"><p>';
            esc_html_e('That email confirmation link is invalid or has expired.', 'yooadmin');
            echo '</p></div>';
        }
    }
}

add_action('admin_notices', 'yooadmin_profile_email_confirmation_admin_notices');

if (!function_exists('yooadmin_profile_get_pending_email_change')) {
    /**
     * @return array{hash: string, newemail: string}|null
     */
    function yooadmin_profile_get_pending_email_change(int $user_id): ?array
    {
        $pending = get_user_meta($user_id, '_new_email', true);

        return is_array($pending) && !empty($pending['newemail']) && !empty($pending['hash'])
            ? $pending
            : null;
    }
}

if (!function_exists('yooadmin_profile_user_has_2fa_for_email_change')) {
    function yooadmin_profile_user_has_2fa_for_email_change(int $user_id): bool
    {
        if ($user_id <= 0) {
            return false;
        }

        if (class_exists('YOOAdmin_2FA_Core') && YOOAdmin_2FA_Core::is_user_using_2fa($user_id)) {
            return true;
        }

        if (class_exists('Two_Factor_Core') && Two_Factor_Core::is_user_using_two_factor($user_id)) {
            return true;
        }

        /** @var bool $has */
        return (bool) apply_filters('yooadmin_profile_user_has_2fa_for_email_change', false, $user_id);
    }
}

if (!function_exists('yooadmin_profile_email_change_verification_providers')) {
    /**
     * Providers the user can use to confirm an email change (excludes email OTP).
     *
     * @return array<int, array{key: string, label: string}>
     */
    function yooadmin_profile_email_change_verification_providers(int $user_id): array
    {
        $out = [];

        if (class_exists('YOOAdmin_2FA_Core') && YOOAdmin_2FA_Core::is_user_using_2fa($user_id)) {
            foreach (YOOAdmin_2FA_Core::get_enabled_providers($user_id) as $key) {
                if ($key === YOOAdmin_2FA_Core::PROVIDER_EMAIL) {
                    continue;
                }
                $out[] = [
                    'key'   => $key,
                    'label' => YOOAdmin_2FA_Core::provider_label($key),
                ];
            }
        }

        if ($out === [] && class_exists('Two_Factor_Core') && Two_Factor_Core::is_user_using_two_factor($user_id)) {
            $user = get_user_by('id', $user_id);
            if ($user instanceof WP_User && class_exists('Two_Factor_Core')) {
                $provider = Two_Factor_Core::get_provider_for_user($user);
                if ($provider && $provider->get_key() !== 'Two_Factor_Email') {
                    $out[] = [
                        'key'   => $provider->get_key(),
                        'label' => method_exists($provider, 'get_label') ? (string) $provider->get_label() : $provider->get_key(),
                    ];
                }
            }
        }

        /** @var array<int, array{key: string, label: string}> $out */
        return (array) apply_filters('yooadmin_profile_email_change_verification_providers', $out, $user_id);
    }
}

if (!function_exists('yooadmin_profile_email_change_2fa_transient_key')) {
    function yooadmin_profile_email_change_2fa_transient_key(int $user_id): string
    {
        return 'yooadmin_ec2fa_' . $user_id;
    }
}

if (!function_exists('yooadmin_profile_clear_email_change_2fa_verification')) {
    function yooadmin_profile_clear_email_change_2fa_verification(int $user_id): void
    {
        delete_transient(yooadmin_profile_email_change_2fa_transient_key($user_id));
    }
}

if (!function_exists('yooadmin_profile_issue_email_change_2fa_verification')) {
    /**
     * Store a short-lived verification grant after 2FA succeeds (save can happen later).
     */
    function yooadmin_profile_issue_email_change_2fa_verification(int $user_id, string $provider, string $target_email): string
    {
        $token = wp_generate_password(32, false, false);
        $payload = [
            'hash'     => hash_hmac('sha256', $token, wp_salt('auth')),
            'provider' => sanitize_key($provider),
            'email'    => hash('sha256', strtolower(trim($target_email))),
            'issued'   => time(),
        ];

        set_transient(
            yooadmin_profile_email_change_2fa_transient_key($user_id),
            $payload,
            30 * MINUTE_IN_SECONDS
        );

        return $token;
    }
}

if (!function_exists('yooadmin_profile_is_email_change_2fa_verified')) {
    function yooadmin_profile_is_email_change_2fa_verified(int $user_id, string $token, string $provider, string $target_email): bool
    {
        $token = trim($token);
        if ($token === '') {
            return false;
        }

        $stored = get_transient(yooadmin_profile_email_change_2fa_transient_key($user_id));
        if (!is_array($stored)) {
            return false;
        }

        $expected_hash = (string) ($stored['hash'] ?? '');
        if ($expected_hash === '' || !hash_equals($expected_hash, hash_hmac('sha256', $token, wp_salt('auth')))) {
            return false;
        }

        if (sanitize_key($provider) !== (string) ($stored['provider'] ?? '')) {
            return false;
        }

        if (hash('sha256', strtolower(trim($target_email))) !== (string) ($stored['email'] ?? '')) {
            return false;
        }

        return true;
    }
}

if (!function_exists('yooadmin_profile_verify_email_change_2fa')) {
    /**
     * @param array<string, mixed> $request
     */
    function yooadmin_profile_verify_email_change_2fa(int $user_id, array $request): bool
    {
        if (!yooadmin_profile_user_has_2fa_for_email_change($user_id)) {
            return true;
        }

        $target_email = isset($request['user_email']) ? sanitize_email((string) $request['user_email']) : '';
        $provider_key = isset($request['email_change_2fa_provider'])
            ? sanitize_key((string) $request['email_change_2fa_provider'])
            : '';

        if (
            $target_email !== ''
            && !empty($request['email_change_2fa_token'])
            && yooadmin_profile_is_email_change_2fa_verified(
                $user_id,
                (string) $request['email_change_2fa_token'],
                $provider_key,
                $target_email
            )
        ) {
            return true;
        }

        $providers = yooadmin_profile_email_change_verification_providers($user_id);
        if ($providers === []) {
            // Email-only 2FA: require current account password instead.
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Verified via wp_check_password.
            $password = isset($request['current_pass']) ? (string) $request['current_pass'] : '';
            if ($password === '') {
                return false;
            }
            $user = get_user_by('id', $user_id);

            return $user instanceof WP_User && wp_check_password($password, $user->user_pass, $user);
        }

        if (class_exists('YOOAdmin_2FA_Core') && YOOAdmin_2FA_Core::is_user_using_2fa($user_id)) {
            if ($provider_key === '') {
                $provider_key = YOOAdmin_2FA_Core::get_primary_provider($user_id);
                if ($provider_key === YOOAdmin_2FA_Core::PROVIDER_EMAIL) {
                    $usable = yooadmin_profile_email_change_verification_providers($user_id);
                    $provider_key = $usable[0]['key'] ?? '';
                }
            }

            if ($provider_key !== '' && function_exists('yooadmin_native_2fa_verify_provider_code')) {
                return yooadmin_native_2fa_verify_provider_code($user_id, $provider_key, $request);
            }
        }

        if (class_exists('Two_Factor_Core')) {
            $user = get_user_by('id', $user_id);
            if ($user instanceof WP_User) {
                $provider = Two_Factor_Core::get_provider_for_user($user, $provider_key !== '' ? $provider_key : null);
                if ($provider && isset($request['authcode'])) {
                    $code = (string) $request['authcode'];
                    if (method_exists($provider, 'validate_authentication')) {
                        return (bool) $provider->validate_authentication($user, $code);
                    }
                }
            }
        }

        /** @var bool $verified */
        return (bool) apply_filters('yooadmin_profile_verify_email_change_2fa', false, $user_id, $request);
    }
}

if (!function_exists('yooadmin_profile_queue_email_change')) {
    /**
     * Queue a pending email change and send the confirmation message to the new address.
     *
     * @return true|WP_Error
     */
    function yooadmin_profile_queue_email_change(int $user_id, string $new_email)
    {
        $user = get_user_by('id', $user_id);
        if (!$user instanceof WP_User) {
            return new WP_Error('user_missing', __('User not found.', 'yooadmin'));
        }

        $new_email = sanitize_email($new_email);
        if (!is_email($new_email)) {
            return new WP_Error('invalid_email', __('Please provide a valid email address.', 'yooadmin'));
        }

        $exists = email_exists($new_email);
        if ($exists && (int) $exists !== $user_id) {
            delete_user_meta($user_id, '_new_email');

            return new WP_Error('email_exists', __('That email address is already in use.', 'yooadmin'));
        }

        if (strcasecmp($new_email, $user->user_email) === 0) {
            delete_user_meta($user_id, '_new_email');

            return true;
        }

        $hash           = md5($new_email . time() . wp_rand());
        $new_user_email = [
            'hash'     => $hash,
            'newemail' => $new_email,
        ];
        update_user_meta($user_id, '_new_email', $new_user_email);

        $confirm = yooadmin_profile_email_confirm_url($user_id, $hash);

        $sent = function_exists('yooadmin_branded_email_send_profile_change_request')
            ? yooadmin_branded_email_send_profile_change_request($user, $new_email, $confirm)
            : false;
        if (!$sent) {
            return new WP_Error('email_failed', __('Could not send the confirmation email. Please try again.', 'yooadmin'));
        }

        return true;
    }
}

if (!function_exists('yooadmin_profile_confirm_email_change')) {
    function yooadmin_profile_confirm_email_change(int $user_id, string $hash): bool
    {
        $pending = yooadmin_profile_get_pending_email_change($user_id);
        if (!$pending || !hash_equals((string) $pending['hash'], $hash)) {
            return false;
        }

        $user             = new stdClass();
        $user->ID         = $user_id;
        $user->user_email = sanitize_email((string) $pending['newemail']);

        if (!is_email($user->user_email)) {
            return false;
        }

        $exists = email_exists($user->user_email);
        if ($exists && (int) $exists !== $user_id) {
            delete_user_meta($user_id, '_new_email');

            return false;
        }

        $updated = wp_update_user($user);
        if (is_wp_error($updated)) {
            return false;
        }

        delete_user_meta($user_id, '_new_email');

        return true;
    }
}

if (!function_exists('yooadmin_profile_dismiss_email_change')) {
    function yooadmin_profile_dismiss_email_change(int $user_id): void
    {
        delete_user_meta($user_id, '_new_email');
    }
}

if (!function_exists('yooadmin_profile_apply_account_fields')) {
    /**
     * Update profile fields; email uses confirmation for own profile.
     *
     * @param array<string, mixed> $fields
     * @return array{user: WP_User, email_pending: bool, email_pending_address: string}|WP_Error
     */
    function yooadmin_profile_apply_account_fields(WP_User $user, array $fields, bool $is_own_profile)
    {
        $user_id = (int) $user->ID;
        $email   = isset($fields['user_email']) ? sanitize_email((string) $fields['user_email']) : $user->user_email;

        $errors = new WP_Error();

        $email_exists = email_exists($email);
        if (!is_email($email) || ($email_exists && (int) $email_exists !== $user_id)) {
            $errors->add('user_email', __('Please provide a unique, valid email address.', 'yooadmin'));
        }

        if ($errors->has_errors()) {
            return $errors;
        }

        $email_changed = strcasecmp($email, $user->user_email) !== 0;
        $email_pending = false;
        $pending_addr  = '';

        if ($email_changed) {
            if ($is_own_profile) {
                if (yooadmin_profile_user_has_2fa_for_email_change($user_id)) {
                    if (!yooadmin_profile_verify_email_change_2fa($user_id, $fields)) {
                        $providers = yooadmin_profile_email_change_verification_providers($user_id);
                        if ($providers === []) {
                            $errors->add(
                                'email_change_2fa',
                                __('Enter your current password to confirm this email change.', 'yooadmin')
                            );
                        } else {
                            $errors->add(
                                'email_change_2fa',
                                __('Enter a valid two-factor code to confirm this email change.', 'yooadmin')
                            );
                        }

                        return $errors;
                    }
                }

                $queued = yooadmin_profile_queue_email_change($user_id, $email);
                if (is_wp_error($queued)) {
                    return $queued;
                }

                yooadmin_profile_clear_email_change_2fa_verification($user_id);

                $email_pending = strcasecmp($email, $user->user_email) !== 0;
                $pending_addr  = $email;
                $email         = $user->user_email;
            }
        }

        $userdata = [
            'ID'           => $user_id,
            'user_email'   => $email,
            'first_name'   => isset($fields['first_name']) ? sanitize_text_field((string) $fields['first_name']) : $user->first_name,
            'last_name'    => isset($fields['last_name']) ? sanitize_text_field((string) $fields['last_name']) : $user->last_name,
            'display_name' => isset($fields['display_name']) ? sanitize_text_field((string) $fields['display_name']) : $user->display_name,
            'user_url'     => isset($fields['user_url']) ? esc_url_raw((string) $fields['user_url']) : $user->user_url,
            'description'  => isset($fields['description']) ? sanitize_textarea_field((string) $fields['description']) : $user->description,
        ];

        $display = trim((string) $userdata['display_name']);
        if ($display === '') {
            $userdata['display_name'] = trim($userdata['first_name'] . ' ' . $userdata['last_name']);
        }

        if (array_key_exists('locale', $fields) && $fields['locale'] !== null) {
            $userdata['locale'] = sanitize_text_field((string) $fields['locale']);
        }

        $result = wp_update_user($userdata);
        if (is_wp_error($result)) {
            return $result;
        }

        $updated = get_userdata($user_id);
        if (!$updated instanceof WP_User) {
            return new WP_Error('user_missing', __('User not found.', 'yooadmin'));
        }

        return [
            'user'                  => $updated,
            'email_pending'         => $email_pending,
            'email_pending_address' => $pending_addr,
        ];
    }
}
