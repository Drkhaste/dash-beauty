<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_branded_email_brand_color')) {
    function yooadmin_branded_email_brand_color(): string
    {
        $color = '#eda934';

        if (function_exists('yooadmin_custom_login_get_merged_theme_colors')) {
            $colors = yooadmin_custom_login_get_merged_theme_colors();
            $maybe  = sanitize_hex_color((string) ($colors['primary'] ?? ''));
            if ($maybe !== '') {
                $color = $maybe;
            }
        } elseif (function_exists('yooadmin_get_primary_color')) {
            $maybe = sanitize_hex_color((string) yooadmin_get_primary_color());
            if ($maybe !== '') {
                $color = $maybe;
            }
        }

        /** @var string $color */
        return (string) apply_filters('yooadmin_branded_email_brand_color', $color);
    }
}

if (!function_exists('yooadmin_branded_email_logo_url')) {
    function yooadmin_branded_email_logo_url(): string
    {
        $url = '';

        if (function_exists('yooadmin_custom_login_resolve_logo')) {
            $resolved = yooadmin_custom_login_resolve_logo('light');
            if (!empty($resolved['url'])) {
                $url = esc_url_raw((string) $resolved['url']);
            }
        } elseif (function_exists('yooadmin_custom_login_resolve_logo_light')) {
            $resolved = yooadmin_custom_login_resolve_logo_light();
            if (!empty($resolved['url'])) {
                $url = esc_url_raw((string) $resolved['url']);
            }
        }

        if ($url === '' && function_exists('yooadmin_logo_url')) {
            $branding = trim((string) yooadmin_logo_url());
            if ($branding !== '') {
                $url = esc_url_raw($branding);
            }
        }

        if ($url === '' && function_exists('yooadmin_get_options')) {
            $opts   = yooadmin_get_options();
            $custom = trim((string) ($opts['login_page_logo_url'] ?? ''));
            if ($custom !== '') {
                $url = esc_url_raw($custom);
            }
        }

        if ($url === '' && defined('YOOADMIN_DIR') && defined('YOOADMIN_PLUGIN_FILE')) {
            $path = YOOADMIN_DIR . '/assets/images/logo-dark.png';
            if (is_readable($path)) {
                $url = esc_url_raw(plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/logo-dark.png');
            }
        }

        /** @var string $url */
        return (string) apply_filters('yooadmin_branded_email_logo_url', $url);
    }
}

if (!function_exists('yooadmin_branded_email_logo_width')) {
    /**
     * Logo width (px) — same source as admin header / login branding (logo_w).
     */
    function yooadmin_branded_email_logo_width(): int
    {
        $width = 150;

        if (function_exists('yooadmin_custom_login_resolve_logo')) {
            $resolved = yooadmin_custom_login_resolve_logo('light');
            if (!empty($resolved['max_w'])) {
                $width = (int) $resolved['max_w'];
            }
        } elseif (function_exists('yooadmin_custom_login_resolve_logo_light')) {
            $resolved = yooadmin_custom_login_resolve_logo_light();
            if (!empty($resolved['max_w'])) {
                $width = (int) $resolved['max_w'];
            }
        } elseif (function_exists('yooadmin_logo_width')) {
            $width = (int) yooadmin_logo_width();
        } elseif (function_exists('yooadmin_get_options')) {
            $opts  = yooadmin_get_options();
            $width = isset($opts['logo_w']) ? (int) $opts['logo_w'] : 150;
        }

        $width = max(20, min(1000, $width));

        /** @var int $width */
        return (int) apply_filters('yooadmin_branded_email_logo_width', $width);
    }
}

if (!function_exists('yooadmin_branded_email_mix_hex')) {
    function yooadmin_branded_email_mix_hex(string $hex, string $with, int $percent = 50): string
    {
        $hex  = ltrim($hex, '#');
        $with = ltrim($with, '#');
        if (strlen($hex) !== 6 || strlen($with) !== 6) {
            return '#' . $hex;
        }

        $p   = max(0, min(100, $percent)) / 100;
        $out = '#';
        for ($i = 0; $i < 3; $i++) {
            $a = hexdec(substr($hex, $i * 2, 2));
            $b = hexdec(substr($with, $i * 2, 2));
            $out .= str_pad(dechex((int) round($a * (1 - $p) + $b * $p)), 2, '0', STR_PAD_LEFT);
        }

        return $out;
    }
}

if (!function_exists('yooadmin_public_login_request_url')) {
    function yooadmin_public_login_request_url(): string
    {
        $uri = isset($_SERVER['REQUEST_URI'])
            ? sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_URI']))
            : '/';

        return home_url($uri);
    }
}

if (!function_exists('yooadmin_public_login_merge_orphaned_query_arg')) {
    /**
     * @param string $url      Destination URL.
     * @param string $arg_name Query argument name.
     */
    function yooadmin_public_login_merge_orphaned_query_arg(string $url, string $arg_name): string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public login redirect repair.
        if (!isset($_GET[ $arg_name ])) {
            return $url;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public login redirect repair.
        $value = sanitize_text_field(wp_unslash((string) $_GET[ $arg_name ]));
        if ($arg_name === 'newuseremail' && !preg_match('/^[a-f0-9]{32}$/i', $value)) {
            return $url;
        }

        if (strpos($url, $arg_name . '=') !== false) {
            return $url;
        }

        return add_query_arg($arg_name, strtolower($value), $url);
    }
}

if (!function_exists('yooadmin_branded_email_wrap_action_url')) {
    /**
     * @param string $destination Final destination URL.
     */
    function yooadmin_branded_email_wrap_action_url(string $destination): string
    {
        $destination = esc_url_raw($destination);
        if ($destination === '') {
            return '';
        }

        // Already routed to the public login screen — do not nest inside redirect_to.
        if (
            function_exists('yooadmin_standalone_login_is_wp_login_url')
            && !yooadmin_standalone_login_is_wp_login_url($destination)
        ) {
            return $destination;
        }

        $wrapped = $destination;

        if (
            function_exists('yooadmin_hidden_login_entry_is_enabled')
            && yooadmin_hidden_login_entry_is_enabled()
            && function_exists('yooadmin_hidden_login_entry_url')
        ) {
            $wrapped = yooadmin_hidden_login_entry_url($destination);
        } elseif (function_exists('yooadmin_standalone_login_public_url')) {
            $login = yooadmin_standalone_login_public_url();
            if ($login !== '') {
                $wrapped = add_query_arg('redirect_to', $destination, $login);
            }
        } elseif (function_exists('yooadmin_native_2fa_core_wp_login_url')) {
            $wrapped = yooadmin_native_2fa_core_wp_login_url(['redirect_to' => $destination]);
        }

        /** @var string $wrapped */
        return (string) apply_filters('yooadmin_branded_email_wrap_action_url', $wrapped, $destination);
    }
}

if (!function_exists('yooadmin_branded_email_render_card')) {
    /**
     * Render a branded notification email card.
     *
     * @param array<string, mixed> $args {
     *     @type string $headline      Main title.
     *     @type string $intro         Optional intro paragraph.
     *     @type string $badge_label   Optional status badge.
     *     @type string $badge_tone    success|warning|error (default success).
     *     @type string $details_title Section title above detail rows.
     *     @type array  $rows          Detail rows [{label,value,url?}].
     *     @type string $cta_label     Optional CTA button label.
     *     @type string $cta_url       Optional CTA button URL.
     *     @type string $footer_note   Optional footer line.
     *     @type string $highlight     Optional large highlighted value (e.g. OTP code).
     * }
     */
    function yooadmin_branded_email_render_card(array $args): string
    {
        $brand      = esc_attr(yooadmin_branded_email_brand_color());
        $logo_url   = esc_url(yooadmin_branded_email_logo_url());
        $logo_w     = function_exists('yooadmin_branded_email_logo_width')
            ? max(20, (int) yooadmin_branded_email_logo_width())
            : 150;
        $headline   = (string) ($args['headline'] ?? '');
        $intro      = trim((string) ($args['intro'] ?? ''));
        $badge      = trim((string) ($args['badge_label'] ?? ''));
        $tone       = sanitize_key((string) ($args['badge_tone'] ?? 'success'));
        $details_h  = esc_html((string) ($args['details_title'] ?? ''));
        $rows       = is_array($args['rows'] ?? null) ? $args['rows'] : [];
        $cta_label  = trim((string) ($args['cta_label'] ?? ''));
        $cta_url    = esc_url((string) ($args['cta_url'] ?? ''));
        $footer     = trim((string) ($args['footer_note'] ?? ''));
        $highlight  = trim((string) ($args['highlight'] ?? ''));
        $site_name  = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $site_url   = home_url('/');
        $link_footer_site = (bool) apply_filters('yooadmin_branded_email_footer_site_linked', false);

        $badge_bg     = '#fff8eb';
        $badge_color  = $brand;
        $badge_border = yooadmin_branded_email_mix_hex($brand, '#ffffff', 70);
        if ($tone === 'warning') {
            $badge_bg     = '#fffbeb';
            $badge_color  = '#b45309';
            $badge_border = '#fde68a';
        } elseif ($tone === 'error') {
            $badge_bg     = '#fef2f2';
            $badge_color  = '#b91c1c';
            $badge_border = '#fecaca';
        }

        $logo_alt = $site_name !== '' ? $site_name : 'YOOAdmin';
        $logo_block = $logo_url !== ''
            ? '<img src="' . $logo_url . '" alt="' . esc_attr($logo_alt) . '" width="' . (int) $logo_w . '" style="display:block;margin:0 auto;width:' . (int) $logo_w . 'px;max-width:100%;height:auto;border:0;" />'
            : '<span style="display:inline-block;font-size:18px;font-weight:600;color:#1e293b;letter-spacing:-0.02em;">' . esc_html($logo_alt) . '</span>';

        $intro_block = $intro !== ''
            ? '<p style="margin:0 0 18px;font-size:14px;line-height:1.55;color:#475569;">' . esc_html($intro) . '</p>'
            : '';

        $highlight_block = $highlight !== ''
            ? '<p style="margin:0 0 18px;text-align:center;">'
                . '<span style="display:inline-block;padding:14px 22px;border-radius:12px;background:#fff8eb;border:1px solid ' . esc_attr($badge_border) . ';font-size:28px;font-weight:700;letter-spacing:0.22em;color:#1e293b;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;">'
                . esc_html($highlight)
                . '</span></p>'
            : '';

        $rows_html = '';
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $label = esc_html((string) ($row['label'] ?? ''));
            $value = (string) ($row['value'] ?? '');
            $url   = trim((string) ($row['url'] ?? ''));
            $value_html = esc_html($value);
            if ($url !== '' && preg_match('#^https?://#i', $url)) {
                $value_html = '<a href="' . esc_url($url) . '" style="color:#2271b1;text-decoration:none;font-weight:600;">' . esc_html($value) . '</a>';
            }
            $rows_html .= '<tr>'
                . '<td style="padding:11px 0;border-bottom:1px solid #eef1f5;color:#64748b;font-size:12px;line-height:1.45;font-weight:500;vertical-align:top;width:38%;">' . $label . '</td>'
                . '<td style="padding:11px 0 11px 12px;border-bottom:1px solid #eef1f5;color:#1e293b;font-size:13px;line-height:1.5;font-weight:500;vertical-align:top;">' . $value_html . '</td>'
                . '</tr>';
        }

        $details_block = '';
        if ($rows_html !== '' && $details_h !== '') {
            $details_block = '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background:#f8fafc;border:1px solid #eef1f5;border-radius:10px;">'
                . '<tr><td style="padding:4px 16px 2px;">'
                . '<p style="margin:12px 0 8px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.06em;color:#94a3b8;">' . $details_h . '</p>'
                . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">' . $rows_html . '</table>'
                . '</td></tr></table>';
        }

        $cta_block = '';
        if ($cta_label !== '' && $cta_url !== '') {
            $cta_block = '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin-top:20px;"><tr><td align="center">'
                . '<a href="' . $cta_url . '" style="display:inline-block;padding:10px 20px;background:' . esc_attr($brand) . ';color:#ffffff !important;text-decoration:none;border-radius:10px;font-size:13px;font-weight:600;line-height:1.2;">'
                . esc_html($cta_label) . '</a></td></tr></table>';
        }

        $badge_block = $badge !== ''
            ? '<span style="display:inline-block;padding:4px 10px;border-radius:8px;background:' . esc_attr($badge_bg) . ';color:' . esc_attr($badge_color) . ';border:1px solid ' . esc_attr($badge_border) . ';font-size:11px;font-weight:600;line-height:1.3;">' . esc_html($badge) . '</span>'
            : '';

        ob_start();
        ?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr(get_bloginfo('language')); ?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo esc_html($headline); ?></title>
</head>
<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;-webkit-font-smoothing:antialiased;">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color:#f1f5f9;margin:0;padding:28px 12px;">
    <tr>
        <td align="center">
            <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:560px;margin:0 auto;">
                <tr>
                    <td style="padding:0 0 14px;text-align:center;">
                        <?php echo $logo_block; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    </td>
                </tr>
                <tr>
                    <td style="background:#ffffff;border:1px solid rgba(15,23,42,0.09);border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(15,23,42,0.06);">
                        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                            <tr>
                                <td style="height:4px;background:<?php echo esc_attr($brand); ?>;font-size:0;line-height:0;">&nbsp;</td>
                            </tr>
                            <tr>
                                <td style="padding:22px 24px 8px;">
                                    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%">
                                        <tr>
                                            <td style="vertical-align:middle;">
                                                <h1 style="margin:0;font-size:17px;font-weight:600;color:#1e293b;line-height:1.35;letter-spacing:-0.02em;"><?php echo esc_html($headline); ?></h1>
                                            </td>
                                            <?php if ($badge_block !== '') : ?>
                                            <td align="right" style="vertical-align:middle;white-space:nowrap;padding-left:12px;">
                                                <?php echo $badge_block; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                            </td>
                                            <?php endif; ?>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:0 24px 20px;">
                                    <?php echo $intro_block; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                    <?php echo $highlight_block; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                    <?php echo $details_block; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                    <?php echo $cta_block; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td style="padding:16px 8px 0;text-align:center;">
                        <?php if ($footer !== '') : ?>
                        <p style="margin:0 0 6px;font-size:12px;line-height:1.5;color:#94a3b8;"><?php echo esc_html($footer); ?></p>
                        <?php endif; ?>
                        <p style="margin:0;font-size:11px;line-height:1.45;color:#cbd5e1;">
                            <?php if ($link_footer_site) : ?>
                            <a href="<?php echo esc_url($site_url); ?>" style="color:#94a3b8;text-decoration:none;"><?php echo esc_html($site_name); ?></a>
                            <?php else : ?>
                            <span style="color:#94a3b8;"><?php echo esc_html($site_name); ?></span>
                            <?php endif; ?>
                        </p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>
        <?php
        return (string) ob_get_clean();
    }
}
