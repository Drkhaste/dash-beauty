<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_maintenance_mode_get_opts')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_maintenance_mode_get_opts(): array
    {
        return function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    }
}

if (!function_exists('yooadmin_maintenance_mode_is_enabled')) {
    function yooadmin_maintenance_mode_is_enabled(): bool
    {
        $opts = yooadmin_maintenance_mode_get_opts();

        return !empty($opts['maintenance_mode_enabled']);
    }
}

if (!function_exists('yooadmin_maintenance_mode_user_can_bypass')) {
    function yooadmin_maintenance_mode_user_can_bypass(): bool
    {
        $can = is_user_logged_in() && current_user_can('manage_options');

        /** @var bool $can */
        return (bool) apply_filters('yooadmin_maintenance_mode_user_can_bypass', $can);
    }
}

if (!function_exists('yooadmin_maintenance_get_language_locales')) {
    /**
     * @return string[]
     */
    function yooadmin_maintenance_get_language_locales(): array
    {
        if (function_exists('yooadmin_login_toolbar_get_language_locales')) {
            return yooadmin_login_toolbar_get_language_locales();
        }

        $installed = get_available_languages();
        if (!is_array($installed)) {
            $installed = [];
        }

        $site_locale = get_locale();
        if (!is_string($site_locale) || $site_locale === '') {
            $site_locale = 'en_US';
        }

        return array_values(array_unique(array_merge(['en_US'], $installed, [$site_locale])));
    }
}

if (!function_exists('yooadmin_maintenance_resolve_effective_color_mode')) {
    /**
     * Maintenance / public error pages always use dark appearance.
     *
     * @return string dark
     */
    function yooadmin_maintenance_resolve_effective_color_mode(): string
    {
        return 'dark';
    }
}

if (!function_exists('yooadmin_maintenance_get_locale_for_content')) {
    function yooadmin_maintenance_get_locale_for_content(): string
    {
        if (function_exists('yooadmin_login_toolbar_resolve_visitor_locale')) {
            $resolved = yooadmin_login_toolbar_resolve_visitor_locale();
            if (is_string($resolved) && $resolved !== '') {
                return $resolved;
            }
        }

        $locale = function_exists('determine_locale') ? determine_locale() : get_locale();

        return is_string($locale) && $locale !== '' ? $locale : 'en_US';
    }
}

if (!function_exists('yooadmin_maintenance_get_enabled_locales')) {
    /**
     * @return string[]
     */
    function yooadmin_maintenance_get_enabled_locales(): array
    {
        $opts = yooadmin_maintenance_mode_get_opts();
        if (!isset($opts['maintenance_mode_enabled_locales']) || !is_array($opts['maintenance_mode_enabled_locales'])) {
            return [];
        }

        $enabled = [];
        foreach ($opts['maintenance_mode_enabled_locales'] as $loc) {
            $loc = yooadmin_sanitize_locale_name((string) $loc);
            if ($loc !== '') {
                $enabled[] = $loc;
            }
        }

        return array_values(array_unique($enabled));
    }
}

if (!function_exists('yooadmin_maintenance_locale_override_allowed')) {
    function yooadmin_maintenance_locale_override_allowed(string $locale): bool
    {
        $locale = yooadmin_sanitize_locale_name($locale);
        if ($locale === '') {
            return false;
        }

        $enabled = yooadmin_maintenance_get_enabled_locales();
        if ($enabled === []) {
            return true;
        }

        return in_array($locale, $enabled, true);
    }
}

if (!function_exists('yooadmin_maintenance_get_localized_string')) {
    /**
     * @param array<string, string> $map    Locale => string.
     * @param string                $fallback Single fallback when map/locale empty.
     */
    function yooadmin_maintenance_get_localized_string(array $map, string $fallback): string
    {
        $locale = yooadmin_maintenance_get_locale_for_content();
        if (yooadmin_maintenance_locale_override_allowed($locale)
            && isset($map[ $locale ])
            && trim((string) $map[ $locale ]) !== '') {
            return (string) $map[ $locale ];
        }

        $site = get_locale();
        if (is_string($site) && $site !== ''
            && yooadmin_maintenance_locale_override_allowed($site)
            && isset($map[ $site ])
            && trim((string) $map[ $site ]) !== '') {
            return (string) $map[ $site ];
        }

        if (trim($fallback) !== '') {
            return $fallback;
        }

        return '';
    }
}

if (!function_exists('yooadmin_maintenance_get_title')) {
    function yooadmin_maintenance_get_title(): string
    {
        $opts   = yooadmin_maintenance_mode_get_opts();
        $titles = isset($opts['maintenance_mode_titles']) && is_array($opts['maintenance_mode_titles'])
            ? $opts['maintenance_mode_titles']
            : [];
        $fallback = isset($opts['maintenance_mode_title']) ? trim((string) $opts['maintenance_mode_title']) : '';
        if ($fallback === '') {
            $fallback = __('Site under maintenance', 'yooadmin');
        }

        $text = yooadmin_maintenance_get_localized_string($titles, $fallback);

        return $text !== '' ? $text : __('Site under maintenance', 'yooadmin');
    }
}

if (!function_exists('yooadmin_maintenance_get_message')) {
    function yooadmin_maintenance_get_message(): string
    {
        $opts     = yooadmin_maintenance_mode_get_opts();
        $messages = isset($opts['maintenance_mode_messages']) && is_array($opts['maintenance_mode_messages'])
            ? $opts['maintenance_mode_messages']
            : [];
        $fallback = isset($opts['maintenance_mode_message']) ? trim((string) $opts['maintenance_mode_message']) : '';
        if ($fallback === '') {
            $fallback = __('We are performing scheduled maintenance. Please check back soon.', 'yooadmin');
        }

        $text = yooadmin_maintenance_get_localized_string($messages, $fallback);

        return $text !== '' ? $text : __('We are performing scheduled maintenance. Please check back soon.', 'yooadmin');
    }
}

if (!function_exists('yooadmin_maintenance_request_is_excluded')) {
    function yooadmin_maintenance_request_is_excluded(): bool
    {
        if (yooadmin_maintenance_mode_user_can_bypass()) {
            return true;
        }

        if (is_admin()) {
            return true;
        }

        if (defined('DOING_AJAX') && DOING_AJAX) {
            return true;
        }
        if (defined('DOING_CRON') && DOING_CRON) {
            return true;
        }
        if (defined('REST_REQUEST') && REST_REQUEST) {
            return true;
        }
        if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
            return true;
        }
        if (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
            return true;
        }

        global $pagenow;
        if (isset($pagenow) && $pagenow === 'wp-login.php') {
            return true;
        }

        $script = isset($_SERVER['PHP_SELF']) ? basename(sanitize_text_field(wp_unslash($_SERVER['PHP_SELF']))) : '';
        if (in_array($script, ['wp-login.php', 'admin-ajax.php', 'async-upload.php'], true)) {
            return true;
        }

        if (function_exists('yooadmin_hidden_login_entry_is_secret_request')
            && yooadmin_hidden_login_entry_is_secret_request()) {
            return true;
        }

        if (function_exists('yooadmin_standalone_login_is_this_request')
            && yooadmin_standalone_login_is_this_request()) {
            return true;
        }

        return false;
    }
}

if (!function_exists('yooadmin_branded_public_print_theme_vars')) {
    /**
     * Dark theme CSS variables for maintenance / public 404 pages.
     */
    function yooadmin_branded_public_print_theme_vars(string $style_id): void
    {
        if (!function_exists('yooadmin_custom_login_get_style_vars')) {
            return;
        }

        $vars = yooadmin_custom_login_get_style_vars('dark');
        $css  = 'body.yooadmin-maintenance-page,body.yooadmin-public-error-page{';
        foreach ($vars as $key => $value) {
            $css .= $key . ':' . $value . ';';
        }
        $css .= '}';

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS variables from trusted theme merge.
        echo '<style id="' . esc_attr($style_id) . '">' . $css . '</style>' . "\n";
    }
}

if (!function_exists('yooadmin_maintenance_resolve_image_attachment')) {
    /**
     * Resolve a stored media URL to the full-size WordPress attachment (if any).
     *
     * @return array{url: string, id: int}
     */
    function yooadmin_maintenance_resolve_image_attachment(string $url): array
    {
        $url = trim($url);
        if ($url === '') {
            return ['url' => '', 'id' => 0];
        }

        $attachment_id = function_exists('attachment_url_to_postid')
            ? (int) attachment_url_to_postid($url)
            : 0;

        if ($attachment_id <= 0 && preg_match('#-\d+x\d+\.(jpe?g|png|gif|webp|avif)$#i', $url)) {
            $stripped = (string) preg_replace('#-\d+x\d+(\.(?:jpe?g|png|gif|webp|avif))#i', '$1', $url);
            if ($stripped !== $url && function_exists('attachment_url_to_postid')) {
                $attachment_id = (int) attachment_url_to_postid($stripped);
                if ($attachment_id > 0) {
                    $url = $stripped;
                }
            }
        }

        if ($attachment_id <= 0) {
            $path = (string) wp_parse_url($url, PHP_URL_PATH);
            $filename = $path !== '' ? basename($path) : '';
            if ($filename !== '' && preg_match('#-\d+x\d+\.(jpe?g|png|gif|webp|avif)$#i', $filename)) {
                $filename = (string) preg_replace('#-\d+x\d+(\.(?:jpe?g|png|gif|webp|avif))#i', '$1', $filename);
            }
            if ($filename !== '') {
                global $wpdb;
                $like = '%' . $wpdb->esc_like($filename);
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Resolve attachment ID from stored filename when URL has no ID; no core helper for this lookup.
                $attachment_id = (int) $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s ORDER BY post_id DESC LIMIT 1",
                        $like
                    )
                );
            }
        }

        if ($attachment_id > 0) {
            $full = '';
            if (function_exists('wp_get_attachment_image_url')) {
                $full = (string) wp_get_attachment_image_url($attachment_id, 'full');
            }
            if ($full === '' && function_exists('wp_get_attachment_url')) {
                $full = (string) wp_get_attachment_url($attachment_id);
            }
            if ($full !== '') {
                return ['url' => $full, 'id' => $attachment_id];
            }
        }

        return ['url' => $url, 'id' => $attachment_id > 0 ? $attachment_id : 0];
    }
}

if (!function_exists('yooadmin_maintenance_get_background_image')) {
    /**
     * Full-size background URL for maintenance / public error pages (no srcset).
     *
     * @return array{url: string, id: int}
     */
    function yooadmin_maintenance_get_background_image(): array
    {
        $opts = yooadmin_maintenance_mode_get_opts();
        $id   = isset($opts['maintenance_mode_image_id']) ? (int) $opts['maintenance_mode_image_id'] : 0;
        $url  = isset($opts['maintenance_mode_image_url']) ? trim((string) $opts['maintenance_mode_image_url']) : '';

        if ($id > 0) {
            $full = '';
            if (function_exists('wp_get_attachment_image_url')) {
                $full = (string) wp_get_attachment_image_url($id, 'full');
            }
            if ($full === '' && function_exists('wp_get_attachment_url')) {
                $full = (string) wp_get_attachment_url($id);
            }
            if ($full !== '') {
                return ['url' => $full, 'id' => $id];
            }
        }

        if ($url !== '') {
            $resolved = yooadmin_maintenance_resolve_image_attachment($url);

            return [
                'url' => $resolved['url'] !== '' ? $resolved['url'] : $url,
                'id'  => (int) $resolved['id'],
            ];
        }

        return ['url' => '', 'id' => 0];
    }
}

if (!function_exists('yooadmin_maintenance_echo_fullsize_background_img')) {
    /**
     * @param array{url: string, id: int} $bg
     */
    function yooadmin_maintenance_echo_fullsize_background_img(array $bg): void
    {
        if (($bg['url'] ?? '') === '') {
            return;
        }

        $src_url = (string) $bg['url'];
        $width   = 0;
        $height  = 0;
        $id      = isset($bg['id']) ? (int) $bg['id'] : 0;

        if ($id > 0 && function_exists('wp_get_attachment_image_src')) {
            $src = wp_get_attachment_image_src($id, 'full');
            if (is_array($src) && !empty($src[0])) {
                $src_url = (string) $src[0];
                $width   = isset($src[1]) ? (int) $src[1] : 0;
                $height  = isset($src[2]) ? (int) $src[2] : 0;
            }
        }

        $attrs = [
            'class'         => 'yoo-maintenance__media-img',
            'src'           => $src_url,
            'alt'           => '',
            'decoding'      => 'sync',
            'fetchpriority' => 'high',
            'loading'       => 'eager',
        ];
        if ($width > 0) {
            $attrs['width'] = (string) $width;
        }
        if ($height > 0) {
            $attrs['height'] = (string) $height;
        }

        $html = '<img';
        foreach ($attrs as $key => $value) {
            $html .= ' ' . $key . '="' . esc_attr($value) . '"';
        }
        $html .= ' />';

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built with esc_attr per attribute.
        echo $html;
    }
}

if (!function_exists('yooadmin_maintenance_render_background_media')) {
    /**
     * Output a single full-resolution background (never wp_get_attachment_image srcset).
     */
    function yooadmin_maintenance_render_background_media(): void
    {
        $bg = yooadmin_maintenance_get_background_image();

        if ($bg['url'] !== '') {
            yooadmin_maintenance_echo_fullsize_background_img($bg);

            return;
        }

        echo '<div class="yoo-maintenance__media-bg" aria-hidden="true"></div>';
    }
}

if (!function_exists('yooadmin_maintenance_get_bg_overlay_opacity')) {
    /**
     * Dark overlay strength over the maintenance background (0.0–1.0).
     */
    function yooadmin_maintenance_get_bg_overlay_opacity(): float
    {
        $opts = yooadmin_maintenance_mode_get_opts();
        $pct  = isset($opts['maintenance_mode_bg_overlay_opacity'])
            ? (int) $opts['maintenance_mode_bg_overlay_opacity']
            : 50;

        return max(0, min(100, $pct)) / 100;
    }
}

if (!function_exists('yooadmin_maintenance_get_bg_blur_amount')) {
    /**
     * Background blur strength (0.0–1.0). Independent from dark overlay.
     */
    function yooadmin_maintenance_get_bg_blur_amount(): float
    {
        $opts = yooadmin_maintenance_mode_get_opts();
        if (isset($opts['maintenance_mode_bg_blur'])) {
            $pct = (int) $opts['maintenance_mode_bg_blur'];
        } else {
            // Sites saved before the blur slider: match previous overlay-linked blur.
            $pct = isset($opts['maintenance_mode_bg_overlay_opacity'])
                ? (int) $opts['maintenance_mode_bg_overlay_opacity']
                : 50;
        }

        return max(0, min(100, $pct)) / 100;
    }
}

if (!function_exists('yooadmin_maintenance_get_branding_logo_width')) {
    /**
     * Logo width from Branding tab (logo_w). Matches the 60–320px slider in settings.
     */
    function yooadmin_maintenance_get_branding_logo_width(): int
    {
        $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
        if (!is_array($opts)) {
            $opts = [];
        }

        $w = isset($opts['logo_w']) ? (int) $opts['logo_w'] : 150;

        /**
         * @param int $w Branding logo width in pixels.
         */
        $w = (int) apply_filters('yooadmin_maintenance_branding_logo_width', $w);

        return max(60, min(320, $w));
    }
}

if (!function_exists('yooadmin_maintenance_get_page_logo_max_width')) {
    function yooadmin_maintenance_get_page_logo_max_width(): int
    {
        return yooadmin_maintenance_get_branding_logo_width();
    }
}

if (!function_exists('yooadmin_maintenance_print_overlay_css_vars')) {
    function yooadmin_maintenance_print_overlay_css_vars(): void
    {
        $overlay = yooadmin_maintenance_get_bg_overlay_opacity();
        $blur    = yooadmin_maintenance_get_bg_blur_amount();
        $card    = yooadmin_maintenance_get_card_overlay_opacity();
        $logo_w  = yooadmin_maintenance_get_page_logo_max_width();

        printf(
            '<style id="yooadmin-maintenance-overlay">body.yooadmin-maintenance-page,body.yooadmin-public-error-page{--yoo-maintenance-overlay-opacity:%1$s;--yoo-maintenance-bg-blur:%2$s;--yoo-maintenance-card-overlay-opacity:%3$s;--yoo-maintenance-logo-max-w:%4$dpx;}</style>' . "\n",
            esc_attr((string) round($overlay, 3)),
            esc_attr((string) round($blur, 3)),
            esc_attr((string) round($card, 3)),
            (int) $logo_w
        );
    }
}

if (!function_exists('yooadmin_maintenance_get_card_overlay_opacity')) {
    /**
     * Dark overlay strength on the maintenance message card (0.0–1.0).
     */
    function yooadmin_maintenance_get_card_overlay_opacity(): float
    {
        $opts = yooadmin_maintenance_mode_get_opts();
        if (isset($opts['maintenance_mode_card_overlay_opacity'])) {
            $pct = (int) $opts['maintenance_mode_card_overlay_opacity'];
        } else {
            $bg  = yooadmin_maintenance_get_bg_overlay_opacity();
            $pct = (int) round(($bg * 0.88 + 0.08) * 100);
        }

        return max(0, min(100, $pct)) / 100;
    }
}

if (!function_exists('yooadmin_maintenance_print_inline_vars')) {
    function yooadmin_maintenance_print_inline_vars(): void
    {
        yooadmin_branded_public_print_theme_vars('yooadmin-maintenance-vars');
        yooadmin_maintenance_print_overlay_css_vars();
    }
}

if (!function_exists('yooadmin_maintenance_render_page')) {
    function yooadmin_maintenance_render_page(): void
    {
        if (!defined('YOOADMIN_DIR')) {
            status_header(503);
            wp_die(esc_html__('Service unavailable.', 'yooadmin'), '', ['response' => 503]);
        }

        status_header(503);
        header('Retry-After: 3600');
        nocache_headers();

        if (!headers_sent()) {
            header('X-Robots-Tag: noindex, nofollow', true);
        }

        $tpl = YOOADMIN_DIR . 'templates/maintenance/maintenance-page.php';
        if (!is_readable($tpl)) {
            wp_die(
                esc_html(yooadmin_maintenance_get_message()),
                esc_html(yooadmin_maintenance_get_title()),
                ['response' => 503]
            );
        }

        require $tpl;
        exit;
    }
}

if (!function_exists('yooadmin_maintenance_template_redirect')) {
    function yooadmin_maintenance_template_redirect(): void
    {
        if (!yooadmin_maintenance_mode_is_enabled() || yooadmin_maintenance_request_is_excluded()) {
            return;
        }

        yooadmin_maintenance_render_page();
    }
}

if (!function_exists('yooadmin_maintenance_pre_determine_locale')) {
    /**
     * @param string $locale Locale.
     * @return string
     */
    function yooadmin_maintenance_pre_determine_locale($locale)
    {
        if (!yooadmin_maintenance_mode_is_enabled() || yooadmin_maintenance_request_is_excluded()) {
            return $locale;
        }

        if (!function_exists('yooadmin_login_toolbar_resolve_visitor_locale')) {
            return $locale;
        }

        $resolved = yooadmin_login_toolbar_resolve_visitor_locale();
        if ($resolved !== null) {
            return $resolved;
        }

        return $locale;
    }
}

if (!function_exists('yooadmin_maintenance_bootstrap')) {
    function yooadmin_maintenance_bootstrap(): void
    {
        add_filter('pre_determine_locale', 'yooadmin_maintenance_pre_determine_locale', 2);
        add_action('template_redirect', 'yooadmin_maintenance_template_redirect', 2);
    }
}

add_action('plugins_loaded', 'yooadmin_maintenance_bootstrap', 22);

if (!function_exists('yooadmin_maintenance_toggle_nonce')) {
    function yooadmin_maintenance_toggle_nonce(): string
    {
        return wp_create_nonce('yooadmin_maintenance_toggle');
    }
}

if (!function_exists('yooadmin_user_can_toggle_maintenance_mode')) {
    function yooadmin_user_can_toggle_maintenance_mode(): bool
    {
        return function_exists('yooadmin_user_can_manage_site_settings')
            && yooadmin_user_can_manage_site_settings();
    }
}

if (!function_exists('yooadmin_maintenance_settings_admin_url')) {
    function yooadmin_maintenance_settings_admin_url(): string
    {
        return admin_url('admin.php?page=yooadmin-settings#tab-maintenance');
    }
}

if (!function_exists('yooadmin_maintenance_bundled_logo_url')) {
    /**
     * Default maintenance page logo (`assets/images/logo.png`), not logo-dark.
     *
     * @return string
     */
    function yooadmin_maintenance_bundled_logo_url(): string
    {
        if (!defined('YOOADMIN_PLUGIN_FILE')) {
            return '';
        }

        $url = plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/logo.png';

        /**
         * Filter the bundled logo URL on the public maintenance screen.
         *
         * @param string $url Absolute URL to logo.png.
         */
        return esc_url_raw((string) apply_filters('yooadmin_maintenance_bundled_logo_url', $url));
    }
}

if (!function_exists('yooadmin_maintenance_resolve_page_logo')) {
    /**
     * Logo for the public maintenance page — bundled logo.png by default (never login dark logo).
     *
     * @return array{url:string,max_w:int,light_url:string,dark_url:string,use_dual:bool}
     */
    function yooadmin_maintenance_resolve_page_logo(): array
    {
        $bundled = yooadmin_maintenance_bundled_logo_url();
        $max_w   = yooadmin_maintenance_get_branding_logo_width();
        $display = $bundled;

        if (function_exists('yooadmin_custom_login_resolve_logo_light')) {
            $light     = yooadmin_custom_login_resolve_logo_light();
            $light_url = trim((string) ($light['url'] ?? ''));

            $reject = [];
            if (function_exists('yooadmin_custom_login_branding_fallback_url')) {
                $reject[] = trim((string) yooadmin_custom_login_branding_fallback_url());
            }
            if (!empty($opts['login_page_logo_dark_url'])) {
                $reject[] = trim((string) $opts['login_page_logo_dark_url']);
            }

            $reject = array_filter(array_unique($reject));

            if ($light_url !== '' && !in_array($light_url, $reject, true)) {
                $display = $light_url;
            }
        }

        return [
            'url'       => $display,
            'max_w'     => $max_w,
            'light_url' => '',
            'dark_url'  => '',
            'use_dual'  => false,
        ];
    }
}

if (!function_exists('yooadmin_maintenance_show_shell_header_badge_when_off')) {
    function yooadmin_maintenance_show_shell_header_badge_when_off(): bool
    {
        $opts = yooadmin_maintenance_mode_get_opts();

        return !empty($opts['maintenance_mode_show_header_badge_when_off']);
    }
}

if (!function_exists('yooadmin_should_render_maintenance_mode_control')) {
    /**
     * Whether the maintenance pill should render for a UI surface.
     *
     * @param string $context shell|frontend-bar|wp-admin-bar
     */
    function yooadmin_should_render_maintenance_mode_control(string $context): bool
    {
        $allowed = ['shell', 'frontend-bar', 'wp-admin-bar'];
        $context = in_array($context, $allowed, true) ? $context : 'shell';

        $on  = yooadmin_maintenance_mode_is_enabled();
        $can = yooadmin_user_can_toggle_maintenance_mode();

        if (!$can && !$on) {
            return false;
        }

        if (!$on && !yooadmin_maintenance_show_shell_header_badge_when_off()) {
            return false;
        }

        $focus_on = function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();

        if ($context === 'wp-admin-bar') {
            return !$focus_on;
        }

        if ($context === 'shell') {
            return $focus_on;
        }

        return true;
    }
}

if (!function_exists('yooadmin_render_maintenance_mode_control')) {
    /**
     * Maintenance pill with YOOAdmin toggle (managers) or read-only badge when on.
     *
     * @param string $context shell|frontend-bar|wp-admin-bar
     */
    function yooadmin_render_maintenance_mode_control(string $context = 'shell'): void
    {
        $allowed = ['shell', 'frontend-bar', 'wp-admin-bar'];
        $context = in_array($context, $allowed, true) ? $context : 'shell';

        if (!yooadmin_should_render_maintenance_mode_control($context)) {
            return;
        }

        $on           = yooadmin_maintenance_mode_is_enabled();
        $can          = yooadmin_user_can_toggle_maintenance_mode();
        $settings_url = yooadmin_maintenance_settings_admin_url();
        $settings_lbl = __('Maintenance settings', 'yooadmin');
        $toggle_on    = __('Maintenance mode on — turn off for visitors', 'yooadmin');
        $toggle_off   = __('Turn on maintenance mode for visitors', 'yooadmin');

        if (!$can) {
            if (!$on) {
                return;
            }
            ?>
            <a href="<?php echo esc_url($settings_url); ?>"
               class="yooadmin-maintenance-pill yooadmin-maintenance-pill--readonly yooadmin-maintenance-pill--<?php echo esc_attr($context); ?> is-on yooadmin-maintenance-pill__settings-link"
               title="<?php echo esc_attr($settings_lbl); ?>">
                <span class="dashicons dashicons-hammer yooadmin-maintenance-pill__icon" aria-hidden="true"></span>
                <span class="yooadmin-maintenance-pill__label"><?php esc_html_e('Maintenance', 'yooadmin'); ?></span>
            </a>
            <?php
            return;
        }

        $pill_class = 'yooadmin-maintenance-pill yooadmin-maintenance-pill--' . esc_attr($context) . ($on ? ' is-on' : ' is-off');
        ?>
        <div class="<?php echo esc_attr($pill_class); ?>"
             data-yooadmin-maintenance-pill
             data-title-on="<?php echo esc_attr($toggle_on); ?>"
             data-title-off="<?php echo esc_attr($toggle_off); ?>">
            <a href="<?php echo esc_url($settings_url); ?>"
               class="yooadmin-maintenance-pill__settings-link"
               title="<?php echo esc_attr($settings_lbl); ?>">
                <span class="dashicons dashicons-hammer yooadmin-maintenance-pill__icon" aria-hidden="true"></span>
                <span class="yooadmin-maintenance-pill__label"><?php esc_html_e('Maintenance', 'yooadmin'); ?></span>
            </a>
            <button type="button"
                    class="yooadmin-maintenance-pill__toggle-btn"
                    aria-pressed="<?php echo $on ? 'true' : 'false'; ?>"
                    title="<?php echo esc_attr($on ? $toggle_on : $toggle_off); ?>">
                <span class="yp-toggle-switch yooadmin-maintenance-pill__switch" aria-hidden="true">
                    <input type="checkbox"
                           class="yooadmin-maintenance-pill__input"
                           <?php checked($on); ?>
                           tabindex="-1"
                           aria-hidden="true">
                    <span class="yp-toggle-slider"></span>
                </span>
            </button>
        </div>
        <?php
    }
}

if (!function_exists('yooadmin_ajax_toggle_maintenance_mode')) {
    function yooadmin_ajax_toggle_maintenance_mode(): void
    {
        check_ajax_referer('yooadmin_maintenance_toggle', 'nonce');

        if (!yooadmin_user_can_toggle_maintenance_mode()) {
            wp_send_json_error(
                ['message' => __('You do not have permission to change maintenance mode.', 'yooadmin')],
                403
            );
        }

        $want_on = isset($_POST['enabled']) ? (int) $_POST['enabled'] : null;
        if ($want_on === null) {
            $want_on = yooadmin_maintenance_mode_is_enabled() ? 0 : 1;
        } else {
            $want_on = $want_on ? 1 : 0;
        }

        $opts = yooadmin_maintenance_mode_get_opts();
        $opts['maintenance_mode_enabled'] = $want_on;
        update_option('yooadmin_options', $opts, false);

        wp_send_json_success([
            'enabled' => (bool) $want_on,
            'message' => $want_on
                ? __('Maintenance mode is on.', 'yooadmin')
                : __('Maintenance mode is off.', 'yooadmin'),
        ]);
    }
}

add_action('wp_ajax_yooadmin_toggle_maintenance_mode', 'yooadmin_ajax_toggle_maintenance_mode');

if (!function_exists('yooadmin_enqueue_maintenance_toggle_script')) {
    function yooadmin_enqueue_maintenance_toggle_script(): void
    {
        if (!is_user_logged_in() || !yooadmin_user_can_toggle_maintenance_mode()) {
            return;
        }

        if (!defined('YOOADMIN_URL') || !defined('YOOADMIN_DIR')) {
            return;
        }

        $rel = 'assets/js/admin/yooadmin-maintenance-toggle.js';
        $abs = YOOADMIN_DIR . $rel;
        if (!is_readable($abs)) {
            return;
        }

        $handle = 'yooadmin-maintenance-toggle';
        if (!wp_script_is($handle, 'registered')) {
            wp_register_script(
                $handle,
                YOOADMIN_URL . $rel,
                ['jquery'],
                (string) filemtime($abs),
                true
            );
            wp_localize_script(
                $handle,
                'yooadminMaintenanceToggle',
                [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce'   => yooadmin_maintenance_toggle_nonce(),
                ]
            );
        }

        wp_enqueue_script($handle);
    }
}

add_action('admin_enqueue_scripts', 'yooadmin_enqueue_maintenance_toggle_script', 30);
add_action('wp_enqueue_scripts', 'yooadmin_enqueue_maintenance_toggle_script', 30);

if (!function_exists('yooadmin_register_admin_bar_maintenance_control')) {
    function yooadmin_register_admin_bar_maintenance_control($wp_admin_bar): void
    {
        if (!is_object($wp_admin_bar) || !method_exists($wp_admin_bar, 'add_node')) {
            return;
        }

        if (!yooadmin_should_render_maintenance_mode_control('wp-admin-bar')) {
            return;
        }

        ob_start();
        yooadmin_render_maintenance_mode_control('wp-admin-bar');
        $title = trim((string) ob_get_clean());
        if ($title === '') {
            return;
        }

        $on = yooadmin_maintenance_mode_is_enabled();

        $wp_admin_bar->add_node([
            'id'     => 'yooadmin-maintenance',
            'parent' => 'top-secondary',
            'title'  => $title,
            'href'   => false,
            'meta'   => [
                'class'    => 'yooadmin-maintenance-ab-item' . ($on ? ' yooadmin-maintenance-ab-item--on' : ' yooadmin-maintenance-ab-item--off'),
                'title'    => $on
                    ? __('Maintenance mode is on for visitors', 'yooadmin')
                    : __('Maintenance mode is off for visitors', 'yooadmin'),
                'priority' => 6,
            ],
        ]);
    }
}

add_action('admin_bar_menu', 'yooadmin_register_admin_bar_maintenance_control', 6);

if (!function_exists('yooadmin_should_enqueue_maintenance_admin_bar_assets')) {
    function yooadmin_should_enqueue_maintenance_admin_bar_assets(): bool
    {
        if (!is_user_logged_in()) {
            return false;
        }

        if (!yooadmin_should_render_maintenance_mode_control('wp-admin-bar')) {
            return false;
        }

        if (is_admin()) {
            return true;
        }

        if (function_exists('yooadmin_is_custom_frontend_admin_bar_enabled')
            && yooadmin_is_custom_frontend_admin_bar_enabled()) {
            return false;
        }

        return function_exists('is_admin_bar_showing') && is_admin_bar_showing();
    }
}

if (!function_exists('yooadmin_enqueue_maintenance_admin_bar_assets')) {
    function yooadmin_enqueue_maintenance_admin_bar_assets(): void
    {
        if (!yooadmin_should_enqueue_maintenance_admin_bar_assets()) {
            return;
        }

        if (!defined('YOOADMIN_URL') || !defined('YOOADMIN_DIR')) {
            return;
        }

        $rel = 'assets/css/admin/admin-bar-maintenance.css';
        $abs = YOOADMIN_DIR . $rel;
        if (!is_readable($abs)) {
            return;
        }

        wp_enqueue_style(
            'yooadmin-admin-bar-maintenance',
            YOOADMIN_URL . $rel,
            ['dashicons'],
            (string) filemtime($abs)
        );
    }
}

add_action('admin_enqueue_scripts', 'yooadmin_enqueue_maintenance_admin_bar_assets', 25);
add_action('wp_enqueue_scripts', 'yooadmin_enqueue_maintenance_admin_bar_assets', 25);
