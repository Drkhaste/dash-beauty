<?php
/**
 * YOOAdmin profile — WordPress Two-Factor integration (UI, email, Arabic).
 *
 * Uses the official two-factor plugin as the backend; YOOAdmin provides
 * branded profile rendering, Arabic translations, and backup-style OTP emails.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

yooadmin_require_if_exists(__DIR__ . '/branded-email-template.php');

/**
 * Whether the WordPress Two-Factor plugin is available.
 */
function yooadmin_profile_two_factor_is_available(): bool {
    return class_exists('Two_Factor_Core');
}

/**
 * Load Arabic (and other bundled) translations for the two-factor text domain.
 */
function yooadmin_profile_two_factor_load_textdomain(): void {
    if (!function_exists('load_textdomain') || !defined('YOOADMIN_DIR')) {
        return;
    }

    $locale = function_exists('get_user_locale') ? get_user_locale() : get_locale();
    $lang   = strtolower(str_replace('_', '-', $locale));
    if (strpos($lang, 'ar') !== 0) {
        return;
    }

    $candidates = [
        YOOADMIN_DIR . 'languages/two-factor-ar.mo',
        YOOADMIN_DIR . 'languages/two-factor-ar_SA.mo',
        YOOADMIN_DIR . 'languages/two-factor-' . $locale . '.mo',
    ];

    foreach ($candidates as $mofile) {
        if (is_readable($mofile)) {
            load_textdomain('two-factor', $mofile);
            break;
        }
    }
}

/**
 * Pending HTML email payload for the next wp_mail() call.
 *
 * @return array<string, mixed>|null
 */
function yooadmin_profile_two_factor_email_pending(): ?array {
    static $pending = null;

    return is_array($pending) ? $pending : null;
}

/**
 * @param array<string, mixed>|null $value
 */
function yooadmin_profile_two_factor_email_set_pending(?array $value): void {
    static $pending = null;
    $pending = $value;
}

/**
 * Store branded email context when two-factor builds the plain message.
 *
 * @param string $message Email body.
 * @param string $token   OTP token.
 * @param int    $user_id User ID.
 */
function yooadmin_profile_two_factor_capture_email_context(string $message, string $token, int $user_id): string {
    $user = get_user_by('id', $user_id);
    if (!($user instanceof WP_User)) {
        return $message;
    }

    $ttl_minutes = 15;
    if (class_exists('Two_Factor_Email')) {
        $provider = Two_Factor_Email::get_instance();
        if (is_object($provider) && method_exists($provider, 'user_token_ttl')) {
            $ttl_minutes = (int) ceil((int) $provider->user_token_ttl($user_id) / MINUTE_IN_SECONDS);
        }
    }

    yooadmin_profile_two_factor_email_set_pending(
        [
            'user_id'     => $user_id,
            'email'       => $user->user_email,
            'token'       => $token,
            'ttl_minutes' => max(1, $ttl_minutes),
            'remote_ip'   => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR'])) : '',
            'user_login'  => $user->user_login,
        ]
    );

    return $message;
}
add_filter('two_factor_token_email_message', 'yooadmin_profile_two_factor_capture_email_context', 5, 3);

/**
 * Replace plain two-factor OTP emails with the YOOAdmin branded HTML layout.
 *
 * @param array<string, mixed> $args wp_mail() arguments.
 * @return array<string, mixed>
 */
function yooadmin_profile_two_factor_branded_wp_mail(array $args): array {
    $pending = yooadmin_profile_two_factor_email_pending();
    if ($pending === null || !function_exists('yooadmin_branded_email_render_card')) {
        return $args;
    }

    $to = $args['to'] ?? '';
    $to_email = '';
    if (is_string($to)) {
        $to_email = $to;
    } elseif (is_array($to) && isset($to[0])) {
        $to_email = (string) $to[0];
    }

    if ($to_email === '' || strcasecmp($to_email, (string) ($pending['email'] ?? '')) !== 0) {
        return $args;
    }

    $token = (string) ($pending['token'] ?? '');
    if ($token === '') {
        return $args;
    }

    yooadmin_profile_two_factor_email_set_pending(null);

    $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
    $ttl       = (int) ($pending['ttl_minutes'] ?? 15);
    $remote_ip = (string) ($pending['remote_ip'] ?? '');
    $login     = (string) ($pending['user_login'] ?? '');

    $headline = sprintf(
        /* translators: %s: site name */
        __('Login verification code for %s', 'yooadmin'),
        $site_name
    );

    $intro = __('Enter this verification code to complete your sign-in:', 'yooadmin');

    $rows = [
        [
            'label' => __('Expires in', 'yooadmin'),
            'value' => sprintf(
                /* translators: %d: minutes */
                _n('%d minute', '%d minutes', $ttl, 'yooadmin'),
                $ttl
            ),
        ],
    ];

    if ($remote_ip !== '') {
        $rows[] = [
            'label' => __('IP address', 'yooadmin'),
            'value' => $remote_ip,
        ];
    }

    if ($login !== '') {
        $rows[] = [
            'label' => __('Account', 'yooadmin'),
            'value' => $login,
        ];
    }

    $rows[] = [
        'label' => __('Site', 'yooadmin'),
        'value' => $site_name,
        'url'   => home_url('/'),
    ];

    $html = yooadmin_branded_email_render_card(
        [
            'headline'      => $headline,
            'intro'         => $intro,
            'badge_label'   => __('Security', 'yooadmin'),
            'badge_tone'    => 'warning',
            'highlight'     => $token,
            'details_title' => __('Verification details', 'yooadmin'),
            'rows'          => $rows,
            'footer_note'   => sprintf(
                /* translators: %s: site name */
                __('Sent by YOOAdmin Security for %s', 'yooadmin'),
                $site_name
            ),
        ]
    );

    $args['message'] = $html;

    $headers = $args['headers'] ?? [];
    if (!is_array($headers)) {
        $headers = array_filter(array_map('trim', explode("\n", (string) $headers)));
    }

    $has_html = false;
    foreach ($headers as $header) {
        if (stripos((string) $header, 'content-type:') !== false && stripos((string) $header, 'text/html') !== false) {
            $has_html = true;
            break;
        }
    }
    if (!$has_html) {
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
    }

    $args['headers'] = $headers;

    return $args;
}
add_filter('wp_mail', 'yooadmin_profile_two_factor_branded_wp_mail', 20);

/**
 * Localized subject for two-factor OTP emails.
 *
 * @param string $subject Subject.
 * @param int    $user_id User ID.
 */
function yooadmin_profile_two_factor_email_subject(string $subject, int $user_id): string {
    unset($user_id);

    return wp_strip_all_tags(
        sprintf(
            /* translators: %s: site name */
            __('[%s] Login verification code', 'yooadmin'),
            wp_specialchars_decode(get_option('blogname'), ENT_QUOTES)
        )
    );
}
add_filter('two_factor_token_email_subject', 'yooadmin_profile_two_factor_email_subject', 10, 2);

/**
 * Enqueue assets required by the Two-Factor profile UI.
 */
function yooadmin_profile_two_factor_enqueue_assets(): void {
    if (!yooadmin_profile_two_factor_is_available()) {
        return;
    }

    yooadmin_profile_two_factor_load_textdomain();

    $tf_main = WP_PLUGIN_DIR . '/two-factor/class-two-factor-core.php';
    if (!is_readable($tf_main)) {
        return;
    }

    if (!wp_style_is('user-edit-2fa', 'registered')) {
        wp_register_style(
            'user-edit-2fa',
            plugins_url('user-edit.css', $tf_main),
            [],
            defined('TWO_FACTOR_VERSION') ? TWO_FACTOR_VERSION : '1'
        );
    }
    wp_enqueue_style('user-edit-2fa');
}

/**
 * Render Two-Factor options for the YOOAdmin profile security panel.
 *
 * @param WP_User $user           Profile user.
 * @param bool    $is_own_profile Own profile vs editing another user.
 */
function yooadmin_profile_two_factor_render(WP_User $user, bool $is_own_profile): void {
    if (!yooadmin_profile_two_factor_is_available()) {
        return;
    }

    yooadmin_profile_two_factor_load_textdomain();

    echo '<div id="two-factor-options" class="yoo-profile-two-factor">';
    Two_Factor_Core::user_two_factor_options($user);
    echo '</div>';

    /**
     * Fires after YOOAdmin renders the Two-Factor profile section.
     *
     * @param WP_User $user
     * @param bool    $is_own_profile
     */
    do_action('yooadmin_profile_after_two_factor_options', $user, $is_own_profile);
}
