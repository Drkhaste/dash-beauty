<?php
/**
 * Standalone login 2FA — Google Authenticator handler.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * @param array<string, array<string, callable>> $handlers Handlers.
 * @return array<string, array<string, callable>>
 */
function yooadmin_standalone_login_two_factor_register_google_authenticator_handler(array $handlers): array {
    if (!class_exists('GoogleAuthenticator')) {
        return $handlers;
    }

    $handlers['google-authenticator'] = [
        'requires'  => 'yooadmin_standalone_login_two_factor_google_authenticator_requires',
        'begin'     => 'yooadmin_standalone_login_two_factor_google_authenticator_begin',
        'challenge' => 'yooadmin_standalone_login_two_factor_google_authenticator_challenge',
        'validate'  => 'yooadmin_standalone_login_two_factor_google_authenticator_validate',
    ];

    return $handlers;
}
add_filter('yooadmin_standalone_login_two_factor_handlers', 'yooadmin_standalone_login_two_factor_register_google_authenticator_handler', 10);

/**
 * @return GoogleAuthenticator|null
 */
function yooadmin_standalone_login_two_factor_google_authenticator_instance() {
    if (!class_exists('GoogleAuthenticator') || empty(GoogleAuthenticator::$instance)) {
        return null;
    }

    $ga = GoogleAuthenticator::$instance;
    return ($ga instanceof GoogleAuthenticator) ? $ga : null;
}

/**
 * @param WP_User $user User.
 */
function yooadmin_standalone_login_two_factor_google_authenticator_requires(WP_User $user): bool {
    $ga = yooadmin_standalone_login_two_factor_google_authenticator_instance();
    if (!$ga || !method_exists($ga, 'is_two_screen_signin_enabled') || !$ga->is_two_screen_signin_enabled()) {
        return false;
    }

    return trim((string) get_user_option('googleauthenticator_enabled', $user->ID)) === 'enabled';
}

/**
 * @param WP_User $user        User.
 * @param bool    $remember    Remember me.
 * @param string  $redirect_to Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_google_authenticator_begin(WP_User $user, bool $remember, string $redirect_to) {
    wp_clear_auth_cookie();

    $challenge = yooadmin_standalone_login_two_factor_google_authenticator_build_challenge();
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'google-authenticator',
        'user_id'     => $user->ID,
        'auth_nonce'  => '',
        'provider'    => 'totp',
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @param WP_User $user         User.
 * @param string  $auth_nonce   Unused.
 * @param string  $provider_key Unused.
 * @param bool    $remember     Remember me.
 * @param string  $redirect_to  Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_google_authenticator_challenge(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    bool $remember,
    string $redirect_to
) {
    unset($auth_nonce, $provider_key);

    $challenge = yooadmin_standalone_login_two_factor_google_authenticator_build_challenge();
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'google-authenticator',
        'user_id'     => $user->ID,
        'auth_nonce'  => '',
        'provider'    => 'totp',
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_google_authenticator_build_challenge() {
    return [
        'title'          => __('Two-factor authentication', 'yooadmin'),
        'lead'           => __('Please enter the Google Authenticator code from your device.', 'yooadmin'),
        'provider'       => 'totp',
        'provider_label' => __('Google Authenticator', 'yooadmin'),
        'fields'         => [
            [
                'name'         => 'googleotp',
                'label'        => __('Authentication code', 'yooadmin'),
                'type'         => 'text',
                'inputmode'    => 'numeric',
                'autocomplete' => 'one-time-code',
                'placeholder'  => '123 456',
                'required'     => true,
            ],
        ],
        'actions'        => [],
        'alternates'     => [],
        'fragment'       => '',
    ];
}

/**
 * @param WP_User              $user         User.
 * @param string               $auth_nonce   Unused.
 * @param string               $provider_key Unused.
 * @param array<string, mixed> $request      Submitted fields.
 * @param bool                 $remember     Remember me.
 * @param string               $redirect_to  Redirect target.
 * @return true|WP_Error
 */
function yooadmin_standalone_login_two_factor_google_authenticator_validate(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    array $request,
    bool $remember,
    string $redirect_to
) {
    unset($auth_nonce, $provider_key, $redirect_to);

    $ga = yooadmin_standalone_login_two_factor_google_authenticator_instance();
    if (!$ga || !method_exists($ga, 'verify')) {
        return new WP_Error('two_factor_unavailable', __('Two-factor authentication is not available.', 'yooadmin'));
    }

    $secret       = trim((string) get_user_option('googleauthenticator_secret', $user->ID));
    $relaxed_mode = trim((string) get_user_option('googleauthenticator_relaxedmode', $user->ID));
    $last_slot    = trim((string) get_user_option('googleauthenticator_lasttimeslot', $user->ID));
    $otp          = isset($request['googleotp']) ? trim((string) $request['googleotp']) : '';

    if ($otp === '') {
        return new WP_Error(
            'two_factor_invalid',
            __('Please enter your verification code.', 'yooadmin')
        );
    }

    $timeslot = $ga->verify($secret, $otp, $relaxed_mode, $last_slot);
    if (!$timeslot) {
        return new WP_Error(
            'two_factor_invalid',
            __('Invalid verification code. Please try again.', 'yooadmin')
        );
    }

    update_user_option($user->ID, 'googleauthenticator_lasttimeslot', $timeslot, true);
    wp_set_auth_cookie($user->ID, $remember);

    if (function_exists('yooadmin_user_switching_finalize_authenticated_session')) {
        yooadmin_user_switching_finalize_authenticated_session((int) $user->ID);
    }

    return true;
}

/**
 * Intercept Google Authenticator before it renders wp-login.php and exits.
 *
 * @param WP_User|WP_Error|null $user     User or error.
 * @param string                $username Username.
 * @param string                $password Password.
 * @return WP_User|WP_Error|null
 */
function yooadmin_standalone_login_two_factor_google_authenticator_intercept($user, $username, $password) {
    unset($username, $password);

    if (!yooadmin_standalone_login_is_ajax_auth_request()) {
        return $user;
    }

    if (is_wp_error($user) || !($user instanceof WP_User)) {
        return $user;
    }

    if (!yooadmin_standalone_login_two_factor_google_authenticator_requires($user)) {
        return $user;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Login step; nonce verified in AJAX handler.
    if (!empty($_POST['googleotp'])) {
        return $user;
    }
    // phpcs:enable WordPress.Security.NonceVerification.Missing

    return new WP_Error(
        'google_2fa_required',
        __('Two-factor authentication required.', 'yooadmin')
    );
}
add_filter('authenticate', 'yooadmin_standalone_login_two_factor_google_authenticator_intercept', 49, 3);

/**
 * @return string[]
 */
function yooadmin_standalone_login_two_factor_google_authenticator_intercept_codes(): array {
    return ['google_2fa_required'];
}
