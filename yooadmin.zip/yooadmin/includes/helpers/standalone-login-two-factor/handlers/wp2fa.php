<?php
/**
 * Standalone login 2FA — WP 2FA (Melapress) handler.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Whether Melapress WP 2FA is fully available.
 */
function yooadmin_standalone_login_two_factor_wp2fa_is_available(): bool {
    return class_exists('\WP2FA\Authenticator\Login')
        && class_exists('\WP2FA\Admin\Helpers\User_Helper');
}

/**
 * Register WP 2FA handler when the plugin is active.
 *
 * @param array<string, array<string, callable>> $handlers Handlers.
 * @return array<string, array<string, callable>>
 */
function yooadmin_standalone_login_two_factor_register_wp2fa_handler(array $handlers): array {
    if (!yooadmin_standalone_login_two_factor_wp2fa_is_available()) {
        return $handlers;
    }

    $handlers['wp-2fa'] = [
        'requires'  => 'yooadmin_standalone_login_two_factor_wp2fa_requires',
        'begin'     => 'yooadmin_standalone_login_two_factor_wp2fa_begin',
        'challenge' => 'yooadmin_standalone_login_two_factor_wp2fa_challenge',
        'validate'  => 'yooadmin_standalone_login_two_factor_wp2fa_validate',
    ];

    return $handlers;
}
add_filter('yooadmin_standalone_login_two_factor_handlers', 'yooadmin_standalone_login_two_factor_register_wp2fa_handler', 10);

/**
 * @param WP_User $user User.
 */
function yooadmin_standalone_login_two_factor_wp2fa_requires(WP_User $user): bool {
    if (!yooadmin_standalone_login_two_factor_wp2fa_is_available()) {
        return false;
    }

    return \WP2FA\Admin\Helpers\User_Helper::is_user_using_two_factor($user->ID);
}

/**
 * @param WP_User $user        User.
 * @param bool    $remember    Remember me.
 * @param string  $redirect_to Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp2fa_begin(WP_User $user, bool $remember, string $redirect_to) {
    \WP2FA\Authenticator\Login::destroy_current_session_for_user($user);
    wp_clear_auth_cookie();

    $login_nonce = \WP2FA\Authenticator\Login::create_login_nonce($user->ID);
    if (!is_array($login_nonce) || empty($login_nonce['key'])) {
        return new WP_Error(
            'two_factor_nonce_failed',
            __('Two-factor authentication could not be started. Please try again.', 'yooadmin')
        );
    }

    $provider = \WP2FA\Admin\Helpers\User_Helper::get_enabled_method_for_user($user);
    if (!is_string($provider) || $provider === '') {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $challenge = yooadmin_standalone_login_two_factor_wp2fa_build_challenge($user, $provider);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'wp-2fa',
        'user_id'     => $user->ID,
        'auth_nonce'  => $login_nonce['key'],
        'provider'    => $provider,
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @param WP_User $user         User.
 * @param string  $auth_nonce   Login nonce.
 * @param string  $provider_key Provider key.
 * @param bool    $remember     Remember me.
 * @param string  $redirect_to  Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp2fa_challenge(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    bool $remember,
    string $redirect_to
) {
    if (!\WP2FA\Authenticator\Login::verify_login_nonce($user->ID, $auth_nonce)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $provider = $provider_key !== ''
        ? $provider_key
        : (string) \WP2FA\Admin\Helpers\User_Helper::get_enabled_method_for_user($user);
    if ($provider === '') {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $challenge = yooadmin_standalone_login_two_factor_wp2fa_build_challenge($user, $provider);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'wp-2fa',
        'user_id'     => $user->ID,
        'auth_nonce'  => $auth_nonce,
        'provider'    => $provider,
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @param WP_User $user         User.
 * @param string  $provider_key Provider key.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp2fa_build_challenge(WP_User $user, string $provider_key) {
    if (!class_exists('\WP2FA\Methods\TOTP')) {
        return new WP_Error('two_factor_provider_missing', __('Two-factor provider not available.', 'yooadmin'));
    }

    $totp_class   = \WP2FA\Methods\TOTP::class;
    $email_class  = \WP2FA\Methods\Email::class;
    $backup_class = \WP2FA\Methods\Backup_Codes::class;

    $alternates = [];
    if (
        $provider_key !== $backup_class::METHOD_NAME
        && $backup_class::are_backup_codes_enabled_for_role(\WP2FA\Admin\Helpers\User_Helper::get_user_role($user))
        && $backup_class::codes_remaining_for_user($user) > 0
    ) {
        $alternates[] = [
            'provider' => $backup_class::METHOD_NAME,
            'label'    => __('Use a backup code', 'yooadmin'),
        ];
    }

    $fields  = [];
    $actions = [];
    $lead    = '';

    if ($provider_key === $totp_class::METHOD_NAME) {
        $lead = __('Enter the code from your authenticator app.', 'yooadmin');
        $fields[] = [
            'name'         => 'authcode',
            'label'        => __('Authentication code', 'yooadmin'),
            'type'         => 'text',
            'inputmode'    => 'numeric',
            'autocomplete' => 'one-time-code',
            'placeholder'  => '123 456',
            'required'     => true,
        ];
    } elseif ($provider_key === $email_class::METHOD_NAME) {
        yooadmin_standalone_login_two_factor_wp2fa_send_email_code($user);
        $lead = __('A verification code has been sent to your email address.', 'yooadmin');
        $fields[] = [
            'name'         => 'authcode',
            'label'        => __('Verification code', 'yooadmin'),
            'type'         => 'text',
            'inputmode'    => 'numeric',
            'autocomplete' => 'one-time-code',
            'placeholder'  => '',
            'required'     => true,
        ];
        $actions[] = [
            'name'  => \WP2FA\Authenticator\Login::INPUT_NAME_RESEND_CODE,
            'label' => __('Resend code', 'yooadmin'),
            'type'  => 'secondary',
        ];
    } elseif ($provider_key === $backup_class::METHOD_NAME) {
        $lead = __('Enter one of your backup codes.', 'yooadmin');
        $fields[] = [
            'name'         => 'wp-2fa-backup-code',
            'label'        => __('Backup code', 'yooadmin'),
            'type'         => 'text',
            'inputmode'    => 'numeric',
            'autocomplete' => 'one-time-code',
            'placeholder'  => '',
            'required'     => true,
        ];
    } else {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    return [
        'title'          => __('Two-factor authentication', 'yooadmin'),
        'lead'           => $lead,
        'provider'       => $provider_key,
        'provider_label' => '',
        'fields'         => $fields,
        'actions'        => $actions,
        'alternates'     => $alternates,
        'fragment'       => '',
    ];
}

/**
 * @param WP_User $user User.
 */
function yooadmin_standalone_login_two_factor_wp2fa_send_email_code(WP_User $user): void {
    if (!class_exists('\WP2FA\Admin\Setup_Wizard') || !defined('WP_2FA_PREFIX')) {
        return;
    }

    $sent = (bool) \WP2FA\Admin\Helpers\User_Helper::get_meta(WP_2FA_PREFIX . 'code_sent');
    if ($sent) {
        return;
    }

    \WP2FA\Admin\Setup_Wizard::send_authentication_setup_email($user->ID, 'nominated_email_address', false);
    \WP2FA\Admin\Helpers\User_Helper::set_meta(WP_2FA_PREFIX . 'code_sent', true);
}

/**
 * @param WP_User              $user         User.
 * @param string               $auth_nonce   Nonce.
 * @param string               $provider_key Provider.
 * @param array<string, mixed> $request      Submitted fields.
 * @param bool                 $remember     Remember me.
 * @param string               $redirect_to  Redirect target.
 * @return true|array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wp2fa_validate(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    array $request,
    bool $remember,
    string $redirect_to
) {
    if (!\WP2FA\Authenticator\Login::verify_login_nonce($user->ID, $auth_nonce)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $provider = $provider_key !== ''
        ? $provider_key
        : (string) \WP2FA\Admin\Helpers\User_Helper::get_enabled_method_for_user($user);
    if ($provider === '') {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $backup = yooadmin_standalone_login_two_factor_stage_request(
        $request,
        [
            'wp-auth-id'    => (string) $user->ID,
            'wp-auth-nonce' => $auth_nonce,
            'provider'      => $provider,
            'rememberme'    => $remember ? '1' : '',
            'redirect_to'   => $redirect_to,
        ]
    );

    $totp_class   = \WP2FA\Methods\TOTP::class;
    $email_class  = \WP2FA\Methods\Email::class;
    $backup_class = \WP2FA\Methods\Backup_Codes::class;
    $resend_key   = \WP2FA\Authenticator\Login::INPUT_NAME_RESEND_CODE;

    if ($provider === $email_class::METHOD_NAME && !empty($request[$resend_key])) {
        if (\WP2FA\Authenticator\Login::pre_process_email_authentication($user) === true) {
            yooadmin_standalone_login_two_factor_restore_request($backup);
            $challenge = yooadmin_standalone_login_two_factor_wp2fa_build_challenge($user, $provider);
            if (is_wp_error($challenge)) {
                return $challenge;
            }

            return [
                'resent'    => true,
                'message'   => __('A new verification code has been sent.', 'yooadmin'),
                'challenge' => $challenge,
                'provider'  => $provider,
            ];
        }
    }

    $valid = null;
    if ($provider === $totp_class::METHOD_NAME) {
        $valid = $totp_class::validate_totp_authentication($user) === true;
    } elseif ($provider === $backup_class::METHOD_NAME) {
        $valid = $backup_class::validate_backup_codes($user) === true;
    } elseif ($provider === $email_class::METHOD_NAME) {
        $valid = \WP2FA\Authenticator\Login::validate_email_authentication($user) === true;
    }

    yooadmin_standalone_login_two_factor_restore_request($backup);

    if ($valid === true) {
        \WP2FA\Authenticator\Login::delete_login_nonce($user->ID);
        wp_set_auth_cookie($user->ID, $remember);

        if (function_exists('yooadmin_user_switching_finalize_authenticated_session')) {
            yooadmin_user_switching_finalize_authenticated_session((int) $user->ID);
        }

        if (defined('WP_2FA_PREFIX')) {
            // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- Firing the WP 2FA plugin's own hook for compatibility; name is owned by that plugin.
            do_action(WP_2FA_PREFIX . 'user_authenticated', $user);
        }

        return true;
    }

    return new WP_Error(
        'two_factor_invalid',
        __('Invalid verification code. Please try again.', 'yooadmin')
    );
}

/**
 * Prevent WP 2FA from redirecting during standalone AJAX login.
 *
 * @param string  $user_login Username.
 * @param WP_User $user       User.
 */
function yooadmin_standalone_login_two_factor_wp2fa_prevent_wp_login(string $user_login, $user): void {
    unset($user_login);

    if (!yooadmin_standalone_login_two_factor_wp2fa_is_available()) {
        return;
    }

    if (!yooadmin_standalone_login_is_ajax_auth_request() || !($user instanceof WP_User)) {
        return;
    }

    if (!yooadmin_standalone_login_two_factor_wp2fa_requires($user)) {
        return;
    }

    remove_action('wp_login', ['\WP2FA\Authenticator\Login', 'wp_login'], 20);
}

if (yooadmin_standalone_login_two_factor_wp2fa_is_available()) {
    add_action('wp_login', 'yooadmin_standalone_login_two_factor_wp2fa_prevent_wp_login', 4, 2);
}
