<?php
/**
 * Standalone login 2FA — Wordfence Login Security handler.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * @param array<string, array<string, callable>> $handlers Handlers.
 * @return array<string, array<string, callable>>
 */
function yooadmin_standalone_login_two_factor_register_wordfence_handler(array $handlers): array {
    if (!class_exists('\WordfenceLS\Controller_TOTP') || !class_exists('\WordfenceLS\Controller_Users')) {
        return $handlers;
    }

    $handlers['wordfence-login-security'] = [
        'requires'  => 'yooadmin_standalone_login_two_factor_wordfence_requires',
        'begin'     => 'yooadmin_standalone_login_two_factor_wordfence_begin',
        'challenge' => 'yooadmin_standalone_login_two_factor_wordfence_challenge',
        'validate'  => 'yooadmin_standalone_login_two_factor_wordfence_validate',
    ];

    return $handlers;
}
add_filter('yooadmin_standalone_login_two_factor_handlers', 'yooadmin_standalone_login_two_factor_register_wordfence_handler', 10);

/**
 * @param WP_User $user User.
 */
function yooadmin_standalone_login_two_factor_wordfence_requires(WP_User $user): bool {
    return \WordfenceLS\Controller_Users::shared()->has_2fa_active($user)
        && !\WordfenceLS\Controller_Users::shared()->has_remembered_2fa($user);
}

/**
 * @param WP_User $user        User.
 * @param bool    $remember    Remember me.
 * @param string  $redirect_to Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wordfence_begin(WP_User $user, bool $remember, string $redirect_to) {
    if (
        class_exists('\WordfenceLS\Controller_WordfenceLS')
        && \WordfenceLS\Controller_WordfenceLS::shared()->legacy_2fa_active()
    ) {
        return new WP_Error(
            'wordfence_legacy_2fa',
            __('Wordfence legacy 2FA mode requires the code in the password field. Please contact the site administrator.', 'yooadmin')
        );
    }

    wp_clear_auth_cookie();

    $challenge = yooadmin_standalone_login_two_factor_wordfence_build_challenge();
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'wordfence-login-security',
        'user_id'     => $user->ID,
        'auth_nonce'  => '',
        'provider'    => 'totp',
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @param WP_User $user         User.
 * @param string  $auth_nonce   Unused.
 * @param string  $provider_key Unused.
 * @param bool    $remember     Remember me.
 * @param string  $redirect_to  Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wordfence_challenge(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    bool $remember,
    string $redirect_to
) {
    unset($auth_nonce, $provider_key);

    $challenge = yooadmin_standalone_login_two_factor_wordfence_build_challenge();
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'wordfence-login-security',
        'user_id'     => $user->ID,
        'auth_nonce'  => '',
        'provider'    => 'totp',
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_standalone_login_two_factor_wordfence_build_challenge() {
    $fields = [
        [
            'name'         => 'wfls-token',
            'label'        => __('Authentication code', 'yooadmin'),
            'type'         => 'text',
            'inputmode'    => 'numeric',
            'autocomplete' => 'one-time-code',
            'placeholder'  => '123 456',
            'required'     => true,
        ],
        [
            'name'  => 'wfls-remember-device',
            'label' => __('Remember this device', 'yooadmin'),
            'type'  => 'checkbox',
        ],
    ];

    return [
        'title'          => __('Two-factor authentication', 'yooadmin'),
        'lead'           => __('Enter the code from your authenticator app or a recovery code.', 'yooadmin'),
        'provider'       => 'totp',
        'provider_label' => __('Wordfence 2FA', 'yooadmin'),
        'fields'         => $fields,
        'actions'        => [],
        'alternates'     => [],
        'fragment'       => '',
    ];
}

/**
 * @param WP_User              $user         User.
 * @param string               $auth_nonce   Unused.
 * @param string               $provider_key Unused.
 * @param array<string, mixed> $request      Submitted fields.
 * @param bool                 $remember     Remember me.
 * @param string               $redirect_to  Redirect target.
 * @return true|WP_Error
 */
function yooadmin_standalone_login_two_factor_wordfence_validate(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    array $request,
    bool $remember,
    string $redirect_to
) {
    unset($auth_nonce, $provider_key, $redirect_to);

    $token = isset($request['wfls-token']) ? trim((string) $request['wfls-token']) : '';
    if ($token === '') {
        return new WP_Error(
            'two_factor_invalid',
            __('Please enter your verification code.', 'yooadmin')
        );
    }

    if (!\WordfenceLS\Controller_TOTP::shared()->validate_2fa($user, $token)) {
        return new WP_Error(
            'two_factor_invalid',
            __('Invalid verification code. Please try again.', 'yooadmin')
        );
    }

    wp_set_auth_cookie($user->ID, $remember);

    if (function_exists('yooadmin_user_switching_finalize_authenticated_session')) {
        yooadmin_user_switching_finalize_authenticated_session((int) $user->ID);
    }

    if (!empty($request['wfls-remember-device'])) {
        \WordfenceLS\Controller_Users::shared()->remember_2fa($user);
    }

    return true;
}

/**
 * Error codes returned by Wordfence when a second step is required.
 *
 * @return string[]
 */
function yooadmin_standalone_login_two_factor_wordfence_intercept_codes(): array {
    return ['wfls_twofactor_required'];
}
