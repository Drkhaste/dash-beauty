<?php
/**
 * Appearance mode icons — bundled Material Design SVGs (light / dark / auto).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_appearance_mode_icon_file')) {
    /**
     * Absolute path to a bundled appearance icon SVG.
     *
     * @param string $mode light|dark|auto
     */
    function yooadmin_appearance_mode_icon_file(string $mode): string
    {
        $mode = sanitize_key($mode);
        if (!in_array($mode, ['light', 'dark', 'auto'], true)) {
            return '';
        }

        $base = defined('YOOADMIN_DIR') ? (string) YOOADMIN_DIR : '';
        if ('' === $base) {
            return '';
        }

        return wp_normalize_path(trailingslashit($base) . 'assets/icons/appearance/' . $mode . '.svg');
    }
}

if (!function_exists('yooadmin_appearance_mode_icon_svg')) {
    /**
     * Render a bundled appearance icon as inline SVG (inherits currentColor).
     *
     * Icons (Material Design, Apache 2.0):
     * - light → wb_sunny
     * - dark  → dark_mode
     * - auto  → contrast (system / half light-half dark — global standard)
     *
     * @param string $mode  light|dark|auto
     * @param int    $size  Pixel width/height.
     * @param string $class CSS class on the root <svg>.
     */
    function yooadmin_appearance_mode_icon_svg(string $mode, int $size = 20, string $class = 'ysh-appearance__svg'): string
    {
        static $cache = [];

        $mode  = sanitize_key($mode);
        $size  = max(12, min(32, $size));
        $class = sanitize_html_class($class) ?: 'ysh-appearance__svg';

        if (!in_array($mode, ['light', 'dark', 'auto'], true)) {
            return '';
        }

        $cache_key = $mode . '|' . $size . '|' . $class;
        if (isset($cache[$cache_key])) {
            return $cache[$cache_key];
        }

        $file = yooadmin_appearance_mode_icon_file($mode);
        if ('' === $file || !is_readable($file)) {
            return '';
        }

        $raw = file_get_contents($file);
        if (!is_string($raw) || '' === trim($raw)) {
            return '';
        }

        if (!preg_match('#<svg[\s\S]*</svg>#i', $raw, $matches)) {
            return '';
        }

        $svg = $matches[0];
        $svg = preg_replace('/\s(width|height|class|aria-hidden|xmlns)="[^"]*"/i', '', $svg);
        $svg = preg_replace(
            '/<svg/i',
            '<svg class="' . esc_attr($class) . '" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="' . (int) $size . '" height="' . (int) $size . '" aria-hidden="true"',
            $svg,
            1
        );
        $svg = preg_replace('/<path(?![^>]*\bfill=)/i', '<path fill="currentColor"', $svg);

        /** @var string $svg */
        $svg = (string) apply_filters('yooadmin_appearance_mode_icon_svg', $svg, $mode, $size, $class);

        $cache[$cache_key] = $svg;

        return $svg;
    }
}

if (!function_exists('yooadmin_appearance_mode_icon_auto_svg')) {
    /**
     * Back-compat wrapper for auto mode icon.
     *
     * @param int    $size  Pixel width/height.
     * @param string $class SVG class attribute.
     */
    function yooadmin_appearance_mode_icon_auto_svg(int $size = 20, string $class = 'ysh-appearance__svg'): string
    {
        return yooadmin_appearance_mode_icon_svg('auto', $size, $class);
    }
}
