<?php
/**
 * Rate limiting for wp-login.php (native WordPress login).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_login_rate_limit_wp_login_action')) {
    function yooadmin_login_rate_limit_wp_login_action(): string
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only wp-login.php action routing; no plugin nonce on core login screen.
        if (isset($_REQUEST['action']) && is_string($_REQUEST['action'])) {
            return sanitize_key(wp_unslash($_REQUEST['action']));
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return 'login';
    }
}

if (!function_exists('yooadmin_login_rate_limit_should_apply_wp_login')) {
    function yooadmin_login_rate_limit_should_apply_wp_login(): bool
    {
        if (!function_exists('yooadmin_login_rate_limit_is_enabled') || !yooadmin_login_rate_limit_is_enabled()) {
            return false;
        }

        if (!function_exists('yooadmin_login_turnstile_is_wp_login_screen')
            || !yooadmin_login_turnstile_is_wp_login_screen()) {
            return false;
        }

        $opts = function_exists('yooadmin_login_rate_limit_get_opts')
            ? yooadmin_login_rate_limit_get_opts()
            : [];

        return !isset($opts['login_rate_limit_wp_login']) || !empty($opts['login_rate_limit_wp_login']);
    }
}

if (!function_exists('yooadmin_login_rate_limit_wp_login_message')) {
    function yooadmin_login_rate_limit_wp_login_message(string $action = 'login', string $identifier = ''): string
    {
        if (function_exists('yooadmin_login_rate_limit_exceeded_message')) {
            return yooadmin_login_rate_limit_exceeded_message($action, $identifier);
        }

        return __('Too many sign-in attempts. Please wait a few minutes before trying again. This is not caused by an incorrect password.', 'yooadmin');
    }
}

if (!function_exists('yooadmin_wp_login_rate_limit_authenticate')) {
    /**
     * @param WP_User|WP_Error|null $user     User, error, or null.
     * @param string                $username Login name.
     * @param string                $password Password.
     * @return WP_User|WP_Error|null
     */
    function yooadmin_wp_login_rate_limit_authenticate($user, $username, $password)
    {
        unset($password);

        if (!yooadmin_login_rate_limit_should_apply_wp_login()) {
            return $user;
        }

        if (yooadmin_login_rate_limit_wp_login_action() !== 'login') {
            return $user;
        }

        if ($user instanceof WP_User) {
            return $user;
        }

        if (is_wp_error($user) && $user->get_error_code() === 'rate_limited') {
            return $user;
        }

        $username = sanitize_user((string) $username);
        $rate     = yooadmin_login_rate_limit_settings();

        if (!yooadmin_login_rate_limit_allows('login', $rate['login_max'], $rate['login_window'], $username)) {
            return new WP_Error('rate_limited', yooadmin_login_rate_limit_wp_login_message('login', $username));
        }

        return $user;
    }
}

if (!function_exists('yooadmin_wp_login_rate_limit_login_failed')) {
    function yooadmin_wp_login_rate_limit_login_failed(string $username): void
    {
        if (!yooadmin_login_rate_limit_should_apply_wp_login()) {
            return;
        }

        $rate = yooadmin_login_rate_limit_settings();
        yooadmin_login_rate_limit_record_failure('login', $rate['login_window'], sanitize_user($username));
    }
}

if (!function_exists('yooadmin_wp_login_rate_limit_login_success')) {
    /**
     * @param string  $user_login Username.
     * @param WP_User $user       User object.
     */
    function yooadmin_wp_login_rate_limit_login_success($user_login, $user): void
    {
        unset($user);

        if (!yooadmin_login_rate_limit_should_apply_wp_login()) {
            return;
        }

        yooadmin_login_rate_limit_clear('login', (string) $user_login);
    }
}

if (!function_exists('yooadmin_wp_login_rate_limit_lostpassword_post')) {
    /**
     * Runs inside {@see retrieve_password()} before the reset email is sent.
     *
     * @param WP_Error      $errors     Errors.
     * @param WP_User|false $user_data  User or false.
     */
    function yooadmin_wp_login_rate_limit_lostpassword_post($errors, $user_data): void
    {
        unset($user_data);

        if (!yooadmin_login_rate_limit_should_apply_wp_login()) {
            return;
        }

        if (!is_wp_error($errors)) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core lost-password POST.
        $user_login = isset($_POST['user_login']) ? sanitize_text_field(wp_unslash($_POST['user_login'])) : '';

        $rate = yooadmin_login_rate_limit_settings();
        if (!yooadmin_login_rate_limit_allows('lostpassword', $rate['lostpassword_max'], $rate['lostpassword_window'], $user_login)) {
            $errors->add('rate_limited', yooadmin_login_rate_limit_wp_login_message('lostpassword', $user_login));
        }
    }
}

if (!function_exists('yooadmin_wp_login_rate_limit_lostpassword_errors')) {
    /**
     * @param WP_Error      $errors     Errors.
     * @param WP_User|false $user_data  User or false.
     * @return WP_Error
     */
    function yooadmin_wp_login_rate_limit_lostpassword_errors($errors, $user_data)
    {
        unset($user_data);

        if (!yooadmin_login_rate_limit_should_apply_wp_login() || !is_wp_error($errors) || !$errors->has_errors()) {
            return $errors;
        }

        if (in_array('rate_limited', (array) $errors->get_error_codes(), true)) {
            return $errors;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Core lost-password POST.
        $user_login = isset($_POST['user_login']) ? sanitize_text_field(wp_unslash($_POST['user_login'])) : '';
        $rate       = yooadmin_login_rate_limit_settings();
        yooadmin_login_rate_limit_record_failure('lostpassword', $rate['lostpassword_window'], $user_login);

        return $errors;
    }
}

if (!function_exists('yooadmin_wp_login_rate_limit_validate_password_reset')) {
    /**
     * @param WP_Error      $errors Errors.
     * @param WP_User|false $user   User or false.
     */
    function yooadmin_wp_login_rate_limit_validate_password_reset($errors, $user): void
    {
        if (!yooadmin_login_rate_limit_should_apply_wp_login()) {
            return;
        }

        $action = yooadmin_login_rate_limit_wp_login_action();
        if (!in_array($action, ['rp', 'resetpass'], true)) {
            return;
        }

        if (!is_wp_error($errors)) {
            return;
        }

        $rate_id = ($user instanceof WP_User && !empty($user->user_login))
            ? (string) $user->user_login
            : '';

        $rate = yooadmin_login_rate_limit_settings();
        if (!yooadmin_login_rate_limit_allows('resetpass', $rate['resetpass_max'], $rate['resetpass_window'], $rate_id)) {
            $errors->add('rate_limited', yooadmin_login_rate_limit_wp_login_message('resetpass', $rate_id));
        }
    }
}

if (!function_exists('yooadmin_wp_login_rate_limit_validate_password_reset_record')) {
    /**
     * @param WP_Error      $errors Errors.
     * @param WP_User|false $user   User or false.
     * @return WP_Error
     */
    function yooadmin_wp_login_rate_limit_validate_password_reset_record($errors, $user)
    {
        if (!yooadmin_login_rate_limit_should_apply_wp_login() || !is_wp_error($errors) || !$errors->has_errors()) {
            return $errors;
        }

        if (in_array('rate_limited', (array) $errors->get_error_codes(), true)) {
            return $errors;
        }

        $rate_id = ($user instanceof WP_User && !empty($user->user_login))
            ? (string) $user->user_login
            : '';
        $rate = yooadmin_login_rate_limit_settings();
        yooadmin_login_rate_limit_record_failure('resetpass', $rate['resetpass_window'], $rate_id);

        return $errors;
    }
}

if (!function_exists('yooadmin_wp_login_rate_limit_after_password_reset')) {
    /**
     * @param WP_User $user User.
     */
    function yooadmin_wp_login_rate_limit_after_password_reset($user): void
    {
        if (!yooadmin_login_rate_limit_should_apply_wp_login() || !($user instanceof WP_User)) {
            return;
        }

        yooadmin_login_rate_limit_clear('resetpass', (string) $user->user_login);
    }
}

if (!function_exists('yooadmin_wp_login_rate_limit_bootstrap')) {
    function yooadmin_wp_login_rate_limit_bootstrap(): void
    {
        if (!yooadmin_login_rate_limit_should_apply_wp_login()) {
            return;
        }

        add_filter('authenticate', 'yooadmin_wp_login_rate_limit_authenticate', 1, 3);
        add_action('wp_login_failed', 'yooadmin_wp_login_rate_limit_login_failed', 10, 1);
        add_action('wp_login', 'yooadmin_wp_login_rate_limit_login_success', 10, 2);
        add_action('lostpassword_post', 'yooadmin_wp_login_rate_limit_lostpassword_post', 0, 2);
        add_filter('lostpassword_errors', 'yooadmin_wp_login_rate_limit_lostpassword_errors', 999, 2);
        add_action('validate_password_reset', 'yooadmin_wp_login_rate_limit_validate_password_reset', 0, 2);
        add_filter('validate_password_reset', 'yooadmin_wp_login_rate_limit_validate_password_reset_record', 999, 2);
        add_action('after_password_reset', 'yooadmin_wp_login_rate_limit_after_password_reset', 10, 1);
    }
}

add_action('login_init', 'yooadmin_wp_login_rate_limit_bootstrap', 6);
