<?php
/**
 * WordPress version compatibility wrappers (Requires at least: 6.0).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_enqueue_emoji_styles')) {
    function yooadmin_enqueue_emoji_styles(): void
    {
        if (function_exists('wp_enqueue_emoji_styles')) {
            call_user_func('wp_enqueue_emoji_styles');
        }
    }
}

if (!function_exists('yooadmin_enqueue_cloudflare_turnstile_script')) {
    /**
     * Cloudflare Turnstile widget (official CDN; required by vendor).
     */
    function yooadmin_enqueue_cloudflare_turnstile_script(): void
    {
        if (!function_exists('wp_enqueue_script')) {
            return;
        }

        $handle = 'cloudflare-turnstile';
        $src    = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';

        if (!wp_script_is($handle, 'registered')) {
            $turnstile_ver = defined('YOOADMIN_VERSION') ? (string) YOOADMIN_VERSION : '1.0.0';
            // phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- Official Cloudflare Turnstile endpoint; cannot be self-hosted.
            wp_register_script($handle, $src, [], $turnstile_ver, true);
            wp_script_add_data($handle, 'async', true);
            wp_script_add_data($handle, 'defer', true);
        }

        wp_enqueue_script($handle);
    }
}

if (!function_exists('yooadmin_sanitize_locale_name')) {
    /**
     * @param string $locale Locale code.
     */
    function yooadmin_sanitize_locale_name(string $locale): string
    {
        if (function_exists('sanitize_locale_name')) {
            return (string) call_user_func('sanitize_locale_name', $locale);
        }

        $locale = str_replace('-', '_', strtolower(trim($locale)));
        if ($locale === '' || !preg_match('/^[a-z]{2,3}(_[a-z0-9]+)*$/', $locale)) {
            return '';
        }

        return $locale;
    }
}

if (!function_exists('yooadmin_cache_flush_group')) {
    /**
     * @param string $group Cache group.
     */
    function yooadmin_cache_flush_group(string $group): bool
    {
        if (function_exists('wp_cache_flush_group')) {
            return (bool) call_user_func('wp_cache_flush_group', $group);
        }

        return wp_cache_flush();
    }
}

if (!function_exists('yooadmin_fast_hash')) {
    /**
     * @param string $data Plaintext to hash.
     */
    function yooadmin_fast_hash(string $data): string
    {
        if (function_exists('wp_fast_hash')) {
            return (string) call_user_func('wp_fast_hash', $data);
        }

        return wp_hash_password($data);
    }
}

if (!function_exists('yooadmin_verify_fast_hash')) {
    /**
     * @param string $data Plaintext.
     * @param string $hash Stored hash.
     */
    function yooadmin_verify_fast_hash(string $data, string $hash): bool
    {
        if (function_exists('wp_verify_fast_hash')) {
            return (bool) call_user_func('wp_verify_fast_hash', $data, $hash);
        }

        return wp_check_password($data, $hash);
    }
}

if (!function_exists('yooadmin_is_password_reset_allowed_for_user')) {
    /**
     * @param WP_User $user User object.
     */
    function yooadmin_is_password_reset_allowed_for_user(WP_User $user): bool
    {
        if (function_exists('wp_is_password_reset_allowed_for_user')) {
            return (bool) call_user_func('wp_is_password_reset_allowed_for_user', $user);
        }

        $allowed = true;

        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
        return (bool) apply_filters('allow_password_reset', $allowed, $user->ID, $user);
    }
}

if (!function_exists('yooadmin_switch_to_user_locale')) {
    /**
     * @param int $user_id User ID.
     */
    function yooadmin_switch_to_user_locale(int $user_id): bool
    {
        if (function_exists('switch_to_user_locale')) {
            return (bool) call_user_func('switch_to_user_locale', $user_id);
        }

        if (!function_exists('get_user_locale') || !function_exists('switch_to_locale')) {
            return false;
        }

        return (bool) switch_to_locale(get_user_locale($user_id));
    }
}

if (!function_exists('yooadmin_ensure_editable_role')) {
    /**
     * @param string $role Role slug.
     */
    function yooadmin_ensure_editable_role(string $role): void
    {
        if (function_exists('wp_ensure_editable_role')) {
            call_user_func('wp_ensure_editable_role', $role);
        }
    }
}

if (!function_exists('yooadmin_current_user_can_for_site')) {
    /**
     * @param int    $blog_id    Site ID.
     * @param string $capability Capability name.
     */
    function yooadmin_current_user_can_for_site(int $blog_id, string $capability): bool
    {
        if (function_exists('current_user_can_for_site')) {
            return (bool) call_user_func('current_user_can_for_site', $blog_id, $capability);
        }

        // phpcs:ignore WordPress.WP.DeprecatedFunctions.current_user_can_for_blogFound -- Fallback for WordPress older than 6.7.
        return current_user_can_for_blog($blog_id, $capability);
    }
}

if (!function_exists('yooadmin_enqueue_command_palette_assets')) {
    function yooadmin_enqueue_command_palette_assets(): void
    {
        if (function_exists('wp_enqueue_command_palette_assets')) {
            call_user_func('wp_enqueue_command_palette_assets');
        }
    }
}

if (!function_exists('yooadmin_command_palette_is_available')) {
    function yooadmin_command_palette_is_available(): bool
    {
        return function_exists('wp_enqueue_command_palette_assets');
    }
}

if (!function_exists('yooadmin_required_field_message')) {
    function yooadmin_required_field_message(): string
    {
        if (function_exists('wp_required_field_message')) {
            return (string) call_user_func('wp_required_field_message');
        }

        /* translators: %s: Asterisk symbol (*). */
        return sprintf(__('Required fields are marked %s', 'yooadmin'), '<span class="required">*</span>');
    }
}

if (!function_exists('yooadmin_required_field_indicator')) {
    function yooadmin_required_field_indicator(): string
    {
        if (function_exists('wp_required_field_indicator')) {
            return (string) call_user_func('wp_required_field_indicator');
        }

        return '<span class="required">*</span>';
    }
}

if (!function_exists('yooadmin_resolve_admin_menu_slug_to_url')) {
    /**
     * Resolve a WordPress admin menu slug to a full admin URL (matches core menu_page_url rules).
     *
     * Slugs such as "my-plugin/settings.php" must use admin.php?page=…, not /wp-admin/my-plugin/settings.php.
     *
     * @param string        $slug     Menu slug from $menu / $submenu.
     * @param callable|null $resolver admin_url or network_admin_url.
     */
    function yooadmin_resolve_admin_menu_slug_to_url(string $slug, $resolver = null): string
    {
        $slug = trim($slug);

        if ($resolver === null || !is_callable($resolver)) {
            $resolver = (is_multisite() && is_network_admin()) ? 'network_admin_url' : 'admin_url';
        }

        if ($slug === '') {
            return (string) call_user_func($resolver);
        }

        if (preg_match('#^https?://#i', $slug)) {
            return function_exists('yooadmin_fix_network_admin_url')
                ? yooadmin_fix_network_admin_url($slug)
                : $slug;
        }

        if (stripos($slug, 'admin.php') === 0) {
            return (string) call_user_func($resolver, $slug);
        }

        if (strpos($slug, '/') !== false) {
            return (string) call_user_func($resolver, 'admin.php?page=' . $slug);
        }

        if (strpos($slug, '=') !== false && strpos($slug, '.php') === false) {
            return (string) call_user_func($resolver, 'admin.php?page=' . $slug);
        }

        if (strpos($slug, '.php') !== false) {
            return (string) call_user_func($resolver, $slug);
        }

        return (string) call_user_func($resolver, 'admin.php?page=' . $slug);
    }
}

if (!function_exists('yooadmin_is_valid_db_table_name')) {
    /**
     * @param string $table Table name.
     */
    function yooadmin_is_valid_db_table_name(string $table): bool
    {
        return (bool) preg_match('/^[a-z0-9_]+$/', $table);
    }
}

if (!function_exists('yooadmin_get_notifications_table_name')) {
    function yooadmin_get_notifications_table_name(): string
    {
        global $wpdb;

        $table = $wpdb->prefix . 'yooadmin_notifications';

        return yooadmin_is_valid_db_table_name($table) ? $table : '';
    }
}

if (!function_exists('yooadmin_notifications_table_exists')) {
    function yooadmin_notifications_table_exists(string $table): bool
    {
        global $wpdb;

        if ($table === '') {
            return false;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table;
    }
}

if (!function_exists('yooadmin_get_notification_rows_by_meta_like')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_get_notification_rows_by_meta_like(string $meta_like): array
    {
        global $wpdb;

        // Fixed suffix only — Plugin Check requires table name assigned in this scope (not via helper return).
        $table = $wpdb->prefix . 'yooadmin_notifications';
        if ($table === '' || !yooadmin_is_valid_db_table_name($table) || !yooadmin_notifications_table_exists($table)) {
            return [];
        }

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table is $wpdb->prefix + fixed yooadmin_notifications suffix; validated above; meta uses %s.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, title, message FROM {$table} WHERE meta LIKE %s",
                $meta_like
            ),
            ARRAY_A
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

        return is_array($rows) ? $rows : [];
    }
}

if (!function_exists('yooadmin_enqueue_script_deferred')) {
    /**
     * Enqueue a footer script with defer when supported.
     *
     * @param string       $handle Script handle.
     * @param string       $src    Script URL.
     * @param string[]     $deps   Dependencies.
     * @param string|false $ver    Version.
     */
    function yooadmin_enqueue_script_deferred(string $handle, string $src, array $deps = [], $ver = false): void
    {
        if (function_exists('wp_register_script') && function_exists('wp_enqueue_script')) {
            if (version_compare(get_bloginfo('version'), '6.3', '>=')) {
                wp_enqueue_script(
                    $handle,
                    $src,
                    $deps,
                    $ver,
                    [
                        'in_footer' => true,
                        'strategy'  => 'defer',
                    ]
                );

                return;
            }

            wp_enqueue_script($handle, $src, $deps, $ver, true);
            if (function_exists('wp_script_add_data')) {
                wp_script_add_data($handle, 'strategy', 'defer');
            }
        }
    }
}

if (!function_exists('yooadmin_register_deferred_script_tag_filter')) {
    function yooadmin_register_deferred_script_tag_filter(): void
    {
        static $registered = false;
        if ($registered) {
            return;
        }
        $registered = true;

        add_filter(
            'script_loader_tag',
            static function (string $tag, string $handle, string $src): string {
                $defer_handles = apply_filters(
                    'yooadmin_defer_script_handles',
                    [
                        'yooadmin-frontend-bar',
                        'yooadmin-focus-alerts',
                        'yooadmin-admin-bar-focus-toggle',
                    ]
                );

                if (!in_array($handle, $defer_handles, true)) {
                    return $tag;
                }

                if (str_contains($tag, ' defer') || str_contains($tag, ' async')) {
                    return $tag;
                }

                return str_replace(' src', ' defer src', $tag);
            },
            10,
            3
        );
    }
}
add_action('init', 'yooadmin_register_deferred_script_tag_filter');

if (!function_exists('yooadmin_admin_ajax_url')) {
    /**
     * Canonical admin-ajax.php URL (not rewritten by custom admin base paths).
     */
    function yooadmin_admin_ajax_url(): string
    {
        return site_url('wp-admin/admin-ajax.php');
    }
}
