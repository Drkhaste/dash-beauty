<?php
/**
 * Cloudflare Turnstile setup guide — links and reusable markup for settings.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Allowed HTML for external links in settings copy.
 *
 * @return array<string, array<string, bool>>
 */
function yooadmin_settings_external_link_allowed_html(): array
{
    return [
        'a' => [
            'href'   => true,
            'class'  => true,
            'target' => true,
            'rel'    => true,
        ],
    ];
}

/**
 * Cloudflare dashboard link (dash.cloudflare.com).
 *
 * @param string|null $label Visible label; defaults to dash.cloudflare.com.
 */
function yooadmin_cloudflare_dashboard_link(?string $label = null): string
{
    $label = $label ?? 'dash.cloudflare.com';

    return sprintf(
        '<a class="yooadmin-settings-external-link" href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
        esc_url('https://dash.cloudflare.com/'),
        esc_html($label)
    );
}

/**
 * Cloudflare Turnstile section link.
 *
 * @param string|null $label Visible label; defaults to translated "Turnstile".
 */
function yooadmin_cloudflare_turnstile_link(?string $label = null): string
{
    $label = $label ?? __('Turnstile', 'yooadmin');

    return sprintf(
        '<a class="yooadmin-settings-external-link" href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
        esc_url('https://dash.cloudflare.com/?to=/:account/turnstile'),
        esc_html($label)
    );
}

/**
 * wp-login.php link for setup instructions.
 */
function yooadmin_wp_login_setup_link(): string
{
    return sprintf(
        '<a class="yooadmin-settings-external-link" href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
        esc_url(wp_login_url()),
        'wp-login.php'
    );
}

/**
 * Short Turnstile intro (no Cloudflare links — those live in the setup modal).
 */
function yooadmin_login_security_turnstile_intro(): string
{
    return __('Cloudflare Turnstile on wp-login.php and the YOOAdmin login page when enabled and keys are saved.', 'yooadmin');
}

/**
 * Print Turnstile setup guide (steps + documentation note).
 */
function yooadmin_render_turnstile_setup_guide(): void
{
    $allowed = yooadmin_settings_external_link_allowed_html();

    ?>
    <div class="yooadmin-turnstile-setup-guide">
        <p class="yooadmin-turnstile-setup-guide__lead"><?php esc_html_e('Turnstile is free for most sites. You only need a Cloudflare account to create keys — your domain does not need to use Cloudflare DNS or proxy.', 'yooadmin'); ?></p>
        <ol class="yooadmin-turnstile-setup-guide__steps">
            <li><?php
                echo wp_kses(
                    sprintf(
                        /* translators: %s: Cloudflare dashboard link. */
                        __('Sign in at %s (create a free account if needed).', 'yooadmin'),
                        yooadmin_cloudflare_dashboard_link()
                    ),
                    $allowed
                );
                ?></li>
            <li><?php esc_html_e('Open Turnstile in the sidebar (or go to Turnstile under Application security).', 'yooadmin'); ?></li>
            <li><?php esc_html_e('Click Add widget, choose a widget name, and add your site hostname (e.g. example.com).', 'yooadmin'); ?></li>
            <li><?php esc_html_e('Copy the Site key into the field on the Turnstile tab, then copy the Secret key into the secret field.', 'yooadmin'); ?></li>
            <li><?php
                echo wp_kses(
                    sprintf(
                        /* translators: 1: wp-login.php link. */
                        __('Save YOOAdmin settings, then open %1$s or your YOOAdmin login page in a private window to confirm the challenge appears.', 'yooadmin'),
                        yooadmin_wp_login_setup_link()
                    ),
                    $allowed
                );
                ?></li>
        </ol>
        <p class="yooadmin-turnstile-setup-guide__note">
            <?php
            echo wp_kses(
                sprintf(
                    /* translators: %s: linked Cloudflare Turnstile documentation label. */
                    __('Documentation: %s', 'yooadmin'),
                    '<a class="yooadmin-settings-external-link" href="https://developers.cloudflare.com/turnstile/get-started/" target="_blank" rel="noopener noreferrer">' . esc_html__('Cloudflare Turnstile — Get started', 'yooadmin') . '</a>'
                ),
                $allowed
            );
            ?>
        </p>
    </div>
    <?php
}

/**
 * Turnstile “How to get keys” dialog (settings page + admin-bar security modal when Focus is off).
 */
function yooadmin_render_login_turnstile_info_modal(): void
{
    static $rendered = false;
    if ($rendered) {
        return;
    }
    $rendered = true;

    ?>
    <div id="yooadmin-login-turnstile-info-modal" class="yp-modal yooadmin-login-turnstile-info-modal" role="dialog" aria-modal="true" aria-hidden="true" aria-labelledby="yooadmin-login-turnstile-info-title">
        <div class="yp-modal__backdrop" data-yooadmin-login-turnstile-info-close></div>
        <div class="yp-modal__dialog" role="document">
            <button type="button" class="yp-modal__close" aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>" data-yooadmin-login-turnstile-info-close>&times;</button>
            <div class="yp-modal__body yooadmin-login-turnstile-info-modal__body">
                <h2 id="yooadmin-login-turnstile-info-title" class="yooadmin-login-turnstile-info-modal__title"><?php esc_html_e('How to get Cloudflare Turnstile keys', 'yooadmin'); ?></h2>
                <?php yooadmin_render_turnstile_setup_guide(); ?>
                <div class="yooadmin-login-turnstile-info-modal__actions">
                    <button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary" data-yooadmin-login-turnstile-info-close><?php esc_html_e('Got it', 'yooadmin'); ?></button>
                </div>
            </div>
        </div>
    </div>
    <?php
}
