<?php
/**
 * YOOAdmin - Helper functions (data-only, no HTML)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Text domain hardcoded as 'yooadmin' for WordPress.org compliance

/* ----------------------------------------------------------------------------
 * STRING / URL HELPERS
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_slug_base')) {
    /**
     * Return the base part of a slug or path (strip query/hash).
     *
     * Examples:
     *  'plugins.php?foo=1'    => 'plugins.php'
     *  'admin.php?page=abc'   => 'admin.php'
     *  'yooadmin-dashboard'   => 'yooadmin-dashboard'
     *
     * @param string $slug
     * @return string
     */
    function yooadmin_slug_base($slug) {
        $s = (string) $slug;
        if ($s === '') return '';
        $cut = strcspn($s, "?#&");
        return ($cut < strlen($s)) ? substr($s, 0, $cut) : $s;
    }
}

if (!function_exists('yooadmin_resolve_admin_url')) {
    /**
     * Convert a short target into a full admin URL.
     *
     * Accepts:
     *  - 'plugins.php'
     *  - 'edit.php?post_type=page'
     *  - 'admin.php?page=yooadmin-dashboard'
     *  - 'yooadmin-dashboard' (treated as admin.php?page=)
     *
     * @param string $target
     * @return string
     */
    function yooadmin_resolve_admin_url($target) {
        global $submenu;
        
        $t = trim((string) $target);
        if ($t === '') return admin_url('index.php');

        if (strpos($t, '.php') !== false || strpos($t, '=') !== false) {
            return admin_url($t);
        }
        
        if (isset($submenu[$t]) && !empty($submenu[$t][0][2])) {
            $first_submenu = (string) $submenu[$t][0][2];
            return admin_url('admin.php?page=' . $first_submenu);
        }
        
        return admin_url('admin.php?page=' . $t);
    }
}

if (!function_exists('yooadmin_quick_actions_remap_media_url')) {
    /**
     * Saved Quick Actions may still point at yooadmin-media after switching to Lite.
     *
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_quick_actions_remap_media_url(array $items): array {
        foreach ($items as $index => $item) {
            if (!is_array($item) || empty($item['url'])) {
                continue;
            }
            $url = (string) $item['url'];
            if (strpos($url, 'page=yooadmin-media') === false) {
                continue;
            }
            if (function_exists('yooadmin_media_redirect_should_use_yooadmin') && yooadmin_media_redirect_should_use_yooadmin()) {
                continue;
            }
            $items[ $index ]['url'] = admin_url('upload.php');
        }

        return $items;
    }
}

add_filter('yooadmin_card_actions', 'yooadmin_quick_actions_remap_media_url', 5);
add_filter('yooadmin_studio_hub_quick_actions', 'yooadmin_quick_actions_remap_media_url', 5);

/* ----------------------------------------------------------------------------
 * MENU TITLE BADGE EXTRACTOR
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_extract_menu_badge')) {
    /**
     * Extract badge info (updates/comments count) from raw menu title.
     * Returns [clean_label, badge|null]
     *
     * @param string $raw_title Raw HTML title coming from $menu/$submenu.
     * @return array{0:string,1:array{type:string,count:int}|null}
     */
    function yooadmin_extract_menu_badge($raw_title) {
        $raw = (string) $raw_title;
        $badge = null;

        // Detect update/comments bubbles: update-plugins / awaiting-mod
        if (preg_match('/<(span)[^>]*class="([^"]*(update-plugins|awaiting-mod)[^"]*)"[^>]*>.*?<span[^>]*>(\d+)<\/span>.*?<\/span>/is', $raw, $m)) {
            $type  = (strpos($m[2], 'awaiting-mod') !== false) ? 'comments' : 'updates';
            $count = (int) $m[4];
            $badge = ['type' => $type, 'count' => $count];
        }

        // Clean to plain text (remove trailing counts if any)
        $clean = trim(wp_strip_all_tags($raw));
        $clean = preg_replace('/\s*\(\d+\)\s*$/u', '', $clean);
        $clean = preg_replace('/\s+\d+\s*$/u', '', $clean);

        return [$clean, $badge];
    }
}

/* ----------------------------------------------------------------------------
 * SUBMENU / NAV HELPERS (DATA ONLY)
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_first_submenu_target')) {
    /**
     * Try to resolve the first real submenu target for a given parent slug.
     * Skips empty/placeholder slugs and "-menu" aliases.
     *
     * @param string $parent_slug
     * @return string|null A slug like 'edit.php?post_type=page' or 'admin.php?page=...' or null.
     */
    function yooadmin_first_submenu_target($parent_slug) {
        global $menu, $submenu;
        if (!isset($submenu) || !is_array($submenu)) return null;

        $orig = (string) $parent_slug;
        $base = yooadmin_slug_base($orig);

        $variants = [$orig, $base];
        $variants[] = (substr($base, -5) === '-menu') ? substr($base, 0, -5) : ($base . '-menu');

        $pick = static function(array $rows, array $skip) {
            foreach ($rows as $row) {
                $slug = isset($row[2]) ? (string) $row[2] : '';
                if ($slug === '' || in_array($slug, $skip, true)) continue;
                return $slug;
            }
            return null;
        };

        // Exact keys first
        if (isset($submenu[$orig]) && ($t = $pick($submenu[$orig], $variants))) return $t;
        if (isset($submenu[$base]) && ($t = $pick($submenu[$base], $variants))) return $t;

        // Try via $menu mapping (menu item that points to this parent)
        if (is_array($menu)) {
            foreach ($menu as $m) {
                $mslug = isset($m[2]) ? (string) $m[2] : '';
                if ($mslug === '') continue;
                $m_base = yooadmin_slug_base($mslug);
                $alt    = (substr($m_base, -5) === '-menu') ? substr($m_base, 0, -5) : ($m_base . '-menu');

                if (in_array($base, [$mslug, $m_base, $alt], true) || in_array($orig, [$mslug, $m_base, $alt], true)) {
                    if (isset($submenu[$mslug]) && ($t = $pick($submenu[$mslug], $variants))) return $t;
                    if (isset($submenu[$m_base]) && ($t = $pick($submenu[$m_base], $variants))) return $t;
                }
            }
        }

        // Fallback: scan all submenus for a base that matches
        foreach ((array) $submenu as $key => $rows) {
            $kb = yooadmin_slug_base((string) $key);
            $kb_nomenu = (substr($kb, -5) === '-menu') ? substr($kb, 0, -5) : $kb;
            if ($kb === $base || $kb_nomenu === $base) {
                if ($t = $pick($rows, $variants)) return $t;
            }
        }

        return null;
    }
}

/* ----------------------------------------------------------------------------
 * BREADCRUMBS (DATA ONLY)
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_wc_admin_breadcrumbs')) {
    /**
     * Build WooCommerce wc-admin breadcrumb segments from ?path=/... parts.
     *
     * @return array<int,array{label:string,url:string}>
     */
    function yooadmin_wc_admin_breadcrumbs() {
        $trail = [
            [
                'label' => __('WooCommerce', 'yooadmin'),
                'url'   => admin_url('admin.php?page=wc-admin'),
            ],
        ];

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only breadcrumb display, no state change.
        $path = isset($_GET['path']) ? sanitize_text_field(wp_unslash($_GET['path'])) : '';
        $path = trim($path);
        if ($path !== '') {
            $accum = '';
            foreach (array_values(array_filter(explode('/', $path))) as $seg) {
                $accum .= '/' . $seg;
                $trail[] = [
                    'label' => ucfirst(str_replace('-', ' ', $seg)),
                    'url'   => admin_url('admin.php?page=wc-admin&path=' . rawurlencode($accum)),
                ];
            }
        }
        return $trail;
    }
}

if (!function_exists('yooadmin_build_breadcrumb')) {
    /**
     * Build breadcrumbs for a given current slug using $menu/$submenu.
     * Returns an array of segments; the last one usually has url=null.
     *
     * @param string $current_slug e.g. 'yooadmin-dashboard' or 'plugins.php'
     * @return array<int,array{label:string,url:string|null}>
     */
    function yooadmin_build_breadcrumb($current_slug) {
        global $menu, $submenu;

        $crumbs = [];
        $slug   = yooadmin_slug_base((string) $current_slug);
        if ($slug === '') return $crumbs;

        // Special case: WooCommerce SPA
        if (isset($_SERVER['REQUEST_URI']) && stripos(sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])), 'admin.php?page=wc-admin') !== false) {
            return yooadmin_wc_admin_breadcrumbs();
        }

        // Top-level match
        if (is_array($menu)) {
            foreach ($menu as $m) {
                $m_slug = isset($m[2]) ? yooadmin_slug_base((string) $m[2]) : '';
                if ($m_slug === $slug) {
                    [$label] = yooadmin_extract_menu_badge((string) ($m[0] ?? ''));
                    $crumbs[] = ['label' => $label, 'url' => null];
                    return $crumbs;
                }
            }
        }

        // Submenu match
        if (is_array($submenu)) {
            foreach ($submenu as $parent_slug => $rows) {
                foreach ((array) $rows as $row) {
                    $row_slug = isset($row[2]) ? yooadmin_slug_base((string) $row[2]) : '';
                    if ($row_slug === $slug) {
                        if (is_array($menu)) {
                            foreach ($menu as $m) {
                                $pslug = isset($m[2]) ? yooadmin_slug_base((string) $m[2]) : '';
                                if ($pslug === yooadmin_slug_base((string) $parent_slug)) {
                                    [$plabel] = yooadmin_extract_menu_badge((string) ($m[0] ?? ''));
                                    $parent_url = admin_url('admin.php?page=' . $parent_slug);
                                    if (!empty($rows[0][2])) {
                                        $first_submenu_slug = (string) $rows[0][2];
                                        $parent_url = yooadmin_resolve_admin_url($first_submenu_slug);
                                    }
                                    $crumbs[] = [
                                        'label' => $plabel,
                                        'url'   => $parent_url,
                                    ];
                                    break;
                                }
                            }
                        }
                        // current segment
                        [$label] = yooadmin_extract_menu_badge((string) ($row[0] ?? ''));
                        $crumbs[] = ['label' => $label, 'url' => null];
                        return $crumbs;
                    }
                }
            }
        }

        // If no exact match, try "first child" breadcrumb
        $first = yooadmin_first_submenu_target($slug);
        if ($first) {
            // parent label
            if (is_array($menu)) {
                foreach ($menu as $m) {
                    $ms = isset($m[2]) ? yooadmin_slug_base((string) $m[2]) : '';
                    if ($ms === $slug) {
                        [$plabel] = yooadmin_extract_menu_badge((string) ($m[0] ?? ''));
                        $crumbs[] = ['label' => $plabel, 'url' => yooadmin_resolve_admin_url($ms)];
                        break;
                    }
                }
            }
            // child label
            if (is_array($submenu)) {
                foreach ($submenu as $parent_slug => $rows) {
                    foreach ((array) $rows as $row) {
                        $row_slug = isset($row[2]) ? yooadmin_slug_base((string) $row[2]) : '';
                        if ($row_slug === yooadmin_slug_base($first)) {
                            [$label] = yooadmin_extract_menu_badge((string) ($row[0] ?? ''));
                            $crumbs[] = ['label' => $label, 'url' => null];
                            return $crumbs;
                        }
                    }
                }
            }
        }

        return $crumbs;
    }
}

/* ----------------------------------------------------------------------------
 * CURRENT ADMIN PAGE CHECK
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_is_current_admin_page')) {
    /**
     * Rough check if a given target appears to be the current admin page.
     *
     * @param string $target e.g. 'plugins.php' or 'admin.php?page=yooadmin-dashboard'
     * @return bool
     */
    function yooadmin_is_current_admin_page($target) {
        $target = yooadmin_slug_base((string) $target);
        if ($target === '') return false;

        $req = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
        $base = admin_url();

        if ($base !== '' && stripos($req, $base) === 0) {
            $req = substr($req, strlen($base));
        }
        $req = yooadmin_slug_base($req);
        return (stripos($req, $target) !== false);
    }
}

if (!function_exists('yooadmin_update_center_should_use_yooadmin')) {
    /**
     * Whether YOOUpdate Center should replace core Updates (network admin in lite; single-site via filter for Plus).
     */
    function yooadmin_update_center_should_use_yooadmin(): bool
    {
        if (is_multisite() && is_network_admin()) {
            return function_exists('yooadmin_network_update_center_should_use')
                && yooadmin_network_update_center_should_use();
        }

        return (bool) apply_filters('yooadmin_update_center_should_use_yooadmin', false);
    }
}

if (!function_exists('yooadmin_update_center_admin_url')) {
    function yooadmin_update_center_admin_url(): string
    {
        if (is_multisite() && is_network_admin()) {
            if (function_exists('yooadmin_network_update_center_should_use') && yooadmin_network_update_center_should_use()) {
                return yooadmin_network_update_center_url();
            }

            return network_admin_url('update-core.php');
        }

        if (yooadmin_update_center_should_use_yooadmin()) {
            return admin_url('admin.php?page=yooadmin-update-center');
        }

        return admin_url('update-core.php');
    }
}

if (!function_exists('yooadmin_update_center_classic_url')) {
    function yooadmin_update_center_classic_url(): string
    {
        return admin_url('update-core.php?yooadmin_no_redirect=1');
    }
}

/* ----------------------------------------------------------------------------
 * GENERIC OPTIONS HELPERS
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_get_option')) {
    /**
     * Read a value from 'yooadmin_options' array option.
     *
     * @param string $key
     * @param mixed  $default
     * @return mixed
     */
    function yooadmin_get_option($key, $default = null) {
        $opts = (array) get_option('yooadmin_options', []);
        return array_key_exists($key, $opts) ? $opts[$key] : $default;
    }
}

if (!function_exists('yooadmin_set_option')) {
    /**
     * Persist a value into 'yooadmin_options' array option.
     * Requires 'manage_options' capability.
     *
     * @param string $key
     * @param mixed  $value
     * @return bool
     */
    function yooadmin_set_option($key, $value) {
        if (!current_user_can('manage_options')) return false;
        $opts = (array) get_option('yooadmin_options', []);
        $opts[$key] = $value;
        return update_option('yooadmin_options', $opts, false);
    }
}

if (!function_exists('yooadmin_get_effective_license_types')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_get_effective_license_types() {
        $catalog_types = get_option('yoopixel_license_types', []);
        $api_cache_types = get_option('yooadmin_api_license_types', []);
        if (!is_array($catalog_types)) {
            $catalog_types = [];
        }
        if (!is_array($api_cache_types)) {
            $api_cache_types = [];
        }
        return array_merge($catalog_types, $api_cache_types);
    }
}

if (!function_exists('yooadmin_set_api_license_types_cache')) {
    /**
     * @param array<string, mixed> $types
     */
    function yooadmin_set_api_license_types_cache(array $types) {
        update_option('yooadmin_api_license_types', $types, false);
        yooadmin_bust_license_type_option_caches();
    }
}

if (!function_exists('yooadmin_bust_license_type_option_caches')) {
    function yooadmin_bust_license_type_option_caches() {
        wp_cache_delete('yoopixel_license_types', 'options');
        wp_cache_delete('yooadmin_api_license_types', 'options');
    }
}

if (!function_exists('yooadmin_themes_redirect_option_enabled')) {
    function yooadmin_themes_redirect_option_enabled(): bool {
        if (function_exists('yooadmin_get_option')) {
            return (bool) yooadmin_get_option('themes_redirect', true);
        }
        $opts = (array) get_option('yooadmin_options', []);
        return array_key_exists('themes_redirect', $opts)
            ? (!empty($opts['themes_redirect']))
            : true;
    }
}

if (!function_exists('yooadmin_themes_redirect_should_use_yooadmin')) {
    function yooadmin_themes_redirect_should_use_yooadmin(): bool {
        if (function_exists('yooadmin_themes_manager_should_use') && !yooadmin_themes_manager_should_use()) {
            return false;
        }

        if (!function_exists('yooadmin_themes_manager_should_use')) {
            if (!yooadmin_themes_redirect_option_enabled()) {
                return false;
            }
            if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
                return false;
            }
        }

        if (function_exists('yooadmin_theme_manager_user_can')) {
            return yooadmin_theme_manager_user_can();
        }

        return current_user_can('switch_themes');
    }
}

if (!function_exists('yooadmin_theme_manager_admin_url')) {
    function yooadmin_theme_manager_admin_url(): string {
        if (function_exists('yooadmin_theme_manager_url')) {
            return yooadmin_theme_manager_url();
        }

        return yooadmin_themes_redirect_should_use_yooadmin()
            ? admin_url('admin.php?page=yooadmin-theme-manager')
            : admin_url('themes.php');
    }
}

if (!function_exists('yooadmin_theme_manager_caps')) {
    /**
     * Theme Manager capabilities for the current user.
     *
     * @return array{can_switch:bool,can_install:bool,can_update:bool,can_delete:bool,can_customize:bool}
     */
    function yooadmin_theme_manager_caps(): array {
        $caps = [
            'can_switch'    => current_user_can('switch_themes'),
            'can_install'   => current_user_can('install_themes'),
            'can_update'    => current_user_can('update_themes'),
            'can_delete'    => current_user_can('delete_themes'),
            'can_customize' => current_user_can('customize'),
        ];

        /**
         * Filter Theme Manager capability flags for UI.
         *
         * @param array{can_switch:bool,can_install:bool,can_update:bool,can_delete:bool,can_customize:bool} $caps
         */
        return (array) apply_filters('yooadmin_theme_manager_caps', $caps);
    }
}
