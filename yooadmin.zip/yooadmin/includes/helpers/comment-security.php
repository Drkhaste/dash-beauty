<?php
/**
 * Comment form security — Turnstile + rate limiting (frontend).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_comment_security_get_opts')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_comment_security_get_opts(): array
    {
        return function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    }
}

if (!function_exists('yooadmin_comment_security_skip_logged_in_visitor')) {
    function yooadmin_comment_security_skip_logged_in_visitor(): bool
    {
        if (!is_user_logged_in()) {
            return false;
        }

        $opts = yooadmin_comment_security_get_opts();

        return !isset($opts['login_turnstile_comments_skip_logged_in'])
            || !empty($opts['login_turnstile_comments_skip_logged_in']);
    }
}

if (!function_exists('yooadmin_comment_security_applies_to_current_visitor')) {
    function yooadmin_comment_security_applies_to_current_visitor(): bool
    {
        if (yooadmin_comment_security_skip_logged_in_visitor()) {
            return false;
        }

        /**
         * @param bool $apply Whether comment security applies to the current visitor.
         */
        return (bool) apply_filters('yooadmin_comment_security_applies_to_visitor', true);
    }
}

if (!function_exists('yooadmin_comment_turnstile_enabled')) {
    function yooadmin_comment_turnstile_enabled(): bool
    {
        if (!function_exists('yooadmin_login_turnstile_is_configured')
            || !yooadmin_login_turnstile_is_configured()) {
            return false;
        }

        $opts = yooadmin_comment_security_get_opts();

        return !empty($opts['login_turnstile_comments']);
    }
}

if (!function_exists('yooadmin_comment_turnstile_should_render')) {
    function yooadmin_comment_turnstile_should_render(): bool
    {
        if (!yooadmin_comment_turnstile_enabled() || !yooadmin_comment_security_applies_to_current_visitor()) {
            return false;
        }

        if (!is_singular() || !comments_open()) {
            return false;
        }

        return true;
    }
}

if (!function_exists('yooadmin_comment_rate_limit_enabled')) {
    function yooadmin_comment_rate_limit_enabled(): bool
    {
        if (!function_exists('yooadmin_login_rate_limit_is_enabled')
            || !yooadmin_login_rate_limit_is_enabled()) {
            return false;
        }

        $opts = yooadmin_comment_security_get_opts();

        return !empty($opts['login_rate_limit_comments']);
    }
}

if (!function_exists('yooadmin_comment_rate_limit_settings')) {
    /**
     * @return array{max: int, window: int}
     */
    function yooadmin_comment_rate_limit_settings(): array
    {
        if (!yooadmin_comment_rate_limit_enabled()) {
            return ['max' => 0, 'window' => 60];
        }

        $opts = yooadmin_comment_security_get_opts();

        return [
            'max'    => max(1, (int) ($opts['login_rate_limit_comments_max'] ?? 8)),
            'window' => max(60, (int) ($opts['login_rate_limit_comments_window'] ?? 15 * MINUTE_IN_SECONDS)),
        ];
    }
}

if (!function_exists('yooadmin_comment_rate_limit_should_apply')) {
    function yooadmin_comment_rate_limit_should_apply(): bool
    {
        return yooadmin_comment_rate_limit_enabled()
            && yooadmin_comment_security_applies_to_current_visitor();
    }
}

if (!function_exists('yooadmin_comment_security_is_submission_request')) {
    function yooadmin_comment_security_is_submission_request(): bool
    {
        if (defined('REST_REQUEST') && REST_REQUEST) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Route slug for routing only.
            $route = isset($GLOBALS['wp']->query_vars['rest_route'])
                ? (string) $GLOBALS['wp']->query_vars['rest_route']
                : '';
            if ($route === '' && !empty($_SERVER['REQUEST_URI'])) {
                $route = sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_URI']));
            }

            return strpos($route, '/wp/v2/comments') !== false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Classic comment POST routing.
        if (isset($_SERVER['SCRIPT_NAME']) && basename(sanitize_text_field(wp_unslash((string) $_SERVER['SCRIPT_NAME']))) === 'wp-comments-post.php') {
            return true;
        }

        return false;
    }
}

if (!function_exists('yooadmin_comment_security_should_verify_submission')) {
    function yooadmin_comment_security_should_verify_submission(): bool
    {
        if (!yooadmin_comment_security_is_submission_request()) {
            return false;
        }

        if (!yooadmin_comment_security_applies_to_current_visitor()) {
            return false;
        }

        return yooadmin_comment_turnstile_enabled() || yooadmin_comment_rate_limit_should_apply();
    }
}

if (!function_exists('yooadmin_comment_rate_limit_exceeded_message')) {
    function yooadmin_comment_rate_limit_exceeded_message(): string
    {
        if (!function_exists('yooadmin_login_rate_limit_remaining_seconds')) {
            return __('Too many comment attempts. Please wait before trying again.', 'yooadmin');
        }

        $remaining = yooadmin_login_rate_limit_remaining_seconds('comment');
        $minutes   = max(1, (int) ceil($remaining / 60));

        /* translators: %d: minutes to wait before trying again. */
        $message = __('Too many comment attempts. Please wait about %d minutes before trying again.', 'yooadmin');

        return sprintf($message, $minutes);
    }
}

if (!function_exists('yooadmin_comment_security_block_submission')) {
    function yooadmin_comment_security_block_submission(string $message, int $status = 403): void
    {
        if (defined('REST_REQUEST') && REST_REQUEST) {
            wp_die(
                esc_html($message),
                esc_html__('Comment blocked', 'yooadmin'),
                ['response' => absint($status)]
            );
        }

        wp_die(
            esc_html($message),
            esc_html__('Comment blocked', 'yooadmin'),
            ['response' => absint($status), 'back_link' => true]
        );
    }
}

if (!function_exists('yooadmin_comment_security_verify_submission')) {
    /**
     * @return true|WP_Error
     */
    function yooadmin_comment_security_verify_submission()
    {
        if (!yooadmin_comment_security_should_verify_submission()) {
            return true;
        }

        if (yooadmin_comment_rate_limit_should_apply()) {
            $settings = yooadmin_comment_rate_limit_settings();
            if (!yooadmin_login_rate_limit_allows('comment', $settings['max'], $settings['window'])) {
                return new WP_Error(
                    'yooadmin_comment_rate_limited',
                    yooadmin_comment_rate_limit_exceeded_message()
                );
            }

            yooadmin_login_rate_limit_record_failure('comment', $settings['window']);
        }

        if (yooadmin_comment_turnstile_enabled()) {
            if (!function_exists('yooadmin_login_turnstile_verify_token')
                || !yooadmin_login_turnstile_verify_token(yooadmin_login_turnstile_request_token())) {
                return new WP_Error(
                    'yooadmin_comment_turnstile_failed',
                    __('Security verification failed. Please complete the challenge and try again.', 'yooadmin')
                );
            }
        }

        return true;
    }
}

if (!function_exists('yooadmin_comment_security_preprocess_comment')) {
    /**
     * @param array<string, mixed> $commentdata
     * @return array<string, mixed>
     */
    function yooadmin_comment_security_preprocess_comment(array $commentdata): array
    {
        if (defined('REST_REQUEST') && REST_REQUEST) {
            return $commentdata;
        }

        if (is_admin()) {
            return $commentdata;
        }

        $check = yooadmin_comment_security_verify_submission();
        if (is_wp_error($check)) {
            yooadmin_comment_security_block_submission($check->get_error_message(), 403);
        }

        return $commentdata;
    }
}

add_filter('preprocess_comment', 'yooadmin_comment_security_preprocess_comment', 1);

if (!function_exists('yooadmin_comment_security_rest_pre_insert')) {
    /**
     * @param array<string, mixed> $prepared_comment
     * @return array<string, mixed>|WP_Error
     */
    function yooadmin_comment_security_rest_pre_insert($prepared_comment, WP_REST_Request $request)
    {
        unset($request);

        if (!is_array($prepared_comment)) {
            return $prepared_comment;
        }

        $check = yooadmin_comment_security_verify_submission();
        if (is_wp_error($check)) {
            return $check;
        }

        return $prepared_comment;
    }
}

add_filter('rest_pre_insert_comment', 'yooadmin_comment_security_rest_pre_insert', 10, 2);

if (!function_exists('yooadmin_comment_turnstile_render_field')) {
    function yooadmin_comment_turnstile_render_field(): void
    {
        if (!yooadmin_comment_turnstile_should_render()) {
            return;
        }

        $display_mode  = function_exists('yooadmin_login_turnstile_display_mode')
            ? yooadmin_login_turnstile_display_mode()
            : 'minimal';
        $display_class = $display_mode === 'standard' ? ' yoo-sl-turnstile-wrap--standard' : '';
        ?>
        <div class="yoo-sl-turnstile-wrap yoo-sl-turnstile-wrap--comment is-pending<?php echo esc_attr($display_class); ?>" data-yoo-turnstile-wrap="comment" data-yoo-comment-turnstile-wrap="1" data-yoo-turnstile-state="pending">
            <p class="yoo-sl-turnstile-status" role="status" aria-live="polite">
                <span class="yoo-sl-turnstile-status__icon dashicons dashicons-shield-alt" aria-hidden="true"></span>
                <span class="yoo-sl-turnstile-status__spinner" aria-hidden="true"></span>
                <span class="yoo-sl-turnstile-status__text" dir="auto"><?php esc_html_e('Security verification in progress…', 'yooadmin'); ?></span>
            </p>
            <div class="yoo-sl-turnstile-host">
                <span class="yoo-sl-turnstile" data-yoo-turnstile-context="comment" data-yoo-comment-turnstile="1" aria-hidden="false"></span>
            </div>
            <button type="button" class="yoo-sl-turnstile-retry" hidden>
                <?php esc_html_e('Try again', 'yooadmin'); ?>
            </button>
        </div>
        <?php
    }
}

add_action('comment_form_after_fields', 'yooadmin_comment_turnstile_render_field', 20);

if (!function_exists('yooadmin_comment_turnstile_form_defaults')) {
    /**
     * @param array<string, mixed> $defaults
     * @return array<string, mixed>
     */
    function yooadmin_comment_turnstile_form_defaults(array $defaults): array
    {
        if (!yooadmin_comment_turnstile_should_render()) {
            return $defaults;
        }

        $class_form = isset($defaults['class_form']) ? (string) $defaults['class_form'] : 'comment-form';
        if (strpos($class_form, 'yoo-comment-form--turnstile') === false) {
            $defaults['class_form'] = trim($class_form . ' yoo-comment-form--turnstile');
        }

        return $defaults;
    }
}

add_filter('comment_form_defaults', 'yooadmin_comment_turnstile_form_defaults');

if (!function_exists('yooadmin_comment_turnstile_enqueue_assets')) {
    function yooadmin_comment_turnstile_enqueue_assets(): void
    {
        if (!yooadmin_comment_turnstile_should_render()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
        if ($base_file === '') {
            return;
        }

        $base_url = plugin_dir_url($base_file);
        $base_dir = plugin_dir_path($base_file);

        if (wp_style_is('dashicons', 'registered')) {
            wp_enqueue_style('dashicons');
        }

        $css_rel = 'assets/css/frontend/yoo-comment-turnstile.css';
        $css_abs = $base_dir . $css_rel;
        if (is_readable($css_abs)) {
            wp_enqueue_style(
                'yooadmin-comment-turnstile',
                $base_url . $css_rel,
                ['dashicons'],
                (string) filemtime($css_abs)
            );
        }

        if (function_exists('yooadmin_enqueue_cloudflare_turnstile_script')) {
            yooadmin_enqueue_cloudflare_turnstile_script();
        }

        $js_rel = 'assets/js/frontend/yoo-comment-turnstile.js';
        $js_abs = $base_dir . $js_rel;
        if (!is_readable($js_abs)) {
            return;
        }

        wp_enqueue_script(
            'yooadmin-comment-turnstile',
            $base_url . $js_rel,
            [],
            (string) filemtime($js_abs),
            true
        );

        $render = function_exists('yooadmin_login_turnstile_client_render_config')
            ? yooadmin_login_turnstile_client_render_config()
            : ['theme' => 'light', 'size' => 'normal', 'appearance' => 'interaction-only', 'language' => 'en'];
        $render['theme'] = 'light';

        wp_localize_script(
            'yooadmin-comment-turnstile',
            'yooadminCommentTurnstile',
            [
                'siteKey'     => function_exists('yooadmin_login_turnstile_site_key')
                    ? yooadmin_login_turnstile_site_key()
                    : '',
                'render'      => $render,
                'displayMode' => function_exists('yooadmin_login_turnstile_display_mode')
                    ? yooadmin_login_turnstile_display_mode()
                    : 'minimal',
                'i18n'    => [
                    'captchaRequired'   => __('Please complete the security check.', 'yooadmin'),
                    'securityChecking'  => __('Security verification in progress…', 'yooadmin'),
                    'securityVerified'  => __('Security verification complete', 'yooadmin'),
                    'securityFailed'    => __('Security verification failed. Please try again.', 'yooadmin'),
                    'securityChallenge' => __('Please complete the security check below.', 'yooadmin'),
                    'securityRetry'     => __('Try again', 'yooadmin'),
                ],
            ]
        );
    }
}

add_action('wp_enqueue_scripts', 'yooadmin_comment_turnstile_enqueue_assets', 20);
