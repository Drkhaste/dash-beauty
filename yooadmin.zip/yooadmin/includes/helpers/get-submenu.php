<?php
/**
 * YOOAdmin - AJAX: get submenu items (JSON)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Text domain hardcoded as 'yooadmin' for WordPress.org compliance

/**
 * AJAX handler to return submenu items for a given `menu_slug`.
 *
 * @return void (wp_send_json_* exits)
 */
function yooadmin_ajax_get_submenu() {
    check_ajax_referer('yooadmin_submenu', '_wpnonce');

    if (!current_user_can('read')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }

    $menu_slug = isset($_GET['menu_slug']) ? sanitize_text_field(wp_unslash($_GET['menu_slug'])) : '';
    if ($menu_slug === '') {
        wp_send_json_error(['message' => 'Missing menu_slug'], 400);
    }

    global $submenu;
    $items = [];

    if (isset($submenu[$menu_slug]) && is_array($submenu[$menu_slug])) {
        foreach ($submenu[$menu_slug] as $row) {
            // $row spec: [0] Title (may include markup), [1] Cap, [2] Slug/URL, [3] Page title
            $label_raw = isset($row[0]) ? (string) $row[0] : '';
            $slug      = isset($row[2]) ? (string) $row[2] : '';

            $label = wp_strip_all_tags($label_raw);
            if (function_exists('yooadmin_resolve_admin_menu_slug_to_url')) {
                $url = yooadmin_resolve_admin_menu_slug_to_url($slug !== '' ? $slug : 'index.php', 'admin_url');
            } elseif (strpos($slug, '/') !== false) {
                $url = admin_url('admin.php?page=' . $slug);
            } else {
                $url = admin_url($slug !== '' ? $slug : 'index.php');
            }

            $items[] = [
                'label' => $label,
                'url'   => $url,
                'icon'  => 'dashicons-arrow-right-alt2',
            ];
        }
    }

    wp_send_json_success($items);
}
add_action('wp_ajax_yooadmin_get_submenu', 'yooadmin_ajax_get_submenu');

