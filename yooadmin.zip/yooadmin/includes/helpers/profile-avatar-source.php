<?php
/**
 * Per-user profile photo source (YOOAdmin upload, plugins, or Gravatar).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_profile_avatar_source_meta_key')) {
    function yooadmin_profile_avatar_source_meta_key(): string
    {
        return 'yooadmin_avatar_source';
    }
}

if (!function_exists('yooadmin_profile_photo_plugin_slugs')) {
    /**
     * Known plugin bootstrap files that provide profile photo UI.
     *
     * @return string[]
     */
    function yooadmin_profile_photo_plugin_slugs(): array
    {
        $slugs = [
            'simple-local-avatars/simple-local-avatars.php',
            'simple-user-avatar/simple-user-avatar.php',
            'simple-user-avatar/simple_user_avatar.php',
            'one-user-avatar/one-user-avatar.php',
            'wp-user-avatars/wp-user-avatars.php',
            'basic-user-avatars/basic-user-avatars.php',
            'custom-user-avatar/custom-user-avatar.php',
            'user-avatar/user-avatar.php',
            'members/members.php',
        ];

        /** @var string[] $slugs */
        return (array) apply_filters('yooadmin_profile_photo_plugin_slugs', $slugs);
    }
}

if (!function_exists('yooadmin_profile_photo_plugin_classes')) {
    /**
     * Known callback class names that render profile photo UI.
     *
     * @return string[]
     */
    function yooadmin_profile_photo_plugin_classes(): array
    {
        $classes = [
            'Simple_Local_Avatars',
            'Simple_Local_Avatars_Setup',
            'Simple_User_Avatar',
            'SimpleUserAvatar_Admin',
            'One_User_Avatar',
            'WP_User_Avatars',
            'Basic_User_Avatars',
            'CUA_Plugin',
            'User_Avatar',
        ];

        /** @var string[] $classes */
        return (array) apply_filters('yooadmin_profile_photo_plugin_classes', $classes);
    }
}

if (!function_exists('yooadmin_profile_photo_plugins_available')) {
    /**
     * Whether any installed plugin exposes profile photo settings.
     *
     * @param WP_User|null $user Optional profile user (for filters).
     */
    function yooadmin_profile_photo_plugins_available(?WP_User $user = null): bool
    {
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        foreach (yooadmin_profile_photo_plugin_slugs() as $slug) {
            if (is_plugin_active($slug)) {
                /** @var bool $available */
                $available = (bool) apply_filters('yooadmin_profile_photo_plugins_available', true, $user);
                return $available;
            }
        }

        $classes = yooadmin_profile_photo_plugin_classes();
        foreach (['personal_options', 'show_user_profile', 'edit_user_profile'] as $hook) {
            if (function_exists('yooadmin_profile_hook_has_callback_class')
                && yooadmin_profile_hook_has_callback_class($hook, $classes)
            ) {
                /** @var bool $available */
                $available = (bool) apply_filters('yooadmin_profile_photo_plugins_available', true, $user);
                return $available;
            }
        }

        /** @var bool $available */
        $available = (bool) apply_filters('yooadmin_profile_photo_plugins_available', false, $user);

        return $available;
    }
}

if (!function_exists('yooadmin_profile_avatar_source_choices')) {
    /**
     * @return array<string, string>
     */
    function yooadmin_profile_avatar_source_choices(): array
    {
        $choices = [
            'yooadmin'  => __('YOOAdmin upload', 'yooadmin'),
            'gravatar'  => __('Gravatar', 'yooadmin'),
        ];

        if (yooadmin_profile_photo_plugins_available()) {
            $choices['plugins'] = __('WordPress plugins', 'yooadmin');
        }

        /** @var array<string, string> $choices */
        $choices = (array) apply_filters('yooadmin_profile_avatar_source_choices', $choices);

        if (!yooadmin_profile_photo_plugins_available()) {
            unset($choices['plugins']);
        }

        return $choices;
    }
}

if (!function_exists('yooadmin_profile_avatar_source_descriptions')) {
    /**
     * @return array<string, string>
     */
    function yooadmin_profile_avatar_source_descriptions(): array
    {
        return [
            'yooadmin' => __('Upload and crop a photo from the profile header.', 'yooadmin'),
            'plugins'  => __('Use profile photo options from installed WordPress plugins below.', 'yooadmin'),
            'gravatar' => __('Use the Gravatar linked to this account email address.', 'yooadmin'),
        ];
    }
}

if (!function_exists('yooadmin_profile_sanitize_avatar_source')) {
    function yooadmin_profile_sanitize_avatar_source(string $raw): string
    {
        $raw = sanitize_key($raw);
        $allowed = array_keys(yooadmin_profile_avatar_source_choices());

        return in_array($raw, $allowed, true) ? $raw : 'yooadmin';
    }
}

if (!function_exists('yooadmin_profile_get_avatar_source')) {
    function yooadmin_profile_get_avatar_source(int $user_id): string
    {
        if ($user_id <= 0) {
            return 'yooadmin';
        }

        $stored = get_user_meta($user_id, yooadmin_profile_avatar_source_meta_key(), true);
        if (!is_string($stored) || $stored === '') {
            return 'yooadmin';
        }

        $source = yooadmin_profile_sanitize_avatar_source($stored);

        if ($source === 'plugins' && !yooadmin_profile_photo_plugins_available()) {
            yooadmin_profile_set_avatar_source($user_id, 'yooadmin');

            return 'yooadmin';
        }

        return $source;
    }
}

if (!function_exists('yooadmin_profile_set_avatar_source')) {
    function yooadmin_profile_set_avatar_source(int $user_id, string $source): bool
    {
        if ($user_id <= 0) {
            return false;
        }

        return (bool) update_user_meta(
            $user_id,
            yooadmin_profile_avatar_source_meta_key(),
            yooadmin_profile_sanitize_avatar_source($source)
        );
    }
}

if (!function_exists('yooadmin_profile_post_avatar_source_submitted')) {
    /**
     * Sanitized avatar source from a verified profile save request, or null.
     *
     * Accepts the standard form field (yooadmin_profile_nonce) or AJAX param (nonce).
     * Avatar crop/upload uses a separate AJAX handler and does not use this helper.
     *
     * @return string|null One of yooadmin_profile_avatar_source_choices() keys.
     */
    function yooadmin_profile_post_avatar_source_submitted(int $user_id): ?string
    {
        if ($user_id <= 0) {
            return null;
        }

        $action   = 'yooadmin_update_user_' . $user_id;
        $verified = false;

        if (isset($_POST['yooadmin_profile_nonce'])) {
            $verified = (bool) wp_verify_nonce(
                sanitize_text_field(wp_unslash((string) $_POST['yooadmin_profile_nonce'])),
                $action
            );
        } elseif (isset($_REQUEST['nonce'])) {
            $verified = (bool) wp_verify_nonce(
                sanitize_text_field(wp_unslash((string) $_REQUEST['nonce'])),
                $action
            );
        }

        if (!$verified || !isset($_POST['yooadmin_avatar_source'])) {
            return null;
        }

        return yooadmin_profile_sanitize_avatar_source(
            sanitize_key(wp_unslash((string) $_POST['yooadmin_avatar_source']))
        );
    }
}

if (!function_exists('yooadmin_profile_save_avatar_source_from_request')) {
    function yooadmin_profile_save_avatar_source_from_request(int $user_id): void
    {
        if ($user_id <= 0 || !current_user_can('edit_user', $user_id)) {
            return;
        }

        $source = yooadmin_profile_post_avatar_source_submitted($user_id);
        if ($source === null) {
            return;
        }

        // Keep YOOAdmin when a custom upload exists but the form still submits Gravatar (stale state after upload).
        if (
            $source === 'gravatar'
            && function_exists('yooadmin_user_has_custom_avatar')
            && yooadmin_user_has_custom_avatar($user_id)
        ) {
            yooadmin_profile_set_avatar_source($user_id, 'yooadmin');

            return;
        }

        yooadmin_profile_set_avatar_source($user_id, $source);
    }
}

if (!function_exists('yooadmin_profile_plugin_avatar_attachment_id')) {
    /**
     * Attachment ID stored by a known profile-photo plugin for this user.
     */
    function yooadmin_profile_plugin_avatar_attachment_id(int $user_id): int
    {
        if ($user_id <= 0) {
            return 0;
        }

        if (defined('SUA_USER_META_KEY')) {
            $sua_id = (int) get_user_meta($user_id, SUA_USER_META_KEY, true);
            if ($sua_id > 0) {
                return $sua_id;
            }
        }

        $local_avatar = get_user_meta($user_id, 'simple_local_avatar', true);
        if (is_numeric($local_avatar) && (int) $local_avatar > 0) {
            return (int) $local_avatar;
        }

        /** @var int $attachment_id */
        $attachment_id = (int) apply_filters('yooadmin_profile_plugin_avatar_attachment_id', 0, $user_id);

        return max(0, $attachment_id);
    }
}

if (!function_exists('yooadmin_profile_plugin_fallback_avatar_url')) {
    /**
     * Default avatar when no plugin attachment is set (Gravatar or WP Discussion default).
     */
    function yooadmin_profile_plugin_fallback_avatar_url(int $user_id, int $size = 96): string
    {
        if ($user_id <= 0) {
            return '';
        }

        return (string) get_avatar_url($user_id, ['size' => $size]);
    }
}

if (!function_exists('yooadmin_profile_avatar_url_from_get_avatar')) {
    /**
     * Parse avatar URL from get_avatar() HTML (respects plugin get_avatar filters).
     */
    function yooadmin_profile_avatar_url_from_get_avatar(int $user_id, int $size = 96): string
    {
        if ($user_id <= 0) {
            return '';
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Parsed from core avatar markup.
        $html = get_avatar($user_id, $size);
        if (!is_string($html) || $html === '') {
            return '';
        }

        if (preg_match('/\ssrc=[\'"]([^\'"]+)[\'"]/i', $html, $matches)) {
            return esc_url_raw(html_entity_decode($matches[1], ENT_QUOTES, 'UTF-8'));
        }

        return '';
    }
}

if (!function_exists('yooadmin_profile_avatar_url_for_source')) {
    /**
     * Resolve the hero avatar URL for a given source (without relying on saved meta alone).
     */
    function yooadmin_profile_avatar_url_for_source(int $user_id, string $source, int $size = 110): string
    {
        if ($user_id <= 0) {
            return '';
        }

        $source = yooadmin_profile_sanitize_avatar_source($source);

        if ($source === 'yooadmin') {
            if (function_exists('yooadmin_get_user_avatar_attachment_id')) {
                $avatar_id = yooadmin_get_user_avatar_attachment_id($user_id);
            } else {
                $avatar_id = (int) get_user_meta($user_id, 'yooadmin_avatar_id', true);
            }
            if ($avatar_id > 0) {
                $custom_url = wp_get_attachment_image_url($avatar_id, 'thumbnail');
                if ($custom_url) {
                    return (string) $custom_url;
                }
            }

            return function_exists('yooadmin_blank_avatar_url')
                ? yooadmin_blank_avatar_url()
                : includes_url('images/blank.gif');
        }

        if ($source === 'plugins') {
            $attachment_id = yooadmin_profile_plugin_avatar_attachment_id($user_id);
            if ($attachment_id > 0) {
                $image_size = $size >= 96 ? 'medium' : 'thumbnail';
                $custom_url = wp_get_attachment_image_url($attachment_id, $image_size);
                if (!$custom_url) {
                    $custom_url = wp_get_attachment_image_url($attachment_id, 'thumbnail');
                }
                if ($custom_url) {
                    return (string) $custom_url;
                }
            }

            $plugin_avatar_url = yooadmin_profile_avatar_url_from_get_avatar($user_id, $size);
            if ($plugin_avatar_url !== '') {
                return $plugin_avatar_url;
            }
        }

        if (function_exists('yooadmin_get_avatar_data_unfiltered')) {
            $avatar_data = yooadmin_get_avatar_data_unfiltered($user_id, ['size' => $size]);
            if (!empty($avatar_data['url'])) {
                return (string) $avatar_data['url'];
            }
        }

        return (string) get_avatar_url($user_id, ['size' => $size]);
    }
}

if (!function_exists('yooadmin_profile_avatar_is_placeholder_for_source')) {
    function yooadmin_profile_avatar_is_placeholder_for_source(int $user_id, string $source, int $size = 110): bool
    {
        if ($user_id <= 0) {
            return true;
        }

        $source = yooadmin_profile_sanitize_avatar_source($source);

        if ($source === 'yooadmin') {
            return !(
                function_exists('yooadmin_user_has_custom_avatar')
                && yooadmin_user_has_custom_avatar($user_id)
            );
        }

        if ($source === 'plugins') {
            return yooadmin_profile_plugin_avatar_attachment_id($user_id) <= 0;
        }

        if (function_exists('yooadmin_get_avatar_data_unfiltered')) {
            $avatar_data = yooadmin_get_avatar_data_unfiltered($user_id, ['size' => $size]);

            return empty($avatar_data['found_avatar']);
        }

        return false;
    }
}

if (!function_exists('yooadmin_profile_avatar_uses_yooadmin_filters')) {
    function yooadmin_profile_avatar_uses_yooadmin_filters(int $user_id): bool
    {
        return yooadmin_profile_get_avatar_source($user_id) === 'yooadmin';
    }
}

if (!function_exists('yooadmin_profile_avatar_native_ui_enabled')) {
    function yooadmin_profile_avatar_native_ui_enabled(int $user_id): bool
    {
        if ($user_id <= 0 || !current_user_can('edit_user', $user_id)) {
            return false;
        }

        return yooadmin_profile_get_avatar_source($user_id) === 'yooadmin';
    }
}

if (!function_exists('yooadmin_profile_avatar_uses_plugin_panel')) {
    function yooadmin_profile_avatar_uses_plugin_panel(int $user_id): bool
    {
        return yooadmin_profile_get_avatar_source($user_id) === 'plugins';
    }
}

if (!function_exists('yooadmin_profile_avatar_wp_hooks_in_security_tab')) {
    /**
     * Generic show_user_profile / edit_user_profile hooks render in Security when not using the plugin photo panel.
     */
    function yooadmin_profile_avatar_wp_hooks_in_security_tab(int $user_id): bool
    {
        return !yooadmin_profile_avatar_uses_plugin_panel($user_id);
    }
}

if (!function_exists('yooadmin_profile_avatar_plugin_skip_classes')) {
    /**
     * Callback class names skipped in the account photo plugin panel (2FA is on Security).
     *
     * @return string[]
     */
    function yooadmin_profile_avatar_plugin_skip_classes(): array
    {
        $skip = [
            'Two_Factor_Core',
            'Two_Factor_Email',
            'Two_Factor_Backup_Codes',
            'Two_Factor_FIDO_U2F',
            'Two_Factor_Totp',
        ];

        /** @var string[] $skip */
        return (array) apply_filters('yooadmin_profile_avatar_plugin_skip_classes', $skip);
    }
}

if (!function_exists('yooadmin_profile_render_photo_plugin_sections')) {
    /**
     * Render WordPress profile hooks for plugin-provided photo UI (account tab).
     *
     * @param WP_User $user           Profile user.
     * @param bool    $is_own_profile Own profile screen.
     */
    function yooadmin_profile_render_photo_plugin_sections(WP_User $user, bool $is_own_profile): void
    {
        if (!yooadmin_profile_avatar_uses_plugin_panel($user->ID)) {
            return;
        }

        if (!current_user_can('edit_user', $user->ID)) {
            return;
        }

        yooadmin_profile_plugin_sections_prepare_context($is_own_profile);

        $skip  = yooadmin_profile_avatar_plugin_skip_classes();
        $allow = yooadmin_profile_photo_plugin_classes();
        $hook  = $is_own_profile ? 'show_user_profile' : 'edit_user_profile';

        ob_start();
        yooadmin_profile_plugin_sections_run_profile_hooks($hook, $user, $skip, $allow);
        $html = (string) ob_get_clean();

        if (trim($html) === '') {
            echo '<div class="yoo-profile-photo-plugins yoo-profile-photo-plugins--empty">';
            echo '<p class="description">';
            esc_html_e('No profile photo plugin sections were found. Install a profile photo plugin or switch the source to YOOAdmin upload or Gravatar.', 'yooadmin');
            echo '</p>';
            echo '</div>';
            return;
        }

        echo '<div class="yoo-profile-photo-plugins yoo-profile-wp-compat">';
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Third-party profile hook markup.
        echo $html;
        echo '</div>';
    }
}

if (!function_exists('yooadmin_profile_enqueue_photo_plugin_assets')) {
    /**
     * Enqueue scripts/styles required by third-party profile photo plugins on the YOOAdmin profile screen.
     */
    function yooadmin_profile_enqueue_photo_plugin_assets(int $user_id): void
    {
        if ($user_id <= 0 || !yooadmin_profile_photo_plugins_available()) {
            return;
        }

        if (defined('SUA_PLUGIN_VERSION')) {
            $sua_main = WP_PLUGIN_DIR . '/simple-user-avatar/simple-user-avatar.php';
            if (is_readable($sua_main)) {
                wp_enqueue_media();
                wp_enqueue_style(
                    'sua',
                    plugins_url('admin/css/style.min.css', $sua_main),
                    [],
                    SUA_PLUGIN_VERSION
                );
                wp_enqueue_script(
                    'sua',
                    plugins_url('admin/js/scripts.js', $sua_main),
                    ['jquery'],
                    SUA_PLUGIN_VERSION,
                    true
                );

                $size  = 96;
                $fallback_url = function_exists('yooadmin_profile_plugin_fallback_avatar_url')
                    ? yooadmin_profile_plugin_fallback_avatar_url($user_id, $size)
                    : (string) get_avatar_url($user_id, ['size' => $size]);
                $l10n  = [
                    'default_avatar_src'    => $fallback_url,
                    'default_avatar_srcset' => (function_exists('yooadmin_profile_plugin_fallback_avatar_url')
                        ? yooadmin_profile_plugin_fallback_avatar_url($user_id, $size * 2)
                        : (string) get_avatar_url($user_id, ['size' => $size * 2])) . ' 2x',
                    'input_name'            => defined('SUA_USER_META_KEY') ? SUA_USER_META_KEY : 'mm_sua_attachment_id',
                ];
                wp_localize_script('sua', 'sua_obj', $l10n);
            }
        }

        /**
         * Allow other profile photo plugins to enqueue assets on the YOOAdmin profile page.
         *
         * @param int $user_id Profile user ID.
         */
        do_action('yooadmin_profile_enqueue_photo_plugin_assets', $user_id);
    }
}

if (!function_exists('yooadmin_profile_maybe_save_photo_plugin_sections')) {
    function yooadmin_profile_maybe_save_photo_plugin_sections(int $user_id, bool $is_own_profile): void
    {
        if ($user_id <= 0 || !current_user_can('edit_user', $user_id)) {
            return;
        }

        $submitted_source = yooadmin_profile_post_avatar_source_submitted($user_id);
        $uses_plugins     = false;

        if ($submitted_source !== null) {
            $uses_plugins = $submitted_source === 'plugins';
        } elseif (yooadmin_profile_avatar_uses_plugin_panel($user_id)) {
            $uses_plugins = true;
        }

        if (!$uses_plugins) {
            return;
        }

        if (function_exists('yooadmin_profile_save_plugin_sections')) {
            yooadmin_profile_save_plugin_sections($user_id, $is_own_profile);
        }
    }
}
