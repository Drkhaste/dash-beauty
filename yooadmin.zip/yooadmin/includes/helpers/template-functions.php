<?php
/**
 * YOOAdmin - Template functions (data-only, no HTML)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Text domain hardcoded as 'yooadmin' for WordPress.org compliance

/**
 * Return admin URL for the plugin dashboard page.
 *
 * @return string
 */
function yooadmin_dashboard_url() {
    $slug = apply_filters('yooadmin_dashboard_page_slug', 'yooadmin-dashboard');
    return admin_url('admin.php?page=' . $slug);
}

/**
 * Return logo URL from settings; fallback to bundled asset if empty.
 *
 * @return string
 */
function yooadmin_logo_url() {
    // 1) Try saved option first
    $opts = (array) get_option('yooadmin_options', []);
    $opt_url = isset($opts['logo_url']) ? esc_url($opts['logo_url']) : '';

    if ($opt_url) {
        /**
         * Filter: allow overriding the resolved logo URL from option.
         */
        return apply_filters('yooadmin_logo_url', $opt_url);
    }

    // 2) Fallback to plugin asset (original behavior)
    $base_file = defined('YOOADMIN_PLUGIN_FILE')
        ? YOOADMIN_PLUGIN_FILE
        : dirname(__DIR__, 2) . '/yooadmin.php';

    // Fallback to bundled logo.png in assets/images (admin header / branding).
    $fallback = plugin_dir_url($base_file) . 'assets/images/logo.png';

    return apply_filters('yooadmin_logo_url', esc_url($fallback));
}

/**
 * Default branding logo asset URL (no saved option).
 *
 * @return string
 */
if (!function_exists('yooadmin_logo_default_url')) {
    function yooadmin_logo_default_url() {
        $base_file = defined('YOOADMIN_PLUGIN_FILE')
            ? YOOADMIN_PLUGIN_FILE
            : dirname(__DIR__, 2) . '/yooadmin.php';

        $fallback = plugin_dir_url($base_file) . 'assets/images/logo.png';

        return apply_filters('yooadmin_logo_default_url', esc_url($fallback));
    }
}

/**
 * URL for branding preview (settings/wizard): only when the saved value is not a bundled/theme default.
 *
 * @param string $raw_logo_url        Raw `logo_url` from options.
 * @param string $theme_default_logo_url Active theme default logo URL, if any.
 * @return string Escaped URL or empty.
 */
function yooadmin_branding_user_logo_preview_url($raw_logo_url, $theme_default_logo_url = '') {
    $raw_logo_url = trim((string) $raw_logo_url);
    if ($raw_logo_url === '') {
        return '';
    }

    $norm = static function ($u) {
        $u = esc_url_raw($u);
        return $u !== '' ? untrailingslashit($u) : '';
    };

    $default_candidates = [];
    if (function_exists('yooadmin_default_options')) {
        $defs = yooadmin_default_options();
        if (!empty($defs['logo_url'])) {
            $default_candidates[] = $norm($defs['logo_url']);
        }
    }
    if (defined('YOOADMIN_LOGO_URL') && YOOADMIN_LOGO_URL) {
        $default_candidates[] = $norm(YOOADMIN_LOGO_URL);
    }
    if (defined('YOOADMIN_PLUGIN_FILE')) {
        $default_candidates[] = $norm(plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/logo.png');
    }
    if (function_exists('yooadmin_logo_default_url')) {
        $default_candidates[] = $norm(yooadmin_logo_default_url());
    }
    $theme_default_logo_url = trim((string) $theme_default_logo_url);
    if ($theme_default_logo_url !== '') {
        $default_candidates[] = $norm($theme_default_logo_url);
    }

    $default_candidates = array_values(array_unique(array_filter($default_candidates)));
    $mine = $norm($raw_logo_url);
    if ($mine === '' || in_array($mine, $default_candidates, true)) {
        return '';
    }

    return esc_url($raw_logo_url);
}

/**
 * Get current user display name and avatar URL safely.
 *
 * @return array{display:string,avatar:string}
 */
function yooadmin_current_user_meta() {
    $u = wp_get_current_user();
    $display = ($u && $u->ID) ? esc_html($u->display_name) : __('User', 'yooadmin');
    $user_id = ($u && $u->ID) ? (int) $u->ID : 0;
    $avatar_size = 72;
    $source = ($user_id > 0 && function_exists('yooadmin_profile_get_avatar_source'))
        ? yooadmin_profile_get_avatar_source($user_id)
        : 'yooadmin';
    $avatar = '';
    if ($user_id > 0) {
        $avatar = function_exists('yooadmin_profile_avatar_url_for_source')
            ? yooadmin_profile_avatar_url_for_source($user_id, $source, $avatar_size)
            : (string) get_avatar_url($user_id, ['size' => $avatar_size]);
    }

    return [
        'display' => $display,
        'avatar' => esc_url($avatar),
        'avatar_is_placeholder' => ($user_id > 0 && function_exists('yooadmin_profile_avatar_is_placeholder_for_source'))
            ? yooadmin_profile_avatar_is_placeholder_for_source($user_id, $source, $avatar_size)
            : false,
    ];
}

/**
 * Determine if focus mode should be enabled by default.
 *
 * Source of truth:
 *  - If project defines `yoo_should_focus_mode()` use it.
 *  - Else check cookie `yoo_focus` (off/on).
 *  - Else fallback to filter default (true).
 *
 * @return bool
 */
function yooadmin_focus_mode_enabled() {
    if (function_exists('yoo_should_focus_mode')) {
        return (bool) yoo_should_focus_mode();
    }
    if (isset($_COOKIE['yoo_focus'])) {
        return sanitize_text_field(wp_unslash($_COOKIE['yoo_focus'])) !== 'off';
    }
    return (bool) apply_filters('yooadmin_focus_mode_default', true);
}
