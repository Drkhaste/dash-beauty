<?php
/**
 * YOOAdmin - Dashboard data helpers (data-only)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Text domain hardcoded as 'yooadmin' for WordPress.org compliance

/* ----------------------------------------------------------------------------
 * WOO HELPERS
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_wc_active')) {
    /**
     * Check if WooCommerce is active.
     *
     * @return bool
     */
    function yooadmin_wc_active() {
        return class_exists('WooCommerce') && function_exists('wc');
    }
}

/* ----------------------------------------------------------------------------
 * CORE COUNTS (Posts/Pages/Comments/Users) + optional WC stats
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_get_core_counts')) {
    /**
     * Return core counts for dashboard. Will include WooCommerce stats if active.
     *
     * @return array{
     *   posts:int,
     *   pages:int,
     *   comments:int,
     *   users:int,
     *   wc?:array{orders:int,products:int}
     * }
     */
    function yooadmin_get_core_counts() {
        // Posts
        $posts_obj   = wp_count_posts('post');
        $posts_total = (isset($posts_obj->publish)) ? (int) $posts_obj->publish : 0;

        // Pages
        $pages_obj   = wp_count_posts('page');
        $pages_total = (isset($pages_obj->publish)) ? (int) $pages_obj->publish : 0;

        // Comments
        $comments_obj   = wp_count_comments();
        $comments_total = isset($comments_obj->approved) ? (int) $comments_obj->approved : 0;

        // Users
        $users_total = 0;
        $users_count = count_users();
        if (is_array($users_count) && isset($users_count['total_users'])) {
            $users_total = (int) $users_count['total_users'];
        }

        $data = [
            'posts'    => $posts_total,
            'pages'    => $pages_total,
            'comments' => $comments_total,
            'users'    => $users_total,
        ];

        // Optional WooCommerce stats
        if (yooadmin_wc_active()) {
            // Orders (best-effort)
            $orders_total = 0;
            if (function_exists('wc_orders_count')) {
                // Available in newer WooCommerce
                $orders_total = (int) wc_orders_count('any');
            } elseif (class_exists('WC_Order_Query')) {
                // Fallback (can be heavy on huge stores; still okay for dashboard)
                $q = new WC_Order_Query([
                    'limit'  => 1,
                    'return' => 'ids',
                    'paginate' => true,
                    'status' => array_keys(wc_get_order_statuses()),
                ]);
                $r = $q->get_orders();
                if (is_array($r) && isset($r['total'])) {
                    $orders_total = (int) $r['total'];
                }
            }

            // Products
            $products_total = 0;
            $p_counts = wp_count_posts('product');
            if ($p_counts && isset($p_counts->publish)) {
                $products_total = (int) $p_counts->publish;
            }

            $data['wc'] = [
                'orders'   => $orders_total,
                'products' => $products_total,
            ];
        }

        return $data;
    }
}

/* ----------------------------------------------------------------------------
 * ACTIVE PLUGINS DATA (no HTML)
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_get_active_plugins_data')) {
    /**
     * List active plugins (including MU) with safe labels and generic icons.
     *
     * @return array<int, array{slug:string,label:string,url:string,icon:string}>
     */
    function yooadmin_get_active_plugins_data() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins      = (array) get_plugins();
        $active       = (array) get_option('active_plugins', []);
        $network_wide = is_multisite()
            ? array_map('strval', array_keys((array) get_site_option('active_sitewide_plugins', [])))
            : [];

        $items = [];

        // Standard active plugins
        foreach ($plugins as $file => $data) {
            $is_active = in_array($file, $active, true) || in_array($file, $network_wide, true);
            if (!$is_active) continue;

            $label = isset($data['Name']) ? (string) $data['Name'] : (string) $file;
            $items[] = [
                'slug'  => (string) $file,
                'label' => wp_strip_all_tags($label),
                'url'   => admin_url('plugins.php'),
                'icon'  => 'dashicons-admin-plugins',
            ];
        }

        // MU-plugins (always loaded)
        if (function_exists('get_mu_plugins')) {
            $mu = (array) get_mu_plugins();
            foreach ($mu as $file => $data) {
                $label = isset($data['Name']) ? (string) $data['Name'] : (string) $file;
                $items[] = [
                    'slug'  => (string) $file,
                    'label' => wp_strip_all_tags($label),
                    'url'   => admin_url('plugins.php'),
                    'icon'  => 'dashicons-shield',
                ];
            }
        }

        return $items;
    }
}

/* ----------------------------------------------------------------------------
 * QUICK LINKS (filterable)
 * ---------------------------------------------------------------------------- */

if (!function_exists('yooadmin_get_quick_links')) {
    /**
     * Provide quick admin links (filterable).
     *
     * @return array<int, array{label:string,url:string,icon:string}>
     */
    function yooadmin_get_quick_links() {
        $links = [
            [
                'label' => __('Add New Post', 'yooadmin'),
                'url'   => admin_url('post-new.php'),
                'icon'  => 'dashicons-edit',
            ],
            [
                'label' => __('Add New Page', 'yooadmin'),
                'url'   => admin_url('post-new.php?post_type=page'),
                'icon'  => 'dashicons-welcome-add-page',
            ],
            [
                'label' => __('Media Library', 'yooadmin'),
                'url'   => admin_url('upload.php'),
                'icon'  => 'dashicons-images-alt2',
            ],
            [
                'label' => __('Plugins', 'yooadmin'),
                'url'   => admin_url('plugins.php'),
                'icon'  => 'dashicons-admin-plugins',
            ],
        ];

        if (yooadmin_wc_active()) {
            $links[] = [
                'label' => __('Orders', 'yooadmin'),
                'url'   => admin_url('edit.php?post_type=shop_order'),
                'icon'  => 'dashicons-cart',
            ];
            $links[] = [
                'label' => __('Products', 'yooadmin'),
                'url'   => admin_url('edit.php?post_type=product'),
                'icon'  => 'dashicons-products',
            ];
        }

        /**
         * Filter: yooadmin_dashboard_quick_links
         * Allows third-parties to add/remove dashboard quick links.
         *
         * @param array $links
         */
        return (array) apply_filters('yooadmin_dashboard_quick_links', $links);
    }
}
