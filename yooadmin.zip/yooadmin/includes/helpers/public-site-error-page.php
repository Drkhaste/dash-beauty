<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_public_site_error_resolve_effective_color_mode')) {
    /**
     * Public branded error pages always use dark appearance.
     *
     * @return string dark
     */
    function yooadmin_public_site_error_resolve_effective_color_mode(): string
    {
        return 'dark';
    }
}

if (!function_exists('yooadmin_public_site_error_print_inline_vars')) {
    function yooadmin_public_site_error_print_inline_vars(): void
    {
        if (function_exists('yooadmin_branded_public_print_theme_vars')) {
            yooadmin_branded_public_print_theme_vars('yooadmin-public-error-vars');
        }
        if (function_exists('yooadmin_maintenance_print_overlay_css_vars')) {
            yooadmin_maintenance_print_overlay_css_vars();
        }
    }
}

if (!function_exists('yooadmin_public_site_error_is_admin_login_http_request')) {
    function yooadmin_public_site_error_is_admin_login_http_request(): bool
    {
        if (defined('WP_ADMIN') && WP_ADMIN) {
            return true;
        }

        global $pagenow;
        if (isset($pagenow) && $pagenow === 'wp-login.php') {
            return true;
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Path match only.
        $req  = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
        $path = wp_parse_url(sanitize_text_field((string) $req), PHP_URL_PATH);

        if (!is_string($path) || $path === '') {
            return false;
        }

        return (bool) preg_match('#/(wp-admin|wp-login\.php)(/|$)#i', $path);
    }
}

if (!function_exists('yooadmin_public_site_error_output_template')) {
    /**
     * Front-end branded error template (site-not-found.php), never maintenance or wp_die admin UI.
     *
     * @param string $title   Page title.
     * @param string $message Body message.
     * @param int    $status  HTTP status code.
     */
    function yooadmin_public_site_error_output_template(string $title, string $message, int $status = 404): void
    {
        status_header($status);
        nocache_headers();

        if (!headers_sent()) {
            header('X-Robots-Tag: noindex, nofollow', true);
        }

        $GLOBALS['yooadmin_public_site_error_title']   = $title;
        $GLOBALS['yooadmin_public_site_error_message'] = $message;

        if (!defined('YOOADMIN_DIR')) {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Minimal output without admin chrome.
            echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . esc_html($title) . '</title></head><body><h1>'
                . esc_html($title) . '</h1><p>' . esc_html($message) . '</p></body></html>';
            exit;
        }

        $tpl = YOOADMIN_DIR . 'templates/public/site-not-found.php';
        if (!is_readable($tpl)) {
            echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . esc_html($title) . '</title></head><body><h1>'
                . esc_html($title) . '</h1><p>' . esc_html($message) . '</p></body></html>';
            exit;
        }

        require $tpl;
        exit;
    }
}

if (!function_exists('yooadmin_public_site_error_render')) {
    /**
     * @param string $title   Page title.
     * @param string $message Body message.
     * @param int    $status  HTTP status code.
     */
    function yooadmin_public_site_error_render(string $title, string $message, int $status = 404): void
    {
        if (yooadmin_public_site_error_is_admin_login_http_request()) {
            yooadmin_public_site_error_output_template($title, $message, $status);
        }

        global $wp_query;

        if ($wp_query instanceof WP_Query && $status === 404) {
            $wp_query->set_404();
        }

        add_filter('redirect_canonical', '__return_false', 100);

        yooadmin_public_site_error_output_template($title, $message, $status);
    }
}

if (!function_exists('yooadmin_public_site_fetch_frontend_404_html')) {
    /**
     * Active theme 404 as rendered on the public front end (works with any theme).
     *
     * @return string HTML or empty string on failure.
     */
    function yooadmin_public_site_fetch_frontend_404_html(): string
    {
        $probe = 'yooadmin-404-probe-' . wp_generate_password(12, false, false);
        $url   = home_url('/' . $probe . '/');

        $headers = [];
        if (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $headers['Accept-Language'] = sanitize_text_field(wp_unslash((string) $_SERVER['HTTP_ACCEPT_LANGUAGE']));
        }

        $response = wp_remote_get(
            $url,
            [
                'timeout'     => 15,
                'redirection' => 0,
                'headers'     => $headers,
            ]
        );

        if (is_wp_error($response)) {
            return '';
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);

        if ($code !== 404 || $body === '') {
            return '';
        }

        return $body;
    }
}

if (!function_exists('yooadmin_public_site_render_theme_404')) {
    /**
     * Respond with the active theme's front-end 404 (blocked wp-admin / wp-login decoy).
     */
    function yooadmin_public_site_render_theme_404(): void
    {
        status_header(404);
        nocache_headers();

        if (!headers_sent()) {
            header('X-Robots-Tag: noindex, nofollow', true);
        }

        add_filter('show_admin_bar', '__return_false', 999);
        add_filter('redirect_canonical', '__return_false', 100);

        $html = yooadmin_public_site_fetch_frontend_404_html();

        if ($html === '') {
            if (function_exists('yooadmin_public_site_error_render_404')) {
                yooadmin_public_site_error_render_404();
            }

            status_header(404);
            nocache_headers();
            exit;
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Active theme front-end markup.
        echo $html;
        exit;
    }
}

if (!function_exists('yooadmin_public_site_error_render_404')) {
    function yooadmin_public_site_error_render_404(): void
    {
        yooadmin_public_site_error_render(
            __('Page not found', 'yooadmin'),
            __('The page you requested could not be found.', 'yooadmin'),
            404
        );
    }
}
