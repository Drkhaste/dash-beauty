<?php
/**
 * List screen Screen Options — YOOAdmin button + modal (comments, posts, users…).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_list_screen_options_modal_is_list_screen')) {
    /**
     * @return bool
     */
    function yooadmin_list_screen_options_modal_is_list_screen(): bool
    {
        if (!function_exists('get_current_screen')) {
            return false;
        }

        $screen = get_current_screen();
        if (!$screen || empty($screen->base)) {
            return false;
        }

        $bases = ['edit', 'upload', 'edit-comments', 'edit-tags', 'users', 'plugins', 'themes'];
        foreach ($bases as $base) {
            if (strpos((string) $screen->base, $base) !== false) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('yooadmin_list_screen_options_modal_active')) {
    function yooadmin_list_screen_options_modal_active(): bool
    {
        if (!is_admin() || !function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return false;
        }

        return yooadmin_list_screen_options_modal_is_list_screen();
    }
}

if (!function_exists('yooadmin_enqueue_list_screen_options_modal_assets')) {
    function yooadmin_enqueue_list_screen_options_modal_assets(): void
    {
        if (!yooadmin_list_screen_options_modal_active()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir  = plugin_dir_path($base_file);
        $base_url  = plugin_dir_url($base_file);

        $css_rel = 'assets/css/admin/list-screen-options-modal.css';
        $css_abs = $base_dir . $css_rel;
        if (is_readable($css_abs)) {
            $deps = wp_style_is('yooadmin-list-screens', 'registered') || wp_style_is('yooadmin-list-screens', 'enqueued')
                ? ['yooadmin-list-screens']
                : ['yooadmin-core'];
            wp_enqueue_style(
                'yooadmin-list-screen-options-modal',
                $base_url . $css_rel,
                $deps,
                (string) filemtime($css_abs)
            );
        }

        $js_rel = 'assets/js/admin/list-screen-options-modal.js';
        $js_abs = $base_dir . $js_rel;
        if (!is_readable($js_abs)) {
            return;
        }

        wp_enqueue_script(
            'yooadmin-list-screen-options-modal',
            $base_url . $js_rel,
            [],
            (string) filemtime($js_abs),
            true
        );

        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $title  = __('Screen Options', 'yooadmin');
        if ($screen && !empty($screen->post_type) && $screen->post_type === 'page') {
            $title = __('Pages display', 'yooadmin');
        } elseif ($screen && !empty($screen->id) && $screen->id === 'edit-comments') {
            $title = __('Comments display', 'yooadmin');
        }

        wp_localize_script(
            'yooadmin-list-screen-options-modal',
            'yooadminListScreenOptions',
            [
                'title' => $title,
                'i18n'  => [
                    'button'      => __('Screen Options', 'yooadmin'),
                    'eyebrow'     => __('Display', 'yooadmin'),
                    'description' => __('Choose which columns and layout options appear on this screen. Changes are saved when you apply.', 'yooadmin'),
                    'apply'       => __('Apply', 'yooadmin'),
                    'done'        => __('Done', 'yooadmin'),
                    'close'       => __('Close', 'yooadmin'),
                    'empty'       => __('No display options were found for this screen.', 'yooadmin'),
                    'hint'        => __('Use these toggles instead of the native Screen Options panel.', 'yooadmin'),
                    'perPage'     => __('Number of items per page:', 'yooadmin'),
                ],
            ]
        );
    }
}

add_action('admin_enqueue_scripts', 'yooadmin_enqueue_list_screen_options_modal_assets', 35);
