<?php
/**
 * YOOAdmin - Categories page (admin list)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

class YOOAdmin_Categories_Page
{

    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('admin_menu', [$this, 'register_page']);
        add_action('admin_init', [$this, 'maybe_redirect']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_yooadmin_categories_action', [$this, 'handle_ajax_action']);
        add_action('wp_ajax_yooadmin_bulk_categories_action', [$this, 'handle_bulk_action']);
        add_action('wp_ajax_yooadmin_filter_categories', [$this, 'ajax_filter_categories']);
        add_action('wp_ajax_yooadmin_add_category', [$this, 'ajax_add_category']);
    }

    /**
     * Register hidden submenu page
     */
    public function register_page()
    {
        $hook = add_submenu_page(
            '', // Hidden from menu
            'Categories',
            'Categories',
            'manage_categories',
            'yooadmin-categories',
        [$this, 'render_page']
        );
        if ($hook) {
            add_action("load-{$hook}", function () {
                global $title;
                $title = __('Categories', 'yooadmin');

                $opts = (array)get_option('yooadmin_options', []);
                $enabled = !empty($opts['categories_redirect']);
                if (!$enabled) {
                    wp_safe_redirect(admin_url('edit-tags.php?taxonomy=category'));
                    exit;
                }
            });
        }
    }

    /**
     * Enqueue assets for categories page
     */
    public function enqueue_assets($hook)
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page detection.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== 'yooadmin-categories') {
            return;
        }

        // Set global $title BEFORE admin-header.php loads
        global $title;
        $title = 'Categories';

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir = plugin_dir_path($base_file);
        $base_url = plugin_dir_url($base_file);

        // Enqueue styles
        $style_rel = 'assets/css/admin/categories-page.css';
        $style_abs = $base_dir . $style_rel;
        if (file_exists($style_abs)) {
            wp_enqueue_style('yooadmin-categories', $base_url . $style_rel, ['yooadmin-shell'], filemtime($style_abs));
        }

        // Enqueue scripts
        $script_rel = 'assets/js/admin/categories-page.js';
        $script_abs = $base_dir . $script_rel;
        if (file_exists($script_abs)) {
            wp_enqueue_script('yooadmin-categories', $base_url . $script_rel, ['jquery'], filemtime($script_abs), true);
            wp_localize_script('yooadmin-categories', 'yooadmCategories', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('yooadmin_categories'),
                'i18n' => [
                    'deleteConfirm' => __('Are you sure you want to delete this category? Posts in this category will not be deleted, but will be moved to the default category.', 'yooadmin'),
                    'selected' => __('selected', 'yooadmin'),
                    'success' => __('Operation completed successfully.', 'yooadmin'),
                    'error' => __('An error occurred. Please try again.', 'yooadmin'),
                ],
            ]);
        }
    }

    /**
     * Redirect from default edit-tags.php?taxonomy=category to our page if YOOAdmin layout is enabled
     */
    public function maybe_redirect()
    {
        global $pagenow;

        if ($pagenow !== 'edit-tags.php') {
            return;
        }

        // Only redirect for categories
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only taxonomy check.
        $taxonomy = isset($_GET['taxonomy']) ? sanitize_key(wp_unslash($_GET['taxonomy'])) : '';
        if ($taxonomy !== 'category') {
            return;
        }

        // Check if already on our page
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page check for redirect.
        if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'yooadmin-categories') {
            return;
        }

        // Check settings
        $opts = (array)get_option('yooadmin_options', []);
        $categories_redirect = array_key_exists('categories_redirect', $opts)
            ? (!empty($opts['categories_redirect']) ? 1 : 0)
            : 1;

        // Check Focus Mode policy
        if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return;
        }

        // Don't redirect if disabled
        if (!$categories_redirect) {
            return;
        }

        // Build redirect URL
        $redirect = admin_url('admin.php?page=yooadmin-categories');

        // Preserve query parameters
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Preserving read-only GET filter for redirect; no state change.
        if (!empty($_GET['s'])) {
            $redirect = add_query_arg('s', sanitize_text_field(wp_unslash($_GET['s'])), $redirect);
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        wp_safe_redirect($redirect);
        exit;
    }

    /**
     * Handle AJAX category actions (delete, etc.)
     */
    public function handle_ajax_action()
    {
        check_ajax_referer('yooadmin_categories', 'nonce');

        if (!current_user_can('manage_categories')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $action = isset($_POST['category_action']) ? sanitize_key((string)$_POST['category_action']) : '';
        $category_id = isset($_POST['category_id']) ? absint($_POST['category_id']) : 0;

        if (empty($action) || !$category_id) {
            wp_send_json_error(['message' => __('Missing required parameters.', 'yooadmin')]);
        }

        $category = get_category($category_id);
        if (!$category) {
            wp_send_json_error(['message' => __('Category not found.', 'yooadmin')]);
        }

        $message = '';

        switch ($action) {
            case 'delete':
                // Get default category
                $default_cat = get_option('default_category');

                // Don't allow deleting default category
                if ((int)$category_id === (int)$default_cat) {
                    wp_send_json_error(['message' => __('You cannot delete the default category.', 'yooadmin')]);
                }

                wp_delete_category($category_id);
                $message = __('Category deleted.', 'yooadmin');
                break;

            default:
                wp_send_json_error(['message' => __('Invalid action.', 'yooadmin')]);
        }

        wp_send_json_success(['message' => $message]);
    }

    /**
     * Handle bulk actions via AJAX
     */
    public function handle_bulk_action()
    {
        check_ajax_referer('yooadmin_categories', 'nonce');

        if (!current_user_can('manage_categories')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $categories = isset($_POST['categories']) ? array_map('absint', (array)$_POST['categories']) : [];
        $action = isset($_POST['bulk_action']) ? sanitize_key((string)$_POST['bulk_action']) : '';

        if (empty($categories) || empty($action)) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'yooadmin')]);
        }

        $processed = 0;
        $errors = [];
        $default_cat = get_option('default_category');

        foreach ($categories as $category_id) {
            $category = get_category($category_id);
            if (!$category) {
                continue;
            }

            switch ($action) {
                case 'delete':
                    // Don't allow deleting default category
                    if ((int)$category_id === (int)$default_cat) {
                        // translators: %s: category name
                        $errors[] = sprintf(__('Cannot delete default category: %s.', 'yooadmin'), $category->name);
                        continue 2;
                    }

                    wp_delete_category($category_id);
                    $processed++;
                    break;
            }
        }

        if ($processed > 0) {
            // translators: %d: number of categories processed
            $message = sprintf(_n('%d category processed.', '%d categories processed.', $processed, 'yooadmin'), $processed);
            if (!empty($errors)) {
                $message .= ' ' . implode(' ', $errors);
            }
            wp_send_json_success(['message' => $message]);
        }
        else {
            $error_message = !empty($errors) ? implode(' ', $errors) : __('No categories were processed.', 'yooadmin');
            wp_send_json_error(['message' => $error_message]);
        }
    }

    /**
     * AJAX handler for filtering categories
     */
    public function ajax_filter_categories()
    {
        check_ajax_referer('yooadmin_categories', 'nonce');

        if (!current_user_can('manage_categories')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified via check_ajax_referer above.
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';

        $args = [
            'taxonomy' => 'category',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ];

        if ($search) {
            $args['search'] = $search;
        }

        $categories = get_categories($args);

        // Render categories HTML
        ob_start();
        if (!empty($categories)) {
            echo '<div class="yoo-categories-grid">';
            foreach ($categories as $category) {
                $this->render_category_card($category);
            }
            echo '</div>';
        }
        else {
            echo '<div class="yoo-categories-empty">';
            echo '<div class="yoo-empty-illustration"><span class="dashicons dashicons-category"></span></div>';
            echo '<h2>' . esc_html__('No categories found', 'yooadmin') . '</h2>';
            echo '<p>' . esc_html__('Try adjusting your search criteria.', 'yooadmin') . '</p>';
            echo '</div>';
        }
        $html = ob_get_clean();

        wp_send_json_success([
            'html' => $html,
            'total' => count($categories),
        ]);
    }

    /**
     * Render category card
     */
    private function render_category_card($category)
    {
        $edit_url = get_edit_term_link($category->term_id, 'category');
        $view_url = get_category_link($category->term_id);
        $posts_count = (int)$category->count;
        $default_cat = get_option('default_category');
        $is_default = ((int)$category->term_id === (int)$default_cat);

?>
        <article class="yoo-category-card" data-category-id="<?php echo esc_attr($category->term_id); ?>">
            <input type="checkbox" class="yoo-category-checkbox" value="<?php echo esc_attr($category->term_id); ?>" id="category-<?php echo esc_attr($category->term_id); ?>" <?php echo $is_default ? 'disabled' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static string. ?>>
            <label for="category-<?php echo esc_attr($category->term_id); ?>" class="yoo-category-checkbox-label"></label>
            
            <div class="yoo-category-content">
                <header class="yoo-category-header">
                    <h2 class="yoo-category-name">
                        <a href="<?php echo esc_url($edit_url); ?>">
                            <?php echo esc_html($category->name); ?>
                        </a>
                    </h2>
                    <?php if ($is_default): ?>
                    <span class="yoo-category-badge yoo-category-badge--default">
                        <?php esc_html_e('Default', 'yooadmin'); ?>
                    </span>
                    <?php
        endif; ?>
                </header>
                
                <?php if (!empty($category->description)): ?>
                <p class="yoo-category-description">
                    <?php echo esc_html(wp_trim_words($category->description, 20)); ?>
                </p>
                <?php
        endif; ?>
                
                <div class="yoo-category-meta">
                    <div class="yoo-category-meta-item">
                        <span class="dashicons dashicons-admin-post"></span>
                        <span><?php
        // translators: %d: number of posts
        printf(esc_html(_n('%d post', '%d posts', $posts_count, 'yooadmin')), (int)$posts_count); ?></span>
                    </div>
                    <?php if ($category->parent):
            $parent = get_category($category->parent);
?>
                    <div class="yoo-category-meta-item">
                        <span class="dashicons dashicons-networking"></span>
                        <span><?php echo esc_html($parent ? $parent->name : __('Unknown', 'yooadmin')); ?></span>
                    </div>
                    <?php
        endif; ?>
                    <div class="yoo-category-meta-item">
                        <span class="dashicons dashicons-tag"></span>
                        <span><?php echo esc_html($category->slug); ?></span>
                    </div>
                </div>
                
                <div class="yoo-category-actions">
                    <a href="<?php echo esc_url($view_url); ?>" target="_blank" class="yoo-action-btn">
                        <span class="dashicons dashicons-visibility"></span>
                        <?php esc_html_e('View', 'yooadmin'); ?>
                    </a>
                    <a href="<?php echo esc_url($edit_url); ?>" class="yoo-action-btn">
                        <span class="dashicons dashicons-edit"></span>
                        <?php esc_html_e('Edit', 'yooadmin'); ?>
                    </a>
                    <?php if (!$is_default): ?>
                    <button class="yoo-action-btn danger delete" data-category-id="<?php echo esc_attr($category->term_id); ?>" data-category-name="<?php echo esc_attr($category->name); ?>">
                        <span class="dashicons dashicons-trash"></span>
                        <?php esc_html_e('Delete', 'yooadmin'); ?>
                    </button>
                    <?php
        endif; ?>
                </div>
            </div>
        </article>
        <?php
    }

    /**
     * Render the categories page
     */
    public function render_page()
    {
        if (!current_user_can('manage_categories')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'yooadmin'));
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search from URL.
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';

        $args = [
            'taxonomy' => 'category',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ];

        if ($search) {
            $args['search'] = $search;
        }

        $categories = get_categories($args);

        // Get stats
        $total_count = count($categories);
        $empty_count = 0;
        $default_cat = get_option('default_category');

        foreach ($categories as $cat) {
            if ($cat->count === 0) {
                $empty_count++;
            }
        }

        $template = plugin_dir_path(yooadmin_base_file()) . 'templates/yoopixel/admin/pages/categories/index.php';
        if (file_exists($template)) {
            include $template;
            return;
        }

        // Fallback render
        echo '<div class="wrap"><h1>' . esc_html__('Categories', 'yooadmin') . '</h1>';
        if (!empty($categories)) {
            echo '<ul>';
            foreach ($categories as $category) {
                printf('<li><a href="%s">%s</a> (%d)</li>',
                    esc_url(get_edit_term_link($category->term_id, 'category')),
                    esc_html($category->name),
                    (int)$category->count
                );
            }
            echo '</ul>';
        }
        else {
            esc_html_e('No categories found.', 'yooadmin');
        }
        echo '</div>';
    }

    /**
     * Handle add category via AJAX
     */
    public function ajax_add_category()
    {
        check_ajax_referer('yooadmin_categories', 'nonce');

        if (!current_user_can('manage_categories')) {
            wp_send_json_error(['message' => __('You do not have permission to add categories.', 'yooadmin')]);
        }

        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $slug = isset($_POST['slug']) ? sanitize_title(wp_unslash($_POST['slug'])) : '';
        $parent = isset($_POST['parent']) ? absint($_POST['parent']) : 0;
        $description = isset($_POST['description']) ? sanitize_textarea_field(wp_unslash($_POST['description'])) : '';

        if (empty($name)) {
            wp_send_json_error(['message' => __('Category name is required.', 'yooadmin')]);
        }

        $args = [
            'cat_name' => $name,
            'category_description' => $description,
            'category_parent' => $parent,
        ];

        if (!empty($slug)) {
            $args['category_nicename'] = $slug;
        }

        $result = wp_insert_category($args);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success([
            'message' => __('Category added successfully!', 'yooadmin'),
            'category_id' => $result
        ]);
    }
}

// Initialize
YOOAdmin_Categories_Page::get_instance();
