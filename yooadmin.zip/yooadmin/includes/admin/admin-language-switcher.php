<?php
/**
 * Per-user admin language switcher in the breadcrumbs bar.
 *
 * Uses WordPress user locale (user meta) — does not change site WPLANG.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Distinct locale codes the user can pick (installed packs + site locale + English).
 *
 * English is always available in wp-admin even without a language pack, matching
 * the WordPress profile "Language" dropdown.
 *
 * @return string[]
 */
function yooadmin_get_site_admin_language_locales(): array {
    $installed = get_available_languages();
    if (!is_array($installed)) {
        $installed = [];
    }

    $site_locale = get_locale();
    if (!is_string($site_locale) || $site_locale === '') {
        $site_locale = 'en_US';
    }

    $locales = array_unique(array_merge(['en_US'], $installed, [$site_locale]));
    $normalized = [];

    foreach ($locales as $locale) {
        $locale = yooadmin_sanitize_locale_name((string) $locale);
        if ($locale !== '') {
            $normalized[] = $locale;
        }
    }

    /**
     * Filter the locale codes considered available for the breadcrumbs language switcher.
     *
     * @param string[] $normalized Sanitized locale codes.
     */
    return array_values(array_unique(apply_filters('yooadmin_admin_language_locales', $normalized)));
}

/**
 * Whether the breadcrumbs language switcher should render.
 */
function yooadmin_should_show_admin_language_switcher(): bool {
    if (!is_user_logged_in() || !is_admin()) {
        return false;
    }

    if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
        return false;
    }

    $locales = yooadmin_get_site_admin_language_locales();

    /**
     * Filter whether the admin language switcher is shown.
     *
     * @param bool     $show    Default: true when two or more locales exist.
     * @param string[] $locales Available locale codes.
     */
    return (bool) apply_filters('yooadmin_show_admin_language_switcher', count($locales) > 1, $locales);
}

/**
 * Selected value for wp_dropdown_languages() (matches user profile screen).
 */
function yooadmin_get_admin_language_switcher_selected(): string {
    $user = wp_get_current_user();
    if (!$user || !$user->ID) {
        return 'site-default';
    }

    $languages   = get_available_languages();
    $user_locale = (string) $user->locale;

    if ($user_locale === 'en_US') {
        return '';
    }

    if ($user_locale === '' || !in_array($user_locale, $languages, true)) {
        return 'site-default';
    }

    return $user_locale;
}

/**
 * Sanitize a submitted locale for the current user (installed packs only).
 */
function yooadmin_sanitize_user_admin_locale_submission(string $locale): string {
    if ($locale === 'site-default') {
        return '';
    }

    if ($locale === '') {
        return 'en_US';
    }

    $locale = yooadmin_sanitize_locale_name($locale);
    if ($locale === '') {
        return '';
    }

    if (in_array($locale, get_available_languages(), true)) {
        return $locale;
    }

    if ($locale === 'en_US') {
        return 'en_US';
    }

    return '';
}

/**
 * Menu options for the breadcrumbs language switcher (matches profile screen).
 *
 * @return array<int, array{value: string, label: string}>
 */
function yooadmin_get_admin_language_switcher_options(): array {
    $installed = get_available_languages();
    if (!is_array($installed)) {
        $installed = [];
    }

    if (!function_exists('wp_get_available_translations')) {
        require_once ABSPATH . 'wp-admin/includes/translation-install.php';
    }

    $translations = wp_get_available_translations();
    $options      = [
        [
            'value' => 'site-default',
            'label' => _x('Site Default', 'default site language', 'yooadmin'),
        ],
        [
            'value' => '',
            'label' => 'English (United States)',
        ],
    ];

    foreach ($installed as $locale) {
        $label = $locale;
        if (isset($translations[$locale]['native_name'])) {
            $label = (string) $translations[$locale]['native_name'];
        }

        $options[] = [
            'value' => $locale,
            'label' => $label,
        ];
    }

    /**
     * Filter language switcher menu options.
     *
     * @param array<int, array{value: string, label: string}> $options Menu rows.
     */
    return apply_filters('yooadmin_admin_language_switcher_options', $options);
}

/**
 * Render the breadcrumbs language switcher markup.
 */
function yooadmin_render_breadcrumbs_language_switcher(): void {
    if (!yooadmin_should_show_admin_language_switcher()) {
        return;
    }

    $options  = yooadmin_get_admin_language_switcher_options();
    $selected = yooadmin_get_admin_language_switcher_selected();
    $menu_id  = 'yooadmin-lang-menu';

    if ($options === []) {
        return;
    }

    ?>
    <div class="yp-breadcrumbs-lang" data-yooadmin-lang-switcher>
        <button type="button"
                class="yp-breadcrumbs-lang__toggle"
                aria-expanded="false"
                aria-haspopup="true"
                aria-controls="<?php echo esc_attr($menu_id); ?>"
                title="<?php esc_attr_e('Admin language', 'yooadmin'); ?>">
            <span class="yp-breadcrumbs-lang__icon dashicons dashicons-translation" aria-hidden="true"></span>
            <span class="screen-reader-text"><?php esc_html_e('Admin language', 'yooadmin'); ?></span>
        </button>
        <div class="yp-breadcrumbs-lang__menu"
             id="<?php echo esc_attr($menu_id); ?>"
             role="menu"
             aria-label="<?php esc_attr_e('Choose admin language', 'yooadmin'); ?>"
             hidden>
            <?php foreach ($options as $option) : ?>
                <?php
                $value   = (string) $option['value'];
                $label   = (string) $option['label'];
                $is_active = $selected === $value;
                $option_lang = yooadmin_get_admin_language_option_lang($value);
                ?>
                <button type="button"
                        class="yp-breadcrumbs-lang__option<?php echo $is_active ? ' is-active' : ''; ?>"
                        role="menuitem"
                        lang="<?php echo esc_attr($option_lang); ?>"
                        data-yooadmin-locale="<?php echo esc_attr($value); ?>"
                        aria-current="<?php echo $is_active ? 'true' : 'false'; ?>">
                    <?php echo esc_html($label); ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}

/**
 * Enqueue switcher assets when visible.
 */
function yooadmin_enqueue_admin_language_switcher_assets(): void {
    if (!yooadmin_should_show_admin_language_switcher()) {
        return;
    }

    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $base_dir  = plugin_dir_path($base_file);
    $base_url  = plugin_dir_url($base_file);

    $css_rel = 'assets/css/admin/yp-admin-language-switcher.css';
    $css_abs = $base_dir . $css_rel;
    if (is_readable($css_abs)) {
        $deps = wp_style_is('yooadmin-core', 'registered') || wp_style_is('yooadmin-core', 'enqueued')
            ? ['yooadmin-core']
            : [];

        if (yooadmin_should_enqueue_tajawal_font()) {
            if (!wp_style_is('yooadmin-tajawal', 'registered') && !wp_style_is('yooadmin-tajawal', 'enqueued')) {
                $tajawal_rel = 'assets/fonts/tajawal.css';
                $tajawal_abs = $base_dir . $tajawal_rel;
                if (is_readable($tajawal_abs)) {
                    wp_enqueue_style(
                        'yooadmin-tajawal',
                        $base_url . $tajawal_rel,
                        [],
                        (string) filemtime($tajawal_abs)
                    );
                }
            }
            $deps[] = 'yooadmin-tajawal';
        }

        wp_enqueue_style(
            'yooadmin-admin-language-switcher',
            $base_url . $css_rel,
            $deps,
            (string) filemtime($css_abs)
        );
    }

    $js_rel = 'assets/js/admin/yp-admin-language-switcher.js';
    $js_abs = $base_dir . $js_rel;
    if (!is_readable($js_abs)) {
        return;
    }

    wp_enqueue_script(
        'yooadmin-admin-language-switcher',
        $base_url . $js_rel,
        [],
        (string) filemtime($js_abs),
        true
    );

    wp_localize_script(
        'yooadmin-admin-language-switcher',
        'yooadminLangSwitcher',
        [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('yooadmin_user_locale'),
            'strings' => [
                'error' => __('Could not save your language preference. Please try again.', 'yooadmin'),
            ],
        ]
    );
}
add_action('admin_enqueue_scripts', 'yooadmin_enqueue_admin_language_switcher_assets', 25);

/**
 * AJAX: save the current user's admin locale preference.
 */
function yooadmin_ajax_set_user_locale(): void {
    check_ajax_referer('yooadmin_user_locale', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 401);
    }

    $raw = isset($_POST['locale']) ? sanitize_text_field(wp_unslash((string) $_POST['locale'])) : '';
    $locale = yooadmin_sanitize_user_admin_locale_submission($raw);

    if ($raw !== 'site-default' && $raw !== '' && $locale === '' && $raw !== 'en_US') {
        wp_send_json_error(['message' => __('Invalid language selection.', 'yooadmin')], 400);
    }

    $user_id = get_current_user_id();
    $updated = wp_update_user(
        [
            'ID'     => $user_id,
            'locale' => $locale,
        ]
    );

    if (is_wp_error($updated)) {
        wp_send_json_error(['message' => $updated->get_error_message()], 500);
    }

    wp_send_json_success(
        [
            'locale' => $locale,
        ]
    );
}
add_action('wp_ajax_yooadmin_set_user_locale', 'yooadmin_ajax_set_user_locale');
