<?php
/**
 * WordPress.org review request modal (split layout, light/dark).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Thanks users and asks for a wordpress.org plugin review.
 */
final class YOOAdmin_Review_Popup {

    public const REVIEW_URL              = 'https://wordpress.org/plugins/yooadmin/';
    public const USER_META_PERMANENT     = 'yooadmin_review_popup_dismissed';
    public const USER_META_SNOOZE        = 'yooadmin_review_popup_snooze_until';
    public const USER_META_DISMISS_COUNT = 'yooadmin_review_popup_dismiss_count';
    public const AJAX_NONCE_ACTION       = 'yooadmin_review_popup';
    public const NOTIFICATION_META_ID    = 'yooadmin_review_request';
    public const USER_META_NOTIF_SUPPRESSED = 'yooadmin_review_notification_suppressed';
    private const DAYS_AFTER_WIZARD      = 7;
    private const SNOOZE_DAYS_FIRST      = 14;
    private const SNOOZE_DAYS_SECOND     = 30;
    private const DISMISS_COUNT_MAX      = 3;

    /**
     * Bootstrap hooks.
     */
    public static function init(): void {
        if (!is_admin()) {
            return;
        }

        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets'], 125);
        add_action('admin_footer', [__CLASS__, 'render_modal'], 8);
        add_action('wp_ajax_yooadmin_review_popup_remind_later', [__CLASS__, 'ajax_remind_later']);
        add_action('wp_ajax_yooadmin_review_popup_reviewed', [__CLASS__, 'ajax_reviewed']);
        add_action('wp_ajax_yooadmin_delete_notification', [__CLASS__, 'suppress_inbox_notification_on_delete'], 9);
    }

    /**
     * @return bool
     */
    public static function should_show(): bool {
        if (!current_user_can(self::required_capability())) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        if (!get_option('yooadmin_wizard_completed', false)) {
            return false;
        }

        if (!self::is_yooadmin_dashboard_screen()) {
            return false;
        }

        if (self::is_permanently_dismissed()) {
            return false;
        }

        if (self::is_snoozed()) {
            return false;
        }

        if (time() < self::eligible_timestamp()) {
            return false;
        }

        if (class_exists('YOOAdmin_Studio_Hub_Upgrade_Modal') && YOOAdmin_Studio_Hub_Upgrade_Modal::should_show()) {
            return false;
        }

        if (class_exists('YOOAdmin_Guided_Tour')) {
            if (YOOAdmin_Guided_Tour::should_show_intro() || YOOAdmin_Guided_Tour::is_tour_in_progress()) {
                return false;
            }
        }

        return (bool) apply_filters('yooadmin_review_popup_should_show', true);
    }

    /**
     * Earliest UNIX time the popup may appear.
     */
    private static function eligible_timestamp(): int {
        $date = get_option('yooadmin_wizard_completed_date', '');
        if (is_string($date) && $date !== '') {
            $ts = strtotime($date);
            if ($ts) {
                return $ts + (self::DAYS_AFTER_WIZARD * DAY_IN_SECONDS);
            }
        }

        $activated = get_option('yooadmin_activation_time', 0);
        if (is_numeric($activated) && (int) $activated > 0) {
            return (int) $activated + (self::DAYS_AFTER_WIZARD * DAY_IN_SECONDS);
        }

        return time() - DAY_IN_SECONDS;
    }

    /**
     * @return bool
     */
    private static function is_permanently_dismissed(): bool {
        return (bool) get_user_meta(get_current_user_id(), self::USER_META_PERMANENT, true);
    }

    /**
     * @return bool
     */
    private static function is_snoozed(): bool {
        $until = (int) get_user_meta(get_current_user_id(), self::USER_META_SNOOZE, true);
        return $until > time();
    }

    /**
     * @return bool
     */
    private static function is_yooadmin_dashboard_screen(): bool {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        return isset($_GET['page']) && 'yooadmin-dashboard' === sanitize_key(wp_unslash($_GET['page']));
    }

    /**
     * @param string $hook
     */
    public static function enqueue_assets($hook = ''): void {
        unset($hook);

        if (!self::should_show()) {
            return;
        }

        self::ensure_inbox_notification();

        $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
        $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);

        $css_rel       = 'assets/css/admin/welcome-popup.css';
        $css_review    = 'assets/css/admin/review-popup.css';
        $btn_css       = 'assets/css/admin/yp-yoo-buttons.css';
        $js_rel        = 'assets/js/admin/review-popup.js';

        if (is_readable($base_dir . $btn_css)) {
            wp_enqueue_style(
                'yooadmin-yoo-buttons',
                $base_url . $btn_css,
                [],
                (string) filemtime($base_dir . $btn_css)
            );
        }

        if (is_readable($base_dir . $css_rel)) {
            wp_enqueue_style('dashicons');
            $review_deps = is_readable($base_dir . $btn_css) ? ['yooadmin-yoo-buttons'] : [];
            wp_enqueue_style(
                'yooadmin-review-popup-base',
                $base_url . $css_rel,
                $review_deps,
                (string) filemtime($base_dir . $css_rel)
            );
            $review_deps[] = 'yooadmin-review-popup-base';
            if (is_readable($base_dir . $css_review)) {
                wp_enqueue_style(
                    'yooadmin-review-popup',
                    $base_url . $css_review,
                    $review_deps,
                    (string) filemtime($base_dir . $css_review)
                );
            }
        }

        if (is_readable($base_dir . $js_rel)) {
            if (function_exists('yooadmin_enqueue_yp_admin_toast_assets')) {
                yooadmin_enqueue_yp_admin_toast_assets();
            }

            $script_deps = ['jquery'];
            if (wp_script_is('yooadmin-yp-admin-toast', 'registered') || wp_script_is('yooadmin-yp-admin-toast', 'enqueued')) {
                $script_deps[] = 'yooadmin-yp-admin-toast';
            }

            wp_enqueue_script(
                'yooadmin-review-popup',
                $base_url . $js_rel,
                $script_deps,
                (string) filemtime($base_dir . $js_rel),
                true
            );

            wp_localize_script(
                'yooadmin-review-popup',
                'yooadminReviewPopup',
                [
                    'ajaxUrl'   => admin_url('admin-ajax.php'),
                    'nonce'     => wp_create_nonce(self::AJAX_NONCE_ACTION),
                    'reviewUrl' => self::REVIEW_URL,
                    'i18n'      => [
                        'remindError' => __('Could not save your reminder. Please try again.', 'yooadmin'),
                    ],
                ]
            );
        }
    }

    /**
     * Print modal markup in admin footer.
     */
    public static function render_modal(): void {
        if (!self::should_show()) {
            return;
        }

        $images_base = plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/';
        $image_light = $images_base . 'review-popup-promo.svg';
        $image_dark  = $images_base . 'review-popup-promo-dark.svg';
        $review_url  = self::REVIEW_URL;
        ?>
        <div id="yooadmin-review-popup" class="ywp-overlay ywp-overlay--review" hidden aria-hidden="true">
            <div class="ywp-dialog" role="dialog" aria-modal="true" aria-labelledby="ywp-review-title">
                <div class="ywp-layout">
                    <div class="ywp-copy">
                        <p class="ywp-eyebrow"><?php esc_html_e('YOOAdmin', 'yooadmin'); ?></p>
                        <h2 id="ywp-review-title" class="ywp-title">
                            <?php esc_html_e('Enjoying YOOAdmin?', 'yooadmin'); ?>
                        </h2>
                        <p class="ywp-lead">
                            <?php esc_html_e('Thank you for using YOOAdmin — we hope it makes your workspace better. If YOOAdmin improves your workflow, a quick review on WordPress.org helps support future development.', 'yooadmin'); ?>
                        </p>
                        <div class="ywp-actions">
                            <a href="<?php echo esc_url($review_url); ?>"
                               class="button button-primary yp-yoo-btn yp-yoo-btn--primary ywp-review-leave"
                               target="_blank"
                               rel="noopener noreferrer">
                                <?php esc_html_e('Leave a review', 'yooadmin'); ?>
                            </a>
                            <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft ywp-review-remind">
                                <?php esc_html_e('Remind me later', 'yooadmin'); ?>
                            </button>
                        </div>
                    </div>
                    <div class="ywp-visual" aria-hidden="true">
                        <div class="ywp-visual-controls">
                            <button type="button" class="ywp-close" aria-label="<?php echo esc_attr__('Close', 'yooadmin'); ?>">
                                <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                            </button>
                        </div>
                        <div class="ywp-visual-inner">
                            <img
                                class="ywp-image ywp-image--light"
                                src="<?php echo esc_url($image_light); ?>"
                                alt=""
                                width="280"
                                height="220"
                                loading="lazy"
                                decoding="async"
                            />
                            <img
                                class="ywp-image ywp-image--dark"
                                src="<?php echo esc_url($image_dark); ?>"
                                alt=""
                                width="280"
                                height="220"
                                loading="lazy"
                                decoding="async"
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Record a dismiss (X, overlay, or Remind me later): 14d → 30d → permanent.
     */
    public static function ajax_remind_later(): void {
        check_ajax_referer(self::AJAX_NONCE_ACTION, 'nonce');

        if (!current_user_can(self::required_capability())) {
            wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 403);
        }

        $user_id = get_current_user_id();
        $result  = self::record_dismiss($user_id);
        $result['toast_message'] = self::dismiss_toast_message($result);

        wp_send_json_success($result, 200);
    }

    /**
     * Toast copy after dismiss / remind later.
     *
     * @param array<string, mixed> $result Result from record_dismiss().
     */
    private static function dismiss_toast_message(array $result): string {
        if (!empty($result['permanent'])) {
            return __('Review prompt dismissed. We will not show it again.', 'yooadmin');
        }

        $days = isset($result['snooze_days']) ? (int) $result['snooze_days'] : self::SNOOZE_DAYS_FIRST;

        return sprintf(
            /* translators: %d: days until the review prompt may appear again. */
            __('Review reminder saved. We will ask again in %d days.', 'yooadmin'),
            $days
        );
    }

    /**
     * @param int $user_id User ID.
     * @return array{snoozed: bool, permanent?: bool, dismiss_count: int, snooze_days?: int}
     */
    private static function record_dismiss(int $user_id): array {
        $count = (int) get_user_meta($user_id, self::USER_META_DISMISS_COUNT, true);
        $count++;

        update_user_meta($user_id, self::USER_META_DISMISS_COUNT, $count);

        if ($count >= self::DISMISS_COUNT_MAX) {
            update_user_meta($user_id, self::USER_META_PERMANENT, 1);
            delete_user_meta($user_id, self::USER_META_SNOOZE);

            return [
                'snoozed'       => false,
                'permanent'     => true,
                'dismiss_count' => $count,
            ];
        }

        $snooze_days = self::SNOOZE_DAYS_FIRST;
        if ($count === 2) {
            $snooze_days = self::SNOOZE_DAYS_SECOND;
        }

        update_user_meta(
            $user_id,
            self::USER_META_SNOOZE,
            time() + ($snooze_days * DAY_IN_SECONDS)
        );

        return [
            'snoozed'       => true,
            'dismiss_count' => $count,
            'snooze_days'   => $snooze_days,
        ];
    }

    /**
     * Permanently dismiss after the user opens the review page.
     */
    public static function ajax_reviewed(): void {
        check_ajax_referer(self::AJAX_NONCE_ACTION, 'nonce');

        if (!current_user_can(self::required_capability())) {
            wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 403);
        }

        $user_id = get_current_user_id();
        update_user_meta($user_id, self::USER_META_PERMANENT, 1);
        update_user_meta($user_id, self::USER_META_DISMISS_COUNT, self::DISMISS_COUNT_MAX);
        delete_user_meta($user_id, self::USER_META_SNOOZE);

        wp_send_json_success(['dismissed' => true, 'permanent' => true], 200);
    }

    /**
     * Inbox notification (not a banner): same copy as the modal, with review link.
     * Created once when the modal is shown; if the user deletes it, it does not return.
     */
    public static function ensure_inbox_notification(): void {
        $user_id = get_current_user_id();
        if ($user_id <= 0 || get_user_meta($user_id, self::USER_META_NOTIF_SUPPRESSED, true)) {
            return;
        }

        if (self::user_has_review_inbox_notification($user_id)) {
            return;
        }

        if (!function_exists('yooadmin_get_integration')) {
            return;
        }

        $integration = yooadmin_get_integration();
        if (!$integration || !method_exists($integration, 'create_notification')) {
            return;
        }

        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $integration->create_notification(
            $user_id,
            [
                'type'        => 'info',
                'title'       => __('Enjoying YOOAdmin?', 'yooadmin'),
                'message'     => __(
                    'Thank you for using YOOAdmin — we hope it makes your workspace better. If YOOAdmin improves your workflow, a quick review on WordPress.org helps support future development.',
                    'yooadmin'
                ),
                'priority'    => 'high',
                'source'      => 'YOOAdmin',
                'source_type' => 'license',
                'sender'      => 'yooadmin_review',
                'url'         => self::REVIEW_URL,
                'icon'        => 'dashicons-star-filled',
                'group_id'    => 'yooadmin_review',
                'meta'        => [
                    'id'      => self::NOTIFICATION_META_ID,
                    'actions' => [
                        [
                            'type'   => 'primary',
                            'text'   => __('Leave a review', 'yooadmin'),
                            'url'    => self::REVIEW_URL,
                            'target' => '_blank',
                        ],
                    ],
                ],
            ]
        );
    }

    /**
     * Stop recreating the inbox item after the user deletes it.
     */
    public static function suppress_inbox_notification_on_delete(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Main handler verifies nonce at default priority.
        $notification_id = isset($_POST['notification_id']) ? (int) $_POST['notification_id'] : 0;
        $user_id         = get_current_user_id();

        if ($notification_id <= 0 || $user_id <= 0) {
            return;
        }

        if (!self::notification_row_is_review_request($user_id, $notification_id)) {
            return;
        }

        update_user_meta($user_id, self::USER_META_NOTIF_SUPPRESSED, 1);
    }

    /**
     * @param int $user_id User ID.
     */
    private static function user_has_review_inbox_notification(int $user_id): bool {
        if (!function_exists('yooadmin_get_integration')) {
            return false;
        }

        $integration = yooadmin_get_integration();
        if (!$integration || !method_exists($integration, 'get_notifications')) {
            return false;
        }

        $items = $integration->get_notifications(
            $user_id,
            [
                'limit' => 100,
            ]
        );

        if (!is_array($items)) {
            return false;
        }

        foreach ($items as $item) {
            if (self::row_meta_id($item) === self::NOTIFICATION_META_ID) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param int $user_id         User ID.
     * @param int $notification_id Notification row ID.
     */
    private static function notification_row_is_review_request(int $user_id, int $notification_id): bool {
        if (!function_exists('yooadmin_get_integration')) {
            return false;
        }

        $integration = yooadmin_get_integration();
        if (!$integration || !method_exists($integration, 'get_notifications')) {
            return false;
        }

        $items = $integration->get_notifications(
            $user_id,
            [
                'limit' => 100,
            ]
        );

        if (!is_array($items)) {
            return false;
        }

        foreach ($items as $item) {
            if ((int) ($item['id'] ?? 0) === $notification_id) {
                return self::row_meta_id($item) === self::NOTIFICATION_META_ID;
            }
        }

        return false;
    }

    /**
     * @param array<string, mixed> $row Notification row.
     */
    private static function row_meta_id(array $row): string {
        $meta = $row['meta'] ?? [];
        if (is_string($meta)) {
            $decoded = json_decode($meta, true);
            $meta    = is_array($decoded) ? $decoded : [];
        }

        return isset($meta['id']) ? (string) $meta['id'] : '';
    }

    /**
     * @return string
     */
    private static function required_capability(): string {
        if (function_exists('yooadmin_required_cap')) {
            return yooadmin_required_cap('settings');
        }

        return 'manage_options';
    }
}
