<?php
/**
 * YOOAdmin - Avatar upload AJAX handler
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_resolve_avatar_user_id')) {
    /**
     * @param int|string|object $id_or_email
     */
    function yooadmin_resolve_avatar_user_id($id_or_email): ?int
    {
        if (is_numeric($id_or_email)) {
            return (int) $id_or_email;
        }

        if (is_object($id_or_email)) {
            if (isset($id_or_email->user_id)) {
                return (int) $id_or_email->user_id;
            }
            if (isset($id_or_email->ID)) {
                return (int) $id_or_email->ID;
            }
        }

        if (is_string($id_or_email) && is_email($id_or_email)) {
            $user = get_user_by('email', $id_or_email);
            if ($user) {
                return (int) $user->ID;
            }
        }

        return null;
    }
}

if (!function_exists('yooadmin_get_user_avatar_attachment_id')) {
    /**
     * Resolve the YOOAdmin avatar attachment ID, re-linking a lone upload if meta was lost.
     */
    function yooadmin_get_user_avatar_attachment_id(int $user_id): int
    {
        if ($user_id <= 0) {
            return 0;
        }

        $avatar_id = (int) get_user_meta($user_id, 'yooadmin_avatar_id', true);
        if ($avatar_id > 0 && wp_get_attachment_image_url($avatar_id, 'thumbnail')) {
            return $avatar_id;
        }

        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Resolve legacy orphan avatar attachment by deterministic title.
        $orphan_id = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts}
                WHERE post_type = 'attachment'
                AND post_status = 'inherit'
                AND post_title = %s
                ORDER BY ID DESC
                LIMIT 1",
                'Avatar for user ' . $user_id
            )
        );

        if ($orphan_id > 0 && wp_get_attachment_image_url($orphan_id, 'thumbnail')) {
            update_user_meta($user_id, 'yooadmin_avatar_id', $orphan_id);

            return $orphan_id;
        }

        return 0;
    }
}

if (!function_exists('yooadmin_user_has_custom_avatar')) {
    function yooadmin_user_has_custom_avatar(int $user_id): bool
    {
        return yooadmin_get_user_avatar_attachment_id($user_id) > 0;
    }
}

if (!function_exists('yooadmin_get_avatar_data_unfiltered')) {
    /**
     * Resolve avatar data without re-entering YOOAdmin get_avatar_url filters.
     *
     * @param int|string|object $id_or_email
     */
    function yooadmin_get_avatar_data_unfiltered($id_or_email, array $args = []): array
    {
        static $resolving = false;

        if ($resolving) {
            return [
                'found_avatar' => false,
                'url'          => yooadmin_blank_avatar_url(),
            ];
        }

        $resolving = true;
        remove_filter('get_avatar_url', 'yooadmin_custom_avatar_url', 10);
        $avatar_data = get_avatar_data($id_or_email, $args);
        add_filter('get_avatar_url', 'yooadmin_custom_avatar_url', 10, 3);
        $resolving = false;

        return is_array($avatar_data) ? $avatar_data : [];
    }
}

if (!function_exists('yooadmin_user_avatar_is_placeholder')) {
    function yooadmin_user_avatar_is_placeholder(int $user_id, array $args = []): bool
    {
        if (yooadmin_user_has_custom_avatar($user_id)) {
            return false;
        }

        $avatar_data = yooadmin_get_avatar_data_unfiltered($user_id, $args);

        return empty($avatar_data['found_avatar']);
    }
}

if (!function_exists('yooadmin_blank_avatar_url')) {
    function yooadmin_blank_avatar_url(): string
    {
        return includes_url('images/blank.gif');
    }
}

// Filter to use custom avatar in get_avatar()
add_filter('get_avatar_url', 'yooadmin_custom_avatar_url', 10, 3);
add_filter('get_avatar', 'yooadmin_custom_avatar_html', 10, 6);

function yooadmin_custom_avatar_url($url, $id_or_email, $args) {
    $user_id = yooadmin_resolve_avatar_user_id($id_or_email);

    // Guests and commenters without a linked account: keep WordPress/Gravatar resolution.
    if (!$user_id) {
        return $url;
    }

    if (
        function_exists('yooadmin_profile_avatar_uses_yooadmin_filters')
        && !yooadmin_profile_avatar_uses_yooadmin_filters($user_id)
    ) {
        return $url;
    }

    $avatar_id = yooadmin_get_user_avatar_attachment_id($user_id);
    if ($avatar_id > 0) {
        $custom_url = wp_get_attachment_image_url($avatar_id, 'thumbnail');
        if ($custom_url) {
            return $custom_url;
        }
    }

    // YOOAdmin source without upload: blank placeholder only in profile shell contexts.
    if (apply_filters('yooadmin_avatar_use_blank_placeholder', false, $user_id, $id_or_email, $args)) {
        return yooadmin_blank_avatar_url();
    }

    return $url;
}

function yooadmin_custom_avatar_html($avatar, $id_or_email, $size, $default, $alt, $args = null) {
    $user_id = yooadmin_resolve_avatar_user_id($id_or_email);

    if (!$user_id) {
        return $avatar;
    }

    if (
        function_exists('yooadmin_profile_avatar_uses_yooadmin_filters')
        && !yooadmin_profile_avatar_uses_yooadmin_filters($user_id)
    ) {
        return $avatar;
    }

    $avatar_id = yooadmin_get_user_avatar_attachment_id($user_id);
    if ($avatar_id > 0) {
        $custom_url = wp_get_attachment_image_url($avatar_id, 'thumbnail');
        if ($custom_url) {
            return sprintf(
                '<img alt="%s" src="%s" class="avatar avatar-%d photo" height="%d" width="%d" />',
                esc_attr($alt),
                esc_url($custom_url),
                (int) $size,
                (int) $size,
                (int) $size
            );
        }
    }

    if (apply_filters('yooadmin_avatar_use_blank_placeholder', false, $user_id, $id_or_email, is_array($args) ? $args : [])) {
        return sprintf(
            '<img alt="%s" src="%s" class="avatar avatar-%d yoo-avatar--no-photo avatar-default photo" height="%d" width="%d" />',
            esc_attr($alt),
            esc_url(yooadmin_blank_avatar_url()),
            (int) $size,
            (int) $size,
            (int) $size
        );
    }

    return $avatar;
}

add_action('wp_ajax_yooadmin_upload_avatar', 'yooadmin_handle_avatar_upload');

function yooadmin_handle_avatar_upload() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'yooadmin_upload_avatar')) {
        wp_send_json_error(['message' => 'Security check failed.']);
    }

    $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;

    if (!$user_id) {
        wp_send_json_error(['message' => 'Invalid user ID.']);
    }

    // Check permissions
    if (!current_user_can('edit_user', $user_id)) {
        wp_send_json_error(['message' => 'You do not have permission to edit this user.']);
    }

    // Check if file was uploaded
    if (!isset($_FILES['avatar']) || !isset($_FILES['avatar']['error']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(['message' => 'No file uploaded or upload error.']);
    }

    $file = $_FILES['avatar']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- File upload; validated by finfo_file() MIME check + size limit below.

    // Validate file type
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime_type, $allowed_types, true)) {
        wp_send_json_error(['message' => 'Invalid file type. Please upload an image.']);
    }

    // Validate file size (5MB)
    if ($file['size'] > 5 * 1024 * 1024) {
        wp_send_json_error(['message' => 'File size must be less than 5MB.']);
    }

    // Upload file
    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $attachment_id = media_handle_upload('avatar', 0, [
        'post_title' => 'Avatar for user ' . $user_id,
        'post_content' => '',
        'post_status' => 'inherit'
    ]);

    if (is_wp_error($attachment_id)) {
        wp_send_json_error(['message' => $attachment_id->get_error_message()]);
    }

    // Delete old avatar if exists
    $old_avatar_id = get_user_meta($user_id, 'yooadmin_avatar_id', true);
    if ($old_avatar_id && is_numeric($old_avatar_id)) {
        wp_delete_attachment($old_avatar_id, true);
    }

    // Save new avatar ID
    update_user_meta($user_id, 'yooadmin_avatar_id', $attachment_id);

    if (function_exists('yooadmin_profile_set_avatar_source')) {
        yooadmin_profile_set_avatar_source($user_id, 'yooadmin');
    }

    $avatar_url = wp_get_attachment_image_url($attachment_id, 'thumbnail');

    wp_send_json_success([
        'message'               => __('Profile photo updated successfully.', 'yooadmin'),
        'avatar_url'            => $avatar_url,
        'avatar_source'         => 'yooadmin',
        'avatar_is_placeholder' => false,
        'has_custom_avatar'     => true,
    ]);
}

if (!function_exists('yooadmin_handle_avatar_delete')) {
    function yooadmin_handle_avatar_delete() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'yooadmin_upload_avatar')) {
            wp_send_json_error(['message' => 'Security check failed.']);
        }

        $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;

        if (!$user_id) {
            wp_send_json_error(['message' => 'Invalid user ID.']);
        }

        if (!current_user_can('edit_user', $user_id)) {
            wp_send_json_error(['message' => 'You do not have permission to edit this user.']);
        }

        $avatar_id = get_user_meta($user_id, 'yooadmin_avatar_id', true);
        if ($avatar_id && is_numeric($avatar_id)) {
            wp_delete_attachment((int) $avatar_id, true);
        }

        delete_user_meta($user_id, 'yooadmin_avatar_id');

        if (function_exists('yooadmin_profile_set_avatar_source')) {
            yooadmin_profile_set_avatar_source($user_id, 'gravatar');
        }

        $avatar_url = function_exists('yooadmin_profile_avatar_url_for_source')
            ? yooadmin_profile_avatar_url_for_source($user_id, 'gravatar', 110)
            : get_avatar_url($user_id, ['size' => 110]);

        wp_send_json_success([
            'message'             => __('Profile photo removed. Showing Gravatar.', 'yooadmin'),
            'avatar_url'          => $avatar_url,
            'avatar_source'       => 'gravatar',
            'avatar_is_placeholder' => false,
            'has_custom_avatar'   => false,
        ]);
    }
}

if (!has_action('wp_ajax_yooadmin_delete_avatar', 'yooadmin_handle_avatar_delete')) {
    add_action('wp_ajax_yooadmin_delete_avatar', 'yooadmin_handle_avatar_delete');
}
