<?php
/**
 * YOOAdmin — per-user Quick Actions storage.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

const YOOADMIN_USER_QUICK_ACTIONS_META_KEY = 'yooadmin_user_quick_actions';

/**
 * Capability required to edit personal Quick Actions.
 */
function yooadmin_quick_actions_capability(): string {
    return (string) apply_filters('yooadmin_quick_actions_capability', 'read');
}

/**
 * Whether the current user may customize their Quick Actions card.
 */
function yooadmin_user_can_edit_quick_actions(): bool {
    return is_user_logged_in() && current_user_can(yooadmin_quick_actions_capability());
}

/**
 * Max tiles for the active dashboard context.
 */
function yooadmin_quick_actions_max_items(): int {
    $max_default = 5;
    if (function_exists('yooadmin_studio_hub_is_active') && yooadmin_studio_hub_is_active()) {
        $max_default = 24;
    }

    $max = (int) apply_filters('yooadmin_quick_actions_max_items', $max_default);

    return $max > 0 ? $max : $max_default;
}

/**
 * @param array<int, mixed> $decoded
 * @return array<int, array<string, string>>
 */
function yooadmin_sanitize_quick_actions_payload(array $decoded): array {
    $max       = yooadmin_quick_actions_max_items();
    $sanitized = [];

    foreach ($decoded as $item) {
        if (count($sanitized) >= $max) {
            break;
        }
        if (!is_array($item)) {
            continue;
        }

        $label  = isset($item['label']) ? sanitize_text_field((string) $item['label']) : '';
        $url    = isset($item['url']) ? esc_url_raw((string) $item['url']) : '';
        $icon   = isset($item['icon']) ? sanitize_text_field((string) $item['icon']) : 'dashicons-admin-links';
        $target = isset($item['target']) && $item['target'] === '_self' ? '_self' : '_blank';

        if ($label === '' || $url === '') {
            continue;
        }
        if (!preg_match('/^dashicons-[a-z0-9\-]+$/', $icon)) {
            $icon = 'dashicons-admin-links';
        }

        $row = [
            'label'  => $label,
            'url'    => $url,
            'icon'   => $icon,
            'target' => $target,
        ];
        if (isset($item['aria_label']) && is_string($item['aria_label'])) {
            $al = sanitize_text_field($item['aria_label']);
            if ($al !== '') {
                $row['aria_label'] = $al;
            }
        }

        $sanitized[] = $row;
    }

    if (function_exists('yooadmin_filter_items_by_admin_href_capability')) {
        $sanitized = yooadmin_filter_items_by_admin_href_capability($sanitized, 'url');
    }

    return $sanitized;
}

/**
 * @param array<int, array<string, string>> $items
 * @return array<int, array<string, string>>
 */
function yooadmin_apply_quick_actions_label_map(array $items): array {
    if (!function_exists('yooadmin_dashboard_quick_actions_label_map')) {
        return $items;
    }

    $label_map = yooadmin_dashboard_quick_actions_label_map();
    $out       = [];

    foreach ($items as $it) {
        if (!is_array($it)) {
            continue;
        }
        $label = isset($it['label']) ? (string) $it['label'] : '';
        if ($label !== '' && isset($label_map[ $label ])) {
            $it['label'] = $label_map[ $label ];
        }
        $out[] = $it;
    }

    return $out;
}

/**
 * @param array<int, array<string, mixed>> $items
 * @return array<int, array<string, string>>
 */
function yooadmin_normalize_quick_actions_option_rows(array $items): array {
    $sanitized = [];

    foreach ($items as $it) {
        if (!is_array($it)) {
            continue;
        }
        $label  = isset($it['label']) ? (string) $it['label'] : '';
        $url    = isset($it['url']) ? (string) $it['url'] : '';
        $icon   = isset($it['icon']) ? (string) $it['icon'] : 'dashicons-admin-links';
        $target = isset($it['target']) ? (string) $it['target'] : '_blank';
        if ($label === '' || $url === '') {
            continue;
        }
        if (strpos($url, 'plugin-install.php') !== false) {
            continue;
        }
        $row = [
            'label'  => $label,
            'url'    => $url,
            'icon'   => $icon,
            'target' => $target === '_self' ? '_self' : '_blank',
        ];
        if (!empty($it['aria_label'])) {
            $row['aria_label'] = (string) $it['aria_label'];
        }
        $sanitized[] = $row;
    }

    return yooadmin_apply_quick_actions_label_map($sanitized);
}

/**
 * Saved personal Quick Actions for a user (empty array when unset).
 *
 * @return array<int, array<string, string>>|null Null when the user never saved personal actions.
 */
function yooadmin_get_user_quick_actions_saved(int $user_id = 0): ?array {
    if ($user_id <= 0) {
        $user_id = (int) get_current_user_id();
    }
    if ($user_id <= 0) {
        return null;
    }

    if (!metadata_exists('user', $user_id, YOOADMIN_USER_QUICK_ACTIONS_META_KEY)) {
        return null;
    }

    $stored = get_user_meta($user_id, YOOADMIN_USER_QUICK_ACTIONS_META_KEY, true);
    if (!is_array($stored)) {
        return [];
    }

    return yooadmin_normalize_quick_actions_option_rows($stored);
}

/**
 * Quick Actions rows to render for the current user.
 *
 * @return array<int, array<string, string>>
 */
function yooadmin_get_quick_actions_for_current_user(): array {
    $defaults = function_exists('yooadmin_dashboard_quick_actions_defaults')
        ? yooadmin_dashboard_quick_actions_defaults()
        : [];

    $personal = yooadmin_get_user_quick_actions_saved();
    if ($personal !== null) {
        $items = $personal;
    } elseif (
        function_exists('yooadmin_user_can_manage_site_settings')
        && yooadmin_user_can_manage_site_settings()
    ) {
        $site = get_option('yooadmin_quick_actions');
        $items = is_array($site) && $site !== [] ? yooadmin_normalize_quick_actions_option_rows($site) : $defaults;
    } else {
        $items = $defaults;
    }

    $items = apply_filters('yooadmin_card_actions', $items);
    if (!is_array($items)) {
        $items = $defaults;
    }
    $items = apply_filters('yooadmin_studio_hub_quick_actions', $items);
    if (!is_array($items)) {
        $items = $defaults;
    }

    if (function_exists('yooadmin_filter_items_by_admin_href_capability')) {
        $items = yooadmin_filter_items_by_admin_href_capability($items, 'url');
    }

    return $items;
}

/**
 * @param array<int, array<string, string>> $actions
 */
function yooadmin_save_user_quick_actions(array $actions, int $user_id = 0): bool {
    if ($user_id <= 0) {
        $user_id = (int) get_current_user_id();
    }
    if ($user_id <= 0) {
        return false;
    }

    $actions = array_values($actions);

    $existing = get_user_meta($user_id, YOOADMIN_USER_QUICK_ACTIONS_META_KEY, true);
    if (is_array($existing) && $existing === $actions) {
        return true;
    }

    return update_user_meta($user_id, YOOADMIN_USER_QUICK_ACTIONS_META_KEY, $actions) !== false;
}
