<?php
/**
 * YOOAdmin - Posts page (admin list)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

require_once __DIR__ . '/yoast-summary.php';

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct post count queries for accurate status counts.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- $where built from $wpdb->prepare(); $wpdb->posts is a core table property.
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter -- $where built from $wpdb->prepare(); $wpdb->posts is a core table property.
class YOOAdmin_Posts_Page
{

    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('admin_menu', [$this, 'register_page']);
        add_action('admin_init', [$this, 'maybe_redirect']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_yooadmin_posts_action', [$this, 'handle_ajax_action']);
        add_action('wp_ajax_yooadmin_bulk_posts_action', [$this, 'handle_bulk_action']);
        add_action('wp_ajax_yooadmin_filter_posts', [$this, 'ajax_filter_posts']);
        add_action('wp_ajax_yooadmin_load_more_posts', [$this, 'ajax_load_more_posts']);
        add_action('wp_ajax_yooadmin_get_post_counts', [$this, 'ajax_get_post_counts']);
    }

    /**
     * Register hidden submenu page
     */
    public function register_page()
    {
        $hook = add_submenu_page(
            '', // Hidden from menu
            'Posts',
            'Posts',
            'edit_posts',
            'yooadmin-posts',
        [$this, 'render_page']
        );
        if ($hook) {
            add_action("load-{$hook}", function () {
                global $title;
                $title = __('Posts', 'yooadmin');

                $opts = (array)get_option('yooadmin_options', []);
                $enabled = !empty($opts['posts_redirect']);
                if (!$enabled) {
                    wp_safe_redirect(admin_url('edit.php'));
                    exit;
                }
            });
        }
    }

    /**
     * Enqueue assets for posts page
     */
    public function enqueue_assets($hook)
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page detection.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== 'yooadmin-posts') {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir = plugin_dir_path($base_file);
        $base_url = plugin_dir_url($base_file);

        // Enqueue styles
        $style_rel = 'assets/css/admin/posts-page.css';
        $style_abs = $base_dir . $style_rel;
        if (file_exists($style_abs)) {
            wp_enqueue_style('yooadmin-posts', $base_url . $style_rel, ['yooadmin-shell'], filemtime($style_abs));
        }

        if (function_exists('yooadmin_enqueue_list_screen_toast_assets')) {
            yooadmin_enqueue_list_screen_toast_assets();
        }

        if (function_exists('yooadmin_enqueue_list_screen_ui_assets')) {
            yooadmin_enqueue_list_screen_ui_assets();
        }

        // Enqueue scripts
        $script_rel = 'assets/js/admin/posts-page.js';
        $script_abs = $base_dir . $script_rel;
        if (file_exists($script_abs)) {
            $posts_deps = ['jquery'];
            if (wp_script_is('yooadmin-list-screen-toast', 'registered') || wp_script_is('yooadmin-list-screen-toast', 'enqueued')) {
                $posts_deps[] = 'yooadmin-list-screen-toast';
            }
            if (wp_script_is('yooadmin-yp-ui-select', 'registered') || wp_script_is('yooadmin-yp-ui-select', 'enqueued')) {
                $posts_deps[] = 'yooadmin-yp-ui-select';
            }
            wp_enqueue_script('yooadmin-posts', $base_url . $script_rel, $posts_deps, filemtime($script_abs), true);
            wp_localize_script('yooadmin-posts', 'yooadmPosts', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('yooadmin_posts'),
                'i18n' => [
                    'deleteConfirm' => __('Are you sure you want to delete this post? This action cannot be undone.', 'yooadmin'),
                    'selected' => __('selected', 'yooadmin'),
                    'success' => __('Operation completed successfully.', 'yooadmin'),
                    'error' => __('An error occurred. Please try again.', 'yooadmin'),
                    'showStatistics' => __('Show Statistics', 'yooadmin'),
                    'hideStatistics' => __('Hide Statistics', 'yooadmin'),
                    'moveToTrash' => __('Move to Trash', 'yooadmin'),
                    'moveToTrashTitle' => __('Move to Trash?', 'yooadmin'),
                    'deletePostTitle' => __('Delete Post?', 'yooadmin'),
                    'restorePostTitle' => __('Restore Post?', 'yooadmin'),
                    /* translators: %s: post title */
                    'deleteConfirmMsg' => __('Are you sure you want to delete %s? This action cannot be undone.', 'yooadmin'),
                    /* translators: %s: post title */
                    'moveToTrashConfirmMsg' => __('Are you sure you want to move %s to trash?', 'yooadmin'),
                    /* translators: %s: post title */
                    'restoreConfirmMsg' => __('Are you sure you want to restore %s?', 'yooadmin'),
                    'cancel' => __('Cancel', 'yooadmin'),
                    'delete' => __('Delete', 'yooadmin'),
                    'restore' => __('Restore', 'yooadmin'),
                    'deleting' => __('Deleting...', 'yooadmin'),
                    'moving' => __('Moving...', 'yooadmin'),
                    'restoring' => __('Restoring...', 'yooadmin'),
                    'postDeleted' => __('Post deleted permanently.', 'yooadmin'),
                    'postMovedToTrash' => __('Post moved to trash.', 'yooadmin'),
                    'postRestored' => __('Post restored.', 'yooadmin'),
                    /* translators: %d: number of posts */
                    'postsDeleted' => __('%d posts deleted permanently.', 'yooadmin'),
                    /* translators: %d: number of posts */
                    'postsMovedToTrash' => __('%d posts moved to trash.', 'yooadmin'),
                    /* translators: %d: number of posts */
                    'postsRestored' => __('%d posts restored.', 'yooadmin'),
                    'apply' => __('Apply', 'yooadmin'),
                    'toDraft' => __('Draft', 'yooadmin'),
                    'publish' => __('Publish', 'yooadmin'),
                    'postMovedToDraft' => __('Post moved to draft.', 'yooadmin'),
                    'postPublished' => __('Post published.', 'yooadmin'),
                    'toDraftTitle' => __('Unpublish and move to draft?', 'yooadmin'),
                    'publishTitle' => __('Publish this post?', 'yooadmin'),
                ],
            ]);
        }
    }

    /**
     * Redirect from default edit.php to our page if YOOAdmin layout is enabled
     */
    public function maybe_redirect()
    {
        global $pagenow;

        if ($pagenow !== 'edit.php') {
            return;
        }

        // Only redirect for posts, not custom post types
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post_type check.
        $post_type = isset($_GET['post_type']) ? sanitize_key(wp_unslash($_GET['post_type'])) : 'post';
        if ($post_type !== 'post') {
            return;
        }

        // Check if already on our page
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page check for redirect.
        if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'yooadmin-posts') {
            return;
        }

        // Check settings
        $opts = (array)get_option('yooadmin_options', []);
        $posts_redirect = array_key_exists('posts_redirect', $opts)
            ? (!empty($opts['posts_redirect']) ? 1 : 0)
            : 1;

        // Check Focus Mode policy
        if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return;
        }

        // Don't redirect if disabled
        if (!$posts_redirect) {
            return;
        }

        // Build redirect URL with query params
        $redirect = admin_url('admin.php?page=yooadmin-posts');

        // Preserve query parameters
        $params = ['post_status', 'category', 'tag', 's', 'paged'];
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Preserving read-only GET filters for redirect; no state change.
        foreach ($params as $param) {
            if (!empty($_GET[$param])) {
                $redirect = add_query_arg($param, sanitize_text_field(wp_unslash($_GET[$param])), $redirect);
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        wp_safe_redirect($redirect);
        exit;
    }

    /**
     * Handle AJAX post actions (trash, delete, restore, etc.)
     */
    public function handle_ajax_action()
    {
        check_ajax_referer('yooadmin_posts', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $action = isset($_POST['post_action']) ? sanitize_key((string)$_POST['post_action']) : '';
        $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;

        if (empty($action) || !$post_id) {
            wp_send_json_error(['message' => __('Missing required parameters.', 'yooadmin')]);
        }

        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'post') {
            wp_send_json_error(['message' => __('Post not found.', 'yooadmin')]);
        }

        $message = '';

        switch ($action) {
            case 'trash':
                if (!current_user_can('delete_post', $post_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to delete this post.', 'yooadmin')]);
                }
                wp_trash_post($post_id);
                $message = __('Post moved to trash.', 'yooadmin');
                break;

            case 'delete':
                if (!current_user_can('delete_post', $post_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to delete this post.', 'yooadmin')]);
                }
                wp_delete_post($post_id, true);
                $message = __('Post permanently deleted.', 'yooadmin');
                break;

            case 'restore':
                if (!current_user_can('delete_post', $post_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to restore this post.', 'yooadmin')]);
                }
                wp_untrash_post($post_id);
                $message = __('Post restored.', 'yooadmin');
                break;

            case 'draft':
                if (!current_user_can('edit_post', $post_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to edit this post.', 'yooadmin')]);
                }
                if ($post->post_status !== 'publish') {
                    wp_send_json_error(['message' => __('Only published posts can be moved to draft.', 'yooadmin')]);
                }
                wp_update_post([
                    'ID' => $post_id,
                    'post_status' => 'draft',
                ]);
                $message = __('Post moved to draft.', 'yooadmin');
                break;

            case 'publish':
                if (!current_user_can('publish_post', $post_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to publish this post.', 'yooadmin')]);
                }
                if (!in_array($post->post_status, ['draft', 'pending', 'private'], true)) {
                    wp_send_json_error(['message' => __('This post cannot be published from the current status.', 'yooadmin')]);
                }
                wp_update_post([
                    'ID' => $post_id,
                    'post_status' => 'publish',
                ]);
                $message = __('Post published.', 'yooadmin');
                break;

            default:
                wp_send_json_error(['message' => __('Invalid action.', 'yooadmin')]);
        }

        wp_send_json_success(['message' => $message]);
    }

    /**
     * Handle bulk actions via AJAX
     */
    public function handle_bulk_action()
    {
        check_ajax_referer('yooadmin_posts', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $posts = isset($_POST['posts']) ? array_map('absint', (array)$_POST['posts']) : [];
        $action = isset($_POST['bulk_action']) ? sanitize_key((string)$_POST['bulk_action']) : '';

        if (empty($posts) || empty($action)) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'yooadmin')]);
        }

        $processed = 0;
        $errors = [];

        foreach ($posts as $post_id) {
            $post = get_post($post_id);
            if (!$post || $post->post_type !== 'post') {
                continue;
            }

            switch ($action) {
                case 'trash':
                    if (current_user_can('delete_post', $post_id)) {
                        wp_trash_post($post_id);
                        $processed++;
                    }
                    else {
                        // translators: %d: post ID
                        $errors[] = sprintf(__('No permission to trash post #%d.', 'yooadmin'), $post_id);
                    }
                    break;

                case 'delete':
                    if (current_user_can('delete_post', $post_id)) {
                        wp_delete_post($post_id, true);
                        $processed++;
                    }
                    else {
                        // translators: %d: post ID
                        $errors[] = sprintf(__('No permission to delete post #%d.', 'yooadmin'), $post_id);
                    }
                    break;

                case 'restore':
                    if (current_user_can('delete_post', $post_id)) {
                        wp_untrash_post($post_id);
                        $processed++;
                    }
                    else {
                        // translators: %d: post ID
                        $errors[] = sprintf(__('No permission to restore post #%d.', 'yooadmin'), $post_id);
                    }
                    break;
            }
        }

        if ($processed > 0) {
            // translators: %d: number of posts processed
            $message = sprintf(_n('%d post processed.', '%d posts processed.', $processed, 'yooadmin'), $processed);
            if (!empty($errors)) {
                // translators: %d: number of errors
                $message .= ' ' . sprintf(_n('%d error occurred.', '%d errors occurred.', count($errors), 'yooadmin'), count($errors));
            }
            wp_send_json_success(['message' => $message]);
        }
        else {
            $error_message = !empty($errors) ? implode(' ', $errors) : __('No posts were processed.', 'yooadmin');
            wp_send_json_error(['message' => $error_message]);
        }
    }

    /**
     * AJAX handler for filtering posts
     */
    public function ajax_filter_posts()
    {
        check_ajax_referer('yooadmin_posts', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $per_page = max(5, (int)apply_filters('yooadmin_posts_per_page', 12));
        $paged = isset($_POST['paged']) ? max(1, (int)$_POST['paged']) : 1;
        $status = isset($_POST['post_status']) ? sanitize_key((string)$_POST['post_status']) : '';
        $category = isset($_POST['category']) ? absint($_POST['category']) : 0;
        $search = isset($_POST['s']) ? sanitize_text_field(wp_unslash($_POST['s'])) : '';
        $author = isset($_POST['author']) ? absint($_POST['author']) : 0;

        $args = [
            'post_type' => 'post',
            'posts_per_page' => $per_page,
            'paged' => $paged,
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        if ($status) {
            $args['post_status'] = $status;
        }

        if ($category) {
            $args['cat'] = $category;
        }

        if ($search) {
            $args['s'] = $search;
        }

        if ($author) {
            $args['author'] = $author;
        }

        $query = new WP_Query($args);
        $has_posts = $query->post_count > 0;

        ob_start();
        if ($has_posts) {
            while ($query->have_posts()) {
                $query->the_post();
                $this->render_post_card(get_post());
            }
            wp_reset_postdata();
        }
        $cards_html = ob_get_clean();

        ob_start();
        if ($has_posts) {
            $query->rewind_posts();
            while ($query->have_posts()) {
                $query->the_post();
                $this->render_post_table_row(get_post());
            }
            wp_reset_postdata();
        }
        $table_html = ob_get_clean();

        $empty_html = '';
        if (!$has_posts) {
            ob_start();
            echo '<div class="yoo-posts-empty">';
            echo '<div class="yoo-empty-illustration"><span class="dashicons dashicons-edit-page"></span></div>';
            echo '<h2>' . esc_html__('No posts found', 'yooadmin') . '</h2>';
            echo '<p>' . esc_html__('Try adjusting your search or filter criteria.', 'yooadmin') . '</p>';
            echo '</div>';
            $empty_html = ob_get_clean();
        }

        $pagination_html = '';
        if ($has_posts && $query->max_num_pages > 1) {
            ob_start();
            $this->render_pagination($paged, $query->max_num_pages, $status, $category, $search, $author);
            $pagination_html = ob_get_clean();
        }

        wp_send_json_success([
            'cards_html' => $cards_html,
            'table_html' => $table_html,
            'empty_html' => $empty_html,
            'pagination_html' => $pagination_html,
            'html' => $cards_html,
            'total' => (int)$query->found_posts,
            'paged' => $paged,
            'total_pages' => (int)$query->max_num_pages,
        ]);
    }

    /**
     * Load more posts via AJAX (for infinite scroll)
     */
    public function ajax_load_more_posts()
    {
        check_ajax_referer('yooadmin_posts', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $per_page = max(5, (int)apply_filters('yooadmin_posts_per_page', 12));
        $paged = isset($_POST['paged']) ? max(1, (int)$_POST['paged']) : 1;
        $status = isset($_POST['post_status']) ? sanitize_key((string)$_POST['post_status']) : '';
        $category = isset($_POST['category']) ? absint($_POST['category']) : 0;
        $search = isset($_POST['s']) ? sanitize_text_field(wp_unslash($_POST['s'])) : '';
        $author = isset($_POST['author']) ? absint($_POST['author']) : 0;
        $view = isset($_POST['view']) ? sanitize_key((string)$_POST['view']) : 'cards'; // cards or table

        $args = [
            'post_type' => 'post',
            'posts_per_page' => $per_page,
            'paged' => $paged,
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        if ($status) {
            $args['post_status'] = $status;
        }

        if ($category) {
            $args['cat'] = $category;
        }

        if ($search) {
            $args['s'] = $search;
        }

        if ($author) {
            $args['author'] = $author;
        }

        $query = new WP_Query($args);

        // Render posts HTML
        ob_start();
        if ($query->have_posts()) {
            if ($view === 'table') {
                // Render table rows
                while ($query->have_posts()) {
                    $query->the_post();
                    $post = get_post();
                    $this->render_post_table_row($post);
                }
            }
            else {
                // Render cards
                while ($query->have_posts()) {
                    $query->the_post();
                    $this->render_post_card(get_post());
                }
            }
            wp_reset_postdata();
        }
        $html = ob_get_clean();

        wp_send_json_success([
            'html' => $html,
            'has_more' => $paged < $query->max_num_pages,
            'next_page' => $paged + 1,
            'total_pages' => (int)$query->max_num_pages,
        ]);
    }

    /**
     * Render post table row
     */
    private function render_post_table_row($post)
    {
        $edit_url = get_edit_post_link($post->ID);
        $view_url = get_permalink($post->ID);
        $post_status = $post->post_status;
        $post_categories = get_the_category($post->ID);
        $post_tags       = get_the_tags($post->ID);
        if (! is_array($post_tags)) {
            $post_tags = [];
        }
        $post_author = get_userdata($post->post_author);
        $featured_image = get_the_post_thumbnail_url($post->ID, 'thumbnail');
        $full_image = get_the_post_thumbnail_url($post->ID, 'full');
?>
        <tr class="yoo-post-row <?php echo esc_attr($post_status); ?>" data-post-id="<?php echo esc_attr($post->ID); ?>" data-title="<?php echo esc_attr(strtolower(get_the_title($post->ID) ?: '')); ?>" data-date="<?php echo esc_attr(get_the_date('U', $post->ID)); ?>">
            <th scope="row" class="check-column">
                <input type="checkbox" class="yoo-post-checkbox" value="<?php echo esc_attr($post->ID); ?>" id="post-table-<?php echo esc_attr($post->ID); ?>">
                <label for="post-table-<?php echo esc_attr($post->ID); ?>" class="screen-reader-text"><?php esc_html_e('Select', 'yooadmin'); ?></label>
            </th>
            <td class="thumbnail column-thumbnail" data-colname="<?php esc_attr_e('Image', 'yooadmin'); ?>">
                <?php if ($featured_image): ?>
                <div class="yoo-table-thumbnail">
                    <img src="<?php echo esc_url($featured_image); ?>" 
                         alt="<?php echo esc_attr(get_the_title($post->ID)); ?>"
                         class="yoo-image-lightbox-trigger"
                         data-image-url="<?php echo esc_url($full_image); ?>"
                         data-image-title="<?php echo esc_attr(get_the_title($post->ID)); ?>"
                         style="cursor: pointer;">
                </div>
                <?php
        else: ?>
                <div class="yoo-table-thumbnail yoo-table-thumbnail--placeholder">
                    <span class="dashicons dashicons-format-image"></span>
                </div>
                <?php
        endif; ?>
            </td>
            <td class="title column-title column-primary" data-colname="<?php esc_attr_e('Title', 'yooadmin'); ?>">
                <strong>
                    <a class="row-title" href="<?php echo esc_url($edit_url); ?>">
                        <?php echo esc_html(get_the_title($post->ID) ?: __('(No title)', 'yooadmin')); ?>
                    </a>
                </strong>
                <div class="row-actions">
                    <?php if ($post_status === 'publish'): ?>
                    <span class="view">
                        <a href="<?php echo esc_url($view_url); ?>" target="_blank">
                            <span class="dashicons dashicons-visibility" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                            <?php esc_html_e('View', 'yooadmin'); ?>
                        </a> |
                    </span>
                    <?php
        endif; ?>
                    <span class="edit">
                        <a href="<?php echo esc_url($edit_url); ?>">
                            <span class="dashicons dashicons-edit" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                            <?php esc_html_e('Edit', 'yooadmin'); ?>
                        </a> |
                    </span>
                    <?php if ($post_status === 'publish' && current_user_can('edit_post', $post->ID)): ?>
                    <span class="to-draft">
                        <a href="#" class="yoo-action-link to-draft" data-post-id="<?php echo esc_attr($post->ID); ?>">
                            <span class="dashicons dashicons-hidden" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                            <?php esc_html_e('Draft', 'yooadmin'); ?>
                        </a> |
                    </span>
                    <?php
        elseif (in_array($post_status, ['draft', 'pending', 'private'], true) && current_user_can('publish_post', $post->ID)): ?>
                    <span class="to-publish">
                        <a href="#" class="yoo-action-link to-publish" data-post-id="<?php echo esc_attr($post->ID); ?>">
                            <span class="dashicons dashicons-yes-alt" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                            <?php esc_html_e('Publish', 'yooadmin'); ?>
                        </a> |
                    </span>
                    <?php
        endif; ?>
                    <?php if ($post_status === 'trash'): ?>
                    <span class="restore">
                        <a href="#" class="yoo-action-link restore" data-post-id="<?php echo esc_attr($post->ID); ?>">
                            <span class="dashicons dashicons-undo" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                            <?php esc_html_e('Restore', 'yooadmin'); ?>
                        </a> |
                    </span>
                    <span class="trash">
                        <a href="#" class="yoo-action-link delete" data-post-id="<?php echo esc_attr($post->ID); ?>">
                            <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                            <?php esc_html_e('Delete Permanently', 'yooadmin'); ?>
                        </a>
                    </span>
                    <?php
        else: ?>
                    <span class="trash">
                        <a href="#" class="yoo-action-link trash" data-post-id="<?php echo esc_attr($post->ID); ?>">
                            <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                            <?php esc_html_e('Trash', 'yooadmin'); ?>
                        </a>
                    </span>
                    <?php
        endif; ?>
                </div>
                <?php yooadmin_render_yoast_summary($post->ID, 'post'); ?>
            </td>
            <td class="author column-author" data-colname="<?php esc_attr_e('Author', 'yooadmin'); ?>">
                <?php echo esc_html($post_author ? $post_author->display_name : __('Unknown', 'yooadmin')); ?>
            </td>
            <td class="categories column-categories" data-colname="<?php esc_attr_e('Categories', 'yooadmin'); ?>">
                <?php
        if (!empty($post_categories)) {
            $cat_names = array_map(function ($cat) {
                return '<a href="' . esc_url(get_edit_term_link($cat->term_id, 'category')) . '">' . esc_html($cat->name) . '</a>';
            }, $post_categories);
            echo wp_kses_post(implode(', ', $cat_names));
        }
        else {
            echo '<span aria-hidden="true">—</span>';
        }
?>
            </td>
            <td class="tags column-tags" data-colname="<?php esc_attr_e('Tags', 'yooadmin'); ?>">
                <?php
        if (!empty($post_tags)) {
            $tag_links = array_map(function ($tag) {
                return '<a href="' . esc_url(get_edit_term_link($tag->term_id, 'post_tag')) . '">' . esc_html($tag->name) . '</a>';
            }, $post_tags);
            echo wp_kses_post(implode(', ', $tag_links));
        }
        else {
            echo '<span aria-hidden="true">—</span>';
        }
?>
            </td>
            <td class="date column-date" data-colname="<?php esc_attr_e('Date', 'yooadmin'); ?>">
                <?php echo esc_html(get_the_date('', $post->ID)); ?>
            </td>
            <td class="comments column-comments" data-colname="<?php esc_attr_e('Comments', 'yooadmin'); ?>">
                <?php
        $comments_count = get_comments_number($post->ID);
        $comments_url = admin_url('edit-comments.php?p=' . $post->ID);
        if ($comments_count > 0):
?>
                <a href="<?php echo esc_url($comments_url); ?>" class="post-com-count post-com-count-approved">
                    <span class="comment-count-approved" aria-hidden="true">
                        <span class="dashicons dashicons-admin-comments" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                        <?php echo esc_html(number_format_i18n($comments_count)); ?>
                    </span>
                </a>
                <?php
        else: ?>
                <span class="post-com-count post-com-count-no-comments">
                    <span class="dashicons dashicons-admin-comments" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; opacity: 0.4;"></span>
                    <span class="screen-reader-text"><?php esc_html_e('No comments', 'yooadmin'); ?></span>
                    <span aria-hidden="true">—</span>
                </span>
                <?php
        endif; ?>
            </td>
            <td class="status column-status" data-colname="<?php esc_attr_e('Status', 'yooadmin'); ?>">
                <span class="yoo-post-status yoo-post-status--<?php echo esc_attr($post_status); ?>">
                    <?php echo esc_html(ucfirst($post_status)); ?>
                </span>
            </td>
        </tr>
        <?php
    }

    /**
     * Render post card
     */
    private function render_post_card($post)
    {
        $edit_url = get_edit_post_link($post->ID);
        $view_url = get_permalink($post->ID);
        $status = $post->post_status;
        $categories = get_the_category($post->ID);
        $author = get_userdata($post->post_author);
        $featured_image = get_the_post_thumbnail_url($post->ID, 'medium');
?>
        <article class="yoo-post-card <?php echo esc_attr($status); ?>" data-post-id="<?php echo esc_attr($post->ID); ?>">
            <input type="checkbox" class="yoo-post-checkbox" value="<?php echo esc_attr($post->ID); ?>" id="post-<?php echo esc_attr($post->ID); ?>">
            <label for="post-<?php echo esc_attr($post->ID); ?>" class="yoo-post-checkbox-label"></label>
            
            <div class="yoo-post-image">
                <span class="yoo-post-status yoo-post-status--<?php echo esc_attr($status); ?>">
                    <?php echo esc_html(ucfirst($status)); ?>
                </span>
                <?php if ($featured_image):
            $full_image = get_the_post_thumbnail_url($post->ID, 'full');
?>
                <img src="<?php echo esc_url($featured_image); ?>"
                     alt="<?php echo esc_attr(get_the_title($post->ID)); ?>"
                     class="yoo-image-lightbox-trigger"
                     data-image-url="<?php echo esc_url($full_image); ?>"
                     data-image-title="<?php echo esc_attr(get_the_title($post->ID)); ?>"
                     style="cursor: pointer;">
                <?php
        else: ?>
                <div class="yoo-post-image-placeholder">
                    <span class="dashicons dashicons-format-image"></span>
                    <span class="yoo-placeholder-text"><?php esc_html_e('No Image', 'yooadmin'); ?></span>
                </div>
                <?php
        endif; ?>
            </div>
            
            <div class="yoo-post-content">
                <header class="yoo-post-header">
                    <h2 class="yoo-post-title">
                        <a href="<?php echo esc_url($edit_url); ?>">
                            <?php echo esc_html(get_the_title($post->ID) ?: __('(No title)', 'yooadmin')); ?>
                        </a>
                    </h2>
                </header>
                
                <div class="yoo-post-meta">
                    <div class="yoo-post-meta-item">
                        <span class="dashicons dashicons-admin-users"></span>
                        <span><?php echo esc_html($author ? $author->display_name : __('Unknown', 'yooadmin')); ?></span>
                    </div>
                    <div class="yoo-post-meta-item">
                        <span class="dashicons dashicons-calendar-alt"></span>
                        <span><?php echo esc_html(get_the_date('', $post->ID)); ?></span>
                    </div>
                    <?php if (!empty($categories)): ?>
                    <div class="yoo-post-meta-item">
                        <span class="dashicons dashicons-category"></span>
                        <span><?php echo esc_html($categories[0]->name); ?></span>
                    </div>
                    <?php
        endif; ?>
                </div>
                
                <?php
        $excerpt = '';
        if (!empty($post->post_excerpt)) {
            $excerpt = $post->post_excerpt;
        }
        else if (!empty($post->post_content)) {
            $excerpt = $post->post_content;
        }
        if (!empty($excerpt)):
?>
                <p class="yoo-post-excerpt"><?php echo esc_html(wp_trim_words(strip_shortcodes($excerpt), 20)); ?></p>
                <?php
        endif; ?>
                
                <div class="yoo-post-actions">
                    <?php if ($status === 'publish'): ?>
                    <a href="<?php echo esc_url($view_url); ?>" target="_blank" class="yoo-action-btn">
                        <span class="dashicons dashicons-visibility"></span>
                        <?php esc_html_e('View', 'yooadmin'); ?>
                    </a>
                    <?php
        endif; ?>
                    <a href="<?php echo esc_url($edit_url); ?>" class="yoo-action-btn">
                        <span class="dashicons dashicons-edit"></span>
                        <?php esc_html_e('Edit', 'yooadmin'); ?>
                    </a>
                    <?php if ($status === 'publish' && current_user_can('edit_post', $post->ID)): ?>
                    <button type="button" class="yoo-action-btn to-draft" data-post-id="<?php echo esc_attr($post->ID); ?>">
                        <span class="dashicons dashicons-hidden"></span>
                        <?php esc_html_e('Draft', 'yooadmin'); ?>
                    </button>
                    <?php
        elseif (in_array($status, ['draft', 'pending', 'private'], true) && current_user_can('publish_post', $post->ID)): ?>
                    <button type="button" class="yoo-action-btn to-publish" data-post-id="<?php echo esc_attr($post->ID); ?>">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <?php esc_html_e('Publish', 'yooadmin'); ?>
                    </button>
                    <?php
        endif; ?>
                    <?php if ($status === 'trash'): ?>
                    <button class="yoo-action-btn restore" data-post-id="<?php echo esc_attr($post->ID); ?>">
                        <span class="dashicons dashicons-undo"></span>
                        <?php esc_html_e('Restore', 'yooadmin'); ?>
                    </button>
                    <button class="yoo-action-btn danger delete" data-post-id="<?php echo esc_attr($post->ID); ?>">
                        <span class="dashicons dashicons-trash"></span>
                        <?php esc_html_e('Delete', 'yooadmin'); ?>
                    </button>
                    <?php
        else: ?>
                    <button class="yoo-action-btn trash" data-post-id="<?php echo esc_attr($post->ID); ?>">
                        <span class="dashicons dashicons-trash"></span>
                        <?php esc_html_e('Trash', 'yooadmin'); ?>
                    </button>
                    <?php
        endif; ?>
                </div>
                <?php yooadmin_render_yoast_summary($post->ID, 'post'); ?>
            </div>
        </article>
        <?php
    }

    /**
     * Render pagination
     */
    private function render_pagination($current, $total_pages, $status = '', $category = 0, $search = '', $author = 0)
    {
        $base_url = admin_url('admin.php?page=yooadmin-posts');
        if ($status) {
            $base_url = add_query_arg('post_status', urlencode($status), $base_url);
        }
        if ($category) {
            $base_url = add_query_arg('category', urlencode($category), $base_url);
        }
        if ($search) {
            $base_url = add_query_arg('s', urlencode($search), $base_url);
        }
        if ($author) {
            $base_url = add_query_arg('author', $author, $base_url);
        }

        echo '<nav class="yoo-posts-pagination">';

        // Previous
        if ($current > 1) {
            $prev_url = add_query_arg('paged', $current - 1, $base_url);
            printf('<a href="%s" class="yoo-pagination-prev" data-paged="%d">%s</a>',
                esc_url($prev_url),
                (int) ($current - 1),
                esc_html__('Previous', 'yooadmin')
            );
        }

        // Page numbers
        for ($i = 1; $i <= $total_pages; $i++) {
            if ($i === $current) {
                printf('<span class="yoo-pagination-current">%d</span>', (int) $i);
            }
            else {
                $page_url = add_query_arg('paged', $i, $base_url);
                printf('<a href="%s" class="yoo-pagination-link" data-paged="%d">%d</a>',
                    esc_url($page_url),
                    (int)$i,
                    (int)$i
                );
            }
        }

        // Next
        if ($current < $total_pages) {
            $next_url = add_query_arg('paged', $current + 1, $base_url);
            printf('<a href="%s" class="yoo-pagination-next" data-paged="%d">%s</a>',
                esc_url($next_url),
                (int) ($current + 1),
                esc_html__('Next', 'yooadmin')
            );
        }

        echo '</nav>';
    }

    /**
     * Render the posts page
     */
    public function render_page()
    {
        if (!current_user_can('edit_posts')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'yooadmin'));
        }

        $per_page = max(5, (int)apply_filters('yooadmin_posts_per_page', 12));
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only pagination/filter/sort from URL; no state change. All values sanitized.
        $paged = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        $status = isset($_GET['post_status']) ? sanitize_key(wp_unslash($_GET['post_status'])) : '';
        $category = isset($_GET['category']) ? absint($_GET['category']) : 0;
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $author = isset($_GET['author']) ? absint($_GET['author']) : 0;
        $orderby = isset($_GET['orderby']) ? sanitize_key(wp_unslash($_GET['orderby'])) : 'date';
        $order = isset($_GET['order']) ? strtoupper(sanitize_key(wp_unslash($_GET['order']))) : 'DESC';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        // Validate orderby
        $allowed_orderby = ['date', 'title', 'author', 'status'];
        if (!in_array($orderby, $allowed_orderby, true)) {
            $orderby = 'date';
        }

        // Validate order
        if (!in_array($order, ['ASC', 'DESC'], true)) {
            $order = 'DESC';
        }

        $args = [
            'post_type' => 'post',
            'posts_per_page' => $per_page,
            'paged' => $paged,
            'orderby' => $orderby,
            'order' => $order,
        ];

        if ($status) {
            $args['post_status'] = $status;
        }

        if ($category) {
            $args['cat'] = $category;
        }

        if ($search) {
            $args['s'] = $search;
        }

        if ($author) {
            $args['author'] = $author;
        }

        $query = new WP_Query($args);

        // Get stats - flush cache to ensure fresh counts
        wp_cache_delete('last_changed', 'posts');

        // Use direct queries to get accurate counts (excluding auto-draft and revisions)
        global $wpdb;

        $post_type = 'post';
        $where = $wpdb->prepare("WHERE post_type = %s", $post_type);
        $where .= " AND post_status != 'auto-draft' AND post_status != 'inherit'";

        // Get publish count
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $publish_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'publish'");

        // Get draft count (excluding auto-draft which we already filtered)
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $draft_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'draft'");

        // Get trash count
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $trash_count = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'trash'", $post_type));

        // Get other statuses for completeness
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $pending_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'pending'");
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $private_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'private'");
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $future_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'future'");

        // Calculate total: publish + draft only (as shown in filter tabs)
        // Exclude trash, auto-draft, inherit (revisions), pending, private, future
        $total_count = $publish_count + $draft_count;

        // Get categories for filter
        $categories = get_categories(['hide_empty' => false]);

        // Get authors for filter
        $authors = get_users([
            'capability' => 'edit_posts',
            'has_published_posts' => ['post'],
        ]);

        // Pass variables to template
        $template_vars = [
            'query' => $query,
            'status' => $status,
            'category' => $category,
            'search' => $search,
            'author' => $author,
            'orderby' => $orderby,
            'order' => $order,
            'paged' => $paged,
            'total_count' => $total_count,
            'publish_count' => $publish_count,
            'draft_count' => $draft_count,
            'trash_count' => $trash_count,
            'categories' => $categories,
            'authors' => $authors,
            'list_url' => admin_url('admin.php?page=yooadmin-posts'),
            'new_url' => admin_url('post-new.php'),
        ];

        // Extract variables
        extract($template_vars);

        $template = plugin_dir_path(yooadmin_base_file()) . 'templates/yoopixel/admin/pages/posts/index.php';
        if (file_exists($template)) {
            include $template;
            return;
        }

        // Fallback render
        echo '<div class="wrap"><h1>' . esc_html__('Posts', 'yooadmin') . '</h1>';
        if ($query->have_posts()) {
            echo '<ul>';
            while ($query->have_posts()) {
                $query->the_post();
                printf('<li><a href="%s">%s</a></li>',
                    esc_url(get_edit_post_link()),
                    esc_html(get_the_title())
                );
            }
            wp_reset_postdata();
            echo '</ul>';
        }
        else {
            esc_html_e('No posts found.', 'yooadmin');
        }
        echo '</div>';
    }

    /**
     * AJAX handler to get current post counts (for updating tabs after actions)
     */
    public function ajax_get_post_counts()
    {
        check_ajax_referer('yooadmin_posts', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        // Get fresh counts - flush cache to ensure fresh counts
        wp_cache_delete('last_changed', 'posts');

        // Use direct queries to get accurate counts (excluding auto-draft and revisions)
        global $wpdb;

        $post_type = 'post';
        $where = $wpdb->prepare("WHERE post_type = %s", $post_type);
        $where .= " AND post_status != 'auto-draft' AND post_status != 'inherit'";

        // Get publish count
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $publish_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'publish'");

        // Get draft count (excluding auto-draft which we already filtered)
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $draft_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'draft'");

        // Get trash count
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $trash_count = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'trash'", $post_type));

        // Get other statuses for completeness
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $pending_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'pending'");
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $private_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'private'");
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Post count query; $where built from $wpdb->prepare().
        $future_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} {$where} AND post_status = 'future'");

        // Calculate total: publish + draft only (as shown in filter tabs)
        // Exclude trash, auto-draft, inherit (revisions), pending, private, future
        $total_count = $publish_count + $draft_count;

        wp_send_json_success([
            'total_count' => $total_count,
            'publish_count' => $publish_count,
            'draft_count' => $draft_count,
            'trash_count' => $trash_count,
        ]);
    }
}

// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter

// Initialize
YOOAdmin_Posts_Page::get_instance();
