<?php
/**
 * YOOAdmin - Users page (admin list and profile)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Settings-style help tooltip for user create / profile form labels.
 *
 * @param string $description Tooltip body text.
 */
function yooadmin_user_field_help_tooltip(string $description): string
{
    if ($description === '') {
        return '';
    }

    return '<span class="yp-help-icon yoo-field-help-icon" tabindex="0" role="button" aria-label="'
        . esc_attr__('Help', 'yooadmin')
        . '"><span class="dashicons dashicons-editor-help" aria-hidden="true"></span><span class="yp-tooltip yoo-user-form-tooltip">'
        . esc_html($description)
        . '</span></span>';
}

/**
 * Short role summary for the Add User sidebar (Role highlights).
 *
 * @param string $role_key WordPress role slug.
 */
function yooadmin_user_role_highlight_description(string $role_key): string
{
    $descriptions = [
        'administrator' => __(
            'Full control of the site: settings, users, plugins, themes, and all content.',
            'yooadmin'
        ),
        'editor' => __(
            'Publish and manage all posts and pages, including content from other users.',
            'yooadmin'
        ),
        'author' => __(
            'Publish and edit their own posts; can upload files to the media library.',
            'yooadmin'
        ),
        'contributor' => __(
            'Write and edit their own posts; cannot publish until an editor approves.',
            'yooadmin'
        ),
        'subscriber' => __(
            'Read-only access to the site; can update their own profile.',
            'yooadmin'
        ),
    ];

    if (isset($descriptions[$role_key])) {
        return $descriptions[$role_key];
    }

    return __('Capabilities for this role depend on your site configuration.', 'yooadmin');
}

/**
 * Translate a WordPress role label (uses role display name, not slug).
 *
 * @param string               $role_key  Role slug.
 * @param array<string, mixed>|null $role_data Optional row from get_editable_roles().
 */
function yooadmin_translate_role_label(string $role_key, ?array $role_data = null): string
{
    $name = '';
    if (is_array($role_data) && !empty($role_data['name'])) {
        $name = (string) $role_data['name'];
    } else {
        $wp_roles = wp_roles();
        $name = isset($wp_roles->roles[$role_key]['name'])
            ? (string) $wp_roles->roles[$role_key]['name']
            : $role_key;
    }

    return translate_user_role($name);
}

/**
 * Comma-separated translated labels for a user's role slugs.
 *
 * @param string[] $role_slugs
 */
function yooadmin_translate_user_role_list(array $role_slugs): string
{
    if ($role_slugs === []) {
        return '';
    }

    $labels = array_map(
        static fn (string $slug): string => yooadmin_translate_role_label($slug),
        array_values($role_slugs)
    );

    return implode(', ', $labels);
}

/**
 * Allowed HTML for third-party user row action links (User Switching, etc.).
 *
 * @return array<string, array<string, bool>>
 */
function yooadmin_users_row_actions_allowed_html(): array
{
    return [
        'a' => [
            'href'       => true,
            'title'      => true,
            'aria-label' => true,
            'class'      => true,
            'target'     => true,
            'rel'        => true,
            'data-*'     => true,
        ],
    ];
}

/**
 * Delete/Remove link for the card overflow menu (handled via YOOAdmin confirm modal + AJAX).
 */
function yooadmin_users_row_destructive_action_link(string $action, WP_User $user, string $label): string
{
    $is_admin = in_array('administrator', (array) $user->roles, true) ? '1' : '0';

    return sprintf(
        '<a class="submitdelete" href="#" data-yoo-user-action="%1$s" data-user-id="%2$d" data-user-name="%3$s" data-is-admin="%4$s">%5$s</a>',
        esc_attr($action),
        (int) $user->ID,
        esc_attr($user->display_name),
        $is_admin,
        esc_html($label)
    );
}

/**
 * Build user row actions (mirrors core users table + user_row_actions filter).
 *
 * @return array<string, string>
 */
function yooadmin_users_build_row_actions(WP_User $user): array
{
    $actions = [];

    if (current_user_can('edit_user', $user->ID)) {
        $edit_link = add_query_arg(
            [
                'page'    => 'yooadmin-user',
                'user_id' => $user->ID,
            ],
            admin_url('admin.php')
        );
        $actions['edit'] = sprintf(
            '<a href="%s">%s</a>',
            esc_url($edit_link),
            esc_html__('Edit', 'yooadmin')
        );
    }

    if (
        !is_multisite()
        && get_current_user_id() !== $user->ID
        && current_user_can('delete_user', $user->ID)
    ) {
        $actions['delete'] = yooadmin_users_row_destructive_action_link('delete', $user, __('Delete', 'yooadmin'));
    }

    if (is_multisite() && current_user_can('remove_user', $user->ID)) {
        $actions['remove'] = yooadmin_users_row_destructive_action_link('remove', $user, __('Remove', 'yooadmin'));
    }

    $author_posts_url = get_author_posts_url($user->ID);
    if ($author_posts_url) {
        $actions['view'] = sprintf(
            '<a href="%s" aria-label="%s">%s</a>',
            esc_url($author_posts_url),
            esc_attr(
                sprintf(
                    /* translators: %s: Author's display name. */
                    __('View posts by %s', 'yooadmin'),
                    $user->display_name
                )
            ),
            esc_html__('View', 'yooadmin')
        );
    }

    if (
        get_current_user_id() !== $user->ID
        && current_user_can('edit_user', $user->ID)
        && function_exists('yooadmin_is_password_reset_allowed_for_user')
        && true === yooadmin_is_password_reset_allowed_for_user($user)
    ) {
        $actions['resetpassword'] = sprintf(
            '<a class="resetpassword" href="%s">%s</a>',
            esc_url(wp_nonce_url('users.php?action=resetpassword&amp;users=' . $user->ID, 'bulk-users')),
            esc_html__('Send password reset', 'yooadmin')
        );
    }

    /**
     * Filters the action links displayed for each user in the YOOAdmin users list.
     *
     * @param string[] $actions Action links keyed by action name.
     * @param WP_User  $user    Listed user.
     */
    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core users list row actions filter.
    return (array) apply_filters('user_row_actions', $actions, $user);
}

/**
 * Build profile hero actions (list actions minus items already on this page).
 *
 * @return array<string, string>
 */
function yooadmin_users_build_profile_actions(WP_User $user): array
{
    $actions = yooadmin_users_build_row_actions($user);

    // Viewer is already on the profile page.
    unset($actions['edit']);

    // Duplicated by the hero "Send password reset link" button.
    unset($actions['resetpassword']);

    /**
     * Filters action links in the YOOAdmin user profile hero.
     *
     * @param string[] $actions Action links keyed by action name.
     * @param WP_User  $user    Profile user.
     */
    return (array) apply_filters('yooadmin_user_profile_actions', $actions, $user);
}

/**
 * Render profile hero overflow menu (Switch To, delete, view, plugin actions, etc.).
 */
function yooadmin_users_render_profile_actions(WP_User $user): void
{
    yooadmin_users_render_row_actions($user, yooadmin_users_build_profile_actions($user), 'profile');
}

/**
 * Render a card overflow menu (3-dot) with user_row_actions links.
 *
 * @param array<string, string>|null $actions Pre-built actions; defaults to list row actions.
 * @param string                     $variant `card` on the users list, `profile` on user profile hero.
 */
function yooadmin_users_render_row_actions(WP_User $user, ?array $actions = null, string $variant = 'card'): void
{
    if ($actions === null) {
        $actions = yooadmin_users_build_row_actions($user);
    }
    if ($actions === []) {
        return;
    }

    $allowed = yooadmin_users_row_actions_allowed_html();
    $menu_id = $variant === 'profile'
        ? 'yoo-user-profile-menu-' . $user->ID
        : 'yoo-user-card-menu-' . $user->ID;
    $menu_classes = 'yoo-user-card-menu';
    if ($variant === 'profile') {
        $menu_classes .= ' yoo-user-card-menu--profile';
    }
    $toggle_classes = 'yoo-user-card-menu__toggle';
    if ($variant === 'profile') {
        $toggle_classes .= ' yoo-button yoo-button--ghost';
    }
    ?>
    <div class="<?php echo esc_attr($menu_classes); ?>">
        <button
            type="button"
            class="<?php echo esc_attr($toggle_classes); ?>"
            aria-expanded="false"
            aria-haspopup="menu"
            aria-controls="<?php echo esc_attr($menu_id); ?>"
        >
            <span class="dashicons dashicons-ellipsis" aria-hidden="true"></span>
            <?php if ($variant === 'profile') : ?>
                <span><?php esc_html_e('More actions', 'yooadmin'); ?></span>
            <?php else : ?>
                <span class="screen-reader-text"><?php esc_html_e('User actions', 'yooadmin'); ?></span>
            <?php endif; ?>
        </button>
        <div
            class="yoo-user-card-menu__dropdown"
            id="<?php echo esc_attr($menu_id); ?>"
            role="menu"
            hidden
        >
            <ul class="yoo-user-card-menu__list">
                <?php foreach ($actions as $action_key => $link_html) : ?>
                    <?php
                    $item_class = 'yoo-user-card-menu__item yoo-user-card-menu__item--' . sanitize_html_class((string) $action_key);
                    if (in_array((string) $action_key, ['delete', 'remove'], true)) {
                        $item_class .= ' yoo-user-card-menu__item--danger';
                    }
                    ?>
                    <li class="<?php echo esc_attr($item_class); ?>" role="none">
                        <?php
                        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Sanitized via wp_kses; third-party plugins extend user_row_actions.
                        echo wp_kses((string) $link_html, $allowed);
                        ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php
}

/**
 * Editable roles keyed by slug with translated labels (for JS/UI).
 *
 * @param array<string, array<string, mixed>> $roles
 * @return array<string, string>
 */
function yooadmin_roles_labels_for_ui(array $roles): array
{
    $labels = [];
    foreach ($roles as $key => $role) {
        $labels[(string) $key] = yooadmin_translate_role_label((string) $key, is_array($role) ? $role : null);
    }

    return $labels;
}

class YOOAdmin_Users_Page
{

    private static ?YOOAdmin_Users_Page $instance = null;

    /** @var WP_Error|null Set when create-user POST fails before render. */
    private ?WP_Error $create_page_errors = null;

    public static function get_instance(): YOOAdmin_Users_Page
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('admin_menu', [$this, 'register_pages']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_init', [$this, 'maybe_redirect'], 30);
        add_action('wp_login', [$this, 'update_user_last_activity'], 10, 2);
        add_action('admin_init', [$this, 'update_current_user_activity']);
        add_action('wp_ajax_yooadmin_filter_users', [$this, 'ajax_filter_users']);
        add_action('wp_ajax_yooadmin_bulk_users_action', [$this, 'ajax_bulk_users_action']);
        add_action('wp_ajax_yooadmin_update_profile', [$this, 'ajax_update_profile']);
        add_action('wp_ajax_yooadmin_set_avatar_source', [$this, 'ajax_set_avatar_source']);
        add_action('wp_ajax_yooadmin_verify_email_change_2fa', [$this, 'ajax_verify_email_change_2fa']);
        add_action('wp_ajax_yooadmin_update_password', [$this, 'ajax_update_password']);
        add_action('wp_ajax_yooadmin_send_password_reset', [$this, 'ajax_send_password_reset']);
    }

    /**
     * Get editable roles with caching
     */
    private function get_editable_roles_cached(): array
    {
        $cache_key = 'yooadmin_editable_roles';
        $roles = wp_cache_get($cache_key, 'yooadmin_users');
        if ($roles === false) {
            $roles = get_editable_roles();
            wp_cache_set($cache_key, $roles, 'yooadmin_users', 300); // 5 minutes
        }
        return $roles;
    }

    /**
     * Whether the current user may assign $role.
     *
     * Uses the same get_editable_roles() check as wp_ensure_editable_role() (wp-admin/includes/ms.php)
     * without wp_die(), so AJAX handlers can return JSON errors. On single-site installs
     * wp_ensure_editable_role() is not loaded; this method is the portable equivalent.
     */
    private function current_user_can_assign_editable_role(string $role): bool
    {
        $role = sanitize_key($role);
        if ($role === '') {
            return false;
        }

        return isset(get_editable_roles()[ $role ]);
    }

    /**
     * Enforce editable-role rules on synchronous form requests (multisite only).
     *
     * wp_ensure_editable_role() is unavailable on single-site; AJAX must use
     * current_user_can_assign_editable_role() instead because wp_die() breaks JSON responses.
     *
     * @return WP_Error|null Error when the role cannot be assigned; null when allowed.
     */
    private function enforce_editable_role_on_form(string $role): ?WP_Error
    {
        if (!$this->current_user_can_assign_editable_role($role)) {
            return new WP_Error('forbidden', __('Sorry, you are not allowed to give users that role.', 'yooadmin'));
        }

        if (function_exists('yooadmin_ensure_editable_role') && !wp_doing_ajax()) {
            yooadmin_ensure_editable_role($role);
        }

        return null;
    }

    /**
     * Roles shown in the profile form — mirrors which options core would allow when editing oneself.
     *
     * @param WP_User $user Profile being edited.
     * @return array<string, array{name: string, capabilities: array<string, bool>}>
     */
    private function get_roles_for_profile_form(WP_User $user): array
    {
        $roles = $this->get_editable_roles_cached();
        if ((int) get_current_user_id() !== (int) $user->ID) {
            return $roles;
        }
        if (is_multisite() && current_user_can('manage_network_users')) {
            return $roles;
        }
        global $wp_roles;
        $filtered = [];
        foreach ($roles as $key => $data) {
            if (!isset($wp_roles->role_objects[$key])) {
                continue;
            }
            if ($wp_roles->role_objects[$key]->has_cap('promote_users')) {
                $filtered[$key] = $data;
            }
        }

        return $filtered;
    }

    /**
     * Whether the current user may assign $new_role to $target_user_id.
     */
    private function profile_new_role_allowed(int $target_user_id, string $new_role): bool
    {
        if ($new_role === '') {
            return true;
        }

        global $wp_roles;
        if (!isset($wp_roles->role_objects[ $new_role ])) {
            return false;
        }

        $potential_role = $wp_roles->role_objects[ $new_role ];

        if ((int) get_current_user_id() === (int) $target_user_id) {
            if (is_multisite() && current_user_can('manage_network_users')) {
                return true;
            }

            if ($potential_role && $potential_role->has_cap('promote_users')) {
                return false;
            }

            return true;
        }

        if (!current_user_can('promote_user', $target_user_id)) {
            return false;
        }

        return $this->current_user_can_assign_editable_role($new_role);
    }

    /**
     * Validate a submitted role for profile save/AJAX; returns empty string when change is not permitted.
     */
    private function sanitize_submitted_profile_role(WP_User $user, string $role): string
    {
        $role = sanitize_key($role);
        if ($role === '' || !$this->profile_show_role_field($user)) {
            return '';
        }

        if (!$this->current_user_can_assign_editable_role($role)) {
            return '';
        }

        if (!$this->profile_new_role_allowed((int) $user->ID, $role)) {
            return '';
        }

        return $role;
    }

    /**
     * @return string Empty when valid; otherwise an error message for the client.
     */
    private function validate_submitted_profile_role(WP_User $user, string $raw_role): string
    {
        $raw_role = sanitize_key($raw_role);

        if (!$this->profile_show_role_field($user)) {
            return $raw_role === '' ? '' : __('You are not allowed to change this user\'s role.', 'yooadmin');
        }

        if ($raw_role === '') {
            return __('Please select a role for this user.', 'yooadmin');
        }

        if (!$this->current_user_can_assign_editable_role($raw_role)) {
            return __('Invalid role selected.', 'yooadmin');
        }

        if (!$this->profile_new_role_allowed((int) $user->ID, $raw_role)) {
            if ((int) get_current_user_id() === (int) $user->ID) {
                return __('You are not allowed to change your role.', 'yooadmin');
            }

            return __('You are not allowed to assign this role.', 'yooadmin');
        }

        return '';
    }

    /**
     * Apply a validated role change (returns false when unchanged or not permitted).
     */
    private function apply_profile_role_change(WP_User $user, string $role): bool
    {
        $role = sanitize_key($role);
        if ($role === '' || !$this->profile_show_role_field($user)) {
            return false;
        }

        $role = $this->sanitize_submitted_profile_role($user, $role);
        if ($role === '') {
            return false;
        }

        $current_role = $user->roles ? (string) reset($user->roles) : '';
        if ($current_role === $role) {
            return false;
        }

        $user->set_role($role);

        return true;
    }

    /**
     * Build a profile save success message, including role changes when relevant.
     *
     * @param string[] $previous_roles
     * @param string[] $new_roles
     */
    private function profile_save_success_message(array $previous_roles, array $new_roles): string
    {
        $previous_role = $previous_roles !== [] ? (string) reset($previous_roles) : '';
        $new_role      = $new_roles !== [] ? (string) reset($new_roles) : '';

        if ($previous_role !== '' && $new_role !== '' && $previous_role !== $new_role) {
            return sprintf(
                /* translators: %s: translated role label */
                __('Profile updated. Role changed to %s.', 'yooadmin'),
                yooadmin_translate_role_label($new_role)
            );
        }

        return __('Profile updated successfully.', 'yooadmin');
    }

    /**
     * Resolve the profile page target user (defaults to the current user like profile.php).
     */
    private function profile_page_user_id(): int
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only user ID from URL.
        $user_id = isset($_GET['user_id']) ? absint($_GET['user_id']) : 0;

        return $user_id > 0 ? $user_id : get_current_user_id();
    }

    /**
     * Block profile page access unless the viewer may edit the target user (matches user-edit.php).
     */
    private function ensure_can_edit_profile_user(int $user_id): void
    {
        if ($user_id <= 0 || !get_userdata($user_id)) {
            wp_safe_redirect(
                add_query_arg('user_missing', '1', admin_url('admin.php?page=yooadmin-users'))
            );
            exit;
        }

        if (!current_user_can('edit_user', $user_id)) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }
    }

    private function can_create_new_users(): bool
    {
        return current_user_can('create_users');
    }

    private function can_add_existing_users(): bool
    {
        if (!is_multisite() || is_network_admin()) {
            return false;
        }
        if (!current_user_can('promote_users')) {
            return false;
        }
        if (wp_is_large_network('users')) {
            return false;
        }

        return (bool) apply_filters('show_network_site_users_add_existing_form', true); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
    }

    private function can_access_create_user_page(): bool
    {
        if (is_multisite()) {
            return $this->can_create_new_users() || $this->can_add_existing_users();
        }

        return $this->can_create_new_users();
    }

    private function users_add_button_label(): string
    {
        if ($this->can_create_new_users()) {
            return __('Add User', 'yooadmin');
        }
        if ($this->can_add_existing_users()) {
            return __('Add Existing User', 'yooadmin');
        }

        return '';
    }

    private function profile_show_role_field(WP_User $user): bool
    {
        if (is_network_admin()) {
            return false;
        }
        if ((int) get_current_user_id() === (int) $user->ID) {
            return false;
        }

        return current_user_can('promote_user', $user->ID);
    }

    /**
     * Whether the profile screen is the logged-in user editing their own account.
     */
    private function profile_is_own_page(WP_User $user): bool
    {
        return (int) get_current_user_id() === (int) $user->ID;
    }

    /**
     * Whether to show the admin "send password reset link" action (never on own profile).
     */
    private function profile_can_send_reset(WP_User $user): bool
    {
        if ($this->profile_is_own_page($user)) {
            return false;
        }

        if (!current_user_can('edit_user', $user->ID)) {
            return false;
        }

        return yooadmin_is_password_reset_allowed_for_user($user);
    }

    private function process_add_existing_user_submission(): ?WP_Error
    {
        check_admin_referer('add-user', '_wpnonce_add-user');

        if (!$this->can_add_existing_users()) {
            return new WP_Error('forbidden', __('Sorry, you are not allowed to add users to this site.', 'yooadmin'));
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $user_email = isset($_POST['email']) ? trim((string) wp_unslash($_POST['email'])) : '';
        $user_details = null;

        if ($user_email !== '' && str_contains($user_email, '@')) {
            $user_details = get_user_by('email', sanitize_email($user_email));
        } elseif ($user_email !== '' && current_user_can('manage_network_users')) {
            $user_details = get_user_by('login', sanitize_user($user_email, true));
        } else {
            return new WP_Error('enter_email', __('Please enter a valid email address.', 'yooadmin'));
        }

        if (!$user_details) {
            return new WP_Error('does_not_exist', __('The email address does not belong to an existing user on this network.', 'yooadmin'));
        }

        if (!current_user_can('promote_user', $user_details->ID)) {
            return new WP_Error('forbidden', __('Sorry, you are not allowed to add this user to the site.', 'yooadmin'));
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $role = isset($_POST['role']) ? sanitize_key(wp_unslash((string) $_POST['role'])) : get_option('default_role');
        $role_error = $this->enforce_editable_role_on_form($role);
        if ($role_error instanceof WP_Error) {
            return $role_error;
        }

        $blog_id = get_current_blog_id();
        if (is_user_member_of_blog($user_details->ID, $blog_id)) {
            return new WP_Error('addexisting', __('This user is already a member of this site.', 'yooadmin'));
        }

        $redirect_base = admin_url('admin.php?page=yooadmin-users-new');

        if (isset($_POST['noconfirmation']) && current_user_can('manage_network_users')) {
            $result = add_existing_user_to_blog([
                'user_id' => $user_details->ID,
                'role'    => $role,
            ]);
            if (is_wp_error($result)) {
                return new WP_Error('could_not_add', __('Could not add user to the site.', 'yooadmin'));
            }

            wp_safe_redirect(add_query_arg([
                'update'  => 'addnoconfirmation',
                'user_id' => $user_details->ID,
            ], $redirect_base));
            exit;
        }

        $newuser_key = wp_generate_password(20, false);
        add_option(
            'new_user_' . $newuser_key,
            [
                'user_id' => $user_details->ID,
                'email'   => $user_details->user_email,
                'role'    => $role,
            ]
        );

        $roles = get_editable_roles();
        $role_data = $roles[$role] ?? ['name' => $role];

        do_action('invite_user', $user_details->ID, $role_data, $newuser_key); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.

        $switched_locale = yooadmin_switch_to_user_locale($user_details->ID);

        if ('' !== get_option('blogname')) {
            $site_title = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
        } else {
            $site_title = wp_parse_url(home_url(), PHP_URL_HOST);
        }

        /* translators: 1: Site title, 2: Site URL, 3: User role, 4: Confirmation URL. */
        $message = __(
            'Hi,

You\'ve been invited to join \'%1$s\' at
%2$s with the role of %3$s.

Please click the following link to confirm the invite:
%4$s',
            'yooadmin'
        );

        $new_user_email = [
            'to'      => $user_details->user_email,
            'subject' => sprintf(
                /* translators: %s: Site title. */
                __('[%s] Joining Confirmation', 'yooadmin'),
                $site_title
            ),
            'message' => sprintf(
                $message,
                get_option('blogname'),
                home_url(),
                wp_specialchars_decode(translate_user_role($role_data['name'])),
                home_url("/newbloguser/$newuser_key/")
            ),
            'headers' => '',
        ];

        $new_user_email = apply_filters('invited_user_email', $new_user_email, $user_details->ID, $role_data, $newuser_key); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.

        wp_mail(
            $new_user_email['to'],
            $new_user_email['subject'],
            $new_user_email['message'],
            $new_user_email['headers']
        );

        if ($switched_locale) {
            restore_previous_locale();
        }

        wp_safe_redirect(add_query_arg('update', 'add', $redirect_base));
        exit;
    }

    public function register_pages(): void
    {
        $parent = yooadmin_dashboard_slug();

        $hook_users = add_submenu_page(
            '',
            __('Users', 'yooadmin'),
            __('Users', 'yooadmin'),
            'list_users',
            'yooadmin-users',
        [$this, 'render_list_page']
        );
        if ($hook_users) {
            add_action("load-{$hook_users}", function () {
                global $title;
                $title = __('Users', 'yooadmin');

                $opts = (array)get_option('yooadmin_options', []);
                $enabled = !empty($opts['users_redirect']);
                if (!$enabled) {
                    wp_safe_redirect(admin_url('users.php'));
                    exit;
                }
            });
        }

        $hook_new = add_submenu_page(
            '',
            __('Add User', 'yooadmin'),
            __('Add User', 'yooadmin'),
            'read',
            'yooadmin-users-new',
        [$this, 'render_create_page']
        );
        if ($hook_new) {
            add_action("load-{$hook_new}", function () {
                global $title;
                if (!$this->can_access_create_user_page()) {
                    wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
                }
                $title = $this->can_create_new_users()
                    ? __('Add User', 'yooadmin')
                    : __('Add Existing User', 'yooadmin');

                $opts = (array)get_option('yooadmin_options', []);
                $enabled = !empty($opts['users_redirect']);
                if (!$enabled) {
                    wp_safe_redirect(admin_url('user-new.php'));
                    exit;
                }

                $this->maybe_handle_create_page_post();
            });
        }

        $hook_profile = add_submenu_page(
            '',
            __('User Profile', 'yooadmin'),
            __('User Profile', 'yooadmin'),
            'read',
            'yooadmin-user',
        [$this, 'render_profile_page']
        );
        if ($hook_profile) {
            add_action("load-{$hook_profile}", function () {
                global $title;
                $user_id = $this->profile_page_user_id();
                $title = ($user_id === get_current_user_id())
                    ? __('My Profile', 'yooadmin')
                    : __('User Profile', 'yooadmin');

                $this->ensure_can_edit_profile_user($user_id);

                $opts = (array)get_option('yooadmin_options', []);
                $enabled = !empty($opts['users_redirect']);
                if (!$enabled) {
                    if ($user_id === get_current_user_id()) {
                        $redirect = admin_url('profile.php');
                        if (function_exists('yooadmin_profile_parse_email_confirmation_hash')) {
                            $confirm_hash = yooadmin_profile_parse_email_confirmation_hash();
                            if ($confirm_hash !== '') {
                                $redirect = add_query_arg('newuseremail', $confirm_hash, $redirect);
                            }
                        }
                        wp_safe_redirect($redirect);
                    } else {
                        wp_safe_redirect(admin_url('user-edit.php?user_id=' . $user_id));
                    }
                    exit;
                }
            });
        }
    }

    public function enqueue_assets(string $hook): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page detection for asset loading.
        $page = isset($_REQUEST['page']) ? sanitize_key(wp_unslash((string) $_REQUEST['page'])) : '';
        if (!in_array($page, ['yooadmin-users', 'yooadmin-users-new', 'yooadmin-user'], true)) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir = plugin_dir_path($base_file);
        $base_url = plugin_dir_url($base_file);

        if (function_exists('yooadmin_enqueue_list_screen_ui_assets')) {
            yooadmin_enqueue_list_screen_ui_assets();
        }

        $style_rel = 'assets/css/admin/users-page.css';
        $style_abs = $base_dir . $style_rel;
        $users_css_deps = ['yooadmin-shell'];
        if (wp_style_is('yooadmin-list-screens-ui', 'registered') || wp_style_is('yooadmin-list-screens-ui', 'enqueued')) {
            $users_css_deps[] = 'yooadmin-list-screens-ui';
        }
        if (wp_style_is('yooadmin-yoo-buttons', 'registered')) {
            wp_enqueue_style('yooadmin-yoo-buttons');
            $users_css_deps[] = 'yooadmin-yoo-buttons';
        }

        if (file_exists($style_abs)) {
            wp_enqueue_style('yooadmin-users', $base_url . $style_rel, $users_css_deps, filemtime($style_abs));
        }

        wp_enqueue_script('password-strength-meter');
        wp_enqueue_script('zxcvbn-async');

        $script_rel = 'assets/js/admin/users-page.js';
        $script_abs = $base_dir . $script_rel;
        if (file_exists($script_abs)) {
            $users_js_deps = ['jquery', 'password-strength-meter'];
            if (wp_script_is('yooadmin-yp-ui-select', 'registered')) {
                $users_js_deps[] = 'yooadmin-yp-ui-select';
            }
            wp_enqueue_script('yooadmin-users', $base_url . $script_rel, $users_js_deps, filemtime($script_abs), true);
            wp_localize_script('yooadmin-users', 'yooadmUsers', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('yooadmin_users'),
                'i18nWeak' => __('Strength: Weak', 'yooadmin'),
                'i18nMedium' => __('Strength: Medium', 'yooadmin'),
                'i18nStrong' => __('Strength: Strong', 'yooadmin'),
                'i18nEmpty' => __('Strength: Empty', 'yooadmin'),
                'i18n' => [
                    'showStatistics' => __('Show Statistics', 'yooadmin'),
                    'hideStatistics' => __('Hide Statistics', 'yooadmin'),
                ],
            ]);
        }

        // Enqueue profile page script
        if ($page === 'yooadmin-user') {
            $toast_css_rel = 'assets/css/admin/toast-notifications.css';
            $toast_css_abs = $base_dir . $toast_css_rel;
            if (file_exists($toast_css_abs)) {
                wp_enqueue_style('yooadmin-toast-notifications', $base_url . $toast_css_rel, [], filemtime($toast_css_abs));
            }

            $toast_js_rel = 'assets/js/admin/toast-notifications.js';
            $toast_js_abs = $base_dir . $toast_js_rel;
            if (file_exists($toast_js_abs)) {
                $toast_deps = ['jquery'];
                if (wp_script_is('yooadmin-notice-classifier', 'registered') || wp_script_is('yooadmin-notice-classifier', 'enqueued')) {
                    $toast_deps[] = 'yooadmin-notice-classifier';
                }
                wp_enqueue_script('yooadmin-toast-notifications', $base_url . $toast_js_rel, $toast_deps, filemtime($toast_js_abs), true);
            }

            // Cropper.js v2 (UMD exposes `Cropper.default` as the class; load before avatar script)
            $cropper_rel = 'assets/vendor/cropperjs/cropper.min.js';
            $cropper_abs = $base_dir . $cropper_rel;
            if (file_exists($cropper_abs)) {
                wp_enqueue_script(
                    'yooadmin-cropperjs',
                    $base_url . $cropper_rel,
                    [],
                    '2.1.0',
                    true
                );
            }

            $profile_user_id = isset($_GET['user_id']) ? absint(wp_unslash((string) $_GET['user_id'])) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if ($profile_user_id <= 0) {
                $profile_user_id = get_current_user_id();
            }
            $profile_can_edit_avatar = $profile_user_id > 0 && current_user_can('edit_user', $profile_user_id);

            // Avatar upload assets when the editor can change photo source / upload.
            $avatar_css_rel = 'assets/css/admin/user-avatar-upload.css';
            $avatar_css_abs = $base_dir . $avatar_css_rel;
            if ($profile_can_edit_avatar && file_exists($avatar_css_abs)) {
                wp_enqueue_style('yooadmin-avatar-upload', $base_url . $avatar_css_rel, [], filemtime($avatar_css_abs));
            }

            $avatar_js_rel = 'assets/js/admin/user-avatar-upload.js';
            $avatar_js_abs = $base_dir . $avatar_js_rel;
            if ($profile_can_edit_avatar && file_exists($avatar_js_abs)) {
                $avatar_deps = ['jquery'];
                if (file_exists($toast_js_abs)) {
                    $avatar_deps[] = 'yooadmin-toast-notifications';
                }
                if (file_exists($cropper_abs)) {
                    $avatar_deps[] = 'yooadmin-cropperjs';
                }
                wp_enqueue_script(
                    'yooadmin-avatar-upload',
                    $base_url . $avatar_js_rel,
                    $avatar_deps,
                    filemtime($avatar_js_abs),
                    true
                );
                wp_localize_script(
                    'yooadmin-avatar-upload',
                    'yooadminAvatarUpload',
                    [
                        'i18n' => [
                            'save'               => __('Save', 'yooadmin'),
                            'saving'             => __('Saving…', 'yooadmin'),
                            'saveSuccess'        => __('Profile photo updated successfully.', 'yooadmin'),
                            'saveFailed'         => __('Failed to upload avatar.', 'yooadmin'),
                            'processFailed'      => __('Could not process image. Please try again.', 'yooadmin'),
                            'errorGeneric'       => __('An error occurred. Please try again.', 'yooadmin'),
                            'cropperLoadFailed'  => __('Cropper failed to load. Please refresh the page.', 'yooadmin'),
                            'invalidImage'       => __('Please select an image file.', 'yooadmin'),
                            'fileTooLarge'       => __('File size must be less than 5MB.', 'yooadmin'),
                            'deleteSuccess'      => __('Profile photo removed.', 'yooadmin'),
                            'deleteFailed'       => __('Failed to delete avatar.', 'yooadmin'),
                        ],
                    ]
                );
            }

            if (function_exists('yooadmin_profile_enqueue_plugin_section_assets')) {
                yooadmin_profile_enqueue_plugin_section_assets();
            }

            $profile_user_id = isset($_GET['user_id']) ? absint(wp_unslash((string) $_GET['user_id'])) : get_current_user_id(); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $profile_user = $profile_user_id > 0 ? get_userdata($profile_user_id) : false;

            if (
                $profile_user_id > 0
                && function_exists('yooadmin_profile_enqueue_photo_plugin_assets')
            ) {
                yooadmin_profile_enqueue_photo_plugin_assets($profile_user_id);
            }

            $profile_script_rel = 'assets/js/admin/user-profile.js';
            $profile_script_abs = $base_dir . $profile_script_rel;
            if (file_exists($profile_script_abs)) {
                $profile_script_deps = ['jquery', 'yooadmin-users', 'yooadmin-toast-notifications'];
                if (wp_script_is('sua', 'registered')) {
                    $profile_script_deps[] = 'sua';
                }
                if (wp_script_is('media-views', 'registered')) {
                    $profile_script_deps[] = 'media-views';
                }
                wp_enqueue_script(
                    'yooadmin-user-profile',
                    $base_url . $profile_script_rel,
                    $profile_script_deps,
                    filemtime($profile_script_abs),
                    true
                );
                $profile_roles = ($profile_user instanceof WP_User)
                    ? $this->get_roles_for_profile_form($profile_user)
                    : [];
                $roles_array = yooadmin_roles_labels_for_ui($profile_roles);
                $profile_requires_2fa_email = ($profile_user instanceof WP_User)
                    && $this->profile_is_own_page($profile_user)
                    && function_exists('yooadmin_profile_user_has_2fa_for_email_change')
                    && yooadmin_profile_user_has_2fa_for_email_change($profile_user->ID);

                $avatar_source_previews = [];
                if ($profile_user instanceof WP_User) {
                    $avatar_choice_keys = function_exists('yooadmin_profile_avatar_source_choices')
                        ? array_keys(yooadmin_profile_avatar_source_choices())
                        : ['yooadmin', 'gravatar'];
                    foreach ($avatar_choice_keys as $avatar_choice_key) {
                        $avatar_source_previews[$avatar_choice_key] = [
                            'url' => function_exists('yooadmin_profile_avatar_url_for_source')
                                ? yooadmin_profile_avatar_url_for_source($profile_user->ID, $avatar_choice_key, 110)
                                : get_avatar_url($profile_user->ID, ['size' => 110]),
                            'is_placeholder' => function_exists('yooadmin_profile_avatar_is_placeholder_for_source')
                                ? yooadmin_profile_avatar_is_placeholder_for_source($profile_user->ID, $avatar_choice_key, 110)
                                : false,
                            'has_custom_avatar' => $avatar_choice_key === 'yooadmin'
                                && function_exists('yooadmin_user_has_custom_avatar')
                                && yooadmin_user_has_custom_avatar($profile_user->ID),
                        ];
                    }
                }

                wp_localize_script('yooadmin-user-profile', 'yooadmProfile', [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'roles' => $roles_array,
                    'showRoleField' => ($profile_user instanceof WP_User) && $this->profile_show_role_field($profile_user),
                    'nonce' => wp_create_nonce('yooadmin_users'),
                    'requires2faForEmail' => $profile_requires_2fa_email,
                    'i18nSaving' => __('Saving...', 'yooadmin'),
                    'i18nPasswordBoth' => __('Please fill in both password fields.', 'yooadmin'),
                    'i18nPasswordMismatch' => __('The passwords do not match.', 'yooadmin'),
                    'i18nPasswordLength' => __('Password must be at least 8 characters long.', 'yooadmin'),
                    'i18n2faRequired' => __('Enter your two-factor code to confirm this email change.', 'yooadmin'),
                    'i18nPasswordRequired' => __('Enter your current password to confirm this email change.', 'yooadmin'),
                    'i18n2faVerifying' => __('Verifying…', 'yooadmin'),
                    'i18n2faVerified' => __('Identity verified for this email change.', 'yooadmin'),
                    'i18n2faInvalid' => __('Invalid verification code. Please try again.', 'yooadmin'),
                    'i18n2faIncomplete' => __('Enter the full 6-digit code.', 'yooadmin'),
                    'i18n2faRevalidated' => __('Identity confirmed. You can change your two-factor settings now.', 'yooadmin'),
                    'i18nEmailUpdated' => __('Your email address has been updated.', 'yooadmin'),
                    'i18nEmailError' => __('That email confirmation link is invalid or has expired.', 'yooadmin'),
                    'i18nEmailDismissed' => __('Pending email change cancelled.', 'yooadmin'),
                    'totpDigits' => 6,
                    'avatarSourceHints' => [
                        'gravatar' => __('Gravatar', 'yooadmin'),
                        'plugins'  => __('Plugin photo', 'yooadmin'),
                    ],
                    'avatarSourcePreviews' => $avatar_source_previews,
                    'hasYooadminPhoto' => ($profile_user instanceof WP_User)
                        && function_exists('yooadmin_user_has_custom_avatar')
                        && yooadmin_user_has_custom_avatar($profile_user->ID),
                    'i18nPluginsPending' => __('Save changes to load profile photo options from your installed plugins.', 'yooadmin'),
                    'pluginAvatarDefaultUrl' => ($profile_user instanceof WP_User && function_exists('yooadmin_profile_plugin_fallback_avatar_url'))
                        ? yooadmin_profile_plugin_fallback_avatar_url($profile_user->ID, 110)
                        : '',
                    'profileUserId' => $profile_user_id,
                    'setAvatarSourceNonce' => ($profile_user instanceof WP_User)
                        ? wp_create_nonce('yooadmin_update_user_' . $profile_user->ID)
                        : '',
                ]);
            }
        }

        // Enqueue bulk actions script
        $bulk_script_rel = 'assets/js/admin/users-bulk-actions.js';
        $bulk_script_abs = $base_dir . $bulk_script_rel;
        if (file_exists($bulk_script_abs)) {
            wp_enqueue_script('yooadmin-users-bulk', $base_url . $bulk_script_rel, ['jquery'], filemtime($bulk_script_abs), true);
            $roles = $this->get_editable_roles_cached();
            $roles_array = yooadmin_roles_labels_for_ui($roles);
            wp_localize_script('yooadmin-users-bulk', 'yooadmUsersBulk', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('yooadmin_bulk_users'),
                'currentUserId' => get_current_user_id(),
                'adminCount' => (function (): int {
                    $admin_query = new \WP_User_Query([
                        'role' => 'administrator',
                        'number' => 1,
                        'fields' => 'ID',
                    ]);
                    return (int) $admin_query->get_total();
                })(),
                'roles' => $roles_array,
                'i18n' => [
                    'selected' => __('selected', 'yooadmin'),
                    'delete' => __('Delete', 'yooadmin'),
                    'deletePermanently' => __('Delete Permanently', 'yooadmin'),
                    // translators: %d: number of users
                    'deleteConfirm' => __('Are you sure you want to delete <strong>%d</strong> user(s)? This action cannot be undone.', 'yooadmin'),
                    'changeRole' => __('Change Role', 'yooadmin'),
                    // translators: %d: number of users
                    'changeRoleConfirm' => __('Change role for <strong>%d</strong> user(s)?', 'yooadmin'),
                    'selectRole' => __('Select Role', 'yooadmin'),
                    'selectNewRole' => __('Select the new role for the selected users:', 'yooadmin'),
                    'cancel' => __('Cancel', 'yooadmin'),
                    'apply' => __('Apply', 'yooadmin'),
                    'processing' => __('Processing...', 'yooadmin'),
                    'success' => __('Operation completed successfully.', 'yooadmin'),
                    'error' => __('An error occurred. Please try again.', 'yooadmin'),
                    'cannotDeleteSelf' => __('You cannot delete your own account.', 'yooadmin'),
                    'cannotDeleteLastAdmin' => __('You cannot delete the last administrator. At least one administrator must remain.', 'yooadmin'),
                    // translators: %s: user display name
                    'deleteSingleConfirm' => __('Are you sure you want to delete <strong>%s</strong>? This action cannot be undone.', 'yooadmin'),
                    // translators: %s: user display name
                    'removeSingleConfirm' => __('Are you sure you want to remove <strong>%s</strong> from this site?', 'yooadmin'),
                    'remove' => __('Remove', 'yooadmin'),
                    'removePermanently' => __('Remove from site', 'yooadmin'),
                ],
            ]);
        }
    }

    public function maybe_redirect(): void
    {
        if (
            function_exists('yooadmin_is_network_admin_request')
            && yooadmin_is_network_admin_request()
        ) {
            return;
        }

        global $pagenow;

        $targets = ['users.php', 'user-new.php', 'user-edit.php', 'profile.php'];
        if (!in_array($pagenow, $targets, true)) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect check.
        if (isset($_GET['page']) && in_array(sanitize_key(wp_unslash($_GET['page'])), ['yooadmin-users', 'yooadmin-users-new', 'yooadmin-user'], true)) {
            return;
        }

        if (!$this->is_redirect_enabled()) {
            return;
        }

        if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return;
        }

        switch ($pagenow) {
            case 'users.php':
                $redirect = admin_url('admin.php?page=yooadmin-users');
                // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Preserving read-only GET filters for redirect.
                if (!empty($_GET['role'])) {
                    $redirect = add_query_arg('role', sanitize_key(wp_unslash($_GET['role'])), $redirect);
                }
                if (!empty($_GET['s'])) {
                    $redirect = add_query_arg('s', sanitize_text_field(wp_unslash($_GET['s'])), $redirect);
                }
                // phpcs:enable WordPress.Security.NonceVerification.Recommended
                break;

            case 'user-new.php':
                $redirect = admin_url('admin.php?page=yooadmin-users-new');
                break;

            case 'user-edit.php':
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only user ID from URL for redirect.
                $user_id = isset($_GET['user_id']) ? absint($_GET['user_id']) : 0;
                if (!$user_id) {
                    return;
                }
                $redirect = add_query_arg([
                    'page' => 'yooadmin-user',
                    'user_id' => $user_id,
                ], admin_url('admin.php'));
                break;

            case 'profile.php':
                $redirect = add_query_arg([
                    'page' => 'yooadmin-user',
                    'user_id' => get_current_user_id(),
                ], admin_url('admin.php'));
                if (function_exists('yooadmin_profile_parse_email_confirmation_hash')) {
                    $confirm_hash = yooadmin_profile_parse_email_confirmation_hash();
                    if ($confirm_hash !== '') {
                        $redirect = add_query_arg('newuseremail', $confirm_hash, $redirect);
                    }
                }
                break;

            default:
                return;
        }

        wp_safe_redirect($redirect);
        exit;
    }

    public function render_list_page(): void
    {
        global $title;
        $title = __('Users', 'yooadmin');
        if (!current_user_can('list_users')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        $per_page = max(5, (int)apply_filters('yooadmin_users_per_page', 12));
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only pagination/search/filter.
        $paged = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search from URL.
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only role filter from URL.
        $role = isset($_GET['role']) ? sanitize_key(wp_unslash($_GET['role'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only sort from URL.
        $sort = isset($_GET['sort']) ? sanitize_key(wp_unslash($_GET['sort'])) : 'recent';

        $args = [
            'number' => $per_page,
            'offset' => ($paged - 1) * $per_page,
            'orderby' => 'registered',
            'order' => 'DESC',
        ];
        $args = $this->apply_users_sort_to_query($args, $sort);

        if ($search !== '') {
            $args['search'] = '*' . esc_attr($search) . '*';
            $args['search_columns'] = ['user_login', 'user_email', 'user_nicename', 'display_name'];
        }

        if ($role !== '') {
            $args['role'] = $role;
        }

        $args = apply_filters('yooadmin_users_query_args', $args, [
            'paged' => $paged,
            'search' => $search,
            'role' => $role,
            'sort' => $sort,
        ]);

        $user_query = new WP_User_Query($args);
        $users = $user_query->get_results();
        if (!empty($args['yooadmin_users_sort_role'])) {
            $users = $this->sort_users_by_role($users);
        }
        $total = (int)$user_query->get_total();
        $total_pages = $per_page > 0 ? (int)ceil($total / $per_page) : 1;

        // Cache roles and user counts (they don't change often)
        $roles = $this->get_editable_roles_cached();

        $count_users_cache_key = 'yooadmin_count_users';
        $count_users = wp_cache_get($count_users_cache_key, 'yooadmin_users');
        if ($count_users === false) {
            $count_users = count_users();
            wp_cache_set($count_users_cache_key, $count_users, 'yooadmin_users', 300); // 5 minutes
        }

        $total_users = isset($count_users['total_users']) ? (int)$count_users['total_users'] : $total;
        $role_counts = isset($count_users['avail_roles']) && is_array($count_users['avail_roles']) ? $count_users['avail_roles'] : [];
        $active_roles = array_filter($role_counts, static function ($count) {
            return (int)$count > 0;
        });

        $recent_query = new WP_User_Query([
            'fields' => 'ids',
            'number' => 1,
            'date_query' => [
                [
                    'after' => gmdate('Y-m-d', strtotime('-7 days')),
                    'column' => 'user_registered',
                ],
            ],
        ]);
        $recent_count = (int)$recent_query->get_total();

        // Count online users (active in last 15 minutes)
        $online_count = $this->count_online_users();

        $stats = [
            'total' => $total_users,
            'new_week' => $recent_count,
            'administrators' => isset($role_counts['administrator']) ? (int)$role_counts['administrator'] : 0,
            'active_roles' => count($active_roles),
            'online' => $online_count,
        ];

        $can_show_add_button = $this->can_access_create_user_page();
        $add_button_label = $this->users_add_button_label();

        $template = plugin_dir_path(yooadmin_base_file()) . 'templates/yoopixel/admin/pages/users/index.php';
        if (file_exists($template)) {
            $stats = $stats;
            $role_counts = $role_counts;
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Users', 'yooadmin') . '</h1>';
        if ($users) {
            echo '<ul>';
            foreach ($users as $user) {
                printf('<li><a href="%s">%s</a> &mdash; %s</li>',
                    esc_url($this->profile_url($user->ID)),
                    esc_html($user->display_name ?: $user->user_login),
                    esc_html($user->user_email)
                );
            }
            echo '</ul>';
        }
        else {
            esc_html_e('No users found.', 'yooadmin');
        }
        echo '</div>';
    }

    /**
     * Handle create-user POST before admin headers (redirect must run pre-output).
     */
    private function maybe_handle_create_page_post(): void
    {
        if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Page slug from POST body on this screen.
        $page = isset($_REQUEST['page']) ? sanitize_key(wp_unslash((string) $_REQUEST['page'])) : '';
        if ($page !== 'yooadmin-users-new') {
            return;
        }

        $can_create_new = $this->can_create_new_users();
        $can_add_existing = $this->can_add_existing_users();

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified per action below.
        $action = isset($_POST['action']) ? sanitize_key(wp_unslash((string) $_POST['action'])) : 'createuser';

        if ($action === 'adduser' && $can_add_existing) {
            $add_error = $this->process_add_existing_user_submission();
            if ($add_error instanceof WP_Error) {
                $this->create_page_errors = $add_error;
            }
            return;
        }

        if (!$can_create_new) {
            $this->create_page_errors = new WP_Error(
                'forbidden',
                __('Sorry, you are not allowed to create users.', 'yooadmin')
            );
            return;
        }

        check_admin_referer('yooadmin_create_user');

        $errors = new WP_Error();
        $username = isset($_POST['user_login']) ? sanitize_user(wp_unslash($_POST['user_login']), true) : '';
        $email = isset($_POST['user_email']) ? sanitize_email(wp_unslash($_POST['user_email'])) : '';
        $first = isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '';
        $last = isset($_POST['last_name']) ? sanitize_text_field(wp_unslash($_POST['last_name'])) : '';
        $role = isset($_POST['role']) ? sanitize_key(wp_unslash($_POST['role'])) : 'subscriber';
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords must not be sanitized to preserve special characters.
        $password = isset($_POST['user_pass']) ? wp_unslash($_POST['user_pass']) : '';

        if ($username === '' || username_exists($username)) {
            $errors->add('user_login', __('Please choose a unique username.', 'yooadmin'));
        }

        if (!is_email($email) || email_exists($email)) {
            $errors->add('user_email', __('Please provide a unique, valid email address.', 'yooadmin'));
        }

        $editable_roles = $this->get_editable_roles_cached();
        if (!isset($editable_roles[$role])) {
            $role = 'subscriber';
        }

        if ($errors->has_errors()) {
            $this->create_page_errors = $errors;
            return;
        }

        $send_password = false;
        if ($password === '') {
            $password = wp_generate_password(12, true);
            $send_password = true;
        }

        $user_id = wp_insert_user([
            'user_login' => $username,
            'user_pass' => $password,
            'user_email' => $email,
            'first_name' => $first,
            'last_name' => $last,
            'display_name' => trim($first . ' ' . $last) ?: $username,
            'role' => $role,
        ]);

        if (is_wp_error($user_id)) {
            $this->create_page_errors = $user_id;
            return;
        }

        if (!empty($_POST['send_notification'])) {
            wp_new_user_notification($user_id, null, 'user');
        } elseif ($send_password) {
            wp_new_user_notification($user_id, null, 'user');
        }

        $redirect = add_query_arg([
            'page' => 'yooadmin-user',
            'user_id' => $user_id,
            'created' => 1,
        ], admin_url('admin.php'));
        wp_safe_redirect($redirect);
        exit;
    }

    public function render_create_page(): void
    {
        global $title;
        if (!$this->can_access_create_user_page()) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        $can_create_new = $this->can_create_new_users();
        $can_add_existing = $this->can_add_existing_users();
        $do_both = $can_create_new && $can_add_existing;
        $title = $can_create_new ? __('Add User', 'yooadmin') : __('Add Existing User', 'yooadmin');

        $errors = $this->create_page_errors instanceof WP_Error ? $this->create_page_errors : new WP_Error();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status flag.
        $update = isset($_GET['update']) ? sanitize_key(wp_unslash((string) $_GET['update'])) : '';

        $roles = $this->get_editable_roles_cached();
        $default_role = get_option('default_role');
        $template = plugin_dir_path(yooadmin_base_file()) . 'templates/yoopixel/admin/pages/users/create.php';
        if (file_exists($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Add User', 'yooadmin') . '</h1></div>';
    }

    public function render_profile_page(): void
    {
        $user_id = $this->profile_page_user_id();
        $this->ensure_can_edit_profile_user($user_id);
        $user = get_userdata($user_id);

        if ($user instanceof WP_User && $user_id === get_current_user_id()) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Dismiss link includes nonce.
            if (!empty($_GET['dismiss']) && (string) $_GET['dismiss'] === $user_id . '_new_email') {
                check_admin_referer('dismiss-' . $user_id . '_new_email');
                if (function_exists('yooadmin_profile_dismiss_email_change')) {
                    yooadmin_profile_dismiss_email_change($user_id);
                }
                $redirect = add_query_arg(
                    'email_dismissed',
                    '1',
                    function_exists('yooadmin_profile_page_url') ? yooadmin_profile_page_url($user_id) : admin_url('admin.php?page=yooadmin-user')
                );
                wp_safe_redirect($redirect);
                exit;
            }
        }

        $errors = new WP_Error();
        $updated = false;
        $email_pending_notice = '';

        if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = isset($_POST['action']) ? sanitize_key(wp_unslash($_POST['action'])) : '';

            // Handle Application Password creation
            if ($action === 'create_app_password' && function_exists('wp_is_application_passwords_available') && wp_is_application_passwords_available()) {
                check_admin_referer('create_app_pass_' . $user_id, '_wpnonce');
                $app_name = isset($_POST['app_name']) ? sanitize_text_field(wp_unslash($_POST['app_name'])) : '';
                if (!empty($app_name)) {
                    $new_password = WP_Application_Passwords::create_new_application_password($user_id, ['name' => $app_name]);
                    if (is_wp_error($new_password)) {
                        $errors = $new_password;
                    }
                    else {
                        // Store the new password to display it once
                        set_transient('yooadmin_new_app_password_' . $user_id, [
                            'password' => $new_password[0],
                            'name' => $app_name,
                        ], 60);
                        $updated = true;
                    }
                }
            }
            // Handle Application Password deletion
            elseif ($action === 'delete_app_password' && function_exists('wp_is_application_passwords_available') && wp_is_application_passwords_available()) {
                $app_uuid = isset($_POST['app_password_uuid']) ? sanitize_text_field(wp_unslash($_POST['app_password_uuid'])) : '';
                if (!empty($app_uuid)) {
                    check_admin_referer('delete_app_pass_' . $app_uuid, '_wpnonce');
                    $deleted = WP_Application_Passwords::delete_application_password($user_id, $app_uuid);
                    if ($deleted) {
                        $updated = true;
                    }
                }
            }
            // Handle Session revocation
            elseif ($action === 'revoke_session') {
                $session_token = isset($_POST['session_token']) ? sanitize_text_field(wp_unslash($_POST['session_token'])) : '';
                if (!empty($session_token)) {
                    check_admin_referer('revoke_session_' . $session_token, '_wpnonce');
                    $manager = WP_Session_Tokens::get_instance($user_id);
                    $manager->destroy($session_token);
                    $updated = true;
                }
            }
            // Third-party profile sections (Two-Factor, etc.)
            elseif (
                $action === 'save_profile_plugin_sections'
                && function_exists('yooadmin_profile_save_plugin_sections')
            ) {
                check_admin_referer('yooadmin_profile_plugin_sections_' . $user_id, 'yooadmin_profile_plugin_sections_nonce');
                $is_own_profile = $this->profile_is_own_page($user);
                yooadmin_profile_save_plugin_sections($user_id, $is_own_profile);

                $redirect_args = [
                    'page'           => 'yooadmin-user',
                    'profile_tab'    => 'security',
                    'security_saved' => '1',
                ];
                if (!$is_own_profile) {
                    $redirect_args['user_id'] = $user_id;
                }

                $redirect_errors = get_transient('yooadmin_native_2fa_profile_errors_' . $user_id);
                if (is_array($redirect_errors) && $redirect_errors !== []) {
                    $redirect_args['security_error'] = '1';
                }

                wp_safe_redirect(add_query_arg($redirect_args, admin_url('admin.php')));
                exit;
            }
            // Handle profile update
            else {
                check_admin_referer('yooadmin_update_user_' . $user_id);

                $raw_role = isset($_POST['role']) ? sanitize_key(wp_unslash($_POST['role'])) : '';
                $role_error = $this->validate_submitted_profile_role($user, $raw_role);
                $previous_roles = $user->roles;
                $locale_raw = isset($_POST['locale']) ? sanitize_text_field(wp_unslash($_POST['locale'])) : null;
                $is_own_profile = $this->profile_is_own_page($user);

                // Handle password change
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords must not be sanitized to preserve special characters.
                $pass1 = isset($_POST['pass1']) ? wp_unslash($_POST['pass1']) : '';
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords must not be sanitized to preserve special characters.
                $pass2 = isset($_POST['pass2']) ? wp_unslash($_POST['pass2']) : '';
                $pass_changed = false;

                if (!empty($pass1)) {
                    if ($pass1 !== $pass2) {
                        $errors->add('pass', __('The passwords do not match.', 'yooadmin'));
                    }
                    elseif (strlen($pass1) < 8) {
                        $errors->add('pass', __('Password must be at least 8 characters long.', 'yooadmin'));
                    }
                    else {
                        $pass_changed = true;
                    }
                }

                if ($role_error !== '') {
                    $errors->add('role', $role_error);
                }

                if ($pass_changed && !$errors->has_errors()) {
                    $pass_result = wp_update_user([
                        'ID'        => $user_id,
                        'user_pass' => $pass1,
                    ]);
                    if (is_wp_error($pass_result)) {
                        $errors = $pass_result;
                    }
                }

                if (!$errors->has_errors() && function_exists('yooadmin_profile_apply_account_fields')) {
                    $account_fields = [
                        'first_name'   => isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '',
                        'last_name'    => isset($_POST['last_name']) ? sanitize_text_field(wp_unslash($_POST['last_name'])) : '',
                        'display_name' => isset($_POST['display_name']) ? sanitize_text_field(wp_unslash($_POST['display_name'])) : '',
                        'user_email'   => isset($_POST['user_email']) ? sanitize_text_field(wp_unslash($_POST['user_email'])) : '',
                        'user_url'     => isset($_POST['user_url']) ? esc_url_raw(wp_unslash($_POST['user_url'])) : '',
                        'description'  => isset($_POST['description']) ? sanitize_textarea_field(wp_unslash($_POST['description'])) : '',
                        'locale'       => $locale_raw !== null ? $this->sanitize_profile_locale_submission($locale_raw) : null,
                        'authcode'     => isset($_POST['authcode']) ? sanitize_text_field(wp_unslash($_POST['authcode'])) : '',
                        'email_code'   => isset($_POST['email_code']) ? sanitize_text_field(wp_unslash($_POST['email_code'])) : '',
                        'backup_code'  => isset($_POST['backup_code']) ? sanitize_text_field(wp_unslash($_POST['backup_code'])) : '',
                        // Password must be passed through unaltered (it is verified, never stored as text); only unslashed.
                        'current_pass' => isset($_POST['current_pass']) ? wp_unslash($_POST['current_pass']) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                        'email_change_2fa_provider' => isset($_POST['email_change_2fa_provider']) ? sanitize_text_field(wp_unslash($_POST['email_change_2fa_provider'])) : '',
                        'email_change_2fa_token'    => isset($_POST['email_change_2fa_token']) ? sanitize_text_field(wp_unslash($_POST['email_change_2fa_token'])) : '',
                    ];

                    $applied = yooadmin_profile_apply_account_fields($user, $account_fields, $is_own_profile);
                    if (is_wp_error($applied)) {
                        $errors = $applied;
                    } else {
                        if ($role_error === '' && $raw_role !== '') {
                            $this->apply_profile_role_change($user, $raw_role);
                        }
                        if (function_exists('yooadmin_profile_maybe_save_photo_plugin_sections')) {
                            yooadmin_profile_maybe_save_photo_plugin_sections($user_id, $is_own_profile);
                        }
                        if (function_exists('yooadmin_profile_save_avatar_source_from_request')) {
                            yooadmin_profile_save_avatar_source_from_request($user_id);
                        }
                        $updated = true;
                        $user    = $applied['user'];
                        if (!empty($applied['email_pending']) && !empty($applied['email_pending_address'])) {
                            $email_pending_notice = sprintf(
                                /* translators: %s: new email address */
                                __('Check your inbox at %s for a confirmation link. Your address will not change until you confirm it.', 'yooadmin'),
                                $applied['email_pending_address']
                            );
                        }
                    }
                }
            }
        }

        $roles = $this->get_roles_for_profile_form($user);
        $show_role_field = $this->profile_show_role_field($user);
        $is_own_profile = $this->profile_is_own_page($user);
        $can_list_users = current_user_can('list_users');
        $can_send_password_reset = $this->profile_can_send_reset($user);
        $profile_back_url = ($is_own_profile || !$can_list_users)
            ? admin_url('admin.php?page=' . yooadmin_dashboard_slug())
            : admin_url('admin.php?page=yooadmin-users');
        $profile_back_label = ($is_own_profile || !$can_list_users)
            ? __('Back to Dashboard', 'yooadmin')
            : __('Back to Users', 'yooadmin');
        $profile_pending_email = function_exists('yooadmin_profile_get_pending_email_change')
            ? yooadmin_profile_get_pending_email_change($user_id)
            : null;
        $profile_email_requires_2fa = $is_own_profile
            && function_exists('yooadmin_profile_user_has_2fa_for_email_change')
            && yooadmin_profile_user_has_2fa_for_email_change($user_id);
        $profile_email_2fa_providers = ($profile_email_requires_2fa && function_exists('yooadmin_profile_email_change_verification_providers'))
            ? yooadmin_profile_email_change_verification_providers($user_id)
            : [];
        $profile_email_password_fallback = $profile_email_requires_2fa && $profile_email_2fa_providers === [];
        $profile_email_dismiss_url = ($is_own_profile && function_exists('yooadmin_profile_page_url'))
            ? wp_nonce_url(
                add_query_arg('dismiss', $user_id . '_new_email', yooadmin_profile_page_url($user_id)),
                'dismiss-' . $user_id . '_new_email'
            )
            : '';
        $template = plugin_dir_path(yooadmin_base_file()) . 'templates/yoopixel/admin/pages/users/profile.php';
        if (file_exists($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('User Profile', 'yooadmin') . '</h1></div>';
    }

    private function is_redirect_enabled(): bool
    {
        $opts = (array)get_option('yooadmin_options', []);
        if (array_key_exists('users_redirect', $opts)) {
            return !empty($opts['users_redirect']);
        }
        return true;
    }

    private function profile_url(int $user_id): string
    {
        return add_query_arg([
            'page' => 'yooadmin-user',
            'user_id' => $user_id,
        ], admin_url('admin.php'));
    }

    /**
     * Handle bulk users action via AJAX
     */
    public function ajax_bulk_users_action(): void
    {
        check_ajax_referer('yooadmin_bulk_users', 'nonce');

        if (!current_user_can('edit_users')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $users = isset($_POST['users']) ? array_map('absint', (array)$_POST['users']) : [];
        $action = isset($_POST['bulk_action']) ? sanitize_key((string)$_POST['bulk_action']) : '';

        if (empty($users) || empty($action)) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'yooadmin')]);
        }

        $processed = 0;
        $errors = [];

        foreach ($users as $user_id) {
            $user = get_userdata($user_id);
            if (!$user) {
                continue;
            }

            // Prevent deleting current user
            if ($action === 'delete' && $user_id === get_current_user_id()) {
                $errors[] = sprintf(__('You cannot delete your own account.', 'yooadmin'), $user->display_name);
                continue;
            }

            switch ($action) {
                case 'delete':
                    if (!current_user_can('delete_user', $user_id)) {
                        // translators: %s: user display name
                        $errors[] = sprintf(__('You do not have permission to delete %s.', 'yooadmin'), $user->display_name);
                        continue 2;
                    }

                    // Check if user is administrator
                    if (in_array('administrator', $user->roles, true)) {
                        // Count remaining administrators (excluding the one being deleted)
                        // phpcs:disable WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude -- Necessary to count remaining admins before deletion; single-ID exclusion, no performance concern.
                        $admin_query = new \WP_User_Query([
                            'role' => 'administrator',
                            'exclude' => [$user_id],
                            'number' => 1,
                            'fields' => 'ID',
                        ]);
                        // phpcs:enable WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude

                        $remaining_admins = $admin_query->get_total();

                        // Prevent deleting if this is the last administrator
                        if ($remaining_admins === 0) {
                            // translators: %s: user display name
                            $errors[] = sprintf(__('Cannot delete %s. You cannot delete the last administrator. At least one administrator must remain.', 'yooadmin'), $user->display_name);
                            continue 2;
                        }
                    }

                    if (wp_delete_user($user_id)) {
                        $processed++;
                    }
                    else {
                        // translators: %s: user display name
                        $errors[] = sprintf(__('Failed to delete %s.', 'yooadmin'), $user->display_name);
                    }
                    break;

                case 'remove':
                    if (!is_multisite() || !current_user_can('remove_user', $user_id)) {
                        // translators: %s: user display name
                        $errors[] = sprintf(__('You do not have permission to remove %s.', 'yooadmin'), $user->display_name);
                        continue 2;
                    }

                    if (remove_user_from_blog($user_id)) {
                        $processed++;
                    } else {
                        // translators: %s: user display name
                        $errors[] = sprintf(__('Failed to remove %s.', 'yooadmin'), $user->display_name);
                    }
                    break;

                case 'change_role':
                    if (!current_user_can('promote_user', $user_id)) {
                        // translators: %s: user display name
                        $errors[] = sprintf(__('You do not have permission to change the role for %s.', 'yooadmin'), $user->display_name);
                        continue 2;
                    }

                    $new_role = isset($_POST['role']) ? sanitize_key((string) $_POST['role']) : '';
                    if ($new_role === '') {
                        $errors[] = __('No role selected.', 'yooadmin');
                        continue 2;
                    }

                    if (!$this->profile_new_role_allowed($user_id, $new_role)) {
                        // translators: %s: user display name
                        $errors[] = sprintf(__('You are not allowed to assign this role to %s.', 'yooadmin'), $user->display_name);
                        continue 2;
                    }

                    $user->set_role($new_role);
                    $processed++;
                    break;
            }
        }

        if ($processed > 0) {
            $message = '';
            switch ($action) {
                case 'delete':
                    // translators: %d: number of users deleted
                    $message = sprintf(_n('%d user deleted.', '%d users deleted.', $processed, 'yooadmin'), $processed);
                    break;
                case 'remove':
                    // translators: %d: number of users removed
                    $message = sprintf(_n('%d user removed.', '%d users removed.', $processed, 'yooadmin'), $processed);
                    break;
                case 'change_role':
                    // translators: %d: number of user roles updated
                    $message = sprintf(_n('%d user role updated.', '%d users roles updated.', $processed, 'yooadmin'), $processed);
                    break;
            }
            if (!empty($errors)) {
                // translators: %d: number of errors
                $message .= ' ' . sprintf(_n('%d error occurred.', '%d errors occurred.', count($errors), 'yooadmin'), count($errors));
            }
            wp_send_json_success(['message' => $message]);
        }
        else {
            $error_message = !empty($errors) ? implode(' ', $errors) : __('No users were processed.', 'yooadmin');
            wp_send_json_error(['message' => $error_message]);
        }
    }

    /**
     * Update user last activity timestamp on login
     */
    public function update_user_last_activity(string $user_login, \WP_User $user): void
    {
        update_user_meta($user->ID, 'yooadmin_last_activity', time());
    }

    /**
     * Update current user's last activity in admin
     */
    public function update_current_user_activity(): void
    {
        if (!is_user_logged_in() || !is_admin()) {
            return;
        }

        // Only update once per minute to avoid excessive database writes
        $user_id = get_current_user_id();
        $last_update = (int)get_user_meta($user_id, 'yooadmin_last_activity', true);
        $now = time();

        // Update if more than 1 minute has passed
        if ($now - $last_update > 60) {
            update_user_meta($user_id, 'yooadmin_last_activity', $now);
        }
    }

    /**
     * Verify 2FA for a pending email change and issue a short-lived save token.
     */
    public function ajax_verify_email_change_2fa(): void
    {
        $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;

        if (!$user_id) {
            wp_send_json_error(['message' => __('Invalid user ID.', 'yooadmin')]);
        }

        if (!current_user_can('edit_user', $user_id)) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        check_ajax_referer('yooadmin_update_user_' . $user_id, 'nonce');

        if (
            !function_exists('yooadmin_profile_user_has_2fa_for_email_change')
            || !yooadmin_profile_user_has_2fa_for_email_change($user_id)
        ) {
            wp_send_json_error(['message' => __('Two-factor verification is not required.', 'yooadmin')]);
        }

        $target_email = isset($_POST['user_email']) ? sanitize_email(wp_unslash((string) $_POST['user_email'])) : '';
        if (!is_email($target_email)) {
            wp_send_json_error(['message' => __('Please provide a valid email address.', 'yooadmin')]);
        }

        $user = get_userdata($user_id);
        if (!$user instanceof WP_User) {
            wp_send_json_error(['message' => __('User not found.', 'yooadmin')]);
        }

        if (strcasecmp($target_email, $user->user_email) === 0) {
            wp_send_json_error(['message' => __('Enter a new email address first.', 'yooadmin')]);
        }

        $request = [
            'user_email'                => $target_email,
            'authcode'                  => isset($_POST['authcode']) ? sanitize_text_field(wp_unslash($_POST['authcode'])) : '',
            'backup_code'               => isset($_POST['backup_code']) ? sanitize_text_field(wp_unslash($_POST['backup_code'])) : '',
            // Password must be passed through unaltered (it is verified, never stored as text); only unslashed.
            'current_pass'              => isset($_POST['current_pass']) ? wp_unslash($_POST['current_pass']) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            'email_change_2fa_provider' => isset($_POST['email_change_2fa_provider']) ? sanitize_text_field(wp_unslash($_POST['email_change_2fa_provider'])) : '',
        ];

        if (!function_exists('yooadmin_profile_verify_email_change_2fa') || !yooadmin_profile_verify_email_change_2fa($user_id, $request)) {
            $providers = function_exists('yooadmin_profile_email_change_verification_providers')
                ? yooadmin_profile_email_change_verification_providers($user_id)
                : [];
            $message = $providers === []
                ? __('Enter your current password to confirm this email change.', 'yooadmin')
                : __('Invalid verification code. Please try again.', 'yooadmin');
            wp_send_json_error(['message' => $message]);
        }

        $provider = sanitize_key((string) $request['email_change_2fa_provider']);
        if ($provider === '') {
            $providers = function_exists('yooadmin_profile_email_change_verification_providers')
                ? yooadmin_profile_email_change_verification_providers($user_id)
                : [];
            $provider = $providers === [] ? 'password' : (string) ($providers[0]['key'] ?? 'totp');
        }

        if (!function_exists('yooadmin_profile_issue_email_change_2fa_verification')) {
            wp_send_json_error(['message' => __('Verification is unavailable.', 'yooadmin')]);
        }

        $token = yooadmin_profile_issue_email_change_2fa_verification($user_id, $provider, $target_email);

        wp_send_json_success([
            'token'   => $token,
            'message' => __('Identity verified for this email change.', 'yooadmin'),
        ]);
    }

    /**
     * Handle profile update via AJAX
     */
    public function ajax_update_profile(): void
    {
        $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;

        if (!$user_id) {
            wp_send_json_error(['message' => __('Invalid user ID.', 'yooadmin')]);
        }

        if (!current_user_can('edit_user', $user_id)) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        check_ajax_referer('yooadmin_update_user_' . $user_id, 'nonce');

        $user = get_userdata($user_id);
        if (!$user) {
            wp_send_json_error(['message' => __('User not found.', 'yooadmin')]);
        }

        $raw_role = isset($_POST['role']) ? sanitize_key(wp_unslash($_POST['role'])) : '';
        $role_error = $this->validate_submitted_profile_role($user, $raw_role);
        $previous_roles = $user->roles;
        $locale_raw = isset($_POST['locale']) ? sanitize_text_field(wp_unslash($_POST['locale'])) : null;
        $is_own_profile = $this->profile_is_own_page($user);

        if ($role_error !== '') {
            wp_send_json_error(['message' => $role_error]);
        }

        if (!function_exists('yooadmin_profile_apply_account_fields')) {
            wp_send_json_error(['message' => __('Profile update is unavailable.', 'yooadmin')]);
        }

        $account_fields = [
            'first_name'   => isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '',
            'last_name'    => isset($_POST['last_name']) ? sanitize_text_field(wp_unslash($_POST['last_name'])) : '',
            'display_name' => isset($_POST['display_name']) ? sanitize_text_field(wp_unslash($_POST['display_name'])) : '',
            'user_email'   => isset($_POST['user_email']) ? sanitize_text_field(wp_unslash($_POST['user_email'])) : '',
            'user_url'     => isset($_POST['user_url']) ? esc_url_raw(wp_unslash($_POST['user_url'])) : '',
            'description'  => isset($_POST['description']) ? sanitize_textarea_field(wp_unslash($_POST['description'])) : '',
            'locale'       => $locale_raw !== null ? $this->sanitize_profile_locale_submission($locale_raw) : null,
            'authcode'     => isset($_POST['authcode']) ? sanitize_text_field(wp_unslash($_POST['authcode'])) : '',
            'email_code'   => isset($_POST['email_code']) ? sanitize_text_field(wp_unslash($_POST['email_code'])) : '',
            'backup_code'  => isset($_POST['backup_code']) ? sanitize_text_field(wp_unslash($_POST['backup_code'])) : '',
            // Password must be passed through unaltered (it is verified, never stored as text); only unslashed.
            'current_pass' => isset($_POST['current_pass']) ? wp_unslash($_POST['current_pass']) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            'email_change_2fa_provider' => isset($_POST['email_change_2fa_provider']) ? sanitize_text_field(wp_unslash($_POST['email_change_2fa_provider'])) : '',
            'email_change_2fa_token'    => isset($_POST['email_change_2fa_token']) ? sanitize_text_field(wp_unslash($_POST['email_change_2fa_token'])) : '',
        ];

        $applied = yooadmin_profile_apply_account_fields($user, $account_fields, $is_own_profile);
        if (is_wp_error($applied)) {
            wp_send_json_error(['message' => implode(' ', $applied->get_error_messages())]);
        }

        $role_changed = false;
        if ($role_error === '' && $raw_role !== '') {
            $role_changed = $this->apply_profile_role_change($user, $raw_role);
        }

        if (function_exists('yooadmin_profile_maybe_save_photo_plugin_sections')) {
            yooadmin_profile_maybe_save_photo_plugin_sections($user_id, $is_own_profile);
        }
        if (function_exists('yooadmin_profile_save_avatar_source_from_request')) {
            yooadmin_profile_save_avatar_source_from_request($user_id);
        }

        $updated_user = $applied['user'];
        if (!$updated_user) {
            wp_send_json_error(['message' => __('User not found.', 'yooadmin')]);
        }

        $avatar_source = function_exists('yooadmin_profile_get_avatar_source')
            ? yooadmin_profile_get_avatar_source($user_id)
            : 'yooadmin';
        $avatar_url = function_exists('yooadmin_profile_avatar_url_for_source')
            ? yooadmin_profile_avatar_url_for_source($user_id, $avatar_source, 110)
            : get_avatar_url($user_id, ['size' => 110]);

        $user_data = [
            'display_name' => $updated_user->display_name,
            'user_email' => $updated_user->user_email,
            'roles' => $updated_user->roles,
            'roles_label' => yooadmin_translate_user_role_list($updated_user->roles),
            'avatar_url' => $avatar_url,
            'avatar_source' => $avatar_source,
            'avatar_is_placeholder' => function_exists('yooadmin_profile_avatar_is_placeholder_for_source')
                ? yooadmin_profile_avatar_is_placeholder_for_source($user_id, $avatar_source, 110)
                : false,
            'has_custom_avatar' => function_exists('yooadmin_user_has_custom_avatar')
                && yooadmin_user_has_custom_avatar($user_id)
                && $avatar_source === 'yooadmin',
        ];

        $message = $this->profile_save_success_message($previous_roles, $updated_user->roles);
        if (!empty($applied['email_pending']) && !empty($applied['email_pending_address'])) {
            $message = sprintf(
                /* translators: %s: new email address */
                __('Profile saved. Check your inbox at %s and confirm the new address before it becomes active.', 'yooadmin'),
                $applied['email_pending_address']
            );
        }

        $plugins_panel_html = '';
        if ($avatar_source === 'plugins' && function_exists('yooadmin_profile_render_photo_plugin_sections')) {
            ob_start();
            yooadmin_profile_render_photo_plugin_sections($updated_user, $is_own_profile);
            $plugins_panel_html = (string) ob_get_clean();
        }

        wp_send_json_success([
            'message' => $message,
            'roleChanged' => $role_changed,
            'emailPending' => !empty($applied['email_pending']),
            'emailPendingAddress' => $applied['email_pending_address'] ?? '',
            'plugins_panel_html' => $plugins_panel_html,
            'user' => $user_data,
        ]);
    }

    /**
     * Save profile photo source immediately when the dropdown changes.
     */
    public function ajax_set_avatar_source(): void
    {
        $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
        if ($user_id <= 0) {
            wp_send_json_error(['message' => __('Invalid user ID.', 'yooadmin')]);
        }

        if (!current_user_can('edit_user', $user_id)) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        check_ajax_referer('yooadmin_update_user_' . $user_id, 'nonce');

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
        $source = isset($_POST['avatar_source'])
            ? sanitize_key(wp_unslash((string) $_POST['avatar_source']))
            : '';

        if ($source === '' || !function_exists('yooadmin_profile_set_avatar_source')) {
            wp_send_json_error(['message' => __('Invalid profile photo source.', 'yooadmin')]);
        }

        if (!yooadmin_profile_set_avatar_source($user_id, $source)) {
            wp_send_json_error(['message' => __('Could not update profile photo source.', 'yooadmin')]);
        }

        $user = get_userdata($user_id);
        if (!$user instanceof WP_User) {
            wp_send_json_error(['message' => __('User not found.', 'yooadmin')]);
        }

        $is_own_profile = $this->profile_is_own_page($user);
        $avatar_url = function_exists('yooadmin_profile_avatar_url_for_source')
            ? yooadmin_profile_avatar_url_for_source($user_id, $source, 110)
            : get_avatar_url($user_id, ['size' => 110]);
        $is_placeholder = function_exists('yooadmin_profile_avatar_is_placeholder_for_source')
            ? yooadmin_profile_avatar_is_placeholder_for_source($user_id, $source, 110)
            : false;
        $has_custom_avatar = function_exists('yooadmin_user_has_custom_avatar')
            && yooadmin_user_has_custom_avatar($user_id)
            && $source === 'yooadmin';

        $plugins_panel_html = '';
        if ($source === 'plugins' && function_exists('yooadmin_profile_render_photo_plugin_sections')) {
            ob_start();
            yooadmin_profile_render_photo_plugin_sections($user, $is_own_profile);
            $plugins_panel_html = (string) ob_get_clean();
        }

        wp_send_json_success([
            'message' => __('Profile photo source updated.', 'yooadmin'),
            'avatar_source' => $source,
            'avatar_url' => $avatar_url,
            'avatar_is_placeholder' => $is_placeholder,
            'has_custom_avatar' => $has_custom_avatar,
            'plugins_panel_html' => $plugins_panel_html,
        ]);
    }

    /**
     * Handle password update via AJAX
     */
    public function ajax_update_password(): void
    {
        $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;

        if (!$user_id) {
            wp_send_json_error(['message' => __('Invalid user ID.', 'yooadmin')]);
        }

        if (!current_user_can('edit_user', $user_id)) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        check_ajax_referer('yooadmin_update_user_' . $user_id, 'nonce');

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords must not be sanitized to preserve special characters.
        $pass1 = isset($_POST['pass1']) ? wp_unslash($_POST['pass1']) : '';
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passwords must not be sanitized to preserve special characters.
        $pass2 = isset($_POST['pass2']) ? wp_unslash($_POST['pass2']) : '';

        if (empty($pass1) || empty($pass2)) {
            wp_send_json_error(['message' => __('Please fill in both password fields.', 'yooadmin')]);
        }

        if ($pass1 !== $pass2) {
            wp_send_json_error(['message' => __('The passwords do not match.', 'yooadmin')]);
        }

        if (strlen($pass1) < 8) {
            wp_send_json_error(['message' => __('Password must be at least 8 characters long.', 'yooadmin')]);
        }

        $userdata = [
            'ID' => $user_id,
            'user_pass' => $pass1,
        ];

        $result = wp_update_user($userdata);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => implode(' ', $result->get_error_messages())]);
        }

        wp_send_json_success([
            'message' => __('Password updated successfully.', 'yooadmin'),
        ]);
    }

    /**
     * Send password reset link via AJAX
     */
    public function ajax_send_password_reset(): void
    {
        $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;

        if (!$user_id) {
            wp_send_json_error(['message' => __('Invalid user ID.', 'yooadmin')]);
        }

        if (!current_user_can('edit_user', $user_id)) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        check_ajax_referer('yooadmin_users', 'nonce');

        $user = get_userdata($user_id);
        if (!$user) {
            wp_send_json_error(['message' => __('User not found.', 'yooadmin')]);
        }

        if (!$this->profile_can_send_reset($user)) {
            wp_send_json_error(['message' => __('You are not allowed to send a password reset link for this user.', 'yooadmin')]);
        }

        // Send password reset email
        $result = retrieve_password($user->user_login);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success([
            'message' => __('Password reset link has been sent to the user\'s email address.', 'yooadmin'),
        ]);
    }

    /**
     * Count users who were active in the last 15 minutes
     */
    private function count_online_users(): int
    {
        global $wpdb;

        $threshold = time() - (15 * 60); // 15 minutes ago
        $meta_key = 'yooadmin_last_activity';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- One-off count query; $wpdb->usermeta is a core table property.
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT user_id) 
            FROM {$wpdb->usermeta} 
            WHERE meta_key = %s 
            AND CAST(meta_value AS UNSIGNED) >= %d",
            $meta_key,
            $threshold
        ));

        return (int)$count;
    }

    /**
     * Sanitize locale from the profile form (empty string = site default).
     */
    private function sanitize_profile_locale_submission(string $locale): string
    {
        if ($locale === '' || $locale === 'site-default') {
            return '';
        }

        if (function_exists('yooadmin_sanitize_user_admin_locale_submission')) {
            $sanitized = yooadmin_sanitize_user_admin_locale_submission($locale);
            if ($locale === 'en_US' || $sanitized !== '') {
                return $sanitized;
            }
        }

        return sanitize_text_field($locale);
    }

    /**
     * Normalize users list sort key from the request.
     */
    private function sanitize_users_sort(string $sort): string
    {
        return in_array($sort, ['recent', 'name', 'role'], true) ? $sort : 'recent';
    }

    /**
     * Map sort UI value to WP_User_Query arguments.
     *
     * @param array<string, mixed> $args  Query args.
     * @param string               $sort Sort key.
     * @return array<string, mixed>
     */
    private function apply_users_sort_to_query(array $args, string $sort): array
    {
        $sort = $this->sanitize_users_sort($sort);

        switch ($sort) {
            case 'name':
                $args['orderby'] = 'display_name';
                $args['order'] = 'ASC';
                break;
            case 'role':
                $args['orderby'] = 'registered';
                $args['order'] = 'DESC';
                $args['yooadmin_users_sort_role'] = true;
                break;
            case 'recent':
            default:
                $args['orderby'] = 'registered';
                $args['order'] = 'DESC';
                break;
        }

        return $args;
    }

    /**
     * Sort loaded users by role hierarchy (current page only).
     *
     * @param \WP_User[] $users Users from WP_User_Query.
     * @return \WP_User[]
     */
    private function sort_users_by_role(array $users): array
    {
        $order = array_flip(['administrator', 'editor', 'author', 'contributor', 'subscriber']);

        usort(
            $users,
            static function (\WP_User $a, \WP_User $b) use ($order): int {
                $ra = $a->roles ? (string) reset($a->roles) : '';
                $rb = $b->roles ? (string) reset($b->roles) : '';
                $ia = isset($order[$ra]) ? $order[$ra] : 99;
                $ib = isset($order[$rb]) ? $order[$rb] : 99;

                if ($ia !== $ib) {
                    return $ia <=> $ib;
                }

                return strcasecmp(
                    $a->display_name !== '' ? $a->display_name : $a->user_login,
                    $b->display_name !== '' ? $b->display_name : $b->user_login
                );
            }
        );

        return $users;
    }

    /**
     * AJAX handler for filtering users
     */
    public function ajax_filter_users(): void
    {
        check_ajax_referer('yooadmin_users', 'nonce');

        if (!current_user_can('list_users')) {
            wp_send_json_error(['message' => __('Sorry, you are not allowed to access this page.', 'yooadmin')]);
        }

        $per_page = max(5, (int)apply_filters('yooadmin_users_per_page', 12));
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified via check_ajax_referer above.
        $paged = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search from URL.
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only role filter from URL.
        $role = isset($_GET['role']) ? sanitize_key(wp_unslash($_GET['role'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only sort from URL.
        $sort = isset($_GET['sort']) ? sanitize_key(wp_unslash($_GET['sort'])) : 'recent';

        $args = [
            'number' => $per_page,
            'offset' => ($paged - 1) * $per_page,
            'orderby' => 'registered',
            'order' => 'DESC',
        ];
        $args = $this->apply_users_sort_to_query($args, $sort);

        if ($search !== '') {
            $args['search'] = '*' . esc_attr($search) . '*';
            $args['search_columns'] = ['user_login', 'user_email', 'user_nicename', 'display_name'];
        }

        if ($role !== '') {
            $args['role'] = $role;
        }

        $args = apply_filters('yooadmin_users_query_args', $args, [
            'paged' => $paged,
            'search' => $search,
            'role' => $role,
            'sort' => $sort,
        ]);

        $user_query = new WP_User_Query($args);
        $users = $user_query->get_results();
        if (!empty($args['yooadmin_users_sort_role'])) {
            $users = $this->sort_users_by_role($users);
        }
        $total = (int)$user_query->get_total();
        $total_pages = $per_page > 0 ? (int)ceil($total / $per_page) : 1;

        // Render users grid HTML
        ob_start();
        if ($users) {
            echo '<section class="yoo-users-grid">';
            foreach ($users as $user) {
                $roles_display = yooadmin_translate_user_role_list($user->roles);
                $primary_role = $user->roles ? reset($user->roles) : '';
                $status_badge = in_array('administrator', $user->roles, true) ? 'administrator' : ($primary_role ?: 'standard');
                $profile_url = add_query_arg([
                    'page' => 'yooadmin-user',
                    'user_id' => $user->ID,
                ], admin_url('admin.php'));
                $registered = strtotime($user->user_registered);
?>
                <article class="yoo-user-card">
                    <?php
                    if (function_exists('yooadmin_users_render_row_actions')) {
                        yooadmin_users_render_row_actions($user);
                    }
                    ?>
                    <header class="yoo-user-card__header">
                        <div class="yoo-user-avatar">
                            <?php echo wp_kses_post(get_avatar($user->ID, 72)); ?>
                            <span class="yoo-user-online-badge" aria-hidden="true"></span>
                        </div>
                        <div class="yoo-user-heading">
                            <h2>
                                <a href="<?php echo esc_url($profile_url); ?>">
                                    <?php echo esc_html($user->display_name ?: $user->user_login); ?>
                                </a>
                            </h2>
                            <span class="yoo-user-role yoo-user-role--<?php echo esc_attr(sanitize_html_class($status_badge)); ?>">
                                <?php echo esc_html($roles_display ?: __('User', 'yooadmin')); ?>
                            </span>
                        </div>
                        <div class="yoo-user-meta-inline">
                            <span><?php echo esc_html(date_i18n(get_option('date_format'), $registered)); ?></span>
                            <span class="dot">•</span>
                            <span><?php echo esc_html($user->user_login); ?></span>
                        </div>
                    </header>

                    <dl class="yoo-user-meta">
                        <div>
                            <dt><?php esc_html_e('Email', 'yooadmin'); ?></dt>
                            <dd>
                                <a href="mailto:<?php echo esc_attr($user->user_email); ?>">
                                    <?php echo esc_html($user->user_email); ?>
                                </a>
                            </dd>
                        </div>
                        <div>
                            <dt><?php esc_html_e('Registered', 'yooadmin'); ?></dt>
                            <dd><?php echo esc_html(date_i18n(get_option('date_format'), $registered)); ?></dd>
                        </div>
                        <div>
                            <dt><?php esc_html_e('Username', 'yooadmin'); ?></dt>
                            <dd><?php echo esc_html($user->user_login); ?></dd>
                        </div>
                    </dl>
                </article>
                <?php
            }
            echo '</section>';

            // Pagination
            if ($total_pages > 1) {
                echo '<nav class="yoo-users-pagination">';
                $base_url = admin_url('admin.php?page=yooadmin-users');
                if ($search) {
                    $base_url = add_query_arg('s', urlencode($search), $base_url);
                }
                if ($role) {
                    $base_url = add_query_arg('role', urlencode($role), $base_url);
                }

                // Previous
                if ($paged > 1) {
                    $prev_url = add_query_arg('paged', $paged - 1, $base_url);
                    printf('<a href="%s" class="yoo-pagination-prev" data-paged="%d">%s</a>',
                        esc_url($prev_url),
                        esc_attr($paged - 1),
                        esc_html__('Previous', 'yooadmin')
                    );
                }

                // Page numbers
                for ($i = 1; $i <= $total_pages; $i++) {
                    if ($i === $paged) {
                        printf('<span class="yoo-pagination-current">%d</span>', (int)$i);
                    }
                    else {
                        $page_url = add_query_arg('paged', $i, $base_url);
                        printf('<a href="%s" class="yoo-pagination-link" data-paged="%d">%d</a>',
                            esc_url($page_url),
                            (int)$i,
                            (int)$i
                        );
                    }
                }

                // Next
                if ($paged < $total_pages) {
                    $next_url = add_query_arg('paged', $paged + 1, $base_url);
                    printf('<a href="%s" class="yoo-pagination-next" data-paged="%d">%s</a>',
                        esc_url($next_url),
                        esc_attr($paged + 1),
                        esc_html__('Next', 'yooadmin')
                    );
                }
                echo '</nav>';
            }
        }
        else {
            echo '<div class="yoo-users-empty">';
            echo '<div class="yoo-empty-illustration">';
            echo '<span class="dashicons dashicons-groups"></span>';
            echo '</div>';
            echo '<h2>' . esc_html__('No users found', 'yooadmin') . '</h2>';
            echo '<p>' . esc_html__('Try adjusting your search or filter criteria.', 'yooadmin') . '</p>';
            echo '</div>';
        }
        $html = ob_get_clean();

        wp_send_json_success([
            'html' => $html,
            'total' => $total,
            'paged' => $paged,
            'total_pages' => $total_pages,
        ]);
    }
}

YOOAdmin_Users_Page::get_instance();
