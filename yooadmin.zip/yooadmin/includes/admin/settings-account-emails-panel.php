<?php
/**
 * Login Security — Account emails panel (branded messages + email-change recovery).
 *
 * Included from settings-login-security-tab.php; expects $this and login_* variables in scope.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Settings tab partial.

/** @var YOOAdmin_Settings $this */

$account_emails_panel_active = isset($security_inner_active) && $security_inner_active === 'account-emails';
?>
<div class="yp-tab-panel yooadmin-security-inner-panel<?php echo $account_emails_panel_active ? ' is-active' : ''; ?>" data-security-inner-panel="account-emails" id="yooadmin-security-panel-account-emails" role="tabpanel" aria-labelledby="yp-security-inner-tab-account-emails"<?php echo $account_emails_panel_active ? '' : ' hidden'; ?>>
    <div class="yooadmin-security-panel-content">
        <p class="yp-help yooadmin-security-card__lead">
            <?php esc_html_e('YOOAdmin sends branded HTML emails for account and security actions. Messages use your site logo and brand colors from Branding and Login settings.', 'yooadmin'); ?>
        </p>

        <div class="yooadmin-email-recovery-settings">
            <p class="yp-help yooadmin-security-card__lead yooadmin-email-recovery-settings__lead">
                <?php esc_html_e('When a user\'s email is changed, send the previous address a secure recovery link to restore the account.', 'yooadmin'); ?>
            </p>
            <table class="form-table yooadmin-security-toggle-table"><tbody>
                <tr>
                    <th scope="row">
                        <div class="yp-th-content">
                            <span class="dashicons dashicons-email-alt yp-th-icon"></span>
                            <span><?php esc_html_e('Email-change recovery', 'yooadmin'); ?></span>
                            <span class="yp-help-icon">
                                <span class="dashicons dashicons-editor-help"></span>
                                <span class="yp-tooltip"><?php esc_html_e('Adds a time-limited recovery button to the notification sent to the previous email address. Requires confirmation before the email is restored and all sessions are signed out.', 'yooadmin'); ?></span>
                            </span>
                        </div>
                    </th>
                    <td>
                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_email_change_recovery_enabled]" value="0">
                        <?php
                        $recovery_on   = !isset($login_email_change_recovery_enabled) || !empty($login_email_change_recovery_enabled);
                        $recovery_desc = __('Send a secure recovery link to the previous email after an address change.', 'yooadmin');
                        $recovery_toggle = $this->render_toggle_field(
                            'login_email_change_recovery_enabled',
                            $recovery_on
                                ? __('Email-change recovery enabled', 'yooadmin')
                                : __('Email-change recovery disabled', 'yooadmin'),
                            $recovery_desc,
                            $recovery_on,
                            'login_email_change_recovery_enabled',
                            $this->opt_options,
                            false
                        );
                        echo wp_kses($recovery_toggle['toggle'], $this->get_toggle_allowed_html());
                        ?>
                    </td>
                </tr>
            </tbody></table>
        </div>
    </div>
</div>
