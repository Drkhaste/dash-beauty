<?php
/**
 * YOOAi — promotional floating assistant (no live AI).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!class_exists('YOOAdmin_YOOAi_Promo')) {

    final class YOOAdmin_YOOAi_Promo {

        public const USER_META_FAB_HIDDEN = 'yooadmin_yooai_fab_hidden';

        public static function init(): void {
            add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets'], 125);
            add_action('admin_footer', [__CLASS__, 'render_markup'], 25);
            add_action('wp_ajax_yooadmin_yooai_hide_fab', [__CLASS__, 'ajax_hide_fab']);
        }

        public static function is_enabled(): bool {
            if (!is_admin() || !is_user_logged_in()) {
                return false;
            }

            if ((function_exists('wp_doing_ajax') && wp_doing_ajax())
                || (function_exists('wp_doing_cron') && wp_doing_cron())
                || defined('REST_REQUEST')) {
                return false;
            }

            if (is_network_admin()) {
                return false;
            }

            $focus_on = true;
            if (function_exists('yooadmin_is_focus_enabled')) {
                $focus_on = (bool) yooadmin_is_focus_enabled();
            } elseif (function_exists('yooadmin_focus_enabled_by_pref')) {
                $focus_on = (bool) yooadmin_focus_enabled_by_pref();
            }

            if (!$focus_on) {
                return false;
            }

            if (function_exists('yooadmin__should_shell_inject_now') && !yooadmin__should_shell_inject_now()) {
                return false;
            }

            return (bool) apply_filters('yooadmin_yooai_promo_enabled', true);
        }

        public static function is_fab_hidden_for_user(int $user_id = 0): bool {
            if (class_exists('YOOAdmin_Labs_Prefs')) {
                return !YOOAdmin_Labs_Prefs::is_yooai_fab_visible($user_id);
            }

            $user_id = $user_id > 0 ? $user_id : get_current_user_id();
            if ($user_id <= 0) {
                return false;
            }

            return (bool) get_user_meta($user_id, self::USER_META_FAB_HIDDEN, true);
        }

        public static function enqueue_assets(): void {
            if (!self::is_enabled()) {
                return;
            }

            $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
            $dir       = plugin_dir_path($base_file);
            $url       = plugin_dir_url($base_file);

            $css_rel = 'assets/css/admin/yooai-promo.css';
            $js_rel  = 'assets/js/admin/yooai-promo.js';
            $css_abs = $dir . $css_rel;
            $js_abs  = $dir . $js_rel;

            if (file_exists($css_abs)) {
                wp_enqueue_style(
                    'yooadmin-yooai-promo',
                    $url . $css_rel,
                    wp_style_is('yooadmin-core', 'registered') || wp_style_is('yooadmin-core', 'enqueued')
                        ? ['yooadmin-core']
                        : [],
                    (string) filemtime($css_abs)
                );
            }

            if (file_exists($js_abs)) {
                wp_enqueue_script(
                    'yooadmin-yooai-promo',
                    $url . $js_rel,
                    ['jquery'],
                    (string) filemtime($js_abs),
                    true
                );

                wp_localize_script(
                    'yooadmin-yooai-promo',
                    'yooadminYooAi',
                    [
                        'ajaxUrl'     => admin_url('admin-ajax.php'),
                        'nonce'       => wp_create_nonce('yooadmin_yooai_promo'),
                        'fabHidden'   => self::is_fab_hidden_for_user(),
                        'settingsUrl' => admin_url('admin.php?page=yooadmin-settings#tab-labs'),
                        'i18n'        => [
                            'title'           => __('YOOAi', 'yooadmin'),
                            'fabOpen'         => __('Open YOOAi', 'yooadmin'),
                            'fabHide'         => __('Hide YOOAi button', 'yooadmin'),
                            'fabHiddenToast'  => __('YOOAi button hidden. Turn it back on anytime in Settings → Labs.', 'yooadmin'),
                            'close'           => __('Close', 'yooadmin'),
                            'badge'           => __('Coming soon', 'yooadmin'),
                            'inactiveNotice'  => __('AI replies are not available yet. This preview is promotional only while we build YOOAi in our labs.', 'yooadmin'),
                            'placeholder'     => __('Type in English…', 'yooadmin'),
                            'send'            => __('Send', 'yooadmin'),
                            'sendDisabled'    => __('Sending is disabled until YOOAi launches.', 'yooadmin'),
                            'welcome'         => __(
                                'Welcome! We\'re building YOOAi in our labs right now. Your dashboard will get smarter over the coming days — artificial intelligence will become part of your workspace, helping you build your entire website and manage it from your directions. You can close this screen for now and stay tuned for YOOAi, your smart personal assistant powered by the latest AI technology.',
                                'yooadmin'
                            ),
                            'welcomeFollowup' => __(
                                'When YOOAi goes live, you\'ll be able to chat here and get guided help across your site.',
                                'yooadmin'
                            ),
                            'extendedPromo'   => __(
                                'Looking for more workspace tools? YOOAdmin Extended is available free at yooadmin.io.',
                                'yooadmin'
                            ),
                            'userEchoPrefix'  => __('You wrote:', 'yooadmin'),
                            'inactiveReply'   => __(
                                'Thanks for your message. YOOAi is not active yet — we\'re still training this assistant for your dashboard. Check back soon!',
                                'yooadmin'
                            ),
                        ],
                    ]
                );
            }
        }

        public static function render_markup(): void {
            if (!self::is_enabled() || !wp_script_is('yooadmin-yooai-promo', 'enqueued')) {
                return;
            }

            $template = dirname(__DIR__, 2) . '/templates/yoopixel/admin/components/yooai-promo.php';
            if (file_exists($template)) {
                include $template;
            }
        }

        public static function ajax_hide_fab(): void {
            check_ajax_referer('yooadmin_yooai_promo', 'nonce');

            if (!is_user_logged_in()) {
                wp_send_json_error(['message' => 'forbidden'], 403);
            }

            if (class_exists('YOOAdmin_Labs_Prefs')) {
                YOOAdmin_Labs_Prefs::set_yooai_fab_visible(false, get_current_user_id());
            } else {
                update_user_meta(get_current_user_id(), self::USER_META_FAB_HIDDEN, '1');
            }

            wp_send_json_success(['hidden' => true]);
        }
    }

    YOOAdmin_YOOAi_Promo::init();
}
