<?php
defined('ABSPATH') || exit;

if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
    return;
}

/**
 * Discovers and registers admin shell packs under `/themes`; templates and assets.
 */
class YOOAdmin_Admin_Theme_Manager {

    private const OPTION_KEY      = 'yooadmin_active_admin_theme';
    /** Preferred default for new installs (Phase 4). */
    private const DEFAULT_SLUG    = 'yooadmin-studio-hub';
    /** Built-in fallback shell bundled with the plugin. */
    private const LEGACY_SLUG     = 'yooadmin-legacy';
    /** One-time: seed default theme for installs that never saved OPTION_KEY. */
    private const DEFAULT_MIGRATION_OPTION = 'yooadmin_admin_theme_default_migrated_v1';
    /** Fresh 1.5+ install seeded with Studio Hub — never show upgrade modal. */
    private const FRESH_INSTALL_MARKER_OPTION = 'yooadmin_fresh_install_studio_hub_v1';
    private const MANIFEST_FILE            = 'manifest.json';
    private const ACTIVATE_ACTION          = 'yooadmin_activate_admin_theme';
    private const UPLOAD_ACTION            = 'yooadmin_upload_admin_theme';
    private const DELETE_ACTION            = 'yooadmin_delete_admin_theme';
    private const SAVE_SETTINGS_ACTION     = 'yooadmin_save_admin_theme_settings';
    private const META_OPTION              = 'yooadmin_admin_theme_meta';
    private const SETTINGS_OPTION_PREFIX   = 'yooadmin_admin_theme_settings_';

    /** @var self|null */
    private static $instance = null;

    /** @var array<string,array> */
    private $themes = [];

    /** @var string|null */
    private $active_slug = null;

    /** @var string */
    private $menu_slug = 'yooadmin-themes';
    private $settings_page_slug = 'yooadmin-admin-theme-settings';

    /** @var array<string,array> */
    private $theme_meta = [];

    /** @var bool */
    private $body_class_hooked = false;

    /**
     * Brand color definitions shared with YOOPixel core settings.
     *
     * @var array<string,array{key:string,default:string}>
     */
    private $brand_color_definitions = [
        '--yooadmin-primary'       => ['key' => 'primary',        'default' => '#eda934'],
        '--yooadmin-border'        => ['key' => 'border',         'default' => '#e0e0e0'],
        '--yooadmin-header-bg'     => ['key' => 'header_bg',      'default' => '#4B4B4B'],
        '--yooadmin-breadcrumbs-bg' => ['key' => 'breadcrumbs_bg', 'default' => '#FFFFFF'],
        '--yooadmin-breadcrumbs-fg' => ['key' => 'breadcrumbs_fg', 'default' => '#5d5d5d'],
        '--yooadmin-sidebar-bg'    => ['key' => 'sidebar_bg',     'default' => '#4B4B4B'],
        '--yooadmin-text-contrast' => ['key' => 'text_contrast',  'default' => '#FFFFFF'],
        '--yooadmin-text-600'      => ['key' => 'text_600',       'default' => '#5d5d5d'],
        '--yooadmin-text-500'      => ['key' => 'text_500',       'default' => '#555555'],
        '--yooadmin-card-icon'     => ['key' => 'card_icon',      'default' => '#eda934'],
    ];

    /**
     * Singleton accessor.
     */
    public static function get_instance(): self {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Bootstrap theme manager.
     */
    public function init(): void {
        $this->theme_meta = get_option(self::META_OPTION, []);
        $this->load_themes();
        add_action('admin_init', [$this, 'ensure_active_theme']);
        add_action('admin_head', [$this, 'print_theme_css_variables'], 5);
        add_filter('yooadmin_shell_template_paths', [$this, 'filter_shell_templates']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_theme_assets'], 5);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_theme_compat_stylesheets'], 100);
        add_action('admin_menu', [$this, 'register_admin_page'], 25);
        add_action('admin_post_' . self::ACTIVATE_ACTION, [$this, 'handle_activate_request']);
        add_action('admin_post_' . self::DELETE_ACTION, [$this, 'handle_delete_request']);
        add_action('admin_post_' . self::SAVE_SETTINGS_ACTION, [$this, 'handle_save_settings']);
        add_action('wp_ajax_' . self::SAVE_SETTINGS_ACTION, [$this, 'handle_save_settings']);
        add_filter('yooadmin_logo_url', [$this, 'filter_default_logo_url'], 20);
        add_action('wp_ajax_yooadmin_shell_theme_activate', [$this, 'ajax_shell_theme_activate']);
    }

    /**
     * Ensure option is set to a valid theme slug.
     */
    public function ensure_active_theme(): void {
        $this->load_themes();
        $this->maybe_apply_default_theme_for_new_installs();

        $slug = $this->get_active_theme_slug();
        if (!isset($this->themes[$slug])) {
            $this->set_active_theme($this->get_preferred_default_slug());
        }
    }

    /**
     * Seed the default admin theme when the plugin is activated/reinstalled.
     *
     * Uninstall often keeps options unless "delete data on uninstall" was enabled.
     * Re-activate without legacy upgrade signals should get Studio Hub, not stale Legacy.
     */
    public function handle_plugin_activation(): void {
        $this->load_themes();

        $stored = (string) get_option(self::OPTION_KEY, '');

        if ($stored === self::DEFAULT_SLUG && isset($this->themes[ self::DEFAULT_SLUG ])) {
            return;
        }

        if ($stored === self::LEGACY_SLUG && $this->has_legacy_upgrade_signals()) {
            return;
        }

        delete_option(self::DEFAULT_MIGRATION_OPTION);
        delete_option(self::OPTION_KEY);

        // Keep wizard completion/dismissal on re-activate so general options (e.g. Plugin Basic) are not re-written by setup.
        $preserve_wizard = (bool) get_option('yooadmin_wizard_completed')
            || (bool) get_option('yooadmin_wizard_dismissed');
        if (!$preserve_wizard) {
            delete_option('yooadmin_wizard_completed');
            delete_option('yooadmin_wizard_completed_date');
            delete_option('yooadmin_wizard_dismissed');
        }

        $this->active_slug = null;

        $this->maybe_apply_default_theme_for_new_installs();
    }

    /**
     * Preferred active theme for new installs (Studio Hub when present, else Legacy).
     *
     * @return string
     */
    public function get_preferred_default_slug(): string {
        if (isset($this->themes[self::DEFAULT_SLUG])) {
            return self::DEFAULT_SLUG;
        }

        return self::LEGACY_SLUG;
    }

    /**
     * Whether this site was seeded as a fresh install with Studio Hub (not an upgrade).
     */
    public function is_fresh_studio_hub_install(): bool {
        return (bool) get_option(self::FRESH_INSTALL_MARKER_OPTION, false);
    }

    /**
     * Persist default theme when OPTION_KEY was never saved.
     * Fresh installs get Studio Hub; pre-1.5 sites keep Legacy.
     */
    private function maybe_apply_default_theme_for_new_installs(): void {
        $force_studio_flag = 'yooadmin_force_studio_hub_default_v1';

        if (!get_option($force_studio_flag, false)) {
            $current = (string) get_option(self::OPTION_KEY, '');
            if ($current === self::LEGACY_SLUG && isset($this->themes[ self::DEFAULT_SLUG ])) {
                $this->set_active_theme(self::DEFAULT_SLUG);
            }
            update_option($force_studio_flag, true, false);
        }

        if (get_option(self::DEFAULT_MIGRATION_OPTION, false)) {
            return;
        }

        $sentinel = '__yooadmin_theme_unset__';
        $stored   = get_option(self::OPTION_KEY, $sentinel);

        if ($sentinel === $stored) {
            $slug = $this->get_preferred_default_slug();
            if (isset($this->themes[$slug])) {
                $this->set_active_theme($slug);
            } else {
                $this->set_active_theme($this->get_preferred_default_slug());
            }

            if (self::DEFAULT_SLUG === get_option(self::OPTION_KEY, '')) {
                update_option(self::FRESH_INSTALL_MARKER_OPTION, true, false);
            }
        }

        update_option(self::DEFAULT_MIGRATION_OPTION, true, false);
    }

    /**
     * Detect installs that used YOOAdmin before the admin theme system (1.5).
     */
    private function is_pre_existing_yooadmin_install(): bool {
        return $this->has_legacy_upgrade_signals();
    }

    /**
     * True when the site has real pre-1.5 / customized YOOAdmin data (not wizard-only flags).
     */
    private function has_legacy_upgrade_signals(): bool {
        foreach (['yoopixel_options', 'yoopixel_primary_color', 'yoopixel_focus_active'] as $legacy_key) {
            if (null !== get_option($legacy_key, null)) {
                return true;
            }
        }

        $colors = get_option('yooadmin_colors', []);
        if (is_array($colors) && [] !== $colors) {
            return true;
        }

        $options = get_option('yooadmin_options', []);
        if (is_array($options) && [] !== $options && !$this->options_match_factory_defaults($options)) {
            return true;
        }

        foreach (['yooadmin_welcome', 'yooadmin_quick_actions', 'yooadmin_brand'] as $option_key) {
            $value = get_option($option_key, null);
            if (null !== $value && '' !== $value && [] !== $value) {
                return true;
            }
        }

        return false;
    }

    /**
     * Factory-default option bag (defaults file + activation-only keys).
     *
     * @return array<string,mixed>
     */
    private function get_factory_default_options(): array {
        $defaults = function_exists('yooadmin_default_options') ? yooadmin_default_options() : [];
        if (!is_array($defaults)) {
            $defaults = [];
        }

        return array_merge(
            $defaults,
            [
                'redirect_dashboard' => 1,
                'tags_redirect'      => 1,
            ]
        );
    }

    /**
     * Whether stored options still match an untouched install (incl. post–data-cleanup reset).
     *
     * @param array<string,mixed> $options
     */
    private function options_match_factory_defaults(array $options): bool {
        $defaults = $this->get_factory_default_options();

        foreach ($options as $key => $value) {
            if (!array_key_exists($key, $defaults)) {
                return false;
            }

            if ($value != $defaults[ $key ]) {
                return false;
            }
        }

        return true;
    }

    /**
     * Return all discovered themes.
     *
     * @return array<string,array>
     */
    public function get_themes(): array {
        return $this->themes;
    }

    /**
     * Return the currently active theme definition.
     *
     * @return array|null
     */
    public function get_active_theme(): ?array {
        $slug = $this->get_active_theme_slug();
        return $this->themes[$slug] ?? null;
    }

    /**
     * Whether the active theme declares a manifest feature.
     *
     * @param string $feature Feature key from manifest "features".
     */
    public function theme_has_feature(string $feature): bool {
        $theme = $this->get_active_theme();
        if (!$theme || $feature === '') {
            return false;
        }

        return !empty($theme['features'][sanitize_key($feature)]);
    }

    /**
     * Dashboard template path for the active theme (manifest templates.dashboard).
     */
    public function get_dashboard_template_path(): ?string {
        $theme = $this->get_active_theme();
        if (!$theme || empty($theme['paths']['dashboard'])) {
            return null;
        }

        $path = (string) $theme['paths']['dashboard'];

        return is_readable($path) ? $path : null;
    }

    /**
     * Appearance color mode for shell UI when theme supports appearance_mode.
     *
     * @return string|null light|dark|auto
     */
    public function get_appearance_color_mode_for_ui(): ?string {
        if (!$this->theme_has_feature('appearance_mode')) {
            return null;
        }

        $slug     = $this->get_active_theme_slug();
        $settings = get_option($this->get_theme_settings_option_name($slug), []);
        if (!is_array($settings)) {
            $settings = [];
        }

        if (function_exists('yooadmin_studio_hub_get_color_mode')) {
            return yooadmin_studio_hub_get_color_mode();
        }

        $mode = isset($settings['color_mode']) ? sanitize_key((string) $settings['color_mode']) : 'auto';
        if (!in_array($mode, ['light', 'dark', 'auto'], true)) {
            $mode = 'auto';
        }

        return $mode;
    }

    /**
     * Persist Studio Hub appearance mode (light / dark / auto).
     *
     * @param string $slug Admin theme slug.
     * @param string $mode light|dark|auto
     */
    public function save_appearance_color_mode(string $slug, string $mode): void {
        if (!in_array($mode, ['light', 'dark', 'auto'], true)) {
            return;
        }

        $this->load_themes();
        $theme = $this->themes[$slug] ?? null;
        if (!$theme || !$this->theme_has_feature('appearance_mode')) {
            return;
        }

        $option_name = $this->get_theme_settings_option_name($slug);
        $settings    = get_option($option_name, []);
        if (!is_array($settings)) {
            $settings = [];
        }

        if ($settings === [] && !empty($theme['settings_schema'])) {
            $settings = $this->get_settings_defaults($theme['settings_schema']);
        }

        $settings['color_mode'] = $mode;
        update_option($option_name, $settings, false);

        if (defined('YOOADMIN_STUDIO_HUB_COLOR_MODE_META_KEY') && is_user_logged_in()) {
            update_user_meta((int) get_current_user_id(), YOOADMIN_STUDIO_HUB_COLOR_MODE_META_KEY, $mode);
        }
    }

    /**
     * Set active theme.
     *
     * @param string $slug
     * @return bool
     */
    public function set_active_theme(string $slug): bool {
        if (!isset($this->themes[$slug])) {
            return false;
        }
        $updated = update_option(self::OPTION_KEY, $slug);
        if ($updated || get_option(self::OPTION_KEY) === $slug) {
            $this->active_slug = $slug;
            $this->maybe_initialize_theme_settings($slug);
            /**
             * Fires when an admin theme becomes active.
             *
             * @param string $slug
             * @param array  $theme
             */
            do_action('yooadmin_admin_theme_activated', $slug, $this->themes[$slug]);
            return true;
        }
        return false;
    }

    /**
     * Filter shell template paths to use active theme templates when available.
     *
     * @param array $paths
     * @return array
     */
    public function filter_shell_templates(array $paths): array {
        $theme = $this->get_active_theme();
        if (!$theme || empty($theme['paths']) || !is_array($theme['paths'])) {
            return $paths;
        }

        foreach (['header', 'footer', 'sidebar'] as $area) {
            if (!empty($theme['paths'][$area]) && file_exists($theme['paths'][$area])) {
                $paths[$area] = $theme['paths'][$area];
            }
        }

        return $paths;
    }

    /**
     * Enqueue styles/scripts for the active theme.
     */
    public function enqueue_theme_assets($hook = ''): void {
        if (!is_admin()) {
            return;
        }

        if ($hook === 'yooadmin_page_' . $this->menu_slug) {
            $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
            $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);
            $upload_css_rel = 'assets/css/admin/upload-page.css';
            $upload_css_abs = $base_dir . $upload_css_rel;
            $themes_page_css_rel = 'assets/css/admin/yooadmin-themes-page.css';
            $themes_page_css_abs = $base_dir . $themes_page_css_rel;
            if (file_exists($upload_css_abs)) {
                wp_enqueue_style('yooadmin-upload-page', $base_url . $upload_css_rel, [], filemtime($upload_css_abs));
            } elseif (file_exists($themes_page_css_abs)) {
                wp_enqueue_style('yooadmin-themes-page', $base_url . $themes_page_css_rel, [], filemtime($themes_page_css_abs));
            }
            $css_rel  = 'assets/css/admin/yooadmin-admin-themes.css';
            $css_abs  = $base_dir . $css_rel;
            if (file_exists($css_abs)) {
                $deps = ['wp-components'];
                if (file_exists($upload_css_abs)) {
                    $deps[] = 'yooadmin-upload-page';
                } elseif (file_exists($themes_page_css_abs)) {
                    $deps[] = 'yooadmin-themes-page';
                }
                wp_enqueue_style('yooadmin-admin-themes', $base_url . $css_rel, $deps, filemtime($css_abs));
            }

            $js_rel = 'assets/js/admin/yooadmin-shell-themes-page.js';
            $js_abs = $base_dir . $js_rel;
            if (file_exists($js_abs)) {
                wp_enqueue_script(
                    'yooadmin-shell-themes-page',
                    $base_url . $js_rel,
                    ['jquery'],
                    (string) filemtime($js_abs),
                    true
                );
                $delete_nonces = [];
                foreach (array_keys($this->get_themes()) as $slug_key) {
                    $slug_key = (string) $slug_key;
                    if ($slug_key === '' || !empty($this->themes[$slug_key]['builtin'])) {
                        continue;
                    }
                    $delete_nonces[$slug_key] = wp_create_nonce(self::DELETE_ACTION . '_' . $slug_key);
                }
                wp_localize_script(
                    'yooadmin-shell-themes-page',
                    'yooadminShellThemes',
                    [
                        'ajaxurl'       => admin_url('admin-ajax.php'),
                        'adminPostUrl'  => admin_url('admin-post.php'),
                        'deleteAction'  => self::DELETE_ACTION,
                        'activateNonce' => wp_create_nonce('yooadmin_shell_theme_activate'),
                        'settingsUrl'   => $this->get_theme_settings_page_url(),
                        'deleteNonces'  => $delete_nonces,
                        'i18n'          => [
                            'active'         => __('Active', 'yooadmin'),
                            'inactive'       => __('Inactive', 'yooadmin'),
                            'activate'       => __('Activate', 'yooadmin'),
                            'adjustSettings' => __('Adjust settings', 'yooadmin'),
                            'delete'         => __('Delete', 'yooadmin'),
                            'deleteConfirm'  => __('Delete this admin theme?', 'yooadmin'),
                            'activated'      => __('Theme activated successfully.', 'yooadmin'),
                            'activateFail'   => __('Could not activate theme.', 'yooadmin'),
                            'uploading'      => __('Uploading…', 'yooadmin'),
                            'uploadOk'       => __('Theme uploaded successfully.', 'yooadmin'),
                            'uploadFail'     => __('Upload failed.', 'yooadmin'),
                            'invalidZip'     => __('Please choose a .zip file.', 'yooadmin'),
                        ],
                    ]
                );
            }
        } elseif ($hook === 'yooadmin_page_' . $this->settings_page_slug) {
            $this->enqueue_theme_settings_assets();
        }

        $theme = $this->get_active_theme();
        if (!$theme) {
            return;
        }

        if (!$this->body_class_hooked) {
            add_filter('admin_body_class', [$this, 'filter_admin_body_class']);
            $this->body_class_hooked = true;
        }

        if (!$this->should_enqueue_theme_shell()) {
            return;
        }

        $assets = $theme['assets'] ?? [];

        if (!empty($assets['styles']) && is_array($assets['styles'])) {
            foreach ($assets['styles'] as $style) {
                $this->enqueue_style($theme['slug'], $style);
            }
        }

        if (!empty($assets['scripts']) && is_array($assets['scripts'])) {
            foreach ($assets['scripts'] as $script) {
                $this->enqueue_script($theme['slug'], $script);
            }
        }
    }

    /**
     * Late compat stylesheets declared in manifest "compat" (e.g. Woo after wc-admin-app).
     */
    public function enqueue_theme_compat_stylesheets(): void {
        if (!is_admin()) {
            return;
        }

        if (!$this->should_enqueue_theme_shell()) {
            return;
        }

        $theme = $this->get_active_theme();
        if (!$theme || empty($theme['compat']) || !is_array($theme['compat'])) {
            return;
        }

        $woo = $theme['compat']['woocommerce'] ?? null;
        if (!is_array($woo) || empty($woo['stylesheet'])) {
            return;
        }

        if (!$this->theme_has_feature('woocommerce_compat')) {
            return;
        }

        if (!function_exists('yooadmin_is_wc_screen') || !yooadmin_is_wc_screen()) {
            return;
        }

        if (!wp_style_is('wc-admin-app', 'enqueued')) {
            return;
        }

        $file = ltrim((string) $woo['stylesheet'], '/');
        $path = $theme['base_dir'] . $file;
        if (!is_readable($path)) {
            return;
        }

        $handle = !empty($woo['handle']) ? sanitize_key((string) $woo['handle']) : 'yooadmin-admin-theme-compat-woo';
        $deps   = isset($woo['deps']) && is_array($woo['deps']) ? $this->filter_registered_style_deps($woo['deps']) : ['wc-admin-app'];

        if (!empty($theme['assets']['styles']) && is_array($theme['assets']['styles'])) {
            $style_assets = $theme['assets']['styles'];
            $last_style   = end($style_assets);
            if (is_array($last_style) && !empty($last_style['handle'])) {
                $last_handle = (string) $last_style['handle'];
                if (wp_style_is($last_handle, 'registered') || wp_style_is($last_handle, 'enqueued')) {
                    $deps[] = $last_handle;
                }
            }
        }

        wp_enqueue_style(
            $handle,
            trailingslashit($theme['base_url']) . str_replace('\\', '/', $file),
            array_values(array_unique($deps)),
            (string) filemtime($path)
        );
    }

    /**
     * Ensure assets required for the theme settings screen are loaded.
     */
    private function enqueue_theme_settings_assets(): void {
        $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
        $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');

        $btn_css_rel = 'assets/css/admin/yp-yoo-buttons.css';
        $btn_css_abs = $base_dir . $btn_css_rel;
        if (file_exists($btn_css_abs)) {
            wp_enqueue_style(
                'yooadmin-yoo-buttons',
                $base_url . $btn_css_rel,
                [],
                filemtime($btn_css_abs)
            );
        }

        $css_rel = 'assets/css/admin/yooadmin-theme-settings.css';
        $css_abs = $base_dir . $css_rel;
        if (file_exists($css_abs)) {
            wp_enqueue_style(
                'yooadmin-theme-settings',
                $base_url . $css_rel,
                ['wp-components', 'wp-color-picker', 'yooadmin-yoo-buttons'],
                filemtime($css_abs)
            );
        }

        $js_rel = 'assets/js/admin/yooadmin-theme-settings.js';
        $js_abs = $base_dir . $js_rel;
        if (file_exists($js_abs)) {
            wp_enqueue_script('yooadmin-theme-settings', $base_url . $js_rel, ['jquery', 'wp-color-picker'], filemtime($js_abs), true);

            $localize_theme_settings = static function (): array {
                return [
                    'colorPicker' => function_exists('yooadmin_get_modern_color_picker_i18n')
                        ? yooadmin_get_modern_color_picker_i18n()
                        : [],
                ];
            };

            wp_localize_script(
                'yooadmin-theme-settings',
                'yooadminThemeSettings',
                function_exists('yooadmin_with_admin_ui_locale')
                    ? yooadmin_with_admin_ui_locale($localize_theme_settings)
                    : $localize_theme_settings()
            );
        }
    }

    /**
     * Whether the active admin theme should load shell CSS/JS and compat styles.
     * Matches YOOAdmin core: native WP layout when Focus Mode is off.
     */
    private function should_enqueue_theme_shell(): bool {
        $enabled = true;
        if (function_exists('yooadmin_is_focus_enabled')) {
            $enabled = yooadmin_is_focus_enabled();
        }

        /**
         * Filter whether the active admin theme enqueues shell assets (manifest styles/scripts, Woo compat).
         *
         * @param bool $enabled True when Focus Mode is on (default).
         */
        return (bool) apply_filters('yooadmin_admin_theme_should_enqueue_shell', $enabled);
    }

    /**
     * Inject body class for active theme.
     *
     * @param string $classes
     * @return string
     */
    public function filter_admin_body_class(string $classes): string {
        $slug = $this->get_active_theme_slug();
        if ($slug) {
            $slug_class = sanitize_html_class($slug);
            $classes   .= ' yooadmin-theme-active yooadmin-theme-' . $slug_class;

            if (strpos($slug, 'yooadmin-') === 0) {
                $trimmed = substr($slug, strlen('yooadmin-'));
                if ($trimmed !== '') {
                    $classes .= ' yooadmin-theme-' . sanitize_html_class($trimmed);
                }
            }
        }
        return $classes;
    }

    /**
     * Print inline CSS variables early to avoid flash of legacy styles.
     */
    public function print_theme_css_variables(): void {
        if (!is_admin()) {
            return;
        }

        $theme = $this->get_active_theme();
        if (!$theme) {
            return;
        }

        if (empty($theme['settings_schema'])) {
            return;
        }

        $slug     = $theme['slug'];
        $settings = $this->get_theme_settings_values($slug);
        $palette  = isset($settings['header_palette']) ? sanitize_key($settings['header_palette']) : '';

        if (strpos($slug, 'yooadmin-') === 0) {
            $slug = substr($slug, strlen('yooadmin-'));
        }

        if ($slug !== 'fusion') {
            return;
        }

        $accent = isset($settings['accent_color']) ? sanitize_hex_color($settings['accent_color']) : '#eda934';
        if (!$accent) {
            $accent = '#eda934';
        }

        $accent_hex = ltrim($accent, '#');
        if (strlen($accent_hex) === 3) {
            $accent_hex = $accent_hex[0] . $accent_hex[0] . $accent_hex[1] . $accent_hex[1] . $accent_hex[2] . $accent_hex[2];
        }
        $accent_rgb = [
            hexdec(substr($accent_hex, 0, 2)),
            hexdec(substr($accent_hex, 2, 2)),
            hexdec(substr($accent_hex, 4, 2)),
        ];
        $luminance = ($accent_rgb[0] * 0.299 + $accent_rgb[1] * 0.587 + $accent_rgb[2] * 0.114) / 255;
        $accent_contrast = $luminance > 0.57 ? '#2d2d2d' : '#F5F5F5';

        $palettes = [
            'yoopixel' => [
                'from'            => '#0045a0',
                'to'              => '#062968',
                'sidebar_bg'      => 'rgba(5, 33, 78, 0.97)',
                'sidebar_text'    => '#dbe4f8',
                'sidebar_active_bg'   => 'rgba(238, 180, 78, 0.18)',
                'sidebar_active_text' => '#ffffff',
            ],
            'sunset' => [
                'from'            => '#3a3d72',
                'to'              => '#191f38',
                'sidebar_bg'      => 'rgba(17, 24, 39, 0.97)',
                'sidebar_text'    => '#d1d5db',
                'sidebar_active_bg'   => 'rgba(238, 180, 78, 0.18)',
                'sidebar_active_text' => '#f9fafb',
            ],
            'ocean' => [
                'from'            => '#1e3a8a',
                'to'              => '#0f172a',
                'sidebar_bg'      => 'rgba(15, 23, 42, 0.96)',
                'sidebar_text'    => '#dbeafe',
                'sidebar_active_bg'   => 'rgba(238, 180, 78, 0.18)',
                'sidebar_active_text' => '#eff6ff',
            ],
            'forest' => [
                'from'            => '#0f766e',
                'to'              => '#0b3a2d',
                'sidebar_bg'      => 'rgba(5, 46, 38, 0.95)',
                'sidebar_text'    => '#bbf7d0',
                'sidebar_active_bg'   => 'rgba(238, 180, 78, 0.18)',
                'sidebar_active_text' => '#ecfdf5',
            ],
            'mono' => [
                'from'            => '#2a2a2a',
                'to'              => '#111213',
                'sidebar_bg'      => 'rgba(20, 22, 23, 0.96)',
                'sidebar_text'    => '#e5e7eb',
                'sidebar_active_bg'   => 'rgba(238, 180, 78, 0.18)',
                'sidebar_active_text' => '#f9fafb',
            ],
        ];

        $palette_config = $palettes[$palette] ?? $palettes['yoopixel'];
        $palette_config['sidebar_active_bg']   = sprintf('rgba(%d, %d, %d, 0.20)', $accent_rgb[0], $accent_rgb[1], $accent_rgb[2]);
        $palette_config['sidebar_active_text'] = $accent_contrast;

        $header_bg = $settings['header_bg'] ?? '';
        $header_bg = $header_bg ? sanitize_hex_color($header_bg) : '';
        if (!$header_bg) {
            $globals = get_option('yooadmin_colors', []);
            if (!empty($globals['header_bg'])) {
                $header_bg = sanitize_hex_color($globals['header_bg']);
            }
        }

        if (!$header_bg) {
            $header_bg = '#5D5D5D';
        }

        $styles = [
            '--yaf-accent'             => $accent,
            '--yaf-accent-contrast'    => $accent_contrast,
            '--yaf-header-from'        => $header_bg,
            '--yaf-header-to'          => $header_bg,
            '--yaf-header-text'        => '#1f2933',
            '--yaf-sidebar-bg'         => $palette_config['sidebar_bg'],
            '--yaf-sidebar-text'       => $palette_config['sidebar_text'],
            '--yaf-sidebar-active-bg'  => $palette_config['sidebar_active_bg'],
            '--yaf-sidebar-active-text'=> $palette_config['sidebar_active_text'],
        ];

        $css_vars = array_reduce(array_keys($styles), function($carry, $key) use ($styles) {
            $value = $styles[$key];
            if (!$value) {
                return $carry;
            }
            return $carry . sprintf('%s:%s;', esc_html($key), esc_html($value));
        }, '');

        if ($css_vars) {
            printf('<style id="yooadmin-theme-fusion-vars">:root{%s}</style>', esc_attr($css_vars));
        }
    }

    /**
     * Register submenu for managing admin themes.
     */
    public function register_admin_page(): void {
        if (!function_exists('yooadmin_dashboard_slug')) {
            return;
        }

        $parent_slug = yooadmin_dashboard_slug();
        $capability  = $this->get_required_capability();

        // Remove existing legacy page if registered earlier.
        remove_submenu_page($parent_slug, 'yooadmin-themes');

        add_submenu_page(
            $parent_slug,
            __('Themes', 'yooadmin'),
            __('Themes', 'yooadmin'),
            $capability,
            $this->menu_slug,
            [$this, 'render_admin_page'],
            35
        );

        add_submenu_page(
            '',
            __('Active theme settings', 'yooadmin'),
            __('Active theme settings', 'yooadmin'),
            $capability,
            $this->settings_page_slug,
            [$this, 'render_theme_settings_page'],
            36
        );
    }

    /**
     * Render admin page with available themes.
     */
    public function render_admin_page(): void {
        global $title;
        $title = __('Themes', 'yooadmin');
        
        if (!current_user_can($this->get_required_capability())) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        $themes      = $this->get_themes();
        $active_slug = $this->get_active_theme_slug();
        $action_url  = admin_url('admin-post.php');

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only GET status display, no state change.
        $status_code = isset($_GET['theme_status']) ? sanitize_key(wp_unslash($_GET['theme_status'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only GET status display, no state change.
        $status_slug = isset($_GET['theme']) ? sanitize_key(wp_unslash($_GET['theme'])) : '';

        $messages = [
            'activated'             => __('Theme activated successfully.', 'yooadmin'),
            'error'                 => __('Unable to activate the selected theme. Please try again.', 'yooadmin'),
            'invalid'               => __('Invalid theme activation request.', 'yooadmin'),
            'upload_success'        => __('Theme uploaded successfully. You can activate it below.', 'yooadmin'),
            'upload_updated'        => __('Theme files updated successfully.', 'yooadmin'),
            'upload_exists'         => __('A theme with that slug already exists. Remove the existing theme or use a different slug.', 'yooadmin'),
            'upload_invalid'        => __('Uploaded file is not a valid YOOAdmin admin theme package.', 'yooadmin'),
            'upload_replace_failed' => __('Unable to replace the existing theme files.', 'yooadmin'),
            'upload_error'          => __('There was an error uploading the theme. Please try again.', 'yooadmin'),
            'upload_security'       => __('Upload failed security check. Please refresh and try again.', 'yooadmin'),
            'delete_success'        => __('Theme deleted successfully.', 'yooadmin'),
            'delete_active'         => __('Deactivate the theme before deleting it.', 'yooadmin'),
            'delete_invalid'        => __('Unable to delete the selected theme.', 'yooadmin'),
            'delete_error'          => __('Failed to delete the theme directory.', 'yooadmin'),
            'settings_saved'        => __('Theme settings saved successfully.', 'yooadmin'),
            'settings_error'        => __('Unable to save theme settings. Please try again.', 'yooadmin'),
        ];

        $notice = ($status_code && isset($messages[$status_code])) ? $messages[$status_code] : '';
        $upload_supported = $this->theme_upload_supported();
        $extended_url     = 'https://www.yooadmin.io/';

        ?>
        <div class="wrap yoo-upload-wrap yooadmin-admin-themes-wrap yoo-theme-manager-wrap" data-page="yooadmin-themes">
            <div class="yooadmin-shell-notice-anchor" aria-live="polite"></div>
            <div class="yoo-upload-header">
                <div class="yoo-upload-header-content">
                    <h1 class="yoo-upload-title">
                        <span class="dashicons dashicons-admin-appearance yoo-upload-title-dashicon" aria-hidden="true"></span>
                        <?php esc_html_e('Themes', 'yooadmin'); ?>
                    </h1>
                    <p class="yoo-upload-subtitle" dir="auto">
                        <?php if ($upload_supported) : ?>
                            <?php esc_html_e('Install admin theme packages to customize the YOOAdmin shell. Activate a theme below to apply its layout and styling.', 'yooadmin'); ?>
                        <?php else : ?>
                            <?php esc_html_e('Included admin themes update with YOOAdmin releases. Activate a theme below to apply its layout and styling.', 'yooadmin'); ?>
                        <?php endif; ?>
                    </p>
                </div>
            </div>

            <?php if (!$upload_supported) : ?>
                <div class="yooadmin-themes-lite-upsell" role="note">
                    <p>
                        <?php esc_html_e('Want more admin themes?', 'yooadmin'); ?>
                        <?php esc_html_e('Get YOOAdmin Extended at', 'yooadmin'); ?>
                        <a href="<?php echo esc_url($extended_url); ?>" target="_blank" rel="noopener noreferrer">yooadmin.io</a>.
                    </p>
                </div>
            <?php endif; ?>

            <?php if ($notice) : ?>
                <div class="notice notice-info is-dismissible">
                    <p><?php echo esc_html($notice); ?></p>
                </div>
            <?php endif; ?>

            <?php if (empty($themes)) : ?>
                <div class="notice notice-warning">
                    <p><?php esc_html_e('No admin themes were found.', 'yooadmin'); ?></p>
                </div>
            <?php else : ?>

            <div id="wp-results" class="yoo-wordpress-results yoo-plugins-grid yooadmin-admin-themes-results" data-yooadmin-shell-themes="1">
                <?php foreach ($themes as $slug => $theme):
                    $is_active   = ($slug === $active_slug);
                    $title       = $this->translate_theme_ui_string((string) ($theme['name'] ?? $slug));
                    $description = $this->translate_theme_ui_string((string) ($theme['description'] ?? ''));
                    $version     = $theme['version'] ?? '';
                    $author      = $theme['author'] ?? '';
                    $builtin     = !empty($theme['builtin']);
                    $is_legacy   = ($slug === self::LEGACY_SLUG);
                    $screenshot  = $this->get_theme_screenshot_url($theme);
                    $show_free_badge = !$upload_supported && $builtin;
                    $top_tags_hover  = !$is_active ? ' yoo-theme-card-top-tags--inactive-hover-only' : '';
                    $top_tags_free   = $show_free_badge ? ' yoo-theme-card-top-tags--has-free' : '';
                    ?>
                    <div class="yoo-plugin-card yoo-theme-card<?php echo $is_active ? ' active' : ''; ?>"
                         data-yooadmin-shell-theme-slug="<?php echo esc_attr($slug); ?>"
                         data-builtin="<?php echo $builtin ? '1' : '0'; ?>">
                        <div class="yoo-theme-card-media-wrap">
                            <?php if ($screenshot) : ?>
                                <div class="yoo-theme-card-media" style="background-image:url('<?php echo esc_url($screenshot); ?>');" role="img" aria-label="<?php echo esc_attr($title); ?>"></div>
                            <?php else : ?>
                                <div class="yoo-theme-card-media yoo-theme-card-media--placeholder" aria-hidden="true">
                                    <span class="dashicons dashicons-admin-customizer"></span>
                                </div>
                            <?php endif; ?>
                            <div class="yoo-theme-card-hover-glass" aria-hidden="true"></div>
                            <div class="yoo-theme-card-hover-text">
                                <span class="yoo-theme-card-hover-title"><?php echo esc_html($title); ?></span>
                                <?php if ($author !== '') : ?>
                                    <span class="yoo-theme-card-hover-author"><?php echo esc_html($author); ?></span>
                                <?php endif; ?>
                                <?php if ($description !== '') : ?>
                                    <span class="yooadmin-shell-theme-hover-desc"><?php echo esc_html(wp_trim_words($description, 22)); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="yoo-theme-card-top-tags<?php echo esc_attr($top_tags_hover . $top_tags_free); ?>">
                                <?php if ($show_free_badge) : ?>
                                    <span class="yoo-theme-version-tag yoo-theme-free-tag"><?php echo esc_html_x('FREE', 'admin theme badge', 'yooadmin'); ?></span>
                                <?php endif; ?>
                                <?php if ($is_legacy) : ?>
                                    <span class="yoo-theme-version-tag yoo-theme-classic-tag"><?php echo esc_html_x('Classic', 'admin theme badge', 'yooadmin'); ?></span>
                                <?php endif; ?>
                                <?php if ($version !== '') : ?>
                                    <span class="yoo-theme-version-tag"><?php echo esc_html('v' . $version); ?></span>
                                <?php endif; ?>
                                <div class="yoo-theme-status-tag" role="status">
                                    <span class="yoo-theme-status-tag__pill <?php echo $is_active ? 'yoo-theme-status-tag__pill--active' : 'yoo-theme-status-tag__pill--inactive'; ?>">
                                        <?php
                                        echo $is_active
                                            ? esc_html__('Active', 'yooadmin')
                                            : esc_html__('Inactive', 'yooadmin');
                                        ?>
                                    </span>
                                </div>
                            </div>
                            <div class="yoo-theme-card__actions-overlay">
                                <div class="yoo-theme-card__actions-bar">
                                    <?php if (!$is_active) : ?>
                                        <button type="button" class="yoo-media-float-btn yoo-install-btn yooadmin-shell-theme-activate" data-slug="<?php echo esc_attr($slug); ?>" title="<?php esc_attr_e('Activate', 'yooadmin'); ?>" aria-label="<?php esc_attr_e('Activate', 'yooadmin'); ?>">
                                            <span class="dashicons dashicons-yes" aria-hidden="true"></span>
                                        </button>
                                    <?php endif; ?>
                                    <?php if ($is_active) : ?>
                                        <a class="yoo-media-float-btn yoo-theme-customize" href="<?php echo esc_url($this->get_theme_settings_page_url()); ?>" title="<?php esc_attr_e('Adjust settings', 'yooadmin'); ?>" aria-label="<?php esc_attr_e('Adjust settings', 'yooadmin'); ?>">
                                            <span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
                                        </a>
                                    <?php endif; ?>
                                    <?php if ($upload_supported && !$builtin && !$is_active) : ?>
                                        <form method="post" action="<?php echo esc_url($action_url); ?>" class="yooadmin-shell-theme-inline-form" data-yooadmin-shell-delete-form="1">
                                            <?php wp_nonce_field(self::DELETE_ACTION . '_' . $slug); ?>
                                            <input type="hidden" name="action" value="<?php echo esc_attr(self::DELETE_ACTION); ?>">
                                            <input type="hidden" name="theme_slug" value="<?php echo esc_attr($slug); ?>">
                                            <button type="submit" class="yoo-media-float-btn danger yoo-delete-btn" title="<?php esc_attr_e('Delete', 'yooadmin'); ?>" aria-label="<?php esc_attr_e('Delete', 'yooadmin'); ?>">
                                                <span class="dashicons dashicons-trash" aria-hidden="true"></span>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php endif; ?>

        </div>
        <?php
    }

    /**
     * Handle theme activation request.
     */
    public function handle_activate_request(): void {
        if (!current_user_can($this->get_required_capability())) {
            wp_die(esc_html__('Sorry, you are not allowed to do this.', 'yooadmin'));
        }

        $slug = isset($_POST['theme_slug']) ? sanitize_key(wp_unslash($_POST['theme_slug'])) : '';

        if (!$slug || !isset($this->themes[$slug])) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'invalid',
                'theme'        => $slug,
            ]));
            exit;
        }

        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), self::ACTIVATE_ACTION . '_' . $slug)) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'invalid',
                'theme'        => $slug,
            ]));
            exit;
        }

        $result = $this->set_active_theme($slug);

        wp_safe_redirect($this->get_admin_page_url([
            'theme_status' => $result ? 'activated' : 'error',
            'theme'        => $slug,
        ]));
        exit;
    }

    /**
     * AJAX: activate an admin shell theme.
     */
    public function ajax_shell_theme_activate(): void {
        if (!current_user_can($this->get_required_capability())) {
            wp_send_json_error(['message' => 'Forbidden.'], 403);
        }

        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'yooadmin_shell_theme_activate')) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        $slug = isset($_POST['theme_slug']) ? sanitize_key(wp_unslash($_POST['theme_slug'])) : '';
        if ($slug === '') {
            wp_send_json_error(['message' => 'Invalid theme.'], 400);
        }

        $this->load_themes();
        if (!isset($this->themes[$slug])) {
            wp_send_json_error(['message' => 'Unknown theme.'], 404);
        }

        if (!$this->set_active_theme($slug)) {
            wp_send_json_error(['message' => 'Could not activate theme.'], 500);
        }

        $color_mode = isset($_POST['color_mode']) ? sanitize_key(wp_unslash($_POST['color_mode'])) : '';
        if ($color_mode !== '' && in_array($color_mode, ['light', 'dark', 'auto'], true)) {
            $this->save_appearance_color_mode($slug, $color_mode);
        }

        wp_send_json_success(
            [
                'active'       => $slug,
                'message'      => 'Theme activated successfully.',
                'settingsUrl'  => $this->get_theme_settings_page_url(),
            ]
        );
    }

    /**
     * AJAX: upload admin shell theme ZIP (same validation as admin-post handler).
     */
    public function ajax_shell_theme_upload(): void {
        if (!current_user_can($this->get_required_capability())) {
            wp_send_json_error(['message' => 'Forbidden.'], 403);
        }

        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, self::UPLOAD_ACTION)) {
            wp_send_json_error(['message' => 'Security check failed.'], 403);
        }

        if (empty($_FILES['theme_zip']) || !is_array($_FILES['theme_zip'])) {
            wp_send_json_error(['message' => 'No file uploaded.'], 400);
        }

        $uploaded = $this->handle_zip_upload($_FILES['theme_zip']); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Binary upload.

        if (is_wp_error($uploaded)) {
            wp_send_json_error(['message' => $uploaded->get_error_message() ?: 'Upload failed.'], 400);
        }

        $result = $this->process_uploaded_theme($uploaded['file']);

        if (!empty($uploaded['file']) && file_exists($uploaded['file'])) {
            wp_delete_file($uploaded['file']);
        }

        if (is_wp_error($result)) {
            $msg = $result->get_error_message() ?: 'Upload failed.';
            wp_send_json_error(['message' => $msg], 400);
        }

        $status = isset($result['status']) && $result['status'] === 'updated' ? 'Theme files updated successfully.' : 'Theme uploaded successfully. You can activate it below.';

        wp_send_json_success(
            [
                'message' => $status,
                'slug'    => isset($result['slug']) ? (string) $result['slug'] : '',
            ]
        );
    }

    /**
     * Handle admin theme upload request.
     */
    public function handle_upload_request(): void {
        if (!current_user_can($this->get_required_capability())) {
            wp_die(esc_html__('Sorry, you are not allowed to upload themes.', 'yooadmin'));
        }

        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), self::UPLOAD_ACTION)) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'upload_security',
            ]));
            exit;
        }

        if (empty($_FILES['theme_zip']) || !is_array($_FILES['theme_zip'])) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'upload_invalid',
            ]));
            exit;
        }

        $uploaded = $this->handle_zip_upload($_FILES['theme_zip']); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- File upload handled by handle_zip_upload() with wp_handle_upload().

        if (is_wp_error($uploaded)) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'upload_error',
            ]));
            exit;
        }

        $result = $this->process_uploaded_theme($uploaded['file']);

        // Clean up uploaded temporary file
        if (!empty($uploaded['file']) && file_exists($uploaded['file'])) {
            wp_delete_file($uploaded['file']);
        }

        if (is_wp_error($result)) {
            $code = $result->get_error_code();
            $status = in_array($code, ['upload_exists', 'upload_invalid', 'upload_replace_failed'], true) ? $code : 'upload_error';
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => $status,
            ]));
            exit;
        }

        $status = isset($result['status']) && $result['status'] === 'updated' ? 'upload_updated' : 'upload_success';
        $slug   = isset($result['slug']) ? $result['slug'] : '';

        wp_safe_redirect($this->get_admin_page_url([
            'theme_status' => $status,
            'theme'        => $slug,
        ]));
        exit;
    }

    /**
     * Handle deletion of a theme.
     */
    public function handle_delete_request(): void {
        if (!current_user_can($this->get_required_capability())) {
            wp_die(esc_html__('Sorry, you are not allowed to delete themes.', 'yooadmin'));
        }

        $slug = isset($_POST['theme_slug']) ? sanitize_key(wp_unslash($_POST['theme_slug'])) : '';

        if (!$slug || !isset($this->themes[$slug])) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'delete_invalid',
            ]));
            exit;
        }

        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), self::DELETE_ACTION . '_' . $slug)) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'delete_invalid',
            ]));
            exit;
        }

        if (!empty($this->themes[$slug]['builtin'])) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'delete_invalid',
            ]));
            exit;
        }

        if ($slug === $this->get_active_theme_slug()) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'delete_active',
            ]));
            exit;
        }

        $path = trailingslashit(YOOADMIN_ADMIN_THEMES_DIR) . $slug;
        if (!is_dir($path)) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'delete_invalid',
            ]));
            exit;
        }

        $deleted = $this->cleanup_dir($path);

        if (!$deleted || is_dir($path)) {
            wp_safe_redirect($this->get_admin_page_url([
                'theme_status' => 'delete_error',
            ]));
            exit;
        }

        $this->delete_theme_meta($slug);
        $this->delete_theme_settings($slug);

        // Refresh list
        $this->load_themes();

        wp_safe_redirect($this->get_admin_page_url([
            'theme_status' => 'delete_success',
        ]));
        exit;
    }

    /**
     * Discover themes and build registry.
     */
    private function load_themes(): void {
        $this->themes = [];
        $this->register_builtin_theme();
        $this->discover_bundled_themes();
        $this->discover_external_themes();
        /**
         * Allow external code to modify the final themes registry.
         *
         * @param array<string,array> $themes
         */
        $this->themes = apply_filters('yooadmin_admin_themes', $this->themes);

        // Attach metadata
        foreach ($this->themes as $slug => &$theme) {
            $meta = $this->theme_meta[$slug] ?? [];
            if (empty($meta) && !empty($theme['builtin'])) {
                $meta = [
                    'source'       => 'builtin',
                    'installed_at' => null,
                ];
            }
            if (empty($meta['source'])) {
                $meta['source'] = !empty($theme['builtin']) ? 'builtin' : 'filesystem';
            }
            if (!array_key_exists('installed_at', $meta)) {
                $meta['installed_at'] = null;
            }
            if (!isset($theme['settings_schema']) || !is_array($theme['settings_schema'])) {
                $theme['settings_schema'] = [];
            }
            if (empty($theme['features']) || !is_array($theme['features'])) {
                $theme['features'] = [];
            }
            if (!isset($theme['supports_brand_colors'])) {
                $theme['supports_brand_colors'] = !empty($theme['features']['brand_colors']);
            }
            if (empty($theme['branding']) || !is_array($theme['branding'])) {
                $theme['branding'] = [];
            }
            $theme['meta'] = $meta;
            if (empty($theme['compat']) || !is_array($theme['compat'])) {
                $theme['compat'] = [];
            }
        }
        unset($theme);

        $active_slug = $this->get_active_theme_slug();
        if (isset($this->themes[$active_slug])) {
            $this->maybe_load_theme_bootstrap($this->themes[$active_slug]);
        }
    }

    /**
     * Register the legacy built-in theme as fallback.
     */
    private function register_builtin_theme(): void {
        $this->themes[self::LEGACY_SLUG] = [
            'slug'        => self::LEGACY_SLUG,
            'name'        => __('YOOPixel Legacy Shell', 'yooadmin'),
            'description' => __('Classic YOOAdmin shell for the original admin experience.', 'yooadmin'),
            'version'     => '1.0.0',
            'author'      => 'YOOPixel',
            'builtin'     => true,
            'features'    => [],
            'supports_brand_colors' => true,
            'branding'    => [],
            'paths'       => [
                'header'  => YOOADMIN_DIR . 'templates/yoopixel/admin/layout/header.php',
                'footer'  => YOOADMIN_DIR . 'templates/yoopixel/admin/layout/footer.php',
                'sidebar' => null,
                'settings'=> null,
            ],
            'assets'      => [
                'styles'  => [],
                'scripts' => [],
            ],
            'base_dir'    => trailingslashit(YOOADMIN_DIR . 'templates/yoopixel/admin'),
            'base_url'    => trailingslashit(plugins_url('templates/yoopixel/admin', YOOADMIN_PLUGIN_FILE)),
            'settings_schema' => [],
            'raw'         => [
                'preview' => plugins_url('assets/images/theme-screenshots/legacy-shell.svg', YOOADMIN_PLUGIN_FILE),
            ],
        ];
    }

    /**
     * Discover admin themes bundled inside the plugin (Studio Hub, etc.).
     */
    private function discover_bundled_themes(): void {
        if (!defined('YOOADMIN_BUNDLED_ADMIN_THEMES_DIR') || !defined('YOOADMIN_BUNDLED_ADMIN_THEMES_URL')) {
            return;
        }

        $base_dir = trailingslashit(wp_normalize_path(YOOADMIN_BUNDLED_ADMIN_THEMES_DIR));
        if (!is_dir($base_dir) || !is_readable($base_dir)) {
            return;
        }

        $directories = glob($base_dir . '*', GLOB_ONLYDIR);
        if (empty($directories)) {
            return;
        }

        foreach ($directories as $dir) {
            $slug = basename($dir);
            if (!$this->is_valid_slug($slug)) {
                continue;
            }

            $theme = $this->build_theme_from_directory(
                $slug,
                trailingslashit($dir),
                trailingslashit(YOOADMIN_BUNDLED_ADMIN_THEMES_URL) . $slug . '/',
                true
            );
            if ($theme) {
                $this->themes[$slug] = $theme;
            }
        }
    }

    /**
     * Discover external themes from wp-content/yooadmin/themes/ (uploads, paid packs).
     */
    private function discover_external_themes(): void {
        if (!defined('YOOADMIN_ADMIN_THEMES_DIR')) {
            return;
        }

        $base_dir = trailingslashit(wp_normalize_path(YOOADMIN_ADMIN_THEMES_DIR));
        if (!is_dir($base_dir) || !is_readable($base_dir)) {
            return;
        }

        $directories = glob($base_dir . '*', GLOB_ONLYDIR);
        if (empty($directories)) {
            return;
        }

        foreach ($directories as $dir) {
            $slug = basename($dir);
            if (!$this->is_valid_slug($slug)) {
                continue;
            }

            // Bundled Studio Hub in the plugin wins over a legacy copy in wp-content.
            if (isset($this->themes[$slug]) && !empty($this->themes[$slug]['bundled'])) {
                continue;
            }

            $theme = $this->build_theme_from_directory($slug, trailingslashit($dir));
            if ($theme) {
                $this->themes[$slug] = $theme;
            }
        }
    }

    /**
     * Build a theme definition from its manifest file.
     *
     * @param string $slug
     * @param string $dir
     * @return array|null
     */
    private function build_theme_from_directory(string $slug, string $dir, ?string $base_url = null, bool $bundled = false): ?array {
        $manifest_path = $dir . self::MANIFEST_FILE;
        if (!file_exists($manifest_path) || !is_readable($manifest_path)) {
            return null;
        }

        $contents = file_get_contents($manifest_path);
        if ($contents === false) {
            return null;
        }

        $data = json_decode($contents, true);
        if (!is_array($data)) {
            return null;
        }

        $name        = isset($data['name']) ? sanitize_text_field($data['name']) : $slug;
        $description = isset($data['description']) ? sanitize_text_field($data['description']) : '';
        $version     = isset($data['version']) ? sanitize_text_field($data['version']) : '';
        $author      = isset($data['author']) ? sanitize_text_field($data['author']) : '';

        if ($base_url === null) {
            $base_url = trailingslashit(YOOADMIN_ADMIN_THEMES_URL) . $slug . '/';
        }

        $paths = [
            'header'    => $this->resolve_template_path($dir, $data, 'header'),
            'footer'    => $this->resolve_template_path($dir, $data, 'footer'),
            'sidebar'   => $this->resolve_template_path($dir, $data, 'sidebar'),
            'settings'  => $this->resolve_template_path($dir, $data, 'settings'),
            'dashboard' => $this->resolve_template_path($dir, $data, 'dashboard'),
        ];

        $compat = [];
        if (!empty($data['compat']) && is_array($data['compat'])) {
            $compat = $data['compat'];
        }

        $assets = [
            'styles'  => $this->normalize_assets($slug, $dir, $base_url, $data, 'styles'),
            'scripts' => $this->normalize_assets($slug, $dir, $base_url, $data, 'scripts'),
        ];

        $branding = $this->normalize_branding($slug, $dir, $base_url, $data);

        $features = [];
        if (!empty($data['features']) && is_array($data['features'])) {
            foreach ($data['features'] as $feature_key => $feature_value) {
                if (!is_string($feature_key)) {
                    continue;
                }
                $normalized_key = sanitize_key($feature_key);
                $features[$normalized_key] = (bool) $feature_value;
            }
        }

        $supports_brand_colors = !empty($features['brand_colors']);

        $theme_def = [
            'slug'        => $slug,
            'name'        => $name,
            'description' => $description,
            'version'     => $version,
            'author'      => $author,
            'builtin'     => $bundled,
            'bundled'     => $bundled,
            'features'    => $features,
            'supports_brand_colors' => $supports_brand_colors,
            'paths'       => $paths,
            'assets'      => $assets,
            'branding'    => $branding,
            'compat'      => $compat,
            'base_dir'    => trailingslashit($dir),
            'base_url'    => $base_url,
            'settings_schema' => isset($data['settings']) && is_array($data['settings']) ? $data['settings'] : [],
            'raw'         => $data,
        ];

        return $theme_def;
    }

    /**
     * Load theme bootstrap PHP (manifest "bootstrap", default theme.php).
     *
     * @param array<string,mixed> $theme
     */
    private function maybe_load_theme_bootstrap(array $theme): void {
        static $loaded = [];

        $slug = (string) ($theme['slug'] ?? '');
        if ($slug === '' || isset($loaded[$slug])) {
            return;
        }

        $raw       = $theme['raw'] ?? [];
        $bootstrap = isset($raw['bootstrap']) ? (string) $raw['bootstrap'] : 'theme.php';
        $path      = $theme['base_dir'] . ltrim($bootstrap, '/');
        if (!is_readable($path)) {
            return;
        }

        $loaded[$slug] = true;

        if ($slug === $this->get_active_theme_slug() && !defined('YOOADMIN_ACTIVE_ADMIN_THEME_DIR')) {
            define('YOOADMIN_ACTIVE_ADMIN_THEME_DIR', $theme['base_dir']);
        }

        require_once $path;

        /**
         * Fires after an admin theme bootstrap file is loaded.
         *
         * @param string              $slug
         * @param array<string,mixed> $theme
         */
        do_action('yooadmin_admin_theme_bootstrap', $slug, $theme);
    }

    /**
     * Normalize assets definition from manifest.
     *
     * @param string $slug
     * @param string $dir
     * @param string $base_url
     * @param array  $data
     * @param string $type    'styles' or 'scripts'
     * @return array<int,array<string,mixed>>
     */
    private function normalize_assets(string $slug, string $dir, string $base_url, array $data, string $type): array {
        $result = [];

        $entries = $data['assets'][$type] ?? [];
        if (empty($entries) || !is_array($entries)) {
            return $result;
        }

        foreach (array_values($entries) as $index => $entry) {
            $normalized = $this->normalize_asset_entry($slug, $dir, $base_url, $type, $index, $entry);
            if ($normalized) {
                $result[] = $normalized;
            }
        }

        return $result;
    }

    /**
     * Normalize branding definitions from manifest.
     *
     * @param string $slug
     * @param string $dir
     * @param string $base_url
     * @param array  $data
     * @return array<string,string>
     */
    private function normalize_branding(string $slug, string $dir, string $base_url, array $data): array {
        $branding = [];
        if (empty($data['branding']) || !is_array($data['branding'])) {
            return $branding;
        }

        if (!empty($data['branding']['default_logo']) && is_string($data['branding']['default_logo'])) {
            $relative = ltrim((string) $data['branding']['default_logo'], '/');
            $path     = wp_normalize_path(trailingslashit($dir) . $relative);
            if (file_exists($path)) {
                $branding['default_logo']      = $relative;
                $branding['default_logo_path'] = $path;
                $branding['default_logo_url']  = trailingslashit($base_url) . $relative;
            } else {
                $branding['default_logo'] = $relative;
            }
        }

        return $branding;
    }

    /**
     * Override YOAdmin fallback logo when theme provides one.
     *
     * @param string $current_url
     * @return string
     */
    public function filter_default_logo_url(string $current_url): string {
        // Respect custom logo configured in YOAdmin settings.
        $options     = get_option('yooadmin_options', []);
        $custom_logo = '';
        if (is_array($options) && !empty($options['logo_url'])) {
            $custom_logo = esc_url_raw((string) $options['logo_url']);
        }
        if ($custom_logo) {
            return $current_url ?: $custom_logo;
        }

        $theme = $this->get_active_theme();
        if (!$theme) {
            return $current_url;
        }

        $branding = (isset($theme['branding']) && is_array($theme['branding'])) ? $theme['branding'] : [];

        if (!empty($branding['default_logo_url'])) {
            return esc_url($branding['default_logo_url']);
        }

        if (!empty($branding['default_logo']) && is_string($branding['default_logo'])) {
            $relative = ltrim($branding['default_logo'], '/');
            $base_url = !empty($theme['base_url']) ? (string) $theme['base_url'] : trailingslashit(YOOADMIN_ADMIN_THEMES_URL) . ($theme['slug'] ?? '') . '/';

            return esc_url(trailingslashit($base_url) . $relative);
        }

        return $current_url;
    }

    /**
     * Normalize a single asset entry.
     *
     * @param string               $slug
     * @param string               $dir
     * @param string               $base_url
     * @param string               $type
     * @param int                  $index
     * @param array|string         $entry
     * @return array<string,mixed>|null
     */
    private function normalize_asset_entry(string $slug, string $dir, string $base_url, string $type, int $index, $entry): ?array {
        $handle = 'yooadmin-admin-theme-' . $type . '-' . $slug . '-' . $index;
        $deps   = [];
        $in_footer = ($type === 'scripts');

        if (is_string($entry)) {
            $file = ltrim($entry, '/');
        } elseif (is_array($entry) && !empty($entry['file'])) {
            $file = ltrim((string) $entry['file'], '/');
            if (!empty($entry['handle'])) {
                $handle = sanitize_key($entry['handle']);
            }
            if (!empty($entry['deps']) && is_array($entry['deps'])) {
                $deps = array_values(array_filter(array_map('sanitize_key', $entry['deps'])));
            }
            if (isset($entry['in_footer'])) {
                $in_footer = (bool) $entry['in_footer'];
            }
        } else {
            return null;
        }

        $path = $dir . $file;
        if (!file_exists($path)) {
            return null;
        }

        $url = trailingslashit($base_url) . str_replace('\\', '/', $file);
        return [
            'handle'    => $handle,
            'file'      => $file,
            'path'      => $path,
            'url'       => $url,
            'deps'      => $deps,
            'in_footer' => $in_footer,
            'type'      => $type,
        ];
    }

    /**
     * Resolve template path for a given area.
     *
     * @param string $dir
     * @param array  $data
     * @param string $area
     * @return string|null
     */
    private function resolve_template_path(string $dir, array $data, string $area): ?string {
        $template_rel = $data['templates'][$area] ?? null;
        if (!$template_rel) {
            return null;
        }

        $template = $dir . ltrim((string) $template_rel, '/');
        return file_exists($template) ? $template : null;
    }

    /**
     * Determine active theme slug.
     *
     * @return string
     */
    private function get_active_theme_slug(): string {
        if ($this->active_slug !== null) {
            return $this->active_slug;
        }

        $slug = get_option(self::OPTION_KEY, $this->get_preferred_default_slug());
        if (!is_string($slug) || !isset($this->themes[$slug])) {
            $slug = $this->get_preferred_default_slug();
        }

        $this->active_slug = $slug;
        return $this->active_slug;
    }

    /**
     * Validate theme slug.
     *
     * @param string $slug
     * @return bool
     */
    private function is_valid_slug(string $slug): bool {
        return (bool) preg_match('/^[a-z0-9\-_]+$/i', $slug);
    }

    /**
     * Enqueue a stylesheet entry.
     *
     * @param string $theme_slug
     * @param array  $asset
     */
    private function enqueue_style(string $theme_slug, array $asset): void {
        if (empty($asset['path']) || empty($asset['url'])) {
            return;
        }

        $handle = $asset['handle'] ?? 'yooadmin-admin-theme-style-' . $theme_slug;
        $deps   = $this->filter_registered_style_deps(isset($asset['deps']) ? (array) $asset['deps'] : []);
        $ver    = (string) filemtime($asset['path']);

        wp_enqueue_style($handle, $asset['url'], $deps, $ver);
    }

    /**
     * Drop style deps that are not registered yet (optional handles like yooadmin-popup).
     *
     * @param array<int, string> $deps
     * @return array<int, string>
     */
    private function filter_registered_style_deps(array $deps): array {
        $out = [];
        foreach ($deps as $dep) {
            if (!is_string($dep) || $dep === '') {
                continue;
            }
            if (wp_style_is($dep, 'registered') || wp_style_is($dep, 'enqueued')) {
                $out[] = $dep;
            }
        }

        return $out;
    }

    /**
     * Enqueue a script entry.
     *
     * @param string $theme_slug
     * @param array  $asset
     */
    private function enqueue_script(string $theme_slug, array $asset): void {
        if (empty($asset['path']) || empty($asset['url'])) {
            return;
        }

        $handle = $asset['handle'] ?? 'yooadmin-admin-theme-script-' . $theme_slug;
        $deps   = isset($asset['deps']) ? (array) $asset['deps'] : ['jquery'];
        $in_footer = isset($asset['in_footer']) ? (bool) $asset['in_footer'] : true;
        $ver    = (string) filemtime($asset['path']);

        wp_enqueue_script($handle, $asset['url'], $deps, $ver, $in_footer);

        $localize = apply_filters('yooadmin_admin_theme_script_localize', null, $handle, $theme_slug, $asset);
        if (is_array($localize) && !empty($localize['object']) && is_array($localize['data'] ?? null)) {
            wp_localize_script($handle, (string) $localize['object'], $localize['data']);
        }
    }

    /**
     * Resolve screenshot URL for theme if provided.
     *
     * @param array $theme
     * @return string|null
     */
    private function get_theme_screenshot_url(array $theme): ?string {
        $raw = $theme['raw'] ?? [];

        if (!empty($raw['screenshot'])) {
            $file = ltrim((string) $raw['screenshot'], '/');
            $base_dir = !empty($theme['base_dir']) ? (string) $theme['base_dir'] : '';
            $base_url = !empty($theme['base_url'])
                ? (string) $theme['base_url']
                : trailingslashit(YOOADMIN_ADMIN_THEMES_URL) . ($theme['slug'] ?? '') . '/';

            if ($base_dir !== '' && is_readable($base_dir . $file)) {
                return $base_url . $file;
            }

            if ($file !== '' && $base_url !== '') {
                return $base_url . $file;
            }
        }

        if (!empty($raw['preview'])) {
            return esc_url_raw($raw['preview']);
        }

        // Fallback to default screenshot
        return plugins_url('assets/images/theme-screenshots/legacy-shell.svg', YOOADMIN_PLUGIN_FILE);
    }

    /**
     * Whether the admin themes screen should expose ZIP upload (Extended only).
     */
    private function theme_upload_supported(): bool {
        return (bool) apply_filters('yooadmin_admin_theme_upload_supported', false);
    }

    /**
     * Capability helper for admin screen/actions.
     */
    private function get_required_capability(): string {
        if (function_exists('yooadmin_required_cap')) {
            return yooadmin_required_cap('settings');
        }
        return 'manage_options';
    }

    /**
     * Helper to generate page URL with optional query arguments.
     *
     * @param array $args
     * @return string
     */
    private function get_admin_page_url(array $args = []): string {
        $url = admin_url('admin.php?page=' . $this->menu_slug);
        return $args ? add_query_arg($args, $url) : $url;
    }

    /**
     * Handle the uploaded ZIP using core helpers.
     *
     * @param array $file
     * @return array|\WP_Error
     */
    private function handle_zip_upload(array $file) {
        require_once ABSPATH . 'wp-admin/includes/file.php';

        $overrides = [
            'test_form' => false,
            'mimes'     => [
                'zip' => 'application/zip',
            ],
        ];

        $uploaded = wp_handle_upload($file, $overrides);
        if (isset($uploaded['error'])) {
            return new \WP_Error('upload_error', $uploaded['error']);
        }

        return $uploaded;
    }

    /**
     * Unzip and register an uploaded theme package.
     *
     * @param string $zip_path
     * @return true|\WP_Error
     */
    private function process_uploaded_theme(string $zip_path) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';

        global $wp_filesystem;
        WP_Filesystem();

        $temp_dir = wp_tempnam('yooadmin_theme');
        if (!$temp_dir || !wp_delete_file($temp_dir) || !wp_mkdir_p($temp_dir)) {
            return new \WP_Error('upload_error', __('Unable to create temporary directory.', 'yooadmin'));
        }

        $unzipped = unzip_file($zip_path, $temp_dir);
        if (is_wp_error($unzipped)) {
            $this->cleanup_dir($temp_dir);
            return new \WP_Error('upload_invalid', __('Unable to extract the ZIP archive.', 'yooadmin'));
        }

        $theme_dir = $this->locate_theme_root($temp_dir);
        if (!$theme_dir) {
            $this->cleanup_dir($temp_dir);
            return new \WP_Error('upload_invalid', __('manifest.json was not found in the uploaded package.', 'yooadmin'));
        }

        $manifest_path = trailingslashit($theme_dir) . self::MANIFEST_FILE;
        $manifest = $this->read_manifest($manifest_path);
        if (!$manifest) {
            $this->cleanup_dir($temp_dir);
            return new \WP_Error('upload_invalid', __('manifest.json is invalid or unreadable.', 'yooadmin'));
        }

        $slug = $manifest['slug'] ?? basename($theme_dir);
        $slug = sanitize_key($slug);
        if (!$this->is_valid_slug($slug)) {
            $this->cleanup_dir($temp_dir);
            return new \WP_Error('upload_invalid', __('Theme slug contains invalid characters.', 'yooadmin'));
        }

        $destination = trailingslashit(YOOADMIN_ADMIN_THEMES_DIR) . $slug;
        $is_update = false;

        if (isset($this->themes[$slug])) {
            if (!empty($this->themes[$slug]['builtin'])) {
                $this->cleanup_dir($temp_dir);
                return new \WP_Error('upload_exists', __('Theme slug is reserved for core theme.', 'yooadmin'));
            }
            $is_update = true;
        } elseif (is_dir($destination)) {
            $is_update = true;
        }

        if ($is_update) {
            if (!$this->cleanup_dir($destination)) {
                $this->cleanup_dir($temp_dir);
                return new \WP_Error('upload_replace_failed', __('Unable to replace the existing theme directory.', 'yooadmin'));
            }
        }

        if (!wp_mkdir_p($destination)) {
            $this->cleanup_dir($temp_dir);
            return new \WP_Error('upload_error', __('Unable to prepare destination directory.', 'yooadmin'));
        }

        $copy = copy_dir($theme_dir, $destination);
        $this->cleanup_dir($temp_dir);

        if (is_wp_error($copy)) {
            $this->cleanup_dir($destination);
            return new \WP_Error('upload_error', __('Failed to move uploaded theme into the themes directory.', 'yooadmin'));
        }

        if ($is_update) {
            $this->update_theme_meta($slug, [
                'updated_at' => current_time('mysql'),
            ]);
        } else {
            $this->update_theme_meta($slug, [
                'source'       => 'upload',
                'installed_at' => current_time('mysql'),
            ]);
        }

        // Refresh themes registry for immediate availability.
        $this->load_themes();

        return [
            'status' => $is_update ? 'updated' : 'new',
            'slug'   => $slug,
        ];
    }

    /**
     * Find the root directory containing manifest.json.
     *
     * @param string $base_dir
     * @return string|null
     */
    private function locate_theme_root(string $base_dir): ?string {
        $base_dir = trailingslashit($base_dir);

        if (file_exists($base_dir . self::MANIFEST_FILE)) {
            return $base_dir;
        }

        $entries = glob($base_dir . '*', GLOB_ONLYDIR);
        if (empty($entries)) {
            return null;
        }

        foreach ($entries as $entry) {
            if (file_exists(trailingslashit($entry) . self::MANIFEST_FILE)) {
                return trailingslashit($entry);
            }
        }

        return null;
    }

    /**
     * Decode manifest file safely.
     *
     * @param string $path
     * @return array|null
     */
    private function read_manifest(string $path): ?array {
        if (!file_exists($path) || !is_readable($path)) {
            return null;
        }

        $contents = file_get_contents($path);
        if ($contents === false) {
            return null;
        }

        $data = json_decode($contents, true);
        return is_array($data) ? $data : null;
    }

    /**
     * Recursively delete directory.
     *
     * @param string $dir
     */
    private function cleanup_dir(string $dir): bool {
        if (!is_dir($dir)) {
            return true;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        if (!class_exists('WP_Filesystem_Base')) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
        }
        if (!class_exists('WP_Filesystem_Direct')) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
        }

        $fs = new \WP_Filesystem_Direct(false);
        return $fs->rmdir($dir, true);
    }

    /**
     * Update metadata for a theme.
     *
     * @param string $slug
     * @param array  $meta
     */
    private function update_theme_meta(string $slug, array $meta): void {
        $this->theme_meta[$slug] = array_merge($this->theme_meta[$slug] ?? [], $meta);
        update_option(self::META_OPTION, $this->theme_meta);
    }

    /**
     * Remove stored metadata.
     *
     * @param string $slug
     */
    private function delete_theme_meta(string $slug): void {
        if (isset($this->theme_meta[$slug])) {
            unset($this->theme_meta[$slug]);
            update_option(self::META_OPTION, $this->theme_meta);
        }
    }

    /**
     * Remove stored settings for a theme.
     *
     * @param string $slug
     */
    private function delete_theme_settings(string $slug): void {
        delete_option($this->get_theme_settings_option_name($slug));
    }

    /**
     * Return the admin URL for the theme settings page.
     *
     * @param array $args
     * @return string
     */
    private function get_theme_settings_page_url(array $args = []): string {
        $url = admin_url('admin.php?page=' . $this->settings_page_slug);
        return $args ? add_query_arg($args, $url) : $url;
    }

    /**
     * Retrieve option name for storing theme settings.
     *
     * @param string $slug
     * @return string
     */
    private function get_theme_settings_option_name(string $slug): string {
        return self::SETTINGS_OPTION_PREFIX . $slug;
    }

    /**
     * Initialize settings storage for a theme if needed.
     *
     * @param string $slug
     */
    private function maybe_initialize_theme_settings(string $slug): void {
        $theme = $this->themes[$slug] ?? null;
        if (!$theme || empty($theme['settings_schema'])) {
            return;
        }

        $option_name = $this->get_theme_settings_option_name($slug);
        if (get_option($option_name, null) !== null) {
            return;
        }

        $defaults = $this->get_settings_defaults($theme['settings_schema']);
        add_option($option_name, $defaults);
    }

    /**
     * Build default values map based on schema.
     *
     * @param array $schema
     * @return array
     */
    private function get_settings_defaults(array $schema): array {
        $defaults = [];
        $sections = $schema['sections'] ?? [];
        if (!is_array($sections)) {
            return $defaults;
        }

        foreach ($sections as $section) {
            $fields = $section['fields'] ?? [];
            if (!is_array($fields)) {
                continue;
            }
            foreach ($fields as $field) {
                $field_id = isset($field['id']) ? sanitize_key($field['id']) : '';
                if (!$field_id) {
                    continue;
                }
                $defaults[$field_id] = $this->compute_field_default($field);
            }
        }
        return $defaults;
    }

    /**
     * Compute a sanitized default value for a field.
     *
     * @param array $field
     * @return mixed
     */
    private function compute_field_default(array $field) {
        $type = isset($field['type']) ? strtolower((string) $field['type']) : 'text';
        $has_default = array_key_exists('default', $field);
        $raw_default = $has_default ? $field['default'] : null;

        switch ($type) {
            case 'checkbox':
                return (bool) $raw_default;
            case 'color':
                if ($raw_default) {
                    $sanitized = sanitize_hex_color($raw_default);
                    if ($sanitized) {
                        return $sanitized;
                    }
                }
                return '';
            case 'select':
                $choices = $this->get_field_choices($field);
                if ($has_default && isset($choices[$raw_default])) {
                    return $raw_default;
                }
                if (!empty($choices)) {
                    return array_key_first($choices);
                }
                return '';
            case 'number':
                if ($has_default && is_numeric($raw_default)) {
                    return isset($field['number_type']) && $field['number_type'] === 'float'
                        ? (float) $raw_default
                        : (int) $raw_default;
                }
                return isset($field['number_type']) && $field['number_type'] === 'float' ? 0.0 : 0;
            case 'url':
                if ($has_default) {
                    $url = esc_url_raw((string) $raw_default);
                    if ($url) {
                        return $url;
                    }
                }
                return '';
            case 'textarea':
                if ($has_default) {
                    return sanitize_textarea_field((string) $raw_default);
                }
                return '';
            case 'text':
            default:
                if ($has_default) {
                    return sanitize_text_field((string) $raw_default);
                }
                return '';
        }
    }

    /**
     * Retrieve choices array for select field.
     *
     * @param array $field
     * @return array
     */
    private function get_field_choices(array $field): array {
        $choices = $field['choices'] ?? [];
        if (!is_array($choices)) {
            return [];
        }
        $normalized = [];
        foreach ($choices as $key => $label) {
            $normalized[sanitize_key((string) $key)] = $this->translate_theme_ui_string(
                sanitize_text_field((string) $label)
            );
        }
        return $normalized;
    }

    /**
     * Retrieve settings values for a theme.
     *
     * @param string $slug
     * @return array
     */
    private function get_theme_settings_values(string $slug): array {
        $theme = $this->themes[$slug] ?? null;
        if (!$theme || empty($theme['settings_schema'])) {
            return [];
        }

        $schema   = $theme['settings_schema'];
        $defaults = $this->get_settings_defaults($schema);
        $option   = get_option($this->get_theme_settings_option_name($slug), []);
        if (!is_array($option)) {
            return $defaults;
        }

        foreach ($option as $field_id => $value) {
            if (!array_key_exists($field_id, $defaults)) {
                continue;
            }
            $field = $this->find_field_in_schema($schema, $field_id);
            if (!$field) {
                continue;
            }
            $defaults[$field_id] = $this->sanitize_setting_value($field, $value);
        }

        if (array_key_exists('color_mode', $defaults) && function_exists('yooadmin_studio_hub_get_color_mode')) {
            $defaults['color_mode'] = yooadmin_studio_hub_get_color_mode();
        }

        return $defaults;
    }

    /**
     * Locate field definition within schema.
     *
     * @param array  $schema
     * @param string $field_id
     * @return array|null
     */
    private function find_field_in_schema(array $schema, string $field_id): ?array {
        $sections = $schema['sections'] ?? [];
        if (!is_array($sections)) {
            return null;
        }
        foreach ($sections as $section) {
            $fields = $section['fields'] ?? [];
            if (!is_array($fields)) {
                continue;
            }
            foreach ($fields as $field) {
                $id = isset($field['id']) ? sanitize_key($field['id']) : '';
                if ($id && $id === $field_id) {
                    return $field;
                }
            }
        }
        return null;
    }

    /**
     * Sanitize a value based on field definition.
     *
     * @param array $field
     * @param mixed $value
     * @return mixed
     */
    private function sanitize_setting_value(array $field, $value) {
        $type    = isset($field['type']) ? strtolower((string) $field['type']) : 'text';
        $default = $this->compute_field_default($field);

        switch ($type) {
            case 'checkbox':
                return !empty($value);
            case 'color':
                $sanitized = $value ? sanitize_hex_color($value) : '';
                return $sanitized ?: $default;
            case 'select':
            case 'appearance_mode':
                $choices = $this->get_field_choices($field);
                $key     = sanitize_key((string) $value);
                return isset($choices[$key]) ? $key : $default;
            case 'number':
                if ($value === '' || $value === null) {
                    return $default;
                }
                if (!is_numeric($value)) {
                    return $default;
                }
                if (isset($field['number_type']) && $field['number_type'] === 'float') {
                    return (float) $value;
                }
                return (int) $value;
            case 'url':
                $url = esc_url_raw((string) $value);
                return $url ?: $default;
            case 'textarea':
                return sanitize_textarea_field((string) $value);
            case 'text':
            default:
                return sanitize_text_field((string) $value);
        }
    }

    /**
     * Determine if a theme supports managing brand colors.
     *
     * @param array $theme
     * @return bool
     */
    private function theme_supports_brand_colors(array $theme): bool {
        return !empty($theme['supports_brand_colors']);
    }

    /**
     * Translate manifest-driven theme UI copy for the current admin locale.
     *
     * @param string $text Source English string (also used as msgid).
     */
    private function translate_theme_ui_string(string $text): string {
        if ($text === '') {
            return '';
        }

        $translate = static function () use ($text): string {
            // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText -- Manifest literals registered in the yooadmin text domain.
            return __($text, 'yooadmin');
        };

        return function_exists('yooadmin_with_admin_ui_locale')
            ? yooadmin_with_admin_ui_locale($translate)
            : $translate();
    }

    /**
     * Retrieve a translated label for a brand color key.
     *
     * @param string $key
     * @return string
     */
    private function get_brand_color_label(string $key): string {
        $map = [
            'primary'       => __('Accent Color', 'yooadmin'),
            'border'        => __('Borders & Dividers', 'yooadmin'),
            'header_bg'      => __('Header Background', 'yooadmin'),
            'breadcrumbs_bg' => __('Breadcrumbs Bar Background', 'yooadmin'),
            'breadcrumbs_fg' => __('Breadcrumbs Bar Text', 'yooadmin'),
            'sidebar_bg'     => __('Sidebar Background', 'yooadmin'),
            'text_contrast'  => __('Header & Flyout Menu Text', 'yooadmin'),
            'text_600'      => __('Secondary Text', 'yooadmin'),
            'text_500'      => __('Muted Text', 'yooadmin'),
            'card_icon'     => __('Card & Widget Icons', 'yooadmin'),
        ];

        return $map[$key] ?? ucfirst(str_replace('_', ' ', $key));
    }

    /**
     * Retrieve a translated description for a brand color key.
     *
     * @param string $key
     * @return string
     */
    private function get_brand_color_description(string $key): string {
        $map = [
            'primary'       => __('Main accent used for buttons, links, and highlights across the admin.', 'yooadmin'),
            'border'        => __('Color of borders, dividers, and separators in the interface.', 'yooadmin'),
            'header_bg'      => __('Background color of the top admin header bar.', 'yooadmin'),
            'breadcrumbs_bg' => __('Background of the shortcuts row under the header in light mode (default white; not tied to header color).', 'yooadmin'),
            'breadcrumbs_fg' => __('Breadcrumbs trail text in light mode (default gray on the white strip). In dark mode the strip matches the header and trail text follows “Header / bar text” (text contrast).', 'yooadmin'),
            'sidebar_bg'     => __('Background color of the WordPress left admin menu and the flyout drawer.', 'yooadmin'),
            'text_contrast'  => __('Text and icons on the header bar and flyout menu (not the breadcrumbs row).', 'yooadmin'),
            'text_600'      => __('Color for secondary headings and labels.', 'yooadmin'),
            'text_500'      => __('Color for muted or helper text.', 'yooadmin'),
            'card_icon'     => __('Icon color in dashboard cards and widgets.', 'yooadmin'),
        ];

        return $map[$key] ?? '';
    }

    /**
     * Return default brand colors as key => hex map.
     *
     * @return array<string,string>
     */
    private function get_brand_color_defaults_flat(): array {
        $defaults = [];
        foreach ($this->brand_color_definitions as $definition) {
            $defaults[$definition['key']] = $definition['default'];
        }
        return $defaults;
    }

    /**
     * Retrieve persisted brand colors merged with defaults.
     *
     * @return array<string,string>
     */
    private function get_current_brand_colors(): array {
        $defaults = $this->get_brand_color_defaults_flat();
        $stored   = get_option('yooadmin_colors', $defaults);
        if (!is_array($stored)) {
            $stored = [];
        }

        $filtered = array_intersect_key($stored, $defaults);
        return array_merge($defaults, $filtered);
    }

    /**
     * Persist sanitized brand colors to the shared option.
     *
     * @param array $input
     * @return void
     */
    private function save_brand_colors(array $input): void {
        $defaults = $this->get_brand_color_defaults_flat();
        // Start from factory defaults so "Reset to Defaults" + Save cannot leave stale keys/values.
        $stored   = $defaults;

        foreach ($this->brand_color_definitions as $definition) {
            $key = $definition['key'];
            if (!array_key_exists($key, $input)) {
                continue;
            }

            $raw = $input[$key];
            if (!is_string($raw) || $raw === '') {
                continue;
            }

            $sanitized = sanitize_hex_color($raw);
            if ($sanitized) {
                $stored[$key] = $sanitized;
            }
        }

        update_option('yooadmin_colors', $stored);
        wp_cache_delete('yooadmin_colors_' . get_current_user_id(), 'yooadmin_settings');
    }

    /**
     * Render active theme settings page.
     */
    public function render_theme_settings_page(): void {
        global $title;
        $title = __( 'Theme Settings', 'yooadmin' );

        if (!current_user_can($this->get_required_capability())) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        $theme = $this->get_active_theme();
        if (!$theme) {
            printf('<div class="wrap"><h1>%s</h1><div class="notice notice-warning"><p>%s</p></div></div>',
                esc_html__('Theme Settings', 'yooadmin'),
                esc_html__('No active theme detected.', 'yooadmin')
            );
            return;
        }

        $this->enqueue_theme_settings_assets();

        $slug    = $theme['slug'];
        $values  = $this->get_theme_settings_values($slug);
        $action  = admin_url('admin-post.php');
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only GET status display, no state change.
        $status  = isset($_GET['settings_status']) ? sanitize_key(wp_unslash($_GET['settings_status'])) : '';
        $brand_colors_supported = $this->theme_supports_brand_colors($theme);
        $schema = $theme['settings_schema'] ?? [];
        $sections = is_array($schema['sections'] ?? null) ? $schema['sections'] : [];
        if (empty($sections) && !$brand_colors_supported) {
            printf('<div class="wrap"><h1>%s</h1><div class="notice notice-info"><p>%s</p></div></div>',
                esc_html__('Theme Settings', 'yooadmin'),
                esc_html__('The active theme does not provide configurable settings.', 'yooadmin')
            );
            return;
        }
        $brand_colors = $brand_colors_supported ? $this->get_current_brand_colors() : [];
        $brand_color_defaults = $brand_colors_supported ? $this->get_brand_color_defaults_flat() : [];

        $messages = [
            'settings_saved' => __('Theme settings saved successfully.', 'yooadmin'),
            'settings_error' => __('Unable to save theme settings. Please try again.', 'yooadmin'),
        ];

        ?>
        <div class="wrap yooadmin-theme-settings-wrap">
            <div class="yooadmin-theme-settings-header">
                <div class="yooadmin-theme-settings-header__main">
                    <div class="yooadmin-theme-settings-header__content">
                        <h1 class="yooadmin-theme-settings-title">
                            <span class="dashicons dashicons-admin-appearance"></span>
                            <?php
                            printf(
                                /* translators: %s: theme name */
                                esc_html__('Theme Settings: %s', 'yooadmin'),
                                esc_html($this->translate_theme_ui_string((string) ($theme['name'] ?? $slug)))
                            );
                            ?>
                        </h1>
                        <p class="yooadmin-theme-settings-subtitle">
                            <?php esc_html_e('Customize colors and options. Changes preview instantly before saving.', 'yooadmin'); ?>
                        </p>
                    </div>
                    <div class="yooadmin-theme-settings-actions--top">
                        <?php if ($brand_colors_supported): ?>
                            <button type="button" class="yp-yoo-btn yp-yoo-btn--soft yooadmin-reset-preview"><?php esc_html_e('Reset Preview', 'yooadmin'); ?></button>
                            <button type="button" class="yp-yoo-btn yp-yoo-btn--soft yooadmin-reset-defaults"><?php esc_html_e('Reset to Defaults', 'yooadmin'); ?></button>
                        <?php endif; ?>
                        <button type="submit" class="yp-yoo-btn yp-yoo-btn--primary yooadmin-save-settings" form="yooadmin-theme-settings-form">
                            <?php esc_html_e('Save Theme Settings', 'yooadmin'); ?>
                        </button>
                    </div>
                </div>
            </div>
            <?php if ($status && isset($messages[$status])): ?>
                <div class="notice notice-<?php echo $status === 'settings_saved' ? 'success' : 'error'; ?> is-dismissible">
                    <p><?php echo esc_html($messages[$status]); ?></p>
                </div>
            <?php endif; ?>

            <div class="yooadmin-theme-settings-feedback" aria-live="polite"></div>

            <form method="post"
                  id="yooadmin-theme-settings-form"
                  action="<?php echo esc_url($action); ?>"
                  class="yooadmin-theme-settings-form"
                  data-message-saved="<?php echo esc_attr($messages['settings_saved']); ?>"
                  data-message-error="<?php echo esc_attr($messages['settings_error']); ?>"
                  data-message-reset-preview="<?php echo esc_attr__('Preview reset to saved settings. Click Save Theme Settings to keep changes.', 'yooadmin'); ?>"
                  data-message-reset-defaults="<?php echo esc_attr__('Reset to default settings. Click Save Theme Settings to keep changes.', 'yooadmin'); ?>"
                  data-ajax-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"
                  data-dismiss-label="<?php echo esc_attr__('Dismiss this notice.', 'yooadmin'); ?>"
                <?php if ($brand_colors_supported): ?>
                  data-brand-colors-initial="<?php echo esc_attr(wp_json_encode($brand_colors)); ?>"
                  data-brand-colors-defaults="<?php echo esc_attr(wp_json_encode($brand_color_defaults)); ?>"
                <?php endif; ?>
            >
                <?php wp_nonce_field(self::SAVE_SETTINGS_ACTION . '_' . $slug); ?>
                <input type="hidden" name="action" value="<?php echo esc_attr(self::SAVE_SETTINGS_ACTION); ?>">
                <input type="hidden" name="theme_slug" value="<?php echo esc_attr($slug); ?>">

                <?php if ($brand_colors_supported): ?>
                    <div class="yooadmin-theme-settings-section yooadmin-theme-settings-section-brand-colors"
                         data-colors-light-title="<?php echo esc_attr__('Switch to Light mode to edit colors', 'yooadmin'); ?>"
                         data-colors-light-text="<?php echo esc_attr__('Brand colors can only be changed in Light mode for an accurate preview.', 'yooadmin'); ?>"
                         data-switch-to-light="<?php echo esc_attr__('Switch to Light', 'yooadmin'); ?>">
                        <h2><?php esc_html_e('Brand Colors', 'yooadmin'); ?></h2>
                        <p class="yooadmin-theme-settings-help">
                            <?php esc_html_e('Customize the admin color scheme. Changes preview instantly before saving.', 'yooadmin'); ?>
                        </p>
                        <div class="yooadmin-theme-settings-split">
                            <?php
                            $items = [];
                            foreach ($this->brand_color_definitions as $css_var => $definition) {
                                $items[] = ['css_var' => $css_var, 'definition' => $definition];
                            }
                            $half  = (int) ceil(count($items) / 2);
                            $left  = array_slice($items, 0, $half);
                            $right = array_slice($items, $half);
                            ?>
                            <div class="yooadmin-theme-settings-col">
                                <?php foreach ($left as $item): ?>
                                    <?php
                                    $definition  = $item['definition'];
                                    $css_var     = $item['css_var'];
                                    $color_key   = $definition['key'];
                                    $default_hex = $definition['default'];
                                    $current_hex = isset($brand_colors[$color_key]) ? $brand_colors[$color_key] : $default_hex;
                                    $input_id    = 'yooadmin-brand-color-' . sanitize_html_class($color_key);
                                    ?>
                                    <div class="yooadmin-theme-settings-option">
                                        <label for="<?php echo esc_attr($input_id); ?>" class="yooadmin-theme-settings-option__label">
                                            <?php echo esc_html($this->get_brand_color_label($color_key)); ?>
                                        </label>
                                        <p class="yooadmin-theme-settings-option__desc">
                                            <?php echo esc_html($this->get_brand_color_description($color_key)); ?>
                                        </p>
                                        <div class="yooadmin-theme-settings-option__control">
                                            <input
                                                type="text"
                                                id="<?php echo esc_attr($input_id); ?>"
                                                name="brand_colors[<?php echo esc_attr($color_key); ?>]"
                                                value="<?php echo esc_attr($current_hex); ?>"
                                                class="yooadmin-color-field yooadmin-brand-color-field"
                                                data-default-color="<?php echo esc_attr($default_hex); ?>"
                                                data-css-var="<?php echo esc_attr($css_var); ?>"
                                                data-color-key="<?php echo esc_attr($color_key); ?>"
                                                data-initial-color="<?php echo esc_attr($current_hex); ?>"
                                            >
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="yooadmin-theme-settings-col">
                                <?php foreach ($right as $item): ?>
                                    <?php
                                    $definition  = $item['definition'];
                                    $css_var     = $item['css_var'];
                                    $color_key   = $definition['key'];
                                    $default_hex = $definition['default'];
                                    $current_hex = isset($brand_colors[$color_key]) ? $brand_colors[$color_key] : $default_hex;
                                    $input_id    = 'yooadmin-brand-color-' . sanitize_html_class($color_key);
                                    ?>
                                    <div class="yooadmin-theme-settings-option">
                                        <label for="<?php echo esc_attr($input_id); ?>" class="yooadmin-theme-settings-option__label">
                                            <?php echo esc_html($this->get_brand_color_label($color_key)); ?>
                                        </label>
                                        <p class="yooadmin-theme-settings-option__desc">
                                            <?php echo esc_html($this->get_brand_color_description($color_key)); ?>
                                        </p>
                                        <div class="yooadmin-theme-settings-option__control">
                                            <input
                                                type="text"
                                                id="<?php echo esc_attr($input_id); ?>"
                                                name="brand_colors[<?php echo esc_attr($color_key); ?>]"
                                                value="<?php echo esc_attr($current_hex); ?>"
                                                class="yooadmin-color-field yooadmin-brand-color-field"
                                                data-default-color="<?php echo esc_attr($default_hex); ?>"
                                                data-css-var="<?php echo esc_attr($css_var); ?>"
                                                data-color-key="<?php echo esc_attr($color_key); ?>"
                                                data-initial-color="<?php echo esc_attr($current_hex); ?>"
                                            >
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php foreach ($sections as $section): ?>
                    <?php
                    $section_id = isset($section['id']) ? sanitize_key($section['id']) : '';
                    $section_title = isset($section['title'])
                        ? $this->translate_theme_ui_string(sanitize_text_field((string) $section['title']))
                        : '';
                    $section_desc  = isset($section['description'])
                        ? $this->translate_theme_ui_string(sanitize_text_field((string) $section['description']))
                        : '';
                    $fields = $section['fields'] ?? [];
                    if (!is_array($fields) || empty($fields)) {
                        continue;
                    }
                    ?>
                    <div class="yooadmin-theme-settings-section" id="<?php echo esc_attr($section_id); ?>">
                        <?php if ($section_title): ?>
                            <h2><?php echo esc_html($section_title); ?></h2>
                        <?php endif; ?>
                        <?php if ($section_desc): ?>
                            <p class="description" dir="auto"><?php echo esc_html($section_desc); ?></p>
                        <?php endif; ?>
                        <table class="form-table" role="presentation">
                            <tbody>
                            <?php foreach ($fields as $field): ?>
                                <?php
                                $field_id = isset($field['id']) ? sanitize_key($field['id']) : '';
                                if (!$field_id || !array_key_exists($field_id, $values)) {
                                    continue;
                                }
                                $field_label = isset($field['label'])
                                    ? $this->translate_theme_ui_string(sanitize_text_field((string) $field['label']))
                                    : ucfirst(str_replace('_', ' ', $field_id));
                                $field_desc  = isset($field['description'])
                                    ? $this->translate_theme_ui_string(sanitize_text_field((string) $field['description']))
                                    : '';
                                $type        = isset($field['type']) ? strtolower((string) $field['type']) : 'text';
                                $value       = $values[$field_id];
                                ?>
                                <tr>
                                    <th scope="row">
                                        <label for="yooadmin-theme-setting-<?php echo esc_attr($field_id); ?>">
                                            <?php echo esc_html($field_label); ?>
                                        </label>
                                    </th>
                                    <td>
                                        <?php
                                        $field_markup = $this->render_settings_field($field_id, $type, $value, $field);
                                        if ($type === 'appearance_mode') {
                                            echo $field_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized in renderer
                                        } else {
                                            echo wp_kses_post($field_markup);
                                        }
                                        ?>
                                        <?php if ($field_desc): ?>
                                            <p class="description" dir="auto"><?php echo esc_html($field_desc); ?></p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endforeach; ?>
            </form>
        </div>
        <?php
    }

    /**
     * Segmented appearance control (light / dark / auto).
     *
     * @param string $name
     * @param string $id
     * @param mixed  $value
     * @param array  $field
     * @return string
     */
    private function render_appearance_mode_field(string $name, string $id, $value, array $field): string {
        $choices = $this->get_field_choices($field);
        $current = sanitize_key((string) $value);
        if (!isset($choices[$current])) {
            $current = sanitize_key((string) $this->compute_field_default($field));
        }
        if (!isset($choices[$current])) {
            $current = 'auto';
        }

        $output  = '<div class="yooadmin-theme-appearance" data-yooadmin-theme-appearance data-appearance-default="' . esc_attr((string) $this->compute_field_default($field)) . '">';
        $output .= sprintf(
            '<input type="hidden" name="%1$s" id="%2$s" value="%3$s" class="yooadmin-theme-appearance-input">',
            esc_attr($name),
            esc_attr($id),
            esc_attr($current)
        );
        $output .= sprintf(
            '<div class="yooadmin-theme-appearance-pills" role="group" aria-label="%s">',
            esc_attr((string) ($field['label'] ?? __('Color mode', 'yooadmin')))
        );

        foreach ($choices as $key => $label) {
            $is_active = $key === $current;
            $icon = function_exists('yooadmin_appearance_mode_icon_svg')
                ? yooadmin_appearance_mode_icon_svg((string) $key, 15, 'yooadmin-theme-appearance-pill__icon')
                : '';
            $output   .= sprintf(
                '<button type="button" class="yooadmin-theme-appearance-pill%3$s" data-yooadmin-theme-appearance="%1$s" aria-pressed="%4$s">%5$s<span>%2$s</span></button>',
                esc_attr($key),
                esc_html($label),
                $is_active ? ' is-active' : '',
                $is_active ? 'true' : 'false',
                $icon
            );
        }

        $output .= '</div></div>';

        return $output;
    }

    /**
     * Generate field markup for settings form.
     *
     * @param string $field_id
     * @param string $type
     * @param mixed  $value
     * @param array  $field
     * @return string
     */
    private function render_settings_field(string $field_id, string $type, $value, array $field): string {
        $name  = 'settings[' . $field_id . ']';
        $id    = 'yooadmin-theme-setting-' . $field_id;

        switch ($type) {
            case 'textarea':
                return sprintf(
                    '<textarea name="%1$s" id="%2$s" rows="6" class="large-text">%3$s</textarea>',
                    esc_attr($name),
                    esc_attr($id),
                    esc_textarea((string) $value)
                );
            case 'color':
                return sprintf(
                    '<input type="text" name="%1$s" id="%2$s" value="%3$s" class="yooadmin-color-field" data-default-color="%4$s">',
                    esc_attr($name),
                    esc_attr($id),
                    esc_attr((string) $value),
                    esc_attr((string) $this->compute_field_default($field))
                );
            case 'appearance_mode':
                return $this->render_appearance_mode_field($name, $id, $value, $field);
            case 'select':
                $choices = $this->get_field_choices($field);
                $output = sprintf(
                    '<select name="%1$s" id="%2$s">',
                    esc_attr($name),
                    esc_attr($id)
                );
                foreach ($choices as $key => $label) {
                    $output .= sprintf(
                        '<option value="%1$s" %3$s>%2$s</option>',
                        esc_attr($key),
                        esc_html($label),
                        selected($value, $key, false)
                    );
                }
                $output .= '</select>';
                return $output;
            case 'checkbox':
                return sprintf(
                    '<label><input type="checkbox" name="%1$s" id="%2$s" value="1" %3$s> %4$s</label>',
                    esc_attr($name),
                    esc_attr($id),
                    checked(!empty($value), true, false),
                    isset($field['checkbox_label']) ? esc_html((string) $field['checkbox_label']) : ''
                );
            case 'number':
                $step = isset($field['number_type']) && $field['number_type'] === 'float' ? 'any' : '1';
                $min  = isset($field['min']) ? ' min="' . esc_attr($field['min']) . '"' : '';
                $max  = isset($field['max']) ? ' max="' . esc_attr($field['max']) . '"' : '';
                return sprintf(
                    '<input type="number" name="%1$s" id="%2$s" value="%3$s" step="%4$s"%5$s%6$s class="regular-text">',
                    esc_attr($name),
                    esc_attr($id),
                    esc_attr($value),
                    esc_attr($step),
                    $min,
                    $max
                );
            case 'url':
                return sprintf(
                    '<input type="url" name="%1$s" id="%2$s" value="%3$s" class="regular-text">',
                    esc_attr($name),
                    esc_attr($id),
                    esc_attr((string) $value)
                );
            case 'text':
            default:
                return sprintf(
                    '<input type="text" name="%1$s" id="%2$s" value="%3$s" class="regular-text">',
                    esc_attr($name),
                    esc_attr($id),
                    esc_attr((string) $value)
                );
        }
    }

    /**
     * Handle saving settings for active theme.
     */
    public function handle_save_settings(): void {
        static $handled = false;
        if ($handled) {
            if (wp_doing_ajax()) {
                wp_send_json_error(['message' => __('Request already processed.', 'yooadmin')]);
            }
            return;
        }
        $handled = true;

        $is_ajax = wp_doing_ajax();

        if (!current_user_can($this->get_required_capability())) {
            $message = __('Sorry, you are not allowed to modify theme settings.', 'yooadmin');
            if ($is_ajax) {
                wp_send_json_error(['message' => $message], 403);
            }
            wp_die(esc_html($message));
        }

        $slug        = isset($_POST['theme_slug']) ? sanitize_key((string) wp_unslash($_POST['theme_slug'])) : '';
        $active_slug = $this->get_active_theme_slug();
        $error_message = __('Unable to save theme settings. Please try again.', 'yooadmin');

        $fail = function (string $message = '') use ($is_ajax, $error_message) {
            $msg = $message ?: $error_message;
            if ($is_ajax) {
                wp_send_json_error(['message' => $msg]);
            }
            wp_safe_redirect($this->get_theme_settings_page_url([
                'settings_status' => 'settings_error',
            ]));
            exit;
        };

        if (!$slug || $slug !== $active_slug || !isset($this->themes[$slug])) {
            $fail(__('Invalid theme settings submission.', 'yooadmin'));
        }

        $nonce = isset($_POST['_wpnonce']) ? sanitize_text_field(wp_unslash($_POST['_wpnonce'])) : '';
        if (!$nonce || !wp_verify_nonce($nonce, self::SAVE_SETTINGS_ACTION . '_' . $slug)) {
            $fail(__('Security check failed. Please refresh the page and try again.', 'yooadmin'));
        }

        $theme      = $this->themes[$slug];
        $schema     = $theme['settings_schema'] ?? [];
        $sections   = is_array($schema['sections'] ?? null) ? $schema['sections'] : [];
        $has_sections = !empty($sections);
        $supports_brand = $this->theme_supports_brand_colors($theme);

        if (!$has_sections && !$supports_brand) {
            $fail();
        }

        $defaults  = $has_sections ? $this->get_settings_defaults($schema) : [];
        $sanitized = $defaults;

        if ($has_sections) {
            $raw_input = isset($_POST['settings']) && is_array($_POST['settings']) ? map_deep(wp_unslash($_POST['settings']), 'sanitize_text_field') : [];

            foreach ($sections as $section) {
                $fields = $section['fields'] ?? [];
                if (!is_array($fields)) {
                    continue;
                }
                foreach ($fields as $field) {
                    $field_id = isset($field['id']) ? sanitize_key($field['id']) : '';
                    if (!$field_id || !array_key_exists($field_id, $defaults)) {
                        continue;
                    }

                    $value = null;
                    if (isset($field['type']) && strtolower((string) $field['type']) === 'checkbox') {
                        $value = isset($raw_input[$field_id]) ? $raw_input[$field_id] : null;
                    } else {
                        $value = $raw_input[$field_id] ?? null;
                    }

                    if (is_array($value) && (!isset($field['type']) || strtolower((string) $field['type']) !== 'select')) {
                        $value = null;
                    }

                    $sanitized[$field_id] = $this->sanitize_setting_value($field, $value);
                }
            }
        }

        if ($supports_brand) {
            $brand_colors_input = isset($_POST['brand_colors']) && is_array($_POST['brand_colors'])
                ? map_deep(wp_unslash($_POST['brand_colors']), 'sanitize_hex_color')
                : [];
            $this->save_brand_colors($brand_colors_input);
        }

        update_option($this->get_theme_settings_option_name($slug), $sanitized);
        $this->update_theme_meta($slug, ['settings_saved_at' => current_time('mysql')]);

        if (
            isset($sanitized['color_mode'])
            && in_array($sanitized['color_mode'], ['light', 'dark', 'auto'], true)
        ) {
            $this->save_appearance_color_mode($slug, (string) $sanitized['color_mode']);
        }

        $success_message = __('Theme settings saved successfully.', 'yooadmin');

        if ($is_ajax) {
            $response = [
                'message'  => $success_message,
                'settings' => $sanitized,
            ];
            if ($supports_brand) {
                $response['brand_colors'] = $this->get_current_brand_colors();
            }
            wp_send_json_success($response);
        }

        wp_safe_redirect($this->get_theme_settings_page_url([
            'settings_status' => 'settings_saved',
        ]));
        exit;
    }
}

