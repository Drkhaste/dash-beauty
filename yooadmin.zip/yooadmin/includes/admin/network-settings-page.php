<?php
defined('ABSPATH') || exit;

class YOOAdmin_Network_Settings_Page
{
    private static $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        if (!is_multisite()) {
            return;
        }

        add_action('admin_init', [$this, 'set_page_title']);
        add_action('network_admin_menu', [$this, 'register_network_page'], 9);
    }

    public function set_page_title(): void
    {
        if (!function_exists('yooadmin_network_settings_is_screen') || !yooadmin_network_settings_is_screen()) {
            return;
        }

        global $title;
        $title = __('Network Settings', 'yooadmin');
    }

    public function register_network_page(): void
    {
        if (!function_exists('yooadmin_network_settings_should_use') || !yooadmin_network_settings_should_use()) {
            return;
        }

        add_submenu_page(
            'settings.php',
            __('Network Settings', 'yooadmin'),
            __('Network Settings', 'yooadmin'),
            'manage_network_options',
            yooadmin_network_settings_page_slug(),
            [$this, 'render_page']
        );
    }

    public function render_page(): void
    {
        if (!current_user_can('manage_network_options')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        if (!function_exists('yooadmin_network_settings_should_use') || !yooadmin_network_settings_should_use()) {
            wp_safe_redirect(network_admin_url('settings.php'));
            exit;
        }

        global $title;
        $title = __('Network Settings', 'yooadmin');

        $template = defined('YOOADMIN_PANEL_DIR')
            ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-settings/index.php'
            : '';

        if ($template && is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Network Settings', 'yooadmin') . '</h1></div>';
    }
}

YOOAdmin_Network_Settings_Page::get_instance();
