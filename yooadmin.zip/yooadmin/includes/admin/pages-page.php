<?php
/**
 * YOOAdmin - Pages page (admin list)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

require_once __DIR__ . '/yoast-summary.php';

class YOOAdmin_Pages_Page
{

    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('admin_menu', [$this, 'register_page']);
        add_action('admin_init', [$this, 'maybe_redirect']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_yooadmin_pages_action', [$this, 'handle_ajax_action']);
        add_action('wp_ajax_yooadmin_bulk_pages_action', [$this, 'handle_bulk_action']);
        add_action('wp_ajax_yooadmin_filter_pages', [$this, 'ajax_filter_pages']);
        add_action('wp_ajax_yooadmin_load_more_pages', [$this, 'ajax_load_more_pages']);
    }

    /**
     * Register hidden submenu page
     */
    public function register_page()
    {
        $hook = add_submenu_page(
            '', // Hidden from menu
            'Pages',
            'Pages',
            'edit_pages',
            'yooadmin-pages',
        [$this, 'render_page']
        );
        if ($hook) {
            add_action("load-{$hook}", function () {
                global $title;
                $title = __('Pages', 'yooadmin');

                $opts = (array)get_option('yooadmin_options', []);
                $enabled = !empty($opts['pages_redirect']);
                if (!$enabled) {
                    wp_safe_redirect(admin_url('edit.php?post_type=page'));
                    exit;
                }
            });
        }
    }

    /**
     * Enqueue assets for pages page
     */
    public function enqueue_assets($hook)
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page detection.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== 'yooadmin-pages') {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir = plugin_dir_path($base_file);
        $base_url = plugin_dir_url($base_file);

        // Enqueue styles
        $style_rel = 'assets/css/admin/pages-page.css';
        $style_abs = $base_dir . $style_rel;
        if (file_exists($style_abs)) {
            wp_enqueue_style('yooadmin-pages', $base_url . $style_rel, ['yooadmin-shell', 'yooadmin-core'], filemtime($style_abs));
        }

        if (function_exists('yooadmin_enqueue_list_screen_toast_assets')) {
            yooadmin_enqueue_list_screen_toast_assets();
        }

        if (function_exists('yooadmin_enqueue_list_screen_ui_assets')) {
            yooadmin_enqueue_list_screen_ui_assets();
        }

        // Enqueue scripts
        $script_rel = 'assets/js/admin/pages-page.js';
        $script_abs = $base_dir . $script_rel;
        if (file_exists($script_abs)) {
            $pages_deps = ['jquery'];
            if (wp_script_is('yooadmin-list-screen-toast', 'registered') || wp_script_is('yooadmin-list-screen-toast', 'enqueued')) {
                $pages_deps[] = 'yooadmin-list-screen-toast';
            }
            if (wp_script_is('yooadmin-yp-ui-select', 'registered') || wp_script_is('yooadmin-yp-ui-select', 'enqueued')) {
                $pages_deps[] = 'yooadmin-yp-ui-select';
            }
            wp_enqueue_script('yooadmin-pages', $base_url . $script_rel, $pages_deps, filemtime($script_abs), true);
            wp_localize_script('yooadmin-pages', 'yooadmPages', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('yooadmin_pages'),
                'i18n' => [
                    'deleteConfirm' => __('Are you sure you want to delete this page? This action cannot be undone.', 'yooadmin'),
                    'moveToTrash' => __('Move to Trash', 'yooadmin'),
                    'moveToTrashTitle' => __('Move to Trash?', 'yooadmin'),
                    'deletePageTitle' => __('Delete Page?', 'yooadmin'),
                    'restorePageTitle' => __('Restore Page?', 'yooadmin'),
                    /* translators: %s: page title */
                    'deleteConfirmMsg' => __('Are you sure you want to delete %s? This action cannot be undone.', 'yooadmin'),
                    /* translators: %s: page title */
                    'moveToTrashConfirmMsg' => __('Are you sure you want to move %s to trash?', 'yooadmin'),
                    /* translators: %s: page title */
                    'restoreConfirmMsg' => __('Are you sure you want to restore %s?', 'yooadmin'),
                    'cancel' => __('Cancel', 'yooadmin'),
                    'delete' => __('Delete', 'yooadmin'),
                    'restore' => __('Restore', 'yooadmin'),
                    'deleting' => __('Deleting...', 'yooadmin'),
                    'moving' => __('Moving...', 'yooadmin'),
                    'restoring' => __('Restoring...', 'yooadmin'),
                    'pageDeleted' => __('Page permanently deleted.', 'yooadmin'),
                    'pageMovedToTrash' => __('Page moved to trash.', 'yooadmin'),
                    'pageRestored' => __('Page restored.', 'yooadmin'),
                    'thisPage' => __('this page', 'yooadmin'),
                    'selected' => __('selected', 'yooadmin'),
                    'success' => __('Operation completed successfully.', 'yooadmin'),
                    'error' => __('An error occurred. Please try again.', 'yooadmin'),
                    'showStatistics' => __('Show Statistics', 'yooadmin'),
                    'hideStatistics' => __('Hide Statistics', 'yooadmin'),
                    'toDraft' => __('Draft', 'yooadmin'),
                    'publish' => __('Publish', 'yooadmin'),
                    'pageMovedToDraft' => __('Page moved to draft.', 'yooadmin'),
                    'pagePublished' => __('Page published.', 'yooadmin'),
                ],
            ]);
        }
    }

    /**
     * Redirect from default edit.php?post_type=page to our page if YOOAdmin layout is enabled
     */
    public function maybe_redirect()
    {
        global $pagenow;

        if ($pagenow !== 'edit.php') {
            return;
        }

        // Only redirect for pages
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post_type check.
        $post_type = isset($_GET['post_type']) ? sanitize_key(wp_unslash($_GET['post_type'])) : '';
        if ($post_type !== 'page') {
            return;
        }

        // Check if already on our page
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page check for redirect.
        if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'yooadmin-pages') {
            return;
        }

        // Check settings
        $opts = (array)get_option('yooadmin_options', []);
        $pages_redirect = array_key_exists('pages_redirect', $opts)
            ? (!empty($opts['pages_redirect']) ? 1 : 0)
            : 1;

        // Check Focus Mode policy
        if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return;
        }

        // Don't redirect if disabled
        if (!$pages_redirect) {
            return;
        }

        // Build redirect URL with query params
        $redirect = admin_url('admin.php?page=yooadmin-pages');

        // Preserve query parameters
        $params = ['post_status', 's', 'paged'];
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Preserving read-only GET filters for redirect; no state change.
        foreach ($params as $param) {
            if (!empty($_GET[$param])) {
                $redirect = add_query_arg($param, sanitize_text_field(wp_unslash($_GET[$param])), $redirect);
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        wp_safe_redirect($redirect);
        exit;
    }

    /**
     * Handle AJAX page actions (trash, delete, restore, etc.)
     */
    public function handle_ajax_action()
    {
        check_ajax_referer('yooadmin_pages', 'nonce');

        if (!current_user_can('edit_pages')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $action = isset($_POST['page_action']) ? sanitize_key((string)$_POST['page_action']) : '';
        $page_id = isset($_POST['page_id']) ? absint($_POST['page_id']) : 0;

        if (empty($action) || !$page_id) {
            wp_send_json_error(['message' => __('Missing required parameters.', 'yooadmin')]);
        }

        $page = get_post($page_id);
        if (!$page || $page->post_type !== 'page') {
            wp_send_json_error(['message' => __('Page not found.', 'yooadmin')]);
        }

        $message = '';

        switch ($action) {
            case 'trash':
                if (!current_user_can('delete_page', $page_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to delete this page.', 'yooadmin')]);
                }
                wp_trash_post($page_id);
                $message = __('Page moved to trash.', 'yooadmin');
                break;

            case 'delete':
                if (!current_user_can('delete_page', $page_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to delete this page.', 'yooadmin')]);
                }
                wp_delete_post($page_id, true);
                $message = __('Page permanently deleted.', 'yooadmin');
                break;

            case 'restore':
                if (!current_user_can('delete_page', $page_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to restore this page.', 'yooadmin')]);
                }
                wp_untrash_post($page_id);
                $message = __('Page restored.', 'yooadmin');
                break;

            case 'draft':
                if (!current_user_can('edit_page', $page_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to edit this page.', 'yooadmin')]);
                }
                if ($page->post_status !== 'publish') {
                    wp_send_json_error(['message' => __('Only published pages can be moved to draft.', 'yooadmin')]);
                }
                wp_update_post([
                    'ID' => $page_id,
                    'post_status' => 'draft',
                ]);
                $message = __('Page moved to draft.', 'yooadmin');
                break;

            case 'publish':
                if (!current_user_can('publish_post', $page_id)) {
                    wp_send_json_error(['message' => __('You do not have permission to publish this page.', 'yooadmin')]);
                }
                if (!in_array($page->post_status, ['draft', 'pending', 'private'], true)) {
                    wp_send_json_error(['message' => __('This page cannot be published from the current status.', 'yooadmin')]);
                }
                wp_update_post([
                    'ID' => $page_id,
                    'post_status' => 'publish',
                ]);
                $message = __('Page published.', 'yooadmin');
                break;

            default:
                wp_send_json_error(['message' => __('Invalid action.', 'yooadmin')]);
        }

        wp_send_json_success(['message' => $message]);
    }

    /**
     * Handle bulk actions via AJAX
     */
    public function handle_bulk_action()
    {
        check_ajax_referer('yooadmin_pages', 'nonce');

        if (!current_user_can('edit_pages')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $pages = isset($_POST['pages']) ? array_map('absint', (array)$_POST['pages']) : [];
        $action = isset($_POST['bulk_action']) ? sanitize_key((string)$_POST['bulk_action']) : '';

        if (empty($pages) || empty($action)) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'yooadmin')]);
        }

        $processed = 0;
        $errors = [];

        foreach ($pages as $page_id) {
            $page = get_post($page_id);
            if (!$page || $page->post_type !== 'page') {
                continue;
            }

            switch ($action) {
                case 'trash':
                    if (current_user_can('delete_page', $page_id)) {
                        wp_trash_post($page_id);
                        $processed++;
                    }
                    else {
                        // translators: %d: page ID
                        $errors[] = sprintf(__('No permission to trash page #%d.', 'yooadmin'), $page_id);
                    }
                    break;

                case 'delete':
                    if (current_user_can('delete_page', $page_id)) {
                        wp_delete_post($page_id, true);
                        $processed++;
                    }
                    else {
                        // translators: %d: page ID
                        $errors[] = sprintf(__('No permission to delete page #%d.', 'yooadmin'), $page_id);
                    }
                    break;

                case 'restore':
                    if (current_user_can('delete_page', $page_id)) {
                        wp_untrash_post($page_id);
                        $processed++;
                    }
                    else {
                        // translators: %d: page ID
                        $errors[] = sprintf(__('No permission to restore page #%d.', 'yooadmin'), $page_id);
                    }
                    break;
            }
        }

        if ($processed > 0) {
            // translators: %d: number of pages processed
            $message = sprintf(_n('%d page processed.', '%d pages processed.', $processed, 'yooadmin'), $processed);
            if (!empty($errors)) {
                // translators: %d: number of errors
                $message .= ' ' . sprintf(_n('%d error occurred.', '%d errors occurred.', count($errors), 'yooadmin'), count($errors));
            }
            wp_send_json_success(['message' => $message]);
        }
        else {
            $error_message = !empty($errors) ? implode(' ', $errors) : __('No pages were processed.', 'yooadmin');
            wp_send_json_error(['message' => $error_message]);
        }
    }

    /**
     * AJAX handler for filtering pages
     */
    public function ajax_filter_pages()
    {
        check_ajax_referer('yooadmin_pages', 'nonce');

        if (!current_user_can('edit_pages')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $per_page = max(5, (int)apply_filters('yooadmin_pages_per_page', 12));
        $paged    = isset($_POST['paged'])       ? max(1, absint($_POST['paged']))                  : 1;
        $status   = isset($_POST['post_status']) ? sanitize_key(wp_unslash($_POST['post_status']))  : '';
        $search   = isset($_POST['s'])           ? sanitize_text_field(wp_unslash($_POST['s']))     : '';

        $args = [
            'post_type'      => 'page',
            'posts_per_page' => $per_page,
            'paged'          => $paged,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        if ($status) {
            $args['post_status'] = $status;
        }

        if ($search) {
            $args['s'] = $search;
        }

        $query     = new WP_Query($args);
        $has_posts = $query->post_count > 0;

        // Cards HTML
        ob_start();
        if ($has_posts) {
            while ($query->have_posts()) {
                $query->the_post();
                $this->render_page_card(get_post());
            }
            wp_reset_postdata();
        }
        $cards_html = ob_get_clean();

        // Table rows HTML
        ob_start();
        if ($has_posts) {
            $query->rewind_posts();
            while ($query->have_posts()) {
                $query->the_post();
                $this->render_page_table_row(get_post());
            }
            wp_reset_postdata();
        }
        $table_html = ob_get_clean();

        // Empty state HTML
        $empty_html = '';
        if (!$has_posts) {
            ob_start();
            echo '<div class="yoo-pages-empty">';
            echo '<div class="yoo-empty-illustration"><span class="dashicons dashicons-admin-page"></span></div>';
            echo '<h2>' . esc_html__('No pages found', 'yooadmin') . '</h2>';
            echo '<p>' . esc_html__('Try adjusting your search or filter criteria.', 'yooadmin') . '</p>';
            echo '</div>';
            $empty_html = ob_get_clean();
        }

        wp_send_json_success([
            'cards_html'  => $cards_html,
            'table_html'  => $table_html,
            'empty_html'  => $empty_html,
            'total'       => (int)$query->found_posts,
            'paged'       => $paged,
            'total_pages' => (int)$query->max_num_pages,
            'has_more'    => $paged < $query->max_num_pages,
        ]);
    }

    /**
     * Load more pages via AJAX (for infinite scroll)
     */
    public function ajax_load_more_pages()
    {
        check_ajax_referer('yooadmin_pages', 'nonce');

        if (!current_user_can('edit_pages')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $per_page = max(5, (int)apply_filters('yooadmin_pages_per_page', 12));
        $paged = isset($_POST['paged']) ? max(1, (int)$_POST['paged']) : 1;
        $status = isset($_POST['post_status']) ? sanitize_key((string)$_POST['post_status']) : '';
        $search = isset($_POST['s']) ? sanitize_text_field(wp_unslash($_POST['s'])) : '';
        $view = isset($_POST['view']) ? sanitize_key((string)$_POST['view']) : 'cards'; // cards or table

        $args = [
            'post_type' => 'page',
            'posts_per_page' => $per_page,
            'paged' => $paged,
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        if ($status) {
            $args['post_status'] = $status;
        }

        if ($search) {
            $args['s'] = $search;
        }

        $query = new WP_Query($args);

        // Render pages HTML
        ob_start();
        if ($query->have_posts()) {
            if ($view === 'table') {
                // Render table rows
                while ($query->have_posts()) {
                    $query->the_post();
                    $page = get_post();
                    $this->render_page_table_row($page);
                }
            }
            else {
                // Render cards
                while ($query->have_posts()) {
                    $query->the_post();
                    $this->render_page_card(get_post());
                }
            }
            wp_reset_postdata();
        }
        $html = ob_get_clean();

        wp_send_json_success([
            'html' => $html,
            'has_more' => $paged < $query->max_num_pages,
            'next_page' => $paged + 1,
            'total_pages' => (int)$query->max_num_pages,
        ]);
    }

    /**
     * WordPress / WooCommerce role labels for a page (homepage, blog, shop, etc.).
     *
     * @param int $page_id Page ID.
     * @return array<int, array{icon:string,label:string,tooltip:string}>
     */
    private function get_page_role_badges($page_id)
    {
        $page_id = (int) $page_id;
        if ($page_id <= 0) {
            return [];
        }

        $badges = [];

        if (get_option('show_on_front') === 'page') {
            $front_id = (int) get_option('page_on_front');
            $posts_id = (int) get_option('page_for_posts');
            if ($front_id === $page_id) {
                $badges[] = [
                    'icon' => 'dashicons-admin-home',
                    'label' => __('Front Page', 'yooadmin'),
                    'tooltip' => __('This page is set as the site homepage (Settings → Reading).', 'yooadmin'),
                ];
            }
            if ($posts_id === $page_id) {
                $badges[] = [
                    'icon' => 'dashicons-admin-post',
                    'label' => __('Blog', 'yooadmin'),
                    'tooltip' => __('This page shows your latest posts (Settings → Reading).', 'yooadmin'),
                ];
            }
        }

        $privacy = (int) get_option('wp_page_for_privacy_policy');
        if ($privacy > 0 && $privacy === $page_id) {
            $badges[] = [
                'icon' => 'dashicons-shield',
                'label' => __('Privacy Policy', 'yooadmin'),
                'tooltip' => __('Designated privacy policy page.', 'yooadmin'),
            ];
        }

        if (function_exists('wc_get_page_id')) {
            $wc_map = [
                'shop' => [
                    'dashicons-cart',
                    __('Shop', 'yooadmin'),
                    __('WooCommerce shop page.', 'yooadmin'),
                ],
                'cart' => [
                    'dashicons-cart',
                    __('Cart', 'yooadmin'),
                    __('WooCommerce cart page.', 'yooadmin'),
                ],
                'checkout' => [
                    'dashicons-clipboard',
                    __('Checkout', 'yooadmin'),
                    __('WooCommerce checkout page.', 'yooadmin'),
                ],
                'myaccount' => [
                    'dashicons-admin-users',
                    __('My account', 'yooadmin'),
                    __('WooCommerce customer account page.', 'yooadmin'),
                ],
            ];
            foreach ($wc_map as $key => $data) {
                $pid = (int) wc_get_page_id($key);
                if ($pid > 0 && $pid === $page_id) {
                    $badges[] = [
                        'icon' => $data[0],
                        'label' => $data[1],
                        'tooltip' => $data[2],
                    ];
                }
            }
        }

        if (function_exists('wc_terms_and_conditions_page_id')) {
            $terms_id = (int) wc_terms_and_conditions_page_id();
            if ($terms_id > 0 && $terms_id === $page_id) {
                $badges[] = [
                    'icon' => 'dashicons-media-text',
                    'label' => __('Terms', 'yooadmin'),
                    'tooltip' => __('WooCommerce terms and conditions page.', 'yooadmin'),
                ];
            }
        }

        return $badges;
    }

    /**
     * Echo role badge chips for a page (homepage, blog, WooCommerce, etc.).
     *
     * @param int $page_id Page ID.
     */
    private function render_page_role_badges_html($page_id)
    {
        $badges = $this->get_page_role_badges($page_id);
        if (empty($badges)) {
            return;
        }

        echo '<div class="yoo-page-wp-roles">';
        foreach ($badges as $badge) {
            printf(
                '<span class="yoo-page-wp-role" title="%1$s"><span class="dashicons %2$s" aria-hidden="true"></span><span class="yoo-page-wp-role__text">%3$s</span></span>',
                esc_attr($badge['tooltip']),
                esc_attr($badge['icon']),
                esc_html($badge['label'])
            );
        }
        echo '</div>';
    }

    /**
     * Render page table row
     */
    private function render_page_table_row($page)
    {
        $edit_url = get_edit_post_link($page->ID);
        $view_url = get_permalink($page->ID);
        $page_status = $page->post_status;
        $page_author = get_userdata($page->post_author);
        $featured_image = get_the_post_thumbnail_url($page->ID, 'thumbnail');
        $full_image = get_the_post_thumbnail_url($page->ID, 'full');
        $parent = $page->post_parent ? get_post($page->post_parent) : null;
?>
        <tr class="yoo-page-row <?php echo esc_attr($page_status); ?>" data-page-id="<?php echo esc_attr($page->ID); ?>" data-title="<?php echo esc_attr(strtolower(get_the_title($page->ID) ?: '')); ?>" data-date="<?php echo esc_attr(get_the_date('U', $page->ID)); ?>">
            <th scope="row" class="check-column">
                <input type="checkbox" class="yoo-page-checkbox" value="<?php echo esc_attr($page->ID); ?>" id="page-table-<?php echo esc_attr($page->ID); ?>">
                <label for="page-table-<?php echo esc_attr($page->ID); ?>" class="screen-reader-text"><?php esc_html_e('Select', 'yooadmin'); ?></label>
            </th>
            <td class="thumbnail column-thumbnail" data-colname="<?php esc_attr_e('Image', 'yooadmin'); ?>">
                <div class="yoo-table-thumb-wrap">
                    <?php if ($featured_image): ?>
                <div class="yoo-table-thumbnail">
                    <img src="<?php echo esc_url($featured_image); ?>"
                         alt="<?php echo esc_attr(get_the_title($page->ID)); ?>"
                         class="yoo-image-lightbox-trigger"
                         data-image-url="<?php echo esc_url($full_image); ?>"
                         data-image-title="<?php echo esc_attr(get_the_title($page->ID)); ?>"
                         style="cursor: pointer;">
                </div>
                    <?php
        else: ?>
                <div class="yoo-table-thumbnail yoo-table-thumbnail--placeholder">
                    <span class="dashicons dashicons-format-image"></span>
                </div>
                    <?php
        endif; ?>
                </div>
            </td>
            <td class="title column-title column-primary" data-colname="<?php esc_attr_e('Title', 'yooadmin'); ?>">
                <strong>
                    <a class="row-title" href="<?php echo esc_url($edit_url); ?>" title="<?php echo esc_attr(get_the_title($page->ID) ?: __('(No title)', 'yooadmin')); ?>">
                        <?php echo esc_html(get_the_title($page->ID) ?: __('(No title)', 'yooadmin')); ?>
                    </a>
                </strong>
                <?php $this->render_page_role_badges_html($page->ID); ?>
                <div class="row-actions">
                    <?php if ($page_status === 'publish'): ?>
                    <span class="view">
                        <a href="<?php echo esc_url($view_url); ?>" target="_blank"><?php esc_html_e('View', 'yooadmin'); ?></a> |
                    </span>
                    <?php
        endif; ?>
                    <span class="edit">
                        <a href="<?php echo esc_url($edit_url); ?>"><?php esc_html_e('Edit', 'yooadmin'); ?></a> |
                    </span>
                    <?php if ($page_status === 'publish' && current_user_can('edit_page', $page->ID)): ?>
                    <span class="to-draft">
                        <a href="#" class="yoo-action-link to-draft" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Draft', 'yooadmin'); ?></a> |
                    </span>
                    <?php
        elseif (in_array($page_status, ['draft', 'pending', 'private'], true) && current_user_can('publish_post', $page->ID)): ?>
                    <span class="to-publish">
                        <a href="#" class="yoo-action-link to-publish" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Publish', 'yooadmin'); ?></a> |
                    </span>
                    <?php
        endif; ?>
                    <?php if ($page_status === 'trash'): ?>
                    <span class="restore">
                        <a href="#" class="yoo-action-link restore" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Restore', 'yooadmin'); ?></a> |
                    </span>
                    <span class="trash">
                        <a href="#" class="yoo-action-link delete" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Delete Permanently', 'yooadmin'); ?></a>
                    </span>
                    <?php
        else: ?>
                    <span class="trash">
                        <a href="#" class="yoo-action-link trash" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Trash', 'yooadmin'); ?></a>
                    </span>
                    <?php
        endif; ?>
                </div>
                <?php yooadmin_render_yoast_summary($page->ID, 'page'); ?>
            </td>
            <td class="author column-author" data-colname="<?php esc_attr_e('Author', 'yooadmin'); ?>">
                <?php echo esc_html($page_author ? $page_author->display_name : __('Unknown', 'yooadmin')); ?>
            </td>
            <td class="parent column-parent" data-colname="<?php esc_attr_e('Parent', 'yooadmin'); ?>">
                <?php echo $parent ? esc_html($parent->post_title) : '<span aria-hidden="true">—</span>'; ?>
            </td>
            <td class="date column-date" data-colname="<?php esc_attr_e('Date', 'yooadmin'); ?>">
                <?php echo esc_html(get_the_date('', $page->ID)); ?>
            </td>
            <td class="status column-status" data-colname="<?php esc_attr_e('Status', 'yooadmin'); ?>">
                <span class="yoo-page-status yoo-page-status--<?php echo esc_attr($page_status); ?>">
                    <?php echo esc_html(ucfirst($page_status)); ?>
                </span>
            </td>
        </tr>
        <?php
    }

    /**
     * Render page card
     */
    private function render_page_card($page)
    {
        $edit_url       = get_edit_post_link($page->ID);
        $view_url       = get_permalink($page->ID);
        $status         = $page->post_status;
        $author         = get_userdata($page->post_author);
        $featured_image = get_the_post_thumbnail_url($page->ID, 'medium');
        $full_image     = $featured_image ? get_the_post_thumbnail_url($page->ID, 'full') : '';
        $parent         = $page->post_parent ? get_post($page->post_parent) : null;
?>
        <article class="yoo-page-card <?php echo esc_attr($status); ?>" data-page-id="<?php echo esc_attr($page->ID); ?>">
            <input type="checkbox" class="yoo-page-checkbox" value="<?php echo esc_attr($page->ID); ?>" id="page-<?php echo esc_attr($page->ID); ?>">
            <label for="page-<?php echo esc_attr($page->ID); ?>" class="yoo-page-checkbox-label"></label>

            <div class="yoo-page-image">
                <?php $this->render_page_role_badges_html($page->ID); ?>
                <span class="yoo-page-status yoo-page-status--<?php echo esc_attr($status); ?>">
                    <?php echo esc_html(ucfirst($status)); ?>
                </span>
                <?php if ($featured_image): ?>
                <img src="<?php echo esc_url($featured_image); ?>"
                     alt="<?php echo esc_attr(get_the_title($page->ID)); ?>"
                     class="yoo-image-lightbox-trigger"
                     data-image-url="<?php echo esc_url($full_image); ?>"
                     data-image-title="<?php echo esc_attr(get_the_title($page->ID)); ?>"
                     style="cursor: pointer;">
                <?php else: ?>
                <div class="yoo-page-image-placeholder">
                    <span class="dashicons dashicons-format-image"></span>
                    <span class="yoo-placeholder-text"><?php esc_html_e('No Image', 'yooadmin'); ?></span>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="yoo-page-content">
                <header class="yoo-page-header">
                    <h2 class="yoo-page-title">
                        <a href="<?php echo esc_url($edit_url); ?>" title="<?php echo esc_attr(get_the_title($page->ID) ?: __('(No title)', 'yooadmin')); ?>">
                            <?php echo esc_html(get_the_title($page->ID) ?: __('(No title)', 'yooadmin')); ?>
                        </a>
                    </h2>
                </header>
                
                <div class="yoo-page-meta">
                    <div class="yoo-page-meta-item">
                        <span class="dashicons dashicons-admin-users"></span>
                        <span><?php echo esc_html($author ? $author->display_name : __('Unknown', 'yooadmin')); ?></span>
                    </div>
                    <div class="yoo-page-meta-item">
                        <span class="dashicons dashicons-calendar-alt"></span>
                        <span><?php echo esc_html(get_the_date('', $page->ID)); ?></span>
                    </div>
                    <?php if ($parent): ?>
                    <div class="yoo-page-meta-item">
                        <span class="dashicons dashicons-networking"></span>
                        <span><?php echo esc_html($parent->post_title); ?></span>
                    </div>
                    <?php
        endif; ?>
                </div>
                
                <?php if (!empty($page->post_excerpt)): ?>
                <p class="yoo-page-excerpt"><?php echo esc_html(wp_trim_words($page->post_excerpt, 20)); ?></p>
                <?php
        endif; ?>
                
                <div class="yoo-page-actions">
                    <?php if ($status === 'publish'): ?>
                    <a href="<?php echo esc_url($view_url); ?>" target="_blank" class="yoo-action-btn">
                        <span class="dashicons dashicons-visibility"></span>
                        <?php esc_html_e('View', 'yooadmin'); ?>
                    </a>
                    <?php
        endif; ?>
                    <a href="<?php echo esc_url($edit_url); ?>" class="yoo-action-btn">
                        <span class="dashicons dashicons-edit"></span>
                        <?php esc_html_e('Edit', 'yooadmin'); ?>
                    </a>
                    <?php if ($status === 'publish' && current_user_can('edit_page', $page->ID)): ?>
                    <button type="button" class="yoo-action-btn to-draft" data-page-id="<?php echo esc_attr($page->ID); ?>">
                        <span class="dashicons dashicons-hidden"></span>
                        <?php esc_html_e('Draft', 'yooadmin'); ?>
                    </button>
                    <?php
        elseif (in_array($status, ['draft', 'pending', 'private'], true) && current_user_can('publish_post', $page->ID)): ?>
                    <button type="button" class="yoo-action-btn to-publish" data-page-id="<?php echo esc_attr($page->ID); ?>">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <?php esc_html_e('Publish', 'yooadmin'); ?>
                    </button>
                    <?php
        endif; ?>
                    <?php if ($status === 'trash'): ?>
                    <button class="yoo-action-btn restore" data-page-id="<?php echo esc_attr($page->ID); ?>">
                        <span class="dashicons dashicons-undo"></span>
                        <?php esc_html_e('Restore', 'yooadmin'); ?>
                    </button>
                    <button class="yoo-action-btn danger delete" data-page-id="<?php echo esc_attr($page->ID); ?>">
                        <span class="dashicons dashicons-trash"></span>
                        <?php esc_html_e('Delete', 'yooadmin'); ?>
                    </button>
                    <?php
        else: ?>
                    <button class="yoo-action-btn trash" data-page-id="<?php echo esc_attr($page->ID); ?>">
                        <span class="dashicons dashicons-trash"></span>
                        <?php esc_html_e('Trash', 'yooadmin'); ?>
                    </button>
                    <?php
        endif; ?>
                </div>
                <?php yooadmin_render_yoast_summary($page->ID, 'page'); ?>
            </div>
        </article>
        <?php
    }

    /**
     * Render pagination
     */
    private function render_pagination($current, $total_pages, $status = '', $search = '')
    {
        $base_url = admin_url('admin.php?page=yooadmin-pages');
        if ($status) {
            $base_url = add_query_arg('post_status', urlencode($status), $base_url);
        }
        if ($search) {
            $base_url = add_query_arg('s', urlencode($search), $base_url);
        }

        echo '<nav class="yoo-pages-pagination">';

        // Previous
        if ($current > 1) {
            $prev_url = add_query_arg('paged', $current - 1, $base_url);
            printf('<a href="%s" class="yoo-pagination-prev" data-paged="%d">%s</a>',
                esc_url($prev_url),
                esc_attr($current - 1),
                esc_html__('Previous', 'yooadmin')
            );
        }

        // Page numbers
        for ($i = 1; $i <= $total_pages; $i++) {
            if ($i === $current) {
                printf('<span class="yoo-pagination-current">%d</span>', (int)$i);
            }
            else {
                $page_url = add_query_arg('paged', $i, $base_url);
                printf('<a href="%s" class="yoo-pagination-link" data-paged="%d">%d</a>',
                    esc_url($page_url),
                    (int)$i,
                    (int)$i
                );
            }
        }

        // Next
        if ($current < $total_pages) {
            $next_url = add_query_arg('paged', $current + 1, $base_url);
            printf('<a href="%s" class="yoo-pagination-next" data-paged="%d">%s</a>',
                esc_url($next_url),
                esc_attr($current + 1),
                esc_html__('Next', 'yooadmin')
            );
        }

        echo '</nav>';
    }

    /**
     * Render the pages page
     */
    public function render_page()
    {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'yooadmin'));
        }

        $per_page = max(5, (int)apply_filters('yooadmin_pages_per_page', 12));
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only pagination/filter from URL.
        $paged = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter from URL.
        $status = isset($_GET['post_status']) ? sanitize_key(wp_unslash($_GET['post_status'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search from URL.
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';

        $args = [
            'post_type' => 'page',
            'posts_per_page' => $per_page,
            'paged' => $paged,
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        if ($status) {
            $args['post_status'] = $status;
        }

        if ($search) {
            $args['s'] = $search;
        }

        $query = new WP_Query($args);

        // Get stats
        $all_count = wp_count_posts('page');
        $publish_count = isset($all_count->publish) ? (int)$all_count->publish : 0;
        $draft_count = isset($all_count->draft) ? (int)$all_count->draft : 0;
        $trash_count = isset($all_count->trash) ? (int)$all_count->trash : 0;
        $total_count = (int)array_sum((array)$all_count) - $trash_count;

        $template = plugin_dir_path(yooadmin_base_file()) . 'templates/yoopixel/admin/pages/pages/index.php';
        if (file_exists($template)) {
            include $template;
            return;
        }

        // Fallback render
        echo '<div class="wrap"><h1>' . esc_html__('Pages', 'yooadmin') . '</h1>';
        if ($query->have_posts()) {
            echo '<ul>';
            while ($query->have_posts()) {
                $query->the_post();
                printf('<li><a href="%s">%s</a></li>',
                    esc_url(get_edit_post_link()),
                    esc_html(get_the_title())
                );
            }
            wp_reset_postdata();
            echo '</ul>';
        }
        else {
            esc_html_e('No pages found.', 'yooadmin');
        }
        echo '</div>';
    }
}

// Initialize
YOOAdmin_Pages_Page::get_instance();
