<?php
/**
 * YOOAdmin — native plugins.php toasts + confirm modal (Studio Hub layout).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * @return bool
 */
function yooadmin_is_plugins_admin_experience_screen(): bool {
    if (!is_admin() || !function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
        return false;
    }

    if (!function_exists('yooadmin_studio_hub_should_style_plugins_php_experience')) {
        return false;
    }

    return yooadmin_studio_hub_should_style_plugins_php_experience();
}

/**
 * @param string $classes
 * @return string
 */
function yooadmin_filter_plugins_admin_experience_body_class(string $classes): string {
    if (!yooadmin_is_plugins_admin_experience_screen()) {
        return $classes;
    }

    return trim($classes . ' yooadmin-plugins-screen yoo-list-screen');
}

/**
 * Enqueue toast + confirm + plugins.php experience script.
 */
function yooadmin_enqueue_plugins_admin_experience_assets(): void {
    if (!yooadmin_is_plugins_admin_experience_screen()) {
        return;
    }

    if (function_exists('yooadmin_enqueue_yp_admin_toast_assets')) {
        yooadmin_enqueue_yp_admin_toast_assets();
    }

    if (function_exists('yooadmin_enqueue_yp_admin_confirm_assets')) {
        yooadmin_enqueue_yp_admin_confirm_assets();
    }

    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $base_dir  = plugin_dir_path($base_file);
    $base_url  = plugin_dir_url($base_file);

    $js_rel = 'assets/js/admin/plugins-admin-experience.js';
    $js_abs = $base_dir . $js_rel;
    if (!is_readable($js_abs)) {
        return;
    }

    $deps = ['jquery'];
    foreach (['yooadmin-notice-classifier', 'yooadmin-yp-admin-toast', 'yooadmin-yp-admin-confirm', 'updates', 'yooadmin-global-buttons'] as $handle) {
        if (wp_script_is($handle, 'registered') || wp_script_is($handle, 'enqueued')) {
            $deps[] = $handle;
        }
    }

    $spa_rel = 'assets/js/admin/plugins-php-spa.js';
    $spa_abs = $base_dir . $spa_rel;
    if (is_readable($spa_abs)) {
        $spa_deps = ['jquery', 'updates'];
        if (wp_script_is('yooadmin-studio-hub-plugins-php-layout', 'registered')) {
            $spa_deps[] = 'yooadmin-studio-hub-plugins-php-layout';
        }
        wp_enqueue_script(
            'yooadmin-plugins-php-spa',
            $base_url . $spa_rel,
            $spa_deps,
            (string) filemtime($spa_abs),
            true
        );
        $deps[] = 'yooadmin-plugins-php-spa';
    }

    wp_enqueue_script(
        'yooadmin-plugins-admin-experience',
        $base_url . $js_rel,
        array_values(array_unique($deps)),
        (string) filemtime($js_abs),
        true
    );

    wp_localize_script(
        'yooadmin-plugins-admin-experience',
        'yooadminPluginsExperience',
        [
            'i18n' => [
                'confirmTitle'       => __('Are you sure?', 'yooadmin'),
                'delete'             => __('Delete', 'yooadmin'),
                'cancel'             => __('Cancel', 'yooadmin'),
                /* translators: %s: plugin name */
                'deleteSingle'       => __('Are you sure you want to delete %s?', 'yooadmin'),
                /* translators: %s: plugin name */
                'deleteSingleData'   => __('Are you sure you want to delete %s and its data?', 'yooadmin'),
                'deleteBulk'         => __('Are you sure you want to delete the selected plugins and their data?', 'yooadmin'),
                'deleteBulkFiles'    => __('Are you sure you want to delete the selected plugins?', 'yooadmin'),
                'pluginActivated'    => __('Plugin activated.', 'yooadmin'),
                /* translators: %s: plugin name */
                'pluginActivatedNamed' => __('%s activated successfully.', 'yooadmin'),
                'pluginDeactivated'  => __('Plugin deactivated.', 'yooadmin'),
                'pluginDeleted'      => __('Plugin deleted.', 'yooadmin'),
                'activateFailed'     => __('Plugin could not be activated.', 'yooadmin'),
                'loadingPlugins'     => __('Updating plugins…', 'yooadmin'),
                'activatingPlugin'   => __('Activating plugin…', 'yooadmin'),
                'deactivatingPlugin' => __('Deactivating plugin…', 'yooadmin'),
                'requestFailed'      => __('Something went wrong. Please try again.', 'yooadmin'),
                /* translators: %s: plugin name */
                'autoUpdateEnabled'  => __('Auto-updates enabled for %s.', 'yooadmin'),
                /* translators: %s: plugin name */
                'autoUpdateDisabled' => __('Auto-updates disabled for %s.', 'yooadmin'),
                'autoUpdateFailed'   => __('Could not change auto-updates setting.', 'yooadmin'),
            ],
        ]
    );
}

add_filter('admin_body_class', 'yooadmin_filter_plugins_admin_experience_body_class', 21);
add_action('admin_enqueue_scripts', 'yooadmin_enqueue_plugins_admin_experience_assets', 25);
