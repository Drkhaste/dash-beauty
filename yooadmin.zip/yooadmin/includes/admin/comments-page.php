<?php
/**
 * YOOAdmin - Comments page (admin list)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

class YOOAdmin_Comments_Page
{

    private static $instance = null;

    /** @var array<string, string> */
    private $column_labels = [];

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('admin_menu', [$this, 'register_page']);
        add_action('admin_init', [$this, 'maybe_redirect']);
        add_action('load-edit-comments.php', [$this, 'maybe_redirect'], 1);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_yooadmin_comments_action', [$this, 'handle_ajax_action']);
        add_action('wp_ajax_yooadmin_bulk_comments_action', [$this, 'handle_bulk_action']);
        add_action('wp_ajax_yooadmin_filter_comments', [$this, 'ajax_filter_comments']);
        add_action('wp_ajax_yooadmin_get_comment_counts', [$this, 'ajax_get_comment_counts']);
        add_action('wp_ajax_yooadmin_comments_delete_batch', [$this, 'ajax_delete_batch']);
        add_action('wp_ajax_yooadmin_comments_set_enabled', [$this, 'ajax_set_comments_enabled']);
        add_action('wp_ajax_yooadmin_comments_screen_options', [$this, 'ajax_save_screen_options']);
        $this->register_frontend_comment_guards();
    }

    public function is_site_comments_enabled(): bool
    {
        return get_option('default_comment_status', 'open') === 'open';
    }

    /**
     * Normalized moderation status for UI/actions.
     *
     * @param WP_Comment $comment
     * @return string pending|approved|spam|trash
     */
    private function get_comment_moderation_status(WP_Comment $comment): string
    {
        $raw = wp_get_comment_status($comment);

        if ($raw === 'unapproved' || $raw === 'hold' || (string) $comment->comment_approved === '0') {
            return 'pending';
        }

        if (in_array($raw, ['approved', 'spam', 'trash'], true)) {
            return $raw;
        }

        return (string) $comment->comment_approved === '1' ? 'approved' : 'pending';
    }

    /**
     * @param string $status
     */
    private function is_comment_pending_status(string $status): bool
    {
        return $status === 'pending';
    }

    public function register_frontend_comment_guards(): void
    {
        if (is_admin() && !wp_doing_ajax()) {
            return;
        }

        add_filter('comments_open', [$this, 'filter_comments_open'], 20, 2);
        add_filter('pings_open', [$this, 'filter_pings_open'], 20, 2);
        add_action('pre_comment_on_post', [$this, 'block_comment_when_disabled'], 0);
    }

    /**
     * @param bool $open
     * @param int  $post_id
     * @return bool
     */
    public function filter_comments_open($open, $post_id)
    {
        if (!$this->is_site_comments_enabled()) {
            return false;
        }

        return (bool) $open;
    }

    /**
     * @param bool $open
     * @param int  $post_id
     * @return bool
     */
    public function filter_pings_open($open, $post_id)
    {
        if (!$this->is_site_comments_enabled()) {
            return false;
        }

        return (bool) $open;
    }

    /**
     * @param int $comment_post_id
     */
    public function block_comment_when_disabled($comment_post_id): void
    {
        if ($this->is_site_comments_enabled()) {
            return;
        }

        wp_die(
            esc_html__('Comments are closed.', 'yooadmin'),
            esc_html__('Comment Submission Failure', 'yooadmin'),
            ['response' => 403, 'back_link' => true]
        );
    }

    /**
     * @return array<string, string>
     */
    private function get_column_labels(): array
    {
        if (empty($this->column_labels)) {
            $this->column_labels = [
                'author'   => __('Author', 'yooadmin'),
                'comment'  => __('Comment', 'yooadmin'),
                'response' => __('In response to', 'yooadmin'),
                'date'     => __('Submitted on', 'yooadmin'),
            ];
        }

        return $this->column_labels;
    }

    /**
     * Whether edit-comments.php should use the YOOAdmin comments page.
     * Default is enabled (1) when the option key is not stored yet.
     */
    private function is_comments_redirect_enabled(): bool
    {
        $opts = (array) get_option('yooadmin_options', []);

        if (!array_key_exists('comments_redirect', $opts)) {
            return true;
        }

        return !empty($opts['comments_redirect']);
    }

    public function register_page()
    {
        $hook = add_submenu_page(
            '',
            'Comments',
            'Comments',
            'moderate_comments',
            'yooadmin-comments',
            [$this, 'render_page']
        );

        if ($hook) {
            add_action("load-{$hook}", function () {
                global $title;
                $title = __('Comments', 'yooadmin');

                if (!$this->is_comments_redirect_enabled()) {
                    $this->redirect_to_native_comments_page();
                }

                if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
                    $this->redirect_to_native_comments_page();
                }
            });
        }
    }

    /**
     * Redirect to the native WordPress comments screen, preserving list filters.
     */
    private function redirect_to_native_comments_page(): void
    {
        $redirect = admin_url('edit-comments.php');
        $params   = ['comment_status', 's', 'paged', 'comment_type'];

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Preserving read-only GET filters for redirect.
        foreach ($params as $param) {
            if (!empty($_GET[$param])) {
                $redirect = add_query_arg($param, sanitize_text_field(wp_unslash($_GET[$param])), $redirect);
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        wp_safe_redirect($redirect);
        exit;
    }

    /**
     * @param array<int, string> $deps
     * @return array<int, string>
     */
    private function filter_registered_style_deps(array $deps): array
    {
        $registered = [];

        foreach ($deps as $dep) {
            if (!is_string($dep) || $dep === '') {
                continue;
            }

            if (wp_style_is($dep, 'registered') || wp_style_is($dep, 'enqueued')) {
                $registered[] = $dep;
            }
        }

        return $registered;
    }

    public function enqueue_assets($hook)
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page detection.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== 'yooadmin-comments') {
            return;
        }

        if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir  = plugin_dir_path($base_file);
        $base_url  = plugin_dir_url($base_file);

        $posts_style = $base_dir . 'assets/css/admin/posts-page.css';
        if (is_readable($posts_style)) {
            wp_enqueue_style(
                'yooadmin-posts',
                $base_url . 'assets/css/admin/posts-page.css',
                $this->filter_registered_style_deps(['yooadmin-shell']),
                filemtime($posts_style)
            );
        }

        $style_rel = 'assets/css/admin/comments-page.css';
        $style_abs = $base_dir . $style_rel;
        $style_deps = $this->filter_registered_style_deps(['yooadmin-shell']);
        if (wp_style_is('yooadmin-posts', 'registered') || wp_style_is('yooadmin-posts', 'enqueued')) {
            $style_deps[] = 'yooadmin-posts';
        }
        if (file_exists($style_abs)) {
            wp_enqueue_style('yooadmin-comments', $base_url . $style_rel, $style_deps, filemtime($style_abs));
        }

        $lso_css = $base_dir . 'assets/css/admin/list-screen-options-modal.css';
        if (is_readable($lso_css)) {
            wp_enqueue_style(
                'yooadmin-list-screen-options-modal',
                $base_url . 'assets/css/admin/list-screen-options-modal.css',
                $this->filter_registered_style_deps(['yooadmin-shell']),
                (string) filemtime($lso_css)
            );
        }

        if (function_exists('yooadmin_enqueue_list_screen_toast_assets')) {
            yooadmin_enqueue_list_screen_toast_assets();
        }

        if (function_exists('yooadmin_enqueue_list_screen_ui_assets')) {
            yooadmin_enqueue_list_screen_ui_assets();
        }

        if (function_exists('yooadmin_enqueue_yp_admin_confirm_assets')) {
            yooadmin_enqueue_yp_admin_confirm_assets();
        }

        wp_enqueue_script('admin-comments');

        $script_rel = 'assets/js/admin/comments-page.js';
        $script_abs = $base_dir . $script_rel;
        if (!file_exists($script_abs)) {
            return;
        }

        $deps = ['jquery', 'admin-comments'];
        foreach (['yooadmin-list-screen-toast', 'yooadmin-yp-ui-select', 'yooadmin-yp-admin-confirm'] as $handle) {
            if (wp_script_is($handle, 'registered') || wp_script_is($handle, 'enqueued')) {
                $deps[] = $handle;
            }
        }

        wp_enqueue_script('yooadmin-comments', $base_url . $script_rel, $deps, filemtime($script_abs), true);

        $hidden = $this->get_hidden_columns();
        $per_page = $this->get_per_page();

        wp_localize_script('yooadmin-comments', 'yooadmComments', [
            'ajaxUrl'         => admin_url('admin-ajax.php'),
            'nonce'           => wp_create_nonce('yooadmin_comments'),
            'listUrl'         => admin_url('admin.php?page=yooadmin-comments'),
            'commentsEnabled' => $this->is_site_comments_enabled(),
            'totalComments'   => (int) get_comments(['count' => true, 'status' => 'all']),
            'screenOptions'   => [
                'perPage' => $per_page,
                'view'    => $this->get_view_mode(),
                'columns' => array_map(
                    static function ($key) use ($hidden) {
                        return [
                            'id'      => $key,
                            'label'   => '',
                            'visible' => !in_array($key, $hidden, true),
                        ];
                    },
                    array_keys($this->get_column_labels())
                ),
            ],
            'columnLabels'     => $this->get_column_labels(),
            'canManageOptions' => current_user_can('manage_options'),
            'i18n'             => $this->get_i18n_strings(),
        ]);
    }

    /**
     * @return array<string, string>
     */
    private function get_i18n_strings(): array
    {
        return [
            'deleteConfirm'        => __('Are you sure you want to delete this comment permanently?', 'yooadmin'),
            'selected'             => __('selected', 'yooadmin'),
            'success'              => __('Operation completed successfully.', 'yooadmin'),
            'error'                => __('An error occurred. Please try again.', 'yooadmin'),
            'showStatistics'       => __('Show Statistics', 'yooadmin'),
            'hideStatistics'       => __('Hide Statistics', 'yooadmin'),
            'screenOptions'        => __('Screen Options', 'yooadmin'),
            'apply'                => __('Apply', 'yooadmin'),
            'cancel'               => __('Cancel', 'yooadmin'),
            'close'                => __('Close', 'yooadmin'),
            'thisComment'          => __('this comment', 'yooadmin'),
            'emptyTitle'           => __('No comments found', 'yooadmin'),
            'emptyHint'            => __('Try adjusting your search or filter criteria.', 'yooadmin'),
            'commentsClosed'       => __('Comments are closed.', 'yooadmin'),
            'columns'              => __('Columns', 'yooadmin'),
            'pagination'           => __('Pagination', 'yooadmin'),
            'itemsPerPage'         => __('Number of items per page', 'yooadmin'),
            'viewMode'             => __('View mode', 'yooadmin'),
            'viewList'             => __('Compact view', 'yooadmin'),
            'viewExcerpt'          => __('Extended view', 'yooadmin'),
            'moderationTitle'      => __('Discussion', 'yooadmin'),
            'commentsStatusLabel'  => __('Site comments', 'yooadmin'),
            'commentsStatusOn'     => __('Enabled', 'yooadmin'),
            'commentsStatusOff'    => __('Disabled', 'yooadmin'),
            'commentsEnabled'      => __('Allow comments on the site', 'yooadmin'),
            'commentsEnabledHint'  => __('Matches Settings → Discussion: new posts accept comments. Turning off also closes comments on existing content.', 'yooadmin'),
            'commentsDisabledNote' => __('Comments are closed site-wide. Existing posts will not accept new comments.', 'yooadmin'),
            'commentsEnabledOn'    => __('Comments enabled. Existing posts can accept comments again.', 'yooadmin'),
            'commentsDisabledOn'   => __('Comments disabled and closed on existing posts.', 'yooadmin'),
            'lsoEyebrow'           => __('Display', 'yooadmin'),
            'lsoDesc'              => __('Choose which columns and layout options appear on this screen. Changes are saved when you apply.', 'yooadmin'),
            'lsoHint'              => __('Column, pagination, and view settings apply to this page only.', 'yooadmin'),
            'deleteAll'            => __('Delete all comments', 'yooadmin'),
            'deleteAllTitle'       => __('Delete all comments?', 'yooadmin'),
            'deleteAllMessage'     => __('This permanently deletes every comment on this site. This cannot be undone.', 'yooadmin'),
            'deleteAllConfirm'     => __('Delete all', 'yooadmin'),
            'deleteAllEmpty'       => __('There are no comments to delete.', 'yooadmin'),
            'approve'              => __('Approve', 'yooadmin'),
            'unapprove'            => __('Unapprove', 'yooadmin'),
            'spam'                 => __('Spam', 'yooadmin'),
            'trash'                => __('Trash', 'yooadmin'),
            'restore'              => __('Restore', 'yooadmin'),
            'delete'               => __('Delete Permanently', 'yooadmin'),
            'reply'                => __('Reply', 'yooadmin'),
            'quickEdit'            => __('Quick Edit', 'yooadmin'),
            'edit'                 => __('Edit', 'yooadmin'),
            'editCommentTitle'     => __('Edit Comment', 'yooadmin'),
            'statusApproved'       => __('Approved', 'yooadmin'),
            'statusPending'        => __('Pending', 'yooadmin'),
            'statusSpam'           => __('Spam', 'yooadmin'),
            'statusLabel'          => __('Status', 'yooadmin'),
            'bulkActions'          => __('Bulk actions', 'yooadmin'),
            'applyBulk'            => __('Apply', 'yooadmin'),
            'noComments'           => __('No comments found.', 'yooadmin'),
            'searchPlaceholder'    => __('Search comments...', 'yooadmin'),
            'approveTitle'         => __('Approve comment?', 'yooadmin'),
            'unapproveTitle'       => __('Unapprove comment?', 'yooadmin'),
            'spamTitle'            => __('Mark as spam?', 'yooadmin'),
            'trashTitle'           => __('Move to trash?', 'yooadmin'),
            'restoreTitle'         => __('Restore comment?', 'yooadmin'),
            'deleteTitle'          => __('Delete permanently?', 'yooadmin'),
            'saved'                => __('Settings saved.', 'yooadmin'),
            'commentApproved'      => __('Comment approved.', 'yooadmin'),
            'commentUnapproved'    => __('Comment unapproved.', 'yooadmin'),
            'commentSpammed'       => __('Comment marked as spam.', 'yooadmin'),
            'commentTrashed'       => __('Comment moved to trash.', 'yooadmin'),
            'commentRestored'      => __('Comment restored.', 'yooadmin'),
            'commentDeleted'       => __('Comment deleted.', 'yooadmin'),
            'commentUpdated'       => __('Comment updated.', 'yooadmin'),
            'commentReplied'       => __('Reply added.', 'yooadmin'),
            /* translators: %d: number of comments */
            'bulkDone'             => __('%d comments updated.', 'yooadmin'),
        ];
    }

    public function maybe_redirect()
    {
        global $pagenow;

        if ($pagenow !== 'edit-comments.php') {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page check for redirect.
        if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'yooadmin-comments') {
            return;
        }

        if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return;
        }

        if (!$this->is_comments_redirect_enabled()) {
            return;
        }

        $redirect = admin_url('admin.php?page=yooadmin-comments');
        $params   = ['comment_status', 's', 'paged', 'comment_type'];
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Preserving read-only GET filters for redirect.
        foreach ($params as $param) {
            if (!empty($_GET[$param])) {
                $redirect = add_query_arg($param, sanitize_text_field(wp_unslash($_GET[$param])), $redirect);
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        wp_safe_redirect($redirect);
        exit;
    }

    /**
     * @return int
     */
    private function get_per_page(): int
    {
        $per_page = (int) get_user_option('edit_comments_per_page');
        if ($per_page < 5) {
            $per_page = 20;
        }
        return min(200, $per_page);
    }

    /**
     * @return string
     */
    private function get_view_mode(): string
    {
        $mode = get_user_option('yooadmin_comments_view_mode');
        return ($mode === 'excerpt') ? 'excerpt' : 'list';
    }

    /**
     * @return array<int, string>
     */
    private function get_hidden_columns(): array
    {
        $hidden = get_user_meta(get_current_user_id(), 'manageedit-commentscolumnshidden', true);
        return is_array($hidden) ? array_map('strval', $hidden) : [];
    }

    /**
     * @param string $url_status
     * @return string
     */
    private function map_url_status_to_query(string $url_status): string
    {
        switch ($url_status) {
            case 'moderated':
                return 'hold';
            case 'approved':
                return 'approve';
            case 'spam':
                return 'spam';
            case 'trash':
                return 'trash';
            default:
                return 'all';
        }
    }

    /**
     * @return array<string, int>
     */
    private function get_counts(): array
    {
        $counts = wp_count_comments();
        return [
            'all'       => (int) $counts->total_comments,
            'moderated' => (int) $counts->moderated,
            'approved'  => (int) $counts->approved,
            'spam'      => (int) $counts->spam,
            'trash'     => (int) $counts->trash,
        ];
    }

    /**
     * @param string $url_status
     * @param string $search
     * @param int    $per_page
     * @param int    $paged
     * @return array{comments: array<int, WP_Comment>, total: int, total_pages: int}
     */
    private function query_comments(string $url_status, string $search, int $per_page, int $paged): array
    {
        $status = $this->map_url_status_to_query($url_status);

        $args = [
            'status'  => $status,
            'orderby' => 'comment_date_gmt',
            'order'   => 'DESC',
            'number'  => $per_page,
            'offset'  => ($paged - 1) * $per_page,
            'type'    => 'comment',
        ];

        if ($search !== '') {
            $args['search'] = $search;
        }

        $comments = get_comments($args);
        if (!is_array($comments)) {
            $comments = [];
        }

        $count_args = $args;
        unset($count_args['number'], $count_args['offset']);
        $total = (int) get_comments(array_merge($count_args, ['count' => true]));
        $total_pages = $per_page > 0 ? (int) ceil($total / $per_page) : 1;

        return [
            'comments'    => $comments,
            'total'       => $total,
            'total_pages' => max(1, $total_pages),
        ];
    }

    /**
     * @param array<int, WP_Comment> $comments
     * @return array<int, array{root: WP_Comment, replies: array<int, WP_Comment>}>
     */
    private function organize_comments_into_threads(array $comments): array
    {
        $by_id = [];
        foreach ($comments as $comment) {
            if ($comment instanceof WP_Comment) {
                $by_id[(int) $comment->comment_ID] = $comment;
            }
        }

        $children = [];
        foreach ($by_id as $comment) {
            $parent_id = (int) $comment->comment_parent;
            if ($parent_id > 0 && isset($by_id[$parent_id])) {
                $children[$parent_id][] = $comment;
            }
        }

        $threads = [];
        foreach ($by_id as $comment) {
            $parent_id = (int) $comment->comment_parent;
            if ($parent_id > 0 && isset($by_id[$parent_id])) {
                continue;
            }

            $threads[] = [
                'root'    => $comment,
                'replies' => $this->collect_thread_replies($by_id, (int) $comment->comment_ID),
            ];
        }

        return $threads;
    }

    /**
     * @param array<int, WP_Comment> $by_id
     * @param int                    $root_id
     * @return array<int, WP_Comment>
     */
    private function collect_thread_replies(array $by_id, int $root_id): array
    {
        $by_parent = [];
        foreach ($by_id as $comment) {
            $parent_id = (int) $comment->comment_parent;
            if (!isset($by_parent[$parent_id])) {
                $by_parent[$parent_id] = [];
            }
            $by_parent[$parent_id][] = $comment;
        }

        $replies = [];
        $queue   = [$root_id];

        while (!empty($queue)) {
            $parent_id = (int) array_shift($queue);
            foreach ($by_parent[$parent_id] ?? [] as $child) {
                $replies[] = $child;
                $queue[]   = (int) $child->comment_ID;
            }
        }

        usort(
            $replies,
            static function (WP_Comment $a, WP_Comment $b): int {
                return strcmp($a->comment_date_gmt, $b->comment_date_gmt);
            }
        );

        return $replies;
    }

    /**
     * @param WP_Comment $comment
     */
    private function render_comment_avatar(WP_Comment $comment): void
    {
        $avatar = get_avatar(
            $comment,
            80,
            'mm',
            '',
            [
                'class'    => 'yoo-chat-avatar__img',
                'loading'  => 'lazy',
                'decoding' => 'async',
            ]
        );

        if ($avatar) {
            echo '<span class="yoo-chat-avatar yoo-chat-avatar--gravatar" aria-hidden="true">' . wp_kses_post($avatar) . '</span>';
            return;
        }

        echo '<span class="yoo-chat-avatar yoo-chat-avatar--initials" aria-hidden="true">';
        echo esc_html($this->get_author_initials($comment));
        echo '</span>';
    }

    /**
     * @param WP_Comment $comment
     */
    private function render_comment_contact_meta(WP_Comment $comment): void
    {
        $parts = [];

        if (!empty($comment->comment_author_email)) {
            $parts[] = sprintf(
                '<a class="yoo-chat-contact__link" href="mailto:%1$s">%2$s</a>',
                esc_attr($comment->comment_author_email),
                esc_html($comment->comment_author_email)
            );
        }

        if (!empty($comment->comment_author_url)) {
            $url   = esc_url($comment->comment_author_url);
            $host  = wp_parse_url($comment->comment_author_url, PHP_URL_HOST);
            $label = $host ?: $comment->comment_author_url;
            $parts[] = sprintf(
                '<a class="yoo-chat-contact__link" href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
                $url,
                esc_html((string) $label)
            );
        }

        if (current_user_can('moderate_comments') && !empty($comment->comment_author_IP)) {
            $parts[] = sprintf(
                '<span class="yoo-chat-contact__ip" title="%1$s">%2$s</span>',
                esc_attr__('IP address', 'yooadmin'),
                esc_html($comment->comment_author_IP)
            );
        }

        if (empty($parts)) {
            return;
        }

        echo '<div class="yoo-chat-msg__contact">';
        echo wp_kses_post(implode('<span class="yoo-chat-contact__sep" aria-hidden="true">·</span>', $parts));
        echo '</div>';
    }

    /**
     * @param WP_Comment $comment
     */
    private function get_author_initials(WP_Comment $comment): string
    {
        $name = trim((string) $comment->comment_author);
        if ($name === '') {
            return 'A';
        }

        $parts = preg_split('/\s+/u', $name) ?: [];
        $initials = '';
        foreach (array_slice($parts, 0, 2) as $part) {
            if ($part !== '') {
                $initials .= mb_strtoupper(mb_substr($part, 0, 1));
            }
        }

        return $initials !== '' ? $initials : 'A';
    }

    /**
     * @param WP_Comment $comment
     * @param string     $status
     * @param string     $edit_url
     * @param string     $view_mode
     * @param bool       $is_root
     * @param int        $depth
     */
    private function render_chat_message(
        WP_Comment $comment,
        string $status,
        string $edit_url,
        string $view_mode,
        bool $is_root = false,
        int $depth = 0
    ): void {
        $comment_id  = (int) $comment->comment_ID;
        $author_name = $comment->comment_author ?: __('Anonymous', 'yooadmin');
        $submitted   = get_comment_date(get_option('date_format') . ' ' . get_option('time_format'), $comment);
        $classes     = ['yoo-chat-msg'];

        if ($is_root) {
            $classes[] = 'yoo-chat-msg--root';
        } else {
            $classes[] = 'yoo-chat-msg--reply';
        }

        if ($this->is_comment_pending_status($status)) {
            $classes[] = 'is-pending';
        }

        ?>
        <article
            id="<?php echo esc_attr('comment-' . $comment_id); ?>"
            class="<?php echo esc_attr(implode(' ', $classes)); ?>"
            data-comment-id="<?php echo esc_attr((string) $comment_id); ?>"
            data-depth="<?php echo esc_attr((string) $depth); ?>"
        >
            <div class="yoo-chat-msg__body">
                <header class="yoo-chat-msg__head">
                    <div class="yoo-chat-msg__meta">
                        <strong class="yoo-chat-msg__author" data-col="author">
                            <?php
                            if ($comment->comment_author_email) {
                                printf(
                                    '<a href="mailto:%1$s">%2$s</a>',
                                    esc_attr($comment->comment_author_email),
                                    esc_html($author_name)
                                );
                            } else {
                                echo esc_html($author_name);
                            }
                            ?>
                        </strong>
                        <time class="yoo-chat-msg__time" data-col="date" datetime="<?php echo esc_attr(get_comment_date('c', $comment)); ?>"><?php echo esc_html($submitted); ?></time>
                        <?php if ($this->is_comment_pending_status($status)) : ?>
                        <span class="yoo-chat-msg__badge"><?php esc_html_e('Pending', 'yooadmin'); ?></span>
                        <?php endif; ?>
                        <?php $this->render_comment_contact_meta($comment); ?>
                    </div>
                    <div class="row-actions yoo-chat-msg__actions">
                        <?php $this->render_row_actions($comment, $status, $edit_url); ?>
                    </div>
                </header>
                <div class="yoo-chat-msg__bubble-row">
                    <div class="yoo-chat-msg__aside">
                        <?php if (!$is_root) : ?>
                        <label class="yoo-chat-msg__select" for="comment-table-<?php echo esc_attr((string) $comment_id); ?>">
                            <input type="checkbox" class="yoo-comment-checkbox yoo-checkbox yoo-chat-msg__checkbox" value="<?php echo esc_attr((string) $comment_id); ?>" id="comment-table-<?php echo esc_attr((string) $comment_id); ?>">
                            <span class="screen-reader-text"><?php esc_html_e('Select', 'yooadmin'); ?></span>
                        </label>
                        <?php endif; ?>
                        <?php $this->render_comment_avatar($comment); ?>
                    </div>
                    <div class="yoo-chat-bubble">
                        <?php echo $view_mode === 'excerpt' ? wp_kses_post(wpautop($comment->comment_content)) : wp_kses_post($comment->comment_content); ?>
                    </div>
                </div>
                <?php $this->render_comment_inline_data($comment); ?>
            </div>
        </article>
        <?php
    }

    /**
     * @param WP_Comment           $root
     * @param array<int, WP_Comment> $replies
     * @param string               $url_status
     * @param array<int, string>   $hidden
     * @param string               $view_mode
     */
    private function render_comment_thread_row(
        WP_Comment $root,
        array $replies,
        string $url_status = '',
        array $hidden = [],
        string $view_mode = 'list'
    ): void {
        $comment_id = (int) $root->comment_ID;
        $approved   = $this->get_comment_moderation_status($root);
        $post       = get_post((int) $root->comment_post_ID);
        $post_title = $post ? get_the_title($post) : __('(post deleted)', 'yooadmin');
        $edit_url   = admin_url('comment.php?action=editcomment&c=' . $comment_id);
        $submitted  = get_comment_date(get_option('date_format') . ' ' . get_option('time_format'), $root);

        $card_classes = ['yoo-comment-card', 'yoo-comment-row', 'yoo-chat-thread'];
        if ($this->is_comment_pending_status($approved)) {
            $card_classes[] = 'unapproved';
            $card_classes[] = 'is-pending';
        }

        ?>
        <article
            class="<?php echo esc_attr(implode(' ', $card_classes)); ?>"
            data-comment-id="<?php echo esc_attr((string) $comment_id); ?>"
            data-status="<?php echo esc_attr($approved); ?>"
            role="listitem"
        >
            <header class="yoo-comment-card__header">
                <label class="yoo-comment-card__select" for="comment-table-<?php echo esc_attr((string) $comment_id); ?>">
                    <input type="checkbox" class="yoo-comment-checkbox yoo-checkbox" value="<?php echo esc_attr((string) $comment_id); ?>" id="comment-table-<?php echo esc_attr((string) $comment_id); ?>">
                    <span class="screen-reader-text"><?php esc_html_e('Select', 'yooadmin'); ?></span>
                </label>

                <div class="yoo-comment-card__meta" data-col="response">
                    <span class="dashicons dashicons-admin-links" aria-hidden="true"></span>
                    <span class="yoo-comment-card__meta-label"><?php esc_html_e('In response to', 'yooadmin'); ?></span>
                    <?php if ($post) : ?>
                    <a class="yoo-comment-card__post-link" href="<?php echo esc_url(get_permalink($post)); ?>"><?php echo esc_html($post_title); ?></a>
                    <?php else : ?>
                    <span class="yoo-comment-card__post-link"><?php echo esc_html($post_title); ?></span>
                    <?php endif; ?>
                </div>
            </header>

            <div class="yoo-chat-thread" data-col="comment">
                <?php $this->render_chat_message($root, $approved, $edit_url, $view_mode, true, 0); ?>
                <?php if (!empty($replies)) : ?>
                <div class="yoo-chat-thread__replies">
                    <?php
                    foreach ($replies as $reply) {
                        $reply_status = $this->get_comment_moderation_status($reply);
                        $reply_edit   = admin_url('comment.php?action=editcomment&c=' . (int) $reply->comment_ID);
                        $depth        = 1;
                        $parent_id    = (int) $reply->comment_parent;
                        if ($parent_id !== $comment_id) {
                            $depth = 2;
                        }
                        $this->render_chat_message($reply, $reply_status, $reply_edit, $view_mode, false, $depth);
                    }
                    ?>
                </div>
                <?php endif; ?>
            </div>

            <div class="yoo-comment-card__reply-host" aria-live="polite"></div>
        </article>
        <?php
    }

    /**
     * @param WP_Comment $comment
     * @param string     $url_status
     * @param array<int, string> $hidden
     * @param string     $view_mode
     */
    public function render_comment_row($comment, string $url_status = '', array $hidden = [], string $view_mode = 'list'): void
    {
        if (!$comment instanceof WP_Comment) {
            return;
        }

        if (empty($hidden)) {
            $hidden = $this->get_hidden_columns();
        }
        if ($view_mode === '') {
            $view_mode = $this->get_view_mode();
        }

        $comment_id = (int) $comment->comment_ID;
        $approved   = $this->get_comment_moderation_status($comment);
        $post       = get_post((int) $comment->comment_post_ID);
        $post_title = $post ? get_the_title($post) : __('(post deleted)', 'yooadmin');
        $edit_url = admin_url('comment.php?action=editcomment&c=' . $comment_id);

        $row_classes = ['yoo-comment-row'];
        if ($this->is_comment_pending_status($approved)) {
            $row_classes[] = 'unapproved';
            $row_classes[] = 'is-pending';
        }

        $author_name = $comment->comment_author ?: __('Anonymous', 'yooadmin');
        if ($comment->comment_author_email) {
            $author_name = sprintf(
                '<a href="mailto:%1$s">%2$s</a>',
                esc_attr($comment->comment_author_email),
                esc_html($author_name)
            );
        } else {
            $author_name = esc_html($author_name);
        }

        ?>
        <tr id="<?php echo esc_attr('comment-' . $comment_id); ?>" class="<?php echo esc_attr(implode(' ', $row_classes)); ?>" data-comment-id="<?php echo esc_attr((string) $comment_id); ?>" data-status="<?php echo esc_attr($approved); ?>">
            <th scope="row" class="check-column">
                <input type="checkbox" class="yoo-comment-checkbox yoo-checkbox" value="<?php echo esc_attr((string) $comment_id); ?>" id="comment-table-<?php echo esc_attr((string) $comment_id); ?>">
                <label for="comment-table-<?php echo esc_attr((string) $comment_id); ?>" class="screen-reader-text"><?php esc_html_e('Select', 'yooadmin'); ?></label>
            </th>
            <?php if (!in_array('author', $hidden, true)) : ?>
            <td class="author column-author" data-col="author" data-colname="<?php esc_attr_e('Author', 'yooadmin'); ?>">
                <strong><?php echo wp_kses_post($author_name); ?></strong>
                <?php if ($comment->comment_author_url) : ?>
                <div class="yoo-comment-meta"><a href="<?php echo esc_url($comment->comment_author_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(wp_parse_url($comment->comment_author_url, PHP_URL_HOST) ?: $comment->comment_author_url); ?></a></div>
                <?php endif; ?>
            </td>
            <?php endif; ?>
            <?php if (!in_array('comment', $hidden, true)) : ?>
            <td class="comment column-comment column-primary" data-col="comment" data-colname="<?php esc_attr_e('Comment', 'yooadmin'); ?>">
                <div class="yoo-comment-content"><?php echo $view_mode === 'excerpt' ? wp_kses_post(wpautop($comment->comment_content)) : wp_kses_post($comment->comment_content); ?></div>
                <div class="row-actions">
                    <?php $this->render_row_actions($comment, $approved, $edit_url); ?>
                </div>
                <?php $this->render_comment_inline_data($comment); ?>
            </td>
            <?php endif; ?>
            <?php if (!in_array('response', $hidden, true)) : ?>
            <td class="response column-response" data-col="response" data-colname="<?php esc_attr_e('In response to', 'yooadmin'); ?>">
                <?php if ($post) : ?>
                <a href="<?php echo esc_url(get_permalink($post)); ?>"><?php echo esc_html($post_title); ?></a>
                <?php else : ?>
                <span><?php echo esc_html($post_title); ?></span>
                <?php endif; ?>
            </td>
            <?php endif; ?>
            <?php if (!in_array('date', $hidden, true)) : ?>
            <td class="date column-date" data-col="date" data-colname="<?php esc_attr_e('Submitted on', 'yooadmin'); ?>">
                <?php
                $submitted = get_comment_date(get_option('date_format') . ' ' . get_option('time_format'), $comment);
                echo esc_html($submitted);
                ?>
            </td>
            <?php endif; ?>
        </tr>
        <?php
    }

    /**
     * Hidden row payload used by WordPress inline reply / quick edit.
     *
     * @param WP_Comment $comment
     */
    private function render_comment_inline_data(WP_Comment $comment): void
    {
        /** This filter is documented in wp-admin/includes/comment.php */
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core comment inline-edit filter.
        $comment_content = apply_filters('comment_edit_pre', $comment->comment_content);
        ?>
        <div id="inline-<?php echo (int) $comment->comment_ID; ?>" class="hidden">
            <textarea class="comment" rows="1" cols="1"><?php echo esc_textarea($comment_content); ?></textarea>
            <div class="author-email"><?php echo esc_html($comment->comment_author_email); ?></div>
            <div class="author"><?php echo esc_html($comment->comment_author); ?></div>
            <div class="author-url"><?php echo esc_url($comment->comment_author_url); ?></div>
            <div class="comment_status"><?php echo esc_html((string) $comment->comment_approved); ?></div>
        </div>
        <?php
    }

    /**
     * @param WP_Comment $comment
     * @param string     $status
     * @param string     $edit_url
     */
    private function render_row_actions($comment, string $status, string $edit_url): void
    {
        $id = (int) $comment->comment_ID;

        if ($status === 'trash') {
            $this->render_action_link('untrash', $id, 'undo', __('Restore', 'yooadmin'));
            echo ' | ';
            $this->render_action_link('delete', $id, 'trash', __('Delete Permanently', 'yooadmin'));
            return;
        }

        if ($status === 'spam') {
            $this->render_action_link('unspam', $id, 'yes', __('Not Spam', 'yooadmin'));
            echo ' | ';
            $this->render_action_link('delete', $id, 'trash', __('Delete Permanently', 'yooadmin'));
            return;
        }

        if ($status === 'pending') {
            $this->render_action_link('approve', $id, 'yes-alt', __('Approve', 'yooadmin'));
        } elseif ($status === 'approved') {
            $this->render_action_link('unapprove', $id, 'hidden', __('Unapprove', 'yooadmin'));
        }
        echo ' | ';
        printf(
            '<span class="reply"><button type="button" data-comment-id="%1$d" data-post-id="%2$d" data-action="replyto" class="vim-r comment-inline yoo-action-link reply" aria-expanded="false" aria-label="%3$s"><span class="dashicons dashicons-admin-comments" style="font-size:16px;width:16px;height:16px;vertical-align:middle;margin-right:4px;"></span>%4$s</button> | </span>',
            (int) $id,
            (int) $comment->comment_post_ID,
            esc_attr__('Reply to this comment', 'yooadmin'),
            esc_html__('Reply', 'yooadmin')
        );
        printf(
            '<span class="edit"><button type="button" data-comment-id="%1$d" data-post-id="%2$d" data-action="edit" class="vim-q comment-inline yoo-action-link edit" aria-expanded="false" aria-label="%3$s"><span class="dashicons dashicons-edit" style="font-size:16px;width:16px;height:16px;vertical-align:middle;margin-right:4px;"></span>%4$s</button> | </span>',
            (int) $id,
            (int) $comment->comment_post_ID,
            esc_attr__('Edit this comment', 'yooadmin'),
            esc_html__('Edit', 'yooadmin')
        );
        $this->render_action_link('spam', $id, 'flag', __('Spam', 'yooadmin'));
        echo ' | ';
        $this->render_action_link('trash', $id, 'trash', __('Trash', 'yooadmin'));
    }

    /**
     * @param string $action
     * @param int    $comment_id
     * @param string $icon
     * @param string $label
     */
    private function render_action_link(string $action, int $comment_id, string $icon, string $label): void
    {
        printf(
            '<span class="%1$s"><a href="#" class="yoo-action-link %1$s" data-action="%1$s" data-comment-id="%2$d"><span class="dashicons dashicons-%3$s" style="font-size:16px;width:16px;height:16px;vertical-align:middle;margin-right:4px;"></span>%4$s</a></span>',
            esc_attr($action),
            (int) $comment_id,
            esc_attr($icon),
            esc_html($label)
        );
    }

    /**
     * @param array<int, WP_Comment> $comments
     * @param string                 $url_status
     */
    public function render_table_body(array $comments, string $url_status = ''): void
    {
        $hidden    = $this->get_hidden_columns();
        $view_mode = $this->get_view_mode();

        if (empty($comments)) {
            echo '<div class="yoo-comments-empty-state">';
            echo '<div class="yoo-posts-empty">';
            echo '<div class="yoo-empty-illustration"><span class="dashicons dashicons-admin-comments"></span></div>';
            echo '<h2>' . esc_html__('No comments found', 'yooadmin') . '</h2>';
            echo '<p>' . esc_html__('Try adjusting your search or filter criteria.', 'yooadmin') . '</p>';
            echo '</div></div>';
            return;
        }

        foreach ($this->organize_comments_into_threads($comments) as $thread) {
            $this->render_comment_thread_row($thread['root'], $thread['replies'], $url_status, $hidden, $view_mode);
        }
    }

    /**
     * @param int    $current
     * @param int    $total_pages
     * @param string $url_status
     * @param string $search
     */
    public function render_pagination(int $current, int $total_pages, string $url_status = '', string $search = ''): void
    {
        if ($total_pages <= 1) {
            return;
        }

        $base_url = admin_url('admin.php?page=yooadmin-comments');
        if ($url_status !== '') {
            $base_url = add_query_arg('comment_status', urlencode($url_status), $base_url);
        }
        if ($search !== '') {
            $base_url = add_query_arg('s', urlencode($search), $base_url);
        }

        echo '<nav class="yoo-posts-pagination yoo-comments-pagination" aria-label="' . esc_attr__('Comments pagination', 'yooadmin') . '">';

        if ($current > 1) {
            printf(
                '<button type="button" class="yoo-pagination-prev" data-paged="%1$d">%2$s</button>',
                (int) ($current - 1),
                esc_html__('Previous', 'yooadmin')
            );
        }

        for ($i = 1; $i <= $total_pages; $i++) {
            if ($i === $current) {
                printf('<span class="yoo-pagination-current" aria-current="page">%d</span>', (int) $i);
            } else {
                printf(
                    '<button type="button" class="yoo-pagination-link" data-paged="%1$d">%2$d</button>',
                    (int) $i,
                    (int) $i
                );
            }
        }

        if ($current < $total_pages) {
            printf(
                '<button type="button" class="yoo-pagination-next" data-paged="%1$d">%2$s</button>',
                (int) ($current + 1),
                esc_html__('Next', 'yooadmin')
            );
        }

        echo '</nav>';
    }

    public function render_page()
    {
        if (!current_user_can('moderate_comments')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'yooadmin'));
        }

        if (!$this->is_comments_redirect_enabled()) {
            $this->redirect_to_native_comments_page();
        }

        if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            $this->redirect_to_native_comments_page();
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters from URL.
        $paged        = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        $url_status   = isset($_GET['comment_status']) ? sanitize_key(wp_unslash($_GET['comment_status'])) : '';
        $search       = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        $per_page = $this->get_per_page();
        $result   = $this->query_comments($url_status, $search, $per_page, $paged);
        $counts   = $this->get_counts();

        $list_url             = admin_url('admin.php?page=yooadmin-comments');
        $hidden               = $this->get_hidden_columns();
        $view_mode            = $this->get_view_mode();
        $comments_enabled     = $this->is_site_comments_enabled();
        $can_manage_options   = current_user_can('manage_options');

        $template = dirname(__DIR__, 2) . '/templates/yoopixel/admin/pages/comments/index.php';
        if (file_exists($template)) {
            include $template;
        }
    }

    public function handle_ajax_action()
    {
        check_ajax_referer('yooadmin_comments', 'nonce');

        if (!current_user_can('moderate_comments')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $comment_id = isset($_POST['comment_id']) ? absint($_POST['comment_id']) : 0;
        $action     = isset($_POST['comment_action']) ? sanitize_key(wp_unslash($_POST['comment_action'])) : '';

        if (!$comment_id || !$action) {
            wp_send_json_error(['message' => __('Invalid request.', 'yooadmin')]);
        }

        $comment = get_comment($comment_id);
        if (!$comment) {
            wp_send_json_error(['message' => __('Comment not found.', 'yooadmin')]);
        }

        $ok = $this->apply_comment_action($comment_id, $action);
        if (!$ok) {
            wp_send_json_error(['message' => __('Action failed.', 'yooadmin')]);
        }

        wp_send_json_success([
            'comment_id' => $comment_id,
            'action'     => $action,
            'counts'     => $this->get_counts(),
        ]);
    }

    public function handle_bulk_action()
    {
        check_ajax_referer('yooadmin_comments', 'nonce');

        if (!current_user_can('moderate_comments')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $action = isset($_POST['bulk_action']) ? sanitize_key(wp_unslash($_POST['bulk_action'])) : '';
        $ids    = isset($_POST['comment_ids']) ? array_map('absint', (array) wp_unslash($_POST['comment_ids'])) : [];

        if (!$action || empty($ids)) {
            wp_send_json_error(['message' => __('Invalid request.', 'yooadmin')]);
        }

        $updated = 0;
        foreach ($ids as $id) {
            if ($id && $this->apply_comment_action($id, $action)) {
                ++$updated;
            }
        }

        wp_send_json_success([
            'updated' => $updated,
            'counts'  => $this->get_counts(),
        ]);
    }

    /**
     * @param int    $comment_id
     * @param string $action
     * @return bool
     */
    private function apply_comment_action(int $comment_id, string $action): bool
    {
        switch ($action) {
            case 'approve':
                return (bool) wp_set_comment_status($comment_id, 'approve');
            case 'unapprove':
                return (bool) wp_set_comment_status($comment_id, 'hold');
            case 'spam':
                return (bool) wp_set_comment_status($comment_id, 'spam');
            case 'unspam':
                return (bool) wp_set_comment_status($comment_id, 'approve');
            case 'trash':
                return (bool) wp_set_comment_status($comment_id, 'trash');
            case 'untrash':
                return (bool) wp_untrash_comment($comment_id);
            case 'delete':
                return (bool) wp_delete_comment($comment_id, true);
            case 'delete_all':
                return (bool) wp_delete_comment($comment_id, true);
            default:
                return false;
        }
    }

    public function ajax_filter_comments()
    {
        check_ajax_referer('yooadmin_comments', 'nonce');

        if (!current_user_can('moderate_comments')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $per_page   = isset($_POST['per_page']) ? max(5, min(200, absint($_POST['per_page']))) : $this->get_per_page();
        $paged      = isset($_POST['paged']) ? max(1, absint($_POST['paged'])) : 1;
        $url_status = isset($_POST['comment_status']) ? sanitize_key(wp_unslash($_POST['comment_status'])) : '';
        $search     = isset($_POST['s']) ? sanitize_text_field(wp_unslash($_POST['s'])) : '';

        $result = $this->query_comments($url_status, $search, $per_page, $paged);

        ob_start();
        $this->render_table_body($result['comments'], $url_status);
        $table_html = ob_get_clean();

        ob_start();
        $this->render_pagination($paged, $result['total_pages'], $url_status, $search);
        $pagination_html = ob_get_clean();

        wp_send_json_success([
            'table_html'       => $table_html,
            'pagination_html'  => $pagination_html,
            'total'            => $result['total'],
            'paged'            => $paged,
            'total_pages'      => $result['total_pages'],
            'counts'           => $this->get_counts(),
        ]);
    }

    public function ajax_get_comment_counts()
    {
        check_ajax_referer('yooadmin_comments', 'nonce');

        if (!current_user_can('moderate_comments')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        wp_send_json_success(['counts' => $this->get_counts()]);
    }

    public function ajax_delete_batch()
    {
        check_ajax_referer('yooadmin_comments', 'nonce');

        if (!current_user_can('moderate_comments')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')], 403);
        }

        $batch = 40;
        $ids   = get_comments([
            'fields'  => 'ids',
            'number'  => $batch,
            'status'  => 'all',
            'orderby' => 'none',
        ]);

        $deleted = 0;
        foreach ($ids as $comment_id) {
            if (wp_delete_comment((int) $comment_id, true)) {
                ++$deleted;
            }
        }

        $remaining = (int) get_comments(['count' => true, 'status' => 'all']);

        wp_send_json_success([
            'deleted'   => $deleted,
            'remaining' => $remaining,
            'done'      => $remaining === 0,
            'counts'    => $this->get_counts(),
        ]);
    }

    /**
     * Post types excluded from bulk comment open/close.
     *
     * @return string[]
     */
    private function get_comment_bulk_excluded_post_types(): array
    {
        return [
            'attachment',
            'revision',
            'nav_menu_item',
            'custom_css',
            'customize_changeset',
            'oembed_cache',
            'user_request',
            'wp_block',
        ];
    }

    /**
     * @return array{enabled: bool, closed_posts: int, opened_posts: int}
     */
    private function set_site_comments_enabled(bool $enabled): array
    {
        update_option('default_comment_status', $enabled ? 'open' : 'closed');
        update_option('default_ping_status', $enabled ? 'open' : 'closed');

        global $wpdb;

        $excluded_types = array_map('sanitize_key', $this->get_comment_bulk_excluded_post_types());
        $closed_posts   = 0;
        $opened_posts   = 0;
        $target_status  = $enabled ? 'closed' : 'open';
        $new_status     = $enabled ? 'open' : 'closed';

        if (count($excluded_types) !== 8) {
            return [
                'enabled'      => $enabled,
                'closed_posts' => 0,
                'opened_posts' => 0,
            ];
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- {$wpdb->posts} is the validated core posts table.
        $post_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE comment_status = %s AND post_type NOT IN (%s, %s, %s, %s, %s, %s, %s, %s)",
                $target_status,
                $excluded_types[0],
                $excluded_types[1],
                $excluded_types[2],
                $excluded_types[3],
                $excluded_types[4],
                $excluded_types[5],
                $excluded_types[6],
                $excluded_types[7]
            )
        );

        if (!empty($post_ids)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- {$wpdb->posts} is the validated core posts table.
            $updated = (int) $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$wpdb->posts} SET comment_status = %s, ping_status = %s WHERE comment_status = %s AND post_type NOT IN (%s, %s, %s, %s, %s, %s, %s, %s)",
                    $new_status,
                    $new_status,
                    $target_status,
                    $excluded_types[0],
                    $excluded_types[1],
                    $excluded_types[2],
                    $excluded_types[3],
                    $excluded_types[4],
                    $excluded_types[5],
                    $excluded_types[6],
                    $excluded_types[7]
                )
            );

            if ($enabled) {
                $opened_posts = $updated;
            } else {
                $closed_posts = $updated;
            }

            foreach ($post_ids as $post_id) {
                clean_post_cache((int) $post_id);
            }

            wp_cache_set('last_changed', microtime(), 'posts');
        }

        return [
            'enabled'      => $enabled,
            'closed_posts' => $closed_posts,
            'opened_posts' => $opened_posts,
        ];
    }

    public function ajax_set_comments_enabled()
    {
        check_ajax_referer('yooadmin_comments', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')], 403);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Verified above; boolean flag from AJAX payload.
        $enabled = isset($_POST['enabled']) && (string) wp_unslash($_POST['enabled']) === '1';
        $result  = $this->set_site_comments_enabled($enabled);

        wp_send_json_success($result);
    }

    public function ajax_save_screen_options()
    {
        check_ajax_referer('yooadmin_comments', 'nonce');

        if (!current_user_can('moderate_comments')) {
            wp_send_json_error(['message' => __('Insufficient permissions.', 'yooadmin')]);
        }

        $user_id = get_current_user_id();

        if (isset($_POST['per_page'])) {
            $per_page = max(5, min(200, absint($_POST['per_page'])));
            update_user_option($user_id, 'edit_comments_per_page', $per_page);
        }

        if (isset($_POST['view'])) {
            $view = sanitize_key(wp_unslash($_POST['view']));
            $view = ($view === 'excerpt') ? 'excerpt' : 'list';
            update_user_option($user_id, 'yooadmin_comments_view_mode', $view);
        }

        if (isset($_POST['columns']) && is_array($_POST['columns'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per item below.
            $columns = wp_unslash($_POST['columns']);
            $hidden  = [];
            foreach (array_keys($this->get_column_labels()) as $col) {
                $visible = !empty($columns[$col]) && (string) $columns[$col] === '1';
                if (!$visible) {
                    $hidden[] = $col;
                }
            }
            update_user_meta($user_id, 'manageedit-commentscolumnshidden', $hidden);
        }

        $comments_result = null;
        if (isset($_POST['comments_enabled']) && current_user_can('manage_options')) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Boolean flag from AJAX payload; nonce verified above.
            $enabled         = (string) wp_unslash($_POST['comments_enabled']) === '1';
            $comments_result = $this->set_site_comments_enabled($enabled);
        }

        wp_send_json_success([
            'per_page'          => $this->get_per_page(),
            'view'              => $this->get_view_mode(),
            'hidden'            => $this->get_hidden_columns(),
            'comments_enabled'  => $comments_result ? $comments_result['enabled'] : $this->is_site_comments_enabled(),
            'closed_posts'      => $comments_result ? $comments_result['closed_posts'] : 0,
            'opened_posts'      => $comments_result ? $comments_result['opened_posts'] : 0,
        ]);
    }
}

add_action(
    'init',
    static function () {
        YOOAdmin_Comments_Page::get_instance();
    }
);
