<?php
/**
 * YOOAdmin — Network Users pages (list, add, edit).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

class YOOAdmin_Network_Users_Page
{
    private static ?self $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        if (!is_multisite()) {
            return;
        }

        add_action('admin_init', [$this, 'set_page_title']);
        add_action('network_admin_menu', [$this, 'register_network_pages'], 9);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function set_page_title(): void
    {
        $td = yooadmin_network_users_text_domain();

        if (function_exists('yooadmin_network_users_list_is_screen') && yooadmin_network_users_list_is_screen()) {
            global $title;
            $title = __('Users', 'yooadmin');
            return;
        }

        if (function_exists('yooadmin_network_user_new_is_screen') && yooadmin_network_user_new_is_screen()) {
            global $title;
            $title = __('Add User', 'yooadmin');
            return;
        }

        if (function_exists('yooadmin_network_user_edit_is_screen') && yooadmin_network_user_edit_is_screen()) {
            global $title;
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $user_id = isset($_GET['user_id']) ? absint($_GET['user_id']) : 0;
            $user    = $user_id > 0 ? get_userdata($user_id) : false;
            $title   = $user
                ? sprintf(
                    /* translators: %s: user display name */
                    __('Edit User %s', 'yooadmin'),
                    $user->display_name ?: $user->user_login
                )
                : __('Edit User', 'yooadmin');
        }
    }

    public function register_network_pages(): void
    {
        if (!function_exists('yooadmin_network_users_should_use') || !yooadmin_network_users_should_use()) {
            return;
        }

        $td = yooadmin_network_users_text_domain();

        add_submenu_page(
            'users.php',
            __('Users', 'yooadmin'),
            __('Users', 'yooadmin'),
            'manage_network_users',
            yooadmin_network_users_list_page_slug(),
            [$this, 'render_list_page']
        );

        add_submenu_page(
            'users.php',
            __('Add User', 'yooadmin'),
            __('Add User', 'yooadmin'),
            'create_users',
            yooadmin_network_user_new_page_slug(),
            [$this, 'render_add_page']
        );

        add_submenu_page(
            '',
            __('Edit User', 'yooadmin'),
            __('Edit User', 'yooadmin'),
            'edit_users',
            yooadmin_network_user_edit_page_slug(),
            [$this, 'render_edit_page']
        );

        remove_submenu_page('users.php', 'users.php');
        remove_submenu_page('users.php', 'user-new.php');
    }

    public function enqueue_assets(): void
    {
        if (!function_exists('yooadmin_network_users_is_screen') || !yooadmin_network_users_is_screen()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir  = plugin_dir_path($base_file);
        $base_url  = plugin_dir_url($base_file);

        if (function_exists('yooadmin_enqueue_list_screen_ui_assets')) {
            yooadmin_enqueue_list_screen_ui_assets();
        }

        $style_rel = 'assets/css/admin/users-page.css';
        $style_abs = $base_dir . $style_rel;
        $users_css_deps = ['yooadmin-shell'];
        if (wp_style_is('yooadmin-list-screens-ui', 'registered') || wp_style_is('yooadmin-list-screens-ui', 'enqueued')) {
            $users_css_deps[] = 'yooadmin-list-screens-ui';
        }
        if (is_readable($style_abs)) {
            wp_enqueue_style(
                'yooadmin-users',
                $base_url . $style_rel,
                $users_css_deps,
                (string) filemtime($style_abs)
            );
        }

        if (function_exists('yooadmin_network_user_edit_is_screen') && yooadmin_network_user_edit_is_screen()) {
            wp_enqueue_script('password-strength-meter');
            wp_enqueue_script('zxcvbn-async');

            $profile_script_rel = 'assets/js/admin/user-profile.js';
            $profile_script_abs = $base_dir . $profile_script_rel;
            if (is_readable($profile_script_abs)) {
                wp_enqueue_script(
                    'yooadmin-user-profile',
                    $base_url . $profile_script_rel,
                    ['jquery'],
                    (string) filemtime($profile_script_abs),
                    true
                );
            }

            return;
        }

        if (function_exists('yooadmin_network_users_list_is_screen') && yooadmin_network_users_list_is_screen()) {
            $script_rel = 'assets/js/admin/users-page.js';
            $script_abs = $base_dir . $script_rel;
            if (is_readable($script_abs)) {
                wp_enqueue_script(
                    'yooadmin-users',
                    $base_url . $script_rel,
                    ['jquery'],
                    (string) filemtime($script_abs),
                    true
                );
                wp_localize_script(
                    'yooadmin-users',
                    'yooadmUsers',
                    [
                        'ajaxUrl'  => admin_url('admin-ajax.php'),
                        'nonce'    => wp_create_nonce('yooadmin_users'),
                        'listUrl'  => yooadmin_network_users_list_url(),
                        'pageSlug' => yooadmin_network_users_list_page_slug(),
                        'isNetwork'=> true,
                    ]
                );
            }
        }
    }

    public function render_list_page(): void
    {
        $td = yooadmin_network_users_text_domain();

        if (!current_user_can('manage_network_users')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        if (!yooadmin_network_users_should_use()) {
            wp_safe_redirect(network_admin_url('users.php'));
            exit;
        }

        global $title;
        $title = __('Users', 'yooadmin');

        $data         = yooadmin_network_users_fetch();
        $users        = $data['users'];
        $total        = $data['total'];
        $total_pages  = $data['total_pages'];
        $paged        = $data['paged'];
        $search       = $data['search'];
        $role         = $data['role'];
        $stats        = yooadmin_network_users_stats();
        $flash        = yooadmin_network_users_flash_message();
        $list_url     = yooadmin_network_users_list_url();
        $new_url      = yooadmin_network_user_new_url();
        $bulk_action  = network_admin_url('users.php?action=allusers');
        $can_add      = current_user_can('create_users');

        $template = defined('YOOADMIN_PANEL_DIR')
            ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-users/index.php'
            : '';

        if ($template && is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Users', 'yooadmin') . '</h1></div>';
    }

    public function render_add_page(): void
    {
        $td = yooadmin_network_users_text_domain();

        if (!current_user_can('create_users')) {
            wp_die(esc_html__('Sorry, you are not allowed to add users to this network.', 'yooadmin'));
        }

        if (!yooadmin_network_users_should_use()) {
            wp_safe_redirect(network_admin_url('user-new.php'));
            exit;
        }

        global $title;
        $title = __('Add User', 'yooadmin');

        $errors  = null;
        $result  = yooadmin_network_user_new_process_submission();
        $errors  = $result['errors'] ?? null;
        $message = yooadmin_network_user_new_success_message();

        $list_url = yooadmin_network_users_list_url();
        $form_url = yooadmin_network_user_new_url(['action' => 'add-user']);

        $template = defined('YOOADMIN_PANEL_DIR')
            ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-users/create.php'
            : '';

        if ($template && is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Add User', 'yooadmin') . '</h1></div>';
    }

    public function render_edit_page(): void
    {
        $td = yooadmin_network_users_text_domain();

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $user_id = isset($_GET['user_id']) ? absint($_GET['user_id']) : 0;
        if ($user_id <= 0 || !get_userdata($user_id)) {
            wp_die(esc_html__('The requested user could not be found.', 'yooadmin'));
        }

        if (!current_user_can('edit_user', $user_id)) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        if (!yooadmin_network_users_should_use()) {
            wp_safe_redirect(network_admin_url('user-edit.php?user_id=' . $user_id));
            exit;
        }

        if (
            is_multisite()
            && !current_user_can('manage_network_users')
            && $user_id !== get_current_user_id()
            && !apply_filters('enable_edit_any_user_configuration', true) // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
        ) {
            wp_die(esc_html__('Sorry, you are not allowed to edit this user.', 'yooadmin'));
        }

        global $title;
        $user = get_userdata($user_id);

        $process = yooadmin_network_user_edit_process_submission($user_id);
        $errors  = $process['errors'];
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $updated_flag = isset($_GET['updated']) ? sanitize_key(wp_unslash((string) $_GET['updated'])) : '';
        $updated      = in_array($updated_flag, ['1', 'true'], true);

        $list_url          = yooadmin_network_users_list_url();
        $form_url          = yooadmin_network_user_edit_url($user_id);
        $show_super_admin  = current_user_can('manage_network_options');
        $is_super_admin    = is_super_admin($user_id);
        $show_role_field   = false;
        $roles             = [];
        $created           = false;

        $template = defined('YOOADMIN_PANEL_DIR')
            ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-users/edit.php'
            : '';

        if ($template && is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Edit User', 'yooadmin') . '</h1></div>';
    }
}

YOOAdmin_Network_Users_Page::get_instance();
