<?php
/**
 * YOOAdmin — global confirm modal (replaces window.confirm on supported screens).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Confirm modal styles + script.
 */
function yooadmin_enqueue_yp_admin_confirm_assets(): void {
    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $base_dir  = plugin_dir_path($base_file);
    $base_url  = plugin_dir_url($base_file);

    $css_rel = 'assets/css/admin/yp-admin-confirm.css';
    $css_abs = $base_dir . $css_rel;
    if (is_readable($css_abs)) {
        $deps = wp_style_is('yooadmin-core', 'registered') || wp_style_is('yooadmin-core', 'enqueued')
            ? ['yooadmin-core']
            : [];
        wp_enqueue_style(
            'yooadmin-yp-admin-confirm',
            $base_url . $css_rel,
            $deps,
            (string) filemtime($css_abs)
        );
    }

    $js_rel = 'assets/js/admin/yp-admin-confirm.js';
    $js_abs = $base_dir . $js_rel;
    if (!is_readable($js_abs)) {
        return;
    }

    $deps = ['jquery'];
    if (wp_script_is('yooadmin-yp-admin-toast', 'registered') || wp_script_is('yooadmin-yp-admin-toast', 'enqueued')) {
        $deps[] = 'yooadmin-yp-admin-toast';
    }

    wp_enqueue_script(
        'yooadmin-yp-admin-confirm',
        $base_url . $js_rel,
        $deps,
        (string) filemtime($js_abs),
        true
    );

    wp_localize_script(
        'yooadmin-yp-admin-confirm',
        'yooadminConfirmI18n',
        [
            'title'   => __('Are you sure?', 'yooadmin'),
            'confirm' => __('OK', 'yooadmin'),
            'cancel'  => __('Cancel', 'yooadmin'),
            'delete'  => __('Delete', 'yooadmin'),
        ]
    );
}
