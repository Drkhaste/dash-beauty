<?php
/**
 * Network Setup — snippet data for YOOAdmin page.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_setup_text_domain')) {
    function yooadmin_network_setup_text_domain(): string
    {
        return function_exists('yooadmin_multisite_text_domain')
            ? yooadmin_multisite_text_domain()
            : 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_setup_allow_multisite')) {
    function yooadmin_network_setup_allow_multisite(): bool
    {
        return defined('WP_ALLOW_MULTISITE') && WP_ALLOW_MULTISITE;
    }
}

if (!function_exists('yooadmin_network_setup_is_enabled')) {
    function yooadmin_network_setup_is_enabled(): bool
    {
        return is_multisite() && defined('MULTISITE') && MULTISITE;
    }
}

if (!function_exists('yooadmin_network_setup_get_context')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_network_setup_get_context(): array
    {
        global $wpdb;

        $hostname     = function_exists('get_clean_basedomain') ? get_clean_basedomain() : wp_parse_url(home_url(), PHP_URL_HOST);
        $slashed_home = trailingslashit(get_option('home'));
        $base         = wp_parse_url($slashed_home, PHP_URL_PATH);
        $base         = is_string($base) ? $base : '/';

        $subdomain_install = false;
        if (is_multisite()) {
            $subdomain_install = is_subdomain_install();
        } elseif (isset($wpdb->sitemeta)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $subdomain_install = (bool) $wpdb->get_var(
                "SELECT meta_value FROM {$wpdb->sitemeta} WHERE site_id = 1 AND meta_key = 'subdomain_install'"
            );
        }

        $document_root_input = isset($_SERVER['DOCUMENT_ROOT'])
            ? sanitize_text_field(wp_unslash((string) $_SERVER['DOCUMENT_ROOT']))
            : '';
        $document_root_fix   = str_replace(
            '\\',
            '/',
            (string) realpath($document_root_input !== '' ? $document_root_input : ABSPATH)
        );
        $abspath_fix       = str_replace('\\', '/', ABSPATH);
        $home_path         = str_starts_with($abspath_fix, $document_root_fix)
            ? $document_root_fix . $base
            : (function_exists('get_home_path') ? get_home_path() : ABSPATH);

        $location_of_wp_config = $abspath_fix;
        if (!file_exists(ABSPATH . 'wp-config.php') && file_exists(dirname(ABSPATH) . '/wp-config.php')) {
            $location_of_wp_config = trailingslashit(dirname($abspath_fix));
        }
        $location_of_wp_config = trailingslashit($location_of_wp_config);

        $wp_config_rules = "define( 'MULTISITE', true );\n"
            . 'define( \'SUBDOMAIN_INSTALL\', ' . ($subdomain_install ? 'true' : 'false') . " );\n"
            . "define( 'DOMAIN_CURRENT_SITE', '" . $hostname . "' );\n"
            . "define( 'PATH_CURRENT_SITE', '" . $base . "' );\n"
            . "define( 'SITE_ID_CURRENT_SITE', 1 );\n"
            . "define( 'BLOG_ID_CURRENT_SITE', 1 );";

        $rewrite_base      = '';
        $wp_siteurl_subdir = preg_replace('#^' . preg_quote($home_path, '#') . '#', '', $abspath_fix);
        if (is_string($wp_siteurl_subdir) && $wp_siteurl_subdir !== '') {
            $rewrite_base = ltrim(trailingslashit($wp_siteurl_subdir), '/');
        }

        $subdir_match          = $subdomain_install ? '' : '([_0-9a-zA-Z-]+/)?';
        $subdir_replacement_01 = $subdomain_install ? '' : '$1';
        $subdir_replacement_12 = $subdomain_install ? '$1' : '$2';

        $htaccess_rules = "# BEGIN WordPress\n"
            . "RewriteEngine On\n"
            . "RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]\n"
            . 'RewriteBase /' . $rewrite_base . "\n"
            . 'RewriteRule ^index\.php$ - [L]' . "\n\n"
            . "# add a trailing slash to /wp-admin\n"
            . 'RewriteRule ^' . ltrim($rewrite_base, '/') . 'wp-admin$ '
            . $subdir_replacement_01 . 'wp-admin/ [R=301,L]' . "\n\n"
            . 'RewriteCond %{REQUEST_FILENAME} -f [OR]' . "\n"
            . "RewriteCond %{REQUEST_FILENAME} -d\n"
            . "RewriteRule ^ - [L]\n"
            . 'RewriteRule ^' . ltrim($rewrite_base, '/') . $subdir_match . 'wp-(content|admin|includes)/.* '
            . $subdir_replacement_12 . " [L]\n"
            . 'RewriteRule ^' . ltrim($rewrite_base, '/') . $subdir_match . '(.*\.php)$ '
            . $subdir_replacement_12 . " [L]\n"
            . "RewriteRule . index.php [L]\n"
            . "# END WordPress";

        return [
            'allow_multisite'       => yooadmin_network_setup_allow_multisite(),
            'multisite_enabled'     => yooadmin_network_setup_is_enabled(),
            'subdomain_install'     => $subdomain_install,
            'hostname'              => (string) $hostname,
            'base_path'             => (string) $base,
            'wp_config_path'        => $location_of_wp_config,
            'wp_config_rules'       => $wp_config_rules,
            'htaccess_rules'        => $htaccess_rules,
            'classic_url'           => function_exists('yooadmin_network_setup_classic_url')
                ? yooadmin_network_setup_classic_url()
                : network_admin_url('setup.php?yooadmin_no_redirect=1'),
        ];
    }
}

if (!function_exists('yooadmin_network_setup_tabs')) {
    /**
     * @return array<string, array{label: string, icon: string, desc: string}>
     */
    function yooadmin_network_setup_tabs(): array
    {
        return [
            'overview'  => [
                'label' => __('Overview', 'yooadmin'),
                'icon'  => 'dashicons-info-outline',
                /* translators: Tab intro on the network setup page. */
                'desc'  => __('Learn what to enable in wp-config.php before creating a multisite network.', 'yooadmin'),
            ],
            'wp-config' => [
                'label' => __('wp-config.php', 'yooadmin'),
                'icon'  => 'dashicons-editor-code',
                /* translators: Tab intro on the network setup page. */
                'desc'  => __('Copy the multisite constants and paste them above the stop-editing line.', 'yooadmin'),
            ],
            'htaccess'  => [
                'label' => __('.htaccess', 'yooadmin'),
                'icon'  => 'dashicons-media-code',
                /* translators: Tab intro on the network setup page. */
                'desc'  => __('Replace WordPress rewrite rules in your .htaccess file on Apache hosts.', 'yooadmin'),
            ],
            'help'      => [
                'label' => __('Help', 'yooadmin'),
                'icon'  => 'dashicons-sos',
                /* translators: Tab intro on the network setup page. */
                'desc'  => __('Quick checklist and links if something does not work after enabling the network.', 'yooadmin'),
            ],
        ];
    }
}
