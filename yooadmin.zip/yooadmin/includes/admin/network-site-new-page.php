<?php
defined('ABSPATH') || exit;

class YOOAdmin_Network_Site_New_Page
{
    private static $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        if (!is_multisite()) {
            return;
        }

        add_action('admin_init', [$this, 'set_page_title']);
        add_action('network_admin_menu', [$this, 'register_network_page'], 9);
    }

    public function set_page_title(): void
    {
        if (!function_exists('yooadmin_network_site_new_is_screen') || !yooadmin_network_site_new_is_screen()) {
            return;
        }

        global $title;
        $title = __('Add Site', 'yooadmin');
    }

    public function register_network_page(): void
    {
        if (!function_exists('yooadmin_network_site_new_should_use') || !yooadmin_network_site_new_should_use()) {
            return;
        }

        add_submenu_page(
            'sites.php',
            __('Add Site', 'yooadmin'),
            __('Add Site', 'yooadmin'),
            'create_sites',
            yooadmin_network_site_new_page_slug(),
            [$this, 'render_page']
        );
    }

    public function render_page(): void
    {
        if (!current_user_can('create_sites')) {
            wp_die(esc_html__('Sorry, you are not allowed to add sites to this network.', 'yooadmin'));
        }

        if (!function_exists('yooadmin_network_site_new_should_use') || !yooadmin_network_site_new_should_use()) {
            wp_safe_redirect(network_admin_url('site-new.php'));
            exit;
        }

        global $title;
        $title = __('Add Site', 'yooadmin');

        wp_enqueue_script('user-suggest');

        if (!function_exists('wp_get_available_translations')) {
            require_once ABSPATH . 'wp-admin/includes/translation-install.php';
        }

        $template = defined('YOOADMIN_PANEL_DIR')
            ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-site-new/index.php'
            : '';

        if ($template && is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Add Site', 'yooadmin') . '</h1></div>';
    }
}

YOOAdmin_Network_Site_New_Page::get_instance();
