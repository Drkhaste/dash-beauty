<?php
/**
 * Global list-screen UI (custom select, buttons, checkboxes) for YOOAdmin posts/pages.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Enqueue yp-ui-select, yp-yoo-btn, and list-screen checkbox/bulk-bar styles.
 */
function yooadmin_enqueue_list_screen_ui_assets(): void {
    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $base_dir  = plugin_dir_path($base_file);
    $base_url  = plugin_dir_url($base_file);

    $core_deps = [];
    if (wp_style_is('yooadmin-core', 'registered') || wp_style_is('yooadmin-core', 'enqueued')) {
        $core_deps[] = 'yooadmin-core';
    }

    $buttons_css = $base_dir . 'assets/css/admin/yp-yoo-buttons.css';
    if (is_readable($buttons_css)) {
        wp_enqueue_style(
            'yooadmin-yoo-buttons',
            $base_url . 'assets/css/admin/yp-yoo-buttons.css',
            $core_deps,
            (string) filemtime($buttons_css)
        );
    }

    $yp_sel_css = $base_dir . 'assets/css/admin/yp-archive-delay-select.css';
    if (is_readable($yp_sel_css)) {
        wp_enqueue_style(
            'yooadmin-yp-ui-select',
            $base_url . 'assets/css/admin/yp-archive-delay-select.css',
            $core_deps,
            (string) filemtime($yp_sel_css)
        );
    }

    $yp_sel_js = $base_dir . 'assets/js/admin/yp-archive-delay-select.js';
    if (is_readable($yp_sel_js)) {
        wp_enqueue_script(
            'yooadmin-yp-ui-select',
            $base_url . 'assets/js/admin/yp-archive-delay-select.js',
            [],
            (string) filemtime($yp_sel_js),
            true
        );
    }

    $search_fields_css = $base_dir . 'assets/css/admin/yp-admin-search-fields.css';
    if (is_readable($search_fields_css)) {
        wp_enqueue_style(
            'yooadmin-admin-search-fields',
            $base_url . 'assets/css/admin/yp-admin-search-fields.css',
            $core_deps,
            (string) filemtime($search_fields_css)
        );
    }

    $ui_css_deps = $core_deps;
    if (wp_style_is('yooadmin-yoo-buttons', 'registered') || wp_style_is('yooadmin-yoo-buttons', 'enqueued')) {
        $ui_css_deps[] = 'yooadmin-yoo-buttons';
    }
    if (wp_style_is('yooadmin-yp-ui-select', 'registered') || wp_style_is('yooadmin-yp-ui-select', 'enqueued')) {
        $ui_css_deps[] = 'yooadmin-yp-ui-select';
    }

    $list_ui_css = $base_dir . 'assets/css/admin/list-screens-ui.css';
    if (is_readable($list_ui_css)) {
        wp_enqueue_style(
            'yooadmin-list-screens-ui',
            $base_url . 'assets/css/admin/list-screens-ui.css',
            $ui_css_deps,
            (string) filemtime($list_ui_css)
        );
    }
}
