<?php
defined('ABSPATH') || exit;

class YOOAdmin_Network_Sites_Page
{
    private static $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        if (!is_multisite()) {
            return;
        }

        add_action('admin_init', [$this, 'set_page_title']);
        add_action('network_admin_menu', [$this, 'register_network_page'], 9);
    }

    public function set_page_title(): void
    {
        if (!function_exists('yooadmin_network_sites_is_screen') || !yooadmin_network_sites_is_screen()) {
            return;
        }

        global $title;
        $title = __('Sites', 'yooadmin');
    }

    public function register_network_page(): void
    {
        if (!function_exists('yooadmin_network_sites_should_use') || !yooadmin_network_sites_should_use()) {
            return;
        }

        add_submenu_page(
            'sites.php',
            __('Sites', 'yooadmin'),
            __('All Sites', 'yooadmin'),
            'manage_sites',
            yooadmin_network_sites_page_slug(),
            [$this, 'render_page']
        );
    }

    public function render_page(): void
    {
        if (!current_user_can('manage_sites')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        if (!function_exists('yooadmin_network_sites_should_use') || !yooadmin_network_sites_should_use()) {
            wp_safe_redirect(network_admin_url('sites.php'));
            exit;
        }

        global $title;
        $title = __('Sites', 'yooadmin');

        $flash       = function_exists('yooadmin_network_sites_flash_message')
            ? yooadmin_network_sites_flash_message()
            : ['', ''];
        $bulk_action = function_exists('yooadmin_network_sites_bulk_action_url')
            ? yooadmin_network_sites_bulk_action_url()
            : network_admin_url('sites.php?action=allblogs');
        $bulk_actions = function_exists('yooadmin_network_sites_bulk_actions')
            ? yooadmin_network_sites_bulk_actions()
            : [];
        $list_url = function_exists('yooadmin_network_sites_url')
            ? yooadmin_network_sites_url()
            : network_admin_url('sites.php');

        $template = defined('YOOADMIN_PANEL_DIR')
            ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-sites/index.php'
            : '';

        if ($template && is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Sites', 'yooadmin') . '</h1></div>';
    }
}

YOOAdmin_Network_Sites_Page::get_instance();
