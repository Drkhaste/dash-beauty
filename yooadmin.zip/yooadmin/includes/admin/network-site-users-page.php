<?php
defined('ABSPATH') || exit;

class YOOAdmin_Network_Site_Users_Page
{
    private static $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        if (!is_multisite()) {
            return;
        }

        add_action('admin_init', [$this, 'set_page_title']);
        add_action('network_admin_menu', [$this, 'register_network_page'], 9);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function set_page_title(): void
    {
        if (!function_exists('yooadmin_network_site_users_is_screen') || !yooadmin_network_site_users_is_screen()) {
            return;
        }

        global $title;
        $blog_id = yooadmin_network_site_editor_current_id();
        $td      = yooadmin_network_site_editor_text_domain();

        if ($blog_id > 0) {
            /* translators: %s: site name. */
            $title = sprintf(__('Edit Site: %s', 'yooadmin'), yooadmin_network_site_editor_site_name($blog_id));
            return;
        }

        $title = __('Edit Site', 'yooadmin');
    }

    public function register_network_page(): void
    {
        $td = yooadmin_network_site_editor_text_domain();

        add_submenu_page(
            null,
            __('Edit Site', 'yooadmin'),
            __('Edit Site', 'yooadmin'),
            'manage_sites',
            yooadmin_network_site_users_page_slug(),
            [$this, 'render_page']
        );
    }

    public function enqueue_assets(): void
    {
        if (!yooadmin_network_site_users_is_screen()) {
            return;
        }

        if (!wp_is_large_network('users') && apply_filters('show_network_site_users_add_existing_form', true)) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
            wp_enqueue_script('user-suggest');
        }
    }

    public function render_page(): void
    {
        $td = yooadmin_network_site_editor_text_domain();

        if (!current_user_can('manage_sites')) {
            wp_die(esc_html__('Sorry, you are not allowed to edit this site.', 'yooadmin'));
        }

        if (!yooadmin_network_site_users_should_use()) {
            $blog_id = yooadmin_network_site_editor_current_id();
            wp_safe_redirect($blog_id > 0 ? network_admin_url('site-users.php?id=' . $blog_id) : network_admin_url('sites.php'));
            exit;
        }

        $blog_id = yooadmin_network_site_editor_current_id();
        if ($blog_id <= 0 || !yooadmin_network_site_editor_get_site($blog_id)) {
            wp_die(esc_html__('The requested site does not exist.', 'yooadmin'));
        }

        $template = defined('YOOADMIN_PANEL_DIR')
            ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-site-users/index.php'
            : '';

        if ($template && is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Edit Site', 'yooadmin') . '</h1></div>';
    }
}

YOOAdmin_Network_Site_Users_Page::get_instance();
