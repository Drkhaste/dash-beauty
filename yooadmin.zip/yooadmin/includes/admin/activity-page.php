<?php
/**
 * YOOAdmin - Activity log page.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

class YOOAdmin_Activity_Page {

    private static ?YOOAdmin_Activity_Page $instance = null;

    public static function get_instance(): YOOAdmin_Activity_Page {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', [ $this, 'register_page' ]);
        add_action('admin_enqueue_scripts', [ $this, 'enqueue_assets' ]);
    }

    public function register_page(): void {
        $parent = function_exists('yooadmin_dashboard_slug') ? yooadmin_dashboard_slug() : 'yooadmin-dashboard';
        $cap = function_exists('yooadmin_activity_page_capability') ? yooadmin_activity_page_capability() : 'read';

        add_submenu_page(
            $parent,
            __('Activity', 'yooadmin'),
            __('Activity', 'yooadmin'),
            $cap,
            'yooadmin-activity',
            [ $this, 'render_page' ]
        );
    }

    public function enqueue_assets(string $hook): void {
        unset($hook);
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page detection.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== 'yooadmin-activity') {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir  = plugin_dir_path($base_file);
        $base_url  = plugin_dir_url($base_file);

        $style_rel = 'assets/css/admin/activity-page.css';
        $style_abs = $base_dir . $style_rel;
        if (file_exists($style_abs)) {
            wp_enqueue_style('yooadmin-activity-page', $base_url . $style_rel, [ 'yooadmin-shell' ], filemtime($style_abs));
        }

        $script_rel = 'assets/js/admin/activity-page.js';
        $script_abs = $base_dir . $script_rel;
        if (file_exists($script_abs)) {
            wp_enqueue_script('yooadmin-activity-page', $base_url . $script_rel, [ 'jquery' ], filemtime($script_abs), true);
            wp_localize_script(
                'yooadmin-activity-page',
                'yooadmActivity',
                [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce'   => wp_create_nonce('yooadmin_activity'),
                    'i18n'    => [
                        'loading'  => __('Loading activity…', 'yooadmin'),
                        'empty'    => __('No activity found for these filters.', 'yooadmin'),
                        'loadMore' => __('Load more', 'yooadmin'),
                        'allLoaded'=> __('All activity loaded.', 'yooadmin'),
                        'error'    => __('Could not load activity. Please try again.', 'yooadmin'),
                        'searchPlaceholder' => __('Search activity…', 'yooadmin'),
                        'allAdmins'       => __('All admins', 'yooadmin'),
                        'clearFilter'     => __('Clear filter', 'yooadmin'),
                        /* translators: %s: number of events */
                        'eventsCount'     => __('%s events', 'yooadmin'),
                    ],
                ]
            );
        }
    }

    public function render_page(): void {
        if (!current_user_can(yooadmin_activity_page_capability())) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        global $title;
        $title = __('Activity', 'yooadmin');

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters from URL.
        $category = isset($_GET['category']) ? sanitize_key(wp_unslash($_GET['category'])) : 'all';
        $range = isset($_GET['range']) ? sanitize_key(wp_unslash($_GET['range'])) : '30d';
        $user_id = isset($_GET['user_id']) ? absint(wp_unslash($_GET['user_id'])) : 0;
        $search = isset($_GET['search']) ? sanitize_text_field(wp_unslash($_GET['search'])) : '';
        $paged = isset($_GET['paged']) ? max(1, absint(wp_unslash($_GET['paged']))) : 1;
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        $args = yooadmin_activity_query_args_from_request(
            [
                'category' => $category,
                'range'    => $range,
                'user_id'  => $user_id,
                'search'   => $search,
                'page'     => $paged,
                'per_page' => 20,
            ]
        );

        $rows = yooadmin_activity_storage()->query($args);
        $total = yooadmin_activity_storage()->count($args);
        $per_page = (int) $args['per_page'];
        $total_pages = $per_page > 0 ? (int) ceil($total / $per_page) : 1;

        $activity_items = [];
        foreach ($rows as $row) {
            if (is_array($row)) {
                $activity_items[] = yooadmin_activity_format_row($row);
            }
        }

        $categories = yooadmin_activity_get_categories();
        $time_ranges = yooadmin_activity_get_time_ranges();
        $filter_users = yooadmin_activity_get_filter_users();
        $list_url = admin_url('admin.php?page=yooadmin-activity');

        $tpl = function_exists('yooadmin_base_file')
            ? plugin_dir_path(yooadmin_base_file()) . 'templates/yoopixel/admin/pages/activity/index.php'
            : dirname(__DIR__, 2) . '/templates/yoopixel/admin/pages/activity/index.php';

        if (is_readable($tpl)) {
            include $tpl;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Activity', 'yooadmin') . '</h1><p>' . esc_html__('Template not found.', 'yooadmin') . '</p></div>';
    }
}

YOOAdmin_Activity_Page::get_instance();
