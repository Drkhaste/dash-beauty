<?php
/**
 * Network Upgrade — render helpers for YOOAdmin page.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_upgrade_text_domain')) {
    function yooadmin_network_upgrade_text_domain(): string
    {
        return function_exists('yooadmin_multisite_text_domain')
            ? yooadmin_multisite_text_domain()
            : 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_upgrade_current_action')) {
    function yooadmin_network_upgrade_current_action(): string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing.
        return isset($_GET['action']) ? sanitize_key(wp_unslash((string) $_GET['action'])) : 'show';
    }
}

if (!function_exists('yooadmin_network_upgrade_batch_index')) {
    function yooadmin_network_upgrade_batch_index(): int
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing.
        return isset($_GET['n']) ? max(0, (int) $_GET['n']) : 0;
    }
}

if (!function_exists('yooadmin_network_upgrade_db_version_mismatch')) {
    function yooadmin_network_upgrade_db_version_mismatch(): bool
    {
        global $wp_db_version;

        return (int) get_site_option('wpmu_upgrade_site') !== (int) $wp_db_version;
    }
}

if (!function_exists('yooadmin_network_upgrade_process_batch')) {
    /**
     * @return array{sites: string[], next: int, done: bool}
     */
    function yooadmin_network_upgrade_process_batch(int $offset): array
    {
        global $wp_db_version;

        if ($offset < 5) {
            update_site_option('wpmu_upgrade_site', $wp_db_version);
        }

        $site_ids = get_sites(
            [
                'spam'                   => 0,
                'deleted'                => 0,
                'archived'               => 0,
                'network_id'             => get_current_network_id(),
                'number'                 => 5,
                'offset'                 => $offset,
                'fields'                 => 'ids',
                'order'                  => 'DESC',
                'orderby'                => 'id',
                'update_site_meta_cache' => false,
            ]
        );

        if (!is_array($site_ids) || $site_ids === []) {
            return [
                'sites' => [],
                'next'  => $offset,
                'done'  => true,
            ];
        }

        $processed = [];
        foreach ($site_ids as $site_id) {
            $site_id = (int) $site_id;
            switch_to_blog($site_id);
            $siteurl     = site_url();
            $upgrade_url = admin_url('upgrade.php?step=upgrade_db');
            restore_current_blog();

            // Intentional: mirrors wp-admin/network/upgrade.php loopback requests to each
            // subsite's upgrade.php (local HTTPS often uses self-signed or mismatched certs).
            $response = wp_remote_get(
                $upgrade_url,
                [
                    'timeout'     => 120,
                    'httpversion' => '1.1',
                    'sslverify'   => false,
                ]
            );

            if (is_wp_error($response)) {
                wp_die(
                    sprintf(
                        /* translators: 1: Site URL, 2: Error message. */
                        esc_html__('Warning! Problem updating %1$s. Error: %2$s', 'yooadmin'),
                        esc_url($siteurl),
                        esc_html($response->get_error_message())
                    )
                );
            }

            /** This action is documented in wp-admin/network/upgrade.php */
            // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
            do_action('after_mu_upgrade', $response);
            /** This action is documented in wp-admin/network/upgrade.php */
            // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
            do_action('wpmu_upgrade_site', $site_id);

            $processed[] = $siteurl;
        }

        return [
            'sites' => $processed,
            'next'  => $offset + 5,
            'done'  => false,
        ];
    }
}

if (!function_exists('yooadmin_network_upgrade_tabs')) {
    /**
     * @return array<string, array{label: string, icon: string, desc: string}>
     */
    function yooadmin_network_upgrade_tabs(): array
    {
        return [
            'overview' => [
                'label' => __('Overview', 'yooadmin'),
                'icon'  => 'dashicons-info-outline',
                /* translators: Tab intro on the network upgrade page. */
                'desc'  => __('Run database upgrades across every site after WordPress core has been updated.', 'yooadmin'),
            ],
            'upgrade'  => [
                'label' => __('Upgrade', 'yooadmin'),
                'icon'  => 'dashicons-update',
                /* translators: Tab intro on the network upgrade page. */
                'desc'  => __('Process five sites at a time until the whole network is up to date.', 'yooadmin'),
            ],
            'help'     => [
                'label' => __('Help', 'yooadmin'),
                'icon'  => 'dashicons-sos',
                /* translators: Tab intro on the network upgrade page. */
                'desc'  => __('What to do if a site fails or the upgrade stops midway.', 'yooadmin'),
            ],
        ];
    }
}
