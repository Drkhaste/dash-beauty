<?php
/**
 * YOOUpdate Center — markup helpers (derived from WordPress `wp-admin/update-core.php`).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!defined('YOOADMIN_UC_AUTO_TIP_ID')) {
    define('YOOADMIN_UC_AUTO_TIP_ID', 'yoo-uc-auto-mode-tip');
}

if (!function_exists('yooadmin_uc_reset_floating_tooltips')) {
    function yooadmin_uc_reset_floating_tooltips(): void
    {
        $GLOBALS['yooadmin_uc_floating_tooltips'] = [];
    }
}

if (!function_exists('yooadmin_uc_register_floating_tooltip')) {
    function yooadmin_uc_register_floating_tooltip(string $id, string $inner_html): void
    {
        if (!isset($GLOBALS['yooadmin_uc_floating_tooltips']) || !is_array($GLOBALS['yooadmin_uc_floating_tooltips'])) {
            $GLOBALS['yooadmin_uc_floating_tooltips'] = [];
        }
        $GLOBALS['yooadmin_uc_floating_tooltips'][$id] = $inner_html;
    }
}

if (!function_exists('yooadmin_uc_get_floating_tooltips_html')) {
    function yooadmin_uc_get_floating_tooltips_html(): string
    {
        $tooltips = isset($GLOBALS['yooadmin_uc_floating_tooltips']) && is_array($GLOBALS['yooadmin_uc_floating_tooltips'])
            ? $GLOBALS['yooadmin_uc_floating_tooltips']
            : [];

        if ($tooltips === []) {
            return '';
        }

        ob_start();
        foreach ($tooltips as $id => $inner_html) {
            echo '<span id="' . esc_attr((string) $id) . '" class="yoo-uc-auto-mode-tooltip yoo-uc-auto-mode-tooltip--portaled" role="tooltip">';
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped fragments in caller.
            echo $inner_html;
            echo '</span>';
        }

        return (string) ob_get_clean();
    }
}

if (!function_exists('yooadmin_uc_render_floating_ui')) {
    function yooadmin_uc_render_floating_ui(): void
    {
        static $rendered = false;
        if ($rendered) {
            return;
        }
        $rendered = true;

        echo '<div id="yoo-uc-floating-ui" class="yoo-uc-floating-ui">';
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Inner markup escaped per tooltip line.
        echo yooadmin_uc_get_floating_tooltips_html();
        echo '</div>';
    }
}

if (!function_exists('yooadmin_uc_render_progress_modal')) {
    function yooadmin_uc_render_progress_modal(): void
    {
        static $rendered = false;
        if ($rendered) {
            return;
        }
        $rendered = true;
        ?>
        <div id="yoo-uc-progress-root" class="yoo-uc-progress-root" hidden aria-hidden="true">
            <div class="yoo-uc-progress-backdrop"></div>
            <div class="yoo-uc-progress-modal" role="dialog" aria-modal="true" aria-labelledby="yoo-uc-progress-title">
                <div class="yoo-uc-progress-head">
                    <span id="yoo-uc-progress-spinner" class="yoo-uc-progress-spinner" aria-hidden="true">
                        <span class="dashicons dashicons-update"></span>
                    </span>
                    <h2 id="yoo-uc-progress-title" class="yoo-uc-progress-title"><?php esc_html_e('Working…', 'yooadmin'); ?></h2>
                </div>
                <div class="yoo-uc-progress-bar-outer" aria-hidden="true">
                    <div class="yoo-uc-progress-bar-inner" id="yoo-uc-progress-bar" style="width:0%;"></div>
                </div>
                <div class="yoo-uc-progress-meta">
                    <p class="yoo-uc-progress-step" id="yoo-uc-progress-step"></p>
                    <span class="yoo-uc-progress-pct" id="yoo-uc-progress-pct" aria-hidden="true">0%</span>
                </div>
                <ul class="yoo-uc-progress-log" id="yoo-uc-progress-log" aria-live="polite"></ul>
                <div class="yoo-uc-progress-footer" id="yoo-uc-progress-footer" hidden>
                    <button type="button" class="button button-primary yoo-btn yoo-btn-primary" id="yoo-uc-progress-ok"><?php esc_html_e('OK', 'yooadmin'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }
}

if (!function_exists('yooadmin_uc_is_update_center_screen')) {
    function yooadmin_uc_is_update_center_screen(): bool
    {
        if (!is_admin()) {
            return false;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!isset($_GET['page'])) {
            return false;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = sanitize_key(wp_unslash($_GET['page']));

        return in_array($page, ['yooadmin-update-center', 'yooadmin-network-update-center'], true);
    }
}

if (!function_exists('yooadmin_uc_register_page_overlays')) {
    function yooadmin_uc_register_page_overlays(): void
    {
        if (!yooadmin_uc_is_update_center_screen()) {
            return;
        }

        add_action('admin_footer', 'yooadmin_uc_render_floating_ui', 5);
        add_action('admin_footer', 'yooadmin_uc_render_progress_modal', 5);
    }
}

add_action('admin_init', 'yooadmin_uc_register_page_overlays');

/**
 * Infobox (not `.notice` / not `wp_admin_notice`) so core notice JS does not relocate or hide it.
 *
 * @param string $inner HTML (already escaped where needed).
 * @param string $kind  neutral|warning|success|error
 */
function yooadmin_uc_infobox(string $inner, string $kind = 'neutral'): void
{
    $k = in_array($kind, ['neutral', 'warning', 'success', 'error'], true) ? $kind : 'neutral';
    $notice_class = [
        'neutral' => 'yoo-notice-info',
        'warning' => 'yoo-notice-warning',
        'success' => 'yoo-notice-success',
        'error'   => 'yoo-notice-error',
    ];
    $nc = $notice_class[$k] ?? 'yoo-notice-info';
    $icon = [
        'neutral' => 'info',
        'warning' => 'warning',
        'success' => 'yes-alt',
        'error'   => 'dismiss',
    ];
    $ic = $icon[$k] ?? 'info';
    echo '<div class="yoo-update-notice-bar ' . esc_attr($nc) . ' yoo-uc-infobox" role="status">';
    echo '<span class="yoo-notice-icon"><span class="dashicons dashicons-' . esc_attr($ic) . '" aria-hidden="true"></span></span>';
    echo '<div class="yoo-notice-content">';
    echo $inner; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- callers pass escaped strings or wp_kses_post.
    echo '</div></div>';
}

/**
 * Shown when there are no plugin/theme/translation updates pending.
 *
 * @param string $message Translated message.
 */
function yooadmin_uc_render_no_updates_notice(string $message): void
{
    echo '<div class="yoo-uc-no-updates" role="status">';
    echo '<span class="dashicons dashicons-yes-alt yoo-uc-no-updates__icon" aria-hidden="true"></span>';
    echo '<p class="yoo-uc-no-updates__text">' . esc_html($message) . '</p>';
    echo '</div>';
}

/**
 * Translation updates with a reliable `type` field (core packs from update_core often omit it).
 *
 * @return object[]
 */
function yooadmin_uc_get_translation_updates_with_type(): array
{
    $updates = [];

    foreach (
        [
            'update_core'    => 'core',
            'update_plugins' => 'plugin',
            'update_themes'  => 'theme',
        ] as $transient_name => $default_type
    ) {
        $transient = get_site_transient($transient_name);
        if (!is_object($transient) || empty($transient->translations) || !is_array($transient->translations)) {
            continue;
        }

        foreach ($transient->translations as $translation) {
            if (!is_array($translation) && !is_object($translation)) {
                continue;
            }

            $item = (object) $translation;
            if (empty($item->type)) {
                $item->type = $default_type;
            }
            $updates[] = $item;
        }
    }

    return $updates;
}

/**
 * Pending update counts for hero stats + tab badges.
 *
 * @return array{core:int,plugins:int,themes:int,translations:int}
 */
function yooadmin_uc_get_tab_counts(): array
{
    $out = [
        'core'           => 0,
        'plugins'        => 0,
        'themes'         => 0,
        'translations'   => 0,
    ];

    if (current_user_can('update_core')) {
        $core = get_core_updates();
        $out['core'] = is_array($core) ? count($core) : 0;
    }

    if (current_user_can('update_plugins')) {
        $p = get_plugin_updates();
        $out['plugins'] = is_array($p) ? count($p) : 0;
    }

    if (current_user_can('update_themes')) {
        $t = get_theme_updates();
        $out['themes'] = is_array($t) ? count($t) : 0;
    }

    if (current_user_can('update_languages')) {
        $tr = yooadmin_uc_get_translation_updates_with_type();
        $out['translations'] = count($tr);
    }

    return $out;
}

/**
 * Last checked line + “Check again” (same data as core Updates screen).
 */
function yooadmin_uc_render_last_checked(): void
{
    $last_update_check = false;
    $current = get_site_transient('update_core');
    if ($current && isset($current->last_checked)) {
        $last_update_check = $current->last_checked + (float) get_option('gmt_offset') * HOUR_IN_SECONDS;
    }

    $check_url = function_exists('yooadmin_update_center_admin_url')
        ? add_query_arg('force-check', '1', yooadmin_update_center_admin_url())
        : self_admin_url('update-core.php?force-check=1');

    echo '<p class="yoo-update-center-meta">';
    if ($last_update_check) {
        printf(
            /* translators: 1: Date, 2: Time. */
            esc_html__('Last checked on %1$s at %2$s.', 'yooadmin'),
            esc_html(date_i18n(__('F j, Y', 'yooadmin'), $last_update_check)),
            esc_html(date_i18n(__('g:i a T', 'yooadmin'), $last_update_check))
        );
        echo ' ';
    } else {
        esc_html_e('Update data has not been loaded yet.', 'yooadmin');
        echo ' ';
    }
    echo '<button type="button" class="button-link yoo-uc-check-again">' . esc_html__('Check again.', 'yooadmin') . '</button>';
    echo ' <noscript><a href="' . esc_url($check_url) . '">' . esc_html__('Check again.', 'yooadmin') . '</a></noscript>';
    echo '</p>';
}

/**
 * Whether to show the “Latest Version” chip beside the hero version (stable install, no newer core offer).
 */
function yooadmin_uc_should_show_latest_version_badge(): bool
{
    if (! current_user_can('update_core')) {
        return false;
    }
    $wp_version = get_bloginfo('version');
    $updates    = get_core_updates();
    if (preg_match('/alpha|beta|RC/i', $wp_version)) {
        return false;
    }
    if (isset($updates[0]->version) && version_compare($updates[0]->version, $wp_version, '>')) {
        return false;
    }

    return true;
}

/**
 * Compact “last checked” row for hero aside (clock left of label; one line: Last Check: date time).
 */
function yooadmin_uc_render_last_checked_compact(): void
{
    $last_update_check = false;
    $current           = get_site_transient('update_core');
    if ($current && isset($current->last_checked)) {
        $last_update_check = $current->last_checked + (float) get_option('gmt_offset') * HOUR_IN_SECONDS;
    }

    $title = '';
    if ($last_update_check) {
        $title = sprintf(
            /* translators: 1: Date, 2: Time with timezone. */
            __('Last checked on %1$s at %2$s.', 'yooadmin'),
            date_i18n(__('F j, Y', 'yooadmin'), $last_update_check),
            date_i18n(__('g:i a T', 'yooadmin'), $last_update_check)
        );
    } else {
        /* translators: Shown in tooltip when core update check time is unknown. */
        $title = __('Update data has not been loaded yet.', 'yooadmin');
    }

    echo '<div class="yoo-uc-last-checked-compact" title="' . esc_attr($title) . '">';
    echo '<span class="screen-reader-text">' . esc_html($title) . '</span>';
    echo '<span class="yoo-uc-last-checked-compact__icon" aria-hidden="true"><span class="dashicons dashicons-clock"></span></span>';
    echo '<span class="yoo-uc-last-checked-compact__text">';
    if ($last_update_check) {
        $time_compact = strtoupper(str_replace(' ', '', date_i18n('g:i a', $last_update_check)));
        printf(
            '%s %s %s',
            esc_html__('Last Check:', 'yooadmin'),
            esc_html(date_i18n('M j, Y', $last_update_check)),
            esc_html($time_compact)
        );
    } else {
        echo esc_html__('Last Check:', 'yooadmin') . ' ';
        echo '<span class="yoo-uc-last-checked-compact__text--muted">' . esc_html__('Not checked yet', 'yooadmin') . '</span>';
    }
    echo '</span></div>';
}

/**
 * Computed fields for a core update row (shared by list + header button).
 *
 * @param object $update Core update object.
 * @return array<string, mixed>
 */
function yooadmin_uc_core_update_meta(object $update): array
{
    global $wpdb;

    $wp_version      = get_bloginfo('version');
    $version_string  = sprintf('%s&ndash;%s', $update->current, get_locale());
    if ('en_US' === $update->locale && 'en_US' === get_locale()) {
        $version_string = $update->current;
    } elseif ('en_US' === $update->locale && $update->packages->partial && $wp_version === $update->partial_version) {
        $updates = get_core_updates();
        if ($updates && 1 === count($updates)) {
            $version_string = $update->current;
        }
    } elseif ('en_US' === $update->locale && 'en_US' !== get_locale()) {
        $version_string = sprintf('%s&ndash;%s', $update->current, $update->locale);
    }

    $current = false;
    if (!isset($update->response) || 'latest' === $update->response) {
        $current = true;
    }

    $message      = '';
    $form_action  = self_admin_url('update-core.php?action=do-core-upgrade');
    $php_version  = PHP_VERSION;
    $mysql_version = $wpdb->db_version();
    $show_buttons = true;

    if (preg_match('/-\w+-\d+/', $update->current)) {
        preg_match('/^\d+.\d+/', $update->current, $update_major);
        /* translators: %s: WordPress version. */
        $submit = sprintf(__('Update to latest %s', 'yooadmin'), $update_major[0]);
    } else {
        /* translators: %s: WordPress version. */
        $submit = sprintf(__('Update to version %s', 'yooadmin'), $version_string);
    }

    $manual_upgrade_plain = '';
    $is_manual_compat     = false;

    if ('development' === $update->response) {
        $message = __('You can update to the latest nightly build manually:', 'yooadmin');
    } else {
        if ($current) {
            /* translators: %s: WordPress version. */
            $submit       = sprintf(__('Re-install version %s', 'yooadmin'), $version_string);
            $form_action  = self_admin_url('update-core.php?action=do-core-reinstall');
        } else {
            $php_compat = version_compare($php_version, $update->php_version, '>=');
            if (file_exists(WP_CONTENT_DIR . '/db.php') && empty($wpdb->is_mysql)) {
                $mysql_compat = true;
            } else {
                $mysql_compat = version_compare($mysql_version, $update->mysql_version, '>=');
            }

            $version_url = sprintf(
                /* translators: %s: WordPress version. */
                esc_url(__('https://wordpress.org/documentation/wordpress-version/version-%s/', 'yooadmin')),
                sanitize_title($update->current)
            );

            $php_update_message = '</p><p>' . sprintf(
                /* translators: %s: URL to Update PHP page. */
                __('<a href="%s">Learn more about updating PHP</a>.', 'yooadmin'),
                esc_url(wp_get_update_php_url())
            );

            $annotation = wp_get_update_php_annotation();
            if ($annotation) {
                $php_update_message .= '</p><p><em>' . $annotation . '</em>';
            }

            if (!$mysql_compat && !$php_compat) {
                $message = sprintf(
                    /* translators: 1: URL to WordPress release notes, 2: WordPress version number, 3: Minimum required PHP version number, 4: Minimum required MySQL version number, 5: Current PHP version number, 6: Current MySQL version number. */
                    __('You cannot update because <a href="%1$s">WordPress %2$s</a> requires PHP version %3$s or higher and MySQL version %4$s or higher. You are running PHP version %5$s and MySQL version %6$s.', 'yooadmin'),
                    $version_url,
                    $update->current,
                    $update->php_version,
                    $update->mysql_version,
                    $php_version,
                    $mysql_version
                ) . $php_update_message;
            } elseif (!$php_compat) {
                $message = sprintf(
                    /* translators: 1: URL to WordPress release notes, 2: WordPress version number, 3: Minimum required PHP version number, 4: Current PHP version number. */
                    __('You cannot update because <a href="%1$s">WordPress %2$s</a> requires PHP version %3$s or higher. You are running version %4$s.', 'yooadmin'),
                    $version_url,
                    $update->current,
                    $update->php_version,
                    $php_version
                ) . $php_update_message;
            } elseif (!$mysql_compat) {
                $message = sprintf(
                    /* translators: 1: URL to WordPress release notes, 2: WordPress version number, 3: Minimum required MySQL version number, 4: Current MySQL version number. */
                    __('You cannot update because <a href="%1$s">WordPress %2$s</a> requires MySQL version %3$s or higher. You are running version %4$s.', 'yooadmin'),
                    $version_url,
                    $update->current,
                    $update->mysql_version,
                    $mysql_version
                );
            } else {
                $message = sprintf(
                    /* translators: 1: Installed WordPress version number, 2: URL to WordPress release notes, 3: New WordPress version number, including locale if necessary. */
                    __('You can update from WordPress %1$s to <a href="%2$s">WordPress %3$s</a> manually:', 'yooadmin'),
                    $wp_version,
                    $version_url,
                    $version_string
                );
                $plain_target = html_entity_decode(wp_strip_all_tags($version_string), ENT_QUOTES, get_bloginfo('charset'));
                $manual_upgrade_plain = sprintf(
                    /* translators: 1: Current WP version, 2: Target version (plain). */
                    __('You can update from WordPress %1$s to WordPress %2$s manually.', 'yooadmin'),
                    $wp_version,
                    $plain_target
                );
                $is_manual_compat = true;
            }

            if (!$mysql_compat || !$php_compat) {
                $show_buttons = false;
            }
        }
    }

    $is_reinstall = (strpos($form_action, 'do-core-reinstall') !== false);
    $suppress_key = $update->current . '|' . $update->locale . '|' . md5((string) $form_action);

    $tooltip_plain = $manual_upgrade_plain;
    if ($tooltip_plain === '') {
        $tooltip_plain = wp_strip_all_tags(html_entity_decode($message, ENT_QUOTES, get_bloginfo('charset')));
    }
    if ($tooltip_plain === '') {
        $tooltip_plain = $submit;
    }

    $list_message = $message;
    if ($is_manual_compat && $show_buttons) {
        $list_message = '';
    }

    return [
        'version_string' => $version_string,
        'current'        => $current,
        'message'        => $message,
        'list_message'   => $list_message,
        'submit'         => $submit,
        'form_action'    => $form_action,
        'show_buttons'   => $show_buttons,
        'is_reinstall'   => $is_reinstall,
        'suppress_key'   => $suppress_key,
        'tooltip_plain'  => $tooltip_plain,
    ];
}

/**
 * Primary core upgrade button in page header (tooltip = manual upgrade line).
 */
function yooadmin_uc_render_header_core_upgrade(): void
{
    if (! current_user_can('update_core')) {
        return;
    }
    $updates = get_core_updates();
    if (empty($updates)) {
        return;
    }
    $meta = yooadmin_uc_core_update_meta($updates[0]);
    if (! $meta['show_buttons']) {
        return;
    }

    $GLOBALS['yooadmin_uc_suppress_core_primary'] = $meta['suppress_key'];

    $is_reinstall = $meta['is_reinstall'];
    ?>
    <div id="yoo-uc-header-core-btn-wrap" class="yoo-uc-header-core-btn-wrap">
        <form method="post" action="<?php echo esc_url($meta['form_action']); ?>" id="yoo-uc-header-core-form" class="upgrade yoo-uc-core-upgrade-form" data-reinstall="<?php echo esc_attr($is_reinstall ? '1' : '0'); ?>">
            <?php wp_nonce_field('upgrade-core'); ?>
            <input name="version" value="<?php echo esc_attr($updates[0]->current); ?>" type="hidden" />
            <input name="locale" value="<?php echo esc_attr($updates[0]->locale); ?>" type="hidden" />
            <button type="submit" name="upgrade" class="button button-primary yoo-btn yoo-btn-primary yoo-uc-header-core-submit" title="<?php echo esc_attr($meta['tooltip_plain']); ?>">
                <span class="dashicons <?php echo $is_reinstall ? 'dashicons-image-rotate' : 'dashicons-update'; ?> yoo-uc-header-core-submit__icon" aria-hidden="true"></span>
                <span class="yoo-uc-header-core-submit__label"><?php echo esc_html($meta['submit']); ?></span>
            </button>
        </form>
    </div>
    <?php
}

/**
 * Header toolbar: core upgrade submit (when applicable) + “Check for updates” (Theme Manager pattern).
 */
function yooadmin_uc_render_header_actions(): void
{
    if (! current_user_can('update_core')) {
        return;
    }
    echo '<div class="yoo-uc-header-actions-toolbar">';
    echo '<button type="button" class="yoo-check-updates-btn yoo-uc-check-again" id="yoo-uc-header-check-updates">';
    echo '<span class="dashicons dashicons-update" aria-hidden="true"></span>';
    echo '<span class="yoo-check-updates-label">' . esc_html__('Check for updates', 'yooadmin') . '</span>';
    echo '</button>';
    yooadmin_uc_render_header_core_upgrade();
    echo '</div>';
}

/**
 * Combined backup + “update available” notice above the hero.
 */
function yooadmin_uc_render_preface_notices(): void
{
    if (! current_user_can('update_core')) {
        return;
    }
    $wp_v     = get_bloginfo('version');
    $updates = get_core_updates();
    if (! $updates || ! isset($updates[0]->version) || ! version_compare($updates[0]->version, $wp_v, '>')) {
        return;
    }

    $backup = sprintf(
        /* translators: 1: Documentation on WordPress backups, 2: Documentation on updating WordPress. */
        __('<strong>Important:</strong> Before updating, please <a href="%1$s">back up your database and files</a>. For help with updates, visit the <a href="%2$s">Updating WordPress</a> documentation page.', 'yooadmin'),
        __('https://wordpress.org/documentation/article/wordpress-backups/', 'yooadmin'),
        __('https://wordpress.org/documentation/article/updating-wordpress/', 'yooadmin')
    );

    $inner  = '<p class="yoo-uc-preface-line"><strong>' . esc_html(__('An updated version of WordPress is available.', 'yooadmin')) . '</strong></p>';
    $inner .= '<p class="yoo-uc-preface-line">' . wp_kses_post($backup) . '</p>';
    echo '<div class="yoo-uc-preface-above-hero">';
    yooadmin_uc_infobox($inner, 'warning');
    echo '</div>';
}

/**
 * GET redirect notices for major/minor auto-update prefs.
 */
function yooadmin_uc_core_auto_redirect_notices(): void
{
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flash query arg.
    if (! isset($_GET['core-major-auto-updates-saved'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flash query arg.
    $v = sanitize_key(wp_unslash((string) $_GET['core-major-auto-updates-saved']));
    if ('enabled' === $v) {
        yooadmin_uc_infobox(esc_html__('Automatic updates for all WordPress versions have been enabled. Thank you!', 'yooadmin'), 'success');
    } elseif ('disabled' === $v) {
        yooadmin_uc_infobox(esc_html__('WordPress will only receive automatic security and maintenance releases from now on.', 'yooadmin'), 'success');
    }
}

/**
 * Automatic updates control for hero row (button + tooltip; links post to core).
 */
function yooadmin_uc_print_auto_update_hero_control(): void
{
    if (! current_user_can('update_core')) {
        return;
    }

    yooadmin_uc_reset_floating_tooltips();

    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    $updater = new WP_Automatic_Updater();

    $upgrade_dev   = get_site_option('auto_update_core_dev', 'enabled') === 'enabled';
    $upgrade_minor = get_site_option('auto_update_core_minor', 'enabled') === 'enabled';
    $upgrade_major = get_site_option('auto_update_core_major', 'unset') === 'enabled';

    $can_set_update_option = true;
    if (defined('WP_AUTO_UPDATE_CORE')) {
        if (false === WP_AUTO_UPDATE_CORE) {
            $upgrade_dev   = false;
            $upgrade_minor = false;
            $upgrade_major = false;
        } elseif (true === WP_AUTO_UPDATE_CORE
            || in_array(WP_AUTO_UPDATE_CORE, ['beta', 'rc', 'development', 'branch-development'], true)
        ) {
            $upgrade_dev   = true;
            $upgrade_minor = true;
            $upgrade_major = true;
        } elseif ('minor' === WP_AUTO_UPDATE_CORE) {
            $upgrade_dev   = false;
            $upgrade_minor = true;
            $upgrade_major = false;
        }
        $can_set_update_option = false;
    }

    if ($updater->is_disabled()) {
        $upgrade_dev   = false;
        $upgrade_minor = false;
        $upgrade_major = false;
        $can_set_update_option = false;
    }

    if (has_filter('allow_major_auto_core_updates')) {
        $can_set_update_option = false;
    }

    /** This filter is documented in wp-admin/includes/class-core-upgrader.php */
    $upgrade_dev   = apply_filters('allow_dev_auto_core_updates', $upgrade_dev); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
    /** This filter is documented in wp-admin/includes/class-core-upgrader.php */
    $upgrade_minor = apply_filters('allow_minor_auto_core_updates', $upgrade_minor); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
    /** This filter is documented in wp-admin/includes/class-core-upgrader.php */
    $upgrade_major = apply_filters('allow_major_auto_core_updates', $upgrade_major); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.

    $auto_update_settings = [
        'dev'   => $upgrade_dev,
        'minor' => $upgrade_minor,
        'major' => $upgrade_major,
    ];

    $tooltip_lines = [];

    if ($updater->is_vcs_checkout(ABSPATH)) {
        $tooltip_icon = 'dashicons-editor-code';
        $tooltip_lines[] = __('This copy of WordPress looks like a development checkout (Git, SVN, etc.). Automatic updates are turned off so your version control history stays clean.', 'yooadmin');
    } elseif ($upgrade_major) {
        $tooltip_icon = $can_set_update_option ? 'dashicons-update' : 'dashicons-lock';
        if ($can_set_update_option) {
            $tooltip_lines[] = __('Major, minor, and security releases can install automatically. That keeps the site on the latest WordPress without manual updates.', 'yooadmin');
            $tooltip_lines[] = __('Use the button to limit automatic updates to maintenance and security releases only (no automatic major upgrades).', 'yooadmin');
        } else {
            $tooltip_lines[] = __('All WordPress versions may update automatically. This is enforced by your configuration (for example WP_AUTO_UPDATE_CORE or a filter), not by this button.', 'yooadmin');
        }
    } elseif ($upgrade_minor) {
        $tooltip_icon = $can_set_update_option ? 'dashicons-shield' : 'dashicons-lock';
        if ($can_set_update_option) {
            $tooltip_lines[] = __('Only maintenance and security releases install automatically — major WordPress versions wait until you update manually.', 'yooadmin');
            $tooltip_lines[] = __('Use the button to allow automatic updates for all releases, including major versions.', 'yooadmin');
        } else {
            $tooltip_lines[] = __('Maintenance and security automatic updates are set by your configuration. The mode cannot be changed from here.', 'yooadmin');
        }
    } else {
        $tooltip_icon = 'dashicons-dismiss';
        $tooltip_lines[] = __('Automatic core updates are not active in this mode (or are fully disabled). Adjust WordPress Updates / site config if you want background updates.', 'yooadmin');
    }

    echo '<div class="yoo-uc-auto-mode-wrap">';
    echo '<span class="yoo-uc-auto-mode-anchor" data-yoo-uc-tip-target="' . esc_attr(YOOADMIN_UC_AUTO_TIP_ID) . '" aria-describedby="' . esc_attr(YOOADMIN_UC_AUTO_TIP_ID) . '">';

    if ($updater->is_vcs_checkout(ABSPATH)) {
        echo '<span class="yoo-btn yoo-btn-text yoo-uc-auto-toggle yoo-uc-auto-toggle--disabled" aria-disabled="true">';
        echo esc_html__('Automatic updates are disabled (version control).', 'yooadmin');
        echo '</span>';
    } elseif ($upgrade_major) {
        if ($can_set_update_option) {
            echo '<button type="button" class="yoo-btn yoo-uc-auto-toggle yoo-uc-auto-toggle--major yoo-uc-core-auto-link" data-value="disable">';
            echo esc_html__('Automatic updates: all versions', 'yooadmin');
            echo '</button>';
        } else {
            echo '<span class="yoo-btn yoo-uc-auto-toggle yoo-uc-auto-toggle--major yoo-uc-auto-toggle--locked" aria-disabled="true">';
            echo esc_html__('Automatic updates: all versions', 'yooadmin');
            echo '</span>';
        }
    } elseif ($upgrade_minor) {
        if ($can_set_update_option) {
            echo '<button type="button" class="yoo-btn yoo-uc-auto-toggle yoo-uc-auto-toggle--minor yoo-uc-core-auto-link" data-value="enable">';
            echo esc_html__('Automatic updates: maintenance & security', 'yooadmin');
            echo '</button>';
        } else {
            echo '<span class="yoo-btn yoo-uc-auto-toggle yoo-uc-auto-toggle--minor yoo-uc-auto-toggle--locked" aria-disabled="true">';
            echo esc_html__('Automatic updates: maintenance & security', 'yooadmin');
            echo '</span>';
        }
    } else {
        echo '<span class="yoo-btn yoo-btn-text yoo-uc-auto-toggle yoo-uc-auto-toggle--off" aria-disabled="true">';
        echo esc_html__('Automatic updates: off', 'yooadmin');
        echo '</span>';
    }

    echo '</span>';
    echo '</div>';

    ob_start();
    echo '<span class="yoo-uc-auto-mode-tooltip__inner">';
    echo '<span class="yoo-uc-auto-mode-tooltip__head">';
    echo '<span class="dashicons ' . esc_attr($tooltip_icon) . ' yoo-uc-auto-mode-tooltip__icon" aria-hidden="true"></span>';
    echo '<span class="yoo-uc-auto-mode-tooltip__body">';
    foreach ($tooltip_lines as $line) {
        echo '<span class="yoo-uc-auto-mode-tooltip__p">' . esc_html($line) . '</span>';
    }
    echo '</span></span>';
    echo '</span>';
    yooadmin_uc_register_floating_tooltip(YOOADMIN_UC_AUTO_TIP_ID, (string) ob_get_clean());

    /**
     * Fires after the major core auto-update settings.
     *
     * @param array $auto_update_settings
     */
    do_action('after_core_auto_updates_settings', $auto_update_settings); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
}

/**
 * Core auto-update message when major + pending core update (below hero controls).
 */
function yooadmin_uc_print_core_auto_pending_message(): void
{
    if (! current_user_can('update_core')) {
        return;
    }
    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    $updater = new WP_Automatic_Updater();
    if ($updater->is_disabled()) {
        return;
    }
    $upgrade_major = get_site_option('auto_update_core_major', 'unset') === 'enabled';
    if (defined('WP_AUTO_UPDATE_CORE') && false === WP_AUTO_UPDATE_CORE) {
        $upgrade_major = false;
    }
    $upgrade_major = apply_filters('allow_major_auto_core_updates', $upgrade_major); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
    if (! $upgrade_major) {
        return;
    }
    $wp_version = get_bloginfo('version');
    $updates    = get_core_updates();
    if (isset($updates[0]->version) && version_compare($updates[0]->version, $wp_version, '>')) {
        echo '<p class="yoo-update-center-auto-msg yoo-uc-hero-auto-pending">' . wp_kses_post(wp_get_auto_update_message()) . '</p>';
    }
}

/**
 * Maintenance note directly under “Current version” in the hero (not in core list).
 */
function yooadmin_uc_print_hero_maintenance_note(): void
{
    if (! current_user_can('update_core')) {
        return;
    }
    $updates = get_core_updates();
    if (! $updates || ! (count($updates) > 1 || 'latest' !== $updates[0]->response)) {
        return;
    }
    echo '<div class="yoo-uc-hero-maintenance-card" role="note">';
    echo '<span class="yoo-uc-hero-maintenance-card__icon" aria-hidden="true"><span class="dashicons dashicons-info-outline"></span></span>';
    echo '<p class="yoo-uc-hero-maintenance-card__text">' . esc_html__('While your site is being updated, it will be in maintenance mode. As soon as your updates are complete, this mode will be deactivated.', 'yooadmin') . '</p>';
    echo '</div>';
}

/**
 * Single core update row (same POST fields / nonces as core).
 *
 * @param object $update Core update object.
 * @return bool True if anything was output (skip empty shells — avoids blank bordered box).
 */
function yooadmin_uc_list_core_update($update): bool
{
    global $wp_local_package;
    static $first_pass = true;

    if (! is_object($update)) {
        return false;
    }

    $meta     = yooadmin_uc_core_update_meta($update);
    $suppress = isset($GLOBALS['yooadmin_uc_suppress_core_primary']) && $GLOBALS['yooadmin_uc_suppress_core_primary'] === $meta['suppress_key'];
    $show_upgrade = $meta['show_buttons'] && ! $suppress;
    $show_dismiss = ( 'en_US' !== $update->locale );

    $has_hint_bottom = ( 'en_US' !== $update->locale && (! isset($wp_local_package) || $wp_local_package !== $update->locale) )
        || ( 'en_US' === $update->locale && 'en_US' !== get_locale() && (! $update->packages->partial && get_bloginfo('version') === $update->partial_version) );

    if ( $meta['list_message'] === '' && ! $show_upgrade && ! $show_dismiss && ! $has_hint_bottom ) {
        return false;
    }

    echo '<div class="yoo-update-center-core-item">';
    if ($meta['list_message'] !== '') {
        echo '<p>' . wp_kses_post($meta['list_message']) . '</p>';
    }

    echo '<form method="post" action="' . esc_url($meta['form_action']) . '" name="upgrade" class="upgrade yoo-uc-core-upgrade-form" data-reinstall="' . esc_attr($meta['is_reinstall'] ? '1' : '0') . '">';
    wp_nonce_field('upgrade-core');

    echo '<p class="yoo-update-center-core-actions">';
    echo '<input name="version" value="' . esc_attr($update->current) . '" type="hidden" />';
    echo '<input name="locale" value="' . esc_attr($update->locale) . '" type="hidden" />';
    if ($meta['show_buttons']) {
        if (! $suppress) {
            $row_icon = $meta['is_reinstall'] ? 'dashicons-image-rotate' : 'dashicons-update';
            if ($first_pass) {
                $row_btn_class = $meta['current'] ? 'button' : 'button button-primary yoo-update-center-btn-primary';
                $first_pass    = false;
            } else {
                $row_btn_class = 'button button-secondary';
            }
            echo '<button type="submit" name="upgrade" class="' . esc_attr($row_btn_class . ' yoo-uc-core-row-submit') . '">';
            echo '<span class="dashicons ' . esc_attr($row_icon) . '" aria-hidden="true"></span>';
            echo '<span class="yoo-uc-core-submit__label">' . esc_html($meta['submit']) . '</span>';
            echo '</button>';
        } else {
            $first_pass = false;
        }
    }
    if ('en_US' !== $update->locale) {
        if (!isset($update->dismissed) || !$update->dismissed) {
            submit_button(__('Hide this update', 'yooadmin'), 'secondary', 'dismiss', false);
        } else {
            submit_button(__('Bring back this update', 'yooadmin'), 'secondary', 'undismiss', false);
        }
    }
    echo '</p>';

    if ('en_US' !== $update->locale && (!isset($wp_local_package) || $wp_local_package !== $update->locale)) {
        echo '<p class="yoo-update-center-hint">' . esc_html__('This localized version contains both the translation and various other localization fixes.', 'yooadmin') . '</p>';
    } elseif ('en_US' === $update->locale && 'en_US' !== get_locale() && (!$update->packages->partial && get_bloginfo('version') === $update->partial_version)) {
        echo '<p class="yoo-update-center-hint">' . esc_html(
            sprintf(
                /* translators: %s: WordPress version. */
                __('You are about to install WordPress %s in English (US). There is a chance this update will break your translation. You may prefer to wait for the localized version to be released.', 'yooadmin'),
                'development' !== $update->response ? $update->current : ''
            )
        ) . '</p>';
    }

    echo '</form></div>';

    return true;
}

/**
 * Hidden dismissed core updates (toggle like core).
 */
function yooadmin_uc_dismissed_updates(): void
{
    $dismissed = get_core_updates(
        [
            'dismissed' => true,
            'available' => false,
        ]
    );

    if (! is_array($dismissed) || $dismissed === []) {
        return;
    }

    $show_text = __('Show hidden updates', 'yooadmin');
    $hide_text = __('Hide hidden updates', 'yooadmin');
    ?>
    <script>
    jQuery(function ($) {
        $('#yoo-show-dismissed-core').on('click', function () {
            var isExpanded = ('true' === $(this).attr('aria-expanded'));
            if (isExpanded) {
                $(this).text(<?php echo wp_json_encode($show_text); ?>).attr('aria-expanded', 'false');
            } else {
                $(this).text(<?php echo wp_json_encode($hide_text); ?>).attr('aria-expanded', 'true');
            }
            $('#yoo-dismissed-core-updates').toggle('fast');
        });
    });
    </script>
    <?php
    echo '<p class="yoo-update-center-dismiss-toggle"><button type="button" class="button" id="yoo-show-dismissed-core" aria-expanded="false">' . esc_html__('Show hidden updates', 'yooadmin') . '</button></p>';
    echo '<ul id="yoo-dismissed-core-updates" class="yoo-update-center-dismissed" style="display:none">';
    foreach ($dismissed as $update) {
        ob_start();
        $ok = yooadmin_uc_list_core_update($update);
        $chunk = ob_get_clean();
        if ($ok) {
            echo '<li>' . wp_kses_post($chunk) . '</li>';
        }
    }
    echo '</ul>';
}

/**
 * WordPress core upgrade intro + list.
 */
function yooadmin_uc_core_upgrade_preamble(): void
{
    $updates = get_core_updates();
    if (! is_array($updates)) {
        $updates = [];
    }
    require ABSPATH . WPINC . '/version.php';

    $is_development_version = preg_match('/alpha|beta|RC/', $wp_version);

    $show_core_status_heading = true;
    if (isset($updates[0]) && is_object($updates[0]) && isset($updates[0]->version) && version_compare($updates[0]->version, $wp_version, '>')) {
        $heading = __('An updated version of WordPress is available.', 'yooadmin');
    } elseif ($is_development_version) {
        $heading = __('You are using a development version of WordPress.', 'yooadmin');
    } else {
        $heading                  = '';
        $show_core_status_heading = false;
    }

    $preface_covers_update = isset($updates[0]) && is_object($updates[0]) && isset($updates[0]->version) && version_compare($updates[0]->version, $wp_version, '>');
    if (! $preface_covers_update && $show_core_status_heading && $heading !== '') {
        echo '<p class="yoo-update-center-core-heading yoo-uc-core-status-line">' . esc_html($heading) . '</p>';
    }

    $core_lis = '';
    foreach ($updates as $update) {
        ob_start();
        $ok = yooadmin_uc_list_core_update($update);
        $chunk = ob_get_clean();
        if ($ok) {
            $core_lis .= '<li>' . $chunk . '</li>';
        }
    }
    if ($core_lis !== '') {
        echo '<ul class="yoo-update-center-core-list">' . wp_kses_post($core_lis) . '</ul>';
    }

    if ($updates === []) {
        list($normalized_version) = explode('-', $wp_version);
        echo '<p class="yoo-update-center-about-version">' . wp_kses_post(
            sprintf(
                /* translators: 1: URL to About screen, 2: WordPress version. */
                __('<a href="%1$s">Learn more about WordPress %2$s</a>.', 'yooadmin'),
                esc_url(self_admin_url('about.php')),
                esc_html($normalized_version)
            )
        ) . '</p>';
    }

    yooadmin_uc_dismissed_updates();
}

/**
 * Hero aside: automatic updates control + pending core message + compact last checked.
 */
function yooadmin_uc_render_hero_aside(): void
{
    if (! current_user_can('update_core')) {
        return;
    }

    yooadmin_uc_print_auto_update_hero_control();
    yooadmin_uc_print_core_auto_pending_message();

    echo '<div id="yoo-uc-hero-last-checked-wrap" class="yoo-uc-hero-last-checked-wrap">';
    yooadmin_uc_render_last_checked_compact();
    echo '</div>';
}

/**
 * Back-compat: automatic updates UI moved to hero (see yooadmin_uc_render_hero_aside).
 *
 * @deprecated
 */
function yooadmin_uc_core_auto_updates_settings(): void
{
    yooadmin_uc_print_auto_update_hero_control();
    yooadmin_uc_print_core_auto_pending_message();
}

/**
 * Plugin updates — grid tiles (Theme Manager–style hover + selection).
 *
 * @param bool $hide_heading Hide section title when embedded in tabs.
 */
function yooadmin_uc_list_plugin_updates( bool $hide_heading = false ): void
{
    $wp_version = get_bloginfo('version');
    $cur_wp_version = preg_replace('/-.*$/', '', $wp_version);

    require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
    $plugins = get_plugin_updates();
    if (empty($plugins)) {
        if (! $hide_heading) {
            echo '<div class="yoo-uc-section-head"><h2 class="yoo-update-center-section-title"><span class="dashicons dashicons-admin-plugins yoo-uc-section-head__icon" aria-hidden="true"></span>' . esc_html__('Plugins', 'yooadmin') . '</h2></div>';
        }
        yooadmin_uc_render_no_updates_notice(__('No plugin updates pending.', 'yooadmin'));
        return;
    }

    $form_action = self_admin_url('update-core.php?action=do-plugin-upgrade');

    $core_updates = get_core_updates();
    if (!isset($core_updates[0]->response) || 'latest' === $core_updates[0]->response || 'development' === $core_updates[0]->response || version_compare($core_updates[0]->current, $cur_wp_version, '=')) {
        $core_update_version = false;
    } else {
        $core_update_version = $core_updates[0]->current;
    }

    $plugins_count = count($plugins);
    if (! $hide_heading) {
        ?>
    <div class="yoo-uc-section-head">
        <h2 class="yoo-update-center-section-title">
            <span class="dashicons dashicons-admin-plugins yoo-uc-section-head__icon" aria-hidden="true"></span>
            <?php
            printf(
                '%s <span class="yoo-update-center-count">(%s)</span>',
                esc_html__('Plugins', 'yooadmin'),
                esc_html(number_format_i18n($plugins_count))
            );
            ?>
        </h2>
        <p class="yoo-update-center-section-lead"><?php esc_html_e('Select updates, then apply — same as the Plugins Manager flow.', 'yooadmin'); ?></p>
    </div>
        <?php
    }
    ?>
    <form method="post" action="<?php echo esc_url($form_action); ?>" name="upgrade-plugins" class="upgrade yoo-uc-form yoo-uc-form--plugins">
        <?php wp_nonce_field('upgrade-core'); ?>
        <div class="yoo-uc-bulk-strip yoo-bulk-actions-bar" id="yoo-uc-plugins-bulk" hidden data-yoo-uc-bulk="plugins">
            <div class="yoo-bulk-actions-left">
                <label class="yoo-uc-bulk-strip__select" for="plugins-select-all">
                    <input type="checkbox" id="plugins-select-all" />
                    <?php esc_html_e('Select all', 'yooadmin'); ?>
                </label>
            </div>
            <div class="yoo-bulk-actions-right">
                <input id="upgrade-plugins" class="yoo-bulk-apply-btn" type="submit" value="<?php esc_attr_e('Update Plugins', 'yooadmin'); ?>" name="upgrade" />
            </div>
        </div>
        <div class="yoo-uc-grid-root yoo-wordpress-results yoo-uc-plugins-grid" id="update-plugins-table">
            <?php
            foreach ((array) $plugins as $plugin_file => $plugin_data) {
                $plugin_data = (object) array_merge(
                    (array) $plugin_data,
                    get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_file, false, true)
                );

                $icon = '<span class="dashicons dashicons-admin-plugins"></span>';
                $preferred_icons = ['svg', '2x', '1x', 'default'];
                foreach ($preferred_icons as $preferred_icon) {
                    if (!empty($plugin_data->update->icons[$preferred_icon])) {
                        $icon = '<img src="' . esc_url($plugin_data->update->icons[$preferred_icon]) . '" alt="" />';
                        break;
                    }
                }

                $requires_php     = isset($plugin_data->update->requires_php) ? $plugin_data->update->requires_php : null;
                $compatible_php   = is_php_version_compatible($requires_php);
                $plugin_compat_line = '';
                if (! $compatible_php) {
                    $plugin_compat_line = __('This update does not work with your version of PHP.', 'yooadmin');
                } elseif (isset($plugin_data->update->tested) && version_compare($plugin_data->update->tested, $cur_wp_version, '>=')) {
                    $plugin_compat_line = sprintf(
                        /* translators: %s: WordPress version. */
                        esc_html__('Compatibility with WordPress %s: 100%%', 'yooadmin'),
                        $cur_wp_version
                    );
                } else {
                    $plugin_compat_line = sprintf(
                        /* translators: %s: WordPress version. */
                        esc_html__('Compatibility with WordPress %s: Unknown', 'yooadmin'),
                        $cur_wp_version
                    );
                }

                $details_url = self_admin_url('plugin-install.php?tab=plugin-information&plugin=' . $plugin_data->update->slug . '&section=changelog&TB_iframe=true&width=640&height=662');
                $details_label = sprintf(
                    /* translators: 1: Plugin name, 2: Version number. */
                    __('View %1$s version %2$s details', 'yooadmin'),
                    $plugin_data->Name,
                    $plugin_data->update->new_version
                );

                $checkbox_id = 'checkbox_' . md5($plugin_file);
                ?>
                <article class="yoo-plugin-card yoo-theme-card yoo-uc-update-tile<?php echo $compatible_php ? '' : ' yoo-uc-update-tile--blocked'; ?>" data-plugin-file="<?php echo esc_attr($plugin_file); ?>">
                    <div class="yoo-theme-card-media-wrap yoo-uc-plugin-tile-wrap">
                        <?php if ($compatible_php) : ?>
                            <span class="yoo-uc-tile-check">
                                <input type="checkbox" name="checked[]" id="<?php echo esc_attr($checkbox_id); ?>" value="<?php echo esc_attr($plugin_file); ?>" class="yoo-uc-tile-cb" />
                                <label for="<?php echo esc_attr($checkbox_id); ?>" class="yoo-uc-tile-check-label">
                                    <span class="screen-reader-text">
                                        <?php
                                        /* translators: Hidden accessibility text. %s: Plugin name. */
                                        printf(esc_html__('Select %s', 'yooadmin'), esc_html($plugin_data->Name));
                                        ?>
                                    </span>
                                </label>
                            </span>
                        <?php endif; ?>
                        <div class="yoo-uc-plugin-tile-icon"><?php echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                        <div class="yoo-uc-tile-meta-bar<?php echo $compatible_php ? '' : ' yoo-uc-tile-meta-bar--blocked'; ?>">
                            <div class="yoo-uc-tile-meta-bar__text">
                                <span class="yoo-uc-tile-meta-bar__title"><?php echo esc_html($plugin_data->Name); ?></span>
                                <span class="yoo-uc-tile-meta-bar__ver">
                                    <?php
                                    printf(
                                        /* translators: 1: Old version, 2: New version. */
                                        esc_html__('%1$s → %2$s', 'yooadmin'),
                                        esc_html($plugin_data->Version),
                                        esc_html($plugin_data->update->new_version)
                                    );
                                    ?>
                                </span>
                                <?php if ($plugin_compat_line !== '') : ?>
                                    <span class="yoo-uc-tile-meta-bar__compat"><?php echo esc_html($plugin_compat_line); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="yoo-uc-tile-meta-bar__actions">
                                <a href="<?php echo esc_url($details_url); ?>" class="yoo-uc-tile-meta-bar__details thickbox open-plugin-details-modal" aria-label="<?php echo esc_attr($details_label); ?>">
                                    <span class="dashicons dashicons-info" aria-hidden="true"></span>
                                </a>
                                <?php if ($compatible_php) : ?>
                                    <button type="button" class="yoo-uc-tile-meta-bar__update yoo-uc-single-plugin-update">
                                        <?php esc_html_e('Update', 'yooadmin'); ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </article>
                <?php
            }
            ?>
        </div>
    </form>
    <?php
}

/**
 * Theme updates — screenshot tiles; name & versions on hover (Theme Manager style).
 *
 * @param bool $hide_heading Hide section title when embedded in tabs.
 */
function yooadmin_uc_list_theme_updates( bool $hide_heading = false ): void
{
    $themes = get_theme_updates();
    if (empty($themes)) {
        if (! $hide_heading) {
            echo '<div class="yoo-uc-section-head"><h2 class="yoo-update-center-section-title"><span class="dashicons dashicons-admin-appearance yoo-uc-section-head__icon" aria-hidden="true"></span>' . esc_html__('Themes', 'yooadmin') . '</h2></div>';
        }
        yooadmin_uc_render_no_updates_notice(__('No theme updates pending.', 'yooadmin'));
        return;
    }

    $form_action = self_admin_url('update-core.php?action=do-theme-upgrade');
    $themes_count = count($themes);

    if (! $hide_heading) {
        ?>
    <div class="yoo-uc-section-head">
        <h2 class="yoo-update-center-section-title">
            <span class="dashicons dashicons-admin-appearance yoo-uc-section-head__icon" aria-hidden="true"></span>
            <?php
            printf(
                '%s <span class="yoo-update-center-count">(%s)</span>',
                esc_html__('Themes', 'yooadmin'),
                esc_html(number_format_i18n($themes_count))
            );
            ?>
        </h2>
        <p class="yoo-update-center-section-lead"><?php esc_html_e('Theme updates like Theme Manager — pick versions, then update in bulk.', 'yooadmin'); ?></p>
    </div>
        <?php
    }
    $child_note = wp_kses_post(
        sprintf(
            /* translators: %s: Link to documentation on child themes. */
            __('<strong>Note:</strong> File edits in the theme folder can be overwritten. Prefer <a href="%s">child themes</a> for customizations.', 'yooadmin'),
            esc_url(__('https://developer.wordpress.org/themes/advanced-topics/child-themes/', 'yooadmin'))
        )
    );
    yooadmin_uc_infobox($child_note, 'neutral');
    ?>
    <form method="post" action="<?php echo esc_url($form_action); ?>" name="upgrade-themes" class="upgrade yoo-uc-form yoo-uc-form--themes">
        <?php wp_nonce_field('upgrade-core'); ?>
        <div class="yoo-uc-bulk-strip yoo-bulk-actions-bar" id="yoo-uc-themes-bulk" hidden data-yoo-uc-bulk="themes">
            <div class="yoo-bulk-actions-left">
                <label class="yoo-uc-bulk-strip__select" for="themes-select-all">
                    <input type="checkbox" id="themes-select-all" />
                    <?php esc_html_e('Select all', 'yooadmin'); ?>
                </label>
            </div>
            <div class="yoo-bulk-actions-right">
                <input id="upgrade-themes" class="yoo-bulk-apply-btn" type="submit" value="<?php esc_attr_e('Update Themes', 'yooadmin'); ?>" name="upgrade" />
            </div>
        </div>
        <div class="yoo-uc-grid-root yoo-wordpress-results yoo-uc-themes-grid" id="update-themes-table">
            <?php
            foreach ($themes as $stylesheet => $theme) {
                $requires_wp = isset($theme->update['requires']) ? $theme->update['requires'] : null;
                $requires_php = isset($theme->update['requires_php']) ? $theme->update['requires_php'] : null;

                $compatible_wp = is_wp_version_compatible($requires_wp);
                $compatible_php = is_php_version_compatible($requires_php);

                $checkbox_id = 'checkbox_' . md5($theme->get('Name'));
                $ok_tile       = $compatible_wp && $compatible_php;

                $theme_compat_line = '';
                if (! $ok_tile) {
                    if (! $compatible_wp && ! $compatible_php) {
                        $theme_compat_line = __('This update does not work with your versions of WordPress and PHP.', 'yooadmin');
                    } elseif (! $compatible_wp) {
                        $theme_compat_line = __('This update does not work with your version of WordPress.', 'yooadmin');
                    } else {
                        $theme_compat_line = __('This update does not work with your version of PHP.', 'yooadmin');
                    }
                } else {
                    $wp_ver_plain = preg_replace('/-.*$/', '', (string) get_bloginfo('version'));
                    $tested       = isset($theme->update['tested']) ? (string) $theme->update['tested'] : '';
                    if ($tested !== '' && version_compare($tested, $wp_ver_plain, '>=')) {
                        $theme_compat_line = sprintf(
                            /* translators: %s: WordPress version. */
                            esc_html__('Compatibility with WordPress %s: OK', 'yooadmin'),
                            $wp_ver_plain
                        );
                    } elseif ($tested !== '') {
                        /* translators: %s: WordPress version. */
                        $theme_compat_line = sprintf(__('Tested up to WordPress %s', 'yooadmin'), $tested);
                    } else {
                        $theme_compat_line = __('Check theme details for WordPress compatibility.', 'yooadmin');
                    }
                }
                ?>
                <article class="yoo-plugin-card yoo-theme-card yoo-uc-update-tile<?php echo $ok_tile ? '' : ' yoo-uc-update-tile--blocked'; ?>" data-stylesheet="<?php echo esc_attr($stylesheet); ?>">
                    <div class="yoo-theme-card-media-wrap">
                        <?php if ($ok_tile) : ?>
                            <span class="yoo-uc-tile-check">
                                <input type="checkbox" name="checked[]" id="<?php echo esc_attr($checkbox_id); ?>" value="<?php echo esc_attr($stylesheet); ?>" class="yoo-uc-tile-cb" />
                                <label for="<?php echo esc_attr($checkbox_id); ?>" class="yoo-uc-tile-check-label">
                                    <span class="screen-reader-text">
                                        <?php
                                        /* translators: Hidden accessibility text. %s: Theme name. */
                                        printf(esc_html__('Select %s', 'yooadmin'), esc_html($theme->display('Name')));
                                        ?>
                                    </span>
                                </label>
                            </span>
                        <?php endif; ?>
                        <img src="<?php echo esc_url($theme->get_screenshot() . '?ver=' . $theme->version); ?>" alt="" class="yoo-theme-card-media" loading="lazy" />
                        <div class="yoo-uc-tile-meta-bar<?php echo $ok_tile ? '' : ' yoo-uc-tile-meta-bar--blocked'; ?>">
                            <div class="yoo-uc-tile-meta-bar__text">
                                <span class="yoo-uc-tile-meta-bar__title"><?php echo esc_html($theme->display('Name')); ?></span>
                                <span class="yoo-uc-tile-meta-bar__ver">
                                    <?php
                                    printf(
                                        /* translators: 1: Old version, 2: New version. */
                                        esc_html__('%1$s → %2$s', 'yooadmin'),
                                        esc_html($theme->display('Version')),
                                        esc_html($theme->update['new_version'])
                                    );
                                    ?>
                                </span>
                                <?php if ($theme_compat_line !== '') : ?>
                                    <span class="yoo-uc-tile-meta-bar__compat"><?php echo esc_html($theme_compat_line); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="yoo-uc-tile-meta-bar__actions">
                                <?php if ($ok_tile) : ?>
                                    <button type="button" class="yoo-uc-tile-meta-bar__update yoo-uc-single-theme-update" aria-label="<?php echo esc_attr(sprintf(
                                        /* translators: %s: theme name. */
                                        __('Update %s', 'yooadmin'),
                                        $theme->display('Name')
                                    )); ?>">
                                        <?php esc_html_e('Update', 'yooadmin'); ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </article>
                <?php
            }
            ?>
        </div>
    </form>
    <?php
}

/**
 * Translation updates — ordered list (type → language), single bulk action.
 *
 * @param bool $hide_heading Hide section title when embedded in tabs.
 */
function yooadmin_uc_list_translation_updates( bool $hide_heading = false ): void
{
    $updates = wp_get_translation_updates();
    if (!$updates) {
        if (! $hide_heading) {
            echo '<div class="yoo-uc-section-head"><h2 class="yoo-update-center-section-title"><span class="dashicons dashicons-translation yoo-uc-section-head__icon" aria-hidden="true"></span>' . esc_html__('Translations', 'yooadmin') . '</h2></div>';
        }
        yooadmin_uc_render_no_updates_notice(__('No translation updates pending.', 'yooadmin'));
        return;
    }

    $arr = (array) $updates;
    usort(
        $arr,
        static function ($a, $b): int {
            $ta = isset($a->type) ? (string) $a->type : '';
            $tb = isset($b->type) ? (string) $b->type : '';
            $c  = strcmp($ta, $tb);
            if (0 !== $c) {
                return $c;
            }
            $la = isset($a->language) ? (string) $a->language : (isset($a->slug) ? (string) $a->slug : '');
            $lb = isset($b->language) ? (string) $b->language : (isset($b->slug) ? (string) $b->slug : '');
            return strcmp($la, $lb);
        }
    );

    $form_action = self_admin_url('update-core.php?action=do-translation-upgrade');
    if (! $hide_heading) {
        ?>
    <div class="yoo-uc-section-head">
        <h2 class="yoo-update-center-section-title">
            <span class="dashicons dashicons-translation yoo-uc-section-head__icon" aria-hidden="true"></span>
            <?php esc_html_e('Translations', 'yooadmin'); ?>
        </h2>
        <p class="yoo-update-center-section-lead"><?php esc_html_e('Language packs ready to install — one action updates all listed packs.', 'yooadmin'); ?></p>
    </div>
        <?php
    }
    ?>
    <form method="post" action="<?php echo esc_url($form_action); ?>" name="upgrade-translations" class="upgrade yoo-uc-form yoo-uc-form--translations yoo-uc-translations-form">
        <?php wp_nonce_field('upgrade-translations'); ?>
        <ol class="yoo-uc-lang-stack" id="update-translations-table">
            <?php foreach ($arr as $u) : ?>
                <?php
                $t    = isset($u->type) ? (string) $u->type : '';
                $lang = isset($u->language) ? (string) $u->language : (isset($u->slug) ? (string) $u->slug : '');
                $ver  = isset($u->version) ? (string) $u->version : '';
                ?>
                <li class="yoo-uc-lang-row">
                    <span class="yoo-uc-lang-row__type"><?php echo esc_html($t); ?></span>
                    <span class="yoo-uc-lang-row__code"><?php echo esc_html($lang); ?></span>
                    <span class="yoo-uc-lang-row__ver"><?php echo esc_html($ver); ?></span>
                </li>
            <?php endforeach; ?>
        </ol>
        <div class="yoo-uc-translations-actions">
            <input class="yoo-btn yoo-btn-primary" type="submit" value="<?php esc_attr_e('Update Translations', 'yooadmin'); ?>" name="upgrade" />
        </div>
    </form>
    <?php
}
