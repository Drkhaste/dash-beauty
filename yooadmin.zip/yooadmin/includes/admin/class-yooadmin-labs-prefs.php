<?php
/**
 * Per-user Labs / experimental feature preferences.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!class_exists('YOOAdmin_Labs_Prefs')) {

    final class YOOAdmin_Labs_Prefs {

        public const USER_META_KEY = 'yooadmin_labs_prefs';

        /** @deprecated Use USER_META_KEY; kept for migration from older FAB hide. */
        public const LEGACY_FAB_HIDDEN_META = 'yooadmin_yooai_fab_hidden';

        /** @deprecated Site-wide dismiss; migrated per user on read. */
        public const LEGACY_STUDIO_DISMISS_OPTION = 'yooadmin_studio_hub_upgrade_modal_dismissed';

        /**
         * @return array{yooai_fab: bool, studio_hub_upgrade: bool, guided_tour: bool}
         */
        public static function defaults(): array {
            return [
                'yooai_fab'          => true,
                'studio_hub_upgrade' => true,
                'guided_tour'        => true,
            ];
        }

        /**
         * @param int $user_id
         * @return array{yooai_fab: bool, studio_hub_upgrade: bool, guided_tour: bool}
         */
        public static function get_prefs(int $user_id = 0): array {
            $user_id = $user_id > 0 ? $user_id : get_current_user_id();
            $prefs   = self::defaults();

            if ($user_id <= 0) {
                return $prefs;
            }

            $stored = get_user_meta($user_id, self::USER_META_KEY, true);
            if (is_array($stored)) {
                $prefs['yooai_fab']          = !empty($stored['yooai_fab']);
                $prefs['studio_hub_upgrade'] = !empty($stored['studio_hub_upgrade']);
                $prefs['guided_tour']       = array_key_exists('guided_tour', $stored)
                    ? !empty($stored['guided_tour'])
                    : $prefs['guided_tour'];
                return $prefs;
            }

            if (get_user_meta($user_id, self::LEGACY_FAB_HIDDEN_META, true)) {
                $prefs['yooai_fab'] = false;
                delete_user_meta($user_id, self::LEGACY_FAB_HIDDEN_META);
            }

            self::write_prefs($prefs, $user_id);

            return $prefs;
        }

        /**
         * @param array{yooai_fab: bool, studio_hub_upgrade: bool, guided_tour: bool} $prefs
         * @param int                                                                 $user_id
         */
        private static function write_prefs(array $prefs, int $user_id): void {
            update_user_meta(
                $user_id,
                self::USER_META_KEY,
                [
                    'yooai_fab'          => !empty($prefs['yooai_fab']) ? 1 : 0,
                    'studio_hub_upgrade' => !empty($prefs['studio_hub_upgrade']) ? 1 : 0,
                    'guided_tour'        => !empty($prefs['guided_tour']) ? 1 : 0,
                ]
            );
        }

        /**
         * @param array{yooai_fab?: bool, studio_hub_upgrade?: bool, guided_tour?: bool} $prefs
         * @param int                                              $user_id
         */
        public static function save_prefs(array $prefs, int $user_id = 0): void {
            $user_id = $user_id > 0 ? $user_id : get_current_user_id();
            if ($user_id <= 0) {
                return;
            }

            $current = self::get_prefs($user_id);
            if (array_key_exists('yooai_fab', $prefs)) {
                $current['yooai_fab'] = (bool) $prefs['yooai_fab'];
            }
            if (array_key_exists('studio_hub_upgrade', $prefs)) {
                $current['studio_hub_upgrade'] = (bool) $prefs['studio_hub_upgrade'];
            }
            if (array_key_exists('guided_tour', $prefs)) {
                $current['guided_tour'] = (bool) $prefs['guided_tour'];
            }

            self::write_prefs($current, $user_id);
        }

        /**
         * Drop obsolete site-wide dismiss flag (prefs are per user now).
         */
        public static function purge_legacy_site_option(): void {
            if (get_option(self::LEGACY_STUDIO_DISMISS_OPTION, null) !== null) {
                delete_option(self::LEGACY_STUDIO_DISMISS_OPTION);
            }
        }

        /**
         * @param int $user_id
         */
        public static function is_yooai_fab_visible(int $user_id = 0): bool {
            $prefs = self::get_prefs($user_id);
            return !empty($prefs['yooai_fab']);
        }

        /**
         * @param int $user_id
         */
        public static function is_studio_hub_upgrade_visible(int $user_id = 0): bool {
            $prefs = self::get_prefs($user_id);
            return !empty($prefs['studio_hub_upgrade']);
        }

        /**
         * @param int $user_id
         */
        public static function is_guided_tour_enabled(int $user_id = 0): bool {
            $prefs = self::get_prefs($user_id);
            return !empty($prefs['guided_tour']);
        }

        /**
         * @param bool $visible
         * @param int  $user_id
         */
        public static function set_yooai_fab_visible(bool $visible, int $user_id = 0): void {
            self::save_prefs(['yooai_fab' => $visible], $user_id);
        }

        /**
         * @param bool $visible
         * @param int  $user_id
         */
        public static function set_studio_hub_upgrade_visible(bool $visible, int $user_id = 0): void {
            self::save_prefs(['studio_hub_upgrade' => $visible], $user_id);
        }

        /**
         * Re-show Studio Hub upgrade prompt for the current user (e.g. after switching back to Legacy).
         */
        public static function reset_studio_hub_upgrade_for_current_user(): void {
            self::set_studio_hub_upgrade_visible(true, get_current_user_id());
        }

        /**
         * @param bool $enabled
         * @param int  $user_id
         */
        public static function set_guided_tour_enabled(bool $enabled, int $user_id = 0): void {
            self::save_prefs(['guided_tour' => $enabled], $user_id);
        }

        /**
         * @param array<string, mixed> $raw Form fragment yooadmin_labs_prefs[...].
         * @param int                  $user_id
         * @return array{yooai_fab: bool, studio_hub_upgrade: bool, guided_tour: bool}
         */
        public static function sanitize_from_form(array $raw, int $user_id = 0): array {
            $user_id = $user_id > 0 ? $user_id : get_current_user_id();
            $prefs   = [
                'yooai_fab'          => !empty($raw['yooai_fab']),
                'studio_hub_upgrade' => !empty($raw['studio_hub_upgrade']),
                'guided_tour'        => !empty($raw['guided_tour']),
            ];
            self::save_prefs($prefs, $user_id);
            return $prefs;
        }
    }

    add_action('admin_init', ['YOOAdmin_Labs_Prefs', 'purge_legacy_site_option'], 1);
}
