<?php
/**
 * Security settings tab (Turnstile, rate limit, username enumeration).
 *
 * Included from YOOAdmin_Settings::render_page(); expects $this and login_* variables in scope.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Settings tab partial; variables are include-local.

if (!function_exists('yooadmin_login_security_inner_tab_keys')) {
    /**
     * @return string[]
     */
    function yooadmin_login_security_inner_tab_keys(): array {
        return ['turnstile', 'rate-limit', 'user-enum', 'hidden-login', 'account-emails', 'two-factor'];
    }
}

if (!function_exists('yooadmin_login_security_inner_tab_url')) {
    /**
     * Shareable URL for a Security settings sub-tab.
     */
    function yooadmin_login_security_inner_tab_url(string $inner_key): string {
        $inner_key = sanitize_key($inner_key);
        $url       = add_query_arg(
            ['page' => 'yooadmin-settings', 'tab' => 'login-security'],
            admin_url('admin.php')
        );

        if ($inner_key !== '' && $inner_key !== 'turnstile') {
            $url = add_query_arg('security_tab', $inner_key, $url);
        }

        return $url . '#tab-login-security';
    }
}

if (!function_exists('yooadmin_login_security_active_inner_tab')) {
    function yooadmin_login_security_active_inner_tab(): string {
        $default = 'turnstile';
        $allowed = yooadmin_login_security_inner_tab_keys();

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!isset($_GET['security_tab'])) {
            return $default;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $candidate = sanitize_key(wp_unslash((string) $_GET['security_tab']));

        return in_array($candidate, $allowed, true) ? $candidate : $default;
    }
}

/** @var YOOAdmin_Settings $this */

$security_inner_tabs = [
    'turnstile'    => __('Turnstile', 'yooadmin'),
    'rate-limit'   => __('Rate limiting', 'yooadmin'),
    'user-enum'    => __('Username protection', 'yooadmin'),
    'hidden-login'   => __('Login URL', 'yooadmin'),
    'account-emails' => __('Account emails', 'yooadmin'),
    'two-factor'     => __('Two-Factor', 'yooadmin'),
];
$security_inner_active = yooadmin_login_security_active_inner_tab();
?>
                        <section class="yp-tab-panel" id="tab-login-security" data-panel="login-security">
                            <div class="yp-tabs yp-tabs--security-inner" data-yp-security-inner-tabs>
                                <div class="yp-tab-nav" role="tablist" aria-label="<?php esc_attr_e('Security settings sections', 'yooadmin'); ?>">
                                    <?php foreach ($security_inner_tabs as $inner_key => $inner_label) :
                                        $inner_is_active = ($security_inner_active === $inner_key);
                                        ?>
                                        <a
                                            href="<?php echo esc_url(yooadmin_login_security_inner_tab_url($inner_key)); ?>"
                                            class="yp-tab<?php echo $inner_is_active ? ' is-active' : ''; ?>"
                                            role="tab"
                                            aria-selected="<?php echo $inner_is_active ? 'true' : 'false'; ?>"
                                            data-security-inner="<?php echo esc_attr($inner_key); ?>"
                                            id="yp-security-inner-tab-<?php echo esc_attr($inner_key); ?>"
                                            aria-controls="yooadmin-security-panel-<?php echo esc_attr($inner_key); ?>"
                                        ><?php echo esc_html($inner_label); ?></a>
                                    <?php endforeach; ?>
                                </div>

                                <div class="yp-tab-panels yooadmin-security-inner-panels">
                                <div class="yp-tab-panel yooadmin-security-inner-panel<?php echo $security_inner_active === 'turnstile' ? ' is-active' : ''; ?>" data-security-inner-panel="turnstile" id="yooadmin-security-panel-turnstile" role="tabpanel" aria-labelledby="yp-security-inner-tab-turnstile"<?php echo $security_inner_active !== 'turnstile' ? ' hidden' : ''; ?>>
                                    <div class="yooadmin-security-panel-content">
                                        <?php
                                        $turnstile_gap = isset($login_turnstile_keys_gap) ? (string) $login_turnstile_keys_gap : 'both';
                                        $turnstile_keys_complete = !empty($login_turnstile_keys_complete);
                                        ?>
                                        <div class="yooadmin-login-security-intro">
                                            <p class="yp-help yooadmin-security-card__lead yooadmin-login-security-intro__text"><?php
                                                echo esc_html(function_exists('yooadmin_login_security_turnstile_intro') ? yooadmin_login_security_turnstile_intro() : __('Cloudflare Turnstile on wp-login.php and the YOOAdmin login page when enabled and keys are saved.', 'yooadmin'));
                                                ?></p>
                                            <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft yooadmin-login-turnstile-info-btn" id="yooadmin-login-turnstile-info-open" aria-haspopup="dialog" aria-controls="yooadmin-login-turnstile-info-modal">
                                                <span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
                                                <?php esc_html_e('How to get keys', 'yooadmin'); ?>
                                            </button>
                                        </div>
                                        <table class="form-table yooadmin-security-toggle-table"><tbody>
                                            <tr class="yooadmin-security-master-toggle-row">
                                                <th scope="row">
                                                    <div class="yp-th-content">
                                                        <span class="dashicons dashicons-shield yp-th-icon"></span>
                                                        <span><?php esc_html_e('Login security', 'yooadmin'); ?></span>
                                                        <span class="yp-help-icon">
                                                            <span class="dashicons dashicons-editor-help"></span>
                                                            <span class="yp-tooltip"><?php esc_html_e('When enabled, visitors must pass a Turnstile challenge before signing in on wp-login.php or the YOOAdmin login page (and optionally before requesting a password reset).', 'yooadmin'); ?></span>
                                                        </span>
                                                    </div>
                                                </th>
                                                <td>
                                                    <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_security_enabled]" value="0">
                                                    <?php
                                                    $sec_desc = __('Uses Cloudflare Turnstile on wp-login.php and the YOOAdmin login page when keys are saved.', 'yooadmin');
                                                    $sec_on = __('Enable login security (Turnstile)', 'yooadmin');
                                                    $sec_off = __('Login security off', 'yooadmin');
                                                    $sec_toggle = $this->render_toggle_field(
                                                        'login_security_enabled',
                                                        $login_security_enabled ? $sec_on : $sec_off,
                                                        $sec_desc,
                                                        $login_security_enabled,
                                                        'login_security_enabled',
                                                        $this->opt_options,
                                                        false
                                                    );
                                                    echo wp_kses($sec_toggle['toggle'], $this->get_toggle_allowed_html());
                                                    ?>
                                                </td>
                                            </tr>
                                        </tbody></table>

                                        <div id="yooadmin-login-security-body" class="yooadmin-login-security-body">
                                            <?php
                                            if (!$turnstile_keys_complete) :
                                                $incomplete_msg = __('Turnstile is not active. Add both the site key and secret key before enabling login security.', 'yooadmin');
                                                if ($turnstile_gap === 'site') {
                                                    $incomplete_msg = __('Turnstile is not active. Add the site key and save — the secret key alone is not enough.', 'yooadmin');
                                                } elseif ($turnstile_gap === 'secret') {
                                                    $incomplete_msg = __('Turnstile is not active. Add the secret key and save.', 'yooadmin');
                                                }
                                                ?>
                                            <div
                                                class="yooadmin-login-turnstile-incomplete-notice yp-settings-callout yp-settings-callout--turnstile-gap"
                                                id="yooadmin-login-turnstile-incomplete-notice"
                                                role="alert"
                                                data-yp-notice-intent="operational"
                                                dir="auto"
                                            >
                                                <p class="yooadmin-login-turnstile-incomplete-notice__title"><?php esc_html_e('Turnstile keys incomplete', 'yooadmin'); ?></p>
                                                <p class="yooadmin-login-turnstile-incomplete-notice__text"><?php echo esc_html($incomplete_msg); ?></p>
                                                <?php if (!empty($login_security_stored_enabled)) : ?>
                                                    <p class="yooadmin-login-turnstile-incomplete-notice__text"><?php esc_html_e('Login security was turned off automatically because keys are incomplete.', 'yooadmin'); ?></p>
                                                <?php endif; ?>
                                            </div>
                                            <?php endif; ?>
                                            <table class="form-table yooadmin-login-security-keys"><tbody>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-admin-network yp-th-icon"></span>
                                                            <span><?php esc_html_e('Turnstile site key', 'yooadmin'); ?></span>
                                                            <span class="yp-help-icon">
                                                                <span class="dashicons dashicons-editor-help"></span>
                                                                <span class="yp-tooltip"><?php esc_html_e('Public site key from Cloudflare Turnstile (shown in the widget on your login page).', 'yooadmin'); ?></span>
                                                            </span>
                                                        </div>
                                                    </th>
                                                    <td>
                                                        <p class="ylp-field ylp-field--with-icon ylp-field--settings">
                                                            <span class="ylp-field__icon dashicons dashicons-admin-network" aria-hidden="true"></span>
                                                            <input type="text" class="ylp-input ylp-input--with-icon ylp-input--settings" name="<?php echo esc_attr($this->opt_options); ?>[login_turnstile_site_key]" id="yooadmin-login-turnstile-site-key" value="<?php echo esc_attr($login_turnstile_site_key); ?>" autocomplete="off" spellcheck="false" placeholder="<?php esc_attr_e('Site key', 'yooadmin'); ?>" />
                                                        </p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-privacy yp-th-icon"></span>
                                                            <span><?php esc_html_e('Turnstile secret key', 'yooadmin'); ?></span>
                                                            <span class="yp-help-icon">
                                                                <span class="dashicons dashicons-editor-help"></span>
                                                                <span class="yp-tooltip"><?php esc_html_e('Secret key used server-side to verify challenges. Never share it publicly.', 'yooadmin'); ?></span>
                                                            </span>
                                                        </div>
                                                    </th>
                                                    <td>
                                                        <p class="ylp-field ylp-field--with-icon ylp-field--settings">
                                                            <span class="ylp-field__icon dashicons dashicons-lock" aria-hidden="true"></span>
                                                            <input type="password" class="ylp-input ylp-input--with-icon ylp-input--settings" name="<?php echo esc_attr($this->opt_options); ?>[login_turnstile_secret_key]" id="yooadmin-login-turnstile-secret-key" value="" autocomplete="new-password" spellcheck="false" placeholder="<?php echo $login_turnstile_has_secret ? esc_attr__('Saved — enter a new key to replace', 'yooadmin') : esc_attr__('Secret key', 'yooadmin'); ?>" />
                                                        </p>
                                                        <?php if ($login_turnstile_has_secret && !empty($login_turnstile_keys_complete)) : ?>
                                                            <p class="description yooadmin-login-security-field-note"><?php esc_html_e('A secret key is already saved. Leave this field empty to keep it.', 'yooadmin'); ?></p>
                                                        <?php elseif ($login_turnstile_has_secret && empty($login_turnstile_keys_complete)) : ?>
                                                            <p class="description yooadmin-login-security-field-note yooadmin-login-security-field-note--warning"><?php esc_html_e('Secret key is stored, but Turnstile cannot run until you also add the site key.', 'yooadmin'); ?></p>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                            <div id="yooadmin-login-security-options" class="yooadmin-login-security-options<?php echo $login_security_enabled ? '' : ' yooadmin-security-panel-body--disabled'; ?>">
                                            <table class="form-table"><tbody>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-email yp-th-icon"></span>
                                                            <span><?php esc_html_e('Protect password reset', 'yooadmin'); ?></span>
                                                        </div>
                                                    </th>
                                                    <td>
                                                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_turnstile_protect_lostpassword]" value="0">
                                                        <?php
                                                        $lp_desc = __('Also require Turnstile on the “Forgot password?” form.', 'yooadmin');
                                                        $lp_on = __('Require Turnstile on password reset requests', 'yooadmin');
                                                        $lp_off = __('Sign-in only', 'yooadmin');
                                                        $lp_toggle = $this->render_toggle_field(
                                                            'login_turnstile_protect_lostpassword',
                                                            $login_turnstile_protect_lostpassword ? $lp_on : $lp_off,
                                                            $lp_desc,
                                                            $login_turnstile_protect_lostpassword,
                                                            'login_turnstile_protect_lostpassword',
                                                            $this->opt_options,
                                                            false
                                                        );
                                                        echo wp_kses($lp_toggle['toggle'], $this->get_toggle_allowed_html());
                                                        ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-visibility yp-th-icon"></span>
                                                            <span><?php esc_html_e('Widget display', 'yooadmin'); ?></span>
                                                            <span class="yp-help-icon">
                                                                <span class="dashicons dashicons-editor-help"></span>
                                                                <span class="yp-tooltip"><?php esc_html_e('Minimal and Compact show a status line and reveal the Cloudflare challenge only when needed (for example VPN or suspicious traffic). Use Standard to always show the full widget.', 'yooadmin'); ?></span>
                                                            </span>
                                                        </div>
                                                    </th>
                                                    <td>
                                                        <div class="yp-select-wrap yp-select-wrap--security">
                                                            <select class="yp-select" name="<?php echo esc_attr($this->opt_options); ?>[login_turnstile_display]" id="yooadmin-login-turnstile-display">
                                                                <option value="minimal" <?php selected($login_turnstile_display, 'minimal'); ?>><?php esc_html_e('Minimal (recommended)', 'yooadmin'); ?></option>
                                                                <option value="compact" <?php selected($login_turnstile_display, 'compact'); ?>><?php esc_html_e('Compact', 'yooadmin'); ?></option>
                                                                <option value="standard" <?php selected($login_turnstile_display, 'standard'); ?>><?php esc_html_e('Standard Cloudflare box', 'yooadmin'); ?></option>
                                                            </select>
                                                        </div>
                                                        <p class="description yooadmin-login-security-field-note"><?php esc_html_e('For the smallest footprint, create a Managed or Invisible widget in Cloudflare and choose Minimal here.', 'yooadmin'); ?></p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-admin-site yp-th-icon"></span>
                                                            <span><?php esc_html_e('Apply to', 'yooadmin'); ?></span>
                                                            <span class="yp-help-icon">
                                                                <span class="dashicons dashicons-editor-help"></span>
                                                                <span class="yp-tooltip"><?php esc_html_e('Choose which login screens show the Turnstile challenge. Add both keys and enable login security.', 'yooadmin'); ?></span>
                                                            </span>
                                                        </div>
                                                    </th>
                                                    <td class="yooadmin-login-turnstile-scopes">
                                                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_turnstile_wp_login]" value="0">
                                                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_turnstile_standalone]" value="0">
                                                        <?php
                                                        $ts_wp_toggle = $this->render_toggle_field(
                                                            'login_turnstile_wp_login',
                                                            $login_turnstile_wp_login
                                                                ? __('Use Turnstile on wp-login.php', 'yooadmin')
                                                                : __('Do not use Turnstile on wp-login.php', 'yooadmin'),
                                                            __('Native WordPress login screen (wp-login.php).', 'yooadmin'),
                                                            $login_turnstile_wp_login,
                                                            'login_turnstile_wp_login',
                                                            $this->opt_options,
                                                            false
                                                        );
                                                        echo wp_kses($ts_wp_toggle['toggle'], $this->get_toggle_allowed_html());
                                                        echo '<div class="yooadmin-login-rate-limit-scopes__gap"></div>';
                                                        $ts_sl_toggle = $this->render_toggle_field(
                                                            'login_turnstile_standalone',
                                                            $login_turnstile_standalone
                                                                ? __('Use Turnstile on YOOAdmin login page', 'yooadmin')
                                                                : __('Do not use Turnstile on YOOAdmin login page', 'yooadmin'),
                                                            __('Custom login page when Login Page Experience is enabled.', 'yooadmin'),
                                                            $login_turnstile_standalone,
                                                            'login_turnstile_standalone',
                                                            $this->opt_options,
                                                            false
                                                        );
                                                        echo wp_kses($ts_sl_toggle['toggle'], $this->get_toggle_allowed_html());
                                                        echo '<div class="yooadmin-login-rate-limit-scopes__gap"></div>';
                                                        $ts_comments_toggle = $this->render_toggle_field(
                                                            'login_turnstile_comments',
                                                            $login_turnstile_comments
                                                                ? __('Use Turnstile on comment forms', 'yooadmin')
                                                                : __('Do not use Turnstile on comment forms', 'yooadmin'),
                                                            __('Frontend post comment forms on your site.', 'yooadmin'),
                                                            $login_turnstile_comments,
                                                            'login_turnstile_comments',
                                                            $this->opt_options,
                                                            false
                                                        );
                                                        echo wp_kses($ts_comments_toggle['toggle'], $this->get_toggle_allowed_html());
                                                        echo '<div class="yooadmin-login-rate-limit-scopes__gap"></div>';
                                                        $ts_comments_skip_toggle = $this->render_toggle_field(
                                                            'login_turnstile_comments_skip_logged_in',
                                                            $login_turnstile_comments_skip_logged_in
                                                                ? __('Skip comment security for logged-in users', 'yooadmin')
                                                                : __('Apply comment security to logged-in users too', 'yooadmin'),
                                                            __('Logged-in visitors can usually comment without an extra challenge.', 'yooadmin'),
                                                            $login_turnstile_comments_skip_logged_in,
                                                            'login_turnstile_comments_skip_logged_in',
                                                            $this->opt_options,
                                                            false
                                                        );
                                                        echo wp_kses($ts_comments_skip_toggle['toggle'], $this->get_toggle_allowed_html());
                                                        ?>
                                                        <p class="description yooadmin-login-security-field-note"><?php esc_html_e('When Turnstile is enabled for wp-login.php, visitors see a YOOAdmin security credit in the page footer.', 'yooadmin'); ?></p>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="yp-tab-panel yooadmin-security-inner-panel<?php echo $security_inner_active === 'rate-limit' ? ' is-active' : ''; ?>" data-security-inner-panel="rate-limit" id="yooadmin-security-panel-rate-limit" role="tabpanel" aria-labelledby="yp-security-inner-tab-rate-limit"<?php echo $security_inner_active !== 'rate-limit' ? ' hidden' : ''; ?>>
                                    <div class="yooadmin-security-panel-content">
                                        <p class="yp-help yooadmin-security-card__lead"><?php esc_html_e('Block repeated failed sign-in and password-reset attempts per IP (and username where applicable). Uses the same counters on wp-login.php and the YOOAdmin login page when both scopes are enabled.', 'yooadmin'); ?></p>
                                        <table class="form-table yooadmin-security-toggle-table"><tbody>
                                            <tr class="yooadmin-security-master-toggle-row">
                                                <th scope="row">
                                                    <div class="yp-th-content">
                                                        <span class="dashicons dashicons-performance yp-th-icon"></span>
                                                        <span><?php esc_html_e('Rate limiting', 'yooadmin'); ?></span>
                                                        <span class="yp-help-icon">
                                                            <span class="dashicons dashicons-editor-help"></span>
                                                            <span class="yp-tooltip"><?php esc_html_e('When enabled, visitors who exceed the limits below must wait before trying again.', 'yooadmin'); ?></span>
                                                        </span>
                                                    </div>
                                                </th>
                                                <td>
                                                    <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_enabled]" value="0">
                                                    <?php
                                                    $rl_desc = __('Limits failed login and password-reset attempts.', 'yooadmin');
                                                    $rl_on = __('Enable login rate limiting', 'yooadmin');
                                                    $rl_off = __('Login rate limiting off', 'yooadmin');
                                                    $rl_toggle = $this->render_toggle_field(
                                                        'login_rate_limit_enabled',
                                                        $login_rate_limit_enabled ? $rl_on : $rl_off,
                                                        $rl_desc,
                                                        $login_rate_limit_enabled,
                                                        'login_rate_limit_enabled',
                                                        $this->opt_options,
                                                        false
                                                    );
                                                    echo wp_kses($rl_toggle['toggle'], $this->get_toggle_allowed_html());
                                                    ?>
                                                </td>
                                            </tr>
                                        </tbody></table>
                                        <div class="yooadmin-login-rate-limit-body<?php echo $login_rate_limit_enabled ? '' : ' yooadmin-security-panel-body--disabled'; ?>">
                                            <table class="form-table"><tbody>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-admin-site yp-th-icon"></span>
                                                            <span><?php esc_html_e('Apply to', 'yooadmin'); ?></span>
                                                        </div>
                                                    </th>
                                                    <td class="yooadmin-login-rate-limit-scopes">
                                                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_wp_login]" value="0">
                                                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_standalone]" value="0">
                                                        <?php
                                                        $wp_login_toggle = $this->render_toggle_field(
                                                            'login_rate_limit_wp_login',
                                                            $login_rate_limit_wp_login
                                                                ? __('Limit attempts on wp-login.php', 'yooadmin')
                                                                : __('Do not limit wp-login.php', 'yooadmin'),
                                                            __('WordPress default login screen.', 'yooadmin'),
                                                            $login_rate_limit_wp_login,
                                                            'login_rate_limit_wp_login',
                                                            $this->opt_options,
                                                            false
                                                        );
                                                        echo wp_kses($wp_login_toggle['toggle'], $this->get_toggle_allowed_html());
                                                        echo '<div class="yooadmin-login-rate-limit-scopes__gap"></div>';
                                                        $standalone_toggle = $this->render_toggle_field(
                                                            'login_rate_limit_standalone',
                                                            $login_rate_limit_standalone
                                                                ? __('Limit attempts on YOOAdmin login page', 'yooadmin')
                                                                : __('Do not limit YOOAdmin login page', 'yooadmin'),
                                                            __('Custom login page when Login Page Experience is enabled.', 'yooadmin'),
                                                            $login_rate_limit_standalone,
                                                            'login_rate_limit_standalone',
                                                            $this->opt_options,
                                                            false
                                                        );
                                                        echo wp_kses($standalone_toggle['toggle'], $this->get_toggle_allowed_html());
                                                        echo '<div class="yooadmin-login-rate-limit-scopes__gap"></div>';
                                                        $comments_rl_toggle = $this->render_toggle_field(
                                                            'login_rate_limit_comments',
                                                            $login_rate_limit_comments
                                                                ? __('Limit comment submissions', 'yooadmin')
                                                                : __('Do not limit comment submissions', 'yooadmin'),
                                                            __('Frontend post comment forms (per IP).', 'yooadmin'),
                                                            $login_rate_limit_comments,
                                                            'login_rate_limit_comments',
                                                            $this->opt_options,
                                                            false
                                                        );
                                                        echo wp_kses($comments_rl_toggle['toggle'], $this->get_toggle_allowed_html());
                                                        ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-lock yp-th-icon"></span>
                                                            <span><?php esc_html_e('Sign-in attempts', 'yooadmin'); ?></span>
                                                        </div>
                                                    </th>
                                                    <td class="yooadmin-login-rate-limit-limits">
                                                        <label class="screen-reader-text" for="login_rate_limit_login_max"><?php esc_html_e('Max failed sign-in attempts', 'yooadmin'); ?></label>
                                                        <input type="number" class="ylp-input ylp-input--settings ylp-input--narrow" min="1" max="100" step="1" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_login_max]" id="login_rate_limit_login_max" value="<?php echo esc_attr((string) $login_rate_limit_login_max); ?>" />
                                                        <span class="yooadmin-login-rate-limit-limits__per"><?php esc_html_e('failures per', 'yooadmin'); ?></span>
                                                        <select class="yp-select yooadmin-login-rate-limit-window" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_login_window]" id="login_rate_limit_login_window">
                                                            <?php foreach ([5, 10, 15, 30, 60, 120] as $mins) : ?>
                                                                <option value="<?php echo esc_attr((string) $mins); ?>" <?php selected($login_rate_limit_login_window_min, $mins); ?>><?php echo esc_html(sprintf(/* translators: %d: minutes */ _n('%d minute', '%d minutes', $mins, 'yooadmin'), $mins)); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-email yp-th-icon"></span>
                                                            <span><?php esc_html_e('Forgot password', 'yooadmin'); ?></span>
                                                        </div>
                                                    </th>
                                                    <td class="yooadmin-login-rate-limit-limits">
                                                        <label class="screen-reader-text" for="login_rate_limit_lostpassword_max"><?php esc_html_e('Max forgot-password attempts', 'yooadmin'); ?></label>
                                                        <input type="number" class="ylp-input ylp-input--settings ylp-input--narrow" min="1" max="100" step="1" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_lostpassword_max]" id="login_rate_limit_lostpassword_max" value="<?php echo esc_attr((string) $login_rate_limit_lostpassword_max); ?>" />
                                                        <span class="yooadmin-login-rate-limit-limits__per"><?php esc_html_e('failures per', 'yooadmin'); ?></span>
                                                        <select class="yp-select yooadmin-login-rate-limit-window" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_lostpassword_window]" id="login_rate_limit_lostpassword_window">
                                                            <?php foreach ([5, 10, 15, 30, 60, 120] as $mins) : ?>
                                                                <option value="<?php echo esc_attr((string) $mins); ?>" <?php selected($login_rate_limit_lostpassword_window_min, $mins); ?>><?php echo esc_html(sprintf(/* translators: %d: minutes */ _n('%d minute', '%d minutes', $mins, 'yooadmin'), $mins)); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-update yp-th-icon"></span>
                                                            <span><?php esc_html_e('Reset password', 'yooadmin'); ?></span>
                                                        </div>
                                                    </th>
                                                    <td class="yooadmin-login-rate-limit-limits">
                                                        <label class="screen-reader-text" for="login_rate_limit_resetpass_max"><?php esc_html_e('Max reset-password attempts', 'yooadmin'); ?></label>
                                                        <input type="number" class="ylp-input ylp-input--settings ylp-input--narrow" min="1" max="100" step="1" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_resetpass_max]" id="login_rate_limit_resetpass_max" value="<?php echo esc_attr((string) $login_rate_limit_resetpass_max); ?>" />
                                                        <span class="yooadmin-login-rate-limit-limits__per"><?php esc_html_e('failures per', 'yooadmin'); ?></span>
                                                        <select class="yp-select yooadmin-login-rate-limit-window" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_resetpass_window]" id="login_rate_limit_resetpass_window">
                                                            <?php foreach ([5, 10, 15, 30, 60, 120] as $mins) : ?>
                                                                <option value="<?php echo esc_attr((string) $mins); ?>" <?php selected($login_rate_limit_resetpass_window_min, $mins); ?>><?php echo esc_html(sprintf(/* translators: %d: minutes */ _n('%d minute', '%d minutes', $mins, 'yooadmin'), $mins)); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-admin-comments yp-th-icon"></span>
                                                            <span><?php esc_html_e('Comment submissions', 'yooadmin'); ?></span>
                                                        </div>
                                                    </th>
                                                    <td class="yooadmin-login-rate-limit-limits">
                                                        <label class="screen-reader-text" for="login_rate_limit_comments_max"><?php esc_html_e('Max comment submissions', 'yooadmin'); ?></label>
                                                        <input type="number" class="ylp-input ylp-input--settings ylp-input--narrow" min="1" max="100" step="1" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_comments_max]" id="login_rate_limit_comments_max" value="<?php echo esc_attr((string) $login_rate_limit_comments_max); ?>" />
                                                        <span class="yooadmin-login-rate-limit-limits__per"><?php esc_html_e('submissions per', 'yooadmin'); ?></span>
                                                        <select class="yp-select yooadmin-login-rate-limit-window" name="<?php echo esc_attr($this->opt_options); ?>[login_rate_limit_comments_window]" id="login_rate_limit_comments_window">
                                                            <?php foreach ([5, 10, 15, 30, 60, 120] as $mins) : ?>
                                                                <option value="<?php echo esc_attr((string) $mins); ?>" <?php selected($login_rate_limit_comments_window_min, $mins); ?>><?php echo esc_html(sprintf(/* translators: %d: minutes */ _n('%d minute', '%d minutes', $mins, 'yooadmin'), $mins)); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        </div>
                                    </div>
                                </div>

                                <div class="yp-tab-panel yooadmin-security-inner-panel<?php echo $security_inner_active === 'user-enum' ? ' is-active' : ''; ?>" data-security-inner-panel="user-enum" id="yooadmin-security-panel-user-enum" role="tabpanel" aria-labelledby="yp-security-inner-tab-user-enum"<?php echo $security_inner_active !== 'user-enum' ? ' hidden' : ''; ?>>
                                    <div class="yooadmin-security-panel-content yooadmin-user-enum-panel">
                                        <div class="yooadmin-user-enum-panel__layout">
                                        <div class="yooadmin-user-enum-panel__settings">
                                        <p class="yp-help yooadmin-security-card__lead"><?php esc_html_e('Prevents exposing usernames via the REST API and public author pages, making it harder for bots to harvest account names and target them with sign-in or password-reset attempts. Does not affect access for logged-in users or the editor.', 'yooadmin'); ?></p>
                                        <table class="form-table yooadmin-security-toggle-table"><tbody>
                                            <tr class="yooadmin-security-master-toggle-row">
                                                <th scope="row">
                                                    <div class="yp-th-content">
                                                        <span class="dashicons dashicons-hidden yp-th-icon"></span>
                                                        <span><?php esc_html_e('Prevent username enumeration', 'yooadmin'); ?></span>
                                                        <span class="yp-help-icon">
                                                            <span class="dashicons dashicons-editor-help"></span>
                                                            <span class="yp-tooltip"><?php esc_html_e('Blocks /wp-json/wp/v2/users for guests, stops ?author= probes, and controls public author archive pages.', 'yooadmin'); ?></span>
                                                        </span>
                                                    </div>
                                                </th>
                                                <td>
                                                    <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_prevent_user_enumeration]" value="0">
                                                    <?php
                                                    $enum_desc = __('Reduces exposure of usernames and author slugs to visitors who are not logged in.', 'yooadmin');
                                                    $enum_on = __('Prevent username enumeration', 'yooadmin');
                                                    $enum_off = __('Username enumeration protection off', 'yooadmin');
                                                    $enum_toggle = $this->render_toggle_field(
                                                        'login_prevent_user_enumeration',
                                                        $login_prevent_user_enumeration ? $enum_on : $enum_off,
                                                        $enum_desc,
                                                        $login_prevent_user_enumeration,
                                                        'login_prevent_user_enumeration',
                                                        $this->opt_options,
                                                        false
                                                    );
                                                    echo wp_kses($enum_toggle['toggle'], $this->get_toggle_allowed_html());
                                                    ?>
                                                </td>
                                            </tr>
                                        </tbody></table>
                                        <div class="yooadmin-login-user-enum-body<?php echo $login_prevent_user_enumeration ? '' : ' yooadmin-security-panel-body--disabled'; ?>">
                                            <table class="form-table"><tbody>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-admin-users yp-th-icon"></span>
                                                            <span><?php esc_html_e('Author archives', 'yooadmin'); ?></span>
                                                            <span class="yp-help-icon">
                                                                <span class="dashicons dashicons-editor-help"></span>
                                                                <span class="yp-tooltip"><?php esc_html_e('How to handle /author/username/ URLs for visitors when enumeration protection is enabled.', 'yooadmin'); ?></span>
                                                            </span>
                                                        </div>
                                                    </th>
                                                    <td>
                                                        <div class="yp-select-wrap yp-select-wrap--security">
                                                            <select class="yp-select" name="<?php echo esc_attr($this->opt_options); ?>[login_user_enum_author_archives]" id="yooadmin-login-user-enum-author-archives">
                                                                <option value="redirect_home" <?php selected($login_user_enum_author_archives, 'redirect_home'); ?>><?php esc_html_e('Redirect to homepage', 'yooadmin'); ?></option>
                                                                <option value="disable_404" <?php selected($login_user_enum_author_archives, 'disable_404'); ?>><?php esc_html_e('Disable (show 404)', 'yooadmin'); ?></option>
                                                            </select>
                                                        </div>
                                                        <p class="description yooadmin-login-security-field-note"><?php esc_html_e('Also applies to ?author= probes (any value). Redirect sends visitors to the homepage; 404 returns a not-found response.', 'yooadmin'); ?></p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-rss yp-th-icon"></span>
                                                            <span><?php esc_html_e('RSS feeds', 'yooadmin'); ?></span>
                                                            <span class="yp-help-icon">
                                                                <span class="dashicons dashicons-editor-help"></span>
                                                                <span class="yp-tooltip"><?php esc_html_e('Removes author names from post and comment RSS/Atom feeds (dc:creator and comment author).', 'yooadmin'); ?></span>
                                                            </span>
                                                        </div>
                                                    </th>
                                                    <td>
                                                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_user_enum_hide_rss_author]" value="0">
                                                        <?php
                                                        $rss_desc = __('Stops feed readers from listing WordPress usernames via author fields.', 'yooadmin');
                                                        $rss_on = __('Hide author names in RSS', 'yooadmin');
                                                        $rss_off = __('Show author names in RSS feeds', 'yooadmin');
                                                        $rss_toggle = $this->render_toggle_field(
                                                            'login_user_enum_hide_rss_author',
                                                            $login_user_enum_hide_rss_author ? $rss_on : $rss_off,
                                                            $rss_desc,
                                                            $login_user_enum_hide_rss_author,
                                                            'login_user_enum_hide_rss_author',
                                                            $this->opt_options,
                                                            false
                                                        );
                                                        echo wp_kses($rss_toggle['toggle'], $this->get_toggle_allowed_html());
                                                        ?>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        </div>
                                        </div>

                                        <?php
                                        $enum_stats_total = isset($login_user_enum_stats['total']) ? (int) $login_user_enum_stats['total'] : 0;
                                        $enum_stats_by_type = isset($login_user_enum_stats['by_type']) && is_array($login_user_enum_stats['by_type'])
                                            ? $login_user_enum_stats['by_type']
                                            : [];
                                        $enum_stats_types = ['rest_users', 'author_query', 'author_archive'];
                                        ?>
                                        <div class="yooadmin-user-enum-stats" id="yooadmin-user-enum-stats">
                                            <div class="yooadmin-user-enum-stats__layout">
                                                <aside class="yooadmin-user-enum-stats__aside" aria-label="<?php esc_attr_e('Blocked attempt breakdown', 'yooadmin'); ?>">
                                                    <ul class="yooadmin-user-enum-stats__breakdown" id="yooadmin-user-enum-stats-breakdown">
                                                        <?php foreach ($enum_stats_types as $enum_type) :
                                                            $enum_type_count = isset($enum_stats_by_type[ $enum_type ]) ? (int) $enum_stats_by_type[ $enum_type ] : 0;
                                                            ?>
                                                        <li class="yooadmin-user-enum-stats__breakdown-item" data-enum-type="<?php echo esc_attr($enum_type); ?>">
                                                            <span class="yooadmin-user-enum-stats__breakdown-label"><?php echo esc_html(function_exists('yooadmin_user_enum_stats_type_label') ? yooadmin_user_enum_stats_type_label($enum_type) : $enum_type); ?></span>
                                                            <span class="yooadmin-user-enum-stats__breakdown-count"><?php echo esc_html(number_format_i18n($enum_type_count)); ?></span>
                                                        </li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </aside>
                                                <div class="yooadmin-user-enum-stats__main">
                                                    <div class="yooadmin-user-enum-stats__head">
                                                        <div class="yooadmin-user-enum-stats__metric">
                                                            <span class="dashicons dashicons-shield-alt" aria-hidden="true"></span>
                                                            <div class="yooadmin-user-enum-stats__metric-text">
                                                                <span class="yooadmin-user-enum-stats__label"><?php esc_html_e('Blocked discovery attempts', 'yooadmin'); ?></span>
                                                                <strong class="yooadmin-user-enum-stats__count" id="yooadmin-user-enum-blocked-count"><?php echo esc_html(number_format_i18n($enum_stats_total)); ?></strong>
                                                            </div>
                                                        </div>
                                                        <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft yooadmin-user-enum-stats__clear" id="yooadmin-user-enum-clear-stats" data-nonce="<?php echo esc_attr(wp_create_nonce('yooadmin_user_enum_stats')); ?>" <?php disabled($enum_stats_total < 1); ?>>
                                                            <span class="dashicons dashicons-trash" aria-hidden="true"></span>
                                                            <?php esc_html_e('Clear counter', 'yooadmin'); ?>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="yp-tab-panel yooadmin-security-inner-panel<?php echo $security_inner_active === 'hidden-login' ? ' is-active' : ''; ?>" data-security-inner-panel="hidden-login" id="yooadmin-security-panel-hidden-login" role="tabpanel" aria-labelledby="yp-security-inner-tab-hidden-login"<?php echo $security_inner_active !== 'hidden-login' ? ' hidden' : ''; ?>>
                                    <div class="yooadmin-security-panel-content">
                                        <p class="yp-help yooadmin-security-card__lead"><?php esc_html_e('Replace WordPress’s default login URLs with a custom login address to help reduce bot activity and automated login attempts while keeping normal admin access unchanged.', 'yooadmin'); ?></p>
                                        <table class="form-table yooadmin-security-toggle-table"><tbody>
                                            <tr class="yooadmin-security-master-toggle-row">
                                                <th scope="row">
                                                    <div class="yp-th-content">
                                                        <span class="dashicons dashicons-lock yp-th-icon"></span>
                                                        <span><?php esc_html_e('Hide default login URLs', 'yooadmin'); ?></span>
                                                        <span class="yp-help-icon">
                                                            <span class="dashicons dashicons-editor-help"></span>
                                                            <span class="yp-tooltip"><?php esc_html_e('Hides wp-login.php, /yooadmin-login/, and wp-admin for guests. Old URLs show a branded site error page—not the WordPress admin login screen.', 'yooadmin'); ?></span>
                                                        </span>
                                                    </div>
                                                </th>
                                                <td>
                                                    <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_hidden_entry_enabled]" value="0">
                                                    <?php
                                                    $hidden_desc = __('Default login addresses are hidden; use your custom login address below to sign in.', 'yooadmin');
                                                    $hidden_on   = __('Hide default login URLs', 'yooadmin');
                                                    $hidden_off  = __('Default login URLs visible', 'yooadmin');
                                                    $hidden_toggle = $this->render_toggle_field(
                                                        'login_hidden_entry_enabled',
                                                        $login_hidden_entry_enabled ? $hidden_on : $hidden_off,
                                                        $hidden_desc,
                                                        $login_hidden_entry_enabled,
                                                        'login_hidden_entry_enabled',
                                                        $this->opt_options,
                                                        false
                                                    );
                                                    echo wp_kses($hidden_toggle['toggle'], $this->get_toggle_allowed_html());
                                                    ?>
                                                </td>
                                            </tr>
                                        </tbody></table>
                                        <div class="yooadmin-login-hidden-entry-body<?php echo $login_hidden_entry_enabled ? '' : ' yooadmin-security-panel-body--disabled'; ?>">
                                            <table class="form-table"><tbody>
                                                <tr>
                                                    <th scope="row">
                                                        <div class="yp-th-content">
                                                            <span class="dashicons dashicons-admin-links yp-th-icon"></span>
                                                            <span><?php esc_html_e('Secret login path', 'yooadmin'); ?></span>
                                                            <span class="yp-help-icon">
                                                                <span class="dashicons dashicons-editor-help"></span>
                                                                <span class="yp-tooltip"><?php esc_html_e('Enter only the path name (letters, numbers, and hyphens)—not the full site URL.', 'yooadmin'); ?></span>
                                                            </span>
                                                        </div>
                                                    </th>
                                                    <td>
                                                        <?php
                                                        $hidden_entry_prefix = function_exists('yooadmin_hidden_login_entry_slug_input_prefix')
                                                            ? yooadmin_hidden_login_entry_slug_input_prefix()
                                                            : user_trailingslashit(home_url('/'));
                                                        $hidden_entry_pretty = function_exists('yooadmin_hidden_login_entry_uses_pretty_permalinks')
                                                            && yooadmin_hidden_login_entry_uses_pretty_permalinks();
                                                        ?>
                                                        <div
                                                            class="yooadmin-login-hidden-entry-url-compose"
                                                            dir="ltr"
                                                            data-site-prefix="<?php echo esc_attr($hidden_entry_prefix); ?>"
                                                            data-pretty="<?php echo $hidden_entry_pretty ? '1' : '0'; ?>"
                                                        >
                                                            <span
                                                                class="yooadmin-login-hidden-entry-url-compose__prefix"
                                                                title="<?php echo esc_attr($hidden_entry_prefix); ?>"
                                                                aria-hidden="true"
                                                            ><?php echo esc_html($hidden_entry_prefix); ?></span>
                                                            <?php if (!$hidden_entry_pretty) : ?>
                                                                <span class="yooadmin-login-hidden-entry-url-compose__query" aria-hidden="true">?hl=</span>
                                                            <?php endif; ?>
                                                            <input
                                                                type="text"
                                                                class="yooadmin-login-hidden-entry-url-compose__slug"
                                                                name="<?php echo esc_attr($this->opt_options); ?>[login_hidden_entry_slug]"
                                                                id="yooadmin-login-hidden-entry-slug"
                                                                value="<?php echo esc_attr($login_hidden_entry_slug); ?>"
                                                                autocomplete="off"
                                                                spellcheck="false"
                                                                placeholder="<?php esc_attr_e('e.g. secure-portal', 'yooadmin'); ?>"
                                                                pattern="[a-z0-9-]{3,40}"
                                                            />
                                                            <?php if ($hidden_entry_pretty) : ?>
                                                                <span class="yooadmin-login-hidden-entry-url-compose__suffix" aria-hidden="true">/</span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <?php if ($login_hidden_entry_enabled && $login_hidden_entry_slug !== '') : ?>
                                                            <div class="yooadmin-login-hidden-entry-url-preview">
                                                                <span class="yooadmin-login-hidden-entry-url-preview__label"><?php esc_html_e('Your login URL:', 'yooadmin'); ?></span>
                                                                <span class="yooadmin-login-hidden-entry-url-preview__row">
                                                                    <code id="yooadmin-login-hidden-entry-url-value" class="yooadmin-login-hidden-entry-url-preview__code" dir="ltr"><?php echo esc_html($login_hidden_entry_url); ?></code>
                                                                    <button
                                                                        type="button"
                                                                        class="yooadmin-login-hidden-entry-url-copy"
                                                                        data-copy-url="<?php echo esc_attr($login_hidden_entry_url); ?>"
                                                                        title="<?php esc_attr_e('Copy login URL', 'yooadmin'); ?>"
                                                                        aria-label="<?php esc_attr_e('Copy login URL', 'yooadmin'); ?>"
                                                                    >
                                                                        <span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
                                                                    </button>
                                                                </span>
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        </div>
                                    </div>
                                </div>

                                <?php
                                include __DIR__ . '/settings-account-emails-panel.php';

                                if (class_exists('YOOAdmin_2FA_Core')) {
                                    include dirname(__DIR__) . '/security/two-factor/settings.php';
                                }
                                ?>
                                </div>
                            </div>
                        </section>
