<?php
/**
 * YOOAdmin - Admin permissions helpers
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/** Map minimal capabilities per context. */
function yooadmin_required_cap(string $context): string {
    $map = [
        'dashboard' => 'read',
        'settings'  => 'manage_options',
    ];
    $cap = $map[$context] ?? 'read';
    return (string) apply_filters('yooadmin_required_cap', $cap, $context);
}

/** Convenience checker. */
function yooadmin_current_user_can(string $context): bool {
    return current_user_can(yooadmin_required_cap($context));
}

/** Site-wide YOOAdmin settings (theme colors, quick actions, dashboard redirect, etc.). */
function yooadmin_user_can_manage_site_settings(): bool {
    return yooadmin_current_user_can('settings');
}

/**
 * Logged-in wp-admin user who is not a site settings administrator (e.g. Editor).
 */
function yooadmin_is_site_regular_user(): bool {
    return is_user_logged_in() && !yooadmin_user_can_manage_site_settings();
}

/** Capability for the per-user "My Preferences" admin page. */
function yooadmin_user_preferences_page_capability(): string {
    return (string) apply_filters('yooadmin_user_preferences_page_capability', 'read');
}

/** Whether the current user may open the personal preferences page. */
function yooadmin_user_can_view_my_preferences(): bool {
    if (!is_user_logged_in() || !current_user_can(yooadmin_user_preferences_page_capability())) {
        return false;
    }

    if (yooadmin_user_can_manage_site_settings()) {
        return false;
    }

    return function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();
}

/** Admin URL for site-wide YOOAdmin settings (administrators only). */
function yooadmin_site_settings_admin_url(string $fragment = ''): string {
    $url = admin_url('admin.php?page=yooadmin-settings');
    if ($fragment !== '') {
        $url .= '#' . ltrim($fragment, '#');
    }

    return $url;
}

/** Admin URL for personal YOOAdmin preferences (all admin-area users with read). */
function yooadmin_my_preferences_admin_url(string $fragment = ''): string {
    $url = admin_url('admin.php?page=yooadmin-my-preferences');
    if ($fragment !== '') {
        $url .= '#' . ltrim($fragment, '#');
    }

    return $url;
}

/**
 * Settings shortcut target: site settings for admins, personal preferences for everyone else.
 */
function yooadmin_settings_admin_url(string $fragment = ''): string {
    if (yooadmin_user_can_manage_site_settings()) {
        return yooadmin_site_settings_admin_url($fragment);
    }

    if (!yooadmin_user_can_view_my_preferences()) {
        return function_exists('yooadmin_enable_focus_url')
            ? yooadmin_enable_focus_url()
            : admin_url('admin.php?page=yooadmin-enable-focus');
    }

    $personal_fragment = $fragment;
    if ($fragment === 'tab-notifications') {
        $personal_fragment = 'notifications';
    }

    return yooadmin_my_preferences_admin_url($personal_fragment);
}

/**
 * Whether the notifications bell/dropdown should render for the current user.
 *
 * Per-user notifications (comments, banners, etc.) use the same capability as
 * notification preferences (`read` by default). Site-wide notification settings
 * in YOOAdmin Settings stay admin-only.
 */
function yooadmin_user_can_view_notifications_ui(): bool {
    if (function_exists('yooadmin_is_site_regular_user') && yooadmin_is_site_regular_user()) {
        return (bool) apply_filters('yooadmin_user_can_view_notifications_ui', false);
    }

    $cap = function_exists('yooadmin_notification_preferences_capability')
        ? yooadmin_notification_preferences_capability()
        : 'read';
    $can = is_user_logged_in() && current_user_can($cap);

    return (bool) apply_filters('yooadmin_user_can_view_notifications_ui', $can);
}

/**
 * Required capabilities for a notification source type (any one grants access).
 *
 * @return string[] Empty = no extra restriction beyond optional URL check.
 */
function yooadmin_notification_source_required_caps(string $source_type): array {
    $map = [
        'plugin_updates'    => ['update_plugins', 'activate_plugins'],
        'wordpress_update'  => ['update_core'],
        'theme_updates'     => ['update_themes', 'switch_themes'],
        'comments'          => ['moderate_comments', 'edit_posts'],
        'spam_comments'     => ['moderate_comments'],
        'license'           => [],
        'banner'            => [],
        'banner-conversion' => [],
        'wp_admin_banner'   => [],
    ];

    return $map[ $source_type ] ?? [];
}

/** Whether the current user should see a single notification item. */
function yooadmin_user_can_view_notification_item(array $notification): bool {
    if (!is_user_logged_in()) {
        return false;
    }

    $source_type = isset($notification['source_type']) ? (string) $notification['source_type'] : '';
    $caps        = yooadmin_notification_source_required_caps($source_type);

    if ($caps !== []) {
        foreach ($caps as $cap) {
            if ($cap !== '__deny__' && current_user_can($cap)) {
                return true;
            }
        }

        return false;
    }

    $url = isset($notification['url']) ? trim((string) $notification['url']) : '';
    if ($url === '') {
        return true;
    }

    if (strpos($url, 'page=yooadmin-license') !== false) {
        return true;
    }

    return yooadmin_user_can_access_admin_href($url);
}

/**
 * @param array<int, array<string, mixed>> $items
 * @return array<int, array<string, mixed>>
 */
function yooadmin_filter_notifications_by_user_capability(array $items): array {
    if (!is_user_logged_in()) {
        return [];
    }

    $filtered = [];

    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }

        if (($item['type'] ?? '') === 'group' && isset($item['items']) && is_array($item['items'])) {
            $children = yooadmin_filter_notifications_by_user_capability($item['items']);
            if ($children === []) {
                continue;
            }
            $item['items'] = $children;
            $filtered[]    = $item;
            continue;
        }

        if (yooadmin_user_can_view_notification_item($item)) {
            $filtered[] = $item;
        }
    }

    return array_values($filtered);
}

/**
 * Required capabilities for a notification preference option (any one grants access).
 *
 * @param 'type'|'source'|'email_trigger' $group
 * @return string[]
 */
function yooadmin_notification_preference_item_required_caps(string $group, string $key): array {
    $maps = [
        'type' => [
            'wordpress_core'      => ['update_core'],
            'plugin_updates'      => ['update_plugins', 'activate_plugins'],
            'theme_updates'       => ['update_themes', 'switch_themes'],
            'translation_updates' => ['update_languages', 'update_core'],
            'security'            => ['manage_options'],
            'backup'              => ['manage_options'],
            'performance'         => ['manage_options'],
            'user_activity'       => ['list_users', 'edit_users'],
            'system'              => ['manage_options'],
            'comments'            => ['moderate_comments', 'edit_posts'],
        ],
        'source' => [
            'wordpress' => ['update_core', 'moderate_comments', 'edit_posts'],
            'plugin'    => ['update_plugins', 'activate_plugins'],
            'theme'     => ['update_themes', 'switch_themes'],
            'system'    => ['manage_options'],
            'user'      => ['list_users', 'edit_users'],
        ],
        'email_trigger' => [
            'critical' => ['read'],
            'security' => ['manage_options'],
            'backup'   => ['manage_options'],
            'updates'  => ['update_core', 'update_plugins', 'update_themes'],
        ],
    ];

    if (!isset($maps[ $group ][ $key ])) {
        return ['read'];
    }

    return $maps[ $group ][ $key ];
}

/** Whether the current user may configure a notification preference option. */
function yooadmin_user_can_manage_notification_preference_item(string $group, string $key): bool {
    if (yooadmin_user_can_manage_site_settings()) {
        return true;
    }

    if (!is_user_logged_in()) {
        return false;
    }

    $caps = yooadmin_notification_preference_item_required_caps($group, $key);
    foreach ($caps as $cap) {
        if ($cap !== '__deny__' && current_user_can($cap)) {
            return true;
        }
    }

    return false;
}

/**
 * @param array<string, string> $options
 * @param 'type'|'source'|'email_trigger' $group
 * @return array<string, string>
 */
function yooadmin_filter_notification_preference_options(array $options, string $group): array {
    $filtered = [];

    foreach ($options as $key => $label) {
        if (yooadmin_user_can_manage_notification_preference_item($group, (string) $key)) {
            $filtered[ (string) $key ] = $label;
        }
    }

    return $filtered;
}

/**
 * WordPress core admin-bar node IDs that YOOAdmin capability rules should apply to.
 *
 * Third-party plugin nodes are omitted — WordPress already scopes them at registration.
 *
 * @return string[]
 */
function yooadmin_toolbar_core_admin_bar_node_ids(): array {
    return [
        'comments',
        'updates',
        'new-content',
        'new-post',
        'new-page',
        'new-media',
        'new-user',
        'view',
        'preview',
        'view-site',
        'edit',
        'customize',
    ];
}

/** Whether a toolbar row is owned by YOOAdmin (custom shortcuts / defaults). */
function yooadmin_toolbar_shortcut_is_yooadmin_owned(array $shortcut): bool {
    $id = isset($shortcut['id']) ? (string) $shortcut['id'] : '';

    return $id !== '' && strncmp($id, 'yooadmin', 8) === 0;
}

/**
 * Whether YOOAdmin should apply href/capability rules to a mirrored toolbar row.
 *
 * Plugin mirrors (Yoast, Elementor, WooCommerce, Site Kit, etc.) are left to WordPress.
 */
function yooadmin_toolbar_shortcut_requires_capability_check(array $shortcut): bool {
    if (yooadmin_toolbar_shortcut_is_yooadmin_owned($shortcut)) {
        return true;
    }

    $id = isset($shortcut['id']) ? (string) $shortcut['id'] : '';
    if ($id === '') {
        return true;
    }

    return in_array($id, yooadmin_toolbar_core_admin_bar_node_ids(), true);
}

/**
 * Required capabilities for a breadcrumbs-toolbar shortcut (any one grants access).
 *
 * @return string[] Empty = visible to any logged-in admin-area user with read.
 */
function yooadmin_toolbar_shortcut_required_caps(array $shortcut): array {
    $id = isset($shortcut['id']) ? (string) $shortcut['id'] : '';

    $by_id = [
        'comments'           => ['moderate_comments', 'edit_posts'],
        'updates'            => ['update_core', 'update_plugins', 'update_themes', 'update_languages'],
        'new-post'           => ['edit_posts'],
        'new-page'           => ['edit_pages', 'edit_posts'],
        'new-media'          => ['upload_files'],
        'new-user'           => ['create_users'],
        'yooadmin-updates'   => ['update_core', 'update_plugins', 'update_themes', 'update_languages'],
        'yooadmin-comments'  => ['moderate_comments', 'edit_posts'],
        'yooadmin-new-post'  => ['edit_posts'],
        'yooadmin-new-page'  => ['edit_pages', 'edit_posts'],
        'yooadmin-new-media' => ['upload_files'],
        'yooadmin-plugins'   => ['activate_plugins'],
        'yooadmin-settings'  => [yooadmin_required_cap('settings')],
        'yooadmin-my-preferences' => [yooadmin_user_preferences_page_capability()],
    ];

    if (isset($by_id[ $id ])) {
        return $by_id[ $id ];
    }

    $href = isset($shortcut['href']) ? trim((string) $shortcut['href']) : '';
    if ($href === '' || $href === '#') {
        return [];
    }

    return yooadmin_admin_href_required_caps($href);
}

/**
 * @return string[] Empty = no extra restriction. ['__deny__'] = always hide.
 */
function yooadmin_admin_href_required_caps(string $href): array {
    $href = trim($href);
    if ($href === '' || $href === '#') {
        return [];
    }

    $path  = wp_parse_url($href, PHP_URL_PATH);
    $query = wp_parse_url($href, PHP_URL_QUERY);
    if (!is_string($path)) {
        return [];
    }

    $args = [];
    if (is_string($query) && $query !== '') {
        parse_str($query, $args);
    }

    $page = isset($args['page']) ? sanitize_key((string) $args['page']) : '';

    if ($page === 'yooadmin-settings' || $page === 'yooadmin-admin-theme-settings' || $page === 'yooadmin-license') {
        return [yooadmin_required_cap('settings')];
    }

    if ($page === 'yooadmin-update-center') {
        return ['update_core', 'update_plugins', 'update_themes', 'update_languages'];
    }

    $yooadmin_page_caps = [
        'yooadmin-dashboard'           => ['read'],
        'yooadmin-themes'              => [yooadmin_required_cap('settings')],
        'yooadmin-my-preferences'      => [yooadmin_user_preferences_page_capability()],
        'yooadmin-notification-preferences' => [yooadmin_user_preferences_page_capability()],
        'yooadmin-users'               => ['list_users'],
        'yooadmin-users-new'           => ['create_users'],
        'yooadmin-plugins'             => ['activate_plugins'],
        'yooadmin-posts'               => ['edit_posts'],
        'yooadmin-pages'               => ['edit_pages', 'edit_posts'],
    ];

    $yooadmin_page_caps = apply_filters('yooadmin_page_required_caps_map', $yooadmin_page_caps);

    if ($page === 'yooadmin-user') {
        $profile_user_id = isset($args['user_id']) ? absint((string) $args['user_id']) : 0;
        if ($profile_user_id <= 0) {
            $profile_user_id = get_current_user_id();
        }

        if ($profile_user_id > 0 && (int) $profile_user_id === (int) get_current_user_id()) {
            return ['read'];
        }

        return ['list_users'];
    }

    if ($page === 'yooadmin-my-preferences' || $page === 'yooadmin-notification-preferences') {
        if (function_exists('yooadmin_user_can_view_my_preferences') && !yooadmin_user_can_view_my_preferences()) {
            return ['__deny__'];
        }

        return [yooadmin_user_preferences_page_capability()];
    }

    if ($page !== '' && isset($yooadmin_page_caps[ $page ])) {
        return $yooadmin_page_caps[ $page ];
    }

    $basename = basename(untrailingslashit($path));

    if ($basename === 'post-new.php') {
        $post_type = isset($args['post_type']) ? sanitize_key((string) $args['post_type']) : 'post';

        return ($post_type === 'page') ? ['edit_pages', 'edit_posts'] : ['edit_posts'];
    }

    if ($basename === 'edit.php') {
        $post_type = isset($args['post_type']) ? sanitize_key((string) $args['post_type']) : 'post';
        if ($post_type === 'page') {
            return ['edit_pages'];
        }
        if ($post_type !== '' && $post_type !== 'post') {
            $pto = get_post_type_object($post_type);
            if ($pto instanceof WP_Post_Type && !empty($pto->cap->edit_posts)) {
                return [(string) $pto->cap->edit_posts];
            }
        }

        return ['edit_posts'];
    }

    if ($basename === 'edit-tags.php') {
        $taxonomy = isset($args['taxonomy']) ? sanitize_key((string) $args['taxonomy']) : 'category';
        $tax      = get_taxonomy($taxonomy);
        if ($tax instanceof WP_Taxonomy && !empty($tax->cap->manage_terms)) {
            return [(string) $tax->cap->manage_terms];
        }

        return ['manage_categories'];
    }

    if ($basename === 'user-edit.php') {
        return ['edit_users'];
    }

    if ($basename === 'profile.php') {
        return ['read'];
    }

    if (strpos($basename, 'options-') === 0) {
        return ['manage_options'];
    }

    $map = [
        'index.php'          => ['read'],
        'plugins.php'        => ['activate_plugins'],
        'plugin-install.php' => ['install_plugins'],
        'plugin-editor.php'  => ['edit_plugins'],
        'themes.php'         => ['switch_themes'],
        'theme-install.php'  => ['install_themes'],
        'theme-editor.php'   => ['edit_themes'],
        'customize.php'      => ['customize'],
        'nav-menus.php'      => ['edit_theme_options'],
        'users.php'          => ['list_users'],
        'user-new.php'       => ['create_users'],
        'update-core.php'    => ['update_core', 'update_plugins', 'update_themes', 'update_languages'],
        'edit-comments.php'  => ['moderate_comments', 'edit_posts'],
        'media-new.php'      => ['upload_files'],
        'upload.php'         => ['upload_files'],
        'tools.php'          => ['edit_posts'],
        'import.php'         => ['import'],
        'export.php'         => ['export'],
        'site-health.php'    => ['view_site_health_checks'],
    ];

    if (isset($map[ $basename ])) {
        return $map[ $basename ];
    }

    return [];
}

/** Whether the current user may open an admin-area href used in welcome/quick links. */
function yooadmin_user_can_access_admin_href(string $href): bool {
    if (!is_user_logged_in()) {
        return false;
    }

    $href = trim($href);
    if ($href === '') {
        return false;
    }

    if (strpos($href, 'http') === 0) {
        $admin_root = admin_url();
        if (strpos($href, $admin_root) !== 0 && strpos($href, network_admin_url()) !== 0) {
            return true;
        }
    }

    $caps = yooadmin_admin_href_required_caps($href);
    if ($caps === []) {
        return true;
    }

    foreach ($caps as $cap) {
        if ($cap !== '__deny__' && current_user_can($cap)) {
            return true;
        }
    }

    return false;
}

/**
 * Whether the current user may use a mirrored toolbar shortcut row.
 *
 * @param array<string, mixed>             $shortcut          Shortcut row.
 * @param array<int, array<string, mixed>>|null $filtered_children Pre-filtered children (optional).
 */
function yooadmin_user_can_access_toolbar_shortcut(array $shortcut, ?array $filtered_children = null): bool {
    if (!is_user_logged_in()) {
        return false;
    }

    $children = $filtered_children ?? (
        isset($shortcut['children']) && is_array($shortcut['children']) ? $shortcut['children'] : []
    );
    $href     = isset($shortcut['href']) ? trim((string) $shortcut['href']) : '';
    $onclick  = isset($shortcut['onclick']) ? trim((string) $shortcut['onclick']) : '';
    $caps     = yooadmin_toolbar_shortcut_required_caps($shortcut);
    $self_ok  = false;

    if ($caps !== []) {
        foreach ($caps as $cap) {
            if ($cap !== '__deny__' && current_user_can($cap)) {
                $self_ok = true;
                break;
            }
        }
    } elseif ($href !== '' && $href !== '#') {
        $self_ok = yooadmin_user_can_access_admin_href($href);
    } elseif ($onclick !== '') {
        $self_ok = true;
    }

    if ($children !== []) {
        return true;
    }

    return $self_ok;
}

/**
 * Hide breadcrumbs-toolbar shortcuts the current user cannot use.
 *
 * @param array<int, array<string, mixed>> $shortcuts
 * @return array<int, array<string, mixed>>
 */
function yooadmin_filter_toolbar_shortcuts_by_capability(array $shortcuts): array {
    if (!is_user_logged_in()) {
        return [];
    }

    $filtered = [];

    foreach ($shortcuts as $shortcut) {
        if (!is_array($shortcut)) {
            continue;
        }

        $children = isset($shortcut['children']) && is_array($shortcut['children'])
            ? yooadmin_filter_toolbar_shortcuts_by_capability($shortcut['children'])
            : [];
        $shortcut['children'] = $children;

        if (!yooadmin_toolbar_shortcut_requires_capability_check($shortcut)) {
            $filtered[] = $shortcut;
            continue;
        }

        if (!yooadmin_user_can_access_toolbar_shortcut($shortcut, $children)) {
            continue;
        }

        $href = isset($shortcut['href']) ? trim((string) $shortcut['href']) : '';
        if (($href === '' || $href === '#') && $children !== [] && isset($children[0]['href'])) {
            $shortcut['href'] = (string) $children[0]['href'];
        }

        $filtered[] = $shortcut;
    }

    return array_values($filtered);
}

/**
 * @param array<int, array<string, mixed>> $items
 * @return array<int, array<string, mixed>>
 */
function yooadmin_filter_items_by_admin_href_capability(array $items, string $url_key = 'url'): array {
    if (!is_user_logged_in()) {
        return [];
    }

    $filtered = [];

    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }

        $url = isset($item[ $url_key ]) ? (string) $item[ $url_key ] : '';
        if ($url !== '' && !yooadmin_user_can_access_admin_href($url)) {
            continue;
        }

        $filtered[] = $item;
    }

    return array_values($filtered);
}

/**
 * @param array<int, array<string, mixed>> $links
 * @return array<int, array<string, mixed>>
 */
function yooadmin_filter_welcome_links_by_capability(array $links): array {
    if (!is_user_logged_in()) {
        return [];
    }

    $filtered = [];

    foreach ($links as $link) {
        if (!is_array($link)) {
            continue;
        }

        $url = isset($link['url']) ? (string) $link['url'] : '';

        if ($url !== '' && !yooadmin_user_can_access_admin_href($url)) {
            continue;
        }

        $filtered[] = $link;
    }

    return array_values($filtered);
}
