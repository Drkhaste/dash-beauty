<?php
/**
 * YOOAdmin - Admin dashboard helpers
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_dashboard_slug')) {
    return;
}

class YOOAdmin_Admin_Dashboard {

    private string $screen_id;

    public function __construct() {
        $this->screen_id = 'toplevel_page_' . yooadmin_dashboard_slug();

        // Disabled: We now convert banners to notifications instead of hiding them
        // add_action('admin_head',        [$this, 'suppress_admin_notices'], 1000);
        // add_action('all_admin_notices', [$this, 'maybe_disable_admin_notices'], 0);
        // add_action('admin_notices',     [$this, 'maybe_disable_admin_notices'], 0);

        add_action('in_admin_header', [$this, 'strip_hello_dolly'], 0);
    }

    private function is_yooadmin_screen(): bool {
        if (!function_exists('get_current_screen')) return false;
        $scr = get_current_screen();
        return ($scr && isset($scr->id) && $scr->id === $this->screen_id);
    }

    public function suppress_admin_notices(): void {
        if (!$this->is_yooadmin_screen()) return;
        $css = '.wrap>.notice,.wrap>.updated,.wrap>.update-nag,.wrap>.error,.wrap .is-dismissible,.notice,.update-nag{display:none!important;}';
        if (wp_style_is('yooadmin-core', 'enqueued')) {
            wp_add_inline_style('yooadmin-core', $css);
        } elseif (wp_style_is('yooadmin-shell', 'enqueued')) {
            wp_add_inline_style('yooadmin-shell', $css);
        }
    }

    public function maybe_disable_admin_notices(): void {
        if (!$this->is_yooadmin_screen()) return;
        remove_all_actions('admin_notices');
        remove_all_actions('all_admin_notices');
    }

    /**
     * Hello Dolly outputs a floated #dolly paragraph via admin_notices; it breaks Studio Hub grid layout.
     */
    public function strip_hello_dolly(): void {
        if (!$this->is_yooadmin_screen()) {
            return;
        }
        remove_action('admin_notices', 'hello_dolly');
        remove_action('admin_head', 'dolly_css');
    }
}

new YOOAdmin_Admin_Dashboard();
