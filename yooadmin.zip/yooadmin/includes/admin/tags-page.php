<?php
/**
 * YOOAdmin - Tags page (admin list)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

class YOOAdmin_Tags_Page
{

    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('admin_menu', [$this, 'register_page']);
        add_action('admin_init', [$this, 'maybe_redirect']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_yooadmin_tags_action', [$this, 'handle_ajax_action']);
        add_action('wp_ajax_yooadmin_bulk_tags_action', [$this, 'handle_bulk_action']);
        add_action('wp_ajax_yooadmin_add_tag', [$this, 'ajax_add_tag']);
    }

    public function register_page()
    {
        $hook = add_submenu_page(
            '',
            'Tags',
            'Tags',
            'manage_categories',
            'yooadmin-tags',
        [$this, 'render_page']
        );
        if ($hook) {
            add_action("load-{$hook}", function () {
                global $title;
                $title = __('Tags', 'yooadmin');

                $opts = (array)get_option('yooadmin_options', []);
                $enabled = !empty($opts['tags_redirect']);
                if (!$enabled) {
                    wp_safe_redirect(admin_url('edit-tags.php?taxonomy=post_tag'));
                    exit;
                }
            });
        }
    }

    public function enqueue_assets($hook)
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page detection.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== 'yooadmin-tags') {
            return;
        }

        global $title;
        $title = 'Tags';

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir = plugin_dir_path($base_file);
        $base_url = plugin_dir_url($base_file);

        $style_rel = 'assets/css/admin/tags-page.css';
        $style_abs = $base_dir . $style_rel;
        if (file_exists($style_abs)) {
            wp_enqueue_style('yooadmin-tags', $base_url . $style_rel, ['yooadmin-shell'], filemtime($style_abs));
        }

        $script_rel = 'assets/js/admin/tags-page.js';
        $script_abs = $base_dir . $script_rel;
        if (file_exists($script_abs)) {
            wp_enqueue_script('yooadmin-tags', $base_url . $script_rel, ['jquery'], filemtime($script_abs), true);
            wp_localize_script('yooadmin-tags', 'yooadmTags', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('yooadmin_tags'),
                'i18n' => [
                    'deleteConfirm' => __('Are you sure you want to delete this tag?', 'yooadmin'),
                    'selected' => __('selected', 'yooadmin'),
                    'success' => __('Operation completed successfully.', 'yooadmin'),
                    'error' => __('An error occurred. Please try again.', 'yooadmin'),
                ],
            ]);
        }
    }

    public function maybe_redirect()
    {
        global $pagenow;

        if ($pagenow !== 'edit-tags.php') {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only taxonomy check for redirect.
        $taxonomy = isset($_GET['taxonomy']) ? sanitize_text_field(wp_unslash($_GET['taxonomy'])) : 'post_tag';
        if ($taxonomy !== 'post_tag') {
            return;
        }

        $opts = (array)get_option('yooadmin_options', []);
        $enabled = !empty($opts['tags_redirect']);
        if (!$enabled) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only action check from URL; no state change.
        $action = isset($_GET['action']) ? sanitize_text_field(wp_unslash($_GET['action'])) : '';
        if ($action === 'edit') {
            return;
        }

        wp_safe_redirect(admin_url('admin.php?page=yooadmin-tags'));
        exit;
    }

    public function render_page()
    {
        if (!current_user_can('manage_categories')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'yooadmin'));
        }

        $tags = get_terms([
            'taxonomy' => 'post_tag',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ]);

        if (is_wp_error($tags)) {
            $tags = [];
        }

        $total_count = count($tags);
        $empty_count = 0;
        foreach ($tags as $tag) {
            if ((int)$tag->count === 0) {
                $empty_count++;
            }
        }

        $list_url = admin_url('admin.php?page=yooadmin-tags');

        $template = dirname(__DIR__, 2) . '/templates/yoopixel/admin/pages/tags/index.php';
        if (file_exists($template)) {
            include $template;
        }
    }

    public function ajax_add_tag()
    {
        check_ajax_referer('yooadmin_tags', 'nonce');

        if (!current_user_can('manage_categories')) {
            wp_send_json_error(['message' => __('Permission denied.', 'yooadmin')]);
        }

        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $slug = isset($_POST['slug']) ? sanitize_title(wp_unslash($_POST['slug'])) : '';
        $description = isset($_POST['description']) ? sanitize_textarea_field(wp_unslash($_POST['description'])) : '';

        if (empty($name)) {
            wp_send_json_error(['message' => __('Tag name is required.', 'yooadmin')]);
        }

        $args = [
            'slug' => $slug,
            'description' => $description,
        ];

        $result = wp_insert_term($name, 'post_tag', $args);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        $tag = get_term($result['term_id'], 'post_tag');

        wp_send_json_success([
            'message' => __('Tag added successfully!', 'yooadmin'),
            'tag' => [
                'id' => $tag->term_id,
                'name' => $tag->name,
                'slug' => $tag->slug,
                'description' => $tag->description,
                'count' => $tag->count,
            ],
        ]);
    }

    public function handle_ajax_action()
    {
        check_ajax_referer('yooadmin_tags', 'nonce');

        if (!current_user_can('manage_categories')) {
            wp_send_json_error(['message' => __('Permission denied.', 'yooadmin')]);
        }

        $tag_action = isset($_POST['tag_action']) ? sanitize_text_field(wp_unslash($_POST['tag_action'])) : '';
        $tag_id = isset($_POST['tag_id']) ? absint($_POST['tag_id']) : 0;

        if (!$tag_action || !$tag_id) {
            wp_send_json_error(['message' => __('Missing required parameters.', 'yooadmin')]);
        }

        if ($tag_action === 'delete') {
            $result = wp_delete_term($tag_id, 'post_tag');

            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()]);
            }

            wp_send_json_success(['message' => __('Tag deleted successfully.', 'yooadmin')]);
        }

        wp_send_json_error(['message' => __('Invalid action.', 'yooadmin')]);
    }

    public function handle_bulk_action()
    {
        check_ajax_referer('yooadmin_tags', 'nonce');

        if (!current_user_can('manage_categories')) {
            wp_send_json_error(['message' => __('Permission denied.', 'yooadmin')]);
        }

        $action = isset($_POST['action_name']) ? sanitize_text_field(wp_unslash($_POST['action_name'])) : '';
        $tag_ids = isset($_POST['tag_ids']) ? array_map('absint', (array)$_POST['tag_ids']) : [];

        if (!$action || empty($tag_ids)) {
            wp_send_json_error(['message' => __('Missing required parameters.', 'yooadmin')]);
        }

        if ($action === 'delete') {
            $deleted = 0;
            foreach ($tag_ids as $tag_id) {
                $result = wp_delete_term($tag_id, 'post_tag');
                if (!is_wp_error($result)) {
                    $deleted++;
                }
            }

            wp_send_json_success([
                // translators: %d: number of tags
                'message' => sprintf(__('%d tags deleted successfully.', 'yooadmin'), $deleted),
            ]);
        }

        wp_send_json_error(['message' => __('Invalid action.', 'yooadmin')]);
    }
}

YOOAdmin_Tags_Page::get_instance();
