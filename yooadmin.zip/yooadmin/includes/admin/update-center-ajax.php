<?php
/**
 * YOOUpdate Center — AJAX updaters (same page, no navigation to update-core/update.php).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * AJAX handlers for YOOUpdate Center.
 */
final class YOOAdmin_Update_Center_Ajax
{
    public const NONCE_ACTION = 'yooadmin_update_center';

    /** @var self|null */
    private static $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('wp_ajax_yooadmin_uc_refresh', [$this, 'ajax_refresh']);
        add_action('wp_ajax_yooadmin_uc_update_plugin', [$this, 'ajax_update_plugin']);
        add_action('wp_ajax_yooadmin_uc_update_theme', [$this, 'ajax_update_theme']);
        add_action('wp_ajax_yooadmin_uc_update_translations', [$this, 'ajax_update_translations']);
        add_action('wp_ajax_yooadmin_uc_update_translation', [$this, 'ajax_update_translation']);
        add_action('wp_ajax_yooadmin_uc_update_core', [$this, 'ajax_update_core']);
        add_action('wp_ajax_yooadmin_uc_core_auto_major', [$this, 'ajax_core_auto_major']);
        add_action('wp_ajax_yooadmin_uc_dismiss_core', [$this, 'ajax_dismiss_core']);
        add_action('wp_ajax_yooadmin_uc_undismiss_core', [$this, 'ajax_undismiss_core']);
    }

    private function verify_nonce(): bool
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce read for verification below.
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        return $nonce !== '' && wp_verify_nonce($nonce, self::NONCE_ACTION);
    }

    /**
     * Drop stray echoed output so {@see wp_send_json_*} returns valid JSON (avoids client "failed" on success).
     */
    private static function prepare_json_response(): void
    {
        if (ob_get_level() > 0) {
            ob_clean();
        }
    }

    /**
     * Start capturing notices/echoes before heavy work (upgrader, etc.).
     */
    private static function begin_ajax_output_buffer(): void
    {
        if (! ob_get_level()) {
            ob_start();
        }
    }

    /**
     * If a previous core update died with a PHP fatal, WordPress may leave `core_updater.lock` set,
     * causing "Another update is currently in progress" on the next attempt.
     */
    private static function maybe_clear_stale_core_update_lock(): void
    {
        $lock = get_option('core_updater.lock');
        if (false === $lock || '' === $lock) {
            return;
        }

        $started = 0;
        if (is_numeric($lock)) {
            $started = (int) $lock;
        } elseif (is_array($lock)) {
            foreach (['start_time', 'updated', 'start', 'lock', 'time'] as $key) {
                if (isset($lock[$key]) && is_numeric($lock[$key])) {
                    $started = (int) $lock[$key];
                    break;
                }
            }
        }

        if ($started > 0 && (time() - $started) > 20 * MINUTE_IN_SECONDS) {
            delete_option('core_updater.lock');
        }
    }

    /**
     * @param mixed $data Payload for {@see self::send_json_success_uc()}.
     */
    private static function send_json_success_uc($data): void
    {
        self::prepare_json_response();
        call_user_func('wp_send_json_success', $data);
    }

    /**
     * @param mixed $data Payload for {@see self::send_json_error_uc()}.
     */
    private static function send_json_error_uc($data): void
    {
        self::prepare_json_response();
        call_user_func('wp_send_json_error', $data);
    }

    /**
     * Re-run update checks and return fresh section HTML for in-place replacement.
     */
    public function ajax_refresh(): void
    {
        self::begin_ajax_output_buffer();

        if (!$this->verify_nonce()) {
            self::send_json_error_uc(['message' => __('Security check failed.', 'yooadmin')]);
        }

        if (!current_user_can('update_core') && !current_user_can('update_plugins') && !current_user_can('update_themes') && !current_user_can('update_languages')) {
            self::send_json_error_uc(['message' => __('Sorry, you are not allowed to update this site.', 'yooadmin')]);
        }

        wp_version_check([], true);
        if (function_exists('wp_update_plugins')) {
            wp_update_plugins();
        }
        if (function_exists('wp_update_themes')) {
            wp_update_themes();
        }

        self::send_json_success_uc(
            [
                'sections' => self::build_sections_payload(),
                'totals'     => wp_get_update_data(),
            ]
        );
    }

    /**
     * @return array<string, string>
     */
    private static function build_sections_payload(): array
    {
        $out = [
            'wp_version' => get_bloginfo('version'),
        ];

        unset($GLOBALS['yooadmin_uc_suppress_core_primary']);

        if (current_user_can('update_core')) {
            yooadmin_uc_reset_floating_tooltips();
            $out['header_core_html'] = self::capture_static('yooadmin_uc_render_header_actions');
            $out['hero_aside_html']  = self::capture_static('yooadmin_uc_render_hero_aside');
            $out['floating_tooltips_html'] = yooadmin_uc_get_floating_tooltips_html();
            $out['hero_maintenance_html'] = self::capture_static('yooadmin_uc_print_hero_maintenance_note');
            $out['core_dynamic_html']     = self::capture_static('yooadmin_uc_core_upgrade_preamble');
            $out['preface_html']          = self::capture_static('yooadmin_uc_render_preface_notices');
        } else {
            $out['header_core_html']      = '';
            $out['hero_aside_html']        = '';
            $out['floating_tooltips_html'] = '';
            $out['hero_maintenance_html']  = '';
            $out['core_dynamic_html']      = '<p class="yoo-update-center-empty">' . esc_html__('You do not have permission to update WordPress core.', 'yooadmin') . '</p>';
            $out['preface_html']           = '';
        }

        if (current_user_can('update_plugins')) {
            $out['plugins_html'] = self::capture_static(
                static function (): void {
                    yooadmin_uc_list_plugin_updates(true);
                }
            );
        } else {
            $out['plugins_html'] = '';
        }

        if (current_user_can('update_themes')) {
            $out['themes_html'] = self::capture_static(
                static function (): void {
                    yooadmin_uc_list_theme_updates(true);
                }
            );
        } else {
            $out['themes_html'] = '';
        }

        if (current_user_can('update_languages')) {
            $out['translations_html'] = self::capture_static(
                static function (): void {
                    yooadmin_uc_list_translation_updates(true);
                }
            );
        } else {
            $out['translations_html'] = '';
        }

        return $out;
    }

    /**
     * @param callable-string|callable():void $cb
     */
    private static function capture_static($cb): string
    {
        ob_start();
        if (is_string($cb) && function_exists($cb)) {
            $cb();
        } elseif (is_callable($cb)) {
            $cb();
        }
        return (string) ob_get_clean();
    }

    /**
     * After {@see Plugin_Upgrader} / {@see Theme_Upgrader}, WordPress may clear or leave update transients
     * in a state where {@see get_plugin_updates()} / {@see get_theme_updates()} is empty until the next
     * API sync — so the Update Center UI wrongly shows “no updates” until a full page refresh.
     */
    private static function sync_plugin_updates_transient(): void
    {
        if (!function_exists('wp_update_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }
        if (function_exists('wp_update_plugins')) {
            wp_update_plugins();
        }
    }

    private static function sync_theme_updates_transient(): void
    {
        if (!function_exists('wp_update_themes')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }
        if (function_exists('wp_update_themes')) {
            wp_update_themes();
        }
    }

    public function ajax_update_plugin(): void
    {
        self::begin_ajax_output_buffer();

        if (!$this->verify_nonce()) {
            self::send_json_error_uc(['message' => __('Security check failed.', 'yooadmin')]);
        }
        if (!current_user_can('update_plugins')) {
            self::send_json_error_uc(['message' => __('Sorry, you are not allowed to update plugins.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $plugin = isset($_POST['plugin']) ? sanitize_text_field(wp_unslash($_POST['plugin'])) : '';
        if ($plugin === '') {
            self::send_json_error_uc(['message' => __('No plugin selected.', 'yooadmin')]);
        }

        $updates = get_plugin_updates();
        if (!isset($updates[$plugin])) {
            self::sync_plugin_updates_transient();
            $updates = get_plugin_updates();
        }
        if (!isset($updates[$plugin])) {
            self::send_json_error_uc(['message' => __('No update available for this plugin.', 'yooadmin')]);
        }

        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';

        if (!defined('YOOADMIN_UPGRADING')) {
            define('YOOADMIN_UPGRADING', true);
        }

        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $result   = $upgrader->upgrade($plugin);

        if (is_wp_error($result)) {
            self::send_json_error_uc(['message' => $result->get_error_message()]);
        }
        if (false === $result) {
            self::sync_plugin_updates_transient();
            $updates = get_plugin_updates();
            if (! isset($updates[$plugin])) {
                $data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
                $ver  = isset($data['Version']) ? (string) $data['Version'] : '';
                self::send_json_success_uc(
                    [
                        'message' => __('Plugin updated successfully.', 'yooadmin'),
                        'version' => $ver,
                        'plugin'  => $plugin,
                        'sections' => self::build_sections_payload(),
                        'totals'   => wp_get_update_data(),
                    ]
                );
                return;
            }
            self::send_json_error_uc(['message' => __('Plugin update failed.', 'yooadmin')]);
        }

        $data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
        $ver  = isset($data['Version']) ? (string) $data['Version'] : '';

        self::sync_plugin_updates_transient();
        self::send_json_success_uc(
            [
                'message' => __('Plugin updated successfully.', 'yooadmin'),
                'version' => $ver,
                'plugin'  => $plugin,
                'sections' => self::build_sections_payload(),
                'totals'   => wp_get_update_data(),
            ]
        );
    }

    public function ajax_update_theme(): void
    {
        self::begin_ajax_output_buffer();

        if (!$this->verify_nonce()) {
            self::send_json_error_uc(['message' => __('Security check failed.', 'yooadmin')]);
        }
        if (!current_user_can('update_themes')) {
            self::send_json_error_uc(['message' => __('Sorry, you are not allowed to update themes.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $stylesheet = isset($_POST['stylesheet']) ? sanitize_text_field(wp_unslash($_POST['stylesheet'])) : '';
        if ($stylesheet === '') {
            self::send_json_error_uc(['message' => __('No theme selected.', 'yooadmin')]);
        }

        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';

        $themes = get_theme_updates();
        if (empty($themes[$stylesheet])) {
            self::sync_theme_updates_transient();
            $themes = get_theme_updates();
        }
        if (empty($themes[$stylesheet])) {
            self::send_json_error_uc(['message' => __('No update available for this theme.', 'yooadmin')]);
        }

        if (!defined('YOOADMIN_UPGRADING')) {
            define('YOOADMIN_UPGRADING', true);
        }

        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Theme_Upgrader($skin);
        $result   = $upgrader->upgrade($stylesheet);

        if (is_wp_error($result)) {
            self::send_json_error_uc(['message' => $result->get_error_message()]);
        }
        if (false === $result) {
            self::sync_theme_updates_transient();
            $themes = get_theme_updates();
            if (empty($themes[$stylesheet])) {
                $theme   = wp_get_theme($stylesheet);
                $version = $theme->exists() ? (string) $theme->get('Version') : '';
                self::send_json_success_uc(
                    [
                        'message' => __('Theme updated successfully.', 'yooadmin'),
                        'version' => $version,
                        'stylesheet' => $stylesheet,
                        'sections' => self::build_sections_payload(),
                        'totals'   => wp_get_update_data(),
                    ]
                );
                return;
            }
            self::send_json_error_uc(['message' => __('Theme update failed.', 'yooadmin')]);
        }

        $theme   = wp_get_theme($stylesheet);
        $version = $theme->exists() ? (string) $theme->get('Version') : '';

        self::sync_theme_updates_transient();
        self::send_json_success_uc(
            [
                'message' => __('Theme updated successfully.', 'yooadmin'),
                'version' => $version,
                'stylesheet' => $stylesheet,
                'sections' => self::build_sections_payload(),
                'totals'   => wp_get_update_data(),
            ]
        );
    }

    public function ajax_update_translations(): void
    {
        self::begin_ajax_output_buffer();

        if (!$this->verify_nonce()) {
            self::send_json_error_uc(['message' => __('Security check failed.', 'yooadmin')]);
        }
        if (!current_user_can('update_languages')) {
            self::send_json_error_uc(['message' => __('Sorry, you are not allowed to update translations.', 'yooadmin')]);
        }

        $result = self::run_translation_upgrader();

        if (is_wp_error($result)) {
            self::send_json_error_uc(['message' => $result->get_error_message()]);
        }
        if (false === $result) {
            self::send_json_error_uc(['message' => __('Translation updates failed.', 'yooadmin')]);
        }

        self::send_json_success_uc(
            [
                'message' => __('Translations updated successfully.', 'yooadmin'),
                'sections' => self::build_sections_payload(),
                'totals'   => wp_get_update_data(),
            ]
        );
    }

    public function ajax_update_translation(): void
    {
        self::begin_ajax_output_buffer();

        if (!$this->verify_nonce()) {
            self::send_json_error_uc(['message' => __('Security check failed.', 'yooadmin')]);
        }
        if (!current_user_can('update_languages')) {
            self::send_json_error_uc(['message' => __('Sorry, you are not allowed to update translations.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $type = isset($_POST['type']) ? sanitize_key(wp_unslash($_POST['type'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $slug = isset($_POST['slug']) ? sanitize_key(wp_unslash($_POST['slug'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $language = isset($_POST['language']) ? sanitize_text_field(wp_unslash($_POST['language'])) : '';

        if ($language === '') {
            self::send_json_error_uc(['message' => __('Missing translation update details.', 'yooadmin')]);
        }

        $update = self::find_translation_update($type, $slug, $language);
        if (!$update) {
            self::send_json_error_uc(['message' => __('No update available for this language pack.', 'yooadmin')]);
        }

        $result = self::run_translation_upgrader($update);
        if (is_wp_error($result)) {
            self::send_json_error_uc(['message' => $result->get_error_message()]);
        }
        if (false === $result) {
            self::send_json_error_uc(['message' => __('Translation update failed.', 'yooadmin')]);
        }

        $version = isset($update->version) ? (string) $update->version : '';

        self::send_json_success_uc(
            [
                'message'    => __('Translation updated successfully.', 'yooadmin'),
                'newVersion' => $version,
                'sections'   => self::build_sections_payload(),
                'totals'     => wp_get_update_data(),
            ]
        );
    }

    /**
     * @return object|null
     */
    private static function find_translation_update(string $type, string $slug, string $language)
    {
        require_once ABSPATH . 'wp-admin/includes/translation-install.php';

        if (!function_exists('yooadmin_uc_get_translation_updates_with_type')) {
            require_once __DIR__ . '/update-center-render.php';
        }

        $type     = sanitize_key($type);
        $slug     = sanitize_key($slug);
        $language = sanitize_text_field($language);

        foreach (yooadmin_uc_get_translation_updates_with_type() as $update) {
            if (!is_object($update)) {
                continue;
            }

            $update_type = isset($update->type) ? sanitize_key((string) $update->type) : '';
            $update_slug = isset($update->slug) ? sanitize_key((string) $update->slug) : '';
            $update_lang = isset($update->language) ? sanitize_text_field((string) $update->language) : '';

            if ($language === '' || strcasecmp($language, $update_lang) !== 0) {
                continue;
            }

            if ($type !== '' && $type !== $update_type) {
                continue;
            }

            if ($slug !== $update_slug) {
                continue;
            }

            return $update;
        }

        return null;
    }

    /**
     * @param object|false $update Single language pack or false for all pending packs.
     * @return array|bool|WP_Error|null
     */
    private static function run_translation_upgrader($update = false)
    {
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';

        if (!defined('YOOADMIN_UPGRADING')) {
            define('YOOADMIN_UPGRADING', true);
        }

        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Language_Pack_Upgrader($skin);

        if ($update) {
            $result = $upgrader->upgrade($update);
        } else {
            $result = $upgrader->bulk_upgrade();
            if (is_array($result)) {
                foreach ($result as $item) {
                    if (is_wp_error($item)) {
                        return $item;
                    }
                }
            }
        }

        if (is_wp_error($result)) {
            return $result;
        }

        if (false === $result) {
            if (is_wp_error($skin->result)) {
                return $skin->result;
            }
            if ($skin->get_errors()->has_errors()) {
                return new WP_Error(
                    'translation_upgrade_failed',
                    $skin->get_error_messages()
                );
            }
        }

        return $result;
    }

    public function ajax_update_core(): void
    {
        self::begin_ajax_output_buffer();

        if (!$this->verify_nonce()) {
            self::send_json_error_uc(['message' => __('Security check failed.', 'yooadmin')]);
        }
        if (!current_user_can('update_core')) {
            self::send_json_error_uc(['message' => __('Sorry, you are not allowed to update WordPress.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $version  = isset($_POST['version']) ? sanitize_text_field(wp_unslash($_POST['version'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $locale   = isset($_POST['locale']) ? sanitize_text_field(wp_unslash($_POST['locale'])) : 'en_US';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $reinstall = !empty($_POST['reinstall']);

        if ($version === '') {
            self::send_json_error_uc(['message' => __('Missing version.', 'yooadmin')]);
        }

        require_once ABSPATH . 'wp-admin/includes/update.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';

        $update = find_core_update($version, $locale);
        if (!$update) {
            self::send_json_error_uc(['message' => __('No matching core update was found. Try “Check again”.', 'yooadmin')]);
        }

        if ($reinstall) {
            $update->response = 'reinstall';
        }

        $allow_relaxed = !$reinstall && isset($update->new_files) && !$update->new_files;

        $return_base = function_exists('yooadmin_update_center_admin_url')
            ? yooadmin_update_center_admin_url()
            : self_admin_url('update-core.php');
        $cred_url = wp_nonce_url(
            add_query_arg($reinstall ? ['action' => 'do-core-reinstall'] : ['action' => 'do-core-upgrade'], $return_base),
            'upgrade-core'
        );

        global $wp_filesystem;

        ob_start();
        $credentials = request_filesystem_credentials(
            $cred_url,
            '',
            false,
            ABSPATH,
            ['version', 'locale'],
            $allow_relaxed
        );
        $cred_form = ob_get_clean();

        if (false === $credentials) {
            $msg = __('WordPress could not access files with the current server setup. Ask your host to allow direct file writes, or add FS_METHOD / FTP credentials in wp-config.php.', 'yooadmin');
            if ($cred_form !== '' && strpos($cred_form, '<form') !== false) {
                $msg = __('Your server requires FTP or SSH credentials to write files. Add them in wp-config.php or contact your hosting support.', 'yooadmin');
            }
            self::send_json_error_uc(
                [
                    'message' => $msg,
                    'code'    => 'fs_credentials',
                ]
            );
        }

        if (!WP_Filesystem($credentials, ABSPATH, $allow_relaxed)) {
            self::send_json_error_uc(
                [
                    'message' => __('Could not access the file system.', 'yooadmin'),
                    'code'    => 'fs_error',
                ]
            );
        }

        if ($wp_filesystem->errors->has_errors()) {
            $errs = $wp_filesystem->errors->get_error_messages();
            self::send_json_error_uc(
                [
                    'message' => $errs ? implode(' ', $errs) : __('File system error.', 'yooadmin'),
                    'code'    => 'fs_error',
                ]
            );
        }

        if (!defined('YOOADMIN_UPGRADING')) {
            define('YOOADMIN_UPGRADING', true);
        }

        self::maybe_clear_stale_core_update_lock();

        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Core_Upgrader($skin);
        $result   = $upgrader->upgrade(
            $update,
            [
                'allow_relaxed_file_ownership' => $allow_relaxed,
            ]
        );

        if (is_wp_error($result)) {
            $msg = $result->get_error_message();
            if ('up_to_date' !== $result->get_error_code() && 'locked' !== $result->get_error_code()) {
                /* translators: %s: Error message. */
                $msg = $msg ?: __('Installation failed.', 'yooadmin');
            }
            self::send_json_error_uc(['message' => $msg]);
        }
        if (false === $result) {
            self::send_json_error_uc(['message' => __('Core update failed.', 'yooadmin')]);
        }

        $new_version = is_string($result) ? $result : get_bloginfo('version');

        if (function_exists('wp_version_check')) {
            wp_version_check([], true);
        }

        self::send_json_success_uc(
            [
                'message'    => __('WordPress updated successfully.', 'yooadmin'),
                'new_version' => $new_version,
                'sections'   => self::build_sections_payload(),
                'totals'     => wp_get_update_data(),
            ]
        );
    }

    public function ajax_core_auto_major(): void
    {
        self::begin_ajax_output_buffer();

        if (!$this->verify_nonce()) {
            self::send_json_error_uc(['message' => __('Security check failed.', 'yooadmin')]);
        }
        if (!current_user_can('update_core')) {
            self::send_json_error_uc(['message' => __('Sorry, you are not allowed to change this setting.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $value = isset($_POST['value']) ? sanitize_key(wp_unslash($_POST['value'])) : '';
        if (!in_array($value, ['enable', 'disable'], true)) {
            self::send_json_error_uc(['message' => __('Invalid value.', 'yooadmin')]);
        }

        if (defined('WP_AUTO_UPDATE_CORE')) {
            self::send_json_error_uc(['message' => __('Automatic core updates are controlled by wp-config.php.', 'yooadmin')]);
        }

        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        $updater = new WP_Automatic_Updater();
        if ($updater->is_disabled()) {
            self::send_json_error_uc(['message' => __('Automatic updates are disabled on this site.', 'yooadmin')]);
        }
        if (has_filter('allow_major_auto_core_updates')) {
            self::send_json_error_uc(['message' => __('This setting cannot be changed.', 'yooadmin')]);
        }

        if ('enable' === $value) {
            update_site_option('auto_update_core_major', 'enabled');
        } else {
            update_site_option('auto_update_core_major', 'disabled');
        }

        self::send_json_success_uc(
            [
                'message'  => __('Setting saved.', 'yooadmin'),
                'sections' => self::build_sections_payload(),
                'totals'   => wp_get_update_data(),
            ]
        );
    }

    public function ajax_dismiss_core(): void
    {
        self::begin_ajax_output_buffer();

        if (!$this->verify_nonce()) {
            self::send_json_error_uc(['message' => __('Security check failed.', 'yooadmin')]);
        }
        if (!current_user_can('update_core')) {
            self::send_json_error_uc(['message' => __('Sorry, you are not allowed to do this.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $version = isset($_POST['version']) ? sanitize_text_field(wp_unslash($_POST['version'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $locale  = isset($_POST['locale']) ? sanitize_text_field(wp_unslash($_POST['locale'])) : 'en_US';
        if ($version === '') {
            self::send_json_error_uc(['message' => __('Missing version.', 'yooadmin')]);
        }

        require_once ABSPATH . 'wp-admin/includes/update.php';

        $update = find_core_update($version, $locale);
        if (!$update) {
            self::send_json_error_uc(['message' => __('Update not found.', 'yooadmin')]);
        }

        dismiss_core_update($update);

        self::send_json_success_uc(
            [
                'message'  => __('Update hidden.', 'yooadmin'),
                'sections' => self::build_sections_payload(),
                'totals'   => wp_get_update_data(),
            ]
        );
    }

    public function ajax_undismiss_core(): void
    {
        self::begin_ajax_output_buffer();

        if (!$this->verify_nonce()) {
            self::send_json_error_uc(['message' => __('Security check failed.', 'yooadmin')]);
        }
        if (!current_user_can('update_core')) {
            self::send_json_error_uc(['message' => __('Sorry, you are not allowed to do this.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $version = isset($_POST['version']) ? sanitize_text_field(wp_unslash($_POST['version'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via verify_nonce().
        $locale  = isset($_POST['locale']) ? sanitize_text_field(wp_unslash($_POST['locale'])) : 'en_US';
        if ($version === '') {
            self::send_json_error_uc(['message' => __('Missing version.', 'yooadmin')]);
        }

        require_once ABSPATH . 'wp-admin/includes/update.php';

        undismiss_core_update($version, $locale);

        self::send_json_success_uc(
            [
                'message'  => __('Update restored.', 'yooadmin'),
                'sections' => self::build_sections_payload(),
                'totals'   => wp_get_update_data(),
            ]
        );
    }
}
