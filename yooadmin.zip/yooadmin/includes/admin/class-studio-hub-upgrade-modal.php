<?php
/**
 * Legacy → Studio Hub upgrade welcome modal.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Prompts sites on the Legacy admin theme to try Studio Hub with one-click activation.
 */
final class YOOAdmin_Studio_Hub_Upgrade_Modal {

    public const OPTION_DISMISSED = 'yooadmin_studio_hub_upgrade_modal_dismissed';
    public const STUDIO_SLUG      = 'yooadmin-studio-hub';
    public const LEGACY_SLUG      = 'yooadmin-legacy';
    private const USER_META_LEGACY_SWITCH_PROMPT = 'yooadmin_studio_hub_upgrade_legacy_switch_prompt';

    /**
     * Bootstrap hooks.
     */
    public static function init(): void {
        if (!is_admin()) {
            return;
        }

        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets'], 120);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_activation_toast'], 121);
        add_action('admin_footer', [__CLASS__, 'render_modal'], 5);
        add_action('wp_ajax_yooadmin_dismiss_studio_hub_upgrade_modal', [__CLASS__, 'ajax_dismiss']);
        add_action('yooadmin_admin_theme_activated', [__CLASS__, 'on_admin_theme_activated'], 10, 2);
    }

    /**
     * Re-show the upgrade prompt when the user returns to Legacy (e.g. after Studio Hub).
     *
     * @param string $slug  Active admin theme slug.
     * @param array  $theme Theme definition (unused).
     */
    public static function on_admin_theme_activated(string $slug, array $theme): void {
        unset($theme);

        if (self::STUDIO_SLUG === $slug) {
            self::clear_legacy_switch_prompt_for_current_user();
            return;
        }

        if (self::LEGACY_SLUG !== $slug) {
            return;
        }

        self::mark_legacy_switch_prompt_for_current_user();

        if (class_exists('YOOAdmin_Labs_Prefs')) {
            YOOAdmin_Labs_Prefs::reset_studio_hub_upgrade_for_current_user();
            return;
        }

        delete_option(self::OPTION_DISMISSED);
    }

    /**
     * @return bool
     */
    public static function should_show(): bool {
        if (!current_user_can(self::required_capability())) {
            return false;
        }

        if (!class_exists('YOOAdmin_Admin_Theme_Manager')) {
            return false;
        }

        $manager = YOOAdmin_Admin_Theme_Manager::get_instance();
        $active  = $manager->get_active_theme();

        // Upgrade modal is for Legacy users only — Studio Hub users already have the new theme.
        if (!$active || ($active['slug'] ?? '') !== self::LEGACY_SLUG) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        if ($manager->is_fresh_studio_hub_install() && !self::legacy_switch_prompt_requested()) {
            return false;
        }

        if (class_exists('YOOAdmin_Labs_Prefs')) {
            if (!YOOAdmin_Labs_Prefs::is_studio_hub_upgrade_visible()) {
                return false;
            }
        } elseif (get_option(self::OPTION_DISMISSED, false)) {
            return false;
        }

        $themes = $manager->get_themes();
        if (!isset($themes[self::STUDIO_SLUG])) {
            return false;
        }

        // Let the post-wizard welcome popup run first on the dashboard.
        if (class_exists('YOOAdmin_Welcome_Popup') && YOOAdmin_Welcome_Popup::should_show()) {
            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    private static function is_yooadmin_dashboard_screen(): bool {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        return isset($_GET['page']) && 'yooadmin-dashboard' === sanitize_key(wp_unslash($_GET['page']));
    }

    /**
     * @param string $hook
     */
    public static function enqueue_assets($hook = ''): void {
        if (!self::should_show()) {
            return;
        }

        $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
        $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);

        $css_rel = 'assets/css/admin/studio-hub-upgrade-modal.css';
        $js_rel  = 'assets/js/admin/studio-hub-upgrade-modal.js';
        $btn_css = 'assets/css/admin/yp-yoo-buttons.css';

        if (is_readable($base_dir . $btn_css)) {
            wp_enqueue_style(
                'yooadmin-yoo-buttons',
                $base_url . $btn_css,
                [],
                (string) filemtime($base_dir . $btn_css)
            );
        }

        if (is_readable($base_dir . $css_rel)) {
            wp_enqueue_style('dashicons');
            wp_enqueue_style(
                'yooadmin-studio-hub-upgrade-modal',
                $base_url . $css_rel,
                ['yooadmin-yoo-buttons'],
                (string) filemtime($base_dir . $css_rel)
            );
        }

        if (is_readable($base_dir . $js_rel)) {
            wp_enqueue_script(
                'yooadmin-studio-hub-upgrade-modal',
                $base_url . $js_rel,
                ['jquery'],
                (string) filemtime($base_dir . $js_rel),
                true
            );

            $studio = YOOAdmin_Admin_Theme_Manager::get_instance()->get_themes()[self::STUDIO_SLUG] ?? [];

            wp_localize_script(
                'yooadmin-studio-hub-upgrade-modal',
                'yooadminStudioHubUpgrade',
                [
                    'ajaxUrl'       => admin_url('admin-ajax.php'),
                    'dismissNonce'  => wp_create_nonce('yooadmin_studio_hub_upgrade_dismiss'),
                    'activateNonce' => wp_create_nonce('yooadmin_shell_theme_activate'),
                    'themeSlug'     => self::STUDIO_SLUG,
                    'dashboardUrl'  => admin_url('admin.php?page=yooadmin-dashboard'),
                    'imageUrl'      => $base_url . 'assets/images/studio-hub-upgrade-promo.svg',
                    'i18n'          => [
                        'activating'   => __('Activating…', 'yooadmin'),
                        'activated'    => __('Studio Hub is active', 'yooadmin'),
                        'activate'     => __('Activate Studio Hub', 'yooadmin'),
                        'activateFail' => __('Could not activate Studio Hub. Please try again from Themes.', 'yooadmin'),
                        'later'        => __('Maybe later', 'yooadmin'),
                        'appearance'   => __('Appearance', 'yooadmin'),
                        'light'        => __('Light', 'yooadmin'),
                        'dark'         => __('Dark', 'yooadmin'),
                        'system'       => __('System', 'yooadmin'),
                    ],
                ]
            );
        }
    }

    /**
     * One-time welcome toast after upgrade modal activation.
     *
     * @param string $hook
     */
    public static function enqueue_activation_toast($hook = ''): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only success flag.
        if (!isset($_GET['ysh_activated']) || '1' !== sanitize_text_field(wp_unslash($_GET['ysh_activated']))) {
            return;
        }

        if (!self::is_yooadmin_dashboard_screen() || !current_user_can(self::required_capability())) {
            return;
        }

        if (!class_exists('YOOAdmin_Admin_Theme_Manager')) {
            return;
        }

        $active = YOOAdmin_Admin_Theme_Manager::get_instance()->get_active_theme();
        if (!$active || ($active['slug'] ?? '') !== self::STUDIO_SLUG) {
            return;
        }

        $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
        $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);
        $css_rel  = 'assets/css/admin/studio-hub-upgrade-modal.css';
        $js_rel   = 'assets/js/admin/studio-hub-activation-toast.js';

        if (is_readable($base_dir . $css_rel)) {
            wp_enqueue_style(
                'yooadmin-studio-hub-activation-toast',
                $base_url . $css_rel,
                [],
                (string) filemtime($base_dir . $css_rel)
            );
        }

        if (is_readable($base_dir . $js_rel)) {
            wp_enqueue_script(
                'yooadmin-studio-hub-activation-toast',
                $base_url . $js_rel,
                ['jquery'],
                (string) filemtime($base_dir . $js_rel),
                true
            );

            wp_localize_script(
                'yooadmin-studio-hub-activation-toast',
                'yooadminStudioHubActivationToast',
                [
                    'message' => __('Welcome to Studio Hub — your workspace is ready.', 'yooadmin'),
                ]
            );
        }
    }

    /**
     * Print modal markup in admin footer.
     */
    public static function render_modal(): void {
        if (!self::should_show()) {
            return;
        }

        $manager = YOOAdmin_Admin_Theme_Manager::get_instance();
        $studio  = $manager->get_themes()[self::STUDIO_SLUG] ?? [];
        $name    = isset($studio['name']) ? (string) $studio['name'] : 'Studio Hub';
        $image   = plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/studio-hub-upgrade-promo.svg';

        $features = [
            __('A card-based dashboard you can arrange your way', 'yooadmin'),
            __('Light, dark, or system appearance — your choice', 'yooadmin'),
            __('A focused workspace that stays clean on every screen', 'yooadmin'),
            __('WooCommerce-ready styling from day one', 'yooadmin'),
            __('Workspace notes, activity, and tips — built in', 'yooadmin'),
        ];
        ?>
        <div id="yooadmin-studio-hub-upgrade" class="ysh-upgrade-overlay" data-ysh-upgrade-pref="light" hidden aria-hidden="true">
            <div class="ysh-upgrade-dialog" role="dialog" aria-modal="true" aria-labelledby="ysh-upgrade-title">
                <div class="ysh-upgrade-layout">
                    <div class="ysh-upgrade-copy">
                        <p class="ysh-upgrade-eyebrow"><?php esc_html_e('Studio Hub · Beta', 'yooadmin'); ?></p>
                        <h2 id="ysh-upgrade-title" class="ysh-upgrade-title">
                            <?php
                            printf(
                                /* translators: %s: Studio Hub theme name */
                                esc_html__('Meet %s', 'yooadmin'),
                                esc_html($name)
                            );
                            ?>
                        </h2>
                        <p class="ysh-upgrade-lead">
                            <?php esc_html_e('We are excited to share Studio Hub with you — a modern admin workspace built on the same YOOAdmin you trust, designed to feel calmer, clearer, and more focused.', 'yooadmin'); ?>
                        </p>
                        <p class="ysh-upgrade-beta">
                            <?php esc_html_e('Studio Hub is still in beta. We are shipping improvements regularly over the coming days and weeks, with broader plugin support on the way.', 'yooadmin'); ?>
                        </p>
                        <ul class="ysh-upgrade-features">
                            <?php foreach ($features as $feature) : ?>
                                <li>
                                    <span class="ysh-upgrade-check dashicons dashicons-yes-alt" aria-hidden="true"></span>
                                    <span><?php echo esc_html($feature); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="ysh-upgrade-actions">
                            <button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary ysh-upgrade-activate">
                                <?php esc_html_e('Activate Studio Hub', 'yooadmin'); ?>
                            </button>
                            <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft ysh-upgrade-dismiss">
                                <?php esc_html_e('Maybe later', 'yooadmin'); ?>
                            </button>
                        </div>
                        <p class="ysh-upgrade-footnote">
                            <?php esc_html_e('You can switch back to Legacy anytime from YOOAdmin → Themes. Your feedback helps us shape what comes next.', 'yooadmin'); ?>
                        </p>
                    </div>
                    <div class="ysh-upgrade-visual" aria-hidden="true">
                        <div class="ysh-upgrade-visual-controls">
                            <?php self::render_appearance_control('light'); ?>
                            <button type="button" class="ysh-upgrade-close" aria-label="<?php echo esc_attr__('Close', 'yooadmin'); ?>">
                                <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                            </button>
                        </div>
                        <img
                            class="ysh-upgrade-image"
                            src="<?php echo esc_url($image); ?>"
                            alt=""
                            width="320"
                            height="280"
                            loading="lazy"
                            decoding="async"
                        />
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * AJAX: persist dismiss.
     */
    public static function ajax_dismiss(): void {
        check_ajax_referer('yooadmin_studio_hub_upgrade_dismiss', 'nonce');

        if (!current_user_can(self::required_capability())) {
            wp_send_json_error(['message' => __('Forbidden.', 'yooadmin')], 403);
        }

        if (class_exists('YOOAdmin_Labs_Prefs')) {
            YOOAdmin_Labs_Prefs::set_studio_hub_upgrade_visible(false, get_current_user_id());
        } else {
            update_option(self::OPTION_DISMISSED, true, false);
        }
        self::clear_legacy_switch_prompt_for_current_user();

        wp_send_json_success(['dismissed' => true]);
    }

    /**
     * Remember that the current user explicitly switched back to Legacy.
     */
    private static function mark_legacy_switch_prompt_for_current_user(): void {
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return;
        }

        update_user_meta($user_id, self::USER_META_LEGACY_SWITCH_PROMPT, 1);
    }

    /**
     * Whether the modal was requested by an explicit Legacy activation.
     */
    private static function legacy_switch_prompt_requested(): bool {
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return false;
        }

        return (bool) get_user_meta($user_id, self::USER_META_LEGACY_SWITCH_PROMPT, true);
    }

    /**
     * Clear the explicit Legacy activation prompt marker.
     */
    private static function clear_legacy_switch_prompt_for_current_user(): void {
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return;
        }

        delete_user_meta($user_id, self::USER_META_LEGACY_SWITCH_PROMPT);
    }

    /**
     * Inline appearance pill (auto / light / dark preview).
     *
     * @param string $color_mode light|dark|auto
     */
    private static function render_appearance_control(string $color_mode = 'auto'): void {
        if (!in_array($color_mode, ['light', 'dark', 'auto'], true)) {
            $color_mode = 'auto';
        }

        $svg_light = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('light', 16, 'ysh-upgrade-appearance-icon') : '';
        $svg_dark  = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('dark', 16, 'ysh-upgrade-appearance-icon') : '';
        $svg_auto  = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('auto', 16, 'ysh-upgrade-appearance-icon') : '';
        ?>
        <div class="ysh-upgrade-appearance" role="group" aria-label="<?php echo esc_attr__('Appearance', 'yooadmin'); ?>">
            <button type="button" class="ysh-upgrade-appearance-btn<?php echo 'auto' === $color_mode ? ' is-active' : ''; ?>" data-ysh-upgrade-pref="auto" title="<?php echo esc_attr__('System', 'yooadmin'); ?>">
                <?php echo $svg_auto; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                <span class="screen-reader-text"><?php esc_html_e('System', 'yooadmin'); ?></span>
            </button>
            <button type="button" class="ysh-upgrade-appearance-btn<?php echo 'light' === $color_mode ? ' is-active' : ''; ?>" data-ysh-upgrade-pref="light" title="<?php echo esc_attr__('Light', 'yooadmin'); ?>">
                <?php echo $svg_light; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                <span class="screen-reader-text"><?php esc_html_e('Light', 'yooadmin'); ?></span>
            </button>
            <button type="button" class="ysh-upgrade-appearance-btn<?php echo 'dark' === $color_mode ? ' is-active' : ''; ?>" data-ysh-upgrade-pref="dark" title="<?php echo esc_attr__('Dark', 'yooadmin'); ?>">
                <?php echo $svg_dark; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                <span class="screen-reader-text"><?php esc_html_e('Dark', 'yooadmin'); ?></span>
            </button>
        </div>
        <?php
    }

    /**
     * @return string
     */
    private static function required_capability(): string {
        if (function_exists('yooadmin_required_cap')) {
            return yooadmin_required_cap('settings');
        }

        return 'manage_options';
    }
}
