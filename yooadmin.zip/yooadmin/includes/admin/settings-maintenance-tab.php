<?php
/**
 * Maintenance mode settings tab.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Settings tab partial; variables are include-local.

/** @var YOOAdmin_Settings $this */

$maintenance_locales = function_exists('yooadmin_maintenance_get_language_locales')
    ? yooadmin_maintenance_get_language_locales()
    : [get_locale()];

$maintenance_titles   = isset($opts['maintenance_mode_titles']) && is_array($opts['maintenance_mode_titles'])
    ? $opts['maintenance_mode_titles']
    : [];
$maintenance_messages = isset($opts['maintenance_mode_messages']) && is_array($opts['maintenance_mode_messages'])
    ? $opts['maintenance_mode_messages']
    : [];

$maintenance_enabled_locales = [];
if (isset($opts['maintenance_mode_enabled_locales']) && is_array($opts['maintenance_mode_enabled_locales'])) {
    foreach ($opts['maintenance_mode_enabled_locales'] as $loc) {
        $loc = yooadmin_sanitize_locale_name((string) $loc);
        if ($loc !== '') {
            $maintenance_enabled_locales[] = $loc;
        }
    }
}
$maintenance_enabled_locales = array_values(array_unique($maintenance_enabled_locales));

if ($maintenance_enabled_locales === []) {
    foreach ($maintenance_titles as $loc => $text) {
        if (trim((string) $text) !== '') {
            $maintenance_enabled_locales[] = yooadmin_sanitize_locale_name((string) $loc);
        }
    }
    foreach ($maintenance_messages as $loc => $text) {
        if (trim((string) $text) !== '') {
            $maintenance_enabled_locales[] = yooadmin_sanitize_locale_name((string) $loc);
        }
    }
    $maintenance_enabled_locales = array_values(array_unique(array_filter($maintenance_enabled_locales)));
}

$maintenance_locale_count = count($maintenance_locales);
$site_locale              = get_locale();
$has_extra_locales        = $maintenance_locale_count > 1;

if (!function_exists('yooadmin_maintenance_settings_locale_label')) {
    /**
     * @param string $locale Locale code.
     */
    function yooadmin_maintenance_settings_locale_label(string $locale): string
    {
        if ($locale === 'en_US') {
            return __('English (United States)', 'yooadmin');
        }

        if (!function_exists('wp_get_available_translations')) {
            require_once ABSPATH . 'wp-admin/includes/translation-install.php';
        }

        $translations = wp_get_available_translations();
        if (isset($translations[ $locale ]['native_name'])) {
            return (string) $translations[ $locale ]['native_name'];
        }

        return $locale;
    }
}

?>
                        <section class="yp-tab-panel" id="tab-maintenance" data-panel="maintenance">
                            <div class="yooadmin-maintenance-settings">
                                <p class="yp-help yooadmin-security-card__lead"><?php esc_html_e('Close the public site for visitors while you work. Administrators can still access the dashboard and the front end.', 'yooadmin'); ?></p>
                                <table class="form-table yooadmin-security-toggle-table"><tbody>
                                    <tr class="yooadmin-security-master-toggle-row">
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-hammer yp-th-icon"></span>
                                                <span><?php esc_html_e('Maintenance mode', 'yooadmin'); ?></span>
                                            </div>
                                        </th>
                                        <td>
                                            <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_enabled]" value="0">
                                            <?php
                                            $maint_desc = __('When on, visitors see a maintenance page instead of the site.', 'yooadmin');
                                            $maint_on   = __('Maintenance mode on', 'yooadmin');
                                            $maint_off  = __('Maintenance mode off', 'yooadmin');
                                            $maint_toggle = $this->render_toggle_field(
                                                'maintenance_mode_enabled',
                                                $maintenance_mode_enabled ? $maint_on : $maint_off,
                                                $maint_desc,
                                                $maintenance_mode_enabled,
                                                'maintenance_mode_enabled',
                                                $this->opt_options,
                                                false
                                            );
                                            echo wp_kses($maint_toggle['toggle'], $this->get_toggle_allowed_html());
                                            ?>
                                        </td>
                                    </tr>
                                    <tr class="yooadmin-security-master-toggle-row">
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-visibility yp-th-icon"></span>
                                                <span><?php esc_html_e('Header badge when off', 'yooadmin'); ?></span>
                                            </div>
                                        </th>
                                        <td>
                                            <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_show_header_badge_when_off]" value="0">
                                            <?php
                                            $header_badge_when_off = !empty($opts['maintenance_mode_show_header_badge_when_off']);
                                            $header_badge_desc     = __('Show the maintenance tag in the YOOAdmin header or WordPress toolbar when maintenance mode is off. When hidden, it appears only while maintenance is on.', 'yooadmin');
                                            $header_badge_on       = __('Show maintenance tag in header when off', 'yooadmin');
                                            $header_badge_off      = __('Hide maintenance tag in header when off', 'yooadmin');
                                            $header_badge_toggle   = $this->render_toggle_field(
                                                'maintenance_mode_show_header_badge_when_off',
                                                $header_badge_when_off ? $header_badge_on : $header_badge_off,
                                                $header_badge_desc,
                                                $header_badge_when_off,
                                                'maintenance_mode_show_header_badge_when_off',
                                                $this->opt_options,
                                                false
                                            );
                                            echo wp_kses($header_badge_toggle['toggle'], $this->get_toggle_allowed_html());
                                            ?>
                                        </td>
                                    </tr>
                                </tbody></table>

                                <div class="yooadmin-maintenance-settings-body<?php echo $maintenance_mode_enabled ? '' : ' yooadmin-security-panel-body--disabled'; ?>">
                                    <table class="form-table"><tbody>
                                        <tr>
                                            <th scope="row">
                                                <div class="yp-th-content">
                                                    <span class="dashicons dashicons-format-image yp-th-icon"></span>
                                                    <span><?php esc_html_e('Background image', 'yooadmin'); ?></span>
                                                </div>
                                            </th>
                                            <td>
                                                <div class="yp-logo-uploader">
                                                    <img id="yooadmin-maintenance-image-preview" src="<?php echo esc_url($maintenance_mode_image_url); ?>" alt="" style="<?php echo $maintenance_mode_image_url !== '' ? '' : 'display:none;'; ?> max-width:240px; height:auto; border-radius:6px;">
                                                    <input type="hidden" id="yooadmin-maintenance-image-url" name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_image_url]" value="<?php echo esc_attr($maintenance_mode_image_url); ?>">
                                                    <?php
                                                    $maintenance_mode_image_id = isset($maintenance_mode_image_id)
                                                        ? (int) $maintenance_mode_image_id
                                                        : 0;
                                                    ?>
                                                    <input type="hidden" id="yooadmin-maintenance-image-id" name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_image_id]" value="<?php echo (int) $maintenance_mode_image_id; ?>">
                                                    <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" id="yooadmin-maintenance-image-choose"><?php esc_html_e('Choose image', 'yooadmin'); ?></button>
                                                    <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" id="yooadmin-maintenance-image-remove" <?php echo $maintenance_mode_image_url !== '' ? '' : 'style="display:none"'; ?>><?php esc_html_e('Remove', 'yooadmin'); ?></button>
                                                </div>
                                                <p class="description yooadmin-login-security-field-note"><?php esc_html_e('Uses the default login background when empty. Logo and logo width come from the Branding tab.', 'yooadmin'); ?></p>
                                            </td>
                                        </tr>
                                        <?php
                                        $maint_bg_overlay_default   = 50;
                                        $maint_bg_blur_default      = 50;
                                        $maint_card_overlay_default = 50;
                                        $maint_bg_overlay_val       = isset($maintenance_bg_overlay)
                                            ? (int) $maintenance_bg_overlay
                                            : $maint_bg_overlay_default;
                                        $maint_bg_blur_val          = isset($maintenance_bg_blur)
                                            ? (int) $maintenance_bg_blur
                                            : $maint_bg_blur_default;
                                        $maint_card_overlay_val     = isset($maintenance_card_overlay)
                                            ? (int) $maintenance_card_overlay
                                            : $maint_card_overlay_default;
                                        $maint_bg_overlay_val         = max(0, min(100, $maint_bg_overlay_val));
                                        $maint_bg_blur_val            = max(0, min(100, $maint_bg_blur_val));
                                        $maint_card_overlay_val       = max(0, min(100, $maint_card_overlay_val));
                                        $maint_preview_bg_overlay     = $maint_bg_overlay_val / 100;
                                        $maint_preview_bg_blur        = $maint_bg_blur_val / 100;
                                        $maint_preview_card_overlay   = $maint_card_overlay_val / 100;
                                        $maint_default_bg = '';
                                        if (defined('YOOADMIN_PLUGIN_FILE')
                                            && is_readable(dirname(YOOADMIN_PLUGIN_FILE) . '/assets/images/login-background.jpg')) {
                                            $maint_default_bg = plugins_url('assets/images/login-background.jpg', YOOADMIN_PLUGIN_FILE);
                                        }
                                        $maint_preview_bg = $maintenance_mode_image_url !== ''
                                            ? $maintenance_mode_image_url
                                            : $maint_default_bg;
                                        ?>
                                        <tr>
                                            <th scope="row">
                                                <div class="yp-th-content">
                                                    <span class="dashicons dashicons-format-image yp-th-icon"></span>
                                                    <span><?php esc_html_e('Image overlay', 'yooadmin'); ?></span>
                                                    <span class="yp-help-icon">
                                                        <span class="dashicons dashicons-editor-help"></span>
                                                        <span class="yp-tooltip"><?php esc_html_e('Darkens the background photo. Does not blur the image — use Background blur for that.', 'yooadmin'); ?></span>
                                                    </span>
                                                </div>
                                            </th>
                                            <td>
                                                <input type="hidden"
                                                       name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_bg_overlay_opacity]"
                                                       id="yooadmin-maintenance-bg-overlay-opacity-post"
                                                       value="<?php echo (int) $maint_bg_overlay_val; ?>">
                                                <div class="yp-range yp-range--modern yooadmin-maintenance-overlay-range yp-range--compact">
                                                    <div class="yp-range__track-wrap">
                                                        <input type="range"
                                                               min="0"
                                                               max="100"
                                                               step="1"
                                                               id="yooadmin-maintenance-bg-overlay-opacity"
                                                               value="<?php echo (int) $maint_bg_overlay_val; ?>"
                                                               aria-label="<?php esc_attr_e('Background image overlay strength', 'yooadmin'); ?>"
                                                               aria-valuemin="0"
                                                               aria-valuemax="100"
                                                               aria-valuenow="<?php echo (int) $maint_bg_overlay_val; ?>">
                                                    </div>
                                                    <span class="yp-range__value">
                                                        <strong id="yooadmin-maintenance-bg-overlay-opacity-val"><?php echo (int) $maint_bg_overlay_val; ?></strong>%
                                                    </span>
                                                    <button type="button" class="button button-secondary yp-yoo-btn yp-yoo-btn--soft" id="yooadmin-maintenance-bg-overlay-opacity-reset">
                                                        <?php esc_html_e('Reset to default', 'yooadmin'); ?>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">
                                                <div class="yp-th-content">
                                                    <span class="dashicons dashicons-image-filter yp-th-icon"></span>
                                                    <span><?php esc_html_e('Background blur', 'yooadmin'); ?></span>
                                                    <span class="yp-help-icon">
                                                        <span class="dashicons dashicons-editor-help"></span>
                                                        <span class="yp-tooltip"><?php esc_html_e('Fog / blur on the background photo. 0% = sharp image; higher = softer background. Independent from image overlay darkness.', 'yooadmin'); ?></span>
                                                    </span>
                                                </div>
                                            </th>
                                            <td>
                                                <input type="hidden"
                                                       name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_bg_blur]"
                                                       id="yooadmin-maintenance-bg-blur-post"
                                                       value="<?php echo (int) $maint_bg_blur_val; ?>">
                                                <div class="yp-range yp-range--modern yooadmin-maintenance-overlay-range yp-range--compact">
                                                    <div class="yp-range__track-wrap">
                                                        <input type="range"
                                                               min="0"
                                                               max="100"
                                                               step="1"
                                                               id="yooadmin-maintenance-bg-blur"
                                                               value="<?php echo (int) $maint_bg_blur_val; ?>"
                                                               aria-label="<?php esc_attr_e('Background image blur strength', 'yooadmin'); ?>"
                                                               aria-valuemin="0"
                                                               aria-valuemax="100"
                                                               aria-valuenow="<?php echo (int) $maint_bg_blur_val; ?>">
                                                    </div>
                                                    <span class="yp-range__value">
                                                        <strong id="yooadmin-maintenance-bg-blur-val"><?php echo (int) $maint_bg_blur_val; ?></strong>%
                                                    </span>
                                                    <button type="button" class="button button-secondary yp-yoo-btn yp-yoo-btn--soft" id="yooadmin-maintenance-bg-blur-reset">
                                                        <?php esc_html_e('Reset to default', 'yooadmin'); ?>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">
                                                <div class="yp-th-content">
                                                    <span class="dashicons dashicons-align-center yp-th-icon"></span>
                                                    <span><?php esc_html_e('Message card overlay', 'yooadmin'); ?></span>
                                                    <span class="yp-help-icon">
                                                        <span class="dashicons dashicons-editor-help"></span>
                                                        <span class="yp-tooltip"><?php esc_html_e('How dark the glass panel is behind the title and message. Independent from the background image overlay.', 'yooadmin'); ?></span>
                                                    </span>
                                                </div>
                                            </th>
                                            <td>
                                                <input type="hidden"
                                                       name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_card_overlay_opacity]"
                                                       id="yooadmin-maintenance-card-overlay-opacity-post"
                                                       value="<?php echo (int) $maint_card_overlay_val; ?>">
                                                <div class="yp-range yp-range--modern yooadmin-maintenance-overlay-range">
                                                    <div class="yp-range__track-wrap">
                                                        <input type="range"
                                                               min="0"
                                                               max="100"
                                                               step="1"
                                                               id="yooadmin-maintenance-card-overlay-opacity"
                                                               value="<?php echo (int) $maint_card_overlay_val; ?>"
                                                               aria-label="<?php esc_attr_e('Message card overlay strength', 'yooadmin'); ?>"
                                                               aria-valuemin="0"
                                                               aria-valuemax="100"
                                                               aria-valuenow="<?php echo (int) $maint_card_overlay_val; ?>">
                                                    </div>
                                                    <span class="yp-range__value">
                                                        <strong id="yooadmin-maintenance-card-overlay-opacity-val"><?php echo (int) $maint_card_overlay_val; ?></strong>%
                                                    </span>
                                                    <button type="button" class="button button-secondary yp-yoo-btn yp-yoo-btn--soft" id="yooadmin-maintenance-card-overlay-opacity-reset">
                                                        <?php esc_html_e('Reset to default', 'yooadmin'); ?>
                                                    </button>
                                                </div>
                                                <?php
                                                $maint_logo_pack = function_exists('yooadmin_maintenance_resolve_page_logo')
                                                    ? yooadmin_maintenance_resolve_page_logo()
                                                    : ['url' => '', 'max_w' => 150];
                                                $maint_preview_logo_url = trim((string) ($maint_logo_pack['url'] ?? ''));
                                                $maint_preview_logo_max_w = max(20, (int) ($maint_logo_pack['max_w'] ?? 150));
                                                ?>
                                                <div class="yooadmin-maintenance-overlay-preview"
                                                     id="yooadmin-maintenance-overlay-preview"
                                                     data-default-bg-opacity="<?php echo (int) $maint_bg_overlay_default; ?>"
                                                     data-default-bg-blur="<?php echo (int) $maint_bg_blur_default; ?>"
                                                     data-default-card-opacity="<?php echo (int) $maint_card_overlay_default; ?>"
                                                     <?php echo $maint_default_bg !== '' ? ' data-default-maint-bg="' . esc_attr($maint_default_bg) . '"' : ''; ?>
                                                     <?php echo $maint_preview_logo_url !== '' ? ' data-preview-logo="' . esc_attr($maint_preview_logo_url) . '"' : ''; ?>
                                                     style="--yooadmin-maint-preview-overlay:<?php echo esc_attr((string) round($maint_preview_bg_overlay, 3)); ?>;--yooadmin-maint-preview-blur:<?php echo esc_attr((string) round($maint_preview_bg_blur, 3)); ?>;--yooadmin-maint-preview-card:<?php echo esc_attr((string) round($maint_preview_card_overlay, 3)); ?>;--yooadmin-maint-preview-logo-max-w:<?php echo (int) $maint_preview_logo_max_w; ?>px;<?php echo $maint_preview_bg !== '' ? '--yooadmin-maint-preview-bg:url(\'' . esc_url($maint_preview_bg) . '\');' : ''; ?>">
                                                    <div class="yooadmin-maintenance-overlay-preview__media" aria-hidden="true"></div>
                                                    <div class="yooadmin-maintenance-overlay-preview__blur" aria-hidden="true"></div>
                                                    <div class="yooadmin-maintenance-overlay-preview__shade" aria-hidden="true"></div>
                                                    <div class="yooadmin-maintenance-overlay-preview__card" aria-hidden="true">
                                                        <?php if ($maint_preview_logo_url !== '') : ?>
                                                            <div class="yooadmin-maintenance-overlay-preview__logo">
                                                                <img class="yooadmin-maintenance-overlay-preview__logo-img" src="<?php echo esc_url($maint_preview_logo_url); ?>" alt="" />
                                                            </div>
                                                        <?php endif; ?>
                                                        <span class="yooadmin-maintenance-overlay-preview__card-title"><?php esc_html_e('Site under maintenance', 'yooadmin'); ?></span>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">
                                                <div class="yp-th-content">
                                                    <span class="dashicons dashicons-edit yp-th-icon"></span>
                                                    <span><?php esc_html_e('Default title', 'yooadmin'); ?></span>
                                                </div>
                                            </th>
                                            <td>
                                                <p class="ylp-field ylp-field--with-icon ylp-field--settings">
                                                    <span class="ylp-field__icon dashicons dashicons-edit" aria-hidden="true"></span>
                                                    <input type="text" class="ylp-input ylp-input--with-icon ylp-input--settings" name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_title]" value="<?php echo esc_attr($maintenance_mode_title); ?>" placeholder="<?php esc_attr_e('Site under maintenance', 'yooadmin'); ?>" />
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">
                                                <div class="yp-th-content">
                                                    <span class="dashicons dashicons-text yp-th-icon"></span>
                                                    <span><?php esc_html_e('Default message', 'yooadmin'); ?></span>
                                                </div>
                                            </th>
                                            <td>
                                                <p class="ylp-field ylp-field--settings ylp-field--textarea">
                                                    <textarea class="ylp-input ylp-input--settings ylp-input--textarea" rows="3" name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_message]" placeholder="<?php esc_attr_e('We are performing scheduled maintenance. Please check back soon.', 'yooadmin'); ?>"><?php echo esc_textarea($maintenance_mode_message); ?></textarea>
                                                </p>
                                            </td>
                                        </tr>
                                    </tbody></table>

                                    <?php if ($has_extra_locales) : ?>
                                        <h3 class="yooadmin-maintenance-settings__langs-title"><?php esc_html_e('Per-language overrides', 'yooadmin'); ?></h3>
                                        <p class="description yooadmin-login-security-field-note yooadmin-maintenance-settings__langs-hint">
                                            <?php
                                            printf(
                                                /* translators: %d: number of installed languages */
                                                esc_html(_n(
                                                    'Your site has %d language available. Enable a language below to customize its title and message.',
                                                    'Your site has %d languages available. Enable each language you want to customize — fields appear only for enabled languages.',
                                                    $maintenance_locale_count,
                                                    'yooadmin'
                                                )),
                                                (int) $maintenance_locale_count
                                            );
                                            ?>
                                        </p>
                                        <div class="yooadmin-maintenance-locales" data-yooadmin-maintenance-locales>
                                            <?php foreach ($maintenance_locales as $maint_locale) :
                                                $maint_locale = (string) $maint_locale;
                                                if ($maint_locale === $site_locale) {
                                                    continue;
                                                }
                                                $lang_label  = yooadmin_maintenance_settings_locale_label($maint_locale);
                                                $locale_on   = in_array($maint_locale, $maintenance_enabled_locales, true);
                                                $title_val   = isset($maintenance_titles[ $maint_locale ]) ? (string) $maintenance_titles[ $maint_locale ] : '';
                                                $message_val = isset($maintenance_messages[ $maint_locale ]) ? (string) $maintenance_messages[ $maint_locale ] : '';
                                                $fields_id   = 'yooadmin-maint-fields-' . sanitize_html_class($maint_locale);
                                                ?>
                                            <div class="yooadmin-maintenance-locale<?php echo $locale_on ? ' is-enabled' : ''; ?>" data-locale="<?php echo esc_attr($maint_locale); ?>">
                                                <label class="yp-toggle-switch yooadmin-maintenance-locale__toggle" for="yooadmin-maint-enable-<?php echo esc_attr($maint_locale); ?>">
                                                    <input type="checkbox"
                                                           class="yooadmin-maintenance-locale-enable"
                                                           id="yooadmin-maint-enable-<?php echo esc_attr($maint_locale); ?>"
                                                           name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_enabled_locales][]"
                                                           value="<?php echo esc_attr($maint_locale); ?>"
                                                           <?php checked($locale_on); ?>
                                                           autocomplete="off">
                                                    <span class="yp-toggle-slider"></span>
                                                    <span class="screen-reader-text"><?php echo esc_html($lang_label); ?></span>
                                                </label>
                                                <div class="yooadmin-maintenance-locale__meta">
                                                    <span class="yooadmin-maintenance-locale__label"><?php echo esc_html($lang_label); ?></span>
                                                    <code class="yooadmin-maintenance-lang-row__code" dir="ltr"><?php echo esc_html($maint_locale); ?></code>
                                                </div>
                                                <div class="yooadmin-maintenance-locale__fields<?php echo $locale_on ? ' is-open' : ''; ?>" id="<?php echo esc_attr($fields_id); ?>"<?php echo $locale_on ? '' : ' hidden'; ?>>
                                                    <p class="ylp-field ylp-field--with-icon ylp-field--settings yooadmin-maintenance-locale__title-field">
                                                        <span class="ylp-field__icon dashicons dashicons-edit" aria-hidden="true"></span>
                                                        <input type="text" class="ylp-input ylp-input--with-icon ylp-input--settings" id="yooadmin-maint-title-<?php echo esc_attr($maint_locale); ?>" name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_titles][<?php echo esc_attr($maint_locale); ?>]" value="<?php echo esc_attr($title_val); ?>" placeholder="<?php esc_attr_e('Title (optional)', 'yooadmin'); ?>" />
                                                    </p>
                                                    <p class="ylp-field ylp-field--settings ylp-field--textarea yooadmin-maintenance-locale__message-field">
                                                        <textarea class="ylp-input ylp-input--settings ylp-input--textarea" rows="2" id="yooadmin-maint-msg-<?php echo esc_attr($maint_locale); ?>" name="<?php echo esc_attr($this->opt_options); ?>[maintenance_mode_messages][<?php echo esc_attr($maint_locale); ?>]" placeholder="<?php esc_attr_e('Message (optional)', 'yooadmin'); ?>"><?php echo esc_textarea($message_val); ?></textarea>
                                                    </p>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </section>
