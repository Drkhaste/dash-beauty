<?php
defined('ABSPATH') || exit;

if (function_exists('yooadmin_network_update_center_bootstrap')) {
    yooadmin_network_update_center_bootstrap();
}

if (!class_exists('YOOAdmin_Network_Update_Center_Page', false)) {

final class YOOAdmin_Network_Update_Center_Page
{
    /** @var self|null */
    private static $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        if (!is_multisite()) {
            return;
        }

        add_action('admin_init', [$this, 'set_page_title'], 0);
        add_action('network_admin_menu', [$this, 'register_network_page'], 999998);
    }

    private function text_domain(): string
    {
        return function_exists('yooadmin_multisite_text_domain')
            ? yooadmin_multisite_text_domain()
            : 'yooadmin';
    }

    public function set_page_title(): void
    {
        if (!function_exists('yooadmin_network_update_center_is_screen') || !yooadmin_network_update_center_is_screen()) {
            return;
        }

        global $title;
        $title = __('YOOUpdate Center', 'yooadmin');
    }

    public function register_network_page(): void
    {
        if (!function_exists('yooadmin_network_register_hidden_admin_page')) {
            return;
        }

        $hook = yooadmin_network_register_hidden_admin_page(
            __('YOOUpdate Center', 'yooadmin'),
            yooadmin_network_update_center_page_slug(),
            [$this, 'render_page']
        );

        if (!$hook) {
            return;
        }

        add_action(
            "load-{$hook}",
            function (): void {
                if (!function_exists('yooadmin_network_update_center_should_use') || !yooadmin_network_update_center_should_use()) {
                    $classic = function_exists('yooadmin_network_update_center_classic_url')
                        ? yooadmin_network_update_center_classic_url()
                        : network_admin_url('update-core.php?yooadmin_no_redirect=1');
                    wp_safe_redirect($classic);
                    exit;
                }

                wp_enqueue_style('plugin-install');
                wp_enqueue_script('plugin-install');
                wp_enqueue_script('updates');
                add_thickbox();

                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                if (!empty($_GET['force-check']) || !empty($_GET['force_check'])) {
                    wp_version_check([], true);
                    if (function_exists('wp_update_plugins')) {
                        wp_update_plugins();
                    }
                    if (function_exists('wp_update_themes')) {
                        wp_update_themes();
                    }
                }

                add_action(
                    'admin_enqueue_scripts',
                    static function (): void {
                        wp_localize_script(
                            'updates',
                            '_wpUpdatesItemCounts',
                            [
                                'totals' => wp_get_update_data(),
                            ]
                        );

                        if (!defined('YOOADMIN_PANEL_DIR') || !defined('YOOADMIN_PANEL_URL')) {
                            return;
                        }

                        $js_rel = 'assets/js/admin/update-center-page.js';
                        $js_abs = YOOADMIN_PANEL_DIR . $js_rel;
                        if (!file_exists($js_abs) || !class_exists('YOOAdmin_Update_Center_Ajax')) {
                            return;
                        }

                        wp_enqueue_script(
                            'yooadmin-update-center-page',
                            YOOADMIN_PANEL_URL . $js_rel,
                            ['jquery', 'updates'],
                            (string) filemtime($js_abs),
                            true
                        );

                        $uc_url = function_exists('yooadmin_network_update_center_url')
                            ? yooadmin_network_update_center_url()
                            : network_admin_url('admin.php?page=yooadmin-network-update-center');

                        wp_localize_script(
                            'yooadmin-update-center-page',
                            'yooadminUpdateCenter',
                            [
                                'nonce'     => wp_create_nonce(YOOAdmin_Update_Center_Ajax::NONCE_ACTION),
                                'ajaxUrl'   => admin_url('admin-ajax.php'),
                                'wpVersion' => get_bloginfo('version'),
                                'urls'      => [
                                    'updateCenter' => $uc_url,
                                ],
                                'i18n'      => [
                                    'working'                  => __('Working…', 'yooadmin'),
                                    /* translators: 1: Current WordPress version, 2: Target WordPress version. */
                                    'coreUpdatingFromTo'       => __('Updating from %1$s to %2$s', 'yooadmin'),
                                    /* translators: %s: WordPress version being reinstalled. */
                                    'coreReinstallingTitle'    => __('Reinstalling WordPress %s', 'yooadmin'),
                                    'progressOk'               => __('OK', 'yooadmin'),
                                    'checking'                 => __('Checking for updates…', 'yooadmin'),
                                    'done'                     => __('Done.', 'yooadmin'),
                                    'error'                    => __('Something went wrong.', 'yooadmin'),
                                    'requestFailed'            => __('Request failed. Please try again.', 'yooadmin'),
                                    'selectPlugins'            => __('Please select one or more plugins.', 'yooadmin'),
                                    'selectThemes'             => __('Please select one or more themes.', 'yooadmin'),
                                    /* translators: %s: Plugin or theme name being updated. */
                                    'updatingItem'             => __('Updating %s…', 'yooadmin'),
                                    'plugin'                   => __('Plugin', 'yooadmin'),
                                    'theme'                    => __('Theme', 'yooadmin'),
                                    'jsonCorrupt'              => __('The server sent an incomplete response. If the update finished, refresh this page.', 'yooadmin'),
                                    'successTitle'             => __('Update complete', 'yooadmin'),
                                    'pluginUpdatedSuccess'     => __('Plugin updated successfully.', 'yooadmin'),
                                    'pluginsUpdatedSuccess'    => __('Plugins updated successfully.', 'yooadmin'),
                                    'themeUpdatedSuccess'      => __('Theme updated successfully.', 'yooadmin'),
                                    'themesUpdatedSuccess'     => __('Themes updated successfully.', 'yooadmin'),
                                    'translationsUpdatedSuccess' => __('Translations updated successfully.', 'yooadmin'),
                                    'updateFailedTitle'        => __('Update failed', 'yooadmin'),
                                    'allUpdatesDone'           => __('All updates finished successfully.', 'yooadmin'),
                                    /* translators: %s: WordPress version after a successful core update. */
                                    'coreUpdatedToast'         => __('WordPress was updated successfully to %s', 'yooadmin'),
                                ],
                            ]
                        );
                    },
                    20
                );
            }
        );
    }

    public function render_page(): void
    {
        if (
            function_exists('yooadmin_network_update_center_user_can_view')
            && !yooadmin_network_update_center_user_can_view()
        ) {
            wp_die(esc_html__('Sorry, you are not allowed to update this site.', 'yooadmin'));
        }

        if (!function_exists('yooadmin_network_update_center_should_use') || !yooadmin_network_update_center_should_use()) {
            $classic = function_exists('yooadmin_network_update_center_classic_url')
                ? yooadmin_network_update_center_classic_url()
                : network_admin_url('update-core.php?yooadmin_no_redirect=1');
            wp_safe_redirect($classic);
            exit;
        }

        global $title;
        $title = __('YOOUpdate Center', 'yooadmin');

        $template = defined('YOOADMIN_PANEL_DIR')
            ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-update-center/index.php'
            : '';

        if ($template && is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('YOOUpdate Center', 'yooadmin') . '</h1><p>' . esc_html__('Template missing.', 'yooadmin') . '</p></div>';
    }
}

}

YOOAdmin_Network_Update_Center_Page::get_instance();
