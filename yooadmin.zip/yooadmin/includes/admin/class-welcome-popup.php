<?php
/**
 * Legacy post-wizard welcome modal — disabled.
 *
 * Replaced by {@see YOOAdmin_Guided_Tour} unified intro (welcome copy + auto-start tour).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * @deprecated Unified guided tour intro; hooks are not registered.
 */
final class YOOAdmin_Welcome_Popup {

    /**
     * Bootstrap hooks (no-op — modal retired).
     */
    public static function init(): void {
    }

    /**
     * @return bool
     */
    public static function should_show(): bool {
        return false;
    }

    /**
     * @return bool
     */
    private static function is_yooadmin_dashboard_screen(): bool {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        return isset($_GET['page']) && 'yooadmin-dashboard' === sanitize_key(wp_unslash($_GET['page']));
    }

    /**
     * @param string $hook
     */
    public static function enqueue_assets($hook = ''): void {
        if (!self::should_show()) {
            return;
        }

        $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
        $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);

        $css_rel = 'assets/css/admin/welcome-popup.css';
        $js_rel  = 'assets/js/admin/welcome-popup.js';

        if (is_readable($base_dir . $css_rel)) {
            wp_enqueue_style('dashicons');
            wp_enqueue_style(
                'yooadmin-welcome-popup',
                $base_url . $css_rel,
                [],
                (string) filemtime($base_dir . $css_rel)
            );
        }

        if (is_readable($base_dir . $js_rel)) {
            wp_enqueue_script(
                'yooadmin-welcome-popup',
                $base_url . $js_rel,
                ['jquery'],
                (string) filemtime($base_dir . $js_rel),
                true
            );

            wp_localize_script(
                'yooadmin-welcome-popup',
                'yooadmWelcomePopup',
                [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce'   => wp_create_nonce('yooadmin_welcome_popup'),
                ]
            );
        }
    }

    /**
     * Print modal markup in admin footer.
     */
    public static function render_modal(): void {
        if (!self::should_show()) {
            return;
        }

        $settings_url = admin_url('admin.php?page=yooadmin-settings');
        $image_url    = plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/welcome-popup-promo.svg';

        $wizard_features = [
            __('Focus Mode is on', 'yooadmin'),
            __('Your dashboard is ready', 'yooadmin'),
        ];
        ?>
        <div id="yooadmin-welcome-popup" class="ywp-overlay" hidden aria-hidden="true">
            <div class="ywp-dialog" role="dialog" aria-modal="true" aria-labelledby="ywp-welcome-title">
                <div class="ywp-layout">
                    <div class="ywp-copy">
                        <p class="ywp-eyebrow"><?php esc_html_e('YOOAdmin', 'yooadmin'); ?></p>
                        <h2 id="ywp-welcome-title" class="ywp-title">
                            <?php esc_html_e('Welcome to your new workspace 👋', 'yooadmin'); ?>
                        </h2>
                        <p class="ywp-lead">
                            <?php esc_html_e('Your workspace is ready. Change layout and colors anytime in Settings.', 'yooadmin'); ?>
                        </p>
                        <ul class="ywp-features">
                            <?php foreach ($wizard_features as $feature) : ?>
                                <li>
                                    <span class="ywp-check dashicons dashicons-yes-alt" aria-hidden="true"></span>
                                    <span><?php echo esc_html($feature); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="ywp-actions">
                            <button type="button" class="button button-primary ywp-welcome-got-it">
                                <?php esc_html_e('Got it', 'yooadmin'); ?>
                            </button>
                            <a href="<?php echo esc_url($settings_url); ?>" class="button ywp-welcome-open-settings">
                                <?php esc_html_e('Open Settings', 'yooadmin'); ?>
                            </a>
                        </div>
                    </div>
                    <div class="ywp-visual" aria-hidden="true">
                        <div class="ywp-visual-controls">
                            <button type="button" class="ywp-close" aria-label="<?php echo esc_attr__('Close', 'yooadmin'); ?>">
                                <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                            </button>
                        </div>
                        <img
                            class="ywp-image"
                            src="<?php echo esc_url($image_url); ?>"
                            alt=""
                            width="320"
                            height="280"
                            loading="lazy"
                            decoding="async"
                        />
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * @return string
     */
    private static function required_capability(): string {
        if (function_exists('yooadmin_required_cap')) {
            return yooadmin_required_cap('settings');
        }

        return 'manage_options';
    }
}
