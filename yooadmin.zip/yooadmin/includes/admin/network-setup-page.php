<?php
defined('ABSPATH') || exit;

require_once YOOADMIN_PANEL_DIR . 'includes/admin/network-setup-render.php';

if (!class_exists('YOOAdmin_Network_Setup_Page', false)) {

final class YOOAdmin_Network_Setup_Page
{
    /** @var self|null */
    private static $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        if (!is_multisite()) {
            return;
        }

        add_action('admin_init', [$this, 'set_page_title'], 0);
        add_action('network_admin_menu', [$this, 'register_network_page'], 999998);
    }

    private function text_domain(): string
    {
        return yooadmin_network_setup_text_domain();
    }

    public function set_page_title(): void
    {
        if (!function_exists('yooadmin_network_setup_is_screen') || !yooadmin_network_setup_is_screen()) {
            return;
        }

        global $title;
        $title = __('Network Setup', 'yooadmin');
    }

    public function register_network_page(): void
    {
        if (!function_exists('yooadmin_network_register_hidden_admin_page')) {
            return;
        }

        $hook = yooadmin_network_register_hidden_admin_page(
            __('Network Setup', 'yooadmin'),
            yooadmin_network_setup_page_slug(),
            [$this, 'render_page']
        );

        if (!$hook) {
            return;
        }

        add_action(
            "load-{$hook}",
            function (): void {
                if (!yooadmin_network_setup_should_use()) {
                    wp_safe_redirect(yooadmin_network_setup_classic_url());
                    exit;
                }
            }
        );
    }

    public function render_page(): void
    {
        if (!yooadmin_network_setup_user_can_view()) {
            wp_die(esc_html__('Sorry, you are not allowed to manage network options.', 'yooadmin'));
        }

        if (!yooadmin_network_setup_should_use()) {
            wp_safe_redirect(yooadmin_network_setup_classic_url());
            exit;
        }

        global $title;
        $title = __('Network Setup', 'yooadmin');

        $template = YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-setup/index.php';
        if (is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Network Setup', 'yooadmin') . '</h1><p>' . esc_html__('Template missing.', 'yooadmin') . '</p></div>';
    }
}

}

YOOAdmin_Network_Setup_Page::get_instance();
