<?php
/**
 * Enqueue global toast assets for YOOAdmin custom list screens (posts/pages).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Global top-right toast (yp-toast-message) — use on any YOOAdmin admin screen.
 */
function yooadmin_enqueue_yp_admin_toast_assets(): void {
    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $base_dir  = plugin_dir_path($base_file);
    $base_url  = plugin_dir_url($base_file);

    $toast_css_rel = 'assets/css/admin/yp-admin-toast.css';
    $toast_css_abs = $base_dir . $toast_css_rel;
    if (is_readable($toast_css_abs)) {
        $deps = wp_style_is('yooadmin-core', 'registered') || wp_style_is('yooadmin-core', 'enqueued')
            ? ['yooadmin-core']
            : [];
        wp_enqueue_style(
            'yooadmin-yp-admin-toast',
            $base_url . $toast_css_rel,
            $deps,
            (string) filemtime($toast_css_abs)
        );
    }

    $toast_js_rel = 'assets/js/admin/yp-admin-toast.js';
    $toast_js_abs = $base_dir . $toast_js_rel;
    if (is_readable($toast_js_abs)) {
        wp_enqueue_script(
            'yooadmin-yp-admin-toast',
            $base_url . $toast_js_rel,
            ['jquery'],
            (string) filemtime($toast_js_abs),
            true
        );
    }
}

/**
 * Bottom-right toast stack (yooadmin-toast) for settings and other YOOAdmin screens.
 */
function yooadmin_enqueue_settings_toast_assets(): void {
    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $base_dir  = plugin_dir_path($base_file);
    $base_url  = plugin_dir_url($base_file);

    if (function_exists('yooadmin_enqueue_yp_admin_toast_assets')) {
        yooadmin_enqueue_yp_admin_toast_assets();
    }

    $toast_css_rel = 'assets/css/admin/toast-notifications.css';
    $toast_js_rel  = 'assets/js/admin/toast-notifications.js';
    $toast_css_abs = $base_dir . $toast_css_rel;
    $toast_js_abs  = $base_dir . $toast_js_rel;

    if (is_readable($toast_css_abs) && !wp_style_is('yooadmin-toast-notifications', 'enqueued')) {
        wp_enqueue_style(
            'yooadmin-toast-notifications',
            $base_url . $toast_css_rel,
            [],
            (string) filemtime($toast_css_abs)
        );
    }

    if (!is_readable($toast_js_abs) || wp_script_is('yooadmin-toast-notifications', 'enqueued')) {
        return;
    }

    $deps = ['jquery'];
    $classifier_rel = 'assets/js/admin/yp-notice-classifier.js';
    $classifier_abs = $base_dir . $classifier_rel;
    if (is_readable($classifier_abs)) {
        if (!wp_script_is('yooadmin-notice-classifier', 'registered') && !wp_script_is('yooadmin-notice-classifier', 'enqueued')) {
            wp_enqueue_script(
                'yooadmin-notice-classifier',
                $base_url . $classifier_rel,
                [],
                (string) filemtime($classifier_abs),
                true
            );
        }
        if (wp_script_is('yooadmin-notice-classifier', 'registered') || wp_script_is('yooadmin-notice-classifier', 'enqueued')) {
            $deps[] = 'yooadmin-notice-classifier';
        }
    }

    wp_enqueue_script(
        'yooadmin-toast-notifications',
        $base_url . $toast_js_rel,
        $deps,
        (string) filemtime($toast_js_abs),
        true
    );
}

/**
 * Toast stack for custom posts/pages list screens.
 */
function yooadmin_enqueue_list_screen_toast_assets(): void {
    yooadmin_enqueue_yp_admin_toast_assets();

    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $base_dir  = plugin_dir_path($base_file);
    $base_url  = plugin_dir_url($base_file);

    $list_toast_rel = 'assets/js/admin/list-screen-toast.js';
    $list_toast_abs = $base_dir . $list_toast_rel;
    if (!is_readable($list_toast_abs)) {
        return;
    }

    $deps = ['jquery'];
    if (wp_script_is('yooadmin-notice-classifier', 'registered') || wp_script_is('yooadmin-notice-classifier', 'enqueued')) {
        $deps[] = 'yooadmin-notice-classifier';
    }
    if (wp_script_is('yooadmin-yp-admin-toast', 'registered') || wp_script_is('yooadmin-yp-admin-toast', 'enqueued')) {
        $deps[] = 'yooadmin-yp-admin-toast';
    }

    wp_enqueue_script(
        'yooadmin-list-screen-toast',
        $base_url . $list_toast_rel,
        $deps,
        (string) filemtime($list_toast_abs),
        true
    );
}

/**
 * @param string $classes
 * @return string
 */
function yooadmin_filter_list_screen_body_class(string $classes): string {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- screen detection only.
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    if ($page === 'yooadmin-posts') {
        return trim($classes . ' yooadmin-posts-screen yoo-list-screen');
    }
    if ($page === 'yooadmin-comments') {
        return trim($classes . ' yooadmin-comments-screen yoo-list-screen');
    }
    if ($page === 'yooadmin-pages') {
        return trim($classes . ' yooadmin-pages-screen yoo-list-screen');
    }
    return $classes;
}

add_filter('admin_body_class', 'yooadmin_filter_list_screen_body_class', 20);
