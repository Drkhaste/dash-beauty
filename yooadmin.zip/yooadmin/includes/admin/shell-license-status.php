<?php
/**
 * YOOAdmin shell — read-only license status for non-admin users.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * License badge + modal copy for the admin shell header.
 *
 * @return array{
 *     status_class: string,
 *     status_text: string,
 *     status_icon: string,
 *     is_active: bool,
 *     license_status: string,
 *     display_status: string,
 *     modal_title: string,
 *     modal_message: string,
 *     modal_icon: string,
 *     modal_type: string
 * }
 */
function yooadmin_get_shell_license_status(): array {
    if (function_exists('yooadmin_load_admin_ui_textdomain')) {
        yooadmin_load_admin_ui_textdomain();
    }

    $defaults = [
        'status_class'   => 'inactive',
        'status_text'    => __('Connect Account', 'yooadmin'),
        'status_icon'    => 'dashicons-admin-users',
        'is_active'      => false,
        'license_status' => 'inactive',
        'display_status' => 'inactive',
        'modal_title'    => __('YOOAdmin License', 'yooadmin'),
        'modal_message'  => __(
            'The YOOAdmin license for this site is not connected. Please contact your site administrator.',
            'yooadmin'
        ),
        'modal_icon'     => 'dashicons-info',
        'modal_type'     => 'info',
    ];

    if (!class_exists('YOOAdmin_License_Manager')) {
        return $defaults;
    }

    $license_manager = YOOAdmin_License_Manager::get_instance();
    $license_data    = $license_manager->get_license_data();
    $is_active       = $license_manager->is_license_active();
    $license_status  = isset($license_data['status']) ? sanitize_key((string) $license_data['status']) : 'inactive';

    $status_class = 'inactive';
    $status_text  = __('Connect Account', 'yooadmin');

    $suspension_source = $license_data['suspension_source'] ?? '';
    $display_status    = $license_status;
    if ($license_status === 'suspended' && $suspension_source === 'billing') {
        $display_status = 'expired';
    }

    if ($is_active) {
        $status_class = 'active';
        $status_text  = __('Active', 'yooadmin');
    } elseif ($license_status === 'expiring') {
        $status_class = 'expiring';
        $status_text  = __('Expiring Soon', 'yooadmin');
    } elseif (in_array($display_status, ['suspended', 'expired', 'revoked'], true)) {
        $status_class = $display_status === 'suspended' ? 'suspended' : 'expired';
        $status_text  = $display_status === 'expired'
            ? __('Expired', 'yooadmin')
            : ($display_status === 'suspended' ? __('Suspended', 'yooadmin') : __('Revoked', 'yooadmin'));
    }

    $status_icon = 'dashicons-admin-users';
    if ($is_active) {
        $status_icon = 'dashicons-yes-alt';
    } elseif ($license_status === 'expiring') {
        $status_icon = 'dashicons-clock';
    } elseif (in_array($display_status, ['suspended', 'expired', 'revoked'], true)) {
        $status_icon = 'dashicons-warning';
    }

    $admin_hint = __(
        'Please contact your site administrator if you need help with the license.',
        'yooadmin'
    );

    if ($is_active) {
        $modal_message = __(
            'The YOOAdmin license for this site is active.',
            'yooadmin'
        );
        $modal_icon    = 'dashicons-yes-alt';
        $modal_type    = 'success';
    } elseif ($license_status === 'expiring') {
        $modal_message = __(
            'The YOOAdmin license for this site is expiring soon.',
            'yooadmin'
        ) . ' ' . $admin_hint;
        $modal_icon    = 'dashicons-clock';
        $modal_type    = 'warning';
    } elseif ($display_status === 'expired') {
        $modal_message = __(
            'The YOOAdmin license for this site has expired.',
            'yooadmin'
        ) . ' ' . $admin_hint;
        $modal_icon    = 'dashicons-warning';
        $modal_type    = 'warning';
    } elseif ($display_status === 'suspended') {
        $modal_message = __(
            'The YOOAdmin license for this site is suspended.',
            'yooadmin'
        ) . ' ' . $admin_hint;
        $modal_icon    = 'dashicons-warning';
        $modal_type    = 'warning';
    } elseif ($display_status === 'revoked') {
        $modal_message = __(
            'The YOOAdmin license for this site has been revoked.',
            'yooadmin'
        ) . ' ' . $admin_hint;
        $modal_icon    = 'dashicons-warning';
        $modal_type    = 'warning';
    } else {
        $modal_message = __(
            'The YOOAdmin license for this site is not connected.',
            'yooadmin'
        ) . ' ' . $admin_hint;
        $modal_icon    = 'dashicons-info';
        $modal_type    = 'info';
    }

    return [
        'status_class'   => $status_class,
        'status_text'    => $status_text,
        'status_icon'    => $status_icon,
        'is_active'      => $is_active,
        'license_status' => $license_status,
        'display_status' => $display_status,
        'modal_title'    => __('YOOAdmin License', 'yooadmin'),
        'modal_message'  => $modal_message,
        'modal_icon'     => $modal_icon,
        'modal_type'     => $modal_type,
    ];
}

/**
 * Whether the shell license badge should render for the current user.
 */
function yooadmin_should_show_shell_license_status(): bool {
    if (!is_user_logged_in()) {
        return false;
    }

    if (function_exists('yooadmin_user_can_manage_site_settings') && !yooadmin_user_can_manage_site_settings()) {
        return false;
    }

    if (function_exists('yooadmin_should_inject_shell') && !yooadmin_should_inject_shell()) {
        return false;
    }

    return true;
}

/**
 * Enqueue read-only license status modal script for non-admin shell users.
 */
function yooadmin_enqueue_shell_license_status_info_script(): void {
    if (!is_user_logged_in()) {
        return;
    }

    if (
        function_exists('yooadmin_user_can_manage_site_settings')
        && yooadmin_user_can_manage_site_settings()
    ) {
        return;
    }

    if (function_exists('yooadmin_should_inject_shell') && !yooadmin_should_inject_shell()) {
        return;
    }

    if (!defined('YOOADMIN_URL') || !defined('YOOADMIN_DIR')) {
        return;
    }

    $path = YOOADMIN_DIR . 'assets/js/admin/license-status-info.js';
    if (!is_readable($path)) {
        return;
    }

    $handle = 'yooadmin-license-status-info';
    $deps   = ['jquery'];
    if (wp_script_is('yp-admin-core-essential', 'registered') || wp_script_is('yp-admin-core-essential', 'enqueued')) {
        $deps[] = 'yp-admin-core-essential';
    }

    wp_enqueue_script(
        $handle,
        YOOADMIN_URL . 'assets/js/admin/license-status-info.js',
        $deps,
        (string) filemtime($path),
        true
    );

    wp_localize_script(
        $handle,
        'yooadmLicenseStatusInfo',
        [
            'close' => __('Close', 'yooadmin'),
        ]
    );
}

add_action('admin_enqueue_scripts', 'yooadmin_enqueue_shell_license_status_info_script', 25);
