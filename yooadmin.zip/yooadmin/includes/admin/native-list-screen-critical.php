<?php
/**
 * Native WordPress list screens — first-paint CSS (prevents FOUC on edit-comments, etc.).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_native_list_screen_critical_active')) {
    /**
     * @return bool
     */
    function yooadmin_native_list_screen_critical_active(): bool
    {
        if (!is_admin() || !function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Custom YOOAdmin pages use their own assets.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== '' && strpos($page, 'yooadmin-') === 0) {
            return false;
        }

        if (!function_exists('get_current_screen')) {
            return false;
        }

        $screen = get_current_screen();
        if (!$screen || empty($screen->base)) {
            return false;
        }

        $bases = ['edit-comments', 'edit', 'upload', 'edit-tags', 'users', 'plugins', 'themes'];
        foreach ($bases as $base) {
            if (strpos((string) $screen->base, $base) !== false) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('yooadmin_print_native_list_screen_critical_css')) {
    function yooadmin_print_native_list_screen_critical_css(): void
    {
        if (!yooadmin_native_list_screen_critical_active()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $css_file  = plugin_dir_path($base_file) . 'assets/css/admin/native-list-screen-critical.css';
        if (!is_readable($css_file)) {
            return;
        }

        $css = file_get_contents($css_file);
        if (!is_string($css) || $css === '') {
            return;
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static plugin CSS asset.
        echo '<style id="yooadmin-native-list-critical">' . $css . '</style>' . "\n";
    }
}

if (!function_exists('yooadmin_enqueue_native_list_screen_styles_early')) {
    /**
     * Enqueue list screen styles before most admin assets so the first paint matches YOOAdmin.
     */
    function yooadmin_enqueue_native_list_screen_styles_early(): void
    {
        if (!yooadmin_native_list_screen_critical_active()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir  = plugin_dir_path($base_file);
        $base_url  = plugin_dir_url($base_file);

        if (!wp_style_is('yooadmin-core', 'enqueued') && !wp_style_is('yooadmin-core', 'registered')) {
            $core = $base_dir . 'assets/css/admin/yp-admin-core.css';
            if (is_readable($core)) {
                wp_enqueue_style('yooadmin-core', $base_url . 'assets/css/admin/yp-admin-core.css', [], (string) filemtime($core));
            }
        }

        $list_css = $base_dir . 'assets/css/admin/list-screens.css';
        if (is_readable($list_css) && !wp_style_is('yooadmin-list-screens', 'enqueued')) {
            $deps = wp_style_is('yooadmin-core', 'registered') || wp_style_is('yooadmin-core', 'enqueued')
                ? ['yooadmin-core']
                : [];
            wp_enqueue_style(
                'yooadmin-list-screens',
                $base_url . 'assets/css/admin/list-screens.css',
                $deps,
                (string) filemtime($list_css)
            );
        }

        if (function_exists('yooadmin_enqueue_global_admin_ui_assets')) {
            yooadmin_enqueue_global_admin_ui_assets();
        }
    }
}

add_action('admin_head', 'yooadmin_print_native_list_screen_critical_css', 0);
add_action('admin_enqueue_scripts', 'yooadmin_enqueue_native_list_screen_styles_early', 1);
