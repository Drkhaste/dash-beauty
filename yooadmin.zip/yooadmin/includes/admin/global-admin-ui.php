<?php
/**
 * Global YOOAdmin admin UI (buttons) on Focus Mode screens.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Enqueue global button enhancer when YOOAdmin focus shell is active.
 */
function yooadmin_enqueue_global_admin_ui_assets(): void {
    if (!is_admin() || !function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
        return;
    }

    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $base_dir  = plugin_dir_path($base_file);
    $base_url  = plugin_dir_url($base_file);

    $core_deps = wp_style_is('yooadmin-core', 'registered') || wp_style_is('yooadmin-core', 'enqueued')
        ? ['yooadmin-core']
        : [];

    $buttons_css = $base_dir . 'assets/css/admin/yp-yoo-buttons.css';
    if (is_readable($buttons_css)) {
        wp_enqueue_style(
            'yooadmin-yoo-buttons',
            $base_url . 'assets/css/admin/yp-yoo-buttons.css',
            $core_deps,
            (string) filemtime($buttons_css)
        );
    }

    $search_fields_css = $base_dir . 'assets/css/admin/yp-admin-search-fields.css';
    if (is_readable($search_fields_css)) {
        wp_enqueue_style(
            'yooadmin-admin-search-fields',
            $base_url . 'assets/css/admin/yp-admin-search-fields.css',
            $core_deps,
            (string) filemtime($search_fields_css)
        );
    }

    $yp_sel_css = $base_dir . 'assets/css/admin/yp-archive-delay-select.css';
    if (is_readable($yp_sel_css)) {
        wp_enqueue_style(
            'yooadmin-yp-ui-select',
            $base_url . 'assets/css/admin/yp-archive-delay-select.css',
            $core_deps,
            (string) filemtime($yp_sel_css)
        );
    }

    $yp_sel_js = $base_dir . 'assets/js/admin/yp-archive-delay-select.js';
    if (is_readable($yp_sel_js)) {
        wp_enqueue_script(
            'yooadmin-yp-ui-select',
            $base_url . 'assets/js/admin/yp-archive-delay-select.js',
            [],
            (string) filemtime($yp_sel_js),
            true
        );
    }

    $js_rel = 'assets/js/admin/yp-global-buttons.js';
    $js_abs = $base_dir . $js_rel;
    if (!is_readable($js_abs)) {
        return;
    }

    wp_enqueue_script(
        'yooadmin-global-buttons',
        $base_url . $js_rel,
        [],
        (string) filemtime($js_abs),
        true
    );
}

add_action('admin_enqueue_scripts', 'yooadmin_enqueue_global_admin_ui_assets', 28);
