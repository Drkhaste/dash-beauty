<?php
/**
 * Studio Hub guided tour — intro modal, step engine, completion modal.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!class_exists('YOOAdmin_Guided_Tour')) {

    final class YOOAdmin_Guided_Tour {

        public const STUDIO_SLUG       = 'yooadmin-studio-hub';
        public const USER_META_STATE   = 'yooadmin_guided_tour_state';
        public const AJAX_NONCE_ACTION = 'yooadmin_guided_tour';

        /**
         * Bootstrap hooks.
         */
        public static function init(): void {
            if (!is_admin()) {
                return;
            }

            add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets'], 122);
            add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_labs_reset_script'], 123);
            add_action('admin_footer', [__CLASS__, 'render_modals'], 7);
            add_action('wp_ajax_yooadmin_guided_tour_action', [__CLASS__, 'ajax_action']);
            add_action('yooadmin_admin_theme_activated', [__CLASS__, 'on_admin_theme_activated'], 10, 2);
        }

        /**
         * @return bool
         */
        public static function is_focus_enabled(): bool {
            if (function_exists('yooadmin_is_focus_enabled')) {
                return (bool) yooadmin_is_focus_enabled();
            }
            if (function_exists('yooadmin_focus_enabled_by_pref')) {
                return (bool) yooadmin_focus_enabled_by_pref();
            }

            return false;
        }

        /**
         * @return bool
         */
        public static function is_studio_hub_active(): bool {
            if (!class_exists('YOOAdmin_Admin_Theme_Manager')) {
                return false;
            }

            $active = YOOAdmin_Admin_Theme_Manager::get_instance()->get_active_theme();

            return $active && (string) ($active['slug'] ?? '') === self::STUDIO_SLUG;
        }

        /**
         * @param int $user_id
         * @return array{status: string, studio_hub_seen: bool}
         */
        public static function get_state(int $user_id = 0): array {
            $user_id = $user_id > 0 ? $user_id : get_current_user_id();
            $empty   = [
                'status'          => '',
                'studio_hub_seen' => false,
                'dashboard_done'  => false,
                'settings_tour'   => '',
                'segments'        => [],
            ];

            if ($user_id <= 0) {
                return $empty;
            }

            $stored = get_user_meta($user_id, self::USER_META_STATE, true);
            if (!is_array($stored)) {
                return $empty;
            }

            $settings_tour = isset($stored['settings_tour']) ? (string) $stored['settings_tour'] : '';

            $segments = [];
            if (!empty($stored['segments']) && is_array($stored['segments'])) {
                foreach ($stored['segments'] as $seg_id => $seg_status) {
                    $seg_id = sanitize_key((string) $seg_id);
                    if ($seg_id === '') {
                        continue;
                    }
                    $seg_status = (string) $seg_status;
                    if (in_array($seg_status, ['pending', 'completed', 'declined'], true)) {
                        $segments[$seg_id] = $seg_status;
                    }
                }
            }

            return [
                'status'          => isset($stored['status']) ? (string) $stored['status'] : '',
                'studio_hub_seen' => !empty($stored['studio_hub_seen']),
                'dashboard_done'  => !empty($stored['dashboard_done']),
                'settings_tour'   => in_array($settings_tour, ['pending', 'declined', 'completed'], true) ? $settings_tour : '',
                'segments'        => $segments,
            ];
        }

        /**
         * @param array{status?: string, studio_hub_seen?: bool} $patch
         * @param int                                           $user_id
         */
        public static function save_state(array $patch, int $user_id = 0): void {
            $user_id = $user_id > 0 ? $user_id : get_current_user_id();
            if ($user_id <= 0) {
                return;
            }

            $state = self::get_state($user_id);
            if (array_key_exists('status', $patch)) {
                $state['status'] = (string) $patch['status'];
            }
            if (array_key_exists('studio_hub_seen', $patch)) {
                $state['studio_hub_seen'] = (bool) $patch['studio_hub_seen'];
            }
            if (array_key_exists('dashboard_done', $patch)) {
                $state['dashboard_done'] = (bool) $patch['dashboard_done'];
            }
            if (array_key_exists('settings_tour', $patch)) {
                $settings_tour = (string) $patch['settings_tour'];
                $state['settings_tour'] = in_array($settings_tour, ['pending', 'declined', 'completed'], true)
                    ? $settings_tour
                    : '';
            }
            if (array_key_exists('segments', $patch) && is_array($patch['segments'])) {
                $normalized = [];
                foreach ($patch['segments'] as $seg_id => $seg_status) {
                    $seg_id = sanitize_key((string) $seg_id);
                    if ($seg_id === '') {
                        continue;
                    }
                    $seg_status = (string) $seg_status;
                    if (in_array($seg_status, ['pending', 'declined', 'completed'], true)) {
                        $normalized[$seg_id] = $seg_status;
                    }
                }
                $state['segments'] = $normalized;
            }

            update_user_meta($user_id, self::USER_META_STATE, $state);
        }

        /**
         * Clear tour progress so the intro can show again (Labs reset).
         *
         * @param int $user_id
         */
        public static function reset_for_user(int $user_id = 0): void {
            $user_id = $user_id > 0 ? $user_id : get_current_user_id();
            if ($user_id <= 0) {
                return;
            }

            delete_user_meta($user_id, self::USER_META_STATE);
        }

        /**
         * @param string $slug
         * @param array  $theme
         */
        public static function on_admin_theme_activated(string $slug, array $theme): void {
            unset($theme);

            if (self::STUDIO_SLUG !== $slug) {
                return;
            }

            $user_id = get_current_user_id();
            if ($user_id <= 0) {
                return;
            }

            $state = self::get_state($user_id);
            if (!$state['studio_hub_seen']) {
                self::save_state(['studio_hub_seen' => true], $user_id);
            }
        }

        /**
         * Mark first Studio Hub dashboard context for this user.
         */
        private static function maybe_mark_studio_hub_seen(): void {
            $user_id = get_current_user_id();
            if ($user_id <= 0) {
                return;
            }

            $state = self::get_state($user_id);
            if (!$state['studio_hub_seen']) {
                self::save_state(['studio_hub_seen' => true], $user_id);
            }
        }

        /**
         * @return bool
         */
        private static function user_may_run_guided_tour(): bool {
            if (function_exists('yooadmin_is_site_regular_user') && yooadmin_is_site_regular_user()) {
                return false;
            }

            if (function_exists('yooadmin_user_can_manage_site_settings')) {
                return yooadmin_user_can_manage_site_settings();
            }

            return current_user_can('manage_options');
        }

        /**
         * Capability requirements per tour step (any listed cap grants access; empty = no extra gate).
         *
         * @return array<string, string[]|string>
         */
        private static function tour_step_capability_rules(): array {
            return [
                'notifications'          => '__notifications_ui',
                'welcome'                => ['manage_options'],
                'quick-actions'          => ['manage_options'],
                'workspace'              => ['manage_options'],
                'workspace-layout-edit'  => ['manage_options'],
                'add-section'            => ['manage_options'],
                'widget-hide-sections'   => ['manage_options'],
                'security-tools'         => ['manage_options'],
                'workspace-notes'        => ['manage_options'],
                'colors'                 => ['manage_options'],
                'logo'                   => ['manage_options'],
                'login'                  => ['manage_options'],
                'settings-login-security'          => ['manage_options'],
                'settings-maintenance'             => ['manage_options'],
                'settings-general'                 => ['manage_options'],
                'settings-focus'         => ['manage_options'],
                'settings-labs'          => ['manage_options'],
                'settings-behavior'      => ['manage_options'],
                'settings-notifications' => '__notifications_ui',
            ];
        }

        /**
         * @param array<string, mixed> $step
         */
        private static function user_can_access_tour_step(array $step): bool {
            $step_id = isset($step['id']) ? sanitize_key((string) $step['id']) : '';
            if ($step_id === '') {
                return true;
            }

            $rules = self::tour_step_capability_rules();
            if (!isset($rules[ $step_id ])) {
                return true;
            }

            $rule = $rules[ $step_id ];

            if ($rule === '__notifications_ui') {
                return function_exists('yooadmin_user_can_view_notifications_ui')
                    && yooadmin_user_can_view_notifications_ui();
            }

            $caps = is_array($rule) ? $rule : [(string) $rule];
            if ($caps === []) {
                return true;
            }

            foreach ($caps as $cap) {
                if ($cap !== '__deny__' && current_user_can($cap)) {
                    return true;
                }
            }

            return false;
        }

        /**
         * @param array<int, array<string, mixed>> $steps
         * @return array<int, array<string, mixed>>
         */
        private static function filter_steps_for_current_user(array $steps): array {
            $filtered = array_values(
                array_filter(
                    $steps,
                    static function (array $step): bool {
                        return self::user_can_access_tour_step($step);
                    }
                )
            );

            /**
             * @param array<int, array<string, mixed>> $filtered
             * @param array<int, array<string, mixed>> $steps
             */
            return apply_filters('yooadmin_guided_tour_steps', $filtered, $steps);
        }

        /**
         * @return bool
         */
        private static function passes_global_gates(): bool {
            if (!self::is_focus_enabled()) {
                return false;
            }

            if (!self::is_studio_hub_active()) {
                return false;
            }

            if (!class_exists('YOOAdmin_Labs_Prefs') || !YOOAdmin_Labs_Prefs::is_guided_tour_enabled()) {
                return false;
            }

            if (!self::user_may_run_guided_tour()) {
                return false;
            }

            return (bool) apply_filters('yooadmin_guided_tour_passes_global_gates', true);
        }

        /**
         * Unified intro replaces the post-wizard welcome popup when the tour is active.
         *
         * @return bool
         */
        public static function replaces_welcome_popup(): bool {
            return self::passes_global_gates();
        }

        /**
         * @return bool
         */
        public static function should_show_intro(): bool {
            if (!self::passes_global_gates()) {
                return false;
            }

            if (!self::is_yooadmin_dashboard_screen()) {
                return false;
            }

            if (self::get_steps_config() === []) {
                return false;
            }

            self::maybe_mark_studio_hub_seen();

            $state = self::get_state();
            if ($state['status'] !== '') {
                return false;
            }

            if (class_exists('YOOAdmin_Studio_Hub_Upgrade_Modal') && YOOAdmin_Studio_Hub_Upgrade_Modal::should_show()) {
                return false;
            }

            return true;
        }

        /**
         * Site-wide flag: post-wizard welcome was handled (unified intro or legacy popup).
         */
        private static function mark_post_wizard_welcome_seen(): void {
            if (get_option('yooadmin_welcome_popup_shown', false)) {
                return;
            }

            update_option('yooadmin_welcome_popup_shown', true);
        }

        /**
         * Tour overlay assets while in progress (any YOOAdmin admin screen).
         *
         * @return bool
         */
        public static function is_tour_in_progress(): bool {
            if (!self::passes_global_gates()) {
                return false;
            }

            return self::get_state()['status'] === 'in_progress';
        }

        /**
         * @return bool
         */
        public static function should_enqueue(): bool {
            if (self::is_blocked_screen()) {
                return false;
            }

            $should = self::should_show_intro() || self::is_tour_in_progress();

            /**
             * @param bool $should
             */
            return (bool) apply_filters('yooadmin_guided_tour_should_enqueue', $should);
        }

        /**
         * Screens that never host a tour step (e.g. the post/product editor). The
         * guided tour targets the YOOAdmin dashboard, settings, and manager pages
         * only, so it must not load on classic editor screens where it would render
         * a misplaced step with no valid target.
         *
         * @return bool
         */
        private static function is_blocked_screen(): bool {
            global $pagenow;

            $blocked = in_array($pagenow, ['post.php', 'post-new.php'], true);

            /**
             * @param bool $blocked
             */
            return (bool) apply_filters('yooadmin_guided_tour_is_blocked_screen', $blocked);
        }

        /**
         * @return bool
         */
        private static function is_yooadmin_dashboard_screen(): bool {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
            return isset($_GET['page']) && 'yooadmin-dashboard' === sanitize_key(wp_unslash($_GET['page']));
        }

        /**
         * @return bool
         */
        private static function is_yooadmin_settings_screen(): bool {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
            return isset($_GET['page']) && 'yooadmin-settings' === sanitize_key(wp_unslash($_GET['page']));
        }

        /**
         * Behavior tab — reset button (works without an active tour session).
         *
         * @param string $hook
         */
        public static function enqueue_labs_reset_script($hook = ''): void {
            unset($hook);

            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
            if (!isset($_GET['page']) || 'yooadmin-settings' !== sanitize_key(wp_unslash($_GET['page']))) {
                return;
            }

            if (!self::user_may_run_guided_tour()) {
                return;
            }

            $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
            $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);
            $js_rel   = 'assets/js/admin/guided-tour-reset.js';

            if (!is_readable($base_dir . $js_rel)) {
                return;
            }

            $reset_deps = ['jquery'];
            if (function_exists('yooadmin_enqueue_settings_toast_assets')) {
                yooadmin_enqueue_settings_toast_assets();
            }
            if (wp_script_is('yooadmin-settings', 'registered') || wp_script_is('yooadmin-settings', 'enqueued')) {
                $reset_deps[] = 'yooadmin-settings';
            } elseif (wp_script_is('yooadmin-toast-notifications', 'registered') || wp_script_is('yooadmin-toast-notifications', 'enqueued')) {
                $reset_deps[] = 'yooadmin-toast-notifications';
            }

            wp_enqueue_script(
                'yooadmin-guided-tour-reset',
                $base_url . $js_rel,
                $reset_deps,
                (string) filemtime($base_dir . $js_rel),
                true
            );

            wp_localize_script(
                'yooadmin-guided-tour-reset',
                'yooadminGuidedTourReset',
                [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                ]
            );
        }

        /**
         * @param string $hook
         */
        public static function enqueue_assets($hook = ''): void {
            unset($hook);

            if (!self::should_enqueue()) {
                return;
            }

            $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
            $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);
            $css_rel  = 'assets/css/admin/guided-tour.css';
            $js_rel   = 'assets/js/admin/guided-tour.js';

            if (is_readable($base_dir . $css_rel)) {
                wp_enqueue_style(
                    'yooadmin-guided-tour',
                    $base_url . $css_rel,
                    ['yooadmin-yoo-buttons'],
                    (string) filemtime($base_dir . $css_rel)
                );
            }

            if (!is_readable($base_dir . $js_rel)) {
                return;
            }

            wp_enqueue_script(
                'yooadmin-guided-tour',
                $base_url . $js_rel,
                ['jquery'],
                (string) filemtime($base_dir . $js_rel),
                true
            );

            $tour_state = self::get_state();

            $localize = [
                    'ajaxUrl'       => admin_url('admin-ajax.php'),
                    'nonce'         => wp_create_nonce(self::AJAX_NONCE_ACTION),
                    'showIntro'     => self::should_show_intro(),
                    'inProgress'    => self::is_tour_in_progress(),
                    'dashboardDone' => $tour_state['dashboard_done'],
                    'settingsTour'  => $tour_state['settings_tour'],
                    'dashboardUrl'  => admin_url('admin.php?page=yooadmin-dashboard'),
                    'settingsUrl'   => admin_url('admin.php?page=yooadmin-settings'),
                    'settingsColors'=> admin_url('admin.php?page=yooadmin-settings#tab-colors'),
                    'themeSettingsUrl' => admin_url('admin.php?page=yooadmin-admin-theme-settings'),
                    'settingsBrand' => admin_url('admin.php?page=yooadmin-settings#tab-brand'),
                    'settingsLogin' => admin_url('admin.php?page=yooadmin-settings#tab-login'),
                    'settingsLoginSecurity' => admin_url('admin.php?page=yooadmin-settings#tab-login-security'),
                    'settingsMaintenance'   => admin_url('admin.php?page=yooadmin-settings#tab-maintenance'),
                    'settingsGeneral' => admin_url('admin.php?page=yooadmin-settings#tab-general'),
                    'settingsFocus' => admin_url('admin.php?page=yooadmin-settings#tab-focus'),
                    'settingsLabs'  => admin_url('admin.php?page=yooadmin-settings#tab-labs'),
                    'settingsBehavior' => admin_url('admin.php?page=yooadmin-settings#tab-behavior'),
                    'settingsNotifications' => admin_url('admin.php?page=yooadmin-settings#tab-notifications'),
                    'pluginsUrl'    => admin_url('plugins.php'),
                    'themeManagerUrl' => admin_url('admin.php?page=yooadmin-theme-manager'),
                    'mediaUrl'      => admin_url('upload.php'),
                    'imageIntro'    => $base_url . 'assets/images/welcome-popup-promo.svg',
                    'imageComplete' => $base_url . 'assets/images/studio-hub-upgrade-promo.svg',
                    'i18n'          => self::get_i18n_strings(),
                    'steps'         => self::get_steps_config(),
                    'extensionTours'=> self::get_extension_tours_config(),
                    'segmentCatalog'=> self::get_segment_catalog(),
                    'segments'      => self::normalize_segments_for_state($tour_state),
                ];

            /**
             * @param array<string, mixed> $localize
             */
            $localize = apply_filters('yooadmin_guided_tour_localize_config', $localize);

            wp_localize_script('yooadmin-guided-tour', 'yooadminGuidedTour', $localize);
        }

        /**
         * @return array<string, string>
         */
        private static function get_i18n_strings(): array {
            return [
                'introEyebrow'       => __('YOOAdmin', 'yooadmin'),
                'introTitle'         => __('Welcome to Studio Hub', 'yooadmin'),
                'introLead'          => __('Your workspace is ready. A smarter, cleaner, and more organized dashboard. A quick tour of navigation, workspace tools, and settings.', 'yooadmin'),
                'introDuration'      => __('About 2 minutes', 'yooadmin'),
                'startTour'          => __('Start guided tour', 'yooadmin'),
                'startingTour'       => __('Starting tour…', 'yooadmin'),
                'notNow'             => __('Not now', 'yooadmin'),
                'close'              => __('Close', 'yooadmin'),
                'next'               => __('Next', 'yooadmin'),
                'back'               => __('Back', 'yooadmin'),
                'skip'               => __('Skip tour', 'yooadmin'),
                'finish'             => __('Finish', 'yooadmin'),
                'endTour'            => __('Finish', 'yooadmin'),
                'continueSettings'   => __('Continue', 'yooadmin'),
                'settingsOfferEyebrow' => __('Dashboard tour complete', 'yooadmin'),
                'settingsOfferTitle'   => __('Continue with settings?', 'yooadmin'),
                'settingsOfferLead'    => __('You can take a separate tour for brand colors (Theme Settings), branding, login, and other YOOAdmin Settings tabs when you are ready.', 'yooadmin'),
                'settingsOfferYes'     => __('Yes, when I open settings', 'yooadmin'),
                'settingsOfferNo'      => __('No thanks', 'yooadmin'),
                'replayTour'         => __('Replay tour', 'yooadmin'),
                'completeEyebrow'    => __('Guided tour', 'yooadmin'),
                'completeTitle'      => __('Thank you!', 'yooadmin'),
                'completeThanks'     => __('Thank you for using YOOAdmin Studio Hub. We hope this tour helps you get the most from your admin workspace.', 'yooadmin'),
                'completeLead'       => __('You can also replay the tour anytime from Settings → Behavior.', 'yooadmin'),
                'skipCompleteTitle'  => __('Tour skipped', 'yooadmin'),
                'skipCompleteThanks' => __('You skipped the guided tour. Explore Studio Hub at your own pace — layout, plugins, and settings are always available from the dashboard.', 'yooadmin'),
                'skipCompleteLead'   => __('Changed your mind? Replay the full tour anytime from Settings → Behavior.', 'yooadmin'),
                /* translators: 1: current step number, 2: total steps */
                'stepOf'             => __('Step %1$s of %2$s', 'yooadmin'),
                'demoMoveTileTitle'  => __('Moving a tile', 'yooadmin'),
                'demoMoveTileText'   => __('Watch the tile slide to its new spot in Your workspace.', 'yooadmin'),
                'demoMoveCardTitle'  => __('Moving a card to Your plugins', 'yooadmin'),
                'demoMoveCardText'   => __('Watch the card travel from Your workspace into the plugins area.', 'yooadmin'),
                'demoMovePluginsTitle' => __('Moving Your plugins', 'yooadmin'),
                'demoMovePluginsText'  => __('Watch the section slide into the main workspace area.', 'yooadmin'),
                'layoutDemoBegin'      => __('Show me', 'yooadmin'),
                'targetMissing'      => __('This area is not visible right now. Click Next to continue.', 'yooadmin'),
                'extOfferEyebrow'    => __('Optional tour', 'yooadmin'),
                'extOfferYes'        => __('Yes, show me', 'yooadmin'),
                'extOfferNo'         => __('Not now', 'yooadmin'),
                'extOfferSkipAll'    => __('Skip remaining tours', 'yooadmin'),
                'pickerEyebrow'      => __('More tours available', 'yooadmin'),
                'pickerTitle'        => __('Explore more features', 'yooadmin'),
                'pickerLead'         => __('Start tour runs it now. Not now keeps it waiting — it starts automatically when you open that page.', 'yooadmin'),
                'pickerStart'        => __('Start tour', 'yooadmin'),
                'pickerLater'        => __('Not now', 'yooadmin'),
                'pickerLaterHint'    => __('Skip for now. This tour will start when you open its page.', 'yooadmin'),
                'pickerFinishAll'    => __('Finish', 'yooadmin'),
                'settingsSegmentTitle' => __('Studio Hub settings', 'yooadmin'),
                'settingsSegmentText'  => __('Theme Settings for brand colors, then YOOAdmin Settings for branding, login, notifications, and more.', 'yooadmin'),
            ];
        }

        /**
         * Step definitions for the JS engine (titles + bodies translated server-side).
         *
         * @return array<int, array<string, mixed>>
         */
        private static function get_steps_config(): array {
            return self::filter_steps_for_current_user(
                array_merge(
                    self::get_dashboard_tour_steps(),
                    self::get_settings_tour_steps()
                )
            );
        }

        /**
         * Dashboard + layout steps.
         *
         * @return array<int, array<string, mixed>>
         */
        private static function get_dashboard_tour_steps(): array {
            return [
                [
                    'id'          => 'sidebar',
                    'target'      => '#yps-sidebar.is-open',
                    'title'       => __('Sidebar menu', 'yooadmin'),
                    'text'        => __('Your main WordPress admin menu lives here. Open sections to reach posts, plugins, WooCommerce, and more.', 'yooadmin'),
                    'placement'   => 'end',
                    'page'        => 'dashboard',
                    'openSidebar'     => true,
                    'spotlightOnly'   => true,
                ],
                [
                    'id'                => 'notifications',
                    'target'            => '.yp-notifications-dropdown.show, .yp-notifications',
                    'title'             => __('Notifications', 'yooadmin'),
                    'text'              => __('Your notification list opens here. Updates, alerts, and converted admin notices are grouped by type.', 'yooadmin'),
                    'placement'         => 'left',
                    'page'              => 'dashboard',
                    'openNotifications' => true,
                ],
                [
                    'id'            => 'breadcrumbs',
                    'target'        => '.yp-breadcrumbs-bar',
                    'title'         => __('Breadcrumbs', 'yooadmin'),
                    'text'          => __('Quick links to parent screens and related admin pages — handy when you drill into settings or store tools.', 'yooadmin'),
                    'placement'     => 'bottom',
                    'page'          => 'dashboard',
                    'spotlightOnly' => true,
                ],
                [
                    'id'            => 'welcome',
                    'target'        => '.yp-card-welcome-studio, .yp-studio-welcome-mock',
                    'title'         => __('Welcome card', 'yooadmin'),
                    'text'          => __('Edit the greeting and links shown to your team. Use the pencil on this card to customize the message.', 'yooadmin'),
                    'placement'     => 'bottom',
                    'page'          => 'dashboard',
                    'spotlightOnly' => true,
                ],
                [
                    'id'            => 'quick-actions',
                    'target'        => '[data-quick-actions-card]',
                    'title'         => __('Quick Actions', 'yooadmin'),
                    'text'          => __('Pin shortcuts to the tools you use most. Use Edit on this card to add, reorder, or remove tiles.', 'yooadmin'),
                    'placement'     => 'bottom',
                    'page'          => 'dashboard',
                    'spotlightOnly' => true,
                    'scrollCenter'  => true,
                ],
                [
                    'id'            => 'workspace',
                    'target'        => '[data-section-id="your-workspace"]',
                    'title'         => __('Your workspace', 'yooadmin'),
                    'text'          => __('Core admin shortcuts for daily work — posts, media, plugins, and the tools you pin here.', 'yooadmin'),
                    'placement'     => 'bottom',
                    'page'          => 'dashboard',
                    'spotlightOnly' => true,
                    'scrollCenter'  => true,
                ],
                [
                    'id'               => 'workspace-layout-edit',
                    'target'           => '[data-section-id="your-workspace"] .yp-card-edit-toggle, [data-section-id="your-workspace"] [data-icon-edit-toggle="main-grid"]',
                    'title'            => __('Layout edit & drag', 'yooadmin'),
                    'text'             => __('Click Show me to watch a tile and Your plugins move in your workspace. When you continue, the layout resets.', 'yooadmin'),
                    'layoutDemoDoneText' => __('Preview complete. Click Next to continue; the dashboard layout will reset automatically.', 'yooadmin'),
                    'placement'        => 'left',
                    'page'             => 'dashboard',
                    'layoutEdit'       => true,
                    'revealEditButton' => true,
                    'layoutTourDemo'   => true,
                    'layoutResetAfter' => true,
                    'spotlightOnly'    => true,
                    'scrollCenter'     => true,
                ],
                [
                    'id'             => 'add-section',
                    'target'         => '.yp-studio-layout-add--main, .yp-studio-layout-add--aside',
                    'title'          => __('Add sections & widgets', 'yooadmin'),
                    'text'           => __('Layout edit is on. Use + at the bottom of the main column (left) or the right sidebar to add a custom section, dashboard widget, or legacy WordPress widget.', 'yooadmin'),
                    'placement'      => 'top',
                    'page'           => 'dashboard',
                    'layoutEdit'     => true,
                    'scrollCenter'   => true,
                    'spotlightOnly'  => true,
                    'dualSpotlights' => true,
                    'spotlightPad'   => 4,
                ],
                [
                    'id'              => 'widget-hide-sections',
                    'target'          => '[data-section-id="studio-tips"], [data-section-id="studio-activity"], .yp-studio-widget-section[data-section-id]',
                    'hideToggle'      => true,
                    'hideScope'       => 'section',
                    'hideSpotlightCard'=> true,
                    'title'           => __('Hide sections', 'yooadmin'),
                    'text'            => __('Use the section eye icon on Tips, Activity, or custom widget blocks to hide whole areas. Show them again anytime with the same control.', 'yooadmin'),
                    'placement'       => 'left',
                    'page'            => 'dashboard',
                    'layoutEdit'      => true,
                    'revealHideToggle' => true,
                    'spotlightOnly'   => true,
                    'scrollCenter'    => true,
                ],
                [
                    'id'            => 'security-tools',
                    'target'        => '[data-widget-id="studio-login-security"], .yp-studio-widget-section--studio-login-security, [data-studio-login-security-widget="true"]',
                    'title'         => __('Login security', 'yooadmin'),
                    'text'          => __('YOOAdmin includes built-in security tools to protect login and the site. Make sure to review them.', 'yooadmin'),
                    'placement'     => 'left',
                    'page'          => 'dashboard',
                    'scrollCenter'  => true,
                    'spotlightOnly' => true,
                ],
                [
                    'id'            => 'workspace-notes',
                    'target'        => '[data-section-id="studio-workspace-notes"], .yp-studio-workspace-notes-card',
                    'title'         => __('Workspace Notes', 'yooadmin'),
                    'text'          => __('Private notes in the right column. Pick a type from the menu, add with +, and remove with the trash icon.', 'yooadmin'),
                    'placement'     => 'left',
                    'page'          => 'dashboard',
                    'spotlightOnly' => true,
                    'scrollCenter'  => true,
                ],
            ];
        }

        /**
         * Settings tabs + theme brand colors.
         *
         * @return array<int, array<string, mixed>>
         */
        private static function get_settings_tour_steps(): array {
            $settings_panel = static function (string $tab, string $selector): array {
                return [
                    'page'           => 'settings',
                    'navigate'       => 'settings-' . $tab,
                    'target'         => $selector,
                    'scrollCenter'   => true,
                    'spotlightOnly'  => true,
                    'placement'      => 'left',
                ];
            };

            $steps = [
                [
                    'id'             => 'colors',
                    'target'         => '.yooadmin-theme-settings-section-brand-colors, #tab-colors.is-active .yooadmin-color-field, #tab-colors.is-active .yp-settings-card',
                    'title'          => __('Brand colors', 'yooadmin'),
                    'text'           => __('Brand colors are not on the main YOOAdmin Settings page. Open YOOAdmin → Themes, then Theme Settings on your active admin theme (Studio Hub). Here you set the primary color and Studio Hub surfaces—header, sidebar, breadcrumbs, and text tokens.', 'yooadmin'),
                    'placement'      => 'left',
                    'page'           => 'theme-settings',
                    'navigate'       => 'settings-colors',
                    'scrollCenter'   => true,
                    'spotlightOnly'  => true,
                ],
                array_merge(
                    [
                        'id'    => 'settings-general',
                        'title' => __('General settings', 'yooadmin'),
                        'text'  => __('Control YOOAdmin redirects and which core WordPress screens open inside the Studio Hub experience.', 'yooadmin'),
                    ],
                    $settings_panel('general', '#tab-general.is-active .yp-notifications-split, #tab-general.is-active .form-table')
                ),
                [
                    'id'            => 'logo',
                    'target'        => '#tab-brand.is-active .yp-settings-card',
                    'title'         => __('Branding & logo', 'yooadmin'),
                    'text'          => __('Set your admin logo and width, upload a favicon, and configure white label options — everything for Studio Hub branding in one place.', 'yooadmin'),
                    'placement'     => 'left',
                    'page'          => 'settings',
                    'navigate'      => 'settings-brand',
                    'scrollCenter'  => true,
                    'spotlightOnly' => true,
                ],
                [
                    'id'            => 'login',
                    'target'        => '#tab-login.is-active .yp-login-split, #tab-login.is-active #yooadmin-login-tab-stack, #tab-login.is-active .yooadmin-login-tab-stack',
                    'title'         => __('Login page', 'yooadmin'),
                    'text'          => __('Customize layout, background image, login logo, and preview the standalone login screen before saving.', 'yooadmin'),
                    'placement'     => 'left',
                    'page'          => 'settings',
                    'navigate'      => 'settings-login',
                    'scrollCenter'  => true,
                    'spotlightOnly' => true,
                    'spotlightPad'  => 18,
                ],
            ];

            if (function_exists('yooadmin_has_feature') && yooadmin_has_feature('login_customizer')) {
                $steps[] = array_merge(
                    [
                        'id'    => 'settings-login-security',
                        'title' => __('Security settings', 'yooadmin'),
                        'text'  => __('Protect sign-in with Turnstile, rate limits, username protection, and custom login URL. Use the sub-tabs here for each area, then save the page.', 'yooadmin'),
                    ],
                    $settings_panel(
                        'login-security',
                        '#tab-login-security.is-active .yp-tabs--security-inner'
                    )
                );
            }

            $steps[] = [
                'id'            => 'settings-maintenance',
                'target'        => '#tab-maintenance.is-active .yooadmin-maintenance-settings, #tab-maintenance.is-active .yooadmin-maintenance-settings-body, #tab-maintenance.is-active .yooadmin-maintenance-overlay-preview',
                'title'         => __('Maintenance mode', 'yooadmin'),
                'text'          => __('Turn maintenance mode on to show a branded page to visitors while you work. Set the background image, overlay and blur, multilingual titles and messages, and whether the header badge appears when maintenance is off.', 'yooadmin'),
                'placement'     => 'left',
                'page'          => 'settings',
                'navigate'      => 'settings-maintenance',
                'scrollCenter'  => true,
                'spotlightOnly' => true,
                'spotlightPad'  => 14,
            ];

            return array_merge(
                $steps,
                [
                array_merge(
                    [
                        'id'    => 'settings-focus',
                        'title' => __('Focus Mode', 'yooadmin'),
                        'text'  => __('Focus Mode hides WordPress clutter so your team stays inside the branded admin shell.', 'yooadmin'),
                    ],
                    $settings_panel('focus', '#tab-focus.is-active .yp-settings-card, #tab-focus.is-active .form-table')
                ),
                array_merge(
                    [
                        'id'    => 'settings-labs',
                        'title' => __('Labs', 'yooadmin'),
                        'text'  => __('Experimental features such as the YOOAi floating button live here.', 'yooadmin'),
                    ],
                    $settings_panel('labs', '#tab-labs.is-active .yp-settings-card, #tab-labs.is-active .form-table')
                ),
                array_merge(
                    [
                        'id'    => 'settings-behavior',
                        'title' => __('Behavior', 'yooadmin'),
                        'text'  => __('Fine-tune admin behavior, Studio Hub prompts, guided tour, and how Studio Hub responds across screens.', 'yooadmin'),
                    ],
                    $settings_panel('behavior', '#tab-behavior.is-active .yp-settings-card, #tab-behavior.is-active .form-table')
                ),
                array_merge(
                    [
                        'id'    => 'settings-notifications',
                        'title' => __('Notifications settings', 'yooadmin'),
                        'text'  => __('Choose how admin notices are collected, grouped, and shown in the header notification center.', 'yooadmin'),
                    ],
                    $settings_panel('notifications', '#tab-notifications.is-active .yp-settings-card, #tab-notifications.is-active .yp-notifications-split, #tab-notifications.is-active .form-table')
                ),
                ]
            );
        }

        /**
         * Follow-up tour segments (settings + optional managers).
         *
         * @return array<int, array<string, mixed>>
         */
        private static function get_segment_catalog(): array {
            $catalog = [];

            if (self::user_may_run_guided_tour()) {
                $catalog[] = [
                    'id'    => 'settings',
                    'type'  => 'core',
                    'page'  => 'settings',
                    'url'   => admin_url('admin.php?page=yooadmin-settings'),
                    'title' => __('Studio Hub settings', 'yooadmin'),
                    'text'  => __('Theme Settings for brand colors, then YOOAdmin Settings for branding, login, notifications, and more.', 'yooadmin'),
                ];
            }

            foreach (self::get_extension_tours_config() as $tour) {
                if (empty($tour['id'])) {
                    continue;
                }
                $catalog[] = [
                    'id'    => (string) $tour['id'],
                    'type'  => 'extension',
                    'page'  => isset($tour['page']) ? (string) $tour['page'] : '',
                    'url'   => isset($tour['url']) ? (string) $tour['url'] : '',
                    'title' => isset($tour['offerTitle']) ? (string) $tour['offerTitle'] : (string) $tour['id'],
                    'text'  => isset($tour['offerText']) ? (string) $tour['offerText'] : '',
                ];
            }

            return apply_filters('yooadmin_guided_tour_segment_catalog', $catalog);
        }

        /**
         * Intro modal bullet list — only features the current user will see on the tour.
         *
         * @return string[]
         */
        private static function get_intro_features(): array {
            $step_ids = array_map(
                static function (array $step): string {
                    return isset($step['id']) ? sanitize_key((string) $step['id']) : '';
                },
                self::filter_steps_for_current_user(self::get_dashboard_tour_steps())
            );
            $step_ids = array_filter($step_ids);
            $has_settings_segment = self::user_may_run_guided_tour();

            $features = [];

            if (array_intersect(['sidebar', 'breadcrumbs', 'welcome', 'notifications'], $step_ids) !== []) {
                $features[] = in_array('notifications', $step_ids, true)
                    ? __('Navigation, notifications, and workspace tools', 'yooadmin')
                    : __('Navigation and workspace tools', 'yooadmin');
            }

            if (array_intersect(['quick-actions', 'workspace', 'workspace-layout-edit', 'add-section', 'widget-hide-sections'], $step_ids) !== []) {
                $features[] = __('Dashboard layout and Quick Actions', 'yooadmin');
            }

            if (in_array('workspace-notes', $step_ids, true) || $has_settings_segment) {
                $features[] = __('Workspace Notes and settings (optional)', 'yooadmin');
            }

            if ($features === []) {
                $features[] = __('Navigation and your Studio Hub dashboard', 'yooadmin');
            }

            return $features;
        }

        /**
         * @param array<string, mixed> $state
         * @return array<string, string>
         */
        private static function normalize_segments_for_state(array $state): array {
            $segments = isset($state['segments']) && is_array($state['segments']) ? $state['segments'] : [];
            $catalog  = self::get_segment_catalog();

            if ($segments === [] && !empty($state['dashboard_done'])) {
                if ($state['settings_tour'] === 'completed') {
                    $segments['settings'] = 'completed';
                } elseif ($state['settings_tour'] === 'declined') {
                    $segments['settings'] = 'declined';
                } elseif ($state['settings_tour'] === 'pending') {
                    $segments['settings'] = 'pending';
                }
            }

            foreach ($catalog as $item) {
                $id = isset($item['id']) ? sanitize_key((string) $item['id']) : '';
                if ($id === '' || isset($segments[$id])) {
                    continue;
                }
                if (!empty($state['dashboard_done'])) {
                    $segments[$id] = 'pending';
                }
            }

            return $segments;
        }

        /**
         * @param array<string, mixed> $state
         * @return array<string, mixed>
         */
        private static function state_for_client(array $state): array {
            $state['segments'] = self::normalize_segments_for_state($state);

            return $state;
        }

        /**
         * @param string $segment_id
         * @param string $status
         */
        private static function set_segment_status(string $segment_id, string $status): void {
            $segment_id = sanitize_key($segment_id);
            if ($segment_id === '' || !in_array($status, ['pending', 'completed', 'declined'], true)) {
                return;
            }

            $state = self::get_state();
            $segments = self::normalize_segments_for_state($state);
            $segments[$segment_id] = $status;
            $patch = ['segments' => $segments];

            if ($segment_id === 'settings') {
                if ($status === 'completed') {
                    $patch['settings_tour'] = 'completed';
                } elseif ($status === 'declined') {
                    $patch['settings_tour'] = 'declined';
                } else {
                    $patch['settings_tour'] = 'pending';
                }
            }

            self::save_state($patch);
        }

        /**
         * Lite has no Plugin Manager, Theme Manager, or YOOMedia follow-up tours.
         *
         * @return array<int, array<string, mixed>>
         */
        private static function get_extension_tours_config(): array {
            /**
             * @param array<int, array<string, mixed>> $tours
             */
            return apply_filters('yooadmin_guided_tour_extension_tours', []);
        }

        /**
         * Print intro / completion shells (tour UI is created in JS).
         */
        public static function render_modals(): void {
            if (!self::should_enqueue() || !wp_script_is('yooadmin-guided-tour', 'enqueued')) {
                return;
            }

            $should_render = self::should_show_intro() || self::is_tour_in_progress();

            /**
             * @param bool $should_render
             */
            $should_render = (bool) apply_filters('yooadmin_guided_tour_should_render_modals', $should_render);

            if (!$should_render) {
                return;
            }

            if (self::should_show_intro() && self::get_steps_config() === []) {
                return;
            }

            $intro_features = self::get_intro_features();
            ?>
            <div id="yooadmin-guided-tour-intro" class="ygt-overlay ygt-overlay--intro" hidden aria-hidden="true">
                <div class="ygt-dialog" role="dialog" aria-modal="true" aria-labelledby="ygt-intro-title">
                    <div class="ygt-layout">
                        <div class="ygt-copy">
                            <p class="ygt-eyebrow"><?php esc_html_e('YOOAdmin', 'yooadmin'); ?></p>
                            <h2 id="ygt-intro-title" class="ygt-title"><?php esc_html_e('Welcome to Studio Hub', 'yooadmin'); ?></h2>
                            <p class="ygt-lead">
                                <?php esc_html_e('Your workspace is ready. A smarter, cleaner, and more organized dashboard. A quick tour of navigation, workspace tools, and settings.', 'yooadmin'); ?>
                                <span class="ygt-duration-tag" aria-label="<?php echo esc_attr__('About 2 minutes', 'yooadmin'); ?>"><span class="ygt-duration-tag__tilde" aria-hidden="true">~</span><?php esc_html_e('About 2 minutes', 'yooadmin'); ?></span>
                            </p>
                            <ul class="ygt-features">
                                <?php foreach ($intro_features as $feature) : ?>
                                    <li>
                                        <span class="ygt-check dashicons dashicons-yes-alt" aria-hidden="true"></span>
                                        <span><?php echo esc_html($feature); ?></span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                            <div class="ygt-actions">
                                <button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary" data-ygt-start-tour><?php esc_html_e('Start guided tour', 'yooadmin'); ?></button>
                                <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" data-ygt-intro-dismiss><?php esc_html_e('Not now', 'yooadmin'); ?></button>
                            </div>
                        </div>
                        <div class="ygt-visual" aria-hidden="true">
                            <button type="button" class="ygt-close" data-ygt-intro-dismiss aria-label="<?php echo esc_attr__('Close', 'yooadmin'); ?>">
                                <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                            </button>
                            <img class="ygt-image" src="<?php echo esc_url(plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/welcome-popup-promo.svg'); ?>" alt="" width="320" height="280" loading="lazy" decoding="async" />
                        </div>
                    </div>
                </div>
            </div>
            <div id="yooadmin-guided-tour-complete" class="ygt-overlay ygt-overlay--complete" hidden aria-hidden="true">
                <div class="ygt-dialog" role="dialog" aria-modal="true" aria-labelledby="ygt-complete-title">
                    <div class="ygt-layout">
                        <div class="ygt-copy">
                            <p class="ygt-eyebrow" data-ygt-complete-eyebrow><?php esc_html_e('Guided tour', 'yooadmin'); ?></p>
                            <h2 id="ygt-complete-title" class="ygt-title" data-ygt-complete-title><?php esc_html_e('Thank you!', 'yooadmin'); ?></h2>
                            <p class="ygt-lead ygt-complete-thanks" data-ygt-complete-thanks><?php esc_html_e('Thank you for using YOOAdmin Studio Hub. We hope this tour helps you get the most from your admin workspace.', 'yooadmin'); ?></p>
                            <p class="ygt-complete-note" data-ygt-complete-note><?php esc_html_e('You can also replay the tour anytime from Settings → Behavior.', 'yooadmin'); ?></p>
                            <div class="ygt-actions">
                                <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" data-ygt-replay-tour><?php esc_html_e('Replay tour', 'yooadmin'); ?></button>
                                <button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary" data-ygt-finish-tour><?php esc_html_e('Finish', 'yooadmin'); ?></button>
                            </div>
                        </div>
                        <div class="ygt-visual" aria-hidden="true">
                            <img class="ygt-image" src="<?php echo esc_url(plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/studio-hub-upgrade-promo.svg'); ?>" alt="" width="320" height="280" loading="lazy" decoding="async" />
                        </div>
                    </div>
                </div>
            </div>
            <div id="yooadmin-guided-tour-settings-offer" class="ygt-overlay ygt-overlay--extension-offer" hidden aria-hidden="true">
                <div class="ygt-dialog ygt-dialog--compact" role="dialog" aria-modal="true" aria-labelledby="ygt-settings-offer-title">
                    <div class="ygt-copy ygt-copy--centered">
                        <p class="ygt-eyebrow"><?php esc_html_e('Dashboard tour complete', 'yooadmin'); ?></p>
                        <h2 id="ygt-settings-offer-title" class="ygt-title"><?php esc_html_e('Continue with settings?', 'yooadmin'); ?></h2>
                        <p class="ygt-lead"><?php esc_html_e('You can take a separate tour for brand colors (Theme Settings), branding, login, and other YOOAdmin Settings tabs when you are ready.', 'yooadmin'); ?></p>
                        <div class="ygt-actions ygt-actions--stack">
                            <button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary" data-ygt-settings-offer-yes><?php esc_html_e('Yes, when I open settings', 'yooadmin'); ?></button>
                            <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" data-ygt-settings-offer-no><?php esc_html_e('No thanks', 'yooadmin'); ?></button>
                        </div>
                    </div>
                </div>
            </div>
            <div id="yooadmin-guided-tour-picker" class="ygt-overlay ygt-overlay--picker" hidden aria-hidden="true">
                <div class="ygt-dialog ygt-dialog--compact ygt-dialog--picker" role="dialog" aria-modal="true" aria-labelledby="ygt-picker-title">
                    <div class="ygt-copy">
                        <p class="ygt-eyebrow" data-ygt-picker-eyebrow><?php esc_html_e('More tours available', 'yooadmin'); ?></p>
                        <h2 id="ygt-picker-title" class="ygt-title" data-ygt-picker-title><?php esc_html_e('Explore more features', 'yooadmin'); ?></h2>
                        <p class="ygt-lead" data-ygt-picker-lead><?php esc_html_e('Start tour runs it now. Not now keeps it waiting — it starts automatically when you open that page.', 'yooadmin'); ?></p>
                        <p class="ygt-section-label"><?php esc_html_e('Available tours', 'yooadmin'); ?></p>
                        <div class="ygt-tour-picker-list" data-ygt-picker-list role="list"></div>
                        <div class="ygt-actions ygt-actions--picker">
                            <button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary" data-ygt-picker-finish><?php esc_html_e('Finish', 'yooadmin'); ?></button>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }

        /**
         * AJAX: start, dismiss intro, skip, complete.
         */
        public static function ajax_action(): void {
            check_ajax_referer(self::AJAX_NONCE_ACTION, 'nonce');

            if (!self::user_may_run_guided_tour()) {
                wp_send_json_error(['message' => 'forbidden'], 403);
            }

            $task = isset($_POST['task']) ? sanitize_key(wp_unslash($_POST['task'])) : '';

            if ('reset' === $task) {
                if (!self::user_may_run_guided_tour()) {
                    wp_send_json_error(['message' => 'forbidden'], 403);
                }
                self::reset_for_user();
                wp_send_json_success(['status' => '']);
            }

            if (!self::passes_global_gates()) {
                wp_send_json_error(['message' => 'unavailable'], 400);
            }

            switch ($task) {
                case 'start':
                    self::mark_post_wizard_welcome_seen();
                    self::save_state(['status' => 'in_progress']);
                    wp_send_json_success(['status' => 'in_progress']);
                    break;
                case 'intro_dismiss':
                    self::mark_post_wizard_welcome_seen();
                    self::save_state(['status' => 'intro_dismissed']);
                    wp_send_json_success(['status' => 'intro_dismissed']);
                    break;
                case 'skip':
                    self::save_state(['status' => 'skipped']);
                    wp_send_json_success(['status' => 'skipped']);
                    break;
                case 'complete':
                    self::save_state(['status' => 'completed']);
                    wp_send_json_success(['status' => 'completed']);
                    break;
                case 'dashboard_done':
                    $state = self::get_state();
                    $segments = self::normalize_segments_for_state($state);
                    foreach (self::get_segment_catalog() as $item) {
                        $id = isset($item['id']) ? sanitize_key((string) $item['id']) : '';
                        if ($id !== '' && !isset($segments[$id])) {
                            $segments[$id] = 'pending';
                        }
                    }
                    self::save_state([
                        'status'         => 'in_progress',
                        'dashboard_done' => true,
                        'segments'       => $segments,
                    ]);
                    wp_send_json_success(self::state_for_client(self::get_state()));
                    break;
                case 'finish_all':
                    $segments = [];
                    foreach (self::get_segment_catalog() as $item) {
                        $id = isset($item['id']) ? sanitize_key((string) $item['id']) : '';
                        if ($id !== '') {
                            $segments[$id] = 'declined';
                        }
                    }
                    self::save_state([
                        'status'         => 'completed',
                        'dashboard_done' => true,
                        'settings_tour'  => 'declined',
                        'segments'       => $segments,
                    ]);
                    wp_send_json_success(self::state_for_client(self::get_state()));
                    break;
                case 'segment_complete':
                    $segment_id = isset($_POST['segment_id']) ? sanitize_key(wp_unslash($_POST['segment_id'])) : '';
                    self::set_segment_status($segment_id, 'completed');
                    wp_send_json_success(self::state_for_client(self::get_state()));
                    break;
                case 'segment_pending':
                    $segment_id = isset($_POST['segment_id']) ? sanitize_key(wp_unslash($_POST['segment_id'])) : '';
                    self::set_segment_status($segment_id, 'pending');
                    wp_send_json_success(self::state_for_client(self::get_state()));
                    break;
                case 'segment_decline':
                    $segment_id = isset($_POST['segment_id']) ? sanitize_key(wp_unslash($_POST['segment_id'])) : '';
                    self::set_segment_status($segment_id, 'declined');
                    wp_send_json_success(self::state_for_client(self::get_state()));
                    break;
                case 'settings_accept':
                    self::save_state([
                        'status'         => 'in_progress',
                        'dashboard_done' => true,
                        'settings_tour'  => 'pending',
                    ]);
                    wp_send_json_success(['settings_tour' => 'pending']);
                    break;
                case 'settings_decline':
                    self::save_state([
                        'status'         => 'in_progress',
                        'dashboard_done' => true,
                        'settings_tour'  => 'declined',
                    ]);
                    wp_send_json_success(['settings_tour' => 'declined']);
                    break;
                case 'settings_complete':
                    self::save_state([
                        'dashboard_done' => true,
                        'settings_tour'  => 'completed',
                    ]);
                    wp_send_json_success(['settings_tour' => 'completed']);
                    break;
                default:
                    wp_send_json_error(['message' => 'invalid'], 400);
            }
        }

        /**
         * @return string
         */
        private static function required_capability(): string {
            return 'manage_options';
        }

        /**
         * Guided tour reset on My Preferences (site administrators only).
         */
        public static function enqueue_reset_script_for_preferences_page(): void {
            if (!self::user_may_run_guided_tour()) {
                return;
            }

            $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
            $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);
            $js_rel   = 'assets/js/admin/guided-tour-reset.js';

            if (!is_readable($base_dir . $js_rel)) {
                return;
            }

            $reset_deps = ['jquery'];
            if (function_exists('yooadmin_enqueue_settings_toast_assets')) {
                yooadmin_enqueue_settings_toast_assets();
            }
            if (wp_script_is('yooadmin-toast-notifications', 'registered') || wp_script_is('yooadmin-toast-notifications', 'enqueued')) {
                $reset_deps[] = 'yooadmin-toast-notifications';
            }

            wp_enqueue_script(
                'yooadmin-guided-tour-reset',
                $base_url . $js_rel,
                $reset_deps,
                (string) filemtime($base_dir . $js_rel),
                true
            );

            wp_localize_script(
                'yooadmin-guided-tour-reset',
                'yooadminGuidedTourReset',
                [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                ]
            );
        }
    }

    YOOAdmin_Guided_Tour::init();
}
