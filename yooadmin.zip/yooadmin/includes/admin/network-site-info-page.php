<?php
defined('ABSPATH') || exit;

class YOOAdmin_Network_Site_Info_Page
{
    private static $instance = null;

    public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        if (!is_multisite()) {
            return;
        }

        add_action('admin_init', [$this, 'set_page_title']);
        add_action('network_admin_menu', [$this, 'register_network_page'], 9);
    }

    public function set_page_title(): void
    {
        if (!function_exists('yooadmin_network_site_info_is_screen') || !yooadmin_network_site_info_is_screen()) {
            return;
        }

        $blog_id = function_exists('yooadmin_network_site_info_current_id')
            ? yooadmin_network_site_info_current_id()
            : 0;

        global $title;
        if ($blog_id > 0 && function_exists('yooadmin_network_site_info_site_name')) {
            $title = sprintf(
                /* translators: %s: site title. */
                __('Edit Site: %s', 'yooadmin'),
                yooadmin_network_site_info_site_name($blog_id)
            );
            return;
        }

        $title = __('Edit Site', 'yooadmin');
    }

    public function register_network_page(): void
    {

        add_submenu_page(
            null,
            __('Edit Site', 'yooadmin'),
            __('Edit Site', 'yooadmin'),
            'manage_sites',
            yooadmin_network_site_info_page_slug(),
            [$this, 'render_page']
        );
    }

    public function render_page(): void
    {

        if (!current_user_can('manage_sites')) {
            wp_die(esc_html__('Sorry, you are not allowed to edit this site.', 'yooadmin'));
        }

        if (!function_exists('yooadmin_network_site_info_should_use') || !yooadmin_network_site_info_should_use()) {
            $blog_id = function_exists('yooadmin_network_site_info_current_id')
                ? yooadmin_network_site_info_current_id()
                : 0;
            $target  = $blog_id > 0
                ? network_admin_url('site-info.php?id=' . $blog_id)
                : network_admin_url('sites.php');
            wp_safe_redirect($target);
            exit;
        }

        $blog_id = yooadmin_network_site_info_current_id();
        if ($blog_id <= 0 || !yooadmin_network_site_info_get_site($blog_id)) {
            wp_die(esc_html__('The requested site does not exist.', 'yooadmin'));
        }

        global $title;
        $title = sprintf(
            /* translators: %s: site title. */
            __('Edit Site: %s', 'yooadmin'),
            yooadmin_network_site_info_site_name($blog_id)
        );

        $template = defined('YOOADMIN_PANEL_DIR')
            ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-site-info/index.php'
            : '';

        if ($template && is_readable($template)) {
            include $template;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html($title) . '</h1></div>';
    }
}

YOOAdmin_Network_Site_Info_Page::get_instance();
