<?php
/**
 * Dashboard and shell experience tailored for non-administrator users (Editors, etc.).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_regular_user_experience_init')) {
    function yooadmin_regular_user_experience_init(): void
    {
        if (!function_exists('yooadmin_is_site_regular_user') || !yooadmin_is_site_regular_user()) {
            return;
        }

        add_filter('yooadmin_studio_hub_layout_capability', static function (): string {
            return 'manage_options';
        });

        add_filter('yooadmin_quick_actions_capability', static function (): string {
            return 'manage_options';
        });

        add_filter('yooadmin_guided_tour_passes_global_gates', static function (): bool {
            return false;
        });

        add_filter('yooadmin_yooai_promo_enabled', static function (): bool {
            return false;
        });

        add_filter('yooadmin_user_can_view_dashboard_card', static function (bool $can, string $id): bool {
            if ($id === 'yooadmin_overview') {
                return false;
            }
            if ($id === 'yooadmin_account_overview') {
                return true;
            }
            if (in_array($id, ['studio-workspace-notes', 'studio-tips'], true)) {
                return false;
            }

            return $can;
        }, 10, 2);

        add_filter('yooadmin_studio_hub_resolved_main_order', static function (array $order): array {
            return array_values(
                array_filter(
                    $order,
                    static function (string $section_id): bool {
                        return $section_id !== 'your-workspace';
                    }
                )
            );
        });

        add_filter('yooadmin_studio_hub_layout_defaults', static function (array $layout): array {
            return yooadmin_regular_user_patch_layout_overview($layout);
        });

        add_filter('yooadmin_studio_hub_user_layout', static function (array $layout): array {
            $layout['mainOrder'] = array_values(
                array_filter(
                    isset($layout['mainOrder']) && is_array($layout['mainOrder']) ? $layout['mainOrder'] : [],
                    static function ($section_id): bool {
                        return (string) $section_id !== 'your-workspace';
                    }
                )
            );

            return yooadmin_regular_user_patch_layout_overview($layout);
        }, 10, 2);

        add_filter('yooadmin_studio_hub_card_welcome_content', static function (array $data): array {
            $data['p2'] = __(
                'Use the shortcuts below to open your profile and the tools available to your account, and review your account summary in the overview panel.',
                'yooadmin'
            );

            return $data;
        });

        add_filter('yooadmin_studio_hub_dashboard_layout_i18n', static function (array $i18n): array {
            $i18n['yooadminOverview'] = __('Account overview', 'yooadmin');

            return $i18n;
        });

        add_filter('yooadmin_toolbar_shortcuts', static function (array $shortcuts): array {
            if ($shortcuts !== []) {
                return $shortcuts;
            }

            if (!function_exists('yooadmin_get_regular_user_shortcut_items')
                || !function_exists('yooadmin_toolbar_shortcuts_from_link_items')
            ) {
                return $shortcuts;
            }

            return yooadmin_toolbar_shortcuts_from_link_items(yooadmin_get_regular_user_shortcut_items());
        }, 100);
    }

    /**
     * @param array<string, mixed> $layout
     * @return array<string, mixed>
     */
    function yooadmin_regular_user_patch_layout_overview(array $layout): array
    {
        if (!function_exists('yooadmin_studio_hub_default_overview_widget_section_id')) {
            return $layout;
        }

        $section_id = yooadmin_studio_hub_default_overview_widget_section_id();
        $aside      = isset($layout['asideOrder']) && is_array($layout['asideOrder']) ? $layout['asideOrder'] : [];

        $aside = array_values(
            array_filter(
                $aside,
                static function ($section_id): bool {
                    return !in_array((string) $section_id, ['studio-workspace-notes', 'studio-tips'], true);
                }
            )
        );

        if (!in_array($section_id, $aside, true)) {
            $aside[] = $section_id;
        }

        $layout['asideOrder'] = $aside;

        if (!isset($layout['widgetSections']) || !is_array($layout['widgetSections'])) {
            $layout['widgetSections'] = [];
        }

        $layout['widgetSections'][ $section_id ] = [
            'placement' => 'aside',
            'widgetId'  => 'yooadmin_account_overview',
            'title'     => function_exists('yooadmin_studio_hub_localized_widget_section_title')
                ? yooadmin_studio_hub_localized_widget_section_title('yooadmin_account_overview')
                : __('Account overview', 'yooadmin'),
            'icon'      => 'dashicons-id-alt',
        ];

        return $layout;
    }

    /**
     * Curated shortcut tiles for non-administrator users (deduped URLs, valid dashicons).
     *
     * @return array<int, array{title: string, url: string, icon: string}>
     */
    function yooadmin_get_regular_user_shortcut_items(): array
    {
        $user = wp_get_current_user();
        if (!$user || !$user->exists()) {
            return [];
        }

        $items    = [];
        $seen_url = [];

        $push = static function (array &$items, array &$seen, string $label, string $url, string $icon) use ($user): void {
            if ($label === '' || $url === '') {
                return;
            }

            $key = untrailingslashit(strtolower($url));
            if (isset($seen[ $key ])) {
                return;
            }

            if (function_exists('yooadmin_user_can_access_admin_href') && !yooadmin_user_can_access_admin_href($url)) {
                return;
            }

            $seen[ $key ] = true;
            $items[]      = [
                'title' => $label,
                'url'   => $url,
                'icon'  => $icon,
            ];
        };

        $dashboard_url = function_exists('yooadmin_dashboard_url')
            ? yooadmin_dashboard_url()
            : admin_url('admin.php?page=yooadmin-dashboard');
        $push($items, $seen_url, __('Dashboard', 'yooadmin'), $dashboard_url, 'dashicons-dashboard');
        $push($items, $seen_url, __('Profile', 'yooadmin'), get_edit_profile_url($user->ID), 'dashicons-admin-users');

        if (user_can($user, 'edit_posts')) {
            $push($items, $seen_url, __('Posts', 'yooadmin'), admin_url('edit.php'), 'dashicons-admin-post');
        }
        if (user_can($user, 'edit_pages')) {
            $push($items, $seen_url, __('Pages', 'yooadmin'), admin_url('edit.php?post_type=page'), 'dashicons-admin-page');
        }
        if (user_can($user, 'upload_files')) {
            $push($items, $seen_url, __('Media', 'yooadmin'), admin_url('upload.php'), 'dashicons-admin-media');
        }
        if (user_can($user, 'moderate_comments')) {
            $push($items, $seen_url, __('Comments', 'yooadmin'), admin_url('edit-comments.php'), 'dashicons-admin-comments');
        }

        return apply_filters('yooadmin_regular_user_shortcut_items', $items, $user);
    }

    /**
     * Section title for the workspace shortcuts card (top row).
     */
    function yooadmin_regular_user_shortcuts_title(): string
    {
        return (string) apply_filters(
            'yooadmin_regular_user_shortcuts_title',
            __('Shortcuts', 'yooadmin')
        );
    }
}

add_action('init', 'yooadmin_regular_user_experience_init', 20);
