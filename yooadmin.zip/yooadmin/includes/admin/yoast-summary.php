<?php
/**
 * Shared Yoast SEO summary helpers for YOOAdmin list screens.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_get_yoast_score_status')) {
    /**
     * Map Yoast numeric scores to compact status labels.
     */
    function yooadmin_get_yoast_score_status($score, $type = 'score', $has_yoast_data = false)
    {
        if ($score === '' || $score === null) {
            if ($has_yoast_data && $type === 'seo') {
                return 'needs-work';
            }
            return '';
        }

        if (!is_numeric($score)) {
            $score = strtolower((string)$score);
            if (in_array($score, ['good', 'ok', 'needs-work', 'bad', 'neutral'], true)) {
                return $score === 'bad' ? 'needs-work' : $score;
            }
            return '';
        }

        $score = (int)$score;
        if ($score <= 0) {
            return $type === 'seo' ? 'needs-work' : 'neutral';
        }
        if ($score >= 80) {
            return 'good';
        }
        if ($score >= 50) {
            return 'ok';
        }
        return 'needs-work';
    }
}

if (!function_exists('yooadmin_get_yoast_indexable_scores')) {
    /**
     * Read Yoast's modern indexable scores when legacy post meta is empty.
     */
    function yooadmin_get_yoast_indexable_scores($post_id, $object_sub_type)
    {
        global $wpdb;

        static $table_exists = null;

        $post_id = (int)$post_id;
        $object_sub_type = sanitize_key((string)$object_sub_type);
        $cache_key = $post_id . ':' . $object_sub_type;

        if ($post_id <= 0 || $object_sub_type === '') {
            return [];
        }

        $cached = wp_cache_get($cache_key, 'yooadmin_yoast');
        if (false !== $cached) {
            return is_array($cached) ? $cached : [];
        }

        $table = $wpdb->prefix . 'yoast_indexable';
        if ($table_exists === null) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Yoast table existence check; no WordPress API available.
            $table_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table);
        }

        if (!$table_exists) {
            wp_cache_set($cache_key, [], 'yooadmin_yoast', HOUR_IN_SECONDS);
            return [];
        }

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is {$wpdb->prefix} + fixed Yoast suffix; values use placeholders.
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT primary_focus_keyword_score, readability_score FROM {$table} WHERE object_id = %d AND object_type = %s AND object_sub_type = %s LIMIT 1",
                $post_id,
                'post',
                $object_sub_type
            ),
            ARRAY_A
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

        $result = is_array($row) ? $row : [];
        wp_cache_set($cache_key, $result, 'yooadmin_yoast', HOUR_IN_SECONDS);

        return $result;
    }
}

if (!function_exists('yooadmin_get_yoast_summary')) {
    /**
     * Build Yoast SEO summary items for a post or page.
     */
    function yooadmin_get_yoast_summary($post_id, $object_sub_type)
    {
        $items = [];
        $seo_score = get_post_meta($post_id, '_yoast_wpseo_linkdex', true);
        $readability_score = get_post_meta($post_id, '_yoast_wpseo_content_score', true);
        $indexable_scores = yooadmin_get_yoast_indexable_scores($post_id, $object_sub_type);
        $has_yoast_data = !empty($indexable_scores);

        if ($seo_score === '' && array_key_exists('primary_focus_keyword_score', $indexable_scores)) {
            $seo_score = $indexable_scores['primary_focus_keyword_score'];
        }
        if ($readability_score === '' && array_key_exists('readability_score', $indexable_scores)) {
            $readability_score = $indexable_scores['readability_score'];
        }

        $seo_status = yooadmin_get_yoast_score_status($seo_score, 'seo', $has_yoast_data);
        if ($seo_status !== '') {
            $seo_title = ($seo_score === '' || $seo_score === null)
                ? __('Yoast SEO: no focus keyphrase set', 'yooadmin')
                : sprintf(
                    /* translators: %s: Yoast SEO score */
                    __('Yoast SEO score: %s', 'yooadmin'),
                    (string)$seo_score
                );
            $items[] = [
                'type' => 'seo',
                'status' => $seo_status,
                'label' => __('SEO', 'yooadmin'),
                'title' => $seo_title,
            ];
        }

        $readability_status = yooadmin_get_yoast_score_status($readability_score, 'readability', $has_yoast_data);
        if ($readability_status !== '') {
            $readability_title = ((string)$readability_score === '0')
                ? __('Yoast readability: not analyzed yet', 'yooadmin')
                : sprintf(
                    /* translators: %s: Yoast readability score */
                    __('Yoast readability score: %s', 'yooadmin'),
                    (string)$readability_score
                );
            $items[] = [
                'type' => 'readability',
                'status' => $readability_status,
                'label' => __('Readability', 'yooadmin'),
                'title' => $readability_title,
            ];
        }

        if ($object_sub_type === 'page') {
            $items = apply_filters('yooadmin_pages_yoast_summary', $items, $post_id);
        } elseif ($object_sub_type === 'post') {
            $items = apply_filters('yooadmin_posts_yoast_summary', $items, $post_id);
        }

        return apply_filters('yooadmin_yoast_summary', $items, $post_id, $object_sub_type);
    }
}

if (!function_exists('yooadmin_render_yoast_summary')) {
    /**
     * Render Yoast SEO summary chips under list screen actions.
     */
    function yooadmin_render_yoast_summary($post_id, $object_sub_type)
    {
        $items = yooadmin_get_yoast_summary($post_id, $object_sub_type);
        if (empty($items)) {
            return;
        }
        ?>
        <div class="yoo-yoast-summary" aria-label="<?php esc_attr_e('Yoast SEO', 'yooadmin'); ?>">
            <span class="yoo-yoast-summary__brand"><?php esc_html_e('Yoast', 'yooadmin'); ?></span>
            <?php foreach ($items as $item): ?>
                <span class="yoo-yoast-chip yoo-yoast-chip--<?php echo esc_attr($item['status']); ?>" title="<?php echo esc_attr($item['title']); ?>">
                    <span class="yoo-yoast-chip__dot" aria-hidden="true"></span>
                    <span><?php echo esc_html($item['label']); ?></span>
                </span>
            <?php endforeach; ?>
        </div>
        <?php
    }
}
