<?php
/**
 * Compact Plus promo strip on YOOAdmin Settings.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_settings_should_show_plus_promo')) {
    function yooadmin_settings_should_show_plus_promo(): bool
    {
        $show = true;

        if (function_exists('yooadmin_plus_license_active') && yooadmin_plus_license_active()) {
            $show = false;
        }

        /**
         * Whether to show the Plus promo strip on YOOAdmin Settings.
         *
         * @param bool $show Default visibility.
         */
        return (bool) apply_filters('yooadmin_settings_show_plus_promo', $show);
    }
}

if (!function_exists('yooadmin_settings_plus_promo_url')) {
    function yooadmin_settings_plus_promo_url(): string
    {
        /**
         * Plus promo destination URL on the settings page.
         *
         * @param string $url Default URL.
         */
        return (string) apply_filters('yooadmin_settings_plus_promo_url', 'https://yooadmin.io');
    }
}

if (!function_exists('yooadmin_render_settings_plus_promo')) {
    function yooadmin_render_settings_plus_promo(): void
    {
        if (!yooadmin_settings_should_show_plus_promo()) {
            return;
        }

        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $url = yooadmin_settings_plus_promo_url();
        ?>
        <div class="yp-settings-callout yp-settings-callout--plus-promo" role="note">
            <span class="yp-settings-callout__badge"><?php esc_html_e('Plus', 'yooadmin'); ?></span>
            <p class="yp-settings-callout__text">
                <?php
                echo wp_kses(
                    sprintf(
                        /* translators: 1: product name, 2: link opening tag, 3: link closing tag */
                        __('🚀 %1$s — expand your dashboard with extensions, media tools, and more. Download %2$sYOOAdmin Plus%3$s for free.', 'yooadmin'),
                        '<strong>' . esc_html__('Enhance your experience', 'yooadmin') . '</strong>',
                        '<a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer">',
                        '</a>'
                    ),
                    [
                        'strong' => [],
                        'a'      => [
                            'href'   => true,
                            'target' => true,
                            'rel'    => true,
                        ],
                    ]
                );
                ?>
            </p>
        </div>
        <?php
    }
}
