<?php
/**
 * Workspace Notes — AJAX handlers.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

add_action('wp_ajax_yooadmin_workspace_notes_list', 'yooadmin_ajax_workspace_notes_list');
add_action('wp_ajax_yooadmin_workspace_notes_save', 'yooadmin_ajax_workspace_notes_save');
add_action('wp_ajax_yooadmin_workspace_notes_delete', 'yooadmin_ajax_workspace_notes_delete');
add_action('wp_ajax_yooadmin_workspace_notes_toggle', 'yooadmin_ajax_workspace_notes_toggle');
add_action('wp_ajax_yooadmin_workspace_notes_set_type', 'yooadmin_ajax_workspace_notes_set_type');

/**
 * Verify AJAX request for workspace notes.
 */
function yooadmin_workspace_notes_ajax_verify(): void {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 401);
    }

    if (!current_user_can('read')) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 403);
    }

    $nonce = yooadmin_workspace_notes_post('nonce', 'text');
    if (!wp_verify_nonce($nonce, 'yooadmin_workspace_notes')) {
        wp_send_json_error(['message' => __('Invalid nonce', 'yooadmin')], 403);
    }
}

/**
 * Read a POST field (call only after yooadmin_workspace_notes_ajax_verify()).
 *
 * @param string $key    POST key.
 * @param string $method Sanitize method: text|key|int|html.
 * @return int|string
 */
function yooadmin_workspace_notes_post(string $key, string $method = 'text') {
    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified by yooadmin_workspace_notes_ajax_verify().
    if (!isset($_POST[ $key ])) {
        return 'int' === $method ? 0 : '';
    }

    $raw = wp_unslash($_POST[ $key ]); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below by $method.
    // phpcs:enable WordPress.Security.NonceVerification.Missing

    switch ($method) {
        case 'key':
            return sanitize_key($raw);
        case 'int':
            return absint($raw);
        case 'html':
            return wp_kses_post((string) $raw);
        default:
            return sanitize_text_field((string) $raw);
    }
}

function yooadmin_ajax_workspace_notes_list(): void {
    yooadmin_workspace_notes_ajax_verify();

    $type = yooadmin_workspace_notes_post('note_type', 'key');
    if ($type === '') {
        $type = null;
    }

    $offset = max(0, yooadmin_workspace_notes_post('offset', 'int'));
    $limit  = yooadmin_workspace_notes_post('limit', 'int');
    if ($limit <= 0) {
        $limit = function_exists('yooadmin_workspace_notes_page_size')
            ? yooadmin_workspace_notes_page_size()
            : 3;
    }
    $limit = max(1, min(50, $limit));

    $service = yooadmin_workspace_notes_service();
    $page    = $service->list_notes_page(get_current_user_id(), $type, $offset, $limit);

    wp_send_json_success(
        array_merge(
            [
                'active_type' => $service->get_active_type(),
                'types'       => yooadmin_workspace_notes_types(),
            ],
            $page
        ),
        200
    );
}

function yooadmin_ajax_workspace_notes_save(): void {
    yooadmin_workspace_notes_ajax_verify();

    $result = yooadmin_workspace_notes_service()->save_note(
        [
            'id'        => yooadmin_workspace_notes_post('id', 'int'),
            'note_type' => yooadmin_workspace_notes_post('note_type', 'key'),
            'title'     => yooadmin_workspace_notes_post('title', 'text'),
            'body'      => yooadmin_workspace_notes_post('body', 'html'),
            'due_at'    => yooadmin_workspace_notes_post('due_at', 'text'),
            'remind_at' => yooadmin_workspace_notes_post('remind_at', 'text'),
        ]
    );

    if (empty($result['success'])) {
        wp_send_json_error(['message' => $result['message'] ?? __('Save failed.', 'yooadmin')], 400);
    }

    wp_send_json_success($result, 200);
}

function yooadmin_ajax_workspace_notes_delete(): void {
    yooadmin_workspace_notes_ajax_verify();

    $id = yooadmin_workspace_notes_post('id', 'int');
    if ($id <= 0) {
        wp_send_json_error(['message' => __('Invalid note.', 'yooadmin')], 400);
    }

    $ok = yooadmin_workspace_notes_service()->delete_note($id);
    if (!$ok) {
        wp_send_json_error(['message' => __('Could not delete note.', 'yooadmin')], 400);
    }

    wp_send_json_success(['deleted' => $id], 200);
}

function yooadmin_ajax_workspace_notes_toggle(): void {
    yooadmin_workspace_notes_ajax_verify();

    $id = yooadmin_workspace_notes_post('id', 'int');
    if ($id <= 0) {
        wp_send_json_error(['message' => __('Invalid note.', 'yooadmin')], 400);
    }

    $result = yooadmin_workspace_notes_service()->toggle_done($id);
    if (empty($result['success'])) {
        wp_send_json_error(['message' => $result['message'] ?? __('Update failed.', 'yooadmin')], 400);
    }

    wp_send_json_success($result, 200);
}

function yooadmin_ajax_workspace_notes_set_type(): void {
    yooadmin_workspace_notes_ajax_verify();

    $type = yooadmin_workspace_notes_post('note_type', 'key');
    if (!yooadmin_workspace_notes_service()->set_active_type($type)) {
        wp_send_json_error(['message' => __('Invalid type.', 'yooadmin')], 400);
    }

    $page_size = function_exists('yooadmin_workspace_notes_page_size')
        ? yooadmin_workspace_notes_page_size()
        : 3;
    $page      = yooadmin_workspace_notes_service()->list_notes_page(get_current_user_id(), $type, 0, $page_size);

    wp_send_json_success(
        array_merge(
            ['active_type' => yooadmin_workspace_notes_get_active_type()],
            $page
        ),
        200
    );
}
