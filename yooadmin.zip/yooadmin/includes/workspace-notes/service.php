<?php
/**
 * Workspace Notes — business logic.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

class YOOAdmin_Workspace_Notes_Service {

    public function get_active_type(int $user_id = 0): string {
        $user_id = $user_id > 0 ? $user_id : get_current_user_id();
        $types   = array_keys(yooadmin_workspace_notes_types());
        $meta    = function_exists('yooadmin_workspace_notes_active_type_meta_key')
            ? yooadmin_workspace_notes_active_type_meta_key()
            : 'yooadmin_workspace_notes_active_type';
        $stored  = (string) get_user_meta($user_id, $meta, true);

        if (in_array($stored, $types, true)) {
            return $stored;
        }

        return 'todos';
    }

    public function set_active_type(string $type, int $user_id = 0): bool {
        $user_id = $user_id > 0 ? $user_id : get_current_user_id();
        $types   = array_keys(yooadmin_workspace_notes_types());

        if (!in_array($type, $types, true)) {
            return false;
        }

        $meta = function_exists('yooadmin_workspace_notes_active_type_meta_key')
            ? yooadmin_workspace_notes_active_type_meta_key()
            : 'yooadmin_workspace_notes_active_type';
        update_user_meta($user_id, $meta, $type);
        return true;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function list_notes(int $user_id = 0, ?string $type = null): array {
        $user_id = $user_id > 0 ? $user_id : get_current_user_id();
        if ($user_id <= 0) {
            return [];
        }

        $type    = $type ?: $this->get_active_type($user_id);
        $types   = array_keys(yooadmin_workspace_notes_types());
        if (!in_array($type, $types, true)) {
            $type = 'todos';
        }

        $blog_id = function_exists('yooadmin_workspace_notes_storage_blog_id')
            ? yooadmin_workspace_notes_storage_blog_id()
            : (int) get_current_blog_id();
        $rows    = yooadmin_workspace_notes_storage()->get_notes($user_id, $blog_id, $type);

        return array_map([$this, 'format_note_for_js'], $rows);
    }

    /**
     * Paginated notes for the workspace list UI.
     *
     * @return array{notes: array<int, array<string, mixed>>, total: int, has_more: bool, offset: int, limit: int}
     */
    public function list_notes_page(int $user_id = 0, ?string $type = null, int $offset = 0, int $limit = 3): array {
        $user_id = $user_id > 0 ? $user_id : get_current_user_id();
        $limit   = max(1, min(50, $limit));
        $offset  = max(0, $offset);

        if ($user_id <= 0) {
            return [
                'notes'    => [],
                'total'    => 0,
                'has_more' => false,
                'offset'   => $offset,
                'limit'    => $limit,
            ];
        }

        $type  = $type ?: $this->get_active_type($user_id);
        $types = array_keys(yooadmin_workspace_notes_types());
        if (!in_array($type, $types, true)) {
            $type = 'todos';
        }

        $blog_id = function_exists('yooadmin_workspace_notes_storage_blog_id')
            ? yooadmin_workspace_notes_storage_blog_id()
            : (int) get_current_blog_id();
        $storage = yooadmin_workspace_notes_storage();
        $total   = $storage->count_notes($user_id, $blog_id, $type);
        $rows    = $storage->get_notes($user_id, $blog_id, $type, $offset, $limit);
        $notes   = array_map([$this, 'format_note_for_js'], $rows);

        return [
            'notes'    => $notes,
            'total'    => $total,
            'has_more' => ($offset + count($notes)) < $total,
            'offset'   => $offset,
            'limit'    => $limit,
        ];
    }

    /**
     * @param array<string, mixed> $input
     * @return array{success: bool, note?: array<string, mixed>, message?: string}
     */
    public function save_note(array $input, int $user_id = 0): array {
        $user_id = $user_id > 0 ? $user_id : get_current_user_id();
        if ($user_id <= 0) {
            return ['success' => false, 'message' => __('Unauthorized', 'yooadmin')];
        }

        $types = array_keys(yooadmin_workspace_notes_types());
        $type  = isset($input['note_type']) ? sanitize_key((string) $input['note_type']) : $this->get_active_type($user_id);
        if (!in_array($type, $types, true)) {
            $type = 'todos';
        }

        $title = isset($input['title']) ? sanitize_text_field((string) $input['title']) : '';
        if ($title === '') {
            return ['success' => false, 'message' => __('Title is required.', 'yooadmin')];
        }

        $body      = isset($input['body']) ? wp_kses_post((string) $input['body']) : '';
        $note_id   = isset($input['id']) ? absint($input['id']) : 0;
        $blog_id   = function_exists('yooadmin_workspace_notes_storage_blog_id')
            ? yooadmin_workspace_notes_storage_blog_id()
            : (int) get_current_blog_id();
        $due_at    = $this->parse_datetime_field($input, 'due_at', $type === 'todos');
        $remind_at = $this->parse_datetime_field($input, 'remind_at', $type === 'reminders');

        if ($type === 'todos' && $due_at === null) {
            return ['success' => false, 'message' => __('Due date is required.', 'yooadmin')];
        }
        if ($type === 'reminders' && $remind_at === null) {
            return ['success' => false, 'message' => __('Reminder time is required.', 'yooadmin')];
        }

        $storage = yooadmin_workspace_notes_storage();

        if ($note_id > 0) {
            $existing = $storage->get_note($note_id, $user_id);
            if (!$existing) {
                return ['success' => false, 'message' => __('Note not found.', 'yooadmin')];
            }

            $update = [
                'title'  => $title,
                'body'   => $body,
                'status' => isset($input['status']) ? sanitize_key((string) $input['status']) : (string) $existing['status'],
            ];

            if ($type === 'todos') {
                $update['due_at']     = $due_at;
                $update['remind_at']  = null;
            } elseif ($type === 'reminders') {
                $update['remind_at']     = $remind_at;
                $update['reminder_sent'] = 0;
                $update['due_at']        = null;
            } else {
                $update['due_at']    = null;
                $update['remind_at'] = null;
            }

            $storage->update_note($note_id, $user_id, $update);
            $row = $storage->get_note($note_id, $user_id);

            if ($type === 'reminders' && function_exists('yooadmin_workspace_notes_process_reminders_after_save')) {
                yooadmin_workspace_notes_process_reminders_after_save($note_id, $user_id);
            }

            return [
                'success' => true,
                'note'    => $row ? $this->format_note_for_js($row) : null,
            ];
        }

        $new_id = $storage->insert_note([
            'user_id'       => $user_id,
            'blog_id'       => $blog_id,
            'note_type'     => $type,
            'title'         => $title,
            'body'          => $body,
            'status'        => 'active',
            'due_at'        => $type === 'todos' ? $due_at : null,
            'completed_at'  => null,
            'remind_at'     => $type === 'reminders' ? $remind_at : null,
            'reminder_sent' => 0,
        ]);

        if (!$new_id) {
            return ['success' => false, 'message' => __('Could not save note.', 'yooadmin')];
        }

        $row = $storage->get_note((int) $new_id, $user_id);

        if ($type === 'reminders' && $new_id && function_exists('yooadmin_workspace_notes_process_reminders_after_save')) {
            yooadmin_workspace_notes_process_reminders_after_save((int) $new_id, $user_id);
        }

        return [
            'success' => true,
            'note'    => $row ? $this->format_note_for_js($row) : null,
        ];
    }

    /**
     * @return array{success: bool, note?: array<string, mixed>, message?: string}
     */
    public function toggle_done(int $note_id, int $user_id = 0): array {
        $user_id = $user_id > 0 ? $user_id : get_current_user_id();
        $storage = yooadmin_workspace_notes_storage();
        $note    = $storage->get_note($note_id, $user_id);

        if (!$note) {
            return ['success' => false, 'message' => __('Note not found.', 'yooadmin')];
        }

        $is_done = ($note['status'] ?? '') === 'done';
        if ($is_done) {
            $storage->update_note(
                $note_id,
                $user_id,
                [
                    'status'       => 'active',
                    'completed_at' => null,
                ]
            );
        } else {
            $storage->update_note(
                $note_id,
                $user_id,
                [
                    'status'       => 'done',
                    'completed_at' => gmdate('Y-m-d H:i:s'),
                ]
            );
        }

        $row = $storage->get_note($note_id, $user_id);

        return [
            'success' => true,
            'note'    => $row ? $this->format_note_for_js($row) : null,
        ];
    }

    public function delete_note(int $note_id, int $user_id = 0): bool {
        $user_id = $user_id > 0 ? $user_id : get_current_user_id();
        return yooadmin_workspace_notes_storage()->soft_delete($note_id, $user_id);
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public function format_note_for_js(array $row): array {
        $due     = $this->format_datetime_fields($row['due_at'] ?? '', true);
        $done    = $this->format_datetime_fields($row['completed_at'] ?? '', true);
        $remind  = $this->format_datetime_fields($row['remind_at'] ?? '', true);
        $created = $this->format_datetime_fields($row['created_at'] ?? '', false);

        return [
            'id'                  => (int) ($row['id'] ?? 0),
            'note_type'           => (string) ($row['note_type'] ?? ''),
            'title'               => (string) ($row['title'] ?? ''),
            'body'                => (string) ($row['body'] ?? ''),
            'status'              => (string) ($row['status'] ?? 'active'),
            'due_at'              => $due['raw'],
            'due_at_iso'          => $due['iso'],
            'due_at_local'        => $due['local'],
            'due_at_label'        => $due['label'],
            'completed_at'        => $done['raw'],
            'completed_at_iso'    => $done['iso'],
            'completed_at_label'  => $done['label'],
            'remind_at'           => $remind['raw'],
            'remind_at_iso'       => $remind['iso'],
            'remind_at_local'     => $remind['local'],
            'remind_at_label'     => $remind['label'],
            'is_done'             => ($row['status'] ?? '') === 'done',
            'created_at'          => (string) ($row['created_at'] ?? ''),
            'created_at_label'    => $created['label'],
        ];
    }

    /**
     * @param bool $stored_utc True for due_at/remind_at (saved as UTC); false for created_at (site-local MySQL).
     * @return array{raw: string, iso: string, local: string, label: string}
     */
    private function format_datetime_fields($value, bool $stored_utc = true): array {
        $raw = is_string($value) ? trim($value) : '';
        if ($raw === '' || $raw === '0000-00-00 00:00:00') {
            return [
                'raw'   => '',
                'iso'   => '',
                'local' => '',
                'label' => '',
            ];
        }

        try {
            if ($stored_utc) {
                $dt = new DateTimeImmutable($raw, new DateTimeZone('UTC'));
            } else {
                $dt = new DateTimeImmutable($raw, wp_timezone());
            }
            $ts = $dt->getTimestamp();
        } catch (Exception $e) {
            return [
                'raw'   => $raw,
                'iso'   => '',
                'local' => '',
                'label' => '',
            ];
        }

        return [
            'raw'   => $raw,
            'iso'   => wp_date('c', $ts),
            'local' => wp_date('Y-m-d\TH:i', $ts),
            'label' => wp_date(get_option('date_format') . ' ' . get_option('time_format'), $ts),
        ];
    }

    /**
     * @param array<string, mixed> $input
     */
    private function parse_datetime_field(array $input, string $key, bool $enabled): ?string {
        if (!$enabled) {
            return null;
        }

        $raw = isset($input[ $key ]) ? trim((string) $input[ $key ]) : '';
        if ($raw === '') {
            return null;
        }

        try {
            $tz = wp_timezone();
            $dt = date_create($raw, $tz);
            if (!$dt) {
                return null;
            }
            $dt->setTimezone(new DateTimeZone('UTC'));
            return $dt->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            return null;
        }
    }
}
