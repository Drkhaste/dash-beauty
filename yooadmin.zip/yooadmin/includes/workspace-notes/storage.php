<?php
/**
 * Workspace Notes — database storage.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is {$wpdb->prefix} + fixed plugin suffix.

class YOOAdmin_Workspace_Notes_Storage {

    /** @var bool */
    private static $schema_ready = false;

    /** @var int Increment when {@see maybe_create_tables()} / migration changes. */
    private const SCHEMA_VERSION = 2;

    /**
     * @return string
     */
    public function table_name(): string {
        global $wpdb;
        return $wpdb->prefix . 'yooadmin_workspace_notes';
    }

    /**
     * Ensure table exists (runs at most once per request; dbDelta only when schema version bumps).
     */
    public function ensure_schema(): void {
        if (self::$schema_ready) {
            return;
        }
        self::$schema_ready = true;

        $option = 'yooadmin_workspace_notes_schema_version';
        $stored = (int) get_option($option, 0);
        if ($stored >= self::SCHEMA_VERSION) {
            return;
        }

        $this->maybe_create_tables();
        $this->maybe_migrate_schema();
        update_option($option, self::SCHEMA_VERSION, false);
    }

    public function maybe_create_tables(): void {
        global $wpdb;

        $table = $this->table_name();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $charset_collate = $wpdb->get_charset_collate();
        $sql             = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            blog_id bigint(20) unsigned NOT NULL DEFAULT 0,
            note_type varchar(32) NOT NULL DEFAULT 'todos',
            title varchar(255) NOT NULL DEFAULT '',
            body longtext NULL,
            status varchar(20) NOT NULL DEFAULT 'active',
            due_at datetime NULL DEFAULT NULL,
            completed_at datetime NULL DEFAULT NULL,
            remind_at datetime NULL DEFAULT NULL,
            reminder_sent tinyint(1) NOT NULL DEFAULT 0,
            sort_order int(11) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_blog_type (user_id, blog_id, note_type),
            KEY remind_due (remind_at, reminder_sent),
            KEY status (status)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        $this->maybe_migrate_schema();
    }

    public function maybe_migrate_schema(): void {
        global $wpdb;

        $table = $this->table_name();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table) {
            return;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $columns = $wpdb->get_col("DESCRIBE {$table}", 0);
        if (!is_array($columns)) {
            return;
        }

        if (!in_array('due_at', $columns, true)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
            $wpdb->query("ALTER TABLE {$table} ADD COLUMN due_at datetime NULL DEFAULT NULL AFTER status");
        }
        if (!in_array('completed_at', $columns, true)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
            $wpdb->query("ALTER TABLE {$table} ADD COLUMN completed_at datetime NULL DEFAULT NULL AFTER due_at");
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function get_notes(int $user_id, int $blog_id, string $type, int $offset = 0, ?int $limit = null): array {
        global $wpdb;

        $this->ensure_schema();
        $table = $this->table_name();

        $query = $wpdb->prepare(
            "SELECT * FROM {$table}
                 WHERE user_id = %d AND blog_id = %d AND note_type = %s AND status != %s
                 ORDER BY sort_order ASC, id DESC",
            $user_id,
            $blog_id,
            $type,
            'deleted'
        );

        if ($limit !== null && $limit > 0) {
            $query .= $wpdb->prepare(' LIMIT %d OFFSET %d', (int) $limit, max(0, (int) $offset));
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- LIMIT appended after prepare(); table from plugin schema.
        $rows = $wpdb->get_results($query, ARRAY_A);

        return is_array($rows) ? $rows : [];
    }

    /**
     * Count active notes for a user, blog, and type.
     */
    public function count_notes(int $user_id, int $blog_id, string $type): int {
        global $wpdb;

        $this->ensure_schema();
        $table = $this->table_name();

        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table}
                 WHERE user_id = %d AND blog_id = %d AND note_type = %s AND status != %s",
                $user_id,
                $blog_id,
                $type,
                'deleted'
            )
        );

        return max(0, (int) $count);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function get_note(int $note_id, int $user_id): ?array {
        global $wpdb;

        $this->ensure_schema();
        $table = $this->table_name();

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d AND user_id = %d LIMIT 1",
                $note_id,
                $user_id
            ),
            ARRAY_A
        );

        return is_array($row) ? $row : null;
    }

    /**
     * @param array<string, mixed> $data
     * @return int|false Note ID or false.
     */
    public function insert_note(array $data) {
        global $wpdb;

        $this->ensure_schema();
        $table = $this->table_name();

        $inserted = $wpdb->insert(
            $table,
            [
                'user_id'        => (int) ($data['user_id'] ?? 0),
                'blog_id'        => (int) ($data['blog_id'] ?? 0),
                'note_type'      => (string) ($data['note_type'] ?? 'todos'),
                'title'          => (string) ($data['title'] ?? ''),
                'body'           => (string) ($data['body'] ?? ''),
                'status'         => (string) ($data['status'] ?? 'active'),
                'due_at'         => !empty($data['due_at']) ? $data['due_at'] : null,
                'completed_at'   => !empty($data['completed_at']) ? $data['completed_at'] : null,
                'remind_at'      => !empty($data['remind_at']) ? $data['remind_at'] : null,
                'reminder_sent'  => (int) ($data['reminder_sent'] ?? 0),
                'sort_order'     => (int) ($data['sort_order'] ?? 0),
            ],
            ['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d']
        );

        return $inserted ? (int) $wpdb->insert_id : false;
    }

    /**
     * @param array<string, mixed> $data
     */
    public function update_note(int $note_id, int $user_id, array $data): bool {
        global $wpdb;

        $this->ensure_schema();
        $table = $this->table_name();

        $fields = [];
        $formats = [];

        $map = [
            'title'          => '%s',
            'body'           => '%s',
            'status'         => '%s',
            'due_at'         => '%s',
            'completed_at'   => '%s',
            'remind_at'      => '%s',
            'reminder_sent'  => '%d',
            'sort_order'     => '%d',
            'note_type'      => '%s',
        ];

        foreach ($map as $key => $format) {
            if (array_key_exists($key, $data)) {
                $fields[ $key ] = $data[ $key ];
                $formats[]      = $format;
            }
        }

        if (!$fields) {
            return false;
        }

        $updated = $wpdb->update(
            $table,
            $fields,
            [
                'id'      => $note_id,
                'user_id' => $user_id,
            ],
            $formats,
            ['%d', '%d']
        );

        return false !== $updated;
    }

    public function soft_delete(int $note_id, int $user_id): bool {
        return $this->update_note($note_id, $user_id, ['status' => 'deleted']);
    }

    /**
     * Notes due for notification delivery.
     *
     * @return array<int, array<string, mixed>>
     */
    public function get_due_reminders(string $now_mysql): array {
        global $wpdb;

        $this->ensure_schema();
        $table = $this->table_name();

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table}
                 WHERE note_type = %s
                   AND status = %s
                   AND remind_at IS NOT NULL
                   AND remind_at <= %s
                   AND reminder_sent = 0",
                'reminders',
                'active',
                $now_mysql
            ),
            ARRAY_A
        );

        return is_array($rows) ? $rows : [];
    }
}
