<?php
/**
 * Workspace Notes — bootstrap (data, reminders, AJAX).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/storage.php';
require_once __DIR__ . '/service.php';
require_once __DIR__ . '/reminders.php';
require_once __DIR__ . '/ajax.php';

add_action('init', 'yooadmin_workspace_notes_bootstrap', 20);

/**
 * Register storage table, cron, and AJAX.
 */
function yooadmin_workspace_notes_bootstrap(): void {
    if (!apply_filters('yooadmin_workspace_notes_enabled', true)) {
        return;
    }

    yooadmin_workspace_notes_storage()->maybe_create_tables();
    yooadmin_workspace_notes_reminders_init();
}
