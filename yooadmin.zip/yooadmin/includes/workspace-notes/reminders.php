<?php
/**
 * Workspace Notes — reminder cron → YOOAdmin notifications.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

const YOOADMIN_WS_NOTES_REMINDER_CRON_HOOK = 'yooadmin_workspace_notes_process_reminders';
const YOOADMIN_WS_NOTES_REMINDER_CRON_SCHEDULE = 'yooadmin_ws_notes_15min';

/**
 * Register 15-minute cron interval for workspace reminders.
 *
 * @param array<string, array{interval: int, display: string}> $schedules
 * @return array<string, array{interval: int, display: string}>
 */
function yooadmin_workspace_notes_cron_schedules(array $schedules): array {
    $schedules[ YOOADMIN_WS_NOTES_REMINDER_CRON_SCHEDULE ] = [
        'interval' => 15 * MINUTE_IN_SECONDS,
        'display'  => __('Every 15 minutes (Workspace Notes)', 'yooadmin'),
    ];

    return $schedules;
}

/**
 * Schedule reminder processing and admin fallback checks.
 */
function yooadmin_workspace_notes_reminders_init(): void {
    add_filter('cron_schedules', 'yooadmin_workspace_notes_cron_schedules', 6);
    add_action(YOOADMIN_WS_NOTES_REMINDER_CRON_HOOK, 'yooadmin_workspace_notes_process_due_reminders');
    add_action('admin_init', 'yooadmin_workspace_notes_maybe_process_reminders_on_admin', 50);

    yooadmin_workspace_notes_ensure_reminder_cron_scheduled();
}

/**
 * Ensure the reminder cron uses the 15-minute schedule.
 */
function yooadmin_workspace_notes_ensure_reminder_cron_scheduled(): void {
    $hook     = YOOADMIN_WS_NOTES_REMINDER_CRON_HOOK;
    $schedule = YOOADMIN_WS_NOTES_REMINDER_CRON_SCHEDULE;
    $next     = wp_next_scheduled($hook);

    if ($next && wp_get_schedule($hook) !== $schedule) {
        wp_unschedule_event($next, $hook);
        $next = false;
    }

    if (!$next) {
        wp_schedule_event(time() + 60, $schedule, $hook);
    }
}

/**
 * When an admin screen loads, process due reminders (throttled) so WP-Cron delays are less noticeable.
 */
function yooadmin_workspace_notes_maybe_process_reminders_on_admin(): void {
    if (!is_user_logged_in() || !is_admin()) {
        return;
    }

    if (!apply_filters('yooadmin_workspace_notes_enabled', true)) {
        return;
    }

    $throttle_key = 'yooadmin_ws_notes_reminder_admin_tick';
    if (get_transient($throttle_key)) {
        return;
    }

    set_transient($throttle_key, '1', 5 * MINUTE_IN_SECONDS);
    yooadmin_workspace_notes_process_due_reminders();
}

/**
 * Find due reminders and push into the notification bell.
 */
function yooadmin_workspace_notes_process_due_reminders(): void {
    if (!apply_filters('yooadmin_workspace_notes_enabled', true)) {
        return;
    }

    if (!function_exists('yooadmin_get_integration')) {
        return;
    }

    $integration = yooadmin_get_integration();
    if (!$integration || !method_exists($integration, 'create_notification')) {
        return;
    }

    $storage = yooadmin_workspace_notes_storage();
    $now     = current_time('mysql', true);
    $due     = $storage->get_due_reminders($now);

    if (!$due) {
        return;
    }

    $dashboard_url = admin_url('admin.php?page=yooadmin-dashboard');

    foreach ($due as $row) {
        $note_id = (int) ( $row['id'] ?? 0 );
        $user_id = (int) ( $row['user_id'] ?? 0 );

        if ($note_id <= 0 || $user_id <= 0) {
            continue;
        }

        $title   = (string) ( $row['title'] ?? '' );
        $body    = (string) ( $row['body'] ?? '' );
        $message = $body !== '' ? wp_strip_all_tags($body) : __('Workspace reminder', 'yooadmin');

        if (strlen($message) > 240) {
            $message = substr($message, 0, 237 ) . '…';
        }

        $integration->create_notification(
            $user_id,
            [
                'type'        => 'info',
                'title'       => $title !== '' ? $title : __('Reminder', 'yooadmin'),
                'message'     => $message,
                'priority'    => 'medium',
                'source'      => 'yooadmin',
                'source_type' => 'workspace_reminder',
                'url'         => $dashboard_url,
                'icon'        => 'dashicons-clock',
                'meta'        => [
                    'id'      => 'workspace_reminder_' . $note_id,
                    'note_id' => $note_id,
                ],
            ]
        );

        $storage->update_note(
            $note_id,
            $user_id,
            [
                'reminder_sent' => 1,
            ]
        );
    }
}

/**
 * Run reminder processing right after saving a reminder (covers past/near-now times).
 */
function yooadmin_workspace_notes_process_reminders_after_save(int $note_id, int $user_id): void {
    if ($note_id <= 0 || $user_id <= 0) {
        return;
    }

    $note = yooadmin_workspace_notes_storage()->get_note($note_id, $user_id);
    if (!$note || ( $note['note_type'] ?? '' ) !== 'reminders') {
        return;
    }

    yooadmin_workspace_notes_process_due_reminders();
}
