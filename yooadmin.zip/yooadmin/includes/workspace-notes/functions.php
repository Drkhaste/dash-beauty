<?php
/**
 * Workspace Notes — public helpers.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_workspace_notes_section_title')) {
    /**
     * Aside section heading for Workspace Notes (filterable per audience).
     */
    function yooadmin_workspace_notes_section_title(): string
    {
        return (string) apply_filters(
            'yooadmin_workspace_notes_section_title',
            __('Workspace Notes', 'yooadmin')
        );
    }
}

if (!function_exists('yooadmin_workspace_notes_types')) {
    /**
     * @return array<string, array{label: string, icon: string}>
     */
    function yooadmin_workspace_notes_types(): array {
        $types = [
            'todos' => [
                'label' => __('TODOs', 'yooadmin'),
                'icon'  => 'dashicons-yes-alt',
            ],
            'reminders' => [
                'label' => __('Reminders', 'yooadmin'),
                'icon'  => 'dashicons-clock',
            ],
            'client_notes' => [
                'label' => __('Client notes', 'yooadmin'),
                'icon'  => 'dashicons-groups',
            ],
            'deployment_notes' => [
                'label' => __('Deployment notes', 'yooadmin'),
                'icon'  => 'dashicons-cloud-upload',
            ],
        ];

        return apply_filters('yooadmin_workspace_notes_types', $types);
    }
}

if (!function_exists('yooadmin_workspace_notes_storage')) {
    function yooadmin_workspace_notes_storage(): YOOAdmin_Workspace_Notes_Storage {
        static $storage = null;
        if (null === $storage) {
            $storage = new YOOAdmin_Workspace_Notes_Storage();
        }
        return $storage;
    }
}

if (!function_exists('yooadmin_workspace_notes_service')) {
    function yooadmin_workspace_notes_service(): YOOAdmin_Workspace_Notes_Service {
        static $service = null;
        if (null === $service) {
            $service = new YOOAdmin_Workspace_Notes_Service();
        }
        return $service;
    }
}

if (!function_exists('yooadmin_workspace_notes_get_active_type')) {
    function yooadmin_workspace_notes_get_active_type(int $user_id = 0): string {
        return yooadmin_workspace_notes_service()->get_active_type($user_id);
    }
}

if (!function_exists('yooadmin_workspace_notes_resolve_scope_from_request')) {
    /**
     * site|network — network notes are stored separately (blog_id 0) from site notes.
     */
    function yooadmin_workspace_notes_resolve_scope_from_request(): string {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
        if (isset($_POST['notes_scope'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Scope flag only; auth verified in AJAX.
            $posted = sanitize_key(wp_unslash((string) $_POST['notes_scope']));
            if ($posted === 'network') {
                return 'network';
            }
        }

        if (
            function_exists('yooadmin_network_dashboard_is_screen')
            && yooadmin_network_dashboard_is_screen()
        ) {
            return 'network';
        }

        /**
         * @param string $scope site|network
         */
        $scope = apply_filters('yooadmin_workspace_notes_scope', 'site');

        return $scope === 'network' ? 'network' : 'site';
    }
}

if (!function_exists('yooadmin_workspace_notes_is_network_scope')) {
    function yooadmin_workspace_notes_is_network_scope(?string $scope = null): bool {
        $scope = $scope ?? yooadmin_workspace_notes_resolve_scope_from_request();

        return $scope === 'network';
    }
}

if (!function_exists('yooadmin_workspace_notes_storage_blog_id')) {
    function yooadmin_workspace_notes_storage_blog_id(?string $scope = null): int {
        if (yooadmin_workspace_notes_is_network_scope($scope)) {
            return 0;
        }

        return (int) get_current_blog_id();
    }
}

if (!function_exists('yooadmin_workspace_notes_active_type_meta_key')) {
    function yooadmin_workspace_notes_active_type_meta_key(?string $scope = null): string {
        if (yooadmin_workspace_notes_is_network_scope($scope)) {
            return 'yooadmin_workspace_notes_active_type_network';
        }

        return 'yooadmin_workspace_notes_active_type';
    }
}

if (!function_exists('yooadmin_workspace_notes_list')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_workspace_notes_list(int $user_id = 0, ?string $type = null): array {
        return yooadmin_workspace_notes_service()->list_notes($user_id, $type);
    }
}

if (!function_exists('yooadmin_workspace_notes_list_page')) {
    /**
     * Paginated workspace notes for list UI.
     *
     * @return array{notes: array<int, array<string, mixed>>, total: int, has_more: bool, offset: int, limit: int}
     */
    function yooadmin_workspace_notes_list_page(int $user_id = 0, ?string $type = null, int $offset = 0, int $limit = 3): array {
        return yooadmin_workspace_notes_service()->list_notes_page($user_id, $type, $offset, $limit);
    }
}

if (!function_exists('yooadmin_workspace_notes_page_size')) {
    function yooadmin_workspace_notes_page_size(): int {
        $size = (int) apply_filters('yooadmin_workspace_notes_page_size', 3);

        return max(1, min(50, $size));
    }
}

if (!function_exists('yooadmin_workspace_notes_timezone_label')) {
    /**
     * Human-readable site timezone for datetime fields (matches WordPress Settings → General).
     */
    function yooadmin_workspace_notes_timezone_label(): string {
        $tz_string = wp_timezone_string();
        $tz        = wp_timezone();
        $now       = new DateTime('now', $tz);
        $offset    = $tz->getOffset($now);
        $hours     = (int) floor($offset / 3600);
        $minutes   = (int) ( abs($offset) % 3600 / 60 );
        $sign      = $offset >= 0 ? '+' : '-';
        $gmt       = sprintf('UTC%s%d:%02d', $sign, abs($hours), $minutes);

        if ($tz_string && $tz_string !== $gmt && $tz_string !== 'UTC') {
            return $gmt . ' (' . $tz_string . ')';
        }

        return $gmt;
    }
}

if (!function_exists('yooadmin_workspace_notes_datetime_config')) {
    /**
     * Config for workspace datetime pickers (site timezone, not browser).
     *
     * @return array{timezone: string, timezoneLabel: string, timezoneOffsetMinutes: int, nowLocal: string}
     */
    function yooadmin_workspace_notes_datetime_config(): array {
        $tz  = wp_timezone();
        $now = new DateTime('now', $tz);

        return [
            'timezone'               => wp_timezone_string(),
            'timezoneLabel'          => yooadmin_workspace_notes_timezone_label(),
            'timezoneOffsetMinutes'  => (int) ( $tz->getOffset($now) / 60 ),
            'nowLocal'               => wp_date('Y-m-d\TH:i', $now->getTimestamp()),
        ];
    }
}
