<?php

defined('ABSPATH') || exit;

class YOOAdmin_Webhook_Receiver {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }
    
    public function register_routes() {
        register_rest_route('yooadmin/v1', '/webhook', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_webhook'],
            'permission_callback' => [$this, 'verify_webhook_signature'],
        ]);
    }
    
    public function verify_webhook_signature($request) {
        $sig = $request->get_header('X-YOOPixel-Signature');
        $event = $request->get_header('X-YOOPixel-Event');
        $ts = $request->get_header('X-YOOPixel-Timestamp');
        $wid = $request->get_header('X-YOOPixel-Webhook-ID');
        if (!empty($sig) && !empty($event) && !empty($ts) && !empty($wid)) {
            $license_manager = YOOAdmin_License_Manager::get_instance();
            $secret = $license_manager->get_webhook_secret();
            if (empty($secret)) {
                return false;
            }
            $body = $request->get_body();
            $payload = $body . $event . $ts . $wid;
            $expected = hash_hmac('sha256', $payload, $secret);
            return hash_equals($expected, $sig);
        }
        $auth_header = $request->get_header('Authorization');
        if (empty($auth_header) || !preg_match('/Bearer\s+(.+)$/i', $auth_header, $matches)) {
            return false;
        }
        $incoming_jwt = trim($matches[1]);
        if ($incoming_jwt === '') {
            return false;
        }
        $license_manager = YOOAdmin_License_Manager::get_instance();
        $license_data = $license_manager->get_license_data();
        $stored_jwt = isset($license_data['jwt_token']) ? (string) $license_data['jwt_token'] : '';
        if ($stored_jwt === '') {
            return false;
        }
        return hash_equals($stored_jwt, $incoming_jwt);
    }
    
    public function handle_webhook($request) {
        $event_type = $request->get_header('X-YOOPixel-Event');
        if (empty($event_type)) {
            $event_type = $request->get_param('event');
        }
        $data = $request->get_param('data');
        if (empty($data) && !empty($request->get_body())) {
            $data = $request->get_json_params();
            if (!is_array($data)) {
                $data = [];
            }
        }
        switch ($event_type) {
            case 'license.status_changed':
                $this->handle_license_status_changed($data);
                break;
                
            case 'license.suspended':
                $this->handle_license_suspended($data);
                break;
                
            case 'license.reactivated':
                $this->handle_license_reactivated($data);
                break;
            default:
                break;
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Webhook received and processed'
        ]);
    }
    
    private function handle_license_status_changed($data) {
        $new_status = $data['new_status'] ?? '';
        if ($new_status === '') {
            return;
        }
        $license_manager = YOOAdmin_License_Manager::get_instance();
        $license_manager->update_license_status_from_webhook($new_status);
        // Pull fresh payload immediately (license_type/status/domain) after webhook sync.
        if (method_exists($license_manager, 'check_license_status')) {
            $license_manager->check_license_status();
        }
    }
    
    private function handle_license_suspended($data) {
        $license_manager    = YOOAdmin_License_Manager::get_instance();
        $suspension_source  = $data['suspension_source'] ?? '';
        $status             = ( $suspension_source === 'admin' ) ? 'suspended' : 'expired';
        $license_manager->update_license_status_from_webhook( $status, [
            'suspension_source' => $suspension_source,
        ] );
    }
    
    private function handle_license_reactivated($data) {
        $new_status = $data['new_status'] ?? 'active';
        $license_manager = YOOAdmin_License_Manager::get_instance();
        $license_manager->update_license_status_from_webhook($new_status);
    }
}

YOOAdmin_Webhook_Receiver::get_instance();


