<?php
/**
 * YOOAdmin - Wizard dashboard widget
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Wizard Dashboard Widget Class
 */
class YOOAdmin_Wizard_Dashboard_Widget {
    
    /**
     * Initialize
     */
    public static function init() {
        // Only show if wizard not completed
        if (!get_option('yooadmin_wizard_completed')) {
            add_action('wp_dashboard_setup', [__CLASS__, 'add_dashboard_widget']);
        }
    }
    
    /**
     * Add dashboard widget
     */
    public static function add_dashboard_widget() {
        wp_add_dashboard_widget(
            'yooadmin_setup_wizard_widget',
            __('YOOAdmin Setup', 'yooadmin'),
            [__CLASS__, 'render_widget']
        );
    }
    
    /**
     * Render widget content
     */
    public static function render_widget() {
        ?>
        <div class="yooadmin-wizard-widget">
            <p>
                <strong><?php esc_html_e('Welcome to YOOAdmin!', 'yooadmin'); ?></strong>
            </p>
            <p>
                <?php esc_html_e('Complete the quick setup wizard to customize your dashboard and unlock all features.', 'yooadmin'); ?>
            </p>
            <p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=yooadmin-setup')); ?>" 
                   class="button button-primary button-large" 
                   style="width: 100%; text-align: center;">
                    <span class="dashicons dashicons-admin-generic" style="margin-top: 3px;"></span>
                    <?php esc_html_e('Start Setup Wizard', 'yooadmin'); ?>
                </a>
            </p>
            <p style="text-align: center; margin-top: 15px;">
                <a href="#" class="yooadmin-dismiss-wizard-widget" style="color: #999; font-size: 13px;">
                    <?php esc_html_e('Hide this widget', 'yooadmin'); ?>
                </a>
            </p>
        </div>
        <?php
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__) . '/yooadmin.php';
        $base_url = plugin_dir_url($base_file);
        $base_dir = plugin_dir_path($base_file);

        $css_path = 'assets/css/admin/wizard-dashboard-widget.css';
        if (file_exists($base_dir . $css_path)) {
            wp_enqueue_style('yooadmin-wizard-dashboard-widget', $base_url . $css_path, [], (string) filemtime($base_dir . $css_path));
        }

        $js_path = 'assets/js/admin/wizard-dashboard-widget.js';
        if (file_exists($base_dir . $js_path)) {
            wp_enqueue_script('yooadmin-wizard-dashboard-widget', $base_url . $js_path, ['jquery'], (string) filemtime($base_dir . $js_path), true);
            wp_localize_script('yooadmin-wizard-dashboard-widget', 'yooadmWizardWidget', [
                'nonce' => wp_create_nonce('yooadmin_wizard'),
            ]);
        }
        ?>
<?php
    }
}

// Initialize
YOOAdmin_Wizard_Dashboard_Widget::init();


