<?php
defined('ABSPATH') || exit;

/**
 * YOOAdmin Panel — Admin assets loader (CSS/JS)
 */

/* Admin favicon injector (admin + login) */
(function () {
    $yooadmin_base = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin-extended.php';
    $yooadmin_dir  = plugin_dir_path($yooadmin_base);
    if (file_exists($yooadmin_dir . 'includes/core/admin-favicon.php')) {
        require_once $yooadmin_dir . 'includes/core/admin-favicon.php';
    }
})();

/* ============================= Admin (Focus ON only) ============================= */

add_action('admin_enqueue_scripts', function () {
    if (!is_admin()) return;

    $focus_on = true;
    if (function_exists('yooadmin_is_focus_enabled')) {
        $focus_on = (bool) yooadmin_is_focus_enabled();
    } elseif (function_exists('yooadmin_focus_enabled_by_pref')) {
        $focus_on = (bool) yooadmin_focus_enabled_by_pref();
    }
    
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
    $current_page = isset($_GET['page']) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
    $is_dashboard = ($current_page === 'yooadmin-dashboard');

    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin-extended.php';
    $dir = plugin_dir_path($base_file);
    $url = plugin_dir_url($base_file);

    $add_style = function (string $handle, string $rel, array $deps = []) use ($dir, $url) {
        $path = $dir . $rel;
        if (file_exists($path)) {
            wp_enqueue_style($handle, $url . $rel, $deps, (string) filemtime($path));
        }
    };
    $add_script = function (string $handle, string $rel, array $deps = [], bool $in_footer = true) use ($dir, $url) {
        $path = $dir . $rel;
        if (file_exists($path)) {
            wp_enqueue_script($handle, $url . $rel, $deps, (string) filemtime($path), $in_footer);
        }
    };

    if ($focus_on) {
        // Extensions Store assets (only on our Extensions page)
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
        $current_page = isset($_GET['page']) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ($current_page === 'yooadmin-extensions') {
            $css = 'assets/css/admin/extensions-store.css';
            $css_header = 'assets/css/admin/extensions-store-header.css';
            $css_enhancements = 'assets/css/admin/extensions-store-enhancements.css';
            $css_variants = 'assets/css/admin/extensions-store-variants.css';
            $js  = 'assets/js/admin/extensions-store.js';
            if (file_exists($dir . $css)) wp_enqueue_style('yooadmin-addons-store', $url . $css, [], (string) filemtime($dir . $css));
            if (file_exists($dir . $css_header)) wp_enqueue_style('yooadmin-addons-store-header', $url . $css_header, [], (string) filemtime($dir . $css_header));
            if (file_exists($dir . $css_enhancements)) wp_enqueue_style('yooadmin-addons-store-enhancements', $url . $css_enhancements, ['yooadmin-addons-store'], (string) filemtime($dir . $css_enhancements));
            if (file_exists($dir . $css_variants)) wp_enqueue_style('yooadmin-addons-store-variants', $url . $css_variants, ['yooadmin-addons-store'], (string) filemtime($dir . $css_variants));
            if (file_exists($dir . $js))  {
                wp_enqueue_script('yooadmin-addons-store', $url . $js, ['jquery'], (string) filemtime($dir . $js), true);
                
                // Get license status
                $license_manager = class_exists('YOOAdmin_License_Manager') ? YOOAdmin_License_Manager::get_instance() : null;
                $license_data = $license_manager ? $license_manager->get_license_data() : [];
                $license_status = $license_data['status'] ?? 'inactive';
                
                $manifest_epoch = (int) get_option( 'yooadmin_store_manifest_epoch', 0 );

                $extensions_store_i18n = [
                    'activateTitle'   => __('Activate your license', 'yooadmin'),
                    'lead'            => __('To access extensions and features that use the Extension Store, activate your license.', 'yooadmin'),
                    'benefitFree'     => __('Free license: access free extensions from the store', 'yooadmin'),
                    'benefitNoCard'   => __('No credit card required for a free license', 'yooadmin'),
                    'benefitQuick'    => __('Complete activation from the license page in about a minute', 'yooadmin'),
                    'getFreeLicense'  => __('Get free license', 'yooadmin'),
                    'activateLicense' => __('Activate license', 'yooadmin'),
                    'privacy'         => __('Privacy Policy', 'yooadmin'),
                    'terms'           => __('Terms of Service', 'yooadmin'),
                ];

                wp_localize_script('yooadmin-addons-store', 'YOOADMIN_EXTENSIONS', [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce'   => function_exists('yooadmin_addons_nonce_value') ? yooadmin_addons_nonce_value() : wp_create_nonce('yooadmin_addons_nonce'),
                    'licenseStatus' => $license_status,
                    'manifestEpoch' => $manifest_epoch,
                    'i18n'          => $extensions_store_i18n,
                ]);
                // Keep old name for backward compatibility
                wp_localize_script('yooadmin-addons-store', 'YOO_ADDONS', [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce'   => function_exists('yooadmin_addons_nonce_value') ? yooadmin_addons_nonce_value() : wp_create_nonce('yooadmin_addons_nonce'),
                    'licenseStatus' => $license_status,
                    'manifestEpoch' => $manifest_epoch,
                    'i18n'          => $extensions_store_i18n,
                ]);
                // Add REST API support
                if (function_exists('wp_create_nonce')) {
                    wp_localize_script('yooadmin-addons-store', 'YOO_ADDONS_REST', [
                        'root'  => esc_url_raw(rest_url('yooadmin/v1/')),
                        'nonce' => wp_create_nonce('wp_rest'),
                    ]);
                }
            }
        }
        
        // YOOAdmin Popup System (universal for add-ons)
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
        $current_page = isset($_GET['page']) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if (in_array($current_page, ['yooadmin-settings', 'yooadmin-extensions'])) {
            $js = 'assets/js/admin/yooadmin-popup-system.js';
            if (file_exists($dir . $js)) {
                wp_enqueue_script('yooadmin-popup-system', $url . $js, ['jquery'], (string) filemtime($dir . $js), true);
            }
        }
        
        // Self-hosted Montserrat (used by yp-admin-core.css)
        $add_style('yooadmin-montserrat', 'assets/fonts/montserrat.css');

        // Optional Google Fonts (admin-only) from settings
        $opts = (array) get_option('yooadmin_options', []);
        $gf_on  = !empty($opts['google_fonts_enable']);
        $gf_url = isset($opts['google_fonts_url']) ? esc_url_raw($opts['google_fonts_url']) : '';
        $gf_family = isset($opts['google_fonts_family']) ? sanitize_text_field($opts['google_fonts_family']) : '';
        if ($gf_on && !empty($gf_url)) {
            wp_enqueue_style('yooadmin-google-fonts', $gf_url, [], YOOADMIN_VERSION);
            if ($gf_family !== '') {
                wp_add_inline_style('yooadmin-google-fonts', yooadmin_build_latin_font_variable_css());
            }
        }
        // SPA Guard - load on YOOAdmin pages and WooCommerce pages
        $is_wc_page = (strpos($current_page, 'wc-') === 0 || strpos($current_page, 'woocommerce') !== false);
        if (in_array($current_page, ['yooadmin-dashboard', 'yooadmin-settings', 'yooadmin-extensions']) || $is_wc_page) {
            $add_script('yooadmin-spa-guard', 'assets/js/admin/yoo-spa-guard.js', [], false);
        }
        
        // Update badge checker - only on pages that show badges
        if (in_array($current_page, ['yooadmin-dashboard', 'yooadmin-extensions', 'yooadmin-plugins', 'yooadmin-theme-manager', 'yooadmin-update-center'], true)) {
            $add_script('yooadmin-update-badge', 'assets/js/admin/update-badge.js', ['jquery'], true);
        }

        // About modal - always loaded on YOOAdmin pages
        $add_style('yooadmin-about-modal',  'assets/css/admin/about-modal.css');
        $add_script('yooadmin-about-modal', 'assets/js/admin/about-modal.js');

        // Core styles - always needed for YOOAdmin pages
        $add_style('yooadmin-shell', 'assets/css/admin/yooadmin-shell.css');
        $core_style_deps = ['yooadmin-montserrat'];
        if (yooadmin_should_enqueue_tajawal_font()) {
            $add_style('yooadmin-tajawal', 'assets/fonts/tajawal.css');
            $core_style_deps[] = 'yooadmin-tajawal';
        }
        $add_style('yooadmin-core', 'assets/css/admin/yp-admin-core.css', $core_style_deps);
        if (!($gf_on && !empty($gf_url) && $gf_family !== '')) {
            wp_add_inline_style('yooadmin-core', yooadmin_build_latin_font_variable_css());
        }
        $add_style('yooadmin-yoo-buttons', 'assets/css/admin/yp-yoo-buttons.css', ['yooadmin-core']);

        if (yooadmin_is_arabic_admin_ui()) {
            $add_style('yooadmin-rtl-tajawal', 'assets/css/admin/rtl-tajawal.css', ['yooadmin-tajawal', 'yooadmin-core']);
        }

        if (function_exists('yooadmin_enqueue_yp_admin_toast_assets')) {
            yooadmin_enqueue_yp_admin_toast_assets();
        } else {
            $add_style('yooadmin-yp-admin-toast', 'assets/css/admin/yp-admin-toast.css', ['yooadmin-core']);
            $add_script('yooadmin-yp-admin-toast', 'assets/js/admin/yp-admin-toast.js', ['jquery']);
        }

        if (function_exists('yooadmin_build_css_variables') && wp_style_is('yooadmin-core', 'enqueued')) {
            $vars = yooadmin_build_css_variables();
            if (is_array($vars) && !empty($vars['css'])) {
                wp_add_inline_style('yooadmin-core', (string) $vars['css']);
            }

            $brand_block = function_exists('yooadmin_get_brand_css_vars_block')
                ? yooadmin_get_brand_css_vars_block()
                : '';
            if ($brand_block !== '') {
                wp_add_inline_style('yooadmin-core', '#yps-sidebar{' . $brand_block . '}');
            }

            if (function_exists('yooadmin_get_brand_primary_600_hex')) {
                $hover_hex = yooadmin_get_brand_primary_600_hex();
                wp_add_inline_style(
                    'yooadmin-core',
                    '#yps-sidebar .yps-focus-label:hover .yps-focus-input:checked ~ .yps-focus-switch{background:' . esc_attr($hover_hex) . ' !important;}'
                );
            }
        }

        $network_shell = function_exists('yooadmin_network_admin_shell_active') && yooadmin_network_admin_shell_active();
        if ($network_shell) {
            $add_style('yooadmin-dashboard', 'assets/css/admin/yp-dashboard.css');
            $add_style('yooadmin-popup', 'assets/css/admin/yp-popup.css');
            $add_style('yooadmin-network-popup', 'assets/css/admin/network-popup.css', ['yooadmin-popup']);

            global $pagenow;
            $network_native_lists = [
                'sites.php',
                'site-new.php',
                'site-info.php',
                'site-settings.php',
                'site-users.php',
                'site-themes.php',
                'users.php',
                'user-new.php',
                'themes.php',
                'theme-install.php',
                'plugins.php',
                'plugin-install.php',
                'settings.php',
                'setup.php',
                'update-core.php',
                'update.php',
                'upgrade.php',
            ];
            if (isset($pagenow) && in_array($pagenow, $network_native_lists, true)) {
                $add_style('yooadmin-list-screens', 'assets/css/admin/list-screens.css');
            }
        }

        // Custom select (yp-ui-select) on Plugin Manager, Extensions Store, Extensions Manager, Theme Manager
        if (in_array($current_page, ['yooadmin-plugins', 'yooadmin-extensions', 'yooadmin-extensions-manager', 'yooadmin-theme-manager'], true)) {
            $yp_sel_css = $dir . 'assets/css/admin/yp-archive-delay-select.css';
            $yp_sel_js  = $dir . 'assets/js/admin/yp-archive-delay-select.js';
            if (file_exists($yp_sel_css)) {
                wp_enqueue_style(
                    'yooadmin-archive-delay-select',
                    $url . 'assets/css/admin/yp-archive-delay-select.css',
                    ['yooadmin-core'],
                    (string) filemtime($yp_sel_css)
                );
            }
            if (file_exists($yp_sel_js)) {
                wp_enqueue_script(
                    'yooadmin-archive-delay-select',
                    $url . 'assets/js/admin/yp-archive-delay-select.js',
                    [],
                    (string) filemtime($yp_sel_js),
                    true
                );
            }
        }

        // Conditional loading: Only load widgets CSS if needed
        if (in_array($current_page, ['yooadmin-dashboard', 'yooadmin-settings'])) {
            $add_style('yooadmin-widgets', 'assets/css/admin/yp-widgets.css');
        }
        
        // Popup CSS - load on all YOOAdmin shell pages that can show popup (including Speed Booster)
        $network_dashboard_slug = function_exists('yooadmin_network_dashboard_slug')
            ? yooadmin_network_dashboard_slug()
            : 'yooadmin-network-dashboard';
        $popup_css_pages = [
            'yooadmin-dashboard',
            $network_dashboard_slug,
            'yooadmin-extensions',
            'yooadmin-settings',
            'yooadmin-plugins',
            'yooadmin-theme-manager',
            'yooadmin-update-center',
            'yooadmin-speed-booster',
        ];
        if (in_array($current_page, $popup_css_pages, true)) {
            $add_style('yooadmin-popup', 'assets/css/admin/yp-popup.css');
        }
        $on_network_dashboard = function_exists('yooadmin_network_dashboard_is_screen')
            && yooadmin_network_dashboard_is_screen();
        if ($on_network_dashboard) {
            $add_style('yooadmin-network-popup', 'assets/css/admin/network-popup.css', ['yooadmin-popup']);
        }
        
        $add_style('yooadmin-focus', 'assets/css/admin/focus-mode.css');
        add_action('admin_enqueue_scripts', static function () use ($dir, $url): void {
            $path = $dir . 'assets/css/admin/wp-media-modal-dark.css';
            if (!is_readable($path)) {
                return;
            }
            $deps = wp_style_is('media-views', 'registered') ? ['media-views'] : [];
            wp_enqueue_style(
                'yooadmin-wp-media-modal-dark',
                $url . 'assets/css/admin/wp-media-modal-dark.css',
                $deps,
                (string) filemtime($path)
            );
        }, 100);
        $add_style('yooadmin-brand-dark', 'assets/css/admin/brand-dark-mode.css');
        
        // List screens CSS — YOOAdmin list UIs + native WordPress tables (edit.php, comments, tags…).
        $yooadmin_list_pages = ['yooadmin-posts', 'yooadmin-pages', 'yooadmin-comments', 'yooadmin-users', 'yooadmin-categories', 'yooadmin-tags'];
        $load_list_screens   = in_array($current_page, $yooadmin_list_pages, true);
        if (!$load_list_screens) {
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($screen && !empty($screen->base)) {
                $list_bases = ['edit', 'upload', 'edit-comments', 'edit-tags', 'users', 'plugins', 'themes'];
                foreach ($list_bases as $base) {
                    if (strpos((string) $screen->base, $base) !== false) {
                        $load_list_screens = true;
                        break;
                    }
                }
            }
        }
        if ($load_list_screens) {
            $add_style('yooadmin-list-screens', 'assets/css/admin/list-screens.css', ['yooadmin-core']);
            if (function_exists('yooadmin_enqueue_list_screen_ui_assets')) {
                yooadmin_enqueue_list_screen_ui_assets();
            }
        }
        
        if ($is_dashboard) {
            $add_style('yooadmin-dashboard', 'assets/css/admin/yp-dashboard.css');
            
            // Add background image URL as CSS variable
            $bg_url = $url . 'assets/images/bg.png';
            $inline_css = ":root { --yp-welcome-bg: url('" . esc_url($bg_url) . "'); }";
            wp_add_inline_style('yooadmin-dashboard', $inline_css);
        }

        // Load core essential script (always needed for YOOAdmin functionality)
        $add_script('yp-admin-core-essential', 'assets/js/admin/yp-admin-core-essential.js');

        // Notice intent (operational toast vs promotional banner) — before utilities & toast scripts.
        $add_script('yooadmin-notice-classifier', 'assets/js/admin/yp-notice-classifier.js', ['yp-admin-core-essential']);

        // Toast intercept for save/error notices (skips promos via classifier).
        $add_style('yooadmin-toast-notifications', 'assets/css/admin/toast-notifications.css');
        $add_script('yooadmin-toast-notifications', 'assets/js/admin/toast-notifications.js', ['jquery', 'yooadmin-notice-classifier'], true);
        if (wp_script_is('yooadmin-toast-notifications', 'enqueued')) {
            wp_localize_script(
                'yooadmin-toast-notifications',
                'yooadmToastI18n',
                [
                    'loginSuccess' => __('Welcome! You are logged in successfully.', 'yooadmin'),
                ]
            );
        }
        
        // Utilities - load on ALL admin pages when Focus Mode is ON
        // This ensures banner hiding works on all WordPress pages (themes.php, plugins.php, etc.)
        $utilities_deps = ['yp-admin-core-essential', 'yooadmin-notice-classifier'];
        if (wp_script_is('yooadmin-toast-notifications', 'registered') || wp_script_is('yooadmin-toast-notifications', 'enqueued')) {
            $utilities_deps[] = 'yooadmin-toast-notifications';
        }
        $add_script('yp-admin-utilities', 'assets/js/admin/yp-admin-utilities.js', $utilities_deps);
        if (wp_script_is('yp-admin-utilities', 'enqueued')) {
            wp_localize_script(
                'yp-admin-utilities',
                'yooadmUtilities',
                [
                    'settingsUrl' => esc_url_raw(rest_url('yooadmin/v1/settings')),
                ]
            );
        }

        // Keep 'yooadmin-admin-core' handle for backward compatibility (point to essential)
        wp_register_script('yooadmin-admin-core', '', ['yp-admin-core-essential'], '1.0.0', true);
        wp_enqueue_script('yooadmin-admin-core');
        
        // Conditional loading: Card icons fix - only on dashboard
        if ($is_dashboard) {
            $add_script('yooadmin-card-icons-fix', 'assets/js/admin/card-icons-fix.js', [], true);
        }
        
        // List screens filter - only on list pages
        if (in_array($current_page, ['yooadmin-posts', 'yooadmin-pages', 'yooadmin-users', 'yooadmin-categories'], true)) {
            $add_script('yooadmin-list-screens-filter', 'assets/js/admin/list-screens-filter.js', ['jquery'], true);
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
        if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'yooadmin-update-center') {
            $add_style('yooadmin-upload-page', 'assets/css/admin/upload-page.css');
            $add_style('yooadmin-update-center-page', 'assets/css/admin/update-center-page.css');
        }

        $network_uc_slug = function_exists('yooadmin_network_update_center_page_slug')
            ? yooadmin_network_update_center_page_slug()
            : 'yooadmin-network-update-center';
        if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === $network_uc_slug) {
            $add_style('yooadmin-upload-page', 'assets/css/admin/upload-page.css');
            $add_style('yooadmin-update-center-page', 'assets/css/admin/update-center-page.css');
        }

        $network_setup_slug = function_exists('yooadmin_network_setup_page_slug')
            ? yooadmin_network_setup_page_slug()
            : 'yooadmin-network-setup';
        $network_upgrade_slug = function_exists('yooadmin_network_upgrade_page_slug')
            ? yooadmin_network_upgrade_page_slug()
            : 'yooadmin-network-upgrade';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $network_classic_page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if (in_array($network_classic_page, [$network_setup_slug, $network_upgrade_slug], true)) {
            wp_enqueue_style('dashicons');
            $add_style('yooadmin-upload-page', 'assets/css/admin/upload-page.css');
            $add_style('yooadmin-settings', 'assets/css/admin/yp-settings.css');
            $add_style('yooadmin-network-settings-page', 'assets/css/admin/network-settings-page.css', ['yooadmin-settings']);
            $add_style('yooadmin-network-classic-page', 'assets/css/admin/network-classic-page.css', ['yooadmin-settings', 'yooadmin-upload-page']);
            $add_script('yooadmin-network-classic-page', 'assets/js/admin/network-classic-page.js', [], true);
            wp_localize_script(
                'yooadmin-network-classic-page',
                'yooadminNetworkClassicPage',
                [
                    'i18n' => [
                        'copied'    => __('Copied to clipboard.', 'yooadmin'),
                        'copyError' => __('Could not copy.', 'yooadmin'),
                    ],
                ]
            );
        }

        if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'yooadmin-network-settings') {
            $add_style('yooadmin-upload-page', 'assets/css/admin/upload-page.css');
            $add_style('yooadmin-settings', 'assets/css/admin/yp-settings.css');
            $add_style('yooadmin-network-settings-page', 'assets/css/admin/network-settings-page.css');
            $add_script('yooadmin-network-settings-page', 'assets/js/admin/network-settings-page.js', [], true);

            wp_localize_script(
                'yooadmin-network-settings-page',
                'yooadminNetworkSettings',
                [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'action'  => 'yooadmin_network_settings_save',
                    'i18n'    => [
                        'saved'         => __('Settings saved.', 'yooadmin'),
                        'defaultsSaved' => __('Network YOOAdmin defaults saved.', 'yooadmin'),
                        'saving'        => __('Saving…', 'yooadmin'),
                        'error'         => __('Settings could not be saved.', 'yooadmin'),
                        'generic'       => __('Something went wrong. Please try again.', 'yooadmin'),
                    ],
                ]
            );
        }

        $network_user_new_slug = function_exists('yooadmin_network_user_new_page_slug')
            ? yooadmin_network_user_new_page_slug()
            : 'yooadmin-network-user-new';
        $network_users_list_slug = function_exists('yooadmin_network_users_list_page_slug')
            ? yooadmin_network_users_list_page_slug()
            : 'yooadmin-network-users';
        $network_user_edit_slug  = function_exists('yooadmin_network_user_edit_page_slug')
            ? yooadmin_network_user_edit_page_slug()
            : 'yooadmin-network-user';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $network_users_page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if (in_array($network_users_page, [$network_user_new_slug, $network_users_list_slug, $network_user_edit_slug], true)) {
            $add_style('yooadmin-users-page', 'assets/css/admin/users-page.css');
        }
        if ($network_users_page === $network_users_list_slug) {
            $add_script('yooadmin-users-page', 'assets/js/admin/users-page.js', ['jquery'], true);
        }

        if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'yooadmin-network-sites') {
            wp_enqueue_style('dashicons');
            $add_style('yooadmin-upload-page', 'assets/css/admin/upload-page.css');
            $add_style('yooadmin-yoo-buttons', 'assets/css/admin/yp-yoo-buttons.css');
            $add_style('yooadmin-users-page', 'assets/css/admin/users-page.css');
            $add_style('yooadmin-network-dashboard', 'assets/css/admin/network-dashboard.css');
            $add_style('yooadmin-network-settings-page', 'assets/css/admin/network-settings-page.css');
            $add_style('yooadmin-network-sites-page', 'assets/css/admin/network-sites-page.css', ['yooadmin-network-dashboard', 'yooadmin-network-settings-page', 'yooadmin-users-page']);
            $yp_ui_css = $dir . 'assets/css/admin/yp-archive-delay-select.css';
            if (is_readable($yp_ui_css)) {
                wp_enqueue_style(
                    'yooadmin-yp-ui-select',
                    $url . 'assets/css/admin/yp-archive-delay-select.css',
                    ['yooadmin-upload-page'],
                    (string) filemtime($yp_ui_css)
                );
            }
            $yp_ui_js = $dir . 'assets/js/admin/yp-archive-delay-select.js';
            if (is_readable($yp_ui_js)) {
                wp_enqueue_script(
                    'yooadmin-yp-ui-select',
                    $url . 'assets/js/admin/yp-archive-delay-select.js',
                    [],
                    (string) filemtime($yp_ui_js),
                    true
                );
            }
            if (function_exists('yooadmin_network_sites_enqueue_confirm_assets')) {
                yooadmin_network_sites_enqueue_confirm_assets($add_script, $add_style);
            }
            $add_script('yooadmin-network-dashboard-sites', 'assets/js/admin/network-dashboard-sites.js', ['yp-admin-core-essential', 'yooadmin-confirm-dialog'], true);
            if (function_exists('yooadmin_network_sites_localize_confirm_script')) {
                yooadmin_network_sites_localize_confirm_script();
            }
            $sites_js_deps = ['jquery', 'yooadmin-network-dashboard-sites', 'yooadmin-confirm-dialog'];
            if (wp_script_is('yooadmin-yp-ui-select', 'registered')) {
                $sites_js_deps[] = 'yooadmin-yp-ui-select';
            }
            $add_script('yooadmin-network-sites-page', 'assets/js/admin/network-sites-page.js', $sites_js_deps, true);
        }

        $network_site_info_slug = function_exists('yooadmin_network_site_info_page_slug')
            ? yooadmin_network_site_info_page_slug()
            : 'yooadmin-network-site-info';
        $network_site_editor_pages = function_exists('yooadmin_network_site_editor_page_slugs')
            ? array_values(yooadmin_network_site_editor_page_slugs())
            : [$network_site_info_slug];
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current_editor_page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if (in_array($current_editor_page, $network_site_editor_pages, true)) {
            $add_style('yooadmin-upload-page', 'assets/css/admin/upload-page.css');
            $add_style('yooadmin-yoo-buttons', 'assets/css/admin/yp-yoo-buttons.css');
            $add_style('yooadmin-settings', 'assets/css/admin/yp-settings.css');
            $add_style('yooadmin-network-settings-page', 'assets/css/admin/network-settings-page.css');
            $add_style('yooadmin-network-site-info-page', 'assets/css/admin/network-site-info-page.css', ['yooadmin-network-settings-page']);
            if (function_exists('yooadmin_network_sites_enqueue_confirm_assets')) {
                yooadmin_network_sites_enqueue_confirm_assets($add_script, $add_style);
            }
            $add_script(
                'yooadmin-network-dashboard-sites',
                'assets/js/admin/network-dashboard-sites.js',
                ['yooadmin-confirm-dialog'],
                true
            );
            if (function_exists('yooadmin_network_sites_localize_confirm_script')) {
                yooadmin_network_sites_localize_confirm_script();
            }
            $add_script('yooadmin-network-site-info-page', 'assets/js/admin/network-site-info-page.js', ['yooadmin-network-dashboard-sites'], true);
            $add_style('yooadmin-archive-delay-select', 'assets/css/admin/yp-archive-delay-select.css', ['yooadmin-core']);
            $add_script('yooadmin-archive-delay-select', 'assets/js/admin/yp-archive-delay-select.js', [], true);

            if ($current_editor_page === (function_exists('yooadmin_network_site_users_page_slug') ? yooadmin_network_site_users_page_slug() : 'yooadmin-network-site-users')) {
                $add_style('yooadmin-users-page', 'assets/css/admin/users-page.css');
                $add_script('yooadmin-confirm-dialog', 'assets/js/admin/yoo-confirm-dialog.js', [], true);
                $add_script('yooadmin-network-site-users-page', 'assets/js/admin/network-site-users-page.js', ['jquery', 'yooadmin-archive-delay-select', 'yooadmin-confirm-dialog'], true);
                wp_localize_script(
                    'yooadmin-network-site-users-page',
                    'yooNetworkSiteUsers',
                    [
                        'ajaxUrl'          => admin_url('admin-ajax.php'),
                        'nonce'            => wp_create_nonce('yooadmin_network_site_users'),
                        'blogId'           => function_exists('yooadmin_network_site_editor_current_id') ? yooadmin_network_site_editor_current_id() : 0,
                        'pageSlug'         => function_exists('yooadmin_network_site_users_page_slug') ? yooadmin_network_site_users_page_slug() : 'yooadmin-network-site-users',
                        'selectedSingular' => __('selected', 'yooadmin'),
                        'selectedPlural'   => __('selected', 'yooadmin'),
                        'confirmTitle'     => __('Confirm action', 'yooadmin'),
                        'cancel'           => __('Cancel', 'yooadmin'),
                        'confirm'          => __('Confirm', 'yooadmin'),
                        'removeConfirm'    => __('Remove the selected users from this site?', 'yooadmin'),
                        'superAdminProtected' => __('Network super admins cannot be removed from a site.', 'yooadmin'),
                        'selectRole'       => __('Select a role.', 'yooadmin'),
                        'loadError'        => __('Error loading users. Please refresh the page.', 'yooadmin'),
                    ]
                );
            }
            if ($current_editor_page === (function_exists('yooadmin_network_site_themes_page_slug') ? yooadmin_network_site_themes_page_slug() : 'yooadmin-network-site-themes')) {
                $add_style('yooadmin-upload-page', 'assets/css/admin/upload-page.css');
                $add_script('yooadmin-network-site-themes-page', 'assets/js/admin/network-site-themes-page.js', ['jquery'], true);
                wp_localize_script(
                    'yooadmin-network-site-themes-page',
                    'yooNetworkSiteThemes',
                    [
                        'selectedSingular' => __('selected', 'yooadmin'),
                        'selectedPlural'   => __('selected', 'yooadmin'),
                    ]
                );
            }
        }

        $network_add_site_slug = function_exists('yooadmin_network_site_new_page_slug')
            ? yooadmin_network_site_new_page_slug()
            : 'yooadmin-network-add-site';
        if (isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === $network_add_site_slug) {
            $add_style('yooadmin-upload-page', 'assets/css/admin/upload-page.css');
            $add_style('yooadmin-yoo-buttons', 'assets/css/admin/yp-yoo-buttons.css');
            $add_style('yooadmin-settings', 'assets/css/admin/yp-settings.css');
            $add_style('yooadmin-network-settings-page', 'assets/css/admin/network-settings-page.css');
            $add_style('yooadmin-network-site-new-page', 'assets/css/admin/network-site-new-page.css', ['yooadmin-network-settings-page', 'yooadmin-settings']);
            $add_script('yooadmin-network-site-new-page', 'assets/js/admin/network-site-new-page.js', [], true);
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        
        /* ---------- Runtime flags for core JS ---------- */
        $slug = function_exists('yooadmin_dashboard_slug') ? yooadmin_dashboard_slug() : 'yooadmin-dashboard';
        // Reuse $opts gathered above
        $redirect = !empty($opts['redirect_dashboard']);
        if ($network_shell) {
            if (function_exists('yooadmin_network_dashboard_slug')) {
                $slug = yooadmin_network_dashboard_slug();
            }
            if (function_exists('yooadmin_network_dashboard_redirect_enabled')) {
                $redirect = yooadmin_network_dashboard_redirect_enabled();
            }
        }

        $notifications_rest = '';
        $notifications_nonce = '';
        $notifications_sw = '';
        $notifications_poll = apply_filters('yooadmin_notifications_poll_interval', 60000);

        if (function_exists('rest_url')) {
            $notifications_rest = esc_url_raw(
                add_query_arg(
                    [
                        'summary_only'  => '0',
                        'include_items' => '1',
                    ],
                    rest_url('yooadmin/v1/notifications')
                )
            );
        }

        if (function_exists('wp_create_nonce')) {
            $notifications_nonce = wp_create_nonce('wp_rest');
        }

        $notifications_sw = esc_url_raw(admin_url('admin-ajax.php?action=yooadmin_notifications_sw'));

        $admin_path_for_scope = wp_parse_url(admin_url(), PHP_URL_PATH);
        $notifications_scope  = (is_string($admin_path_for_scope) && $admin_path_for_scope !== '')
            ? trailingslashit($admin_path_for_scope)
            : '/';

        // Get convert banners setting
        $opts = yooadmin_get_options();
        $panel_opts = (array) get_option('yooadmin_panel_options', []);
        if (!empty($panel_opts)) {
            $opts = array_merge($opts, $panel_opts);
        }
        
        // Match settings/header: option only (no license gate).
        $convert_banners = isset($opts['convert_banners_to_notifications'])
            ? !empty($opts['convert_banners_to_notifications'])
            : false;
        
        $excluded_submenu_pages = ['elementor-system'];
        if (function_exists('yooadmin_get_excluded_submenu_pages')) {
            $excluded_submenu_pages = yooadmin_get_excluded_submenu_pages();
        }

        wp_localize_script('yp-admin-core-essential', 'yooadmRuntime', [
            'redirectDashboard' => (bool) $redirect,
            'dashboardSlug'     => (string) $slug,
            'excludedSubmenuPages' => is_array($excluded_submenu_pages) ? array_values($excluded_submenu_pages) : ['elementor-system'],
            'notifications'     => [
                'channel'      => 'yp-notifications',
                'restEndpoint' => $notifications_rest,
                'bannerSaveUrl' => esc_url_raw(rest_url('yooadmin/v1/notifications/banner')),
                'restNonce'    => $notifications_nonce,
                'pollInterval' => (int) $notifications_poll,
                'swUrl'        => $notifications_sw,
                'scope'        => $notifications_scope,
                'ajaxUrl'      => admin_url('admin-ajax.php'),
                'ajaxAction'   => 'yooadmin_check_notifications',
                'nonce'        => wp_create_nonce('yooadmin_notifications_nonce'),
            ],
            'convertBannersToNotifications' => (bool) $convert_banners,
            'settingsUrl'       => function_exists('yooadmin_settings_admin_url')
                ? yooadmin_settings_admin_url('tab-notifications')
                : admin_url('admin.php?page=yooadmin-settings#tab-notifications'),
        ]);

        if (function_exists('yooadmin_build_admin_menu_tree') || function_exists('yooadmin_build_network_admin_menu_tree')) {
            $skip_core_card_menus = function_exists('yooadmin_network_dashboard_is_screen')
                && yooadmin_network_dashboard_is_screen();
            if (!$skip_core_card_menus) {
                $card_menu_items = [];
                if (is_multisite() && is_network_admin() && function_exists('yooadmin_network_dashboard_resolve_menu_tree')) {
                    $force_refresh = function_exists('yooadmin_network_dashboard_is_screen') && yooadmin_network_dashboard_is_screen();
                    $card_menu_items = yooadmin_network_dashboard_resolve_menu_tree($force_refresh);
                } elseif (is_multisite() && is_network_admin() && function_exists('yooadmin_build_network_admin_menu_tree')) {
                    $card_menu_items = yooadmin_build_network_admin_menu_tree();
                } elseif (function_exists('yooadmin_build_admin_menu_tree')) {
                    $card_menu_items = yooadmin_build_admin_menu_tree();
                }

                wp_localize_script('yp-admin-core-essential', 'yooadmCardMenus', [
                    'items' => $card_menu_items,
                    'nonce' => wp_create_nonce('yooadmin_popup_nonce'),
                ]);
            }
        }
        /* ------------------------------------------------ */

        $add_style('yooadmin-focus-alerts', 'assets/css/admin/focus-mode-alerts.css');
        $add_script('yooadmin-focus-alerts', 'assets/js/admin/focus-mode-alerts.js', ['yp-admin-core-essential']);
        
        $add_script('yooadmin-focus-toggle', 'assets/js/admin/yoo-focus-toggle.js', ['yp-admin-core-essential', 'yooadmin-focus-alerts']);
        if (wp_script_is('yooadmin-focus-toggle', 'enqueued')) {
            $focus_policy = function_exists('yooadmin_get_focus_policy') ? yooadmin_get_focus_policy() : 'auto';
            $focus_active = function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();
            wp_localize_script('yooadmin-focus-toggle', 'yooadmFocus', [
                'is_active'        => $focus_active,
                'policy'           => $focus_policy,
                'canManagePolicy'  => function_exists('yooadmin_user_can_manage_focus_policy')
                    && yooadmin_user_can_manage_focus_policy(),
                'saveNonce'        => wp_create_nonce('yooadmin_focus_mode'),
                'ajaxUrl'          => admin_url('admin-ajax.php'),
                'toggle_on_url'    => esc_url(add_query_arg('yoo', 'on')),
                'toggle_off_url'   => esc_url(add_query_arg('yoo', 'off')),
                'enable_focus_url' => function_exists('yooadmin_enable_focus_url')
                    ? esc_url(yooadmin_enable_focus_url(['yoo' => 'off']))
                    : esc_url(admin_url('admin.php?page=yooadmin-enable-focus&yoo=off')),
                'focus_home_url'   => function_exists('yooadmin_focus_home_url')
                    ? esc_url(yooadmin_focus_home_url())
                    : esc_url(admin_url('admin.php?page=yooadmin-dashboard&yoo=on')),
            ]);

            if ($focus_active) {
                wp_add_inline_script(
                    'yooadmin-focus-toggle',
                    "try{sessionStorage.removeItem('yooadminFocusTransition');}catch(e){}",
                    'before'
                );
            }
        }
        
        // Banner tooltip - helps users discover the banner conversion feature
        $add_style('yooadmin-banner-tooltip', 'assets/css/admin/yp-banner-tooltip.css');
        $add_script('yooadmin-banner-tooltip', 'assets/js/admin/yp-banner-tooltip.js', ['yp-admin-core-essential', 'jquery']);
        if (wp_script_is('yooadmin-banner-tooltip', 'enqueued')) {
            wp_localize_script('yooadmin-banner-tooltip', 'yooadmBannerTooltip', [
                'tip'              => __('Tip: Convert all banners to notifications!', 'yooadmin'),
                'enableInSettings' => __('Enable in Settings', 'yooadmin'),
            ]);
        }

        $add_script('yooadmin-header-sync', 'assets/js/admin/yp-header-sync.js', ['yp-admin-core-essential']);
        
        // Always load popup and menus (they're needed for dashboard functionality)
        // Load YPIconAI before popup (popup uses it for icon prediction)
        $add_script('yooadmin-icon-ai',     'assets/js/admin/yp-icon-ai.js',     ['yp-admin-core-essential']);
        $add_script('yooadmin-popup',       'assets/js/admin/yp-popup.js',       ['yp-admin-core-essential', 'jquery', 'yooadmin-icon-ai']);
        if ($network_shell) {
            $add_script('yooadmin-network-popup', 'assets/js/admin/network-popup.js', ['yooadmin-popup']);
        }
        $add_script('yooadmin-menus',       'assets/js/admin/yp-menus.js',       ['yp-admin-core-essential', 'jquery']);
        $add_script('yooadmin-card-icons',  'assets/js/admin/yp-card-icons.js',  ['yp-admin-core-essential']);
        
        /* ---------- Enqueue YOOPanel assets (page-specific) ---------- */
        // Also load on dashboard for Quick Actions
        if ($is_dashboard) {
            // CSS
            $rel_css = 'assets/css/admin/yp-panel.css'; 
            $abs_css = $dir . $rel_css;
            if (file_exists($abs_css)) {
                // load after core/widgets so our panel styles win
                $deps = [];
                if (wp_style_is('yooadmin-core', 'registered') || wp_style_is('yooadmin-core', 'enqueued'))     $deps[] = 'yooadmin-core';
                if (wp_style_is('yooadmin-widgets', 'registered') || wp_style_is('yooadmin-widgets', 'enqueued')) $deps[] = 'yooadmin-widgets';
                wp_enqueue_style('yp-panel-css', $url . $rel_css, $deps, (string) filemtime($abs_css));
            }
        
            // Runtime data (keep as you had it)
            $runtime = [
                'plan'             => !empty($opts['plan']) ? (string) $opts['plan'] : 'free',
                'plan_label'       => !empty($opts['plan_label']) ? (string) $opts['plan_label'] : '',
                'domain_name'      => !empty($opts['domain_name']) ? (string) $opts['domain_name'] : '',
                'license_expires'  => !empty($opts['license_expires']) ? (string) $opts['license_expires'] : '',
                'theme_name'       => !empty($opts['theme_name']) ? (string) $opts['theme_name'] : '',
                'addons_enabled'   => isset($opts['addons_enabled']) ? (int) $opts['addons_enabled'] : 0,
                'addons_available' => isset($opts['addons_available']) ? (int) $opts['addons_available'] : 0,
            ];
        
            // JS
            $rel_js = 'assets/js/admin/yp-panel-index.js';
            $abs_js = $dir . $rel_js;
            if (file_exists($abs_js)) {
                wp_enqueue_script('yp-panel-index', $url . $rel_js, ['jquery'], (string) filemtime($abs_js), true);
                wp_localize_script('yp-panel-index', 'yooadmPanelRuntime', $runtime);

                wp_localize_script('yp-panel-index', 'yooadmPanelQa', [
                    'ajaxUrl'  => admin_url('admin-ajax.php'),
                    'nonce'    => wp_create_nonce('yooadmin_quick_actions'),
                    'maxItems' => 24,
                    'itemsPerPage' => 6,
                    'icons'    => [
                        'dashicons-admin-site', 'dashicons-admin-home', 'dashicons-admin-generic', 'dashicons-admin-settings', 'dashicons-admin-tools',
                        'dashicons-admin-appearance', 'dashicons-admin-customizer', 'dashicons-admin-plugins', 'dashicons-admin-users', 'dashicons-admin-media',
                        'dashicons-admin-page', 'dashicons-admin-post', 'dashicons-admin-comments', 'dashicons-admin-links', 'dashicons-admin-network',
                        'dashicons-admin-multisite', 'dashicons-admin-site-alt2', 'dashicons-admin-site-alt3', 'dashicons-dashboard', 'dashicons-update',
                        'dashicons-clock', 'dashicons-performance', 'dashicons-chart-pie', 'dashicons-chart-area', 'dashicons-chart-bar', 'dashicons-chart-line',
                        'dashicons-chart-pie-alt', 'dashicons-megaphone', 'dashicons-clipboard', 'dashicons-edit', 'dashicons-edit-large', 'dashicons-search',
                        'dashicons-filter', 'dashicons-category', 'dashicons-tag', 'dashicons-portfolio', 'dashicons-layout', 'dashicons-align-left',
                        'dashicons-align-center', 'dashicons-align-right', 'dashicons-align-none', 'dashicons-randomize', 'dashicons-media-document',
                        'dashicons-media-spreadsheet', 'dashicons-media-interactive', 'dashicons-media-code', 'dashicons-format-image', 'dashicons-format-audio',
                        'dashicons-format-video', 'dashicons-format-gallery', 'dashicons-format-status', 'dashicons-format-aside', 'dashicons-images-alt',
                        'dashicons-images-alt2', 'dashicons-image-filter', 'dashicons-visibility', 'dashicons-hidden', 'dashicons-lock', 'dashicons-unlock',
                        'dashicons-shield', 'dashicons-superhero', 'dashicons-vault', 'dashicons-email', 'dashicons-email-alt', 'dashicons-email-alt2',
                        'dashicons-share', 'dashicons-share-alt', 'dashicons-share-alt2', 'dashicons-rss', 'dashicons-facebook', 'dashicons-facebook-alt',
                        'dashicons-twitter', 'dashicons-googleplus', 'dashicons-linkedin', 'dashicons-phone', 'dashicons-smartphone', 'dashicons-tablet',
                        'dashicons-desktop', 'dashicons-location', 'dashicons-location-alt', 'dashicons-time', 'dashicons-calendar', 'dashicons-calendar-alt',
                        'dashicons-groups', 'dashicons-businessman', 'dashicons-id', 'dashicons-buddicons-buddypress-logo', 'dashicons-buddicons-groups',
                        'dashicons-buddicons-friends', 'dashicons-buddicons-activity', 'dashicons-money', 'dashicons-tickets-alt', 'dashicons-cart',
                        'dashicons-products', 'dashicons-store', 'dashicons-bank', 'dashicons-calculator', 'dashicons-cloud', 'dashicons-cloud-saved',
                        'dashicons-backup', 'dashicons-download', 'dashicons-upload', 'dashicons-awards', 'dashicons-star-filled', 'dashicons-heart',
                        'dashicons-smiley', 'dashicons-lightbulb', 'dashicons-yes', 'dashicons-yes-alt', 'dashicons-info', 'dashicons-info-outline',
                        'dashicons-warning', 'dashicons-sos', 'dashicons-flag', 'dashicons-rest-api', 'dashicons-text', 'dashicons-translation',
                        'dashicons-paperclip', 'dashicons-screenoptions'
                    ],
                    'strings'  => [
                        'addTitle'      => __('Add Quick Action', 'yooadmin'),
                        'editTitle'     => __('Edit Quick Action', 'yooadmin'),
                        'label'         => __('Label', 'yooadmin'),
                        'url'           => __('URL', 'yooadmin'),
                        'target'        => __('Target', 'yooadmin'),
                        'targetBlank'   => __('Open in new tab', 'yooadmin'),
                        'targetSelf'    => __('Open in same tab', 'yooadmin'),
                        'icon'          => __('Icon', 'yooadmin'),
                        'save'          => __('Save', 'yooadmin'),
                        'cancel'        => __('Cancel', 'yooadmin'),
                        'deleteModalTitle' => __('Delete quick action?', 'yooadmin'),
                        'deleteConfirm' => __('Are you sure you want to delete this quick action?', 'yooadmin'),
                        'deleteButton'  => __('Delete', 'yooadmin'),
                        'error'         => __('Something went wrong, please try again.', 'yooadmin'),
                        'maxReached'    => __('Maximum items reached', 'yooadmin'),
                        'validation'    => __('Please provide both label and URL.', 'yooadmin'),
                        'editAction'    => __('Edit quick action', 'yooadmin'),
                        'deleteAction'  => __('Delete quick action', 'yooadmin')
                    ]
                ]);

                // Welcome card editor config (for customizing welcome text)
                wp_localize_script('yp-panel-index', 'yooadmPanelWelcome', [
                    'ajaxUrl'     => admin_url('admin-ajax.php'),
                    'nonce'       => wp_create_nonce('yooadmin_welcome'),
                    'title'       => __('Title', 'yooadmin'),
                    'paragraph1'  => __('Paragraph 1', 'yooadmin'),
                    'paragraph2'  => __('Paragraph 2', 'yooadmin'),
                    'reset'       => __('Reset', 'yooadmin'),
                    'cancel'      => __('Cancel', 'yooadmin'),
                    'save'        => __('Save', 'yooadmin'),
                    'customizeText' => __('Customize text', 'yooadmin'),
                    'resetting'   => __('Resetting…', 'yooadmin'),
                ]);

                if (wp_script_is('yooadmin-card-icons', 'enqueued') || wp_script_is('yooadmin-card-icons', 'registered')) {
                    wp_localize_script('yooadmin-card-icons', 'yooadmCardIconsI18n', [
                        'chooseIcon'  => __('Choose icon', 'yooadmin'),
                        'searchIcons' => __('Search icons…', 'yooadmin'),
                        'reset'       => __('Reset', 'yooadmin'),
                        'noMatch'     => __('No icons match your search', 'yooadmin'),
                        'closePicker' => __('Close icon picker', 'yooadmin'),
                    ]);
                }
            }
        }
        /* ------------------------------------------------------------- */

        return;
    }

    // Focus OFF: keep native WP layout (no layout CSS from YOOAdmin).
}, 1);

/* ============================= WooCommerce fixes (Focus ON only) ============================= */

add_action('admin_enqueue_scripts', function () {
    if (!is_admin()) return;

    $focus_on = true;
    if (function_exists('yooadmin_is_focus_enabled')) {
        $focus_on = (bool) yooadmin_is_focus_enabled();
    } elseif (function_exists('yooadmin_focus_enabled_by_pref')) {
        $focus_on = (bool) yooadmin_focus_enabled_by_pref();
    }
    if (!$focus_on) return;

    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin-extended.php';
    $dir = plugin_dir_path($base_file);
    $url = plugin_dir_url($base_file);

    $is_woo = false;
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only check
    if (isset($_GET['page']) && strpos(sanitize_text_field(wp_unslash($_GET['page'])), 'wc-admin') !== false) $is_woo = true;

    if (function_exists('get_current_screen')) {
        try {
            $s = get_current_screen();
            if ($s) {
                $id = (string) $s->id;
                $pt = isset($s->post_type) ? (string) $s->post_type : '';
                if (strpos($id, 'wc-admin') !== false || strpos($id, 'woocommerce') !== false) $is_woo = true;
                if (in_array($pt, ['product','shop_order','shop_coupon','shop_subscription','shop_order_refund'], true)) $is_woo = true;
            }
        } catch (Throwable $e) {}
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only check, no state change.
    $is_heavy_spa = (
        isset($_GET['page'], $_GET['path']) &&
        sanitize_text_field(wp_unslash($_GET['page'])) === 'wc-admin' &&
        (
            strpos(urldecode(sanitize_text_field(wp_unslash($_GET['path']))), '/customize-store') === 0 ||
            strpos(urldecode(sanitize_text_field(wp_unslash($_GET['path']))), '/launch-your-store') === 0 ||
            strpos(urldecode(sanitize_text_field(wp_unslash($_GET['path']))), '/setup-wizard') === 0
        )
    );
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    /* Active theme with Woo compat ships its own rules — skip core full-bleed woocommerce-fix.css. */
    if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
        $theme_manager = YOOAdmin_Admin_Theme_Manager::get_instance();
        if ($theme_manager->theme_has_feature('woocommerce_compat')) {
            return;
        }
    }

    if ($is_woo && !$is_heavy_spa) {
        $rel = 'assets/css/admin/woocommerce-fix.css';
        $abs = $dir . $rel;
        if (file_exists($abs)) {
            wp_enqueue_style('yooadmin-woocommerce-fix', $url . $rel, [], (string) filemtime($abs));
        }
    }
}, 11);

$yooadmin_localize_focus_alerts = function () {
    if (wp_script_is('yooadmin-focus-alerts', 'enqueued')) {
        wp_localize_script('yooadmin-focus-alerts', 'yooadmFocusAlerts', [
            'focusModeDisabled'       => __('Focus Mode Disabled', 'yooadmin'),
            'focusDisabledMessage'    => __('Focus Mode is disabled by the administrator. To enable it for yourself only, the policy must be set to "Auto" to allow users to choose their preference.', 'yooadmin'),
            'focusDisabledMessageUser' => __('Focus Mode is turned off for all users by your site administrator. You cannot enable it yourself. Please contact your administrator if you need access.', 'yooadmin'),
            'cancel'                  => __('Cancel', 'yooadmin'),
            'enableAutoMode'          => __('Enable Auto Mode', 'yooadmin'),
            'focusModePolicy'         => __('Focus Mode Policy', 'yooadmin'),
            'focusModePolicyUser'     => __('Focus Mode Is Locked', 'yooadmin'),
            'policyOnMessage'         => __('Focus Mode policy is currently set to <strong>"Force On"</strong>. To allow users to control Focus Mode, change the policy to <strong>"Auto"</strong> in settings.', 'yooadmin'),
            'policyOnMessageUser'     => __('Your site administrator requires Focus Mode for all users. You cannot turn it off while this policy is active. Please contact your administrator if you need the classic WordPress admin.', 'yooadmin'),
            'policyOffMessage'        => __('Focus Mode policy is currently set to <strong>"Force Off"</strong>. To enable Focus Mode, change the policy to <strong>"Auto"</strong> in settings.', 'yooadmin'),
            'policyOffMessageUser'    => __('Focus Mode is turned off for all users by your site administrator. You cannot enable it yourself. Please contact your administrator if you need access.', 'yooadmin'),
            'close'                   => __('Close', 'yooadmin'),
            'focusModeSettings'       => __('Focus Mode Settings', 'yooadmin'),
            'canManagePolicy'         => function_exists('yooadmin_user_can_manage_focus_policy')
                && yooadmin_user_can_manage_focus_policy(),
        ]);
    }
};
add_action('admin_enqueue_scripts', $yooadmin_localize_focus_alerts, 20);
add_action('wp_enqueue_scripts', $yooadmin_localize_focus_alerts, 20);

/**
 * Arabic (RTL): load Tajawal overrides after per-page CSS so they win the cascade.
 */
add_action('admin_enqueue_scripts', function () {
    if (!yooadmin_is_arabic_admin_ui()) {
        return;
    }
    if (!wp_style_is('yooadmin-rtl-tajawal', 'registered')) {
        return;
    }

    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $url = plugin_dir_url($base_file);
    $path = plugin_dir_path($base_file) . 'assets/css/admin/rtl-tajawal.css';
    if (!file_exists($path)) {
        return;
    }

    wp_dequeue_style('yooadmin-rtl-tajawal');
    wp_deregister_style('yooadmin-rtl-tajawal');
    wp_enqueue_style(
        'yooadmin-rtl-tajawal',
        $url . 'assets/css/admin/rtl-tajawal.css',
        wp_style_is('yooadmin-tajawal', 'registered') ? ['yooadmin-tajawal'] : [],
        (string) filemtime($path)
    );
}, 999);

/* ============================= Login screen (independent branding) ============================= */
// NOTE: Login customization has been moved to YOOAdmin Login Customizer extension
// This section is kept for backward compatibility but will be removed in future versions
