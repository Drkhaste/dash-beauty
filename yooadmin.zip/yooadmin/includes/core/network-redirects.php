<?php
/**
 * YOOAdmin — Network Admin redirects and menu rewrites (multisite only).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!is_multisite()) {
    return;
}

if (!function_exists('yooadmin_network_redirects_text_domain')) {
    function yooadmin_network_redirects_text_domain(): string
    {
        return function_exists('yooadmin_multisite_text_domain')
            ? yooadmin_multisite_text_domain()
            : 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_site_editor_classic_url')) {
    function yooadmin_network_site_editor_classic_url(string $script): string
    {
        $blog_id = function_exists('yooadmin_network_site_editor_current_id')
            ? yooadmin_network_site_editor_current_id()
            : (isset($_GET['id']) ? absint(wp_unslash((string) $_GET['id'])) : 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        if ($blog_id <= 0) {
            return network_admin_url('sites.php');
        }

        return network_admin_url($script . '?id=' . $blog_id);
    }
}

if (!function_exists('yooadmin_network_yoo_page_classic_url')) {
    /**
     * Map the current YOOAdmin network admin.php?page=… request to the core WordPress screen.
     *
     * @return string Empty string when no redirect is needed.
     */
    function yooadmin_network_yoo_page_classic_url(): string
    {
        if (!is_multisite() || !is_network_admin()) {
            return '';
        }

        if (
            function_exists('yooadmin_network_dashboard_is_screen')
            && yooadmin_network_dashboard_is_screen()
            && function_exists('yooadmin_network_dashboard_should_use')
            && !yooadmin_network_dashboard_should_use()
        ) {
            return network_admin_url('index.php');
        }

        if (
            function_exists('yooadmin_network_sites_is_screen')
            && yooadmin_network_sites_is_screen()
            && function_exists('yooadmin_network_sites_should_use')
            && !yooadmin_network_sites_should_use()
        ) {
            return network_admin_url('sites.php');
        }

        if (
            function_exists('yooadmin_network_site_new_is_screen')
            && yooadmin_network_site_new_is_screen()
            && function_exists('yooadmin_network_site_new_should_use')
            && !yooadmin_network_site_new_should_use()
        ) {
            return network_admin_url('site-new.php');
        }

        if (
            function_exists('yooadmin_network_settings_is_screen')
            && yooadmin_network_settings_is_screen()
            && function_exists('yooadmin_network_settings_should_use')
            && !yooadmin_network_settings_should_use()
        ) {
            return network_admin_url('settings.php');
        }

        if (
            function_exists('yooadmin_network_users_list_is_screen')
            && yooadmin_network_users_list_is_screen()
            && function_exists('yooadmin_network_users_should_use')
            && !yooadmin_network_users_should_use()
        ) {
            return network_admin_url('users.php');
        }

        if (
            function_exists('yooadmin_network_user_new_is_screen')
            && yooadmin_network_user_new_is_screen()
            && function_exists('yooadmin_network_user_new_should_use')
            && !yooadmin_network_user_new_should_use()
        ) {
            return network_admin_url('user-new.php');
        }

        if (
            function_exists('yooadmin_network_user_edit_is_screen')
            && yooadmin_network_user_edit_is_screen()
            && function_exists('yooadmin_network_users_should_use')
            && !yooadmin_network_users_should_use()
        ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect target.
            $user_id = isset($_GET['user_id']) ? absint($_GET['user_id']) : 0;

            return $user_id > 0
                ? network_admin_url('user-edit.php?user_id=' . $user_id)
                : network_admin_url('users.php');
        }

        if (
            function_exists('yooadmin_network_update_center_is_screen')
            && yooadmin_network_update_center_is_screen()
            && function_exists('yooadmin_network_update_center_should_use')
            && !yooadmin_network_update_center_should_use()
        ) {
            return function_exists('yooadmin_network_update_center_classic_url')
                ? yooadmin_network_update_center_classic_url()
                : network_admin_url('update-core.php?yooadmin_no_redirect=1');
        }

        if (
            function_exists('yooadmin_network_setup_is_screen')
            && yooadmin_network_setup_is_screen()
            && function_exists('yooadmin_network_setup_should_use')
            && !yooadmin_network_setup_should_use()
        ) {
            return function_exists('yooadmin_network_setup_classic_url')
                ? yooadmin_network_setup_classic_url()
                : network_admin_url('setup.php?yooadmin_no_redirect=1');
        }

        if (
            function_exists('yooadmin_network_upgrade_is_screen')
            && yooadmin_network_upgrade_is_screen()
            && function_exists('yooadmin_network_upgrade_should_use')
            && !yooadmin_network_upgrade_should_use()
        ) {
            return function_exists('yooadmin_network_upgrade_classic_url')
                ? yooadmin_network_upgrade_classic_url()
                : network_admin_url('upgrade.php?yooadmin_no_redirect=1');
        }

        if (
            function_exists('yooadmin_network_site_info_is_screen')
            && yooadmin_network_site_info_is_screen()
            && function_exists('yooadmin_network_site_info_should_use')
            && !yooadmin_network_site_info_should_use()
        ) {
            return yooadmin_network_site_editor_classic_url('site-info.php');
        }

        if (
            function_exists('yooadmin_network_site_users_is_screen')
            && yooadmin_network_site_users_is_screen()
            && function_exists('yooadmin_network_site_users_should_use')
            && !yooadmin_network_site_users_should_use()
        ) {
            return yooadmin_network_site_editor_classic_url('site-users.php');
        }

        if (
            function_exists('yooadmin_network_site_themes_is_screen')
            && yooadmin_network_site_themes_is_screen()
            && function_exists('yooadmin_network_site_themes_should_use')
            && !yooadmin_network_site_themes_should_use()
        ) {
            return yooadmin_network_site_editor_classic_url('site-themes.php');
        }

        if (
            function_exists('yooadmin_network_site_settings_is_screen')
            && yooadmin_network_site_settings_is_screen()
            && function_exists('yooadmin_network_site_settings_should_use')
            && !yooadmin_network_site_settings_should_use()
        ) {
            return yooadmin_network_site_editor_classic_url('site-settings.php');
        }

        if (
            function_exists('yooadmin_network_site_yooadmin_is_screen')
            && yooadmin_network_site_yooadmin_is_screen()
            && function_exists('yooadmin_network_site_yooadmin_should_use')
            && !yooadmin_network_site_yooadmin_should_use()
        ) {
            return yooadmin_network_site_editor_classic_url('site-info.php');
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page === 'yooadmin-plugins') {
            return network_admin_url('plugins.php');
        }

        return '';
    }
}

if (!function_exists('yooadmin_network_maybe_redirect_yoo_page_to_classic')) {
    function yooadmin_network_maybe_redirect_yoo_page_to_classic(): void
    {
        if (!is_multisite() || !is_network_admin()) {
            return;
        }
        if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
            return;
        }

        $target = yooadmin_network_yoo_page_classic_url();
        if ($target === '') {
            return;
        }

        wp_safe_redirect($target);
        exit;
    }
}

add_action('_network_admin_menu', 'yooadmin_network_maybe_redirect_yoo_page_to_classic', 1);
add_action('admin_page_access_denied', 'yooadmin_network_maybe_redirect_yoo_page_to_classic', 1);
add_action('admin_init', 'yooadmin_network_maybe_redirect_yoo_page_to_classic', 1);

if (!function_exists('yooadmin_network_submenu_remove_slugs')) {
    /**
     * Remove submenu entries by slug (core + YOOAdmin rewrites).
     *
     * @param string   $parent_file Parent menu slug.
     * @param string[] $slugs       Child slugs to remove.
     */
    function yooadmin_network_submenu_remove_slugs(string $parent_file, array $slugs): void
    {
        global $submenu;

        $slugs = array_values(array_filter(array_map('strval', $slugs)));
        if ($parent_file === '' || $slugs === []) {
            return;
        }

        foreach ($slugs as $slug) {
            remove_submenu_page($parent_file, $slug);
        }

        if (!isset($submenu[ $parent_file ]) || !is_array($submenu[ $parent_file ])) {
            return;
        }

        foreach ($submenu[ $parent_file ] as $index => $item) {
            if (!is_array($item) || empty($item[2])) {
                continue;
            }
            if (in_array((string) $item[2], $slugs, true)) {
                unset($submenu[ $parent_file ][ $index ]);
            }
        }

        $submenu[ $parent_file ] = array_values($submenu[ $parent_file ]);
    }
}

if (!function_exists('yooadmin_network_submenu_dedupe_by_slug')) {
    function yooadmin_network_submenu_dedupe_by_slug(string $parent_file): void
    {
        global $submenu;

        if ($parent_file === '' || !isset($submenu[ $parent_file ]) || !is_array($submenu[ $parent_file ])) {
            return;
        }

        $seen    = [];
        $deduped = [];

        foreach ($submenu[ $parent_file ] as $item) {
            if (!is_array($item) || empty($item[2])) {
                continue;
            }

            $slug = (string) $item[2];
            if (isset($seen[ $slug ])) {
                continue;
            }

            $seen[ $slug ] = true;
            $deduped[]       = $item;
        }

        $submenu[ $parent_file ] = $deduped;
    }
}

/**
 * Legacy yooadmin-plugins route → native plugins list (bookmarks / old links).
 */

add_filter(
    'parent_file',
    static function ($parent_file) {
        if (!is_multisite() || !is_network_admin()) {
            return $parent_file;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page === 'yooadmin-network-settings') {
            return 'settings.php';
        }
        if (function_exists('yooadmin_network_users_list_page_slug') && $page === yooadmin_network_users_list_page_slug()) {
            return 'users.php';
        }
        if (function_exists('yooadmin_network_user_new_page_slug') && $page === yooadmin_network_user_new_page_slug()) {
            return 'users.php';
        }
        if (function_exists('yooadmin_network_user_edit_page_slug') && $page === yooadmin_network_user_edit_page_slug()) {
            return 'users.php';
        }
        if ($page === 'yooadmin-network-sites') {
            return 'sites.php';
        }
        if (function_exists('yooadmin_network_site_editor_page_slugs')) {
            $editor_slugs = yooadmin_network_site_editor_page_slugs();
            if (in_array($page, array_values($editor_slugs), true)) {
                return 'sites.php';
            }
        }
        $add_site_slug = function_exists('yooadmin_network_site_new_page_slug')
            ? yooadmin_network_site_new_page_slug()
            : 'yooadmin-network-add-site';
        if ($page === $add_site_slug || $page === 'yooadmin-network-site-new') {
            return 'sites.php';
        }
        $network_uc_slug = function_exists('yooadmin_network_update_center_page_slug')
            ? yooadmin_network_update_center_page_slug()
            : 'yooadmin-network-update-center';
        if ($page === $network_uc_slug) {
            return 'index.php';
        }

        $network_upgrade_slug = function_exists('yooadmin_network_upgrade_page_slug')
            ? yooadmin_network_upgrade_page_slug()
            : 'yooadmin-network-upgrade';
        if ($page === $network_upgrade_slug) {
            return 'index.php';
        }

        $network_setup_slug = function_exists('yooadmin_network_setup_page_slug')
            ? yooadmin_network_setup_page_slug()
            : 'yooadmin-network-setup';
        if ($page === $network_setup_slug) {
            return 'settings.php';
        }

        if (
            function_exists('yooadmin_network_dashboard_is_screen')
            && yooadmin_network_dashboard_is_screen()
        ) {
            return 'index.php';
        }

        return $parent_file;
    }
);

add_filter(
    'submenu_file',
    static function ($submenu_file, $parent_file) {
        if (!is_multisite() || !is_network_admin()) {
            return $submenu_file;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        if ($parent_file === 'settings.php' && $page === 'yooadmin-network-settings') {
            return 'yooadmin-network-settings';
        }
        if ($parent_file === 'users.php') {
            if (function_exists('yooadmin_network_users_list_page_slug') && $page === yooadmin_network_users_list_page_slug()) {
                return yooadmin_network_users_list_page_slug();
            }
            if (function_exists('yooadmin_network_user_new_page_slug') && $page === yooadmin_network_user_new_page_slug()) {
                return yooadmin_network_user_new_page_slug();
            }
        }
        if ($parent_file === 'sites.php') {
            if ($page === 'yooadmin-network-sites') {
                return 'yooadmin-network-sites';
            }
            if (function_exists('yooadmin_network_site_editor_page_slugs')) {
                $editor_slugs = yooadmin_network_site_editor_page_slugs();
                if (in_array($page, array_values($editor_slugs), true)) {
                    return 'yooadmin-network-sites';
                }
            }
            $add_site_slug = function_exists('yooadmin_network_site_new_page_slug')
                ? yooadmin_network_site_new_page_slug()
                : 'yooadmin-network-add-site';
            if ($page === $add_site_slug || $page === 'yooadmin-network-site-new') {
                return $add_site_slug;
            }
        }
        if ($parent_file === 'settings.php') {
            $network_setup_slug = function_exists('yooadmin_network_setup_page_slug')
                ? yooadmin_network_setup_page_slug()
                : 'yooadmin-network-setup';
            if ($page === $network_setup_slug) {
                return $network_setup_slug;
            }
        }

        if ($parent_file === 'index.php') {
            $network_uc_slug = function_exists('yooadmin_network_update_center_page_slug')
                ? yooadmin_network_update_center_page_slug()
                : 'yooadmin-network-update-center';
            if ($page === $network_uc_slug) {
                return $network_uc_slug;
            }

            $network_upgrade_slug = function_exists('yooadmin_network_upgrade_page_slug')
                ? yooadmin_network_upgrade_page_slug()
                : 'yooadmin-network-upgrade';
            if ($page === $network_upgrade_slug) {
                return $network_upgrade_slug;
            }

            if (
                function_exists('yooadmin_network_dashboard_is_screen')
                && yooadmin_network_dashboard_is_screen()
                && function_exists('yooadmin_network_dashboard_slug')
            ) {
                return yooadmin_network_dashboard_slug();
            }
        }

        return $submenu_file;
    },
    10,
    2
);

/**
 * Network Admin — redirect users.php list to YOOAdmin when enabled.
 */
add_action('load-users.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    if (!current_user_can('manage_network_users')) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flag.
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Skip redirect while a form POST is in progress.
    if (!empty($_POST)) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Native bulk/list actions.
    $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash((string) $_REQUEST['action'])) : '';
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Native bulk/list actions.
    $action2 = isset($_REQUEST['action2']) ? sanitize_key(wp_unslash((string) $_REQUEST['action2'])) : '';
    if ($action !== '' && $action !== '-1') {
        return;
    }
    if ($action2 !== '' && $action2 !== '-1') {
        return;
    }
    if (!function_exists('yooadmin_network_users_should_use') || !yooadmin_network_users_should_use()) {
        return;
    }

    $redirect = yooadmin_network_users_list_url();
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Preserve read-only GET query args during redirect.
    if (!empty($_GET['s'])) {
        $redirect = add_query_arg('s', sanitize_text_field(wp_unslash((string) $_GET['s'])), $redirect);
    }
    if (!empty($_GET['role'])) {
        $redirect = add_query_arg('role', sanitize_key(wp_unslash((string) $_GET['role'])), $redirect);
    }
    if (!empty($_GET['paged'])) {
        $redirect = add_query_arg('paged', absint(wp_unslash((string) $_GET['paged'])), $redirect);
    }
    if (isset($_GET['updated'])) {
        $redirect = add_query_arg(
            [
                'updated' => sanitize_key(wp_unslash((string) $_GET['updated'])),
                'action'  => isset($_GET['action']) ? sanitize_key(wp_unslash((string) $_GET['action'])) : '',
            ],
            $redirect
        );
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    wp_safe_redirect($redirect);
    exit;
});

/**
 * Network Admin — redirect user-edit.php to YOOAdmin profile when enabled.
 */
add_action('load-user-edit.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flag.
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Skip redirect while a form POST is in progress.
    if (!empty($_POST)) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $user_id = isset($_GET['user_id']) ? absint(wp_unslash((string) $_GET['user_id'])) : 0;
    if ($user_id <= 0) {
        return;
    }
    if (!current_user_can('edit_user', $user_id)) {
        return;
    }
    if (!function_exists('yooadmin_network_users_should_use') || !yooadmin_network_users_should_use()) {
        return;
    }

    $redirect = yooadmin_network_user_edit_url($user_id);
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only flash query arg during redirect.
    if (isset($_GET['updated'])) {
        $redirect = add_query_arg('updated', sanitize_key(wp_unslash((string) $_GET['updated'])), $redirect);
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    wp_safe_redirect($redirect);
    exit;
});

/**
 * Network Admin — redirect user-new.php to YOOAdmin Add User when enabled.
 */
add_action('load-user-new.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    if (!current_user_can('create_users')) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flag.
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    if (!function_exists('yooadmin_network_users_should_use') || !yooadmin_network_users_should_use()) {
        return;
    }

    wp_safe_redirect(yooadmin_network_user_new_url());
    exit;
});

add_action('network_admin_menu', function () {
    global $submenu;

    if (!is_multisite() || !function_exists('yooadmin_network_users_should_use') || !yooadmin_network_users_should_use()) {
        return;
    }

    if (!current_user_can('manage_network_users')) {
        return;
    }

    if (!isset($submenu['users.php']) || !is_array($submenu['users.php'])) {
        return;
    }

    $list_slug = yooadmin_network_users_list_page_slug();
    $new_slug  = yooadmin_network_user_new_page_slug();

    $list_entry = null;
    $new_entry  = null;

    foreach ($submenu['users.php'] as $index => $item) {
        if (!is_array($item) || empty($item[2])) {
            continue;
        }
        $slug = (string) $item[2];
        if ($slug === $list_slug) {
            $list_entry = $item;
            unset($submenu['users.php'][ $index ]);
        } elseif ($slug === $new_slug) {
            $new_entry = $item;
            unset($submenu['users.php'][ $index ]);
        }
    }

    if (!$list_entry) {
        $list_entry = [__('Users', 'yooadmin'), 'manage_network_users', $list_slug, __('Users', 'yooadmin')];
    } else {
        $list_entry[0] = __('Users', 'yooadmin');
        $list_entry[2] = $list_slug;
        $list_entry[3] = __('Users', 'yooadmin');
    }

    if (!$new_entry) {
        $new_entry = [__('Add User', 'yooadmin'), 'create_users', $new_slug, __('Add User', 'yooadmin')];
    } else {
        $new_entry[0] = __('Add User', 'yooadmin');
        $new_entry[2] = $new_slug;
        $new_entry[3] = __('Add User', 'yooadmin');
    }

    $submenu['users.php'] = array_values($submenu['users.php']);
    array_unshift($submenu['users.php'], $new_entry);
    array_unshift($submenu['users.php'], $list_entry);
    yooadmin_network_submenu_remove_slugs('users.php', ['users.php', 'user-new.php']);
    yooadmin_network_submenu_dedupe_by_slug('users.php');
}, 99999);

/**
 * Network Admin — redirect settings.php to Network Settings Manager when enabled.
 */
add_action('load-settings.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    if (!current_user_can('manage_network_options')) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flag.
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Email confirmation / dismiss actions.
    if (!empty($_GET['network_admin_hash']) || !empty($_GET['dismiss'])) {
        return;
    }
    if (!function_exists('yooadmin_network_settings_should_use') || !yooadmin_network_settings_should_use()) {
        return;
    }

    wp_safe_redirect(yooadmin_network_settings_url());
    exit;
});

add_action('network_admin_menu', function () {
    global $submenu;

    if (!is_multisite() || !function_exists('yooadmin_network_settings_should_use') || !yooadmin_network_settings_should_use()) {
        return;
    }

    if (!current_user_can('manage_network_options')) {
        return;
    }

    remove_submenu_page('settings.php', 'settings.php');

    if (!isset($submenu['settings.php']) || !is_array($submenu['settings.php'])) {
        $submenu['settings.php'] = [];
    }

    $slug = function_exists('yooadmin_network_settings_page_slug') ? yooadmin_network_settings_page_slug() : 'yooadmin-network-settings';

    $entry = null;
    foreach ($submenu['settings.php'] as $index => $item) {
        if (!is_array($item) || empty($item[2])) {
            continue;
        }
        if ((string) $item[2] === $slug) {
            $entry = $item;
            unset($submenu['settings.php'][$index]);
            break;
        }
    }

    if (!$entry) {
        $entry = [
            __('Network Settings', 'yooadmin'),
            'manage_network_options',
            $slug,
            __('Network Settings', 'yooadmin'),
        ];
    } else {
        $entry[0] = __('Network Settings', 'yooadmin');
        $entry[2] = $slug;
        $entry[3] = __('Network Settings', 'yooadmin');
    }

    $submenu['settings.php'] = array_values($submenu['settings.php']);
    array_unshift($submenu['settings.php'], $entry);
    yooadmin_network_submenu_remove_slugs('settings.php', ['settings.php']);
    yooadmin_network_submenu_dedupe_by_slug('settings.php');
}, 99999);

/**
 * Network Admin — redirect sites.php to Network Sites Manager when enabled.
 */
add_action('load-sites.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    if (!current_user_can('manage_sites')) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flag.
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Skip redirect while a form POST is in progress.
    if (!empty($_POST)) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Native bulk/list actions.
    $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash((string) $_REQUEST['action'])) : '';
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Native bulk/list actions.
    $action2 = isset($_REQUEST['action2']) ? sanitize_key(wp_unslash((string) $_REQUEST['action2'])) : '';
    if ($action !== '' && $action !== '-1') {
        return;
    }
    if ($action2 !== '' && $action2 !== '-1') {
        return;
    }
    if (!function_exists('yooadmin_network_sites_should_use') || !yooadmin_network_sites_should_use()) {
        return;
    }

    $redirect_url = yooadmin_network_sites_url();
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only flash query arg during redirect.
    if (isset($_GET['updated'])) {
        $updated = sanitize_key(wp_unslash((string) $_GET['updated']));
        if ($updated !== '') {
            $redirect_url = add_query_arg('updated', $updated, $redirect_url);
        }
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    wp_safe_redirect($redirect_url);
    exit;
});

/**
 * Network Admin — redirect site-info.php to YOOAdmin Site Info when enabled.
 */
add_action('load-site-info.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    if (!current_user_can('manage_sites')) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flag.
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Skip redirect while a form POST is in progress.
    if (!empty($_POST)) {
        return;
    }
    if (!function_exists('yooadmin_network_site_info_should_use') || !yooadmin_network_site_info_should_use()) {
        return;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route parameter.
    $id = isset($_GET['id']) ? absint(wp_unslash((string) $_GET['id'])) : 0;
    if ($id <= 0) {
        return;
    }

    wp_safe_redirect(yooadmin_network_site_info_url($id));
    exit;
});

add_action('load-site-users.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    if (!current_user_can('manage_sites')) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Skip redirect while a form POST is in progress.
    if (!empty($_POST)) {
        return;
    }
    if (!function_exists('yooadmin_network_site_users_should_use') || !yooadmin_network_site_users_should_use()) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $id = isset($_GET['id']) ? absint(wp_unslash((string) $_GET['id'])) : 0;
    if ($id <= 0) {
        return;
    }
    wp_safe_redirect(yooadmin_network_site_users_url($id));
    exit;
});

add_action('load-site-themes.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    if (!current_user_can('manage_sites')) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Skip redirect while a form POST is in progress.
    if (!empty($_POST)) {
        return;
    }
    if (!function_exists('yooadmin_network_site_themes_should_use') || !yooadmin_network_site_themes_should_use()) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $id = isset($_GET['id']) ? absint(wp_unslash((string) $_GET['id'])) : 0;
    if ($id <= 0) {
        return;
    }
    wp_safe_redirect(yooadmin_network_site_themes_url($id));
    exit;
});

add_action('load-site-settings.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    if (!current_user_can('manage_sites')) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Skip redirect while a form POST is in progress.
    if (!empty($_POST)) {
        return;
    }
    if (!function_exists('yooadmin_network_site_settings_should_use') || !yooadmin_network_site_settings_should_use()) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $id = isset($_GET['id']) ? absint(wp_unslash((string) $_GET['id'])) : 0;
    if ($id <= 0) {
        return;
    }
    wp_safe_redirect(yooadmin_network_site_settings_url($id));
    exit;
});

add_action('network_admin_menu', function () {
    global $submenu;

    $sites_use = function_exists('yooadmin_network_sites_should_use') && yooadmin_network_sites_should_use();
    $add_use   = function_exists('yooadmin_network_site_new_should_use') && yooadmin_network_site_new_should_use();

    if (!is_multisite() || (!$sites_use && !$add_use)) {
        return;
    }

    if (!current_user_can('manage_sites') && !current_user_can('create_sites')) {
        return;
    }

    $sites_slug = function_exists('yooadmin_network_sites_page_slug') ? yooadmin_network_sites_page_slug() : 'yooadmin-network-sites';
    $add_slug   = function_exists('yooadmin_network_site_new_page_slug') ? yooadmin_network_site_new_page_slug() : 'yooadmin-network-add-site';

    $items = [];

    if ($sites_use && current_user_can('manage_sites')) {
        $items[] = [
            __('All Sites', 'yooadmin'),
            'manage_sites',
            $sites_slug,
            __('Sites', 'yooadmin'),
        ];
    }

    if ($add_use && current_user_can('create_sites')) {
        $items[] = [
            __('Add Site', 'yooadmin'),
            'create_sites',
            $add_slug,
            __('Add Site', 'yooadmin'),
        ];
    }

    if ($items === []) {
        return;
    }

    yooadmin_network_submenu_remove_slugs(
        'sites.php',
        ['sites.php', 'site-new.php', $sites_slug, $add_slug, 'yooadmin-network-site-new']
    );

    $submenu['sites.php'] = $items;
}, 99999);

/**
 * Network Admin — redirect site-new.php to YOOAdmin Add Site when enabled.
 */
add_action('load-site-new.php', function () {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    if (!current_user_can('create_sites')) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flag.
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Skip redirect while a form POST is in progress.
    if (!empty($_POST)) {
        return;
    }
    if (!function_exists('yooadmin_network_site_new_should_use') || !yooadmin_network_site_new_should_use()) {
        return;
    }

    wp_safe_redirect(yooadmin_network_site_new_url());
    exit;
});

/**
 * Network Admin — redirect update-core.php to YOOUpdate Center when Focus Mode is on.
 */
$yooadmin_redirect_network_update_core = static function (): void {
    if (!is_network_admin()) {
        return;
    }
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (isset($_GET['yooadmin_no_redirect'])) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper(sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD']))) : 'GET';
    if ($method !== 'GET') {
        return;
    }
    if (!function_exists('yooadmin_network_update_center_should_use') || !yooadmin_network_update_center_should_use()) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $action = isset($_GET['action']) ? sanitize_key(wp_unslash($_GET['action'])) : '';
    if ($action !== '' && 'upgrade-core' !== $action) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $args = isset($_GET) && is_array($_GET) ? wp_unslash($_GET) : [];
    unset($args['action']);
    $target = add_query_arg($args, yooadmin_network_update_center_url());
    wp_safe_redirect($target);
    exit;
};
add_action('load-update-core', $yooadmin_redirect_network_update_core);
add_action('load-update-core.php', $yooadmin_redirect_network_update_core);

add_action('network_admin_menu', function () {
    if (!function_exists('yooadmin_network_dashboard_should_use') || !yooadmin_network_dashboard_should_use()) {
        return;
    }
    if (!function_exists('yooadmin_network_dashboard_slug')) {
        return;
    }

    remove_submenu_page('index.php', 'index.php');

    global $submenu;

    $dash_slug = yooadmin_network_dashboard_slug();
    if (!isset($submenu['index.php']) || !is_array($submenu['index.php'])) {
        return;
    }

    foreach ($submenu['index.php'] as $index => $item) {
        if (!is_array($item) || empty($item[2])) {
            continue;
        }
        if ((string) $item[2] !== $dash_slug) {
            continue;
        }
        $submenu['index.php'][ $index ][0] = __('Home', 'yooadmin');
    }
}, 99999);

require_once __DIR__ . '/network-classic-pages-redirects.php';
