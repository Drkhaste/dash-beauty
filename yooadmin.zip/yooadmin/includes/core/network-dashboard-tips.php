<?php
/**
 * YOOAdmin network dashboard — tips pool and rotation.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_dashboard_tips_text_domain')) {
    function yooadmin_network_dashboard_tips_text_domain(): string
    {
        if (function_exists('yooadmin_multisite_text_domain')) {
            return yooadmin_multisite_text_domain();
        }

        return function_exists('yooadmin_network_dashboard_text_domain')
            ? yooadmin_network_dashboard_text_domain()
            : 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_dashboard_tip_entry')) {
    /**
     * @param array<string, string> $args
     * @return array<string, string>
     */
    function yooadmin_network_dashboard_tip_entry(array $args): array
    {
        if (function_exists('yooadmin_studio_hub_tip_entry')) {
            return yooadmin_studio_hub_tip_entry($args);
        }

        return [
            'id'    => (string) ($args['id'] ?? 'net-tip'),
            'title' => (string) ($args['title'] ?? ''),
            'text'  => (string) ($args['text'] ?? ''),
            'theme' => (string) ($args['theme'] ?? 'brand'),
            'icon'  => (string) ($args['icon'] ?? 'dashicons-lightbulb'),
            'image' => '',
        ];
    }
}

if (!function_exists('yooadmin_network_dashboard_get_all_tips')) {
    /**
     * Full network admin tips pool (YOOAdmin + multisite workflows).
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_network_dashboard_get_all_tips(): array
    {
        $td = yooadmin_network_dashboard_tips_text_domain();
        $t  = static function (array $a) use ($td): array {
            $a['title'] = isset($a['title']) ? (string) $a['title'] : '';
            $a['text']  = isset($a['text']) ? (string) $a['text'] : '';

            return yooadmin_network_dashboard_tip_entry($a);
        };

        $tips = [
            $t([
                'id' => 'net-yoo-focus', 'art' => 'focus', 'theme' => 'brand',
                'icon' => 'dashicons-visibility',
                'title' => __('YOOAdmin in Network Admin', 'yooadmin'),
                'text'  => __('With Focus Mode on, YOOAdmin replaces the default network dashboard with a workspace for sites, users, and network tools.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-yoo-home', 'art' => 'workspace', 'theme' => 'violet',
                'icon' => 'dashicons-admin-home',
                'title' => __('Network home dashboard', 'yooadmin'),
                'text'  => __('Open the YOOAdmin network dashboard from the menu to see overview stats, workspace tiles, sites, and tips in one place.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-overview', 'art' => 'organize', 'theme' => 'teal',
                'icon' => 'dashicons-chart-pie',
                'title' => __('Overview sidebar', 'yooadmin'),
                'text'  => __('The Overview card shows network totals and shortcuts to sites, users, plugins, and network settings.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-workspace', 'art' => 'workspace', 'theme' => 'amber',
                'icon' => 'dashicons-layout',
                'title' => __('Network Workspace', 'yooadmin'),
                'text'  => __('Pin network admin screens as tiles in Network Workspace for one-click access to the tools you use most.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-layout-edit', 'art' => 'workspace', 'theme' => 'indigo',
                'icon' => 'dashicons-move',
                'title' => __('Edit dashboard layout', 'yooadmin'),
                'text'  => __('Turn on layout edit mode to drag sections, hide cards, and add registered dashboard cards to the network home screen.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-layout-reset', 'art' => 'quick', 'theme' => 'rose',
                'icon' => 'dashicons-image-rotate',
                'title' => __('Reset network layout', 'yooadmin'),
                'text'  => __('Use Reset layout in edit mode to restore the default Network Workspace, Sites, Overview, Notes, and Tips arrangement.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-notes', 'art' => 'workspace', 'theme' => 'green',
                'icon' => 'dashicons-edit',
                'title' => __('Network Notes', 'yooadmin'),
                'text'  => __('Network Notes are saved per super admin and stay separate from site workspace notes on individual dashboards.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-sites-card', 'art' => 'organize', 'theme' => 'blue',
                'icon' => 'dashicons-admin-multisite',
                'title' => __('Sites on the dashboard', 'yooadmin'),
                'text'  => __('The Sites section lists recent sites with search and quick links to visit, edit, or manage each site.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-add-site', 'art' => 'quick', 'theme' => 'brand',
                'icon' => 'dashicons-plus-alt',
                'title' => __('Add a new site', 'yooadmin'),
                'text'  => __('Create sites from Sites → Add New. Choose address, title, and admin user before the site goes live on the network.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-site-info', 'art' => 'organize', 'theme' => 'cyan',
                'icon' => 'dashicons-info',
                'title' => __('Edit site info', 'yooadmin'),
                'text'  => __('Update a site’s domain, path, title, and registration flags from the site info screen without leaving network admin.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-site-users', 'art' => 'roles', 'theme' => 'violet',
                'icon' => 'dashicons-groups',
                'title' => __('Site users', 'yooadmin'),
                'text'  => __('Add or remove users on a single site from Site Users. Roles apply only on that site, not across the whole network.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-site-themes', 'art' => 'theme', 'theme' => 'amber',
                'icon' => 'dashicons-admin-appearance',
                'title' => __('Site themes', 'yooadmin'),
                'text'  => __('Enable or disable themes per site when the network does not force the same theme everywhere.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-site-settings', 'art' => 'organize', 'theme' => 'teal',
                'icon' => 'dashicons-admin-settings',
                'title' => __('Per-site settings', 'yooadmin'),
                'text'  => __('Some options live under each site’s Settings screen—useful when subsites need different defaults than the network.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-site-actions', 'art' => 'health', 'theme' => 'orange',
                'icon' => 'dashicons-flag',
                'title' => __('Archive, spam, or delete', 'yooadmin'),
                'text'  => __('Mark sites as archived or spam before deleting. Archived sites stay in the list but are disabled for visitors.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-settings', 'art' => 'organize', 'theme' => 'indigo',
                'icon' => 'dashicons-admin-network',
                'title' => __('Network settings', 'yooadmin'),
                'text'  => __('Network Settings control registration, welcome emails, upload limits, language defaults, and other global multisite rules.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-registration', 'art' => 'privacy', 'theme' => 'rose',
                'icon' => 'dashicons-admin-users',
                'title' => __('Registration options', 'yooadmin'),
                'text'  => __('Allow or disable new user and site sign-ups, and set whether admins get email when someone registers.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-upload-limits', 'art' => 'media', 'theme' => 'blue',
                'icon' => 'dashicons-upload',
                'title' => __('Upload space limits', 'yooadmin'),
                'text'  => __('Set per-site upload quotas in network settings so large networks do not run out of disk space on one busy site.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-users', 'art' => 'roles', 'theme' => 'green',
                'icon' => 'dashicons-groups',
                'title' => __('Network users', 'yooadmin'),
                'text'  => __('The Users screen lists everyone on the network. Open a user to edit their profile or assign super admin.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-add-user', 'art' => 'quick', 'theme' => 'brand',
                'icon' => 'dashicons-plus-alt2',
                'title' => __('Add a network user', 'yooadmin'),
                'text'  => __('Add users at the network level, then add them to individual sites with the role each site needs.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-super-admin', 'art' => 'roles', 'theme' => 'violet',
                'icon' => 'dashicons-shield',
                'title' => __('Super admins', 'yooadmin'),
                'text'  => __('Only super admins can manage the whole network. Grant super admin carefully from the user profile screen.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-spam-user', 'art' => 'health', 'theme' => 'orange',
                'icon' => 'dashicons-warning',
                'title' => __('Spam users', 'yooadmin'),
                'text'  => __('Mark suspicious accounts as spam to block sign-in across the network without deleting content immediately.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-plugins', 'art' => 'updates', 'theme' => 'teal',
                'icon' => 'dashicons-admin-plugins',
                'title' => __('Network plugins', 'yooadmin'),
                'text'  => __('Install plugins once in network admin, then Network Activate or enable them per site as needed.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-network-activate', 'art' => 'updates', 'theme' => 'amber',
                'icon' => 'dashicons-yes',
                'title' => __('Network Activate', 'yooadmin'),
                'text'  => __('Network Activate runs a plugin on every site. Use it only when all subsites should load that plugin.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-site-plugins', 'art' => 'updates', 'theme' => 'cyan',
                'icon' => 'dashicons-admin-plugins',
                'title' => __('Site-only plugins', 'yooadmin'),
                'text'  => __('Open a site dashboard from My Sites or the Sites list to activate plugins for that site only.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-themes', 'art' => 'theme', 'theme' => 'indigo',
                'icon' => 'dashicons-admin-appearance',
                'title' => __('Network themes', 'yooadmin'),
                'text'  => __('Enable themes for the network here, then allow or restrict them per site from each site’s Themes screen.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-subsite-bar', 'art' => 'focus', 'theme' => 'brand',
                'icon' => 'dashicons-arrow-left-alt',
                'title' => __('Subsite context bar', 'yooadmin'),
                'text'  => __('When you open a site from the network, the context bar shows which site you are in and a quick way back to network admin.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-updates', 'art' => 'updates', 'theme' => 'green',
                'icon' => 'dashicons-update',
                'title' => __('Network updates', 'yooadmin'),
                'text'  => __('Run WordPress, plugin, and theme updates from the network update center to keep every site on a safe version.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-quick-actions', 'art' => 'quick', 'theme' => 'amber',
                'icon' => 'dashicons-performance',
                'title' => __('Quick Actions', 'yooadmin'),
                'text'  => __('Customize Quick Actions on the network dashboard for faster access to screens you open every day.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-command-palette', 'art' => 'search', 'theme' => 'violet',
                'icon' => 'dashicons-search',
                'title' => __('Jump anywhere quickly', 'yooadmin'),
                'text'  => __('Use the command palette shortcut to search network admin pages, sites, and tools without digging through menus.', 'yooadmin'),
            ]),
            $t([
                'id' => 'net-my-sites', 'art' => 'organize', 'theme' => 'blue',
                'icon' => 'dashicons-admin-site-alt3',
                'title' => __('My Sites menu', 'yooadmin'),
                'text'  => __('My Sites lists every site you belong to—handy for jumping between subsite dashboards while staying in YOOAdmin.', 'yooadmin'),
            ]),
        ];

        /**
         * Filter the full network dashboard tips pool.
         *
         * @param array<int, array<string, string>> $tips
         */
        return apply_filters('yooadmin_network_dashboard_all_tips', $tips);
    }
}

if (!function_exists('yooadmin_network_dashboard_pick_rotating_tips')) {
    /**
     * Fair rotation for network tips (separate user-meta deck from site tips).
     *
     * @param array<int, array<string, string>> $tips
     * @return array<int, array<string, string>>
     */
    function yooadmin_network_dashboard_pick_rotating_tips(array $tips, int $min = 4, int $max = 6): array
    {
        $indexed = [];
        foreach ($tips as $tip) {
            if (!is_array($tip)) {
                continue;
            }
            $id = isset($tip['id']) ? (string) $tip['id'] : '';
            if ($id === '') {
                continue;
            }
            $indexed[ $id ] = $tip;
        }

        $total = count($indexed);
        if ($total <= 0) {
            return [];
        }
        if ($total <= $min) {
            return array_values($indexed);
        }

        $max  = min($max, $total);
        $min  = min($min, $max);
        $want = wp_rand($min, $max);

        $user_id = function_exists('get_current_user_id') ? (int) get_current_user_id() : 0;
        if ($user_id <= 0) {
            $deck = array_keys($indexed);
            shuffle($deck);

            return array_values(array_intersect_key($indexed, array_flip(array_slice($deck, 0, $want))));
        }

        $meta_deck = 'yooadmin_network_dashboard_tips_deck';
        $meta_sig  = 'yooadmin_network_dashboard_tips_deck_sig';

        $ids = array_keys($indexed);
        sort($ids, SORT_STRING);
        $sig = md5(implode("\n", $ids));

        $stored_sig = (string) get_user_meta($user_id, $meta_sig, true);
        if ($stored_sig !== $sig) {
            delete_user_meta($user_id, $meta_deck);
            update_user_meta($user_id, $meta_sig, $sig);
        }

        $deck = get_user_meta($user_id, $meta_deck, true);
        if (!is_array($deck)) {
            $deck = [];
        }

        $valid = array_flip(array_keys($indexed));
        $deck  = array_values(array_filter(
            array_map('strval', $deck),
            static function (string $id) use ($valid): bool {
                return isset($valid[ $id ]);
            }
        ));

        if (count($deck) < $want) {
            $in_deck   = array_flip($deck);
            $remaining = [];
            foreach (array_keys($indexed) as $id) {
                if (!isset($in_deck[ $id ])) {
                    $remaining[] = $id;
                }
            }
            if ($remaining === []) {
                $remaining = array_keys($indexed);
                $deck      = [];
            }
            shuffle($remaining);
            $deck = array_merge($deck, $remaining);
        }

        $picked_ids = array_slice($deck, 0, $want);
        $deck       = array_slice($deck, $want);
        update_user_meta($user_id, $meta_deck, $deck);

        $picked = [];
        foreach ($picked_ids as $id) {
            if (isset($indexed[ $id ])) {
                $picked[] = $indexed[ $id ];
            }
        }

        if (count($picked) < $want) {
            $fallback = array_keys($indexed);
            shuffle($fallback);
            foreach ($fallback as $id) {
                if (isset($indexed[ $id ]) && !in_array($id, $picked_ids, true)) {
                    $picked[] = $indexed[ $id ];
                }
                if (count($picked) >= $want) {
                    break;
                }
            }
        }

        shuffle($picked);

        return array_slice($picked, 0, $want);
    }
}

if (!function_exists('yooadmin_network_dashboard_get_tips')) {
    /**
     * Rotating subset for the network dashboard Tips card.
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_network_dashboard_get_tips(): array
    {
        $all = yooadmin_network_dashboard_get_all_tips();

        /**
         * Filter tips before rotation (legacy hook; same shape as full pool entries).
         *
         * @param array<int, array<string, string>> $all
         */
        $all = apply_filters('yooadmin_network_dashboard_tips', $all);

        return yooadmin_network_dashboard_pick_rotating_tips($all, 4, 6);
    }
}
