<?php
/**
 * YOOAdmin network site settings tab.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_site_settings_page_slug')) {
    function yooadmin_network_site_settings_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_site_settings_page_slug', 'yooadmin-network-site-settings');
    }
}

if (!function_exists('yooadmin_network_site_settings_url')) {
    function yooadmin_network_site_settings_url(int $blog_id, array $args = []): string
    {
        if (function_exists('yooadmin_network_site_settings_should_use') && !yooadmin_network_site_settings_should_use()) {
            $url = network_admin_url('site-settings.php?id=' . max(1, $blog_id));
            return $args ? add_query_arg($args, $url) : $url;
        }

        $url = network_admin_url('admin.php?page=' . yooadmin_network_site_settings_page_slug());
        $url = add_query_arg('id', max(1, $blog_id), $url);

        if ($args) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_site_settings_should_use')) {
    function yooadmin_network_site_settings_should_use(): bool
    {
        return function_exists('yooadmin_network_site_editor_should_use') && yooadmin_network_site_editor_should_use();
    }
}

if (!function_exists('yooadmin_network_site_settings_is_screen')) {
    function yooadmin_network_site_settings_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_site_settings_page_slug();
    }
}

if (!function_exists('yooadmin_network_site_settings_get_options')) {
    /**
     * @return array<int, object>
     */
    function yooadmin_network_site_settings_get_options(int $blog_id): array
    {
        global $wpdb;

        $blog_prefix   = $wpdb->get_blog_prefix($blog_id);
        $options_table = $blog_prefix . 'options';
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name from $wpdb->get_blog_prefix().
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $options = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM `{$options_table}` WHERE option_name NOT LIKE %s AND option_name NOT LIKE %s",
                $wpdb->esc_like('_') . '%',
                '%' . $wpdb->esc_like('user_roles')
            )
        );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter

        return is_array($options) ? $options : [];
    }
}

if (!function_exists('yooadmin_network_site_settings_ltr_fields')) {
    /**
     * @return array<int, string>
     */
    function yooadmin_network_site_settings_ltr_fields(): array
    {
        return [
            'siteurl',
            'home',
            'admin_email',
            'new_admin_email',
            'mailserver_url',
            'mailserver_login',
            'mailserver_pass',
            'ping_sites',
            'permalink_structure',
            'category_base',
            'tag_base',
            'upload_path',
            'upload_url_path',
        ];
    }
}

if (!function_exists('yooadmin_network_site_settings_option_label')) {
    function yooadmin_network_site_settings_option_label(string $option_name): string
    {
        $td = yooadmin_network_site_editor_text_domain();
        $labels = [
            'blogname'                       => __('Site Title', 'yooadmin'),
            'blogdescription'                => __('Tagline', 'yooadmin'),
            'siteurl'                        => __('WordPress Address (URL)', 'yooadmin'),
            'home'                           => __('Site Address (URL)', 'yooadmin'),
            'admin_email'                    => __('Administration Email Address', 'yooadmin'),
            'new_admin_email'                => __('Pending Admin Email', 'yooadmin'),
            'users_can_register'             => __('Membership', 'yooadmin'),
            'default_role'                   => __('New User Default Role', 'yooadmin'),
            'timezone_string'                => __('Timezone', 'yooadmin'),
            'gmt_offset'                     => __('UTC Offset', 'yooadmin'),
            'date_format'                    => __('Date Format', 'yooadmin'),
            'time_format'                    => __('Time Format', 'yooadmin'),
            'start_of_week'                  => __('Week Starts On', 'yooadmin'),
            'WPLANG'                         => __('Site Language', 'yooadmin'),
            'posts_per_page'                 => __('Blog pages show at most', 'yooadmin'),
            'posts_per_rss'                  => __('Syndication feeds show the most recent', 'yooadmin'),
            'rss_use_excerpt'                => __('For each article in a feed, show', 'yooadmin'),
            'blog_public'                    => __('Search Engine Visibility', 'yooadmin'),
            'default_category'               => __('Default Post Category', 'yooadmin'),
            'default_email_category'         => __('Default Mail Category', 'yooadmin'),
            'permalink_structure'          => __('Permalink Structure', 'yooadmin'),
            'category_base'                  => __('Category Base', 'yooadmin'),
            'tag_base'                       => __('Tag Base', 'yooadmin'),
            'thumbnail_size_w'               => __('Thumbnail Width', 'yooadmin'),
            'thumbnail_size_h'               => __('Thumbnail Height', 'yooadmin'),
            'medium_size_w'                  => __('Medium Width', 'yooadmin'),
            'medium_size_h'                  => __('Medium Height', 'yooadmin'),
            'large_size_w'                   => __('Large Width', 'yooadmin'),
            'large_size_h'                   => __('Large Height', 'yooadmin'),
            'uploads_use_yearmonth_folders'  => __('Organize uploads into month- and year-based folders', 'yooadmin'),
            'upload_path'                    => __('Store uploads in this folder', 'yooadmin'),
            'upload_url_path'                => __('Full URL path to files', 'yooadmin'),
            'mailserver_url'                 => __('Mail Server URL', 'yooadmin'),
            'mailserver_login'               => __('Login Name', 'yooadmin'),
            'mailserver_pass'                => __('Password', 'yooadmin'),
            'default_post_format'            => __('Default Post Format', 'yooadmin'),
            'ping_sites'                     => __('Update Services', 'yooadmin'),
            'comments_notify'                => __('Email me whenever anyone posts a comment', 'yooadmin'),
            'moderation_notify'              => __('Email me whenever a comment is held for moderation', 'yooadmin'),
            'comment_moderation'             => __('Comment must be manually approved', 'yooadmin'),
            'require_name_email'             => __('Comment author must fill out name and email', 'yooadmin'),
            'comment_registration'           => __('Users must be registered and logged in to comment', 'yooadmin'),
            'close_comments_for_old_posts'   => __('Automatically close comments on old posts', 'yooadmin'),
            'close_comments_days_old'        => __('Close comments when post is how many days old', 'yooadmin'),
            'thread_comments'                => __('Enable threaded (nested) comments', 'yooadmin'),
            'thread_comments_depth'          => __('Number of levels for threaded comments', 'yooadmin'),
            'page_comments'                  => __('Break comments into pages', 'yooadmin'),
            'comments_per_page'              => __('Comments per page', 'yooadmin'),
            'default_comments_page'          => __('Default comments page', 'yooadmin'),
            'comment_order'                  => __('Comments should be displayed with', 'yooadmin'),
            'comment_whitelist'              => __('Comment author must have a previously approved comment', 'yooadmin'),
            'show_on_front'                  => __('Your homepage displays', 'yooadmin'),
            'page_on_front'                  => __('Homepage', 'yooadmin'),
            'page_for_posts'                 => __('Posts page', 'yooadmin'),
        ];

        if (isset($labels[ $option_name ])) {
            return $labels[ $option_name ];
        }

        return ucwords(str_replace(['_', '-'], ' ', $option_name));
    }
}

if (!function_exists('yooadmin_network_site_settings_checkbox_options')) {
    /**
     * @return array<int, string>
     */
    function yooadmin_network_site_settings_checkbox_options(): array
    {
        return [
            'users_can_register',
            'blog_public',
            'rss_use_excerpt',
            'uploads_use_yearmonth_folders',
            'comments_notify',
            'moderation_notify',
            'comment_moderation',
            'require_name_email',
            'comment_registration',
            'close_comments_for_old_posts',
            'thread_comments',
            'page_comments',
            'comment_whitelist',
        ];
    }
}

if (!function_exists('yooadmin_network_site_settings_field_groups')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_site_settings_field_groups(): array
    {
        $td = yooadmin_network_site_editor_text_domain();

        return [
            [
                'id'      => 'identity',
                'title'   => __('Site Identity', 'yooadmin'),
                'icon'    => 'dashicons-admin-site-alt3',
                'column'  => 'left',
                'options' => ['blogname', 'blogdescription', 'siteurl', 'home', 'admin_email', 'WPLANG'],
            ],
            [
                'id'      => 'reading',
                'title'   => __('Reading', 'yooadmin'),
                'icon'    => 'dashicons-book-alt',
                'column'  => 'left',
                'options' => ['posts_per_page', 'posts_per_rss', 'rss_use_excerpt', 'blog_public', 'show_on_front', 'page_on_front', 'page_for_posts'],
            ],
            [
                'id'      => 'discussion',
                'title'   => __('Discussion', 'yooadmin'),
                'icon'    => 'dashicons-admin-comments',
                'column'  => 'left',
                'options' => [
                    'comments_notify',
                    'moderation_notify',
                    'comment_moderation',
                    'require_name_email',
                    'comment_registration',
                    'close_comments_for_old_posts',
                    'close_comments_days_old',
                    'thread_comments',
                    'thread_comments_depth',
                    'page_comments',
                    'comments_per_page',
                    'default_comments_page',
                    'comment_order',
                    'comment_whitelist',
                ],
            ],
            [
                'id'      => 'membership',
                'title'   => __('Membership', 'yooadmin'),
                'icon'    => 'dashicons-groups',
                'column'  => 'right',
                'options' => ['users_can_register', 'default_role'],
            ],
            [
                'id'      => 'datetime',
                'title'   => __('Date & Time', 'yooadmin'),
                'icon'    => 'dashicons-clock',
                'column'  => 'right',
                'options' => ['timezone_string', 'gmt_offset', 'date_format', 'time_format', 'start_of_week'],
            ],
            [
                'id'      => 'media',
                'title'   => __('Media', 'yooadmin'),
                'icon'    => 'dashicons-format-image',
                'column'  => 'right',
                'options' => [
                    'thumbnail_size_w',
                    'thumbnail_size_h',
                    'medium_size_w',
                    'medium_size_h',
                    'large_size_w',
                    'large_size_h',
                    'uploads_use_yearmonth_folders',
                    'upload_path',
                    'upload_url_path',
                ],
            ],
            [
                'id'      => 'permalinks',
                'title'   => __('Permalinks', 'yooadmin'),
                'icon'    => 'dashicons-admin-links',
                'column'  => 'right',
                'options' => ['permalink_structure', 'category_base', 'tag_base'],
            ],
            [
                'id'      => 'email',
                'title'   => __('Post via Email', 'yooadmin'),
                'icon'    => 'dashicons-email-alt',
                'column'  => 'right',
                'options' => ['mailserver_url', 'mailserver_login', 'mailserver_pass', 'default_email_category', 'ping_sites'],
            ],
        ];
    }
}

if (!function_exists('yooadmin_network_site_settings_prepare_groups')) {
    /**
     * @return array{left: array<int, array<string, mixed>>, right: array<int, array<string, mixed>>, advanced: array<int, object>}
     */
    function yooadmin_network_site_settings_prepare_groups(int $blog_id): array
    {
        $options = yooadmin_network_site_settings_get_options($blog_id);
        $by_name = [];
        $advanced = [];

        foreach ($options as $option) {
            if (!is_object($option) || !isset($option->option_name)) {
                continue;
            }

            $name = (string) $option->option_name;
            if ($name === 'new_admin_email' || $name === 'allowedthemes') {
                continue;
            }

            if (is_serialized($option->option_value) && !is_serialized_string($option->option_value)) {
                continue;
            }

            $by_name[ $name ] = $option;
        }

        $used = [];
        $left = [];
        $right = [];

        foreach (yooadmin_network_site_settings_field_groups() as $group) {
            $fields = [];
            foreach ((array) ($group['options'] ?? []) as $option_name) {
                if (!isset($by_name[ $option_name ])) {
                    continue;
                }
                $fields[] = $by_name[ $option_name ];
                $used[ $option_name ] = true;
            }

            if (!$fields) {
                continue;
            }

            $group['fields'] = $fields;
            if (($group['column'] ?? 'left') === 'right') {
                $right[] = $group;
            } else {
                $left[] = $group;
            }
        }

        foreach ($by_name as $name => $option) {
            if (isset($used[ $name ])) {
                continue;
            }
            $advanced[] = $option;
        }

        usort(
            $advanced,
            static function (object $a, object $b): int {
                return strcmp((string) $a->option_name, (string) $b->option_name);
            }
        );

        return [
            'left'     => $left,
            'right'    => $right,
            'advanced' => $advanced,
        ];
    }
}

if (!function_exists('yooadmin_network_site_settings_render_field')) {
    function yooadmin_network_site_settings_render_field(object $option, int $blog_id, bool $is_main_site): void
    {
        $td      = yooadmin_network_site_editor_text_domain();
        $name    = (string) $option->option_name;
        $label   = yooadmin_network_site_settings_option_label($name);
        $value   = $option->option_value;
        $disabled = false;
        $class   = 'regular-text';

        if (is_serialized($value)) {
            if (is_serialized_string($value)) {
                $value = maybe_unserialize($value);
            } else {
                return;
            }
        }

        if (in_array($name, yooadmin_network_site_settings_ltr_fields(), true)) {
            $class .= ' ltr';
        }

        if ($name === 'default_role') {
            ?>
            <div class="yoo-network-settings-field yoo-network-settings-field--row">
              <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label>
              <div class="yoo-network-settings-field__control">
                <select name="option[<?php echo esc_attr($name); ?>]" id="<?php echo esc_attr($name); ?>">
                  <?php
                  switch_to_blog($blog_id);
                  wp_dropdown_roles((string) $value);
                  restore_current_blog();
                  ?>
                </select>
              </div>
            </div>
            <?php
            return;
        }

        if (in_array($name, yooadmin_network_site_settings_checkbox_options(), true)) {
            ?>
            <div class="yoo-network-settings-field yoo-network-settings-field--toggles">
              <label class="yoo-network-settings-choice">
                <input type="hidden" name="option[<?php echo esc_attr($name); ?>]" value="0" />
                <input type="checkbox" name="option[<?php echo esc_attr($name); ?>]" id="<?php echo esc_attr($name); ?>" value="1" <?php checked((string) $value, '1'); ?> />
                <?php echo esc_html($label); ?>
              </label>
            </div>
            <?php
            return;
        }

        if ($is_main_site && in_array($name, ['siteurl', 'home'], true)) {
            ?>
            <div class="yoo-network-settings-field yoo-network-settings-field--row">
              <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label>
              <div class="yoo-network-settings-field__control">
                <code class="yoo-network-site-info-url-code"><?php echo esc_html((string) $value); ?></code>
              </div>
            </div>
            <?php
            return;
        }

        ?>
        <div class="yoo-network-settings-field yoo-network-settings-field--row">
          <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label>
          <div class="yoo-network-settings-field__control">
            <?php if (str_contains((string) $value, "\n")) : ?>
              <textarea class="<?php echo esc_attr($class); ?>" rows="5" cols="40" name="option[<?php echo esc_attr($name); ?>]" id="<?php echo esc_attr($name); ?>"<?php disabled($disabled); ?>><?php echo esc_textarea((string) $value); ?></textarea>
            <?php else : ?>
              <input class="<?php echo esc_attr($class); ?>" name="option[<?php echo esc_attr($name); ?>]" type="text" id="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr((string) $value); ?>" size="40" <?php disabled($disabled); ?> />
            <?php endif; ?>
          </div>
        </div>
        <?php
    }
}

if (!function_exists('yooadmin_network_site_settings_process_save')) {
    function yooadmin_network_site_settings_process_save(): bool
    {
        if (!is_multisite() || !is_network_admin() || !current_user_can('manage_sites')) {
            return false;
        }

        if (!yooadmin_network_site_settings_is_screen()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!isset($_REQUEST['action']) || 'update-site' !== sanitize_key(wp_unslash((string) $_REQUEST['action']))) {
            return false;
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        if (!isset($_POST['option']) || !is_array($_POST['option'])) {
            return false;
        }

        check_admin_referer('edit-site');

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $id = isset($_REQUEST['id']) ? absint(wp_unslash((string) $_REQUEST['id'])) : 0;
        if ($id <= 0 || !yooadmin_network_site_editor_get_site($id)) {
            wp_die(esc_html__('Invalid site ID.', 'yooadmin'));
        }

        switch_to_blog($id);

        $skip_options = ['allowedthemes'];
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        foreach ((array) wp_unslash($_POST['option']) as $key => $val) {
            $key = wp_unslash($key);
            $val = wp_unslash($val);
            if (0 === $key || is_array($val) || in_array($key, $skip_options, true)) {
                continue;
            }
            update_option((string) $key, $val);
        }

        do_action('wpmu_update_blog_options', $id); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
        restore_current_blog();

        wp_safe_redirect(
            yooadmin_network_site_settings_url(
                $id,
                [
                    'update' => 'updated',
                ]
            )
        );
        exit;
    }
}

add_action(
    'admin_init',
    static function (): void {
        if (!yooadmin_network_site_settings_should_use()) {
            return;
        }
        yooadmin_network_site_settings_process_save();
    },
    5
);
