<?php
/**
 * YOOAdmin - Admin favicon injector (admin + login)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

if (!defined('YOOADMIN_PLUGIN_FILE')) {
    define('YOOADMIN_PLUGIN_FILE', dirname(__DIR__, 2) . '/yooadmin.php');
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function yooadmin_guess_mime_from_url(string $url): string
{
    $path = wp_parse_url($url, PHP_URL_PATH) ?: '';
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    return match ($ext) {
            'ico' => 'image/x-icon',
            'svg' => 'image/svg+xml',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'jpg', 'jpeg' => 'image/jpeg',
            default => '',
        };
}

function yooadmin_is_raster_mime(string $mime): bool
{
    return in_array($mime, ['image/png', 'image/jpeg', 'image/gif'], true);
}

/**
 * Create (or reuse) downsized PNGs (16x16, 32x32) from a raster source URL.
 * Returns array of [ size => absolute_url ] for the sizes that were created.
 */
function yooadmin_ensure_raster_favicons(string $source_url): array
{
    $out = [];
    $upload = wp_upload_dir();
    if (!empty($upload['error']))
        return $out;

    $dir = trailingslashit($upload['basedir']) . 'yooadmin-favicons/';
    $url = trailingslashit($upload['baseurl']) . 'yooadmin-favicons/';
    if (!wp_mkdir_p($dir))
        return $out;

    // Resolve local path or sideload
    $src_path = '';
    $host_src = wp_parse_url($source_url, PHP_URL_HOST);
    $host_site = wp_parse_url(home_url('/'), PHP_URL_HOST);
    if ($host_src && $host_site && $host_src === $host_site) {
        $maybe = str_replace(trailingslashit($upload['baseurl']), trailingslashit($upload['basedir']), $source_url);
        if (file_exists($maybe))
            $src_path = $maybe;
        if (!$src_path) {
            $content_url = content_url();
            if (strpos($source_url, $content_url) === 0) {
                $rel = substr($source_url, strlen($content_url));
                $try = wp_normalize_path(WP_CONTENT_DIR . $rel);
                if (file_exists($try)) {
                    $src_path = $try;
                }
            }
        }
        if (!$src_path) {
            $home_path = wp_parse_url(home_url('/'), PHP_URL_PATH) ?: '';
            $url_path  = wp_parse_url($source_url, PHP_URL_PATH) ?: '';
            if ($home_path !== '' && $url_path !== '' && strpos($url_path, $home_path) === 0) {
                $rel = ltrim(substr($url_path, strlen(untrailingslashit($home_path))), '/');
                $try = wp_normalize_path(ABSPATH . $rel);
                if (file_exists($try)) {
                    $src_path = $try;
                }
            }
        }
    }
    $tmp_cleanup = false;
    if (!$src_path) {
        $tmp = download_url($source_url);
        if (!is_wp_error($tmp) && file_exists($tmp)) {
            $src_path = $tmp;
            $tmp_cleanup = true;
        }
        else {
            return $out;
        }
    }

    $editor = wp_get_image_editor($src_path);
    if (is_wp_error($editor)) {
        if ($tmp_cleanup && file_exists($src_path))
            wp_delete_file($src_path);
        return $out;
    }

    foreach ([16, 32] as $size) {
        $name = 'admin-favicon-' . $size . 'x' . $size . '.png';
        $dest = $dir . $name;
        $href = $url . $name;

        if (!file_exists($dest)) {
            $ed = clone $editor;
            $ed->resize($size, $size, true);
            $saved = $ed->save($dest, 'image/png');
            if (is_wp_error($saved))
                continue;
        }
        $ver = @filemtime($dest);
        $out[$size] = $href . ($ver ? '?ver=' . $ver : '');
    }

    if ($tmp_cleanup && file_exists($src_path))
        wp_delete_file($src_path);
    return $out;
}

/* -------------------------------------------------------------------------- */
/* Collector                                                                  */
/* -------------------------------------------------------------------------- */

function yooadmin_collect_admin_favicons(): array
{
    // 1) Use WP Site Icon if set (best cropping + multi sizes)
    if (function_exists('has_site_icon') && has_site_icon()) {
        return ['__use_core_site_icon__' => true];
    }

    // 2) Option (admin_favicon_url)
    $opts = (array)get_option('yooadmin_options', []);
    $opt = isset($opts['admin_favicon_url']) ? esc_url_raw($opts['admin_favicon_url']) : '';
    if ($opt) {
        $mime = yooadmin_guess_mime_from_url($opt);

        // SVG/ICO -> print directly
        if ($mime === 'image/svg+xml' || $mime === 'image/x-icon') {
            $arr = [
                ['rel' => 'icon', 'href' => $opt, 'type' => $mime],
                ['rel' => 'shortcut icon', 'href' => $opt, 'type' => $mime],
            ];
            if ($mime === 'image/svg+xml') {
                $arr[] = ['rel' => 'mask-icon', 'href' => $opt, 'type' => $mime, 'color' => '#333333'];
            }
            return $arr;
        }

        // Raster -> generate clean 16/32 PNGs
        if (yooadmin_is_raster_mime($mime)) {
            $pngs = yooadmin_ensure_raster_favicons($opt);
            $arr = [];
            if (!empty($pngs[16]))
                $arr[] = ['rel' => 'icon', 'href' => $pngs[16], 'type' => 'image/png', 'sizes' => '16x16'];
            if (!empty($pngs[32]))
                $arr[] = ['rel' => 'icon', 'href' => $pngs[32], 'type' => 'image/png', 'sizes' => '32x32'];
            if ($arr)
                return $arr;
        }
    }

    // 3) Fallback to plugin assets (ICO/SVG only; PNGs are optional)
    $base = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : __FILE__;
    $dir = plugin_dir_path($base);
    $url = plugin_dir_url($base);

    $cands = [
        // Use your custom favicon files from assets/images
        ['path' => 'assets/images/favicon.ico', 'type' => 'image/x-icon', 'sizes' => ''],
        ['path' => 'assets/images/favicon.svg', 'type' => 'image/svg+xml', 'sizes' => ''],
    ];

    $out = [];
    foreach ($cands as $c) {
        $abs = $dir . $c['path'];
        if (!file_exists($abs))
            continue;

        $href = $url . $c['path'];
        $ver = @filemtime($abs);
        if ($ver)
            $href .= '?ver=' . $ver;

        $item = ['rel' => 'icon', 'href' => $href, 'type' => $c['type']];
        if (!empty($c['sizes']))
            $item['sizes'] = $c['sizes'];
        $out[] = $item;

        $si = $item;
        $si['rel'] = 'shortcut icon';
        $out[] = $si;

        if ($c['type'] === 'image/svg+xml') {
            $out[] = ['rel' => 'mask-icon', 'href' => $href, 'type' => 'image/svg+xml', 'color' => '#333333'];
        }
    }

    return $out;
}

/* -------------------------------------------------------------------------- */
/* Virtual Site Icon (admin/login only when no real Site Icon exists)         */
/* -------------------------------------------------------------------------- */

add_action('init', function () {
    $script = isset($_SERVER['SCRIPT_NAME']) ? wp_basename(sanitize_text_field(wp_unslash($_SERVER['SCRIPT_NAME']))) : '';
    $is_login = ($script === 'wp-login.php')
        || (!empty($GLOBALS['pagenow']) && $GLOBALS['pagenow'] === 'wp-login.php');
    $is_standalone_login = function_exists('yooadmin_standalone_login_is_this_request')
        && yooadmin_standalone_login_is_this_request();
    if (!is_admin() && !$is_login && !$is_standalone_login) {
        return;
    }

    if (function_exists('has_site_icon') && has_site_icon()) {
        return;
    }

    // Gutenberg uses native Site Icon only — never register the virtual marker there.
    if (function_exists('yooadmin_studio_hub_is_block_editor_site_icon_context')
        && yooadmin_studio_hub_is_block_editor_site_icon_context()) {
        return;
    }

    // Prefer: option admin_favicon_url; otherwise plugin fallbacks (ICO -> SVG)
    $base = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : __FILE__;
    $dir = plugin_dir_path($base);
    $url = plugin_dir_url($base);

    $opts = (array)get_option('yooadmin_options', []);
    $opt = isset($opts['admin_favicon_url']) ? esc_url_raw($opts['admin_favicon_url']) : '';

    $icon_url = '';
    if (!empty($opt)) {
        $icon_url = $opt;
    }
    else {
        $fallbacks = [
            // Fallback to bundled favicon files in assets/images
            $dir . 'assets/images/favicon.ico' => $url . 'assets/images/favicon.ico',
            $dir . 'assets/images/favicon.svg' => $url . 'assets/images/favicon.svg',
        ];
        foreach ($fallbacks as $abs => $href) {
            if (file_exists($abs)) {
                $ver = @filemtime($abs);
                $icon_url = $href . ($ver ? '?ver=' . $ver : '');
                break;
            }
        }
    }
    if (!$icon_url)
        return;

    // Pretend there is a Site Icon so core prints its tags
    add_filter('pre_option_site_icon', function ($pre) {
            return '__yooadmin_virtual_site_icon__';
        }
        );

        // Provide the URL core should use for rel=icon (works for ICO/SVG too)
        add_filter('get_site_icon_url', function ($url_in, $size) use ($icon_url) {
            return $icon_url;
        }
            , 10, 2);

        // Ensure core actually prints the tags very early
        add_action('admin_head', function () {
            if (function_exists('wp_site_icon'))
                wp_site_icon();
        }
            , 0);
        add_action('login_head', function () {
            if (function_exists('wp_site_icon'))
                wp_site_icon();
        }
            , 0);
    });

/* -------------------------------------------------------------------------- */
/* Printer (fallback to our links; runs very early so it wins)                */
/* -------------------------------------------------------------------------- */

function yooadmin_print_admin_favicon_links(): void
{
    $icons = yooadmin_collect_admin_favicons();
    if (!$icons)
        return;

    // Delegate to core if instructed
    if (isset($icons['__use_core_site_icon__'])) {
        if (function_exists('wp_site_icon')) {
            wp_site_icon();
        }
        return;
    }

    foreach ($icons as $i) {
        $rel = $i['rel'] ?? 'icon';
        $href = $i['href'] ?? '';
        if (!$href)
            continue;

        echo '<link rel="' . esc_attr($rel) . '" href="' . esc_url($href) . '"'
            . (!empty($i['type']) ? ' type="' . esc_attr($i['type']) . '"' : '')
            . (!empty($i['sizes']) ? ' sizes="' . esc_attr($i['sizes']) . '"' : '')
            . (!empty($i['color']) ? ' color="' . esc_attr($i['color']) . '"' : '')
            . " />\n";
    }
}

// Print early so our links (or core's via virtual Site Icon) take precedence.
add_action('admin_head', 'yooadmin_print_admin_favicon_links', 0);
add_action('login_head', 'yooadmin_print_admin_favicon_links', 0);
