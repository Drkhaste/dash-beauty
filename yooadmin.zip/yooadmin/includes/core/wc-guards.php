<?php
/**
 * YOOAdmin - WooCommerce guards and route detection
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * True on WooCommerce admin screens (classic & wc-admin).
 */
function yooadmin_is_wc_screen(): bool {
    // Quick URL check
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only check, no state change.
    if (isset($_GET['page'])) {
        $page = sanitize_text_field(wp_unslash($_GET['page']));
        if (strpos($page, 'wc-admin') !== false || strpos($page, 'woocommerce') !== false) {
            return true;
        }
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    // Screen object check
    if (function_exists('get_current_screen')) {
        try {
            $s = get_current_screen();
            if ($s) {
                $id = (string) $s->id;
                if (strpos($id, 'woocommerce') !== false || strpos($id, 'wc-admin') !== false) {
                    return true;
                }
            }
        } catch (Throwable $e) {}
    }

    return false;
}

/**
 * Detect heavy wc-admin SPA pages where we should not inject our shell/CSS.
 * e.g. /customize-store, /launch-your-store
 */
function yooadmin_is_wc_heavy_spa_page(): bool {
    if (!is_admin()) return false;

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only check
    $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
    if ($page !== 'wc-admin') return false;

    // Avoid over-sanitizing path (keep slashes), just strip tags & trim
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only check, no state change.
    $path = isset($_GET['path']) ? sanitize_text_field(wp_unslash($_GET['path'])) : '';

    return (
        strpos($path, '/customize-store') === 0 ||
        strpos($path, '/launch-your-store') === 0 ||
        strpos($path, '/setup-wizard') === 0 
    );
}
