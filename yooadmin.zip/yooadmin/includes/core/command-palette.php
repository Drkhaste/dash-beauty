<?php
/**
 * YOOAdmin — WordPress 7 command palette integration.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Inline JS: bind YOOAdmin Ctrl+K trigger after WP initializes the palette (once).
 *
 * @param bool $desktop_bridge When true, forward to Desktop Mode shell palette.
 */
function yooadmin_get_command_palette_bind_js(bool $desktop_bridge = false): string
{
    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $js_path   = plugin_dir_path($base_file) . 'assets/js/admin/command-palette-bind.js';

    if (!is_readable($js_path)) {
        return '';
    }

    $js = (string) file_get_contents($js_path);

    return str_replace(
        '__DESKTOP_BRIDGE__',
        $desktop_bridge ? 'true' : 'false',
        $js
    );
}

/**
 * Enqueue WP command palette assets + YOOAdmin skin (after admin menu is ready).
 */
function yooadmin_enqueue_command_palette_integration(): void
{
    if (!is_admin() || !is_user_logged_in()) {
        return;
    }

    if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
        return;
    }

    $desktop_bridge = function_exists('yooadmin_should_bridge_command_palette_to_desktop')
        && yooadmin_should_bridge_command_palette_to_desktop();

    $bind_handle = '';

    if ($desktop_bridge) {
        if (!wp_script_is('yooadmin-admin-core', 'enqueued') && !wp_script_is('yp-admin-core-essential', 'enqueued')) {
            return;
        }
        $bind_handle = wp_script_is('yooadmin-admin-core', 'enqueued') ? 'yooadmin-admin-core' : 'yp-admin-core-essential';
    } else {
        if (!yooadmin_command_palette_is_available()) {
            return;
        }

        // Core already hooks admin_enqueue_scripts @10 — calling again duplicates
        // initializeCommandPalette() and breaks Ctrl+K + the modal entirely.
        if (!wp_script_is('wp-core-commands', 'enqueued')) {
            yooadmin_enqueue_command_palette_assets();
        }

        if (!wp_script_is('wp-core-commands', 'enqueued')) {
            return;
        }

        $bind_handle = 'wp-core-commands';
    }

    $bind_js = yooadmin_get_command_palette_bind_js($desktop_bridge);
    if ($bind_js === '') {
        return;
    }

    wp_add_inline_script(
        $bind_handle,
        $bind_js,
        'after'
    );

    if ($desktop_bridge) {
        return;
    }

    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $dir       = plugin_dir_path($base_file);
    $url       = plugin_dir_url($base_file);
    $css_rel   = 'assets/css/admin/command-palette-yooadmin.css';

    if (file_exists($dir . $css_rel)) {
        $css_deps = wp_style_is('wp-commands', 'registered') ? ['wp-commands'] : [];
        wp_enqueue_style(
            'yooadmin-command-palette',
            $url . $css_rel,
            $css_deps,
            (string) filemtime($dir . $css_rel)
        );
    }
}
add_action('admin_enqueue_scripts', 'yooadmin_enqueue_command_palette_integration', 100);
