<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

function yooadmin_custom_login_uses_standalone_page(): bool {
    if (!function_exists('yooadmin_custom_login_is_enabled') || !yooadmin_custom_login_is_enabled()) {
        return false;
    }

    return (bool) apply_filters('yooadmin_custom_login_use_standalone_page', true);
}

/**
 * Public URL for the standalone login screen (pretty or query style).
 *
 * @return string
 */
function yooadmin_standalone_login_url(): string {
    $pretty = (string) get_option('permalink_structure', '');
    if ($pretty !== '') {
        return user_trailingslashit(home_url('/yooadmin-login/'));
    }

    return add_query_arg('yooadmin_standalone_login', '1', home_url('/'));
}

function yooadmin_standalone_login_public_url(): string {
    if (function_exists('yooadmin_hidden_login_entry_is_enabled') && yooadmin_hidden_login_entry_is_enabled()
        && function_exists('yooadmin_hidden_login_entry_url')) {
        return yooadmin_hidden_login_entry_url();
    }

    return yooadmin_standalone_login_url();
}

function yooadmin_login_uses_custom_logout_redirect(): bool {
    if (function_exists('yooadmin_hidden_login_entry_is_enabled') && yooadmin_hidden_login_entry_is_enabled()) {
        return true;
    }

    return function_exists('yooadmin_custom_login_uses_standalone_page') && yooadmin_custom_login_uses_standalone_page()
        && function_exists('yooadmin_custom_login_is_enabled') && yooadmin_custom_login_is_enabled();
}

function yooadmin_login_post_logout_redirect_url(): string {
    if (!yooadmin_login_uses_custom_logout_redirect()) {
        return home_url('/');
    }

    return yooadmin_standalone_login_public_url();
}

/**
 * Whether front-end login GET flows should use the branded standalone screen (hidden entry or /yooadmin-login/).
 */
function yooadmin_login_routes_through_standalone_page(): bool {
    return function_exists('yooadmin_custom_login_uses_standalone_page')
        && yooadmin_custom_login_uses_standalone_page()
        && function_exists('yooadmin_custom_login_is_enabled')
        && yooadmin_custom_login_is_enabled();
}

/**
 * @param array<string, mixed> $query Parsed wp-login.php query arguments.
 */
function yooadmin_login_prefers_standalone_for_query(array $query): bool {
    if (!yooadmin_login_routes_through_standalone_page()) {
        return false;
    }

    $action = isset($query['action']) ? sanitize_key((string) $query['action']) : '';

    $always_core = ['logout', 'confirm_admin_email', 'postpass', 'register', 'validate_2fa'];
    if (in_array($action, $always_core, true)) {
        return false;
    }

    if (
        isset($query['yooadmin_email_recovered'])
        || isset($query['yooadmin_2fa_revalidated'])
        || isset($query['recovered_login'])
    ) {
        return true;
    }

    $standalone_actions = [
        'login',
        'lostpassword',
        'retrievepassword',
        'rp',
        'resetpass',
        'checkemail',
        'yooadmin_recover_email',
    ];
    if ($action === '' || in_array($action, $standalone_actions, true)) {
        return true;
    }

    if (isset($query['key']) || isset($query['login']) || isset($query['reauth'])) {
        return true;
    }

    return !empty($query['yooadmin_hl_gate']);
}

/**
 * Password-reset link for account emails (standalone, hidden entry, or core wp-login).
 *
 * @param array<string, scalar|null> $extra_args Optional extra query arguments.
 */
function yooadmin_login_password_reset_url(string $user_login, string $key, WP_User $user, array $extra_args = []): string {
    $locale = get_user_locale($user);
    $args   = array_merge(
        [
            'login'   => $user_login,
            'key'     => $key,
            'action'  => 'rp',
            'wp_lang' => $locale,
        ],
        $extra_args
    );

    if (yooadmin_login_routes_through_standalone_page()) {
        return add_query_arg($args, yooadmin_standalone_login_public_url());
    }

    if (
        function_exists('yooadmin_hidden_login_entry_is_enabled')
        && yooadmin_hidden_login_entry_is_enabled()
        && function_exists('yooadmin_hidden_login_entry_should_block_visitor')
        && yooadmin_hidden_login_entry_should_block_visitor()
        && function_exists('yooadmin_hidden_login_entry_url')
    ) {
        return add_query_arg($args, yooadmin_hidden_login_entry_url());
    }

    return network_site_url(
        'wp-login.php?login=' . rawurlencode($user_login)
        . '&key=' . rawurlencode($key)
        . '&action=rp&wp_lang=' . rawurlencode($locale),
        'login'
    );
}

/**
 * Public URL for the “Forgot password?” step.
 *
 * Standalone YOOAdmin reset UI when custom login is on; hidden-entry or core wp-login.php otherwise.
 *
 * @param array<string, scalar|null> $extra_args Optional query arguments.
 */
function yooadmin_login_lostpassword_url(array $extra_args = []): string {
    $args = array_merge(['action' => 'lostpassword'], $extra_args);

    if (
        function_exists('yooadmin_custom_login_uses_standalone_page')
        && yooadmin_custom_login_uses_standalone_page()
        && function_exists('yooadmin_custom_login_is_enabled')
        && yooadmin_custom_login_is_enabled()
    ) {
        return add_query_arg($args, yooadmin_standalone_login_public_url());
    }

    if (
        function_exists('yooadmin_hidden_login_entry_is_enabled')
        && yooadmin_hidden_login_entry_is_enabled()
        && function_exists('yooadmin_hidden_login_entry_should_block_visitor')
        && yooadmin_hidden_login_entry_should_block_visitor()
        && function_exists('yooadmin_hidden_login_entry_url')
    ) {
        return add_query_arg($args, yooadmin_hidden_login_entry_url());
    }

    $base = site_url('wp-login.php?action=lostpassword', 'login');

    return add_query_arg($extra_args, $base);
}

/**
 * @param string $lostpassword_url Default lost-password URL.
 * @param string $redirect         Redirect target after reset.
 */
function yooadmin_login_filter_lostpassword_url($lostpassword_url, $redirect): string {
    unset($lostpassword_url);

    $args = [];
    $redirect = is_string($redirect) ? wp_validate_redirect($redirect, '') : '';
    if ($redirect !== '') {
        $args['redirect_to'] = $redirect;
    }

    return yooadmin_login_lostpassword_url($args);
}
add_filter('lostpassword_url', 'yooadmin_login_filter_lostpassword_url', 10, 2);

/**
 * @param string  $redirect_to           Sanitized redirect URL.
 * @param string  $requested_redirect_to Requested redirect URL.
 * @param WP_User $user                  User being logged out.
 */
function yooadmin_login_filter_logout_redirect($redirect_to, $requested_redirect_to, $user): string {
    unset($requested_redirect_to, $user);

    if (!yooadmin_login_uses_custom_logout_redirect()) {
        return (string) $redirect_to;
    }

    return yooadmin_login_post_logout_redirect_url();
}
add_filter('logout_redirect', 'yooadmin_login_filter_logout_redirect', 10, 3);

/**
 * Whether a redirect target is the standalone login URL (pretty or ?yooadmin_standalone_login=1).
 *
 * @param string $url Absolute or relative URL.
 */
function yooadmin_standalone_login_is_url_the_standalone_screen(string $url): bool {
    $url = trim($url);
    if ($url === '') {
        return false;
    }
    $candidate = function_exists('yooadmin_standalone_login_normalize_redirect_url')
        ? yooadmin_standalone_login_normalize_redirect_url($url)
        : $url;
    if ($candidate === '') {
        return false;
    }
    $canonical = yooadmin_standalone_login_url();
    if ($canonical !== '' && untrailingslashit($candidate) === untrailingslashit($canonical)) {
        return true;
    }
    $parts = wp_parse_url($candidate);
    if (!is_array($parts) || empty($parts['query'])) {
        return false;
    }
    parse_str((string) $parts['query'], $q);

    return isset($q['yooadmin_standalone_login']) && (string) $q['yooadmin_standalone_login'] === '1';
}

/**
 * @param string           $redirect_to           Sanitized redirect URL.
 * @param string           $requested_redirect_to Original request value.
 * @param WP_User|WP_Error $user                  User or error.
 */
function yooadmin_standalone_login_filter_login_redirect($redirect_to, $requested_redirect_to, $user): string {
    if (!function_exists('yooadmin_custom_login_is_enabled') || yooadmin_custom_login_is_enabled()) {
        return $redirect_to;
    }
    if ($user instanceof WP_Error) {
        return $redirect_to;
    }
    if (yooadmin_standalone_login_is_url_the_standalone_screen((string) $redirect_to)) {
        return admin_url();
    }
    if (yooadmin_standalone_login_is_url_the_standalone_screen((string) $requested_redirect_to)) {
        return admin_url();
    }

    return $redirect_to;
}
add_filter('login_redirect', 'yooadmin_standalone_login_filter_login_redirect', 5, 3);

/**
 * Register rewrite rule + query var.
 */
function yooadmin_standalone_login_register_rewrites(): void {
    add_rewrite_rule('^yooadmin-login/?$', 'index.php?yooadmin_standalone_login=1', 'top');
}
add_action('init', 'yooadmin_standalone_login_register_rewrites', 9);

/**
 * @param string[] $vars
 * @return string[]
 */
function yooadmin_standalone_login_query_vars(array $vars): array {
    $vars[] = 'yooadmin_standalone_login';

    return $vars;
}
add_filter('query_vars', 'yooadmin_standalone_login_query_vars');

/**
 * Signature for when standalone login rewrite rules must be flushed.
 */
function yooadmin_standalone_login_get_rewrite_flush_signature(): string {
    $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : (array) get_option('yooadmin_options', []);
    $parts = [
        defined('YOOADMIN_VERSION') ? (string) YOOADMIN_VERSION : '0',
        (string) get_option('permalink_structure', ''),
        !empty($opts['login_page_enabled']) ? '1' : '0',
    ];

    return md5(implode('|', $parts));
}

/**
 * Whether the current request path is /yooadmin-login/ (pretty permalinks).
 */
function yooadmin_standalone_login_request_path_matches(): bool {
    if ((string) get_option('permalink_structure', '') === '') {
        return false;
    }

    $expected = wp_parse_url(home_url('/yooadmin-login/'), PHP_URL_PATH);
    if (!is_string($expected) || $expected === '') {
        return false;
    }
    $expected = untrailingslashit($expected);

    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Path segment only; sanitized below.
    $req = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
    $path = wp_parse_url(sanitize_text_field((string) $req), PHP_URL_PATH);
    if (!is_string($path) || $path === '') {
        return false;
    }

    return strcasecmp(untrailingslashit($path), $expected) === 0;
}

/**
 * When rewrite rules are stale, map /yooadmin-login/ before WordPress returns 404.
 *
 * @param WP $wp Current environment instance.
 */
function yooadmin_standalone_login_parse_request($wp): void {
    if (!($wp instanceof WP) || is_admin()) {
        return;
    }
    if ((string) get_option('permalink_structure', '') === '') {
        return;
    }
    if (!function_exists('yooadmin_custom_login_is_enabled') || !yooadmin_custom_login_is_enabled()) {
        return;
    }
    if (!empty($wp->query_vars['yooadmin_standalone_login'])) {
        return;
    }
    if (!yooadmin_standalone_login_request_path_matches()) {
        return;
    }

    $wp->query_vars['yooadmin_standalone_login'] = '1';
}
add_action('parse_request', 'yooadmin_standalone_login_parse_request', 0);

/**
 * Prevent 404 when pretty permalinks were not flushed yet.
 *
 * @param bool     $preempt  Whether to short-circuit 404 handling.
 * @param WP_Query $wp_query Main query.
 */
function yooadmin_standalone_login_pre_handle_404($preempt, $wp_query) {
    if ($preempt) {
        return $preempt;
    }
    if (!($wp_query instanceof WP_Query) || !$wp_query->is_main_query()) {
        return $preempt;
    }
    if (!function_exists('yooadmin_custom_login_is_enabled') || !yooadmin_custom_login_is_enabled()) {
        return $preempt;
    }
    if (yooadmin_standalone_login_request_path_matches()) {
        return true;
    }

    return $preempt;
}
add_filter('pre_handle_404', 'yooadmin_standalone_login_pre_handle_404', 10, 2);

/**
 * Flush rewrite rules once per plugin version so /yooadmin-login/ works without a manual Permalinks save.
 */
function yooadmin_standalone_login_maybe_flush_rewrite_rules(): void {
    $opt = 'yooadmin_standalone_login_rewrite_signature';
    $sig = yooadmin_standalone_login_get_rewrite_flush_signature();
    if (get_option($opt, '') === $sig) {
        return;
    }
    yooadmin_standalone_login_flush_rewrite_rules();
    update_option($opt, $sig);
    delete_option('yooadmin_standalone_login_rewrite_rules_ver');
}
add_action('init', 'yooadmin_standalone_login_maybe_flush_rewrite_rules', 999);

/**
 * Re-flush when custom login is toggled or permalink structure changes.
 *
 * @param mixed $old_value Previous option value.
 * @param mixed $new_value New option value.
 */
function yooadmin_standalone_login_on_options_updated($old_value, $new_value): void {
    $old = is_array($old_value) ? $old_value : [];
    $new = is_array($new_value) ? $new_value : [];
    $old_login = !empty($old['login_page_enabled']);
    $new_login = !empty($new['login_page_enabled']);
    if ($old_login === $new_login && $new_login) {
        return;
    }
    if ($new_login || $old_login) {
        yooadmin_standalone_login_flush_rewrite_rules();
        update_option('yooadmin_standalone_login_rewrite_signature', 'yooadmin');
        delete_option('yooadmin_standalone_login_rewrite_rules_ver');
    }
}
add_action('update_option_yooadmin_options', 'yooadmin_standalone_login_on_options_updated', 10, 2);

/**
 * @param mixed $old_value Previous permalink structure.
 * @param mixed $new_value New permalink structure.
 */
function yooadmin_standalone_login_on_permalink_structure_updated($old_value, $new_value): void {
    if ((string) $old_value === (string) $new_value) {
        return;
    }
    yooadmin_standalone_login_flush_rewrite_rules();
    update_option('yooadmin_standalone_login_rewrite_signature', 'yooadmin');
    delete_option('yooadmin_standalone_login_rewrite_rules_ver');
}
add_action('update_option_permalink_structure', 'yooadmin_standalone_login_on_permalink_structure_updated', 10, 2);

/**
 * Whether the current front request is the standalone login URL (rewrite, query arg, or path fallback when rules were stale).
 */
function yooadmin_standalone_login_is_this_request(): bool {
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public GET for URL detection (cf. wp-login).
    if (isset($_GET['yooadmin_standalone_login']) && '1' === sanitize_text_field(wp_unslash($_GET['yooadmin_standalone_login']))) {
        return true;
    }

    if (yooadmin_standalone_login_request_path_matches()) {
        return true;
    }

    if (function_exists('yooadmin_hidden_login_entry_is_secret_request') && yooadmin_hidden_login_entry_is_secret_request()) {
        return true;
    }

    // get_query_var() requires a parsed main query (not available during pre_determine_locale).
    global $wp_query;
    if ($wp_query instanceof WP_Query) {
        $qv = (int) get_query_var('yooadmin_standalone_login', 0);
        if ($qv === 1) {
            return true;
        }
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended -- End URL-detection GET scope.

    return false;
}

/**
 * Whether the current request is a standalone login AJAX action.
 */
function yooadmin_standalone_login_is_ajax_request(): bool {
    if (!defined('DOING_AJAX') || !DOING_AJAX) {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Action slug routing only.
    if (!isset($_REQUEST['action'])) {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Action slug routing only.
    $action = sanitize_key(wp_unslash((string) $_REQUEST['action']));

    return strpos($action, 'yooadmin_sl_') === 0;
}

/**
 * Current full request URL (path + query) for standalone routing.
 *
 * @return string
 */
function yooadmin_standalone_login_get_request_url(): string {
    $host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : '';
    $uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
    if ($host === '') {
        return home_url('/');
    }
    $scheme = is_ssl() ? 'https' : 'http';

    return $scheme . '://' . $host . $uri;
}

/**
 * Path prefix for the resetpass cookie (mirrors wp-login.php).
 *
 * @return string
 */
function yooadmin_standalone_login_rp_cookie_path(): string {
    if (!isset($_SERVER['REQUEST_URI'])) {
        return '';
    }
    list($rp_path) = explode('?', sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])), 2);

    return $rp_path;
}

/**
 * When the email link opens the standalone URL with key+login, store the cookie and redirect (same as core wp-login.php).
 */
function yooadmin_standalone_login_maybe_set_rp_cookie(): void {
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET key/login from emailed reset link (core-style).
    if (!isset($_GET['key'], $_GET['login'])) {
        return;
    }

    $login_q = sanitize_text_field(wp_unslash($_GET['login']));
    $key_q = sanitize_text_field(wp_unslash($_GET['key']));
    // phpcs:enable WordPress.Security.NonceVerification.Recommended -- End reset-link GET scope.
    $value = sprintf('%s:%s', $login_q, $key_q);
    $rp_cookie = 'wp-resetpass-' . COOKIEHASH;
    $rp_path = yooadmin_standalone_login_rp_cookie_path();
    setcookie($rp_cookie, $value, 0, $rp_path, COOKIE_DOMAIN, is_ssl(), true);

    $here = yooadmin_standalone_login_get_request_url();
    $clean = remove_query_arg(['key', 'login'], $here);
    $parts = wp_parse_url($clean);
    $q = [];
    if (!empty($parts['query'])) {
        parse_str((string) $parts['query'], $q);
    }
    if (empty($q['action'])) {
        $clean = add_query_arg('action', 'resetpass', $clean);
    }
    wp_safe_redirect($clean);
    exit;
}

/**
 * Invalid or missing reset session: clear cookie and send users to the lost-password step on the standalone URL.
 */
function yooadmin_standalone_login_maybe_redirect_invalid_rp_session(): void {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- GET action slug for reset routing only.
    $ga = isset($_GET['action']) ? sanitize_key(wp_unslash($_GET['action'])) : '';
    if (!in_array($ga, ['rp', 'resetpass'], true)) {
        return;
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Handled by maybe_set_rp_cookie first.
    if (isset($_GET['key'])) {
        return;
    }

    $rp_cookie = 'wp-resetpass-' . COOKIEHASH;
    $rp_path = yooadmin_standalone_login_rp_cookie_path();

    $rp_cookie_val = isset($_COOKIE[$rp_cookie]) ? sanitize_text_field(wp_unslash($_COOKIE[$rp_cookie])) : '';
    if ($rp_cookie_val === '' || strpos($rp_cookie_val, ':') <= 0) {
        wp_safe_redirect(
            add_query_arg(
                [
                    'action' => 'lostpassword',
                    'error'  => 'invalidkey',
                ],
                yooadmin_standalone_login_public_url()
            )
        );
        exit;
    }

    list($rp_login, $rp_key) = explode(':', $rp_cookie_val, 2);
    $user = check_password_reset_key($rp_key, $rp_login);

    if ($user && !is_wp_error($user)) {
        return;
    }

    setcookie($rp_cookie, ' ', time() - YEAR_IN_SECONDS, $rp_path, COOKIE_DOMAIN, is_ssl(), true);

    $err = 'invalidkey';
    if (is_wp_error($user) && $user->get_error_code() === 'expired_key') {
        $err = 'expiredkey';
    }

    wp_safe_redirect(
        add_query_arg(
            [
                'action' => 'lostpassword',
                'error'  => $err,
            ],
            yooadmin_standalone_login_public_url()
        )
    );
    exit;
}

/**
 * Decoded reset key + login from cookie when the key is still valid.
 *
 * @return array{rp_login: string, rp_key: string, user: WP_User}|null
 */
function yooadmin_standalone_login_get_valid_rp_session(): ?array {
    $rp_cookie = 'wp-resetpass-' . COOKIEHASH;
    $rp_cookie_val = isset($_COOKIE[$rp_cookie]) ? sanitize_text_field(wp_unslash($_COOKIE[$rp_cookie])) : '';
    if ($rp_cookie_val === '' || strpos($rp_cookie_val, ':') <= 0) {
        return null;
    }
    list($rp_login, $rp_key) = explode(':', $rp_cookie_val, 2);

    return yooadmin_standalone_login_validate_rp_credentials($rp_login, $rp_key);
}

/**
 * Validate reset credentials (cookie or AJAX POST fields).
 *
 * @return array{rp_login: string, rp_key: string, user: WP_User}|null
 */
function yooadmin_standalone_login_validate_rp_credentials(string $rp_login, string $rp_key): ?array {
    $rp_login = sanitize_user($rp_login);
    $rp_key   = sanitize_text_field($rp_key);
    if ($rp_login === '' || $rp_key === '') {
        return null;
    }

    $user = check_password_reset_key($rp_key, $rp_login);
    if (!$user || is_wp_error($user)) {
        return null;
    }

    return [
        'rp_login' => $rp_login,
        'rp_key'   => $rp_key,
        'user'     => $user,
    ];
}

/**
 * Reset session from cookie or posted rp_login/rp_key (AJAX cannot read path-scoped cookies).
 *
 * @return array{rp_login: string, rp_key: string, user: WP_User}|null
 */
function yooadmin_standalone_login_resolve_rp_session(): ?array {
    $sess = yooadmin_standalone_login_get_valid_rp_session();
    if ($sess !== null) {
        return $sess;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified by AJAX handler.
    $posted_key = isset($_POST['rp_key']) ? sanitize_text_field(wp_unslash($_POST['rp_key'])) : '';
    $posted_login = isset($_POST['rp_login']) ? sanitize_user(wp_unslash($_POST['rp_login'])) : '';
    // phpcs:enable WordPress.Security.NonceVerification.Missing

    if ($posted_key === '' || $posted_login === '') {
        return null;
    }

    return yooadmin_standalone_login_validate_rp_credentials($posted_login, $posted_key);
}

/**
 * Whether the current request is a 2FA revalidation step.
 */
function yooadmin_standalone_login_is_revalidate_request(): bool {
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login action slug.
    if (!isset($_GET['action'])) {
        return false;
    }

    return sanitize_key(wp_unslash((string) $_GET['action'])) === 'revalidate_2fa';
    // phpcs:enable WordPress.Security.NonceVerification.Recommended
}

/**
 * Output the standalone login / revalidate template.
 */
function yooadmin_standalone_login_render_page_template(): void {
    status_header(200);
    nocache_headers();

    if (!defined('YOOADMIN_DIR')) {
        if (is_user_logged_in()) {
            wp_safe_redirect(admin_url());
        } else {
            wp_safe_redirect(wp_login_url(admin_url()));
        }
        exit;
    }

    $tpl = YOOADMIN_DIR . 'templates/login/standalone-login.php';
    if (!is_readable($tpl)) {
        if (is_user_logged_in()) {
            wp_safe_redirect(admin_url());
            exit;
        }
        wp_safe_redirect(wp_login_url(admin_url()));
        exit;
    }

    if (!headers_sent()) {
        header('X-Robots-Tag: noindex, nofollow', true);
    }

    require $tpl;
    exit;
}

/**
 * Serve the standalone template and exit.
 */
function yooadmin_standalone_login_template_redirect(): void {
    if (is_admin()) {
        return;
    }
    if (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
        return;
    }
    if (defined('REST_REQUEST') && REST_REQUEST) {
        return;
    }

    if (!yooadmin_standalone_login_is_this_request()) {
        return;
    }

    if (!function_exists('yooadmin_custom_login_is_enabled') || !yooadmin_custom_login_is_enabled()) {
        if (function_exists('yooadmin_hidden_login_entry_is_secret_request') && yooadmin_hidden_login_entry_is_secret_request()) {
            nocache_headers();

            if (is_user_logged_in()) {
                $go = admin_url();
                // phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET redirect_to; public URL, no form nonce.
                if (function_exists('yooadmin_profile_is_public_email_confirm_request')
                    && yooadmin_profile_is_public_email_confirm_request()
                    && function_exists('yooadmin_public_login_request_url')) {
                    $go = yooadmin_public_login_request_url();
                } elseif (isset($_GET['redirect_to'])) {
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passed to wp_validate_redirect().
                    $maybe = wp_validate_redirect(wp_unslash($_GET['redirect_to']), admin_url());
                    if (is_string($maybe) && $maybe !== '' && !yooadmin_standalone_login_is_url_the_standalone_screen($maybe)) {
                        $go = $maybe;
                    }
                    if (function_exists('yooadmin_public_login_merge_orphaned_query_arg')) {
                        $go = yooadmin_public_login_merge_orphaned_query_arg($go, 'newuseremail');
                    }
                }
                // phpcs:enable WordPress.Security.NonceVerification.Recommended -- End GET redirect_to block.
                wp_safe_redirect($go);
                exit;
            }

            if (function_exists('yooadmin_hidden_login_entry_render_core_login_page')) {
                yooadmin_hidden_login_entry_render_core_login_page();
            }

            wp_safe_redirect(wp_login_url(admin_url()));
            exit;
        }

        nocache_headers();
        if (is_user_logged_in()) {
            if (
                function_exists('yooadmin_standalone_login_is_revalidate_request')
                && yooadmin_standalone_login_is_revalidate_request()
            ) {
                $reval_redirect = admin_url();
                // phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET redirect_to; public URL, no form nonce.
                if (isset($_GET['redirect_to'])) {
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passed to wp_validate_redirect().
                    $reval_redirect = wp_validate_redirect(wp_unslash($_GET['redirect_to']), admin_url());
                }
                // phpcs:enable WordPress.Security.NonceVerification.Recommended

                $reval_dest = function_exists('yooadmin_native_2fa_revalidate_login_url')
                    ? yooadmin_native_2fa_revalidate_login_url($reval_redirect)
                    : add_query_arg(
                        [
                            'action'      => 'revalidate_2fa',
                            'redirect_to' => $reval_redirect,
                        ],
                        function_exists('yooadmin_native_2fa_core_wp_login_url')
                            ? yooadmin_native_2fa_core_wp_login_url(['action' => 'revalidate_2fa'])
                            : site_url('wp-login.php?action=revalidate_2fa', 'login')
                    );

                wp_safe_redirect($reval_dest);
                exit;
            }

            $go = admin_url();
            // phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET redirect_to; public URL, no form nonce.
            if (function_exists('yooadmin_profile_is_public_email_confirm_request')
                && yooadmin_profile_is_public_email_confirm_request()
                && function_exists('yooadmin_public_login_request_url')) {
                $go = yooadmin_public_login_request_url();
            } elseif (isset($_GET['redirect_to'])) {
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Passed to wp_validate_redirect().
                $maybe = wp_validate_redirect(wp_unslash($_GET['redirect_to']), admin_url());
                if (is_string($maybe) && $maybe !== '' && !yooadmin_standalone_login_is_url_the_standalone_screen($maybe)) {
                    $go = $maybe;
                }
                if (function_exists('yooadmin_public_login_merge_orphaned_query_arg')) {
                    $go = yooadmin_public_login_merge_orphaned_query_arg($go, 'newuseremail');
                }
            }
            // phpcs:enable WordPress.Security.NonceVerification.Recommended -- End GET redirect_to block.
            wp_safe_redirect($go);
            exit;
        }
        wp_safe_redirect(wp_login_url(admin_url()));
        exit;
    }

    if (function_exists('yooadmin_custom_login_uses_standalone_page') && yooadmin_custom_login_uses_standalone_page()) {
        yooadmin_standalone_login_maybe_set_rp_cookie();
        yooadmin_standalone_login_maybe_redirect_invalid_rp_session();
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Logged-in bounce; public login query args.
    $interim_login = isset($_GET['interim-login']) ? sanitize_text_field(wp_unslash($_GET['interim-login'])) : '';
    if ($interim_login === '') {
        $sl_action_logged = isset($_GET['action']) ? sanitize_key(wp_unslash($_GET['action'])) : 'login';
        if (isset($_GET['key'])) {
            $sl_action_logged = 'resetpass';
        }
        if (is_user_logged_in()) {
            $reauth_get = isset($_GET['reauth']) ? sanitize_text_field(wp_unslash($_GET['reauth'])) : '';
            if ($reauth_get !== '1') {
                $logged_in_bounce = ['login', 'lostpassword', 'retrievepassword', 'checkemail'];
                if (in_array($sl_action_logged, $logged_in_bounce, true)) {
                    $redirect_to = admin_url();
                    if (isset($_GET['redirect_to'])) {
                        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Validated by wp_validate_redirect().
                        $redirect_to = wp_validate_redirect(wp_unslash($_GET['redirect_to']), admin_url());
                    }
                    nocache_headers();
                    wp_safe_redirect($redirect_to);
                    exit;
                }
            }
        }
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended -- End logged-in bounce block.

    yooadmin_standalone_login_render_page_template();
}
add_action('template_redirect', 'yooadmin_standalone_login_template_redirect', 0);

function yooadmin_standalone_login_redirect_from_wp_login(): void {
    if (!function_exists('yooadmin_custom_login_uses_standalone_page') || !yooadmin_custom_login_uses_standalone_page()) {
        return;
    }

    if (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
        return;
    }

    $method_raw = isset($_SERVER['REQUEST_METHOD']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'])) : 'GET';
    $method = strtoupper($method_raw);
    if ($method !== 'GET') {
        return;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- wp-login.php GET redirect; read-only routing.
    $interim_login = isset($_GET['interim-login']) ? sanitize_text_field(wp_unslash($_GET['interim-login'])) : '';
    if ($interim_login !== '') {
        return;
    }

    $action = isset($_GET['action']) ? sanitize_key(wp_unslash($_GET['action'])) : 'login';
    if (isset($_GET['key'])) {
        $action = 'resetpass';
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended -- End action detection.

    $allowed = ['login', 'lostpassword', 'retrievepassword', 'rp', 'resetpass', 'checkemail'];
    /**
     * Filters which `wp-login.php` GET actions are sent to the standalone login URL.
     *
     * @param string[] $allowed Action slugs.
     */
    $allowed = apply_filters('yooadmin_standalone_login_get_redirect_actions', $allowed);

    $hidden_login = function_exists('yooadmin_hidden_login_entry_is_enabled') && yooadmin_hidden_login_entry_is_enabled();
    if ($hidden_login && !yooadmin_login_routes_through_standalone_page()) {
        $allowed = array_values(array_intersect($allowed, ['revalidate_2fa']));
    }

    if (!in_array($action, $allowed, true)) {
        return;
    }

    $dest = yooadmin_standalone_login_public_url();
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Pass-through query to standalone URL (sanitized below).
    if (!empty($_GET) && is_array($_GET)) {
        $sanitized_get = [];
        foreach (wp_unslash($_GET) as $gk => $gv) {
            $g_key = sanitize_key((string) $gk);
            if ($g_key === '' || is_array($gv)) {
                continue;
            }
            $gv = (string) $gv;
            if ('redirect_to' === $g_key) {
                $sanitized_get[$g_key] = wp_sanitize_redirect($gv);
            } else {
                $sanitized_get[$g_key] = sanitize_text_field($gv);
            }
        }
        if (!empty($sanitized_get)) {
            $dest = add_query_arg($sanitized_get, $dest);
        }
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended -- End query pass-through.

    wp_safe_redirect($dest);
    exit;
}
add_action('login_init', 'yooadmin_standalone_login_redirect_from_wp_login', 0);

/**
 * @param string $login_url    Login URL.
 * @param string $redirect     Redirect destination.
 * @param mixed  $force_reauth Whether to force reauthentication.
 */
function yooadmin_standalone_login_filter_login_url($login_url, $redirect = '', $force_reauth = false) {
    if (!function_exists('yooadmin_custom_login_uses_standalone_page') || !yooadmin_custom_login_uses_standalone_page()) {
        return $login_url;
    }

    $url = yooadmin_standalone_login_url();
    $redirect = is_string($redirect) ? $redirect : '';
    if ($redirect !== '') {
        $url = add_query_arg('redirect_to', $redirect, $url);
    }
    if ($force_reauth) {
        $url = add_query_arg('reauth', '1', $url);
    }

    return $url;
}
add_filter('login_url', 'yooadmin_standalone_login_filter_login_url', 10, 3);

/**
 * Normalize redirect target to absolute URL for comparison.
 *
 * @param string $location Redirect location.
 * @return string
 */
function yooadmin_standalone_login_normalize_redirect_url(string $location): string {
    $location = wp_sanitize_redirect($location);
    if ($location === '') {
        return '';
    }
    if (preg_match('#^https?://#i', $location)) {
        return $location;
    }
    if (strpos($location, '//') === 0) {
        return (is_ssl() ? 'https:' : 'http:') . $location;
    }
    if (strpos($location, '/') === 0) {
        return home_url($location);
    }

    return home_url('/' . ltrim($location, '/'));
}

/**
 * @param string $location Absolute URL.
 * @return bool
 */
function yooadmin_standalone_login_is_wp_login_url(string $location): bool {
    $parts = wp_parse_url($location);
    if (empty($parts['path']) || stripos($parts['path'], 'wp-login.php') === false) {
        return false;
    }

    $home = wp_parse_url(home_url('/'));
    $loc_host = isset($parts['host']) ? strtolower((string) $parts['host']) : '';
    $home_host = isset($home['host']) ? strtolower((string) $home['host']) : '';
    if ($home_host !== '' && $loc_host !== '' && strcasecmp($loc_host, $home_host) !== 0) {
        return false;
    }

    return true;
}

/**
 * @param string[] $query Parsed query vars.
 * @return bool
 */
function yooadmin_standalone_login_redirect_must_use_core_wp_login(array $query): bool {
    $action = isset($query['action']) ? sanitize_key((string) $query['action']) : 'login';
    $bypass = [];
    /** @var string[] $bypass */
    $bypass = apply_filters('yooadmin_standalone_login_bypass_redirect_actions', $bypass);

    return in_array($action, $bypass, true);
}

/**
 * @param string $location Redirect location.
 * @param int    $status   HTTP status code.
 * @return string
 */
function yooadmin_standalone_login_filter_wp_redirect($location, $status) {
    if (!function_exists('yooadmin_custom_login_uses_standalone_page') || !yooadmin_custom_login_uses_standalone_page()) {
        return $location;
    }
    if (!function_exists('yooadmin_custom_login_is_enabled') || !yooadmin_custom_login_is_enabled()) {
        return $location;
    }

    $location = (string) $location;
    $abs = yooadmin_standalone_login_normalize_redirect_url($location);
    if ($abs === '' || !yooadmin_standalone_login_is_wp_login_url($abs)) {
        return $location;
    }

    $parts = wp_parse_url($abs);
    $query = [];
    if (!empty($parts['query'])) {
        parse_str((string) $parts['query'], $query);
    }

    if (yooadmin_standalone_login_redirect_must_use_core_wp_login($query)) {
        return $location;
    }

    $standalone = yooadmin_standalone_login_public_url();
    $merged = add_query_arg($query, $standalone);
    if (!empty($parts['fragment'])) {
        $merged .= '#' . $parts['fragment'];
    }

    return $merged;
}
add_filter('wp_redirect', 'yooadmin_standalone_login_filter_wp_redirect', 10, 2);

/**
 * @return bool
 */
function yooadmin_standalone_login_ajax_is_allowed(): bool {
    if (
        function_exists('yooadmin_custom_login_uses_standalone_page')
        && yooadmin_custom_login_uses_standalone_page()
        && function_exists('yooadmin_custom_login_is_enabled')
        && yooadmin_custom_login_is_enabled()
    ) {
        return true;
    }

    return yooadmin_standalone_login_two_factor_logged_in_ajax_allowed();
}

/**
 * Allow inline 2FA AJAX (revalidate / challenge) when the branded login page is off.
 */
function yooadmin_standalone_login_two_factor_logged_in_ajax_allowed(): bool {
    if (!is_user_logged_in() || !defined('DOING_AJAX') || !DOING_AJAX) {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Action slug only; nonce verified in handler.
    $action = isset($_REQUEST['action']) ? sanitize_key((string) wp_unslash($_REQUEST['action'])) : '';

    return in_array(
        $action,
        [
            'yooadmin_sl_validate_2fa',
            'yooadmin_sl_two_factor_challenge',
        ],
        true
    );
}

/**
 * User-facing message for wp_signon() error codes (AJAX login).
 *
 * @param string $code {@see WP_Error} code.
 */
function yooadmin_standalone_login_ajax_login_error_message(string $code): string {
    if ($code === 'rate_limited' && function_exists('yooadmin_login_rate_limit_exceeded_message')) {
        return yooadmin_login_rate_limit_exceeded_message('login');
    }

    $messages = [
        'failed'                  => __('Invalid username or incorrect password.', 'yooadmin'),
        'empty'                   => __('The username field is empty.', 'yooadmin'),
        'empty_password'          => __('The password field is empty.', 'yooadmin'),
        'invalid_email'           => __('Unknown email address.', 'yooadmin'),
        'invalid_username'        => __('Unknown username.', 'yooadmin'),
        'incorrect_password'      => __('The password you entered is incorrect.', 'yooadmin'),
        'expired'                 => __('Your session has expired. Please log in again.', 'yooadmin'),
        'authentication_failed'   => __('Authentication failed.', 'yooadmin'),
        'notavailable'            => __('Username is not available.', 'yooadmin'),
        'blog_not_found'          => __('Site not found.', 'yooadmin'),
        'test_cookie'             => __('Cookies are blocked or not supported. Enable cookies to log in.', 'yooadmin'),
        'empty_username'          => __('The username field is empty.', 'yooadmin'),
    ];

    return $messages[$code] ?? __('Login failed. Please try again.', 'yooadmin');
}

/**
 * @param string $code {@see WP_Error} code from retrieve_password().
 */
function yooadmin_standalone_login_ajax_lostpassword_error_message(string $code): string {
    $messages = [
        'empty_username'   => __('Enter a username or email address.', 'yooadmin'),
        'invalid_email'    => __('Invalid email address.', 'yooadmin'),
        'invalidcombo'     => __('Invalid username or email.', 'yooadmin'),
        'invalid_username' => __('Invalid username.', 'yooadmin'),
        'retrieve_pass_email_failure' => __('The email could not be sent.', 'yooadmin'),
    ];

    return $messages[$code] ?? __('Something went wrong. Please try again.', 'yooadmin');
}

/**
 * @param string $code Error code from reset validation.
 */
function yooadmin_standalone_login_ajax_reset_error_message(string $code): string {
    $messages = [
        'password_reset_empty_space' => __('The password cannot be a space or all spaces.', 'yooadmin'),
        'password_reset_mismatch'    => __('The passwords do not match.', 'yooadmin'),
        'password_reset_empty'       => __('Please enter a password.', 'yooadmin'),
        'invalidkey'                 => __('Your password reset link appears to be invalid.', 'yooadmin'),
        'bad_key'                    => __('Your password reset link appears to be invalid.', 'yooadmin'),
    ];

    return $messages[$code] ?? __('Something went wrong. Please try again.', 'yooadmin');
}

/**
 * Register a standalone-login AJAX handler for guests and logged-in users.
 *
 * WordPress routes admin-ajax.php to wp_ajax_* when a session exists; nopriv-only
 * handlers return "0" and the login UI shows a generic session-expired message.
 *
 * @param string   $action   AJAX action slug (without wp_ajax_ prefix).
 * @param callable $callback Handler callback.
 */
function yooadmin_standalone_login_register_ajax_handler(string $action, callable $callback): void {
    $wrapped = static function () use ($callback): void {
        if (function_exists('yooadmin_load_yooadmin_textdomain')) {
            $locale = function_exists('yooadmin_custom_login_get_login_locale')
                ? yooadmin_custom_login_get_login_locale()
                : null;
            yooadmin_load_yooadmin_textdomain($locale);
        }
        call_user_func($callback);
    };
    add_action('wp_ajax_nopriv_' . $action, $wrapped);
    add_action('wp_ajax_' . $action, $wrapped);
}

/**
 * Fresh AJAX nonce for standalone login requests.
 */
function yooadmin_standalone_login_create_ajax_nonce(): string {
    return wp_create_nonce('yooadmin_sl_ajax');
}

/**
 * Verify AJAX nonce.
 */
function yooadmin_standalone_login_ajax_verify_nonce(): void {
    if (!check_ajax_referer('yooadmin_sl_ajax', 'nonce', false)) {
        wp_send_json_error(
            [
                'code'    => 'invalid_nonce',
                'message' => __('Your session has expired. Please refresh the page and try again.', 'yooadmin'),
            ],
            403
        );
    }
}

/**
 * AJAX: sign in.
 */
function yooadmin_standalone_login_ajax_login(): void {
    yooadmin_standalone_login_ajax_verify_nonce();

    if (!yooadmin_standalone_login_ajax_is_allowed()) {
        wp_send_json_error(['code' => 'forbidden', 'message' => __('Not allowed.', 'yooadmin')], 403);
    }

    $turnstile = function_exists('yooadmin_login_turnstile_verify_request_or_fail')
        ? yooadmin_login_turnstile_verify_request_or_fail()
        : true;
    if (is_wp_error($turnstile)) {
        wp_send_json_error(
            [
                'code'    => 'captcha_failed',
                'message' => $turnstile->get_error_message(),
            ],
            403
        );
    }

    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified in yooadmin_standalone_login_ajax_verify_nonce().
    $log = isset($_POST['log']) ? sanitize_user(wp_unslash($_POST['log'])) : '';
    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Password string for wp_signon().
    $pwd = isset($_POST['pwd']) ? (string) wp_unslash($_POST['pwd']) : '';
    $remember = !empty($_POST['rememberme']);

    if ($log === '') {
        wp_send_json_error(
            [
                'code'    => 'empty_username',
                'message' => yooadmin_standalone_login_ajax_login_error_message('empty_username'),
            ]
        );
    }
    if ($pwd === '') {
        wp_send_json_error(
            [
                'code'    => 'empty_password',
                'message' => yooadmin_standalone_login_ajax_login_error_message('empty_password'),
            ]
        );
    }

    $rate = yooadmin_standalone_login_rate_limit_settings();
    if (!yooadmin_standalone_login_rate_limit_allows('login', $rate['login_max'], $rate['login_window'], $log)) {
        yooadmin_standalone_login_rate_limit_exceeded_response('login', $log);
    }

    $creds = [
        'user_login'    => $log,
        'user_password' => $pwd,
        'remember'      => $remember,
    ];

    if (function_exists('yooadmin_standalone_login_two_factor_suspend_external_login_handlers')) {
        yooadmin_standalone_login_two_factor_suspend_external_login_handlers();
    }

    // Keep the page AJAX nonce valid until 2FA completes (wp_signon must not set cookies yet).
    add_filter('send_auth_cookies', '__return_false', PHP_INT_MAX);

    $user = wp_signon($creds, is_ssl());

    remove_filter('send_auth_cookies', '__return_false', PHP_INT_MAX);

    $redirect_to = admin_url();
    if (isset($_POST['redirect_to']) && is_string($_POST['redirect_to'])) {
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Validated by wp_validate_redirect().
        $redirect_to = wp_validate_redirect(wp_unslash($_POST['redirect_to']), admin_url());
    }
    // phpcs:enable WordPress.Security.NonceVerification.Missing -- End AJAX login POST reads.

    if (is_string($redirect_to) && strpos($redirect_to, 'wp-admin') !== false) {
        $redirect_to = add_query_arg('yooadmin_login', '1', $redirect_to);
    }

    if (is_wp_error($user)) {
        $code = $user->get_error_code();
        $intercept_codes = function_exists('yooadmin_standalone_login_two_factor_wp_signon_intercept_codes')
            ? yooadmin_standalone_login_two_factor_wp_signon_intercept_codes()
            : [];

        if (in_array($code, $intercept_codes, true)) {
            $auth_user = get_user_by('login', $log);
            if (!$auth_user) {
                $auth_user = get_user_by('email', $log);
            }

            if (
                $auth_user instanceof WP_User
                && function_exists('yooadmin_standalone_login_user_requires_two_factor')
                && yooadmin_standalone_login_user_requires_two_factor($auth_user)
                && function_exists('yooadmin_standalone_login_two_factor_ajax_begin_response')
            ) {
                yooadmin_standalone_login_rate_limit_clear('login', $log);
                yooadmin_standalone_login_two_factor_ajax_begin_response($auth_user, $remember, $redirect_to);
            }
        }

        yooadmin_standalone_login_rate_limit_record_failure('login', $rate['login_window'], $log);
        wp_send_json_error(
            [
                'code'    => $code,
                'message' => yooadmin_standalone_login_ajax_login_error_message($code),
            ]
        );
    }

    if (
        $user instanceof WP_User
        && function_exists('yooadmin_standalone_login_user_requires_two_factor')
        && yooadmin_standalone_login_user_requires_two_factor($user)
        && function_exists('yooadmin_standalone_login_two_factor_ajax_begin_response')
    ) {
        yooadmin_standalone_login_rate_limit_clear('login', $log);
        yooadmin_standalone_login_two_factor_ajax_begin_response($user, $remember, $redirect_to);
    }

    yooadmin_standalone_login_rate_limit_clear('login', $log);

    if ($user instanceof WP_User) {
        wp_set_auth_cookie((int) $user->ID, $remember, is_ssl());
        wp_set_current_user((int) $user->ID);

        if (function_exists('yooadmin_user_switching_finalize_authenticated_session')) {
            yooadmin_user_switching_finalize_authenticated_session((int) $user->ID);
        }

        if (function_exists('yooadmin_email_recovery_consume_login_grace')) {
            yooadmin_email_recovery_consume_login_grace($user->user_login);
        }
    }

    wp_send_json_success(['redirect' => $redirect_to]);
}
yooadmin_standalone_login_register_ajax_handler('yooadmin_sl_login', 'yooadmin_standalone_login_ajax_login');

/**
 * AJAX: request password reset email.
 */
function yooadmin_standalone_login_ajax_lostpassword(): void {
    yooadmin_standalone_login_ajax_verify_nonce();

    if (!yooadmin_standalone_login_ajax_is_allowed()) {
        wp_send_json_error(['code' => 'forbidden', 'message' => __('Not allowed.', 'yooadmin')], 403);
    }

    if (function_exists('yooadmin_login_turnstile_protect_lostpassword') && yooadmin_login_turnstile_protect_lostpassword()) {
        $turnstile = function_exists('yooadmin_login_turnstile_verify_request_or_fail')
            ? yooadmin_login_turnstile_verify_request_or_fail()
            : true;
        if (is_wp_error($turnstile)) {
            wp_send_json_error(
                [
                    'code'    => 'captcha_failed',
                    'message' => $turnstile->get_error_message(),
                ],
                403
            );
        }
    }

    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified in yooadmin_standalone_login_ajax_verify_nonce().
    $user_login = isset($_POST['user_login']) ? sanitize_text_field(wp_unslash($_POST['user_login'])) : '';
    if (!is_string($user_login)) {
        $user_login = '';
    }
    // phpcs:enable WordPress.Security.NonceVerification.Missing -- End lost-password POST reads.

    $rate = yooadmin_standalone_login_rate_limit_settings();
    if (!yooadmin_standalone_login_rate_limit_allows('lostpassword', $rate['lostpassword_max'], $rate['lostpassword_window'], $user_login)) {
        yooadmin_standalone_login_rate_limit_exceeded_response('lostpassword', $user_login);
    }

    $result = retrieve_password($user_login);

    if (is_wp_error($result)) {
        yooadmin_standalone_login_rate_limit_record_failure('lostpassword', $rate['lostpassword_window'], $user_login);
        $code = $result->get_error_code();
        wp_send_json_error(
            [
                'code'    => $code,
                'message' => yooadmin_standalone_login_ajax_lostpassword_error_message($code),
            ]
        );
    }

    wp_send_json_success(
        [
            'message' => __('Check your email for a link to reset your password.', 'yooadmin'),
        ]
    );
}
yooadmin_standalone_login_register_ajax_handler('yooadmin_sl_lostpassword', 'yooadmin_standalone_login_ajax_lostpassword');

/**
 * AJAX: set new password (reset key session via cookie).
 */
function yooadmin_standalone_login_ajax_resetpass(): void {
    yooadmin_standalone_login_ajax_verify_nonce();

    if (!yooadmin_standalone_login_ajax_is_allowed()) {
        wp_send_json_error(['code' => 'forbidden', 'message' => __('Not allowed.', 'yooadmin')], 403);
    }

    $turnstile = function_exists('yooadmin_login_turnstile_verify_request_or_fail')
        ? yooadmin_login_turnstile_verify_request_or_fail()
        : true;
    if (is_wp_error($turnstile)) {
        wp_send_json_error(
            [
                'code'    => 'captcha_failed',
                'message' => $turnstile->get_error_message(),
            ],
            403
        );
    }

    $rate = yooadmin_standalone_login_rate_limit_settings();

    $sess = yooadmin_standalone_login_resolve_rp_session();
    if ($sess === null) {
        if (!yooadmin_standalone_login_rate_limit_allows('resetpass', $rate['resetpass_max'], $rate['resetpass_window'], '')) {
            yooadmin_standalone_login_rate_limit_exceeded_response('resetpass');
        }
        yooadmin_standalone_login_rate_limit_record_failure('resetpass', $rate['resetpass_window'], '');
        wp_send_json_error(
            [
                'code'    => 'invalidkey',
                'message' => yooadmin_standalone_login_ajax_reset_error_message('invalidkey'),
            ]
        );
    }

    $user = $sess['user'];
    $rp_key = $sess['rp_key'];
    $rate_id = is_object($user) && isset($user->user_login) ? (string) $user->user_login : '';

    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified in yooadmin_standalone_login_ajax_verify_nonce().
    $posted_key = isset($_POST['rp_key']) ? sanitize_text_field(wp_unslash($_POST['rp_key'])) : '';
    if (!hash_equals($rp_key, $posted_key)) {
        if (!yooadmin_standalone_login_rate_limit_allows('resetpass', $rate['resetpass_max'], $rate['resetpass_window'], $rate_id)) {
            yooadmin_standalone_login_rate_limit_exceeded_response('resetpass', $rate_id);
        }
        yooadmin_standalone_login_rate_limit_record_failure('resetpass', $rate['resetpass_window'], $rate_id);
        wp_send_json_error(
            [
                'code'    => 'bad_key',
                'message' => yooadmin_standalone_login_ajax_reset_error_message('bad_key'),
            ]
        );
    }

    if (!yooadmin_standalone_login_rate_limit_allows('resetpass', $rate['resetpass_max'], $rate['resetpass_window'], $rate_id)) {
        yooadmin_standalone_login_rate_limit_exceeded_response('resetpass', $rate_id);
    }

    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- New password fields; not for sanitize_text_field().
    $p1 = isset($_POST['pass1']) ? (string) wp_unslash($_POST['pass1']) : '';
    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Confirm password; same as core reset form.
    $p2 = isset($_POST['pass2']) ? (string) wp_unslash($_POST['pass2']) : '';
    // phpcs:enable WordPress.Security.NonceVerification.Missing -- End reset-password POST reads.

    $errors = new WP_Error();

    if ($p1 !== '') {
        $p1 = trim($p1);
        if ($p1 === '') {
            $errors->add(
                'password_reset_empty_space',
                __('The password cannot be a space or all spaces.', 'yooadmin')
            );
        }
    }

    if ($p1 !== '' && trim($p2) !== $p1) {
        $errors->add('password_reset_mismatch', __('The passwords do not match.', 'yooadmin'));
    }

    /** This action is documented in wp-login.php */
    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook name from wp-login.php.
    do_action('validate_password_reset', $errors, $user);

    if ($errors->has_errors()) {
        $code = $errors->get_error_code();
        $msg = $errors->get_error_message($code);
        if ($msg !== '') {
            $msg = wp_strip_all_tags($msg);
        } else {
            $msg = yooadmin_standalone_login_ajax_reset_error_message($code);
        }
        yooadmin_standalone_login_rate_limit_record_failure('resetpass', $rate['resetpass_window'], $rate_id);
        wp_send_json_error(['code' => $code, 'message' => $msg]);
    }

    if ($p1 === '') {
        yooadmin_standalone_login_rate_limit_record_failure('resetpass', $rate['resetpass_window'], $rate_id);
        wp_send_json_error(
            [
                'code'    => 'password_reset_empty',
                'message' => yooadmin_standalone_login_ajax_reset_error_message('password_reset_empty'),
            ]
        );
    }

    reset_password($user, $p1);
    yooadmin_standalone_login_rate_limit_clear('resetpass', $rate_id);

    $rp_cookie = 'wp-resetpass-' . COOKIEHASH;
    $rp_path = yooadmin_standalone_login_rp_cookie_path();
    setcookie($rp_cookie, ' ', time() - YEAR_IN_SECONDS, $rp_path, COOKIE_DOMAIN, is_ssl(), true);

    wp_send_json_success(
        [
            'redirect' => add_query_arg('checkemail', 'pass', yooadmin_standalone_login_public_url()),
            'message'  => __('Your password has been reset.', 'yooadmin'),
        ]
    );
}
yooadmin_standalone_login_register_ajax_handler('yooadmin_sl_resetpass', 'yooadmin_standalone_login_ajax_resetpass');

/**
 * On plugin activation: flush so `/yooadmin-login/` resolves when permalinks are on.
 */
function yooadmin_standalone_login_flush_rewrite_rules(): void {
    yooadmin_standalone_login_register_rewrites();
    flush_rewrite_rules(false);
    update_option('yooadmin_standalone_login_rewrite_signature', 'yooadmin');
    delete_option('yooadmin_standalone_login_rewrite_rules_ver');
}

/**
 * Human-readable notices from wp-login.php query args (after redirect back).
 *
 * @return string HTML fragments (already escaped).
 */
function yooadmin_standalone_login_get_notices_html(): string {
    $parts = [];

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
    if (!empty($_GET['yooadmin_email_recovered'])) {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
        if (isset($_GET['recovered_login'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only flash flag.
            $recovered_login = sanitize_user(wp_unslash((string) $_GET['recovered_login']), true);
        } else {
            $recovered_login = '';
        }

        if ($recovered_login !== '') {
            $parts[] = yooadmin_standalone_login_notice_wrap(
                'success',
                sprintf(
                    /* translators: %s: WordPress username */
                    __('Your account email was restored. Sign in with username %s and your password.', 'yooadmin'),
                    $recovered_login
                )
            );
        } else {
            $parts[] = yooadmin_standalone_login_notice_wrap(
                'success',
                __('Your account email was restored. Please sign in with your username and password.', 'yooadmin')
            );
        }
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
    if (!empty($_GET['loggedout']) && $_GET['loggedout'] === 'true') {
        $parts[] = yooadmin_standalone_login_notice_wrap('success', __('You are now logged out.', 'yooadmin'));
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
    if (!empty($_GET['registration']) && $_GET['registration'] === 'disabled') {
        $parts[] = yooadmin_standalone_login_notice_wrap('info', __('User registration is currently not allowed.', 'yooadmin'));
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
    $check = isset($_GET['checkemail']) ? sanitize_key(wp_unslash($_GET['checkemail'])) : '';
    if ($check === 'confirm') {
        $parts[] = yooadmin_standalone_login_notice_wrap(
            'success',
            __('Check your email for a link to reset your password.', 'yooadmin')
        );
    } elseif ($check === 'registered') {
        $parts[] = yooadmin_standalone_login_notice_wrap('success', __('Registration complete. Please check your email.', 'yooadmin'));
    } elseif ($check === 'pass') {
        /* translators: Password reset success message. */
        $parts[] = yooadmin_standalone_login_notice_wrap('success', __('Your password has been reset.', 'yooadmin'));
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
    if (!empty($_GET['reauth'])) {
        /* translators: Sign-in notice after redirect to wp-login. */
        $parts[] = yooadmin_standalone_login_notice_wrap('info', __('Please sign in to continue.', 'yooadmin'));
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
    $code = isset($_GET['login']) ? sanitize_key(wp_unslash($_GET['login'])) : '';
    $login_query_error_codes = [
        'failed',
        'empty',
        'empty_password',
        'invalid_email',
        'invalid_username',
        'incorrect_password',
        'expired',
        'authentication_failed',
        'notavailable',
        'blog_not_found',
        'rate_limited',
    ];
    if ($code !== '' && in_array($code, $login_query_error_codes, true)) {
        if ($code === 'rate_limited' && function_exists('yooadmin_login_rate_limit_exceeded_message')) {
            $msg = yooadmin_login_rate_limit_exceeded_message('login');
        } else {
            $msg = yooadmin_standalone_login_ajax_login_error_message($code);
        }
        $notice_type = $code === 'rate_limited' ? 'info' : 'error';
        $parts[] = yooadmin_standalone_login_notice_wrap($notice_type, $msg);
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
    $err = isset($_GET['error']) ? sanitize_key(wp_unslash($_GET['error'])) : '';
    if ($err !== '') {
        $err_msgs = [
            'empty_username'   => __('Enter a username or email address.', 'yooadmin'),
            'invalid_email'    => __('Invalid email address.', 'yooadmin'),
            'invalidcombo'     => __('Invalid username or email.', 'yooadmin'),
            'invalid_username' => __('Invalid username.', 'yooadmin'),
            'retrieve_pass_email_failure' => __('The email could not be sent.', 'yooadmin'),
            'invalidkey'       => __('Your password reset link appears to be invalid.', 'yooadmin'),
            'expiredkey'       => __('Your password reset link has expired.', 'yooadmin'),
            'expired_key'      => __('Your password reset link has expired.', 'yooadmin'),
            'password_reset_mismatch' => __('The passwords do not match.', 'yooadmin'),
            'password_reset_empty'    => __('Please enter a password.', 'yooadmin'),
        ];
        $default_err = $err_msgs[$err] ?? '';
        /**
         * Filters the message for a given `error` query arg on the standalone login page.
         *
         * @param string $message Default message (may be empty if unknown code).
         * @param string $err     Sanitized error code.
         */
        $msg = apply_filters('yooadmin_standalone_login_error_message', $default_err, $err);
        if ($msg === '') {
            $msg = __('Something went wrong. Please try again.', 'yooadmin');
        }
        $parts[] = yooadmin_standalone_login_notice_wrap('error', $msg);
    }

    $inner = implode('', $parts);
    if ($inner === '') {
        return '';
    }

    return '<div class="yoo-sl-messages yoo-sl-messages--fixed" id="yoo-sl-messages" role="region" aria-live="polite" aria-relevant="additions">' . $inner . '</div>';
}

/**
 * @param string $type success|error|info
 * @param string $text Already translated message.
 */
function yooadmin_standalone_login_notice_wrap(string $type, string $text): string {
    if ($type === 'error') {
        $class = 'yoo-sl-toast yoo-sl-toast--error';
        $icon  = 'dashicons-warning';
    } elseif ($type === 'success') {
        $class = 'yoo-sl-toast yoo-sl-toast--success';
        $icon  = 'dashicons-yes-alt';
    } else {
        $class = 'yoo-sl-toast yoo-sl-toast--info';
        $icon  = 'dashicons-info';
    }

    return '<div class="' . esc_attr($class) . '" data-yoo-sl-toast="' . esc_attr($type) . '" role="alert">'
        . '<span class="yoo-sl-toast__icon dashicons ' . esc_attr($icon) . '" aria-hidden="true"></span>'
        . '<div class="yoo-sl-toast__body">' . esc_html($text) . '</div>'
        . '<button type="button" class="yoo-sl-toast__close" aria-label="' . esc_attr__('Dismiss', 'yooadmin') . '">&times;</button>'
        . '</div>';
}
