<?php
/**
 * Late brand hover overrides (literal hex) — wins over CSS variable fallbacks.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_print_brand_hover_fix_css')) {
    /**
     * Print computed brand hover colors last in the page so hover matches Theme Settings.
     */
    function yooadmin_print_brand_hover_fix_css(): void
    {
        if (!is_user_logged_in()) {
            return;
        }

        if (!is_admin() && !(function_exists('is_admin_bar_showing') && is_admin_bar_showing())) {
            return;
        }

        if (!function_exists('yooadmin_get_brand_options') || !function_exists('yooadmin_get_brand_primary_600_hex')) {
            return;
        }

        $brand = yooadmin_get_brand_options();
        $primary = isset($brand['primary']) ? sanitize_hex_color((string) $brand['primary']) : '';
        if (!$primary) {
            $primary = '#eda934';
        }

        $hover = yooadmin_get_brand_primary_600_hex();
        $gradient = 'linear-gradient(180deg,' . $hover . ' 0%,' . $hover . ' 100%)';

        $turnstile_selectors = implode(
            ',',
            [
                '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .button.yp-yoo-btn--primary:hover',
                '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .button.yp-yoo-btn--primary:focus-visible',
                '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .yp-yoo-btn--primary:hover',
                '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .yp-yoo-btn--primary:focus-visible',
            ]
        );

        $css  = '<style id="yooadmin-brand-hover-fix">';
        $css .= $turnstile_selectors . '{background:' . esc_attr($gradient) . '!important;background-color:' . esc_attr($hover) . '!important;border:0!important;color:#fff!important;}';
        $css .= '#yps-sidebar .yps-focus-input:checked~.yps-focus-switch{background:' . esc_attr($primary) . '!important;}';
        $css .= '#yps-sidebar .yps-focus-label:hover .yps-focus-input:checked~.yps-focus-switch{background:' . esc_attr($hover) . '!important;}';
        $css .= '#wpadminbar #wp-admin-bar-yooadmin-focus-toggle>.ab-item:hover,#wpadminbar #wp-admin-bar-yooadmin-focus-toggle.hover>.ab-item{background:' . esc_attr($hover) . '!important;border-color:' . esc_attr($hover) . '!important;color:#fff!important;}';
        $css .= '</style>';

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from sanitized hex values above.
        echo $css;
    }
}

add_action('admin_footer', 'yooadmin_print_brand_hover_fix_css', 99999);
add_action('wp_footer', 'yooadmin_print_brand_hover_fix_css', 99999);
