<?php
/**
 * Custom admin URL — rewrite generated admin links to the custom base.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_custom_admin_url_filter_admin_url')) {
    /**
     * @param string $url     Complete URL.
     * @param string $path    Path relative to wp-admin.
     * @param int|null $blog_id Blog ID.
     * @return string
     */
    function yooadmin_custom_admin_url_filter_admin_url($url, $path, $blog_id): string {
        unset($blog_id);
        $path = (string) $path;
        if (function_exists('yooadmin_custom_admin_url_is_core_install_path')
            && yooadmin_custom_admin_url_is_core_install_path($path)) {
            return (string) $url;
        }

        return yooadmin_custom_admin_url_replace_in_url((string) $url);
    }
}
add_filter('admin_url', 'yooadmin_custom_admin_url_filter_admin_url', 10, 3);

if (!function_exists('yooadmin_custom_admin_url_filter_network_admin_url')) {
    /**
     * @param string $url     Complete URL.
     * @param string $path    Path relative to network admin.
     * @return string
     */
    function yooadmin_custom_admin_url_filter_network_admin_url($url, $path): string {
        unset($path);
        if (!is_multisite() || !function_exists('yooadmin_custom_admin_url_is_enabled') || !yooadmin_custom_admin_url_is_enabled()) {
            return $url;
        }

        $wp_base = yooadmin_custom_admin_url_network_wp_admin_base();
        $custom_base = yooadmin_custom_admin_url_custom_base();
        if ($custom_base === '' || strpos($url, $wp_base) !== 0) {
            return $url;
        }

        return $custom_base . substr($url, strlen($wp_base));
    }
}
add_filter('network_admin_url', 'yooadmin_custom_admin_url_filter_network_admin_url', 10, 2);

if (!function_exists('yooadmin_custom_admin_url_filter_site_url')) {
    /**
     * @param string      $url     Complete URL.
     * @param string      $path    Path relative to the site URL.
     * @param string|null $scheme  Scheme.
     * @param int|null    $blog_id Blog ID.
     * @return string
     */
    function yooadmin_custom_admin_url_filter_site_url($url, $path, $scheme, $blog_id): string {
        unset($scheme, $blog_id);
        $path = (string) $path;
        if (!function_exists('yooadmin_custom_admin_url_is_enabled') || !yooadmin_custom_admin_url_is_enabled()) {
            return $url;
        }
        if (function_exists('yooadmin_custom_admin_url_is_core_install_path')
            && yooadmin_custom_admin_url_is_core_install_path($path)) {
            return $url;
        }

        if ($path !== '' && stripos($path, 'wp-admin') === false && stripos((string) $url, '/wp-admin') === false) {
            return $url;
        }

        return yooadmin_custom_admin_url_replace_in_url((string) $url);
    }
}
add_filter('site_url', 'yooadmin_custom_admin_url_filter_site_url', 10, 4);

if (!function_exists('yooadmin_custom_admin_url_filter_wp_redirect')) {
    /**
     * @param string $location Redirect target.
     * @param int    $status   HTTP status.
     * @return string
     */
    function yooadmin_custom_admin_url_filter_wp_redirect($location, $status): string {
        unset($status);
        if (!function_exists('yooadmin_custom_admin_url_is_enabled') || !yooadmin_custom_admin_url_is_enabled()) {
            return $location;
        }

        if (defined('YOOADMIN_CUSTOM_ADMIN_BOOTSTRAP') && YOOADMIN_CUSTOM_ADMIN_BOOTSTRAP) {
            return $location;
        }

        $abs = wp_validate_redirect($location, false);
        if ($abs === false) {
            return $location;
        }

        if (function_exists('yooadmin_custom_admin_url_is_core_install_path')) {
            $redirect_path = (string) wp_parse_url($abs, PHP_URL_PATH);
            $wp_path = (string) wp_parse_url(yooadmin_custom_admin_url_wp_admin_base(), PHP_URL_PATH);
            if ($redirect_path !== '' && $wp_path !== '' && str_starts_with($redirect_path, $wp_path)) {
                $rel = ltrim(substr($redirect_path, strlen($wp_path)), '/');
                if (yooadmin_custom_admin_url_is_core_install_path($rel)) {
                    return $abs;
                }
            }
        }

        return yooadmin_custom_admin_url_replace_in_url($abs);
    }
}
add_filter('wp_redirect', 'yooadmin_custom_admin_url_filter_wp_redirect', 10, 2);
