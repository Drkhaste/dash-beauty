<?php
/**
 * YOOAdmin network site info page (multisite + Focus Mode).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_site_info_text_domain')) {
    function yooadmin_network_site_info_text_domain(): string
    {
        return function_exists('yooadmin_multisite_text_domain')
            ? yooadmin_multisite_text_domain()
            : 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_site_info_page_slug')) {
    function yooadmin_network_site_info_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_site_info_page_slug', 'yooadmin-network-site-info');
    }
}

if (!function_exists('yooadmin_network_site_info_url')) {
    function yooadmin_network_site_info_url(int $blog_id, array $args = []): string
    {
        if (function_exists('yooadmin_network_site_info_should_use') && !yooadmin_network_site_info_should_use()) {
            $url = network_admin_url('site-info.php?id=' . max(1, $blog_id));
            return $args ? add_query_arg($args, $url) : $url;
        }

        $url = network_admin_url('admin.php?page=' . yooadmin_network_site_info_page_slug());
        $url = add_query_arg('id', max(1, $blog_id), $url);

        if ($args) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_site_info_should_use')) {
    function yooadmin_network_site_info_should_use(): bool
    {
        if (!is_multisite()) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        $enabled = true;
        if (function_exists('yooadmin_get_option')) {
            $enabled = (bool) yooadmin_get_option('network_site_info_redirect', true);
        }

        return (bool) apply_filters('yooadmin_network_site_info_should_use', $enabled);
    }
}

if (!function_exists('yooadmin_network_site_info_is_screen')) {
    function yooadmin_network_site_info_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_site_info_page_slug();
    }
}

if (!function_exists('yooadmin_network_site_info_current_id')) {
    function yooadmin_network_site_info_current_id(): int
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route parameter.
        return isset($_GET['id']) ? absint(wp_unslash((string) $_GET['id'])) : 0;
    }
}

if (!function_exists('yooadmin_network_site_info_get_site')) {
    /**
     * @return WP_Site|null
     */
    function yooadmin_network_site_info_get_site(int $blog_id)
    {
        if ($blog_id <= 0) {
            return null;
        }

        $details = get_site($blog_id);
        if (!$details) {
            return null;
        }

        if (!can_edit_network($details->site_id)) {
            return null;
        }

        return $details;
    }
}

if (!function_exists('yooadmin_network_site_info_site_name')) {
    function yooadmin_network_site_info_site_name(int $blog_id): string
    {
        $name = get_blog_option($blog_id, 'blogname');
        if (is_string($name) && $name !== '') {
            return $name;
        }

        return sprintf(
            /* translators: %d: site ID. */
            __('Site %d', 'yooadmin'),
            $blog_id
        );
    }
}

if (!function_exists('yooadmin_network_site_info_nav_tabs')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_site_info_nav_tabs(int $blog_id, string $selected = 'site-info'): array
    {
        if (function_exists('yooadmin_network_site_editor_nav_tabs')) {
            return yooadmin_network_site_editor_nav_tabs($blog_id, $selected);
        }

        $td = yooadmin_network_site_info_text_domain();

        return [
            [
                'id'       => 'site-info',
                'label'    => __('Info', 'yooadmin'),
                'icon'     => 'dashicons-info-outline',
                'desc'     => __('Site address, registration dates, and attributes.', 'yooadmin'),
                'url'      => yooadmin_network_site_info_url($blog_id),
                'selected' => $selected === 'site-info',
            ],
        ];
    }
}

if (!function_exists('yooadmin_network_site_info_process_save')) {
    /**
     * @return bool True when a save was processed.
     */
    function yooadmin_network_site_info_process_save(): bool
    {
        if (!is_multisite() || !is_network_admin() || !current_user_can('manage_sites')) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Checked below.
        if (!isset($_REQUEST['action']) || 'update-site' !== sanitize_key(wp_unslash((string) $_REQUEST['action']))) {
            return false;
        }

        check_admin_referer('edit-site');

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Validated above.
        $id = isset($_REQUEST['id']) ? absint(wp_unslash((string) $_REQUEST['id'])) : 0;
        if ($id <= 0) {
            wp_die(esc_html__('Invalid site ID.', 'yooadmin'));
        }

        $details = yooadmin_network_site_info_get_site($id);
        if (!$details) {
            wp_die(esc_html__('The requested site does not exist.', 'yooadmin'));
        }

        $parsed_scheme = wp_parse_url($details->siteurl, PHP_URL_SCHEME);
        $is_main_site  = is_main_site($id);

        switch_to_blog($id);
        delete_option('rewrite_rules');

        if (!isset($_POST['blog']) || !is_array($_POST['blog'])) {
            restore_current_blog();
            wp_die(esc_html__('Invalid site data.', 'yooadmin'));
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per core site-info.php.
        $blog_data           = wp_unslash($_POST['blog']);
        $blog_data['scheme'] = $parsed_scheme;

        if ($is_main_site) {
            $blog_data['domain'] = $details->domain;
            $blog_data['path']   = $details->path;
        } else {
            $new_url_scheme = wp_parse_url($blog_data['url'], PHP_URL_SCHEME);

            if (!$new_url_scheme) {
                $blog_data['url'] = esc_url($parsed_scheme . '://' . $blog_data['url']);
            }
            $update_parsed_url = wp_parse_url($blog_data['url']);

            if (!isset($update_parsed_url['path'])) {
                $update_parsed_url['path'] = '/';
            }

            $blog_data['scheme'] = $update_parsed_url['scheme'];
            $blog_data['domain'] = $update_parsed_url['host'];
            if (isset($update_parsed_url['port'])) {
                $blog_data['domain'] .= ':' . $update_parsed_url['port'];
            }
            $blog_data['path'] = $update_parsed_url['path'];
        }

        $existing_details     = get_site($id);
        $blog_data_checkboxes = ['public', 'archived', 'spam', 'mature', 'deleted'];

        foreach ($blog_data_checkboxes as $checkbox) {
            if (!in_array((int) $existing_details->$checkbox, [0, 1], true)) {
                $blog_data[ $checkbox ] = $existing_details->$checkbox;
            } else {
                $blog_data[ $checkbox ] = isset($_POST['blog'][ $checkbox ]) ? 1 : 0;
            }
        }

        update_blog_details($id, $blog_data);

        $new_details     = get_site($id);
        $old_home_url    = trailingslashit(esc_url(get_option('home')));
        $old_home_parsed = wp_parse_url($old_home_url);
        $old_home_host   = $old_home_parsed['host'] . (isset($old_home_parsed['port']) ? ':' . $old_home_parsed['port'] : '');

        if ($old_home_host === $existing_details->domain && $old_home_parsed['path'] === $existing_details->path) {
            $new_home_url = untrailingslashit(sanitize_url($blog_data['scheme'] . '://' . $new_details->domain . $new_details->path));
            update_option('home', $new_home_url);
        }

        $old_site_url    = trailingslashit(esc_url(get_option('siteurl')));
        $old_site_parsed = wp_parse_url($old_site_url);
        $old_site_host   = $old_site_parsed['host'] . (isset($old_site_parsed['port']) ? ':' . $old_site_parsed['port'] : '');

        if ($old_site_host === $existing_details->domain && $old_site_parsed['path'] === $existing_details->path) {
            $new_site_url = untrailingslashit(sanitize_url($blog_data['scheme'] . '://' . $new_details->domain . $new_details->path));
            update_option('siteurl', $new_site_url);
        }

        restore_current_blog();

        wp_safe_redirect(
            yooadmin_network_site_info_url(
                $id,
                [
                    'update' => 'updated',
                ]
            )
        );
        exit;
    }
}

add_action(
    'admin_init',
    static function (): void {
        if (!function_exists('yooadmin_network_site_info_should_use') || !yooadmin_network_site_info_should_use()) {
            return;
        }

        if (!function_exists('yooadmin_network_site_info_is_screen') || !yooadmin_network_site_info_is_screen()) {
            return;
        }

        yooadmin_network_site_info_process_save();
    },
    5
);
