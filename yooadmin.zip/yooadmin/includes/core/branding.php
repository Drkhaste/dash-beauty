<?php
/**
 * YOOAdmin - Branding helpers (logo URL, width)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_logo_url')) {
    function yooadmin_logo_url(): string {
        $opts = (array) get_option('yooadmin_options', []);
        $url  = isset($opts['logo_url']) ? esc_url($opts['logo_url']) : '';
        /**
         * Filter: allow upstream to override the admin logo URL.
         */
        return apply_filters('yooadmin_logo_url', $url);
    }
}

if (!function_exists('yooadmin_logo_width')) {
    function yooadmin_logo_width(): int {
        $opts = (array) get_option('yooadmin_options', []);
        $w    = isset($opts['logo_w']) ? (int) $opts['logo_w'] : 150;
        $w    = max(20, min(1000, $w));
        /**
         * Filter: allow upstream to override the admin logo width (px).
         */
        return (int) apply_filters('yooadmin_logo_width', $w);
    }
}
