<?php
/**
 * YOOAdmin network site themes tab.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_site_themes_page_slug')) {
    function yooadmin_network_site_themes_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_site_themes_page_slug', 'yooadmin-network-site-themes');
    }
}

if (!function_exists('yooadmin_network_site_themes_url')) {
    function yooadmin_network_site_themes_url(int $blog_id, array $args = []): string
    {
        if (function_exists('yooadmin_network_site_themes_should_use') && !yooadmin_network_site_themes_should_use()) {
            $url = network_admin_url('site-themes.php?id=' . max(1, $blog_id));
            return $args ? add_query_arg($args, $url) : $url;
        }

        $url = network_admin_url('admin.php?page=' . yooadmin_network_site_themes_page_slug());
        $url = add_query_arg('id', max(1, $blog_id), $url);

        if ($args) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_site_themes_should_use')) {
    function yooadmin_network_site_themes_should_use(): bool
    {
        return function_exists('yooadmin_network_site_editor_should_use') && yooadmin_network_site_editor_should_use();
    }
}

if (!function_exists('yooadmin_network_site_themes_is_screen')) {
    function yooadmin_network_site_themes_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_site_themes_page_slug();
    }
}

if (!function_exists('yooadmin_network_site_themes_get_items')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_site_themes_get_items(int $blog_id, string $view = 'all', string $search = ''): array
    {
        switch_to_blog($blog_id);
        $allowed = get_option('allowedthemes');
        if (!is_array($allowed)) {
            $allowed = [];
        }
        restore_current_blog();

        $items = [];
        foreach (wp_get_themes() as $stylesheet => $theme) {
            if ($theme->is_allowed('network')) {
                continue;
            }

            $enabled = !empty($allowed[ $stylesheet ]);
            if ($view === 'enabled' && !$enabled) {
                continue;
            }
            if ($view === 'disabled' && $enabled) {
                continue;
            }

            if ($search !== '') {
                $haystack = strtolower($theme->get('Name') . ' ' . $theme->get('Description') . ' ' . $stylesheet);
                if (strpos($haystack, strtolower($search)) === false) {
                    continue;
                }
            }

            $items[] = [
                'stylesheet'  => $stylesheet,
                'name'        => $theme->get('Name'),
                'description' => $theme->get('Description'),
                'version'     => $theme->get('Version'),
                'author'      => $theme->display('Author', false, true),
                'screenshot'  => $theme->get_screenshot(),
                'enabled'     => $enabled,
            ];
        }

        usort(
            $items,
            static function (array $a, array $b): int {
                return strcasecmp((string) $a['name'], (string) $b['name']);
            }
        );

        return $items;
    }
}

if (!function_exists('yooadmin_network_site_themes_flash_message')) {
    function yooadmin_network_site_themes_flash_message(): array
    {
        $td = yooadmin_network_site_editor_text_domain();

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash query arg.
        if (isset($_GET['enabled'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash query arg.
            $enabled = absint(wp_unslash((string) $_GET['enabled']));
            if (1 === $enabled) {
                return [__('Theme enabled.', 'yooadmin'), 'success'];
            }
            /* translators: %s: number of themes. */
            return [sprintf(_n('%s theme enabled.', '%s themes enabled.', $enabled, 'yooadmin'), number_format_i18n($enabled)), 'success'];
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash query arg.
        if (isset($_GET['disabled'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash query arg.
            $disabled = absint(wp_unslash((string) $_GET['disabled']));
            if (1 === $disabled) {
                return [__('Theme disabled.', 'yooadmin'), 'success'];
            }
            /* translators: %s: number of themes. */
            return [sprintf(_n('%s theme disabled.', '%s themes disabled.', $disabled, 'yooadmin'), number_format_i18n($disabled)), 'success'];
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (isset($_GET['error']) && 'none' === sanitize_key(wp_unslash((string) $_GET['error']))) {
            return [__('No theme selected.', 'yooadmin'), 'error'];
        }

        return ['', ''];
    }
}

if (!function_exists('yooadmin_network_site_themes_process_actions')) {
    function yooadmin_network_site_themes_process_actions(): bool
    {
        if (!is_multisite() || !is_network_admin() || !current_user_can('manage_sites')) {
            return false;
        }

        if (!yooadmin_network_site_themes_is_screen()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $id = isset($_REQUEST['id']) ? absint(wp_unslash((string) $_REQUEST['id'])) : 0;
        if ($id <= 0 || !yooadmin_network_site_editor_get_site($id)) {
            return false;
        }

        $action = '';
        if (!empty($_POST['action']) && '-1' !== $_POST['action']) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $action = sanitize_key(wp_unslash((string) $_POST['action']));
        } elseif (!empty($_POST['action2']) && '-1' !== $_POST['action2']) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $action = sanitize_key(wp_unslash((string) $_POST['action2']));
        } elseif (!empty($_GET['action'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $action = sanitize_key(wp_unslash((string) $_GET['action']));
        }

        if ($action === '' || $action === 'update-site') {
            return false;
        }

        $referer = yooadmin_network_site_themes_url($id);
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        foreach (['theme-status', 's'] as $key) {
            if (isset($_GET[ $key ])) {
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $referer = add_query_arg($key, sanitize_text_field(wp_unslash((string) $_GET[ $key ])), $referer);
            }
        }

        switch_to_blog($id);
        $allowed_themes = get_option('allowedthemes');
        if (!is_array($allowed_themes)) {
            $allowed_themes = [];
        }

        $result_action = '';
        $count         = 0;

        switch ($action) {
            case 'enable':
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $theme = isset($_GET['theme']) ? sanitize_text_field(wp_unslash((string) $_GET['theme'])) : '';
                check_admin_referer('enable-theme_' . $theme);
                $allowed_themes[ $theme ] = true;
                $result_action            = 'enabled';
                $count                    = 1;
                break;

            case 'disable':
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $theme = isset($_GET['theme']) ? sanitize_text_field(wp_unslash((string) $_GET['theme'])) : '';
                check_admin_referer('disable-theme_' . $theme);
                unset($allowed_themes[ $theme ]);
                $result_action = 'disabled';
                $count         = 1;
                break;

            case 'enable-selected':
                check_admin_referer('bulk-themes');
                if (isset($_POST['checked']) && is_array($_POST['checked'])) {
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Theme slugs sanitized in loop.
                    $checked_themes = wp_unslash($_POST['checked']);
                    foreach ($checked_themes as $theme) {
                        $allowed_themes[ sanitize_text_field((string) $theme) ] = true;
                    }
                    $result_action = 'enabled';
                    $count         = count($checked_themes);
                } else {
                    $result_action = 'error';
                    $count         = 'none';
                }
                break;

            case 'disable-selected':
                check_admin_referer('bulk-themes');
                if (isset($_POST['checked']) && is_array($_POST['checked'])) {
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Theme slugs sanitized in loop.
                    $checked_themes = wp_unslash($_POST['checked']);
                    foreach ($checked_themes as $theme) {
                        unset($allowed_themes[ sanitize_text_field((string) $theme) ]);
                    }
                    $result_action = 'disabled';
                    $count         = count($checked_themes);
                } else {
                    $result_action = 'error';
                    $count         = 'none';
                }
                break;
        }

        if ($result_action === '') {
            restore_current_blog();
            return false;
        }

        update_option('allowedthemes', $allowed_themes, false);
        restore_current_blog();

        $args = ['id' => $id];
        if ($result_action === 'error') {
            $args['error'] = $count;
        } else {
            $args[ $result_action ] = $count;
        }

        wp_safe_redirect(add_query_arg($args, yooadmin_network_site_themes_url($id)));
        exit;
    }
}

add_action(
    'admin_init',
    static function (): void {
        if (!yooadmin_network_site_themes_should_use()) {
            return;
        }
        yooadmin_network_site_themes_process_actions();
    },
    5
);
