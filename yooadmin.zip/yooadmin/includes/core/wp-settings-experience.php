<?php
/**
 * WordPress core settings screens — YOOAdmin experience (native pages, styled in place).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_wp_settings_experience_option_enabled')) {
    function yooadmin_wp_settings_experience_option_enabled(): bool
    {
        $opts = function_exists('yooadmin_get_options')
            ? (array) yooadmin_get_options()
            : (array) get_option('yooadmin_options', []);

        if (!array_key_exists('wp_settings_experience', $opts)) {
            return true;
        }

        return (int) $opts['wp_settings_experience'] === 1;
    }
}

if (!function_exists('yooadmin_wp_settings_experience_active')) {
    /**
     * Active when option is on AND Focus Mode is on.
     *
     * Boot-layout hosts (WP 7+ @wordpress/boot SPAs) skip manage_options — the user
     * already passed WordPress capability checks for that screen (e.g. edit_theme_options).
     */
    function yooadmin_wp_settings_experience_active(): bool
    {
        if (!yooadmin_wp_settings_experience_option_enabled()) {
            return false;
        }
        if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return false;
        }
        if (yooadmin_wp_settings_experience_is_boot_layout_screen()) {
            return is_admin() && is_user_logged_in();
        }
        return current_user_can('manage_options');
    }
}

if (!function_exists('yooadmin_wp_settings_experience_screen_ids')) {
    /**
     * Core WP settings screens we style (expand per phase).
     *
     * @return string[]
     */
    function yooadmin_wp_settings_experience_screen_ids(): array
    {
        $screens = [
            'options-general',
            'options-reading',
            'options-writing',
            'options-discussion',
            'options-media',
            'options-permalink',
            'options-privacy',
            'options-connectors',
            'settings_page_ai-wp-admin',
            'tools',
            'import',
            'export',
            'site-health',
            'export-personal-data',
            'erase-personal-data',
            'theme-editor',
            'plugin-editor',
            'network',
        ];
        return apply_filters('yooadmin_wp_settings_experience_screen_ids', $screens);
    }
}

if (!function_exists('yooadmin_wp_settings_experience_boot_layout_screens')) {
    /**
     * WP 7+ React boot pages with non-standard screen → mount mappings.
     *
     * Most boot hosts auto-resolve via {@see yooadmin_wp_settings_experience_resolve_boot_layout_app_id()}.
     *
     * @return array<string, string>
     */
    function yooadmin_wp_settings_experience_boot_layout_screens(): array
    {
        $screens = [
            'options-connectors'        => 'options-connectors-wp-admin-app',
            'settings_page_ai-wp-admin' => 'ai-wp-admin-app',
        ];

        return apply_filters('yooadmin_wp_settings_experience_boot_layout_screens', $screens);
    }
}

if (!function_exists('yooadmin_wp_settings_experience_boot_layout_app_id_from_prerequisites_handle')) {
    /**
     * Derive mount id from a WP boot prerequisites script handle.
     *
     * @param string $handle Script handle, e.g. font-library-wp-admin-prerequisites.
     */
    function yooadmin_wp_settings_experience_boot_layout_app_id_from_prerequisites_handle(string $handle): string
    {
        if (preg_match('/^(.+)-wp-admin-prerequisites$/', $handle, $matches)) {
            return $matches[1] . '-wp-admin-app';
        }

        return '';
    }
}

if (!function_exists('yooadmin_wp_settings_experience_discover_boot_layout_app_id_from_scripts')) {
    /**
     * Detect boot mount id from enqueued @wordpress/boot prerequisite scripts.
     */
    function yooadmin_wp_settings_experience_discover_boot_layout_app_id_from_scripts(): string
    {
        global $wp_scripts;

        if (!$wp_scripts instanceof WP_Scripts) {
            return '';
        }

        $handles = array_merge(
            array_keys((array) $wp_scripts->registered),
            (array) $wp_scripts->queue
        );

        foreach (array_unique($handles) as $handle) {
            if (!is_string($handle)) {
                continue;
            }

            $app_id = yooadmin_wp_settings_experience_boot_layout_app_id_from_prerequisites_handle($handle);
            if ($app_id !== '') {
                return $app_id;
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_wp_settings_experience_infer_boot_layout_app_id_from_request')) {
    /**
     * Infer boot mount id from the current admin route (before scripts enqueue).
     */
    function yooadmin_wp_settings_experience_infer_boot_layout_app_id_from_request(): string
    {
        global $pagenow;

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route discovery.
        if ('admin.php' === $pagenow && isset($_GET['page'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route discovery.
            $page   = sanitize_key((string) wp_unslash($_GET['page']));
            $suffix = '-wp-admin';

            if ($page !== '' && strlen($page) >= strlen($suffix) && substr($page, -strlen($suffix)) === $suffix) {
                return $page . '-app';
            }
        }

        if (is_string($pagenow) && preg_match('/^([a-z0-9-]+)\.php$/', $pagenow, $matches)) {
            $slug        = $matches[1];
            $render_func = 'wp_' . str_replace('-', '_', $slug) . '_wp_admin_render_page';

            if (function_exists($render_func)) {
                return $slug . '-wp-admin-app';
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_wp_settings_experience_resolve_boot_layout_app_id')) {
    /**
     * Resolve the boot SPA mount element id for the current (or given) screen.
     *
     * Order: explicit registry → route heuristics → enqueued prerequisites script.
     *
     * @param string|null $screen_id Optional WP_Screen id.
     */
    function yooadmin_wp_settings_experience_resolve_boot_layout_app_id(?string $screen_id = null): string
    {
        if ($screen_id === null && function_exists('get_current_screen')) {
            $screen = get_current_screen();
            if ($screen && !empty($screen->id)) {
                $screen_id = (string) $screen->id;
            }
        }

        if (is_string($screen_id) && $screen_id !== '') {
            $screens = yooadmin_wp_settings_experience_boot_layout_screens();
            if (isset($screens[$screen_id])) {
                return (string) $screens[$screen_id];
            }
        }

        $from_request = yooadmin_wp_settings_experience_infer_boot_layout_app_id_from_request();
        if ($from_request !== '') {
            return $from_request;
        }

        $from_scripts = yooadmin_wp_settings_experience_discover_boot_layout_app_id_from_scripts();
        if ($from_scripts !== '') {
            return $from_scripts;
        }

        return (string) apply_filters(
            'yooadmin_wp_settings_experience_boot_layout_app_id',
            '',
            is_string($screen_id) ? $screen_id : ''
        );
    }
}

if (!function_exists('yooadmin_wp_settings_experience_is_boot_layout_screen')) {
    function yooadmin_wp_settings_experience_is_boot_layout_screen(?string $screen_id = null): bool
    {
        return yooadmin_wp_settings_experience_resolve_boot_layout_app_id($screen_id) !== '';
    }
}

if (!function_exists('yooadmin_wp_settings_experience_boot_layout_app_id')) {
    function yooadmin_wp_settings_experience_boot_layout_app_id(?string $screen_id = null): string
    {
        return yooadmin_wp_settings_experience_resolve_boot_layout_app_id($screen_id);
    }
}

if (!function_exists('yooadmin_wp_settings_experience_boot_layout_title')) {
    function yooadmin_wp_settings_experience_boot_layout_title(?string $screen_id = null): string
    {
        if ($screen_id === null) {
            if (!function_exists('get_current_screen')) {
                return '';
            }
            $screen = get_current_screen();
            if (!$screen || empty($screen->id)) {
                return '';
            }
            $screen_id = (string) $screen->id;
        }

        $titles = [
            'options-connectors'        => __('Connectors', 'yooadmin'),
            'settings_page_ai-wp-admin' => __('AI', 'yooadmin'),
        ];

        $title = isset($titles[$screen_id]) ? (string) $titles[$screen_id] : '';

        if ($title === '' && function_exists('get_admin_page_title')) {
            $title = (string) get_admin_page_title();
        }

        return (string) apply_filters('yooadmin_wp_settings_experience_boot_layout_title', $title, $screen_id);
    }
}

if (!function_exists('yooadmin_wp_settings_experience_is_tools_screen')) {
    function yooadmin_wp_settings_experience_is_tools_screen(string $screen_id): bool
    {
        if ($screen_id === 'tools' || strpos($screen_id, 'tools_page_') === 0) {
            return true;
        }

        $tools_files = [
            'import',
            'export',
            'site-health',
            'export-personal-data',
            'erase-personal-data',
            'theme-editor',
            'plugin-editor',
            'network',
        ];

        return in_array($screen_id, $tools_files, true);
    }
}

if (!function_exists('yooadmin_wp_settings_experience_is_screen')) {
    function yooadmin_wp_settings_experience_is_screen(): bool
    {
        if (!function_exists('get_current_screen')) {
            return false;
        }
        $screen = get_current_screen();
        if (!$screen || empty($screen->id)) {
            return false;
        }

        $screen_id = (string) $screen->id;
        if (in_array($screen_id, yooadmin_wp_settings_experience_screen_ids(), true)) {
            return true;
        }

        if (yooadmin_wp_settings_experience_is_boot_layout_screen($screen_id)) {
            return (bool) apply_filters('yooadmin_wp_settings_experience_boot_layout_screen', true, $screen);
        }

        if (yooadmin_wp_settings_experience_is_tools_screen($screen_id)) {
            return (bool) apply_filters('yooadmin_wp_settings_experience_tools_subpage', true, $screen);
        }

        return (bool) apply_filters('yooadmin_wp_settings_experience_matches_screen', false, $screen);
    }
}

if (!function_exists('yooadmin_wp_settings_experience_bootstrap')) {
    function yooadmin_wp_settings_experience_bootstrap(): void
    {
        add_filter('admin_body_class', static function (string $classes): string {
            if (!yooadmin_wp_settings_experience_active() || !yooadmin_wp_settings_experience_is_screen()) {
                return $classes;
            }
            $classes .= ' yoo-wp-settings-experience';
            if (function_exists('get_current_screen')) {
                $screen = get_current_screen();
                if (
                    $screen
                    && yooadmin_wp_settings_experience_is_boot_layout_screen((string) $screen->id)
                ) {
                    $classes .= ' yoo-wp-boot-layout-experience';
                }
                if (
                    $screen
                    && ! empty($screen->id)
                    && yooadmin_wp_settings_experience_is_tools_screen((string) $screen->id)
                ) {
                    $classes .= ' yoo-wp-tools-experience';
                }
                if (
                    $screen
                    && in_array((string) $screen->id, ['export-personal-data', 'erase-personal-data'], true)
                ) {
                    $classes .= ' yp-wp-settings-privacy-tools-active';
                }
            }
            return $classes;
        });

        add_action('admin_head', static function (): void {
            if (!yooadmin_wp_settings_experience_active() || !yooadmin_wp_settings_experience_is_screen()) {
                return;
            }
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if (
                $screen
                && in_array((string) $screen->id, ['export-personal-data', 'erase-personal-data'], true)
            ) {
                echo '<style id="yoo-privacy-tools-table-css">body.yoo-wp-settings-experience.yp-wp-settings-privacy-tools-active .wrap>.subsubsub:not(.yp-wp-settings-privacy-tools-views){display:none!important}body.yoo-wp-settings-experience.yp-wp-settings-privacy-tools-active .yp-wp-settings-privacy-tools-table-card .subsubsub{margin:0!important;padding:0!important;background:transparent!important;border:0!important}body.yoo-wp-settings-experience.yp-wp-settings-privacy-tools-active .yp-wp-settings-privacy-tools-table-card table.wp-list-table.widefat tfoot{display:none!important}</style>';
            }

            if ($screen && yooadmin_wp_settings_experience_is_boot_layout_screen((string) $screen->id)) {
                echo '<style id="yoo-wp-boot-layout-boot-css">body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) #wpbody-content>[id$="-wp-admin-app"],body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) .wrap.yp-wp-settings-boot-layout-wrap>[id$="-wp-admin-app"],body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) .wrap.yp-wp-settings-boot-layout-wrap>h1,body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) .wrap.yp-wp-settings-boot-layout-wrap>.yp-wp-settings-boot-layout-intro{display:none!important}body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) #wpbody-content>.wrap,body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) .wrap.yp-wp-settings-boot-layout-wrap{display:flex!important;align-items:center;justify-content:center;min-height:min(320px,50vh);position:relative}body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) #wpbody-content>.wrap::after,body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) .wrap.yp-wp-settings-boot-layout-wrap::after{content:"";display:block!important;width:40px;height:40px;border:3px solid rgba(0,0,0,.08);border-top-color:var(--yooadmin-primary,#eda934);border-radius:50%;animation:yp-wp-settings-boot-spin .8s linear infinite}body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience #wpwrap,body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience #wpbody,body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience #wpbody-content{background:transparent!important}</style>';
                echo '<style id="yoo-wp-boot-layout-core-reset">body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience{background:transparent!important}body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience #wpwrap{background:transparent!important;overflow-y:visible!important}body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience #wpcontent{padding-inline-start:0!important}body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience #wpbody-content{padding-bottom:0!important}body.yoo-wp-settings-experience.yoo-wp-boot-layout-experience #wpfooter{display:none!important}</style>';
            }

            echo '<style id="yoo-wp-settings-boot-css">body.yoo-wp-settings-experience.yoo-wp-tools-experience:not(.yp-wp-settings-ready) #wpbody-content>.notice,body.yoo-wp-settings-experience.yoo-wp-tools-experience:not(.yp-wp-settings-ready) #wpbody-content>.updated,body.yoo-wp-settings-experience.yoo-wp-tools-experience:not(.yp-wp-settings-ready) #wpbody-content>.error,body.yoo-wp-settings-experience.yoo-wp-tools-experience:not(.yp-wp-settings-ready) .wrap>*{display:none!important}body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>form,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>h1,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>h2,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>p,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>hr,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>div,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>table,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>nav,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>fieldset,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>.notice,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>.updated,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>.error,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>.subsubsub,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>.card,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap>.yp-wp-settings-header,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .privacy-settings-header,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .privacy-settings-body,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .yp-wp-settings-privacy-root,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .yp-wp-settings-tools-panel,body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) hr.wp-header-end{display:none!important}body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap{position:relative;min-height:min(320px,50vh);display:flex;align-items:center;justify-content:center}body.yoo-wp-settings-experience:not(.yp-wp-settings-ready) .wrap::after{content:"";position:static;width:40px;height:40px;margin:0;border:3px solid rgba(0,0,0,.08);border-top-color:var(--yooadmin-primary,#eda934);border-radius:50%;animation:yp-wp-settings-boot-spin .8s linear infinite;flex-shrink:0}body.yoo-wp-settings-experience.privacy-settings:not(.yp-wp-settings-ready) #wpcontent{position:relative;min-height:min(320px,50vh)}body.yoo-wp-settings-experience.privacy-settings:not(.yp-wp-settings-ready) #wpcontent::after{content:"";position:absolute;left:50%;top:50%;width:40px;height:40px;margin:-20px 0 0 -20px;border:3px solid rgba(0,0,0,.08);border-top-color:var(--yooadmin-primary,#eda934);border-radius:50%;animation:yp-wp-settings-boot-spin .8s linear infinite}body.yoo-wp-settings-experience.privacy-settings:not(.yp-wp-settings-ready) .wrap{display:none!important;min-height:0!important}body.yoo-wp-settings-experience.privacy-settings:not(.yp-wp-settings-ready) .wrap::after{display:none!important}body.yoo-wp-settings-experience.yp-wp-settings-ready .wrap{display:block;min-height:0}body.yoo-wp-settings-experience.yp-wp-settings-ready .wrap::after,body.yoo-wp-settings-experience.yp-wp-settings-ready.privacy-settings #wpcontent::after{display:none!important}@keyframes yp-wp-settings-boot-spin{to{transform:rotate(360deg)}}</style>';
        }, 1);

        add_action('admin_enqueue_scripts', static function (string $hook): void {
            if (!yooadmin_wp_settings_experience_active() || !yooadmin_wp_settings_experience_is_screen()) {
                return;
            }

            $base = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
            $url  = plugin_dir_url($base);
            $dir  = plugin_dir_path($base);

            $settings_css = 'assets/css/admin/yp-settings.css';
            if (is_readable($dir . $settings_css)) {
                wp_enqueue_style(
                    'yooadmin-settings',
                    $url . $settings_css,
                    ['yooadmin-core'],
                    (string) filemtime($dir . $settings_css)
                );
            }

            $archive_css = 'assets/css/admin/yp-archive-delay-select.css';
            if (is_readable($dir . $archive_css)) {
                wp_enqueue_style(
                    'yooadmin-yp-ui-select',
                    $url . $archive_css,
                    ['yooadmin-settings'],
                    (string) filemtime($dir . $archive_css)
                );
            }

            $buttons_css = 'assets/css/admin/yp-yoo-buttons.css';
            if (is_readable($dir . $buttons_css)) {
                wp_enqueue_style(
                    'yooadmin-yoo-buttons',
                    $url . $buttons_css,
                    ['yooadmin-core'],
                    (string) filemtime($dir . $buttons_css)
                );
            }

            $css = 'assets/css/admin/wp-settings-experience.css';
            if (is_readable($dir . $css)) {
                wp_enqueue_style(
                    'yooadmin-wp-settings-experience',
                    $url . $css,
                    ['yooadmin-settings', 'yooadmin-yoo-buttons'],
                    (string) filemtime($dir . $css)
                );
            }

            $select_js = 'assets/js/admin/yp-archive-delay-select.js';
            if (is_readable($dir . $select_js)) {
                wp_enqueue_script(
                    'yooadmin-yp-ui-select',
                    $url . $select_js,
                    [],
                    (string) filemtime($dir . $select_js),
                    true
                );
            }

            $js_deps = ['jquery', 'yooadmin-yp-ui-select'];
            $js_deps = apply_filters('yooadmin_wp_settings_experience_script_deps', $js_deps);

            $js = 'assets/js/admin/wp-settings-experience.js';
            if (is_readable($dir . $js)) {
                wp_enqueue_script(
                    'yooadmin-wp-settings-experience',
                    $url . $js,
                    $js_deps,
                    (string) filemtime($dir . $js),
                    true
                );

                wp_localize_script(
                    'yooadmin-wp-settings-experience',
                    'yooWpSettingsExperience',
                    apply_filters('yooadmin_wp_settings_experience_script_data', [
                        'useYooMedia'     => false,
                        'screen'          => function_exists('get_current_screen') && get_current_screen()
                            ? (string) get_current_screen()->id
                            : '',
                        'bootLayoutAppId' => function_exists('get_current_screen') && get_current_screen()
                            ? yooadmin_wp_settings_experience_boot_layout_app_id((string) get_current_screen()->id)
                            : '',
                        'bootLayoutTitle' => function_exists('get_current_screen') && get_current_screen()
                            ? yooadmin_wp_settings_experience_boot_layout_title((string) get_current_screen()->id)
                            : '',
                    ])
                );
            }

            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($screen
                && function_exists('yooadmin_wp_settings_experience_is_boot_layout_screen')
                && yooadmin_wp_settings_experience_is_boot_layout_screen((string) $screen->id)
                && function_exists('yooadmin_studio_hub_enqueue_plugin_admin_adaptive_assets')) {
                yooadmin_studio_hub_enqueue_plugin_admin_adaptive_assets();
            }

            do_action('yooadmin_wp_settings_experience_enqueue', $base, $url, $dir);

            if (function_exists('options_general_add_js')) {
                add_action('admin_print_footer_scripts', 'options_general_add_js', 20);
            }
            if (function_exists('options_reading_add_js')) {
                add_action('admin_print_footer_scripts', 'options_reading_add_js', 20);
            }
        }, 20);

        add_action('admin_print_footer_scripts', static function (): void {
            if (!yooadmin_wp_settings_experience_active() || !yooadmin_wp_settings_experience_is_screen()) {
                return;
            }
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if (!$screen || !yooadmin_wp_settings_experience_is_boot_layout_screen((string) $screen->id)) {
                return;
            }
            $app_id = yooadmin_wp_settings_experience_boot_layout_app_id((string) $screen->id);
            if ($app_id === '') {
                return;
            }
            echo '<style id="yoo-wp-boot-layout-fix-early">body.yoo-wp-boot-layout-experience #wpwrap,body.yoo-wp-boot-layout-experience #wpbody,body.yoo-wp-boot-layout-experience #wpbody-content{background:transparent!important}body.yoo-wp-boot-layout-experience #wpbody-content>.wrap{display:flex!important;align-items:center;justify-content:center;min-height:min(320px,50vh);max-width:1280px;margin:12px 12px!important;padding:0!important;background:var(--yp-set-surface,#fff)!important;border:1px solid var(--yp-set-border,rgba(15,23,42,.09))!important;border-radius:7px!important;box-shadow:none!important;box-sizing:border-box}body.yoo-wp-boot-layout-experience.yp-wp-settings-ready #wpbody-content>.wrap{display:block!important;min-height:0}body.yoo-wp-boot-layout-experience #wpbody-content>.wrap>h1,body.yoo-wp-boot-layout-experience #wpbody-content>.wrap>.yp-wp-settings-boot-layout-intro{display:none!important}body.yoo-wp-boot-layout-experience #wpbody-content>[id$="-wp-admin-app"]{display:none!important}body.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) #wpbody-content>.wrap>[id$="-wp-admin-app"]{display:none!important}body.yoo-wp-boot-layout-experience:not(.yp-wp-settings-ready) #wpbody-content>.wrap::after{content:"";display:block!important;width:40px;height:40px;border:3px solid color-mix(in srgb,var(--yp-set-text,#1d2327) 8%,transparent);border-top-color:var(--yooadmin-primary,#eda934);border-radius:50%;animation:yp-wp-settings-boot-spin .8s linear infinite;flex-shrink:0}body.yoo-wp-boot-layout-experience.yp-wp-settings-ready #wpbody-content>.wrap::after{display:none!important}body.yoo-wp-boot-layout-experience.yp-wp-settings-ready #wpbody-content>.wrap>[id$="-wp-admin-app"]{display:block!important}</style>';
            printf(
                '<script id="yoo-wp-boot-layout-early">(function(){var appId=%1$s,a=document.getElementById(appId),bc=document.getElementById("wpbody-content");if(!a||!bc)return;var w=bc.querySelector(":scope > .wrap.yp-wp-settings-boot-layout-wrap")||bc.querySelector(":scope > .wrap");if(!w){w=document.createElement("div");w.className="wrap yp-wp-settings-boot-layout-wrap";bc.insertBefore(w,a)}else{w.classList.add("yp-wp-settings-boot-layout-wrap")}if(a.parentNode!==w){w.appendChild(a)}var h1=w.querySelector(":scope > h1");if(h1){h1.style.display="none";h1.setAttribute("aria-hidden","true")}})();</script>',
                wp_json_encode($app_id)
            );
        }, 5);

        add_action('admin_print_footer_scripts', static function (): void {
            if (!yooadmin_wp_settings_experience_active() || !yooadmin_wp_settings_experience_is_screen()) {
                return;
            }
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if (!$screen || !yooadmin_wp_settings_experience_is_boot_layout_screen((string) $screen->id)) {
                return;
            }
            echo '<style id="yoo-wp-boot-layout-fix">body.yoo-wp-boot-layout-experience #wpbody-content>.wrap{display:block!important;max-width:1280px;margin:12px 12px!important;padding:0!important;background:var(--yp-set-surface,#fff)!important;border:1px solid var(--yp-set-border,rgba(15,23,42,.09))!important;border-radius:7px!important;box-shadow:none!important}body.yoo-wp-boot-layout-experience #wpbody-content>.wrap>h1{display:none!important}body.yoo-wp-boot-layout-experience #wpbody-content>[id$="-wp-admin-app"]{display:none!important}body.yoo-wp-boot-layout-experience [id$="-wp-admin-app"] .boot-layout,body.yoo-wp-boot-layout-experience [id$="-wp-admin-app"] .boot-layout.boot-layout--single-page{position:relative!important;inset:auto!important;top:auto!important;right:auto!important;bottom:auto!important;left:auto!important;width:100%!important;max-width:100%!important;min-height:0!important;height:auto!important;background:transparent!important}body.yoo-wp-boot-layout-experience [id$="-wp-admin-app"] .admin-ui-page,body.yoo-wp-boot-layout-experience [id$="-wp-admin-app"] .boot-layout.has-full-canvas .boot-layout__canvas,body.yoo-wp-boot-layout-experience [id$="-wp-admin-app"] .boot-layout__canvas,body.yoo-wp-boot-layout-experience [id$="-wp-admin-app"] .boot-layout__stage,body.yoo-wp-boot-layout-experience [id$="-wp-admin-app"] .boot-layout__surfaces{background:transparent!important;height:auto!important;min-height:0!important;position:relative!important;top:auto!important;margin:0!important;padding:0!important;border:0!important;box-shadow:none!important;overflow:visible!important}body.yoo-wp-boot-layout-experience [id$="-wp-admin-app"] .ai-settings-page{padding:16px 20px 20px!important}body.yoo-wp-boot-layout-experience #wpwrap,body.yoo-wp-boot-layout-experience #wpbody,body.yoo-wp-boot-layout-experience #wpbody-content{background:transparent!important}</style>';
        }, 999);
    }
}

yooadmin_wp_settings_experience_bootstrap();
