<?php
/**
 * YOOAdmin - Admin menu registration (focus-aware)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Text domain is now hardcoded as 'yooadmin' for WordPress.org compliance

/** Stable dashboard slug (filterable) */
function yooadmin_dashboard_slug(): string {
    return (string) apply_filters('yooadmin_dashboard_page_slug', 'yooadmin-dashboard');
}

/** URL helper */
if (!function_exists('yooadmin_dashboard_url')) {
    function yooadmin_dashboard_url(): string {
        return admin_url('admin.php?page=' . yooadmin_dashboard_slug());
    }
}

/** Enable Focus Mode page slug */
if (!function_exists('yooadmin_enable_focus_slug')) {
    function yooadmin_enable_focus_slug(): string
    {
        return 'yooadmin-enable-focus';
    }
}

/** Enable Focus Mode page URL (site or network admin). */
if (!function_exists('yooadmin_enable_focus_url')) {
    function yooadmin_enable_focus_url(array $args = []): string
    {
        $base = (is_multisite() && is_network_admin())
            ? network_admin_url('admin.php')
            : admin_url('admin.php');

        $args = array_merge(['page' => yooadmin_enable_focus_slug()], $args);

        return add_query_arg($args, $base);
    }
}

/** Home URL after Focus Mode is enabled from the enable-focus page. */
if (!function_exists('yooadmin_focus_home_url')) {
    function yooadmin_focus_home_url(): string
    {
        if (function_exists('yooadmin_is_network_admin_request') && yooadmin_is_network_admin_request()) {
            if (function_exists('yooadmin_network_dashboard_url')) {
                return add_query_arg('yoo', 'on', 'yooadmin');
            }

            return add_query_arg('yoo', 'on', network_admin_url('index.php'));
        }

        return admin_url('admin.php?page=' . yooadmin_dashboard_slug() . '&yoo=on');
    }
}

/** Focus resolver (safe fallbacks) */
if (!function_exists('yooadmin_menu_focus_on')) {
    function yooadmin_menu_focus_on(): bool {
        if (function_exists('yooadmin_is_focus_enabled')) {
            return (bool) yooadmin_is_focus_enabled();
        }
        if (function_exists('yooadmin_focus_enabled_by_pref')) {
            return (bool) yooadmin_focus_enabled_by_pref();
        }
        if (isset($_COOKIE['yoo_focus'])) {
            return sanitize_text_field(wp_unslash($_COOKIE['yoo_focus'])) !== 'off';
        }
        return true;
    }
}

if (!function_exists('yooadmin_get_brand_icon_svg')) {
    /**
     * YOOAdmin brand mark SVG (same artwork as the wp-admin menu icon).
     */
    function yooadmin_get_brand_icon_svg(): string
    {
        return '<svg xmlns="http://www.w3.org/2000/svg" width="46" height="46" viewBox="0 0 44 44"><path fill="currentColor" d="M36.45,15.28c-2.93,0-5.43,1.84-6.41,4.42-1.44-2.78-4.34-4.69-7.69-4.69-1.59,0-3.08.44-4.37,1.19l2.53-4.44h-4.57l-5.33,9.37-5.32-9.37H.7l7.91,13.91v6.56h3.99v-6.56l1.11-1.95c.06,4.7,3.91,8.51,8.64,8.51,2.96,0,5.58-1.49,7.13-3.76l-.08,3.76h3.46v-4.31c1.04.64,2.27,1.02,3.58,1.02,3.78,0,6.86-3.06,6.86-6.83s-3.08-6.83-6.86-6.83ZM22.35,27.75c-2.28,0-4.14-1.85-4.14-4.13s1.86-4.13,4.14-4.13,4.14,1.85,4.14,4.13-1.86,4.13-4.14,4.13ZM36.45,25.38c-1.81,0-3.29-1.47-3.29-3.27s1.47-3.27,3.29-3.27,3.29,1.47,3.29,3.27-1.47,3.27-3.29,3.27Z"/></svg>';
    }
}

if (!function_exists('yooadmin_get_admin_menu_icon_data_uri')) {
    /**
     * Data URI for the wp-admin left-menu icon.
     */
    function yooadmin_get_admin_menu_icon_data_uri(): string
    {
        return 'data:image/svg+xml;base64,' . base64_encode(yooadmin_get_brand_icon_svg());
    }
}

/** Read redirect setting (from options) */
if (!function_exists('yooadmin_is_redirect_enabled')) {
    function yooadmin_is_redirect_enabled(): bool {
        if (function_exists('yooadmin_get_option')) {
            return (bool) yooadmin_get_option('redirect_dashboard', false);
        }
        $opts = (array) get_option('yooadmin_options', []);
        return !empty($opts['redirect_dashboard']);
    }
}

/** Resolve base file for template paths */
if (!function_exists('yooadmin_base_file')) {
    function yooadmin_base_file(): string {
        return defined('YOOADMIN_PLUGIN_FILE')
            ? YOOADMIN_PLUGIN_FILE
            : dirname(__DIR__, 2) . '/yooadmin.php';
    }
}

/** Render dashboard template (original behavior) */
function yooadmin_render_dashboard_page(): void {
    if (!current_user_can('read')) {
        wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
    }
    
    // Check if Focus Mode is enabled
    $focus_enabled = function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();
    
    // If Focus Mode is OFF, redirect to enable-focus page
    if (!$focus_enabled) {
        wp_safe_redirect(yooadmin_enable_focus_url());
        exit;
    }

    $tpl = plugin_dir_path(yooadmin_base_file()) . 'templates/yoopixel/admin/pages/dashboard.php';
    if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
        $theme_tpl = YOOAdmin_Admin_Theme_Manager::get_instance()->get_dashboard_template_path();
        if (is_string($theme_tpl) && $theme_tpl !== '') {
            $tpl = $theme_tpl;
        }
    }

    if (file_exists($tpl)) {
        include $tpl;
        return;
    }

    echo '<div class="wrap"><h1>YOOAdmin</h1><p>' . esc_html__( 'Dashboard template not found.', 'yooadmin' ) . '</p></div>';
}

/** Focus-aware entry: render or redirect */
if (!function_exists('yooadmin_render_dashboard_entry')) {
    function yooadmin_render_dashboard_entry(): void {
        // Redirect logic is now in admin_init hook (early, before output)
        // This just renders the page
        yooadmin_render_dashboard_page();
    }
}

/**
 * CRITICAL: Early redirect for wizard protection
 * Must happen in admin_init BEFORE any output
 */
add_action('admin_init', function() {
    // Only check on YOOAdmin pages
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
    $current_page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    
    // Skip if on wizard or setup pages
    if (in_array($current_page, ['yooadmin-setup', 'yooadmin-enable-focus'])) {
        return;
    }
    
    // List of YOOAdmin pages that require wizard completion
    $protected_pages = [
        'yooadmin-dashboard',
        'yooadmin-themes',
        'yooadmin-license',
        'yooadmin-admin-theme-settings',
    ];
    
    // Check if current page is protected
    if (in_array($current_page, $protected_pages)) {
        // ✅ CRITICAL: Redirect to wizard if not completed
        if (!get_option('yooadmin_wizard_completed')) {
            wp_safe_redirect(admin_url('admin.php?page=yooadmin-setup'));
            exit;
        }
    }
}, 1);

add_action(
    'admin_init',
    static function (): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing.
        $current_page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($current_page !== 'yooadmin-dashboard') {
            return;
        }
        if (!function_exists('yooadmin_is_focus_enabled') || yooadmin_is_focus_enabled()) {
            return;
        }
        wp_safe_redirect(admin_url('admin.php?page=yooadmin-enable-focus'));
        exit;
    },
    2
);

/**
 * Strip ALL third-party admin notices on the wizard & enable-focus pages.
 * CSS alone is not enough — some plugins inject markup that bypasses our selectors.
 */
add_action('in_admin_header', function () {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

    if ($page !== 'yooadmin-setup' && $page !== 'yooadmin-enable-focus') {
        return;
    }

    remove_all_actions('admin_notices');
    remove_all_actions('all_admin_notices');
}, 0);

/** -------- YOOPanel new pages (independent views) -------- */

/** Generic safe renderer for a given template filename */
if (!function_exists('yooadmin_render_template_safe')) {
    function yooadmin_render_template_safe(string $filename, string $fallback_title): void {
        // Redirect logic is now in admin_init hook (early, before output)
        
        if (!current_user_can('read')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        $tpl = plugin_dir_path(yooadmin_base_file()) . 'templates/yoopixel/admin/pages/' . ltrim($filename, '/');

        if (file_exists($tpl)) {
            include $tpl;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html($fallback_title) . '</h1><p>' . esc_html__( 'Template not found:', 'yooadmin' ) . ' ' . esc_html($filename) . '</p></div>';
    }
}

/** YOOPanel > Themes */
if (!function_exists('yooadmin_render_themes_page')) {
    function yooadmin_render_themes_page(): void {
        yooadmin_render_template_safe('yoopanel/themes.php', 'YOOPanel — Themes');
    }
}

/** Enable Focus Mode Page */
if (!function_exists('yooadmin_render_enable_focus_page')) {
    function yooadmin_render_enable_focus_page(): void {
        yooadmin_render_template_safe('yoopanel/enable-focus.php', 'Enable Focus Mode');
    }
}

/** Enqueue Enable Focus Mode assets early */
add_action('admin_enqueue_scripts', function($hook) {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
    $current_page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

    if ($current_page === 'yooadmin-enable-focus') {
        $base = plugin_dir_url(yooadmin_base_file());
        $base_path = plugin_dir_path(yooadmin_base_file());

        if (function_exists('yooadmin_enqueue_focus_split_modal_assets')) {
            yooadmin_enqueue_focus_split_modal_assets('yooadmin-enable-focus-modal');
        }

        wp_enqueue_style('yooadmin-enable-focus', $base . 'assets/css/admin/enable-focus.css', ['yooadmin-enable-focus-modal'], YOOADMIN_VERSION);

        wp_add_inline_style(
            'yooadmin-enable-focus',
            'body.yooadmin-enable-focus-body #wpadminbar,body.yooadmin-enable-focus-body #adminmenumain,'
            . 'body.yooadmin-enable-focus-body #adminmenuwrap,body.yooadmin-enable-focus-body #adminmenuback{'
            . 'display:block!important;visibility:visible!important;opacity:1!important;}'
        );

        if (function_exists('yooadmin_focus_page_background_image_url')) {
            $focus_bg_url = yooadmin_focus_page_background_image_url();
            if ($focus_bg_url !== '') {
                wp_add_inline_style(
                    'yooadmin-enable-focus',
                    'body.yooadmin-enable-focus-body::before{background-image:url(' . esc_url($focus_bg_url) . ');}'
                );
            }
        }

        $inline_brand = '';
        if (function_exists('yooadmin_build_css_variables')) {
            $vars = yooadmin_build_css_variables();
            if (is_array($vars) && !empty($vars['css'])) {
                $inline_brand .= (string) $vars['css'];
            }
        }
        if (function_exists('yooadmin_build_latin_font_variable_css')) {
            $inline_brand .= yooadmin_build_latin_font_variable_css();
        }
        if ($inline_brand !== '') {
            wp_add_inline_style('yooadmin-enable-focus', $inline_brand);
        }

        wp_enqueue_script('yooadmin-enable-focus', $base . 'assets/js/admin/enable-focus.js', [], YOOADMIN_VERSION, true);

        $tajawal_deps = [];
        if (function_exists('yooadmin_should_enqueue_tajawal_font') && yooadmin_should_enqueue_tajawal_font()) {
            $tajawal_path = $base_path . 'assets/fonts/tajawal.css';
            if (file_exists($tajawal_path) && !wp_style_is('yooadmin-tajawal-focus', 'enqueued')) {
                wp_enqueue_style(
                    'yooadmin-tajawal-enable-focus',
                    $base . 'assets/fonts/tajawal.css',
                    [],
                    (string) filemtime($tajawal_path)
                );
                $tajawal_deps[] = 'yooadmin-tajawal-enable-focus';
            } elseif (wp_style_is('yooadmin-tajawal-focus', 'enqueued')) {
                $tajawal_deps[] = 'yooadmin-tajawal-focus';
            }
        }

        $focus_on = function_exists('yooadmin_menu_focus_on') && yooadmin_menu_focus_on();
        if (
            !$focus_on
            && (
                (function_exists('yooadmin_is_arabic_admin_ui') && yooadmin_is_arabic_admin_ui())
                || is_rtl()
            )
        ) {
            $rtl_path = $base_path . 'assets/css/admin/rtl-tajawal.css';
            if (file_exists($rtl_path) && !wp_style_is('yooadmin-rtl-tajawal', 'enqueued')) {
                wp_enqueue_style(
                    'yooadmin-rtl-tajawal-enable-focus',
                    $base . 'assets/css/admin/rtl-tajawal.css',
                    $tajawal_deps,
                    (string) filemtime($rtl_path)
                );
            }
        }
    }
}, 5);

add_filter('admin_body_class', function ($classes) {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing.
    $current_page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    if ($current_page === 'yooadmin-enable-focus') {
        $classes .= ' yooadmin-enable-focus-body';
    }
    return $classes;
}, 5);

/** YOOPanel > License — detect page for early asset loading (avoids FOUC on hard refresh). */
if (!function_exists('yooadmin_is_license_admin_page')) {
    function yooadmin_is_license_admin_page(): bool
    {
        if (!is_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing.
        return isset($_GET['page']) && sanitize_key(wp_unslash($_GET['page'])) === 'yooadmin-license';
    }
}

if (!function_exists('yooadmin_enqueue_license_page_assets')) {
    /**
     * Load license page CSS/JS in <head> via admin_enqueue_scripts (not from the page template).
     */
    function yooadmin_enqueue_license_page_assets(): void
    {
        $base_file = function_exists('yooadmin_base_file') ? yooadmin_base_file() : (defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '');
        if ($base_file === '') {
            return;
        }

        $base_url = defined('YOOADMIN_URL') ? YOOADMIN_URL : plugin_dir_url($base_file);
        $base_dir = plugin_dir_path($base_file);
        $css_abs  = $base_dir . 'assets/css/admin/license.css';
        $js_abs   = $base_dir . 'assets/js/admin/license.js';
        $fallback = defined('YOOADMIN_VERSION') ? YOOADMIN_VERSION : '1.3.6';

        $style_deps = [];
        foreach (['yooadmin-core', 'yooadmin-yoo-buttons'] as $handle) {
            if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
                $style_deps[] = $handle;
            }
        }

        if (file_exists($css_abs)) {
            wp_enqueue_style(
                'yooadmin-license',
                $base_url . 'assets/css/admin/license.css',
                $style_deps,
                (string) filemtime($css_abs)
            );
        } else {
            wp_enqueue_style('yooadmin-license', $base_url . 'assets/css/admin/license.css', $style_deps, $fallback);
        }

        $opts    = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
        $primary = isset($opts['color_primary']) && is_string($opts['color_primary']) ? $opts['color_primary'] : '#eda934';
        wp_add_inline_style(
            'yooadmin-license',
            '.yooadmin-license-page{--yooadmin-primary:' . esc_attr($primary) . ';--yp-primary:' . esc_attr($primary) . ';}'
        );

        if (file_exists($js_abs)) {
            wp_enqueue_script(
                'yooadmin-license',
                $base_url . 'assets/js/admin/license.js',
                ['jquery'],
                (string) filemtime($js_abs),
                true
            );
        } else {
            wp_enqueue_script('yooadmin-license', $base_url . 'assets/js/admin/license.js', ['jquery'], $fallback, true);
        }

        $portal_messages = [
            'confirmDisconnect'         => __('This will disconnect your account from this site. Continue?', 'yooadmin'),
            'confirmDisconnectMsg'      => __('This will disconnect your account from this site. Continue?', 'yooadmin'),
            'confirmDeactivate'         => __('Are you sure you want to disconnect your account?', 'yooadmin'),
            'confirmDeactivateMsg'    => __('This will remove the account connection from this site. You can reconnect at any time from your account.', 'yooadmin'),
            'disconnectFailed'          => __('Connection error. Please try again.', 'yooadmin'),
            'cancel'                    => __('Cancel', 'yooadmin'),
            'deactivate'                => __('Disconnect', 'yooadmin'),
            'close'                     => __('Close', 'yooadmin'),
            'licenseDeactivatedTitle'   => __('Account Disconnected Successfully', 'yooadmin'),
            'licenseDeactivatedMessage' => __('Account disconnected successfully!', 'yooadmin'),
            'processing'                => __('Processing...', 'yooadmin'),
        ];

        $portal_connect_url = class_exists('YOOAdmin_License_Manager')
            ? YOOAdmin_License_Manager::get_license_portal_connect_url()
            : '';
        $portal_origin      = '';

        if ($portal_connect_url && strpos($portal_connect_url, 'http') === 0) {
            $parsed = wp_parse_url($portal_connect_url);
            if (!empty($parsed['scheme']) && !empty($parsed['host'])) {
                $portal_origin = $parsed['scheme'] . '://' . $parsed['host'];
                if (!empty($parsed['port'])) {
                    $portal_origin .= ':' . $parsed['port'];
                }
            }
        }

        wp_localize_script('yooadmin-license', 'yooadmLicense', [
            'nonce'            => wp_create_nonce('yooadmin_license_nonce'),
            'ajaxUrl'          => admin_url('admin-ajax.php'),
            'portalMessages'   => $portal_messages,
            'portalConnectUrl' => $portal_connect_url,
            'portalOrigin'     => $portal_origin,
            'termsUrl'         => 'https://www.yooadmin.io/terms-of-service/',
            'privacyUrl'       => 'https://www.yooadmin.io/privacy-policy/',
            'termsLinkText'    => __('Terms of Service', 'yooadmin'),
            'privacyLinkText'  => __('Privacy Policy', 'yooadmin'),
        ]);

        wp_add_inline_script(
            'yooadmin-license',
            'jQuery(document).ready(function($){var urlParams=new URLSearchParams(window.location.search);var activationCode=urlParams.get("activation_code");if(activationCode){var $form=$("#license-activation-form");var $input=$("#activation-code-input");if($form.length&&$input.length){$input.val(activationCode);setTimeout(function(){$form.trigger("submit");},100);}var cleanUrl=window.location.pathname+"?page=yooadmin-license";window.history.replaceState({},"",cleanUrl);}});'
        );
    }
}

add_action('admin_enqueue_scripts', function () {
    if (!function_exists('yooadmin_is_license_admin_page') || !yooadmin_is_license_admin_page()) {
        return;
    }
    if (!function_exists('yooadmin_enqueue_license_page_assets')) {
        return;
    }
    yooadmin_enqueue_license_page_assets();
}, 20);

add_filter('admin_body_class', function ($classes) {
    if (function_exists('yooadmin_is_license_admin_page') && yooadmin_is_license_admin_page()) {
        $classes .= ' yooadmin-license-admin-page';
    }

    return $classes;
}, 6);

/** YOOPanel > License */
if (!function_exists('yooadmin_render_license_page')) {
    function yooadmin_render_license_page(): void {
        // Redirect logic is now in admin_init hook (early, before output)
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }
        
        // Get license manager instance
        $license_manager = YOOAdmin_License_Manager::get_instance();
        
        // Check license status to ensure we have fresh data
        $license_manager->check_license_status();
        
        // Get updated license data
        $license_data = $license_manager->get_license_data();
        $is_active = $license_manager->is_license_active();
        
        // Load template
        $tpl = apply_filters(
            'yooadmin_license_page_template',
            plugin_dir_path(yooadmin_base_file()) . 'templates/admin/license-page.php'
        );
        
        if (file_exists($tpl)) {
            include $tpl;
            return;
        }
        
        echo '<div class="wrap"><h1>' . esc_html__( 'License', 'yooadmin' ) . '</h1><p>' . esc_html__( 'Template not found.', 'yooadmin' ) . '</p></div>';
    }
}

/** Register menu */
add_action('admin_menu', function () {
    $slug       = yooadmin_dashboard_slug();
    $cap        = 'read';
    $focus_on   = yooadmin_menu_focus_on();
    $redirectOn = yooadmin_is_redirect_enabled();

    $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    $panel_title = isset($opts['panel_title']) && (string) $opts['panel_title'] !== '' ? (string) $opts['panel_title'] : 'YOOAdmin';
    $menu_title = $panel_title;

    $yooadmin_icon_svg = function_exists('yooadmin_get_admin_menu_icon_data_uri')
        ? yooadmin_get_admin_menu_icon_data_uri()
        : 'data:image/svg+xml;base64,' . base64_encode(
            function_exists('yooadmin_get_brand_icon_svg')
                ? yooadmin_get_brand_icon_svg()
                : ''
        );
    
    // Top-level: page title and menu label use panel_title (from options/constants)
    add_menu_page(
        $panel_title,
        $menu_title,
        $cap,
        $slug,
        'yooadmin_render_dashboard_entry',
        $yooadmin_icon_svg,
        80
    );

    // Dashboard submenu (original behavior)
    if ($focus_on && !$redirectOn) {
        add_submenu_page(
            $slug,
            __('Dashboard', 'yooadmin'),
            __('Dashboard', 'yooadmin'),
            $cap,
            $slug,
            'yooadmin_render_dashboard_entry',
            1
        );
    }


    // -------- New independent pages under YOOAdmin (YOOPanel) --------
    $settings_cap = function_exists('yooadmin_required_cap') ? yooadmin_required_cap('settings') : 'manage_options';

    add_submenu_page(
        $slug,
        __('Themes', 'yooadmin'),
        __('Themes', 'yooadmin'),
        $settings_cap,
        'yooadmin-themes',
        'yooadmin_render_themes_page',
        2
    );

    add_submenu_page(
        $slug,
        __('Connect Account', 'yooadmin'),
        __('Connect Account', 'yooadmin'),
        $settings_cap,
        'yooadmin-license',
        'yooadmin_render_license_page',
        6
    );
    
}, 9);

/**
 * Add custom icons to YOOAdmin submenu items
 */
add_filter('yooadmin_menu_tree_item', function($item) {
    if (empty($item['slug'])) {
        return $item;
    }

    if (function_exists('yooadmin_resolve_menu_tree_item_title') && !empty($item['title'])) {
        $item['title'] = yooadmin_resolve_menu_tree_item_title((string) $item['slug'], (string) $item['title']);
    }
    
    // Map submenu slugs to dashicons (core YOOAdmin pages only)
    $icon_map = [
        'yooadmin-dashboard'         => 'dashicons-admin-home',
        'yooadmin-themes'            => 'dashicons-admin-appearance',
        'yooadmin-license'           => 'dashicons-admin-users',
        'yooadmin-users'             => 'dashicons-groups',
        'yooadmin-posts'             => 'dashicons-admin-post',
        'yooadmin-comments'          => 'dashicons-admin-comments',
        'yooadmin-pages'             => 'dashicons-admin-page',
        'yooadmin-categories'        => 'dashicons-category',
        'yooadmin-settings'          => 'dashicons-admin-settings',
        'yooadmin-my-preferences'    => 'dashicons-admin-users',
        'yooadmin-speed-booster'     => 'dashicons-performance',
        // WordPress core pages - Add new
        'post-new.php'               => 'dashicons-plus-alt',
        'post-new.php?post_type=page'=> 'dashicons-plus-alt',
        'plugin-install.php'         => 'dashicons-plus-alt',
        'theme-install.php'          => 'dashicons-plus-alt',
        'themes.php?page=theme-install.php' => 'dashicons-plus-alt',
        // Editors
        'theme-editor.php'           => 'dashicons-editor-code',
        'plugin-editor.php'          => 'dashicons-editor-code',
    ];
    
    // Apply icon if found in map
    if (isset($icon_map[$item['slug']])) {
        $item['icon'] = $icon_map[$item['slug']];
    }
    
    // Special handling for "Add" pages (check if slug contains certain keywords)
    if (empty($item['icon']) || $item['icon'] === 'dashicons-admin-generic') {
        $slug_lower = strtolower($item['slug']);
        $title_lower = isset($item['title']) ? strtolower($item['title']) : '';
        
        // Check if it's an "Add" page
        if (strpos($title_lower, 'add') !== false || 
            strpos($slug_lower, 'new') !== false || 
            strpos($slug_lower, 'install') !== false) {
            $item['icon'] = 'dashicons-plus-alt';
        }
    }
    
    return $item;
}, 10);

/**
 * Hidden route for Focus Mode — must stay registered while Focus is ON so
 * disable-focus redirects (page=yooadmin-enable-focus&yoo=off) do not wp_die.
 */
add_action('admin_menu', function (): void {
    if (!get_option('yooadmin_wizard_completed') || !function_exists('yooadmin_render_enable_focus_page')) {
        return;
    }

    $focus_cap = function_exists('yooadmin_focus_preference_capability')
        ? yooadmin_focus_preference_capability()
        : 'read';
    $slug = function_exists('yooadmin_enable_focus_slug')
        ? yooadmin_enable_focus_slug()
        : 'yooadmin-enable-focus';

    add_submenu_page(
        null,
        __('Focus Mode', 'yooadmin'),
        __('Focus Mode', 'yooadmin'),
        $focus_cap,
        $slug,
        'yooadmin_render_enable_focus_page'
    );
}, 8);

/**
 * Late pruning:
 * - If Focus is OFF, remove ALL submenus and add a single "Enable Focus Mode" submenu.
 * - CRITICAL: Only show "Enable Focus Mode" if wizard is completed (terms accepted)
 */
add_action('admin_menu', function () {
    global $submenu;
    $parent = yooadmin_dashboard_slug();
    
    if (!yooadmin_menu_focus_on()) {
        if (isset($submenu[$parent])) {
            $submenu[$parent] = [];
        }

        // Only add "Focus Mode" submenu if wizard is completed (terms accepted)
        if (get_option('yooadmin_wizard_completed')) {
            $focus_cap = function_exists('yooadmin_focus_preference_capability')
                ? yooadmin_focus_preference_capability()
                : 'read';
            $slug = function_exists('yooadmin_enable_focus_slug')
                ? yooadmin_enable_focus_slug()
                : 'yooadmin-enable-focus';

            $submenu[$parent][] = [
                __('Focus Mode', 'yooadmin'),
                $focus_cap,
                $slug,
                __('Focus Mode', 'yooadmin'),
            ];
        }
    } elseif (yooadmin_is_redirect_enabled()) {
        remove_submenu_page($parent, $parent);
    }

    if (isset($submenu[$parent]) && is_array($submenu[$parent])) {
        $deduped = [];
        $seen_slugs = [];
        foreach ($submenu[$parent] as $item) {
            $item_slug = isset($item[2]) ? (string) $item[2] : '';
            if ($item_slug !== '' && isset($seen_slugs[$item_slug])) {
                continue;
            }
            if ($item_slug !== '') {
                $seen_slugs[$item_slug] = true;
            }
            $deduped[] = $item;
        }
        $submenu[$parent] = $deduped;
    }
}, 99);


