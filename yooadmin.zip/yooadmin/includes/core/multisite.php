<?php
/**
 * YOOAdmin multisite admin integration.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_multisite_text_domain')) {
    function yooadmin_multisite_text_domain(): string
    {
        return 'yooadmin';
    }
}

if (!function_exists('yooadmin_multisite_user_can_read_blog')) {
    function yooadmin_multisite_user_can_read_blog(int $blog_id): bool
    {
        return yooadmin_current_user_can_for_site($blog_id, 'read');
    }
}

if (!function_exists('yooadmin_inject_shell_on_network')) {
    function yooadmin_inject_shell_on_network(): bool
    {
        if (!is_multisite() || !yooadmin_is_network_admin_request()) {
            return true;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        /**
         * Filter whether the YOOAdmin shell is rendered in network admin.
         *
         * @param bool $enabled Default true when focus mode is on.
         */
        return (bool) apply_filters('yooadmin_inject_shell_on_network', true);
    }
}

if (!function_exists('yooadmin_network_admin_shell_active')) {
    function yooadmin_network_admin_shell_active(): bool
    {
        if (!is_multisite() || !yooadmin_is_network_admin_request()) {
            return false;
        }

        if (!yooadmin_inject_shell_on_network()) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled')) {
            return (bool) yooadmin_is_focus_enabled();
        }

        return true;
    }
}

if (!function_exists('yooadmin_is_multisite_subsite_admin_request')) {
    function yooadmin_is_multisite_subsite_admin_request(): bool
    {
        if (!is_multisite() || !is_admin()) {
            return false;
        }

        if (function_exists('yooadmin_is_network_admin_request')) {
            return !yooadmin_is_network_admin_request();
        }

        return !is_network_admin();
    }
}

if (!function_exists('yooadmin_should_mirror_admin_bar_in_breadcrumbs')) {
    /**
     * Client subsite dashboards: YOOAdmin shortcuts only (no third-party admin-bar mirrors).
     */
    function yooadmin_should_mirror_admin_bar_in_breadcrumbs(): bool
    {
        return !(function_exists('yooadmin_is_multisite_subsite_admin_request') && yooadmin_is_multisite_subsite_admin_request());
    }
}

if (!function_exists('yooadmin_show_subsite_network_admin_breadcrumbs_link')) {
    function yooadmin_show_subsite_network_admin_breadcrumbs_link(): bool
    {
        if (!function_exists('yooadmin_is_multisite_subsite_admin_request') || !yooadmin_is_multisite_subsite_admin_request()) {
            return false;
        }

        return function_exists('yooadmin_user_can_access_network_admin') && yooadmin_user_can_access_network_admin();
    }
}

if (!function_exists('yooadmin_multisite_filter_toolbar_shortcut_ids_for_subsite')) {
    /**
     * @param array<int, array<string, mixed>> $shortcuts
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_filter_toolbar_shortcut_ids_for_subsite(array $shortcuts): array
    {
        if (!function_exists('yooadmin_is_multisite_subsite_admin_request') || !yooadmin_is_multisite_subsite_admin_request()) {
            return $shortcuts;
        }

        if (function_exists('yooadmin_multisite_subsite_filter_toolbar_shortcuts')) {
            $shortcuts = yooadmin_multisite_subsite_filter_toolbar_shortcuts($shortcuts);
        }

        if (!function_exists('yooadmin_show_subsite_network_admin_breadcrumbs_link') || !yooadmin_show_subsite_network_admin_breadcrumbs_link()) {
            return $shortcuts;
        }

        $filtered = [];
        foreach ($shortcuts as $shortcut) {
            if (!is_array($shortcut)) {
                continue;
            }

            $id = isset($shortcut['id']) ? (string) $shortcut['id'] : '';
            if ($id === 'yooadmin-network-admin') {
                continue;
            }

            $filtered[] = $shortcut;
        }

        return array_values($filtered);
    }
}

if (!function_exists('yooadmin_user_can_access_network_admin')) {
    function yooadmin_user_can_access_network_admin(): bool
    {
        if (!is_multisite() || !is_user_logged_in()) {
            return false;
        }

        return is_super_admin() || current_user_can('manage_network');
    }
}

if (!function_exists('yooadmin_is_network_admin_request')) {
    /**
     * True when the current admin request is network-scoped.
     *
     * Uses is_network_admin() with a URI fallback for edge cases where the
     * network bootstrap flag is not set yet during shell rendering.
     */
    function yooadmin_is_network_admin_request(): bool
    {
        if (!is_multisite()) {
            return false;
        }

        if (is_network_admin()) {
            return true;
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only request path detection.
        $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';
        if ($request_uri !== '' && strpos($request_uri, '/wp-admin/network/') !== false) {
            return true;
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only script path detection.
        $script = isset($_SERVER['PHP_SELF']) ? (string) wp_unslash($_SERVER['PHP_SELF']) : '';
        if ($script !== '' && strpos($script, '/wp-admin/network/') !== false) {
            return true;
        }

        return false;
    }
}

if (!function_exists('yooadmin_multisite_network_users_list_url')) {
    function yooadmin_multisite_network_users_list_url(): string
    {
        if (function_exists('yooadmin_network_users_should_use') && yooadmin_network_users_should_use()) {
            return yooadmin_network_users_list_url();
        }

        return network_admin_url('users.php');
    }
}

if (!function_exists('yooadmin_multisite_network_user_edit_url')) {
    function yooadmin_multisite_network_user_edit_url(int $user_id): string
    {
        if ($user_id <= 0) {
            return '';
        }

        if (function_exists('yooadmin_network_users_should_use') && yooadmin_network_users_should_use()) {
            return yooadmin_network_user_edit_url($user_id);
        }

        return network_admin_url('user-edit.php?user_id=' . $user_id);
    }
}

if (!function_exists('yooadmin_multisite_network_user_new_url')) {
    function yooadmin_multisite_network_user_new_url(): string
    {
        if (function_exists('yooadmin_network_user_new_should_use') && yooadmin_network_user_new_should_use()) {
            return yooadmin_network_user_new_url();
        }

        return network_admin_url('user-new.php');
    }
}

if (!function_exists('yooadmin_multisite_map_url_to_network_users')) {
    /**
     * Rewrites site-scoped YOOAdmin/core user URLs to network admin users screens.
     */
    function yooadmin_multisite_map_url_to_network_users(string $url): string
    {
        if ($url === '' || !is_multisite()) {
            return $url;
        }

        $path  = (string) wp_parse_url($url, PHP_URL_PATH);
        $query = (string) wp_parse_url($url, PHP_URL_QUERY);
        if ($path === '') {
            return $url;
        }

        $script = basename(strtok($path, '?'));
        $page   = '';
        $params = [];
        if ($script === 'admin.php' && $query !== '') {
            parse_str($query, $params);
            $page = isset($params['page']) ? sanitize_key((string) $params['page']) : '';
        }

        if ($page === 'yooadmin-users') {
            $redirect = yooadmin_multisite_network_users_list_url();
            unset($params['page']);
            if (!empty($params)) {
                $redirect = add_query_arg($params, $redirect);
            }

            return $redirect;
        }

        if ($page === 'yooadmin-users-new') {
            return yooadmin_multisite_network_user_new_url();
        }

        if ($page === 'yooadmin-user' && isset($params['user_id'])) {
            return yooadmin_multisite_network_user_edit_url((int) $params['user_id']);
        }

        if ($page === 'yooadmin-network-user' && isset($params['user_id'])) {
            return yooadmin_network_user_edit_url((int) $params['user_id']);
        }

        if (in_array($script, ['users.php', 'user-new.php', 'user-edit.php'], true) && strpos($path, '/wp-admin/network/') === false) {
            return function_exists('yooadmin_fix_network_admin_url')
                ? yooadmin_fix_network_admin_url($url)
                : network_admin_url($script);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_shell_home_url')) {
    function yooadmin_shell_home_url(): string
    {
        if (yooadmin_is_network_admin_request()) {
            if (function_exists('yooadmin_network_dashboard_url')) {
                return yooadmin_network_dashboard_url();
            }

            return network_admin_url('index.php');
        }

        if (function_exists('yooadmin_dashboard_url')) {
            $opts = (array) get_option('yooadmin_options', []);
            $redirect_enabled = array_key_exists('redirect_dashboard', $opts)
                ? !empty($opts['redirect_dashboard'])
                : true;

            if (!$redirect_enabled) {
                return add_query_arg('yooadmin_no_redirect', '1', admin_url('index.php'));
            }

            return yooadmin_dashboard_url();
        }

        return admin_url('admin.php?page=yooadmin-dashboard');
    }
}

if (!function_exists('yooadmin_license_admin_url')) {
    function yooadmin_license_admin_url(): string
    {
        $target = 'admin.php?page=yooadmin-license';

        if (is_multisite() && is_network_admin()) {
            return get_admin_url((int) get_main_site_id(), $target);
        }

        return admin_url($target);
    }
}

if (!function_exists('yooadmin_admin_menu_url')) {
    function yooadmin_admin_menu_url(string $slug): string
    {
        $resolver = (is_multisite() && is_network_admin()) ? 'network_admin_url' : 'admin_url';

        if (function_exists('yooadmin_resolve_admin_menu_slug_to_url')) {
            return yooadmin_resolve_admin_menu_slug_to_url($slug, $resolver);
        }

        $slug = trim($slug);
        if ($slug === '') {
            return $resolver();
        }

        if (strpos($slug, '/') !== false) {
            return $resolver('admin.php?page=' . $slug);
        }

        if (stripos($slug, 'admin.php') === 0 || strpos($slug, '.php') !== false) {
            return $resolver($slug);
        }

        return $resolver('admin.php?page=' . $slug);
    }
}

if (!function_exists('yooadmin_fix_network_admin_url')) {
    /**
     * Rewrites mistaken site-admin URLs to network-admin paths on multisite.
     */
    function yooadmin_fix_network_admin_url(string $url): string
    {
        if (!is_multisite() || $url === '') {
            return $url;
        }

        $path = wp_parse_url($url, PHP_URL_PATH);
        if (!is_string($path) || $path === '' || strpos($path, '/wp-admin/network/') !== false) {
            return $url;
        }

        if (strpos($path, '/wp-admin/') === false) {
            return $url;
        }

        $query  = wp_parse_url($url, PHP_URL_QUERY);
        $script = basename(strtok($path, '?'));

        $network_scripts = [
            'site-new.php',
            'site-info.php',
            'site-settings.php',
            'site-users.php',
            'site-themes.php',
            'sites.php',
            'user-new.php',
            'users.php',
            'themes.php',
            'theme-install.php',
            'plugins.php',
            'plugin-install.php',
            'plugin-editor.php',
            'settings.php',
            'setup.php',
            'update-core.php',
            'update.php',
            'upgrade.php',
            'index.php',
        ];

        $needs_network = in_array($script, $network_scripts, true);
        if (!$needs_network && $script === 'admin.php' && is_string($query) && $query !== '') {
            parse_str($query, $params);
            $page = isset($params['page']) ? (string) $params['page'] : '';
            if ($page !== '' && (is_network_admin() || strpos($page, 'yooadmin-') === 0)) {
                $needs_network = is_network_admin();
            }
        }

        if (!$needs_network) {
            return $url;
        }

        $fixed_path = preg_replace('#(/wp-admin/)(?!network/)#', '$1network/', $path, 1);
        if (!is_string($fixed_path) || $fixed_path === $path) {
            return $url;
        }

        $rebuilt = $fixed_path;
        if (is_string($query) && $query !== '') {
            $rebuilt .= '?' . $query;
        }

        $scheme = wp_parse_url($url, PHP_URL_SCHEME);
        $host   = wp_parse_url($url, PHP_URL_HOST);
        if ($host) {
            $prefix = ($scheme ? $scheme . '://' : '') . $host;
            $port   = wp_parse_url($url, PHP_URL_PORT);
            if ($port) {
                $prefix .= ':' . $port;
            }

            return $prefix . $rebuilt;
        }

        return $rebuilt;
    }
}

if (!function_exists('yooadmin_multisite_site_label')) {
    function yooadmin_multisite_site_label(int $blog_id, string $text_domain = ''): string
    {
        $name = get_blog_option($blog_id, 'blogname');
        if (is_string($name)) {
            $name = trim($name);
            if ($name !== '') {
                return $name;
            }
        }

        /* translators: %d: site ID. */
        return sprintf(__('Site %d', 'yooadmin'), $blog_id);
    }
}

if (!function_exists('yooadmin_welcome_site_context_user_eligible')) {
    /**
     * Whether the logged-in user should see subsite identity in the welcome card.
     */
    function yooadmin_welcome_site_context_user_eligible(): bool
    {
        if (!is_user_logged_in()) {
            return false;
        }

        if (is_super_admin()) {
            return true;
        }

        if (current_user_can('manage_network')) {
            return true;
        }

        return current_user_can('manage_sites');
    }
}

if (!function_exists('yooadmin_welcome_site_context')) {
    /**
     * Site identity for welcome card when a network admin views a subsite dashboard.
     *
     * @return array{name:string,url:string,url_label:string}|null
     */
    function yooadmin_welcome_site_context(): ?array
    {
        if (!is_multisite() || is_network_admin() || !is_admin()) {
            return null;
        }

        if (!function_exists('yooadmin_welcome_site_context_user_eligible') || !yooadmin_welcome_site_context_user_eligible()) {
            return null;
        }

        $blog_id = (int) get_current_blog_id();
        if ($blog_id <= 0) {
            return null;
        }

        $name = yooadmin_multisite_site_label($blog_id);
        $home_url = get_home_url($blog_id, '/');
        $url_label = function_exists('yooadmin_network_sites_format_url')
            ? yooadmin_network_sites_format_url($home_url)
            : preg_replace('#^https?://#i', '', $home_url);

        if (!is_string($url_label) || $url_label === '') {
            $url_label = $home_url;
        }

        $context = apply_filters(
            'yooadmin_welcome_site_context',
            [
                'name'      => $name,
                'url'       => $home_url,
                'url_label' => untrailingslashit($url_label),
            ]
        );

        if (!is_array($context)) {
            return null;
        }

        return $context;
    }
}

if (!function_exists('yooadmin_welcome_card_user_greeting')) {
    /**
     * Greeting line for the welcome card (always the logged-in user).
     */
    function yooadmin_welcome_card_user_greeting(): string
    {
        $user = wp_get_current_user();
        $display = ($user instanceof WP_User && $user->exists())
            ? $user->display_name
            : __('Admin', 'yooadmin');

        return sprintf(
            /* translators: %s: current user display name */
            __('Hi %s! 👋', 'yooadmin'),
            $display
        );
    }
}

if (!function_exists('yooadmin_welcome_studio_card_content')) {
    /**
     * Studio welcome card: merge saved title/intro; greeting is never taken from options.
     *
     * @param array<string, string> $defaults
     * @return array<string, string>
     */
    function yooadmin_welcome_studio_card_content(array $defaults): array
    {
        $defaults['p1'] = yooadmin_welcome_card_user_greeting();

        $opt = (array) get_option('yooadmin_welcome', []);
        unset($opt['p1']);

        $data       = array_merge($defaults, array_intersect_key($opt, $defaults));
        $data['p1'] = yooadmin_welcome_card_user_greeting();

        return $data;
    }
}

if (!function_exists('yooadmin_welcome_studio_card_ensure_user_greeting')) {
    /**
     * @param array<string, string>|mixed $data
     * @return array<string, string>|mixed
     */
    function yooadmin_welcome_studio_card_ensure_user_greeting($data)
    {
        if (!is_array($data)) {
            return $data;
        }

        $data['p1'] = yooadmin_welcome_card_user_greeting();

        return $data;
    }
}

if (!function_exists('yooadmin_render_welcome_site_context')) {
    function yooadmin_render_welcome_site_context(): void
    {
        $context = yooadmin_welcome_site_context();
        if (!is_array($context)) {
            return;
        }

        $name      = isset($context['name']) ? (string) $context['name'] : '';
        $url       = isset($context['url']) ? (string) $context['url'] : '';
        $url_label = isset($context['url_label']) ? (string) $context['url_label'] : '';
        if ($name === '' || $url === '') {
            return;
        }
        if ($url_label === '') {
            $url_label = $url;
        }
        ?>
        <div class="yp-welcome-site-context">
            <span class="yp-welcome-site-context__pill">
                <span class="yp-welcome-site-context__icon dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
                <span class="yp-welcome-site-context__name"><?php echo esc_html($name); ?></span>
                <span class="yp-welcome-site-context__sep" aria-hidden="true">·</span>
                <a class="yp-welcome-site-context__url" href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">
                    <?php echo esc_html($url_label); ?>
                </a>
            </span>
        </div>
        <?php
    }
}

if (!function_exists('yooadmin_multisite_is_site_usable')) {
    function yooadmin_multisite_is_site_usable(int $blog_id): bool
    {
        $site = get_site($blog_id);
        if (!$site) {
            return false;
        }

        return empty($site->archived) && empty($site->spam) && empty($site->deleted);
    }
}

if (!function_exists('yooadmin_multisite_user_sites')) {
    /**
     * @return array<int, array{id:int,name:string,url:string}>
     */
    function yooadmin_multisite_user_sites(int $limit = 10): array
    {
        if (!is_multisite() || !is_user_logged_in()) {
            return [];
        }

        $limit = max(1, min(50, $limit));
        $sites = [];

        if (is_super_admin()) {
            $site_rows = get_sites(
                [
                    'number'   => $limit,
                    'orderby'  => 'id',
                    'order'    => 'ASC',
                    'public'   => null,
                    'archived' => 0,
                    'spam'     => 0,
                    'deleted'  => 0,
                ]
            );

            foreach ($site_rows as $site_row) {
                if (!is_object($site_row) || empty($site_row->blog_id)) {
                    continue;
                }

                $blog_id = (int) $site_row->blog_id;
                if (!yooadmin_multisite_is_site_usable($blog_id)) {
                    continue;
                }

                $sites[] = [
                    'id'   => $blog_id,
                    'name' => yooadmin_multisite_site_label($blog_id),
                    'url'  => get_admin_url($blog_id),
                ];
            }

            return $sites;
        }

        $user_sites = get_blogs_of_user(get_current_user_id());
        if (!is_array($user_sites)) {
            return [];
        }

        $count = 0;
        foreach ($user_sites as $site) {
            if ($count >= $limit) {
                break;
            }

            if (!is_object($site) || empty($site->userblog_id)) {
                continue;
            }

            $blog_id = (int) $site->userblog_id;

            if (!yooadmin_multisite_user_can_read_blog($blog_id)) {
                continue;
            }

            if (!yooadmin_multisite_is_site_usable($blog_id)) {
                continue;
            }

            $sites[] = [
                'id'   => $blog_id,
                'name' => yooadmin_multisite_site_label($blog_id),
                'url'  => get_admin_url($blog_id),
            ];
            ++$count;
        }

        return $sites;
    }
}

if (!function_exists('yooadmin_multisite_toolbar_shortcuts')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_toolbar_shortcuts(): array
    {
        if (!is_multisite() || !is_user_logged_in()) {
            return [];
        }

        $shortcuts = [];

        if (is_network_admin()) {
            if (yooadmin_multisite_user_can_read_blog((int) get_current_blog_id())) {
                $shortcuts[] = [
                    'id'         => 'yooadmin-site-admin',
                    'label'      => '',
                    'href'       => get_admin_url((int) get_current_blog_id()),
                    'tooltip'    => __('Site Admin', 'yooadmin'),
                    'icon_class' => 'dashicons dashicons-admin-home',
                    'badge'      => '',
                    'target'     => '',
                    'children'   => [],
                ];
            }
        } elseif (yooadmin_user_can_access_network_admin()) {
            $shortcuts[] = [
                'id'         => 'yooadmin-network-admin',
                'label'      => '',
                'href'       => network_admin_url(),
                'tooltip'    => __('Network Admin', 'yooadmin'),
                'icon_class' => 'dashicons dashicons-admin-multisite',
                'badge'      => '',
                'target'     => '',
                'children'   => [],
            ];
        }

        $sites = yooadmin_multisite_user_sites();
        if ($sites) {
            $children = [];

            if (yooadmin_user_can_access_network_admin() && !is_network_admin()) {
                $children[] = [
                    'id'         => 'yooadmin-network-admin-link',
                    'label'      => __('Network Admin', 'yooadmin'),
                    'href'       => network_admin_url(),
                    'icon_class' => 'dashicons dashicons-admin-multisite',
                    'target'     => '',
                    'badge'      => '',
                ];
            }

            foreach ($sites as $site) {
                $children[] = [
                    'id'         => 'yooadmin-site-' . (int) $site['id'],
                    'label'      => (string) $site['name'],
                    'href'       => (string) $site['url'],
                    'icon_class' => 'dashicons dashicons-admin-site',
                    'target'     => '',
                    'badge'      => '',
                ];
            }

            if ($children) {
                $shortcuts[] = [
                    'id'         => 'yooadmin-my-sites',
                    'label'      => '',
                    'href'       => $children[0]['href'],
                    'tooltip'    => __('My Sites', 'yooadmin'),
                    'icon_class' => 'dashicons dashicons-admin-site-alt3',
                    'badge'      => '',
                    'target'     => '',
                    'children'   => $children,
                ];
            }
        }

        /**
         * Filter multisite shortcuts shown in the YOOAdmin header toolbar.
         *
         * @param array<int, array<string, mixed>> $shortcuts
         */
        $shortcuts = apply_filters('yooadmin_multisite_toolbar_shortcuts', $shortcuts);

        if (is_network_admin()) {
            $shortcuts = yooadmin_multisite_network_filter_toolbar_shortcuts($shortcuts);
        }

        if (function_exists('yooadmin_multisite_filter_toolbar_shortcut_ids_for_subsite')) {
            $shortcuts = yooadmin_multisite_filter_toolbar_shortcut_ids_for_subsite($shortcuts);
        }

        return $shortcuts;
    }
}

if (!function_exists('yooadmin_multisite_user_menu_links')) {
    /**
     * @return array<int, array{label:string,href:string,icon_class?:string}>
     */
    function yooadmin_multisite_user_menu_links(): array
    {
        if (!is_multisite() || !is_user_logged_in()) {
            return [];
        }

        $links = [];

        if (is_network_admin()) {
            $links[] = [
                'label'      => __('Site Admin', 'yooadmin'),
                'href'       => get_admin_url((int) get_current_blog_id()),
                'icon_class' => 'dashicons dashicons-admin-home',
            ];
        } elseif (yooadmin_user_can_access_network_admin()) {
            $links[] = [
                'label'      => __('Network Admin', 'yooadmin'),
                'href'       => network_admin_url(),
                'icon_class' => 'dashicons dashicons-admin-multisite',
            ];
        }

        /**
         * Filter extra user-menu links rendered in the YOOAdmin header.
         *
         * @param array<int, array{label:string,href:string,icon_class?:string}> $links
         */
        return apply_filters('yooadmin_multisite_user_menu_links', $links);
    }
}

if (!function_exists('yooadmin_plugins_manager_should_use')) {
    /**
     * Native plugins.php is styled in place — no separate manager route.
     *
     * @return bool
     */
    function yooadmin_plugins_manager_should_use(): bool
    {
        return (bool) apply_filters('yooadmin_plugins_manager_should_use', false);
    }
}

if (!function_exists('yooadmin_plugins_manager_page_title')) {
    function yooadmin_plugins_manager_page_title(): string
    {
        $title = yooadmin_is_network_admin_request()
            ? __('Plugins', 'yooadmin')
            : __('Plugins', 'yooadmin');

        /**
         * Filters the Plugins Manager page title when Plus overrides the route.
         *
         * @param string $title Default title.
         */
        return (string) apply_filters('yooadmin_plugins_manager_page_title', $title);
    }
}

if (!function_exists('yooadmin_plugins_manager_url')) {
    /**
     * Native WordPress plugins list URL (site or network admin).
     *
     * @return string
     */
    function yooadmin_plugins_manager_url(): string
    {
        if (is_multisite() && yooadmin_is_network_admin_request()) {
            $url = network_admin_url('plugins.php');
        } else {
            $url = admin_url('plugins.php');
        }

        /**
         * Filters the Plugins Manager admin URL (Plus may point to yooadmin-plugins).
         *
         * @param string $url Default plugins.php URL.
         */
        return (string) apply_filters('yooadmin_plugins_manager_url', $url);
    }
}

if (!function_exists('yooadmin_themes_manager_should_use')) {
    /**
     * Whether the YOOAdmin Theme Manager route should replace core themes screens.
     *
     * @return bool
     */
    function yooadmin_themes_manager_should_use(): bool
    {
        return (bool) apply_filters('yooadmin_themes_manager_should_use', false);
    }
}

if (!function_exists('yooadmin_theme_manager_user_can')) {
    function yooadmin_theme_manager_user_can(): bool
    {
        if (is_multisite() && is_network_admin()) {
            return current_user_can('install_themes')
                || current_user_can('manage_network_themes')
                || current_user_can('switch_themes');
        }

        return current_user_can('switch_themes');
    }
}

if (!function_exists('yooadmin_theme_manager_url')) {
    /**
     * Theme Manager or classic themes URL (site or network admin).
     *
     * @param array<string, scalar> $args Optional query args.
     * @return string
     */
    function yooadmin_theme_manager_url(array $args = []): string
    {
        if (function_exists('yooadmin_themes_manager_should_use') && yooadmin_themes_manager_should_use()) {
            $base = (is_multisite() && is_network_admin())
                ? network_admin_url('admin.php?page=yooadmin-theme-manager')
                : admin_url('admin.php?page=yooadmin-theme-manager');
        } elseif (is_multisite() && is_network_admin()) {
            $base = network_admin_url('theme-install.php');
        } else {
            $base = admin_url('themes.php');
        }

        $url = $args !== [] ? add_query_arg($args, $base) : $base;

        /**
         * Filters the Theme Manager admin URL (Plus may point to yooadmin-theme-manager).
         *
         * @param string               $url  Resolved URL.
         * @param array<string, scalar> $args Query arguments passed to the helper.
         */
        return (string) apply_filters('yooadmin_theme_manager_url', $url, $args);
    }
}

if (!function_exists('yooadmin_theme_manager_page_title')) {
    function yooadmin_theme_manager_page_title(): string
    {
        $title = (is_multisite() && function_exists('yooadmin_is_network_admin_request') && yooadmin_is_network_admin_request())
            ? __('Themes', 'yooadmin')
            : __('Themes', 'yooadmin');

        /**
         * Filters the Theme Manager page title when Plus overrides the route.
         *
         * @param string $title Default title.
         */
        return (string) apply_filters('yooadmin_theme_manager_page_title', $title);
    }
}

if (!function_exists('yooadmin_network_settings_manager_url')) {
    function yooadmin_network_settings_manager_url(): string
    {
        if (function_exists('yooadmin_network_settings_should_use') && yooadmin_network_settings_should_use()) {
            return yooadmin_network_settings_url();
        }

        return network_admin_url('settings.php');
    }
}

if (!function_exists('yooadmin_network_sites_manager_url')) {
    function yooadmin_network_sites_manager_url(): string
    {
        if (function_exists('yooadmin_network_sites_should_use') && yooadmin_network_sites_should_use()) {
            return yooadmin_network_sites_url();
        }

        return network_admin_url('sites.php');
    }
}

if (!function_exists('yooadmin_network_update_center_manager_url')) {
    function yooadmin_network_update_center_manager_url(): string
    {
        if (function_exists('yooadmin_network_update_center_should_use') && yooadmin_network_update_center_should_use()) {
            return yooadmin_network_update_center_url();
        }

        return network_admin_url('update-core.php');
    }
}

if (!function_exists('yooadmin_render_shell_user_menu_links')) {
    function yooadmin_render_shell_user_menu_links(): void
    {
        foreach (yooadmin_multisite_user_menu_links() as $link) {
            if (!is_array($link) || empty($link['href']) || empty($link['label'])) {
                continue;
            }

            $icon = isset($link['icon_class']) ? (string) $link['icon_class'] : 'dashicons dashicons-admin-site';

            echo '<a href="' . esc_url((string) $link['href']) . '">';
            echo '<span class="' . esc_attr($icon) . '" aria-hidden="true"></span> ';
            echo esc_html((string) $link['label']);
            echo '</a>';
        }
    }
}

if (!function_exists('yooadmin_multisite_user_can_any_cap')) {
    /**
     * @param string[] $caps
     */
    function yooadmin_multisite_user_can_any_cap(array $caps): bool
    {
        if ($caps === []) {
            return true;
        }

        foreach ($caps as $cap) {
            if (is_string($cap) && $cap !== '' && current_user_can($cap)) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('yooadmin_multisite_network_toolbar_href_caps')) {
    /**
     * Required capabilities for a breadcrumbs-toolbar href (any one may grant access).
     *
     * @return string[] Empty array = no extra restriction for this href.
     */
    function yooadmin_multisite_network_toolbar_href_caps(string $href): array
    {
        $href = trim($href);
        if ($href === '' || $href === '#') {
            return [];
        }

        $path  = wp_parse_url($href, PHP_URL_PATH);
        $query = wp_parse_url($href, PHP_URL_QUERY);
        if (!is_string($path)) {
            return [];
        }

        $args = [];
        if (is_string($query) && $query !== '') {
            parse_str($query, $args);
        }

        $page = isset($args['page']) ? sanitize_key((string) $args['page']) : '';

        if ($page === 'yooadmin-plugins') {
            return ['manage_network_plugins', 'activate_plugins'];
        }
        if ($page === 'yooadmin-theme-manager') {
            return ['manage_network_themes', 'install_themes', 'switch_themes'];
        }
        if ($page === 'yooadmin-network-settings') {
            return ['manage_network_options'];
        }
        if ($page === 'yooadmin-extensions' || $page === 'yooadmin-extensions-manager') {
            return ['manage_network_plugins', 'activate_plugins', 'install_plugins'];
        }
        if ($page === 'yooadmin-update-center' || $page === 'yooadmin-network-update-center') {
            return ['update_core', 'update_plugins', 'update_themes', 'update_languages'];
        }

        $basename = basename(untrailingslashit($path));

        if ($basename === 'post-new.php') {
            $post_type = isset($args['post_type']) ? sanitize_key((string) $args['post_type']) : 'post';

            return ($post_type === 'page') ? ['edit_pages', 'edit_posts'] : ['edit_posts'];
        }

        $map = [
            'plugins.php'        => ['manage_network_plugins', 'activate_plugins'],
            'plugin-install.php' => ['install_plugins'],
            'plugin-editor.php'  => ['edit_plugins'],
            'themes.php'         => ['manage_network_themes'],
            'theme-install.php'  => ['install_themes'],
            'theme-editor.php'   => ['edit_themes'],
            'sites.php'          => ['manage_sites'],
            'site-new.php'       => ['manage_sites'],
            'users.php'          => ['manage_network_users'],
            'user-new.php'       => ['create_users'],
            'settings.php'       => ['manage_network_options'],
            'setup.php'          => ['setup_network'],
            'update-core.php'    => ['update_core', 'update_plugins', 'update_themes', 'update_languages'],
            'edit-comments.php'  => ['moderate_comments', 'edit_posts'],
            'media-new.php'      => ['upload_files'],
        ];

        if (isset($map[ $basename ])) {
            return $map[ $basename ];
        }

        $blog_id   = (int) get_current_blog_id();
        $admin_url = get_admin_url($blog_id);
        if ($admin_url !== '' && strpos($href, $admin_url) === 0) {
            return yooadmin_multisite_user_can_read_blog($blog_id) ? [] : ['__deny__'];
        }

        if (strpos($path, '/wp-admin/network/') !== false) {
            return ['manage_network'];
        }

        return [];
    }
}

if (!function_exists('yooadmin_multisite_network_toolbar_shortcut_allowed')) {
    function yooadmin_multisite_network_toolbar_shortcut_allowed(array $shortcut): bool
    {
        if (!is_network_admin() || !is_user_logged_in()) {
            return true;
        }

        $href = isset($shortcut['href']) ? (string) $shortcut['href'] : '';
        $caps = yooadmin_multisite_network_toolbar_href_caps($href);

        if ($caps === ['__deny__']) {
            return false;
        }

        return yooadmin_multisite_user_can_any_cap($caps);
    }
}

if (!function_exists('yooadmin_multisite_network_filter_toolbar_shortcuts')) {
    /**
     * Hide Network Admin breadcrumbs-toolbar shortcuts the current user cannot use.
     *
     * @param array<int, array<string, mixed>> $shortcuts
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_network_filter_toolbar_shortcuts(array $shortcuts): array
    {
        if (!is_multisite() || !is_network_admin() || !is_user_logged_in()) {
            return $shortcuts;
        }

        $filtered = [];

        foreach ($shortcuts as $shortcut) {
            if (!is_array($shortcut)) {
                continue;
            }

            $children = isset($shortcut['children']) && is_array($shortcut['children'])
                ? yooadmin_multisite_network_filter_toolbar_shortcuts($shortcut['children'])
                : [];
            $shortcut['children'] = $children;

            $href     = isset($shortcut['href']) ? (string) $shortcut['href'] : '';
            $self_ok  = yooadmin_multisite_network_toolbar_shortcut_allowed($shortcut);
            $has_menu = ($href === '' || $href === '#') && $children !== [];

            if (!$self_ok && !$has_menu) {
                continue;
            }

            if (!$self_ok && $has_menu) {
                $shortcut['href'] = $children[0]['href'] ?? '#';
            }

            if (($href === '' || $href === '#') && $children === [] && !$self_ok) {
                continue;
            }

            $filtered[] = $shortcut;
        }

        return array_values($filtered);
    }
}

if (!function_exists('yooadmin_multisite_subsite_toolbar_shortcut_allowed')) {
    function yooadmin_multisite_subsite_toolbar_shortcut_allowed(array $shortcut): bool
    {
        if (!function_exists('yooadmin_is_multisite_subsite_admin_request') || !yooadmin_is_multisite_subsite_admin_request()) {
            return true;
        }

        if (!is_user_logged_in()) {
            return false;
        }

        $id = isset($shortcut['id']) ? (string) $shortcut['id'] : '';
        if ($id === 'yooadmin-plugins') {
            return yooadmin_multisite_user_can_any_cap(['activate_plugins', 'manage_network_plugins']);
        }

        $href = isset($shortcut['href']) ? (string) $shortcut['href'] : '';
        $caps = yooadmin_multisite_network_toolbar_href_caps($href);

        if ($caps === ['__deny__']) {
            return false;
        }

        return yooadmin_multisite_user_can_any_cap($caps);
    }
}

if (!function_exists('yooadmin_multisite_subsite_filter_toolbar_shortcuts')) {
    /**
     * Hide subsite breadcrumbs-toolbar shortcuts the current user cannot use.
     *
     * @param array<int, array<string, mixed>> $shortcuts
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_subsite_filter_toolbar_shortcuts(array $shortcuts): array
    {
        if (!is_multisite()
            || !function_exists('yooadmin_is_multisite_subsite_admin_request')
            || !yooadmin_is_multisite_subsite_admin_request()
            || !is_user_logged_in()
        ) {
            return $shortcuts;
        }

        $filtered = [];

        foreach ($shortcuts as $shortcut) {
            if (!is_array($shortcut)) {
                continue;
            }

            $children = isset($shortcut['children']) && is_array($shortcut['children'])
                ? yooadmin_multisite_subsite_filter_toolbar_shortcuts($shortcut['children'])
                : [];
            $shortcut['children'] = $children;

            $href     = isset($shortcut['href']) ? (string) $shortcut['href'] : '';
            $self_ok  = yooadmin_multisite_subsite_toolbar_shortcut_allowed($shortcut);
            $has_menu = ($href === '' || $href === '#') && $children !== [];

            if (!$self_ok && !$has_menu) {
                continue;
            }

            if (!$self_ok && $has_menu) {
                $shortcut['href'] = $children[0]['href'] ?? '#';
            }

            if (($href === '' || $href === '#') && $children === [] && !$self_ok) {
                continue;
            }

            $filtered[] = $shortcut;
        }

        return array_values($filtered);
    }
}

if (!function_exists('yooadmin_multisite_filter_breadcrumbs_toolbar_shortcut_sets')) {
    /**
     * Apply network/subsite capability filters to mirrored + custom toolbar shortcut sets.
     *
     * @param array<int, array<string, mixed>> $mirrored
     * @param array<int, array<string, mixed>> $custom
     * @return array{0: array<int, array<string, mixed>>, 1: array<int, array<string, mixed>>}
     */
    function yooadmin_multisite_filter_breadcrumbs_toolbar_shortcut_sets(array $mirrored, array $custom): array
    {
        if (!is_multisite() || !is_user_logged_in()) {
            return [$mirrored, $custom];
        }

        if (is_network_admin() && function_exists('yooadmin_multisite_network_filter_toolbar_shortcuts')) {
            return [
                yooadmin_multisite_network_filter_toolbar_shortcuts($mirrored),
                yooadmin_multisite_network_filter_toolbar_shortcuts($custom),
            ];
        }

        if (function_exists('yooadmin_is_multisite_subsite_admin_request')
            && yooadmin_is_multisite_subsite_admin_request()
            && function_exists('yooadmin_multisite_subsite_filter_toolbar_shortcuts')
        ) {
            return [
                yooadmin_multisite_subsite_filter_toolbar_shortcuts($mirrored),
                yooadmin_multisite_subsite_filter_toolbar_shortcuts($custom),
            ];
        }

        return [$mirrored, $custom];
    }
}

if (!function_exists('yooadmin_multisite_adapt_toolbar_shortcuts')) {
    /**
     * @param array<int, array<string, mixed>> $shortcuts
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_adapt_toolbar_shortcuts(array $shortcuts): array
    {
        if (!is_multisite() || !is_network_admin()) {
            return $shortcuts;
        }

        $blocked = apply_filters(
            'yooadmin_network_admin_blocked_toolbar_ids',
            [
                'yooadmin-settings',
                'yooadmin-extended-settings',
                'yooadmin-preview-site',
                'yooadmin-extended-preview-site',
                'yooadmin-preview-store',
                'yooadmin-extended-preview-store',
            ]
        );

        $filtered = [];
        foreach ($shortcuts as $shortcut) {
            if (!is_array($shortcut)) {
                continue;
            }

            $id = isset($shortcut['id']) ? (string) $shortcut['id'] : '';
            if ($id !== '' && in_array($id, (array) $blocked, true)) {
                continue;
            }

            if ($id === 'yooadmin-plugins') {
                $plugins_url = function_exists('yooadmin_plugins_manager_url')
                    ? yooadmin_plugins_manager_url()
                    : network_admin_url('plugins.php');
                $shortcut['href'] = $plugins_url;
                $shortcut['children'] = [
                    [
                        'label'      => __('Installed Plugins', 'yooadmin'),
                        'href'       => $plugins_url,
                        'icon_class' => 'dashicons dashicons-admin-plugins',
                        'target'     => '',
                    ],
                    [
                        'label'      => __('Add Plugin', 'yooadmin'),
                        'href'       => network_admin_url('plugin-install.php'),
                        'icon_class' => 'dashicons dashicons-plus-alt',
                        'target'     => '',
                    ],
                ];
            }

            $filtered[] = $shortcut;
        }

        return yooadmin_multisite_network_filter_toolbar_shortcuts(array_values($filtered));
    }
}

if (!function_exists('yooadmin_dashboard_quick_actions_defaults')) {
    /**
     * Quick Actions for a single-site dashboard (not Network Admin).
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_dashboard_quick_actions_defaults(): array
    {
        return [
            [
                'label'  => __('Add Post', 'yooadmin'),
                'url'    => admin_url('post-new.php'),
                'icon'   => 'dashicons-welcome-write-blog',
                'target' => '_self',
            ],
            [
                'label'  => __('Add Page', 'yooadmin'),
                'url'    => admin_url('post-new.php?post_type=page'),
                'icon'   => 'dashicons-admin-page',
                'target' => '_self',
            ],
            [
                'label'  => __('Media', 'yooadmin'),
                'url'    => admin_url('upload.php'),
                'icon'   => 'dashicons-admin-media',
                'target' => '_self',
            ],
            [
                'label'  => __('Users', 'yooadmin'),
                'url'    => admin_url('admin.php?page=yooadmin-users'),
                'icon'   => 'dashicons-groups',
                'target' => '_self',
            ],
            [
                'label'  => __('Comments', 'yooadmin'),
                'url'    => admin_url('edit-comments.php'),
                'icon'   => 'dashicons-admin-comments',
                'target' => '_self',
            ],
            [
                'label'  => __('Settings', 'yooadmin'),
                'url'    => admin_url('admin.php?page=yooadmin-settings'),
                'icon'   => 'dashicons-admin-settings',
                'target' => '_self',
            ],
        ];
    }
}

if (!function_exists('yooadmin_dashboard_quick_actions_label_map')) {
    /**
     * Known default labels when loading saved quick actions (locale-safe).
     *
     * @return array<string, string>
     */
    function yooadmin_dashboard_quick_actions_label_map(): array
    {
        return [
            'Add Post'           => __('Add Post', 'yooadmin'),
            'Add Page'           => __('Add Page', 'yooadmin'),
            'Media'              => __('Media', 'yooadmin'),
            'Users'              => __('Users', 'yooadmin'),
            'Comments'           => __('Comments', 'yooadmin'),
            'Settings'           => __('Settings', 'yooadmin'),
            'YOOAdmin Settings'  => __('Settings', 'yooadmin'),
            'Add Plugin'         => __('Add Plugin', 'yooadmin'),
        ];
    }
}

if (!function_exists('yooadmin_multisite_network_quick_actions_defaults')) {
    /**
     * Default Quick Actions on the Network Admin dashboard.
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_multisite_network_quick_actions_defaults(): array
    {
        $sites_url = function_exists('yooadmin_network_sites_manager_url')
            ? yooadmin_network_sites_manager_url()
            : network_admin_url('sites.php');

        $plugins_url = network_admin_url('plugins.php');
        if (function_exists('yooadmin_network_settings_manager_url')) {
            $settings_url = yooadmin_network_settings_manager_url();
        }

        $create_site_url = function_exists('yooadmin_network_site_new_url')
            ? yooadmin_network_site_new_url()
            : network_admin_url('site-new.php');

        return [
            [
                'label'  => __('Create Site', 'yooadmin'),
                'url'    => $create_site_url,
                'icon'   => 'dashicons-plus-alt2',
                'target' => '_self',
            ],
            [
                'label'  => __('Sites', 'yooadmin'),
                'url'    => $sites_url,
                'icon'   => 'dashicons-admin-multisite',
                'target' => '_self',
            ],
            [
                'label'  => __('Add User', 'yooadmin'),
                'url'    => network_admin_url('user-new.php'),
                'icon'   => 'dashicons-admin-users',
                'target' => '_self',
            ],
            [
                'label'  => __('Plugins', 'yooadmin'),
                'url'    => $plugins_url,
                'icon'   => 'dashicons-admin-plugins',
                'target' => '_self',
            ],
            [
                'label'  => __('Settings', 'yooadmin'),
                'url'    => $settings_url,
                'icon'   => 'dashicons-admin-settings',
                'target' => '_self',
            ],
            [
                'label'  => __('Site Admin', 'yooadmin'),
                'url'    => get_admin_url((int) get_current_blog_id()),
                'icon'   => 'dashicons-admin-home',
                'target' => '_self',
            ],
        ];
    }
}

if (!function_exists('yooadmin_multisite_site_dashboard_quick_actions_defaults')) {
    /**
     * Subsite dashboard: same Quick Actions as a normal site (not network tiles).
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_multisite_site_dashboard_quick_actions_defaults(): array
    {
        return function_exists('yooadmin_dashboard_quick_actions_defaults')
            ? yooadmin_dashboard_quick_actions_defaults()
            : [];
    }
}

if (!function_exists('yooadmin_multisite_use_site_dashboard_quick_actions')) {
    /**
     * Subsite dashboards use the same Quick Actions as a normal site (not network URLs).
     */
    function yooadmin_multisite_use_site_dashboard_quick_actions(): bool
    {
        return false;
    }
}

if (!function_exists('yooadmin_multisite_quick_action_label_matches')) {
    /**
     * @param string $label Stored tile label.
     * @param string $needle English source string.
     */
    function yooadmin_multisite_quick_action_label_matches(string $label, string $needle): bool
    {
        return $label === $needle || $label === __(
            $needle, // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText -- Matches against known English source keys.
            'yooadmin'
        );
    }
}

if (!function_exists('yooadmin_multisite_reorder_create_site_first')) {
    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_reorder_create_site_first(array $items): array
    {
        $create_index = null;
        $create_item  = null;

        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            $label = isset($item['label']) ? (string) $item['label'] : '';
            if (yooadmin_multisite_quick_action_label_matches($label, 'Create Site')) {
                $create_index = $index;
                $create_item  = $item;
                break;
            }
        }

        if ($create_index === null || $create_index === 0 || !is_array($create_item)) {
            return $items;
        }

        unset($items[ $create_index ]);

        return array_values(array_merge([ $create_item ], $items));
    }
}

if (!function_exists('yooadmin_multisite_resolve_network_quick_action_url')) {
    /**
     * Map core network admin URLs to YOOAdmin network pages (Focus shell).
     */
    function yooadmin_multisite_resolve_network_quick_action_url(string $url): string
    {
        if ($url === '' || !is_multisite()) {
            return $url;
        }

        $path  = (string) wp_parse_url($url, PHP_URL_PATH);
        $query = (string) wp_parse_url($url, PHP_URL_QUERY);
        if ($path === '') {
            return $url;
        }

        $script = basename(strtok($path, '?'));
        $page   = '';
        if ($script === 'admin.php' && $query !== '') {
            parse_str($query, $params);
            $page = isset($params['page']) ? sanitize_key((string) $params['page']) : '';
        }

        $is_network_path = strpos($path, '/wp-admin/network/') !== false;

        if ($page !== '') {
            if (in_array($page, ['yooadmin-users', 'yooadmin-users-new', 'yooadmin-user'], true)) {
                return yooadmin_multisite_map_url_to_network_users($url);
            }

            if (in_array($page, ['yooadmin-network-users', 'yooadmin-network-user-new', 'yooadmin-network-user'], true)) {
                return $url;
            }

            if ($page === 'yooadmin-network-dashboard' && function_exists('yooadmin_network_dashboard_url')) {
                return yooadmin_network_dashboard_url();
            }
            if (
                in_array($page, ['yooadmin-network-sites', 'yooadmin-network-site-new'], true)
                && function_exists('yooadmin_network_sites_manager_url')
            ) {
                return $page === 'yooadmin-network-site-new' && function_exists('yooadmin_network_site_new_url')
                    ? yooadmin_network_site_new_url()
                    : yooadmin_network_sites_manager_url();
            }
            if ($page === 'yooadmin-network-add-site' && function_exists('yooadmin_network_site_new_url')) {
                return yooadmin_network_site_new_url();
            }
            if ($page === 'yooadmin-network-settings' && function_exists('yooadmin_network_settings_manager_url')) {
                return yooadmin_network_settings_manager_url();
            }
            if ($page === 'yooadmin-plugins') {
                return yooadmin_plugins_manager_url();
            }
            if ($page === 'yooadmin-settings' && function_exists('yooadmin_network_settings_manager_url')) {
                return yooadmin_network_settings_manager_url();
            }

            if (strpos($page, 'yooadmin-') === 0 && !$is_network_path && function_exists('yooadmin_fix_network_admin_url')) {
                return yooadmin_fix_network_admin_url($url);
            }

            return $url;
        }

        if (!$is_network_path) {
            return $url;
        }

        switch ($script) {
            case 'index.php':
                if (
                    function_exists('yooadmin_network_dashboard_should_use')
                    && function_exists('yooadmin_network_dashboard_url')
                    && yooadmin_network_dashboard_should_use()
                ) {
                    return yooadmin_network_dashboard_url();
                }
                return $url;
            case 'sites.php':
                return function_exists('yooadmin_network_sites_manager_url')
                    ? yooadmin_network_sites_manager_url()
                    : $url;
            case 'site-new.php':
                return function_exists('yooadmin_network_site_new_url')
                    ? yooadmin_network_site_new_url()
                    : $url;
            case 'users.php':
                return yooadmin_multisite_network_users_list_url();
            case 'user-new.php':
                return yooadmin_multisite_network_user_new_url();
            case 'user-edit.php':
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $user_id = isset($_GET['user_id']) ? absint(wp_unslash((string) $_GET['user_id'])) : 0;
                if ($user_id > 0 && function_exists('yooadmin_multisite_network_user_edit_url')) {
                    return yooadmin_multisite_network_user_edit_url($user_id);
                }
                break;
            case 'settings.php':
                return function_exists('yooadmin_network_settings_manager_url')
                    ? yooadmin_network_settings_manager_url()
                    : $url;
        }

        return $url;
    }
}

if (!function_exists('yooadmin_multisite_normalize_network_quick_actions')) {
    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_normalize_network_quick_actions(array $items): array
    {
        $dashboard_url = function_exists('yooadmin_network_dashboard_url')
            ? yooadmin_network_dashboard_url()
            : network_admin_url('index.php');
        $sites_url = function_exists('yooadmin_network_sites_manager_url')
            ? yooadmin_network_sites_manager_url()
            : network_admin_url('sites.php');
        $settings_url = function_exists('yooadmin_network_settings_manager_url')
            ? yooadmin_network_settings_manager_url()
            : network_admin_url('settings.php');
        $create_site_url = function_exists('yooadmin_network_site_new_url')
            ? yooadmin_network_site_new_url()
            : network_admin_url('site-new.php');
        $plugins_url = network_admin_url('plugins.php');

        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            $label = isset($item['label']) ? (string) $item['label'] : '';
            $url   = isset($item['url']) ? (string) $item['url'] : '';

            if (yooadmin_multisite_quick_action_label_matches($label, 'Admin')) {
                $items[ $index ]['url']        = $dashboard_url;
                $items[ $index ]['icon']       = 'dashicons-dashboard';
                $items[ $index ]['aria_label'] = __('Network Admin', 'yooadmin');
                continue;
            }

            if (yooadmin_multisite_quick_action_label_matches($label, 'Network Admin')) {
                $items[ $index ]['label'] = __('Sites', 'yooadmin');
                $items[ $index ]['url']   = $sites_url;
                $items[ $index ]['icon']  = 'dashicons-admin-multisite';
                continue;
            }

            if (yooadmin_multisite_quick_action_label_matches($label, 'Sites')) {
                $items[ $index ]['url'] = $sites_url;
            } elseif (yooadmin_multisite_quick_action_label_matches($label, 'Create Site')) {
                $items[ $index ]['url'] = $create_site_url;
            } elseif (yooadmin_multisite_quick_action_label_matches($label, 'Settings')) {
                $items[ $index ]['url'] = $settings_url;
            } elseif (
                yooadmin_multisite_quick_action_label_matches($label, 'Plugins')
                || $label === _x('Plugins', 'Quick action tile (short label)', 'yooadmin')
            ) {
                $items[ $index ]['url'] = $plugins_url;
            } elseif (yooadmin_multisite_quick_action_label_matches($label, 'Users')) {
                $items[ $index ]['url'] = yooadmin_multisite_network_users_list_url();
            } elseif (yooadmin_multisite_quick_action_label_matches($label, 'Add User')) {
                $items[ $index ]['url'] = yooadmin_multisite_network_user_new_url();
            }

            if ($url !== '') {
                $url = yooadmin_multisite_resolve_network_quick_action_url($url);
                $url = yooadmin_multisite_map_url_to_network_users($url);
                if (function_exists('yooadmin_fix_network_admin_url')) {
                    $url = yooadmin_fix_network_admin_url($url);
                }
                $items[ $index ]['url'] = $url;
            }
        }

        return yooadmin_multisite_reorder_create_site_first($items);
    }
}

if (!function_exists('yooadmin_multisite_remap_site_dashboard_quick_actions')) {
    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_remap_site_dashboard_quick_actions(array $items): array
    {
        $network_dashboard_url = function_exists('yooadmin_network_dashboard_url')
            ? yooadmin_network_dashboard_url()
            : network_admin_url('index.php');
        $site_plugins_url = admin_url('plugins.php');
        $site_settings_url = admin_url('admin.php?page=yooadmin-settings');

        $admin_index = null;
        $admin_item  = null;

        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            $label = isset($item['label']) ? (string) $item['label'] : '';
            $url   = isset($item['url']) ? (string) $item['url'] : '';

            if (
                yooadmin_multisite_quick_action_label_matches($label, 'Site Admin')
                || yooadmin_multisite_quick_action_label_matches($label, 'Network Admin')
            ) {
                $items[ $index ]['label']      = __('Admin', 'yooadmin');
                $items[ $index ]['url']        = $network_dashboard_url;
                $items[ $index ]['icon']       = 'dashicons-dashboard';
                $items[ $index ]['aria_label'] = __('Network Admin', 'yooadmin');
                $admin_index                   = $index;
                $admin_item                    = $items[ $index ];
                continue;
            }

            if (yooadmin_multisite_quick_action_label_matches($label, 'Network Settings')) {
                $items[ $index ]['label'] = __('Settings', 'yooadmin');
                $items[ $index ]['url']   = $site_settings_url;
                continue;
            }

            if (yooadmin_multisite_quick_action_label_matches($label, 'Network Plugins')) {
                $items[ $index ]['label'] = _x('Plugins', 'Quick action tile (short label)', 'yooadmin');
                $items[ $index ]['url']   = $site_plugins_url;
                continue;
            }

            if (yooadmin_multisite_quick_action_label_matches($label, 'Settings') && strpos($url, '/wp-admin/network/') !== false) {
                $items[ $index ]['url'] = $site_settings_url;
            }

            if (
                (
                    yooadmin_multisite_quick_action_label_matches($label, 'Plugins')
                    || $label === _x('Plugins', 'Quick action tile (short label)', 'yooadmin')
                )
                && strpos($url, '/wp-admin/network/') !== false
            ) {
                $items[ $index ]['url'] = $site_plugins_url;
            }
        }

        if ($admin_item !== null && $admin_index !== null && $admin_index !== 0) {
            unset($items[ $admin_index ]);
            $items = array_values(array_merge([ $admin_item ], $items));
        }

        return $items;
    }
}

if (!function_exists('yooadmin_multisite_apply_site_dashboard_quick_actions')) {
    /**
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_apply_site_dashboard_quick_actions(array $items): array
    {
        return yooadmin_multisite_purify_subsite_quick_actions($items);
    }
}

if (!function_exists('yooadmin_multisite_purify_subsite_quick_actions')) {
    /**
     * On a subsite, keep site-scoped Quick Actions only (strip network admin links).
     *
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_multisite_purify_subsite_quick_actions(array $items): array
    {
        // Subsite dashboards already load this site's yooadmin_quick_actions in the card template.
        // Network operators see the same list as site administrators — no replacement or stripping.
        return is_array($items) ? $items : [];
    }
}

if (!function_exists('yooadmin_multisite_quick_action_points_to_network')) {
    function yooadmin_multisite_quick_action_points_to_network(string $url): bool
    {
        if ($url === '') {
            return false;
        }

        $path = (string) wp_parse_url($url, PHP_URL_PATH);
        if ($path !== '' && strpos($path, '/wp-admin/network') !== false) {
            return true;
        }

        $network_home = network_admin_url();
        if ($network_home !== '' && strpos($url, $network_home) === 0) {
            return true;
        }

        return false;
    }
}

if (!function_exists('yooadmin_multisite_quick_action_is_network_only_label')) {
    function yooadmin_multisite_quick_action_is_network_only_label(string $label): bool
    {
        foreach (['Create Site', 'Sites', 'Site Admin', 'Network Admin'] as $needle) {
            if (yooadmin_multisite_quick_action_label_matches($label, $needle)) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('yooadmin_site_dashboard_quick_actions_defaults')) {
    /**
     * @return array<int, array<string, string>>
     */
    function yooadmin_site_dashboard_quick_actions_defaults(): array
    {
        return function_exists('yooadmin_dashboard_quick_actions_defaults')
            ? yooadmin_dashboard_quick_actions_defaults()
            : [];
    }
}

if (!function_exists('yooadmin_show_subsite_back_to_network_badge')) {
    /**
     * @deprecated Use yooadmin_show_subsite_context_bar().
     */
    function yooadmin_show_subsite_back_to_network_badge(): bool
    {
        return function_exists('yooadmin_show_subsite_context_bar') && yooadmin_show_subsite_context_bar();
    }
}

if (!function_exists('yooadmin_show_subsite_context_bar')) {
    function yooadmin_show_subsite_context_bar(): bool
    {
        if (!is_multisite() || yooadmin_is_network_admin_request() || !is_admin()) {
            return false;
        }

        if (!function_exists('yooadmin_should_inject_shell') || !yooadmin_should_inject_shell()) {
            return false;
        }

        return function_exists('yooadmin_welcome_site_context_user_eligible')
            && yooadmin_welcome_site_context_user_eligible();
    }
}

if (!function_exists('yooadmin_subsite_back_to_network_url')) {
    function yooadmin_subsite_back_to_network_url(): string
    {
        if (function_exists('yooadmin_network_dashboard_url')) {
            return yooadmin_network_dashboard_url();
        }

        return network_admin_url();
    }
}

if (!function_exists('yooadmin_subsite_context_bar_data')) {
    /**
     * @return array{site_name:string,site_url:string,site_url_label:string,back_url:string,back_label:string,message:string}|null
     */
    function yooadmin_subsite_context_bar_data(): ?array
    {
        if (!function_exists('yooadmin_show_subsite_context_bar') || !yooadmin_show_subsite_context_bar()) {
            return null;
        }

        $context = function_exists('yooadmin_welcome_site_context') ? yooadmin_welcome_site_context() : null;
        if (!is_array($context)) {
            return null;
        }

        $site_name = isset($context['name']) ? (string) $context['name'] : '';
        $site_url  = isset($context['url']) ? (string) $context['url'] : '';
        if ($site_name === '' || $site_url === '') {
            return null;
        }

        $site_url_label = isset($context['url_label']) ? (string) $context['url_label'] : '';
        if ($site_url_label === '') {
            $site_url_label = $site_url;
        }

        return [
            'site_name'      => $site_name,
            'site_url'       => $site_url,
            'site_url_label' => $site_url_label,
            'back_url'       => yooadmin_subsite_back_to_network_url(),
            'back_label'     => __('Back', 'yooadmin'),
            'message'        => __('You are now inside site', 'yooadmin'),
        ];
    }
}

if (!function_exists('yooadmin_render_subsite_context_bar')) {
    function yooadmin_render_subsite_context_bar(): void
    {
        $bar = yooadmin_subsite_context_bar_data();
        if (!$bar) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $template  = plugin_dir_path($base_file) . 'templates/yoopixel/admin/layout/subsite-context-bar.php';
        if (!is_readable($template)) {
            return;
        }

        include $template;
    }
}

if (!function_exists('yooadmin_render_subsite_back_to_network_badge')) {
    /** @deprecated Header badge removed; use yooadmin_render_subsite_context_bar(). */
    function yooadmin_render_subsite_back_to_network_badge(): void
    {
    }
}

add_filter(
    'admin_body_class',
    static function (string $classes): string {
        if (function_exists('yooadmin_is_multisite_subsite_admin_request') && yooadmin_is_multisite_subsite_admin_request()) {
            $classes .= ' yooadmin-multisite-subsite-admin';
        }

        if (function_exists('yooadmin_show_subsite_context_bar') && yooadmin_show_subsite_context_bar()) {
            $classes .= ' yp-has-subsite-context-bar';
        }

        return $classes;
    }
);

add_action(
    'admin_enqueue_scripts',
    static function (): void {
        if (!function_exists('yooadmin_show_subsite_context_bar') || !yooadmin_show_subsite_context_bar()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $rel       = 'assets/css/admin/subsite-context-bar.css';
        $path      = plugin_dir_path($base_file) . $rel;
        if (!is_readable($path)) {
            return;
        }

        $deps = ['yooadmin-core'];
        if (wp_style_is('yooadmin-yoo-buttons', 'registered')) {
            $deps[] = 'yooadmin-yoo-buttons';
        }

        wp_enqueue_style(
            'yooadmin-subsite-context-bar',
            plugin_dir_url($base_file) . $rel,
            $deps,
            (string) filemtime($path)
        );

        if (!wp_style_is('yooadmin-yoo-buttons', 'enqueued') && wp_style_is('yooadmin-yoo-buttons', 'registered')) {
            wp_enqueue_style('yooadmin-yoo-buttons');
        }

        $js_rel  = 'assets/js/admin/subsite-context-bar.js';
        $js_path = plugin_dir_path($base_file) . $js_rel;
        if (is_readable($js_path)) {
            wp_enqueue_script(
                'yooadmin-subsite-context-bar',
                plugin_dir_url($base_file) . $js_rel,
                [],
                (string) filemtime($js_path),
                true
            );
        }
    },
    25
);

add_filter(
    'yooadmin_network_dashboard_quick_actions',
    static function ($items) {
        if (!is_array($items)) {
            return $items;
        }

        return yooadmin_multisite_normalize_network_quick_actions($items);
    },
    10
);

add_filter(
    'yooadmin_network_dashboard_overview_links',
    static function ($links) {
        if (!is_array($links)) {
            return $links;
        }

        foreach ($links as $index => $link) {
            if (!is_array($link) || empty($link['url'])) {
                continue;
            }
            $url = (string) $link['url'];
            if (function_exists('yooadmin_multisite_map_url_to_network_users')) {
                $url = yooadmin_multisite_map_url_to_network_users($url);
            }
            if (function_exists('yooadmin_fix_network_admin_url')) {
                $url = yooadmin_fix_network_admin_url($url);
            }
            $links[ $index ]['url'] = $url;
        }

        return $links;
    },
    15
);

add_filter('yooadmin_card_actions', 'yooadmin_multisite_apply_site_dashboard_quick_actions', 15);
add_filter('yooadmin_studio_hub_quick_actions', 'yooadmin_multisite_apply_site_dashboard_quick_actions', 15);
add_filter('yooadmin_studio_hub_card_welcome_content', 'yooadmin_welcome_studio_card_ensure_user_greeting', 99);

add_filter(
    'yooadmin_toolbar_shortcuts',
    static function ($shortcuts) {
        if (function_exists('yooadmin_should_mirror_admin_bar_in_breadcrumbs') && !yooadmin_should_mirror_admin_bar_in_breadcrumbs()) {
            return [];
        }

        return is_array($shortcuts) ? $shortcuts : [];
    },
    5
);

add_filter(
    'yooadmin_toolbar_custom_shortcuts',
    static function ($shortcuts) {
        if (!function_exists('yooadmin_multisite_filter_toolbar_shortcut_ids_for_subsite')) {
            return $shortcuts;
        }

        return yooadmin_multisite_filter_toolbar_shortcut_ids_for_subsite(is_array($shortcuts) ? $shortcuts : []);
    },
    25
);

add_filter(
    'yooadmin_toolbar_shortcuts',
    static function ($shortcuts) {
        if (!is_multisite() || !is_network_admin()) {
            return $shortcuts;
        }

        return yooadmin_multisite_network_filter_toolbar_shortcuts(is_array($shortcuts) ? $shortcuts : []);
    },
    50
);

add_filter(
    'yooadmin_toolbar_custom_shortcuts',
    static function ($shortcuts) {
        if (!is_multisite()) {
            return $shortcuts;
        }

        $shortcuts = is_array($shortcuts) ? $shortcuts : [];
        $shortcuts = yooadmin_multisite_adapt_toolbar_shortcuts($shortcuts);

        $multisite_shortcuts = yooadmin_multisite_toolbar_shortcuts();
        if (!$multisite_shortcuts) {
            return $shortcuts;
        }

        return array_merge($multisite_shortcuts, $shortcuts);
    },
    20
);

add_action(
    'network_admin_menu',
    static function (): void {
        if (!is_multisite() || !function_exists('yooadmin_render_enable_focus_page')) {
            return;
        }

        $slug = function_exists('yooadmin_enable_focus_slug')
            ? yooadmin_enable_focus_slug()
            : 'yooadmin-enable-focus';

        add_submenu_page(
            null,
            __('Focus Mode', 'yooadmin'),
            __('Focus Mode', 'yooadmin'),
            'read',
            $slug,
            'yooadmin_render_enable_focus_page'
        );
    },
    99
);

if (function_exists('yooadmin_require_if_exists')) {
    yooadmin_require_if_exists(__DIR__ . '/multisite-access-denied.php');
} elseif (is_readable(__DIR__ . '/multisite-access-denied.php')) {
    require_once __DIR__ . '/multisite-access-denied.php';
}
