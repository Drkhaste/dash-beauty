<?php
/**
 * YOOAdmin styled multisite access-denied and dead-site splash pages.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_multisite_access_denied_text_domain')) {
    function yooadmin_multisite_access_denied_text_domain(): string
    {
        if (defined('YOO_TD')) {
            return (string) YOO_TD;
        }

        if (defined('YOOADMIN_TD')) {
            return (string) YOOADMIN_TD;
        }

        return 'yooadmin';
    }
}

if (!function_exists('yooadmin_multisite_access_denied_use_styled_splash')) {
    /**
     * Branded splash on all multisite requests when YOOAdmin is active.
     */
    function yooadmin_multisite_access_denied_use_styled_splash(): bool
    {
        return is_multisite();
    }
}

if (!function_exists('yooadmin_multisite_access_denied_with_network_branding')) {
    /**
     * Resolve network (main site) branding options — same source as network admin login.
     *
     * @template T
     * @param callable():T $callback
     * @return T
     */
    function yooadmin_multisite_access_denied_with_network_branding(callable $callback)
    {
        if (!is_multisite()) {
            return $callback();
        }

        $main_id = (int) get_main_site_id();
        $current = (int) get_current_blog_id();

        if ($main_id <= 0 || $main_id === $current) {
            return $callback();
        }

        switch_to_blog($main_id);
        try {
            return $callback();
        } finally {
            restore_current_blog();
        }
    }
}

if (!function_exists('yooadmin_multisite_access_denied_resolve_logo')) {
    /**
     * @return array{url:string,max_w:int}
     */
    function yooadmin_multisite_access_denied_resolve_logo(): array
    {
        return yooadmin_multisite_access_denied_with_network_branding(static function (): array {
            if (function_exists('yooadmin_custom_login_resolve_logo')) {
                $resolved = yooadmin_custom_login_resolve_logo();
                return [
                    'url'   => isset($resolved['url']) ? (string) $resolved['url'] : '',
                    'max_w' => isset($resolved['max_w']) ? (int) $resolved['max_w'] : 220,
                ];
            }

            if (function_exists('yooadmin_custom_login_branding_fallback_url')) {
                return [
                    'url'   => (string) yooadmin_custom_login_branding_fallback_url(),
                    'max_w' => 220,
                ];
            }

            return ['url' => '', 'max_w' => 220];
        });
    }
}

if (!function_exists('yooadmin_multisite_access_denied_get_style_vars')) {
    /**
     * @return array<string, string>
     */
    function yooadmin_multisite_access_denied_get_style_vars(): array
    {
        return yooadmin_multisite_access_denied_with_network_branding(static function (): array {
            if (function_exists('yooadmin_custom_login_get_style_vars')) {
                $vars = yooadmin_custom_login_get_style_vars();
                if (is_array($vars) && $vars !== []) {
                    return $vars;
                }
            }

            return [
                '--yoo-login-panel-bg'   => '#ffffff',
                '--yoo-login-text'       => '#334155',
                '--yoo-login-primary'    => '#eda934',
                '--yoo-login-link'       => '#eda934',
                '--yoo-login-button-bg'  => '#eda934',
                '--yoo-login-button-text'=> '#ffffff',
                '--yoo-login-input-border'=> '#e2e8f0',
            ];
        });
    }
}

if (!function_exists('yooadmin_multisite_access_denied_network_site_name')) {
    function yooadmin_multisite_access_denied_network_site_name(): string
    {
        return yooadmin_multisite_access_denied_with_network_branding(static function (): string {
            return (string) get_bloginfo('name', 'display');
        });
    }
}

if (!function_exists('yooadmin_multisite_access_denied_register_wp_die_handler')) {
    function yooadmin_multisite_access_denied_register_wp_die_handler(string $handler): string
    {
        if (!yooadmin_multisite_access_denied_use_styled_splash()) {
            return $handler;
        }

        return 'yooadmin_multisite_access_denied_wp_die_handler';
    }

    add_filter('wp_die_handler', 'yooadmin_multisite_access_denied_register_wp_die_handler', 20);
}

if (!function_exists('yooadmin_multisite_access_denied_intercept')) {
    /**
     * Runs before core _access_denied_splash (priority 99).
     */
    function yooadmin_multisite_access_denied_intercept(): void
    {
        if (!yooadmin_multisite_access_denied_use_styled_splash()) {
            return;
        }

        remove_action('admin_page_access_denied', '_access_denied_splash', 99);
        yooadmin_multisite_access_denied_splash();
    }

    add_action('admin_page_access_denied', 'yooadmin_multisite_access_denied_intercept', 1);
}

if (!function_exists('yooadmin_multisite_access_denied_splash')) {
    /**
     * Same early-return logic as core _access_denied_splash().
     */
    function yooadmin_multisite_access_denied_splash(): void
    {
        if (!is_user_logged_in() || is_network_admin()) {
            return;
        }

        $blogs = get_blogs_of_user(get_current_user_id());

        if (wp_list_filter($blogs, ['userblog_id' => get_current_blog_id()])) {
            return;
        }

        yooadmin_multisite_access_denied_die([
            'variant'   => 'no_privileges',
            'blog_name' => get_bloginfo('name'),
            'blogs'     => is_array($blogs) ? $blogs : [],
        ]);
    }
}

if (!function_exists('yooadmin_multisite_access_denied_detect_dead_site_variant')) {
    function yooadmin_multisite_access_denied_detect_dead_site_variant(): ?string
    {
        if (!is_multisite() || is_super_admin()) {
            return null;
        }

        $blog = get_site();
        if (!$blog) {
            return null;
        }

        if ('1' === $blog->deleted) {
            return 'deleted';
        }

        if ('1' === $blog->archived || '1' === $blog->spam) {
            return 'archived';
        }

        return null;
    }
}

if (!function_exists('yooadmin_multisite_access_denied_die')) {
    /**
     * @param array{variant?:string,blog_name?:string,blogs?:object[]} $context
     */
    function yooadmin_multisite_access_denied_die(array $context): void
    {
        $GLOBALS['yooadmin_access_denied_ctx'] = $context;
        wp_die('', '', ['response' => 403]);
    }
}

if (!function_exists('yooadmin_multisite_access_denied_output')) {
    /**
     * @param array{variant?:string,blog_name?:string,blogs?:object[]} $context
     * @param array<string, mixed>                                     $parsed_args
     */
    function yooadmin_multisite_access_denied_output(array $context, array $parsed_args): bool
    {
        if (!defined('YOOADMIN_DIR')) {
            return false;
        }

        $template = YOOADMIN_DIR . 'templates/login/access-denied-splash.php';
        if (!is_readable($template)) {
            return false;
        }

        status_header((int) ($parsed_args['response'] ?? 403));
        nocache_headers();

        $blog_name = (string) ($context['blog_name'] ?? get_bloginfo('name'));
        $blogs     = isset($context['blogs']) && is_array($context['blogs']) ? $context['blogs'] : [];
        $variant   = isset($context['variant']) ? (string) $context['variant'] : 'no_privileges';

        include $template;
        die;
    }
}

if (!function_exists('yooadmin_multisite_access_denied_wp_die_handler')) {
    /**
     * @param string|WP_Error $message
     * @param string            $title
     * @param string|array      $args
     */
    function yooadmin_multisite_access_denied_wp_die_handler($message, $title = '', $args = [])
    {
        list($message, $title, $parsed_args) = _wp_die_process_input($message, $title, $args);

        if (isset($GLOBALS['yooadmin_access_denied_ctx']) && is_array($GLOBALS['yooadmin_access_denied_ctx'])) {
            $ctx = $GLOBALS['yooadmin_access_denied_ctx'];
            unset($GLOBALS['yooadmin_access_denied_ctx']);

            if (yooadmin_multisite_access_denied_output($ctx, $parsed_args)) {
                return;
            }
        }

        if (!yooadmin_multisite_access_denied_use_styled_splash()) {
            _default_wp_die_handler($message, $title, $args);
            return;
        }

        $dead_variant = yooadmin_multisite_access_denied_detect_dead_site_variant();
        if ($dead_variant !== null) {
            if (yooadmin_multisite_access_denied_output([
                'variant'   => $dead_variant,
                'blog_name' => get_bloginfo('name'),
                'blogs'     => [],
            ], $parsed_args)) {
                return;
            }
        }

        _default_wp_die_handler($message, $title, $args);
    }
}

if (!function_exists('yooadmin_multisite_access_denied_inline_vars')) {
    function yooadmin_multisite_access_denied_inline_vars(): string
    {
        $vars   = yooadmin_multisite_access_denied_get_style_vars();
        $logo   = yooadmin_multisite_access_denied_resolve_logo();
        $logo_w = isset($logo['max_w']) ? (int) $logo['max_w'] : 220;

        $vars['--yoo-login-logo-max-w'] = max(80, min(400, $logo_w)) . 'px';

        $css = 'body.yooadmin-access-denied{';
        foreach ($vars as $key => $value) {
            if ($key === '--yoo-login-logo-url') {
                continue;
            }
            $css .= $key . ':' . esc_html((string) $value) . ';';
        }
        $css .= '}';

        return '<style id="yooadmin-access-denied-vars">' . $css . '</style>';
    }
}

if (!function_exists('yooadmin_multisite_access_denied_assets')) {
    /**
     * @return array{css_url:string,css_ver:string,buttons_css_url:string,buttons_css_ver:string,logo_url:string,logo_w:int,site_name:string,network_name:string,variant:string}
     */
    function yooadmin_multisite_access_denied_assets(): array
    {
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
        $css_path  = $base_file ? plugin_dir_path($base_file) . 'assets/css/login/yoo-access-denied.css' : '';
        $css_url   = $base_file ? plugin_dir_url($base_file) . 'assets/css/login/yoo-access-denied.css' : '';
        $css_ver   = ($css_path && is_readable($css_path)) ? (string) filemtime($css_path) : '1';
        $btn_path  = $base_file ? plugin_dir_path($base_file) . 'assets/css/admin/yp-yoo-buttons.css' : '';
        $btn_url   = $base_file ? plugin_dir_url($base_file) . 'assets/css/admin/yp-yoo-buttons.css' : '';
        $btn_ver   = ($btn_path && is_readable($btn_path)) ? (string) filemtime($btn_path) : '1';

        $logo     = yooadmin_multisite_access_denied_resolve_logo();
        $logo_url = isset($logo['url']) ? (string) $logo['url'] : '';
        $logo_w   = isset($logo['max_w']) ? (int) $logo['max_w'] : 220;

        return [
            'css_url'         => $css_url,
            'css_ver'         => $css_ver,
            'buttons_css_url' => $btn_url,
            'buttons_css_ver' => $btn_ver,
            'logo_url'      => $logo_url,
            'logo_w'        => max(80, min(400, $logo_w)),
            'site_name'     => get_bloginfo('name', 'display'),
            'network_name'  => yooadmin_multisite_access_denied_network_site_name(),
            'variant'       => 'no_privileges',
        ];
    }
}
