<?php
defined('ABSPATH') || exit;

if (!function_exists('yooadmin_focus_modal_promo_image_url')) {
    /**
     * Promo illustration used in welcome / focus split modals and the enable-focus page card.
     */
    function yooadmin_focus_modal_promo_image_url(): string
    {
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $relative  = 'assets/images/welcome-popup-promo.svg';
        $path      = plugin_dir_path($base_file) . $relative;
        $url       = plugin_dir_url($base_file) . $relative;

        if (is_readable($path)) {
            return $url . '?v=' . (string) filemtime($path);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_focus_page_background_image_url')) {
    /**
     * Blurred full-page background on the enable-focus screen and focus admin-bar modal overlay.
     */
    function yooadmin_focus_page_background_image_url(): string
    {
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $relative  = 'assets/images/background-FM.png';
        $path      = plugin_dir_path($base_file) . $relative;
        $url       = plugin_dir_url($base_file) . $relative;

        if (is_readable($path)) {
            return $url . '?v=' . (string) filemtime($path);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_enqueue_focus_split_modal_assets')) {
    function yooadmin_enqueue_focus_split_modal_assets(string $style_handle = 'yooadmin-enable-focus-modal', bool $include_brand_fonts = true): void
    {
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_url  = plugin_dir_url($base_file);
        $base_dir  = plugin_dir_path($base_file);
        $deps      = [];

        if ($include_brand_fonts) {
            $montserrat_path = $base_dir . 'assets/fonts/montserrat.css';
            if (file_exists($montserrat_path)) {
                wp_enqueue_style(
                    'yooadmin-montserrat-focus',
                    $base_url . 'assets/fonts/montserrat.css',
                    [],
                    (string) filemtime($montserrat_path)
                );
                $deps[] = 'yooadmin-montserrat-focus';
            }

            $load_tajawal = function_exists('yooadmin_should_enqueue_tajawal_font')
                ? yooadmin_should_enqueue_tajawal_font()
                : (function_exists('yooadmin_is_arabic_admin_ui') && yooadmin_is_arabic_admin_ui());
            if ($load_tajawal) {
                $tajawal_path = $base_dir . 'assets/fonts/tajawal.css';
                if (file_exists($tajawal_path)) {
                    wp_enqueue_style(
                        'yooadmin-tajawal-focus',
                        $base_url . 'assets/fonts/tajawal.css',
                        [],
                        (string) filemtime($tajawal_path)
                    );
                    $deps[] = 'yooadmin-tajawal-focus';
                }
            }
        }

        wp_enqueue_style('dashicons');

        $welcome_popup_path = $base_dir . 'assets/css/admin/welcome-popup.css';
        if (file_exists($welcome_popup_path)) {
            wp_enqueue_style(
                'yooadmin-welcome-popup',
                $base_url . 'assets/css/admin/welcome-popup.css',
                [],
                (string) filemtime($welcome_popup_path)
            );
            $deps[] = 'yooadmin-welcome-popup';
        }

        $modal_css = $base_dir . 'assets/css/admin/enable-focus-modal.css';
        wp_enqueue_style(
            $style_handle,
            $base_url . 'assets/css/admin/enable-focus-modal.css',
            $deps,
            file_exists($modal_css) ? (string) filemtime($modal_css) : YOOADMIN_VERSION
        );

        $inline_brand = '';
        if (function_exists('yooadmin_build_css_variables')) {
            $vars = yooadmin_build_css_variables();
            if (is_array($vars) && !empty($vars['css'])) {
                $inline_brand .= (string) $vars['css'];
            }
        }
        if (function_exists('yooadmin_build_latin_font_variable_css') && $include_brand_fonts) {
            $inline_brand .= yooadmin_build_latin_font_variable_css();
        }
        if ($inline_brand !== '') {
            wp_add_inline_style($style_handle, $inline_brand);
        }
    }
}

if (!function_exists('yooadmin_render_focus_split_modal')) {
    /**
     * Render the split-layout Focus Mode modal.
     *
     * @param array<string,mixed> $args {
     *     @type string $modal_id   DOM id for the modal root.
     *     @type string $intent     enable|disable
     *     @type string $context    page|admin_bar
     *     @type bool   $can_manage Whether the user can change site-wide policy.
     *     @type string $nonce      AJAX nonce when context is admin_bar.
     *     @type string $promo_url  Promo image URL.
     * }
     */
    function yooadmin_render_focus_split_modal(array $args): void
    {
        $args = wp_parse_args($args, [
            'modal_id'   => 'yoo-enable-focus-modal',
            'intent'     => 'enable',
            'context'    => 'page',
            'can_manage' => false,
            'nonce'      => '',
            'promo_url'  => yooadmin_focus_modal_promo_image_url(),
        ]);

        $modal_id   = sanitize_key((string) $args['modal_id']);
        $intent     = $args['intent'] === 'disable' ? 'disable' : 'enable';
        $context    = $args['context'] === 'admin_bar' ? 'admin_bar' : 'page';
        $can_manage = (bool) $args['can_manage'];
        $promo_url  = esc_url((string) $args['promo_url']);
        $nonce      = (string) $args['nonce'];

        $is_enable = $intent === 'enable';
        $title_id  = $modal_id . '-title';

        if ($is_enable) {
            $title = __('Return to YOOAdmin Workspace', 'yooadmin');
            $lead  = __('Choose how to enable Focus Mode:', 'yooadmin');
        } else {
            $title = __('Disable Focus Mode', 'yooadmin');
            $lead  = __('Choose who should have Focus Mode disabled:', 'yooadmin');
        }

        $radio_name = $context === 'page' ? 'enable_scope' : 'focus_scope';
        $for_all_desc = $is_enable
            ? __('Force all users to use YOOAdmin', 'yooadmin')
            : __('Force all users to use standard WordPress', 'yooadmin');

        $confirm_label = $is_enable ? __('Enable', 'yooadmin') : __('Confirm', 'yooadmin');
        $confirm_enable = $is_enable ? '1' : '0';
        ?>
        <div id="<?php echo esc_attr($modal_id); ?>" class="ywp-overlay yoo-focus-split-modal" hidden aria-hidden="true">
            <div class="ywp-dialog" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr($title_id); ?>">
                <div class="ywp-layout">
                    <div class="ywp-copy">
                        <p class="ywp-eyebrow"><?php esc_html_e('YOOAdmin', 'yooadmin'); ?></p>
                        <h2 id="<?php echo esc_attr($title_id); ?>" class="ywp-title"><?php echo esc_html($title); ?></h2>
                        <p class="ywp-lead"><?php echo esc_html($lead); ?></p>

                        <?php if ($context === 'page') : ?>
                        <form method="post" action="" id="yoo-enable-focus-form">
                            <?php wp_nonce_field('yooadmin_enable_focus', 'yooadmin_focus_nonce'); ?>
                        <?php endif; ?>

                            <div class="yoo-enable-options">
                                <label class="yoo-enable-option">
                                    <input type="radio" name="<?php echo esc_attr($radio_name); ?>" value="user" checked>
                                    <div class="yoo-enable-option-content">
                                        <strong><?php esc_html_e('For me only', 'yooadmin'); ?></strong>
                                        <span><?php esc_html_e('Other users can still choose their preference', 'yooadmin'); ?></span>
                                    </div>
                                </label>

                                <?php if ($can_manage) : ?>
                                <label class="yoo-enable-option">
                                    <input type="radio" name="<?php echo esc_attr($radio_name); ?>" value="all">
                                    <div class="yoo-enable-option-content">
                                        <strong><?php esc_html_e('For everyone', 'yooadmin'); ?></strong>
                                        <span><?php echo esc_html($for_all_desc); ?></span>
                                    </div>
                                </label>
                                <?php endif; ?>
                            </div>

                            <div class="ywp-actions">
                                <button type="button" class="yp-yoo-btn yp-yoo-btn--soft yoo-focus-modal-dismiss yoo-focus-modal-cancel">
                                    <?php esc_html_e('Cancel', 'yooadmin'); ?>
                                </button>
                                <?php if ($context === 'page') : ?>
                                <button type="submit" name="enable_focus" value="1" class="yp-yoo-btn yp-yoo-btn--primary yoo-focus-modal-submit">
                                    <?php echo esc_html($confirm_label); ?>
                                </button>
                                <?php else : ?>
                                <button
                                    type="button"
                                    class="yp-yoo-btn yp-yoo-btn--primary yoo-focus-modal-confirm"
                                    data-enable="<?php echo esc_attr($confirm_enable); ?>"
                                    data-nonce="<?php echo esc_attr($nonce); ?>"
                                >
                                    <?php echo esc_html($confirm_label); ?>
                                </button>
                                <?php endif; ?>
                            </div>

                        <?php if ($context === 'page') : ?>
                        </form>
                        <?php endif; ?>
                    </div>
                    <div class="ywp-visual" aria-hidden="true">
                        <div class="ywp-visual-controls">
                            <button type="button" class="ywp-close yoo-focus-modal-close" aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
                                <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                            </button>
                        </div>
                        <img
                            class="ywp-image"
                            src="<?php echo esc_url($promo_url); ?>"
                            alt=""
                            width="320"
                            height="280"
                            loading="<?php echo $context === 'page' && $is_enable ? 'eager' : 'lazy'; ?>"
                            decoding="async"
                        />
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}
