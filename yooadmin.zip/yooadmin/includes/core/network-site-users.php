<?php
/**
 * YOOAdmin network site users tab.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_site_users_page_slug')) {
    function yooadmin_network_site_users_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_site_users_page_slug', 'yooadmin-network-site-users');
    }
}

if (!function_exists('yooadmin_network_site_users_url')) {
    function yooadmin_network_site_users_url(int $blog_id, array $args = []): string
    {
        if (function_exists('yooadmin_network_site_users_should_use') && !yooadmin_network_site_users_should_use()) {
            $url = network_admin_url('site-users.php?id=' . max(1, $blog_id));
            return $args ? add_query_arg($args, $url) : $url;
        }

        $url = network_admin_url('admin.php?page=' . yooadmin_network_site_users_page_slug());
        $url = add_query_arg('id', max(1, $blog_id), $url);

        if ($args) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_site_users_edit_user_url')) {
    function yooadmin_network_site_users_edit_user_url(int $blog_id, int $user_id): string
    {
        if ($blog_id <= 0 || $user_id <= 0) {
            return '';
        }

        switch_to_blog($blog_id);
        $url = add_query_arg(
            [
                'page'    => 'yooadmin-user',
                'user_id' => $user_id,
            ],
            admin_url('admin.php')
        );
        restore_current_blog();

        return $url;
    }
}

if (!function_exists('yooadmin_network_site_users_can_edit_user')) {
    function yooadmin_network_site_users_can_edit_user(int $blog_id, int $user_id): bool
    {
        if ($blog_id <= 0 || $user_id <= 0) {
            return false;
        }

        switch_to_blog($blog_id);
        $can_edit = current_user_can('edit_user', $user_id);
        restore_current_blog();

        return $can_edit;
    }
}

if (!function_exists('yooadmin_network_site_users_should_use')) {
    function yooadmin_network_site_users_should_use(): bool
    {
        return function_exists('yooadmin_network_site_editor_should_use') && yooadmin_network_site_editor_should_use();
    }
}

if (!function_exists('yooadmin_network_site_users_is_screen')) {
    function yooadmin_network_site_users_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_site_users_page_slug();
    }
}

if (!function_exists('yooadmin_network_site_users_is_removal_protected')) {
    function yooadmin_network_site_users_is_removal_protected(int $user_id): bool
    {
        return $user_id > 0 && is_super_admin($user_id);
    }
}

if (!function_exists('yooadmin_network_site_users_flash_message')) {
    function yooadmin_network_site_users_flash_message(): array
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!isset($_GET['update'])) {
            return ['', ''];
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash query arg.
        $update = sanitize_key(wp_unslash((string) $_GET['update']));

        $map = [
            'adduser'         => [__('User added.', 'yooadmin'), 'success'],
            'err_add_member'  => [__('User is already a member of this site.', 'yooadmin'), 'error'],
            'err_add_fail'    => [__('User could not be added to this site.', 'yooadmin'), 'error'],
            'err_add_notfound'=> [__('Enter the username of an existing user.', 'yooadmin'), 'error'],
            'promote'         => [__('Changed roles.', 'yooadmin'), 'success'],
            'err_promote'     => [__('Select a user to change role.', 'yooadmin'), 'error'],
            'remove'          => [__('User removed from this site.', 'yooadmin'), 'success'],
            'remove_partial'  => [__('Some users were removed. Network super admins were skipped.', 'yooadmin'), 'success'],
            'err_remove'      => [__('Select a user to remove.', 'yooadmin'), 'error'],
            'err_super_admin' => [__('Network super admins cannot be removed from a site.', 'yooadmin'), 'error'],
            'newuser'         => [__('User created.', 'yooadmin'), 'success'],
            'err_new'         => [__('Enter the username and email.', 'yooadmin'), 'error'],
            'err_new_dup'     => [__('Duplicated username or email address.', 'yooadmin'), 'error'],
        ];

        return isset($map[ $update ]) ? $map[ $update ] : ['', ''];
    }
}

if (!function_exists('yooadmin_network_site_users_query_args')) {
    function yooadmin_network_site_users_query_args(int $blog_id): array
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash((string) $_GET['s'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $role   = isset($_GET['role']) ? sanitize_key(wp_unslash((string) $_GET['role'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $paged  = isset($_GET['paged']) ? max(1, absint(wp_unslash((string) $_GET['paged']))) : 1;

        return yooadmin_network_site_users_build_query($blog_id, $search, $role, $paged);
    }
}

if (!function_exists('yooadmin_network_site_users_get_roles')) {
    function yooadmin_network_site_users_get_roles(int $blog_id): array
    {
        switch_to_blog($blog_id);
        $roles = get_editable_roles();
        restore_current_blog();

        return is_array($roles) ? $roles : [];
    }
}

if (!function_exists('yooadmin_network_site_users_build_query')) {
    /**
     * @return array{query_args: array<string, mixed>, search: string, role: string, paged: int, per_page: int}
     */
    function yooadmin_network_site_users_build_query(int $blog_id, string $search = '', string $role = '', int $paged = 1): array
    {
        $per_page = 20;
        $paged    = max(1, $paged);

        $args = [
            'blog_id' => $blog_id,
            'number'  => $per_page,
            'offset'  => ($paged - 1) * $per_page,
            'orderby' => 'display_name',
            'order'   => 'ASC',
        ];

        if ($search !== '') {
            $args['search']         = '*' . $search . '*';
            $args['search_columns'] = ['user_login', 'user_email', 'display_name'];
        }

        if ($role !== '') {
            $args['role'] = $role;
        }

        return [
            'query_args' => $args,
            'search'     => $search,
            'role'       => $role,
            'paged'      => $paged,
            'per_page'   => $per_page,
        ];
    }
}

if (!function_exists('yooadmin_network_site_users_fetch')) {
    /**
     * @return array{users: array<int, WP_User>, total: int, total_pages: int, paged: int, search: string, role: string}
     */
    function yooadmin_network_site_users_fetch(int $blog_id, string $search = '', string $role = '', int $paged = 1): array
    {
        $query       = yooadmin_network_site_users_build_query($blog_id, $search, $role, $paged);
        $user_query  = new WP_User_Query($query['query_args']);
        $users       = $user_query->get_results();
        $total       = (int) $user_query->get_total();
        $total_pages = (int) ceil($total / max(1, (int) $query['per_page']));

        return [
            'users'       => is_array($users) ? $users : [],
            'total'       => $total,
            'total_pages' => $total_pages,
            'paged'       => (int) $query['paged'],
            'search'      => (string) $query['search'],
            'role'        => (string) $query['role'],
        ];
    }
}

if (!function_exists('yooadmin_network_site_users_list_partial')) {
    function yooadmin_network_site_users_list_partial(): string
    {
        if (defined('YOOADMIN_PANEL_DIR')) {
            $path = YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/network-site-users/partials/users-list.php';
            if (is_readable($path)) {
                return $path;
            }
        }

        $fallback = dirname(__DIR__, 2) . '/templates/yoopixel/admin/pages/network-site-users/partials/users-list.php';

        return is_readable($fallback) ? $fallback : '';
    }
}

if (!function_exists('yooadmin_network_site_users_render_list_html')) {
    function yooadmin_network_site_users_render_list_html(int $blog_id, string $search = '', string $role = '', int $paged = 1, bool $can_add_new = true): string
    {
        $data     = yooadmin_network_site_users_fetch($blog_id, $search, $role, $paged);
        $partial  = yooadmin_network_site_users_list_partial();
        $list_url = yooadmin_network_site_users_url($blog_id);
        $td       = yooadmin_network_site_editor_text_domain();

        if (!$partial) {
            return '';
        }

        $users       = $data['users'];
        $total       = $data['total'];
        $total_pages = $data['total_pages'];
        $paged       = $data['paged'];
        $search      = $data['search'];
        $role        = $data['role'];

        ob_start();
        include $partial;

        return (string) ob_get_clean();
    }
}

if (!function_exists('yooadmin_network_site_users_total_label')) {
    function yooadmin_network_site_users_total_label(int $total): string
    {
        $td = yooadmin_network_site_editor_text_domain();

        return sprintf(
            /* translators: %s: number of users. */
            _n('%s user on this site', '%s users on this site', $total, 'yooadmin'),
            number_format_i18n($total)
        );
    }
}

if (!function_exists('yooadmin_network_site_users_ajax_filter')) {
    function yooadmin_network_site_users_ajax_filter(): void
    {
        check_ajax_referer('yooadmin_network_site_users', 'nonce');

        if (!is_multisite() || !current_user_can('manage_sites')) {
            wp_send_json_error(['message' => __('Sorry, you are not allowed to access this page.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $blog_id = isset($_REQUEST['id']) ? absint(wp_unslash((string) $_REQUEST['id'])) : 0;
        if ($blog_id <= 0 || !yooadmin_network_site_editor_get_site($blog_id)) {
            wp_send_json_error(['message' => __('Invalid site ID.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $search = isset($_REQUEST['s']) ? sanitize_text_field(wp_unslash((string) $_REQUEST['s'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $role = isset($_REQUEST['role']) ? sanitize_key(wp_unslash((string) $_REQUEST['role'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $paged = isset($_REQUEST['paged']) ? max(1, absint(wp_unslash((string) $_REQUEST['paged']))) : 1;

        $can_add_new = current_user_can('create_users') && apply_filters('show_network_site_users_add_new_form', true); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
        $data        = yooadmin_network_site_users_fetch($blog_id, $search, $role, $paged);

        wp_send_json_success(
            [
                'html'        => yooadmin_network_site_users_render_list_html($blog_id, $search, $role, $paged, $can_add_new),
                'total'       => $data['total'],
                'total_label' => yooadmin_network_site_users_total_label($data['total']),
                'has_filters' => ($search !== '' || $role !== ''),
            ]
        );
    }
}

add_action('wp_ajax_yooadmin_network_site_users_filter', 'yooadmin_network_site_users_ajax_filter');

if (!function_exists('yooadmin_network_site_users_process_actions')) {
    function yooadmin_network_site_users_process_actions(): bool
    {
        if (!is_multisite() || !is_network_admin() || !current_user_can('manage_sites')) {
            return false;
        }

        if (!yooadmin_network_site_users_is_screen()) {
            return false;
        }

        if (empty($_POST) && empty($_GET['action'])) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $id = isset($_REQUEST['id']) ? absint(wp_unslash((string) $_REQUEST['id'])) : 0;
        if ($id <= 0 || !yooadmin_network_site_editor_get_site($id)) {
            return false;
        }

        $action = '';
        if (!empty($_POST['action']) && '-1' !== $_POST['action']) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $action = sanitize_key(wp_unslash((string) $_POST['action']));
        } elseif (!empty($_POST['action2']) && '-1' !== $_POST['action2']) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $action = sanitize_key(wp_unslash((string) $_POST['action2']));
        } elseif (!empty($_GET['action'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $action = sanitize_key(wp_unslash((string) $_GET['action']));
        }

        if ($action === '' || $action === 'update-site') {
            return false;
        }

        $referer = yooadmin_network_site_users_url($id);
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (isset($_GET['s'])) {
            $referer = add_query_arg('s', sanitize_text_field(wp_unslash((string) $_GET['s'])), $referer);
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (isset($_GET['role'])) {
            $referer = add_query_arg('role', sanitize_key(wp_unslash((string) $_GET['role'])), $referer);
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (isset($_GET['paged'])) {
            $referer = add_query_arg('paged', absint(wp_unslash((string) $_GET['paged'])), $referer);
        }

        $update = '';

        switch ($action) {
            case 'newuser':
                check_admin_referer('add-user', '_wpnonce_add-new-user');
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                $user = isset($_POST['user']) ? wp_unslash($_POST['user']) : [];
                if (!is_array($user) || empty($user['username']) || empty($user['email'])) {
                    $update = 'err_new';
                    break;
                }
                $password = wp_generate_password(12, false);
                $user_id  = wpmu_create_user(sanitize_user((string) $user['username'], true), $password, sanitize_email((string) $user['email']));
                if (false === $user_id) {
                    $update = 'err_new_dup';
                    break;
                }
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                $new_role = isset($_POST['new_role']) ? sanitize_key(wp_unslash((string) $_POST['new_role'])) : '';
                $result   = add_user_to_blog($id, $user_id, $new_role);
                if (is_wp_error($result)) {
                    $update = 'err_add_fail';
                } else {
                    $update = 'newuser';
                    do_action('network_site_users_created_user', $user_id); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
                }
                break;

            case 'adduser':
                check_admin_referer('add-user', '_wpnonce_add-user');
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                $newuser = isset($_POST['newuser']) ? sanitize_user(wp_unslash((string) $_POST['newuser']), true) : '';
                if ($newuser === '') {
                    $update = 'err_add_notfound';
                    break;
                }
                $update = 'adduser';
                $user   = get_user_by('login', $newuser);
                if ($user && $user->exists()) {
                    if (!is_user_member_of_blog($user->ID, $id)) {
                        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                        $new_role = isset($_POST['new_role']) ? sanitize_key(wp_unslash((string) $_POST['new_role'])) : '';
                        $result   = add_user_to_blog($id, $user->ID, $new_role);
                        if (is_wp_error($result)) {
                            $update = 'err_add_fail';
                        }
                    } else {
                        $update = 'err_add_member';
                    }
                } else {
                    $update = 'err_add_notfound';
                }
                break;

            case 'remove':
                if (!current_user_can('remove_users')) {
                    wp_die(esc_html__('Sorry, you are not allowed to remove users.', 'yooadmin'), '', ['response' => 403]);
                }
                check_admin_referer('bulk-users');
                $update  = 'err_remove';
                $removed = 0;
                $skipped = 0;
                if (isset($_REQUEST['users']) && is_array($_REQUEST['users'])) {
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cast to int per user ID in loop.
                    foreach (wp_unslash($_REQUEST['users']) as $user_id) {
                        $user_id = (int) $user_id;
                        if (yooadmin_network_site_users_is_removal_protected($user_id)) {
                            $skipped++;
                            continue;
                        }
                        remove_user_from_blog($user_id, $id);
                        $removed++;
                    }
                    if ($removed > 0 && $skipped > 0) {
                        $update = 'remove_partial';
                    } elseif ($removed > 0) {
                        $update = 'remove';
                    } elseif ($skipped > 0) {
                        $update = 'err_super_admin';
                    }
                } elseif (isset($_GET['user'])) {
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                    $user_id = absint(wp_unslash((string) $_GET['user']));
                    if (yooadmin_network_site_users_is_removal_protected($user_id)) {
                        $update = 'err_super_admin';
                    } else {
                        remove_user_from_blog($user_id, $id);
                        $update = 'remove';
                    }
                }
                break;

            case 'promote':
                check_admin_referer('bulk-users');
                if (!current_user_can('promote_users')) {
                    wp_die(esc_html__('Sorry, you are not allowed to edit this user.', 'yooadmin'), '', ['response' => 403]);
                }
                switch_to_blog($id);
                $editable_roles = get_editable_roles();
                restore_current_blog();
                $editable_roles['none'] = ['name' => __('&mdash; No role for this site &mdash;', 'yooadmin')];
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
                $role = isset($_REQUEST['new_role']) ? sanitize_key(wp_unslash((string) $_REQUEST['new_role'])) : '';
                if ($role === '' || empty($editable_roles[ $role ])) {
                    wp_die(esc_html__('Sorry, you are not allowed to give users that role.', 'yooadmin'), '', ['response' => 403]);
                }
                if ($role === 'none') {
                    $role = '';
                }
                if (isset($_REQUEST['users']) && is_array($_REQUEST['users'])) {
                    $update = 'promote';
                    switch_to_blog($id);
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cast to int per user ID in loop.
                    foreach (wp_unslash($_REQUEST['users']) as $user_id) {
                        $user_id = (int) $user_id;
                        if (!current_user_can('promote_user', $user_id)) {
                            restore_current_blog();
                            wp_die(esc_html__('Sorry, you are not allowed to edit this user.', 'yooadmin'), '', ['response' => 403]);
                        }
                        if (!is_user_member_of_blog($user_id, $id)) {
                            restore_current_blog();
                            wp_die(esc_html__('One of the selected users is not a member of this site.', 'yooadmin'), '', ['response' => 403]);
                        }
                        $user = get_userdata($user_id);
                        if ($user) {
                            $user->set_role($role);
                        }
                    }
                    restore_current_blog();
                } else {
                    $update = 'err_promote';
                }
                break;
        }

        if ($update === '') {
            return false;
        }

        wp_safe_redirect(add_query_arg('update', $update, $referer));
        exit;
    }
}

add_action(
    'admin_init',
    static function (): void {
        if (!yooadmin_network_site_users_should_use()) {
            return;
        }
        yooadmin_network_site_users_process_actions();
    },
    5
);
