<?php
/**
 * YOOAdmin network users (list, add, edit).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_users_text_domain')) {
    function yooadmin_network_users_text_domain(): string
    {
        return function_exists('yooadmin_multisite_text_domain')
            ? yooadmin_multisite_text_domain()
            : 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_user_new_page_slug')) {
    function yooadmin_network_user_new_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_user_new_page_slug', 'yooadmin-network-user-new');
    }
}

if (!function_exists('yooadmin_network_user_new_url')) {
    function yooadmin_network_user_new_url(array $args = []): string
    {
        $url = network_admin_url('admin.php?page=' . yooadmin_network_user_new_page_slug());
        if ($args !== []) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_users_should_use')) {
    function yooadmin_network_users_should_use(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        $enabled = true;
        if (function_exists('yooadmin_get_option')) {
            $enabled = (bool) yooadmin_get_option('users_redirect', true);
        }

        return (bool) apply_filters('yooadmin_network_users_should_use', $enabled);
    }
}

if (!function_exists('yooadmin_network_user_new_should_use')) {
    function yooadmin_network_user_new_should_use(): bool
    {
        return yooadmin_network_users_should_use();
    }
}

if (!function_exists('yooadmin_network_users_list_page_slug')) {
    function yooadmin_network_users_list_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_users_list_page_slug', 'yooadmin-network-users');
    }
}

if (!function_exists('yooadmin_network_users_list_url')) {
    function yooadmin_network_users_list_url(array $args = []): string
    {
        $url = network_admin_url('admin.php?page=' . yooadmin_network_users_list_page_slug());
        if ($args !== []) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_users_list_is_screen')) {
    function yooadmin_network_users_list_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_users_list_page_slug();
    }
}

if (!function_exists('yooadmin_network_user_edit_page_slug')) {
    function yooadmin_network_user_edit_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_user_edit_page_slug', 'yooadmin-network-user');
    }
}

if (!function_exists('yooadmin_network_user_edit_url')) {
    function yooadmin_network_user_edit_url(int $user_id, array $args = []): string
    {
        $url = network_admin_url('admin.php');
        $url = add_query_arg(
            [
                'page'    => yooadmin_network_user_edit_page_slug(),
                'user_id' => max(0, $user_id),
            ],
            $url
        );
        if ($args !== []) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_user_edit_is_screen')) {
    function yooadmin_network_user_edit_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_user_edit_page_slug();
    }
}

if (!function_exists('yooadmin_network_users_is_screen')) {
    function yooadmin_network_users_is_screen(): bool
    {
        return yooadmin_network_users_list_is_screen()
            || yooadmin_network_user_new_is_screen()
            || yooadmin_network_user_edit_is_screen();
    }
}

if (!function_exists('yooadmin_network_user_new_is_screen')) {
    function yooadmin_network_user_new_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_user_new_page_slug();
    }
}

if (!function_exists('yooadmin_network_user_new_process_submission')) {
    /**
     * Handle network Add User POST (mirrors wp-admin/network/user-new.php).
     *
     * @return array{errors: ?WP_Error, redirect: bool}
     */
    function yooadmin_network_user_new_process_submission(): array
    {
        $empty = ['errors' => null, 'redirect' => false];

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Action routing.
        if (!isset($_REQUEST['action']) || 'add-user' !== $_REQUEST['action']) {
            return $empty;
        }

        if (!current_user_can('manage_network_users')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'), '', ['response' => 403]);
        }

        check_admin_referer('add-user', '_wpnonce_add-user');

        if (!is_array($_POST['user'] ?? null)) {
            return [
                'errors'   => new WP_Error('empty_user', __('Cannot create an empty user.', 'yooadmin')),
                'redirect' => false,
            ];
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Validated via wpmu_validate_user_signup.
        $user = wp_unslash($_POST['user']);

        $user_details = wpmu_validate_user_signup(
            isset($user['username']) ? (string) $user['username'] : '',
            isset($user['email']) ? (string) $user['email'] : ''
        );

        if (is_wp_error($user_details['errors']) && $user_details['errors']->has_errors()) {
            return ['errors' => $user_details['errors'], 'redirect' => false];
        }

        $password = wp_generate_password(12, false);
        $user_id  = wpmu_create_user(
            esc_html(strtolower((string) $user['username'])),
            $password,
            sanitize_email((string) $user['email'])
        );

        if (!$user_id) {
            return [
                'errors'   => new WP_Error('add_user_fail', __('Cannot add user.', 'yooadmin')),
                'redirect' => false,
            ];
        }

        /** This action is documented in wp-admin/network/user-new.php */
        do_action('network_user_new_created_user', $user_id); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.

        wp_safe_redirect(
            yooadmin_network_user_new_url(
                [
                    'update'  => 'added',
                    'user_id' => $user_id,
                ]
            )
        );
        exit;
    }
}

if (!function_exists('yooadmin_network_user_new_success_message')) {
    function yooadmin_network_user_new_success_message(): string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status flag.
        if (!isset($_GET['update']) || sanitize_key(wp_unslash((string) $_GET['update'])) !== 'added') {
            return '';
        }

        $message = __('User added.', 'yooadmin');

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only user ID.
        $user_id_new = isset($_GET['user_id']) ? absint($_GET['user_id']) : 0;
        if ($user_id_new > 0) {
            $edit_url = function_exists('yooadmin_network_user_edit_url') && yooadmin_network_users_should_use()
                ? yooadmin_network_user_edit_url($user_id_new)
                : get_edit_user_link($user_id_new);
            $edit_link = esc_url(
                add_query_arg(
                    'wp_http_referer',
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Used for referer only; escaped via esc_url().
                    rawurlencode(wp_unslash((string) ($_SERVER['REQUEST_URI'] ?? ''))),
                    $edit_url
                )
            );
            $message .= sprintf(
                ' <a href="%1$s">%2$s</a>',
                $edit_link,
                esc_html__('Edit user', 'yooadmin')
            );
        }

        return $message;
    }
}

if (!function_exists('yooadmin_network_users_per_page')) {
    function yooadmin_network_users_per_page(): int
    {
        $per_page = 12;
        if (function_exists('get_user_option')) {
            $saved = get_user_option('users_network_per_page');
            if ($saved) {
                $per_page = (int) $saved;
            }
        }

        return max(5, (int) apply_filters('yooadmin_network_users_per_page', $per_page));
    }
}

if (!function_exists('yooadmin_network_users_fetch')) {
    /**
     * @return array{users: array<int, WP_User>, total: int, total_pages: int, paged: int, search: string, role: string}
     */
    function yooadmin_network_users_fetch(): array
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash((string) $_GET['s'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $role = isset($_GET['role']) ? sanitize_key(wp_unslash((string) $_GET['role'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $paged = isset($_GET['paged']) ? max(1, absint(wp_unslash((string) $_GET['paged']))) : 1;

        $per_page = yooadmin_network_users_per_page();

        $args = [
            'number'  => $per_page,
            'offset'  => ($paged - 1) * $per_page,
            'orderby' => 'registered',
            'order'   => 'DESC',
            'blog_id' => 0,
        ];

        if ($search !== '') {
            if (wp_is_large_network('users')) {
                $args['search'] = ltrim($search, '*');
            } else {
                $args['search'] = '*' . trim($search, '*') . '*';
            }
            $args['search_columns'] = ['user_login', 'user_email', 'user_nicename', 'display_name'];
        }

        if ('super' === $role) {
            $args['login__in'] = get_super_admins();
            if (empty($args['login__in'])) {
                return [
                    'users'       => [],
                    'total'       => 0,
                    'total_pages' => 0,
                    'paged'       => $paged,
                    'search'      => $search,
                    'role'        => $role,
                ];
            }
        }

        /** This filter is documented in wp-admin/includes/class-wp-users-list-table.php */
        $args = apply_filters('users_list_table_query_args', $args); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.

        $user_query  = new WP_User_Query($args);
        $users       = $user_query->get_results();
        $total       = (int) $user_query->get_total();
        $total_pages = $per_page > 0 ? (int) ceil($total / $per_page) : 1;

        return [
            'users'       => is_array($users) ? $users : [],
            'total'       => $total,
            'total_pages' => $total_pages,
            'paged'       => $paged,
            'search'      => $search,
            'role'        => $role,
        ];
    }
}

if (!function_exists('yooadmin_network_users_stats')) {
    /**
     * @return array{total: int, super_admins: int, new_week: int, spam: int}
     */
    function yooadmin_network_users_stats(): array
    {
        $total_users = (int) get_user_count();

        $recent_query = new WP_User_Query(
            [
                'blog_id'    => 0,
                'fields'     => 'ids',
                'number'     => 1,
                'date_query' => [
                    [
                        'after'  => gmdate('Y-m-d', strtotime('-7 days')),
                        'column' => 'user_registered',
                    ],
                ],
            ]
        );

        global $wpdb;
        $spam_count = 0;
        if (isset($wpdb->users)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $spam_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users} WHERE spam = '1'");
        }

        return [
            'total'        => $total_users,
            'super_admins' => count(get_super_admins()),
            'new_week'     => (int) $recent_query->get_total(),
            'spam'         => $spam_count,
        ];
    }
}

if (!function_exists('yooadmin_network_users_flash_message')) {
    function yooadmin_network_users_flash_message(): array
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!isset($_GET['updated']) || sanitize_key(wp_unslash((string) $_GET['updated'])) !== 'true') {
            return ['', ''];
        }

        $td = yooadmin_network_users_text_domain();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $action = isset($_GET['action']) ? sanitize_key(wp_unslash((string) $_GET['action'])) : '';

        $map = [
            'delete'      => [__('User deleted.', 'yooadmin'), 'success'],
            'all_delete'  => [__('Users deleted.', 'yooadmin'), 'success'],
            'all_spam'    => [__('Users marked as spam.', 'yooadmin'), 'success'],
            'all_notspam' => [__('Users removed from spam.', 'yooadmin'), 'success'],
            'add'         => [__('User added.', 'yooadmin'), 'success'],
        ];

        return isset($map[ $action ]) ? $map[ $action ] : ['', ''];
    }
}

if (!function_exists('yooadmin_network_users_user_badge')) {
    function yooadmin_network_users_user_badge(WP_User $user): string
    {
        if (is_super_admin($user->ID)) {
            return __('Super Admin', 'yooadmin');
        }
        if (!empty($user->spam)) {
            return _x('Spam', 'user', 'yooadmin');
        }

        return __('User', 'yooadmin');
    }
}

if (!function_exists('yooadmin_network_users_user_sites_summary')) {
    function yooadmin_network_users_user_sites_summary(int $user_id): string
    {
        $blogs = get_blogs_of_user($user_id);
        if (empty($blogs)) {
            return '';
        }

        $names = [];
        foreach (array_slice($blogs, 0, 3) as $blog) {
            $names[] = $blog->blogname ?: $blog->domain;
        }

        $summary = implode(', ', $names);
        if (count($blogs) > 3) {
            $summary .= sprintf(
                /* translators: %d: additional site count */
                __(' +%d more', 'yooadmin'),
                count($blogs) - 3
            );
        }

        return $summary;
    }
}

if (!function_exists('yooadmin_network_user_edit_process_submission')) {
    /**
     * Handle network user profile update (mirrors wp-admin/user-edit.php update action).
     *
     * @return array{errors: WP_Error, updated: bool, redirect: bool}
     */
    function yooadmin_network_user_edit_process_submission(int $user_id): array
    {
        $errors  = new WP_Error();
        $result  = ['errors' => $errors, 'updated' => false, 'redirect' => false];

        if ($user_id <= 0 || !get_userdata($user_id)) {
            $errors->add('invalid_user', __('The requested user could not be found.', 'yooadmin'));

            return $result;
        }

        if (!isset($_POST['action']) || 'update' !== sanitize_key(wp_unslash((string) $_POST['action']))) {
            return $result;
        }

        check_admin_referer('update-user_' . $user_id);

        if (!current_user_can('edit_user', $user_id)) {
            wp_die(esc_html__('Sorry, you are not allowed to edit this user.', 'yooadmin'), '', ['response' => 403]);
        }

        if (!function_exists('edit_user')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }

        /** This action is documented in wp-admin/user-edit.php */
        do_action('edit_user_profile_update', $user_id); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.

        if (isset($_POST['user_email']) && !isset($_POST['email'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $_POST['email'] = wp_unslash($_POST['user_email']);
        }

        $edit_errors = edit_user($user_id);

        if (is_multisite() && is_network_admin() && current_user_can('manage_network_options')) {
            $was_super = is_super_admin($user_id);
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $grant_super = !empty($_POST['super_admin']);
            if ($grant_super !== $was_super) {
                if ($grant_super) {
                    grant_super_admin($user_id);
                } else {
                    revoke_super_admin($user_id);
                }
            }
        }

        if (is_wp_error($edit_errors) && $edit_errors->has_errors()) {
            return ['errors' => $edit_errors, 'updated' => false, 'redirect' => false];
        }

        wp_safe_redirect(yooadmin_network_user_edit_url($user_id, ['updated' => '1']));
        exit;
    }
}
