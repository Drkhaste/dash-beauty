<?php
/**
 * YOOAdmin network add-site page (multisite + Focus Mode).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_site_new_text_domain')) {
    function yooadmin_network_site_new_text_domain(): string
    {
        return function_exists('yooadmin_multisite_text_domain')
            ? yooadmin_multisite_text_domain()
            : 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_site_new_page_slug')) {
    function yooadmin_network_site_new_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_site_new_page_slug', 'yooadmin-network-add-site');
    }
}

if (!function_exists('yooadmin_network_site_new_url')) {
    function yooadmin_network_site_new_url(array $args = []): string
    {
        $url = network_admin_url('admin.php?page=' . yooadmin_network_site_new_page_slug());

        if ($args) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_site_new_should_use')) {
    function yooadmin_network_site_new_should_use(): bool
    {
        if (!is_multisite()) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        $enabled = true;
        if (function_exists('yooadmin_get_option')) {
            $enabled = (bool) yooadmin_get_option('network_site_new_redirect', true);
        }

        return (bool) apply_filters('yooadmin_network_site_new_should_use', $enabled);
    }
}

if (!function_exists('yooadmin_network_site_new_is_screen')) {
    function yooadmin_network_site_new_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_site_new_page_slug() || $page === 'yooadmin-network-site-new';
    }
}

if (!function_exists('yooadmin_network_site_new_success_messages')) {
    /**
     * @return array<int, string>
     */
    function yooadmin_network_site_new_success_messages(): array
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash message flag.
        if (!isset($_GET['update']) || sanitize_key(wp_unslash((string) $_GET['update'])) !== 'added') {
            return [];
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash message flag.
        $site_id = isset($_GET['id']) ? absint(wp_unslash((string) $_GET['id'])) : 0;
        if ($site_id <= 0) {
            return [];
        }

        $td = yooadmin_network_site_new_text_domain();

        return [
            sprintf(
                /* translators: 1: Dashboard URL, 2: Network admin edit URL. */
                __('Site added. <a href="%1$s">Visit Dashboard</a> or <a href="%2$s">Edit Site</a>', 'yooadmin'),
                esc_url(get_admin_url($site_id)),
                esc_url(
                    function_exists('yooadmin_network_site_info_should_use') && yooadmin_network_site_info_should_use() && function_exists('yooadmin_network_site_info_url')
                        ? yooadmin_network_site_info_url($site_id)
                        : network_admin_url('site-info.php?id=' . $site_id)
                )
            ),
        ];
    }
}

if (!function_exists('yooadmin_network_site_new_process_add')) {
    /**
     * Create a network site from POST data.
     *
     * @return int|null Site ID on success, null when no submission.
     */
    function yooadmin_network_site_new_process_add(): ?int
    {
        if (!is_multisite() || !current_user_can('create_sites')) {
            return null;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked below.
        if (empty($_REQUEST['action']) || 'add-site' !== sanitize_key(wp_unslash((string) $_REQUEST['action']))) {
            return null;
        }

        check_admin_referer('add-blog', '_wpnonce_add-blog');

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Validated above.
        if (!isset($_POST['blog']) || !is_array($_POST['blog'])) {
            wp_die(esc_html__('Cannot create an empty site.', 'yooadmin'));
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per field below.
        $blog   = wp_unslash($_POST['blog']);
        $domain = '';

        $blog['domain'] = isset($blog['domain']) ? trim((string) $blog['domain']) : '';
        if (preg_match('|^([a-zA-Z0-9-])+$|', $blog['domain'])) {
            $domain = strtolower($blog['domain']);
        }

        if (!is_subdomain_install()) {
            $subdirectory_reserved_names = get_subdirectory_reserved_names();

            if (in_array($domain, $subdirectory_reserved_names, true)) {
                wp_die(
                    sprintf(
                        /* translators: %s: Reserved names list. */
                        esc_html__('The following words are reserved for use by WordPress functions and cannot be used as site names: %s', 'yooadmin'),
                        '<code>' . implode('</code>, <code>', array_map('esc_html', $subdirectory_reserved_names)) . '</code>'
                    )
                );
            }
        }

        $title = isset($blog['title']) ? (string) $blog['title'] : '';

        $meta = [
            'public' => 1,
        ];

        if (isset($_POST['WPLANG'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Core parity.
            $posted_lang = wp_unslash((string) $_POST['WPLANG']);
            if ('' === $posted_lang) {
                $meta['WPLANG'] = '';
            } elseif (in_array($posted_lang, get_available_languages(), true)) {
                $meta['WPLANG'] = sanitize_text_field($posted_lang);
            } elseif (current_user_can('install_languages') && wp_can_install_language_pack()) {
                if (!function_exists('wp_download_language_pack')) {
                    require_once ABSPATH . 'wp-admin/includes/translation-install.php';
                }
                $language = wp_download_language_pack($posted_lang);
                if ($language) {
                    $meta['WPLANG'] = $language;
                }
            }
        }

        if ($title === '') {
            wp_die(esc_html__('Missing site title.', 'yooadmin'));
        }

        if ($domain === '') {
            wp_die(esc_html__('Missing or invalid site address.', 'yooadmin'));
        }

        if (!isset($blog['email']) || '' === trim((string) $blog['email'])) {
            wp_die(esc_html__('Missing email address.', 'yooadmin'));
        }

        $email = sanitize_email((string) $blog['email']);
        if (!is_email($email)) {
            wp_die(esc_html__('Invalid email address.', 'yooadmin'));
        }

        if (is_subdomain_install()) {
            $newdomain = $domain . '.' . preg_replace('|^www\.|', '', get_network()->domain);
            $path      = get_network()->path;
        } else {
            $newdomain = get_network()->domain;
            $path      = get_network()->path . $domain . '/';
        }

        $password = 'N/A';
        $user_id  = email_exists($email);
        if (!$user_id) {
            /** This action is documented in wp-admin/network/site-new.php */
            do_action('pre_network_site_new_created_user', $email); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.

            $user_id = username_exists($domain);
            if ($user_id) {
                wp_die(esc_html__('The domain or path entered conflicts with an existing username.', 'yooadmin'));
            }

            $password = wp_generate_password(12, false);
            $user_id  = wpmu_create_user($domain, $password, $email);
            if (false === $user_id) {
                wp_die(esc_html__('There was an error creating the user.', 'yooadmin'));
            }

            /** This action is documented in wp-admin/network/site-new.php */
            do_action('network_site_new_created_user', $user_id); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
        }

        global $wpdb;

        $wpdb->hide_errors();
        $id = wpmu_create_blog($newdomain, $path, $title, $user_id, $meta, get_current_network_id());
        $wpdb->show_errors();

        if (is_wp_error($id)) {
            wp_die(esc_html($id->get_error_message()));
        }

        if (!is_super_admin($user_id) && !get_user_option('primary_blog', $user_id)) {
            update_user_option($user_id, 'primary_blog', $id, true);
        }

        wpmu_new_site_admin_notification($id, $user_id);
        wpmu_welcome_notification($id, $user_id, $password, $title, ['public' => 1]);

        if (function_exists('yooadmin_network_site_yooadmin_provision_new_site')) {
            yooadmin_network_site_yooadmin_provision_new_site(
                (int) $id,
                (int) $user_id,
                yooadmin_network_site_yooadmin_parse_provision_flags(
                    [
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'copy_settings'     => !empty($_POST['yooadmin_provision_copy_settings']),
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'copy_theme_colors' => !empty($_POST['yooadmin_provision_copy_theme_colors']),
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'copy_login_logo'   => !empty($_POST['yooadmin_provision_copy_login_logo']),
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'copy_custom_login' => !empty($_POST['yooadmin_provision_copy_custom_login']),
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'show_admin_tour'   => !empty($_POST['yooadmin_provision_show_admin_tour']),
                    ]
                )
            );
        }

        return (int) $id;
    }
}

add_action(
    'admin_init',
    static function (): void {
        if (!yooadmin_network_site_new_is_screen() || wp_doing_ajax()) {
            return;
        }

        $site_id = yooadmin_network_site_new_process_add();
        if ($site_id === null) {
            return;
        }

        wp_safe_redirect(
            yooadmin_network_site_new_url(
                [
                    'update' => 'added',
                    'id'     => $site_id,
                ]
            )
        );
        exit;
    },
    5
);

add_action(
    'admin_init',
    static function (): void {
        if (!is_multisite() || !is_network_admin() || wp_doing_ajax()) {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only legacy slug redirect.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($page !== 'yooadmin-network-site-new' || !empty($_POST)) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- POST presence only skips redirect.
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Preserve safe query args only.
        $args = isset($_GET) && is_array($_GET) ? wp_unslash($_GET) : [];
        unset($args['page']);

        wp_safe_redirect(yooadmin_network_site_new_url($args));
        exit;
    },
    1
);
