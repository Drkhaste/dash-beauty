<?php
/**
 * Admin bar settings overlay (Security / Maintenance) when Focus Mode is off.
 * Loads panel HTML via AJAX — does not navigate to or iframe the settings page.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_user_can_admin_bar_settings_modal')) {
    function yooadmin_user_can_admin_bar_settings_modal(): bool
    {
        $cap = function_exists('yooadmin_required_cap') ? yooadmin_required_cap('settings') : 'manage_options';

        return current_user_can($cap);
    }
}

if (!function_exists('yooadmin_should_show_admin_bar_settings_modal')) {
    function yooadmin_should_show_admin_bar_settings_modal(): bool
    {
        if (!is_user_logged_in() || !yooadmin_user_can_admin_bar_settings_modal()) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled()) {
            return false;
        }

        if (!is_admin() && !(function_exists('is_admin_bar_showing') && is_admin_bar_showing())) {
            return false;
        }

        return true;
    }
}

if (!function_exists('yooadmin_admin_bar_settings_modal_footer_text')) {
    function yooadmin_admin_bar_settings_modal_footer_text(): string
    {
        $brand = 'YOOAdmin';
        $url   = function_exists('yooadmin_enable_focus_url')
            ? yooadmin_enable_focus_url()
            : admin_url('admin.php?page=yooadmin-enable-focus');

        return sprintf(
            /* translators: %s: YOOAdmin brand name (linked). */
            __('Supported by %s', 'yooadmin'),
            '<a class="yooadmin-ab-settings-modal__brand" href="' . esc_url($url) . '">' . esc_html($brand) . '</a>'
        );
    }
}

if (!function_exists('yooadmin_enqueue_admin_bar_settings_panel_assets')) {
    function yooadmin_enqueue_admin_bar_settings_panel_assets(): void
    {
        if (!defined('YOOADMIN_URL') || !defined('YOOADMIN_DIR')) {
            return;
        }

        $base_url = YOOADMIN_URL;
        $base_dir = YOOADMIN_DIR;

        $yoo_btn_css = $base_dir . 'assets/css/admin/yp-yoo-buttons.css';
        if (is_readable($yoo_btn_css)) {
            wp_enqueue_style(
                'yooadmin-yoo-buttons',
                $base_url . 'assets/css/admin/yp-yoo-buttons.css',
                [],
                (string) filemtime($yoo_btn_css)
            );
        }

        $settings_css = $base_dir . 'assets/css/admin/yp-settings.css';
        if (is_readable($settings_css)) {
            $deps = ['dashicons'];
            if (wp_style_is('yooadmin-yoo-buttons', 'enqueued')) {
                $deps[] = 'yooadmin-yoo-buttons';
            }
            wp_enqueue_style(
                'yooadmin-ab-panel-settings',
                $base_url . 'assets/css/admin/yp-settings.css',
                $deps,
                (string) filemtime($settings_css)
            );
        }

        foreach (
            [
                'assets/css/admin/login-tab-settings.css'   => 'yooadmin-ab-panel-login',
                'assets/css/admin/maintenance-tab-settings.css' => 'yooadmin-ab-panel-maintenance',
            ] as $rel => $handle
        ) {
            $abs = $base_dir . $rel;
            if (is_readable($abs)) {
                wp_enqueue_style(
                    $handle,
                    $base_url . $rel,
                    ['yooadmin-ab-panel-settings'],
                    (string) filemtime($abs)
                );
            }
        }

        wp_enqueue_media();

        $js_abs = $base_dir . 'assets/js/admin/yoo-settings.js';
        if (is_readable($js_abs)) {
            wp_enqueue_script(
                'yooadmin-ab-panel-settings',
                $base_url . 'assets/js/admin/yoo-settings.js',
                ['jquery'],
                (string) filemtime($js_abs),
                true
            );
            if (function_exists('wp_script_add_data')) {
                wp_script_add_data('yooadmin-ab-panel-settings', 'strategy', 'defer');
            }

            $options_cache_key = 'yooadmin_options_' . get_current_user_id();
            $options           = wp_cache_get($options_cache_key, 'yooadmin_settings');
            if ($options === false) {
                $options = (array) get_option('yooadmin_options', []);
            }

            wp_localize_script('yooadmin-ab-panel-settings', 'yooadmSettings', [
                'ajaxUrl'       => admin_url('admin-ajax.php'),
                'nonce'         => wp_create_nonce('yooadmin_settings_save'),
                'ajax'          => [
                    'url'    => admin_url('admin-ajax.php'),
                    'nonce'  => wp_create_nonce('yooadmin_settings_save'),
                    'action' => 'yooadmin_save_settings',
                ],
                'i18n'          => [
                    'chooseImage' => __('Choose image', 'yooadmin'),
                    'useImage'    => __('Use this image', 'yooadmin'),
                    'error'       => __('Error while saving', 'yooadmin'),
                ],
                'loginLogoMaxCap' => 268,
                'loginTurnstile'  => function_exists('yooadmin_login_turnstile_client_config')
                    ? yooadmin_login_turnstile_client_config(is_array($options) ? $options : [])
                    : [],
            ]);
        }
    }
}

add_action('wp_ajax_yooadmin_admin_bar_settings_panel', function () {
    if (!yooadmin_user_can_admin_bar_settings_modal()) {
        wp_send_json_error(['message' => __('Forbidden', 'yooadmin')], 403);
    }

    check_ajax_referer('yooadmin_admin_bar_settings', 'nonce');

    $panel = isset($_POST['panel']) ? sanitize_key(wp_unslash((string) $_POST['panel'])) : '';
    if (!in_array($panel, ['login-security', 'maintenance'], true)) {
        wp_send_json_error(['message' => __('Invalid panel', 'yooadmin')], 400);
    }

    $settings = class_exists('YOOAdmin_Settings') ? YOOAdmin_Settings::instance() : null;
    if (!$settings || !method_exists($settings, 'render_admin_bar_modal_panel')) {
        wp_send_json_error(['message' => __('Settings unavailable', 'yooadmin')], 500);
    }

    ob_start();
    $settings->render_admin_bar_modal_panel($panel);
    $html = (string) ob_get_clean();

    if ($html === '') {
        wp_send_json_error(['message' => __('Panel is empty', 'yooadmin')], 500);
    }

    wp_send_json_success([
        'panel' => $panel,
        'html'  => $html,
    ]);
});

if (!function_exists('yooadmin_register_admin_bar_security_control')) {
    function yooadmin_register_admin_bar_security_control($wp_admin_bar): void
    {
        if (!yooadmin_should_show_admin_bar_settings_modal()) {
            return;
        }

        if (!is_object($wp_admin_bar) || !method_exists($wp_admin_bar, 'add_node')) {
            return;
        }

        $icon = '<span class="ab-icon yooadmin-ab-security-icon" aria-hidden="true">'
            . '<span class="dashicons dashicons-shield"></span></span>';

        $wp_admin_bar->add_node([
            'id'     => 'yooadmin-security-settings',
            'parent' => 'top-secondary',
            'title'  => $icon . '<span class="ab-label">' . esc_html__('Security', 'yooadmin') . '</span>',
            'href'   => '#yooadmin-security-settings',
            'meta'   => [
                'class'    => 'yooadmin-ab-settings-trigger yooadmin-ab-settings-trigger--security',
                'title'    => __('YOOAdmin security settings', 'yooadmin'),
                'priority' => 7,
            ],
        ]);
    }
}

add_action('admin_bar_menu', 'yooadmin_register_admin_bar_security_control', 7);

if (!function_exists('yooadmin_render_admin_bar_settings_modals')) {
    function yooadmin_render_admin_bar_settings_modals(): void
    {
        static $rendered = false;
        if ($rendered || !yooadmin_should_show_admin_bar_settings_modal()) {
            return;
        }
        $rendered = true;

        $footer_html   = yooadmin_admin_bar_settings_modal_footer_text();
        $wp_spinner_src = admin_url('images/spinner.gif');
        ?>
        <div id="yooadmin-ab-settings-modal" class="yooadmin-ab-settings-modal<?php echo is_rtl() ? ' yooadmin-ab-settings-modal--rtl' : ''; ?>" hidden aria-hidden="true">
            <div class="yooadmin-ab-settings-modal__backdrop" data-yooadmin-ab-settings-close></div>
            <div class="yooadmin-ab-settings-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="yooadmin-ab-settings-modal-title">
                <header class="yooadmin-ab-settings-modal__header">
                    <h2 id="yooadmin-ab-settings-modal-title" class="yooadmin-ab-settings-modal__title"></h2>
                    <button type="button" class="yooadmin-ab-settings-modal__close" data-yooadmin-ab-settings-close aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                    </button>
                </header>
                <div class="yooadmin-ab-settings-modal__body">
                    <div class="yooadmin-ab-settings-modal__loading" hidden>
                        <?php if (is_string($wp_spinner_src) && $wp_spinner_src !== '') : ?>
                            <img
                                class="yooadmin-ab-settings-modal__busy"
                                src="<?php echo esc_url($wp_spinner_src); ?>"
                                width="20"
                                height="20"
                                alt=""
                                decoding="async"
                            />
                        <?php endif; ?>
                        <span><?php esc_html_e('Loading…', 'yooadmin'); ?></span>
                    </div>
                    <div class="yooadmin-ab-settings-modal__content"></div>
                </div>
                <footer class="yooadmin-ab-settings-modal__footer">
                    <p class="yooadmin-ab-settings-modal__credit"><?php echo wp_kses($footer_html, ['a' => ['class' => [], 'href' => []]]); ?></p>
                    <div class="yooadmin-ab-settings-modal__actions">
                        <button type="button" class="button button-secondary yp-yoo-btn yp-yoo-btn--soft" data-yooadmin-ab-settings-close><?php esc_html_e('Cancel', 'yooadmin'); ?></button>
                        <button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary yooadmin-ab-settings-modal__save"><?php esc_html_e('Save', 'yooadmin'); ?></button>
                    </div>
                </footer>
            </div>
        </div>
        <?php
        if (function_exists('yooadmin_render_login_turnstile_info_modal')) {
            yooadmin_render_login_turnstile_info_modal();
        }
    }
}

if (!function_exists('yooadmin_enqueue_admin_bar_settings_modal_assets')) {
    function yooadmin_enqueue_admin_bar_settings_modal_assets(): void
    {
        if (!yooadmin_should_show_admin_bar_settings_modal()) {
            return;
        }

        if (!defined('YOOADMIN_URL') || !defined('YOOADMIN_DIR')) {
            return;
        }

        yooadmin_enqueue_admin_bar_settings_panel_assets();

        if (function_exists('yooadmin_enqueue_settings_toast_assets')) {
            yooadmin_enqueue_settings_toast_assets();
        } elseif (function_exists('yooadmin_enqueue_yp_admin_toast_assets')) {
            yooadmin_enqueue_yp_admin_toast_assets();
        }

        $base_url = YOOADMIN_URL;
        $base_dir = YOOADMIN_DIR;

        $css_rel = 'assets/css/admin/admin-bar-settings-modal.css';
        $js_rel  = 'assets/js/admin/admin-bar-settings-modal.js';
        $css_abs = $base_dir . $css_rel;
        $js_abs  = $base_dir . $js_rel;

        $modal_style_deps = ['dashicons', 'yooadmin-ab-panel-settings'];
        if (wp_style_is('yooadmin-yoo-buttons', 'registered') || wp_style_is('yooadmin-yoo-buttons', 'enqueued')) {
            $modal_style_deps[] = 'yooadmin-yoo-buttons';
        }
        $montserrat_path  = $base_dir . 'assets/fonts/montserrat.css';
        if (is_readable($montserrat_path)) {
            wp_enqueue_style(
                'yooadmin-montserrat-ab-settings-modal',
                $base_url . 'assets/fonts/montserrat.css',
                [],
                (string) filemtime($montserrat_path)
            );
            $modal_style_deps[] = 'yooadmin-montserrat-ab-settings-modal';
        }

        if (function_exists('yooadmin_should_enqueue_tajawal_font') && yooadmin_should_enqueue_tajawal_font()) {
            $tajawal_path = $base_dir . 'assets/fonts/tajawal.css';
            if (is_readable($tajawal_path)) {
                wp_enqueue_style(
                    'yooadmin-tajawal-ab-settings-modal',
                    $base_url . 'assets/fonts/tajawal.css',
                    [],
                    (string) filemtime($tajawal_path)
                );
                $modal_style_deps[] = 'yooadmin-tajawal-ab-settings-modal';
            }
        }

        if (
            (function_exists('yooadmin_is_arabic_admin_ui') && yooadmin_is_arabic_admin_ui())
            || is_rtl()
        ) {
            $rtl_path = $base_dir . 'assets/css/admin/rtl-tajawal.css';
            $rtl_deps = array_values(array_filter($modal_style_deps, static function (string $handle): bool {
                return strpos($handle, 'tajawal') !== false;
            }));
            if (is_readable($rtl_path)) {
                wp_enqueue_style(
                    'yooadmin-rtl-tajawal-ab-settings-modal',
                    $base_url . 'assets/css/admin/rtl-tajawal.css',
                    $rtl_deps,
                    (string) filemtime($rtl_path)
                );
                $modal_style_deps[] = 'yooadmin-rtl-tajawal-ab-settings-modal';
            }
        }

        if (is_readable($css_abs)) {
            wp_enqueue_style(
                'yooadmin-admin-bar-settings-modal',
                $base_url . $css_rel,
                $modal_style_deps,
                (string) filemtime($css_abs)
            );

            $inline_modal  = '';
            $latin_family  = function_exists('yooadmin_get_latin_font_family_css_value')
                ? yooadmin_get_latin_font_family_css_value()
                : 'Montserrat';
            $brand_block = function_exists('yooadmin_get_brand_css_vars_block')
                ? yooadmin_get_brand_css_vars_block()
                : '';

            $inline_modal .= '.yooadmin-ab-settings-modal{--yooadmin-latin-font-family:' . $latin_family . ';';
            if ($brand_block !== '') {
                $inline_modal .= $brand_block;
            }
            $inline_modal .= '}';

            if ($brand_block !== '') {
                $inline_modal .= '.yooadmin-ab-settings-modal .yooadmin-settings-wrap{' . $brand_block . '}';
                $inline_modal .= '#yooadmin-login-turnstile-info-modal{' . $brand_block . '}';
            }

            if (function_exists('yooadmin_get_brand_primary_hover_gradient_css')) {
                $hover_bg = yooadmin_get_brand_primary_hover_gradient_css();
                $hover_hex = function_exists('yooadmin_get_brand_primary_600_hex')
                    ? yooadmin_get_brand_primary_600_hex()
                    : '#d8942a';
                $turnstile_hover_selectors = implode(
                    ',',
                    [
                        '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .button.yp-yoo-btn--primary:hover',
                        '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .button.yp-yoo-btn--primary:focus-visible',
                        '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .yp-yoo-btn--primary:hover',
                        '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .yp-yoo-btn--primary:focus-visible',
                    ]
                );
                $inline_modal .= $turnstile_hover_selectors . '{background:' . esc_attr($hover_bg) . ' !important;background-color:' . esc_attr($hover_hex) . ' !important;border:0 !important;color:#fff !important;}';
            }

            wp_add_inline_style('yooadmin-admin-bar-settings-modal', $inline_modal);
        }

        if (is_readable($js_abs)) {
            $modal_js_deps = ['jquery', 'yooadmin-ab-panel-settings'];
            if (wp_script_is('yooadmin-toast-notifications', 'registered') || wp_script_is('yooadmin-toast-notifications', 'enqueued')) {
                $modal_js_deps[] = 'yooadmin-toast-notifications';
            } elseif (wp_script_is('yooadmin-yp-admin-toast', 'registered') || wp_script_is('yooadmin-yp-admin-toast', 'enqueued')) {
                $modal_js_deps[] = 'yooadmin-yp-admin-toast';
            }

            wp_enqueue_script(
                'yooadmin-admin-bar-settings-modal',
                $base_url . $js_rel,
                $modal_js_deps,
                (string) filemtime($js_abs),
                true
            );
            if (function_exists('wp_script_add_data')) {
                wp_script_add_data('yooadmin-admin-bar-settings-modal', 'strategy', 'defer');
            }

            wp_localize_script('yooadmin-admin-bar-settings-modal', 'yooadminAdminBarSettingsModal', [
                'ajaxUrl'       => admin_url('admin-ajax.php'),
                'nonce'         => wp_create_nonce('yooadmin_admin_bar_settings'),
                'settingsNonce' => wp_create_nonce('yooadmin_settings_save'),
                'isRtl'         => is_rtl(),
                'titles'        => [
                    'login-security' => __('Security Settings', 'yooadmin'),
                    'maintenance'    => __('Maintenance Settings', 'yooadmin'),
                ],
                'loadError'     => __('Could not load settings.', 'yooadmin'),
                'saveSuccess'   => __('Settings saved.', 'yooadmin'),
                'saveError'     => __('Could not save settings.', 'yooadmin'),
            ]);
        }
    }
}

add_action('admin_enqueue_scripts', 'yooadmin_enqueue_admin_bar_settings_modal_assets', 14);
add_action('wp_enqueue_scripts', 'yooadmin_enqueue_admin_bar_settings_modal_assets', 14);
add_action('admin_footer', 'yooadmin_render_admin_bar_settings_modals', 20);
add_action('wp_footer', 'yooadmin_render_admin_bar_settings_modals', 20);
