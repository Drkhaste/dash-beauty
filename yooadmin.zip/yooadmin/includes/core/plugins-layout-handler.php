<?php
/**
 * YOOAdmin - Plugins layout handler (placeholder)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;
