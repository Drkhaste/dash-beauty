<?php
/**
 * YOOAdmin network site provisioning — copy settings, login logo, guided tour.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_site_yooadmin_text_domain')) {
    function yooadmin_network_site_yooadmin_text_domain(): string
    {
        return function_exists('yooadmin_network_site_editor_text_domain')
            ? yooadmin_network_site_editor_text_domain()
            : 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_page_slug')) {
    function yooadmin_network_site_yooadmin_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_site_yooadmin_page_slug', 'yooadmin-network-site-yooadmin');
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_url')) {
    function yooadmin_network_site_yooadmin_url(int $blog_id, array $args = []): string
    {
        if (function_exists('yooadmin_network_site_yooadmin_should_use') && !yooadmin_network_site_yooadmin_should_use()) {
            $url = network_admin_url('site-info.php?id=' . max(1, $blog_id));
            return $args ? add_query_arg($args, $url) : $url;
        }

        $url = network_admin_url('admin.php?page=' . yooadmin_network_site_yooadmin_page_slug());
        $url = add_query_arg('id', $blog_id, $url);

        if ($args) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_should_use')) {
    function yooadmin_network_site_yooadmin_should_use(): bool
    {
        return function_exists('yooadmin_network_site_editor_should_use')
            && yooadmin_network_site_editor_should_use();
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_is_screen')) {
    function yooadmin_network_site_yooadmin_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_site_yooadmin_page_slug();
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_source_blog_id')) {
    function yooadmin_network_site_yooadmin_source_blog_id(): int
    {
        return (int) get_main_site_id();
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_branding_settings_url')) {
    function yooadmin_network_site_yooadmin_branding_settings_url(): string
    {
        $blog_id = yooadmin_network_site_yooadmin_source_blog_id();

        return get_admin_url($blog_id, 'admin.php?page=yooadmin-settings');
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_network_settings_url')) {
    function yooadmin_network_site_yooadmin_network_settings_url(): string
    {
        if (function_exists('yooadmin_network_settings_url')) {
            return yooadmin_network_settings_url('yooadmin');
        }

        return network_admin_url('admin.php?page=yooadmin-network-settings&tab=yooadmin');
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_login_logo_option_keys')) {
    /**
     * @deprecated 1.5.3 Use granular key helpers below.
     * @return string[]
     */
    function yooadmin_network_site_yooadmin_login_logo_option_keys(): array
    {
        return array_values(
            array_unique(
                array_merge(
                    yooadmin_network_site_yooadmin_admin_logo_option_keys(),
                    yooadmin_network_site_yooadmin_custom_login_option_keys()
                )
            )
        );
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_admin_logo_option_keys')) {
    /**
     * Admin header branding logo keys.
     *
     * @return string[]
     */
    function yooadmin_network_site_yooadmin_admin_logo_option_keys(): array
    {
        return ['logo_url', 'logo_w'];
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_custom_login_option_keys')) {
    /**
     * Custom login page experience keys (excluding per-login color overrides).
     *
     * @return string[]
     */
    function yooadmin_network_site_yooadmin_custom_login_option_keys(): array
    {
        return [
            'login_page_enabled',
            'login_page_logo_source',
            'login_page_logo_url',
            'login_page_logo_dark_url',
            'login_page_logo_max_w',
            'login_page_image_url',
            'login_page_image_side',
            'login_page_content_page_id',
            'login_security_enabled',
            'login_turnstile_site_key',
            'login_turnstile_secret_key',
            'login_turnstile_protect_lostpassword',
            'login_turnstile_display',
            'login_turnstile_wp_login',
            'login_turnstile_standalone',
            'login_rate_limit_enabled',
            'login_rate_limit_wp_login',
            'login_rate_limit_standalone',
            'login_rate_limit_login_max',
            'login_rate_limit_login_window',
            'login_rate_limit_lostpassword_max',
            'login_rate_limit_lostpassword_window',
            'login_rate_limit_resetpass_max',
            'login_rate_limit_resetpass_window',
            'login_prevent_user_enumeration',
            'login_user_enum_author_archives',
            'login_user_enum_hide_rss_author',
            'login_hidden_entry_enabled',
            'login_hidden_entry_slug',
            'maintenance_mode_enabled',
            'maintenance_mode_appearance_mode',
            'maintenance_mode_image_url',
            'maintenance_mode_image_id',
            'maintenance_mode_bg_blur',
            'maintenance_mode_title',
            'maintenance_mode_message',
            'maintenance_mode_titles',
            'maintenance_mode_messages',
            'maintenance_mode_enabled_locales',
        ];
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_media_url_option_keys')) {
    /**
     * Option keys that may contain media URLs and should be copied into the target site library.
     *
     * @return string[]
     */
    function yooadmin_network_site_yooadmin_media_url_option_keys(): array
    {
        return ['logo_url', 'login_page_logo_url', 'login_page_logo_dark_url', 'login_page_image_url'];
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_theme_color_option_keys')) {
    /**
     * @param array<string, mixed> $template_options
     * @return string[]
     */
    function yooadmin_network_site_yooadmin_theme_color_option_keys(array $template_options): array
    {
        $keys = [];
        foreach ($template_options as $key => $value) {
            $key = (string) $key;
            if (strpos($key, 'login_page_color_') === 0 || $key === 'login_page_custom_css') {
                $keys[] = $key;
            }
        }

        return $keys;
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_provision_flag_keys')) {
    /**
     * @return string[]
     */
    function yooadmin_network_site_yooadmin_provision_flag_keys(): array
    {
        return [
            'copy_settings',
            'copy_theme_colors',
            'copy_login_logo',
            'copy_custom_login',
            'show_admin_tour',
        ];
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_default_provision_flags')) {
    /**
     * @return array<string, bool>
     */
    function yooadmin_network_site_yooadmin_default_provision_flags(): array
    {
        return [
            'copy_settings'     => true,
            'copy_theme_colors' => true,
            'copy_login_logo'   => true,
            'copy_custom_login' => true,
            'show_admin_tour'   => true,
        ];
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_parse_provision_flags')) {
    /**
     * @param array<string, mixed> $source
     * @return array<string, bool>
     */
    function yooadmin_network_site_yooadmin_parse_provision_flags(array $source, string $prefix = ''): array
    {
        $flags = yooadmin_network_site_yooadmin_default_provision_flags();

        foreach (yooadmin_network_site_yooadmin_provision_flag_keys() as $key) {
            $field = $prefix . $key;
            if (array_key_exists($field, $source)) {
                $flags[ $key ] = !empty($source[ $field ]);
            }
        }

        return $flags;
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_import_media_url')) {
    /**
     * Copy a media URL from the network source site into the target site's uploads when possible.
     */
    function yooadmin_network_site_yooadmin_import_media_url(string $url, int $target_blog_id, int $source_blog_id): string
    {
        $url = trim($url);
        if ($url === '' || $target_blog_id <= 0 || $source_blog_id <= 0) {
            return $url;
        }

        static $cache = [];
        $cache_key = $target_blog_id . '|' . $source_blog_id . '|' . $url;
        if (isset($cache[ $cache_key ])) {
            return $cache[ $cache_key ];
        }

        switch_to_blog($target_blog_id);
        $target_upload = wp_upload_dir();
        restore_current_blog();

        if (empty($target_upload['error']) && !empty($target_upload['baseurl']) && strpos($url, (string) $target_upload['baseurl']) === 0) {
            $cache[ $cache_key ] = esc_url_raw($url);

            return $cache[ $cache_key ];
        }

        switch_to_blog($source_blog_id);
        $source_upload = wp_upload_dir();
        $attachment_id = attachment_url_to_postid($url);
        $source_path     = '';

        if ($attachment_id > 0) {
            $source_path = (string) get_attached_file($attachment_id);
        }

        if ($source_path === '' && empty($source_upload['error']) && !empty($source_upload['baseurl']) && strpos($url, (string) $source_upload['baseurl']) === 0) {
            $maybe = str_replace(trailingslashit((string) $source_upload['baseurl']), trailingslashit((string) $source_upload['basedir']), $url);
            if (is_readable($maybe)) {
                $source_path = $maybe;
            }
        }

        if ($source_path === '' && is_readable($url)) {
            $source_path = $url;
        }

        restore_current_blog();

        if ($source_path === '' || !is_readable($source_path)) {
            $cache[ $cache_key ] = esc_url_raw($url);

            return $cache[ $cache_key ];
        }

        switch_to_blog($target_blog_id);

        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        if (!function_exists('wp_check_filetype')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if (!function_exists('media_handle_sideload')) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }

        $upload = wp_upload_dir();
        if (!empty($upload['error'])) {
            restore_current_blog();
            $cache[ $cache_key ] = esc_url_raw($url);

            return $cache[ $cache_key ];
        }

        $filename  = wp_unique_filename((string) $upload['path'], basename($source_path));
        $dest_path = trailingslashit((string) $upload['path']) . $filename;

        if (!@copy($source_path, $dest_path)) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            restore_current_blog();
            $cache[ $cache_key ] = esc_url_raw($url);

            return $cache[ $cache_key ];
        }

        $filetype   = wp_check_filetype($filename);
        $attachment = [
            'post_mime_type' => $filetype['type'] ?: 'image/jpeg',
            'post_title'     => sanitize_file_name((string) pathinfo($filename, PATHINFO_FILENAME)),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ];
        $new_id = wp_insert_attachment($attachment, $dest_path);
        if (is_wp_error($new_id) || !$new_id) {
            restore_current_blog();
            $cache[ $cache_key ] = esc_url_raw($url);

            return $cache[ $cache_key ];
        }

        $metadata = wp_generate_attachment_metadata((int) $new_id, $dest_path);
        if (is_array($metadata)) {
            wp_update_attachment_metadata((int) $new_id, $metadata);
        }

        $new_url = (string) wp_get_attachment_url((int) $new_id);
        restore_current_blog();

        $cache[ $cache_key ] = $new_url !== '' ? esc_url_raw($new_url) : esc_url_raw($url);

        return $cache[ $cache_key ];
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_remap_option_media_urls')) {
    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    function yooadmin_network_site_yooadmin_remap_option_media_urls(array $options, int $target_blog_id, int $source_blog_id): array
    {
        foreach (yooadmin_network_site_yooadmin_media_url_option_keys() as $key) {
            if (!array_key_exists($key, $options)) {
                continue;
            }

            $value = trim((string) $options[ $key ]);
            if ($value === '') {
                continue;
            }

            $options[ $key ] = yooadmin_network_site_yooadmin_import_media_url($value, $target_blog_id, $source_blog_id);
        }

        return $options;
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_merge_template_option_keys')) {
    /**
     * @param array<string, mixed> $target
     * @param array<string, mixed> $template
     * @param string[]             $keys
     * @return array<string, mixed>
     */
    function yooadmin_network_site_yooadmin_merge_template_option_keys(array $target, array $template, array $keys): array
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $template)) {
                $target[ $key ] = $template[ $key ];
            }
        }

        return $target;
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_capture_template')) {
    /**
     * Snapshot YOOAdmin settings from the network main site.
     *
     * @return array<string, mixed>
     */
    function yooadmin_network_site_yooadmin_capture_template(): array
    {
        $blog_id = yooadmin_network_site_yooadmin_source_blog_id();
        if ($blog_id <= 0) {
            return [];
        }

        switch_to_blog($blog_id);

        $options = get_option('yooadmin_options', []);
        if (!is_array($options)) {
            $options = [];
        }

        $colors = get_option('yooadmin_colors', []);
        if (!is_array($colors)) {
            $colors = [];
        }

        $theme_slug = (string) get_option('yooadmin_active_admin_theme', '');
        $template   = [
            'source_blog_id'              => $blog_id,
            'yooadmin_options'            => $options,
            'yooadmin_colors'             => $colors,
            'yooadmin_focus_policy'       => (string) get_option('yooadmin_focus_policy', 'auto'),
            'yooadmin_active_admin_theme'   => $theme_slug,
            'yooadmin_admin_theme_settings' => [],
            'saved_at'                    => time(),
        ];

        if ($theme_slug !== '') {
            $theme_settings = get_option('yooadmin_admin_theme_settings_' . $theme_slug, []);
            if (is_array($theme_settings)) {
                $template['yooadmin_admin_theme_settings'] = $theme_settings;
            }
        }

        restore_current_blog();

        return $template;
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_get_template')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_network_site_yooadmin_get_template(): array
    {
        $stored = get_site_option('yooadmin_network_site_provision_template', []);
        if (is_array($stored) && !empty($stored['yooadmin_options'])) {
            return $stored;
        }

        return yooadmin_network_site_yooadmin_capture_template();
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_save_network_template')) {
    function yooadmin_network_site_yooadmin_save_network_template(): bool
    {
        if (!current_user_can('manage_network')) {
            return false;
        }

        $template = yooadmin_network_site_yooadmin_capture_template();
        if (!$template) {
            return false;
        }

        update_site_option('yooadmin_network_site_provision_template', $template);

        return true;
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_default_form_values')) {
    /**
     * Default toggle values for the Add Site form.
     *
     * @return array<string, bool>
     */
    function yooadmin_network_site_yooadmin_default_form_values(): array
    {
        $stored = get_site_option('yooadmin_network_site_provision_defaults', []);
        if (!is_array($stored)) {
            $stored = [];
        }

        $defaults = yooadmin_network_site_yooadmin_default_provision_flags();
        foreach (yooadmin_network_site_yooadmin_provision_flag_keys() as $key) {
            if (array_key_exists($key, $stored)) {
                $defaults[ $key ] = !empty($stored[ $key ]);
            }
        }

        return $defaults;
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_save_default_form_values')) {
    /**
     * @param array<string, mixed> $values
     */
    function yooadmin_network_site_yooadmin_save_default_form_values(array $values): void
    {
        $stored = [];
        foreach (yooadmin_network_site_yooadmin_provision_flag_keys() as $key) {
            $stored[ $key ] = !empty($values[ $key ]);
        }

        update_site_option('yooadmin_network_site_provision_defaults', $stored);
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_get_site_prefs')) {
    /**
     * @return array{show_admin_tour: bool}
     */
    function yooadmin_network_site_yooadmin_get_site_prefs(int $blog_id): array
    {
        if ($blog_id <= 0) {
            return ['show_admin_tour' => true];
        }

        switch_to_blog($blog_id);
        $show = get_option('yooadmin_site_show_guided_tour', null);
        restore_current_blog();

        if ($show === null) {
            $defaults = yooadmin_network_site_yooadmin_default_form_values();

            return ['show_admin_tour' => !empty($defaults['show_admin_tour'])];
        }

        return ['show_admin_tour' => (bool) $show];
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_provision_toggle_definitions')) {
    /**
     * @return array<int, array{key: string, label: string, help: string, field: string}>
     */
    function yooadmin_network_site_yooadmin_provision_toggle_definitions(?string $td = null): array
    {
        if ($td === null) {
            $td = yooadmin_network_site_yooadmin_text_domain();
        }

        return [
            [
                'key'   => 'copy_settings',
                'field' => 'copy_settings',
                'label' => __('Admin settings', 'yooadmin'),
                'help'  => __('Copy redirects, focus behavior, and other YOOAdmin admin options from the network defaults.', 'yooadmin'),
            ],
            [
                'key'   => 'copy_theme_colors',
                'field' => 'copy_theme_colors',
                'label' => __('Theme colors', 'yooadmin'),
                'help'  => __('Copy admin theme brand colors from Theme Settings, including login color overrides when saved.', 'yooadmin'),
            ],
            [
                'key'   => 'copy_login_logo',
                'field' => 'copy_login_logo',
                'label' => __('Admin logo', 'yooadmin'),
                'help'  => __('Copy the admin header logo. Media files are imported into this site’s library so the logo URL stays valid.', 'yooadmin'),
            ],
            [
                'key'   => 'copy_custom_login',
                'field' => 'copy_custom_login',
                'label' => __('Custom login', 'yooadmin'),
                'help'  => __('Enable the YOOAdmin custom login page on this site and copy its layout, side image, and login logo settings.', 'yooadmin'),
            ],
            [
                'key'   => 'show_admin_tour',
                'field' => 'show_admin_tour',
                'label' => __('Guided tour', 'yooadmin'),
                'help'  => __('Show the YOOAdmin guided tour the first time the site admin opens wp-admin.', 'yooadmin'),
            ],
        ];
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_render_provision_toggle_rows')) {
    /**
     * @param array<string, bool> $defaults
     */
    function yooadmin_network_site_yooadmin_render_provision_toggle_rows(string $name_prefix, array $defaults, ?string $td = null, array $exclude_keys = []): void
    {
        foreach (yooadmin_network_site_yooadmin_provision_toggle_definitions($td) as $row) {
            $key = (string) $row['key'];
            if ($exclude_keys && in_array($key, $exclude_keys, true)) {
                continue;
            }
            yooadmin_network_site_yooadmin_render_toggle(
                $name_prefix . (string) $row['field'],
                (string) $row['label'],
                (string) $row['help'],
                !empty($defaults[ $key ]),
                sanitize_html_class($name_prefix . (string) $row['field'])
            );
        }
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_render_toggle')) {
    function yooadmin_network_site_yooadmin_render_toggle(
        string $name,
        string $label,
        string $description,
        bool $checked = false,
        string $id = ''
    ): void {
        if ($id === '') {
            $id = sanitize_html_class(str_replace(['[', ']'], '-', $name));
        }

        echo '<tr>';
        echo '<th scope="row">';
        echo '<div class="yp-th-content">';
        echo '<span>' . esc_html($label) . '</span>';
        if ($description !== '') {
            echo '<span class="yp-help-icon">';
            echo '<span class="dashicons dashicons-editor-help"></span>';
            echo '<span class="yp-tooltip">' . esc_html($description) . '</span>';
            echo '</span>';
        }
        echo '</div>';
        echo '</th>';
        echo '<td>';
        echo '<div class="yp-toggle-container">';
        echo '<label class="yp-toggle-switch">';
        echo '<input type="checkbox" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="1"' . checked($checked, true, false) . '>';
        echo '<span class="yp-toggle-slider"></span>';
        echo '</label>';
        echo '</div>';
        echo '</td>';
        echo '</tr>';
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_render_settings_table_open')) {
    function yooadmin_network_site_yooadmin_render_settings_table_open(): void
    {
        echo '<table class="form-table" role="presentation"><tbody>';
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_render_settings_table_close')) {
    function yooadmin_network_site_yooadmin_render_settings_table_close(): void
    {
        echo '</tbody></table>';
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_apply_template_to_site')) {
    /**
     * @param array<string, mixed> $args
     */
    function yooadmin_network_site_yooadmin_apply_template_to_site(int $blog_id, array $args = []): bool
    {
        if ($blog_id <= 0 || !get_site($blog_id)) {
            return false;
        }

        $args = wp_parse_args($args, yooadmin_network_site_yooadmin_default_provision_flags());

        $template = yooadmin_network_site_yooadmin_get_template();
        if (!$template) {
            return false;
        }

        $source_blog_id    = isset($template['source_blog_id']) ? (int) $template['source_blog_id'] : yooadmin_network_site_yooadmin_source_blog_id();
        $template_options  = !empty($template['yooadmin_options']) && is_array($template['yooadmin_options']) ? $template['yooadmin_options'] : [];
        $reserved_keys     = array_values(
            array_unique(
                array_merge(
                    yooadmin_network_site_yooadmin_admin_logo_option_keys(),
                    yooadmin_network_site_yooadmin_custom_login_option_keys(),
                    yooadmin_network_site_yooadmin_theme_color_option_keys($template_options)
                )
            )
        );

        switch_to_blog($blog_id);

        $options = get_option('yooadmin_options', []);
        if (!is_array($options)) {
            $options = [];
        }

        if (!empty($args['copy_settings']) && $template_options) {
            foreach ($template_options as $key => $value) {
                if (in_array((string) $key, $reserved_keys, true)) {
                    continue;
                }
                $options[ (string) $key ] = $value;
            }

            if (isset($template['yooadmin_focus_policy'])) {
                update_option('yooadmin_focus_policy', (string) $template['yooadmin_focus_policy'], false);
            }

            $theme_slug = isset($template['yooadmin_active_admin_theme']) ? (string) $template['yooadmin_active_admin_theme'] : '';
            if ($theme_slug !== '') {
                update_option('yooadmin_active_admin_theme', $theme_slug, false);
                if (!empty($template['yooadmin_admin_theme_settings']) && is_array($template['yooadmin_admin_theme_settings'])) {
                    update_option('yooadmin_admin_theme_settings_' . $theme_slug, $template['yooadmin_admin_theme_settings'], false);
                }
            }
        }

        if (!empty($args['copy_theme_colors'])) {
            if (!empty($template['yooadmin_colors']) && is_array($template['yooadmin_colors'])) {
                update_option('yooadmin_colors', $template['yooadmin_colors'], false);
            }

            $options = yooadmin_network_site_yooadmin_merge_template_option_keys(
                $options,
                $template_options,
                yooadmin_network_site_yooadmin_theme_color_option_keys($template_options)
            );
        }

        if (!empty($args['copy_login_logo']) && $template_options) {
            $logo_options = yooadmin_network_site_yooadmin_merge_template_option_keys(
                [],
                $template_options,
                yooadmin_network_site_yooadmin_admin_logo_option_keys()
            );
            $logo_options = yooadmin_network_site_yooadmin_remap_option_media_urls($logo_options, $blog_id, $source_blog_id);
            $options      = array_merge($options, $logo_options);
        }

        if (!empty($args['copy_custom_login']) && $template_options) {
            $login_options = yooadmin_network_site_yooadmin_merge_template_option_keys(
                [],
                $template_options,
                yooadmin_network_site_yooadmin_custom_login_option_keys()
            );
            $login_options = yooadmin_network_site_yooadmin_remap_option_media_urls($login_options, $blog_id, $source_blog_id);
            if (array_key_exists('login_page_content_page_id', $login_options)) {
                $login_options['login_page_content_page_id'] = 0;
            }
            $options = array_merge($options, $login_options);
        }

        if (
            !empty($args['copy_settings'])
            || !empty($args['copy_theme_colors'])
            || !empty($args['copy_login_logo'])
            || !empty($args['copy_custom_login'])
        ) {
            update_option('yooadmin_options', $options, false);
        }

        update_option('yooadmin_site_show_guided_tour', !empty($args['show_admin_tour']) ? 1 : 0, false);

        restore_current_blog();

        return true;
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_configure_user_tour')) {
    function yooadmin_network_site_yooadmin_configure_user_tour(int $user_id, bool $enabled): void
    {
        if ($user_id <= 0) {
            return;
        }

        if (class_exists('YOOAdmin_Labs_Prefs')) {
            YOOAdmin_Labs_Prefs::set_guided_tour_enabled($enabled, $user_id);
        }

        if (!$enabled) {
            delete_user_meta($user_id, 'yooadmin_guided_tour_state');
        }
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_provision_new_site')) {
    /**
     * @param array<string, mixed> $args
     */
    function yooadmin_network_site_yooadmin_provision_new_site(int $blog_id, int $admin_user_id, array $args = []): void
    {
        $args = wp_parse_args(
            $args,
            yooadmin_network_site_yooadmin_default_form_values()
        );

        yooadmin_network_site_yooadmin_apply_template_to_site($blog_id, $args);
        yooadmin_network_site_yooadmin_configure_user_tour($admin_user_id, !empty($args['show_admin_tour']));
    }
}

if (!function_exists('yooadmin_network_site_yooadmin_process_save')) {
    function yooadmin_network_site_yooadmin_process_save(): bool
    {
        if (!yooadmin_network_site_yooadmin_is_screen() || !current_user_can('manage_sites')) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $action = isset($_POST['yooadmin_network_site_yooadmin_action']) ? sanitize_key(wp_unslash((string) $_POST['yooadmin_network_site_yooadmin_action'])) : '';
        if ($action === '') {
            return false;
        }

        check_admin_referer('yooadmin-network-site-yooadmin');

        $blog_id = isset($_POST['id']) ? absint(wp_unslash((string) $_POST['id'])) : 0;
        if ($blog_id <= 0 || !yooadmin_network_site_editor_get_site($blog_id)) {
            wp_die(esc_html__('The requested site does not exist.', 'yooadmin'));
        }

        $redirect_args = ['id' => $blog_id];

        if ($action === 'apply-to-site') {
            yooadmin_network_site_yooadmin_apply_template_to_site(
                $blog_id,
                yooadmin_network_site_yooadmin_parse_provision_flags(
                    [
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'copy_settings'     => !empty($_POST['yooadmin_apply_copy_settings']),
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'copy_theme_colors' => !empty($_POST['yooadmin_apply_copy_theme_colors']),
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'copy_login_logo'   => !empty($_POST['yooadmin_apply_copy_login_logo']),
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'copy_custom_login' => !empty($_POST['yooadmin_apply_copy_custom_login']),
                        // phpcs:ignore WordPress.Security.NonceVerification.Missing
                        'show_admin_tour'   => !empty($_POST['yooadmin_apply_show_admin_tour']),
                    ]
                )
            );
            $redirect_args['update'] = 'applied';
        } elseif ($action === 'save-site-prefs') {
            switch_to_blog($blog_id);
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            update_option('yooadmin_site_show_guided_tour', !empty($_POST['yooadmin_site_show_admin_tour']) ? 1 : 0, false);
            restore_current_blog();
            $redirect_args['update'] = 'prefs_saved';
        }

        wp_safe_redirect(yooadmin_network_site_yooadmin_url($blog_id, $redirect_args));
        exit;
    }
}

add_action(
    'admin_init',
    static function (): void {
        if (!yooadmin_network_site_yooadmin_should_use()) {
            return;
        }
        yooadmin_network_site_yooadmin_process_save();
    },
    6
);

if (!function_exists('yooadmin_network_site_yooadmin_flash_message')) {
    /**
     * @return array{0: string, 1: string}
     */
    function yooadmin_network_site_yooadmin_flash_message(): array
    {
        $td = yooadmin_network_site_yooadmin_text_domain();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $update = isset($_GET['update']) ? sanitize_key(wp_unslash((string) $_GET['update'])) : '';

        switch ($update) {
            case 'defaults_saved':
                return [__('Network YOOAdmin defaults saved.', 'yooadmin'), 'success'];
            case 'applied':
                return [__('YOOAdmin settings applied to this site.', 'yooadmin'), 'success'];
            case 'prefs_saved':
                return [__('YOOAdmin site preferences saved.', 'yooadmin'), 'success'];
            default:
                return ['', ''];
        }
    }
}
