<?php
/**
 * YOOAdmin network sites manager (multisite + Focus Mode).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_sites_text_domain')) {
    function yooadmin_network_sites_text_domain(): string
    {
        return 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_sites_page_slug')) {
    function yooadmin_network_sites_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_sites_page_slug', 'yooadmin-network-sites');
    }
}

if (!function_exists('yooadmin_network_sites_url')) {
    function yooadmin_network_sites_url(array $args = []): string
    {
        $url = network_admin_url('admin.php?page=' . yooadmin_network_sites_page_slug());

        if ($args) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_sites_should_use')) {
    function yooadmin_network_sites_should_use(): bool
    {
        if (!is_multisite()) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        $enabled = true;
        if (function_exists('yooadmin_get_option')) {
            $enabled = (bool) yooadmin_get_option('network_sites_redirect', true);
        }

        return (bool) apply_filters('yooadmin_network_sites_should_use', $enabled);
    }
}

if (!function_exists('yooadmin_network_sites_is_screen')) {
    function yooadmin_network_sites_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_sites_page_slug();
    }
}

if (!function_exists('yooadmin_network_sites_per_page')) {
    function yooadmin_network_sites_per_page(): int
    {
        $per_page = 20;

        /**
         * @param int $per_page Sites per page in the manager.
         */
        return max(5, min(100, (int) apply_filters('yooadmin_network_sites_per_page', $per_page)));
    }
}

if (!function_exists('yooadmin_network_sites_current_page')) {
    function yooadmin_network_sites_current_page(): int
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only pagination.
        $paged = isset($_GET['paged']) ? absint(wp_unslash($_GET['paged'])) : 0;

        return max(1, $paged);
    }
}

if (!function_exists('yooadmin_network_sites_current_search')) {
    function yooadmin_network_sites_current_search(): string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only search query.
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash((string) $_GET['s'])) : '';

        return trim($search);
    }
}

if (!function_exists('yooadmin_network_sites_format_url')) {
    function yooadmin_network_sites_format_url(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $display = preg_replace('#^https?://#i', '', $url);

        return untrailingslashit((string) $display);
    }
}

if (!function_exists('yooadmin_network_sites_map_row')) {
    /**
     * @param WP_Site|object $site Site object.
     * @return array<string, mixed>|null
     */
    function yooadmin_network_sites_map_row($site): ?array
    {
        if (!is_object($site) || empty($site->blog_id)) {
            return null;
        }

        $blog_id = (int) $site->blog_id;
        if ($blog_id <= 0) {
            return null;
        }

        $td   = yooadmin_network_sites_text_domain();
        $name = function_exists('yooadmin_multisite_site_label')
            ? yooadmin_multisite_site_label($blog_id, 'yooadmin')
            : (string) $blog_id;

        $home_url  = get_home_url($blog_id, '/');
        $admin_url = get_admin_url($blog_id);
        $info_url  = function_exists('yooadmin_network_site_info_should_use') && yooadmin_network_site_info_should_use() && function_exists('yooadmin_network_site_info_url')
            ? yooadmin_network_site_info_url($blog_id)
            : network_admin_url('site-info.php?id=' . $blog_id);
        $settings_url = function_exists('yooadmin_network_site_settings_should_use') && yooadmin_network_site_settings_should_use() && function_exists('yooadmin_network_site_settings_url')
            ? yooadmin_network_site_settings_url($blog_id)
            : network_admin_url('site-settings.php?id=' . $blog_id);
        $yooadmin_url = function_exists('yooadmin_network_site_yooadmin_should_use') && yooadmin_network_site_yooadmin_should_use() && function_exists('yooadmin_network_site_yooadmin_url')
            ? yooadmin_network_site_yooadmin_url($blog_id)
            : '';
        $users_url = function_exists('yooadmin_network_site_users_url')
            ? yooadmin_network_site_users_url($blog_id)
            : network_admin_url('site-users.php?id=' . $blog_id);
        $themes_url = function_exists('yooadmin_network_site_themes_url')
            ? yooadmin_network_site_themes_url($blog_id)
            : network_admin_url('site-themes.php?id=' . $blog_id);

        $flags = [
            'archived' => !empty($site->archived),
            'spam'     => !empty($site->spam),
            'deleted'  => !empty($site->deleted),
            'mature'   => !empty($site->mature),
        ];
        $status_tags = function_exists('yooadmin_network_sites_status_tags')
            ? yooadmin_network_sites_status_tags($flags, 'yooadmin')
            : [];
        if ($blog_id === 1) {
            array_unshift(
                $status_tags,
                [
                    'slug'  => 'your-site',
                    'label' => __('Your site', 'yooadmin'),
                ]
            );
        }
        $status      = array_column($status_tags, 'label');

        return [
            'id'          => $blog_id,
            'name'        => $name,
            'home'        => $home_url,
            'admin'       => $admin_url,
            'info'        => $info_url,
            'users'       => $users_url,
            'themes'      => $themes_url,
            'settings'    => $settings_url,
            'yooadmin'    => $yooadmin_url,
            'url_label'   => yooadmin_network_sites_format_url($home_url),
            'is_main'     => $blog_id === 1,
            'status'      => $status,
            'status_tags' => $status_tags,
            'archived'    => $flags['archived'],
            'spam'        => $flags['spam'],
            'deleted'     => $flags['deleted'],
            'mature'      => $flags['mature'],
            'registered'  => !empty($site->registered) ? (string) $site->registered : '',
        ];
    }
}

if (!function_exists('yooadmin_network_sites_site_address')) {
    function yooadmin_network_sites_site_address(int $blog_id): string
    {
        if ($blog_id <= 0) {
            return '';
        }

        $details = get_site($blog_id);
        if (!$details) {
            return '';
        }

        return untrailingslashit((string) $details->domain . (string) $details->path);
    }
}

if (!function_exists('yooadmin_network_sites_status_tags')) {
    /**
     * @param array<string, bool> $flags
     * @return array<int, array{slug: string, label: string}>
     */
    function yooadmin_network_sites_status_tags(array $flags, ?string $td = null): array
    {
        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        $tags = [];
        if (!empty($flags['archived'])) {
            $tags[] = ['slug' => 'archived', 'label' => __('Archived', 'yooadmin')];
        }
        if (!empty($flags['spam'])) {
            $tags[] = ['slug' => 'spam', 'label' => _x('Spam', 'site', 'yooadmin')];
        }
        if (!empty($flags['deleted'])) {
            $tags[] = ['slug' => 'deleted', 'label' => __('Flagged for Deletion', 'yooadmin')];
        }
        if (!empty($flags['mature'])) {
            $tags[] = ['slug' => 'mature', 'label' => __('Mature', 'yooadmin')];
        }

        /**
         * @param array<int, array{slug: string, label: string}> $tags
         * @param array<string, bool>                           $flags
         */
        return (array) apply_filters('yooadmin_network_sites_status_tags', $tags, $flags);
    }
}

if (!function_exists('yooadmin_network_sites_confirm_copy')) {
    /**
     * Core-aligned confirmation copy for network site status actions.
     *
     * @return array<string, array{message: string, notice: string, confirm_label: string, tone: string}>
     */
    function yooadmin_network_sites_confirm_copy(?string $td = null): array
    {
        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        return [
            'activateblog' => [
                /* translators: %s: Site URL. */
                'message'       => __('You are about to remove the deletion flag from the site %s.', 'yooadmin'),
                'notice'        => '',
                'confirm_label' => __('Confirm', 'yooadmin'),
                'tone'          => 'success',
            ],
            'deactivateblog' => [
                /* translators: %s: Site URL. */
                'message'       => __('You are about to flag the site %s for deletion.', 'yooadmin'),
                'notice'        => __('Flagging a site for deletion makes the site unavailable to its users and visitors. This is a reversible action. A super admin can permanently delete the site at a later date.', 'yooadmin'),
                'confirm_label' => __('Confirm', 'yooadmin'),
                'tone'          => 'warning',
            ],
            'unarchiveblog' => [
                /* translators: %s: Site URL. */
                'message'       => __('You are about to unarchive the site %s.', 'yooadmin'),
                'notice'        => '',
                'confirm_label' => __('Confirm', 'yooadmin'),
                'tone'          => 'success',
            ],
            'archiveblog' => [
                /* translators: %s: Site URL. */
                'message'       => __('You are about to archive the site %s.', 'yooadmin'),
                'notice'        => __('Archiving a site makes the site unavailable to its users and visitors. This is a reversible action.', 'yooadmin'),
                'confirm_label' => __('Confirm', 'yooadmin'),
                'tone'          => 'warning',
            ],
            'unspamblog' => [
                /* translators: %s: Site URL. */
                'message'       => __('You are about to unspam the site %s.', 'yooadmin'),
                'notice'        => '',
                'confirm_label' => __('Confirm', 'yooadmin'),
                'tone'          => 'success',
            ],
            'spamblog' => [
                /* translators: %s: Site URL. */
                'message'       => __('You are about to mark the site %s as spam.', 'yooadmin'),
                'notice'        => '',
                'confirm_label' => __('Confirm', 'yooadmin'),
                'tone'          => 'danger',
            ],
            'deleteblog' => [
                /* translators: %s: Site URL. */
                'message'       => __('You are about to delete the site %s.', 'yooadmin'),
                'notice'        => __('Deleting a site is a permanent action that cannot be undone. This will delete the entire site and its uploads directory.', 'yooadmin'),
                'confirm_label' => __('Delete this site permanently', 'yooadmin'),
                'tone'          => 'danger',
            ],
        ];
    }
}

if (!function_exists('yooadmin_network_sites_build_confirm_meta')) {
    /**
     * @return array{action: string, id: int, nonce: string, message: string, notice: string, confirm_label: string, tone: string}|null
     */
    function yooadmin_network_sites_build_confirm_meta(int $blog_id, string $action_key, ?string $td = null): ?array
    {
        if ($blog_id <= 0 || $action_key === '') {
            return null;
        }

        $copy = yooadmin_network_sites_confirm_copy($td);
        if (!isset($copy[$action_key])) {
            return null;
        }

        $address = yooadmin_network_sites_site_address($blog_id);
        $entry   = $copy[$action_key];

        return [
            'action'        => $action_key,
            'id'            => $blog_id,
            'nonce'         => wp_create_nonce($action_key . '_' . $blog_id),
            'message'       => sprintf($entry['message'], $address),
            'notice'        => $entry['notice'],
            'confirm_label' => $entry['confirm_label'],
            'tone'          => $entry['tone'],
        ];
    }
}

if (!function_exists('yooadmin_network_sites_row_action_class')) {
    function yooadmin_network_sites_row_action_class(array $action): string
    {
        $classes = 'yp-network-sites-card__action-btn';
        if (!empty($action['primary'])) {
            $classes .= ' yp-network-sites-card__action-btn--primary';
        }

        $tone = isset($action['tone']) ? (string) $action['tone'] : '';
        if ($tone === 'danger' || !empty($action['danger'])) {
            $classes .= ' yp-network-sites-card__action-btn--danger';
        } elseif ($tone === 'warning') {
            $classes .= ' yp-network-sites-card__action-btn--warning';
        } elseif ($tone === 'success') {
            $classes .= ' yp-network-sites-card__action-btn--success';
        }

        if (!empty($action['confirm'])) {
            $classes .= ' yp-network-sites-card__action-btn--confirm';
        }

        return $classes;
    }
}

if (!function_exists('yooadmin_network_sites_confirm_url')) {
    /**
     * Core multisite confirmation URL (sites.php?action=confirm).
     */
    function yooadmin_network_sites_confirm_url(int $blog_id, string $action2): string
    {
        if ($blog_id <= 0 || $action2 === '') {
            return '';
        }

        $url = add_query_arg(
            [
                'action'  => 'confirm',
                'action2' => $action2,
                'id'      => $blog_id,
            ],
            network_admin_url('sites.php')
        );

        return (string) wp_nonce_url($url, $action2 . '_' . $blog_id);
    }
}

if (!function_exists('yooadmin_network_sites_bulk_action_url')) {
    function yooadmin_network_sites_bulk_action_url(): string
    {
        return network_admin_url('sites.php?action=allblogs');
    }
}

if (!function_exists('yooadmin_network_sites_bulk_actions')) {
    /**
     * Bulk actions aligned with WP_MS_Sites_List_Table::get_bulk_actions().
     *
     * @return array<string, string>
     */
    function yooadmin_network_sites_bulk_actions(?string $td = null): array
    {
        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        $actions = [];
        if (current_user_can('delete_sites')) {
            $actions['delete'] = __('Delete', 'yooadmin');
        }
        $actions['spam']    = _x('Mark as spam', 'site', 'yooadmin');
        $actions['notspam'] = _x('Not spam', 'site', 'yooadmin');

        return $actions;
    }
}

if (!function_exists('yooadmin_network_sites_updated_message')) {
    /**
     * @return array{0: string, 1: string} Message and notice type.
     */
    function yooadmin_network_sites_updated_message(string $action, ?string $td = null): array
    {
        $action = sanitize_key($action);
        if ($action === '') {
            return ['', ''];
        }

        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        $type = 'success';

        switch ($action) {
            case 'all_notspam':
                $msg = __('Sites removed from spam.', 'yooadmin');
                break;
            case 'all_spam':
                $msg = __('Sites marked as spam.', 'yooadmin');
                break;
            case 'all_delete':
                $msg = __('Sites permanently deleted.', 'yooadmin');
                break;
            case 'delete':
                $msg = __('Site permanently deleted.', 'yooadmin');
                break;
            case 'not_deleted':
                $msg = __('Sorry, you are not allowed to delete that site.', 'yooadmin');
                $type = 'error';
                break;
            case 'archiveblog':
                $msg = __('Site archived.', 'yooadmin');
                break;
            case 'unarchiveblog':
                $msg = __('Site unarchived.', 'yooadmin');
                break;
            case 'activateblog':
                $msg = __('Site deletion flag removed.', 'yooadmin');
                break;
            case 'deactivateblog':
                $msg = __('Site flagged for deletion.', 'yooadmin');
                break;
            case 'unspamblog':
                $msg = __('Site removed from spam.', 'yooadmin');
                break;
            case 'spamblog':
                $msg = __('Site marked as spam.', 'yooadmin');
                break;
            default:
                $msg = (string) apply_filters("network_sites_updated_message_{$action}", __('Settings saved.', 'yooadmin')); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core dynamic hook.
                break;
        }

        if ($msg === '') {
            return ['', ''];
        }

        return [$msg, $type];
    }
}

if (!function_exists('yooadmin_network_sites_flash_message')) {
    /**
     * @return array{0: string, 1: string} Message and notice type.
     */
    function yooadmin_network_sites_flash_message(): array
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash query arg.
        if (!isset($_GET['updated'])) {
            return ['', ''];
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash query arg.
        $action = sanitize_key(wp_unslash((string) $_GET['updated']));

        return yooadmin_network_sites_updated_message($action);
    }
}

if (!function_exists('yooadmin_network_sites_query')) {
    /**
     * @return array{items: array<int, array<string, mixed>>, total: int, pages: int, page: int, per_page: int, search: string}
     */
    function yooadmin_network_sites_query(): array
    {
        $per_page = yooadmin_network_sites_per_page();
        $page     = yooadmin_network_sites_current_page();
        $search   = yooadmin_network_sites_current_search();
        $offset   = ($page - 1) * $per_page;

        $args = [
            'number'   => $per_page,
            'offset'   => $offset,
            'orderby'  => 'id',
            'order'    => 'DESC',
            'archived' => null,
            'spam'     => null,
            'deleted'  => null,
        ];

        if ($search !== '') {
            $args['search']         = $search;
            $args['search_columns'] = ['domain', 'path'];
        }

        $sites = get_sites($args);
        $items = [];

        foreach ($sites as $site) {
            $row = yooadmin_network_sites_map_row($site);
            if ($row) {
                $items[] = $row;
            }
        }

        $count_args = $args;
        unset($count_args['number'], $count_args['offset']);
        $count_args['count'] = true;
        $total               = (int) get_sites($count_args);
        $pages               = max(1, (int) ceil($total / $per_page));

        return [
            'items'    => $items,
            'total'    => $total,
            'pages'    => $pages,
            'page'     => min($page, $pages),
            'per_page' => $per_page,
            'search'   => $search,
        ];
    }
}

if (!function_exists('yooadmin_network_sites_build_manage_actions')) {
    /**
     * Core multisite status actions (matches WP_MS_Sites_List_Table::handle_row_actions).
     *
     * @param array<string, mixed> $site
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_sites_build_manage_actions(array $site, ?string $td = null): array
    {
        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        $blog_id = isset($site['id']) ? (int) $site['id'] : 0;
        $is_main = !empty($site['is_main']);
        $actions = [];

        if ($blog_id <= 0 || $is_main || !current_user_can('manage_sites')) {
            return $actions;
        }

        $is_deleted  = !empty($site['deleted']);
        $is_archived = !empty($site['archived']);
        $is_spam     = !empty($site['spam']);

        $push_confirm_action = static function (string $action_key, string $icon, string $label) use (&$actions, $blog_id): void {
            $confirm = yooadmin_network_sites_build_confirm_meta($blog_id, $action_key, 'yooadmin');
            if (!$confirm) {
                return;
            }

            $actions[] = [
                'icon'    => $icon,
                'label'   => $label,
                'url'     => yooadmin_network_sites_confirm_url($blog_id, $action_key),
                'confirm' => $confirm,
                'tone'    => $confirm['tone'],
                'danger'  => $confirm['tone'] === 'danger',
            ];
        };

        if ($is_deleted) {
            $push_confirm_action('activateblog', 'dashicons-yes-alt', _x('Remove Deletion Flag', 'site', 'yooadmin'));
        } else {
            $push_confirm_action('deactivateblog', 'dashicons-flag', __('Flag for Deletion', 'yooadmin'));
        }

        if ($is_archived) {
            $push_confirm_action('unarchiveblog', 'dashicons-unlock', __('Unarchive', 'yooadmin'));
        } else {
            $push_confirm_action('archiveblog', 'dashicons-archive', _x('Archive', 'verb; site', 'yooadmin'));
        }

        if ($is_spam) {
            $push_confirm_action('unspamblog', 'dashicons-yes', _x('Not Spam', 'site', 'yooadmin'));
        } else {
            $push_confirm_action('spamblog', 'dashicons-warning', _x('Spam', 'site', 'yooadmin'));
        }

        if (current_user_can('delete_site', $blog_id)) {
            $push_confirm_action('deleteblog', 'dashicons-trash', __('Delete Permanently', 'yooadmin'));
        }

        return $actions;
    }
}

if (!function_exists('yooadmin_network_sites_build_text_row_actions')) {
    /**
     * Pipe-separated row links in core order (Edit, Dashboard, status actions, Visit, YOOAdmin extras).
     *
     * @param array<string, mixed> $site
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_sites_build_text_row_actions(array $site, ?string $td = null): array
    {
        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        $info_url     = isset($site['info']) ? (string) $site['info'] : '';
        $users_url    = isset($site['users']) ? (string) $site['users'] : '';
        $themes_url   = isset($site['themes']) ? (string) $site['themes'] : '';
        $settings_url = isset($site['settings']) ? (string) $site['settings'] : '';
        $home_url     = isset($site['home']) ? (string) $site['home'] : '';
        $admin_url    = isset($site['admin']) ? (string) $site['admin'] : '';
        $actions      = [];

        if ($info_url !== '') {
            $actions[] = [
                'label' => __('Edit', 'yooadmin'),
                'url'   => $info_url,
            ];
        }
        if ($admin_url !== '') {
            $actions[] = [
                'label' => __('Dashboard', 'yooadmin'),
                'url'   => $admin_url,
            ];
        }

        foreach (yooadmin_network_sites_build_manage_actions($site, 'yooadmin') as $manage_action) {
            $actions[] = [
                'label'  => (string) ($manage_action['label'] ?? ''),
                'url'    => (string) ($manage_action['url'] ?? ''),
                'danger' => !empty($manage_action['danger']),
            ];
        }

        if ($home_url !== '') {
            $actions[] = [
                'label'  => __('Visit', 'yooadmin'),
                'url'    => $home_url,
                'target' => '_blank',
            ];
        }

        if ($users_url !== '') {
            $actions[] = [
                'label' => __('Users', 'yooadmin'),
                'url'   => $users_url,
            ];
        }
        if ($themes_url !== '') {
            $actions[] = [
                'label' => __('Themes', 'yooadmin'),
                'url'   => $themes_url,
            ];
        }
        if ($settings_url !== '') {
            $actions[] = [
                'label' => __('Settings', 'yooadmin'),
                'url'   => $settings_url,
            ];
        }

        /**
         * Filters text row actions for a network site in YOOAdmin.
         *
         * @param array<int, array<string, mixed>> $actions Action definitions.
         * @param array<string, mixed>            $site    Site row data.
         */
        return (array) apply_filters('yooadmin_network_sites_text_row_actions', $actions, $site);
    }
}

if (!function_exists('yooadmin_network_sites_build_row_actions')) {
    /**
     * Icon toolbar actions (overflow menu + primary shortcuts).
     *
     * @param array<string, mixed> $site
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_sites_build_row_actions(array $site, ?string $td = null): array
    {
        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        $info_url     = isset($site['info']) ? (string) $site['info'] : '';
        $users_url    = isset($site['users']) ? (string) $site['users'] : '';
        $themes_url   = isset($site['themes']) ? (string) $site['themes'] : '';
        $settings_url = isset($site['settings']) ? (string) $site['settings'] : '';
        $home_url     = isset($site['home']) ? (string) $site['home'] : '';
        $admin_url    = isset($site['admin']) ? (string) $site['admin'] : '';
        $actions      = [];

        if ($info_url !== '') {
            $actions[] = [
                'icon'  => 'dashicons-edit',
                'label' => __('Edit', 'yooadmin'),
                'url'   => $info_url,
            ];
        }

        foreach (yooadmin_network_sites_build_manage_actions($site, 'yooadmin') as $manage_action) {
            $actions[] = $manage_action;
        }

        if ($users_url !== '') {
            $actions[] = [
                'icon'  => 'dashicons-groups',
                'label' => __('Users', 'yooadmin'),
                'url'   => $users_url,
            ];
        }
        if ($themes_url !== '') {
            $actions[] = [
                'icon'  => 'dashicons-admin-appearance',
                'label' => __('Themes', 'yooadmin'),
                'url'   => $themes_url,
            ];
        }
        if ($settings_url !== '') {
            $actions[] = [
                'icon'  => 'dashicons-admin-settings',
                'label' => __('Settings', 'yooadmin'),
                'url'   => $settings_url,
            ];
        }
        if ($home_url !== '') {
            $actions[] = [
                'icon'   => 'dashicons-external',
                'label'  => __('Visit', 'yooadmin'),
                'url'    => $home_url,
                'target' => '_blank',
            ];
        }
        if ($admin_url !== '') {
            $actions[] = [
                'icon'    => 'dashicons-dashboard',
                'label'   => __('Dashboard', 'yooadmin'),
                'url'     => $admin_url,
                'primary' => true,
            ];
        }

        /**
         * Filters row actions for a network site in YOOAdmin.
         *
         * @param array<int, array<string, mixed>> $actions Action definitions.
         * @param array<string, mixed>            $site    Site row data.
         */
        return (array) apply_filters('yooadmin_network_sites_row_actions', $actions, $site);
    }
}

if (!function_exists('yooadmin_network_sites_editor_header_button_class')) {
    function yooadmin_network_sites_editor_header_button_class(array $action): string
    {
        $classes = ['yp-yoo-btn'];
        $tone    = isset($action['tone']) ? (string) $action['tone'] : '';

        if ($tone === 'danger' || !empty($action['danger'])) {
            $classes[] = 'yp-yoo-btn--secondary';
            $classes[] = 'yoo-network-site-editor-manage-btn--danger';
        } elseif ($tone === 'warning') {
            $classes[] = 'yp-yoo-btn--secondary';
            $classes[] = 'yoo-network-site-editor-manage-btn--warning';
        } elseif ($tone === 'success') {
            $classes[] = 'yp-yoo-btn--soft';
        } else {
            $classes[] = 'yp-yoo-btn--secondary';
        }

        if (!empty($action['confirm'])) {
            $classes[] = 'yoo-network-site-editor-manage-btn--confirm';
        }

        return implode(' ', $classes);
    }
}

if (!function_exists('yooadmin_network_sites_build_editor_header_actions')) {
    /**
     * Site status actions for the network site editor header (archive, spam, delete, etc.).
     *
     * @param array<string, mixed> $site
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_sites_build_editor_header_actions(array $site, ?string $td = null): array
    {
        $actions = yooadmin_network_sites_build_manage_actions($site, 'yooadmin');

        /**
         * Filters editor header actions for a network site in YOOAdmin.
         *
         * @param array<int, array<string, mixed>> $actions Action definitions.
         * @param array<string, mixed>            $site    Site row data.
         */
        return (array) apply_filters('yooadmin_network_sites_editor_header_actions', $actions, $site);
    }
}

if (!function_exists('yooadmin_network_sites_editor_header_actions_partial')) {
    function yooadmin_network_sites_editor_header_actions_partial(): string
    {
        if (defined('YOOADMIN_PANEL_DIR')) {
            $path = YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/components/network-site-editor/editor-header-actions.php';
            if (is_readable($path)) {
                return $path;
            }
        }

        return dirname(__DIR__, 2) . '/templates/yoopixel/admin/components/network-site-editor/editor-header-actions.php';
    }
}

if (!function_exists('yooadmin_network_sites_render_editor_header_actions')) {
    /**
     * @param array<string, mixed> $site
     */
    function yooadmin_network_sites_render_editor_header_actions(array $site, ?string $td = null, ?string $selected_tab = null): void
    {
        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        $site_actions = yooadmin_network_sites_build_editor_header_actions($site, 'yooadmin');
        if (!$site_actions) {
            return;
        }

        $partial = yooadmin_network_sites_editor_header_actions_partial();
        if (!is_readable($partial)) {
            return;
        }

        include $partial;
    }
}

if (!function_exists('yooadmin_network_sites_status_tags_partial')) {
    function yooadmin_network_sites_status_tags_partial(): string
    {
        if (defined('YOOADMIN_PANEL_DIR')) {
            $path = YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/components/network-sites/status-tags.php';
            if (is_readable($path)) {
                return $path;
            }
        }

        return dirname(__DIR__, 2) . '/templates/yoopixel/admin/components/network-sites/status-tags.php';
    }
}

if (!function_exists('yooadmin_network_sites_render_status_tags')) {
    /**
     * @param array<string, mixed> $site
     */
    function yooadmin_network_sites_render_status_tags(array $site): void
    {
        $partial = yooadmin_network_sites_status_tags_partial();
        if (!is_readable($partial)) {
            return;
        }

        include $partial;
    }
}

if (!function_exists('yooadmin_network_sites_row_actions_partial')) {
    function yooadmin_network_sites_row_actions_partial(): string
    {
        if (defined('YOOADMIN_PANEL_DIR')) {
            $path = YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/components/network-sites/row-actions.php';
            if (is_readable($path)) {
                return $path;
            }
        }

        return dirname(__DIR__, 2) . '/templates/yoopixel/admin/components/network-sites/row-actions.php';
    }
}

if (!function_exists('yooadmin_network_sites_text_row_actions_partial')) {
    function yooadmin_network_sites_text_row_actions_partial(): string
    {
        if (defined('YOOADMIN_PANEL_DIR')) {
            $path = YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/components/network-sites/row-actions-text.php';
            if (is_readable($path)) {
                return $path;
            }
        }

        return dirname(__DIR__, 2) . '/templates/yoopixel/admin/components/network-sites/row-actions-text.php';
    }
}

if (!function_exists('yooadmin_network_sites_confirm_script_data')) {
    /**
     * @return array<string, string>
     */
    function yooadmin_network_sites_confirm_script_data(?string $td = null): array
    {
        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        $referer = function_exists('yooadmin_network_sites_url')
            ? yooadmin_network_sites_url()
            : network_admin_url('sites.php');

        return [
            'ajaxUrl'            => admin_url('admin-ajax.php'),
            'ajaxAction'         => 'yooadmin_network_sites_action',
            'ajaxNonce'          => wp_create_nonce('yooadmin_network_sites'),
            'postUrl'            => network_admin_url('sites.php'),
            'referer'            => $referer,
            'confirmTitle'       => __('Confirm action', 'yooadmin'),
            'cancel'             => __('Cancel', 'yooadmin'),
            'confirm'            => __('Confirm', 'yooadmin'),
            'errorGeneric'       => __('Something went wrong. Please try again.', 'yooadmin'),
            /* translators: %d: number of selected sites. */
            'bulkDeleteConfirm'  => __('Delete %d selected sites permanently? This cannot be undone.', 'yooadmin'),
            'bulkDeleteLabel'    => __('Delete permanently', 'yooadmin'),
            /* translators: %d: number of selected sites. */
            'bulkSpamConfirm'    => __('Mark %d selected sites as spam?', 'yooadmin'),
            /* translators: %d: number of selected sites. */
            'bulkNotSpamConfirm' => __('Remove %d selected sites from spam?', 'yooadmin'),
            /* translators: %d: number of selected sites. */
            'bulkGenericConfirm' => __('Apply this action to %d selected sites?', 'yooadmin'),
        ];
    }
}

if (!function_exists('yooadmin_network_sites_manage_action_keys')) {
    /**
     * @return string[]
     */
    function yooadmin_network_sites_manage_action_keys(): array
    {
        return [
            'activateblog',
            'deactivateblog',
            'unarchiveblog',
            'archiveblog',
            'unspamblog',
            'spamblog',
            'deleteblog',
        ];
    }
}

if (!function_exists('yooadmin_network_sites_perform_action')) {
    /**
     * Run a single network site status action (aligned with wp-admin/network/sites.php).
     *
     * @return array{updated: string, removed: bool}|WP_Error
     */
    function yooadmin_network_sites_perform_action(int $blog_id, string $action)
    {
        $action = sanitize_key($action);
        if ($blog_id <= 0 || !in_array($action, yooadmin_network_sites_manage_action_keys(), true)) {
            return new WP_Error('invalid_request', __('The requested action is not valid.', 'yooadmin'));
        }

        if (!current_user_can('manage_sites')) {
            return new WP_Error('forbidden', __('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        if (is_main_site($blog_id)) {
            return new WP_Error('forbidden', __('Sorry, you are not allowed to change the current site.', 'yooadmin'));
        }

        $updated_action = '';
        $removed        = false;

        switch ($action) {
            case 'deleteblog':
                if (!current_user_can('delete_sites') || !current_user_can('delete_site', $blog_id)) {
                    return new WP_Error('forbidden', __('Sorry, you are not allowed to delete that site.', 'yooadmin'));
                }

                wpmu_delete_blog($blog_id, true);
                $updated_action = 'delete';
                $removed        = true;
                break;

            case 'archiveblog':
            case 'unarchiveblog':
                update_blog_status($blog_id, 'archived', ('archiveblog' === $action) ? '1' : '0');
                $updated_action = $action;
                break;

            case 'activateblog':
                update_blog_status($blog_id, 'deleted', '0');
                /** This action is documented in wp-admin/network/sites.php */
                do_action('activate_blog', $blog_id); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
                $updated_action = $action;
                break;

            case 'deactivateblog':
                /** This action is documented in wp-admin/network/sites.php */
                do_action('deactivate_blog', $blog_id); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
                update_blog_status($blog_id, 'deleted', '1');
                $updated_action = $action;
                break;

            case 'spamblog':
            case 'unspamblog':
                update_blog_status($blog_id, 'spam', ('spamblog' === $action) ? '1' : '0');
                $updated_action = $action;
                break;
        }

        return [
            'updated' => $updated_action,
            'removed' => $removed,
        ];
    }
}

if (!function_exists('yooadmin_network_sites_perform_bulk_action')) {
    /**
     * @param int[] $blog_ids
     * @return array{updated: string, removed_ids: int[]}|WP_Error
     */
    function yooadmin_network_sites_perform_bulk_action(string $bulk_action, array $blog_ids)
    {
        $bulk_action = sanitize_key($bulk_action);
        $blog_ids    = array_values(array_filter(array_map('absint', $blog_ids)));

        if (!$blog_ids || !in_array($bulk_action, ['delete', 'spam', 'notspam'], true)) {
            return new WP_Error('invalid_request', __('The requested action is not valid.', 'yooadmin'));
        }

        if (!current_user_can('manage_sites')) {
            return new WP_Error('forbidden', __('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        $updated_action = '';
        $removed_ids    = [];

        foreach ($blog_ids as $blog_id) {
            if ($blog_id <= 0 || is_main_site($blog_id)) {
                continue;
            }

            if ('delete' === $bulk_action) {
                if (!current_user_can('delete_sites') || !current_user_can('delete_site', $blog_id)) {
                    return new WP_Error('forbidden', __('Sorry, you are not allowed to delete that site.', 'yooadmin'));
                }

                wpmu_delete_blog($blog_id, true);
                $updated_action = 'all_delete';
                $removed_ids[]  = $blog_id;
                continue;
            }

            if ('spam' === $bulk_action) {
                update_blog_status($blog_id, 'spam', '1');
                $updated_action = 'all_spam';
            } else {
                update_blog_status($blog_id, 'spam', '0');
                $updated_action = 'all_notspam';
            }
        }

        return [
            'updated'     => $updated_action,
            'removed_ids' => $removed_ids,
        ];
    }
}

if (!function_exists('yooadmin_network_sites_capture_partial')) {
    function yooadmin_network_sites_capture_partial(callable $render): string
    {
        ob_start();
        $render();
        return (string) ob_get_clean();
    }
}

if (!function_exists('yooadmin_network_sites_render_status_tags_html')) {
    function yooadmin_network_sites_render_status_tags_html(array $site): string
    {
        return yooadmin_network_sites_capture_partial(
            static function () use ($site): void {
                if (function_exists('yooadmin_network_sites_render_status_tags')) {
                    yooadmin_network_sites_render_status_tags($site);
                }
            }
        );
    }
}

if (!function_exists('yooadmin_network_sites_render_row_actions_html')) {
    function yooadmin_network_sites_render_row_actions_html(array $site, ?array $args = null): string
    {
        return yooadmin_network_sites_capture_partial(
            static function () use ($site, $args): void {
                if (function_exists('yooadmin_network_sites_render_row_actions')) {
                    yooadmin_network_sites_render_row_actions($site, null, $args);
                }
            }
        );
    }
}

if (!function_exists('yooadmin_network_sites_action_response_message')) {
    function yooadmin_network_sites_action_response_message(string $updated_action): string
    {
        $flash = yooadmin_network_sites_updated_message($updated_action);

        return $flash[0] !== '' ? $flash[0] : __('Settings saved.', 'yooadmin');
    }
}

if (!function_exists('yooadmin_network_sites_ajax_site_action')) {
    function yooadmin_network_sites_ajax_site_action(): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $ajax_nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if ($ajax_nonce === '' || !wp_verify_nonce($ajax_nonce, 'yooadmin_network_sites')) {
            wp_send_json_error(
                [
                    'message' => __(
                        'Security check failed. Please refresh the page and try again.',
                        'yooadmin'
                    ),
                ]
            );
        }

        if (!is_multisite() || !current_user_can('manage_sites')) {
            wp_send_json_error(['message' => __('Sorry, you are not allowed to access this page.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
        $site_action = isset($_POST['site_action']) ? sanitize_key(wp_unslash((string) $_POST['site_action'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
        $bulk_action = isset($_POST['bulk_action']) ? sanitize_key(wp_unslash((string) $_POST['bulk_action'])) : '';

        if ($bulk_action !== '') {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; IDs cast to int in perform_bulk_action().
            $raw_ids = isset($_POST['ids']) ? (array) wp_unslash($_POST['ids']) : [];
            $result  = yooadmin_network_sites_perform_bulk_action($bulk_action, $raw_ids);
            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()]);
            }

            $message = yooadmin_network_sites_action_response_message((string) $result['updated']);
            wp_send_json_success(
                [
                    'message'     => $message,
                    'notice_type' => 'success',
                    'removed_ids' => $result['removed_ids'],
                ]
            );
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
        $blog_id = isset($_POST['id']) ? absint(wp_unslash((string) $_POST['id'])) : 0;
        if ($blog_id <= 0 || $site_action === '') {
            wp_send_json_error(['message' => __('The requested action is not valid.', 'yooadmin')]);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Per-action nonce verified below.
        $site_nonce = isset($_POST['site_nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['site_nonce'])) : '';
        if (!wp_verify_nonce($site_nonce, $site_action . '_' . $blog_id)) {
            wp_send_json_error(['message' => __('Security check failed. Please refresh the page and try again.', 'yooadmin')]);
        }

        $result = yooadmin_network_sites_perform_action($blog_id, $site_action);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        $message = yooadmin_network_sites_action_response_message((string) $result['updated']);
        $payload = [
            'message'     => $message,
            'notice_type' => 'success',
            'removed'     => !empty($result['removed']),
            'site_id'     => $blog_id,
        ];

        if (!empty($result['removed'])) {
            wp_send_json_success($payload);
        }

        $site = get_site($blog_id);
        $row  = $site ? yooadmin_network_sites_map_row($site) : null;
        if ($row) {
            $payload['status_tags_html'] = yooadmin_network_sites_render_status_tags_html($row);
            $payload['actions_html']     = yooadmin_network_sites_render_row_actions_html($row);
        }

        wp_send_json_success($payload);
    }
}

if (!has_action('wp_ajax_yooadmin_network_sites_action', 'yooadmin_network_sites_ajax_site_action')) {
    add_action('wp_ajax_yooadmin_network_sites_action', 'yooadmin_network_sites_ajax_site_action');
}

if (!function_exists('yooadmin_network_sites_enqueue_confirm_assets')) {
    function yooadmin_network_sites_enqueue_confirm_assets(callable $add_script, callable $add_style): void
    {
        $add_style('yooadmin-network-site-info-page', 'assets/css/admin/network-site-info-page.css', ['yooadmin-network-settings-page']);
        $add_style(
            'yooadmin-confirm-dialog',
            'assets/css/admin/yoo-confirm-dialog.css',
            ['yooadmin-network-site-info-page']
        );
        $add_script('yooadmin-confirm-dialog', 'assets/js/admin/yoo-confirm-dialog.js', [], true);
    }
}

if (!function_exists('yooadmin_network_sites_localize_confirm_script')) {
    function yooadmin_network_sites_localize_confirm_script(): void
    {
        if (!wp_script_is('yooadmin-network-dashboard-sites', 'registered')) {
            return;
        }

        $td = yooadmin_network_sites_text_domain();
        wp_localize_script(
            'yooadmin-network-dashboard-sites',
            'yooNetworkSitesConfirm',
            yooadmin_network_sites_confirm_script_data($td)
        );
    }
}

if (!function_exists('yooadmin_network_sites_render_row_actions')) {
    /**
     * @param array<string, mixed>      $site
     * @param array<string, mixed>|null $args Optional. style: icons|text.
     */
    function yooadmin_network_sites_render_row_actions(array $site, ?string $td = null, ?array $args = null): void
    {
        if ($td === null) {
            $td = yooadmin_network_sites_text_domain();
        }

        $args  = is_array($args) ? $args : [];
        $style = isset($args['style']) ? (string) $args['style'] : 'icons';
        $visible_count = array_key_exists('visible_count', $args) ? (int) $args['visible_count'] : 2;

        if ($style === 'text') {
            $site_actions = yooadmin_network_sites_build_text_row_actions($site, 'yooadmin');
            $partial      = yooadmin_network_sites_text_row_actions_partial();
        } elseif ($style === 'editor_header') {
            $site_actions  = yooadmin_network_sites_build_editor_header_actions($site, 'yooadmin');
            $partial       = yooadmin_network_sites_row_actions_partial();
            $visible_count = max(count($site_actions), 1);
        } else {
            $site_actions = yooadmin_network_sites_build_row_actions($site, 'yooadmin');
            $partial      = yooadmin_network_sites_row_actions_partial();
        }

        if (!$site_actions) {
            return;
        }

        if (!is_readable($partial)) {
            return;
        }

        include $partial;
    }
}
