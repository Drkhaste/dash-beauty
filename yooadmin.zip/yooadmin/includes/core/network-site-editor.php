<?php
/**
 * YOOAdmin network site editor — shared shell helpers (multisite + Focus Mode).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_site_editor_text_domain')) {
    function yooadmin_network_site_editor_text_domain(): string
    {
        return function_exists('yooadmin_network_site_info_text_domain')
            ? yooadmin_network_site_info_text_domain()
            : (function_exists('yooadmin_multisite_text_domain') ? yooadmin_multisite_text_domain() : 'yooadmin');
    }
}

if (!function_exists('yooadmin_network_site_editor_should_use')) {
    function yooadmin_network_site_editor_should_use(): bool
    {
        return function_exists('yooadmin_network_site_info_should_use')
            && yooadmin_network_site_info_should_use();
    }
}

if (!function_exists('yooadmin_network_site_editor_current_id')) {
    function yooadmin_network_site_editor_current_id(): int
    {
        return function_exists('yooadmin_network_site_info_current_id')
            ? yooadmin_network_site_info_current_id()
            : (isset($_GET['id']) ? absint(wp_unslash((string) $_GET['id'])) : 0); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    }
}

if (!function_exists('yooadmin_network_site_editor_get_site')) {
    /**
     * @return WP_Site|null
     */
    function yooadmin_network_site_editor_get_site(int $blog_id)
    {
        return function_exists('yooadmin_network_site_info_get_site')
            ? yooadmin_network_site_info_get_site($blog_id)
            : null;
    }
}

if (!function_exists('yooadmin_network_site_editor_site_name')) {
    function yooadmin_network_site_editor_site_name(int $blog_id): string
    {
        return function_exists('yooadmin_network_site_info_site_name')
            ? yooadmin_network_site_info_site_name($blog_id)
            : (string) $blog_id;
    }
}

if (!function_exists('yooadmin_network_site_editor_page_slugs')) {
    /**
     * @return array<string, string>
     */
    function yooadmin_network_site_editor_page_slugs(): array
    {
        return [
            'site-info'     => function_exists('yooadmin_network_site_info_page_slug') ? yooadmin_network_site_info_page_slug() : 'yooadmin-network-site-info',
            'site-users'    => function_exists('yooadmin_network_site_users_page_slug') ? yooadmin_network_site_users_page_slug() : 'yooadmin-network-site-users',
            'site-themes'   => function_exists('yooadmin_network_site_themes_page_slug') ? yooadmin_network_site_themes_page_slug() : 'yooadmin-network-site-themes',
            'site-settings' => function_exists('yooadmin_network_site_settings_page_slug') ? yooadmin_network_site_settings_page_slug() : 'yooadmin-network-site-settings',
            'site-yooadmin' => function_exists('yooadmin_network_site_yooadmin_page_slug') ? yooadmin_network_site_yooadmin_page_slug() : 'yooadmin-network-site-yooadmin',
        ];
    }
}

if (!function_exists('yooadmin_network_site_editor_is_screen')) {
    function yooadmin_network_site_editor_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return in_array($page, array_values(yooadmin_network_site_editor_page_slugs()), true);
    }
}

if (!function_exists('yooadmin_network_site_editor_selected_tab')) {
    function yooadmin_network_site_editor_selected_tab(): string
    {
        $map = array_flip(yooadmin_network_site_editor_page_slugs());
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return isset($map[ $page ]) ? (string) $map[ $page ] : 'site-info';
    }
}

if (!function_exists('yooadmin_network_site_editor_nav_tabs')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_site_editor_nav_tabs(int $blog_id, ?string $selected = null): array
    {
        $td       = yooadmin_network_site_editor_text_domain();
        $selected = $selected ?? yooadmin_network_site_editor_selected_tab();

        $info_url = function_exists('yooadmin_network_site_info_url')
            ? yooadmin_network_site_info_url($blog_id)
            : network_admin_url('admin.php?page=yooadmin-network-site-info&id=' . $blog_id);
        $users_url = function_exists('yooadmin_network_site_users_url')
            ? yooadmin_network_site_users_url($blog_id)
            : network_admin_url('admin.php?page=yooadmin-network-site-users&id=' . $blog_id);
        $themes_url = function_exists('yooadmin_network_site_themes_url')
            ? yooadmin_network_site_themes_url($blog_id)
            : network_admin_url('admin.php?page=yooadmin-network-site-themes&id=' . $blog_id);
        $settings_url = function_exists('yooadmin_network_site_settings_url')
            ? yooadmin_network_site_settings_url($blog_id)
            : network_admin_url('admin.php?page=yooadmin-network-site-settings&id=' . $blog_id);
        $yooadmin_url = function_exists('yooadmin_network_site_yooadmin_url')
            ? yooadmin_network_site_yooadmin_url($blog_id)
            : network_admin_url('admin.php?page=yooadmin-network-site-yooadmin&id=' . $blog_id);

        return [
            [
                'id'       => 'site-info',
                'label'    => __('Info', 'yooadmin'),
                'icon'     => 'dashicons-info-outline',
                'desc'     => __('Site address, registration dates, and attributes.', 'yooadmin'),
                'url'      => $info_url,
                'selected' => $selected === 'site-info',
            ],
            [
                'id'       => 'site-users',
                'label'    => __('Users', 'yooadmin'),
                'icon'     => 'dashicons-admin-users',
                'desc'     => __('Manage users assigned to this site.', 'yooadmin'),
                'url'      => $users_url,
                'selected' => $selected === 'site-users',
            ],
            [
                'id'       => 'site-themes',
                'label'    => __('Themes', 'yooadmin'),
                'icon'     => 'dashicons-admin-appearance',
                'desc'     => __('Enable or disable themes for this site.', 'yooadmin'),
                'url'      => $themes_url,
                'selected' => $selected === 'site-themes',
            ],
            [
                'id'       => 'site-settings',
                'label'    => __('Settings', 'yooadmin'),
                'icon'     => 'dashicons-admin-settings',
                'desc'     => __('Site-specific options and defaults.', 'yooadmin'),
                'url'      => $settings_url,
                'selected' => $selected === 'site-settings',
            ],
            [
                'id'       => 'site-yooadmin',
                'label'    => __('YOOAdmin', 'yooadmin'),
                'icon'     => 'dashicons-admin-customizer',
                'desc'     => __('Copy YOOAdmin admin settings, login branding, and guided tour defaults for this site.', 'yooadmin'),
                'url'      => $yooadmin_url,
                'selected' => $selected === 'site-yooadmin',
            ],
        ];
    }
}

if (!function_exists('yooadmin_network_site_editor_shell_template')) {
    function yooadmin_network_site_editor_shell_template(): string
    {
        if (defined('YOOADMIN_PANEL_DIR')) {
            $path = YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/components/network-site-editor/shell.php';
            if (is_readable($path)) {
                return $path;
            }
        }

        $fallback = dirname(__DIR__, 2) . '/templates/yoopixel/admin/components/network-site-editor/shell.php';

        return is_readable($fallback) ? $fallback : '';
    }
}

if (!function_exists('yooadmin_network_site_editor_flash_message')) {
    /**
     * Resolve redirect flash message for a network site editor tab.
     *
     * @return array{0: string, 1: string} Message and type (success|error).
     */
    function yooadmin_network_site_editor_flash_message(string $context = ''): array
    {
        switch ($context) {
            case 'site-users':
                return function_exists('yooadmin_network_site_users_flash_message')
                    ? yooadmin_network_site_users_flash_message()
                    : ['', ''];

            case 'site-themes':
                return function_exists('yooadmin_network_site_themes_flash_message')
                    ? yooadmin_network_site_themes_flash_message()
                    : ['', ''];

            case 'site-settings':
                $td = yooadmin_network_site_editor_text_domain();
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                if (isset($_GET['update']) && sanitize_key(wp_unslash((string) $_GET['update'])) === 'updated') {
                    return [__('Site options updated.', 'yooadmin'), 'success'];
                }

                return ['', ''];

            case 'site-yooadmin':
                return function_exists('yooadmin_network_site_yooadmin_flash_message')
                    ? yooadmin_network_site_yooadmin_flash_message()
                    : ['', ''];

            case 'site-info':
            default:
                $td = function_exists('yooadmin_network_site_info_text_domain')
                    ? yooadmin_network_site_info_text_domain()
                    : yooadmin_network_site_editor_text_domain();
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                if (isset($_GET['update']) && sanitize_key(wp_unslash((string) $_GET['update'])) === 'updated') {
                    return [__('Site info updated.', 'yooadmin'), 'success'];
                }

                return ['', ''];
        }
    }
}

if (!function_exists('yooadmin_network_site_editor_render_notice')) {
    function yooadmin_network_site_editor_render_notice(string $message, string $type = 'success'): void
    {
        if ($message === '') {
            return;
        }

        $class = 'yoo-network-site-info-notice yoo-network-site-info-notice--success';
        if ($type === 'error') {
            $class = 'yoo-network-site-info-notice yoo-network-site-editor-notice--error';
        }

        echo '<div class="' . esc_attr($class) . '" role="status">';
        echo '<span class="dashicons dashicons-' . esc_attr($type === 'error' ? 'warning' : 'yes-alt') . '" aria-hidden="true"></span>';
        echo esc_html($message);
        echo '</div>';
    }
}

if (!function_exists('yooadmin_network_site_editor_build_breadcrumb_trail')) {
    /**
     * Breadcrumb trail for network site editor screens (after Home in yp-breadcrumbs-bar).
     *
     * @return array<int, array{label: string, url: string}>
     */
    function yooadmin_network_site_editor_build_breadcrumb_trail(): array
    {
        $td = yooadmin_network_site_editor_text_domain();
        $blog_id = yooadmin_network_site_editor_current_id();

        $sites_url = function_exists('yooadmin_network_sites_url')
            ? yooadmin_network_sites_url()
            : network_admin_url('admin.php?page=yooadmin-network-sites');

        $trail = [
            [
                'label' => __('Sites', 'yooadmin'),
                'url'   => $sites_url,
            ],
        ];

        if ($blog_id <= 0 || !yooadmin_network_site_editor_get_site($blog_id)) {
            return $trail;
        }

        $site_name = yooadmin_network_site_editor_site_name($blog_id);
        $info_url  = function_exists('yooadmin_network_site_info_url')
            ? yooadmin_network_site_info_url($blog_id)
            : network_admin_url('admin.php?page=yooadmin-network-site-info&id=' . $blog_id);

        $selected = yooadmin_network_site_editor_selected_tab();

        if ($selected === 'site-info') {
            $trail[] = [
                'label' => $site_name,
                'url'   => '',
            ];

            return $trail;
        }

        $trail[] = [
            'label' => $site_name,
            'url'   => $info_url,
        ];

        foreach (yooadmin_network_site_editor_nav_tabs($blog_id, $selected) as $tab_item) {
            if (empty($tab_item['selected'])) {
                continue;
            }

            $tab_label = isset($tab_item['label']) ? (string) $tab_item['label'] : '';
            if ($tab_label !== '') {
                $trail[] = [
                    'label' => $tab_label,
                    'url'   => '',
                ];
            }
            break;
        }

        return $trail;
    }
}
