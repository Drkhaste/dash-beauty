<?php
/**
 * YOOAdmin - Shell DOM injection (header/footer)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/* -------------------------------------------------------------------------
 * Load navigation helpers early (breadcrumbs + sidebar SSR fallbacks)
 * ---------------------------------------------------------------------- */
(function () {
    if (!empty($GLOBALS['yooadmin_helpers_nav_loaded'])) {
        return;
    }
    $helpers_nav = dirname(__DIR__) . '/helpers/helpers-nav.php';
    if (file_exists($helpers_nav)) {
        require_once $helpers_nav;
    }
    $shell_user_menu = dirname(__DIR__) . '/helpers/shell-user-menu.php';
    if (file_exists($shell_user_menu)) {
        require_once $shell_user_menu;
    }
    $GLOBALS['yooadmin_helpers_nav_loaded'] = true;
})();

/* -------------------------------------------------------------------------
 * Environment guards
 * ---------------------------------------------------------------------- */
function yooadmin__should_shell_inject_now(): bool {
    // Global policy gate
    if (!function_exists('yooadmin_should_inject_shell') || !yooadmin_should_inject_shell()) {
        return false;
    }
    // Skip async contexts
    if ((function_exists('wp_doing_ajax') && wp_doing_ajax())
        || (function_exists('wp_doing_cron') && wp_doing_cron())
        || defined('REST_REQUEST')) {
        return false;
    }
    if (is_user_admin()) {
        return false;
    }
    if (is_network_admin() && function_exists('yooadmin_inject_shell_on_network') && !yooadmin_inject_shell_on_network()) {
        return false;
    }
    // Skip heavy WooCommerce SPA routes (support both helper names)
    if ((function_exists('yooadmin_is_wc_heavy_spa_page') && yooadmin_is_wc_heavy_spa_page())
        || (function_exists('yp_is_wc_heavy_spa_page') && yp_is_wc_heavy_spa_page())) {
        return false;
    }

    // Allow integrators to skip specific ?page= slugs if needed (default: inject everywhere)
    $skip_pages = apply_filters('yooadmin_shell_skip_pages', []);
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
    if (!empty($skip_pages) && !empty($_GET['page'])) {
        $page = sanitize_text_field(wp_unslash($_GET['page']));
        if (in_array($page, (array) $skip_pages, true)) {
            // phpcs:enable WordPress.Security.NonceVerification.Recommended
            return false;
        }
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    return true;
}

function yooadmin__should_shell_footer_inject_now(): bool {
    if (!yooadmin__should_shell_inject_now()) {
        return false;
    }

    /**
     * Filter: yooadmin_should_inject_shell_footer
     *
     * @param bool $inject Whether the YOOAdmin footer shell should render.
     */
    return (bool) apply_filters('yooadmin_should_inject_shell_footer', true);
}

/* -------------------------------------------------------------------------
 * Resolve template paths (filterable)
 * ---------------------------------------------------------------------- */
function yooadmin__shell_template_paths(): array {
    $base_file = defined('YOOADMIN_PLUGIN_FILE')
        ? YOOADMIN_PLUGIN_FILE
        : dirname(__DIR__, 2) . '/yooadmin.php';

    $dir = plugin_dir_path($base_file);

    $paths = [
        'header' => $dir . 'templates/yoopixel/admin/layout/header.php',
        'footer' => $dir . 'templates/yoopixel/admin/layout/footer.php',
    ];

    /**
     * Filter: yooadmin_shell_template_paths
     * Allows overriding header/footer template absolute paths.
     *
     * @param array $paths ['header' => '/abs/path', 'footer' => '/abs/path']
     */
    return apply_filters('yooadmin_shell_template_paths', $paths);
}

/* -------------------------------------------------------------------------
 * Header injection
 * ---------------------------------------------------------------------- */
add_action('in_admin_header', function () {
    if (!yooadmin__should_shell_inject_now()) {
        return;
    }

    // Prevent double-injection
    if (!empty($GLOBALS['yooadmin_header_printed'])) {
        return;
    }
    $GLOBALS['yooadmin_header_printed'] = true;

    $paths = yooadmin__shell_template_paths();
    $header_file = isset($paths['header']) ? (string) $paths['header'] : '';

    if ($header_file && file_exists($header_file)) {
        include $header_file; // Template prints markup (no inline assets here)
    }

    // Open content wrapper after header
    echo '<div class="yoo-shell-content" id="yoo-shell-content">';
}, 0);

/* -------------------------------------------------------------------------
 * Footer injection
 * ---------------------------------------------------------------------- */
add_action('in_admin_footer', function () {
    if (!yooadmin__should_shell_inject_now()) {
        return;
    }

    // Close content wrapper if header was printed
    if (!empty($GLOBALS['yooadmin_header_printed'])) {
        echo '</div><!-- /.yoo-shell-content -->';
    }

    $paths = yooadmin__shell_template_paths();
    $footer_file = isset($paths['footer']) ? (string) $paths['footer'] : '';

    if ($footer_file && file_exists($footer_file) && yooadmin__should_shell_footer_inject_now()) {
        include_once $footer_file;
    }
}, PHP_INT_MAX);
