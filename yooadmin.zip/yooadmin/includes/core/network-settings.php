<?php
defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_settings_page_slug')) {
    function yooadmin_network_settings_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_settings_page_slug', 'yooadmin-network-settings');
    }
}

if (!function_exists('yooadmin_network_settings_url')) {
    function yooadmin_network_settings_url(string $tab = ''): string
    {
        $url = network_admin_url('admin.php?page=' . yooadmin_network_settings_page_slug());
        if ($tab !== '') {
            $url = add_query_arg('tab', sanitize_key($tab), $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_settings_should_use')) {
    function yooadmin_network_settings_should_use(): bool
    {
        if (!is_multisite()) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        $enabled = true;
        if (function_exists('yooadmin_get_option')) {
            $enabled = (bool) yooadmin_get_option('network_settings_redirect', true);
        }

        return (bool) apply_filters('yooadmin_network_settings_should_use', $enabled);
    }
}

if (!function_exists('yooadmin_network_settings_is_screen')) {
    function yooadmin_network_settings_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_settings_page_slug();
    }
}

if (!function_exists('yooadmin_network_settings_tabs')) {
    /**
     * @return array<string, array{label: string, icon: string, desc: string}>
     */
    function yooadmin_network_settings_tabs(?string $td = null): array
    {
        if ($td === null) {
            $td = yooadmin_network_settings_text_domain();
        }

        return [
            'general'  => [
                'label' => __('General', 'yooadmin'),
                'icon'  => 'dashicons-admin-settings',
                'desc'  => __('Network title, admin email, and registration rules.', 'yooadmin'),
            ],
            'sites'    => [
                'label' => __('Sites & Uploads', 'yooadmin'),
                'icon'  => 'dashicons-admin-multisite',
                'desc'  => __('New site defaults, uploads, language, and menus.', 'yooadmin'),
            ],
            'yooadmin' => [
                'label' => __('YOOAdmin', 'yooadmin'),
                'icon'  => 'dashicons-admin-customizer',
                'desc'  => __('Network defaults copied to new sites and applied from the site YOOAdmin tab.', 'yooadmin'),
            ],
        ];
    }
}

if (!function_exists('yooadmin_network_settings_current_tab')) {
    function yooadmin_network_settings_current_tab(): string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only tab routing.
        $tab  = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'general';
        $tabs = array_keys(yooadmin_network_settings_tabs());

        return in_array($tab, $tabs, true) ? $tab : 'general';
    }
}

if (!function_exists('yooadmin_network_settings_option_fields')) {
    /**
     * @return array<int, string>
     */
    function yooadmin_network_settings_option_fields(): array
    {
        return [
            'registrationnotification',
            'registration',
            'add_new_users',
            'menu_items',
            'upload_space_check_disabled',
            'blog_upload_space',
            'upload_filetypes',
            'site_name',
            'first_post',
            'first_page',
            'first_comment',
            'first_comment_url',
            'first_comment_author',
            'welcome_email',
            'welcome_user_email',
            'fileupload_maxk',
            'illegal_names',
            'limited_email_domains',
            'banned_email_domains',
            'WPLANG',
            'new_admin_email',
            'first_comment_email',
        ];
    }
}

if (!function_exists('yooadmin_network_settings_process_yooadmin_tab_save')) {
    function yooadmin_network_settings_process_yooadmin_tab_save(): bool
    {
        if (!current_user_can('manage_network')) {
            return false;
        }

        if (!function_exists('yooadmin_network_site_yooadmin_save_network_template')
            || !function_exists('yooadmin_network_site_yooadmin_save_default_form_values')
            || !function_exists('yooadmin_network_site_yooadmin_parse_provision_flags')) {
            return false;
        }

        yooadmin_network_site_yooadmin_save_network_template();
        yooadmin_network_site_yooadmin_save_default_form_values(
            yooadmin_network_site_yooadmin_parse_provision_flags(
                [
                    // phpcs:ignore WordPress.Security.NonceVerification.Missing
                    'copy_settings'     => !empty($_POST['yooadmin_default_copy_settings']),
                    // phpcs:ignore WordPress.Security.NonceVerification.Missing
                    'copy_theme_colors' => !empty($_POST['yooadmin_default_copy_theme_colors']),
                    // phpcs:ignore WordPress.Security.NonceVerification.Missing
                    'copy_login_logo'   => !empty($_POST['yooadmin_default_copy_login_logo']),
                    // phpcs:ignore WordPress.Security.NonceVerification.Missing
                    'copy_custom_login' => !empty($_POST['yooadmin_default_copy_custom_login']),
                    // phpcs:ignore WordPress.Security.NonceVerification.Missing
                    'show_admin_tour'   => !empty($_POST['yooadmin_default_show_admin_tour']),
                ]
            )
        );

        return true;
    }
}

if (!function_exists('yooadmin_network_settings_process_save')) {
    function yooadmin_network_settings_process_save(bool $verify_nonce = true): bool
    {
        if (!is_multisite() || !current_user_can('manage_network_options')) {
            return false;
        }

        if (empty($_POST['yooadmin_network_settings_save'])) {
            return false;
        }

        if ($verify_nonce) {
            check_admin_referer('yooadmin_network_settings');
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $tab = isset($_POST['yooadmin_network_settings_tab']) ? sanitize_key(wp_unslash((string) $_POST['yooadmin_network_settings_tab'])) : 'general';
        if ($tab === 'yooadmin') {
            return yooadmin_network_settings_process_yooadmin_tab_save();
        }

        /** This action is documented in wp-admin/network/edit.php */
        do_action('wpmuadminedit'); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.

        $checked_options = [
            'menu_items'                  => [],
            'registrationnotification'    => 'no',
            'upload_space_check_disabled' => 1,
            'add_new_users'               => 0,
        ];
        foreach ($checked_options as $option_name => $option_unchecked_value) {
            if (!isset($_POST[$option_name])) {
                $_POST[$option_name] = $option_unchecked_value;
            }
        }

        if (!empty($_POST['WPLANG']) && current_user_can('install_languages') && wp_can_install_language_pack()) {
            if (!function_exists('wp_download_language_pack')) {
                require_once ABSPATH . 'wp-admin/includes/translation-install.php';
            }
            $language = wp_download_language_pack(sanitize_text_field(wp_unslash((string) $_POST['WPLANG'])));
            if ($language) {
                $_POST['WPLANG'] = $language;
            }
        }

        foreach (yooadmin_network_settings_option_fields() as $option_name) {
            if (!isset($_POST[$option_name])) {
                continue;
            }
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Mirrors core network settings; stored via update_site_option().
            $value = wp_unslash($_POST[$option_name]);
            update_site_option($option_name, $value);
        }

        /** This action is documented in wp-admin/network/settings.php */
        do_action('update_wpmu_options'); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.

        return true;
    }
}

if (!function_exists('yooadmin_network_settings_handle_email_actions')) {
    function yooadmin_network_settings_handle_email_actions(): void
    {
        if (!is_multisite() || !is_network_admin() || !current_user_can('manage_network_options')) {
            return;
        }

        $base = yooadmin_network_settings_url();

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Email confirmation hash from email link.
        if (!empty($_GET['network_admin_hash'])) {
            $new_admin_details = get_site_option('network_admin_hash');
            $redirect          = add_query_arg('updated', 'false', $base);
            if (
                is_array($new_admin_details)
                && hash_equals((string) $new_admin_details['hash'], sanitize_text_field(wp_unslash((string) $_GET['network_admin_hash'])))
                && !empty($new_admin_details['newemail'])
            ) {
                update_site_option('admin_email', $new_admin_details['newemail']);
                delete_site_option('network_admin_hash');
                delete_site_option('new_admin_email');
                $redirect = add_query_arg('updated', 'true', $base);
            }
            wp_safe_redirect($redirect);
            exit;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Dismiss action from admin notice link.
        if (!empty($_GET['dismiss']) && 'new_network_admin_email' === sanitize_key(wp_unslash((string) $_GET['dismiss']))) {
            check_admin_referer('dismiss_new_network_admin_email');
            delete_site_option('network_admin_hash');
            delete_site_option('new_admin_email');
            wp_safe_redirect(add_query_arg('updated', 'true', $base));
            exit;
        }
    }
}

add_action('admin_init', 'yooadmin_network_settings_handle_email_actions', 1);

if (!function_exists('yooadmin_ajax_network_settings_save')) {
    function yooadmin_network_settings_text_domain(): string
    {
        return function_exists('yooadmin_multisite_text_domain')
            ? yooadmin_multisite_text_domain()
            : 'yooadmin';
    }

    function yooadmin_ajax_network_settings_save(): void
    {
        if (!is_multisite() || !current_user_can('manage_network_options')) {
            wp_send_json_error(
                [
                    'message' => __('Sorry, you are not allowed to access this page.', 'yooadmin'),
                ],
                403
            );
        }

        check_ajax_referer('yooadmin_network_settings');

        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $tab = isset($_POST['yooadmin_network_settings_tab']) ? sanitize_key(wp_unslash((string) $_POST['yooadmin_network_settings_tab'])) : 'general';

        if (!yooadmin_network_settings_process_save(false)) {
            wp_send_json_error(
                [
                    'message' => __('Settings could not be saved.', 'yooadmin'),
                ],
                400
            );
        }

        $message = $tab === 'yooadmin'
            ? __('Network YOOAdmin defaults saved.', 'yooadmin')
            : __('Settings saved.', 'yooadmin');

        wp_send_json_success(
            [
                'message' => $message,
            ]
        );
    }
}

add_action('wp_ajax_yooadmin_network_settings_save', 'yooadmin_ajax_network_settings_save');

add_action(
    'admin_init',
    static function (): void {
        if (!yooadmin_network_settings_is_screen() || wp_doing_ajax()) {
            return;
        }

        if (yooadmin_network_settings_process_save()) {
            // phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in yooadmin_network_settings_process_save().
            $tab = isset($_POST['yooadmin_network_settings_tab'])
                ? sanitize_key(wp_unslash((string) $_POST['yooadmin_network_settings_tab']))
                : yooadmin_network_settings_current_tab();
            // phpcs:enable WordPress.Security.NonceVerification.Missing
            if (!in_array($tab, array_keys(yooadmin_network_settings_tabs()), true)) {
                $tab = 'general';
            }
            wp_safe_redirect(add_query_arg(['updated' => 'true', 'tab' => $tab], yooadmin_network_settings_url()));
            exit;
        }
    },
    5
);
