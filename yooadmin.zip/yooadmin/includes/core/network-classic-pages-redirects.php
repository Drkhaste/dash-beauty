<?php
defined('ABSPATH') || exit;

/**
 * Network Setup + Upgrade redirects, submenu rewrites, and dashboard submenu fix.
 */

if (!function_exists('yooadmin_network_fix_dashboard_submenu')) {
    /**
     * Keep Dashboard flyout children under index.php after WP menu reparenting.
     */
    function yooadmin_network_fix_dashboard_submenu(): void
    {
        if (!is_multisite() || !is_network_admin()) {
            return;
        }
        if (!function_exists('yooadmin_network_dashboard_should_use') || !yooadmin_network_dashboard_should_use()) {
            return;
        }
        if (!function_exists('yooadmin_network_dashboard_slug')) {
            return;
        }

        global $submenu, $menu;

        $dash_slug = yooadmin_network_dashboard_slug();

        if (isset($submenu[ $dash_slug ]) && is_array($submenu[ $dash_slug ])) {
            if (!isset($submenu['index.php']) || !is_array($submenu['index.php'])) {
                $submenu['index.php'] = [];
            }
            foreach ($submenu[ $dash_slug ] as $item) {
                $submenu['index.php'][] = $item;
            }
            unset($submenu[ $dash_slug ]);
            $submenu['index.php'] = array_values($submenu['index.php']);
        }

        if (is_array($menu)) {
            foreach ($menu as $index => $item) {
                if (!is_array($item) || empty($item[2])) {
                    continue;
                }
                if ((string) $item[2] === $dash_slug) {
                    $menu[ $index ][2] = 'index.php';
                }
            }
        }

        if (function_exists('yooadmin_network_dashboard_is_screen') && yooadmin_network_dashboard_is_screen()) {
            global $parent_file, $submenu_file;
            $parent_file  = 'index.php';
            $submenu_file = $dash_slug;
        }
    }

    add_action('admin_init', 'yooadmin_network_fix_dashboard_submenu', 0);
}

if (!function_exists('yooadmin_network_setup_redirect_classic')) {
    function yooadmin_network_setup_redirect_classic(): void
    {
        if (!is_network_admin()) {
            return;
        }
        if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
            return;
        }
        if (!current_user_can('setup_network')) {
            return;
        }
        if (!function_exists('yooadmin_network_setup_should_use') || !yooadmin_network_setup_should_use()) {
            return;
        }

        wp_safe_redirect(yooadmin_network_setup_url());
        exit;
    }

    add_action('load-setup.php', 'yooadmin_network_setup_redirect_classic');
}

if (!function_exists('yooadmin_network_upgrade_redirect_classic')) {
    function yooadmin_network_upgrade_redirect_classic(): void
    {
        if (!is_network_admin()) {
            return;
        }
        if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
            return;
        }
        if (!current_user_can('upgrade_network')) {
            return;
        }
        if (!function_exists('yooadmin_network_upgrade_should_use') || !yooadmin_network_upgrade_should_use()) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $args = isset($_GET) && is_array($_GET) ? wp_unslash($_GET) : [];
        unset($args['yooadmin_no_redirect']);
        wp_safe_redirect(add_query_arg($args, yooadmin_network_upgrade_url()));
        exit;
    }

    add_action('load-upgrade.php', 'yooadmin_network_upgrade_redirect_classic');
}
