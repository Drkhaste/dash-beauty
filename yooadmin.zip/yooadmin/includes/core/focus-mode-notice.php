<?php
/**
 * YOOAdmin - Focus mode disabled notice
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Display popup when redirected from YOOAdmin plugins page after disabling Focus Mode
 * Also handle Settings link click when Focus Mode is disabled
 */
add_action('admin_enqueue_scripts', function($hook) {
    // Only on plugins.php
    if ($hook !== 'plugins.php') {
        return;
    }
    
    // Load scripts if:
    // 1. Focus disabled flag is present (after deactivation from YOOAdmin)
    // 2. OR Focus Mode is currently disabled (for Settings link)
    $focus_enabled = function_exists('yooadmin_is_focus_enabled') ? yooadmin_is_focus_enabled() : true;
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flag check, no state change.
    $show_popup = !empty($_GET['yooadmin_focus_disabled']);
    
    // Skip if Focus Mode is enabled and no popup flag
    if ($focus_enabled && !$show_popup) {
        return;
    }
    
    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $url = plugin_dir_url($base_file);
    $dir = plugin_dir_path($base_file);
    
    // Enqueue popup script
    $script_path = $dir . 'assets/js/admin/focus-mode-notice.js';
    if (file_exists($script_path)) {
        wp_enqueue_script(
            'yooadmin-focus-notice',
            $url . 'assets/js/admin/focus-mode-notice.js',
            ['jquery'],
            filemtime($script_path),
            true
        );
        
        // Get logo URL (custom or default) - same as header
        if (!function_exists('yooadmin_logo_url')) {
            require_once $dir . 'includes/helpers/template-functions.php';
        }
        $logo_url = function_exists('yooadmin_logo_url') ? yooadmin_logo_url() : $url . 'assets/images/logo.png';

        // Dark logo for the plugins row → Settings modal only (enable-focus modal), not the post-deactivation popup.
        $logo_dark_path = $dir . 'assets/images/logo-dark.png';
        $settings_modal_logo_url = $url . 'assets/images/logo-dark.png';
        if (!file_exists($logo_dark_path)) {
            $settings_modal_logo_url = $url . 'assets/images/logo.png';
        }
        
        wp_localize_script('yooadmin-focus-notice', 'yooadmFocusNotice', [
            'nonce' => wp_create_nonce('yooadmin_enable_focus'),
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'enableFocusUrl' => admin_url('admin.php?page=yooadmin-enable-focus'),
            'pluginUrl' => untrailingslashit($url),
            'logoUrl' => esc_url($logo_url),
            'settingsModalLogoUrl' => esc_url($settings_modal_logo_url),
            'i18n' => [
                'title' => __('Focus Mode Disabled', 'yooadmin'),
                'message' => __('Focus Mode has been turned off, and your dashboard is now back to the default WordPress interface.', 'yooadmin'),
                'info' => __('If you\'d like to remove all YOOAdmin data before deactivating the plugin, you can use Data Cleanup at any time.', 'yooadmin'),
                'option1' => __('You can now:', 'yooadmin'),
                'bullet1' => __('Review your plugins and data', 'yooadmin'),
                'bullet2' => __('Use Data Cleanup if you want to remove YOOAdmin data', 'yooadmin'),
                'bullet3' => __('Re-enable Focus Mode anytime to return to YOOAdmin interface', 'yooadmin'),
                'enableButton' => __('Re-enable YOOAdmin', 'yooadmin'),
                'continueButton' => __('Continue', 'yooadmin'),
                // Enable Focus modal (Settings link when Focus disabled)
                'enableFocusTitle' => __('Enable Focus Mode', 'yooadmin'),
                'enableFocusMessage' => __('Focus Mode is currently disabled.', 'yooadmin'),
                'enableFocusInfo' => __('To access YOOAdmin Settings and features, please enable Focus Mode first.', 'yooadmin'),
                'cancel' => __('Cancel', 'yooadmin'),
                'enableFocusButton' => __('Enable Focus Mode', 'yooadmin'),
                'enabling' => __('Enabling...', 'yooadmin'),
            ]
        ]);
    }
    
    // Enqueue styles
    $style_path = $dir . 'assets/css/admin/focus-mode-notice.css';
    if (file_exists($style_path)) {
        wp_enqueue_style(
            'yooadmin-focus-notice',
            $url . 'assets/css/admin/focus-mode-notice.css',
            [],
            filemtime($style_path)
        );
    }
});

/**
 * AJAX handler to re-enable Focus Mode
 */
add_action('wp_ajax_yooadmin_enable_focus_mode', function() {
    check_ajax_referer('yooadmin_enable_focus', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'yooadmin')]);
    }
    
    // Re-enable Focus Mode
    update_option('yooadmin_focus_policy', 'on');
    
    // Set cookie to on
    setcookie('yoo_focus', 'on', time() + YEAR_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true);
    
    wp_send_json_success([
        'message' => __('Focus Mode has been re-enabled.', 'yooadmin'),
        'redirect_url' => admin_url('admin.php?page=yooadmin-dashboard')
    ]);
});

