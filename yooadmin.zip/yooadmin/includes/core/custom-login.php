<?php
/**
 * YOOAdmin — Custom wp-login.php layout (split panel, branding).
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Bootstrap login-screen hooks. `login_enqueue_scripts` runs only on wp-login.php; `on_enqueue`
 * decides whether to attach markup (preview may apply when the option is off — admin iframe).
 */
function yooadmin_custom_login_bootstrap(): void {
    add_action('login_enqueue_scripts', 'yooadmin_custom_login_on_enqueue', 5);
}
add_action('plugins_loaded', 'yooadmin_custom_login_bootstrap', 30);

/**
 * Register late hooks and assets once we know we're on the login screen.
 */
function yooadmin_custom_login_on_enqueue(): void {
    if (!yooadmin_custom_login_is_enabled()) {
        return;
    }

    if (function_exists('yooadmin_custom_login_uses_standalone_page') && yooadmin_custom_login_uses_standalone_page()) {
        $allow_two_factor_wp_login = function_exists('yooadmin_standalone_login_is_two_factor_wp_login_request')
            && yooadmin_standalone_login_is_two_factor_wp_login_request();
        if (!$allow_two_factor_wp_login) {
            return;
        }
    }

    add_action('login_header', 'yooadmin_custom_login_render_open', 0);
    add_action('login_footer', 'yooadmin_custom_login_render_close', 1000);
    add_filter('login_body_class', 'yooadmin_custom_login_body_class', 99, 2);
    add_action('login_head', 'yooadmin_custom_login_print_inline_vars', 15);
    add_action('login_head', 'yooadmin_custom_login_print_color_mode_bootstrap_head', 5);
    add_filter('login_headerurl', 'yooadmin_custom_login_filter_header_url', 20, 2);
    add_filter('login_headertext', 'yooadmin_custom_login_filter_header_text', 20, 1);

    yooadmin_custom_login_enqueue_shared_assets();

    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
    if ($base_file === '') {
        return;
    }

    $base_url = plugin_dir_url($base_file);
    $base_dir = plugin_dir_path($base_file);
    $css_rel  = 'assets/css/login/yoo-custom-login.css';
    $css_abs  = $base_dir . $css_rel;
    if (!is_readable($css_abs)) {
        return;
    }

    wp_enqueue_style(
        'yooadmin-custom-login',
        $base_url . $css_rel,
        ['yooadmin-login-fonts', 'yooadmin-login-dark'],
        filemtime($css_abs)
    );

    $js_rel = 'assets/js/login/yoo-login-password-toggle.js';
    $js_abs = $base_dir . $js_rel;
    if (is_readable($js_abs)) {
        wp_enqueue_script(
            'yooadmin-login-password-toggle',
            $base_url . $js_rel,
            [],
            filemtime($js_abs),
            true
        );
        wp_localize_script(
            'yooadmin-login-password-toggle',
            'yooadminLoginPw',
            [
                'show' => __('Show password', 'yooadmin'),
                'hide' => __('Hide password', 'yooadmin'),
            ]
        );
    }
}

/**
 * True when wp-login / standalone is loaded in “settings preview” mode (admin iframe).
 * Lets the custom layout render even if “Login page experience” is off or Focus rules would block it.
 *
 * @return bool
 */
function yooadmin_custom_login_is_settings_preview_request(): bool {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Preview flag + nonce verified below; public login URL.
    $yoo_lp_flag = isset($_GET['yooadmin_lp']) ? sanitize_text_field(wp_unslash($_GET['yooadmin_lp'])) : '';
    if ($yoo_lp_flag !== '1') {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (!isset($_GET['yooadmin_lp_nonce'])) {
        return false;
    }

    $nonce = sanitize_text_field(wp_unslash($_GET['yooadmin_lp_nonce']));
    if (!wp_verify_nonce($nonce, 'yooadmin_login_preview')) {
        return false;
    }

    if (!is_user_logged_in() || !current_user_can('manage_options')) {
        return false;
    }

    return true;
}

/**
 * Focus gate for the login screen (logged-out context).
 *
 * Site-level only — per-user `yoo_focus` cookie does not affect the login screen.
 *
 * - policy off → custom login off (WordPress default login)
 * - policy on or auto → custom login for all visitors when login_page_enabled is on
 *
 * @return bool
 */
function yooadmin_custom_login_focus_gate(): bool {
    if (!function_exists('yooadmin_get_focus_policy')) {
        return false;
    }

    $policy = yooadmin_get_focus_policy();
    if (!in_array($policy, ['on', 'auto', 'off'], true)) {
        $policy = 'auto';
    }

    return $policy !== 'off';
}

/**
 * Whether the custom login UI should apply.
 *
 * @return bool
 */
function yooadmin_custom_login_is_enabled(): bool {
    // Admin “Open full preview” iframe must work even when Login page experience is off (same as Extended).
    if (yooadmin_custom_login_is_settings_preview_request()) {
        return (bool) apply_filters('yooadmin_custom_login_is_enabled', true);
    }

    if (!function_exists('yooadmin_has_feature') || !yooadmin_has_feature('login_customizer')) {
        return (bool) apply_filters('yooadmin_custom_login_is_enabled', false);
    }

    $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    if (empty($opts['login_page_enabled'])) {
        return (bool) apply_filters('yooadmin_custom_login_is_enabled', false);
    }

    return (bool) apply_filters('yooadmin_custom_login_is_enabled', yooadmin_custom_login_focus_gate());
}

/**
 * Bundled default logo for light login backgrounds (`assets/images/logo-dark.png`).
 *
 * Used when branding is selected and no custom login / branding logo URL is set.
 *
 * @return string
 */
function yooadmin_custom_login_default_light_logo_url(): string {
    if (!defined('YOOADMIN_PLUGIN_FILE')) {
        return '';
    }

    $url = plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/logo-dark.png';

    /**
     * Filter the default login logo URL used in light mode when no custom light logo is set.
     *
     * @param string $url Absolute URL to logo-dark.png.
     */
    return esc_url_raw((string) apply_filters('yooadmin_custom_login_default_light_logo_url', $url));
}

/**
 * Bundled default logo for dark login backgrounds (`assets/images/logo.png`).
 *
 * @return string
 */
function yooadmin_custom_login_default_dark_logo_url(): string {
    if (!defined('YOOADMIN_PLUGIN_FILE')) {
        return '';
    }

    $url = plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/logo.png';

    /**
     * Filter the default login logo URL used in dark mode when no dark logo is uploaded.
     *
     * @param string $url Absolute URL to logo.png.
     */
    return esc_url_raw((string) apply_filters('yooadmin_custom_login_default_dark_logo_url', $url));
}

/**
 * Fallback logo URL for the custom login screen only (bundled `logo-dark.png` after theme default).
 *
 * @return string Non-empty URL or ''.
 */
function yooadmin_custom_login_branding_fallback_url(): string {
    $theme_logo_default_url = '';
    if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
        $theme_manager = YOOAdmin_Admin_Theme_Manager::get_instance();
        if ($theme_manager && method_exists($theme_manager, 'get_active_theme')) {
            $active_theme = $theme_manager->get_active_theme();
            if (!empty($active_theme['branding']['default_logo_url'])) {
                $theme_logo_default_url = esc_url($active_theme['branding']['default_logo_url']);
            }
        }
    }
    if ($theme_logo_default_url !== '') {
        return esc_url_raw($theme_logo_default_url);
    }
    if (defined('YOOADMIN_PLUGIN_FILE')) {
        return esc_url_raw(plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/logo-dark.png');
    }

    return '';
}

/**
 * Maximum CSS width (px) for the login form logo (split + standalone).
 *
 * @return int
 */
function yooadmin_login_logo_max_w_cap(): int {
    return (int) apply_filters('yooadmin_login_logo_max_w_cap', 268);
}

/**
 * Branding logo for the login page (light or dark), separate from admin header defaults.
 *
 * Light default: logo-dark.png. Dark default: logo.png. A Branding-tab logo_url overrides both.
 *
 * @param string $mode `light` or `dark`.
 * @return array{url:string,max_w:int}
 */
function yooadmin_custom_login_resolve_branding_logo_for_mode(string $mode): array {
    $mode = $mode === 'dark' ? 'dark' : 'light';
    $cap  = yooadmin_login_logo_max_w_cap();
    $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    $defs = function_exists('yooadmin_default_options') ? yooadmin_default_options() : [];

    $url = '';
    if (!empty($opts['logo_url'])) {
        $url = esc_url_raw(trim((string) $opts['logo_url']));
    }

    if ($url === '') {
        $url = $mode === 'dark'
            ? yooadmin_custom_login_default_dark_logo_url()
            : yooadmin_custom_login_default_light_logo_url();
    }

    $w = 150;
    if (function_exists('yooadmin_logo_width')) {
        $w = (int) yooadmin_logo_width();
    } elseif (isset($opts['logo_w'])) {
        $w = (int) $opts['logo_w'];
    } else {
        $w = (int) ($defs['logo_w'] ?? 150);
    }

    return [
        'url'   => $url,
        'max_w' => max(20, min($cap, max(20, min(1000, $w)))),
    ];
}

/**
 * @return array{url:string,max_w:int}
 */
function yooadmin_custom_login_resolve_branding_logo(): array {
    return yooadmin_custom_login_resolve_branding_logo_for_mode('light');
}

/**
 * Resolved logo URL and max width for light login (branding vs custom).
 *
 * @return array{url:string,max_w:int}
 */
function yooadmin_custom_login_resolve_logo_light(): array {
    $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    $defs = function_exists('yooadmin_default_options') ? yooadmin_default_options() : [];
    $cap  = yooadmin_login_logo_max_w_cap();

    $source = isset($opts['login_page_logo_source']) ? (string) $opts['login_page_logo_source'] : 'branding';
    if (!in_array($source, ['branding', 'custom'], true)) {
        $source = 'branding';
    }

    $login_logo = isset($opts['login_page_logo_url']) ? trim((string) $opts['login_page_logo_url']) : '';
    $custom_w = isset($opts['login_page_logo_max_w']) ? (int) $opts['login_page_logo_max_w'] : (int) ($defs['login_page_logo_max_w'] ?? 220);
    $custom_w = max(80, min($cap, $custom_w));

    $apply_cap = static function (int $w) use ($cap): int {
        return max(20, min($cap, $w));
    };

    if ($source === 'custom') {
        if ($login_logo === '') {
            return [
                'url'   => '',
                'max_w' => $apply_cap($custom_w),
            ];
        }

        return [
            'url'   => esc_url_raw($login_logo),
            'max_w' => $apply_cap($custom_w),
        ];
    }

    return yooadmin_custom_login_resolve_branding_logo();
}

/**
 * Resolved logo URL and max width for the login form (branding vs custom).
 *
 * @param string|null $effective_color_mode Optional `light` or `dark` override.
 * @return array{url:string,max_w:int}
 */
function yooadmin_custom_login_resolve_logo(?string $effective_color_mode = null): array {
    $mode  = $effective_color_mode ?? yooadmin_custom_login_resolve_effective_color_mode();
    $light = yooadmin_custom_login_resolve_logo_light();

    if ($mode !== 'dark') {
        return $light;
    }

    $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    $defs = function_exists('yooadmin_default_options') ? yooadmin_default_options() : [];
    $cap  = yooadmin_login_logo_max_w_cap();

    $source = isset($opts['login_page_logo_source']) ? (string) $opts['login_page_logo_source'] : 'branding';
    if (!in_array($source, ['branding', 'custom'], true)) {
        $source = 'branding';
    }

    $login_dark = isset($opts['login_page_logo_dark_url']) ? trim((string) $opts['login_page_logo_dark_url']) : '';
    $login_logo = isset($opts['login_page_logo_url']) ? trim((string) $opts['login_page_logo_url']) : '';
    $custom_w   = isset($opts['login_page_logo_max_w']) ? (int) $opts['login_page_logo_max_w'] : (int) ($defs['login_page_logo_max_w'] ?? 220);
    $custom_w   = max(80, min($cap, $custom_w));

    $apply_cap = static function (int $w) use ($cap): int {
        return max(20, min($cap, $w));
    };

    if ($login_dark !== '') {
        return [
            'url'   => esc_url_raw($login_dark),
            'max_w' => $apply_cap($custom_w),
        ];
    }

    // Login-only logo: dark matches light unless a dedicated dark login logo is set above.
    if ($source === 'custom') {
        return $light;
    }

    return yooadmin_custom_login_resolve_branding_logo_for_mode('dark');
}

/**
 * Brand colors from Theme Settings ({@see YOOAdmin_Admin_Theme_Manager}) stored in `yooadmin_colors`.
 *
 * @return array<string, string>
 */
function yooadmin_custom_login_get_merged_theme_colors(): array {
    $defaults = [
        'primary'       => '#eda934',
        'border'        => '#e0e0e0',
        'header_bg'     => '#4B4B4B',
        'sidebar_bg'    => '#4B4B4B',
        'text_contrast' => '#FFFFFF',
        'text_600'      => '#5d5d5d',
        'text_500'      => '#555555',
        'card_icon'     => '#eda934',
    ];
    $stored = get_option('yooadmin_colors', []);
    if (!is_array($stored)) {
        $stored = [];
    }

    return array_merge($defaults, array_intersect_key($stored, $defaults));
}

/**
 * Locale used on the login screen (logged-out safe).
 */
function yooadmin_custom_login_get_login_locale(): string {
    if (function_exists('yooadmin_login_toolbar_resolve_visitor_locale')) {
        $resolved = yooadmin_login_toolbar_resolve_visitor_locale();
        if ($resolved !== null) {
            return $resolved;
        }
    }

    if (function_exists('determine_locale')) {
        return (string) determine_locale();
    }

    return (string) get_locale();
}

/**
 * @return bool
 */
function yooadmin_custom_login_is_arabic_locale(): bool {
    return strpos(yooadmin_custom_login_get_login_locale(), 'ar') === 0;
}

/**
 * Stored login appearance mode (falls back to Studio Hub site color_mode).
 *
 * @return string light|dark|auto
 */
function yooadmin_custom_login_get_color_mode(): string {
    $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    $mode = isset($opts['login_page_appearance_mode']) ? sanitize_key((string) $opts['login_page_appearance_mode']) : '';
    if (in_array($mode, ['light', 'dark', 'auto'], true)) {
        return $mode;
    }

    $opt = get_option('yooadmin_admin_theme_settings_yooadmin-studio-hub', []);
    if (is_array($opt)) {
        $theme_mode = isset($opt['color_mode']) ? sanitize_key((string) $opt['color_mode']) : 'auto';
        if (in_array($theme_mode, ['light', 'dark', 'auto'], true)) {
            return $theme_mode;
        }
    }

    return 'auto';
}

/**
 * Resolve auto to light|dark for inline CSS vars (preview may override via query arg).
 *
 * @return string light|dark
 */
function yooadmin_custom_login_resolve_effective_color_mode(): string {
    if (yooadmin_custom_login_is_settings_preview_request()) {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified in preview gate.
        $preview = isset($_GET['yooadmin_lp_effective']) ? sanitize_key(wp_unslash((string) $_GET['yooadmin_lp_effective'])) : '';
        if (in_array($preview, ['light', 'dark'], true)) {
            return $preview;
        }
    }

    $mode = yooadmin_custom_login_get_color_mode();
    if ($mode === 'dark') {
        return 'dark';
    }
    if ($mode === 'light') {
        return 'light';
    }

    return 'light';
}

/**
 * Plugin-relative login asset URL.
 */
function yooadmin_custom_login_asset_url(string $relative): string {
    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
    if ($base_file === '') {
        return '';
    }

    return plugins_url(ltrim($relative, '/'), $base_file);
}

/**
 * Print enqueued font + dark-mode stylesheets and anti-flash bootstrap for login templates.
 */
function yooadmin_custom_login_print_head_assets(): void {
    if (!function_exists('wp_styles')) {
        require_once ABSPATH . WPINC . '/script-loader.php';
    }

    if (function_exists('yooadmin_print_admin_favicon_links')) {
        yooadmin_print_admin_favicon_links();
    }

    yooadmin_custom_login_enqueue_shared_assets();

    wp_print_styles(
        [
            'yooadmin-montserrat',
            'yooadmin-tajawal',
            'yooadmin-login-fonts',
            'yooadmin-login-dark',
        ]
    );

    $mode = yooadmin_custom_login_get_color_mode();
    printf(
        '<script id="yooadmin-login-color-mode">(function(){var m=%1$s;var eff="light";if(m==="dark"){eff="dark";}else if(m==="auto"){try{eff=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(e){eff="light";}}document.documentElement.setAttribute("data-yoo-login-color-mode",m);document.documentElement.setAttribute("data-yoo-login-color-mode-effective",eff);})();</script>' . "\n",
        wp_json_encode($mode)
    );
}

/**
 * Fonts and dark login tokens for maintenance / public 404 (always dark).
 */
function yooadmin_public_branded_page_print_head_assets(): void {
    if (!function_exists('wp_styles')) {
        require_once ABSPATH . WPINC . '/script-loader.php';
    }

    if (function_exists('yooadmin_print_admin_favicon_links')) {
        yooadmin_print_admin_favicon_links();
    }

    yooadmin_custom_login_enqueue_shared_assets();

    wp_print_styles(
        [
            'yooadmin-montserrat',
            'yooadmin-tajawal',
            'yooadmin-login-fonts',
            'yooadmin-login-dark',
        ]
    );
}

/**
 * Enqueue shared login assets on wp-login.php.
 */
function yooadmin_custom_login_enqueue_shared_assets(): void {
    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
    if ($base_file === '') {
        return;
    }

    $base_url = plugin_dir_url($base_file);
    $base_dir = plugin_dir_path($base_file);

    $montserrat = $base_dir . 'assets/fonts/montserrat.css';
    if (is_readable($montserrat)) {
        wp_enqueue_style('yooadmin-montserrat', $base_url . 'assets/fonts/montserrat.css', [], (string) filemtime($montserrat));
    }
    $tajawal = $base_dir . 'assets/fonts/tajawal.css';
    if (is_readable($tajawal)) {
        wp_enqueue_style('yooadmin-tajawal', $base_url . 'assets/fonts/tajawal.css', [], (string) filemtime($tajawal));
    }

    $fonts_rel = 'assets/css/login/yoo-login-fonts.css';
    $fonts_abs = $base_dir . $fonts_rel;
    if (is_readable($fonts_abs)) {
        wp_enqueue_style('yooadmin-login-fonts', $base_url . $fonts_rel, ['yooadmin-montserrat', 'yooadmin-tajawal'], (string) filemtime($fonts_abs));
    }

    $dark_rel = 'assets/css/login/yoo-login-dark.css';
    $dark_abs = $base_dir . $dark_rel;
    if (is_readable($dark_abs)) {
        wp_enqueue_style('yooadmin-login-dark', $base_url . $dark_rel, ['yooadmin-login-fonts'], (string) filemtime($dark_abs));
    }

    if (function_exists('yooadmin_build_latin_font_variable_css')) {
        wp_add_inline_style('yooadmin-login-fonts', yooadmin_build_latin_font_variable_css());
    }
}

/**
 * Anti-flash color mode bootstrap on wp-login.php.
 */
function yooadmin_custom_login_print_color_mode_bootstrap_head(): void {
    if (!yooadmin_custom_login_is_enabled()) {
        return;
    }

    $mode = yooadmin_custom_login_get_color_mode();
    printf(
        '<script id="yooadmin-login-color-mode">(function(){var m=%1$s;var eff="light";if(m==="dark"){eff="dark";}else if(m==="auto"){try{eff=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(e){eff="light";}}document.documentElement.setAttribute("data-yoo-login-color-mode",m);document.documentElement.setAttribute("data-yoo-login-color-mode-effective",eff);})();</script>' . "\n",
        wp_json_encode($mode)
    );
}

/**
 * Brand tokens for YOO buttons on login (yp-yoo-btn--primary reads these, not --yoo-login-* alone).
 *
 * @param array<string, string> $t Merged theme colors.
 * @return array<string, string>
 */
function yooadmin_custom_login_get_brand_css_vars(array $t): array {
    $primary = isset($t['primary']) ? sanitize_hex_color((string) $t['primary']) : '';
    if (!$primary) {
        $primary = '#eda934';
    }

    return [
        '--yooadmin-primary'      => $primary,
        '--yooadmin-brand-source' => $primary,
        '--yp-yoo-btn-primary'    => $primary,
    ];
}

/**
 * CSS variables for login templates (standalone + wp-login split). Colors follow Theme Settings.
 *
 * @param string|null $effective_color_mode Optional light|dark override for saved/preview vars.
 * @return array<string, string>
 */
function yooadmin_custom_login_get_style_vars(?string $effective_color_mode = null): array {
    $t = yooadmin_custom_login_get_merged_theme_colors();
    $brand = yooadmin_custom_login_get_brand_css_vars($t);
    $effective = $effective_color_mode ?? yooadmin_custom_login_resolve_effective_color_mode();
    $is_dark   = ($effective === 'dark');

    if ($is_dark) {
        return array_merge(
            [
                '--yoo-login-panel-bg'            => '#121418',
                '--yoo-login-media-bg'              => $t['sidebar_bg'],
                '--yoo-login-placeholder-color'     => '#9aa5b1',
                '--yoo-login-text'                  => '#d7dde7',
                '--yoo-login-input-bg'              => '#1a1d23',
                '--yoo-login-input-border'          => 'rgba(255, 255, 255, 0.14)',
                '--yoo-login-link'                  => $t['primary'],
                '--yoo-login-button-bg'             => $t['primary'],
                '--yoo-login-button-text'           => $t['text_contrast'],
                '--yoo-login-primary'               => $t['primary'],
                '--yoo-login-footer-text'           => '#9aa5b1',
                '--yoo-login-card-shadow'           => '0 8px 32px rgba(0, 0, 0, 0.35)',
            ],
            $brand
        );
    }

    return array_merge(
        [
            '--yoo-login-panel-bg'            => '#ffffff',
            '--yoo-login-media-bg'              => $t['sidebar_bg'],
            '--yoo-login-placeholder-color'     => $t['text_500'],
            '--yoo-login-text'                  => $t['text_600'],
            '--yoo-login-input-bg'              => '#f8fafc',
            '--yoo-login-input-border'          => $t['border'],
            '--yoo-login-link'                  => $t['primary'],
            '--yoo-login-button-bg'             => $t['primary'],
            '--yoo-login-button-text'           => $t['text_contrast'],
            '--yoo-login-primary'               => $t['primary'],
            '--yoo-login-footer-text'           => '#64748b',
            '--yoo-login-card-shadow'           => '0 4px 24px rgba(15, 23, 42, 0.08)',
        ],
        $brand
    );
}

/**
 * Build inline CSS (variables) for a given body selector.
 *
 * @param string $body_selector e.g. `body.yooadmin-login-custom`.
 * @param string $style_id      HTML id for the style tag.
 * @return string Full `<style>...</style>` markup or empty.
 */
function yooadmin_custom_login_build_inline_vars_style(string $body_selector, string $style_id): string {
    $is_standalone = ($body_selector === 'body.yooadmin-login-standalone');
    if (!$is_standalone && !yooadmin_custom_login_is_enabled()) {
        return '';
    }

    $vars = yooadmin_custom_login_get_style_vars();

    $effective_mode = yooadmin_custom_login_resolve_effective_color_mode();
    $resolved       = yooadmin_custom_login_resolve_logo($effective_mode);
    $resolved_light = yooadmin_custom_login_resolve_logo('light');
    $resolved_dark  = yooadmin_custom_login_resolve_logo('dark');
    $resolved_logo  = $resolved['url'];
    $logo_w         = $resolved['max_w'];

    if ($resolved_logo !== '') {
        $vars['--yoo-login-logo-url'] = 'url(\'' . esc_url($resolved_logo, ['http', 'https']) . '\')';
    } else {
        $vars['--yoo-login-logo-url'] = 'none';
    }

    if ($resolved_light['url'] !== '') {
        $vars['--yoo-login-logo-url-light'] = 'url(\'' . esc_url($resolved_light['url'], ['http', 'https']) . '\')';
    } else {
        $vars['--yoo-login-logo-url-light'] = 'none';
    }

    if ($resolved_dark['url'] !== '') {
        $vars['--yoo-login-logo-url-dark'] = 'url(\'' . esc_url($resolved_dark['url'], ['http', 'https']) . '\')';
    } else {
        $vars['--yoo-login-logo-url-dark'] = 'none';
    }

    $vars['--yoo-login-logo-max-w'] = $logo_w . 'px';

    if ($body_selector === 'body.yooadmin-login-standalone' && defined('YOOADMIN_DIR') && defined('YOOADMIN_PLUGIN_FILE')) {
        $welcome_bg_fs = YOOADMIN_DIR . 'assets/images/login-background.jpg';
        if (is_readable($welcome_bg_fs)) {
            $welcome_url = plugins_url('assets/images/login-background.jpg', YOOADMIN_PLUGIN_FILE);
            $vars['--yoo-sl-welcome-bg-image'] = 'url(\'' . esc_url($welcome_url, ['http', 'https']) . '\')';
        } else {
            $vars['--yoo-sl-welcome-bg-image'] = 'none';
        }
    }

    $css = $body_selector . '{';
    foreach ($vars as $k => $v) {
        if ($k === '--yoo-login-logo-url' || $k === '--yoo-login-logo-url-light' || $k === '--yoo-login-logo-url-dark' || $k === '--yoo-sl-welcome-bg-image') {
            $css .= $k . ':' . $v . ';';
            continue;
        }
        $css .= $k . ':' . esc_html((string) $v) . ';';
    }
    $css .= '}';

    return '<style id="' . esc_attr($style_id) . '">' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS built from sanitized hex vars + strip_tags custom block.
}

function yooadmin_custom_login_print_inline_vars(): void {
    echo yooadmin_custom_login_build_inline_vars_style('body.yooadmin-login-custom', 'yooadmin-custom-login-vars'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function yooadmin_custom_login_print_standalone_inline_vars(): void {
    echo yooadmin_custom_login_build_inline_vars_style('body.yooadmin-login-standalone', 'yooadmin-standalone-login-vars'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * @param string[] $classes
 * @param string   $action_login
 * @return string[]
 */
function yooadmin_custom_login_body_class(array $classes, string $action_login): array {
    if (!yooadmin_custom_login_is_enabled()) {
        return $classes;
    }
    $classes[] = 'yooadmin-login-custom';

    $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    $side = isset($opts['login_page_image_side']) ? (string) $opts['login_page_image_side'] : 'left';
    if ($side === 'right') {
        $classes[] = 'yoo-login--media-right';
    } else {
        $classes[] = 'yoo-login--media-left';
    }

    $resolved = yooadmin_custom_login_resolve_logo_light();
    if ($resolved['url'] === '') {
        $classes[] = 'yoo-login--no-logo';
    }

    if (function_exists('yooadmin_custom_login_is_arabic_locale') && yooadmin_custom_login_is_arabic_locale()) {
        $classes[] = 'yoo-login--ar';
    }

    return $classes;
}

function yooadmin_custom_login_render_open(): void {
    if (!yooadmin_custom_login_is_enabled()) {
        return;
    }

    $opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];
    $img_raw = isset($opts['login_page_image_url']) ? (string) $opts['login_page_image_url'] : '';
    $img_url = $img_raw !== '' ? esc_url($img_raw) : '';
    $has_image = $img_url !== '';

    echo '<div class="yoo-login-wrap">';
    echo '<div class="yoo-login-media' . ($has_image ? ' yoo-login-media--has-image' : ' yoo-login-media--no-image') . '" role="presentation">';

    if ($has_image) {
        echo '<div class="yoo-login-media__img-wrap"><img class="yoo-login-media__img" src="' . esc_url($img_url) . '" alt="" /></div>';
    }

    yooadmin_custom_login_render_split_welcome($has_image);

    echo '</div>';
    echo '<div class="yoo-login-panel">';
}

function yooadmin_custom_login_render_split_welcome(bool $over_image): void {
    $site_name = get_bloginfo('name', 'display');
    $text = (string) apply_filters(
        'yooadmin_login_media_welcome_text',
        sprintf(
            /* translators: %s: site title */
            __('Welcome back. Sign in to %s to continue.', 'yooadmin'),
            $site_name !== '' ? $site_name : __('this site', 'yooadmin')
        )
    );

    $cls = 'yoo-login-welcome' . ($over_image ? ' yoo-login-welcome--over-image' : '');

    echo '<div class="' . esc_attr($cls) . '">';
    echo '<div class="yoo-login-welcome__glass">';
    echo '<p class="yoo-login-welcome__text">' . esc_html($text) . '</p>';
    echo '</div></div>';
}

function yooadmin_custom_login_render_close(): void {
    if (!yooadmin_custom_login_is_enabled()) {
        return;
    }
    echo '</div></div>';
}

/**
 * Login logo link: front door of this site (matches branded admin), not wordpress.org.
 *
 * @param mixed $login_header_url Passed by core.
 */
function yooadmin_custom_login_filter_header_url($login_header_url, $action = '')
{
    return home_url('/');
}

/**
 * Visible / accessible title for the login logo area — site name, not core default marketing text.
 *
 * @param mixed $login_header_text Passed by core.
 */
function yooadmin_custom_login_filter_header_text($login_header_text)
{
    $name = get_bloginfo('name', 'display');

    return $name !== '' ? $name : (string) $login_header_text;
}
