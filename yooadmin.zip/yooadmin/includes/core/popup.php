<?php
/**
 * YOOAdmin - Popup menus data & localization (data-only)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Resolve a menu tree label in the current admin UI locale (popup / cards).
 *
 * @param string $slug  Menu slug or external URL used as slug.
 * @param string $title Fallback title from the global $menu / $submenu.
 */
if (!function_exists('yooadmin_resolve_menu_tree_item_title')) {
    function yooadmin_resolve_menu_tree_item_title(string $slug, string $title = ''): string {
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $slug = trim($slug);
        $map  = [
            'yooadmin-dashboard'         => __('Dashboard', 'yooadmin'),
            'yooadmin-themes'            => __('Themes', 'yooadmin'),
            'yooadmin-settings'          => __('Settings', 'yooadmin'),
            'yooadmin-license'           => __('Connect Account', 'yooadmin'),
            'yooadmin-activity'          => __('Activity', 'yooadmin'),
            'yooadmin-enable-focus'      => __('Focus Mode', 'yooadmin'),
            'yooadmin-users'             => __('Users', 'yooadmin'),
            'yooadmin-posts'             => __('Posts', 'yooadmin'),
            'yooadmin-comments'          => __('Comments', 'yooadmin'),
            'yooadmin-pages'             => __('Pages', 'yooadmin'),
            'yooadmin-plugins'           => __('Plugins', 'yooadmin'),
            'yooadmin-extensions'        => __('Extensions', 'yooadmin'),
        ];

        if ($slug !== '' && isset($map[ $slug ])) {
            return $map[ $slug ];
        }

        $page = '';
        if ($slug !== '' && strpos($slug, '.php') === false && strpos($slug, '://') === false) {
            $page = $slug;
        } elseif ($slug !== '' && strpos($slug, 'page=') !== false) {
            $query = [];
            parse_str((string) wp_parse_url($slug, PHP_URL_QUERY), $query);
            $page = isset($query['page']) ? (string) $query['page'] : '';
        }

        if ($page !== '' && isset($map[ $page ])) {
            return $map[ $page ];
        }

        return $title;
    }
}

/**
 * Split a WordPress submenu title (may contain HTML for counts) into a clean label and badge.
 * wp_strip_all_tags() alone turns "Updates <span…>0</span>" into "Updates 0"; we remove the orphan count
 * and only expose a badge when the count is &gt; 0 (matches native admin behavior).
 *
 * @return array{0:string,1:string,2:string} [title, badge_digits_or_empty, badge_kind: updates|comments|'']
 */
if (!function_exists('yooadmin_submenu_title_and_badge')) {
    function yooadmin_submenu_title_and_badge(string $html): array {
        $html = (string) $html;
        $badge  = '';
        $kind   = '';

        $has_updates_markup  = (bool) preg_match('/update-plugins|class\s*=\s*["\'][^"\']*update-plugins/i', $html);
        $has_comments_markup = (bool) preg_match('/awaiting-mod|pending-count/i', $html);

        if ($has_updates_markup) {
            $kind = 'updates';
            if (preg_match('/<[^>]*(?:update-count|plugin-count|\bcount\b)[^>]*>\s*([\d,\s\x{00A0}]+)\s*</iu', $html, $m)) {
                $badge = preg_replace('/[^\d]/', '', $m[1]);
            }
        } elseif ($has_comments_markup) {
            $kind = 'comments';
            if (preg_match('/<span[^>]*pending-count[^>]*>\s*([\d,\s]+)\s*</i', $html, $m)) {
                $badge = preg_replace('/[^\d]/', '', $m[1]);
            }
        }

        $plain = wp_strip_all_tags($html);
        $plain = html_entity_decode($plain, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain = trim($plain);

        if ($kind !== '') {
            $plain = trim((string) preg_replace('/\s+[\d,\s]+\s*$/u', '', $plain));
        }

        // Count is 0 → $kind cleared below, but strip_tags still left "0 … moderation" on the label.
        if ($has_comments_markup) {
            $plain = trim((string) preg_replace('/\s+[\d,\s]+\s*(?:comments?\s+)?in\s+moderation.*$/iu', '', $plain));
            $plain = trim((string) preg_replace('/\s+[\d,\s]+\s*$/u', '', $plain));
        }
        if ($has_updates_markup) {
            $plain = trim((string) preg_replace('/\s+[\d,\s]+\s*$/u', '', $plain));
        }

        if ($badge === '0') {
            $badge = '';
        }

        $kind = ($badge !== '') ? $kind : '';

        return [$plain, $badge, $kind];
    }
}

/**
 * WordPress puts update/comment counts on the parent menu item, not submenu rows.
 * Copy the parent badge onto the submenu entry that opens the related screen.
 *
 * @param array<int, array<string, mixed>> $subs
 * @return array<int, array<string, mixed>>
 */
if (!function_exists('yooadmin_propagate_parent_badge_to_submenus')) {
    function yooadmin_propagate_parent_badge_to_submenus(string $parent_slug, string $parent_badge, string $parent_kind, array $subs): array {
        if ($parent_badge === '' || empty($subs)) {
            return $subs;
        }

        $slug_l = strtolower($parent_slug);
        $targets = [];

        if ($parent_kind === 'comments' || strpos($slug_l, 'edit-comments') !== false) {
            $targets[] = 'edit-comments.php';
        }

        if ($parent_kind === 'updates' || $parent_slug === 'plugins.php' || strpos($slug_l, 'plugins.php') !== false) {
            $targets[] = 'plugins.php';
        }

        if ($parent_kind === 'updates' || $parent_slug === 'themes.php' || strpos($slug_l, 'themes.php') !== false) {
            $targets[] = 'themes.php';
        }

        if ($parent_slug === 'index.php' || strpos($slug_l, 'update-core') !== false) {
            $targets[] = 'update-core.php';
        }

        if (empty($targets)) {
            return $subs;
        }

        foreach ($subs as $idx => $sub) {
            if (!is_array($sub) || ($sub['badge'] ?? '') !== '') {
                continue;
            }

            $sslug = strtolower((string) ($sub['slug'] ?? ''));
            $surl  = strtolower((string) ($sub['url'] ?? ''));

            foreach ($targets as $target) {
                $target_l = strtolower($target);
                if ($sslug === $target_l || strpos($surl, $target_l) !== false) {
                    $subs[$idx]['badge'] = $parent_badge;
                    if ($parent_kind !== '') {
                        $subs[$idx]['badge_kind'] = $parent_kind;
                    }
                    break;
                }
            }
        }

        return $subs;
    }
}

/**
 * Remove trailing count / notification text left after strip_tags on admin menu labels
 * (Yoast "0 notifications", duplicate digits, etc.).
 */
if (!function_exists('yooadmin_clean_menu_label_noise')) {
    function yooadmin_clean_menu_label_noise(string $plain): string {
        $plain = trim(html_entity_decode((string) $plain, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        // Plugin counters exposed as plain text after tag strip
        $plain = preg_replace('/\s+[\d,\s]+\s+notifications?\s*$/iu', '', $plain);
        $plain = preg_replace('/\s+notifications?\s*$/iu', '', $plain);
        $plain = preg_replace('/\s+[\d,\s]+\s*(?:comments?\s+)?in\s+moderation.*$/iu', '', $plain);
        // "Comments 0 0 Comments …" (pending count + screen-reader / i18n tail)
        $plain = preg_replace('/\s+[\d,\s]+\s+comments?\s.*$/iu', '', $plain);
        $plain = preg_replace('/\s+[\d,\s]+\s*$/u', '', $plain);
        $plain = trim((string) preg_replace('/\s+/u', ' ', $plain));

        return $plain;
    }
}

/**
 * Default denylist for admin submenu `page` slugs that should not appear in YOOAdmin mirrors
 * (broken routes, placeholder parents, etc.). Extend via filter `yooadmin_excluded_admin_submenu_pages`.
 *
 * @return string[]
 */
if (!function_exists('yooadmin_get_excluded_submenu_pages')) {
    function yooadmin_get_excluded_submenu_pages(): array {
        $default = [
            'elementor-system',
        ];
        return apply_filters('yooadmin_excluded_admin_submenu_pages', $default);
    }
}

/**
 * Whether a submenu row should be included in the card/sidebar tree (has a safe, navigable target).
 */
if (!function_exists('yooadmin_submenu_item_is_included')) {
    function yooadmin_submenu_item_is_included(string $sslug, string $surl): bool {
        $sslug = trim($sslug);
        if ($sslug === '' || $sslug === '#') {
            return false;
        }
        if (preg_match('/^separator\d*$/i', $sslug) || stripos($sslug, 'separator') === 0) {
            return false;
        }

        $surl = trim($surl);
        if ($surl === '' || $surl === '#') {
            return false;
        }
        if (stripos($surl, 'javascript:') === 0) {
            return false;
        }

        $page = '';
        if (preg_match('/[?&]page=([^&]+)/i', $surl, $m)) {
            $page = rawurldecode($m[1]);
        }
        if ($page === '' && strpos($sslug, '.php') === false && stripos($sslug, 'http') !== 0) {
            $page = $sslug;
        }

        $deny = yooadmin_get_excluded_submenu_pages();
        if ($page !== '' && is_array($deny)) {
            $pl = strtolower($page);
            foreach ($deny as $bad) {
                if ((string) $bad !== '' && strtolower((string) $bad) === $pl) {
                    return false;
                }
            }
        }

        return true;
    }
}

/* ----------------------------------------------------------------------------
 * Build admin menu tree (data-only)
 * ---------------------------------------------------------------------------- */
if (!function_exists('yooadmin_build_admin_menu_tree')) {
    /**
     * Build a tree of top-level menus and their submenus the current user can access.
     *
     * @return array<int, array{
     *   title:string, slug:string, url:string, icon:string, has_sub:bool,
     *   subs: array<int, array{title:string,url:string,icon:string,badge?:string,badge_kind?:string}>
     * }>
     */
    function yooadmin_build_admin_menu_tree(): array {
        if (!is_admin()) {
            return [];
        }

        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        global $menu, $submenu;

        if (!isset($menu) || !is_array($menu) || empty($menu)) return [];

        $out = [];
        foreach ($menu as $m) {
            $raw_title = isset($m[0]) ? (string) $m[0] : '';
            list($title, $parent_badge, $parent_kind) = yooadmin_submenu_title_and_badge($raw_title);
            $title = yooadmin_clean_menu_label_noise($title);
            $cap   = isset($m[1]) ? $m[1] : '';
            $slug  = isset($m[2]) ? (string) $m[2] : '';
            $title = yooadmin_resolve_menu_tree_item_title($slug, $title);
            $icon  = isset($m[6]) ? $m[6] : '';

            if ($title === '' || $slug === '') continue;
            if ($cap && !current_user_can($cap)) continue;

            if (function_exists('yooadmin_admin_menu_url')) {
                $url = yooadmin_admin_menu_url((string) $slug);
            } elseif (function_exists('yooadmin_resolve_admin_menu_slug_to_url')) {
                $url = yooadmin_resolve_admin_menu_slug_to_url((string) $slug, 'admin_url');
            } elseif (strpos((string) $slug, 'http://') === 0 || strpos((string) $slug, 'https://') === 0) {
                $url = $slug;
            } elseif (strpos((string) $slug, '/') !== false) {
                $url = admin_url('admin.php?page=' . $slug);
            } elseif (strpos((string) $slug, '.php') !== false) {
                $url = admin_url($slug);
            } else {
                $url = admin_url('admin.php?page=' . $slug);
            }

            $subs = [];
            if (isset($submenu, $submenu[$slug]) && is_array($submenu[$slug])) {
                $sorted_subs = $submenu[$slug];
                ksort($sorted_subs);
                foreach ($sorted_subs as $sm) {
                    $raw_sub_title = isset($sm[0]) ? (string) $sm[0] : '';
                    $scap          = isset($sm[1]) ? $sm[1] : '';
                    $sslug         = isset($sm[2]) ? $sm[2] : '';
                    if ($raw_sub_title === '' || $sslug === '') {
                        continue;
                    }
                    if ($scap && !current_user_can($scap)) {
                        continue;
                    }

                    list($stitle, $sbadge, $skind) = yooadmin_submenu_title_and_badge($raw_sub_title);
                    if ($stitle === '') {
                        continue;
                    }
                    $stitle = yooadmin_resolve_menu_tree_item_title((string) $sslug, $stitle);

                    if (function_exists('yooadmin_admin_menu_url')) {
                        $surl = yooadmin_admin_menu_url((string) $sslug);
                    } elseif (function_exists('yooadmin_resolve_admin_menu_slug_to_url')) {
                        $surl = yooadmin_resolve_admin_menu_slug_to_url((string) $sslug, 'admin_url');
                    } elseif (strpos((string) $sslug, 'http://') === 0 || strpos((string) $sslug, 'https://') === 0) {
                        $surl = $sslug;
                    } elseif (strpos((string) $sslug, '/') !== false) {
                        $surl = admin_url('admin.php?page=' . $sslug);
                    } elseif (strpos((string) $sslug, '.php') !== false) {
                        $surl = admin_url($sslug);
                    } else {
                        $surl = admin_url('admin.php?page=' . $sslug);
                    }

                    if (function_exists('yooadmin_user_can_access_admin_href') && !yooadmin_user_can_access_admin_href($surl)) {
                        continue;
                    }

                    $sub_item = [
                        'title'      => $stitle,
                        'url'        => $surl,
                        'slug'       => $sslug,
                        'icon'       => '',
                        'badge'      => $sbadge,
                        'badge_kind' => $skind,
                    ];

                    if (! yooadmin_submenu_item_is_included((string) $sslug, (string) $surl)) {
                        continue;
                    }

                    // Apply filter to allow custom icons
                    $sub_item = apply_filters('yooadmin_menu_tree_item', $sub_item);

                    $subs[] = $sub_item;
                }
            }

            if (!empty($subs)) {
                $subs = yooadmin_propagate_parent_badge_to_submenus(
                    (string) $slug,
                    (string) $parent_badge,
                    (string) $parent_kind,
                    $subs
                );
            }

            // Icon override: ensure Pages uses admin-page, not admin-users
            $slug_normalized = strtolower((string) $slug);
            if (strpos($slug_normalized, 'post_type=page') !== false || $slug === 'yooadmin-pages') {
                $icon = 'dashicons-admin-page';
            } elseif ($slug === 'yooadmin-users' || strpos($slug_normalized, 'users.php') !== false) {
                $icon = 'dashicons-groups';
            }

            $out[] = [
                'title'      => $title,
                'slug'       => $slug,
                'url'        => $url,
                'icon'       => (is_string($icon) && (strpos($icon, 'dashicons-') === 0 || strpos($icon, 'http') === 0 || strpos($icon, 'data:') === 0))
                                ? $icon
                                : 'dashicons-admin-generic',
                'has_sub'    => !empty($subs),
                'subs'       => $subs,
                'badge'      => $parent_badge,
                'badge_kind' => $parent_kind,
            ];
        }

        $out = yooadmin_merge_duplicate_top_level_menus_by_title_family($out);
        $out = yooadmin_merge_post_type_listing_into_prefixed_hub($out);

        return apply_filters('yooadmin_admin_menu_tree', $out);
    }
}

if (!function_exists('yooadmin_normalize_menu_title_key')) {
    /**
     * Normalize visible menu title for grouping (aligned with yp-menus.js normalizeTitleKey intent).
     */
    function yooadmin_normalize_menu_title_key(string $raw): string {
        $t = wp_strip_all_tags($raw);
        $t = preg_replace('/\s*\(\s*\d+\s*\)\s*$/u', '', $t);
        $t = preg_replace('/\s+\d+\s*$/u', '', $t);
        return strtolower(trim($t));
    }
}

if (!function_exists('yooadmin_same_plugin_slug_family')) {
    /**
     * Whether two $menu slugs belong to the same “plugin family” (matches yp-menus.js samePluginFamily).
     */
    function yooadmin_same_plugin_slug_family(string $a, string $b): bool {
        $a = strtolower($a);
        $b = strtolower($b);
        if ($a === '' || $b === '') {
            return false;
        }
        if ($a === $b) {
            return true;
        }
        return strpos($a, $b . '-') === 0 || strpos($b, $a . '-') === 0;
    }
}

if (!function_exists('yooadmin_merge_canonical_slug')) {
    /**
     * Pick the shorter / parent slug (matches yp-menus.js mergeCanonicalSlug).
     */
    function yooadmin_merge_canonical_slug(string $a, string $b): string {
        $la = strtolower($a);
        $lb = strtolower($b);
        if ($la === $lb) {
            return $a;
        }
        if (strpos($lb, $la . '-') === 0) {
            return $a;
        }
        if (strpos($la, $lb . '-') === 0) {
            return $b;
        }
        return strlen($la) <= strlen($lb) ? $a : $b;
    }
}

if (!function_exists('yooadmin_union_submenu_rows_by_url')) {
    /**
     * Union multiple submenu arrays, deduping by URL (case-insensitive).
     *
     * @param array<int, array<int, array<string,mixed>>> $subs_arrays
     * @return array<int, array<string,mixed>>
     */
    function yooadmin_union_submenu_rows_by_url(array $subs_arrays): array {
        $merged = [];
        $seen   = [];
        foreach ($subs_arrays as $list) {
            if (! is_array($list)) {
                continue;
            }
            foreach ($list as $sub) {
                if (! is_array($sub) || empty($sub['url'])) {
                    continue;
                }
                $key = strtolower((string) $sub['url']);
                if ($key === '' || isset($seen[ $key ])) {
                    continue;
                }
                $seen[ $key ] = true;
                $merged[]     = $sub;
            }
        }
        return $merged;
    }
}

if (!function_exists('yooadmin_merge_duplicate_top_level_menus_by_title_family')) {
    /**
     * Merge top-level rows that share the same visible title and slug “family” (e.g. foo + foo-bar).
     * Generalizes the former Elementor-only duplicate merge; aligns with yp-menus.js buildCanonSlugByTitle.
     *
     * Filter: `yooadmin_merge_duplicate_top_level_menus_by_title_family` (pass false to disable).
     *
     * @param array<int, array<string,mixed>> $items Built menu tree rows.
     * @return array<int, array<string,mixed>>
     */
    function yooadmin_merge_duplicate_top_level_menus_by_title_family(array $items): array {
        if (! apply_filters('yooadmin_merge_duplicate_top_level_menus_by_title_family', true)) {
            return $items;
        }

        $by_title = [];
        foreach ($items as $i => $item) {
            $k = yooadmin_normalize_menu_title_key((string) ($item['title'] ?? ''));
            if ($k === '') {
                continue;
            }
            if (! isset($by_title[ $k ])) {
                $by_title[ $k ] = [];
            }
            $by_title[ $k ][] = $i;
        }

        $removed         = [];
        $merged_primary  = [];

        foreach ($by_title as $title_key => $indices) {
            if (count($indices) < 2) {
                continue;
            }

            $bucket = [];
            $slugs  = [];
            foreach ($indices as $i) {
                $bucket[] = $items[ $i ];
                $slugs[]  = (string) ($items[ $i ]['slug'] ?? '');
            }

            $c = $slugs[0];
            if ($c === '') {
                continue;
            }

            $ok = true;
            $n  = count($slugs);
            for ($j = 1; $j < $n; $j++) {
                if (! yooadmin_same_plugin_slug_family($c, $slugs[ $j ]) || $slugs[ $j ] === '') {
                    $ok = false;
                    break;
                }
                $c = yooadmin_merge_canonical_slug($c, $slugs[ $j ]);
            }
            if (! $ok) {
                continue;
            }

            $primary = $bucket[0];
            foreach ($bucket as $it) {
                if (strtolower((string) ($it['slug'] ?? '')) === strtolower($c)) {
                    $primary = $it;
                    break;
                }
            }

            $lists = [];
            foreach ($bucket as $it) {
                $lists[] = isset($it['subs']) && is_array($it['subs']) ? $it['subs'] : [];
            }
            $primary['subs']    = yooadmin_union_submenu_rows_by_url($lists);
            $primary['has_sub'] = ! empty($primary['subs']);

            $first_i = $indices[0];
            for ($x = 1; $x < count($indices); $x++) {
                $removed[ $indices[ $x ] ] = true;
            }
            $merged_primary[ $first_i ] = $primary;
        }

        if ($merged_primary === [] && $removed === []) {
            return $items;
        }

        $new = [];
        foreach ($items as $i => $item) {
            if (isset($removed[ $i ])) {
                continue;
            }
            if (isset($merged_primary[ $i ])) {
                $new[] = $merged_primary[ $i ];
                continue;
            }
            $new[] = $item;
        }

        return $new;
    }
}

if (!function_exists('yooadmin_menu_hub_slug_token')) {
    /**
     * Token used to match `post_type=foo_bar` to hub slug `foo` (prefix foo_).
     * Returns empty if this row should not act as a merge target hub.
     */
    function yooadmin_menu_hub_slug_token(string $slug): string {
        $slug = (string) $slug;
        if (strpos($slug, 'post_type=') !== false) {
            return '';
        }
        if (preg_match('/[?&]page=([^&]+)/i', $slug, $m)) {
            return strtolower($m[1]);
        }
        $s = strtolower(trim($slug));
        if (strpos($s, '.php') !== false && strpos($s, '?') === false) {
            $s = preg_replace('/\.php$/', '', basename($s));
        }
        $deny = [ 'edit', 'upload', 'admin', 'index', 'plugins', 'themes', 'users', 'tools', 'options-general', 'customize' ];
        if (in_array($s, $deny, true)) {
            return '';
        }
        return $s;
    }
}

if (!function_exists('yooadmin_merge_post_type_listing_into_prefixed_hub')) {
    /**
     * Merge a top-level `edit.php?post_type=X` row into an existing hub when X starts with `{hub}_`
     * (e.g. elementor_library → elementor). Generalizes the former Elementor-only Templates merge.
     *
     * Filters: `yooadmin_merge_post_type_into_prefixed_hub` (bool), `yooadmin_post_type_hub_merge_skip` (bool, $post_type, $item).
     *
     * @param array<int, array<string,mixed>> $items
     * @return array<int, array<string,mixed>>
     */
    function yooadmin_merge_post_type_listing_into_prefixed_hub(array $items): array {
        if (! apply_filters('yooadmin_merge_post_type_into_prefixed_hub', true)) {
            return $items;
        }

        $cpt_rows = [];
        foreach ($items as $i => $item) {
            $slug = isset($item['slug']) ? (string) $item['slug'] : '';
            if (strpos($slug, 'post_type=') === false || ! preg_match('/post_type=([^&]+)/', $slug, $m)) {
                continue;
            }
            $pt = $m[1];
            if (apply_filters('yooadmin_post_type_hub_merge_skip', false, $pt, $item)) {
                continue;
            }
            $cpt_rows[ $i ] = strtolower($pt);
        }
        if ($cpt_rows === []) {
            return $items;
        }

        $hub_tokens = [];
        foreach ($items as $i => $item) {
            if (isset($cpt_rows[ $i ])) {
                continue;
            }
            $slug  = isset($item['slug']) ? (string) $item['slug'] : '';
            $token = yooadmin_menu_hub_slug_token($slug);
            if ($token !== '') {
                $hub_tokens[ $i ] = $token;
            }
        }

        $merge_cpt_into_hub = [];
        foreach ($cpt_rows as $ci => $pt_lower) {
            $best_i   = null;
            $best_len = 0;
            foreach ($hub_tokens as $hi => $token) {
                $prefix = str_replace('-', '_', $token) . '_';
                if (strpos($pt_lower, $prefix) === 0 && strlen($token) > $best_len) {
                    $best_len = strlen($token);
                    $best_i   = $hi;
                }
            }
            if ($best_i !== null) {
                $merge_cpt_into_hub[ $ci ] = $best_i;
            }
        }
        if ($merge_cpt_into_hub === []) {
            return $items;
        }

        $extra_by_hub = [];
        foreach ($merge_cpt_into_hub as $ci => $hi) {
            if (! isset($extra_by_hub[ $hi ])) {
                $extra_by_hub[ $hi ] = [];
            }
            $extra_by_hub[ $hi ][] = isset($items[ $ci ]['subs']) && is_array($items[ $ci ]['subs']) ? $items[ $ci ]['subs'] : [];
        }

        $remove_cpt = array_flip(array_keys($merge_cpt_into_hub));

        $new = [];
        foreach ($items as $i => $item) {
            if (isset($remove_cpt[ $i ])) {
                continue;
            }
            if (isset($extra_by_hub[ $i ])) {
                $base  = isset($item['subs']) && is_array($item['subs']) ? $item['subs'] : [];
                $lists = array_merge([ $base ], $extra_by_hub[ $i ]);
                $item['subs']    = yooadmin_union_submenu_rows_by_url($lists);
                $item['has_sub'] = ! empty($item['subs']);
            }
            $new[] = $item;
        }

        return $new;
    }
}

if (!function_exists('yooadmin_merge_elementor_top_level_menu_duplicates')) {
    /**
     * @deprecated Use yooadmin_merge_duplicate_top_level_menus_by_title_family() (same behavior, general).
     */
    function yooadmin_merge_elementor_top_level_menu_duplicates(array $items): array {
        return yooadmin_merge_duplicate_top_level_menus_by_title_family($items);
    }
}

if (!function_exists('yooadmin_merge_elementor_library_menu_into_elementor_hub')) {
    /**
     * @deprecated Use yooadmin_merge_post_type_listing_into_prefixed_hub() (same behavior, general).
     */
    function yooadmin_merge_elementor_library_menu_into_elementor_hub(array $items): array {
        return yooadmin_merge_post_type_listing_into_prefixed_hub($items);
    }
}

/* ----------------------------------------------------------------------------
 * Localize data into the popup script (no enqueue here)
 * ---------------------------------------------------------------------------- */
if (!function_exists('yooadmin_localize_popup_menus')) {
    /**
     * Localize menu tree data to a given script handle.
     *
     * @param string $handle Typically 'yooadmin-popup'.
     * @return void
     */
    function yooadmin_localize_popup_menus($handle): void {
        $menu_tree = yooadmin_build_admin_menu_tree();

        wp_localize_script($handle, 'yooadmCardMenus', [
            'items' => $menu_tree,
            'nonce' => wp_create_nonce('yooadmin_popup_nonce'),
        ]);
    }
}

/* ----------------------------------------------------------------------------
 * Hook: localize only when needed and when the script is already enqueued
 * ---------------------------------------------------------------------------- */
if (!function_exists('yooadmin_maybe_localize_popup')) {
    /**
     * Localize popup data if we're on our panel screen or should inject shell,
     * and the 'yooadmin-popup' script is already enqueued by assets.php.
     */
    function yooadmin_maybe_localize_popup(): void {
        // Card menu data is localized once on `yp-admin-core-essential` in assets.php (same tree as popup).
        // Avoid duplicating `yooadmCardMenus` on another handle (would redefine the global).
    }
    add_action('admin_enqueue_scripts', 'yooadmin_maybe_localize_popup', 20);
}
