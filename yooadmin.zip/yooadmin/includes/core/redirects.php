<?php
/**
 * YOOAdmin - Redirect core dashboard to plugin dashboard (optional)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

add_action('load-index.php', function () {
    // Skip non-interactive contexts
    if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) return;

    // Skip multisite network admin or user admin
    if (is_network_admin() || is_user_admin()) return;

    // Minimal capability
    if (!current_user_can('read')) return;

    // Respect opt-out query
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flag, no state change.
    if (isset($_GET['yooadmin_no_redirect'])) return;

    // If YOOAdmin Focus UI is disabled, never redirect – let WP behave normally.
    if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) return;

    // Read setting: only redirect if enabled
    if (!function_exists('yooadmin_get_option')) return;
    $enabled = (bool) yooadmin_get_option('redirect_dashboard', false);
    if (!$enabled) return;

    // Determine target slug
    $slug = apply_filters('yooadmin_dashboard_page_slug', 'yooadmin-dashboard');

    // Avoid loop if already targeting our page
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
    if (isset($_GET['page']) && sanitize_key( wp_unslash( $_GET['page'] ) ) === $slug) return;

    $dest = add_query_arg('page', $slug, admin_url('admin.php'));
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only query flag for redirect target; no mutation.
    if (isset($_GET['yooadmin_login']) && '1' === sanitize_text_field(wp_unslash($_GET['yooadmin_login']))) {
        $dest = add_query_arg('yooadmin_login', '1', $dest);
    }
    wp_safe_redirect($dest);
    exit;
});

add_action('admin_post_yooadmin_enable_dashboard_redirect', function () {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Forbidden', 'yooadmin'), 403);
    }

    check_admin_referer('yooadmin_enable_dashboard_redirect');

    $opts = (array) get_option('yooadmin_options', []);
    $opts['redirect_dashboard'] = 1;
    update_option('yooadmin_options', $opts, false);
    wp_cache_delete('yooadmin_options_' . get_current_user_id(), 'yooadmin_settings');

    $slug = apply_filters('yooadmin_dashboard_page_slug', 'yooadmin-dashboard');
    wp_safe_redirect(add_query_arg('page', $slug, admin_url('admin.php')));
    exit;
});

add_action('admin_head-index.php', function () {
    if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
        return;
    }
    ?>
    <style>
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-row{
        display:flex!important;align-items:center!important;justify-content:space-between!important;gap:16px!important;margin:8px 0 16px!important;width:100%!important;box-sizing:border-box!important;
      }
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-row>h1{margin:0!important;padding:0!important;flex:0 1 auto!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-actions{
        display:flex!important;align-items:center!important;gap:8px!important;margin:0!important;flex:0 1 auto!important;
        flex-wrap:wrap!important;justify-content:flex-end!important;
      }
      /* RTL: h1 first in DOM → flex-start (right); actions second → flex-end (left), like EN but mirrored. */
      :is([dir="rtl"], body.rtl) body.wp-admin.index-php .ysh-wp-dashboard-redirect-row{direction:rtl!important;}
      :is([dir="rtl"], body.rtl) body.wp-admin.index-php .ysh-wp-dashboard-redirect-row>h1{text-align:right!important;}
      :is([dir="rtl"], body.rtl) body.wp-admin.index-php .ysh-wp-dashboard-actions{justify-content:flex-start!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-form{margin:0!important;display:block!important;width:100%!important;}
      /* Softer, more compact single "Widgets" trigger in the dashboard header. */
      body.wp-admin.index-php .ysh-wp-dashboard-widgets-btn{
        display:inline-flex!important;align-items:center!important;gap:6px!important;min-height:32px!important;padding:6px 11px!important;border-radius:9px!important;
        border:1px solid rgba(237,169,52,.2)!important;background:rgba(237,169,52,.07)!important;color:var(--yp-primary,#eda934)!important;
        font-size:12px!important;font-weight:600!important;line-height:1!important;text-decoration:none!important;box-shadow:none!important;cursor:pointer!important;
        transition:background-color .16s ease,border-color .16s ease!important;
      }
      body.wp-admin.index-php .ysh-wp-dashboard-widgets-btn:hover,
      body.wp-admin.index-php .ysh-wp-dashboard-widgets-btn:focus{
        background:rgba(237,169,52,.13)!important;border-color:rgba(237,169,52,.34)!important;color:var(--yp-primary,#eda934)!important;outline:none!important;
      }
      body.wp-admin.index-php .ysh-wp-dashboard-widgets-btn .dashicons{width:14px!important;height:14px!important;font-size:14px!important;line-height:1!important;color:currentColor!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widgets-btn span:not(.dashicons){display:inline-flex!important;align-items:center!important;font-size:12px!important;font-weight:600!important;line-height:1!important;}
      /* Quick-action rows relocated inside the Widgets modal (YOOAdmin / Add Note / Dashboard Redirect). */
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__label{
        display:flex!important;align-items:center!important;justify-content:space-between!important;gap:14px!important;width:100%!important;box-sizing:border-box!important;
        padding:10px 12px!important;border-radius:11px!important;
        background:#f8fafc!important;border:1px solid #e2e8f0!important;color:#1d2327!important;
        font-size:13px!important;font-weight:600!important;line-height:1.35!important;cursor:pointer!important;
        box-shadow:0 1px 2px rgba(15,23,42,.04)!important;transition:background-color .16s ease,border-color .16s ease!important;
      }
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__label:hover{background:#f1f5f9!important;border-color:#cbd5e1!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__text{min-width:0!important;color:inherit!important;-webkit-text-fill-color:currentColor!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__label input{position:absolute!important;opacity:0!important;pointer-events:none!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__switch{
        position:relative!important;width:34px!important;height:18px!important;border-radius:999px!important;background:rgba(100,116,139,.36)!important;
        box-shadow:inset 0 0 0 1px rgba(100,116,139,.28)!important;
      }
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__switch:before{
        content:""!important;position:absolute!important;top:3px!important;left:3px!important;width:12px!important;height:12px!important;border-radius:50%!important;
        background:#fff!important;box-shadow:0 1px 4px rgba(15,23,42,.28)!important;transition:transform .18s ease!important;
      }
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__label input:checked+.ysh-wp-dashboard-redirect-toggle__switch{
        background:var(--yp-primary,#eda934)!important;box-shadow:inset 0 0 0 1px rgba(0,0,0,.18)!important;
      }
      body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__label input:checked+.ysh-wp-dashboard-redirect-toggle__switch:before{
        transform:translateX(16px)!important;
      }
      :is([dir="rtl"], body.rtl) body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__switch:before{
        left:auto!important;right:3px!important;
      }
      :is([dir="rtl"], body.rtl) body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__label input:checked+.ysh-wp-dashboard-redirect-toggle__switch:before{
        transform:translateX(-16px)!important;
      }
      body.wp-admin.index-php.ysh-wp-dashboard-widget-modal-open{overflow:hidden!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal[hidden]{display:none!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal{position:fixed!important;inset:0!important;z-index:100160!important;display:flex!important;align-items:center!important;justify-content:center!important;padding:24px!important;box-sizing:border-box!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__overlay{position:absolute!important;inset:0!important;background:rgba(10,15,23,.55)!important;backdrop-filter:blur(8px)!important;-webkit-backdrop-filter:blur(8px)!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__panel{position:relative!important;z-index:1!important;width:min(96vw,680px)!important;max-height:min(84vh,720px)!important;display:flex!important;flex-direction:column!important;overflow:hidden!important;border-radius:16px!important;background:#fff!important;border:1px solid #dcdcde!important;box-shadow:0 24px 80px rgba(15,23,42,.28)!important;color:#1d2327!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__header{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:16px!important;padding:20px 22px 16px!important;border-bottom:1px solid #edf0f3!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__eyebrow{display:inline-flex!important;align-items:center!important;gap:6px!important;margin:0 0 6px!important;color:var(--yp-primary,#eda934)!important;font-size:11px!important;font-weight:800!important;text-transform:uppercase!important;letter-spacing:.08em!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__title{margin:0!important;color:#1d2327!important;font-size:20px!important;font-weight:800!important;line-height:1.25!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__desc{margin:7px 0 0!important;color:#646970!important;font-size:13px!important;line-height:1.5!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__close{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 auto!important;width:34px!important;height:34px!important;border-radius:10px!important;border:1px solid #dcdcde!important;background:#f6f7f7!important;color:#50575e!important;box-shadow:none!important;cursor:pointer!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__body{padding:16px 18px!important;overflow:auto!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__list{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(230px,1fr))!important;gap:10px!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__actions{display:flex!important;flex-direction:column!important;gap:8px!important;margin:0 0 16px!important;padding:0 0 16px!important;border-bottom:1px solid #edf0f3!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-modal-action{
        display:flex!important;align-items:center!important;gap:10px!important;margin:0!important;width:100%!important;box-sizing:border-box!important;
        padding:10px 12px!important;border-radius:11px!important;background:#f8fafc!important;border:1px solid #e2e8f0!important;color:#1d2327!important;
        font-size:13px!important;font-weight:600!important;line-height:1.35!important;text-align:start!important;text-decoration:none!important;
        box-shadow:0 1px 2px rgba(15,23,42,.04)!important;cursor:pointer!important;transition:background-color .16s ease,border-color .16s ease!important;
      }
      body.wp-admin.index-php .ysh-wp-dashboard-modal-action:hover,
      body.wp-admin.index-php .ysh-wp-dashboard-modal-action:focus{background:#f1f5f9!important;border-color:#cbd5e1!important;color:#1d2327!important;outline:none!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-modal-action .dashicons{flex:0 0 auto!important;width:18px!important;height:18px!important;font-size:18px!important;line-height:1!important;color:var(--yp-primary,#eda934)!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-modal-action__text{min-width:0!important;color:inherit!important;-webkit-text-fill-color:currentColor!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__empty{margin:0!important;padding:16px!important;border-radius:12px!important;background:#f6f7f7!important;border:1px dashed #dcdcde!important;color:#646970!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-toggle{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:14px!important;padding:13px 14px!important;border-radius:13px!important;background:#f8fafc!important;border:1px solid #e2e8f0!important;color:#1d2327!important;cursor:pointer!important;box-shadow:0 1px 2px rgba(15,23,42,.04)!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-toggle__text{min-width:0!important;font-size:13px!important;font-weight:700!important;line-height:1.35!important;color:inherit!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-toggle input{position:absolute!important;opacity:0!important;pointer-events:none!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-toggle__switch{position:relative!important;flex:0 0 auto!important;width:42px!important;height:24px!important;border-radius:999px!important;background:#cbd5e1!important;box-shadow:inset 0 0 0 1px rgba(100,116,139,.24)!important;transition:background-color .18s ease,box-shadow .18s ease!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-toggle__switch:before{content:""!important;position:absolute!important;top:4px!important;left:4px!important;width:16px!important;height:16px!important;border-radius:50%!important;background:#fff!important;box-shadow:0 2px 6px rgba(15,23,42,.26)!important;transition:transform .18s ease!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-toggle input:checked+.ysh-wp-dashboard-widget-toggle__switch{background:var(--yp-primary,#eda934)!important;box-shadow:inset 0 0 0 1px rgba(0,0,0,.15)!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-toggle input:checked+.ysh-wp-dashboard-widget-toggle__switch:before{transform:translateX(18px)!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__footer{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:12px!important;padding:14px 18px!important;border-top:1px solid #edf0f3!important;background:#fbfcfd!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__hint{margin:0!important;color:#646970!important;font-size:12px!important;line-height:1.4!important;}
      body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__done{display:inline-flex!important;align-items:center!important;justify-content:center!important;min-height:34px!important;padding:7px 14px!important;border-radius:10px!important;border:1px solid var(--yp-primary,#eda934)!important;background:var(--yp-primary,#eda934)!important;color:#fff!important;font-weight:800!important;cursor:pointer!important;}
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__panel{background:#1a1d23!important;border-color:rgba(255,255,255,.12)!important;box-shadow:0 28px 90px rgba(0,0,0,.52)!important;color:#cfd6e0!important;}
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__header,
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__footer{border-color:rgba(255,255,255,.1)!important;background:#1a1d23!important;}
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__title{color:#eef1f5!important;}
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__desc,
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__hint{color:#9aa5b1!important;}
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__close{background:rgba(255,255,255,.06)!important;border-color:rgba(255,255,255,.14)!important;color:#eef1f5!important;}
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-widget-toggle{background:#22262e!important;border-color:rgba(255,255,255,.11)!important;color:#eef1f5!important;box-shadow:none!important;}
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__actions{border-bottom-color:rgba(255,255,255,.1)!important;}
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-modal-action,
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__label{background:#22262e!important;border-color:rgba(255,255,255,.11)!important;color:#eef1f5!important;box-shadow:none!important;}
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-modal-action:hover,
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-modal-action:focus,
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php .ysh-wp-dashboard-redirect-toggle__label:hover{background:#2a3039!important;border-color:rgba(255,255,255,.18)!important;color:#eef1f5!important;}
      @media (max-width:782px){
        body.wp-admin.index-php .ysh-wp-dashboard-redirect-row{align-items:flex-start!important;flex-direction:column!important;}
        body.wp-admin.index-php .ysh-wp-dashboard-actions{justify-content:flex-start!important;}
        :is([dir="rtl"], body.rtl) body.wp-admin.index-php .ysh-wp-dashboard-redirect-row>h1{text-align:right!important;}
        :is([dir="rtl"], body.rtl) body.wp-admin.index-php .ysh-wp-dashboard-actions{justify-content:flex-start!important;}
        body.wp-admin.index-php .ysh-wp-dashboard-widget-modal{padding:12px!important;align-items:flex-end!important;}
        body.wp-admin.index-php .ysh-wp-dashboard-widget-modal__panel{width:100%!important;max-height:88vh!important;border-radius:16px 16px 0 0!important;}
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #welcome-panel,
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #welcome-panel :is(.welcome-panel-content,.welcome-panel-column-container,.welcome-panel-column){
        background:#1a1d23!important;background-color:#1a1d23!important;border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #welcome-panel :is(h2,h3,p,li,span):not(.dashicons),
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets :is(h2,h3,p,li,span,td,th):not(.dashicons){
        color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #welcome-panel :is(h2,h3,strong),
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets :is(h2,h3,strong){
        color:#eef1f5!important;-webkit-text-fill-color:#eef1f5!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #welcome-panel a:not(.button),
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets a:not(.button){
        color:var(--yp-primary,#eda934)!important;-webkit-text-fill-color:var(--yp-primary,#eda934)!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets :is(
        .postbox,.inside,.card,[class*="card" i],[class*="panel" i],[class*="module" i],[class*="widget" i],
        table,thead,tbody,tfoot,tr,td,th
      ){
        background:#1a1d23!important;background-color:#1a1d23!important;border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets .inside :is(
        div,section,article,p,ul,ol,li,dl,dt,dd
      ):not(svg):not(path):not(canvas):not(img):not(iframe){
        background-color:transparent!important;border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets .inside > :is(
        div,section,article,p,ul,ol
      ):not(svg):not(path):not(canvas):not(img):not(iframe){
        background:#1a1d23!important;background-color:#1a1d23!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets :is(
        [style*="background:#fff"],[style*="background: #fff"],[style*="background-color:#fff"],[style*="background-color: #fff"],
        [style*="background:white"],[style*="background: white"],[style*="background-color:white"],[style*="background-color: white"],
        [style*="background:#ffffff"],[style*="background: #ffffff"],[style*="background-color:#ffffff"],[style*="background-color: #ffffff"],
        [style*="rgb(255, 255, 255)"],[style*="rgba(255, 255, 255"]
      ){
        background:#1a1d23!important;background-color:#1a1d23!important;border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets :is(
        table,thead,tbody,tfoot,tr,td,th
      ):nth-child(even){
        background:#22262e!important;background-color:#22262e!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets :is(
        img,svg,canvas,video,iframe
      ){
        background:transparent!important;background-color:transparent!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets :is(
        input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]),textarea,select,.button:not(.button-primary)
      ){
        background:#22262e!important;background-color:#22262e!important;border-color:rgba(255,255,255,.16)!important;color:#eef1f5!important;-webkit-text-fill-color:#eef1f5!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets :is(
        progress,meter,[role="progressbar"],[class*="progress" i],[class*="skeleton" i],[class*="placeholder" i],
        [class*="yst-bg-white" i],[class*="yst-bg-slate" i],[class*="yst-bg-gray" i],[class*="yst-bg-neutral" i]
      ){
        background:#2a3039!important;background-color:#2a3039!important;border-color:rgba(255,255,255,.14)!important;color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;box-shadow:none!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets progress::-webkit-progress-bar{
        background:#2a3039!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub #dashboard-widgets progress::-webkit-progress-value{
        background:var(--yp-primary,#eda934)!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub :is(
        [class*="yst-bg-white" i],[class*="yst-bg-slate" i],[class*="yst-bg-gray" i],[class*="yst-bg-neutral" i],
        [class*="yst-modal" i],[class*="yst-popover" i],[class*="yst-toast" i],[class*="yst-card" i],[class*="yst-panel" i],
        [class*="yoast" i][class*="modal" i],[class*="yoast" i][class*="notice" i]
      ){
        background:#1a1d23!important;background-color:#1a1d23!important;border-color:rgba(255,255,255,.14)!important;color:#cfd6e0!important;box-shadow:0 18px 48px rgba(0,0,0,.46)!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub :is(
        [class*="yst-text-slate" i],[class*="yst-text-gray" i],[class*="yst-text-neutral" i],[class*="yst-text-black" i]
      ){
        color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub :is(
        [class*="yst-modal" i],[class*="yst-popover" i],[class*="yst-toast" i],[class*="yst-card" i],[class*="yst-panel" i],
        [class*="yoast" i][class*="modal" i],[class*="yoast" i][class*="notice" i]
      ) :is(h1,h2,h3,h4,h5,h6,strong){
        color:#eef1f5!important;-webkit-text-fill-color:#eef1f5!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub :is(
        [class*="yst-modal" i],[class*="yst-popover" i],[class*="yst-toast" i],[class*="yst-card" i],[class*="yst-panel" i],
        [class*="yoast" i][class*="modal" i],[class*="yoast" i][class*="notice" i]
      ) :is(p,span,div,li):not([class*="dashicon" i]):not([aria-hidden="true"]){
        color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;
      }
      html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.wp-admin.index-php.yooadmin-theme-yooadmin-studio-hub :is(
        [class*="yst-modal" i],[class*="yst-popover" i],[class*="yst-toast" i],[class*="yst-card" i],[class*="yst-panel" i],
        [class*="yoast" i][class*="modal" i],[class*="yoast" i][class*="notice" i]
      ) :is(button:not([class*="primary" i]),.button:not(.button-primary),a:not([class*="primary" i])){
        color:var(--yp-primary,#eda934)!important;-webkit-text-fill-color:var(--yp-primary,#eda934)!important;
      }
    </style>
    <?php
});

add_action('admin_footer-index.php', function () {
    if (!current_user_can('manage_options')) {
        return;
    }
    if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
        return;
    }

    $opts    = (array) get_option('yooadmin_options', []);
    $enabled = !array_key_exists('redirect_dashboard', $opts) || !empty($opts['redirect_dashboard']);
    $action  = admin_url('admin-post.php');
    $dashboard_url = function_exists('yooadmin_dashboard_url')
        ? yooadmin_dashboard_url()
        : add_query_arg('page', apply_filters('yooadmin_dashboard_page_slug', 'yooadmin-dashboard'), admin_url('admin.php'));
    $has_dashboard_notes = class_exists('WP_Dashboard_Notes', false) || isset($GLOBALS['wp_dashboard_notes']);
    ?>
    <script>
      (function () {
        var wrap = document.querySelector('#wpbody-content .wrap');
        if (!wrap || wrap.querySelector('.ysh-wp-dashboard-redirect-row')) return;
        var hasDashboardNotes = <?php echo $has_dashboard_notes ? 'true' : 'false'; ?>;

        var heading = wrap.querySelector('h1');
        if (!heading) {
          heading = document.createElement('h1');
          heading.textContent = 'Dashboard';
          wrap.insertBefore(heading, wrap.firstChild);
        }

        var row = document.createElement('div');
        row.className = 'ysh-wp-dashboard-redirect-row';
        heading.parentNode.insertBefore(row, heading);
        row.appendChild(heading);

        var actions = document.createElement('div');
        actions.className = 'ysh-wp-dashboard-actions';
        row.appendChild(actions);

        var widgetsBtn = document.createElement('button');
        widgetsBtn.type = 'button';
        widgetsBtn.className = 'ysh-wp-dashboard-widgets-btn';
        widgetsBtn.innerHTML =
          '<span class="dashicons dashicons-screenoptions" aria-hidden="true"></span>' +
          '<span><?php echo esc_js(__('Widgets', 'yooadmin')); ?></span>';
        actions.appendChild(widgetsBtn);

        var dashboardUrl = <?php echo wp_json_encode($dashboard_url); ?>;
        var redirectAction = <?php echo wp_json_encode($action); ?>;
        var redirectNonce = '<?php echo esc_js(wp_create_nonce('yooadmin_enable_dashboard_redirect')); ?>';
        var redirectEnabled = <?php echo $enabled ? 'true' : 'false'; ?>;

        function buildModalActions(container) {
          if (!container) {
            return;
          }
          container.innerHTML = '';

          var yooadminBtn = document.createElement('a');
          yooadminBtn.className = 'ysh-wp-dashboard-modal-action ysh-wp-dashboard-modal-action--yooadmin';
          yooadminBtn.href = dashboardUrl;
          yooadminBtn.title = '<?php echo esc_js(__('YOOAdmin Dashboard', 'yooadmin')); ?>';
          yooadminBtn.setAttribute('aria-label', '<?php echo esc_js(__('Open YOOAdmin Dashboard', 'yooadmin')); ?>');
          yooadminBtn.innerHTML =
            '<span class="dashicons dashicons-admin-home" aria-hidden="true"></span>' +
            '<span class="ysh-wp-dashboard-modal-action__text"><?php echo esc_js(__('YOOAdmin', 'yooadmin')); ?></span>';
          container.appendChild(yooadminBtn);

          if (hasDashboardNotes) {
            var noteBtn = document.createElement('button');
            noteBtn.type = 'button';
            noteBtn.className = 'ysh-wp-dashboard-modal-action ysh-wp-dashboard-modal-action--note wpdn-add-note';
            noteBtn.innerHTML =
              '<span class="dashicons dashicons-welcome-write-blog" aria-hidden="true"></span>' +
              '<span class="ysh-wp-dashboard-modal-action__text"><?php echo esc_js(__('Add Note', 'yooadmin')); ?></span>';
            noteBtn.addEventListener('click', function () {
              window.setTimeout(removeWidgetModal, 0);
            });
            container.appendChild(noteBtn);
          }

          var form = document.createElement('form');
          form.className = 'ysh-wp-dashboard-redirect-form';
          form.method = 'post';
          form.action = redirectAction;
          form.innerHTML =
            '<input type="hidden" name="action" value="yooadmin_enable_dashboard_redirect">' +
            '<input type="hidden" name="_wpnonce" value="' + redirectNonce + '">' +
            '<label class="ysh-wp-dashboard-redirect-toggle__label">' +
            '<span class="ysh-wp-dashboard-redirect-toggle__text"><?php echo esc_js(__('Dashboard Redirect', 'yooadmin')); ?></span>' +
            '<input type="checkbox" role="switch"' + (redirectEnabled ? ' checked' : '') + '>' +
            '<span class="ysh-wp-dashboard-redirect-toggle__switch" aria-hidden="true"></span>' +
            '</label>';
          form.querySelector('input[type="checkbox"]').addEventListener('change', function () {
            if (!this.checked) {
              this.checked = true;
            }
            this.disabled = true;
            form.submit();
          });
          container.appendChild(form);
        }

        function getScreenOptionCheckboxes() {
          var panel = document.getElementById('screen-options-wrap');
          if (!panel) {
            return [];
          }
          return Array.prototype.slice
            .call(panel.querySelectorAll('.metabox-prefs label input[type="checkbox"], .metabox-prefs input[type="checkbox"]'))
            .filter(function (input) {
              return input && input.id && !input.disabled;
            });
        }

        function labelTextForCheckbox(input) {
          var label = input.closest('label');
          if (!label) {
            return input.getAttribute('aria-label') || input.id.replace(/-hide$/, '').replace(/[_-]+/g, ' ');
          }
          var clone = label.cloneNode(true);
          Array.prototype.slice.call(clone.querySelectorAll('input, .dashicons')).forEach(function (node) {
            node.parentNode.removeChild(node);
          });
          return (clone.textContent || input.id).replace(/\s+/g, ' ').trim();
        }

        function removeWidgetModal() {
          var existing = document.getElementById('ysh-wp-dashboard-widget-modal');
          if (existing && existing.parentNode) {
            existing.parentNode.removeChild(existing);
          }
          document.body.classList.remove('ysh-wp-dashboard-widget-modal-open');
        }

        function buildWidgetModalList(modal) {
          var list = modal.querySelector('[data-ysh-dashboard-widget-list]');
          if (!list) {
            return;
          }
          var inputs = getScreenOptionCheckboxes();
          if (!inputs.length) {
            list.innerHTML =
              '<p class="ysh-wp-dashboard-widget-modal__empty"><?php echo esc_js(__('No dashboard widgets were found on this screen.', 'yooadmin')); ?></p>';
            return;
          }

          list.innerHTML = '';
          inputs.forEach(function (input) {
            var id = input.id;
            var label = document.createElement('label');
            label.className = 'ysh-wp-dashboard-widget-toggle';
            label.setAttribute('for', 'ysh-toggle-' + id);
            label.innerHTML =
              '<span class="ysh-wp-dashboard-widget-toggle__text"></span>' +
              '<input id="ysh-toggle-' + id + '" type="checkbox" role="switch">' +
              '<span class="ysh-wp-dashboard-widget-toggle__switch" aria-hidden="true"></span>';

            var text = label.querySelector('.ysh-wp-dashboard-widget-toggle__text');
            var toggle = label.querySelector('input');
            text.textContent = labelTextForCheckbox(input);
            toggle.checked = input.checked;
            toggle.setAttribute('aria-label', text.textContent);
            toggle.addEventListener('change', function () {
              if (input.checked !== toggle.checked) {
                input.click();
              }
              toggle.checked = input.checked;
            });
            list.appendChild(label);
          });
        }

        function openWidgetModal() {
          removeWidgetModal();
          var modal = document.createElement('div');
          modal.id = 'ysh-wp-dashboard-widget-modal';
          modal.className = 'ysh-wp-dashboard-widget-modal';
          modal.setAttribute('role', 'dialog');
          modal.setAttribute('aria-modal', 'true');
          modal.setAttribute('aria-labelledby', 'ysh-wp-dashboard-widget-modal-title');
          modal.innerHTML =
            '<div class="ysh-wp-dashboard-widget-modal__overlay" data-ysh-widget-modal-close></div>' +
            '<div class="ysh-wp-dashboard-widget-modal__panel">' +
            '<div class="ysh-wp-dashboard-widget-modal__header">' +
            '<div><p class="ysh-wp-dashboard-widget-modal__eyebrow"><span class="dashicons dashicons-screenoptions" aria-hidden="true"></span><?php echo esc_js(__('Screen Elements', 'yooadmin')); ?></p>' +
            '<h2 id="ysh-wp-dashboard-widget-modal-title" class="ysh-wp-dashboard-widget-modal__title"><?php echo esc_js(__('Dashboard widgets', 'yooadmin')); ?></h2>' +
            '<p class="ysh-wp-dashboard-widget-modal__desc"><?php echo esc_js(__('Choose which WordPress dashboard widgets should be visible. Changes apply immediately and are saved by WordPress.', 'yooadmin')); ?></p></div>' +
            '<button type="button" class="ysh-wp-dashboard-widget-modal__close" data-ysh-widget-modal-close aria-label="<?php echo esc_js(__('Close', 'yooadmin')); ?>"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>' +
            '</div>' +
            '<div class="ysh-wp-dashboard-widget-modal__body">' +
            '<div class="ysh-wp-dashboard-widget-modal__actions" data-ysh-dashboard-actions></div>' +
            '<div class="ysh-wp-dashboard-widget-modal__list" data-ysh-dashboard-widget-list></div>' +
            '</div>' +
            '<div class="ysh-wp-dashboard-widget-modal__footer">' +
            '<p class="ysh-wp-dashboard-widget-modal__hint"><?php echo esc_js(__('Use these toggles instead of the native Screen Options checkboxes.', 'yooadmin')); ?></p>' +
            '<button type="button" class="ysh-wp-dashboard-widget-modal__done" data-ysh-widget-modal-close><?php echo esc_js(__('Done', 'yooadmin')); ?></button>' +
            '</div></div>';

          document.body.appendChild(modal);
          document.body.classList.add('ysh-wp-dashboard-widget-modal-open');
          buildModalActions(modal.querySelector('[data-ysh-dashboard-actions]'));
          buildWidgetModalList(modal);
          modal.querySelectorAll('[data-ysh-widget-modal-close]').forEach(function (el) {
            el.addEventListener('click', removeWidgetModal);
          });
          var close = modal.querySelector('.ysh-wp-dashboard-widget-modal__close');
          if (close) {
            close.focus();
          }
        }

        widgetsBtn.addEventListener('click', function (e) {
          e.preventDefault();
          openWidgetModal();
        });

        document.addEventListener('keydown', function (e) {
          if (e.key === 'Escape' && document.getElementById('ysh-wp-dashboard-widget-modal')) {
            removeWidgetModal();
          }
        });
      })();
    </script>
    <?php
});

