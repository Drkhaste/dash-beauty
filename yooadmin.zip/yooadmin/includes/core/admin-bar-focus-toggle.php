<?php
defined('ABSPATH') || exit;

if (!function_exists('yooadmin_is_enable_focus_admin_page')) {
    function yooadmin_is_enable_focus_admin_page(): bool
    {
        if (!is_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === 'yooadmin-enable-focus';
    }
}

if (!function_exists('yooadmin_user_can_admin_bar_focus_toggle')) {
    function yooadmin_user_can_admin_bar_focus_toggle(): bool
    {
        $pref_cap = function_exists('yooadmin_focus_preference_capability')
            ? yooadmin_focus_preference_capability()
            : 'read';
        if (current_user_can($pref_cap)) {
            return true;
        }

        return function_exists('yooadmin_user_can_manage_focus_policy')
            && yooadmin_user_can_manage_focus_policy();
    }
}

if (!function_exists('yooadmin_parse_ajax_bool')) {
    function yooadmin_parse_ajax_bool($value, bool $default = true): bool
    {
        if ($value === null || $value === '') {
            return $default;
        }
        if (is_bool($value)) {
            return $value;
        }

        $value = strtolower(trim(sanitize_text_field((string) $value)));
        if (in_array($value, ['1', 'true', 'yes', 'on'], true)) {
            return true;
        }
        if (in_array($value, ['0', 'false', 'no', 'off'], true)) {
            return false;
        }

        return $default;
    }
}

if (!function_exists('yooadmin_localize_focus_alerts_script')) {
    function yooadmin_localize_focus_alerts_script(): void
    {
        if (!wp_script_is('yooadmin-focus-alerts', 'enqueued')) {
            return;
        }

        $can_manage = function_exists('yooadmin_user_can_manage_focus_policy')
            && yooadmin_user_can_manage_focus_policy();

        wp_localize_script('yooadmin-focus-alerts', 'yooadmFocusAlerts', [
            'focusModeDisabled'        => __('Focus Mode Disabled', 'yooadmin'),
            'focusDisabledMessage'     => __('Focus Mode is disabled by the administrator. To enable it for yourself only, the policy must be set to "Auto" to allow users to choose their preference.', 'yooadmin'),
            'focusDisabledMessageUser' => __('Focus Mode is turned off for all users by your site administrator. You cannot enable it yourself. Please contact your administrator if you need access.', 'yooadmin'),
            'cancel'                   => __('Cancel', 'yooadmin'),
            'enableAutoMode'           => __('Enable Auto Mode', 'yooadmin'),
            'focusModePolicy'          => __('Focus Mode Policy', 'yooadmin'),
            'focusModePolicyUser'      => __('Focus Mode Is Locked', 'yooadmin'),
            'policyOnMessage'          => __('Focus Mode policy is currently set to <strong>"Force On"</strong>. To allow users to control Focus Mode, change the policy to <strong>"Auto"</strong> in settings.', 'yooadmin'),
            'policyOnMessageUser'      => __('Your site administrator requires Focus Mode for all users. You cannot turn it off while this policy is active. Please contact your administrator if you need the classic WordPress admin.', 'yooadmin'),
            'policyOffMessage'         => __('Focus Mode policy is currently set to <strong>"Force Off"</strong>. To enable Focus Mode, change the policy to <strong>"Auto"</strong> in settings.', 'yooadmin'),
            'policyOffMessageUser'     => __('Focus Mode is turned off for all users by your site administrator. You cannot enable it yourself. Please contact your administrator if you need access.', 'yooadmin'),
            'close'                    => __('Close', 'yooadmin'),
            'focusModeSettings'        => __('Focus Mode Settings', 'yooadmin'),
            'canManagePolicy'          => $can_manage,
        ]);
    }
}

add_action('admin_bar_menu', function ($wp_admin_bar) {
    if (!yooadmin_user_can_admin_bar_focus_toggle()) {
        return;
    }

    if (yooadmin_is_enable_focus_admin_page()) {
        return;
    }

    $is_focus_on = function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();
    $label_text  = $is_focus_on ? __('Disable Focus', 'yooadmin') : __('Enable Focus', 'yooadmin');
    $tooltip     = $is_focus_on ? __('Disable YOOAdmin Focus Mode', 'yooadmin') : __('Enable YOOAdmin Focus Mode', 'yooadmin');

    $icon = '<span class="ab-icon yoo-focus-ab-icon" aria-hidden="true">'
        . '<svg class="yoo-focus-ab-svg" viewBox="0 0 20 20" width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg">'
        . '<circle cx="10" cy="10" r="3.25" stroke="currentColor" stroke-width="1.75"></circle>'
        . '<path d="M10 2.25v2.5M10 15.25v2.5M2.25 10h2.5M15.25 10h2.5" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"></path>'
        . '</svg></span>';

    $wp_admin_bar->add_node([
        'id'     => 'yooadmin-focus-toggle',
        'parent' => 'top-secondary',
        'title'  => $icon . '<span class="ab-label">' . esc_html($label_text) . '</span>',
        'href'   => '#yooadmin-focus-toggle',
        'meta'   => [
            'class'    => 'yooadmin-focus-toggle-btn' . ($is_focus_on ? ' yooadmin-focus-active' : ''),
            'title'    => $tooltip,
            'priority' => 5,
        ],
    ]);
}, 5);

add_action('wp_ajax_yooadmin_admin_bar_toggle_focus', function () {
    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'yooadmin_admin_bar_focus')) {
        wp_send_json_error(['message' => __('Security check failed', 'yooadmin')]);
    }

    $can_manage = function_exists('yooadmin_user_can_manage_focus_policy')
        && yooadmin_user_can_manage_focus_policy();
    $pref_cap = function_exists('yooadmin_focus_preference_capability')
        ? yooadmin_focus_preference_capability()
        : 'read';
    $can_preference = current_user_can($pref_cap);

    $scope = isset($_POST['scope']) ? sanitize_text_field(wp_unslash($_POST['scope'])) : 'user';
    $scope = in_array($scope, ['user', 'all'], true) ? $scope : 'user';

    if ($scope === 'all') {
        if (!$can_manage) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')]);
        }
    } elseif (!$can_preference) {
        wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')]);
    }

    $enable = yooadmin_parse_ajax_bool(
        isset($_POST['enable'])
            ? sanitize_text_field(wp_unslash((string) $_POST['enable']))
            : '1',
        true
    );
    $current_policy = function_exists('yooadmin_get_focus_policy')
        ? yooadmin_get_focus_policy()
        : get_option('yooadmin_focus_policy', 'auto');

    $current_url = isset($_POST['current_url']) ? esc_url_raw(wp_unslash($_POST['current_url'])) : '';
    $is_enable_focus_page = (strpos($current_url, 'page=yooadmin-enable-focus') !== false);

    if (!$enable) {
        if ($scope === 'all' && $can_manage) {
            update_option('yooadmin_focus_policy', 'off');
        }

        if (function_exists('yooadmin_save_user_focus_preference')) {
            yooadmin_save_user_focus_preference('off');
        } elseif (function_exists('yooadmin_set_focus_cookie')) {
            yooadmin_set_focus_cookie('off');
        }

        $response = [
            'message' => $scope === 'all'
                ? __('Focus Mode disabled for everyone', 'yooadmin')
                : __('Focus Mode disabled for you', 'yooadmin'),
        ];

        if ($is_enable_focus_page) {
            $response['redirect'] = function_exists('yooadmin_enable_focus_url')
                ? yooadmin_enable_focus_url()
                : admin_url('admin.php?page=yooadmin-enable-focus');
        }

        wp_send_json_success($response);
    }

    if ($scope === 'user' && $current_policy === 'off') {
        wp_send_json_error([
            'message' => __('Cannot enable for user only when policy is "off". Enable for everyone first.', 'yooadmin'),
            'code'    => 'policy_off_user',
        ]);
    }

    if ($scope === 'all' && $can_manage) {
        update_option('yooadmin_focus_policy', 'on');
    }

    if (function_exists('yooadmin_save_user_focus_preference')) {
        yooadmin_save_user_focus_preference('on');
    } elseif (function_exists('yooadmin_set_focus_cookie')) {
        yooadmin_set_focus_cookie('on');
    }

    $response = [
        'message' => $scope === 'all'
            ? __('Focus Mode enabled for everyone', 'yooadmin')
            : __('Focus Mode enabled for you', 'yooadmin'),
        'redirect' => function_exists('yooadmin_focus_home_url')
            ? yooadmin_focus_home_url()
            : admin_url('admin.php?page=yooadmin-dashboard&yoo=on'),
    ];

    wp_send_json_success($response);
});

if (!function_exists('yooadmin_register_focus_alerts_assets')) {
    function yooadmin_register_focus_alerts_assets(): void
    {
        if (wp_script_is('yooadmin-focus-alerts', 'registered')) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir  = plugin_dir_path($base_file);
        $base_url  = plugin_dir_url($base_file);

        $css = $base_dir . 'assets/css/admin/focus-mode-alerts.css';
        if (file_exists($css)) {
            wp_register_style(
                'yooadmin-focus-alerts',
                $base_url . 'assets/css/admin/focus-mode-alerts.css',
                [],
                (string) filemtime($css)
            );
        }

        $js = $base_dir . 'assets/js/admin/focus-mode-alerts.js';
        if (file_exists($js)) {
            wp_register_script(
                'yooadmin-focus-alerts',
                $base_url . 'assets/js/admin/focus-mode-alerts.js',
                [],
                (string) filemtime($js),
                true
            );
        }
    }
}

if (!function_exists('yooadmin_should_enqueue_admin_bar_focus_assets')) {
    function yooadmin_should_enqueue_admin_bar_focus_assets(): bool
    {
        if (!yooadmin_user_can_admin_bar_focus_toggle()) {
            return false;
        }

        if (yooadmin_is_enable_focus_admin_page()) {
            return false;
        }

        if (is_admin()) {
            return true;
        }

        if (wp_doing_ajax() || (function_exists('wp_is_json_request') && wp_is_json_request())) {
            return false;
        }

        if (yooadmin_is_custom_frontend_admin_bar_enabled()) {
            return true;
        }

        return is_admin_bar_showing();
    }
}

function yooadmin_enqueue_admin_bar_focus_assets(): void
{
    if (!yooadmin_should_enqueue_admin_bar_focus_assets()) {
        return;
    }

    if (defined('YOOADMIN_URL') && defined('YOOADMIN_DIR')) {
        $base_url = YOOADMIN_URL;
        $base_dir = YOOADMIN_DIR;
    } else {
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_url  = plugin_dir_url($base_file);
        $base_dir  = plugin_dir_path($base_file);
    }

    yooadmin_register_focus_alerts_assets();
    wp_enqueue_style('yooadmin-focus-alerts');
    wp_enqueue_script('yooadmin-focus-alerts');
    if (function_exists('wp_script_add_data')) {
        wp_script_add_data('yooadmin-focus-alerts', 'strategy', 'defer');
    }
    yooadmin_localize_focus_alerts_script();

    if (function_exists('yooadmin_enqueue_focus_split_modal_assets')) {
        yooadmin_enqueue_focus_split_modal_assets(
            'yooadmin-admin-bar-focus-modal',
            is_admin()
        );
    }

    if (
        function_exists('yooadmin_focus_page_background_image_url')
        && wp_style_is('yooadmin-admin-bar-focus-modal', 'enqueued')
    ) {
        $focus_bg_url = yooadmin_focus_page_background_image_url();
        if ($focus_bg_url !== '') {
            wp_add_inline_style(
                'yooadmin-admin-bar-focus-modal',
                'body.yoo-focus-modal-open{--yoo-focus-modal-bg-image:url(' . esc_url($focus_bg_url) . ');}'
            );
        }
    }

    $css_file = 'assets/css/admin/admin-bar-focus-toggle.css';
    if (file_exists($base_dir . $css_file)) {
        wp_enqueue_style(
            'yooadmin-admin-bar-focus-toggle',
            $base_url . $css_file,
            ['yooadmin-admin-bar-focus-modal'],
            (string) filemtime($base_dir . $css_file)
        );
    }

    $js_file = 'assets/js/admin/admin-bar-focus-toggle.js';
    if (file_exists($base_dir . $js_file)) {
        wp_enqueue_script(
            'yooadmin-admin-bar-focus-toggle',
            $base_url . $js_file,
            ['jquery', 'yooadmin-focus-alerts'],
            (string) filemtime($base_dir . $js_file),
            true
        );
        if (function_exists('wp_script_add_data')) {
            wp_script_add_data('yooadmin-admin-bar-focus-toggle', 'strategy', 'defer');
        }

        wp_localize_script('yooadmin-admin-bar-focus-toggle', 'yooadminAdminBarFocus', [
            'confirm'         => __('Confirm', 'yooadmin'),
            'processing'      => __('Processing...', 'yooadmin'),
            'ajaxUrl'         => admin_url('admin-ajax.php'),
            'focusHomeUrl'    => function_exists('yooadmin_focus_home_url')
                ? yooadmin_focus_home_url()
                : admin_url('admin.php?page=yooadmin-dashboard&yoo=on'),
            'canManagePolicy' => function_exists('yooadmin_user_can_manage_focus_policy')
                && yooadmin_user_can_manage_focus_policy(),
        ]);
    }
}
add_action('admin_enqueue_scripts', 'yooadmin_enqueue_admin_bar_focus_assets', 17);
add_action('wp_enqueue_scripts', 'yooadmin_enqueue_admin_bar_focus_assets', 17);

function yooadmin_render_admin_bar_focus_modal(): void
{
    static $rendered = false;
    if ($rendered) {
        return;
    }

    if (!yooadmin_user_can_admin_bar_focus_toggle()) {
        return;
    }

    if (yooadmin_is_enable_focus_admin_page()) {
        return;
    }

    if (!function_exists('yooadmin_render_focus_split_modal')) {
        return;
    }

    $rendered = true;

    $can_manage = function_exists('yooadmin_user_can_manage_focus_policy')
        && yooadmin_user_can_manage_focus_policy();
    $is_focus_on = function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();
    $nonce       = wp_create_nonce('yooadmin_admin_bar_focus');

    yooadmin_render_focus_split_modal([
        'modal_id'   => 'yoo-admin-bar-focus-modal',
        'intent'     => $is_focus_on ? 'disable' : 'enable',
        'context'    => 'admin_bar',
        'can_manage' => $can_manage,
        'nonce'      => $nonce,
    ]);
}

add_action('admin_footer', 'yooadmin_render_admin_bar_focus_modal');
add_action('wp_footer', 'yooadmin_render_admin_bar_focus_modal');
