<?php
/**
 * YOOAdmin - Plugin action links (plugins page row)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Add custom action links to plugin row in WordPress plugins page.
 * Use English literals here: this filter can run in edge bootstrap paths; WP 6.7+ flags early __() for this domain.
 */
add_filter('plugin_action_links_' . plugin_basename(YOOADMIN_PLUGIN_FILE), function($links) {
    $opts = get_option('yooadmin_options', []);
    $delete_enabled = !empty($opts['delete_data_on_uninstall']);
    
    // Check if Focus Mode is enabled
    $focus_enabled = false;
    if (function_exists('yooadmin_is_focus_enabled')) {
        $focus_enabled = yooadmin_is_focus_enabled();
    }
    
    // Settings link - different behavior based on Focus Mode
    if ($focus_enabled) {
        // Focus Mode ON: direct link to settings page
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('admin.php?page=yooadmin-settings#tab-behavior')),
            'Settings'
        );
    } else {
        // Focus Mode OFF: show popup to enable Focus Mode first
        $settings_link = sprintf(
            '<a href="#" class="yooadmin-enable-focus-link" style="color: #2271b1;">%s</a>',
            'Settings'
        );
    }
    
    // Data Cleanup link - always show (will prompt to enable if disabled)
    $cleanup_link = sprintf(
        '<a href="#" class="yooadmin-data-cleanup-link" data-plugin="yooadmin" data-enabled="%s">%s</a>',
        $delete_enabled ? '1' : '0',
        'Data Cleanup'
    );
    
    // Add links at the beginning
    array_unshift($links, $settings_link);
    array_unshift($links, $cleanup_link);
    
    return $links;
});

/**
 * Enqueue scripts for data cleanup modal on plugins page
 */
add_action('admin_enqueue_scripts', function($hook) {
    // Only load on plugins page
    if ($hook !== 'plugins.php') {
        return;
    }
    
    $opts = get_option('yooadmin_options', []);
    $delete_enabled = !empty($opts['delete_data_on_uninstall']);
    
    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
    $url = plugin_dir_url($base_file);
    $dir = plugin_dir_path($base_file);
    
    // Enqueue data cleanup modal script
    $script_path = $dir . 'assets/js/admin/data-cleanup-modal.js';
    if (file_exists($script_path)) {
        wp_enqueue_script(
            'yooadmin-data-cleanup-modal',
            $url . 'assets/js/admin/data-cleanup-modal.js',
            ['jquery'],
            filemtime($script_path),
            true
        );

        wp_localize_script('yooadmin-data-cleanup-modal', 'yooadmCleanup', [
            'nonce' => wp_create_nonce('yooadmin_data_cleanup'),
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'i18n' => [
                'title' => yooadmin_translate_admin_ui(__('Data Cleanup Confirmation', 'yooadmin')),
                'message' => yooadmin_translate_admin_ui(__('Are you sure you want to delete all YOOAdmin core data from your database? This action cannot be undone.', 'yooadmin')),
                'warning' => yooadmin_translate_admin_ui(__('This will permanently delete:', 'yooadmin')),
                'item1' => yooadmin_translate_admin_ui(__('All plugin settings and preferences (branding, custom login page, behavior, and Focus Mode)', 'yooadmin')),
                'item2' => yooadmin_translate_admin_ui(__('All notifications, activity log, workspace notes, transients, and scheduled cleanup tasks', 'yooadmin')),
                'item3' => yooadmin_translate_admin_ui(__('All YOOAdmin core database tables (notifications, activity, workspace notes, preferences, etc.)', 'yooadmin')),
                'item4' => yooadmin_translate_admin_ui(__('All YOOAdmin user data (2FA, notification preferences, tours, and per-user screen options)', 'yooadmin')),
                'safe' => yooadmin_translate_admin_ui(__('Your WordPress content (posts, pages, comments, media, etc.) will NOT be affected. Plus extensions and other plugins are not included in this cleanup.', 'yooadmin')),
                'confirm' => yooadmin_translate_admin_ui(__('Type "DELETE" to confirm:', 'yooadmin')),
                'deleteButton' => yooadmin_translate_admin_ui(__('Delete All Data', 'yooadmin')),
                'cancelButton' => yooadmin_translate_admin_ui(__('Cancel', 'yooadmin')),
                'processing' => yooadmin_translate_admin_ui(__('Deleting data...', 'yooadmin')),
                'success' => yooadmin_translate_admin_ui(__('All YOOAdmin core data has been successfully deleted.', 'yooadmin')),
                'error' => yooadmin_translate_admin_ui(__('An error occurred while deleting data. Please try again.', 'yooadmin')),
                'typeMismatch' => yooadmin_translate_admin_ui(__('Please type "DELETE" exactly to confirm.', 'yooadmin')),
                'enableTitle' => yooadmin_translate_admin_ui(__('Enable Data Cleanup', 'yooadmin')),
                'enableMessage' => yooadmin_translate_admin_ui(__('Data Cleanup is currently disabled. To prevent accidental data loss, you need to enable "Delete Data on Uninstall" before permanent cleanup actions are allowed.', 'yooadmin')),
                'enableLabel' => yooadmin_translate_admin_ui(__('Delete Data on Uninstall', 'yooadmin')),
                'enableSaveButton' => yooadmin_translate_admin_ui(__('Save & Continue', 'yooadmin')),
            ],
        ]);
    }
    
    // Enqueue styles for modal
    $style_path = $dir . 'assets/css/admin/data-cleanup-modal.css';
    if (file_exists($style_path)) {
        wp_enqueue_style(
            'yooadmin-data-cleanup-modal',
            $url . 'assets/css/admin/data-cleanup-modal.css',
            [],
            filemtime($style_path)
        );
    }
});

/**
 * AJAX handler for data cleanup
 */
add_action('wp_ajax_yooadmin_data_cleanup', function() {
    // Verify nonce
    check_ajax_referer('yooadmin_data_cleanup', 'nonce');
    
    // Check user capabilities
    if (!current_user_can('activate_plugins')) {
        wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'yooadmin')]);
    }
    
    // Check if delete on uninstall is enabled
    $opts = get_option('yooadmin_options', []);
    if (empty($opts['delete_data_on_uninstall'])) {
        wp_send_json_error(['message' => __('Data cleanup is not enabled in settings.', 'yooadmin')]);
    }
    
    // Verify confirmation text
    $confirmation = isset($_POST['confirmation']) ? sanitize_text_field(wp_unslash($_POST['confirmation'])) : '';
    if ($confirmation !== 'DELETE') {
        wp_send_json_error(['message' => __('Invalid confirmation text.', 'yooadmin')]);
    }
    
    // Perform cleanup (shared with uninstall.php; core plugin data only).
    try {
        if (function_exists('yooadmin_purge_core_stored_data')) {
            yooadmin_purge_core_stored_data();
        }

        // Disable Focus Mode so tables don't get recreated on next load
        // Set cookie for future requests
        if (!headers_sent()) {
            setcookie('yoo_focus', 'off', time() + (365 * DAY_IN_SECONDS), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        }
        // Override for current PHP process (AJAX responses may not update browser cookie immediately)
        $_COOKIE['yoo_focus'] = 'off';
        // Persist focus policy as 'off' so storage.php constructor won't recreate tables
        update_option('yooadmin_focus_policy', 'off');

        // 8) Clear object cache
        wp_cache_flush();

        // 9) Reset options bag to defaults (incl. delete_data_on_uninstall off) — same as a fresh install preference.
        $fresh_options = function_exists('yooadmin_default_options') ? yooadmin_default_options() : [];
        if (!is_array($fresh_options)) {
            $fresh_options = [];
        }
        $fresh_options['delete_data_on_uninstall'] = 0;
        update_option('yooadmin_options', $fresh_options);

        // Re-seed admin theme as a fresh install (Studio Hub when available).
        if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
            YOOAdmin_Admin_Theme_Manager::get_instance()->ensure_active_theme();
        }

        wp_send_json_success(['message' => __('All YOOAdmin core data has been successfully deleted.', 'yooadmin')]);
    } catch (Exception $e) {
        wp_send_json_error(['message' => __('An error occurred while deleting data.', 'yooadmin')]);
    }
});

/**
 * AJAX handler to enable delete data on uninstall setting
 */
add_action('wp_ajax_yooadmin_enable_delete_data_setting', function() {
    // Verify nonce
    check_ajax_referer('yooadmin_data_cleanup', 'nonce');
    
    // Check user capabilities
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'yooadmin')]);
    }
    
    // Get current options
    $opts = get_option('yooadmin_options', []);
    
    // Enable delete_data_on_uninstall
    $opts['delete_data_on_uninstall'] = 1;
    
    // Save options
    $result = update_option('yooadmin_options', $opts);
    
    if ($result) {
        wp_send_json_success(['message' => __('Setting enabled successfully.', 'yooadmin')]);
    } else {
        wp_send_json_error(['message' => __('Failed to enable setting. Please try again.', 'yooadmin')]);
    }
});






