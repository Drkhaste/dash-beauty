<?php
/**
 * YOOAdmin core data purge (Data Cleanup + uninstall).
 *
 * Removes YOOAdmin plugin storage only. Does not touch Plus extensions
 * (e.g. yooadmin-backup tables) or other plugins (e.g. yoo-mail-check).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_purge_delete_option_rows_like')) {
    /**
     * @param string $prefix Option name prefix (LIKE prefix%).
     */
    function yooadmin_purge_delete_option_rows_like(string $prefix): void
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentional purge.
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                $wpdb->esc_like($prefix) . '%'
            )
        );
    }
}

if (!function_exists('yooadmin_purge_delete_usermeta_rows_like')) {
    /**
     * @param string $prefix Meta key prefix (LIKE prefix%).
     */
    function yooadmin_purge_delete_usermeta_rows_like(string $prefix): void
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentional purge.
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
                $wpdb->esc_like($prefix) . '%'
            )
        );
    }
}

if (!function_exists('yooadmin_purge_core_stored_data')) {
    /**
     * Delete YOOAdmin core options, transients, tables, user meta, caps, and cron hooks.
     */
    function yooadmin_purge_core_stored_data(): void
    {
        global $wpdb;

        // 1) Options (core + legacy yoopixel / yoopxl prefixes).
        foreach (['yooadmin_', 'yoopixel_', 'yoopxl_'] as $prefix) {
            yooadmin_purge_delete_option_rows_like($prefix);
        }

        // 2) Transients (including site transients used for plugin update checks).
        foreach (
            [
                '_transient_yooadmin_',
                '_transient_timeout_yooadmin_',
                '_transient_yoopixel_',
                '_transient_timeout_yoopixel_',
                '_site_transient_yooadmin_',
                '_site_transient_timeout_yooadmin_',
            ] as $prefix
        ) {
            yooadmin_purge_delete_option_rows_like($prefix);
        }

        // 3) Core custom tables only (not Plus extension tables such as yooadmin_backup_*).
        $tables = [
            $wpdb->prefix . 'yooadmin_notifications',
            $wpdb->prefix . 'yooadmin_user_preferences',
            $wpdb->prefix . 'yooadmin_dismissed_notifications',
            $wpdb->prefix . 'yooadmin_blocked_senders',
            $wpdb->prefix . 'yooadmin_workspace_notes',
            $wpdb->prefix . 'yooadmin_activity',
        ];
        foreach ($tables as $table) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- DROP known core tables.
            $wpdb->query("DROP TABLE IF EXISTS {$table}");
        }

        // 4) User meta — plain keys, private 2FA keys, and prefixed user options.
        foreach (['yooadmin_', 'yoopixel_', '_yooadmin_'] as $prefix) {
            yooadmin_purge_delete_usermeta_rows_like($prefix);
        }
        yooadmin_purge_delete_usermeta_rows_like($wpdb->prefix . 'yooadmin_');

        // 5) Capabilities.
        $roles = wp_roles();
        if ($roles) {
            foreach (array_keys($roles->roles) as $role) {
                $roles->remove_cap($role, 'manage_yooadmin');
                $roles->remove_cap($role, 'manage_yoopixel');
            }
        }

        // 6) Scheduled cron hooks (core only).
        foreach (
            [
                'yooadmin_notifications_restore_snoozed',
                'yooadmin_notifications_cleanup',
                'yooadmin_daily_cleanup',
                'yooadmin_weekly_report',
                'yooadmin_workspace_notes_process_reminders',
            ] as $hook
        ) {
            wp_clear_scheduled_hook($hook);
        }
    }
}
