<?php
/**
 * YOOAdmin - External API guard (license gate)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Check if license is active and external API calls are allowed
 * 
 * @return bool
 */
function yooadmin_can_use_external_api() {
    // Check if license manager exists
    if (!class_exists('YOOAdmin_License_Manager')) {
        return false;
    }
    
    $license_manager = YOOAdmin_License_Manager::get_instance();
    $license_data = $license_manager->get_license_data();
    
    // Only allow external calls if license is active
    return isset($license_data['status']) && $license_data['status'] === 'active';
}

/**
 * Get safe error response when external API is not allowed
 * 
 * @return array
 */
function yooadmin_external_api_blocked_response() {
    return [
        'ok' => false,
        'error' => __('Please activate your license to enable external connected services.', 'yooadmin'),
        'requires_license' => true,
        'license_url' => admin_url('admin.php?page=yooadmin-license'),
        'get_license_url' => 'https://yooadmin.io/portal/register/'
    ];
}

/**
 * Show license activation notice
 */
function yooadmin_show_license_required_notice() {
    if (!yooadmin_can_use_external_api()) {
        ?>
        <div class="notice notice-info yooadmin-license-notice" style="padding: 20px; border-left: 4px solid var(--yp-brand);">
            <h2 style="margin-top: 0;"><?php esc_html_e('Connect Your Account', 'yooadmin'); ?></h2>
            <p><?php esc_html_e('To enable external connected services (YOOAdmin Extended and remote modules), please connect your YOOAdmin account.', 'yooadmin'); ?></p>

            <div style="display: flex; gap: 10px; margin-top: 15px; flex-wrap: wrap;">
                <a href="https://yooadmin.io/portal/register/"
                   class="button button-primary"
                   target="_blank"
                   style="background: var(--yp-brand); border-color: var(--yp-brand);">
                    <?php esc_html_e('Create Free Account', 'yooadmin'); ?>
                </a>

                <a href="<?php echo esc_url(admin_url('admin.php?page=yooadmin-license')); ?>"
                   class="button">
                    <?php esc_html_e('Connect Account', 'yooadmin'); ?>
                </a>
            </div>
            
            <p style="margin: 15px 0 0 0;">
                <small style="color: #666;">
                    <?php esc_html_e('✅ Free license: Download YOOAdmin Extended', 'yooadmin'); ?><br>
                    <?php esc_html_e('✅ No credit card required', 'yooadmin'); ?><br>
                    <?php esc_html_e('✅ Takes 30 seconds to activate', 'yooadmin'); ?>
                    <br><br>
                    <a href="https://yooadmin.io/privacy" target="_blank"><?php esc_html_e('Privacy Policy', 'yooadmin'); ?></a> | 
                    <a href="https://yooadmin.io/terms" target="_blank"><?php esc_html_e('Terms of Service', 'yooadmin'); ?></a>
                </small>
            </p>
        </div>
        <?php
    }
}

/**
 * Block external HTTP requests to yooadmin.io without license
 */
add_filter('pre_http_request', function($preempt, $args, $url) {
    if (strpos($url, 'yooadmin.io') === false) {
        return $preempt;
    }
    
    $allowed_endpoints = [
        '/yoopixel-api/v1/activate',
        '/yoopixel-api/v1/attach-domain-for-activation',
        '/yoopixel-api/v1/get-secret-for-activation',
        '/yoopixel-api/v1/check',
        '/yoopixel-api/v1/refresh-jwt',
        '/yoopixel/v1/activate',
        '/yoopixel/v1/attach-domain-for-activation',
        '/yoopixel/v1/get-secret-for-activation',
        '/yoopixel/v1/check',
        '/yoopixel/v1/refresh-jwt',
        '/yoopixel/v1/login',
        '/yoopixel/v1/panel/session',
    ];
    
    foreach ($allowed_endpoints as $endpoint) {
        if (strpos($url, $endpoint) !== false) {
            return $preempt;
        }
    }
    
    if (yooadmin_can_use_external_api()) {
        return $preempt;
    }
    
    // Plain string: this filter can run before `init`; using __() here triggers WP 6.7+ JIT loading notices.
    return new WP_Error(
        'yooadmin_license_required',
        'External connected services require an active license. Please activate your license first.',
        ['status' => 403]
    );
}, 10, 3);

