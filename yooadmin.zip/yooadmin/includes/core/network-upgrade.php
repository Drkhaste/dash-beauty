<?php
defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_upgrade_page_slug')) {
    function yooadmin_network_upgrade_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_upgrade_page_slug', 'yooadmin-network-upgrade');
    }
}

if (!function_exists('yooadmin_network_upgrade_url')) {
    function yooadmin_network_upgrade_url(array $args = []): string
    {
        $url = network_admin_url('admin.php?page=' . yooadmin_network_upgrade_page_slug());
        if ($args !== []) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_upgrade_classic_url')) {
    function yooadmin_network_upgrade_classic_url(array $args = []): string
    {
        $url = network_admin_url('upgrade.php?yooadmin_no_redirect=1');
        if ($args !== []) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_upgrade_menu_cap')) {
    function yooadmin_network_upgrade_menu_cap(): string
    {
        return (string) apply_filters('yooadmin_network_upgrade_menu_cap', 'read');
    }
}

if (!function_exists('yooadmin_network_upgrade_submenu_cap')) {
    function yooadmin_network_upgrade_submenu_cap(): string
    {
        return 'upgrade_network';
    }
}

if (!function_exists('yooadmin_network_upgrade_user_can_view')) {
    function yooadmin_network_upgrade_user_can_view(): bool
    {
        if (is_multisite() && is_super_admin()) {
            return true;
        }

        return current_user_can('upgrade_network');
    }
}

if (!function_exists('yooadmin_network_upgrade_should_use')) {
    function yooadmin_network_upgrade_should_use(): bool
    {
        if (!is_multisite()) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        $enabled = true;
        if (function_exists('yooadmin_get_option')) {
            $enabled = (bool) yooadmin_get_option('network_upgrade_redirect', true);
        }

        return (bool) apply_filters('yooadmin_network_upgrade_should_use', $enabled);
    }
}

if (!function_exists('yooadmin_network_upgrade_is_screen')) {
    function yooadmin_network_upgrade_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_upgrade_page_slug();
    }
}

if (!function_exists('yooadmin_network_upgrade_maybe_route_before_access')) {
    function yooadmin_network_upgrade_maybe_route_before_access(): void
    {
        if (!is_multisite() || !is_network_admin()) {
            return;
        }
        if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
            return;
        }
        if (!function_exists('yooadmin_network_upgrade_is_screen') || !yooadmin_network_upgrade_is_screen()) {
            return;
        }
        if (function_exists('yooadmin_network_upgrade_should_use') && yooadmin_network_upgrade_should_use()) {
            return;
        }

        wp_safe_redirect(yooadmin_network_upgrade_classic_url());
        exit;
    }

    add_action('network_admin_menu', 'yooadmin_network_upgrade_maybe_route_before_access', 999999);
}
