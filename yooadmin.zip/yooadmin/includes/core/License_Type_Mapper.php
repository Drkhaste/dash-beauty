<?php
/**
 * YOOAdmin - License type mapper (key ↔ display name)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

namespace YOOAdmin\Core;

if (!defined('ABSPATH')) {
    exit;
}

class YOOAdmin_License_Type_Mapper {
    
    /**
     * Get Type Key from Name (case-insensitive, handles variations)
     * 
     * @param string $name License name (e.g., "PRO-PLUS", "Pro Plus", "pro-plus")
     * @return string|null Type Key (e.g., "plus") or null if not found
     */
    public static function get_type_key_from_name($name) {
        if (empty($name)) {
            return null;
        }
        
        yooadmin_bust_license_type_option_caches();
        $all_license_types = yooadmin_get_effective_license_types();
        
        // Normalize input name
        $normalized_name = strtolower(trim($name));
        $normalized_name = str_replace(['-', '_', ' '], '', $normalized_name);
        
        // First, try exact match (case-insensitive)
        foreach ($all_license_types as $type_key => $type_config) {
            $type_name = isset($type_config['name']) ? strtolower(trim($type_config['name'])) : '';
            $normalized_type_name = str_replace(['-', '_', ' '], '', $type_name);
            
            // Match by name
            if ($normalized_type_name === $normalized_name) {
                return $type_key; // Return Type Key
            }
            
            // Also check if name matches type_key
            $normalized_type_key = str_replace(['-', '_', ' '], '', strtolower($type_key));
            if ($normalized_type_key === $normalized_name) {
                return $type_key; // Return Type Key
            }
        }
        
        return null;
    }
    
    /**
     * Get Name from Type Key
     * 
     * @param string $type_key Type Key (e.g., "plus")
     * @return string|null Name (e.g., "PRO-PLUS") or null if not found
     */
    public static function get_name_from_type_key($type_key) {
        if (empty($type_key)) {
            return null;
        }
        
        yooadmin_bust_license_type_option_caches();
        $all_license_types = yooadmin_get_effective_license_types();
        
        // Normalize type_key for lookup
        $normalized_key = strtolower(trim($type_key));
        
        // Find matching type key (case-insensitive)
        foreach ($all_license_types as $key => $type_config) {
            if (strtolower($key) === $normalized_key) {
                return isset($type_config['name']) ? $type_config['name'] : ucfirst($type_key);
            }
        }
        
        return null;
    }
    
    /**
     * Normalize license identifier to Type Key
     * Accepts either Type Key or Name and returns Type Key
     * 
     * @param string $identifier Type Key or Name
     * @return string|null Type Key or null if not found
     */
    public static function normalize_to_type_key($identifier) {
        if (empty($identifier)) {
            return null;
        }
        
        yooadmin_bust_license_type_option_caches();
        $all_license_types = yooadmin_get_effective_license_types();
        
        $normalized = strtolower(trim($identifier));
        
        // First, check if it's already a valid type key
        foreach ($all_license_types as $type_key => $type_config) {
            if (strtolower($type_key) === $normalized) {
                return $type_key; // Return original key (preserves case from DB)
            }
        }
        
        // If not found as type key, try to find by name
        return self::get_type_key_from_name($identifier);
    }
    
    /**
     * Check if two license identifiers refer to the same license
     * 
     * @param string $identifier1 Type Key or Name
     * @param string $identifier2 Type Key or Name
     * @return bool True if they refer to the same license
     */
    public static function are_same_license($identifier1, $identifier2) {
        if (empty($identifier1) || empty($identifier2)) {
            return false;
        }
        
        $key1 = self::normalize_to_type_key($identifier1);
        $key2 = self::normalize_to_type_key($identifier2);
        
        if ($key1 === null || $key2 === null) {
            return false;
        }
        
        return strtolower($key1) === strtolower($key2);
    }
}








