<?php
/**
 * YOOAdmin network dashboard (multisite + Focus Mode).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

const YOOADMIN_NETWORK_DASHBOARD_LAYOUT_META = 'yooadmin_network_dashboard_layout_v1';
const YOOADMIN_NETWORK_DASHBOARD_LAYOUT_VER  = 1;

if (!function_exists('yooadmin_network_dashboard_text_domain')) {
    function yooadmin_network_dashboard_text_domain(): string
    {
        return 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_dashboard_slug')) {
    function yooadmin_network_dashboard_slug(): string
    {
        return (string) apply_filters('yooadmin_network_dashboard_page_slug', 'yooadmin-network-dashboard');
    }
}

if (!function_exists('yooadmin_network_dashboard_url')) {
    function yooadmin_network_dashboard_url(): string
    {
        if (function_exists('yooadmin_network_dashboard_should_use') && !yooadmin_network_dashboard_should_use()) {
            return network_admin_url('index.php');
        }

        return network_admin_url('admin.php?page=' . yooadmin_network_dashboard_slug());
    }
}

if (!function_exists('yooadmin_network_dashboard_is_screen')) {
    function yooadmin_network_dashboard_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_dashboard_slug();
    }
}

if (!function_exists('yooadmin_network_dashboard_focus_on')) {
    function yooadmin_network_dashboard_focus_on(): bool
    {
        if (function_exists('yooadmin_is_focus_enabled')) {
            return (bool) yooadmin_is_focus_enabled();
        }

        return true;
    }
}

if (!function_exists('yooadmin_network_dashboard_redirect_enabled')) {
    function yooadmin_network_dashboard_redirect_enabled(): bool
    {
        if (function_exists('yooadmin_get_option')) {
            $enabled = yooadmin_get_option('redirect_network_dashboard', true);
        } else {
            $opts    = (array) get_option('yooadmin_options', []);
            $enabled = array_key_exists('redirect_network_dashboard', $opts)
                ? !empty($opts['redirect_network_dashboard'])
                : true;
        }

        return (bool) apply_filters('yooadmin_redirect_network_dashboard', $enabled);
    }
}

if (!function_exists('yooadmin_network_dashboard_should_use')) {
    function yooadmin_network_dashboard_should_use(): bool
    {
        if (!is_multisite() || !is_user_logged_in()) {
            return false;
        }

        if (!yooadmin_network_dashboard_focus_on()) {
            return false;
        }

        return (bool) apply_filters('yooadmin_network_dashboard_should_use', true);
    }
}

if (!function_exists('yooadmin_network_dashboard_maybe_route_before_access')) {
    function yooadmin_network_dashboard_maybe_route_before_access(): void
    {
        if (!is_multisite() || !is_network_admin()) {
            return;
        }
        if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
            return;
        }
        if (
            !function_exists('yooadmin_network_dashboard_is_screen')
            || !yooadmin_network_dashboard_is_screen()
        ) {
            return;
        }
        if (
            function_exists('yooadmin_network_dashboard_should_use')
            && yooadmin_network_dashboard_should_use()
        ) {
            return;
        }

        wp_safe_redirect(network_admin_url('index.php'));
        exit;
    }

    add_action('network_admin_menu', 'yooadmin_network_dashboard_maybe_route_before_access', 999999);
}

if (!function_exists('yooadmin_network_dashboard_layout_defaults')) {
    function yooadmin_network_dashboard_layout_defaults(): array
    {
        return [
            'version'                => YOOADMIN_NETWORK_DASHBOARD_LAYOUT_VER,
            'mainOrder'              => ['network-workspace', 'network-sites'],
            'asideOrder'             => ['network-overview', 'network-workspace-notes', 'network-tips'],
            'hidden'                 => [],
            'hiddenSections'         => [],
            'hiddenSectionsExplicit' => true,
        ];
    }
}

if (!function_exists('yooadmin_network_dashboard_core_main_sections')) {
    /**
     * @return string[]
     */
    function yooadmin_network_dashboard_core_main_sections(): array
    {
        return ['network-workspace', 'network-sites'];
    }
}

if (!function_exists('yooadmin_network_dashboard_core_aside_sections')) {
    /**
     * @return string[]
     */
    function yooadmin_network_dashboard_core_aside_sections(): array
    {
        return ['network-overview', 'network-workspace-notes', 'network-tips'];
    }
}

if (!function_exists('yooadmin_network_dashboard_extract_dynamic_sections')) {
    /**
     * @param array<string, mixed> $payload
     * @return array{main: string[], aside: string[]}
     */
    function yooadmin_network_dashboard_extract_dynamic_sections(array $payload): array
    {
        $main  = [];
        $aside = [];

        foreach (['customSections', 'widgetSections'] as $key) {
            if (empty($payload[ $key ]) || !is_array($payload[ $key ])) {
                continue;
            }
            foreach ($payload[ $key ] as $section_id => $meta) {
                if (!is_array($meta)) {
                    continue;
                }
                if (
                    $key === 'widgetSections'
                    && function_exists('yooadmin_dashboard_card_allowed_in_context')
                ) {
                    $widget_id = isset($meta['widgetId']) ? sanitize_key((string) $meta['widgetId']) : '';
                    if ($widget_id === '' || ! yooadmin_dashboard_card_allowed_in_context($widget_id, 'network')) {
                        continue;
                    }
                }
                $section_id = sanitize_key((string) $section_id);
                if ($section_id === '') {
                    continue;
                }
                $placement = isset($meta['placement']) && $meta['placement'] === 'aside' ? 'aside' : 'main';
                if ($placement === 'aside') {
                    $aside[] = $section_id;
                } else {
                    $main[] = $section_id;
                }
            }
        }

        return [
            'main'  => array_values(array_unique($main)),
            'aside' => array_values(array_unique($aside)),
        ];
    }
}

if (!function_exists('yooadmin_network_dashboard_allowed_section_ids')) {
    /**
     * @param array<string, mixed> $payload
     * @return array{main: string[], aside: string[]}
     */
    function yooadmin_network_dashboard_allowed_section_ids(array $payload): array
    {
        $dynamic = yooadmin_network_dashboard_extract_dynamic_sections($payload);

        return [
            'main'  => array_values(array_unique(array_merge(yooadmin_network_dashboard_core_main_sections(), $dynamic['main']))),
            'aside' => array_values(array_unique(array_merge(yooadmin_network_dashboard_core_aside_sections(), $dynamic['aside']))),
        ];
    }
}

if (!function_exists('yooadmin_network_dashboard_normalize_layout')) {
    function yooadmin_network_dashboard_normalize_layout($payload): ?array
    {
        if (!is_array($payload) || (int) ($payload['version'] ?? 0) !== YOOADMIN_NETWORK_DASHBOARD_LAYOUT_VER) {
            return null;
        }

        $allowed = yooadmin_network_dashboard_allowed_section_ids($payload);
        $allowed_main  = array_fill_keys($allowed['main'], true);
        $allowed_aside = array_fill_keys($allowed['aside'], true);

        $main = [];
        if (!empty($payload['mainOrder']) && is_array($payload['mainOrder'])) {
            foreach ($payload['mainOrder'] as $id) {
                $id = sanitize_key((string) $id);
                if ($id !== '' && isset($allowed_main[ $id ]) && !in_array($id, $main, true)) {
                    $main[] = $id;
                }
            }
        }
        foreach (yooadmin_network_dashboard_core_main_sections() as $id) {
            if (!in_array($id, $main, true)) {
                $main[] = $id;
            }
        }
        foreach ($allowed['main'] as $id) {
            if (!in_array($id, $main, true)) {
                $main[] = $id;
            }
        }

        $aside = [];
        if (!empty($payload['asideOrder']) && is_array($payload['asideOrder'])) {
            foreach ($payload['asideOrder'] as $id) {
                $id = sanitize_key((string) $id);
                if ($id !== '' && isset($allowed_aside[ $id ]) && !in_array($id, $aside, true)) {
                    $aside[] = $id;
                }
            }
        }
        foreach (yooadmin_network_dashboard_core_aside_sections() as $id) {
            if (!in_array($id, $aside, true)) {
                $aside[] = $id;
            }
        }
        foreach ($allowed['aside'] as $id) {
            if (!in_array($id, $aside, true)) {
                $aside[] = $id;
            }
        }

        $hidden = [];
        if (!empty($payload['hiddenSections']) && is_array($payload['hiddenSections'])) {
            foreach ($payload['hiddenSections'] as $id) {
                $id = sanitize_key((string) $id);
                if ($id !== '') {
                    $hidden[] = $id;
                }
            }
        }

        $main_column_locked_ids = ['network-workspace', 'network-sites'];
        $aside                  = array_values(
            array_filter(
                $aside,
                static function ($id) use ($main_column_locked_ids) {
                    return ! in_array($id, $main_column_locked_ids, true);
                }
            )
        );

        if (! in_array('network-workspace', $main, true)) {
            array_unshift($main, 'network-workspace');
        } else {
            $main = array_values(
                array_unique(
                    array_merge(['network-workspace'], array_diff($main, ['network-workspace']))
                )
            );
        }

        if (! in_array('network-sites', $main, true)) {
            $workspace_index = array_search('network-workspace', $main, true);
            if ($workspace_index !== false) {
                array_splice($main, (int) $workspace_index + 1, 0, ['network-sites']);
            } else {
                $main[] = 'network-sites';
            }
        } else {
            $main = array_values(array_diff($main, ['network-sites']));
            $workspace_index = array_search('network-workspace', $main, true);
            if ($workspace_index !== false) {
                array_splice($main, (int) $workspace_index + 1, 0, ['network-sites']);
            } else {
                $main[] = 'network-sites';
            }
        }

        $workspace_main_id = 'network-workspace';
        $hidden            = array_values(
            array_filter(
                $hidden,
                static function ($id) use ($workspace_main_id) {
                    return $id !== $workspace_main_id;
                }
            )
        );

        $layout = [
            'version'                => YOOADMIN_NETWORK_DASHBOARD_LAYOUT_VER,
            'mainOrder'              => array_values(array_unique($main)),
            'asideOrder'             => array_values(array_unique($aside)),
            'hiddenSections'         => array_values(array_unique($hidden)),
            'hiddenSectionsExplicit' => !empty($payload['hiddenSectionsExplicit']),
            'savedAt'                => isset($payload['savedAt']) ? (int) $payload['savedAt'] : time(),
        ];

        if (isset($payload['cards']) && is_array($payload['cards'])) {
            $cards              = [];
            $core_card_sections = function_exists('yooadmin_network_dashboard_core_card_sections')
                ? yooadmin_network_dashboard_core_card_sections()
                : ['network-workspace', 'network-sites'];
            foreach ($payload['cards'] as $section_id => $card_ids) {
                $section_id = sanitize_key((string) $section_id);
                if ($section_id === '' || !is_array($card_ids)) {
                    continue;
                }
                $card_ids = array_values(
                    array_filter(
                        array_map(
                            static function ($card_id) {
                                $card_id = sanitize_text_field((string) $card_id);
                                return $card_id !== '' ? $card_id : null;
                            },
                            $card_ids
                        )
                    )
                );
                if (!$card_ids && in_array($section_id, $core_card_sections, true)) {
                    continue;
                }
                $cards[ $section_id ] = $card_ids;
            }
            if ($cards) {
                $layout['cards'] = $cards;
            }
        }

        if (isset($payload['sectionIcons']) && is_array($payload['sectionIcons'])) {
            $icons = [];
            foreach ($payload['sectionIcons'] as $section_id => $icon) {
                $section_id = sanitize_key((string) $section_id);
                $icon       = sanitize_text_field((string) $icon);
                if ($section_id !== '' && $icon !== '') {
                    $icons[ $section_id ] = $icon;
                }
            }
            if ($icons) {
                $layout['sectionIcons'] = $icons;
            }
        }

        if (isset($payload['customSections']) && is_array($payload['customSections'])) {
            $sections = [];
            foreach ($payload['customSections'] as $section_id => $meta) {
                $section_id = sanitize_key((string) $section_id);
                if ($section_id === '' || !is_array($meta)) {
                    continue;
                }
                $placement = isset($meta['placement']) && $meta['placement'] === 'aside' ? 'aside' : 'main';
                $sections[ $section_id ] = [
                    'placement' => $placement,
                    'title'     => isset($meta['title']) ? sanitize_text_field((string) $meta['title']) : '',
                    'icon'      => isset($meta['icon']) ? sanitize_text_field((string) $meta['icon']) : '',
                ];
            }
            if ($sections) {
                $layout['customSections'] = $sections;
            }
        }

        if (isset($payload['widgetSections']) && is_array($payload['widgetSections'])) {
            $widgets = [];
            foreach ($payload['widgetSections'] as $section_id => $meta) {
                $section_id = sanitize_key((string) $section_id);
                if ($section_id === '' || !is_array($meta)) {
                    continue;
                }
                $widget_id = isset($meta['widgetId']) ? sanitize_key((string) $meta['widgetId']) : '';
                if ($widget_id === '') {
                    continue;
                }
                if (
                    function_exists('yooadmin_dashboard_card_allowed_in_context')
                    && ! yooadmin_dashboard_card_allowed_in_context($widget_id, 'network')
                ) {
                    continue;
                }
                $placement = isset($meta['placement']) && $meta['placement'] === 'aside' ? 'aside' : 'main';
                $widgets[ $section_id ] = [
                    'placement' => $placement,
                    'widgetId'  => $widget_id,
                    'title'     => isset($meta['title']) ? sanitize_text_field((string) $meta['title']) : '',
                    'icon'      => isset($meta['icon']) ? sanitize_text_field((string) $meta['icon']) : '',
                ];
            }
            if ($widgets) {
                $layout['widgetSections'] = $widgets;
            }
        }

        if (!empty($layout['cards']) && is_array($layout['cards'])) {
            $core_card_sections = yooadmin_network_dashboard_core_card_sections();
            foreach ($core_card_sections as $core_section_id) {
                if (
                    isset($layout['cards'][ $core_section_id ])
                    && is_array($layout['cards'][ $core_section_id ])
                    && !$layout['cards'][ $core_section_id ]
                ) {
                    unset($layout['cards'][ $core_section_id ]);
                }
            }
            if (!$layout['cards']) {
                unset($layout['cards']);
            }
        }

        return $layout;
    }
}

if (!function_exists('yooadmin_network_dashboard_get_user_layout')) {
    function yooadmin_network_dashboard_get_user_layout(int $user_id = 0): ?array
    {
        if ($user_id <= 0) {
            $user_id = get_current_user_id();
        }
        if ($user_id <= 0) {
            return null;
        }

        $stored = get_user_meta($user_id, YOOADMIN_NETWORK_DASHBOARD_LAYOUT_META, true);

        return yooadmin_network_dashboard_normalize_layout($stored);
    }
}

if (!function_exists('yooadmin_network_dashboard_delete_user_layout')) {
    function yooadmin_network_dashboard_delete_user_layout(int $user_id = 0): bool
    {
        if ($user_id <= 0) {
            $user_id = get_current_user_id();
        }
        if ($user_id <= 0) {
            return false;
        }

        return (bool) delete_user_meta($user_id, YOOADMIN_NETWORK_DASHBOARD_LAYOUT_META);
    }
}

if (!function_exists('yooadmin_network_dashboard_save_user_layout')) {
    function yooadmin_network_dashboard_save_user_layout(array $payload, int $user_id = 0): bool
    {
        if ($user_id <= 0) {
            $user_id = get_current_user_id();
        }
        if ($user_id <= 0) {
            return false;
        }

        $layout = yooadmin_network_dashboard_normalize_layout($payload);
        if (!$layout) {
            return false;
        }

        $layout['savedAt'] = time();

        return (bool) update_user_meta($user_id, YOOADMIN_NETWORK_DASHBOARD_LAYOUT_META, $layout);
    }
}

if (!function_exists('yooadmin_network_dashboard_section_hidden')) {
    function yooadmin_network_dashboard_section_hidden(string $section_id, ?array $layout = null): bool
    {
        if (sanitize_key($section_id) === 'network-workspace') {
            return false;
        }

        if (!$layout) {
            $layout = yooadmin_network_dashboard_get_user_layout();
        }
        if (!$layout) {
            return false;
        }

        $hidden = isset($layout['hiddenSections']) && is_array($layout['hiddenSections'])
            ? $layout['hiddenSections']
            : [];

        return in_array(sanitize_key($section_id), $hidden, true);
    }
}

if (!function_exists('yooadmin_network_dashboard_section_hidden_attrs')) {
    function yooadmin_network_dashboard_section_hidden_attrs(string $section_id, ?array $layout = null): string
    {
        if (!yooadmin_network_dashboard_section_hidden($section_id, $layout)) {
            return '';
        }

        return ' data-section-hidden="true" class="is-dashboard-section-hidden"';
    }
}

if (!function_exists('yooadmin_network_dashboard_resolve_main_order')) {
    function yooadmin_network_dashboard_resolve_main_order(?array $layout): array
    {
        $defaults = yooadmin_network_dashboard_layout_defaults()['mainOrder'];
        if (!$layout) {
            return $defaults;
        }

        $allowed = yooadmin_network_dashboard_allowed_section_ids($layout);
        $allowed_set = array_fill_keys($allowed['main'], true);
        $saved       = isset($layout['mainOrder']) && is_array($layout['mainOrder']) ? $layout['mainOrder'] : [];
        $out         = [];

        foreach ($saved as $id) {
            $id = sanitize_key((string) $id);
            if ($id !== '' && isset($allowed_set[ $id ]) && !in_array($id, $out, true)) {
                $out[] = $id;
            }
        }

        foreach ($defaults as $id) {
            if (!in_array($id, $out, true)) {
                $out[] = $id;
            }
        }

        foreach ($allowed['main'] as $id) {
            if (!in_array($id, $out, true)) {
                $out[] = $id;
            }
        }

        return $out;
    }
}

if (!function_exists('yooadmin_network_dashboard_resolve_aside_order')) {
    function yooadmin_network_dashboard_resolve_aside_order(?array $layout): array
    {
        $defaults = yooadmin_network_dashboard_layout_defaults()['asideOrder'];
        if (!$layout) {
            return $defaults;
        }

        $allowed = yooadmin_network_dashboard_allowed_section_ids($layout);
        $allowed_set = array_fill_keys($allowed['aside'], true);
        $saved       = isset($layout['asideOrder']) && is_array($layout['asideOrder']) ? $layout['asideOrder'] : [];
        $out         = [];

        foreach ($saved as $id) {
            $id = sanitize_key((string) $id);
            if ($id !== '' && isset($allowed_set[ $id ]) && !in_array($id, $out, true)) {
                $out[] = $id;
            }
        }

        foreach ($defaults as $id) {
            if (!in_array($id, $out, true)) {
                $out[] = $id;
            }
        }

        foreach ($allowed['aside'] as $id) {
            if (!in_array($id, $out, true)) {
                $out[] = $id;
            }
        }

        return $out;
    }
}

if (!function_exists('yooadmin_network_dashboard_should_collapse_aside')) {
    function yooadmin_network_dashboard_should_collapse_aside(?array $layout): bool
    {
        if (!$layout) {
            return false;
        }

        $aside_order = yooadmin_network_dashboard_resolve_aside_order($layout);
        foreach ($aside_order as $section_id) {
            if (!yooadmin_network_dashboard_section_hidden($section_id, $layout)) {
                return false;
            }
        }

        return $aside_order !== [];
    }
}

if (!function_exists('yooadmin_network_dashboard_menu_url')) {
    function yooadmin_network_dashboard_menu_url(string $slug): string
    {
        if (function_exists('yooadmin_resolve_admin_menu_slug_to_url')) {
            return yooadmin_resolve_admin_menu_slug_to_url($slug, 'network_admin_url');
        }

        $slug = trim($slug);
        if ($slug === '') {
            return network_admin_url();
        }
        if (strpos($slug, '/') !== false) {
            return network_admin_url('admin.php?page=' . $slug);
        }
        if (stripos($slug, 'admin.php') === 0 || strpos($slug, '.php') !== false) {
            return network_admin_url($slug);
        }

        return network_admin_url('admin.php?page=' . $slug);
    }
}

if (!function_exists('yooadmin_network_dashboard_core_menu_items')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_dashboard_core_menu_items(): array
    {
        $defs = [
            [
                'title' => __('Dashboard', 'yooadmin'),
                'slug'  => yooadmin_network_dashboard_slug(),
                'url'   => yooadmin_network_dashboard_url(),
                'icon'  => 'dashicons-dashboard',
                'cap'   => 'manage_network',
            ],
            [
                'title' => __('Sites', 'yooadmin'),
                'slug'  => 'sites.php',
                'url'   => function_exists('yooadmin_network_sites_manager_url')
                    ? yooadmin_network_sites_manager_url()
                    : network_admin_url('sites.php'),
                'icon'  => 'dashicons-admin-multisite',
                'cap'   => 'manage_sites',
            ],
            [
                'title' => __('Users', 'yooadmin'),
                'slug'  => 'users.php',
                'url'   => network_admin_url('users.php'),
                'icon'  => 'dashicons-admin-users',
                'cap'   => 'manage_network_users',
            ],
            [
                'title' => __('Themes', 'yooadmin'),
                'slug'  => 'themes.php',
                'url'   => network_admin_url('themes.php'),
                'icon'  => 'dashicons-admin-appearance',
                'cap'   => 'manage_network_themes',
            ],
            [
                'title' => __('Plugins', 'yooadmin'),
                'slug'  => 'plugins.php',
                'url'   => network_admin_url('plugins.php'),
                'icon'  => 'dashicons-admin-plugins',
                'cap'   => 'manage_network_plugins',
            ],
            [
                'title' => __('Settings', 'yooadmin'),
                'slug'  => 'settings.php',
                'url'   => function_exists('yooadmin_network_settings_manager_url')
                    ? yooadmin_network_settings_manager_url()
                    : network_admin_url('settings.php'),
                'icon'  => 'dashicons-admin-settings',
                'cap'   => 'manage_network_options',
            ],
        ];

        $out = [];
        foreach ($defs as $def) {
            $cap = isset($def['cap']) ? (string) $def['cap'] : '';
            if ($cap !== '' && !current_user_can($cap)) {
                continue;
            }

            $out[] = [
                'title'   => (string) $def['title'],
                'slug'    => (string) $def['slug'],
                'url'     => (string) $def['url'],
                'icon'    => (string) $def['icon'],
                'has_sub' => false,
                'subs'    => [],
            ];
        }

        return $out;
    }
}

if (!function_exists('yooadmin_network_dashboard_minimum_menu_items')) {
    /**
     * Last-resort workspace tiles when no network menu entries match the current user.
     *
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_dashboard_minimum_menu_items(): array
    {
        if (!is_user_logged_in() || !current_user_can('read')) {
            return [];
        }

        $out = [];

        if (function_exists('yooadmin_network_dashboard_url')) {
            $out[] = [
                'title'   => __('Dashboard', 'yooadmin'),
                'slug'    => yooadmin_network_dashboard_slug(),
                'url'     => yooadmin_network_dashboard_url(),
                'icon'    => 'dashicons-dashboard',
                'has_sub' => false,
                'subs'    => [],
            ];
        }

        if (current_user_can('manage_sites')) {
            $sites_url = function_exists('yooadmin_network_sites_manager_url')
                ? yooadmin_network_sites_manager_url()
                : network_admin_url('sites.php');
            $out[] = [
                'title'   => __('Sites', 'yooadmin'),
                'slug'    => 'sites.php',
                'url'     => $sites_url,
                'icon'    => 'dashicons-admin-multisite',
                'has_sub' => false,
                'subs'    => [],
            ];
        }

        if (current_user_can('manage_network_users')) {
            $out[] = [
                'title'   => __('Users', 'yooadmin'),
                'slug'    => 'users.php',
                'url'     => network_admin_url('users.php'),
                'icon'    => 'dashicons-admin-users',
                'has_sub' => false,
                'subs'    => [],
            ];
        }

        if (current_user_can('manage_network_options')) {
            $settings_url = function_exists('yooadmin_network_settings_manager_url')
                ? yooadmin_network_settings_manager_url()
                : network_admin_url('settings.php');
            $out[] = [
                'title'   => __('Network Settings', 'yooadmin'),
                'slug'    => 'settings.php',
                'url'     => $settings_url,
                'icon'    => 'dashicons-admin-settings',
                'has_sub' => false,
                'subs'    => [],
            ];
        }

        return $out;
    }
}

if (!function_exists('yooadmin_network_dashboard_core_card_sections')) {
    /**
     * Built-in dashboard sections whose card order should not be saved empty.
     *
     * @return string[]
     */
    function yooadmin_network_dashboard_core_card_sections(): array
    {
        return ['network-workspace', 'network-sites'];
    }
}

if (!function_exists('yooadmin_network_dashboard_can_build_menu_tree')) {
    function yooadmin_network_dashboard_can_build_menu_tree(): bool
    {
        if (!is_multisite() || !is_user_logged_in()) {
            return false;
        }

        if (is_network_admin()) {
            return true;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_dashboard_slug();
    }
}

if (!function_exists('yooadmin_network_dashboard_merge_menu_tree')) {
    /**
     * @param array<int, array<string, mixed>> $primary
     * @param array<int, array<string, mixed>> $fallback
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_dashboard_merge_menu_tree(array $primary, array $fallback): array
    {
        $merged = [];
        $seen   = [];

        foreach (array_merge($primary, $fallback) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $slug = isset($item['slug']) ? (string) $item['slug'] : '';
            $url  = isset($item['url']) ? (string) $item['url'] : '';
            $key  = $slug !== '' ? $slug : $url;
            if ($key === '' || isset($seen[ $key ])) {
                continue;
            }

            $seen[ $key ] = true;
            $merged[]       = $item;
        }

        return $merged;
    }
}

if (!function_exists('yooadmin_network_dashboard_default_menu_subs')) {
    /**
     * Fallback submenu items when the global $submenu is not populated yet.
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_network_dashboard_default_menu_subs(string $slug): array
    {
        $defs = [
            'index.php' => [
                [
                    'title' => __('Updates', 'yooadmin'),
                    'slug'  => (
                        function_exists('yooadmin_network_update_center_should_use') && yooadmin_network_update_center_should_use()
                        && function_exists('yooadmin_network_update_center_page_slug')
                    ) ? yooadmin_network_update_center_page_slug() : 'update-core.php',
                    'cap'   => 'update_core',
                ],
            ],
            'sites.php' => [
                [
                    'title' => __('All Sites', 'yooadmin'),
                    'slug'  => (function_exists('yooadmin_network_sites_should_use') && yooadmin_network_sites_should_use() && function_exists('yooadmin_network_sites_page_slug'))
                        ? yooadmin_network_sites_page_slug()
                        : 'sites.php',
                    'cap'   => 'manage_sites',
                ],
                [
                    'title' => __('Add Site', 'yooadmin'),
                    'slug'  => (function_exists('yooadmin_network_site_new_should_use') && yooadmin_network_site_new_should_use() && function_exists('yooadmin_network_site_new_page_slug'))
                        ? yooadmin_network_site_new_page_slug()
                        : 'site-new.php',
                    'cap'   => 'create_sites',
                ],
            ],
            'users.php' => [
                [
                    'title' => __('All Users', 'yooadmin'),
                    'slug'  => 'users.php',
                    'cap'   => 'manage_network_users',
                ],
                [
                    'title' => __('Add User', 'yooadmin'),
                    'slug'  => 'user-new.php',
                    'cap'   => 'create_users',
                ],
            ],
            'themes.php' => [
                [
                    'title' => __('Installed Themes', 'yooadmin'),
                    'slug'  => 'themes.php',
                    'cap'   => 'manage_network_themes',
                ],
                [
                    'title' => __('Add Theme', 'yooadmin'),
                    'slug'  => 'theme-install.php',
                    'cap'   => 'install_themes',
                ],
                [
                    'title' => __('Theme File Editor', 'yooadmin'),
                    'slug'  => 'theme-editor.php',
                    'cap'   => 'edit_themes',
                ],
            ],
            'plugins.php' => [
                [
                    'title' => __('Installed Plugins', 'yooadmin'),
                    'slug'  => 'plugins.php',
                    'cap'   => 'manage_network_plugins',
                ],
                [
                    'title' => __('Add Plugin', 'yooadmin'),
                    'slug'  => 'plugin-install.php',
                    'cap'   => 'install_plugins',
                ],
                [
                    'title' => __('Plugin File Editor', 'yooadmin'),
                    'slug'  => 'plugin-editor.php',
                    'cap'   => 'edit_plugins',
                ],
            ],
            'settings.php' => [
                [
                    'title' => __('Network Settings', 'yooadmin'),
                    'slug'  => (
                        function_exists('yooadmin_network_settings_should_use') && yooadmin_network_settings_should_use()
                        && function_exists('yooadmin_network_settings_page_slug')
                    ) ? yooadmin_network_settings_page_slug() : 'settings.php',
                    'cap'   => 'manage_network_options',
                ],
                [
                    'title' => __('Network Setup', 'yooadmin'),
                    'slug'  => 'setup.php',
                    'cap'   => 'setup_network',
                ],
            ],
        ];

        if (!isset($defs[ $slug ]) || !is_array($defs[ $slug ])) {
            return [];
        }

        $subs = [];
        foreach ($defs[ $slug ] as $def) {
            $cap = isset($def['cap']) ? (string) $def['cap'] : '';
            if ($cap !== '' && !current_user_can($cap)) {
                continue;
            }

            $sub_slug = isset($def['slug']) ? (string) $def['slug'] : '';
            if ($sub_slug === '') {
                continue;
            }

            $subs[] = [
                'title' => (string) ($def['title'] ?? ''),
                'url'   => yooadmin_network_dashboard_menu_url($sub_slug),
                'slug'  => $sub_slug,
            ];
        }

        return $subs;
    }
}

if (!function_exists('yooadmin_network_dashboard_build_menu_subs')) {
    /**
     * @return array<int, array<string, string>>
     */
    function yooadmin_network_dashboard_build_menu_subs(string $slug): array
    {
        global $submenu;

        $lookup_slug = $slug;
        if (
            function_exists('yooadmin_network_dashboard_slug')
            && $slug === yooadmin_network_dashboard_slug()
        ) {
            $lookup_slug = 'index.php';
        }

        if ($lookup_slug !== '' && isset($submenu[ $lookup_slug ]) && is_array($submenu[ $lookup_slug ])) {
            $subs = [];
            foreach ($submenu[ $lookup_slug ] as $sm) {
                    $sub_title = isset($sm[0]) ? trim(wp_strip_all_tags((string) $sm[0])) : '';
                    $sub_cap   = isset($sm[1]) ? (string) $sm[1] : '';
                    $sub_slug  = isset($sm[2]) ? (string) $sm[2] : '';
                    if ($sub_title === '' || $sub_slug === '') {
                        continue;
                    }
                    if ($sub_cap && !current_user_can($sub_cap)) {
                        continue;
                    }
                    $subs[] = [
                        'title' => $sub_title,
                        'url'   => yooadmin_network_dashboard_menu_url($sub_slug),
                        'slug'  => $sub_slug,
                    ];
                }

            if ($subs) {
                if (function_exists('yooadmin_network_dashboard_normalize_menu_subs')) {
                    $subs = yooadmin_network_dashboard_normalize_menu_subs($subs, $lookup_slug);
                }

                return $subs;
            }
        }

        if (
            function_exists('yooadmin_network_dashboard_slug')
            && $slug === yooadmin_network_dashboard_slug()
        ) {
            return function_exists('yooadmin_network_dashboard_default_menu_subs')
                ? yooadmin_network_dashboard_default_menu_subs('index.php')
                : [];
        }

        return function_exists('yooadmin_network_dashboard_default_menu_subs')
            ? yooadmin_network_dashboard_default_menu_subs($slug)
            : [];
    }
}

if (!function_exists('yooadmin_network_dashboard_normalize_menu_subs')) {
    /**
     * Drop legacy core submenu links when a YOOAdmin replacement is active.
     *
     * @param array<int, array<string, string>> $subs
     * @return array<int, array<string, string>>
     */
    function yooadmin_network_dashboard_normalize_menu_subs(array $subs, string $parent_slug): array
    {
        $legacy_replacements = [];

        if ($parent_slug === 'sites.php') {
            if (function_exists('yooadmin_network_sites_should_use') && yooadmin_network_sites_should_use()) {
                $legacy_replacements['sites.php'] = function_exists('yooadmin_network_sites_page_slug')
                    ? yooadmin_network_sites_page_slug()
                    : 'yooadmin-network-sites';
            }
            if (function_exists('yooadmin_network_site_new_should_use') && yooadmin_network_site_new_should_use()) {
                $legacy_replacements['site-new.php'] = function_exists('yooadmin_network_site_new_page_slug')
                    ? yooadmin_network_site_new_page_slug()
                    : 'yooadmin-network-add-site';
            }
        }

        if ($parent_slug === 'index.php' && function_exists('yooadmin_network_update_center_should_use') && yooadmin_network_update_center_should_use()) {
            $legacy_replacements['update-core.php'] = function_exists('yooadmin_network_update_center_page_slug')
                ? yooadmin_network_update_center_page_slug()
                : 'yooadmin-network-update-center';
        }

        if ($parent_slug === 'index.php' && function_exists('yooadmin_network_upgrade_should_use') && yooadmin_network_upgrade_should_use()) {
            $legacy_replacements['upgrade.php'] = function_exists('yooadmin_network_upgrade_page_slug')
                ? yooadmin_network_upgrade_page_slug()
                : 'yooadmin-network-upgrade';
        }

        if ($parent_slug === 'settings.php' && function_exists('yooadmin_network_setup_should_use') && yooadmin_network_setup_should_use()) {
            $legacy_replacements['setup.php'] = function_exists('yooadmin_network_setup_page_slug')
                ? yooadmin_network_setup_page_slug()
                : 'yooadmin-network-setup';
        }

        if (
            $parent_slug === 'index.php'
            && function_exists('yooadmin_network_dashboard_should_use')
            && yooadmin_network_dashboard_should_use()
            && function_exists('yooadmin_network_dashboard_slug')
        ) {
            $legacy_replacements['index.php'] = yooadmin_network_dashboard_slug();
        }

        if ($parent_slug === 'settings.php' && function_exists('yooadmin_network_settings_should_use') && yooadmin_network_settings_should_use()) {
            $legacy_replacements['settings.php'] = function_exists('yooadmin_network_settings_page_slug')
                ? yooadmin_network_settings_page_slug()
                : 'yooadmin-network-settings';
        }

        $modern_slugs = array_values($legacy_replacements);
        $filtered     = [];
        $seen         = [];
        $seen_titles  = [];
        $dash_slug    = function_exists('yooadmin_network_dashboard_slug')
            ? yooadmin_network_dashboard_slug()
            : 'yooadmin-network-dashboard';

        foreach ($subs as $sub) {
            if (!is_array($sub)) {
                continue;
            }

            $sub_slug = isset($sub['slug']) ? (string) $sub['slug'] : '';
            if ($sub_slug !== '' && isset($legacy_replacements[ $sub_slug ]) && in_array($legacy_replacements[ $sub_slug ], $modern_slugs, true)) {
                continue;
            }
            if ($sub_slug !== '' && isset($seen[ $sub_slug ])) {
                continue;
            }

            $sub_title = isset($sub['title']) ? trim((string) $sub['title']) : '';
            if ($parent_slug === 'index.php' && $sub_title !== '') {
                $title_key = strtolower($sub_title);
                if (isset($seen_titles[ $title_key ])) {
                    continue;
                }
                $seen_titles[ $title_key ] = true;
            }

            if ($sub_slug === $dash_slug) {
                $sub['title'] = __('Home', 'yooadmin');
            }

            if ($sub_slug !== '') {
                $seen[ $sub_slug ] = true;
            }

            $filtered[] = $sub;
        }

        return array_values($filtered);
    }
}

if (!function_exists('yooadmin_network_dashboard_enrich_menu_tree_subs')) {
    /**
     * Attach live network admin submenu items so workspace tiles open the popup.
     *
     * @param array<int, array<string, mixed>> $tree
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_dashboard_enrich_menu_tree_subs(array $tree): array
    {
        foreach ($tree as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            $slug = isset($item['slug']) ? (string) $item['slug'] : '';
            if ($slug === '') {
                continue;
            }

            $subs = yooadmin_network_dashboard_build_menu_subs($slug);
            if (!$subs) {
                $tree[ $index ]['subs']    = [];
                $tree[ $index ]['has_sub'] = false;
                continue;
            }

            $tree[ $index ]['subs']    = $subs;
            $tree[ $index ]['has_sub'] = true;
        }

        return $tree;
    }
}

if (!function_exists('yooadmin_network_dashboard_prioritize_dashboard_tile')) {
    /**
     * Ensure the network dashboard tile exists and appears first in Network Workspace.
     *
     * @param array<int, array<string, mixed>> $tree
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_dashboard_prioritize_dashboard_tile(array $tree): array
    {
        $dash_slug = yooadmin_network_dashboard_slug();
        $dashboard = null;
        $rest      = [];

        foreach ($tree as $item) {
            if (!is_array($item)) {
                continue;
            }

            $slug = isset($item['slug']) ? (string) $item['slug'] : '';
            if ($slug === $dash_slug) {
                $dashboard = $item;
                continue;
            }

            $rest[] = $item;
        }

        if ($dashboard === null && function_exists('yooadmin_network_dashboard_core_menu_items')) {
            foreach (yooadmin_network_dashboard_core_menu_items() as $core_item) {
                if (!is_array($core_item)) {
                    continue;
                }
                if ((isset($core_item['slug']) ? (string) $core_item['slug'] : '') === $dash_slug) {
                    $dashboard = $core_item;
                    break;
                }
            }
        }

        if (!is_array($dashboard)) {
            return $tree;
        }

        return array_merge([$dashboard], $rest);
    }
}

if (!function_exists('yooadmin_network_dashboard_finalize_menu_tree')) {
    /**
     * @param array<int, array<string, mixed>> $out
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_dashboard_finalize_menu_tree(array $out): array
    {
        $core = yooadmin_network_dashboard_core_menu_items();
        if ($core) {
            $out = yooadmin_network_dashboard_merge_menu_tree($out, $core);
        }

        if (!$out && function_exists('yooadmin_network_dashboard_minimum_menu_items')) {
            $out = yooadmin_network_dashboard_minimum_menu_items();
        }

        $out = (array) apply_filters('yooadmin_network_admin_menu_tree', $out);

        if (!$out && function_exists('yooadmin_network_dashboard_minimum_menu_items')) {
            $out = yooadmin_network_dashboard_minimum_menu_items();
        }

        if (function_exists('yooadmin_network_dashboard_enrich_menu_tree_subs')) {
            $out = yooadmin_network_dashboard_enrich_menu_tree_subs($out);
        }

        if (function_exists('yooadmin_network_dashboard_prioritize_dashboard_tile')) {
            $out = yooadmin_network_dashboard_prioritize_dashboard_tile($out);
        }

        return function_exists('yooadmin_network_dashboard_normalize_menu_tree_urls')
            ? yooadmin_network_dashboard_normalize_menu_tree_urls($out)
            : $out;
    }
}

if (!function_exists('yooadmin_build_network_admin_menu_tree')) {
    function yooadmin_build_network_admin_menu_tree(): array
    {
        if (!yooadmin_network_dashboard_can_build_menu_tree()) {
            return [];
        }

        global $menu, $submenu;
        if (!isset($menu) || !is_array($menu) || !$menu) {
            return yooadmin_network_dashboard_finalize_menu_tree([]);
        }

        $out = [];
        foreach ($menu as $m) {
            $raw_title = isset($m[0]) ? (string) $m[0] : '';
            $cap       = isset($m[1]) ? (string) $m[1] : '';
            $slug      = isset($m[2]) ? (string) $m[2] : '';
            $icon      = isset($m[6]) ? (string) $m[6] : '';

            if ($raw_title === '' || $slug === '') {
                continue;
            }
            if ($cap && !current_user_can($cap)) {
                continue;
            }

            $title = trim(wp_strip_all_tags($raw_title));
            $title = preg_replace('/\s*\d+\s*$/u', '', $title);

            $url   = yooadmin_network_dashboard_menu_url($slug);
            $subs = function_exists('yooadmin_network_dashboard_build_menu_subs')
                ? yooadmin_network_dashboard_build_menu_subs($slug)
                : [];

            if (strpos($slug, 'index.php') !== false) {
                continue;
            }

            $out[] = [
                'title'   => $title,
                'slug'    => $slug,
                'url'     => $url,
                'icon'    => (is_string($icon) && strpos($icon, 'dashicons-') === 0) ? $icon : 'dashicons-admin-generic',
                'has_sub' => !empty($subs),
                'subs'    => $subs,
            ];
        }

        return yooadmin_network_dashboard_finalize_menu_tree($out);
    }
}

if (!function_exists('yooadmin_network_dashboard_resolve_menu_tree')) {
    function yooadmin_network_dashboard_resolve_menu_tree(bool $force_refresh = false): array
    {
        static $cache = null;

        if (!$force_refresh && $cache !== null) {
            return $cache;
        }

        $resolved = yooadmin_build_network_admin_menu_tree();
        if (!$resolved) {
            $resolved = yooadmin_network_dashboard_finalize_menu_tree([]);
        }

        $cache = is_array($resolved) ? $resolved : [];

        return $cache;
    }
}

if (!function_exists('yooadmin_network_dashboard_normalize_menu_tree_urls')) {
    /**
     * @param array<int, array<string, mixed>> $tree
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_network_dashboard_normalize_menu_tree_urls(array $tree): array
    {
        if (!function_exists('yooadmin_fix_network_admin_url')) {
            return $tree;
        }

        foreach ($tree as $index => $item) {
            if (!is_array($item)) {
                continue;
            }
            if (!empty($item['url'])) {
                $tree[$index]['url'] = yooadmin_fix_network_admin_url((string) $item['url']);
            }
            if (!empty($item['subs']) && is_array($item['subs'])) {
                foreach ($item['subs'] as $sub_index => $sub) {
                    if (!is_array($sub) || empty($sub['url'])) {
                        continue;
                    }
                    $tree[$index]['subs'][$sub_index]['url'] = yooadmin_fix_network_admin_url((string) $sub['url']);
                }
            }
        }

        return $tree;
    }
}

if (!function_exists('yooadmin_network_dashboard_network_stats')) {
    function yooadmin_network_dashboard_network_stats(): array
    {
        $site_count = function_exists('get_blog_count') ? (int) get_blog_count() : count(get_sites(['number' => 500]));
        $user_count = function_exists('get_user_count') ? (int) get_user_count() : 0;

        return [
            'sites' => max(0, $site_count),
            'users' => max(0, $user_count),
        ];
    }
}

if (!function_exists('yooadmin_network_dashboard_recent_sites')) {
    function yooadmin_network_dashboard_recent_sites(int $limit = 5): array
    {
        if (!is_multisite()) {
            return [];
        }

        $sites = get_sites(
            [
                'number'   => max(1, min(20, $limit)),
                'orderby'  => 'id',
                'order'    => 'DESC',
                'public'   => null,
                'archived' => null,
                'spam'     => null,
                'deleted'  => null,
            ]
        );

        $out = [];
        foreach ($sites as $site) {
            if (function_exists('yooadmin_network_sites_map_row')) {
                $row = yooadmin_network_sites_map_row($site);
                if ($row) {
                    $out[] = $row;
                }
                continue;
            }

            if (!is_object($site) || empty($site->blog_id)) {
                continue;
            }

            $blog_id = (int) $site->blog_id;

            $name = function_exists('yooadmin_multisite_site_label')
                ? yooadmin_multisite_site_label($blog_id)
                : (string) $blog_id;

            $out[] = [
                'id'    => $blog_id,
                'name'  => $name,
                'admin' => get_admin_url($blog_id),
                'home'  => get_home_url($blog_id, '/'),
            ];
        }

        return $out;
    }
}

if (!function_exists('yooadmin_network_dashboard_welcome_links')) {
    /**
     * Welcome quick links under the network dashboard greeting (matches site dashboard).
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_network_dashboard_welcome_links(): array
    {
        $settings_url = function_exists('yooadmin_admin_menu_url')
            ? yooadmin_admin_menu_url('yooadmin-settings')
            : network_admin_url('admin.php?page=yooadmin-settings');
        $theme_url = function_exists('yooadmin_admin_menu_url')
            ? yooadmin_admin_menu_url('yooadmin-admin-theme-settings')
            : network_admin_url('admin.php?page=yooadmin-admin-theme-settings');

        $links = [
            [
                'icon'  => 'dashicons-admin-generic',
                'label' => __('Customize', 'yooadmin'),
                'url'   => $settings_url,
            ],
            [
                'icon'  => 'dashicons-admin-appearance',
                'label' => __('Theme Colors', 'yooadmin'),
                'url'   => $theme_url,
            ],
            [
                'icon'   => 'dashicons-warning',
                'label'  => __('Report Bug', 'yooadmin'),
                'url'    => 'https://www.yooadmin.io/report-bug',
                'target' => '_blank',
            ],
        ];

        $links = apply_filters('yooadmin_card_welcome_links', $links);
        $links = apply_filters('yooadmin_network_dashboard_welcome_links', $links);
        $links = apply_filters('yooadmin_studio_hub_card_welcome_links', $links);

        return is_array($links) ? $links : [];
    }
}

if (!function_exists('yooadmin_network_dashboard_render_section')) {
    function yooadmin_network_dashboard_render_section(string $section_id, ?array $layout, string $cards_dir, array $context = []): void
    {
        $section_id = sanitize_key($section_id);
        $map        = [
            'network-workspace'       => 'card-network-workspace.php',
            'network-sites'           => 'card-network-sites.php',
            'network-overview'        => 'card-network-overview.php',
            'network-tips'            => 'card-network-tips.php',
            'network-workspace-notes' => 'card-network-workspace-notes.php',
        ];

        $menu_tree     = isset($context['menu_tree']) && is_array($context['menu_tree']) ? $context['menu_tree'] : [];
        $recent_sites  = isset($context['recent_sites']) && is_array($context['recent_sites']) ? $context['recent_sites'] : [];
        $network_stats = isset($context['network_stats']) && is_array($context['network_stats'])
            ? $context['network_stats']
            : ['sites' => 0, 'users' => 0];

        if (isset($map[$section_id])) {
            $file = trailingslashit($cards_dir) . $map[$section_id];
            if (is_readable($file)) {
                include $file;
            }
            return;
        }

        if (
            is_array($layout)
            && !empty($layout['customSections'][ $section_id ])
            && is_array($layout['customSections'][ $section_id ])
            && function_exists('yooadmin_studio_hub_render_custom_section_shell')
        ) {
            yooadmin_studio_hub_render_custom_section_shell($section_id, $layout['customSections'][ $section_id ], $layout);
            return;
        }

        if (
            is_array($layout)
            && !empty($layout['widgetSections'][ $section_id ])
            && is_array($layout['widgetSections'][ $section_id ])
            && function_exists('yooadmin_studio_hub_render_widget_section_shell')
        ) {
            $widget_meta = $layout['widgetSections'][ $section_id ];
            $widget_id   = isset($widget_meta['widgetId']) ? sanitize_key((string) $widget_meta['widgetId']) : '';
            if (
                $widget_id !== ''
                && (
                    ! function_exists('yooadmin_dashboard_card_allowed_in_context')
                    || yooadmin_dashboard_card_allowed_in_context($widget_id, 'network')
                )
            ) {
                yooadmin_studio_hub_render_widget_section_shell($section_id, $widget_meta);
            }
        }
    }
}

if (!function_exists('yooadmin_network_dashboard_allowed_card_ids')) {
    /**
     * Dashboard card ids allowed in the network dashboard picker.
     *
     * @return string[]
     */
    function yooadmin_network_dashboard_allowed_card_ids(): array
    {
        if (!function_exists('yooadmin_get_dashboard_cards_catalog_for_context')) {
            return [];
        }

        $ids = [];
        foreach (yooadmin_get_dashboard_cards_catalog_for_context('network') as $row) {
            if (!empty($row['id'])) {
                $ids[] = sanitize_key((string) $row['id']);
            }
        }

        return array_values(array_unique(array_filter($ids)));
    }
}

if (!function_exists('yooadmin_network_dashboard_template_path')) {
    function yooadmin_network_dashboard_template_path(string $relative = ''): string
    {
        $base = defined('YOOADMIN_PLUGIN_FILE')
            ? plugin_dir_path(YOOADMIN_PLUGIN_FILE)
            : dirname(__DIR__, 2) . '/';

        $path = $base . 'templates/yoopixel/admin/';
        if ($relative !== '') {
            $path .= ltrim($relative, '/');
        }

        return $path;
    }
}

if (!function_exists('yooadmin_render_network_dashboard_page')) {
    function yooadmin_render_network_dashboard_page(): void
    {
        if (!current_user_can('manage_network') && !current_user_can('read')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        if (!yooadmin_network_dashboard_should_use()) {
            wp_safe_redirect(network_admin_url('index.php'));
            exit;
        }

        $tpl = yooadmin_network_dashboard_template_path('pages/network-dashboard.php');
        if (is_readable($tpl)) {
            include $tpl;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('Network Dashboard', 'yooadmin') . '</h1></div>';
    }
}

if (!function_exists('yooadmin_network_dashboard_ajax_get_layout')) {
    function yooadmin_network_dashboard_ajax_get_layout(): void
    {
        check_ajax_referer('yooadmin_network_dashboard_layout', 'nonce');

        if (!yooadmin_network_dashboard_should_use()) {
            wp_send_json_error(['message' => 'forbidden'], 403);
        }

        $layout = yooadmin_network_dashboard_get_user_layout();
        if (!$layout) {
            $layout = yooadmin_network_dashboard_layout_defaults();
        }

        wp_send_json_success(['layout' => $layout]);
    }
}

if (!function_exists('yooadmin_network_dashboard_ajax_save_layout')) {
    function yooadmin_network_dashboard_ajax_save_layout(): void
    {
        check_ajax_referer('yooadmin_network_dashboard_layout', 'nonce');

        if (!yooadmin_network_dashboard_should_use()) {
            wp_send_json_error(['message' => 'forbidden'], 403);
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Normalized via layout validator.
        $raw = isset($_POST['layout']) ? wp_unslash($_POST['layout']) : '';
        if (is_string($raw)) {
            $payload = json_decode($raw, true);
        } else {
            $payload = $raw;
        }

        if (!is_array($payload)) {
            wp_send_json_error(['message' => 'invalid'], 400);
        }

        if (!yooadmin_network_dashboard_save_user_layout($payload)) {
            wp_send_json_error(['message' => 'save_failed'], 500);
        }

        wp_send_json_success(
            [
                'layout' => yooadmin_network_dashboard_get_user_layout(),
            ]
        );
    }
}

if (!function_exists('yooadmin_network_dashboard_ajax_reset_layout')) {
    function yooadmin_network_dashboard_ajax_reset_layout(): void
    {
        check_ajax_referer('yooadmin_network_dashboard_layout', 'nonce');

        if (!yooadmin_network_dashboard_should_use()) {
            wp_send_json_error(['message' => 'forbidden'], 403);
        }

        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            wp_send_json_error(['message' => 'forbidden'], 403);
        }

        $had_layout = metadata_exists('user', $user_id, YOOADMIN_NETWORK_DASHBOARD_LAYOUT_META);
        if ($had_layout && !yooadmin_network_dashboard_delete_user_layout($user_id)) {
            wp_send_json_error(['message' => 'reset_failed'], 500);
        }

        wp_send_json_success(
            [
                'layout' => yooadmin_network_dashboard_layout_defaults(),
            ]
        );
    }
}

add_action('wp_ajax_yooadmin_network_dashboard_get_layout', 'yooadmin_network_dashboard_ajax_get_layout');
add_action('wp_ajax_yooadmin_network_dashboard_save_layout', 'yooadmin_network_dashboard_ajax_save_layout');
add_action('wp_ajax_yooadmin_network_dashboard_reset_layout', 'yooadmin_network_dashboard_ajax_reset_layout');

add_action(
    'network_admin_menu',
    static function (): void {
        if (!is_multisite()) {
            return;
        }

        if (!function_exists('yooadmin_network_dashboard_slug')) {
            return;
        }

        if (!function_exists('yooadmin_network_register_hidden_admin_page')) {
            return;
        }

        yooadmin_network_register_hidden_admin_page(
            __('Network Dashboard', 'yooadmin'),
            yooadmin_network_dashboard_slug(),
            'yooadmin_render_network_dashboard_page'
        );
    },
    999998
);

add_action(
    'load-index.php',
    static function (): void {
        if (!is_network_admin() || !yooadmin_network_dashboard_should_use() || !yooadmin_network_dashboard_redirect_enabled()) {
            return;
        }
        if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect flag.
        if (isset($_GET['yooadmin_no_redirect'])) {
            return;
        }

        wp_safe_redirect(yooadmin_network_dashboard_url());
        exit;
    }
);

add_filter(
    'yooadmin_network_admin_menu_tree',
    static function ($tree) {
        if (!is_array($tree)) {
            return $tree;
        }

        $users_url    = function_exists('yooadmin_multisite_network_users_list_url')
            ? yooadmin_multisite_network_users_list_url()
            : network_admin_url('users.php');
        $user_new_url = function_exists('yooadmin_multisite_network_user_new_url')
            ? yooadmin_multisite_network_user_new_url()
            : network_admin_url('user-new.php');

        foreach ($tree as $index => $item) {
            if (!is_array($item)) {
                continue;
            }
            $slug = isset($item['slug']) ? (string) $item['slug'] : '';
            if ($slug === 'users.php' || $slug === 'yooadmin-users' || strpos($slug, 'users.php') !== false) {
                $tree[ $index ]['url'] = $users_url;
            }
            if (!empty($item['subs']) && is_array($item['subs'])) {
                foreach ($item['subs'] as $sub_index => $sub) {
                    if (!is_array($sub)) {
                        continue;
                    }
                    $sub_slug = isset($sub['slug']) ? (string) $sub['slug'] : '';
                    if ($sub_slug === 'user-new.php' || $sub_slug === 'yooadmin-users-new') {
                        $tree[ $index ]['subs'][ $sub_index ]['url'] = $user_new_url;
                    } elseif ($sub_slug === 'users.php' || $sub_slug === 'yooadmin-users') {
                        $tree[ $index ]['subs'][ $sub_index ]['url'] = $users_url;
                    }
                }
            }
        }

        return $tree;
    }
);

add_filter(
    'admin_body_class',
    static function (string $classes): string {
        if (!function_exists('yooadmin_network_admin_shell_active') || !yooadmin_network_admin_shell_active()) {
            return $classes;
        }

        $classes .= ' yooadmin-network-admin-shell';

        if (yooadmin_network_dashboard_is_screen()) {
            $classes .= ' yooadmin-network-dashboard yp-network-dashboard-screen toplevel_page_yooadmin-dashboard';
        }

        return $classes;
    }
);

if (!function_exists('yooadmin_network_dashboard_workspace_notes_script_data')) {
    /**
     * Localized config for Workspace Notes on the network dashboard.
     *
     * @return array<string, mixed>
     */
    function yooadmin_network_dashboard_workspace_notes_script_data(): array
    {
        $ws_types = function_exists('yooadmin_workspace_notes_types')
            ? yooadmin_workspace_notes_types()
            : [];
        $ws_dt    = function_exists('yooadmin_workspace_notes_datetime_config')
            ? yooadmin_workspace_notes_datetime_config()
            : [];

        return array_merge(
            [
                'ajaxUrl'    => admin_url('admin-ajax.php'),
                'nonce'      => wp_create_nonce('yooadmin_workspace_notes'),
                'notesScope' => 'network',
                'types'      => $ws_types,
                'i18n'       => [
                    'empty'              => __('No notes yet.', 'yooadmin'),
                    'markDone'           => __('Mark done', 'yooadmin'),
                    'deleteNote'         => __('Delete note', 'yooadmin'),
                    'confirmDelete'      => __('Delete this note?', 'yooadmin'),
                    'addNote'            => __('Add note', 'yooadmin'),
                    /* translators: %s: due date or time string. */
                    'due'                => __('Due: %s', 'yooadmin'),
                    /* translators: %s: completion date or time string. */
                    'completed'          => __('Completed: %s', 'yooadmin'),
                    /* translators: %s: reminder date or time string. */
                    'remind'             => __('Remind: %s', 'yooadmin'),
                    /* translators: %s: note creation date or time string. */
                    'added'              => __('Added: %s', 'yooadmin'),
                    'dueRequired'        => __('Due date is required.', 'yooadmin'),
                    'remindRequired'     => __('Reminder time is required.', 'yooadmin'),
                    'deleteModalTitle'   => __('Delete note?', 'yooadmin'),
                    'deleteModalMessage' => __('This note will be removed permanently.', 'yooadmin'),
                    'cancel'             => __('Cancel', 'yooadmin'),
                    'deleteConfirm'      => __('Delete', 'yooadmin'),
                    'titleRequired'      => __('Title is required.', 'yooadmin'),
                    'saved'              => __('Note saved.', 'yooadmin'),
                    'deleted'            => __('Note deleted.', 'yooadmin'),
                    'markedDone'         => __('Marked as done.', 'yooadmin'),
                    'markedActive'       => __('Marked as active.', 'yooadmin'),
                    'saveFailed'         => __('Could not save note.', 'yooadmin'),
                    'deleteFailed'       => __('Could not delete note.', 'yooadmin'),
                    'errorGeneric'       => __('Something went wrong. Please try again.', 'yooadmin'),
                    'loadMore'           => __('Load more', 'yooadmin'),
                    /* translators: %s: site-local time string. */
                    'siteTime'           => __('Site time: %s', 'yooadmin'),
                ],
            ],
            $ws_dt
        );
    }
}

add_action(
    'admin_enqueue_scripts',
    static function (): void {
        if (!yooadmin_network_dashboard_is_screen() || !yooadmin_network_dashboard_should_use()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $dir       = plugin_dir_path($base_file);
        $url       = plugin_dir_url($base_file);
        $theme_dir = $dir . 'themes/yooadmin-studio-hub/';
        $theme_url = plugins_url('themes/yooadmin-studio-hub/', $base_file);

        $enqueue_style = static function (string $handle, string $rel, array $deps = []) use ($dir, $url): void {
            $path = $dir . $rel;
            if (is_readable($path)) {
                wp_enqueue_style($handle, $url . $rel, $deps, (string) filemtime($path));
            }
        };

        $enqueue_script = static function (string $handle, string $rel, array $deps = []) use ($dir, $url): void {
            $path = $dir . $rel;
            if (is_readable($path)) {
                wp_enqueue_script($handle, $url . $rel, $deps, (string) filemtime($path), true);
            }
        };

        if (wp_style_is('yooadmin-core', 'enqueued') === false && wp_style_is('yooadmin-core', 'registered')) {
            wp_enqueue_style('yooadmin-core');
        }

        $enqueue_style('yooadmin-dashboard', 'assets/css/admin/yp-dashboard.css', ['yooadmin-core']);

        $welcome_bg_path = $dir . 'assets/images/bg.png';
        if (is_readable($welcome_bg_path) && wp_style_is('yooadmin-dashboard', 'enqueued')) {
            wp_add_inline_style(
                'yooadmin-dashboard',
                ":root { --yp-welcome-bg: url('" . esc_url($url . 'assets/images/bg.png') . "'); }"
            );
        }

        $enqueue_style('yooadmin-yoo-buttons', 'assets/css/admin/yp-yoo-buttons.css', ['yooadmin-core']);
        $enqueue_style('yooadmin-popup', 'assets/css/admin/yp-popup.css', ['yooadmin-core']);
        $enqueue_style('yooadmin-network-popup', 'assets/css/admin/network-popup.css', ['yooadmin-popup']);

        if (is_readable($theme_dir . 'assets/studio-hub.css')) {
            wp_enqueue_style(
                'yooadmin-studio-hub-dashboard',
                $theme_url . 'assets/studio-hub.css',
                ['yooadmin-core', 'yooadmin-dashboard', 'yooadmin-popup'],
                (string) filemtime($theme_dir . 'assets/studio-hub.css')
            );
        }
        if (is_readable($theme_dir . 'assets/css/core/studio-hub-late.css')) {
            wp_enqueue_style(
                'yooadmin-studio-hub-late',
                $theme_url . 'assets/css/core/studio-hub-late.css',
                ['yooadmin-studio-hub-dashboard'],
                (string) filemtime($theme_dir . 'assets/css/core/studio-hub-late.css')
            );
        }

        $enqueue_style('yooadmin-focus-alerts', 'assets/css/admin/focus-mode-alerts.css', ['yooadmin-core']);
        $enqueue_style('yooadmin-network-dashboard', 'assets/css/admin/network-dashboard.css', ['yooadmin-studio-hub-dashboard', 'yooadmin-studio-hub-late', 'yooadmin-focus-alerts']);

        if (wp_script_is('yp-admin-core-essential', 'registered') && wp_script_is('yp-admin-core-essential', 'enqueued') === false) {
            wp_enqueue_script('yp-admin-core-essential');
        }
        $enqueue_script('yooadmin-icon-ai', 'assets/js/admin/yp-icon-ai.js', ['yp-admin-core-essential']);
        $enqueue_script('yooadmin-popup', 'assets/js/admin/yp-popup.js', ['yp-admin-core-essential', 'jquery', 'yooadmin-icon-ai']);
        $enqueue_script('yooadmin-network-popup', 'assets/js/admin/network-popup.js', ['yooadmin-popup']);
        $enqueue_style('yooadmin-network-settings-page', 'assets/css/admin/network-settings-page.css', ['yooadmin-yoo-buttons']);
        if (function_exists('yooadmin_network_sites_enqueue_confirm_assets')) {
            yooadmin_network_sites_enqueue_confirm_assets(
                static function (string $handle, string $rel, array $deps = [], bool $in_footer = true) use ($enqueue_script, $enqueue_style): void {
                    if (str_ends_with($rel, '.js')) {
                        $enqueue_script($handle, $rel, $deps, $in_footer);
                        return;
                    }
                    $enqueue_style($handle, $rel, $deps);
                },
                static function (string $handle, string $rel, array $deps = []) use ($enqueue_style): void {
                    $enqueue_style($handle, $rel, $deps);
                }
            );
        }
        $enqueue_script('yooadmin-network-dashboard-sites', 'assets/js/admin/network-dashboard-sites.js', ['yp-admin-core-essential', 'yooadmin-confirm-dialog']);
        if (function_exists('yooadmin_network_sites_localize_confirm_script')) {
            yooadmin_network_sites_localize_confirm_script();
        }
        $tips_carousel_js = $theme_dir . 'assets/js/dashboard/studio-tips-carousel.js';
        if (is_readable($tips_carousel_js)) {
            wp_enqueue_script(
                'yooadmin-studio-hub-tips-carousel',
                $theme_url . 'assets/js/dashboard/studio-tips-carousel.js',
                [],
                (string) filemtime($tips_carousel_js),
                true
            );
        }
        $enqueue_script('yooadmin-menus', 'assets/js/admin/yp-menus.js', ['yp-admin-core-essential', 'jquery']);
        $enqueue_script('yooadmin-card-icons', 'assets/js/admin/yp-card-icons.js', ['yp-admin-core-essential', 'jquery', 'yooadmin-popup']);

        $card_menu_items = function_exists('yooadmin_network_dashboard_resolve_menu_tree')
            ? yooadmin_network_dashboard_resolve_menu_tree(true)
            : [];
        if (wp_script_is('yooadmin-popup', 'enqueued')) {
            wp_add_inline_script(
                'yooadmin-popup',
                'window.yooadmCardMenus = ' . wp_json_encode(
                    [
                        'items' => $card_menu_items,
                        'nonce' => wp_create_nonce('yooadmin_popup_nonce'),
                    ]
                ) . ';',
                'before'
            );
        }

        $panel_css = $dir . 'assets/css/admin/yp-panel.css';
        if (is_readable($panel_css)) {
            wp_enqueue_style(
                'yp-panel-css',
                $url . 'assets/css/admin/yp-panel.css',
                ['yooadmin-core', 'yooadmin-dashboard'],
                (string) filemtime($panel_css)
            );
        }

        $panel_js = $dir . 'assets/js/admin/yp-panel-index.js';
        if (is_readable($panel_js)) {
            wp_enqueue_script(
                'yp-panel-index',
                $url . 'assets/js/admin/yp-panel-index.js',
                ['jquery'],
                (string) filemtime($panel_js),
                true
            );
            wp_localize_script(
                'yp-panel-index',
                'yooadmPanelQa',
                [
                    'ajaxUrl'      => admin_url('admin-ajax.php'),
                    'nonce'        => wp_create_nonce('yooadmin_quick_actions'),
                    'maxItems'     => 24,
                    'itemsPerPage' => 6,
                    'icons'        => [
                        'dashicons-admin-site', 'dashicons-admin-home', 'dashicons-admin-generic', 'dashicons-admin-settings', 'dashicons-admin-tools',
                        'dashicons-admin-appearance', 'dashicons-admin-customizer', 'dashicons-admin-plugins', 'dashicons-admin-users', 'dashicons-admin-media',
                        'dashicons-admin-page', 'dashicons-admin-post', 'dashicons-admin-comments', 'dashicons-admin-links', 'dashicons-admin-network',
                        'dashicons-admin-multisite', 'dashicons-admin-site-alt2', 'dashicons-admin-site-alt3', 'dashicons-dashboard', 'dashicons-update',
                        'dashicons-clock', 'dashicons-performance', 'dashicons-chart-pie', 'dashicons-chart-area', 'dashicons-chart-bar', 'dashicons-chart-line',
                        'dashicons-megaphone', 'dashicons-clipboard', 'dashicons-edit', 'dashicons-search', 'dashicons-filter', 'dashicons-category',
                        'dashicons-tag', 'dashicons-portfolio', 'dashicons-layout', 'dashicons-media-document', 'dashicons-format-image', 'dashicons-email',
                        'dashicons-share', 'dashicons-groups', 'dashicons-businessman', 'dashicons-money', 'dashicons-cart', 'dashicons-products',
                        'dashicons-cloud', 'dashicons-backup', 'dashicons-download', 'dashicons-upload', 'dashicons-star-filled', 'dashicons-yes',
                        'dashicons-info', 'dashicons-warning', 'dashicons-flag', 'dashicons-rest-api', 'dashicons-translation', 'dashicons-screenoptions',
                    ],
                    'strings'      => [
                        'addTitle'      => __('Add Quick Action', 'yooadmin'),
                        'editTitle'     => __('Edit Quick Action', 'yooadmin'),
                        'label'         => __('Label', 'yooadmin'),
                        'url'           => __('URL', 'yooadmin'),
                        'target'        => __('Target', 'yooadmin'),
                        'targetBlank'   => __('Open in new tab', 'yooadmin'),
                        'targetSelf'    => __('Open in same tab', 'yooadmin'),
                        'icon'          => __('Icon', 'yooadmin'),
                        'save'          => __('Save', 'yooadmin'),
                        'cancel'        => __('Cancel', 'yooadmin'),
                        'deleteModalTitle' => __('Delete quick action?', 'yooadmin'),
                        'deleteConfirm' => __('Are you sure you want to delete this quick action?', 'yooadmin'),
                        'deleteButton'  => __('Delete', 'yooadmin'),
                        'error'         => __('Something went wrong, please try again.', 'yooadmin'),
                        'maxReached'    => __('Maximum items reached', 'yooadmin'),
                        'validation'    => __('Please provide both label and URL.', 'yooadmin'),
                        'editAction'    => __('Edit quick action', 'yooadmin'),
                        'deleteAction'  => __('Delete quick action', 'yooadmin'),
                    ],
                ]
            );
        }

        $layout_storage = $theme_dir . 'assets/js/dashboard/layout/layout-storage.js';
        if (is_readable($layout_storage)) {
            wp_enqueue_script(
                'yooadmin-studio-hub-layout-storage',
                $theme_url . 'assets/js/dashboard/layout/layout-storage.js',
                [],
                (string) filemtime($layout_storage),
                true
            );
        }

        $theme_scripts = [
            'assets/js/core/studio-hub.js'                          => ['yooadmin-studio-hub-dashboard', []],
            'assets/js/dashboard/studio-hub-dashboard-layout.js'    => ['yooadmin-studio-hub-dashboard-layout', ['jquery', 'yooadmin-card-icons', 'yooadmin-studio-hub-layout-storage']],
            'assets/js/dashboard/layout/layout-coordinator.js'      => ['yooadmin-studio-hub-layout-coordinator', ['yooadmin-studio-hub-layout-storage', 'yooadmin-studio-hub-dashboard-layout']],
            'assets/js/dashboard/studio-workspace-pagination.js'    => ['yooadmin-studio-hub-workspace-pagination', ['yooadmin-studio-hub-dashboard-layout', 'yooadmin-studio-hub-layout-coordinator']],
        ];
        foreach ($theme_scripts as $rel => $meta) {
            $path = $theme_dir . $rel;
            if (!is_readable($path)) {
                continue;
            }
            wp_enqueue_script(
                $meta[0],
                $theme_url . $rel,
                $meta[1],
                (string) filemtime($path),
                true
            );
        }

        $workspace_notes_js = $theme_dir . 'assets/js/dashboard/workspace-notes.js';
        if (
            apply_filters('yooadmin_workspace_notes_enabled', true)
            && is_readable($workspace_notes_js)
        ) {
            wp_enqueue_script(
                'yooadmin-studio-hub-workspace-notes',
                $theme_url . 'assets/js/dashboard/workspace-notes.js',
                ['jquery'],
                (string) filemtime($workspace_notes_js),
                true
            );

            $localized = null;
            if (function_exists('yooadmin_studio_hub_filter_script_localize')) {
                $localized = yooadmin_studio_hub_filter_script_localize(
                    [],
                    'yooadmin-studio-hub-workspace-notes',
                    'yooadmin-studio-hub',
                    ['file' => 'assets/js/dashboard/workspace-notes.js']
                );
            }

            $ws_object = (is_array($localized) && !empty($localized['object']))
                ? (string) $localized['object']
                : 'yooadminWorkspaceNotes';
            $ws_data   = (is_array($localized) && !empty($localized['data']) && is_array($localized['data']))
                ? $localized['data']
                : (function_exists('yooadmin_network_dashboard_workspace_notes_script_data')
                    ? yooadmin_network_dashboard_workspace_notes_script_data()
                    : []);

            if ($ws_data) {
                wp_localize_script(
                    'yooadmin-studio-hub-workspace-notes',
                    $ws_object,
                    $ws_data
                );
            }
        }

        if (wp_script_is('yooadmin-studio-hub-dashboard-layout', 'enqueued')) {
            wp_localize_script(
                'yooadmin-studio-hub-dashboard-layout',
                'yooadminStudioHubLayout',
                [
                    'ajaxUrl'   => admin_url('admin-ajax.php'),
                    'nonce'     => wp_create_nonce('yooadmin_studio_hub_layout'),
                    'restUrl'   => rest_url('yooadmin/v1/'),
                    'restNonce' => wp_create_nonce('wp_rest'),
                    'i18n'      => [
                        'addSectionTitle'      => __('Add to dashboard', 'yooadmin'),
                        'addSectionCustom'     => __('Custom section', 'yooadmin'),
                        'addSectionCustomHint' => __('Empty section for your tiles. Drag cards from other sections.', 'yooadmin'),
                        'addSectionCards'      => __('Dashboard card', 'yooadmin'),
                        'addSectionCardsHint'  => __(
                            'Cards registered by plugins for YOOAdmin Studio Hub.',
                            'yooadmin'
                        ),
                        'addBelow'             => __('Add section below', 'yooadmin'),
                        'addAside'             => __('Add section on the right', 'yooadmin'),
                        'hideSection'          => __('Hide section', 'yooadmin'),
                        'showSection'          => __('Show section', 'yooadmin'),
                        'layoutSaved'          => __('Layout saved.', 'yooadmin'),
                        'layoutSaveFailed'     => __('Could not save layout. Please try again.', 'yooadmin'),
                        'networkCardOnly'      => __('Only network dashboard cards can be added here.', 'yooadmin'),
                        'networkWorkspaceAsideBlockedToast' => __(
                            'Network Workspace must stay in the main column and cannot be moved to the right sidebar.',
                            'yooadmin'
                        ),
                        'networkWorkspaceCardLockedToast' => __(
                            'The last tiles in Network Workspace cannot be moved.',
                            'yooadmin'
                        ),
                        'widgetsLoading'       => __('Loading cards…', 'yooadmin'),
                        'widgetsEmpty'         => __('No dashboard cards are registered yet.', 'yooadmin'),
                        'widgetsSearch'        => __('Search cards…', 'yooadmin'),
                        'cancel'               => __('Cancel', 'yooadmin'),
                        'ok'                   => __('OK', 'yooadmin'),
                    ],
                ]
            );
        }

        wp_localize_script(
            'yooadmin-studio-hub-layout-storage',
            'yooadminNetworkDashboardLayout',
            [
                'isNetworkDashboard' => true,
                'ajaxUrl'            => admin_url('admin-ajax.php'),
                'nonce'              => wp_create_nonce('yooadmin_network_dashboard_layout'),
                'allowedCardIds'     => yooadmin_network_dashboard_allowed_card_ids(),
                'actions'            => [
                    'get'   => 'yooadmin_network_dashboard_get_layout',
                    'save'  => 'yooadmin_network_dashboard_save_layout',
                    'reset' => 'yooadmin_network_dashboard_reset_layout',
                ],
            ]
        );
    },
    20
);

add_filter(
    'yooadmin_network_dashboard_quick_actions',
    static function ($items) {
        if (!is_array($items) || !function_exists('yooadmin_fix_network_admin_url')) {
            return $items;
        }

        foreach ($items as $index => $item) {
            if (!is_array($item) || empty($item['url'])) {
                continue;
            }
            $url = (string) $item['url'];
            if (function_exists('yooadmin_multisite_resolve_network_quick_action_url')) {
                $url = yooadmin_multisite_resolve_network_quick_action_url($url);
            }
            $items[ $index ]['url'] = yooadmin_fix_network_admin_url($url);
        }

        return $items;
    },
    999
);

add_filter(
    'yooadmin_network_dashboard_overview_links',
    static function ($links) {
        if (!is_array($links) || !function_exists('yooadmin_fix_network_admin_url')) {
            return $links;
        }

        foreach ($links as $index => $link) {
            if (!is_array($link) || empty($link['url'])) {
                continue;
            }
            $links[$index]['url'] = yooadmin_fix_network_admin_url((string) $link['url']);
        }

        return $links;
    },
    999
);

add_filter(
    'yooadmin_network_dashboard_welcome_links',
    static function ($links) {
        if (!is_array($links) || !function_exists('yooadmin_fix_network_admin_url')) {
            return $links;
        }

        foreach ($links as $index => $link) {
            if (!is_array($link) || empty($link['url'])) {
                continue;
            }

            $url = (string) $link['url'];
            if (strpos($url, 'yooadmin-license') !== false) {
                continue;
            }

            $path = wp_parse_url($url, PHP_URL_PATH);
            if (!is_string($path) || strpos($path, '/wp-admin/') === false) {
                continue;
            }

            $links[$index]['url'] = yooadmin_fix_network_admin_url($url);
        }

        return $links;
    },
    999
);

add_filter(
    'yooadmin_workspace_notes_types',
    static function (array $types): array {
        $use_network_types = (
            (function_exists('yooadmin_workspace_notes_is_network_scope') && yooadmin_workspace_notes_is_network_scope())
            || (function_exists('yooadmin_network_dashboard_is_screen') && yooadmin_network_dashboard_is_screen())
        );

        if (!$use_network_types) {
            return $types;
        }

        return [
            'todos' => $types['todos'] ?? [
                'label' => __('TODOs', 'yooadmin'),
                'icon'  => 'dashicons-yes-alt',
            ],
            'reminders' => $types['reminders'] ?? [
                'label' => __('Reminders', 'yooadmin'),
                'icon'  => 'dashicons-clock',
            ],
            'network_notes' => [
                'label' => __('Network notes', 'yooadmin'),
                'icon'  => 'dashicons-admin-multisite',
            ],
            'site_rollouts' => [
                'label' => __('Site rollouts', 'yooadmin'),
                'icon'  => 'dashicons-update',
            ],
        ];
    },
    20
);
