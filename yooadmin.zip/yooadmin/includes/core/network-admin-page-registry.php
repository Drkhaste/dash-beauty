<?php
/**
 * Network admin plugin pages — hidden registration + submenu sync.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_admin_page_registry_text_domain')) {
    function yooadmin_network_admin_page_registry_text_domain(): string
    {
        return function_exists('yooadmin_multisite_text_domain')
            ? yooadmin_multisite_text_domain()
            : 'yooadmin';
    }
}

if (!function_exists('yooadmin_network_admin_page_registry')) {
    /**
     * @return array<string, array{parent: string, submenu_cap: callable(): string, should_use: callable(): bool}>
     */
    function yooadmin_network_admin_page_registry(): array
    {
        return [
            'yooadmin-network-update-center' => [
                'parent'      => 'index.php',
                'submenu_cap' => static function (): string {
                    return function_exists('yooadmin_network_update_center_submenu_cap')
                        ? yooadmin_network_update_center_submenu_cap()
                        : 'update_core';
                },
                'should_use'  => static function (): bool {
                    return function_exists('yooadmin_network_update_center_should_use')
                        && yooadmin_network_update_center_should_use();
                },
            ],
            'yooadmin-network-upgrade' => [
                'parent'      => 'index.php',
                'submenu_cap' => static function (): string {
                    return function_exists('yooadmin_network_upgrade_submenu_cap')
                        ? yooadmin_network_upgrade_submenu_cap()
                        : 'upgrade_network';
                },
                'should_use'  => static function (): bool {
                    return function_exists('yooadmin_network_upgrade_should_use')
                        && yooadmin_network_upgrade_should_use();
                },
            ],
            'yooadmin-network-setup' => [
                'parent'      => 'settings.php',
                'submenu_cap' => static function (): string {
                    return function_exists('yooadmin_network_setup_submenu_cap')
                        ? yooadmin_network_setup_submenu_cap()
                        : 'setup_network';
                },
                'should_use'  => static function (): bool {
                    return function_exists('yooadmin_network_setup_should_use')
                        && yooadmin_network_setup_should_use();
                },
            ],
            'yooadmin-network-dashboard' => [
                'parent'      => 'index.php',
                'submenu_cap' => static function (): string {
                    return 'manage_network';
                },
                'should_use'  => static function (): bool {
                    return function_exists('yooadmin_network_dashboard_should_use')
                        && yooadmin_network_dashboard_should_use();
                },
            ],
        ];
    }
}

if (!function_exists('yooadmin_network_hidden_admin_page_hook')) {
    function yooadmin_network_hidden_admin_page_hook(string $menu_slug): string
    {
        return get_plugin_page_hookname($menu_slug, '');
    }
}

if (!function_exists('yooadmin_network_hidden_admin_page_hook_aliases')) {
    /**
     * WordPress resolves different hook names for the same ?page= slug depending on parent context.
     *
     * @return string[]
     */
    function yooadmin_network_hidden_admin_page_hook_aliases(string $menu_slug): array
    {
        $parents = ['', 'admin.php', 'index.php', 'settings.php', 'sites.php', 'users.php', 'plugins.php', 'themes.php'];
        $hooks   = [];

        foreach ($parents as $parent) {
            $hooks[] = get_plugin_page_hookname($menu_slug, $parent);
        }

        return array_values(array_unique(array_filter($hooks)));
    }
}

if (!function_exists('yooadmin_network_register_hidden_admin_page')) {
    /**
     * Register admin.php?page= callback (hidden from menu). Same pattern as single-site YOOUpdate Center.
     *
     * @return string Hook suffix used for load-{hook} handlers.
     */
    function yooadmin_network_register_hidden_admin_page(
        string $page_title,
        string $menu_slug,
        callable $callback
    ): string {
        global $_registered_pages, $_parent_pages, $_wp_submenu_nopriv, $_wp_menu_nopriv;

        $register_cap = 'read';
        $hook         = add_submenu_page('', $page_title, '', $register_cap, $menu_slug, $callback);

        $hooknames = yooadmin_network_hidden_admin_page_hook_aliases($menu_slug);
        $primary   = $hooknames[0] ?? yooadmin_network_hidden_admin_page_hook($menu_slug);

        foreach ($hooknames as $hookname) {
            $_registered_pages[ $hookname ] = true;
            if (!has_action($hookname, $callback)) {
                add_action($hookname, $callback);
            }
        }

        $_parent_pages[ $menu_slug ] = '';

        foreach (array_merge([''], ['index.php', 'settings.php', 'admin.php']) as $parent_key) {
            unset($_wp_submenu_nopriv[ $parent_key ][ $menu_slug ]);
        }
        unset($_wp_menu_nopriv[ $menu_slug ]);

        if (is_string($hook) && $hook !== '') {
            return $hook;
        }

        return $primary;
    }
}

if (!function_exists('yooadmin_network_submenu_remove_slug_only')) {
    function yooadmin_network_submenu_remove_slug_only(string $parent_file, string $menu_slug): void
    {
        global $submenu;

        if ($menu_slug === '' || !isset($submenu[ $parent_file ]) || !is_array($submenu[ $parent_file ])) {
            return;
        }

        foreach ($submenu[ $parent_file ] as $index => $item) {
            if (!is_array($item) || empty($item[2])) {
                continue;
            }
            if ((string) $item[2] === $menu_slug) {
                unset($submenu[ $parent_file ][ $index ]);
            }
        }

        $submenu[ $parent_file ] = array_values($submenu[ $parent_file ]);
    }
}

if (!function_exists('yooadmin_network_submenu_replace_entry')) {
    /**
     * @param string[] $legacy_slugs
     */
    function yooadmin_network_submenu_replace_entry(
        string $parent_file,
        string $menu_title,
        string $submenu_cap,
        string $menu_slug,
        array $legacy_slugs,
        string $page_title = ''
    ): void {
        global $submenu, $_wp_submenu_nopriv;

        if (!isset($submenu[ $parent_file ]) || !is_array($submenu[ $parent_file ])) {
            $submenu[ $parent_file ] = [];
        }

        unset($_wp_submenu_nopriv[ $parent_file ][ $menu_slug ]);

        $entry = [
            $menu_title,
            $submenu_cap,
            $menu_slug,
            $page_title !== '' ? $page_title : $menu_title,
        ];

        $replace = array_values(array_unique(array_merge($legacy_slugs, [ $menu_slug ])));
        $rebuilt = [];
        $added   = false;

        foreach ($submenu[ $parent_file ] as $item) {
            if (!is_array($item) || empty($item[2])) {
                $rebuilt[] = $item;
                continue;
            }

            $item_slug = (string) $item[2];
            if (in_array($item_slug, $replace, true)) {
                if (!$added) {
                    $rebuilt[] = $entry;
                    $added     = true;
                }
                continue;
            }

            $rebuilt[] = $item;
        }

        if (!$added) {
            $rebuilt[] = $entry;
        }

        $submenu[ $parent_file ] = $rebuilt;
    }
}

if (!function_exists('yooadmin_network_resolve_registry_slug')) {
    function yooadmin_network_resolve_registry_slug(string $logical_slug): string
    {
        switch ($logical_slug) {
            case 'yooadmin-network-update-center':
                return function_exists('yooadmin_network_update_center_page_slug')
                    ? yooadmin_network_update_center_page_slug()
                    : $logical_slug;
            case 'yooadmin-network-upgrade':
                return function_exists('yooadmin_network_upgrade_page_slug')
                    ? yooadmin_network_upgrade_page_slug()
                    : $logical_slug;
            case 'yooadmin-network-setup':
                return function_exists('yooadmin_network_setup_page_slug')
                    ? yooadmin_network_setup_page_slug()
                    : $logical_slug;
            case 'yooadmin-network-dashboard':
                return function_exists('yooadmin_network_dashboard_slug')
                    ? yooadmin_network_dashboard_slug()
                    : $logical_slug;
            default:
                return $logical_slug;
        }
    }
}

if (!function_exists('yooadmin_network_sync_registered_submenus')) {
    /**
     * Rewrite native submenu slugs to YOOAdmin pages (display only — callbacks stay hidden-registered).
     */
    function yooadmin_network_sync_registered_submenus(): void
    {
        if (!is_multisite() || !is_network_admin()) {
            return;
        }

        $registry = yooadmin_network_admin_page_registry();

        foreach ($registry as $logical_slug => $meta) {
            $slug   = yooadmin_network_resolve_registry_slug($logical_slug);
            $parent = (string) $meta['parent'];

            $should_use = is_callable($meta['should_use']) ? (bool) $meta['should_use']() : false;
            if (!$should_use) {
                yooadmin_network_submenu_remove_slug_only($parent, $slug);
                continue;
            }

            $submenu_cap = is_callable($meta['submenu_cap']) ? (string) $meta['submenu_cap']() : 'manage_network';

            switch ($logical_slug) {
                case 'yooadmin-network-update-center':
                    $legacy     = ['update-core.php'];
                    $menu_title = __('Updates', 'yooadmin');
                    break;
                case 'yooadmin-network-upgrade':
                    $legacy     = ['upgrade.php'];
                    $menu_title = __('Upgrade Network', 'yooadmin');
                    break;
                case 'yooadmin-network-setup':
                    $legacy     = ['setup.php'];
                    $menu_title = __('Network Setup', 'yooadmin');
                    break;
                case 'yooadmin-network-dashboard':
                    $legacy     = ['index.php'];
                    $menu_title = __('Home', 'yooadmin');
                    break;
                default:
                    $legacy     = [];
                    $menu_title = $logical_slug;
                    break;
            }

            yooadmin_network_submenu_replace_entry(
                $parent,
                $menu_title,
                $submenu_cap,
                $slug,
                array_merge($legacy, [ $slug ])
            );
        }

        if (function_exists('yooadmin_network_submenu_dedupe_by_slug')) {
            yooadmin_network_submenu_dedupe_by_slug('index.php');
            yooadmin_network_submenu_dedupe_by_slug('settings.php');
        }
    }

    add_action('network_admin_menu', 'yooadmin_network_sync_registered_submenus', 99999);
}

/** @deprecated Use yooadmin_network_register_hidden_admin_page(). */
if (!function_exists('yooadmin_network_register_admin_page')) {
    function yooadmin_network_register_admin_page(
        string $parent_slug,
        string $page_title,
        string $menu_title,
        string $menu_slug,
        callable $callback,
        ?int $position = null
    ): string {
        unset($parent_slug, $menu_title, $position);

        return yooadmin_network_register_hidden_admin_page($page_title, $menu_slug, $callback);
    }
}

/** @deprecated Renamed to yooadmin_network_sync_registered_submenus(). */
if (!function_exists('yooadmin_network_ensure_registered_pages_access')) {
    function yooadmin_network_ensure_registered_pages_access(): void
    {
        yooadmin_network_sync_registered_submenus();
    }
}
