<?php
defined('ABSPATH') || exit;

if (!function_exists('yooadmin_network_update_center_page_slug')) {
    function yooadmin_network_update_center_page_slug(): string
    {
        return (string) apply_filters('yooadmin_network_update_center_page_slug', 'yooadmin-network-update-center');
    }
}

if (!function_exists('yooadmin_network_update_center_url')) {
    function yooadmin_network_update_center_url(array $args = []): string
    {
        $url = network_admin_url('admin.php?page=' . yooadmin_network_update_center_page_slug());
        if ($args !== []) {
            $url = add_query_arg($args, $url);
        }

        return $url;
    }
}

if (!function_exists('yooadmin_network_update_center_classic_url')) {
    function yooadmin_network_update_center_classic_url(): string
    {
        return network_admin_url('update-core.php?yooadmin_no_redirect=1');
    }
}

if (!function_exists('yooadmin_network_update_center_submenu_cap')) {
    /**
     * Capability shown on the Updates submenu (matches core network update-core.php).
     */
    function yooadmin_network_update_center_submenu_cap(): string
    {
        if (current_user_can('update_core')) {
            return 'update_core';
        }
        if (current_user_can('update_plugins')) {
            return 'update_plugins';
        }
        if (current_user_can('update_themes')) {
            return 'update_themes';
        }

        return 'update_languages';
    }
}

if (!function_exists('yooadmin_network_update_center_menu_cap')) {
    /**
     * Capability used when registering the admin page hook (must always register).
     */
    function yooadmin_network_update_center_menu_cap(): string
    {
        return (string) apply_filters('yooadmin_network_update_center_menu_cap', 'read');
    }
}

if (!function_exists('yooadmin_network_update_center_user_can_view')) {
    function yooadmin_network_update_center_user_can_view(): bool
    {
        if (is_multisite() && is_super_admin()) {
            return true;
        }

        return current_user_can('update_core')
            || current_user_can('update_plugins')
            || current_user_can('update_themes')
            || current_user_can('update_languages');
    }
}

if (!function_exists('yooadmin_network_update_center_should_use')) {
    /**
     * Whether the network YOOUpdate Center replaces core update-core.php (Focus Mode required).
     */
    function yooadmin_network_update_center_should_use(): bool
    {
        if (!is_multisite()) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        $enabled = true;
        if (function_exists('yooadmin_get_option')) {
            $enabled = (bool) yooadmin_get_option('network_update_center_redirect', true);
        }

        return (bool) apply_filters('yooadmin_network_update_center_should_use', $enabled);
    }
}

if (!function_exists('yooadmin_network_update_center_is_screen')) {
    function yooadmin_network_update_center_is_screen(): bool
    {
        if (!is_multisite() || !is_network_admin()) {
            return false;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        return $page === yooadmin_network_update_center_page_slug();
    }
}

if (!function_exists('yooadmin_network_update_center_bootstrap')) {
    /**
     * Load YOOUpdate Center render + AJAX handlers when the network page is used.
     */
    function yooadmin_network_update_center_bootstrap(): void
    {
        if (!defined('YOOADMIN_PANEL_DIR')) {
            return;
        }

        $render = YOOADMIN_PANEL_DIR . 'includes/admin/update-center-render.php';
        if (!function_exists('yooadmin_uc_get_tab_counts') && is_readable($render)) {
            require_once $render;
        }

        $ajax = YOOADMIN_PANEL_DIR . 'includes/admin/update-center-ajax.php';
        if (!class_exists('YOOAdmin_Update_Center_Ajax') && is_readable($ajax)) {
            require_once $ajax;
            YOOAdmin_Update_Center_Ajax::get_instance();
        }
    }
}

if (!function_exists('yooadmin_network_update_center_maybe_route_before_access')) {
    /**
     * Redirect classic update-core when YOOUpdate Center is off (runs before menu access check).
     */
    function yooadmin_network_update_center_maybe_route_before_access(): void
    {
        if (!is_multisite() || !is_network_admin()) {
            return;
        }
        if (wp_doing_ajax() || wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
            return;
        }
        if (
            !function_exists('yooadmin_network_update_center_is_screen')
            || !yooadmin_network_update_center_is_screen()
        ) {
            return;
        }
        if (
            function_exists('yooadmin_network_update_center_should_use')
            && yooadmin_network_update_center_should_use()
        ) {
            return;
        }

        wp_safe_redirect(yooadmin_network_update_center_classic_url());
        exit;
    }

    add_action('network_admin_menu', 'yooadmin_network_update_center_maybe_route_before_access', 999999);
}
