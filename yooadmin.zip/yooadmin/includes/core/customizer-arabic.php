<?php
/**
 * YOOAdmin — Customizer Arabic typography and RTL chevron fixes.
 *
 * The main admin asset loader skips customize.php when Focus Mode is off.
 * This module loads Tajawal and RTL arrow corrections when Focus is on and the UI is Arabic or RTL.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_customizer_arabic_applies')) {
    /**
     * Whether Arabic Customizer overrides should load.
     */
    function yooadmin_customizer_arabic_applies(): bool {
        if (!is_admin()) {
            return false;
        }

        if (!function_exists('yooadmin_is_customizer_request') || !yooadmin_is_customizer_request()) {
            return false;
        }

        if (!function_exists('yooadmin_resolve_focus_preference') || !yooadmin_resolve_focus_preference()) {
            return false;
        }

        if (function_exists('yooadmin_is_arabic_admin_ui') && yooadmin_is_arabic_admin_ui()) {
            return true;
        }

        return function_exists('is_rtl') && is_rtl();
    }
}

if (!function_exists('yooadmin_enqueue_customizer_arabic_assets')) {
    /**
     * Enqueue Tajawal + RTL chevron fixes for the Customizer controls pane.
     */
    function yooadmin_enqueue_customizer_arabic_assets(): void {
        if (!yooadmin_customizer_arabic_applies()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $dir       = plugin_dir_path($base_file);
        $url       = plugin_dir_url($base_file);

        $font_rel = 'assets/fonts/tajawal.css';
        $css_rel  = 'assets/css/admin/customizer-arabic.css';

        if (is_readable($dir . $font_rel)) {
            wp_enqueue_style(
                'yooadmin-tajawal',
                $url . $font_rel,
                [],
                (string) filemtime($dir . $font_rel)
            );
        }

        if (!is_readable($dir . $css_rel)) {
            return;
        }

        $deps = ['customize-controls'];
        if (wp_style_is('yooadmin-tajawal', 'registered') || wp_style_is('yooadmin-tajawal', 'enqueued')) {
            $deps[] = 'yooadmin-tajawal';
        }
        if (wp_style_is('yooadmin-studio-hub-customizer-dark', 'registered') || wp_style_is('yooadmin-studio-hub-customizer-dark', 'enqueued')) {
            $deps[] = 'yooadmin-studio-hub-customizer-dark';
        }

        wp_enqueue_style(
            'yooadmin-customizer-arabic',
            $url . $css_rel,
            $deps,
            (string) filemtime($dir . $css_rel)
        );
    }
}

add_action('customize_controls_enqueue_scripts', 'yooadmin_enqueue_customizer_arabic_assets', 25);
add_action('admin_enqueue_scripts', 'yooadmin_enqueue_customizer_arabic_assets', 25);
