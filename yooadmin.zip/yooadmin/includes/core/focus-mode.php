<?php
/**
 * YOOAdmin - Focus mode (preference, cookie, body classes)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

if (!defined('YOOADMIN_FOCUS_MODE')) {
    define('YOOADMIN_FOCUS_MODE', 'global'); // 'global' or 'param' (legacy param mode)
}

if (!defined('YOOADMIN_USER_FOCUS_META_KEY')) {
    define('YOOADMIN_USER_FOCUS_META_KEY', 'yooadmin_user_focus_mode');
}

if (!function_exists('yooadmin_focus_preference_capability')) {
    /**
     * Capability for per-user Focus Mode preference (sidebar toggle).
     *
     * @return string
     */
    function yooadmin_focus_preference_capability(): string {
        return (string) apply_filters('yooadmin_focus_preference_capability', 'read');
    }
}

if (!function_exists('yooadmin_user_can_manage_focus_policy')) {
    function yooadmin_user_can_manage_focus_policy(): bool {
        if (is_super_admin()) {
            return true;
        }

        if (is_multisite() && is_network_admin() && current_user_can('manage_network')) {
            return true;
        }

        return function_exists('yooadmin_user_can_manage_site_settings')
            ? yooadmin_user_can_manage_site_settings()
            : current_user_can('manage_options');
    }
}

if (!function_exists('yooadmin_normalize_user_focus_preference')) {
    function yooadmin_normalize_user_focus_preference(string $value): string {
        return $value === 'off' ? 'off' : ($value === 'on' ? 'on' : '');
    }
}

/**
 * Saved Focus Mode preference for a user ('' = not set yet).
 */
if (!function_exists('yooadmin_get_user_focus_preference')) {
    function yooadmin_get_user_focus_preference(int $user_id = 0): string {
        if ($user_id <= 0) {
            $user_id = (int) get_current_user_id();
        }
        if ($user_id <= 0) {
            return yooadmin_normalize_user_focus_preference(yooadmin_get_focus_cookie());
        }

        $stored = get_user_meta($user_id, YOOADMIN_USER_FOCUS_META_KEY, true);
        if (is_string($stored) && $stored !== '') {
            return yooadmin_normalize_user_focus_preference($stored);
        }

        $cookie = yooadmin_get_focus_cookie();
        if ($cookie === 'on' || $cookie === 'off') {
            update_user_meta($user_id, YOOADMIN_USER_FOCUS_META_KEY, $cookie);

            return $cookie;
        }

        return '';
    }
}

if (!function_exists('yooadmin_save_user_focus_preference')) {
    function yooadmin_save_user_focus_preference(string $value, int $user_id = 0): bool {
        $value = yooadmin_normalize_user_focus_preference($value);
        if ($value === '') {
            return false;
        }

        if ($user_id <= 0) {
            $user_id = (int) get_current_user_id();
        }
        if ($user_id <= 0) {
            yooadmin_set_focus_cookie($value);

            return true;
        }

        yooadmin_set_focus_cookie($value);

        $existing = get_user_meta($user_id, YOOADMIN_USER_FOCUS_META_KEY, true);
        if ($existing === $value) {
            return true;
        }

        return update_user_meta($user_id, YOOADMIN_USER_FOCUS_META_KEY, $value) !== false;
    }
}

/* ------------------------------------------------------------------------
 * Utilities
 * --------------------------------------------------------------------- */

/** Detect if current screen is one of our panel pages */
if (!function_exists('yooadmin_is_panel_screen')) {
    function yooadmin_is_panel_screen(): bool {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only check
        if (empty($_GET['page'])) {
            return false;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
        $page = sanitize_text_field(wp_unslash($_GET['page']));
        return is_string($page) && strpos($page, 'yooadmin-') === 0;
    }
}

/** Cookie utils */
if (!function_exists('yooadmin_get_focus_cookie')) {
    function yooadmin_get_focus_cookie(): string {
        return isset($_COOKIE['yoo_focus']) ? sanitize_text_field(wp_unslash($_COOKIE['yoo_focus'])) : '';
    }
}
if (!function_exists('yooadmin_set_focus_cookie')) {
    function yooadmin_set_focus_cookie($val): void {
        $val = ($val === 'on') ? 'on' : 'off';
        $exp = time() + YEAR_IN_SECONDS;
        if (!headers_sent()) {
            setcookie('yoo_focus', $val, $exp, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true);
        }
        $_COOKIE['yoo_focus'] = $val;
    }
}

/**
 * Re-enable Focus Mode after setup wizard (complete or skip with focus on).
 *
 * Clean data / activation can leave yooadmin_focus_policy=off and yoo_focus=off.
 * Raw setcookie() in admin-ajax is unreliable; persist user preference + in-process cookie.
 */
if (!function_exists('yooadmin_restore_focus_after_wizard')) {
    function yooadmin_restore_focus_after_wizard(): void {
        $policy = get_option('yooadmin_focus_policy', 'auto');
        if ($policy === 'off' || $policy === '') {
            update_option('yooadmin_focus_policy', 'auto');
        }

        if (function_exists('yooadmin_save_user_focus_preference')) {
            yooadmin_save_user_focus_preference('on');
            return;
        }

        if (function_exists('yooadmin_set_focus_cookie')) {
            yooadmin_set_focus_cookie('on');
        }
    }
}

if (!function_exists('yooadmin_redirect_strip_yoo_param')) {
    function yooadmin_redirect_strip_yoo_param(): void {
        $url = remove_query_arg('yoo');
        wp_safe_redirect($url);
        exit;
    }
}

/**
 * WordPress Customizer is a full-screen iframe application. Injecting the
 * YOOAdmin shell or global Focus Mode CSS into customize.php can freeze or
 * break the controls pane, especially with themes that load heavy setup UI.
 */
if (!function_exists('yooadmin_is_customizer_request')) {
    function yooadmin_is_customizer_request(): bool {
        if (!is_admin()) {
            return false;
        }

        global $pagenow, $wp_customize;

        if (isset($pagenow) && 'customize.php' === $pagenow) {
            return true;
        }

        if (isset($wp_customize) && $wp_customize instanceof WP_Customize_Manager) {
            return true;
        }

        $script_name = isset($_SERVER['SCRIPT_NAME']) ? basename(sanitize_text_field(wp_unslash($_SERVER['SCRIPT_NAME']))) : '';
        return 'customize.php' === $script_name;
    }
}

/** URL toggle → cookie (admin only) */
add_action('admin_init', function () {
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only toggle, no state change beyond cookie.
    if (!isset($_GET['yoo'])) {
        return;
    }
    $val = isset($_GET['yoo']) ? sanitize_text_field(wp_unslash($_GET['yoo'])) : '';
    // phpcs:enable WordPress.Security.NonceVerification.Recommended
    if ($val === 'on' || $val === 'off') {
        if (function_exists('yooadmin_save_user_focus_preference')) {
            yooadmin_save_user_focus_preference($val);
        } else {
            yooadmin_set_focus_cookie($val);
        }
        yooadmin_redirect_strip_yoo_param();
    }
});

/* ------------------------------------------------------------------------
 * Focus state resolvers
 * --------------------------------------------------------------------- */

/** Read policy option once, with sane default ('auto' | 'on' | 'off') */
if (!function_exists('yooadmin_get_focus_policy')) {
    function yooadmin_get_focus_policy(): string {
        $policy = get_option('yooadmin_focus_policy', 'auto');
        return in_array($policy, ['auto', 'on', 'off'], true) ? $policy : 'auto';
    }
}

/**
 * User/site Focus preference without screen-specific opt-outs (Customizer, etc.).
 * Use on customize.php to decide whether YOOAdmin chrome applies there.
 */
if (!function_exists('yooadmin_resolve_focus_preference')) {
    function yooadmin_resolve_focus_preference(): bool {
        $enabled = true;
        $user_id = (int) get_current_user_id();

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only URL parameter check; no state change.
        if (isset($_GET['yoo'])) {
            $yoo_param = sanitize_text_field(wp_unslash($_GET['yoo']));
            if ($yoo_param === 'off') {
                $enabled = false;
            } elseif ($yoo_param === 'on') {
                $enabled = true;
            }
        } else {
            // phpcs:enable WordPress.Security.NonceVerification.Recommended
            $pref = $user_id > 0
                ? yooadmin_get_user_focus_preference($user_id)
                : yooadmin_get_focus_cookie();

            if ($pref === 'off') {
                $enabled = false;
            } elseif ($pref === 'on') {
                $enabled = true;
            }
        }

        $policy = yooadmin_get_focus_policy();
        if ($policy === 'on') {
            $enabled = true;
        } elseif ($policy === 'off') {
            $enabled = false;
        }

        return (bool) apply_filters('yooadmin_focus_enabled', $enabled);
    }
}

/**
 * Central resolver for Focus Mode.
 * Base rule: ON unless cookie yoo_focus=off (or legacy param mode is used).
 * Then apply settings policy from yooadmin_focus_policy.
 * Finally expose a public filter 'yooadmin_focus_enabled'.
 */
if (!function_exists('yooadmin_is_focus_enabled')) {
    function yooadmin_is_focus_enabled(): bool {
        // CRITICAL: Setup wizard must ALWAYS show without shell/focus
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only check
        if (!empty($_GET['page']) && sanitize_text_field(wp_unslash($_GET['page'])) === 'yooadmin-setup') {
            return false;
        }

        if (yooadmin_is_customizer_request()) {
            return false;
        }

        return yooadmin_resolve_focus_preference();
    }
}

/**
 * Back-compat wrapper used by older code.
 * Keep the name but delegate to the central resolver.
 */
if (!function_exists('yooadmin_focus_enabled_by_pref')) {
    function yooadmin_focus_enabled_by_pref(): bool {
        return yooadmin_is_focus_enabled();
    }
}

/* ------------------------------------------------------------------------
 * Context helpers
 * --------------------------------------------------------------------- */

/** Block editor detection (must work during in_admin_header — screen is often not ready yet). */
if (!function_exists('yooadmin_is_block_editor')) {
    function yooadmin_is_block_editor(): bool {
        if (!is_admin()) {
            return false;
        }

        if (function_exists('yooadmin_studio_hub_is_gutenberg_admin_request')) {
            return yooadmin_studio_hub_is_gutenberg_admin_request();
        }

        global $pagenow;

        if (isset($pagenow) && 'site-editor.php' === $pagenow) {
            return true;
        }

        if (isset($pagenow) && in_array($pagenow, ['post.php', 'post-new.php'], true)) {
            if (function_exists('get_current_screen')) {
                try {
                    $screen = get_current_screen();
                    if ($screen && method_exists($screen, 'is_block_editor')) {
                        return (bool) $screen->is_block_editor();
                    }
                } catch (Throwable $e) {
                    // Fall through — screen not initialized yet during in_admin_header.
                }
            }

            $post_type = '';
            if ('post-new.php' === $pagenow) {
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing.
                $post_type = isset($_GET['post_type']) ? sanitize_key(wp_unslash($_GET['post_type'])) : 'post';
            } elseif (isset($_GET['post'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $post_id = absint(wp_unslash($_GET['post'])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                if ($post_id > 0) {
                    $resolved  = get_post_type($post_id);
                    $post_type = is_string($resolved) ? $resolved : '';
                }
            }

            if ('' !== $post_type && function_exists('use_block_editor_for_post_type')) {
                return (bool) use_block_editor_for_post_type($post_type);
            }
        }

        if (!function_exists('get_current_screen')) {
            return false;
        }

        try {
            $screen = get_current_screen();
            return ($screen && method_exists($screen, 'is_block_editor') && $screen->is_block_editor());
        } catch (Throwable $e) {
            return false;
        }
    }
}

/** High-level policy helpers used by shell/header logic */
if (!function_exists('yooadmin_should_hide_chrome')) {
    function yooadmin_should_hide_chrome(): bool {
        if (yooadmin_is_customizer_request()) {
            return false;
        }
        if (yooadmin_is_block_editor()) {
            return false;
        }
        return yooadmin_is_focus_enabled();
    }
}

if (!function_exists('yooadmin_should_inject_shell')) {
    function yooadmin_should_inject_shell(): bool {
        if (yooadmin_is_customizer_request()) {
            return false;
        }
        // Block editor uses Gutenberg chrome + Studio Hub block-editor hooks (same as subsite editors).
        if (yooadmin_is_block_editor()) {
            return false;
        }
        $inject = yooadmin_is_focus_enabled();

        /**
         * @param bool $inject Whether the YOOAdmin header/footer shell should render.
         */
        return (bool) apply_filters('yooadmin_should_inject_shell', $inject);
    }
}

/* ------------------------------------------------------------------------
 * Admin body classes
 * --------------------------------------------------------------------- */
add_filter('admin_body_class', function ($classes) {
    if (yooadmin_is_focus_enabled()) {
        $classes .= ' yoo-focus';
        if (function_exists('yooadmin_is_wc_screen') && yooadmin_is_wc_screen()) {
            $classes .= ' yoo-woo';
        }
        
        // Add yoo-list-screen class for WordPress list pages (plugins, themes, posts, etc)
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen) {
            $list_bases = ['plugins', 'themes', 'edit', 'upload', 'edit-comments', 'users', 'tools', 'options-general'];
            foreach ($list_bases as $base) {
                if (strpos($screen->base, $base) !== false) {
                    $classes .= ' yoo-list-screen';
                    break;
                }
            }
        }
    }
    if (function_exists('yooadmin_is_wc_heavy_spa_page') && yooadmin_is_wc_heavy_spa_page()) {
        $classes .= ' yoo-skip-heavy';
    }
    
    // Add body class for banner conversion feature (used by CSS)
    $opts = (array) get_option('yooadmin_panel_options', []);
    if (empty($opts)) {
        $opts = (array) get_option('yooadmin_options', []);
    }
    $convert_banners = !empty($opts['convert_banners_to_notifications']);
    
    if ($convert_banners) {
        $classes .= ' yp-convert-banners-enabled';
    }
    
    return $classes;
});

/* ------------------------------------------------------------------------
 * Hide WP footer (thank you/version) on panel screens when Focus is ON
 * --------------------------------------------------------------------- */
add_action('admin_init', function () {
    if (!is_admin()) {
        return;
    }
    if (!yooadmin_is_focus_enabled()) {
        return;
    }

    // Limit to our panel screens only
    $allowed = array(
        'yooadmin-dashboard',
        'yooadmin-settings',
        'yooadmin',
        'yooadmin-themes',
        'yooadmin-license',
    );
    $allowed = apply_filters('yooadmin_focus_panel_page_slugs', $allowed);

    // Hide footer on YOOAdmin pages
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
    $page = isset($_GET['page']) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
    if ($page && in_array($page, $allowed, true)) {
        add_filter('admin_footer_text', '__return_empty_string', 999);
        add_filter('update_footer', '__return_empty_string', 999);
    }
});

// Hide footer and enqueue focus-mode CSS on ALL admin pages when focus mode is enabled
add_action('admin_enqueue_scripts', function() {
    if (yooadmin_is_focus_enabled()) {
        add_filter('admin_footer_text', '__return_empty_string', 999);
        add_filter('update_footer', '__return_empty_string', 999);
        
        // Enqueue focus-mode CSS (includes update page fixes)
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $dir = plugin_dir_path($base_file);
        $url = plugin_dir_url($base_file);
        $css_path = $dir . 'assets/css/admin/focus-mode.css';
        
        if (file_exists($css_path)) {
            wp_enqueue_style('yooadmin-focus-mode', $url . 'assets/css/admin/focus-mode.css', [], filemtime($css_path));
        }
    }
}, 999);

if (!function_exists('yooadmin_enqueue_focus_toggle_assets')) {
    /**
     * Enqueue Focus toggle + policy alert scripts (sidebar, My Preferences, etc.).
     */
    function yooadmin_enqueue_focus_toggle_assets(): void {
        if (!is_admin() || !is_user_logged_in()) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_dir  = plugin_dir_path($base_file);
        $base_url  = plugin_dir_url($base_file);

        $alerts_js = $base_dir . 'assets/js/admin/focus-mode-alerts.js';
        if (file_exists($alerts_js)) {
            wp_enqueue_script(
                'yooadmin-focus-alerts',
                $base_url . 'assets/js/admin/focus-mode-alerts.js',
                ['yp-admin-core-essential'],
                (string) filemtime($alerts_js),
                true
            );
        }

        $toggle_js = $base_dir . 'assets/js/admin/yoo-focus-toggle.js';
        if (file_exists($toggle_js)) {
            $deps = wp_script_is('yooadmin-focus-alerts', 'enqueued') ? ['yp-admin-core-essential', 'yooadmin-focus-alerts'] : ['yp-admin-core-essential'];
            wp_enqueue_script(
                'yooadmin-focus-toggle',
                $base_url . 'assets/js/admin/yoo-focus-toggle.js',
                $deps,
                (string) filemtime($toggle_js),
                true
            );

            $focus_policy = function_exists('yooadmin_get_focus_policy') ? yooadmin_get_focus_policy() : 'auto';
            $focus_active = function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();

            wp_localize_script('yooadmin-focus-toggle', 'yooadmFocus', [
                'is_active'        => $focus_active,
                'policy'           => $focus_policy,
                'canManagePolicy'  => function_exists('yooadmin_user_can_manage_focus_policy')
                    && yooadmin_user_can_manage_focus_policy(),
                'saveNonce'        => wp_create_nonce('yooadmin_focus_mode'),
                'ajaxUrl'          => admin_url('admin-ajax.php'),
                'toggle_on_url'    => esc_url(add_query_arg('yoo', 'on')),
                'toggle_off_url'   => esc_url(add_query_arg('yoo', 'off')),
                'enable_focus_url' => function_exists('yooadmin_enable_focus_url')
                    ? esc_url(yooadmin_enable_focus_url(['yoo' => 'off']))
                    : esc_url(admin_url('admin.php?page=yooadmin-enable-focus&yoo=off')),
                'focus_home_url'   => function_exists('yooadmin_focus_home_url')
                    ? esc_url(yooadmin_focus_home_url())
                    : esc_url(admin_url('admin.php?page=yooadmin-dashboard&yoo=on')),
            ]);
        }
    }
}
