<?php
/**
 * YOOAdmin Dashboard Cards API (Lite + Studio Hub).
 *
 * Public registration API for third-party plugins. Uses WordPress hooks only —
 * compatible with WordPress.org plugin guidelines (extensibility, no core hijacking).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * Register a dashboard card for YOOAdmin Studio Hub layout sections.
 *
 * @param string               $id   Unique card id (a-z, 0-9, underscore, hyphen).
 * @param array<string, mixed> $args {
 *     @type string          $title       Card title in the layout picker.
 *     @type string          $description Optional. Shown in the picker list.
 *     @type string          $icon        Dashicons class. Default dashicons-admin-generic.
 *     @type callable        $render      Required. Echoes card HTML inside the section body.
 *     @type callable|null   $enqueue     Optional. Enqueues styles/scripts on dashboard + render.
 *     @type string          $capability  Required capability. Default read.
 *     @type string[]        $placements  main, aside, or both. Default both.
 *     @type string[]        $scopes      site, network, or both. Default site.
 *     @type int             $priority    Catalog sort (lower first). Default 10.
 * }
 * @return bool True when registered.
 */
function yooadmin_register_dashboard_card(string $id, array $args): bool {
    return YOOAdmin_Dashboard_Cards::instance()->register($id, $args);
}

/**
 * Remove a registered dashboard card.
 */
function yooadmin_unregister_dashboard_card(string $id): bool {
    return YOOAdmin_Dashboard_Cards::instance()->unregister($id);
}

/**
 * Whether a card id is registered.
 */
function yooadmin_is_dashboard_card(string $id): bool {
    return YOOAdmin_Dashboard_Cards::instance()->has($id);
}

/**
 * @return array<string, array<string, mixed>>
 */
function yooadmin_get_dashboard_cards(): array {
    return YOOAdmin_Dashboard_Cards::instance()->get_all();
}

/**
 * Catalog rows for Studio Hub picker / REST.
 *
 * @return array<int, array<string, mixed>>
 */
function yooadmin_get_dashboard_cards_catalog(): array {
    return YOOAdmin_Dashboard_Cards::instance()->get_catalog();
}

/**
 * Whether the current user may view a registered dashboard card/widget.
 */
function yooadmin_user_can_view_dashboard_card(string $id): bool {
    $id = sanitize_key($id);
    if ($id === '' || !yooadmin_is_dashboard_card($id)) {
        return false;
    }

    $cards = yooadmin_get_dashboard_cards();
    if (!isset($cards[ $id ]) || !is_array($cards[ $id ])) {
        return false;
    }

    $cap = isset($cards[ $id ]['capability']) ? (string) $cards[ $id ]['capability'] : 'read';

    return (bool) apply_filters(
        'yooadmin_user_can_view_dashboard_card',
        current_user_can($cap),
        $id,
        $cards[ $id ]
    );
}

/**
 * Active dashboard context for card scope filtering.
 *
 * @return string site|network
 */
function yooadmin_dashboard_card_active_context(): string {
    if (
        function_exists('yooadmin_network_dashboard_is_screen')
        && yooadmin_network_dashboard_is_screen()
    ) {
        return 'network';
    }

    return 'site';
}

/**
 * Normalize scope list on a registered card.
 *
 * @param array<string, mixed> $card Card row.
 * @return string[]
 */
function yooadmin_dashboard_card_normalize_scopes(array $card): array {
    $scopes = isset($card['scopes']) && is_array($card['scopes']) ? $card['scopes'] : [ 'site' ];
    $scopes = array_values(array_intersect($scopes, [ 'site', 'network' ]));

    return $scopes !== [] ? $scopes : [ 'site' ];
}

/**
 * Whether a card id is allowed in the given dashboard context.
 *
 * @param string $id      Card id.
 * @param string $context site|network
 */
function yooadmin_dashboard_card_allowed_in_context(string $id, string $context): bool {
    $context = $context === 'network' ? 'network' : 'site';
    $cards   = yooadmin_get_dashboard_cards();
    $id      = sanitize_key($id);

    if ($id === '' || !isset($cards[ $id ])) {
        return false;
    }

    return in_array($context, yooadmin_dashboard_card_normalize_scopes($cards[ $id ]), true);
}

/**
 * Catalog rows filtered for site or network dashboard.
 *
 * @param string|null $context site|network|null for active screen.
 * @return array<int, array<string, mixed>>
 */
function yooadmin_get_dashboard_cards_catalog_for_context(?string $context = null): array {
    if ($context === null) {
        $context = yooadmin_dashboard_card_active_context();
    }
    $context = $context === 'network' ? 'network' : 'site';
    $catalog = yooadmin_get_dashboard_cards_catalog();
    $out     = [];

    foreach ($catalog as $row) {
        $scopes = isset($row['scopes']) && is_array($row['scopes']) ? $row['scopes'] : [ 'site' ];
        if (in_array($context, $scopes, true)) {
            $out[] = $row;
        }
    }

    return $out;
}

/**
 * Render a registered card. Returns HTML (includes inner wrapper).
 */
function yooadmin_render_dashboard_card(string $id): string {
    $render = static function () use ($id): string {
        return YOOAdmin_Dashboard_Cards::instance()->render($id);
    };

    if (function_exists('yooadmin_with_admin_ui_locale')) {
        return yooadmin_with_admin_ui_locale($render);
    }

    return $render();
}

/**
 * @return array{styles: string, scripts: string}
 */
function yooadmin_capture_dashboard_card_assets(string $id): array {
    return YOOAdmin_Dashboard_Cards::instance()->capture_assets($id);
}

/**
 * Fires on init so plugins can register cards from plugins_loaded or init.
 */
function yooadmin_dashboard_cards_bootstrap(): void {
    /**
     * Register YOOAdmin dashboard cards for Studio Hub.
     */
    do_action('yooadmin_dashboard_cards_init');
}

add_action('init', 'yooadmin_dashboard_cards_bootstrap', 15);

/**
 * Built-in overview card (YOOAdmin dashboard widget).
 */
add_action(
    'yooadmin_dashboard_cards_init',
    static function (): void {
        if (!function_exists('yooadmin_dw_render_widget')) {
            return;
        }

        $cap = 'manage_options';
        if (function_exists('yooadmin_dw_get_settings')) {
            $settings = yooadmin_dw_get_settings();
            if (!empty($settings['capability'])) {
                $cap = (string) $settings['capability'];
            }
        }

        yooadmin_register_dashboard_card(
            'yooadmin_overview',
            [
                'title'       => __('YOOAdmin Overview', 'yooadmin'),
                'description' => __('Site stats, server info, and updates at a glance.', 'yooadmin'),
                'icon'        => 'dashicons-dashboard',
                'capability'  => $cap,
                'priority'    => 5,
                'placements'  => [ 'main', 'aside' ],
                'scopes'      => [ 'site', 'network' ],
                'enqueue'     => static function (): void {
                    if (function_exists('yooadmin_dw_enqueue_overview_assets')) {
                        yooadmin_dw_enqueue_overview_assets(true);
                    }
                },
                'render'      => static function (): void {
                    yooadmin_dw_render_widget();
                },
            ]
        );
    }
);

/**
 * Dashboard card registry (singleton).
 */
final class YOOAdmin_Dashboard_Cards {

    private static ?self $instance = null;

    /** @var array<string, array<string, mixed>> */
    private array $cards = [];

    public static function instance(): self {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * @param array<string, mixed> $args
     */
    public function register(string $id, array $args): bool {
        $id = $this->sanitize_id($id);
        if ($id === '') {
            return false;
        }

        if (empty($args['render']) || !is_callable($args['render'])) {
            return false;
        }

        $title = isset($args['title']) ? wp_strip_all_tags((string) $args['title']) : $id;
        if ($title === '') {
            $title = $id;
        }

        $placements = isset($args['placements']) && is_array($args['placements'])
            ? array_values(array_intersect($args['placements'], [ 'main', 'aside' ]))
            : [ 'main', 'aside' ];

        if ($placements === []) {
            $placements = [ 'main', 'aside' ];
        }

        $scopes = isset($args['scopes']) && is_array($args['scopes'])
            ? array_values(array_intersect($args['scopes'], [ 'site', 'network' ]))
            : [ 'site' ];
        if ($scopes === []) {
            $scopes = [ 'site' ];
        }

        $card = [
            'id'          => $id,
            'title'       => $title,
            'description' => isset($args['description']) ? wp_strip_all_tags((string) $args['description']) : '',
            'icon'        => $this->sanitize_icon((string) ($args['icon'] ?? 'dashicons-admin-generic')),
            'render'      => $args['render'],
            'enqueue'     => (isset($args['enqueue']) && is_callable($args['enqueue'])) ? $args['enqueue'] : null,
            'capability'  => isset($args['capability']) ? sanitize_key((string) $args['capability']) : 'read',
            'placements'  => $placements,
            'scopes'      => $scopes,
            'priority'    => isset($args['priority']) ? (int) $args['priority'] : 10,
            'type'        => 'card',
            'builtin'     => !empty($args['builtin']),
            'category'    => isset($args['category']) ? wp_strip_all_tags((string) $args['category']) : '',
        ];

        /**
         * Filter card args before storing.
         *
         * @param array<string, mixed> $card Card configuration.
         * @param string               $id   Card id.
         */
        $card = apply_filters('yooadmin_register_dashboard_card', $card, $id);

        if (empty($card['render']) || !is_callable($card['render'])) {
            return false;
        }

        $this->cards[ $id ] = $card;

        return true;
    }

    public function unregister(string $id): bool {
        $id = $this->sanitize_id($id);
        if ($id === '' || !isset($this->cards[ $id ])) {
            return false;
        }

        unset($this->cards[ $id ]);

        return true;
    }

    public function has(string $id): bool {
        $id = $this->sanitize_id($id);

        return $id !== '' && isset($this->cards[ $id ]);
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    public function get_all(): array {
        return $this->cards;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function get_catalog(): array {
        $catalog = [];

        foreach ($this->cards as $card) {
            if (!$this->user_can_view_card($card)) {
                continue;
            }

            $catalog[] = [
                'id'          => $card['id'],
                'title'       => $card['title'],
                'description' => $card['description'],
                'icon'        => $card['icon'],
                'context'     => 'normal',
                'type'        => 'card',
                'placements'  => $card['placements'],
                'scopes'      => yooadmin_dashboard_card_normalize_scopes($card),
                'priority'    => (int) $card['priority'],
                'builtin'     => !empty($card['builtin']),
                'category'    => isset($card['category']) ? (string) $card['category'] : '',
            ];
        }

        usort(
            $catalog,
            static function (array $a, array $b): int {
                $pa = (int) ($a['priority'] ?? 10);
                $pb = (int) ($b['priority'] ?? 10);
                if ($pa !== $pb) {
                    return $pa <=> $pb;
                }

                return strcasecmp((string) $a['title'], (string) $b['title']);
            }
        );

        /**
         * @param array<int, array<string, mixed>> $catalog
         */
        return apply_filters('yooadmin_dashboard_cards_catalog', $catalog);
    }

    public function render(string $id): string {
        $id = $this->sanitize_id($id);
        if ($id === '' || !isset($this->cards[ $id ])) {
            return $this->error_html(
                __('This dashboard card is not available.', 'yooadmin')
            );
        }

        $card = $this->cards[ $id ];

        if (!$this->user_can_view_card($card)) {
            return $this->error_html(
                __('You do not have permission to view this card.', 'yooadmin')
            );
        }

        if (is_callable($card['enqueue'])) {
            call_user_func($card['enqueue'], $id);
        }

        ob_start();
        echo '<div class="yp-studio-dashboard-card yp-studio-dashboard-card--' . esc_attr($id) . '">';
        try {
            call_user_func($card['render'], $id, $card);
        } catch (Throwable $e) {
            ob_end_clean();

            return $this->error_html(
                __('This dashboard card could not be loaded.', 'yooadmin')
            );
        }
        echo '</div>';

        $html = (string) ob_get_clean();

        if (trim(wp_strip_all_tags($html)) === '') {
            return $this->error_html(
                __('This dashboard card returned no content.', 'yooadmin')
            );
        }

        return $html;
    }

    /**
     * @return array{styles: string, scripts: string}
     */
    public function capture_assets(string $id): array {
        $id = $this->sanitize_id($id);
        if ($id === '' || !isset($this->cards[ $id ])) {
            return [ 'styles' => '', 'scripts' => '' ];
        }

        $card = $this->cards[ $id ];
        if (!is_callable($card['enqueue'])) {
            return [ 'styles' => '', 'scripts' => '' ];
        }

        $before_styles  = $this->queued_style_handles();
        $before_scripts = $this->queued_script_handles();

        call_user_func($card['enqueue'], $id);

        return [
            'styles'  => $this->print_new_styles($before_styles),
            'scripts' => $this->print_new_scripts($before_scripts),
        ];
    }

    private function sanitize_id(string $id): string {
        $id = sanitize_key($id);
        if ($id === '' || !preg_match('/^[a-z0-9_-]+$/', $id)) {
            return '';
        }

        return $id;
    }

    private function sanitize_icon(string $icon): string {
        $icon = sanitize_html_class($icon);
        if ($icon === '' || strpos($icon, 'dashicons-') !== 0) {
            return 'dashicons-admin-generic';
        }

        return $icon;
    }

    /**
     * @param array<string, mixed> $card
     */
    private function user_can_view_card(array $card): bool {
        $cap = isset($card['capability']) ? (string) $card['capability'] : 'read';

        return current_user_can($cap);
    }

    private function error_html(string $message): string {
        return '<p class="yp-studio-widget-section__error">' . esc_html($message) . '</p>';
    }

    /**
     * @return string[]
     */
    private function queued_style_handles(): array {
        if (!wp_styles()) {
            return [];
        }

        return array_keys(wp_styles()->queue);
    }

    /**
     * @return string[]
     */
    private function queued_script_handles(): array {
        if (!wp_scripts()) {
            return [];
        }

        return array_keys(wp_scripts()->queue);
    }

    /**
     * @param string[] $before
     */
    private function print_new_styles(array $before): string {
        if (!wp_styles()) {
            return '';
        }

        $after = array_diff(array_keys(wp_styles()->queue), $before);
        if ($after === []) {
            return '';
        }

        ob_start();
        foreach ($after as $handle) {
            wp_styles()->do_item($handle);
        }

        return (string) ob_get_clean();
    }

    /**
     * @param string[] $before
     */
    private function print_new_scripts(array $before): string {
        if (!wp_scripts()) {
            return '';
        }

        $after = array_diff(array_keys(wp_scripts()->queue), $before);
        if ($after === []) {
            return '';
        }

        ob_start();
        foreach ($after as $handle) {
            wp_scripts()->do_item($handle);
        }

        return (string) ob_get_clean();
    }
}
