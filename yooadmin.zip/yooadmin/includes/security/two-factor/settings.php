<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

/** @var YOOAdmin_Settings $this */

$two_factor_enabled = !empty($login_two_factor_enabled);
$two_factor_plugin  = class_exists('Two_Factor_Core');

$tf_method_totp         = !isset($login_two_factor_method_totp) || !empty($login_two_factor_method_totp);
$tf_method_email        = !isset($login_two_factor_method_email) || !empty($login_two_factor_method_email);
$tf_method_backup_codes = !isset($login_two_factor_method_backup_codes) || !empty($login_two_factor_method_backup_codes);

$tf_primary_options = [];
if ($tf_method_totp) {
    $tf_primary_options[ YOOAdmin_2FA_Core::PROVIDER_TOTP ] = YOOAdmin_2FA_Core::provider_label(YOOAdmin_2FA_Core::PROVIDER_TOTP);
}
if ($tf_method_email) {
    $tf_primary_options[ YOOAdmin_2FA_Core::PROVIDER_EMAIL ] = YOOAdmin_2FA_Core::provider_label(YOOAdmin_2FA_Core::PROVIDER_EMAIL);
}
if ($tf_method_backup_codes) {
    $tf_primary_options[ YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES ] = YOOAdmin_2FA_Core::provider_label(YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES);
}
if ($tf_primary_options === []) {
    $tf_primary_options[ YOOAdmin_2FA_Core::PROVIDER_TOTP ] = YOOAdmin_2FA_Core::provider_label(YOOAdmin_2FA_Core::PROVIDER_TOTP);
}

$tf_default_primary = isset($login_two_factor_default_primary)
    ? sanitize_key((string) $login_two_factor_default_primary)
    : YOOAdmin_2FA_Core::PROVIDER_TOTP;
if (!isset($tf_primary_options[ $tf_default_primary ])) {
    $tf_default_primary = (string) array_key_first($tf_primary_options);
}

$security_inner_active   = isset($security_inner_active) ? sanitize_key((string) $security_inner_active) : 'turnstile';
$two_factor_panel_active = ($security_inner_active === 'two-factor');
?>
<div class="yp-tab-panel yooadmin-security-inner-panel<?php echo $two_factor_panel_active ? ' is-active' : ''; ?>" data-security-inner-panel="two-factor" id="yooadmin-security-panel-two-factor" role="tabpanel" aria-labelledby="yp-security-inner-tab-two-factor"<?php echo $two_factor_panel_active ? '' : ' hidden'; ?>>
    <div class="yooadmin-security-panel-content">
        <p class="yp-help yooadmin-security-card__lead">
            <?php esc_html_e('Add a second verification step after the password on wp-login.php and the YOOAdmin login page when that layout is enabled. Users set up their own methods from their profile.', 'yooadmin'); ?>
        </p>

        <table class="form-table yooadmin-security-toggle-table"><tbody>
            <tr class="yooadmin-security-master-toggle-row">
                <th scope="row">
                    <div class="yp-th-content">
                        <span class="dashicons dashicons-shield-alt yp-th-icon"></span>
                        <span><?php esc_html_e('Two-factor authentication', 'yooadmin'); ?></span>
                        <span class="yp-help-icon">
                            <span class="dashicons dashicons-editor-help"></span>
                            <span class="yp-tooltip"><?php esc_html_e('When enabled, users manage 2FA from their YOOAdmin profile and complete verification during sign-in on wp-login.php and the YOOAdmin login page.', 'yooadmin'); ?></span>
                        </span>
                    </div>
                </th>
                <td>
                    <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_two_factor_enabled]" value="0">
                    <?php
                    $tf_desc = __('Protect accounts with a second sign-in step.', 'yooadmin');
                    $tf_on   = __('Enable two-factor authentication', 'yooadmin');
                    $tf_off  = __('Two-factor authentication off', 'yooadmin');
                    $tf_toggle = $this->render_toggle_field(
                        'login_two_factor_enabled',
                        $two_factor_enabled ? $tf_on : $tf_off,
                        $tf_desc,
                        $two_factor_enabled,
                        'login_two_factor_enabled',
                        $this->opt_options,
                        false
                    );
                    echo wp_kses($tf_toggle['toggle'], $this->get_toggle_allowed_html());
                    ?>
                </td>
            </tr>
        </tbody></table>

        <div class="yooadmin-native-2fa-settings-body<?php echo $two_factor_enabled ? '' : ' yooadmin-security-panel-body--disabled'; ?>">
            <p class="yp-help yooadmin-native-2fa-settings__intro"><?php esc_html_e('Choose which verification methods users can enable in their profile.', 'yooadmin'); ?></p>
            <table class="form-table"><tbody>
                <tr>
                    <th scope="row">
                        <div class="yp-th-content">
                            <span class="dashicons dashicons-smartphone yp-th-icon"></span>
                            <span><?php echo esc_html(YOOAdmin_2FA_Core::provider_label(YOOAdmin_2FA_Core::PROVIDER_TOTP)); ?></span>
                            <span class="yp-help-icon">
                                <span class="dashicons dashicons-editor-help"></span>
                                <span class="yp-tooltip"><?php esc_html_e('Users can scan a QR code with an authenticator app.', 'yooadmin'); ?></span>
                            </span>
                        </div>
                    </th>
                    <td>
                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_two_factor_method_totp]" value="0">
                        <?php
                        $totp_toggle = $this->render_toggle_field(
                            'login_two_factor_method_totp',
                            $tf_method_totp
                                ? __('Authenticator app available', 'yooadmin')
                                : __('Authenticator app disabled', 'yooadmin'),
                            __('Users can scan a QR code with an authenticator app.', 'yooadmin'),
                            $tf_method_totp,
                            'login_two_factor_method_totp',
                            $this->opt_options,
                            false,
                            !$two_factor_enabled
                        );
                        echo wp_kses($totp_toggle['toggle'], $this->get_toggle_allowed_html());
                        ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <div class="yp-th-content">
                            <span class="dashicons dashicons-email yp-th-icon"></span>
                            <span><?php echo esc_html(YOOAdmin_2FA_Core::provider_label(YOOAdmin_2FA_Core::PROVIDER_EMAIL)); ?></span>
                            <span class="yp-help-icon">
                                <span class="dashicons dashicons-editor-help"></span>
                                <span class="yp-tooltip"><?php esc_html_e('Users receive a one-time code by email during sign-in.', 'yooadmin'); ?></span>
                            </span>
                        </div>
                    </th>
                    <td>
                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_two_factor_method_email]" value="0">
                        <?php
                        $email_toggle = $this->render_toggle_field(
                            'login_two_factor_method_email',
                            $tf_method_email
                                ? __('Email codes available', 'yooadmin')
                                : __('Email codes disabled', 'yooadmin'),
                            __('Users receive a one-time code by email during sign-in.', 'yooadmin'),
                            $tf_method_email,
                            'login_two_factor_method_email',
                            $this->opt_options,
                            false,
                            !$two_factor_enabled
                        );
                        echo wp_kses($email_toggle['toggle'], $this->get_toggle_allowed_html());
                        ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <div class="yp-th-content">
                            <span class="dashicons dashicons-clock yp-th-icon"></span>
                            <span><?php esc_html_e('Email resend protection', 'yooadmin'); ?></span>
                            <span class="yp-help-icon">
                                <span class="dashicons dashicons-editor-help"></span>
                                <span class="yp-tooltip"><?php esc_html_e('Limits how often users can request a new email code during sign-in.', 'yooadmin'); ?></span>
                            </span>
                        </div>
                    </th>
                    <td>
                        <div class="yooadmin-native-2fa-email-resend-limits">
                            <label class="screen-reader-text" for="login_two_factor_email_resend_cooldown"><?php esc_html_e('Resend cooldown (seconds)', 'yooadmin'); ?></label>
                            <input
                                type="number"
                                class="ylp-input ylp-input--settings ylp-input--narrow"
                                min="15"
                                max="3600"
                                step="1"
                                name="<?php echo esc_attr($this->opt_options); ?>[login_two_factor_email_resend_cooldown]"
                                id="login_two_factor_email_resend_cooldown"
                                value="<?php echo esc_attr((string) $login_two_factor_email_resend_cooldown); ?>"
                                <?php disabled(!$two_factor_enabled || !$tf_method_email); ?>
                            />
                            <span class="yooadmin-native-2fa-email-resend-limits__unit"><?php esc_html_e('seconds between resend requests', 'yooadmin'); ?></span>
                            <span class="yooadmin-native-2fa-email-resend-limits__sep" aria-hidden="true">·</span>
                            <label class="screen-reader-text" for="login_two_factor_email_resend_max"><?php esc_html_e('Maximum resend attempts', 'yooadmin'); ?></label>
                            <input
                                type="number"
                                class="ylp-input ylp-input--settings ylp-input--narrow"
                                min="1"
                                max="20"
                                step="1"
                                name="<?php echo esc_attr($this->opt_options); ?>[login_two_factor_email_resend_max]"
                                id="login_two_factor_email_resend_max"
                                value="<?php echo esc_attr((string) $login_two_factor_email_resend_max); ?>"
                                <?php disabled(!$two_factor_enabled || !$tf_method_email); ?>
                            />
                            <span class="yooadmin-native-2fa-email-resend-limits__unit"><?php esc_html_e('max resends per active code', 'yooadmin'); ?></span>
                        </div>
                        <p class="description yooadmin-login-security-field-note"><?php esc_html_e('Applies to the YOOAdmin native email method during sign-in on wp-login.php and the YOOAdmin login page.', 'yooadmin'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <div class="yp-th-content">
                            <span class="dashicons dashicons-backup yp-th-icon"></span>
                            <span><?php echo esc_html(YOOAdmin_2FA_Core::provider_label(YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES)); ?></span>
                            <span class="yp-help-icon">
                                <span class="dashicons dashicons-editor-help"></span>
                                <span class="yp-tooltip"><?php esc_html_e('Users can generate single-use backup codes.', 'yooadmin'); ?></span>
                            </span>
                        </div>
                    </th>
                    <td>
                        <input type="hidden" name="<?php echo esc_attr($this->opt_options); ?>[login_two_factor_method_backup_codes]" value="0">
                        <?php
                        $backup_toggle = $this->render_toggle_field(
                            'login_two_factor_method_backup_codes',
                            $tf_method_backup_codes
                                ? __('Recovery codes available', 'yooadmin')
                                : __('Recovery codes disabled', 'yooadmin'),
                            __('Users can generate single-use backup codes.', 'yooadmin'),
                            $tf_method_backup_codes,
                            'login_two_factor_method_backup_codes',
                            $this->opt_options,
                            false,
                            !$two_factor_enabled
                        );
                        echo wp_kses($backup_toggle['toggle'], $this->get_toggle_allowed_html());
                        ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <div class="yp-th-content">
                            <span class="dashicons dashicons-sort yp-th-icon"></span>
                            <span><?php esc_html_e('Default primary method', 'yooadmin'); ?></span>
                            <span class="yp-help-icon">
                                <span class="dashicons dashicons-editor-help"></span>
                                <span class="yp-tooltip"><?php esc_html_e('Used first when a user has multiple methods enabled.', 'yooadmin'); ?></span>
                            </span>
                        </div>
                    </th>
                    <td>
                        <div class="yp-select-wrap yp-select-wrap--security">
                            <select
                                class="yp-select"
                                name="<?php echo esc_attr($this->opt_options); ?>[login_two_factor_default_primary]"
                                id="login_two_factor_default_primary"
                                <?php disabled(!$two_factor_enabled); ?>
                            >
                                <?php foreach ($tf_primary_options as $provider_key => $provider_label) : ?>
                                    <option value="<?php echo esc_attr($provider_key); ?>" <?php selected($tf_default_primary, $provider_key); ?>>
                                        <?php echo esc_html($provider_label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <p class="description yooadmin-login-security-field-note"><?php esc_html_e('Other enabled methods remain available as alternatives during sign-in.', 'yooadmin'); ?></p>
                    </td>
                </tr>
            </tbody></table>

            <?php if ($two_factor_plugin) : ?>
            <p class="yp-help yooadmin-native-2fa-settings__intro yooadmin-native-2fa-settings__intro--migration"><?php esc_html_e('Copy existing user 2FA settings from the WordPress Two-Factor plugin.', 'yooadmin'); ?></p>
            <table class="form-table"><tbody>
                <tr>
                    <th scope="row">
                        <div class="yp-th-content">
                            <span class="dashicons dashicons-migrate yp-th-icon"></span>
                            <span><?php esc_html_e('Import from WordPress Two-Factor', 'yooadmin'); ?></span>
                        </div>
                    </th>
                    <td>
                        <div class="yooadmin-native-2fa-settings__import">
                            <button
                                type="button"
                                class="button yp-yoo-btn yp-yoo-btn--soft"
                                id="yooadmin-2fa-run-migration"
                                data-nonce="<?php echo esc_attr(wp_create_nonce('yooadmin_2fa_migration')); ?>"
                                <?php disabled(!$two_factor_enabled); ?>
                            >
                                <?php esc_html_e('Run manual import', 'yooadmin'); ?>
                            </button>
                            <div id="yooadmin-2fa-migration-result" class="yooadmin-native-2fa-migration-result" aria-live="polite" hidden></div>
                        </div>
                    </td>
                </tr>
            </tbody></table>
            <?php endif; ?>
        </div>
    </div>
</div>
