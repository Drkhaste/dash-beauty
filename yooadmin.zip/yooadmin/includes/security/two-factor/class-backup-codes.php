<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

final class YOOAdmin_2FA_Backup_Codes {

    private const CODE_COUNT = 10;
    private const CODE_LENGTH = 8;

    /**
     * @return string[] Plaintext codes (show once).
     */
    public static function generate(int $user_id): array {
        $codes = [];
        for ($i = 0; $i < self::CODE_COUNT; $i++) {
            $codes[] = self::random_code();
        }

        self::store_hashed($user_id, $codes);

        return $codes;
    }

    public static function verify(int $user_id, string $code): bool {
        $code = strtolower(preg_replace('/\s+/', '', $code) ?? '');
        if ($code === '') {
            return false;
        }

        $stored = get_user_meta($user_id, YOOAdmin_2FA_Core::META_BACKUP_CODES, true);
        if (!is_array($stored)) {
            return false;
        }

        $hash = YOOAdmin_2FA_Core::hash_code($code);
        $hit  = false;
        $next = [];

        foreach ($stored as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $entry_hash = (string) ($entry['hash'] ?? '');
            $used       = !empty($entry['used']);
            if (!$used && $entry_hash !== '' && hash_equals($entry_hash, $hash)) {
                $hit = true;
                $entry['used'] = 1;
            }
            $next[] = $entry;
        }

        if ($hit) {
            update_user_meta($user_id, YOOAdmin_2FA_Core::META_BACKUP_CODES, $next);
        }

        return $hit;
    }

    public static function remaining_count(int $user_id): int {
        $stored = get_user_meta($user_id, YOOAdmin_2FA_Core::META_BACKUP_CODES, true);
        if (!is_array($stored)) {
            return 0;
        }

        $count = 0;
        foreach ($stored as $entry) {
            if (is_array($entry) && empty($entry['used'])) {
                $count++;
            }
        }

        return $count;
    }

    public static function clear(int $user_id): void {
        delete_user_meta($user_id, YOOAdmin_2FA_Core::META_BACKUP_CODES);
    }

    /**
     * @param string[] $codes
     */
    private static function store_hashed(int $user_id, array $codes): void {
        $entries = [];
        foreach ($codes as $code) {
            $entries[] = [
                'hash' => YOOAdmin_2FA_Core::hash_code($code),
                'used' => 0,
            ];
        }
        update_user_meta($user_id, YOOAdmin_2FA_Core::META_BACKUP_CODES, $entries);
    }

    private static function random_code(): string {
        $chars = 'abcdefghijklmnopqrstuvwxyz23456789';
        $max   = strlen($chars) - 1;
        $code  = '';
        for ($i = 0; $i < self::CODE_LENGTH; $i++) {
            $code .= $chars[random_int(0, $max)];
        }

        return $code;
    }
}
