<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

final class YOOAdmin_2FA_Core {

    public const META_ENABLED_PROVIDERS = '_yooadmin_2fa_enabled_providers';
    public const META_PRIMARY_PROVIDER  = '_yooadmin_2fa_primary_provider';
    public const META_TOTP_SECRET         = '_yooadmin_2fa_totp_secret';
    public const META_BACKUP_CODES        = '_yooadmin_2fa_backup_codes';
    public const META_EMAIL_TOKEN         = '_yooadmin_2fa_email_token';
    public const META_EMAIL_TOKEN_TIME    = '_yooadmin_2fa_email_token_time';

    public const PROVIDER_TOTP         = 'totp';
    public const PROVIDER_EMAIL        = 'email';
    public const PROVIDER_BACKUP_CODES = 'backup_codes';

    /**
     * Whether the site-level YOOAdmin 2FA service is enabled.
     */
    public static function is_service_enabled(): bool {
        if (!function_exists('yooadmin_get_options')) {
            return false;
        }

        $opts = yooadmin_get_options();

        return !empty($opts['login_two_factor_enabled']);
    }

    /**
     * Whether any external 2FA plugin is active for this user.
     */
    public static function user_has_external_2fa(int $user_id): bool {
        if ($user_id <= 0) {
            return false;
        }

        $user = get_user_by('id', $user_id);
        if (!($user instanceof WP_User)) {
            return false;
        }

        if (class_exists('Two_Factor_Core') && Two_Factor_Core::is_user_using_two_factor($user_id)) {
            return true;
        }

        if (
            function_exists('yooadmin_standalone_login_two_factor_wp2fa_is_available')
            && yooadmin_standalone_login_two_factor_wp2fa_is_available()
            && class_exists('\WP2FA\Admin\Helpers\User_Helper')
            && method_exists('\WP2FA\Admin\Helpers\User_Helper', 'is_user_using_two_factor')
            && \WP2FA\Admin\Helpers\User_Helper::is_user_using_two_factor($user_id)
        ) {
            return true;
        }

        if (
            class_exists('\WordfenceLS\Controller_Users')
            && \WordfenceLS\Controller_Users::shared()->has_2fa_active($user)
        ) {
            return true;
        }

        if (
            function_exists('yooadmin_standalone_login_two_factor_google_authenticator_requires')
            && yooadmin_standalone_login_two_factor_google_authenticator_requires($user)
        ) {
            return true;
        }

        /** @var bool $has */
        return (bool) apply_filters('yooadmin_2fa_user_has_external', false, $user);
    }

    /**
     * Whether any external 2FA plugin is installed on the site.
     */
    public static function site_has_external_2fa_plugin(): bool {
        if (class_exists('Two_Factor_Core')) {
            return true;
        }
        if (function_exists('yooadmin_standalone_login_two_factor_wp2fa_is_available') && yooadmin_standalone_login_two_factor_wp2fa_is_available()) {
            return true;
        }
        if (class_exists('\WordfenceLS\Controller_TOTP')) {
            return true;
        }
        if (class_exists('GoogleAuthenticator')) {
            return true;
        }

        /** @var bool $has */
        return (bool) apply_filters('yooadmin_2fa_site_has_external_plugin', false);
    }

    /**
     * Whether the user has YOOAdmin native 2FA enabled.
     */
    public static function is_user_using_2fa(int $user_id): bool {
        $providers = self::get_enabled_providers($user_id);

        return $providers !== [];
    }

    /**
     * @return string[]
     */
    public static function get_enabled_providers(int $user_id): array {
        $raw = get_user_meta($user_id, self::META_ENABLED_PROVIDERS, true);
        if (!is_array($raw)) {
            return [];
        }

        $allowed = [self::PROVIDER_TOTP, self::PROVIDER_EMAIL, self::PROVIDER_BACKUP_CODES];
        $out     = [];
        foreach ($raw as $key) {
            $key = sanitize_key((string) $key);
            if (in_array($key, $allowed, true) && !in_array($key, $out, true)) {
                $out[] = $key;
            }
        }

        return array_values(array_intersect($out, self::get_site_allowed_providers()));
    }

    public static function get_primary_provider(int $user_id): string {
        $primary = sanitize_key((string) get_user_meta($user_id, self::META_PRIMARY_PROVIDER, true));
        $enabled = self::get_enabled_providers($user_id);

        if ($primary !== '' && in_array($primary, $enabled, true)) {
            return $primary;
        }

        $site_default = self::get_site_default_primary();
        if ($site_default !== '' && in_array($site_default, $enabled, true)) {
            return $site_default;
        }

        return $enabled[0] ?? '';
    }

    /**
     * Site-wide allowed verification methods (admin settings).
     *
     * @return string[]
     */
    public static function get_site_allowed_providers(): array {
        $all = self::all_provider_definitions();
        if (!function_exists('yooadmin_get_options')) {
            return $all;
        }

        $opts = yooadmin_get_options();
        $map  = [
            self::PROVIDER_TOTP         => 'login_two_factor_method_totp',
            self::PROVIDER_EMAIL        => 'login_two_factor_method_email',
            self::PROVIDER_BACKUP_CODES => 'login_two_factor_method_backup_codes',
        ];
        $out  = [];
        foreach ($all as $provider) {
            $key = $map[ $provider ] ?? '';
            if ($key === '' || !empty($opts[ $key ])) {
                $out[] = $provider;
            }
        }

        return $out !== [] ? $out : [ self::PROVIDER_TOTP ];
    }

    /**
     * Default primary method for sign-in (admin settings).
     */
    public static function get_site_default_primary(): string {
        if (!function_exists('yooadmin_get_options')) {
            return self::PROVIDER_TOTP;
        }

        $primary = sanitize_key((string) ( yooadmin_get_options()['login_two_factor_default_primary'] ?? '' ));
        $allowed = self::get_site_allowed_providers();

        if ($primary !== '' && in_array($primary, $allowed, true)) {
            return $primary;
        }

        return $allowed[0] ?? self::PROVIDER_TOTP;
    }

    /**
     * @param string[] $providers
     */
    public static function set_enabled_providers(int $user_id, array $providers, string $primary = ''): void {
        $allowed = [self::PROVIDER_TOTP, self::PROVIDER_EMAIL, self::PROVIDER_BACKUP_CODES];
        $clean   = [];
        foreach ($providers as $provider) {
            $provider = sanitize_key((string) $provider);
            if (in_array($provider, $allowed, true) && !in_array($provider, $clean, true)) {
                $clean[] = $provider;
            }
        }

        if ($clean === []) {
            delete_user_meta($user_id, self::META_ENABLED_PROVIDERS);
            delete_user_meta($user_id, self::META_PRIMARY_PROVIDER);
            return;
        }

        update_user_meta($user_id, self::META_ENABLED_PROVIDERS, $clean);

        $primary = sanitize_key($primary);
        if ($primary === '' || !in_array($primary, $clean, true)) {
            $primary = $clean[0];
        }
        update_user_meta($user_id, self::META_PRIMARY_PROVIDER, $primary);
    }

    public static function provider_label(string $provider): string {
        switch ($provider) {
            case self::PROVIDER_TOTP:
                return __('Authenticator app (TOTP)', 'yooadmin');
            case self::PROVIDER_EMAIL:
                return __('Email code', 'yooadmin');
            case self::PROVIDER_BACKUP_CODES:
                return __('Recovery codes', 'yooadmin');
            default:
                return $provider;
        }
    }

    /**
     * @return string[]
     */
    public static function all_provider_definitions(): array {
        return [self::PROVIDER_TOTP, self::PROVIDER_EMAIL, self::PROVIDER_BACKUP_CODES];
    }

    public static function seal_secret(string $plaintext): string {
        if ($plaintext === '') {
            return '';
        }

        $key = hash('sha256', wp_salt('auth') . 'yooadmin_2fa', true);
        $iv  = random_bytes(16);
        if (function_exists('openssl_encrypt')) {
            $cipher = openssl_encrypt($plaintext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
            if (is_string($cipher)) {
                return base64_encode($iv . $cipher);
            }
        }

        return base64_encode($iv . $plaintext);
    }

    public static function unseal_secret(string $stored): string {
        if ($stored === '') {
            return '';
        }

        $decoded = base64_decode($stored, true);
        if (!is_string($decoded) || strlen($decoded) < 17) {
            return '';
        }

        $key    = hash('sha256', wp_salt('auth') . 'yooadmin_2fa', true);
        $iv     = substr($decoded, 0, 16);
        $cipher = substr($decoded, 16);

        if (function_exists('openssl_decrypt')) {
            $plain = openssl_decrypt($cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
            if (is_string($plain)) {
                return $plain;
            }
        }

        return is_string($cipher) ? $cipher : '';
    }

    public static function hash_code(string $code): string {
        return wp_hash(strtolower(preg_replace('/\s+/', '', $code)));
    }

    /**
     * Whether native profile UI should render for this user.
     */
    public static function should_show_native_profile(WP_User $user): bool {
        if (!self::is_service_enabled()) {
            return false;
        }

        if (self::user_has_external_2fa($user->ID)) {
            return false;
        }

        return current_user_can('edit_user', $user->ID);
    }
}

if (!function_exists('yooadmin_login_security_two_factor_is_active')) {
    /**
     * Whether two-factor protection is active (native service or external plugin).
     */
    function yooadmin_login_security_two_factor_is_active(): bool {
        if (class_exists('YOOAdmin_2FA_Core') && YOOAdmin_2FA_Core::is_service_enabled()) {
            return true;
        }

        return class_exists('YOOAdmin_2FA_Core') && YOOAdmin_2FA_Core::site_has_external_2fa_plugin();
    }
}
