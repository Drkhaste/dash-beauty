<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

function yooadmin_native_2fa_profile_is_available(WP_User $user): bool {
    return YOOAdmin_2FA_Core::should_show_native_profile($user);
}

function yooadmin_native_2fa_profile_enqueue_assets(): void {
    if (!YOOAdmin_2FA_Core::is_service_enabled()) {
        return;
    }

    $base = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
    if ($base === '') {
        return;
    }

    $qr_url   = plugin_dir_url($base) . 'assets/js/vendor/qrcode.min.js';
    $qr_path  = plugin_dir_path($base) . 'assets/js/vendor/qrcode.min.js';
    $js_url   = plugin_dir_url($base) . 'assets/js/admin/yoo-two-factor-profile.js';
    $js_path  = plugin_dir_path($base) . 'assets/js/admin/yoo-two-factor-profile.js';
    $css_url  = plugin_dir_url($base) . 'assets/css/admin/users-page.css';
    $css_path = plugin_dir_path($base) . 'assets/css/admin/users-page.css';
    $qr_ver   = is_readable($qr_path) ? (string) filemtime($qr_path) : '1';
    $js_ver   = is_readable($js_path) ? (string) filemtime($js_path) : '1';
    $css_ver  = is_readable($css_path) ? (string) filemtime($css_path) : '1';

    wp_enqueue_script(
        'yooadmin-qrcode',
        $qr_url,
        [],
        $qr_ver,
        true
    );

    wp_enqueue_script(
        'yooadmin-two-factor-profile',
        $js_url,
        ['jquery', 'yooadmin-qrcode'],
        $js_ver,
        true
    );

    wp_localize_script(
        'yooadmin-two-factor-profile',
        'yooadminNative2FA',
        [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('yooadmin_native_2fa'),
            'i18n'    => [
                'setupTotp'       => __('Set up authenticator', 'yooadmin'),
                'resetTotp'       => __('Reset authenticator', 'yooadmin'),
                'resetCurrentCode'=> __('Current 6-digit code', 'yooadmin'),
                'resetHint'       => __('If your QR code or secret key was exposed, generate a new one. Your old authenticator codes stop working after you verify the new device. Existing recovery codes are revoked for security — generate new ones afterward if needed.', 'yooadmin'),
                'resetSuccess'    => __('Authenticator app reset successfully. Old recovery codes were revoked — generate new ones if you still need them.', 'yooadmin'),
                'verify'          => __('Verify', 'yooadmin'),
                'generateCodes'   => __('Generate recovery codes', 'yooadmin'),
                'copied'          => __('Copied', 'yooadmin'),
                'qrUnavailable'   => __('QR preview unavailable. Use the manual key below.', 'yooadmin'),
                'error'           => __('Something went wrong. Please try again.', 'yooadmin'),
                'saveSuccess'     => __('Two-factor settings saved.', 'yooadmin'),
                'codesWarning'    => __('Save these recovery codes in a safe place. Each code can be used once. They are shown only once.', 'yooadmin'),
                'codesGenerated'  => __('Recovery codes generated. Download or copy them now — they will not be shown again.', 'yooadmin'),
                'download'        => __('Download', 'yooadmin'),
                'copyAll'         => __('Copy all', 'yooadmin'),
                'downloadName'    => __('yooadmin-recovery-codes.txt', 'yooadmin'),
                'enabled'         => __('Enabled', 'yooadmin'),
                'disabled'        => __('Disabled', 'yooadmin'),
            ],
        ]
    );

    $style_deps = [];
    if (wp_style_is('yooadmin-yoo-buttons', 'registered')) {
        wp_enqueue_style('yooadmin-yoo-buttons');
        $style_deps[] = 'yooadmin-yoo-buttons';
    }

    wp_enqueue_style('yooadmin-users-page', $css_url, $style_deps, $css_ver);
}

/**
 * @return string[]
 */
function yooadmin_native_2fa_profile_status_bits(string $provider_key, bool $checked, bool $totp_configured, int $backup_remaining): array {
    $bits = [
        $checked ? __('Enabled', 'yooadmin') : __('Disabled', 'yooadmin'),
    ];

    if ($provider_key === YOOAdmin_2FA_Core::PROVIDER_TOTP && $totp_configured) {
        $bits[] = __('Configured', 'yooadmin');
    } elseif ($provider_key === YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES && $backup_remaining > 0) {
        $bits[] = sprintf(
            /* translators: %d: remaining recovery codes */
            _n('%d recovery code remaining', '%d recovery codes remaining', $backup_remaining, 'yooadmin'),
            $backup_remaining
        );
    }

    return $bits;
}

function yooadmin_native_2fa_profile_render_toggle(string $id, string $name, string $value, bool $checked, bool $disabled): void {
    ?>
    <label class="yp-toggle-switch yoo-native-2fa__toggle" for="<?php echo esc_attr($id); ?>">
        <input
            type="checkbox"
            id="<?php echo esc_attr($id); ?>"
            name="<?php echo esc_attr($name); ?>"
            value="<?php echo esc_attr($value); ?>"
            <?php checked($checked); ?>
            <?php disabled($disabled); ?>
        />
        <span class="yp-toggle-slider"></span>
    </label>
    <?php
}

function yooadmin_native_2fa_profile_render(WP_User $user, bool $is_own_profile): void {
    if (!yooadmin_native_2fa_profile_is_available($user)) {
        return;
    }

    $template = defined('YOOADMIN_DIR')
        ? YOOADMIN_DIR . 'templates/yoopixel/admin/pages/users/partials/two-factor-options.php'
        : '';

    if ($template === '' || !is_readable($template)) {
        return;
    }

    $enabled_providers = YOOAdmin_2FA_Core::get_enabled_providers($user->ID);
    $providers         = YOOAdmin_2FA_Core::get_site_allowed_providers();
    $totp_configured   = YOOAdmin_2FA_TOTP::get_user_secret($user->ID) !== '';
    $backup_remaining  = YOOAdmin_2FA_Backup_Codes::remaining_count($user->ID);
    $revalidate_url    = '';

    if ($is_own_profile && YOOAdmin_2FA_Session::is_revalidation_required($user->ID)) {
        if (function_exists('yooadmin_profile_uses_yooadmin_profile_page') && yooadmin_profile_uses_yooadmin_profile_page()) {
            $revalidate_redirect = function_exists('yooadmin_profile_tab_url')
                ? yooadmin_profile_tab_url($user->ID, 'security')
                : (function_exists('yooadmin_profile_plugin_sections_url')
                    ? yooadmin_profile_plugin_sections_url($user->ID)
                    : admin_url());
        } elseif (function_exists('yooadmin_wp_core_profile_url')) {
            $revalidate_redirect = yooadmin_wp_core_profile_url($user->ID);
        } else {
            $revalidate_redirect = admin_url('profile.php');
        }

        $revalidate_url = function_exists('yooadmin_native_2fa_revalidate_login_url')
            ? yooadmin_native_2fa_revalidate_login_url($revalidate_redirect)
            : '';
    }

    include $template;
}

/**
 * Normalize submitted provider keys and drop methods that are not ready yet.
 *
 * @param array<int, string> $raw      Raw provider keys from POST/JSON.
 * @param int                $user_id  Profile user ID.
 * @return array{providers: string[], errors: string[]}
 */
function yooadmin_native_2fa_normalize_profile_providers(array $raw, int $user_id): array {
    $allowed   = YOOAdmin_2FA_Core::get_site_allowed_providers();
    $providers = array_values(
        array_intersect(
            array_map('sanitize_key', $raw),
            $allowed
        )
    );
    $errors    = [];

    if (in_array(YOOAdmin_2FA_Core::PROVIDER_TOTP, $providers, true) && YOOAdmin_2FA_TOTP::get_user_secret($user_id) === '') {
        $providers = array_values(array_diff($providers, [YOOAdmin_2FA_Core::PROVIDER_TOTP]));
        $errors[]  = __('Set up your authenticator app before enabling TOTP.', 'yooadmin');
    }

    if (in_array(YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES, $providers, true) && YOOAdmin_2FA_Backup_Codes::remaining_count($user_id) < 1) {
        $providers = array_values(array_diff($providers, [YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES]));
        $errors[]  = __('Generate recovery codes before enabling them.', 'yooadmin');
    }

    return [
        'providers' => $providers,
        'errors'    => $errors,
    ];
}

/**
 * @param mixed $payload JSON string or list of provider slugs from POST/AJAX.
 * @return string[]
 */
function yooadmin_native_2fa_parse_providers_payload($payload): array {
    if (is_string($payload)) {
        $decoded = json_decode($payload, true);
        $payload = is_array($decoded) ? $decoded : [];
    }

    if (!is_array($payload)) {
        return [];
    }

    $raw = [];
    foreach ($payload as $value) {
        if (is_scalar($value)) {
            $raw[] = (string) $value;
        }
    }

    return $raw;
}

/**
 * Read profile security POST fields. Call only after nonce verification.
 *
 * @return array<string, mixed>
 */
function yooadmin_native_2fa_read_profile_save_request(): array {
    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Caller verifies nonce; this only type-checks the superglobal.
    if (!is_array($_POST)) {
        return [];
    }

    // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Caller verifies nonce; provider slugs are sanitized via sanitize_key().
    $request = wp_unslash($_POST);
    // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

    return is_array($request) ? $request : [];
}

/**
 * @param array<string, mixed>|null $request Unslashed request payload; defaults to profile POST.
 * @return array{providers: string[], errors: string[]}|null Null when this request should not touch 2FA settings.
 */
function yooadmin_native_2fa_profile_providers_from_request(int $user_id, ?array $request = null): ?array {
    $request = $request ?? yooadmin_native_2fa_read_profile_save_request();

    if (array_key_exists('providers', $request)) {
        return yooadmin_native_2fa_normalize_profile_providers(
            yooadmin_native_2fa_parse_providers_payload($request['providers']),
            $user_id
        );
    }

    $action = isset($request['action']) ? sanitize_key((string) $request['action']) : '';
    $is_security_form = $action === 'save_profile_plugin_sections';
    $has_native_fields = !empty($request['yooadmin_native_2fa_present'])
        || isset($request['yooadmin_native_2fa_providers']);

    if (!$is_security_form && !$has_native_fields) {
        return null;
    }

    $raw = [];
    if (isset($request['yooadmin_native_2fa_providers']) && is_array($request['yooadmin_native_2fa_providers'])) {
        $raw = yooadmin_native_2fa_parse_providers_payload($request['yooadmin_native_2fa_providers']);
    }

    return yooadmin_native_2fa_normalize_profile_providers($raw, $user_id);
}

function yooadmin_native_2fa_profile_save(int $user_id): void {
    if ($user_id <= 0 || !YOOAdmin_2FA_Core::is_service_enabled()) {
        return;
    }

    if (YOOAdmin_2FA_Core::user_has_external_2fa($user_id)) {
        return;
    }

    $parsed = yooadmin_native_2fa_profile_providers_from_request($user_id);
    if ($parsed === null) {
        return;
    }

    if ($parsed['errors'] !== []) {
        set_transient(
            'yooadmin_native_2fa_profile_errors_' . $user_id,
            $parsed['errors'],
            MINUTE_IN_SECONDS
        );
    } else {
        delete_transient('yooadmin_native_2fa_profile_errors_' . $user_id);
    }

    YOOAdmin_2FA_Core::set_enabled_providers(
        $user_id,
        $parsed['providers'],
        YOOAdmin_2FA_Core::get_site_default_primary()
    );
}
add_action('personal_options_update', 'yooadmin_native_2fa_profile_save');
add_action('edit_user_profile_update', 'yooadmin_native_2fa_profile_save');
