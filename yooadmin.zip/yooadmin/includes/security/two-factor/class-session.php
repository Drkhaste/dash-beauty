<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

final class YOOAdmin_2FA_Session {

    private const TRANSIENT_PREFIX = 'yooadmin_2fa_login_';
    private const REVALIDATE_PREFIX  = 'yooadmin_2fa_reval_';
    private const TTL                = 600;

    public static function create_login_nonce(int $user_id): ?string {
        if ($user_id <= 0) {
            return null;
        }

        $key = wp_generate_password(20, false, false);
        set_transient(self::TRANSIENT_PREFIX . $user_id . '_' . $key, time(), self::TTL);

        return $key;
    }

    public static function check_login_nonce(int $user_id, string $key): bool {
        if ($user_id <= 0 || $key === '') {
            return false;
        }

        return get_transient(self::TRANSIENT_PREFIX . $user_id . '_' . $key) !== false;
    }

    public static function consume_login_nonce(int $user_id, string $key): void {
        if ($user_id <= 0 || $key === '') {
            return;
        }

        delete_transient(self::TRANSIENT_PREFIX . $user_id . '_' . $key);
    }

    public static function create_revalidate_nonce(int $user_id): string {
        return wp_create_nonce('yooadmin_2fa_revalidate_' . $user_id);
    }

    public static function verify_revalidate_nonce(int $user_id, string $nonce): bool {
        return wp_verify_nonce($nonce, 'yooadmin_2fa_revalidate_' . $user_id) !== false;
    }

    public static function mark_revalidated(int $user_id): void {
        if ($user_id <= 0 || !class_exists('WP_Session_Tokens')) {
            return;
        }

        $token = wp_get_session_token();
        if ($token === '') {
            return;
        }

        $manager = WP_Session_Tokens::get_instance($user_id);
        $session = $manager->get($token);
        if (!is_array($session)) {
            return;
        }

        $session['yooadmin-2fa-login']    = time();
        $session['yooadmin-2fa-provider']  = YOOAdmin_2FA_Core::get_primary_provider($user_id);
        $manager->update($token, $session);
    }

    public static function is_revalidation_required(int $user_id): bool {
        if ($user_id <= 0 || !YOOAdmin_2FA_Core::is_user_using_2fa($user_id)) {
            return false;
        }

        $token = wp_get_session_token();
        if ($token === '') {
            return true;
        }

        $session = WP_Session_Tokens::get_instance($user_id)->get($token);
        if (!is_array($session)) {
            return true;
        }

        $validated = (int) ($session['yooadmin-2fa-login'] ?? 0);
        if ($validated <= 0) {
            return true;
        }

        return (time() - $validated) > HOUR_IN_SECONDS;
    }
}
