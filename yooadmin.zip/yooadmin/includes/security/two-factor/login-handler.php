<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

/**
 * @param array<string, array<string, callable>> $handlers Handlers.
 * @return array<string, array<string, callable>>
 */
function yooadmin_native_2fa_register_login_handler(array $handlers): array {
    if (!YOOAdmin_2FA_Core::is_service_enabled()) {
        return $handlers;
    }

    $handlers['yooadmin-native-2fa'] = [
        'requires'  => 'yooadmin_native_2fa_login_requires',
        'begin'     => 'yooadmin_native_2fa_login_begin',
        'challenge' => 'yooadmin_native_2fa_login_challenge',
        'validate'  => 'yooadmin_native_2fa_login_validate',
    ];

    return $handlers;
}
add_filter('yooadmin_standalone_login_two_factor_handlers', 'yooadmin_native_2fa_register_login_handler', 100);

/**
 * @param WP_User $user User.
 */
function yooadmin_native_2fa_login_requires(WP_User $user): bool {
    if (!YOOAdmin_2FA_Core::is_service_enabled()) {
        return false;
    }

    return YOOAdmin_2FA_Core::is_user_using_2fa($user->ID);
}

/**
 * @param WP_User $user        User.
 * @param bool    $remember    Remember me.
 * @param string  $redirect_to Redirect target.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_native_2fa_login_begin(WP_User $user, bool $remember, string $redirect_to) {
    wp_clear_auth_cookie();

    $auth_nonce = YOOAdmin_2FA_Session::create_login_nonce($user->ID);
    if ($auth_nonce === null) {
        return new WP_Error(
            'two_factor_nonce_failed',
            __('Two-factor authentication could not be started. Please try again.', 'yooadmin')
        );
    }

    $provider = YOOAdmin_2FA_Core::get_primary_provider($user->ID);
    if ($provider === '') {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    $challenge = yooadmin_native_2fa_build_challenge($user, $provider, $auth_nonce);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'yooadmin-native-2fa',
        'user_id'     => $user->ID,
        'auth_nonce'  => $auth_nonce,
        'provider'    => $provider,
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @param WP_User $user        User.
 * @param string  $auth_nonce  Nonce.
 * @param string  $provider_key Provider.
 * @param bool    $remember    Remember.
 * @param string  $redirect_to Redirect.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_native_2fa_login_challenge(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    bool $remember,
    string $redirect_to
) {
    if (!YOOAdmin_2FA_Session::check_login_nonce($user->ID, $auth_nonce)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $provider = $provider_key !== '' ? sanitize_key($provider_key) : YOOAdmin_2FA_Core::get_primary_provider($user->ID);
    $enabled  = YOOAdmin_2FA_Core::get_enabled_providers($user->ID);
    if (!in_array($provider, $enabled, true)) {
        $provider = YOOAdmin_2FA_Core::get_primary_provider($user->ID);
    }

    $challenge = yooadmin_native_2fa_build_challenge($user, $provider, $auth_nonce);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'yooadmin-native-2fa',
        'user_id'     => $user->ID,
        'auth_nonce'  => $auth_nonce,
        'provider'    => $provider,
        'remember'    => $remember,
        'redirect_to' => $redirect_to,
        'challenge'   => $challenge,
    ];
}

/**
 * @param WP_User $user        User.
 * @param string  $auth_nonce  Nonce.
 * @param string  $provider_key Provider.
 * @param array<string, mixed> $request Request fields.
 * @param bool    $remember    Remember.
 * @param string  $redirect_to Redirect.
 * @return true|array<string, mixed>|WP_Error
 */
function yooadmin_native_2fa_login_validate(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    array $request,
    bool $remember,
    string $redirect_to
) {
    $provider = $provider_key !== '' ? sanitize_key($provider_key) : YOOAdmin_2FA_Core::get_primary_provider($user->ID);

    if (
        $provider === YOOAdmin_2FA_Core::PROVIDER_EMAIL
        && (!empty($request['resend_email_code']) || !empty($request['resend']))
    ) {
        return yooadmin_native_2fa_resend_email_challenge(
            $user,
            $auth_nonce,
            $provider,
            $remember,
            $redirect_to,
            false
        );
    }

    if (!YOOAdmin_2FA_Session::check_login_nonce($user->ID, $auth_nonce)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $provider = $provider_key !== '' ? sanitize_key($provider_key) : YOOAdmin_2FA_Core::get_primary_provider($user->ID);
    $valid    = yooadmin_native_2fa_verify_provider_code($user->ID, $provider, $request);

    if (!$valid) {
        return new WP_Error(
            'two_factor_invalid',
            __('Invalid verification code. Please try again.', 'yooadmin')
        );
    }

    YOOAdmin_2FA_Session::consume_login_nonce($user->ID, $auth_nonce);

    wp_set_auth_cookie($user->ID, $remember, is_ssl());
    wp_set_current_user($user->ID);

    return true;
}

/**
 * @param array<string, mixed>|WP_Error|null $payload     Existing payload.
 * @param WP_User                            $user        User.
 * @param string                             $redirect_to Redirect.
 * @return array<string, mixed>|WP_Error|null
 */
function yooadmin_native_2fa_begin_revalidate($payload, WP_User $user, string $redirect_to) {
    if ($payload !== null) {
        return $payload;
    }

    if (!YOOAdmin_2FA_Core::is_service_enabled() || !YOOAdmin_2FA_Core::is_user_using_2fa($user->ID)) {
        return null;
    }

    if (YOOAdmin_2FA_Core::user_has_external_2fa($user->ID)) {
        return null;
    }

    if (!is_user_logged_in() || get_current_user_id() !== $user->ID) {
        return new WP_Error(
            'two_factor_reauth_required',
            __('You must be signed in to revalidate your session.', 'yooadmin')
        );
    }

    $auth_nonce = YOOAdmin_2FA_Session::create_revalidate_nonce($user->ID);
    $provider   = YOOAdmin_2FA_Core::get_primary_provider($user->ID);
    $challenge  = yooadmin_native_2fa_build_challenge($user, $provider, $auth_nonce, true);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'yooadmin-native-2fa',
        'mode'        => 'revalidate',
        'user_id'     => $user->ID,
        'auth_nonce'  => $auth_nonce,
        'provider'    => $provider,
        'remember'    => false,
        'redirect_to' => wp_validate_redirect($redirect_to, admin_url()),
        'challenge'   => $challenge,
    ];
}
add_filter('yooadmin_standalone_login_two_factor_begin_revalidate', 'yooadmin_native_2fa_begin_revalidate', 5, 3);

if (!function_exists('yooadmin_native_2fa_revalidate_login_url')) {
    function yooadmin_native_2fa_revalidate_login_url(string $redirect_to = ''): string {
        $redirect_to = $redirect_to !== ''
            ? wp_validate_redirect($redirect_to, admin_url())
            : admin_url();

        $args = [
            'action'      => 'revalidate_2fa',
            'redirect_to' => $redirect_to,
        ];

        if (
            function_exists('yooadmin_native_2fa_should_use_wp_login_forms')
            && !yooadmin_native_2fa_should_use_wp_login_forms()
        ) {
            if (function_exists('yooadmin_standalone_login_public_url')) {
                return add_query_arg($args, yooadmin_standalone_login_public_url());
            }

            if (function_exists('yooadmin_standalone_login_url')) {
                return add_query_arg($args, yooadmin_standalone_login_url());
            }
        }

        if (function_exists('yooadmin_native_2fa_core_wp_login_url')) {
            return yooadmin_native_2fa_core_wp_login_url($args);
        }

        return add_query_arg($args, site_url('wp-login.php?action=revalidate_2fa', 'login'));
    }
}

/**
 * @param WP_User $user        User.
 * @param string  $auth_nonce  Nonce.
 * @param string  $provider_key Provider.
 * @param bool    $remember    Unused.
 * @param string  $redirect_to Redirect.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_native_2fa_revalidate_challenge(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    bool $remember,
    string $redirect_to
) {
    unset($remember);

    if (!YOOAdmin_2FA_Session::verify_revalidate_nonce($user->ID, $auth_nonce)) {
        $auth_nonce = YOOAdmin_2FA_Session::create_revalidate_nonce($user->ID);
    }

    $provider = $provider_key !== '' ? sanitize_key($provider_key) : YOOAdmin_2FA_Core::get_primary_provider($user->ID);
    $challenge = yooadmin_native_2fa_build_challenge($user, $provider, $auth_nonce, true);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    return [
        'handler'     => 'yooadmin-native-2fa',
        'mode'        => 'revalidate',
        'user_id'     => $user->ID,
        'auth_nonce'  => $auth_nonce,
        'provider'    => $provider,
        'remember'    => false,
        'redirect_to' => wp_validate_redirect($redirect_to, admin_url()),
        'challenge'   => $challenge,
    ];
}

/**
 * @param WP_User $user        User.
 * @param string  $auth_nonce  Nonce.
 * @param string  $provider_key Provider.
 * @param array<string, mixed> $request Request.
 * @param bool    $remember    Unused.
 * @param string  $redirect_to Redirect.
 * @return true|WP_Error
 */
function yooadmin_native_2fa_revalidate_validate(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    array $request,
    bool $remember,
    string $redirect_to
) {
    $provider = $provider_key !== '' ? sanitize_key($provider_key) : YOOAdmin_2FA_Core::get_primary_provider($user->ID);

    if (
        $provider === YOOAdmin_2FA_Core::PROVIDER_EMAIL
        && (!empty($request['resend_email_code']) || !empty($request['resend']))
    ) {
        return yooadmin_native_2fa_resend_email_challenge(
            $user,
            $auth_nonce,
            $provider,
            $remember,
            $redirect_to,
            true
        );
    }

    unset($remember, $redirect_to);

    if (!YOOAdmin_2FA_Session::verify_revalidate_nonce($user->ID, $auth_nonce)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $provider = $provider_key !== '' ? sanitize_key($provider_key) : YOOAdmin_2FA_Core::get_primary_provider($user->ID);
    if (!yooadmin_native_2fa_verify_provider_code($user->ID, $provider, $request)) {
        return new WP_Error(
            'two_factor_invalid',
            __('Invalid verification code. Please try again.', 'yooadmin')
        );
    }

    YOOAdmin_2FA_Session::mark_revalidated($user->ID);

    return true;
}

/**
 * @param WP_User $user     User.
 * @param string  $provider Provider key.
 * @param string  $auth_nonce Nonce.
 * @param bool    $revalidate Revalidate mode.
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_native_2fa_build_challenge(
    WP_User $user,
    string $provider,
    string $auth_nonce,
    bool $revalidate = false,
    bool $send_email_code = true
) {
    if (function_exists('yooadmin_load_yooadmin_textdomain')) {
        $locale = function_exists('yooadmin_custom_login_get_login_locale')
            ? yooadmin_custom_login_get_login_locale()
            : null;
        yooadmin_load_yooadmin_textdomain($locale);
    }

    $enabled = YOOAdmin_2FA_Core::get_enabled_providers($user->ID);
    if (!in_array($provider, $enabled, true)) {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    if ($provider === YOOAdmin_2FA_Core::PROVIDER_EMAIL && $send_email_code) {
        $sent = YOOAdmin_2FA_Email::send_login_code($user, false);
        if (is_wp_error($sent)) {
            return $sent;
        }
        if (!$sent) {
            return new WP_Error(
                'two_factor_email_failed',
                __('Could not send the verification email. Please try again.', 'yooadmin')
            );
        }
    }

    $alternates = [];
    foreach ($enabled as $key) {
        if ($key === $provider) {
            continue;
        }
        $alternates[] = [
            'provider' => $key,
            'label'    => YOOAdmin_2FA_Core::provider_label($key),
        ];
    }

    $fields  = [];
    $actions = [];
    $lead    = '';

    switch ($provider) {
        case YOOAdmin_2FA_Core::PROVIDER_TOTP:
            $lead = __('Enter the code from your authenticator app.', 'yooadmin');
            $fields[] = [
                'name'         => 'authcode',
                'label'        => __('Authentication code', 'yooadmin'),
                'type'         => 'text',
                'inputmode'    => 'numeric',
                'autocomplete' => 'one-time-code',
                'placeholder'  => '123456',
                'required'     => true,
            ];
            break;

        case YOOAdmin_2FA_Core::PROVIDER_EMAIL:
            $lead = __('A verification code has been sent to your email address.', 'yooadmin');
            $fields[] = [
                'name'         => 'email_code',
                'label'        => __('Verification code', 'yooadmin'),
                'type'         => 'text',
                'inputmode'    => 'numeric',
                'autocomplete' => 'one-time-code',
                'placeholder'  => '',
                'required'     => true,
            ];
            $actions[] = [
                'name'  => 'resend_email_code',
                'label' => __('Resend code', 'yooadmin'),
                'type'  => 'secondary',
            ];
            break;

        case YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES:
            $lead = __('Enter one of your recovery codes.', 'yooadmin');
            $fields[] = [
                'name'         => 'backup_code',
                'label'        => __('Recovery code', 'yooadmin'),
                'type'         => 'text',
                'inputmode'    => 'text',
                'autocomplete' => 'one-time-code',
                'placeholder'  => __('8-character code', 'yooadmin'),
                'required'     => true,
                'pin'          => false,
            ];
            break;
    }

    $challenge = [
        'title'          => __('Two-factor authentication', 'yooadmin'),
        'lead'           => $lead,
        'provider'       => $provider,
        'provider_label' => YOOAdmin_2FA_Core::provider_label($provider),
        'fields'         => $fields,
        'actions'        => $actions,
        'alternates'     => $alternates,
        'fragment'       => '',
        'auth_nonce'     => $auth_nonce,
    ];

    if ($provider === YOOAdmin_2FA_Core::PROVIDER_EMAIL) {
        $challenge['resend_cooldown']    = YOOAdmin_2FA_Email::get_resend_cooldown_seconds();
        $challenge['resend_retry_after'] = YOOAdmin_2FA_Email::get_resend_retry_after($user->ID);
    }

    return $challenge;
}

/**
 * @return array<string, mixed>|WP_Error
 */
function yooadmin_native_2fa_resend_email_challenge(
    WP_User $user,
    string $auth_nonce,
    string $provider_key,
    bool $remember,
    string $redirect_to,
    bool $revalidate
) {
    $provider = $provider_key !== '' ? sanitize_key($provider_key) : YOOAdmin_2FA_Core::get_primary_provider($user->ID);
    if ($provider !== YOOAdmin_2FA_Core::PROVIDER_EMAIL) {
        return new WP_Error(
            'two_factor_provider_missing',
            __('Two-factor provider not available for this account.', 'yooadmin')
        );
    }

    if ($revalidate) {
        if (!YOOAdmin_2FA_Session::verify_revalidate_nonce($user->ID, $auth_nonce)) {
            return new WP_Error(
                'two_factor_expired',
                __('Your verification session expired. Please sign in again.', 'yooadmin')
            );
        }
    } elseif (!YOOAdmin_2FA_Session::check_login_nonce($user->ID, $auth_nonce)) {
        return new WP_Error(
            'two_factor_expired',
            __('Your verification session expired. Please sign in again.', 'yooadmin')
        );
    }

    $sent = YOOAdmin_2FA_Email::send_login_code($user, true);
    if (is_wp_error($sent)) {
        return $sent;
    }
    if (!$sent) {
        return new WP_Error(
            'two_factor_email_failed',
            __('Could not send the verification email. Please try again.', 'yooadmin')
        );
    }

    $challenge = yooadmin_native_2fa_build_challenge($user, $provider, $auth_nonce, $revalidate, false);
    if (is_wp_error($challenge)) {
        return $challenge;
    }

    $payload = [
        'resent'    => true,
        'message'   => __('A new verification code has been sent.', 'yooadmin'),
        'handler'   => 'yooadmin-native-2fa',
        'user_id'   => $user->ID,
        'auth_nonce'  => $auth_nonce,
        'provider'  => $provider,
        'remember'  => $remember,
        'redirect_to' => $redirect_to,
        'challenge' => $challenge,
    ];

    if ($revalidate) {
        $payload['mode'] = 'revalidate';
    }

    return $payload;
}

/**
 * @param array<string, mixed> $request
 */
function yooadmin_native_2fa_verify_provider_code(int $user_id, string $provider, array $request): bool {
    switch ($provider) {
        case YOOAdmin_2FA_Core::PROVIDER_TOTP:
            $code   = isset($request['authcode']) ? (string) $request['authcode'] : '';
            $secret = YOOAdmin_2FA_TOTP::get_user_secret($user_id);

            return $secret !== '' && YOOAdmin_2FA_TOTP::verify($secret, $code);

        case YOOAdmin_2FA_Core::PROVIDER_EMAIL:
            $code = isset($request['email_code']) ? (string) $request['email_code'] : '';

            return YOOAdmin_2FA_Email::verify($user_id, $code);

        case YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES:
            $code = isset($request['backup_code']) ? (string) $request['backup_code'] : '';

            return YOOAdmin_2FA_Backup_Codes::verify($user_id, $code);
    }

    return false;
}
