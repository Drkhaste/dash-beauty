<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

yooadmin_require_if_exists(dirname(__DIR__, 2) . '/helpers/branded-email-template.php');

final class YOOAdmin_2FA_Email {

    public const TOKEN_TTL = 900;

    public const META_LAST_SENT = '_yooadmin_2fa_email_last_sent';

    /**
     * @return bool|WP_Error
     */
    public static function send_login_code(WP_User $user, bool $is_resend = false) {
        if ($is_resend) {
            $allowed = self::assert_resend_allowed($user->ID);
            if (is_wp_error($allowed)) {
                return $allowed;
            }
        } else {
            self::reset_resend_counter($user->ID);
        }

        $token = self::generate_token();
        self::store_token($user->ID, $token);

        $sent = self::dispatch_email($user, $token);
        if (!$sent) {
            return false;
        }

        update_user_meta($user->ID, self::META_LAST_SENT, time());

        if ($is_resend) {
            self::record_resend_attempt($user->ID);
        }

        return true;
    }

    public static function verify(int $user_id, string $code): bool {
        $code = preg_replace('/\s+/', '', $code);
        if (!is_string($code) || !preg_match('/^\d{6}$/', $code)) {
            return false;
        }

        $stored = (string) get_user_meta($user_id, YOOAdmin_2FA_Core::META_EMAIL_TOKEN, true);
        $time   = (int) get_user_meta($user_id, YOOAdmin_2FA_Core::META_EMAIL_TOKEN_TIME, true);

        if ($stored === '' || $time <= 0 || (time() - $time) > self::TOKEN_TTL) {
            return false;
        }

        if (!hash_equals($stored, YOOAdmin_2FA_Core::hash_code($code))) {
            return false;
        }

        delete_user_meta($user_id, YOOAdmin_2FA_Core::META_EMAIL_TOKEN);
        delete_user_meta($user_id, YOOAdmin_2FA_Core::META_EMAIL_TOKEN_TIME);

        return true;
    }

    public static function get_resend_cooldown_seconds(): int {
        $default = 60;
        if (!function_exists('yooadmin_get_options')) {
            return $default;
        }

        $opts = yooadmin_get_options();
        $raw  = isset($opts['login_two_factor_email_resend_cooldown'])
            ? (int) $opts['login_two_factor_email_resend_cooldown']
            : $default;

        return max(15, min(3600, $raw));
    }

    public static function get_resend_max_attempts(): int {
        $default = 5;
        if (!function_exists('yooadmin_get_options')) {
            return $default;
        }

        $opts = yooadmin_get_options();
        $raw  = isset($opts['login_two_factor_email_resend_max'])
            ? (int) $opts['login_two_factor_email_resend_max']
            : $default;

        return max(1, min(20, $raw));
    }

    public static function get_resend_retry_after(int $user_id): int {
        $cooldown  = self::get_resend_cooldown_seconds();
        $last_sent = (int) get_user_meta($user_id, self::META_LAST_SENT, true);
        if ($last_sent <= 0) {
            return 0;
        }

        $remaining = $cooldown - (time() - $last_sent);

        return $remaining > 0 ? $remaining : 0;
    }

    /**
     * @return true|WP_Error
     */
    private static function assert_resend_allowed(int $user_id) {
        $retry_after = self::get_resend_retry_after($user_id);
        if ($retry_after > 0) {
            return new WP_Error(
                'two_factor_resend_cooldown',
                sprintf(
                    /* translators: %d: seconds until another code can be requested */
                    __('Please wait %d seconds before requesting another code.', 'yooadmin'),
                    $retry_after
                ),
                ['retry_after' => $retry_after]
            );
        }

        $key    = self::resend_counter_key($user_id);
        $record = get_transient($key);
        $count  = is_array($record) ? (int) ($record['count'] ?? 0) : 0;
        $max    = self::get_resend_max_attempts();

        if ($count >= $max) {
            return new WP_Error(
                'two_factor_resend_limit',
                __('Too many code requests. Please wait for the current code to expire or sign in again.', 'yooadmin')
            );
        }

        return true;
    }

    private static function resend_counter_key(int $user_id): string {
        $ip = function_exists('yooadmin_get_request_client_ip')
            ? yooadmin_get_request_client_ip()
            : '0.0.0.0';

        return 'yooadmin_2fa_email_resend_' . $user_id . '_' . md5($ip);
    }

    private static function reset_resend_counter(int $user_id): void {
        delete_transient(self::resend_counter_key($user_id));
    }

    private static function record_resend_attempt(int $user_id): void {
        $key    = self::resend_counter_key($user_id);
        $record = get_transient($key);
        $count  = is_array($record) ? (int) ($record['count'] ?? 0) : 0;

        set_transient($key, ['count' => $count + 1], self::TOKEN_TTL);
    }

    private static function generate_token(): string {
        return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }

    private static function store_token(int $user_id, string $token): void {
        update_user_meta($user_id, YOOAdmin_2FA_Core::META_EMAIL_TOKEN, YOOAdmin_2FA_Core::hash_code($token));
        update_user_meta($user_id, YOOAdmin_2FA_Core::META_EMAIL_TOKEN_TIME, time());
    }

    private static function dispatch_email(WP_User $user, string $token): bool {
        if (function_exists('yooadmin_load_yooadmin_textdomain')) {
            $locale = function_exists('yooadmin_custom_login_get_login_locale')
                ? yooadmin_custom_login_get_login_locale()
                : null;
            yooadmin_load_yooadmin_textdomain($locale);
        }

        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        $subject   = sprintf(
            /* translators: %s: site name */
            __('[%s] Your sign-in verification code', 'yooadmin'),
            $site_name
        );

        $ttl_minutes = (int) ceil(self::TOKEN_TTL / MINUTE_IN_SECONDS);
        $remote_ip   = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR'])) : '';

        $rows = [
            [
                'label' => __('Account', 'yooadmin'),
                'value' => $user->user_login,
            ],
            [
                'label' => __('Email', 'yooadmin'),
                'value' => $user->user_email,
            ],
            [
                'label' => __('Valid for', 'yooadmin'),
                'value' => sprintf(
                    /* translators: %d: minutes */
                    _n('%d minute', '%d minutes', $ttl_minutes, 'yooadmin'),
                    $ttl_minutes
                ),
            ],
        ];

        if ($remote_ip !== '') {
            $rows[] = [
                'label' => __('IP address', 'yooadmin'),
                'value' => $remote_ip,
            ];
        }

        $body = '';
        if (function_exists('yooadmin_branded_email_render_card')) {
            $body = yooadmin_branded_email_render_card(
                [
                    'headline'      => __('Sign-in verification code', 'yooadmin'),
                    'intro'         => __('Use this one-time code to complete your sign-in.', 'yooadmin'),
                    'badge_label'   => __('Two-factor authentication', 'yooadmin'),
                    'badge_tone'    => 'success',
                    'highlight'     => $token,
                    'details_title' => __('Verification details', 'yooadmin'),
                    'rows'          => $rows,
                    'footer_note'   => sprintf(
                        /* translators: %s: site name */
                        __('This message was sent by %s security.', 'yooadmin'),
                        $site_name
                    ),
                ]
            );
        }

        if ($body === '') {
            $body = sprintf(
                "%s\n\n%s: %s\n",
                __('Your sign-in verification code:', 'yooadmin'),
                __('Code', 'yooadmin'),
                $token
            );
        }

        $headers = ['Content-Type: text/html; charset=UTF-8'];

        return (bool) wp_mail($user->user_email, $subject, $body, $headers);
    }
}
