<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

final class YOOAdmin_2FA_TOTP {

    private const PERIOD = 30;
    private const DIGITS = 6;
    private const BASE32_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public static function generate_secret(int $length = 16): string {
        $chars  = self::BASE32_CHARS;
        $secret = '';
        $max    = strlen($chars) - 1;
        for ($i = 0; $i < $length; $i++) {
            $secret .= $chars[random_int(0, $max)];
        }

        return $secret;
    }

    public static function get_otpauth_uri(string $secret, string $account, string $issuer = ''): string {
        $label = rawurlencode($issuer !== '' ? $issuer . ':' . $account : $account);

        return 'otpauth://totp/' . $label
            . '?secret=' . rawurlencode($secret)
            . '&issuer=' . rawurlencode($issuer)
            . '&digits=' . self::DIGITS
            . '&period=' . self::PERIOD;
    }

    public static function verify(string $secret, string $code, int $window = 1): bool {
        $code = preg_replace('/\s+/', '', $code);
        if (!is_string($code) || !preg_match('/^\d{6}$/', $code)) {
            return false;
        }

        $time_slice = (int) floor(time() / self::PERIOD);
        for ($i = -$window; $i <= $window; $i++) {
            if (hash_equals(self::generate_code($secret, $time_slice + $i), $code)) {
                return true;
            }
        }

        return false;
    }

    public static function generate_code(string $secret, ?int $time_slice = null): string {
        if ($time_slice === null) {
            $time_slice = (int) floor(time() / self::PERIOD);
        }

        $key  = self::base32_decode($secret);
        $time = pack('N*', 0, $time_slice);
        $hash = hash_hmac('sha1', $time, $key, true);
        $offset = ord(substr($hash, -1)) & 0x0F;
        $truncated = (
            ((ord($hash[$offset]) & 0x7F) << 24)
            | ((ord($hash[$offset + 1]) & 0xFF) << 16)
            | ((ord($hash[$offset + 2]) & 0xFF) << 8)
            | (ord($hash[$offset + 3]) & 0xFF)
        );

        return str_pad((string) ($truncated % (10 ** self::DIGITS)), self::DIGITS, '0', STR_PAD_LEFT);
    }

    private static function base32_decode(string $secret): string {
        $secret = strtoupper(preg_replace('/[^A-Z2-7]/', '', $secret) ?? '');
        $buffer = 0;
        $bits   = 0;
        $out    = '';

        $chars = self::BASE32_CHARS;
        $len   = strlen($secret);
        for ($i = 0; $i < $len; $i++) {
            $val = strpos($chars, $secret[$i]);
            if ($val === false) {
                continue;
            }
            $buffer = ($buffer << 5) | $val;
            $bits  += 5;
            if ($bits >= 8) {
                $bits -= 8;
                $out .= chr(($buffer >> $bits) & 0xFF);
            }
        }

        return $out;
    }

    public static function get_user_secret(int $user_id): string {
        $stored = (string) get_user_meta($user_id, YOOAdmin_2FA_Core::META_TOTP_SECRET, true);

        return YOOAdmin_2FA_Core::unseal_secret($stored);
    }

    public static function set_user_secret(int $user_id, string $secret): void {
        update_user_meta($user_id, YOOAdmin_2FA_Core::META_TOTP_SECRET, YOOAdmin_2FA_Core::seal_secret($secret));
    }

    public static function clear_user_secret(int $user_id): void {
        delete_user_meta($user_id, YOOAdmin_2FA_Core::META_TOTP_SECRET);
    }
}
