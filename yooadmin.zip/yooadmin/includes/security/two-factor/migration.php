<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

final class YOOAdmin_2FA_Migration {

    /**
     * @return array{imported: int, skipped: int, errors: int, messages: string[]}
     */
    public static function run(): array {
        $result = [
            'imported' => 0,
            'skipped'  => 0,
            'errors'   => 0,
            'messages' => [],
        ];

        if (!class_exists('Two_Factor_Core')) {
            $result['messages'][] = __('WordPress Two-Factor plugin is not active.', 'yooadmin');

            return $result;
        }

        $users = get_users(['fields' => 'ID']);
        foreach ($users as $user_id) {
            $user_id = (int) $user_id;
            if ($user_id <= 0) {
                continue;
            }

            if (!Two_Factor_Core::is_user_using_two_factor($user_id)) {
                continue;
            }

            if (YOOAdmin_2FA_Core::is_user_using_2fa($user_id)) {
                $result['skipped']++;
                continue;
            }

            if (self::import_user($user_id)) {
                $result['imported']++;
            } else {
                $result['skipped']++;
            }
        }

        if ($result['imported'] === 0 && $result['skipped'] === 0 && $result['errors'] === 0) {
            $result['messages'][] = __('No users with WordPress Two-Factor settings were found.', 'yooadmin');
        }

        return $result;
    }

    private static function import_user(int $user_id): bool {
        $wp_providers = get_user_meta($user_id, '_two_factor_enabled_providers', true);
        if (!is_array($wp_providers) || $wp_providers === []) {
            return false;
        }

        $map = [
            'Two_Factor_Totp'         => YOOAdmin_2FA_Core::PROVIDER_TOTP,
            'Two_Factor_Email'        => YOOAdmin_2FA_Core::PROVIDER_EMAIL,
            'Two_Factor_Backup_Codes' => YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES,
        ];

        $native = [];
        foreach ($wp_providers as $wp_key) {
            $wp_key = (string) $wp_key;
            if (isset($map[$wp_key])) {
                $native[] = $map[$wp_key];
            }
        }

        if ($native === []) {
            return false;
        }

        $wp_primary = (string) get_user_meta($user_id, '_two_factor_provider', true);
        $primary    = $map[$wp_primary] ?? $native[0];

        $totp_key = (string) get_user_meta($user_id, '_two_factor_totp_key', true);
        if ($totp_key !== '' && in_array(YOOAdmin_2FA_Core::PROVIDER_TOTP, $native, true)) {
            YOOAdmin_2FA_TOTP::set_user_secret($user_id, $totp_key);
        }

        $backup = get_user_meta($user_id, '_two_factor_backup_codes', true);
        if (is_array($backup) && $backup !== []) {
            $entries = [];
            foreach ($backup as $entry) {
                if (!is_array($entry)) {
                    continue;
                }
                $hash = (string) ($entry['hash'] ?? '');
                if ($hash === '') {
                    continue;
                }
                $entries[] = [
                    'hash' => $hash,
                    'used' => !empty($entry['used']) ? 1 : 0,
                ];
            }
            if ($entries !== []) {
                update_user_meta($user_id, YOOAdmin_2FA_Core::META_BACKUP_CODES, $entries);
            }
        }

        YOOAdmin_2FA_Core::set_enabled_providers($user_id, $native, $primary);

        return true;
    }
}

function yooadmin_native_2fa_ajax_run_migration(): void {
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Not allowed.', 'yooadmin')], 403);
    }

    check_ajax_referer('yooadmin_2fa_migration', 'nonce');

    if (!YOOAdmin_2FA_Core::is_service_enabled()) {
        wp_send_json_error(['message' => __('Enable the YOOAdmin Two-Factor service first.', 'yooadmin')]);
    }

    $result = YOOAdmin_2FA_Migration::run();
    wp_send_json_success($result);
}
add_action('wp_ajax_yooadmin_2fa_run_migration', 'yooadmin_native_2fa_ajax_run_migration');
