<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

function yooadmin_native_2fa_register_ajax(): void {
    $actions = [
        'yooadmin_2fa_setup_totp',
        'yooadmin_2fa_reset_totp',
        'yooadmin_2fa_verify_totp',
        'yooadmin_2fa_generate_backup_codes',
        'yooadmin_2fa_save_providers',
    ];

    foreach ($actions as $action) {
        add_action('wp_ajax_' . $action, 'yooadmin_native_2fa_ajax_' . str_replace('yooadmin_2fa_', '', $action));
    }
}
add_action('init', 'yooadmin_native_2fa_register_ajax');

/**
 * @return array{secret: string, uri: string, issuer: string}
 */
function yooadmin_native_2fa_ajax_totp_begin_pending(int $user_id): array {
    $secret = YOOAdmin_2FA_TOTP::generate_secret();
    set_transient(
        'yooadmin_2fa_totp_pending_' . $user_id,
        YOOAdmin_2FA_Core::seal_secret($secret),
        15 * MINUTE_IN_SECONDS
    );

    $user   = get_user_by('id', $user_id);
    $issuer = function_exists('yooadmin_get_options')
        ? (string) (yooadmin_get_options()['panel_title'] ?? get_bloginfo('name'))
        : get_bloginfo('name');

    return [
        'secret' => $secret,
        'uri'    => YOOAdmin_2FA_TOTP::get_otpauth_uri(
            $secret,
            $user instanceof WP_User ? $user->user_login : '',
            $issuer
        ),
        'issuer' => $issuer,
    ];
}

function yooadmin_native_2fa_ajax_require_own_totp_user(int $user_id): void {
    if ($user_id <= 0 || $user_id !== get_current_user_id()) {
        wp_send_json_error(['message' => __('You can only change your own authenticator settings.', 'yooadmin')], 403);
    }
}

function yooadmin_native_2fa_ajax_require_totp_settings_unlocked(int $user_id): void {
    if (!class_exists('YOOAdmin_2FA_Session')) {
        return;
    }

    if (YOOAdmin_2FA_Session::is_revalidation_required($user_id)) {
        wp_send_json_error(['message' => __('Confirm your identity before changing two-factor settings.', 'yooadmin')], 403);
    }
}

function yooadmin_native_2fa_ajax_setup_totp(): void {
    $ctx     = yooadmin_native_2fa_ajax_guard();
    $user_id = (int) $ctx['user_id'];

    yooadmin_native_2fa_ajax_require_own_totp_user($user_id);
    yooadmin_native_2fa_ajax_require_totp_settings_unlocked($user_id);

    if (YOOAdmin_2FA_TOTP::get_user_secret($user_id) !== '') {
        wp_send_json_error(['message' => __('Authenticator is already configured. Use reset to replace it.', 'yooadmin')]);
    }

    wp_send_json_success(yooadmin_native_2fa_ajax_totp_begin_pending($user_id));
}

function yooadmin_native_2fa_ajax_reset_totp(): void {
    $ctx     = yooadmin_native_2fa_ajax_guard();
    $user_id = (int) $ctx['user_id'];

    yooadmin_native_2fa_ajax_require_own_totp_user($user_id);
    yooadmin_native_2fa_ajax_require_totp_settings_unlocked($user_id);

    $existing = YOOAdmin_2FA_TOTP::get_user_secret($user_id);
    if ($existing === '') {
        wp_send_json_error(['message' => __('Authenticator is not set up yet.', 'yooadmin')]);
    }

    $current_code = isset($ctx['request']['current_code'])
        ? sanitize_text_field((string) $ctx['request']['current_code'])
        : '';

    if ($current_code === '' || !YOOAdmin_2FA_TOTP::verify($existing, $current_code)) {
        wp_send_json_error(['message' => __('Enter a valid code from your current authenticator app.', 'yooadmin')]);
    }

    wp_send_json_success(yooadmin_native_2fa_ajax_totp_begin_pending($user_id));
}

function yooadmin_native_2fa_ajax_verify_totp(): void {
    $ctx     = yooadmin_native_2fa_ajax_guard();
    $user_id = (int) $ctx['user_id'];

    yooadmin_native_2fa_ajax_require_own_totp_user($user_id);
    yooadmin_native_2fa_ajax_require_totp_settings_unlocked($user_id);

    $code = isset($ctx['request']['code']) ? sanitize_text_field((string) $ctx['request']['code']) : '';

    $pending = get_transient('yooadmin_2fa_totp_pending_' . $user_id);
    if (!is_string($pending) || $pending === '') {
        wp_send_json_error(['message' => __('TOTP setup expired. Please start again.', 'yooadmin')]);
    }

    $secret = YOOAdmin_2FA_Core::unseal_secret($pending);
    if ($secret === '' || !YOOAdmin_2FA_TOTP::verify($secret, $code)) {
        wp_send_json_error(['message' => __('Invalid code. Check your authenticator app and try again.', 'yooadmin')]);
    }

    $was_configured = YOOAdmin_2FA_TOTP::get_user_secret($user_id) !== '';

    YOOAdmin_2FA_TOTP::set_user_secret($user_id, $secret);
    delete_transient('yooadmin_2fa_totp_pending_' . $user_id);

    $message = __('Authenticator app verified.', 'yooadmin');
    if ($was_configured) {
        YOOAdmin_2FA_Backup_Codes::clear($user_id);

        $enabled = YOOAdmin_2FA_Core::get_enabled_providers($user_id);
        $enabled = array_values(
            array_diff($enabled, [YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES])
        );
        $primary = YOOAdmin_2FA_Core::get_primary_provider($user_id);
        if ($primary === YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES) {
            $primary = '';
        }
        YOOAdmin_2FA_Core::set_enabled_providers($user_id, $enabled, $primary);

        $message = __('Authenticator app reset successfully. Old recovery codes were revoked — generate new ones if you still need them.', 'yooadmin');
    }

    wp_send_json_success(['message' => $message]);
}

function yooadmin_native_2fa_ajax_generate_backup_codes(): void {
    $ctx     = yooadmin_native_2fa_ajax_guard();
    $user_id = (int) $ctx['user_id'];

    yooadmin_native_2fa_ajax_require_own_totp_user($user_id);
    yooadmin_native_2fa_ajax_require_totp_settings_unlocked($user_id);
    $codes   = YOOAdmin_2FA_Backup_Codes::generate($user_id);

    wp_send_json_success(
        [
            'codes'   => $codes,
            'message' => __('Save these recovery codes in a safe place. Each code can be used once.', 'yooadmin'),
        ]
    );
}

/**
 * @param array<string, mixed> $request Unslashed AJAX payload.
 */
function yooadmin_native_2fa_ajax_resolve_target_user_id(int $default_user_id, array $request): int {
    if (empty($request['user_id'])) {
        return $default_user_id;
    }

    $maybe = absint((string) $request['user_id']);
    if ($maybe > 0 && current_user_can('edit_user', $maybe)) {
        return $maybe;
    }

    return $default_user_id;
}

/**
 * @return array{user_id: int, request: array<string, mixed>}
 */
function yooadmin_native_2fa_ajax_guard(): array {
    if (!YOOAdmin_2FA_Core::is_service_enabled()) {
        wp_send_json_error(['message' => __('Two-factor service is not enabled.', 'yooadmin')], 403);
    }

    check_ajax_referer('yooadmin_native_2fa', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('You must be signed in.', 'yooadmin')], 403);
    }

    $request = function_exists('yooadmin_native_2fa_read_profile_save_request')
        ? yooadmin_native_2fa_read_profile_save_request()
        : [];
    $user_id = yooadmin_native_2fa_ajax_resolve_target_user_id(get_current_user_id(), $request);

    if (YOOAdmin_2FA_Core::user_has_external_2fa($user_id)) {
        wp_send_json_error(['message' => __('This account uses an external two-factor plugin.', 'yooadmin')], 403);
    }

    return [
        'user_id' => $user_id,
        'request' => $request,
    ];
}

function yooadmin_native_2fa_ajax_save_providers(): void {
    $ctx = yooadmin_native_2fa_ajax_guard();

    $parsed = function_exists('yooadmin_native_2fa_profile_providers_from_request')
        ? yooadmin_native_2fa_profile_providers_from_request((int) $ctx['user_id'], $ctx['request'])
        : null;

    if ($parsed === null) {
        wp_send_json_error(['message' => __('No two-factor settings to save.', 'yooadmin')]);
    }

    if ($parsed['errors'] !== []) {
        wp_send_json_error(['message' => implode(' ', $parsed['errors'])]);
    }

    $primary = isset($ctx['request']['primary']) ? sanitize_key((string) $ctx['request']['primary']) : '';

    YOOAdmin_2FA_Core::set_enabled_providers(
        (int) $ctx['user_id'],
        $parsed['providers'],
        $primary !== '' ? $primary : YOOAdmin_2FA_Core::get_site_default_primary()
    );

    wp_send_json_success(['message' => __('Two-factor settings saved.', 'yooadmin')]);
}
