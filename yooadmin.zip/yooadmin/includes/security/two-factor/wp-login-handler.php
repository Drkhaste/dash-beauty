<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_native_2fa_core_wp_login_url')) {
    /**
     * @param array<string, scalar|null> $args Query arguments.
     */
    function yooadmin_native_2fa_core_wp_login_url(array $args = []): string {
        $path = 'wp-login.php';
        if ($args !== []) {
            $path = add_query_arg($args, $path);
        }

        /** @var string $url */
        return (string) apply_filters('yooadmin_native_2fa_core_wp_login_url', site_url($path, 'login'), $args);
    }
}

if (!function_exists('yooadmin_native_2fa_should_use_wp_login_forms')) {
    function yooadmin_native_2fa_should_use_wp_login_forms(): bool {
        if (
            function_exists('yooadmin_custom_login_uses_standalone_page')
            && yooadmin_custom_login_uses_standalone_page()
            && function_exists('yooadmin_custom_login_is_enabled')
            && yooadmin_custom_login_is_enabled()
        ) {
            return false;
        }

        return true;
    }
}

if (!function_exists('yooadmin_native_2fa_wp_login_user_uses_native')) {
    /**
     * @param WP_User|int|null $user User object or ID.
     */
    function yooadmin_native_2fa_wp_login_user_uses_native($user): bool {
        if (!class_exists('YOOAdmin_2FA_Core') || !YOOAdmin_2FA_Core::is_service_enabled()) {
            return false;
        }

        if ($user instanceof WP_User) {
            $user_id = $user->ID;
        } else {
            $user_id = absint($user);
        }

        if ($user_id <= 0) {
            return false;
        }

        if (!YOOAdmin_2FA_Core::is_user_using_2fa($user_id)) {
            return false;
        }

        return !YOOAdmin_2FA_Core::user_has_external_2fa($user_id);
    }
}

if (!function_exists('yooadmin_native_2fa_wp_login_request_fields')) {
    /**
     * @return array<string, mixed>
     */
    function yooadmin_native_2fa_wp_login_request_fields(): array {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified by caller before processing.
        $request = [];
        foreach ($_POST as $key => $value) {
            if (!is_string($key)) {
                continue;
            }
            if (is_string($value) || is_numeric($value)) {
                $request[$key] = (string) $value;
            }
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        return $request;
    }
}

if (!function_exists('yooadmin_native_2fa_wp_login_render_form')) {
    /**
     * @param array<string, mixed> $challenge Challenge payload.
     */
    function yooadmin_native_2fa_wp_login_render_form(
        WP_User $user,
        string $auth_nonce,
        string $redirect_to,
        string $error_msg,
        array $challenge,
        string $action
    ): void {
        $provider = isset($challenge['provider']) ? sanitize_key((string) $challenge['provider']) : '';
        $fields   = isset($challenge['fields']) && is_array($challenge['fields']) ? $challenge['fields'] : [];
        $actions  = isset($challenge['actions']) && is_array($challenge['actions']) ? $challenge['actions'] : [];
        $alternates = isset($challenge['alternates']) && is_array($challenge['alternates']) ? $challenge['alternates'] : [];
        $lead     = isset($challenge['lead']) ? (string) $challenge['lead'] : '';
        $title    = isset($challenge['title']) ? (string) $challenge['title'] : __('Two-factor authentication', 'yooadmin');

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login interim flag.
        $interim_login = isset($_REQUEST['interim-login']);
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        $rememberme = 0;
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login rememberme flag.
        if ($action === 'validate_2fa' && !empty($_REQUEST['rememberme'])) {
            $rememberme = 1;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        add_filter('login_display_language_dropdown', '__return_false');

        login_header($title);

        if ($error_msg !== '') {
            echo '<div id="login_error"><strong>' . esc_html($error_msg) . '</strong><br /></div>';
        } elseif ($lead !== '') {
            echo '<p class="message">' . esc_html($lead) . '</p>';
        }

        $form_args = $action !== '' ? ['action' => $action] : [];
        if (
            function_exists('yooadmin_hidden_login_entry_current_gate_token')
            && function_exists('yooadmin_hidden_login_entry_verify_gate_token')
        ) {
            $gate_token = yooadmin_hidden_login_entry_current_gate_token();
            if ($gate_token !== '' && yooadmin_hidden_login_entry_verify_gate_token($gate_token)) {
                $form_args['yooadmin_hl_gate'] = $gate_token;
            }
        }
        $form_action = yooadmin_native_2fa_core_wp_login_url($form_args);
        ?>
        <form name="yooadmin_2fa_form" id="loginform" action="<?php echo esc_url($form_action); ?>" method="post" autocomplete="off">
            <?php if (function_exists('yooadmin_hidden_login_entry_print_gate_field')) : ?>
                <?php yooadmin_hidden_login_entry_print_gate_field(); ?>
            <?php endif; ?>
            <input type="hidden" name="provider" id="provider" value="<?php echo esc_attr($provider); ?>" />
            <input type="hidden" name="wp-auth-nonce" id="wp-auth-nonce" value="<?php echo esc_attr($auth_nonce); ?>" />
            <?php if ($action === 'validate_2fa') : ?>
                <input type="hidden" name="wp-auth-id" id="wp-auth-id" value="<?php echo esc_attr((string) $user->ID); ?>" />
                <input type="hidden" name="rememberme" id="rememberme" value="<?php echo esc_attr((string) $rememberme); ?>" />
            <?php endif; ?>
            <?php if ($interim_login) : ?>
                <input type="hidden" name="interim-login" value="1" />
            <?php else : ?>
                <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>" />
            <?php endif; ?>

            <?php foreach ($fields as $field) : ?>
                <?php
                if (!is_array($field)) {
                    continue;
                }
                $name = isset($field['name']) ? sanitize_key((string) $field['name']) : '';
                if ($name === '') {
                    continue;
                }
                $label = isset($field['label']) ? (string) $field['label'] : '';
                $type  = isset($field['type']) ? sanitize_key((string) $field['type']) : 'text';
                $inputmode = isset($field['inputmode']) ? sanitize_key((string) $field['inputmode']) : '';
                $autocomplete = isset($field['autocomplete']) ? sanitize_key((string) $field['autocomplete']) : '';
                $placeholder = isset($field['placeholder']) ? (string) $field['placeholder'] : '';
                $required = !empty($field['required']);
                ?>
                <p>
                    <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label>
                    <input
                        type="<?php echo esc_attr($type); ?>"
                        name="<?php echo esc_attr($name); ?>"
                        id="<?php echo esc_attr($name); ?>"
                        class="input"
                        value=""
                        size="20"
                        <?php echo $required ? 'required' : ''; ?>
                        <?php echo $inputmode !== '' ? 'inputmode="' . esc_attr($inputmode) . '"' : ''; ?>
                        <?php echo $autocomplete !== '' ? 'autocomplete="' . esc_attr($autocomplete) . '"' : ''; ?>
                        <?php echo $placeholder !== '' ? 'placeholder="' . esc_attr($placeholder) . '"' : ''; ?>
                    />
                </p>
            <?php endforeach; ?>

            <p class="submit">
                <input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="<?php esc_attr_e('Verify', 'yooadmin'); ?>" />
            </p>

            <?php foreach ($actions as $action_btn) : ?>
                <?php
                if (!is_array($action_btn)) {
                    continue;
                }
                $btn_name = isset($action_btn['name']) ? sanitize_key((string) $action_btn['name']) : '';
                if ($btn_name === '') {
                    continue;
                }
                $btn_label = isset($action_btn['label']) ? (string) $action_btn['label'] : '';
                ?>
                <p class="submit">
                    <button type="submit" name="<?php echo esc_attr($btn_name); ?>" value="1" class="button button-secondary button-large">
                        <?php echo esc_html($btn_label); ?>
                    </button>
                </p>
            <?php endforeach; ?>
        </form>

        <?php if ($alternates !== []) : ?>
            <div class="backup-methods-wrap">
                <p><?php esc_html_e('Having problems?', 'yooadmin'); ?></p>
                <ul>
                    <?php foreach ($alternates as $alternate) : ?>
                        <?php
                        if (!is_array($alternate)) {
                            continue;
                        }
                        $alt_provider = isset($alternate['provider']) ? sanitize_key((string) $alternate['provider']) : '';
                        $alt_label    = isset($alternate['label']) ? (string) $alternate['label'] : '';
                        if ($alt_provider === '') {
                            continue;
                        }
                        $link_args = [
                            'action'        => $action,
                            'provider'      => $alt_provider,
                            'wp-auth-nonce' => $auth_nonce,
                            'redirect_to'   => $redirect_to,
                        ];
                        if (
                            function_exists('yooadmin_hidden_login_entry_current_gate_token')
                            && function_exists('yooadmin_hidden_login_entry_verify_gate_token')
                        ) {
                            $gate_token = yooadmin_hidden_login_entry_current_gate_token();
                            if ($gate_token !== '' && yooadmin_hidden_login_entry_verify_gate_token($gate_token)) {
                                $link_args['yooadmin_hl_gate'] = $gate_token;
                            }
                        }
                        if ($action === 'validate_2fa') {
                            $link_args['wp-auth-id'] = $user->ID;
                            if ($rememberme) {
                                $link_args['rememberme'] = $rememberme;
                            }
                        }
                        if ($interim_login) {
                            $link_args['interim-login'] = 1;
                        }
                        ?>
                        <li><a href="<?php echo esc_url(yooadmin_native_2fa_core_wp_login_url($link_args)); ?>"><?php echo esc_html($alt_label); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <style>
            .backup-methods-wrap {
                margin-top: 16px;
                padding: 0 24px;
            }
            .backup-methods-wrap a {
                text-decoration: none;
            }
            .backup-methods-wrap ul {
                margin: 8px 0 0;
                padding: 0;
                list-style: none;
            }
        </style>
        <?php
        login_footer();
        exit;
    }
}

if (!function_exists('yooadmin_native_2fa_login_form_revalidate_2fa')) {
    function yooadmin_native_2fa_login_form_revalidate_2fa(): void {
        if (!yooadmin_native_2fa_should_use_wp_login_forms()) {
            return;
        }

        if (!is_user_logged_in()) {
            wp_safe_redirect(home_url());
            exit;
        }

        $user = wp_get_current_user();
        if (!yooadmin_native_2fa_wp_login_user_uses_native($user)) {
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login query args.
        $redirect_to = !empty($_REQUEST['redirect_to'])
            ? wp_validate_redirect(esc_url_raw(wp_unslash((string) $_REQUEST['redirect_to'])), admin_url())
            : admin_url();
        $provider_key = !empty($_REQUEST['provider']) ? sanitize_key(wp_unslash((string) $_REQUEST['provider'])) : '';
        $auth_nonce   = !empty($_REQUEST['wp-auth-nonce']) ? sanitize_text_field(wp_unslash((string) $_REQUEST['wp-auth-nonce'])) : '';
        $request_method = isset($_SERVER['REQUEST_METHOD']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_METHOD'])) : 'GET';
        $is_post      = strtoupper($request_method) === 'POST';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if ($auth_nonce === '') {
            $auth_nonce = YOOAdmin_2FA_Session::create_revalidate_nonce($user->ID);
        }

        if ($is_post) {
            $request = yooadmin_native_2fa_wp_login_request_fields();
            $result  = yooadmin_native_2fa_revalidate_validate(
                $user,
                $auth_nonce,
                $provider_key,
                $request,
                false,
                $redirect_to
            );

            if ($result === true) {
                // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login interim flag.
                if (!empty($_REQUEST['interim-login'])) {
                    global $interim_login;
                    $interim_login = 'success'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
                    login_header('', '<p class="message">' . esc_html__('You have revalidated successfully.', 'yooadmin') . '</p>');
                    echo '</div>';
                    do_action('login_footer'); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
                    echo '</body></html>';
                    exit;
                }
                // phpcs:enable WordPress.Security.NonceVerification.Recommended

                $success_url = function_exists('yooadmin_profile_2fa_revalidated_result_url')
                    ? yooadmin_profile_2fa_revalidated_result_url($redirect_to)
                    : add_query_arg('yooadmin_2fa_revalidated', '1', $redirect_to);
                wp_safe_redirect($success_url);
                exit;
            }

            if (is_array($result) && !empty($result['challenge']) && is_array($result['challenge'])) {
                yooadmin_native_2fa_wp_login_render_form(
                    $user,
                    $auth_nonce,
                    $redirect_to,
                    isset($result['message']) ? (string) $result['message'] : '',
                    $result['challenge'],
                    'revalidate_2fa'
                );
                return;
            }

            $error = is_wp_error($result) ? $result->get_error_message() : __('Invalid verification code. Please try again.', 'yooadmin');
            $auth_nonce = YOOAdmin_2FA_Session::create_revalidate_nonce($user->ID);
        }

        $challenge = yooadmin_native_2fa_build_challenge($user, $provider_key !== '' ? $provider_key : YOOAdmin_2FA_Core::get_primary_provider($user->ID), $auth_nonce, true);
        if (is_wp_error($challenge)) {
            wp_die(esc_html($challenge->get_error_message()));
        }

        yooadmin_native_2fa_wp_login_render_form(
            $user,
            $auth_nonce,
            $redirect_to,
            isset($error) ? (string) $error : '',
            $challenge,
            'revalidate_2fa'
        );
        exit;
    }
}
add_action('login_form_revalidate_2fa', 'yooadmin_native_2fa_login_form_revalidate_2fa', 5);

if (!function_exists('yooadmin_native_2fa_filter_authenticate')) {
    /**
     * @param WP_User|WP_Error|null $user User or error.
     * @return WP_User|WP_Error|null
     */
    function yooadmin_native_2fa_filter_authenticate($user) {
        if (!yooadmin_native_2fa_should_use_wp_login_forms()) {
            return $user;
        }

        if ($user instanceof WP_User && yooadmin_native_2fa_wp_login_user_uses_native($user)) {
            add_filter('send_auth_cookies', '__return_false', PHP_INT_MAX);

            if (!defined('YOOADMIN_NATIVE_2FA_WP_LOGIN_PENDING')) {
                define('YOOADMIN_NATIVE_2FA_WP_LOGIN_PENDING', (int) $user->ID);
            }
        }

        return $user;
    }
}
add_filter('authenticate', 'yooadmin_native_2fa_filter_authenticate', PHP_INT_MAX);

if (!function_exists('yooadmin_native_2fa_wp_login_start_challenge')) {
    /**
     * @param WP_User $user        User object.
     * @param bool    $remember    Remember me.
     * @param string  $redirect_to Redirect target.
     */
    function yooadmin_native_2fa_wp_login_start_challenge(WP_User $user, bool $remember, string $redirect_to): void {
        wp_clear_auth_cookie();

        $auth_nonce = YOOAdmin_2FA_Session::create_login_nonce($user->ID);
        if ($auth_nonce === null) {
            wp_die(esc_html__('Two-factor authentication could not be started. Please try again.', 'yooadmin'));
        }

        $provider  = YOOAdmin_2FA_Core::get_primary_provider($user->ID);
        $challenge = yooadmin_native_2fa_build_challenge($user, $provider, $auth_nonce);
        if (is_wp_error($challenge)) {
            wp_die(esc_html($challenge->get_error_message()));
        }

        yooadmin_native_2fa_wp_login_render_form(
            $user,
            $auth_nonce,
            $redirect_to,
            '',
            $challenge,
            'validate_2fa'
        );
        exit;
    }
}

if (!function_exists('yooadmin_native_2fa_wp_login_intercept')) {
    /**
     * @param string  $user_login Username.
     * @param WP_User $user       User object.
     */
    function yooadmin_native_2fa_wp_login_intercept(string $user_login, $user): void {
        unset($user_login);

        if (!yooadmin_native_2fa_should_use_wp_login_forms()) {
            return;
        }

        if (
            function_exists('yooadmin_standalone_login_is_ajax_auth_request')
            && yooadmin_standalone_login_is_ajax_auth_request()
        ) {
            return;
        }

        if (!($user instanceof WP_User) || !yooadmin_native_2fa_wp_login_user_uses_native($user)) {
            return;
        }

        $remember = false;
        $redirect_to = admin_url();
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Standard wp-login POST; 2FA step follows.
        if (!empty($_POST['rememberme'])) {
            $remember = true;
        }
        if (isset($_POST['redirect_to']) && is_string($_POST['redirect_to'])) {
            $redirect_to = wp_validate_redirect(esc_url_raw(wp_unslash($_POST['redirect_to'])), admin_url());
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        yooadmin_native_2fa_wp_login_start_challenge($user, $remember, $redirect_to);
    }
}
add_action('wp_login', 'yooadmin_native_2fa_wp_login_intercept', 1, 2);

if (!function_exists('yooadmin_native_2fa_wp_login_login_redirect_guard')) {
    /**
     * Fallback when auth cookies were withheld but the 2FA screen did not render.
     *
     * @param string           $redirect_to           Redirect URL.
     * @param string           $requested_redirect_to Requested redirect.
     * @param WP_User|WP_Error $user                  User or error.
     */
    function yooadmin_native_2fa_wp_login_login_redirect_guard($redirect_to, $requested_redirect_to, $user): string {
        unset($requested_redirect_to);

        if (!yooadmin_native_2fa_should_use_wp_login_forms()) {
            return (string) $redirect_to;
        }

        if (!($user instanceof WP_User) || !yooadmin_native_2fa_wp_login_user_uses_native($user)) {
            return (string) $redirect_to;
        }

        if (
            !defined('YOOADMIN_NATIVE_2FA_WP_LOGIN_PENDING')
            || (int) YOOADMIN_NATIVE_2FA_WP_LOGIN_PENDING !== (int) $user->ID
        ) {
            return (string) $redirect_to;
        }

        $remember = false;
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Standard wp-login POST; 2FA step follows.
        if (!empty($_POST['rememberme'])) {
            $remember = true;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $target = is_string($redirect_to) && $redirect_to !== ''
            ? wp_validate_redirect($redirect_to, admin_url())
            : admin_url();

        yooadmin_native_2fa_wp_login_start_challenge($user, $remember, $target);

        return (string) $redirect_to;
    }
}
add_filter('login_redirect', 'yooadmin_native_2fa_wp_login_login_redirect_guard', 1, 3);

if (!function_exists('yooadmin_native_2fa_login_form_validate_2fa')) {
    
    function yooadmin_native_2fa_login_form_validate_2fa(): void {
        if (!yooadmin_native_2fa_should_use_wp_login_forms()) {
            return;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login query args.
        $user_id = !empty($_REQUEST['wp-auth-id']) ? absint($_REQUEST['wp-auth-id']) : 0;
        $auth_nonce = !empty($_REQUEST['wp-auth-nonce']) ? sanitize_text_field(wp_unslash((string) $_REQUEST['wp-auth-nonce'])) : '';
        $provider_key = !empty($_REQUEST['provider']) ? sanitize_key(wp_unslash((string) $_REQUEST['provider'])) : '';
        $redirect_to = !empty($_REQUEST['redirect_to'])
            ? wp_validate_redirect(esc_url_raw(wp_unslash((string) $_REQUEST['redirect_to'])), admin_url())
            : admin_url();
        $remember = !empty($_REQUEST['rememberme']);
        $request_method = isset($_SERVER['REQUEST_METHOD']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_METHOD'])) : 'GET';
        $is_post = strtoupper($request_method) === 'POST';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if ($user_id <= 0 || $auth_nonce === '') {
            return;
        }

        $user = get_user_by('id', $user_id);
        if (!($user instanceof WP_User) || !yooadmin_native_2fa_wp_login_user_uses_native($user)) {
            return;
        }

        if ($is_post) {
            remove_filter('send_auth_cookies', '__return_false', PHP_INT_MAX);

            $request = yooadmin_native_2fa_wp_login_request_fields();
            $result  = yooadmin_native_2fa_login_validate(
                $user,
                $auth_nonce,
                $provider_key,
                $request,
                $remember,
                $redirect_to
            );

            if ($result === true) {
                YOOAdmin_2FA_Session::mark_revalidated($user->ID);
                wp_safe_redirect($redirect_to);
                exit;
            }

            if (is_array($result) && !empty($result['challenge']) && is_array($result['challenge'])) {
                yooadmin_native_2fa_wp_login_render_form(
                    $user,
                    $auth_nonce,
                    $redirect_to,
                    isset($result['message']) ? (string) $result['message'] : '',
                    $result['challenge'],
                    'validate_2fa'
                );
                return;
            }

            $error = is_wp_error($result) ? $result->get_error_message() : __('Invalid verification code. Please try again.', 'yooadmin');
            $auth_nonce = YOOAdmin_2FA_Session::create_login_nonce($user->ID);
            if ($auth_nonce === null) {
                wp_die(esc_html__('Two-factor authentication could not be started. Please try again.', 'yooadmin'));
            }
        }

        $challenge = yooadmin_native_2fa_build_challenge(
            $user,
            $provider_key !== '' ? $provider_key : YOOAdmin_2FA_Core::get_primary_provider($user->ID),
            $auth_nonce
        );
        if (is_wp_error($challenge)) {
            wp_die(esc_html($challenge->get_error_message()));
        }

        yooadmin_native_2fa_wp_login_render_form(
            $user,
            $auth_nonce,
            $redirect_to,
            isset($error) ? (string) $error : '',
            $challenge,
            'validate_2fa'
        );
        exit;
    }
}
add_action('login_form_validate_2fa', 'yooadmin_native_2fa_login_form_validate_2fa', 5);
