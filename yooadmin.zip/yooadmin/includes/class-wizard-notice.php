<?php
/**
 * YOOAdmin - Wizard notice (admin notice to run setup)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Wizard Notice Class
 */
class YOOAdmin_Wizard_Notice {
    
    /**
     * Initialize
     */
    public static function init() {
        add_action('admin_notices', [__CLASS__, 'show_notice']);
        add_action('wp_ajax_yooadmin_dismiss_wizard_notice', [__CLASS__, 'dismiss_notice']);
    }
    
    /**
     * Show admin notice
     */
    public static function show_notice() {
        // Don't show if:
        // 1. Wizard completed
        if (get_option('yooadmin_wizard_completed')) {
            return;
        }
        
        // 2. Notice dismissed temporarily (for 7 days)
        $user_id = get_current_user_id();
        if (get_transient('yooadmin_wizard_notice_dismissed_' . $user_id)) {
            return;
        }
        
        // 3. Already on wizard page
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
        if (isset($_GET['page']) && sanitize_key( wp_unslash( $_GET['page'] ) ) === 'yooadmin-setup') {
            return;
        }
        
        // 4. Not an admin
        if (!current_user_can('manage_options')) {
            return;
        }
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__) . '/yooadmin.php';
        $base_url = plugin_dir_url($base_file);
        $base_dir = plugin_dir_path($base_file);

        $css_path = 'assets/css/admin/wizard-notice.css';
        if (file_exists($base_dir . $css_path)) {
            wp_enqueue_style('yooadmin-wizard-notice', $base_url . $css_path, [], (string) filemtime($base_dir . $css_path));
        }

        $js_path = 'assets/js/admin/wizard-notice.js';
        if (file_exists($base_dir . $js_path)) {
            wp_enqueue_script('yooadmin-wizard-notice', $base_url . $js_path, ['jquery'], (string) filemtime($base_dir . $js_path), true);
            wp_localize_script('yooadmin-wizard-notice', 'yooadmWizardNotice', [
                'nonce' => wp_create_nonce('yooadmin_dismiss_wizard_notice'),
            ]);
        }
        ?>
        <div class="notice is-dismissible yooadmin-wizard-notice" data-notice="wizard">
            <p>
                <strong><?php esc_html_e('🚀 Finish setting up your workspace', 'yooadmin'); ?></strong><br>
                <?php esc_html_e('Takes less than a minute to personalize your admin and reduce distractions.', 'yooadmin'); ?>
            </p>
            <p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=yooadmin-setup')); ?>" 
                   class="button button-primary" style="background: #eda934; border-color: #eda934;">
                    <?php esc_html_e('Finish Setup', 'yooadmin'); ?>
                </a>
                <a href="#" class="button yooadmin-dismiss-wizard-notice" style="margin-left: 10px;">
                    <?php esc_html_e('Remind Me Later', 'yooadmin'); ?>
                </a>
            </p>
        </div>
        <?php
    }
    
    /**
     * Dismiss notice via AJAX
     * Will show again after 7 days
     */
    public static function dismiss_notice() {
        check_ajax_referer('yooadmin_dismiss_wizard_notice');

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Insufficient permissions.' ), 403 );
        }

        $user_id = get_current_user_id();
        set_transient('yooadmin_wizard_notice_dismissed_' . $user_id, true, 7 * DAY_IN_SECONDS);
        wp_send_json_success();
    }
}

// Initialize
YOOAdmin_Wizard_Notice::init();


