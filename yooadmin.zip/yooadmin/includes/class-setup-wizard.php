<?php
/**
 * YOOAdmin - Setup wizard
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

/**
 * Setup Wizard Class
 */
class YOOAdmin_Setup_Wizard
{

    /**
     * Current step
     *
     * @var string
     */
    private $step = '';

    /**
     * Steps for the setup wizard
     *
     * @var array
     */
    private $steps = [];

    /**
     * Singleton instance
     *
     * @var YOOAdmin_Setup_Wizard
     */
    private static $instance = null;

    /**
     * Get singleton instance
     *
     * @return YOOAdmin_Setup_Wizard
     */
    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct()
    {
        // Register hidden wizard page (not in menu)
        add_action('admin_menu', [$this, 'register_hidden_page']);
        add_action('admin_init', [$this, 'setup_wizard'], 999); // Low priority to avoid conflicts
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_filter('admin_body_class', [$this, 'admin_body_class']);

        // AJAX handlers
        add_action('wp_ajax_yooadmin_wizard_save_step', [$this, 'ajax_save_step']);
        add_action('wp_ajax_yooadmin_wizard_complete', [$this, 'ajax_complete_wizard']);
        add_action('wp_ajax_yooadmin_wizard_skip', [$this, 'ajax_skip_wizard']);
        add_action('wp_ajax_yooadmin_check_license_status', [$this, 'ajax_check_license_status']);
        add_action('wp_ajax_yooadmin_refresh_license_step', [$this, 'ajax_refresh_license_step']);
        add_action('wp_ajax_yooadmin_mark_welcome_popup_shown', [$this, 'ajax_mark_welcome_popup_shown']);
        add_action('wp_ajax_yooadmin_wizard_save_convert_banners', [$this, 'ajax_save_convert_banners']);
        add_action('wp_ajax_yooadmin_wizard_save_color_mode', [$this, 'ajax_save_color_mode']);

        $this->steps = [
            'welcome' => [
                'view' => [$this, 'wizard_welcome'],
            ],
            'branding' => [
                'view' => [$this, 'wizard_branding'],
            ],
            'general' => [
                'view' => [$this, 'wizard_general'],
            ],
            'license' => [
                'view' => [$this, 'wizard_license'],
            ],
            'launch' => [
                'view' => [$this, 'wizard_launch'],
            ],
        ];
    }

    /**
     * Wizard step label (translated at render time under admin UI locale).
     */
    private function get_wizard_step_label(string $step_key): string
    {
        $labels = [
            'welcome'  => __('Welcome', 'yooadmin'),
            'branding' => __('Branding', 'yooadmin'),
            'general'  => __('General Settings', 'yooadmin'),
            'license'  => __('Connect Account', 'yooadmin'),
            'launch'   => __('Launch', 'yooadmin'),
        ];

        return $labels[$step_key] ?? '';
    }

    /**
     * Check if wizard should be shown
     *
     * @return bool
     */
    private function should_show_wizard()
    {
        // Don't show if already completed
        if (get_option('yooadmin_wizard_completed')) {
            return false;
        }

        // Don't show if dismissed
        if (get_option('yooadmin_wizard_dismissed')) {
            return false;
        }

        // Show for fresh installations
        return true;
    }

    /**
     * Add admin menus
     */
    /**
     * Register hidden wizard page (not in menu)
     */
    public function register_hidden_page()
    {
        add_submenu_page(
            'options.php', // Hidden page (3rd-level under options.php = not visible in menu, but $title is set correctly)
            __('Setup Wizard', 'yooadmin'),
            __('Setup Wizard', 'yooadmin'),
            'manage_options',
            'yooadmin-setup',
        [$this, 'render_wizard_page']
        );

    }

    /**
     * Render wizard page
     */
    public function render_wizard_page()
    {
        // Get current step
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
        $this->step = isset($_GET['step']) ? sanitize_key(wp_unslash($_GET['step'])) : 'welcome';

        // Redirect to first step if invalid
        if (!array_key_exists($this->step, $this->steps)) {
            $this->step = 'welcome';
        }

        $wizard_color_mode = $this->get_wizard_color_mode();
        ?>
        <script id="yooadmin-wizard-color-mode">
        (function(){
            var m=<?php echo wp_json_encode($wizard_color_mode); ?>;
            var eff='light';
            if(m==='dark'){eff='dark';}
            else if(m==='auto'){try{eff=window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';}catch(e){}}
            document.documentElement.setAttribute('data-yoo-wizard-pref',m);
            document.documentElement.setAttribute('data-yoo-wizard-effective',eff);
            if(eff==='dark'){document.documentElement.classList.add('yoo-wizard-html-dark');}
        })();
        </script>

        <div class="wrap yooadmin-wizard-page" data-yoo-wizard-pref="<?php echo esc_attr($wizard_color_mode); ?>">
            <div class="yooadmin-wizard-card">
                <div class="yoo-wizard-card-tools">
                    <?php $this->render_wizard_appearance_control($wizard_color_mode); ?>
                    <?php
                    if (function_exists('yooadmin_render_breadcrumbs_language_switcher')) {
                        yooadmin_render_breadcrumbs_language_switcher();
                    }
                    ?>
                </div>
                <div class="yooadmin-wizard-header">
                    <?php
        // Get logo URL - SAME AS YOOAdmin Header does
        $logo_url = function_exists('yooadmin_logo_url') ? yooadmin_logo_url() : '';
        $logo_default_url = function_exists('yooadmin_logo_default_url')
            ? yooadmin_logo_default_url()
            : YOOADMIN_PANEL_URL . 'assets/images/logo.png';
        $logo_display = $logo_url ?: $logo_default_url;
?>
                    <?php if ($logo_display): ?>
                        <img src="<?php echo esc_url($logo_display); ?>" alt="YOOAdmin" class="yooadmin-wizard-logo">
                    <?php
        else: ?>
                        <span class="yooadmin-wizard-logo-text">YOOAdmin</span>
                    <?php
        endif; ?>
                </div>
                <?php
        $this->setup_wizard_steps();
        $this->setup_wizard_content();
?>
            </div>
        </div>
        
        <!-- Skip Wizard Popup -->
        <div id="yooadmin-skip-wizard-popup" class="yooadmin-wizard-popup" style="display: none;">
            <div class="yooadmin-wizard-popup-overlay" id="skip-popup-overlay"></div>
            <div class="yooadmin-wizard-popup-content">
                <div class="yooadmin-wizard-popup-header">
                    <h2><?php esc_html_e('Skip Setup Wizard?', 'yooadmin'); ?></h2>
                    <button type="button" class="yooadmin-wizard-popup-close" id="skip-popup-close">
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>
                
                <div class="yooadmin-wizard-popup-body">
                    <p class="yooadmin-wizard-popup-message">
                        <?php esc_html_e('You can complete the setup anytime from YOOAdmin Settings.', 'yooadmin'); ?>
                    </p>
                    
                    <div class="yooadmin-wizard-popup-option">
                        <label class="yooadmin-wizard-popup-radio">
                            <input type="radio" name="skip_option" id="skip-continue-wordpress" value="wordpress">
                            <span class="yooadmin-wizard-popup-radio-label">
                                <strong><?php esc_html_e('Continue with WordPress', 'yooadmin'); ?></strong>
                                <small><?php esc_html_e('Keep WordPress default admin interface', 'yooadmin'); ?></small>
                            </span>
                        </label>
                    </div>
                    
                    <div class="yooadmin-wizard-popup-option">
                        <label class="yooadmin-wizard-popup-radio">
                            <input type="radio" name="skip_option" id="skip-enable-yooadmin" value="enable">
                            <span class="yooadmin-wizard-popup-radio-label">
                                <strong><?php esc_html_e('Enable YOOAdmin', 'yooadmin'); ?></strong>
                                <small><?php esc_html_e('Start with Focus Mode (recommended)', 'yooadmin'); ?></small>
                            </span>
                        </label>
                    </div>
                </div>
                
                <div class="yooadmin-wizard-popup-footer">
                    <button type="button" class="yp-yoo-btn yp-yoo-btn--soft yooadmin-wizard-popup-btn" id="skip-popup-close">
                        <?php esc_html_e('Cancel', 'yooadmin'); ?>
                    </button>
                    <button type="button" class="yp-yoo-btn yp-yoo-btn--primary yooadmin-wizard-popup-btn" id="skip-enable-btn" style="display: none;">
                        <?php esc_html_e('Enable YOOAdmin', 'yooadmin'); ?>
                    </button>
                    <button type="button" class="yp-yoo-btn yp-yoo-btn--soft yooadmin-wizard-popup-btn" id="skip-continue-btn" style="display: none;">
                        <?php esc_html_e('Continue', 'yooadmin'); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Setup wizard initialization
     * Works like enable-focus page - just needs inline CSS to hide everything
     */
    public function setup_wizard()
    {
        // Check if we're on the setup page
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing, no state change.
        if (empty($_GET['page']) || 'yooadmin-setup' !== $_GET['page']) {
            return;
        }

    // Nothing needed here - inline CSS in render_wizard_page() handles everything
    }

    /**
     * Enqueue scripts
     */
    public function enqueue_scripts($hook)
    {
        // Check if we're on the wizard page
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only page routing check; no state change.
        if ('dashboard_page_yooadmin-setup' !== $hook &&
        (empty($_GET['page']) || 'yooadmin-setup' !== $_GET['page'])) {
            // phpcs:enable WordPress.Security.NonceVerification.Recommended
            return;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        // Enqueue WordPress dependencies
        wp_enqueue_style('dashicons');
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');

        // Enqueue media uploader
        wp_enqueue_media();

        $media_modal_dark_abs = dirname(__DIR__) . '/assets/css/admin/wp-media-modal-dark.css';
        if (file_exists($media_modal_dark_abs)) {
            wp_enqueue_style(
                'yooadmin-wp-media-modal-dark',
                YOOADMIN_PANEL_URL . 'assets/css/admin/wp-media-modal-dark.css',
                [],
                (string) filemtime($media_modal_dark_abs)
            );
        }

        // Enqueue license CSS FIRST - required for popup styling
        wp_enqueue_style(
            'yooadmin-license',
            YOOADMIN_PANEL_URL . 'assets/css/admin/license.css',
            [],
            YOOADMIN_VERSION
        );

        // Arabic font (Tajawal) - only on wizard page, does not affect other WordPress pages
        $wizard_style_deps = ['wp-color-picker', 'yooadmin-license'];
        if (yooadmin_is_arabic_admin_ui()) {
            wp_enqueue_style(
                'yooadmin-tajawal-wizard',
                YOOADMIN_PANEL_URL . 'assets/fonts/tajawal.css',
                [],
                YOOADMIN_VERSION
            );
            $wizard_style_deps[] = 'yooadmin-tajawal-wizard';
        }

        // Enqueue wizard styles
        wp_enqueue_style(
            'yooadmin-setup-wizard',
            YOOADMIN_PANEL_URL . 'assets/css/setup-wizard.css',
            $wizard_style_deps,
            YOOADMIN_VERSION
        );

        $range_brand_css = dirname(__DIR__) . '/assets/css/admin/maintenance-tab-settings.css';
        if (file_exists($range_brand_css)) {
            wp_enqueue_style(
                'yooadmin-wizard-range-brand',
                YOOADMIN_PANEL_URL . 'assets/css/admin/maintenance-tab-settings.css',
                ['yooadmin-setup-wizard'],
                (string) filemtime($range_brand_css)
            );
        }

        $brand_dark_abs = dirname(__DIR__) . '/assets/css/admin/brand-dark-mode.css';
        if (file_exists($brand_dark_abs)) {
            wp_enqueue_style(
                'yooadmin-brand-dark',
                YOOADMIN_PANEL_URL . 'assets/css/admin/brand-dark-mode.css',
                ['yooadmin-setup-wizard'],
                (string) filemtime($brand_dark_abs)
            );
        }

        if (yooadmin_is_arabic_admin_ui()) {
            $tajawal_stack = '"Tajawal", system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif';
            wp_add_inline_style(
                'yooadmin-setup-wizard',
                '.yooadmin-wizard-page{--yoo-wizard-font:' . $tajawal_stack . ';}'
                . '.yooadmin-wizard-page .wizard-section-header h3{font-family:' . $tajawal_stack . '!important;font-weight:500;}'
                . '.yooadmin-wizard-popup,.yooadmin-wizard-popup-content,.yooadmin-wizard-popup-header,.yooadmin-wizard-popup-header h2,.yooadmin-wizard-popup-body,.yooadmin-wizard-popup-footer,.yooadmin-wizard-popup-btn,.yooadmin-wizard-popup-message,.yooadmin-wizard-popup-radio-label,.yooadmin-wizard-popup-terms,.yooadmin-wizard-popup-checkbox,.wizard-launch-overlay{font-family:' . $tajawal_stack . '!important;}'
            );
        }

        // Enqueue license.js for panel-connect and license actions
        wp_enqueue_script(
            'yooadmin-license',
            YOOADMIN_PANEL_URL . 'assets/js/admin/license.js',
        ['jquery'],
            YOOADMIN_VERSION,
            true
        );

        $portal_connect_url = YOOAdmin_License_Manager::get_license_portal_connect_url();
        $portal_origin = '';
        if ($portal_connect_url && strpos($portal_connect_url, 'http') === 0) {
            $parsed = wp_parse_url($portal_connect_url);
            if (!empty($parsed['scheme']) && !empty($parsed['host'])) {
                $portal_origin = $parsed['scheme'] . '://' . $parsed['host'];
                if (!empty($parsed['port'])) {
                    $portal_origin .= ':' . $parsed['port'];
                }
            }
        }

        // Localize script for license.js
        wp_localize_script('yooadmin-license', 'yooadmLicense', [
            'nonce' => wp_create_nonce('yooadmin_license_nonce'),
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'portalMessages' => [],
            'portalConnectUrl' => $portal_connect_url,
            'portalOrigin' => $portal_origin,
        ]);

        // Enqueue wizard scripts
        wp_enqueue_script(
            'yooadmin-setup-wizard',
            YOOADMIN_PANEL_URL . 'assets/js/admin/setup-wizard.js',
        ['jquery', 'wp-color-picker', 'yooadmin-license'],
            YOOADMIN_VERSION,
            true
        );

        if (function_exists('yooadmin_enqueue_admin_language_switcher_assets')) {
            yooadmin_enqueue_admin_language_switcher_assets();
        }

        $saved_colors = get_option('yooadmin_colors', []);
        $wizard_options = get_option('yooadmin_options', []);
        if (!is_array($wizard_options)) {
            $wizard_options = [];
        }
        $logo_url = isset($wizard_options['logo_url']) ? esc_url((string) $wizard_options['logo_url']) : '';
        $logo_width = isset($wizard_options['logo_w']) ? max(60, min(320, (int) $wizard_options['logo_w'])) : 150;
        $admin_favicon_url = isset($wizard_options['admin_favicon_url']) ? esc_url($wizard_options['admin_favicon_url']) : '';
        $admin_favicon_default_url = YOOADMIN_PANEL_URL . 'assets/images/favicon.ico';
        $default_logo_url = function_exists('yooadmin_logo_default_url')
            ? yooadmin_logo_default_url()
            : YOOADMIN_PANEL_URL . 'assets/images/logo.png';

        $license_context = \YOOAdmin_License_Manager::get_instance()->get_license_view_context();
        $get_license_url = $license_context['get_license_url'] ?? 'https://www.yooadmin.io/portal/register/?return_url=' . urlencode(admin_url('admin.php?page=yooadmin-license')) . '&source=yooadmin';
        $license_manager = YOOAdmin_License_Manager::get_instance();

        $color_picker_i18n = static function (): array {
            return function_exists('yooadmin_get_modern_color_picker_i18n')
                ? yooadmin_get_modern_color_picker_i18n()
                : [];
        };
        $color_picker_i18n = function_exists('yooadmin_with_admin_ui_locale')
            ? yooadmin_with_admin_ui_locale($color_picker_i18n)
            : $color_picker_i18n();

        wp_localize_script('yooadmin-setup-wizard', 'yooadmWizard', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'adminUrl' => admin_url(),
            'nonce' => wp_create_nonce('yooadmin_wizard'),
            'getLicenseUrl' => $get_license_url,
            'isLicenseActive' => $license_manager->is_license_active(),
            'steps' => array_keys($this->steps),
            'currentStep' => $this->step,
            'dashboardUrl' => admin_url('admin.php?page=yooadmin-dashboard'),
            'savedColors' => $saved_colors,
            'savedLogo' => $logo_url,
            'savedLogoWidth' => $logo_width,
            'adminFaviconUrl' => $admin_favicon_url,
            'adminFaviconDefaultUrl' => esc_url($admin_favicon_default_url),
            'defaultLogoUrl' => $default_logo_url,
            'colorMode' => $this->get_wizard_color_mode(),
            'colorModeNonce' => wp_create_nonce('yooadmin_wizard_color_mode'),
            'strings' => [
                'saving' => __('Saving...', 'yooadmin'),
                'error' => __('An error occurred. Please try again.', 'yooadmin'),
                'settingUp' => __('Setting up your dashboard...', 'yooadmin'),
                'applyingPreferences' => __('Applying your preferences...', 'yooadmin'),
                'almostReady' => __('Almost ready...', 'yooadmin'),
                'appearance' => __('Appearance', 'yooadmin'),
                'light' => __('Light', 'yooadmin'),
                'dark' => __('Dark', 'yooadmin'),
                'system' => __('System', 'yooadmin'),
                'brandingColorsLightTitle' => __('Switch to Light mode to edit colors', 'yooadmin'),
                'brandingColorsLightText' => __('Brand colors can only be changed in Light mode for an accurate preview.', 'yooadmin'),
                'switchToLight' => __('Switch to Light', 'yooadmin'),
                'next' => __('Next', 'yooadmin'),
                'skipForNow' => __('Skip for Now', 'yooadmin'),
            ],
            'colorPicker' => $color_picker_i18n,
        ]);

        // Dynamic wizard CSS (colors from DB) — must be in enqueue_assets so it's in <head>
        $wiz_colors = get_option('yooadmin_colors', []);
        $wiz_primary = !empty($wiz_colors['primary']) ? sanitize_hex_color($wiz_colors['primary']) : '#eda934';
        $wiz_border  = !empty($wiz_colors['border'])  ? sanitize_hex_color($wiz_colors['border'])  : '#e0e0e0';
        $wiz_header  = !empty($wiz_colors['header_bg']) ? sanitize_hex_color($wiz_colors['header_bg']) : '#4B4B4B';
        $wiz_sidebar = !empty($wiz_colors['sidebar_bg']) ? sanitize_hex_color($wiz_colors['sidebar_bg']) : '#4B4B4B';
        $wiz_rgb     = sscanf($wiz_primary, '#%02x%02x%02x');
        $wiz_primary_rgb = is_array($wiz_rgb) && count($wiz_rgb) === 3 ? implode(',', $wiz_rgb) : '237,169,52';

        $wizard_dynamic_css = '
#wpadminbar,#adminmenumain,#adminmenuback,#adminmenuwrap,.yooadmin-header,.yooadmin-sidebar,.yooadmin-main-content,.yooadmin-notification-icon,.yooadmin-breadcrumb,#wpfooter,#screen-meta,#screen-meta-links,.update-nag,.notice,.error,div.wrap>h1,div.wrap>h2{display:none!important;visibility:hidden!important}
html.wp-toolbar{padding-top:0!important}
#wpcontent{margin:0!important;padding:0!important}
#wpbody,#wpbody-content{padding:0!important;margin:0!important}
body{background:var(--yoo-wizard-surface,#eef0f3)!important;opacity:0;transition:opacity 0.1s,background-color 0.22s ease}
body.yoo-loaded{opacity:1}
html{--yooadmin-brand-source:' . esc_attr($wiz_primary) . ';--yooadmin-header-bg-source:' . esc_attr($wiz_header) . ';--yooadmin-sidebar-bg-source:' . esc_attr($wiz_sidebar) . '}
.yooadmin-wizard-page{--yoo-wizard-header-brand:' . esc_attr($wiz_header) . ';--yooadmin-brand-source:' . esc_attr($wiz_primary) . ';--yooadmin-header-bg-source:' . esc_attr($wiz_header) . ';--yooadmin-sidebar-bg-source:' . esc_attr($wiz_sidebar) . '}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page{--yoo-wizard-brand:' . esc_attr($wiz_primary) . '}
html.yoo-wizard-html-dark{--yoo-wp-media-brand-rgb:' . esc_attr($wiz_primary_rgb) . '}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page{--yoo-wizard-header:var(--yoo-wizard-header-brand)}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .yooadmin-setup-steps li.completed{color:' . esc_attr($wiz_primary) . '}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .yooadmin-setup-steps li.completed .step-number{background:' . esc_attr($wiz_primary) . ';color:#fff;border-color:' . esc_attr($wiz_primary) . '}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .yooadmin-setup-steps li.active .step-number{background:' . esc_attr($wiz_primary) . ';color:#fff;border-color:' . esc_attr($wiz_primary) . '}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-step-footer .wizard-btn-primary,html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-step-footer .wizard-btn-next,html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-btn-primary,html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-btn-next{background-color:' . esc_attr($wiz_primary) . ' !important;border:none !important;color:#fff !important}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-step-footer .wizard-btn-primary:hover,html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-step-footer .wizard-btn-next:hover,html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-btn-primary:hover,html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-btn-next:hover{background-color:' . esc_attr($wiz_primary) . ' !important;opacity:0.9;color:#fff !important}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-compact-setting input[type="checkbox"]:checked ~ .wizard-compact-checkmark{background:' . esc_attr($wiz_primary) . ';border-color:' . esc_attr($wiz_primary) . '}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-section-hint .yoo-hint{color:' . esc_attr($wiz_primary) . '}
html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-features-list .dashicons,html:not(.yoo-wizard-html-dark) .yooadmin-wizard-page .wizard-launch-icon .dashicons{color:' . esc_attr($wiz_primary) . '}
html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button-primary{background-color:' . esc_attr($wiz_primary) . ' !important;border-color:' . esc_attr($wiz_primary) . ' !important;color:#fff !important}
html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button-primary:hover{background-color:' . esc_attr($wiz_primary) . ' !important;opacity:0.9}
html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-login-code,html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-otp-use-code,html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-otp-resend,html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-code-back,html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-otp-back{background-color:' . esc_attr($wiz_primary) . ' !important;border-color:' . esc_attr($wiz_primary) . ' !important;color:#fff !important}
html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-login-code:hover,html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-otp-use-code:hover,html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-otp-resend:hover,html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-code-back:hover,html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .button.yooadmin-otp-back:hover{background-color:' . esc_attr($wiz_primary) . ' !important;opacity:0.9}
html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .yooadmin-otp-forgot{color:' . esc_attr($wiz_primary) . ' !important}
html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .yooadmin-otp-forgot:hover{color:' . esc_attr($wiz_primary) . ' !important;opacity:0.8}
html:not(.yoo-wizard-html-dark) #yooadmin-otp-popup .yooadmin-otp-mode-active{background:rgba(' . esc_attr($wiz_primary_rgb) . ',0.12) !important;color:' . esc_attr($wiz_primary) . ' !important;box-shadow:inset 0 -2px 0 ' . esc_attr($wiz_primary) . ' !important}';

        wp_add_inline_style('yooadmin-setup-wizard', $wizard_dynamic_css);

        wp_add_inline_script('yooadmin-setup-wizard', '
(function(){
    var hideElements = function(){
        var selectors = "#wpadminbar,#adminmenumain,#adminmenuback,.yooadmin-header,.yooadmin-sidebar,#wpfooter";
        var elements = document.querySelectorAll(selectors);
        elements.forEach(function(el){el.style.display="none"});
        document.body.classList.add("yooadmin-wizard-fullscreen","yoo-loaded");
    };
    if(document.readyState==="loading"){
        document.addEventListener("DOMContentLoaded",hideElements);
    }else{
        hideElements();
    }
    window.addEventListener("load",hideElements);
})();', 'before');
    }

    /**
     * Fullscreen wizard body class (before JS runs).
     *
     * @param string $classes Admin body classes.
     * @return string
     */
    public function admin_body_class($classes)
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && $screen->id === 'admin_page_yooadmin-setup') {
            $classes .= ' yooadmin-wizard-fullscreen';
        }

        return $classes;
    }


    /**
     * Setup wizard steps
     */
    private function setup_wizard_steps()
    {
        $output_steps = $this->steps;
?>
        <div class="yooadmin-setup-wrapper">
        <div class="yooadmin-setup-steps">
            <ul>
                <?php
        $step_number = 1;
        foreach ($output_steps as $step_key => $step) {
            $is_completed = array_search($this->step, array_keys($this->steps), true) > array_search($step_key, array_keys($this->steps), true);
            $is_active = $this->step === $step_key;

            $class = '';
            if ($is_active) {
                $class = 'active';
            }
            elseif ($is_completed) {
                $class = 'completed';
            }
?>
                    <li class="<?php echo esc_attr($class); ?>">
                        <span class="step-number"><?php echo $is_completed ? '✓' : esc_html($step_number); ?></span>
                        <span class="step-name"><?php echo esc_html($this->get_wizard_step_label($step_key)); ?></span>
                    </li>
                    <?php
            $step_number++;
        }
?>
            </ul>
        </div>
        <?php
    }

    /**
     * Setup wizard content
     */
    private function setup_wizard_content()
    {
        echo '<div class="yooadmin-wizard-step yooadmin-wizard-' . esc_attr($this->step) . '">';
        echo '<div class="yooadmin-setup-content">';

        if (!empty($this->steps[$this->step]['view'])) {
            call_user_func($this->steps[$this->step]['view'], $this);
        }

        echo '</div>'; // Close yooadmin-setup-content

        // Footer outside content for full width
        $this->setup_wizard_footer();

        // Launch Animation Overlay (used for Launch and Skip)
?>
        <div class="wizard-launch-overlay" id="wizard-launch-overlay" style="display: none;">
            <div class="wizard-launch-animation">
                <!-- Building Animation -->
                <div class="wizard-building-stage" id="building-stage">
                    <div class="wizard-progress-bar">
                        <div class="wizard-progress-fill" id="progress-fill"></div>
                    </div>
                    <p class="wizard-progress-message" id="progress-message">
                        <?php esc_html_e('Setting up your dashboard...', 'yooadmin'); ?>
                    </p>
                </div>
                
                <!-- Countdown Stage -->
                <div class="wizard-countdown-stage" id="countdown-stage" style="display: none;">
                    <div class="wizard-countdown-number" id="countdown-number">3</div>
                </div>
            </div>
        </div>
        <?php

        echo '</div>'; // Close yooadmin-wizard-step
        echo '</div>'; // Close yooadmin-setup-wrapper
    }

    /**
     * Setup wizard footer with full width
     */
    private function setup_wizard_footer()
    {
        $license_active = false;
        if ($this->step === 'license') {
            $license_active = YOOAdmin_License_Manager::get_instance()->is_license_active();
        }
?>
        <div class="wizard-step-footer">
            <div class="wizard-footer-start">
                <?php if ($this->step !== 'welcome' && $this->step !== 'launch'): ?>
                    <button type="button" class="wizard-btn wizard-btn-text wizard-btn-prev" data-action="prev">
                        <?php esc_html_e('Previous', 'yooadmin'); ?>
                    </button>
                <?php
        elseif ($this->step === 'welcome'): ?>
                    <button type="button" class="wizard-btn wizard-btn-text wizard-btn-skip" data-action="skip">
                        <?php esc_html_e('Skip Setup', 'yooadmin'); ?>
                    </button>
                <?php
        endif; ?>
            </div>
            <div class="wizard-footer-end">
                <?php if ($this->step !== 'launch'): ?>
                    <?php if ($this->step !== 'welcome' && ($this->step !== 'license' || !$license_active)): ?>
                        <button type="button" class="wizard-btn wizard-btn-text wizard-btn-skip" data-action="skip">
                            <?php
                if ($this->step === 'license') {
                    esc_html_e('Skip for Now', 'yooadmin');
                }
                else {
                    esc_html_e('Skip this step', 'yooadmin');
                }
?>
                        </button>
                    <?php
            endif; ?>
                    <?php if ($this->step !== 'license' || $license_active): ?>
                    <button type="button" class="wizard-btn wizard-btn-primary wizard-btn-next" data-action="next">
                        <?php
            if ($this->step === 'welcome') {
                esc_html_e('Let\'s Start', 'yooadmin');
            }
            else {
                esc_html_e('Next', 'yooadmin');
            }
?>
                    </button>
                    <?php endif; ?>
                <?php
        else: ?>
                    <button type="button" class="wizard-btn wizard-btn-primary wizard-btn-launch" id="wizard-launch-btn">
                        <?php esc_html_e('Launch YOOAdmin', 'yooadmin'); ?>
                    </button>
                <?php
        endif; ?>
            </div>
        </div>
        <?php
    }


    /**
     * Welcome step
     */
    public function wizard_welcome()
    {
        include YOOADMIN_PANEL_DIR . 'templates/wizard/step-welcome.php';
    }

    /**
     * Branding step
     */
    public function wizard_branding()
    {
        include YOOADMIN_PANEL_DIR . 'templates/wizard/step-branding.php';
    }

    /**
     * General settings step
     */
    public function wizard_general()
    {
        include YOOADMIN_PANEL_DIR . 'templates/wizard/step-general.php';
    }

    /**
     * License step
     */
    public function wizard_license()
    {
        include YOOADMIN_PANEL_DIR . 'templates/wizard/step-license.php';
    }

    /**
     * Launch step
     */
    public function wizard_launch()
    {
        include YOOADMIN_PANEL_DIR . 'templates/wizard/step-launch.php';
    }

    /**
     * AJAX: Save step data
     */
    public function ajax_save_step()
    {
        check_ajax_referer('yooadmin_wizard', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')]);
        }

        $step = isset($_POST['step']) ? sanitize_key($_POST['step']) : '';
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via sanitize_wizard_step_data() below.
        $data = isset($_POST['data']) ? $this->sanitize_wizard_step_data(wp_unslash($_POST['data'])) : [];

        // Save step data based on step
        switch ($step) {
            case 'welcome':
                $this->save_welcome_step($data);
                break;
            case 'branding':
                $this->save_branding_step($data);
                break;
            case 'general':
                $this->save_general_step($data);
                break;
            case 'license':
                $this->save_license_step($data);
                break;
        }

        // Persist appearance with step navigation (click-save AJAX can abort on redirect).
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
        $color_mode = isset($_POST['color_mode']) ? sanitize_key((string) wp_unslash($_POST['color_mode'])) : '';
        if ($color_mode !== '') {
            $this->persist_wizard_color_mode($color_mode);
        }

        wp_send_json_success(['message' => __('Saved successfully', 'yooadmin')]);
    }

    /**
     * Save welcome step
     */
    private function save_welcome_step($data)
    {
        // Save terms acceptance
        if (!empty($data['accept_terms'])) {
            update_option('yooadmin_terms_accepted', [
                'accepted' => true,
                'timestamp' => current_time('mysql'),
                'ip' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '',
                'version' => '1.0'
            ]);
        }

        // Create notification tables early so they're available for all wizard steps
        // (e.g., license activation needs to query/store notifications)
        if (function_exists('yooadmin_get_storage')) {
            $storage = yooadmin_get_storage();
            if (method_exists($storage, 'create_tables')) {
                $storage->create_tables();
            }
        }
    }

    /**
     * Save branding step
     */
    private function save_branding_step($data)
    {
        // Save or clear logo from yooadmin_options array - SAME AS YOOAdmin Settings
        $options = get_option('yooadmin_options', []);
        if (!is_array($options)) {
            $options = [];
        }

        if (!empty($data['logo_id'])) {
            // Save logo
            $logo_id = intval($data['logo_id']);
            $logo_url = wp_get_attachment_url($logo_id);

            if ($logo_url) {
                // Save as 'logo_url' - exactly like YOOAdmin Settings does
                $options['logo_url'] = esc_url_raw($logo_url);
            }
        }
        elseif (!empty($data['logo_url'])) {
            $options['logo_url'] = esc_url_raw((string) $data['logo_url']);
        }
        elseif (isset($data['logo_action']) && $data['logo_action'] === 'clear') {
            // Clear logo (when reset button is clicked)
            $options['logo_url'] = '';
            $options['logo_w']   = 150;
        }

        if (isset($data['logo_w'])) {
            $options['logo_w'] = isset($data['logo_action']) && $data['logo_action'] === 'clear'
                ? 150
                : max(60, min(320, (int) $data['logo_w']));
        }

        if (isset($data['admin_favicon_url'])) {
            $options['admin_favicon_url'] = !empty($data['admin_favicon_url'])
                ? esc_url_raw((string) $data['admin_favicon_url'])
                : '';
        }

        update_option('yooadmin_options', $options);

        // Save colors - EXACTLY LIKE Theme Manager's save_brand_colors() method
        if (!empty($data['colors']) && is_array($data['colors'])) {
            // Define brand color defaults - SAME AS Theme Manager
            $brand_color_definitions = [
                'primary' => ['key' => 'primary', 'default' => '#eda934'],
                'border' => ['key' => 'border', 'default' => '#e0e0e0'],
                'header_bg' => ['key' => 'header_bg', 'default' => '#4B4B4B'],
                'sidebar_bg' => ['key' => 'sidebar_bg', 'default' => '#4B4B4B'],
                'text_contrast' => ['key' => 'text_contrast', 'default' => '#FFFFFF'],
                'text_600' => ['key' => 'text_600', 'default' => '#5d5d5d'],
                'text_500' => ['key' => 'text_500', 'default' => '#555555'],
                'card_icon' => ['key' => 'card_icon', 'default' => '#eda934'],
            ];

            // Get current stored colors
            $stored = get_option('yooadmin_colors', []);
            if (!is_array($stored)) {
                $stored = [];
            }

            // Loop through each color definition - ONLY UPDATE COLORS THAT WERE CHANGED
            foreach ($brand_color_definitions as $definition) {
                $key = $definition['key'];
                $default = $definition['default'];
                $raw = $data['colors'][$key] ?? '';

                // Only update if a new value was provided
                if (isset($data['colors'][$key]) && $raw !== '') {
                    $sanitized = sanitize_hex_color($raw);
                    if ($sanitized) {
                        // Valid new color - save it
                        $stored[$key] = $sanitized;
                    }
                    elseif ($raw === '') {
                        // Empty string means reset to default
                        $stored[$key] = $default;
                    }
                // If sanitization failed, keep existing value (don't update)
                }
            // If color not in $data['colors'], keep existing value from $stored (don't overwrite with default)
            }

            // Save to database - EXACTLY LIKE Theme Manager
            update_option('yooadmin_colors', $stored);
        }
    }

    /**
     * Save general step
     */
    private function save_general_step($data)
    {
        // Get existing options array
        $options = get_option('yooadmin_options', []);
        if (!is_array($options)) {
            $options = [];
        }

        // Map wizard data to yooadmin_options array format
        // The wizard sends data with keys matching the option names
        $mapping = [
            'posts_redirect'                 => 'posts_redirect',
            'comments_redirect'              => 'comments_redirect',
            'pages_redirect'                 => 'pages_redirect',
            'categories_redirect'            => 'categories_redirect',
            'tags_redirect'                  => 'tags_redirect',
            'users_redirect'                   => 'users_redirect',
            'wp_settings_experience'         => 'wp_settings_experience',
            'plugin_install_basic'           => 'plugin_install_basic',
            'login_page_enabled'             => 'login_page_enabled',
            'login_rate_limit_enabled'       => 'login_rate_limit_enabled',
            'convert_banners_to_notifications' => 'convert_banners_to_notifications',
            'delete_data_on_uninstall'       => 'delete_data_on_uninstall',
        ];

        foreach ($mapping as $wizard_key => $option_key) {
            if (isset($data[$wizard_key])) {
                $on = ($data[$wizard_key] === '1' || $data[$wizard_key] === 'on' || $data[$wizard_key] === true);
                // Store 0/1 like Settings sanitize_toggle (avoids ambiguous booleans in DB).
                $options[$option_key] = $on ? 1 : 0;
            }
        }

        $options = apply_filters('yooadmin_wizard_general_options', $options, $data);

        update_option('yooadmin_options', $options);
    }

    /**
     * Save license step
     */
    private function save_license_step($data)
    {
        // License activation handled by License Manager
        // Just mark that user went through this step
        update_option('yooadmin_wizard_license_step_completed', true);
    }

    /**
     * AJAX: Complete wizard
     */
    public function ajax_complete_wizard()
    {
        check_ajax_referer('yooadmin_wizard', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')]);
        }

        // Re-persist branding snapshot sent from launch/complete (covers uploads not saved via Next).
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via sanitize_wizard_step_data() below.
        $branding_raw = isset($_POST['branding']) ? wp_unslash($_POST['branding']) : [];
        $branding     = is_array($branding_raw) ? $this->sanitize_wizard_step_data($branding_raw) : [];
        if ($branding) {
            $this->save_branding_step($branding);
        }

        // Mark wizard as completed
        update_option('yooadmin_wizard_completed', true);
        update_option('yooadmin_wizard_completed_date', current_time('mysql'));

        if (function_exists('yooadmin_restore_focus_after_wizard')) {
            yooadmin_restore_focus_after_wizard();
        }

        // Create notification tables immediately so they exist on first dashboard load
        // (storage.php constructor won't create them during this AJAX request because Focus was OFF)
        if (function_exists('yooadmin_get_storage')) {
            $storage = yooadmin_get_storage();
            if (method_exists($storage, 'create_tables')) {
                $storage->create_tables();
            }
        }

        wp_send_json_success([
            'message' => __('Setup completed successfully!', 'yooadmin'),
            'redirect' => admin_url('admin.php?page=yooadmin-dashboard')
        ]);
    }

    /**
     * AJAX: Skip wizard
     */
    public function ajax_skip_wizard()
    {
        check_ajax_referer('yooadmin_wizard', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')]);
        }

        // Get enable_focus parameter
        $enable_focus = !empty($_POST['enable_focus']) && $_POST['enable_focus'] === '1';

        if ($enable_focus) {
            // User chose "Enable YOOAdmin" - save default settings first
            $this->save_default_settings();

            // Mark as completed
            update_option('yooadmin_wizard_completed', true);
            update_option('yooadmin_wizard_completed_date', current_time('mysql'));

            if (function_exists('yooadmin_restore_focus_after_wizard')) {
                yooadmin_restore_focus_after_wizard();
            }

            // Create notification tables immediately
            if (function_exists('yooadmin_get_storage')) {
                $storage = yooadmin_get_storage();
                if (method_exists($storage, 'create_tables')) {
                    $storage->create_tables();
                }
            }
        }
        else {
            // User chose "Continue with WordPress" - mark as dismissed
            update_option('yooadmin_wizard_dismissed', true);
            update_option('yooadmin_wizard_dismissed_date', current_time('mysql'));

            // CRITICAL: Keep policy as 'off' to disable Focus Mode completely
            // Don't reset to 'auto' because that would enable Focus Mode by default!
            update_option('yooadmin_focus_policy', 'off');

            // Set cookie to OFF
            if (!headers_sent()) {
                setcookie('yoo_focus', 'off', time() + (365 * DAY_IN_SECONDS), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
            }
        }

        // Redirect based on choice
        $redirect = $enable_focus ? admin_url('admin.php?page=yooadmin-dashboard') : admin_url();

        wp_send_json_success([
            'message' => __('Setup completed', 'yooadmin'),
            'redirect' => $redirect
        ]);
    }

    /**
     * Get next step URL
     */
    public function get_next_step_url()
    {
        $keys = array_keys($this->steps);
        $current_index = array_search($this->step, $keys, true);

        if ($current_index !== false && isset($keys[$current_index + 1])) {
            return admin_url('admin.php?page=yooadmin-setup&step=' . $keys[$current_index + 1]);
        }

        return admin_url('admin.php?page=yooadmin-dashboard');
    }

    /**
     * Get previous step URL
     */
    public function get_previous_step_url()
    {
        $keys = array_keys($this->steps);
        $current_index = array_search($this->step, $keys, true);

        if ($current_index !== false && $current_index > 0) {
            return admin_url('admin.php?page=yooadmin-setup&step=' . $keys[$current_index - 1]);
        }

        return admin_url('admin.php?page=yooadmin-setup');
    }

    /**
     * AJAX: Check license status
     */
    public function ajax_check_license_status()
    {
        check_ajax_referer('yooadmin_wizard', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')]);
        }

        $license_manager = YOOAdmin_License_Manager::get_instance();
        $is_active = $license_manager->is_license_active();

        wp_send_json_success([
            'is_active' => $is_active
        ]);
    }

    /**
     * Save default settings when skipping wizard
     */
    private function save_default_settings()
    {
        // Save default branding (colors)
        $brand_color_definitions = [
            'primary' => ['key' => 'primary', 'default' => '#eda934'],
            'border' => ['key' => 'border', 'default' => '#e0e0e0'],
            'header_bg' => ['key' => 'header_bg', 'default' => '#4B4B4B'],
            'sidebar_bg' => ['key' => 'sidebar_bg', 'default' => '#4B4B4B'],
            'text_contrast' => ['key' => 'text_contrast', 'default' => '#FFFFFF'],
            'text_600' => ['key' => 'text_600', 'default' => '#5d5d5d'],
            'text_500' => ['key' => 'text_500', 'default' => '#555555'],
            'card_icon' => ['key' => 'card_icon', 'default' => '#eda934'],
        ];

        $stored = get_option('yooadmin_colors', []);
        if (!is_array($stored)) {
            $stored = [];
        }

        // Save default colors (only if not already set)
        foreach ($brand_color_definitions as $definition) {
            $key = $definition['key'];
            $default = $definition['default'];

            // Only set if not already set
            if (!isset($stored[$key]) || empty($stored[$key])) {
                $stored[$key] = $default;
            }
        }

        update_option('yooadmin_colors', $stored);

        // Save default general settings (all unchecked = WordPress default)
        $options = get_option('yooadmin_options', []);
        if (!is_array($options)) {
            $options = [];
        }

        // Set all redirects to false (WordPress default)
        $redirect_options = [
            'posts_redirect' => false,
            'comments_redirect' => false,
            'pages_redirect' => false,
            'categories_redirect' => false,
            'tags_redirect' => false,

            'users_redirect' => false,
            'delete_data_on_uninstall' => false,
        ];

        foreach ($redirect_options as $key => $value) {
            // Only set if not already set
            if (!isset($options[$key])) {
                $options[$key] = $value;
            }
        }

        if (!isset($options['login_page_enabled'])) {
            $options['login_page_enabled'] = 1;
        }
        if (!isset($options['login_page_logo_source'])) {
            $options['login_page_logo_source'] = 'branding';
        }
        if (!isset($options['login_rate_limit_enabled'])) {
            $options['login_rate_limit_enabled'] = 1;
        }

        update_option('yooadmin_options', $options);
    }

    /**
     * AJAX: Refresh license step content
     */
    public function ajax_refresh_license_step()
    {
        check_ajax_referer('yooadmin_wizard', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')]);
        }

        // Get updated license step HTML
        ob_start();
        include YOOADMIN_PANEL_DIR . 'templates/wizard/step-license.php';
        $html = ob_get_clean();

        $license_manager = YOOAdmin_License_Manager::get_instance();
        $is_active = $license_manager->is_license_active();

        wp_send_json_success([
            'html' => $html,
            'is_active' => $is_active
        ]);
    }

    /**
     * AJAX: Mark welcome popup as shown
     */
    public function ajax_mark_welcome_popup_shown()
    {
        check_ajax_referer('yooadmin_welcome_popup', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')]);
        }

        // Mark popup as shown (show once on first launch only)
        update_option('yooadmin_welcome_popup_shown', true);

        wp_send_json_success(['message' => __('Welcome popup marked as shown', 'yooadmin')]);
    }

    /**
     * Sanitize wizard step payload (preserve URLs and color hex values).
     *
     * @param mixed $data Raw POST data.
     * @return array<string, mixed>
     */
    private function sanitize_wizard_step_data($data): array
    {
        if (!is_array($data)) {
            return [];
        }

        $url_keys = ['admin_favicon_url', 'logo_url'];
        $out = [];

        foreach ($data as $key => $value) {
            $key = is_string($key) ? sanitize_key($key) : '';
            if ($key === '') {
                continue;
            }

            if ($key === 'colors' && is_array($value)) {
                $out['colors'] = [];
                foreach ($value as $color_key => $color_value) {
                    $color_key = is_string($color_key) ? sanitize_key($color_key) : '';
                    if ($color_key === '') {
                        continue;
                    }
                    $raw = is_scalar($color_value) ? (string) $color_value : '';
                    $hex = sanitize_hex_color($raw);
                    $out['colors'][$color_key] = $hex ? $hex : sanitize_text_field($raw);
                }
                continue;
            }

            if (in_array($key, $url_keys, true)) {
                $out[$key] = esc_url_raw(is_scalar($value) ? (string) $value : '');
                continue;
            }

            if (is_array($value)) {
                $out[$key] = map_deep($value, 'sanitize_text_field');
                continue;
            }

            $out[$key] = sanitize_text_field(is_scalar($value) ? (string) $value : '');
        }

        return $out;
    }

    /**
     * AJAX: Save convert banners to notifications option
     */
    public function ajax_save_convert_banners()
    {
        check_ajax_referer('yooadmin_wizard', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')]);
        }

        // Get current options
        $opts = get_option('yooadmin_options', []);
        if (!is_array($opts)) {
            $opts = [];
        }

        // Save convert_banners_to_notifications
        $convert_banners = isset($_POST['convert_banners']) && $_POST['convert_banners'] === '1';
        $opts['convert_banners_to_notifications'] = $convert_banners ? 1 : 0;

        // Save options
        update_option('yooadmin_options', $opts);

        wp_send_json_success(['message' => __('Setting saved successfully', 'yooadmin')]);
    }

    /**
     * Saved Studio Hub appearance preference (light|dark|auto).
     *
     * @return string
     */
    private function get_wizard_color_mode(): string
    {
        $stored = get_option('yooadmin_admin_theme_settings_yooadmin-studio-hub', []);
        if (is_array($stored) && isset($stored['color_mode'])) {
            $mode = sanitize_key((string) $stored['color_mode']);
            if (in_array($mode, ['light', 'dark', 'auto'], true)) {
                return $mode;
            }
        }

        if (function_exists('yooadmin_studio_hub_get_color_mode')) {
            $mode = yooadmin_studio_hub_get_color_mode();
            if (in_array($mode, ['light', 'dark', 'auto'], true)) {
                return $mode;
            }
        }

        if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
            $mode = YOOAdmin_Admin_Theme_Manager::get_instance()->get_appearance_color_mode_for_ui();
            if (is_string($mode) && in_array($mode, ['light', 'dark', 'auto'], true)) {
                return $mode;
            }
        }

        return 'auto';
    }

    /**
     * Persist wizard appearance to Studio Hub theme settings.
     *
     * @param string $mode light|dark|auto
     */
    private function persist_wizard_color_mode(string $mode): void
    {
        if (!in_array($mode, ['light', 'dark', 'auto'], true)) {
            return;
        }

        $option_name = 'yooadmin_admin_theme_settings_yooadmin-studio-hub';
        $stored = get_option($option_name, []);
        if (!is_array($stored)) {
            $stored = [];
        }
        $stored['color_mode'] = $mode;
        update_option($option_name, $stored, false);

        if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
            YOOAdmin_Admin_Theme_Manager::get_instance()->save_appearance_color_mode('yooadmin-studio-hub', $mode);
        }
    }

    /**
     * Appearance pill control (light / dark / system).
     *
     * @param string $color_mode light|dark|auto
     */
    private function render_wizard_appearance_control(string $color_mode = 'auto'): void
    {
        if (!in_array($color_mode, ['light', 'dark', 'auto'], true)) {
            $color_mode = 'auto';
        }

        $svg_light = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('light', 15, 'yoo-wizard-appearance-icon') : '';
        $svg_dark  = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('dark', 15, 'yoo-wizard-appearance-icon') : '';
        $svg_auto  = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('auto', 15, 'yoo-wizard-appearance-icon') : '';
        ?>
        <div class="yoo-wizard-appearance" role="group" aria-label="<?php echo esc_attr__('Appearance', 'yooadmin'); ?>">
            <span class="yoo-wizard-appearance-label"><?php esc_html_e('Appearance', 'yooadmin'); ?></span>
            <div class="yoo-wizard-appearance-pills">
                <button type="button" class="yoo-wizard-appearance-btn<?php echo 'auto' === $color_mode ? ' is-active' : ''; ?>" data-yoo-wizard-pref="auto" title="<?php echo esc_attr__('System', 'yooadmin'); ?>">
                    <?php echo $svg_auto; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <span class="screen-reader-text"><?php esc_html_e('System', 'yooadmin'); ?></span>
                </button>
                <button type="button" class="yoo-wizard-appearance-btn<?php echo 'light' === $color_mode ? ' is-active' : ''; ?>" data-yoo-wizard-pref="light" title="<?php echo esc_attr__('Light', 'yooadmin'); ?>">
                    <?php echo $svg_light; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <span class="screen-reader-text"><?php esc_html_e('Light', 'yooadmin'); ?></span>
                </button>
                <button type="button" class="yoo-wizard-appearance-btn<?php echo 'dark' === $color_mode ? ' is-active' : ''; ?>" data-yoo-wizard-pref="dark" title="<?php echo esc_attr__('Dark', 'yooadmin'); ?>">
                    <?php echo $svg_dark; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <span class="screen-reader-text"><?php esc_html_e('Dark', 'yooadmin'); ?></span>
                </button>
            </div>
        </div>
        <?php
    }

    /**
     * AJAX: persist appearance color mode from wizard.
     */
    public function ajax_save_color_mode(): void
    {
        check_ajax_referer('yooadmin_wizard_color_mode', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')], 403);
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
        $raw = isset($_POST['color_mode']) ? sanitize_key((string) wp_unslash($_POST['color_mode'])) : '';
        if (!in_array($raw, ['light', 'dark', 'auto'], true)) {
            wp_send_json_error(['message' => __('Invalid appearance mode.', 'yooadmin')], 400);
        }

        $this->persist_wizard_color_mode($raw);

        wp_send_json_success(['color_mode' => $raw]);
    }
}

// Initialize
YOOAdmin_Setup_Wizard::get_instance();
