<?php
/**
 * YOOAdmin - Hash optimizer (notification change detection)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Load cache constants
require_once __DIR__ . '/cache-constants.php';

class YOOAdmin_Hash_Optimizer
{

    private $cache;

    public function __construct()
    {
        $this->cache = new YOOAdmin_Cache();
    }

    /**
     * Generate hash for notifications array
     */
    public function generate($notifications)
    {
        if (empty($notifications)) {
            return 'empty';
        }

        // Create a normalized array for consistent hashing
        $normalized = $this->normalize_notifications($notifications);

        // Generate hash using multiple algorithms for reliability
        $hash_data = [
            'count' => count($normalized),
            'items' => $normalized,
            'timestamp' => floor(time() / YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS_HASH) * YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS_HASH
        ];

        $hash = md5(serialize($hash_data));

        return $hash;
    }

    /**
     * Compare two hashes
     */
    public function compare($hash1, $hash2)
    {
        return $hash1 === $hash2;
    }

    /**
     * Check if hash changed
     */
    public function has_changed($user_id, $new_hash)
    {
        $cached_hash = $this->cache->get(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATIONS_HASH . $user_id);

        return $cached_hash !== $new_hash;
    }

    /**
     * Get cached hash
     */
    public function get_cached_hash($user_id)
    {
        return $this->cache->get(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATIONS_HASH . $user_id);
    }

    /**
     * Set cached hash
     */
    public function set_cached_hash($user_id, $hash, $ttl = null)
    {
        if ($ttl === null) {
            $ttl = YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS_HASH;
        }
        return $this->cache->set(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATIONS_HASH . $user_id, $hash, $ttl);
    }

    /**
     * Generate hash for individual notification
     */
    public function generate_notification_hash($notification)
    {
        $normalized = $this->normalize_single_notification($notification);
        return md5(serialize($normalized));
    }

    /**
     * Check if notification content changed
     */
    public function notification_changed($notification_id, $new_notification)
    {
        $cached_hash = $this->cache->get(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATION_HASH . $notification_id);
        $new_hash = $this->generate_notification_hash($new_notification);

        return $cached_hash !== $new_hash;
    }

    /**
     * Set notification hash cache
     */
    public function set_notification_hash($notification_id, $hash, $ttl = null)
    {
        if ($ttl === null) {
            $ttl = YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS_HASH;
        }
        return $this->cache->set(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATION_HASH . $notification_id, $hash, $ttl);
    }

    /**
     * Generate hash for data source
     */
    public function generate_source_hash($source_type, $data)
    {
        $hash_data = [
            'source' => $source_type,
            'data' => $data,
            'timestamp' => floor(time() / YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS_HASH) * YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS_HASH
        ];

        return md5(serialize($hash_data));
    }

    /**
     * Check if source data changed
     */
    public function source_changed($source_type, $new_data)
    {
        $cached_hash = $this->cache->get(YOOAdmin_Cache_Constants::PREFIX_SOURCE_HASH . $source_type);
        $new_hash = $this->generate_source_hash($source_type, $new_data);

        return $cached_hash !== $new_hash;
    }

    /**
     * Set source hash cache
     */
    public function set_source_hash($source_type, $hash, $ttl = null)
    {
        if ($ttl === null) {
            $ttl = YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS_HASH;
        }
        return $this->cache->set(YOOAdmin_Cache_Constants::PREFIX_SOURCE_HASH . $source_type, $hash, $ttl);
    }

    /**
     * Normalize notifications for consistent hashing
     */
    private function normalize_notifications($notifications)
    {
        $normalized = [];

        foreach ($notifications as $notification) {
            $normalized[] = $this->normalize_single_notification($notification);
        }

        // Sort by title then message to ensure consistent order
        usort($normalized, function ($a, $b) {
            $title_cmp = strcmp($a['title'], $b['title']);
            if ($title_cmp !== 0) {
                return $title_cmp;
            }
            return strcmp($a['message'], $b['message']);
        });

        return $normalized;
    }

    /**
     * Normalize single notification
     */
    private function normalize_single_notification($notification)
    {
        // Create a normalized version with consistent field order
        return [
            'title' => $this->normalize_string($notification['title'] ?? ''),
            'message' => $this->normalize_string($notification['message'] ?? ''),
            'type' => $notification['type'] ?? 'info',
            'priority' => $notification['priority'] ?? 'medium',
            'source' => $notification['source'] ?? 'unknown',
            'source_type' => $notification['source_type'] ?? 'unknown',
            'url' => $notification['url'] ?? '',
            'icon' => $notification['icon'] ?? 'admin-site',
            'group_id' => $notification['group_id'] ?? ''
        ];
    }

    /**
     * Normalize string for hashing
     */
    private function normalize_string($string)
    {
        // Remove HTML tags, normalize whitespace, and convert to lowercase
        $string = wp_strip_all_tags($string);
        $string = preg_replace('/\s+/', ' ', $string);
        $string = trim($string);

        return strtolower($string);
    }

    /**
     * Generate quick hash for performance
     */
    public function generate_quick_hash($data)
    {
        // Use a faster hashing method for performance-critical operations
        return hash('xxh64', serialize($data));
    }

    /**
     * Batch hash generation for multiple users
     */
    public function generate_batch_hashes($notifications_by_user)
    {
        $hashes = [];

        foreach ($notifications_by_user as $user_id => $notifications) {
            $hashes[$user_id] = $this->generate($notifications);
        }

        return $hashes;
    }

    /**
     * Invalidate hash cache
     */
    public function invalidate_hash_cache($user_id = null)
    {
        if ($user_id) {
            $this->cache->delete(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATIONS_HASH . $user_id);
        }
        else {
            // Invalidate all notification hashes
            $this->cache->delete_by_pattern(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATIONS_HASH);
        }
    }

    /**
     * Get hash statistics
     */
    public function get_hash_stats()
    {
        return [
            'cache_hits' => $this->cache->get_hits(),
            'cache_misses' => $this->cache->get_misses(),
            'hash_generation_time' => $this->get_average_hash_time(),
            'total_hashes_generated' => $this->get_total_hashes_generated()
        ];
    }

    /**
     * Get average hash generation time
     */
    private function get_average_hash_time()
    {
        $times = $this->cache->get('hash_generation_times', []);

        if (empty($times)) {
            return 0;
        }

        return array_sum($times) / count($times);
    }

    /**
     * Get total hashes generated
     */
    private function get_total_hashes_generated()
    {
        return $this->cache->get('total_hashes_generated', 0);
    }

    /**
     * Record hash generation time
     */
    public function record_hash_time($time)
    {
        $times = $this->cache->get('hash_generation_times', []);
        $times[] = $time;

        // Keep only last 100 measurements
        if (count($times) > 100) {
            $times = array_slice($times, -100);
        }

        $this->cache->set('hash_generation_times', $times, YOOAdmin_Cache_Constants::TTL_STATS);

        $total = $this->cache->get('total_hashes_generated', 0);
        $this->cache->set('total_hashes_generated', $total + 1, YOOAdmin_Cache_Constants::TTL_STATS);
    }

    /**
     * Optimize hash cache
     */
    public function optimize_cache()
    {
        // Remove old hash entries
        $this->cache->delete_by_pattern('notifications_hash_', true);

        // Clean up hash generation times
        $this->cache->delete('hash_generation_times');
    }

    /**
     * Benchmark hash performance
     */
    public function benchmark($iterations = 1000)
    {
        $test_data = $this->generate_test_notifications(100);

        $start_time = microtime(true);

        for ($i = 0; $i < $iterations; $i++) {
            $this->generate($test_data);
        }

        $total_time = microtime(true) - $start_time;
        $avg_time = $total_time / $iterations;

        return [
            'iterations' => $iterations,
            'total_time' => $total_time,
            'average_time' => $avg_time,
            'hashes_per_second' => 1 / $avg_time
        ];
    }

    /**
     * Generate test notifications for benchmarking
     */
    private function generate_test_notifications($count)
    {
        $notifications = [];

        for ($i = 0; $i < $count; $i++) {
            $notifications[] = [
                'title' => 'Test Notification ' . $i,
                'message' => 'This is a test notification message number ' . $i,
                'type' => ['info', 'warning', 'success', 'error'][wp_rand(0, 3)],
                'priority' => ['low', 'medium', 'high', 'critical'][wp_rand(0, 3)],
                'source' => 'test',
                'source_type' => 'benchmark'
            ];
        }

        return $notifications;
    }
}

// Initialize hash optimizer
function yooadmin_get_hash_optimizer()
{
    static $hash_optimizer = null;

    if ($hash_optimizer === null) {
        $hash_optimizer = new YOOAdmin_Hash_Optimizer();
    }

    return $hash_optimizer;
}
