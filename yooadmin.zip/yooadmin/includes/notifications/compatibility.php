<?php
/**
 * YOOAdmin - Notifications compatibility layer
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Prevent multiple loading - ABSOLUTE FINAL PREVENTION
if (defined('YOOADMIN_COMPATIBILITY_LOADED')) {
    return;
}
define('YOOADMIN_COMPATIBILITY_LOADED', true);

// Prevent multiple initialization
if (!defined('YOOADMIN_COMPATIBILITY_INITIALIZED')) {
    define('YOOADMIN_COMPATIBILITY_INITIALIZED', true);
}
/**
 * Compatibility functions for legacy notification system
 * These functions provide fallback behavior using the new notification system
 */

if (!function_exists('yooadmin_notifications_collect_core_updates')) {
    /**
     * Collect core updates (compatibility function)
     */
    function yooadmin_notifications_collect_core_updates() {
        try {
            // Use the new collector if available
            if (class_exists('YOOAdmin_Smart_Collector')) {
                $collector = new YOOAdmin_Smart_Collector();
                $user_id = get_current_user_id();
                $core_updates = $collector->collect_wordpress_updates($user_id);
                
                // Format for legacy compatibility
                $formatted = [];
                foreach ($core_updates as $update) {
                    if ($update['source_type'] === 'wordpress_core') {
                        $formatted[] = [
                            'title' => $update['title'],
                            'message' => $update['message'],
                            'version' => $update['meta']['new_version'] ?? '',
                            'current_version' => $update['meta']['current_version'] ?? '',
                            'type' => 'core'
                        ];
                    }
                }
                
                return $formatted;
            }
            
            // Fallback to WordPress core function
            $core_updates = get_core_updates();
            $formatted = [];
            
            foreach ($core_updates as $update) {
                if ($update->response === 'upgrade') {
                    $formatted[] = [
                        'title' => 'WordPress Core Update',
                        'message' => sprintf('Update to version %s', $update->version),
                        'version' => $update->version,
                        'current_version' => get_bloginfo('version'),
                        'type' => 'core'
                    ];
                }
            }
            
            return $formatted;
            
        } catch (Exception $e) {
        // silent
            return [];
        }
    }
}

if (!function_exists('yooadmin_notifications_collect_plugin_updates')) {
    /**
     * Collect plugin updates (compatibility function)
     */
    function yooadmin_notifications_collect_plugin_updates() {
        try {
            // Use the new collector if available
            if (class_exists('YOOAdmin_Smart_Collector')) {
                $collector = new YOOAdmin_Smart_Collector();
                $user_id = get_current_user_id();
                $all_updates = $collector->collect_all($user_id);
                
                // Filter for plugin updates only
                $plugin_updates = array_filter($all_updates, function($update) {
                    return ($update['source_type'] ?? '') === 'plugin' || 
                           ($update['source_type'] ?? '') === 'plugin_update' ||
                           ($update['source_type'] ?? '') === 'plugin_updates';
                });
                
                // Format for legacy compatibility
                $formatted = [];
                foreach ($plugin_updates as $update) {
                    if (($update['source_type'] ?? '') === 'plugin' || 
                        ($update['source_type'] ?? '') === 'plugin_update' ||
                        ($update['source_type'] ?? '') === 'plugin_updates') {
                        $formatted[] = [
                            'title' => $update['title'],
                            'message' => $update['message'],
                            'plugin' => $update['meta']['plugin_name'] ?? '',
                            'version' => $update['meta']['new_version'] ?? '',
                            'current_version' => $update['meta']['current_version'] ?? '',
                            'type' => 'plugin',
                            'priority' => $update['priority'],
                            'url' => $update['url'] ?? ''
                        ];
                    }
                }
                
                return $formatted;
            }
            
            // Fallback to WordPress core function
            if (!function_exists('get_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            
            $all_plugins = get_plugins();
            $update_plugins = get_plugin_updates();
            $formatted = [];
            
            foreach ($update_plugins as $file => $plugin) {
                $plugin_info = $all_plugins[$file] ?? [];
                $formatted[] = [
                    'title' => $plugin_info['Name'] ?? 'Unknown Plugin',
                    'message' => sprintf('Update to version %s', $plugin->new_version),
                    'plugin' => $file,
                    'version' => $plugin->new_version,
                    'current_version' => $plugin_info['Version'] ?? '',
                    'type' => 'plugin'
                ];
            }
            
            return $formatted;
            
        } catch (Exception $e) {
        // silent
            return [];
        }
    }
}

if (!function_exists('yooadmin_notifications_collect_theme_updates')) {
    /**
     * Collect theme updates (compatibility function)
     */
    function yooadmin_notifications_collect_theme_updates() {
        try {
            // Use the new collector if available
            if (class_exists('YOOAdmin_Smart_Collector')) {
                $collector = new YOOAdmin_Smart_Collector();
                $user_id = get_current_user_id();
                $all_updates = $collector->collect_all($user_id);
                
                // Filter for theme updates only
                $theme_updates = array_filter($all_updates, function($update) {
                    return ($update['source_type'] ?? '') === 'theme' || 
                           ($update['source_type'] ?? '') === 'theme_update' ||
                           ($update['source_type'] ?? '') === 'theme_updates';
                });
                
                // Format for legacy compatibility
                $formatted = [];
                foreach ($theme_updates as $update) {
                    if (($update['source_type'] ?? '') === 'theme' || 
                        ($update['source_type'] ?? '') === 'theme_update' ||
                        ($update['source_type'] ?? '') === 'theme_updates') {
                        $formatted[] = [
                            'title' => $update['title'],
                            'message' => $update['message'],
                            'theme' => $update['meta']['theme_name'] ?? '',
                            'version' => $update['meta']['new_version'] ?? '',
                            'current_version' => $update['meta']['current_version'] ?? '',
                            'type' => 'theme',
                            'priority' => $update['priority'],
                            'url' => $update['url'] ?? ''
                        ];
                    }
                }
                
                return $formatted;
            }
            
            // Fallback to WordPress core function
            $theme_updates = get_theme_updates();
            $formatted = [];
            
            foreach ($theme_updates as $theme_slug => $theme) {
                $theme_info = wp_get_theme($theme_slug);
                $formatted[] = [
                    'title' => $theme_info->get('Name'),
                    'message' => sprintf('Update to version %s', $theme->new_version),
                    'theme' => $theme_slug,
                    'version' => $theme->new_version,
                    'current_version' => $theme_info->get('Version'),
                    'type' => 'theme'
                ];
            }
            
            return $formatted;
            
        } catch (Exception $e) {
        // silent
            return [];
        }
    }
}

if (!function_exists('yooadmin_notifications_collect_translation_updates')) {
    /**
     * Collect translation updates (compatibility function)
     */
    function yooadmin_notifications_collect_translation_updates() {
        try {
            // Use the new collector if available
            if (class_exists('YOOAdmin_Smart_Collector')) {
                $collector = new YOOAdmin_Smart_Collector();
                $user_id = get_current_user_id();
                $all_updates = $collector->collect_all($user_id);
                
                // Filter for translation updates only
                $translation_updates = array_filter($all_updates, function($update) {
                    return ($update['source_type'] ?? '') === 'translation' || 
                           ($update['source_type'] ?? '') === 'translation_update' ||
                           ($update['source_type'] ?? '') === 'translation_updates';
                });
                
                // Format for legacy compatibility
                $formatted = [];
                foreach ($translation_updates as $update) {
                    if (($update['source_type'] ?? '') === 'translation' || 
                        ($update['source_type'] ?? '') === 'translation_update' ||
                        ($update['source_type'] ?? '') === 'translation_updates') {
                        $formatted[] = [
                            'title' => $update['title'],
                            'message' => $update['message'],
                            'language' => $update['meta']['language'] ?? '',
                            'type' => 'translation',
                            'priority' => $update['priority'],
                            'url' => $update['url'] ?? ''
                        ];
                    }
                }
                
                return $formatted;
            }
            
            // Fallback to WordPress core function
            $translation_updates = wp_get_translation_updates();
            $formatted = [];
            
            foreach ($translation_updates as $update) {
                $formatted[] = [
                    'title' => 'Translation Update Available',
                    'message' => sprintf('Update for %s (%s)', $update['name'], $update['language']),
                    'language' => $update['language'],
                    'type' => 'translation'
                ];
            }
            
            return $formatted;
            
        } catch (Exception $e) {
        // silent
            return [];
        }
    }
}


if (!function_exists('yooadmin_get_notifications_feed')) {
    /**
     * Get notifications feed (compatibility function)
     */
    function yooadmin_get_notifications_feed($args = []) {
        try {
            // Use the new integration if available
            if (class_exists('YOOAdmin_Integration')) {
                $integration = yooadmin_get_integration();
                $user_id = get_current_user_id();
                $notifications = $integration->get_notifications($user_id, $args);
                
                // Format for legacy compatibility
                $formatted_notifications = [];
                foreach ($notifications as $notification) {
                    $formatted_notifications[] = [
                        'id' => $notification['id'],
                        'title' => $notification['title'],
                        'message' => $notification['message'],
                        'type' => $notification['type'],
                        'priority' => $notification['priority'],
                        'status' => $notification['status'],
                        'source' => $notification['source'],
                        'created_at' => $notification['created_at'],
                        'url' => $notification['url'] ?? '',
                        'meta' => $notification['meta'] ?? []
                    ];
                }
                
                // Calculate counts
                $counts = [
                    'total' => count($formatted_notifications),
                    'unread' => count(array_filter($formatted_notifications, function($n) {
                        return $n['status'] === 'new';
                    })),
                    'critical' => count(array_filter($formatted_notifications, function($n) {
                        return in_array($n['priority'], ['critical', 'high']);
                    })),
                    'badge' => count(array_filter($formatted_notifications, function($n) {
                        return $n['status'] === 'new';
                    }))
                ];
                
                // Generate hash
                $hash = md5(json_encode($formatted_notifications));
                
                return [
                    'notifications' => $formatted_notifications,
                    'counts' => $counts,
                    'hash' => $hash,
                    'generated_at' => current_time('mysql'),
                    'summary_only' => $args['summary_only'] ?? false,
                    'include_items' => $args['include_items'] ?? true
                ];
            }
            
            // Fallback to basic WordPress updates
            $updates = wp_get_update_data();
            $counts = $updates['counts'] ?? [];
            
            return [
                'notifications' => [],
                'counts' => $counts,
                'hash' => md5(json_encode($counts)),
                'generated_at' => current_time('mysql'),
                'summary_only' => $args['summary_only'] ?? false,
                'include_items' => $args['include_items'] ?? true
            ];
            
        } catch (Exception $e) {
        // silent
            return [
                'notifications' => [],
                'counts' => ['total' => 0, 'unread' => 0, 'critical' => 0, 'badge' => 0],
                'hash' => '',
                'generated_at' => current_time('mysql'),
                'summary_only' => $args['summary_only'] ?? false,
                'include_items' => $args['include_items'] ?? true
            ];
        }
    }
}


/**
 * Auto-load compatibility functions - FINAL VERSION
 */
add_action('plugins_loaded', function() {
    // Ensure compatibility functions are loaded early - ONLY ONCE
    if (is_admin() && !defined('YOOADMIN_COMPATIBILITY_AUTO_LOADED')) {
        define('YOOADMIN_COMPATIBILITY_AUTO_LOADED', true);
    }
}, 5);

/**
 * Log when compatibility functions are used
 */
add_action('admin_init', function() {
    if (WP_DEBUG) {
        $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_debug_backtrace -- WP_DEBUG diagnostic only.
        foreach ($backtrace as $trace) {
            if (isset($trace['function']) && strpos($trace['function'], 'yooadmin_notifications_collect_') === 0) {
                // silent
                break;
            }
        }
    }
});
