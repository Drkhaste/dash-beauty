<?php
/**
 * YOOAdmin - Cache system (notifications)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Load cache constants
require_once __DIR__ . '/cache-constants.php';

class YOOAdmin_Cache {
    
    private $cache_group = 'yooadmin_notifications';
    private $hits = 0;
    private $misses = 0;
    
    public function __construct() {
        // Only load cache statistics if Focus Mode is ON
        // (prevents recreating yooadmin_ options after data cleanup)
        if (!function_exists('yooadmin_is_focus_enabled') || yooadmin_is_focus_enabled()) {
            $this->hits = get_option('yooadmin_cache_hits', 0);
            $this->misses = get_option('yooadmin_cache_misses', 0);
        }
    }
    
    /**
     * Get cached value
     */
    public function get($key, $default = null) {
        $cached = wp_cache_get($key, $this->cache_group);
        
        if ($cached === false) {
            $this->misses++;
            $this->update_stats();
            return $default;
        }
        
        $this->hits++;
        $this->update_stats();
        
        return $cached;
    }
    
    /**
     * Set cached value
     */
    public function set($key, $value, $ttl = null) {
        if ($ttl === null) {
            $ttl = YOOAdmin_Cache_Constants::TTL_DEFAULT;
        }
        $result = wp_cache_set($key, $value, $this->cache_group, $ttl);
        
        return $result;
    }
    
    /**
     * Delete cached value
     */
    public function delete($key) {
        $result = wp_cache_delete($key, $this->cache_group);
        
        return $result;
    }
    
    /**
     * Delete cache by pattern
     */
    public function delete_by_pattern($pattern, $exact = false) {
        global $wp_object_cache;
        
        $deleted = 0;
        
        if (is_object($wp_object_cache) && method_exists($wp_object_cache, 'cache')) {
            $cache_data = $wp_object_cache->cache[$this->cache_group] ?? [];
            
            foreach ($cache_data as $key => $value) {
                $should_delete = false;
                
                if ($exact) {
                    $should_delete = $key === $pattern;
                } else {
                    $should_delete = strpos($key, $pattern) !== false;
                }
                
                if ($should_delete) {
                    $this->delete($key);
                    $deleted++;
                }
            }
        }
        
        return $deleted;
    }
    
    /**
     * Clear all cache
     */
    public function clear() {
        $result = yooadmin_cache_flush_group($this->cache_group);
        
        return $result;
    }

    /**
     * Get the current version token for a cache namespace.
     *
     * Pattern-based deletion (delete_by_pattern) can only reach keys that were
     * loaded in the current request, so on a persistent object cache
     * (Redis/Memcached) it cannot invalidate keys written by earlier requests.
     * Versioned namespaces solve this: each cached key embeds a version token,
     * and invalidation just bumps the token (a single exact-key write that works
     * on persistent caches). Stale keys become unreachable and expire on TTL.
     */
    public function get_namespace_version($namespace) {
        $version_key = 'nsver_' . $namespace;
        $version = wp_cache_get($version_key, $this->cache_group);

        if ($version === false || !is_numeric($version)) {
            $version = 1;
            // 0 = no expiry, so the token survives for the namespace's lifetime.
            wp_cache_set($version_key, $version, $this->cache_group, 0);
        }

        return (int) $version;
    }

    /**
     * Bump (invalidate) a cache namespace. Every key built with the previous
     * version becomes unreachable immediately.
     */
    public function bump_namespace_version($namespace) {
        $version_key = 'nsver_' . $namespace;
        $next = $this->get_namespace_version($namespace) + 1;
        wp_cache_set($version_key, $next, $this->cache_group, 0);

        return $next;
    }
    
    /**
     * Get or set (memoization pattern)
     */
    public function remember($key, $callback, $ttl = null) {
        if ($ttl === null) {
            $ttl = YOOAdmin_Cache_Constants::TTL_DEFAULT;
        }
        $value = $this->get($key);
        
        if ($value === null) {
            $value = call_user_func($callback);
            $this->set($key, $value, $ttl);
        }
        
        return $value;
    }
    
    /**
     * Get multiple values
     */
    public function get_multiple($keys) {
        $values = [];
        
        foreach ($keys as $key) {
            $values[$key] = $this->get($key);
        }
        
        return $values;
    }
    
    /**
     * Set multiple values
     */
    public function set_multiple($values, $ttl = null) {
        if ($ttl === null) {
            $ttl = YOOAdmin_Cache_Constants::TTL_DEFAULT;
        }
        $success = true;
        
        foreach ($values as $key => $value) {
            if (!$this->set($key, $value, $ttl)) {
                $success = false;
            }
        }
        
        return $success;
    }
    
    /**
     * Increment numeric value
     */
    public function increment($key, $step = 1, $ttl = null) {
        if ($ttl === null) {
            $ttl = YOOAdmin_Cache_Constants::TTL_DEFAULT;
        }
        $current = $this->get($key, 0);
        $new_value = $current + $step;
        
        return $this->set($key, $new_value, $ttl) ? $new_value : false;
    }
    
    /**
     * Decrement numeric value
     */
    public function decrement($key, $step = 1, $ttl = null) {
        return $this->increment($key, -$step, $ttl);
    }
    
    /**
     * Check if key exists
     */
    public function has($key) {
        return $this->get($key) !== null;
    }
    
    
    /**
     * Get cache engine information
     */
    private function get_cache_engine_info() {
        global $wp_object_cache;
        
        if (is_object($wp_object_cache)) {
            return [
                'type' => get_class($wp_object_cache),
                'persistent' => $wp_object_cache->persistent ?? false,
                'max_ttl' => $wp_object_cache->max_expiration ?? 0
            ];
        }
        
        return [
            'type' => 'default',
            'persistent' => false,
            'max_ttl' => 0
        ];
    }
    
    /**
     * Update cache statistics
     * Optimized: Use memory cache first, update database every 100 requests
     */
    private function update_stats() {
        // Store in memory cache first (fast)
        wp_cache_set('yooadmin_cache_stats', [
            'hits' => $this->hits,
            'misses' => $this->misses,
            'last_update' => time()
        ], YOOAdmin_Cache_Constants::GROUP_STATS, YOOAdmin_Cache_Constants::TTL_STATS);
        
        // Update database only every 100 requests (reduce database writes)
        $total_requests = $this->hits + $this->misses;
        if ($total_requests % 100 === 0) {
            update_option('yooadmin_cache_hits', $this->hits);
            update_option('yooadmin_cache_misses', $this->misses);
        }
    }
    
    /**
     * Get cache statistics (optimized)
     */
    public function get_stats() {
        // Try to get from memory cache first
        $cached_stats = wp_cache_get('yooadmin_cache_stats', YOOAdmin_Cache_Constants::GROUP_STATS);
        
        if ($cached_stats && isset($cached_stats['hits']) && isset($cached_stats['misses'])) {
            $this->hits = $cached_stats['hits'];
            $this->misses = $cached_stats['misses'];
        } else {
            // Fallback to database
            $this->hits = get_option('yooadmin_cache_hits', 0);
            $this->misses = get_option('yooadmin_cache_misses', 0);
        }
        
        $total = $this->hits + $this->misses;
        $hit_rate = $total > 0 ? ($this->hits / $total) * 100 : 0;
        
        return [
            'hits' => $this->hits,
            'misses' => $this->misses,
            'total' => $total,
            'hit_rate' => round($hit_rate, 2),
            'cache_engine' => $this->get_cache_engine_info()
        ];
    }
    
    /**
     * Reset cache statistics
     */
    public function reset_stats() {
        $this->hits = 0;
        $this->misses = 0;
        
        update_option('yooadmin_cache_hits', 0);
        update_option('yooadmin_cache_misses', 0);
    }
    
    /**
     * Warm up cache
     */
    public function warm_up($user_ids = []) {
        $warmed = 0;
        
        if (empty($user_ids)) {
            // Get all users with notifications
            global $wpdb;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Cache warmup query; table name from $wpdb->prefix + hardcoded string.
            $user_ids = $wpdb->get_col("SELECT DISTINCT user_id FROM {$wpdb->prefix}yooadmin_notifications");
        }
        
        foreach ($user_ids as $user_id) {
            // Warm up notifications cache
            $collector = yooadmin_get_collector();
            $notifications = $collector->collect_all($user_id);
            
            // Warm up hash cache
            $hash = yooadmin_get_hash_optimizer();
            $hash->set_cached_hash($user_id, $hash->generate($notifications));
            
            $warmed++;
        }
        
        return $warmed;
    }
    
    /**
     * Cache cleanup
     */
    public function cleanup() {
        $cleaned = 0;
        
        // Clean up expired entries
        $cleaned += $this->delete_by_pattern('expired_');
        
        // Clean up old statistics
        $this->reset_stats();
        
        // Clean up temporary cache
        $cleaned += $this->delete_by_pattern('temp_');
        
        return $cleaned;
    }
    
    /**
     * Get cache size estimation
     */
    public function get_size() {
        global $wp_object_cache;
        
        $size = 0;
        
        if (is_object($wp_object_cache) && method_exists($wp_object_cache, 'cache')) {
            $cache_data = $wp_object_cache->cache[$this->cache_group] ?? [];
            
            foreach ($cache_data as $key => $value) {
                $size += strlen(serialize($value));
            }
        }
        
        return [
            'bytes' => $size,
            'human_readable' => $this->format_bytes($size),
            'entries' => count($cache_data ?? [])
        ];
    }
    
    /**
     * Format bytes to human readable
     */
    private function format_bytes($bytes) {
        $units = ['B', 'KB', 'MB', 'GB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= pow(1024, $pow);
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }
    
    /**
     * Benchmark cache performance
     */
    public function benchmark($iterations = 1000) {
        $test_key = 'benchmark_test';
        $test_value = ['data' => 'test', 'timestamp' => time()];
        
        // Benchmark writes
        $start_time = microtime(true);
        for ($i = 0; $i < $iterations; $i++) {
            $this->set($test_key . '_' . $i, $test_value, YOOAdmin_Cache_Constants::TTL_DEFAULT);
        }
        $write_time = microtime(true) - $start_time;
        
        // Benchmark reads
        $start_time = microtime(true);
        for ($i = 0; $i < $iterations; $i++) {
            $this->get($test_key . '_' . $i);
        }
        $read_time = microtime(true) - $start_time;
        
        // Cleanup
        for ($i = 0; $i < $iterations; $i++) {
            $this->delete($test_key . '_' . $i);
        }
        
        $results = [
            'iterations' => $iterations,
            'write_time' => $write_time,
            'read_time' => $read_time,
            'avg_write_time' => $write_time / $iterations,
            'avg_read_time' => $read_time / $iterations,
            'writes_per_second' => $iterations / $write_time,
            'reads_per_second' => $iterations / $read_time
        ];
        
        return $results;
    }
    
    /**
     * Get cache health status
     */
    public function get_health_status() {
        $stats = $this->get_stats();
        $size = $this->get_size();
        
        $health = [
            'status' => 'good',
            'issues' => []
        ];
        
        // Check hit rate
        if ($stats['hit_rate'] < 50) {
            $health['status'] = 'warning';
            $health['issues'][] = 'Low hit rate: ' . $stats['hit_rate'] . '%';
        }
        
        // Check cache size
        if ($size['bytes'] > 50 * 1024 * 1024) { // 50MB
            $health['status'] = 'warning';
            $health['issues'][] = 'Large cache size: ' . $size['human_readable'];
        }
        
        // Check cache engine
        if (!$stats['cache_engine']['persistent']) {
            $health['status'] = 'warning';
            $health['issues'][] = 'Non-persistent cache engine';
        }
        
        return array_merge($health, [
            'stats' => $stats,
            'size' => $size,
            'recommendations' => $this->get_recommendations($health)
        ]);
    }
    
    /**
     * Get cache recommendations
     */
    private function get_recommendations($health) {
        $recommendations = [];
        
        if ($health['status'] === 'warning') {
            $recommendations[] = 'Consider increasing cache TTL values';
            $recommendations[] = 'Review cache usage patterns';
            $recommendations[] = 'Consider using a persistent cache engine like Redis';
        }
        
        if (in_array('Low hit rate', $health['issues'])) {
            $recommendations[] = 'Optimize cache key patterns';
            $recommendations[] = 'Increase cache warm-up frequency';
        }
        
        if (in_array('Large cache size', $health['issues'])) {
            $recommendations[] = 'Implement cache cleanup more frequently';
            $recommendations[] = 'Review cache TTL values';
        }
        
        return $recommendations;
    }
    
    /**
     * Export cache data
     */
    public function export() {
        global $wp_object_cache;
        
        $data = [];
        
        if (is_object($wp_object_cache) && method_exists($wp_object_cache, 'cache')) {
            $cache_data = $wp_object_cache->cache[$this->cache_group] ?? [];
            
            foreach ($cache_data as $key => $value) {
                $data[$key] = [
                    'value' => $value,
                    'timestamp' => time(),
                    'size' => strlen(serialize($value))
                ];
            }
        }
        
        return [
            'exported_at' => current_time('mysql'),
            'cache_group' => $this->cache_group,
            'entries' => count($data),
            'total_size' => array_sum(array_column($data, 'size')),
            'data' => $data
        ];
    }
    
    /**
     * Import cache data
     */
    public function import($data) {
        $imported = 0;
        
        if (isset($data['data']) && is_array($data['data'])) {
            foreach ($data['data'] as $key => $entry) {
                if (isset($entry['value'])) {
                    $this->set($key, $entry['value'], YOOAdmin_Cache_Constants::TTL_DEFAULT);
                    $imported++;
                }
            }
        }
        
        return $imported;
    }
}

// Initialize cache
function yooadmin_get_cache() {
    static $cache = null;
    
    if ($cache === null) {
        $cache = new YOOAdmin_Cache();
    }
    
    return $cache;
}
