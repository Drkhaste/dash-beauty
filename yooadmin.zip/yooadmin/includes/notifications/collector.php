<?php
/**
 * YOOAdmin - Smart collector (notifications)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Load cache constants
require_once __DIR__ . '/cache-constants.php';

if (!defined('YOOADMIN_WELCOME_NOTICE_VERSION')) {
    define('YOOADMIN_WELCOME_NOTICE_VERSION', 4);
}

if (!function_exists('yooadmin_welcome_notification_is_rtl')) {
    function yooadmin_welcome_notification_is_rtl(): bool
    {
        $locale = function_exists('yooadmin_get_admin_ui_locale')
            ? (string) yooadmin_get_admin_ui_locale()
            : (function_exists('get_user_locale') ? get_user_locale() : get_locale());

        return str_starts_with($locale, 'ar');
    }
}

if (!function_exists('yooadmin_welcome_notification_message_html')) {
    function yooadmin_welcome_notification_message_html(): string
    {
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        return '<p>🎉 ' . esc_html__(
            'Your admin workspace is ready. A cleaner, modern WordPress experience built for you and your clients.',
            'yooadmin'
        ) . '</p>' .
        '<p>✨ ' . esc_html__(
            'Focus mode, smart navigation, and an organized dashboard. Everything you need from day one.',
            'yooadmin'
        ) . '</p>' .
        '<p>🚀 ' . sprintf(
            /* translators: %s: product name (HTML) */
            __('Go further with %s. Download it free from yooadmin.io to unlock extensions, YOOMedia, update center, plugin manager, and more.', 'yooadmin'),
            '<strong>' . esc_html__('YOOAdmin Plus', 'yooadmin') . '</strong>'
        ) . '</p>' .
        '<p>🔗 ' . esc_html__(
            'Connect a free account anytime to activate Plus and keep your workspace in sync.',
            'yooadmin'
        ) . '</p>';
    }
}

if (!function_exists('yooadmin_welcome_notification_title')) {
    function yooadmin_welcome_notification_title(): string
    {
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        return __('Welcome to YOOAdmin 👋', 'yooadmin');
    }
}

if (!function_exists('yooadmin_sync_welcome_notifications_in_storage')) {
    function yooadmin_sync_welcome_notifications_in_storage(): int
    {
        global $wpdb;

        $table = yooadmin_get_notifications_table_name();
        if ($table === '') {
            return 0;
        }

        $title   = yooadmin_welcome_notification_title();
        $message = yooadmin_welcome_notification_message_html();
        $updated = 0;

        $rows = function_exists('yooadmin_get_notification_rows_by_meta_like')
            ? yooadmin_get_notification_rows_by_meta_like('%"id":"yooadmin_welcome"%')
            : [];

        foreach ($rows as $row) {
            $row_id = (int) ($row['id'] ?? 0);
            if ($row_id <= 0) {
                continue;
            }

            if (($row['title'] ?? '') === $title && ($row['message'] ?? '') === $message) {
                continue;
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $result = $wpdb->update(
                $table,
                [
                    'title'      => $title,
                    'message'    => $message,
                    'updated_at' => current_time('mysql'),
                ],
                ['id' => $row_id],
                ['%s', '%s', '%s'],
                ['%d']
            );

            if ($result !== false) {
                $updated++;
            }
        }

        return $updated;
    }
}

if (!function_exists('yooadmin_maybe_sync_welcome_notification_copy')) {
    function yooadmin_maybe_sync_welcome_notification_copy(): void
    {
        $stored_version = (int) get_option('yooadmin_welcome_notice_version', 0);
        if ($stored_version >= YOOADMIN_WELCOME_NOTICE_VERSION) {
            return;
        }

        yooadmin_sync_welcome_notifications_in_storage();

        if (class_exists('YOOAdmin_Cache')) {
            $cache = new YOOAdmin_Cache();
            $cache->delete_by_pattern('notifications_');
            $cache->delete_by_pattern('notification_count_');
            $cache->delete_by_pattern('notifications_hash_');
            $cache->delete_by_pattern('unread_count_');
        }

        update_option('yooadmin_welcome_notice_version', YOOADMIN_WELCOME_NOTICE_VERSION, false);
    }
}

add_action('init', 'yooadmin_maybe_sync_welcome_notification_copy', 20);

if (!function_exists('yooadmin_notification_meta_id')) {
    function yooadmin_notification_meta_id(array $notification): string
    {
        if (isset($notification['meta']) && is_array($notification['meta']) && !empty($notification['meta']['id'])) {
            return sanitize_key((string) $notification['meta']['id']);
        }

        if (isset($notification['meta']) && is_string($notification['meta']) && $notification['meta'] !== '') {
            $decoded = json_decode($notification['meta'], true);
            if (is_array($decoded) && !empty($decoded['id'])) {
                return sanitize_key((string) $decoded['id']);
            }
        }

        return '';
    }
}

if (!function_exists('yooadmin_is_welcome_notification')) {
    function yooadmin_is_welcome_notification(array $notification): bool
    {
        $meta_id = yooadmin_notification_meta_id($notification);

        return in_array($meta_id, ['yooadmin_welcome', 'license_not_activated'], true);
    }
}

if (!function_exists('yooadmin_apply_welcome_notification_copy')) {
    /**
     * @param array<string, mixed> $notification
     * @return array<string, mixed>
     */
    function yooadmin_apply_welcome_notification_copy(array $notification): array
    {
        $notification['title']   = yooadmin_welcome_notification_title();
        $notification['message']   = yooadmin_welcome_notification_message_html();
        $notification['meta']    = is_array($notification['meta'] ?? null) ? $notification['meta'] : [];
        $notification['meta']['id'] = 'yooadmin_welcome';

        // Canonical action buttons (applied to new AND already-stored welcome
        // notifications so the yooadmin.io link always renders as a button).
        $notification['meta']['actions'] = [
            [
                'type'   => 'primary',
                'text'   => __('Connect free account', 'yooadmin'),
                'url'    => admin_url('admin.php?page=yooadmin-license'),
                'target' => '_self',
            ],
            [
                'type'   => 'secondary',
                'text'   => __('Download from yooadmin.io', 'yooadmin'),
                'url'    => 'https://yooadmin.io',
                'target' => '_blank',
            ],
        ];

        if (yooadmin_welcome_notification_is_rtl()) {
            $notification['title_dir'] = 'rtl';
        }

        return $notification;
    }
}

if (!function_exists('yooadmin_rewrite_welcome_notifications')) {
    /**
     * @param array<int, array<string, mixed>> $notifications
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_rewrite_welcome_notifications(array $notifications): array
    {
        foreach ($notifications as $index => $notification) {
            if (!is_array($notification)) {
                continue;
            }

            if (($notification['type'] ?? '') === 'group' && !empty($notification['items']) && is_array($notification['items'])) {
                $notifications[$index]['items'] = yooadmin_rewrite_welcome_notifications($notification['items']);
                continue;
            }

            if (!yooadmin_is_welcome_notification($notification)) {
                continue;
            }

            $notifications[$index] = yooadmin_apply_welcome_notification_copy($notification);
        }

        return $notifications;
    }
}

if (!function_exists('yooadmin_filter_welcome_notification')) {
    /**
     * @param array<int, array<string, mixed>> $notifications
     * @return array<int, array<string, mixed>>
     */
    function yooadmin_filter_welcome_notification(array $notifications, $user_id = 0, $options = []): array
    {
        unset($user_id, $options);

        return yooadmin_rewrite_welcome_notifications($notifications);
    }
}

add_filter('yooadmin_notifications_before_grouping', 'yooadmin_filter_welcome_notification', 12, 3);
add_filter('yooadmin_notifications_filtered', 'yooadmin_filter_welcome_notification', 12, 3);
add_filter('yooadmin_notifications_cached', 'yooadmin_filter_welcome_notification', 12, 3);

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom notification tables; caching handled by notification cache layer.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Table names from $wpdb->prefix + hardcoded strings.
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names from $wpdb->prefix + hardcoded strings; all user input passed through $wpdb->prepare().
class YOOAdmin_Smart_Collector {
    
    private $storage;
    private $hash;
    private $cache;
    
    public function __construct() {
        $this->storage = yooadmin_get_storage();
        
        // Try to get hash optimizer, or use fallback
        if (class_exists('YOOAdmin_Hash_Optimizer')) {
            $this->hash = new YOOAdmin_Hash_Optimizer();
        } else {
            // Create a simple hash fallback
            $this->hash = new class {
                public function generate($data) {
                    return md5(serialize($data));
                }
            };
        }
        
        // Try to get cache, or use fallback
        if (class_exists('YOOAdmin_Cache')) {
            $this->cache = new YOOAdmin_Cache();
        } else {
            // Create a simple cache fallback
            $this->cache = new class {
                private $data = [];
                
                public function get($key) {
                    return isset($this->data[$key]) ? $this->data[$key] : null;
                }
                
                public function set($key, $value, $ttl = null) {
                    if ($ttl === null) {
                        $ttl = YOOAdmin_Cache_Constants::TTL_DEFAULT;
                    }
                    $this->data[$key] = $value;
                }
                
                public function remember($key, $callback, $ttl = null) {
                    if ($ttl === null) {
                        $ttl = YOOAdmin_Cache_Constants::TTL_DEFAULT;
                    }
                    $value = $this->get($key);
                    if ($value === null) {
                        $value = call_user_func($callback);
                        $this->set($key, $value, $ttl);
                    }
                    return $value;
                }
                
                public function clear() {
                    $this->data = [];
                }
            };
        }
    }
    
    /**
     * Collect all notifications from all sources
     */
    public function collect_all($user_id, $force = false) {
        // Don't collect notifications if Focus Mode is OFF (e.g., after data cleanup)
        // This prevents options/transients from being recreated after cleanup
        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return [];
        }

        $start_time = microtime(true);
        
        // Get cached hash to check if we need to update
        $cached_hash = $this->cache->get('notifications_hash_' . $user_id);
        
        // Collect from all sources
        // NOTE: Do NOT include collect_database_notifications() or collect_banner_notifications() here because:
        // 1. Those notifications are already in the database
        // 2. get_notifications() in integration.php fetches them directly from database
        // 3. Including them here causes duplicates when store_collected_notifications() tries to save them again
        $all_notifications = array_merge(
            $this->collect_wordpress_updates($user_id),
            $this->collect_license_status($user_id),
            $this->collect_translation_contribute($user_id),
            $this->collect_comments($user_id)
        );
        
        // Generate new hash
        $new_hash = $this->hash->generate($all_notifications);
        
        // Always store if force is true, or if hash changed
        if ($force || $cached_hash !== $new_hash) {
            // Store new notifications
            $stored_count = $this->store_collected_notifications($user_id, $all_notifications);
            
            // Update cache
            $this->cache->set(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATIONS_HASH . $user_id, $new_hash, YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS_HASH);
            
        }
        
        return $all_notifications;
        
        return $all_notifications;
    }
    
    /**
     * Collect WordPress updates notifications
     * Updated to display each plugin/theme separately (like old system) with accurate information
     */
    public function collect_wordpress_updates($user_id) {
        if (
            !user_can($user_id, 'update_core')
            && !user_can($user_id, 'update_plugins')
            && !user_can($user_id, 'update_themes')
        ) {
            return [];
        }

        $notifications = [];
        
        // Force refresh WordPress update cache to ensure accurate data
        // Check if cache is stale (older than 1 hour)
        $transient_plugins = get_site_transient('update_plugins');
        $transient_themes = get_site_transient('update_themes');
        
        $should_refresh_plugins = false;
        $should_refresh_themes = false;
        
        if (!$transient_plugins || (isset($transient_plugins->last_checked) && (time() - $transient_plugins->last_checked) > YOOAdmin_Cache_Constants::TTL_PLUGINS_CHECK)) {
            $should_refresh_plugins = true;
        }
        
        if (!$transient_themes || (isset($transient_themes->last_checked) && (time() - $transient_themes->last_checked) > YOOAdmin_Cache_Constants::TTL_THEMES_CHECK)) {
            $should_refresh_themes = true;
        }
        
        // Refresh cache if needed
        if ($should_refresh_plugins) {
            wp_update_plugins();
        }
        if ($should_refresh_themes) {
            wp_update_themes();
        }
        
        // Check WordPress core updates
        if (!function_exists('get_core_updates')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }
        
        $core_updates = get_core_updates();
        if (!empty($core_updates) && is_array($core_updates)) {
            $current_version = get_bloginfo('version');
            
            foreach ($core_updates as $update) {
                if (!is_object($update) || empty($update->current)) {
                    continue;
                }
                
                // Only show if there's actually an update available
                if (version_compare($update->current, $current_version, '>')) {
                    $identifier = sanitize_key('core_' . $update->current);
                    if (!$identifier) {
                        $identifier = 'core_' . md5($update->current);
                    }
                    
                    $notifications[] = [
                        'id' => $identifier,
                        'type' => 'update',
                        'title' => sprintf('WordPress Update: %s', $update->current),
                        'message' => sprintf(
                            'WordPress %s is available. You are running version %s. Updating ensures you have the latest security features.',
                            $update->current,
                            $current_version
                        ),
                        'priority' => 'high',
                        'source' => 'wordpress',
                        'source_type' => 'wordpress_update',
                        'url' => admin_url('update-core.php'),
                        'icon' => 'wordpress-alt',
                        'group_id' => 'wp-core-update',
                        'status' => 'new',
                        'created_at' => current_time('mysql'),
                        'meta' => [
                            'id' => $identifier, // CRITICAL: Store id in meta for duplicate detection
                            'fingerprint' => 'ver:' . $update->current,
                            'current_version' => $current_version,
                            'available_version' => $update->current,
                            'download_url' => $update->download ?? '',
                            'php_version' => $update->php_version ?? '',
                            'mysql_version' => $update->mysql_version ?? '',
                            'scope' => 'core',
                            'count' => 1
                        ]
                    ];
                    break; // Only show one core update
                }
            }
        }
        
        // Check plugin updates - Display each plugin separately (like old system)
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        // Force refresh transient if it's stale or missing
        $transient = get_site_transient('update_plugins');
        if (!$transient || (isset($transient->last_checked) && (time() - $transient->last_checked) > YOOAdmin_Cache_Constants::TTL_PLUGINS_CHECK)) {
            wp_update_plugins();
            $transient = get_site_transient('update_plugins');
        }
        
        if ($transient && !empty($transient->response) && is_array($transient->response)) {
            $all_plugins = function_exists('get_plugins') ? get_plugins() : [];
            
            foreach ($transient->response as $file => $plugin_info) {
                $info = is_object($plugin_info) ? (array) $plugin_info : (array) $plugin_info;
                $name = $all_plugins[$file]['Name'] ?? ($info['name'] ?? ($info['slug'] ?? $file));
                $current_version = $all_plugins[$file]['Version'] ?? '';
                $new_version = $info['new_version'] ?? '';
                
                // Skip if no version info
                if (empty($new_version)) {
                    continue;
                }
                
                // Get upgrade notice
                $upgrade_notice_raw = '';
                if (!empty($info['upgrade_notice'])) {
                    $upgrade_notice_raw = wp_strip_all_tags(
                        is_array($info['upgrade_notice']) ? implode(' ', $info['upgrade_notice']) : (string) $info['upgrade_notice']
                    );
                    $upgrade_notice_raw = trim(preg_replace('/\s+/', ' ', $upgrade_notice_raw));
                }
                
                $row_notice_raw = '';
                
                // Use upgrade_notice as primary message, fallback to version info
                $primary_message = $upgrade_notice_raw;
                if (empty($primary_message) && $row_notice_raw) {
                    $primary_message = $row_notice_raw;
                }
                if (empty($primary_message)) {
                    if ($current_version && $new_version) {
                        $primary_message = sprintf('Update from version %s to %s', $current_version, $new_version);
                    } elseif ($new_version) {
                        $primary_message = sprintf('Update to version %s', $new_version);
                    } else {
                        $primary_message = 'A new version is available.';
                    }
                }
                
                // Create unique identifier (like old system)
                $slug_source = $info['slug'] ?? '';
                if (!$slug_source) {
                    $parts = explode('/', $file);
                    $slug_source = reset($parts);
                }
                $slug = sanitize_key(str_replace(['/', '\\', '.php'], '-', (string) $slug_source));
                $version_key = $new_version ? sanitize_key(str_replace('.', '-', (string) $new_version)) : '';
                $identifier = $slug ?: sanitize_key(str_replace(['/', '\\', '.php'], '-', (string) $file));
                if ($version_key) {
                    $identifier = sanitize_key($identifier . '_' . $version_key);
                }
                if (!$identifier) {
                    $identifier = 'plugin_' . md5($file . $new_version);
                }
                
                $notifications[] = [
                    'id' => 'wp-plugin-' . $identifier,
                    'type' => 'update',
                    'title' => sprintf('Plugin Update: %s', $name),
                    'message' => $primary_message,
                    'priority' => 'high',
                    'source' => 'wordpress',
                    'source_type' => 'plugin_updates',
                    'sender' => 'plugin_' . $slug, // Specific sender identifier for blocking
                    'url' => admin_url('plugins.php'),
                    'icon' => 'dashicons-admin-plugins',
                    'group_id' => 'wp-plugin-updates',
                    'status' => 'new',
                    'created_at' => current_time('mysql'),
                    'meta' => [
                        'id' => 'wp-plugin-' . $identifier, // CRITICAL: Store id in meta for duplicate detection
                        'fingerprint' => 'ver:' . $new_version,
                        'scope' => 'plugins',
                        'count' => 1,
                        'item' => [
                            'id' => $identifier,
                            'name' => $name,
                            'file' => $file,
                            'current_version' => $current_version,
                            'new_version' => $new_version,
                            'description' => $all_plugins[$file]['Description'] ?? '',
                            'upgrade_notice' => $upgrade_notice_raw,
                            'row_notice' => $row_notice_raw
                        ],
                        'details' => array_values(array_filter([
                            $current_version && $new_version ? sprintf('Version %s → %s', $current_version, $new_version) : '',
                            $upgrade_notice_raw,
                            $row_notice_raw
                        ]))
                    ]
                ];
            }
        }
        
        // Check theme updates - Display each theme separately (like old system)
        // Force refresh transient if it's stale or missing
        $transient_themes = get_site_transient('update_themes');
        if (!$transient_themes || (isset($transient_themes->last_checked) && (time() - $transient_themes->last_checked) > YOOAdmin_Cache_Constants::TTL_THEMES_CHECK)) {
            wp_update_themes();
            $transient_themes = get_site_transient('update_themes');
        }
        
        if ($transient_themes && !empty($transient_themes->response) && is_array($transient_themes->response)) {
            foreach ($transient_themes->response as $slug => $theme_info) {
                $info = is_object($theme_info) ? (array) $theme_info : (array) $theme_info;
                $theme = wp_get_theme($slug);
                $name = $theme->exists() ? $theme->get('Name') : ($info['theme'] ?? $slug);
                $current_version = $theme->exists() ? $theme->get('Version') : '';
                $new_version = $info['new_version'] ?? '';
                
                // Skip if no version info
                if (empty($new_version)) {
                    continue;
                }
                
                // Create message
                $message = '';
                if ($current_version && $new_version) {
                    $message = sprintf('Update from version %s to %s', $current_version, $new_version);
                } elseif ($new_version) {
                    $message = sprintf('Update to version %s', $new_version);
                } else {
                    $message = 'A new version is available with new features and improvements.';
                }
                
                // Create unique identifier (like old system)
                $version_key = $new_version ? sanitize_key(str_replace('.', '-', (string) $new_version)) : '';
                $identifier = sanitize_key($slug);
                if ($version_key) {
                    $identifier = sanitize_key($identifier . '_' . $version_key);
                }
                if (!$identifier) {
                    $identifier = 'theme_' . md5($slug . $new_version);
                }
                
                $notifications[] = [
                    'id' => 'wp-theme-' . $identifier,
                    'type' => 'update',
                    'title' => sprintf('Theme Update: %s', $name),
                    'message' => $message,
                    'priority' => 'medium',
                    'source' => 'wordpress',
                    'source_type' => 'theme_updates',
                    'sender' => 'theme_' . $slug, // Specific sender identifier for blocking
                    'url' => admin_url('themes.php'),
                    'icon' => 'dashicons-admin-appearance',
                    'group_id' => 'wp-theme-updates',
                    'status' => 'new',
                    'created_at' => current_time('mysql'),
                    'meta' => [
                        'id' => 'wp-theme-' . $identifier, // CRITICAL: Store id in meta for duplicate detection
                        'fingerprint' => 'ver:' . $new_version,
                        'scope' => 'themes',
                        'count' => 1,
                        'item' => [
                            'id' => $identifier,
                            'name' => $name,
                            'slug' => $slug,
                            'current_version' => $current_version,
                            'new_version' => $new_version
                        ],
                        'details' => [$message]
                    ]
                ];
            }
        }
        
        return $notifications;
    }
    
    /**
     * Collect license status notifications
     */
    public function collect_license_status($user_id) {
        $notifications = [];
        $license_status = $this->get_license_status();
        $previous_status = get_option('yooadmin_previous_license_status', null);
        $status_changed_flag = get_option('yooadmin_license_status_changed', false);
        
        if ($status_changed_flag) {
            $previous_status = get_option('yooadmin_previous_license_status', null);
            delete_option('yooadmin_license_status_changed');
        }
        
        if ($license_status === 'inactive' || $license_status === 'not_activated' || $license_status === 'expired') {
            $existing_notif = $this->storage->get_for_user($user_id, [
                'limit' => 100
            ]);
            
            $has_existing = false;
            foreach ($existing_notif as $notif) {
                $meta = is_array($notif['meta'] ?? null) ? $notif['meta'] : (is_string($notif['meta'] ?? null) ? json_decode($notif['meta'], true) : []);
                if (isset($meta['id']) && in_array($meta['id'], ['yooadmin_welcome', 'license_not_activated'], true)) {
                    $has_existing = true;
                    break;
                }
            }
            
            if (!$has_existing) {
                $license_url = admin_url('admin.php?page=yooadmin-license');
                $notifications[] = [
                    'id' => 'yooadmin_welcome',
                    'type' => 'info',
                    'title' => yooadmin_welcome_notification_title(),
                    'message' => yooadmin_welcome_notification_message_html(),
                    'priority' => 'high',
                    'source' => 'YOOAdmin',
                    'source_type' => 'license',
                    'sender' => 'yooadmin_license',
                    'url' => admin_url('admin.php?page=yooadmin-license'),
                    'icon' => 'dashicons-shield-alt',
                    'group_id' => 'yooadmin_welcome',
                    'meta' => [
                        'id' => 'yooadmin_welcome',
                        'fingerprint' => 'status:' . $license_status,
                        'status' => $license_status,
                        'previous_status' => $previous_status,
                        'actions' => [
                            [
                                'type' => 'primary',
                                'text' => __('Connect free account', 'yooadmin'),
                                'url' => admin_url('admin.php?page=yooadmin-license'),
                                'target' => '_self'
                            ]
                        ]
                    ]
                ];
            }
        }
        
        if ($license_status === 'active' && ($previous_status !== 'active' || $status_changed_flag)) {
            $existing_notif = $this->storage->get_for_user($user_id, [
                'limit' => 100
            ]);
            
            $has_existing = false;
            foreach ($existing_notif as $notif) {
                $meta = is_array($notif['meta'] ?? null) ? $notif['meta'] : (is_string($notif['meta'] ?? null) ? json_decode($notif['meta'], true) : []);
                if (isset($meta['id']) && $meta['id'] === 'license_activated') {
                    $has_existing = true;
                    if ($notif['status'] === 'read') {
                        $this->storage->mark_as_new($notif['id'], $user_id);
                        
                    }
                    break;
                }
            }
            
            if (!$has_existing) {
                $current_user = wp_get_current_user();
                $user_name = $current_user->exists() ? $current_user->display_name : 'User';
                
                $notifications[] = [
                    'id' => 'license_activated',
                    'type' => 'success',
                    'title' => __("You're All Set! Welcome to YOOAdmin 🚀", 'yooadmin'),
                    'message' => '<p>' . sprintf(/* translators: %s: user display name */ __('Dear %s,', 'yooadmin'), esc_html($user_name)) . '</p>' .
                        '<p>' . __('Thanks for connecting your account! We built YOOAdmin to be the cleanest, simplest admin panel for you and your clients.', 'yooadmin') . '</p>' .
                        '<p><strong>' . __("Why you'll love it:", 'yooadmin') . '</strong></p>' .
                        '<p>✨ ' . __('Zero clutter: No ads, no forced notifications.', 'yooadmin') . '</p>' .
                        '<p>🚀 ' . __('Performance first: Designed for speed and ease of use.', 'yooadmin') . '</p>' .
                        '<p>🤝 ' . __('Community supported: We rely on users like you.', 'yooadmin') . '</p>' .
                        '<p>📋 ' . __('Banners have been converted to organized notifications — no more banner clutter.', 'yooadmin') . '</p>' .
                        '<p>' . __('For more information, visit our website.', 'yooadmin') . '</p>',
                    'priority' => 'high',
                    'source' => 'YOOAdmin',
                    'source_type' => 'license',
                    'url' => 'https://yooadmin.io/docs',
                    'icon' => 'dashicons-yes-alt',
                    'group_id' => 'license_welcome',
                    'meta' => [
                        'id' => 'license_activated',
                        'fingerprint' => 'status:' . $license_status,
                        'actions' => [
                            [
                                'type' => 'primary',
                                'text' => __('View Documentation', 'yooadmin'),
                                'url' => 'https://yooadmin.io/docs',
                                'target' => '_blank',
                                'class' => 'yp-welcome-docs'
                            ]
                        ],
                        'status' => $license_status,
                        'previous_status' => $previous_status
                    ]
                ];
            }
            
            $this->mark_license_notifications_read_by_group($user_id, 'yooadmin_welcome');
            $this->mark_license_notification_read($user_id, 'yooadmin_welcome');
            $this->mark_license_notification_read($user_id, 'license_not_activated');
        }
        
        if ($license_status === 'deactivated' && ($previous_status === 'active' || $status_changed_flag)) {
            $existing_notif = $this->storage->get_for_user($user_id, [
                'limit' => 100
            ]);
            
            $has_existing = false;
            foreach ($existing_notif as $notif) {
                $meta = is_array($notif['meta'] ?? null) ? $notif['meta'] : (is_string($notif['meta'] ?? null) ? json_decode($notif['meta'], true) : []);
                if (isset($meta['id']) && $meta['id'] === 'license_deactivated') {
                    $has_existing = true;
                    if ($notif['status'] === 'read') {
                        $this->storage->mark_as_new($notif['id'], $user_id);
                        
                    }
                    break;
                }
            }
            
            if (!$has_existing) {
                $notifications[] = [
                    'id' => 'license_deactivated',
                    'type' => 'warning',
                    'title' => __('Account Disconnected', 'yooadmin'),
                    'message' => __('Your YOOAdmin account has been disconnected. Remote services will not receive updates until you reconnect.', 'yooadmin'),
                    'priority' => 'high',
                    'source' => 'YOOAdmin',
                    'source_type' => 'license',
                    'sender' => 'yooadmin_license',
                    'url' => admin_url('admin.php?page=yooadmin-license'),
                    'icon' => 'dashicons-warning',
                    'group_id' => 'license_deactivated',
                    'meta' => [
                        'id' => 'license_deactivated',
                        'fingerprint' => 'status:' . $license_status,
                        'actions' => [
                            [
                                'type' => 'primary',
                                'text' => __('Reconnect Account', 'yooadmin'),
                                'url' => admin_url('admin.php?page=yooadmin-license')
                            ]
                        ],
                        'status' => $license_status,
                        'previous_status' => $previous_status
                    ]
                ];
            }
            
            $this->mark_license_notification_read($user_id, 'license_activated');
        }
        
        if ($license_status !== $previous_status || $status_changed_flag) {
            update_option('yooadmin_previous_license_status', $license_status);
        }

        /**
         * Filter license-status notifications before storage.
         *
         * @param array<int, array<string, mixed>> $notifications
         * @param int $user_id
         */
        return apply_filters('yooadmin_license_status_notifications', $notifications, $user_id);
    }

    /**
     * Invite contributors when the admin UI locale has no YOOAdmin translation pack.
     *
     * Stored in the notification center only (not an admin banner).
     *
     * @param int $user_id User ID.
     * @return array<int, array<string, mixed>>
     */
    public function collect_translation_contribute($user_id) {
        if (!function_exists('yooadmin_should_show_translation_contribute_notification')
            || !yooadmin_should_show_translation_contribute_notification($user_id)) {
            return [];
        }

        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $locale = function_exists('yooadmin_get_admin_ui_locale')
            ? yooadmin_get_admin_ui_locale()
            : (function_exists('get_user_locale') ? get_user_locale($user_id) : get_locale());

        $language_name = function_exists('yooadmin_get_admin_locale_display_name')
            ? yooadmin_get_admin_locale_display_name($locale)
            : $locale;

        $translate_url = function_exists('yooadmin_get_wordpress_translate_project_url')
            ? yooadmin_get_wordpress_translate_project_url($locale)
            : 'https://translate.wordpress.org/projects/wp-plugins/yooadmin/';

        return [
            [
                'id'          => 'yooadmin_translation_contribute',
                'type'        => 'info',
                'title'       => __('Help translate YOOAdmin', 'yooadmin'),
                'message'     => sprintf(
                    /* translators: %s: language name. */
                    __('Your admin language (%s) does not have a YOOAdmin translation yet. You can contribute on WordPress.org and help bring YOOAdmin to more users.', 'yooadmin'),
                    $language_name
                ),
                'priority'    => 'low',
                'source'      => 'YOOAdmin',
                'source_type' => 'translation',
                'sender'      => 'yooadmin_i18n',
                'url'         => $translate_url,
                'icon'        => 'dashicons-translation',
                'group_id'    => 'translation_contribute',
                'meta'        => [
                    'id'     => 'yooadmin_translation_contribute',
                    'fingerprint' => 'locale:' . $locale,
                    'locale' => $locale,
                    'actions' => [
                        [
                            'type'   => 'primary',
                            'text'   => __('Translate on WordPress.org', 'yooadmin'),
                            'url'    => $translate_url,
                            'target' => '_blank',
                        ],
                    ],
                ],
            ],
        ];
    }
    
    /**
     * Mark license notification as read by meta id
     */
    private function mark_license_notification_read($user_id, $notification_id) {
        // Check if tables exist (may not exist during setup wizard)
        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_notifications';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
        if (!$table_exists) {
            return;
        }

        $notifications = $this->storage->get_for_user($user_id, [
            'limit' => 100
        ]);
        
        foreach ($notifications as $notif) {
            // Handle both array and JSON string meta
            $meta = is_array($notif['meta'] ?? null) ? $notif['meta'] : [];
            if (is_string($notif['meta'] ?? null)) {
                $decoded = json_decode($notif['meta'], true);
                if (is_array($decoded)) {
                    $meta = $decoded;
                }
            }
            
            // Check by meta id
            if (isset($meta['id']) && $meta['id'] === $notification_id) {
                $this->storage->mark_as_read($notif['id'], $user_id);
            }
        }
    }
    
    /**
     * Mark all license notifications as read by group_id
     * Uses direct SQL query to include expired notifications
     */
    private function mark_license_notifications_read_by_group($user_id, $group_id) {
        global $wpdb;
        // Table name built from $wpdb->prefix and static string.
        // Safe: 'yooadmin_notifications' is a hardcoded string, not user input.
        $table = $wpdb->prefix . 'yooadmin_notifications';
        
        // Direct SQL query to find all notifications with this group_id (including expired)
        // Check if table exists first (may not exist during setup wizard)
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
        if (!$table_exists) {
            return 0;
        }

        $notifications = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, status FROM {$table} WHERE user_id = %d AND group_id = %s AND status = 'new'",
                $user_id,
                $group_id
            ),
            ARRAY_A
        );
        
        $marked_count = 0;
        foreach ($notifications as $notif) {
            $this->storage->mark_as_read($notif['id'], $user_id);
            $marked_count++;
        }
        
        return $marked_count;
    }
    
    /**
     * Collect comments notifications
     */
    public function collect_comments($user_id) {
        if (!user_can($user_id, 'moderate_comments') && !user_can($user_id, 'edit_posts')) {
            return [];
        }

        $notifications = [];
        
        // Get pending comments awaiting moderation (site-wide).
        $pending_comments = get_comments([
            'status' => 'hold',
            'number' => 10,
        ]);
        
        if (!empty($pending_comments)) {
            $count = count($pending_comments);
            $pending_ids = array_map('intval', wp_list_pluck($pending_comments, 'comment_ID'));

            $notifications[] = [
                'id' => 'wp-comments-pending', // Stable identity (NOT count-based) for dedupe.
                'dedupe_key' => 'wp:comments:pending',
                'type' => 'info',
                'title' => sprintf('%d Pending Comment%s', $count, $count > 1 ? 's' : ''),
                'message' => sprintf(
                    'You have %d comment%s awaiting moderation.',
                    $count,
                    $count > 1 ? 's' : ''
                ),
                'priority' => 'medium',
                'source' => 'wordpress',
                'source_type' => 'comments',
                'sender' => 'wordpress_comments', // Specific sender identifier for blocking
                'url' => admin_url('edit-comments.php?comment_status=moderated'),
                'icon' => 'admin-comments',
                'group_id' => 'pending_comments',
                'meta' => [
                    'id' => 'wp-comments-pending',
                    'count' => $count,
                    // Fingerprint changes only when a genuinely newer comment appears,
                    // so a dismissed item stays hidden until there is something new.
                    'fingerprint' => 'max:' . (empty($pending_ids) ? 0 : max($pending_ids)),
                    'comment_ids' => $pending_ids
                ]
            ];
        }
        
        // Get spam comments (site-wide, moderators only).
        $spam_comments = get_comments([
            'status' => 'spam',
            'number' => 10,
        ]);
        
        if (!empty($spam_comments)) {
            $count = count($spam_comments);
            $spam_ids = array_map('intval', wp_list_pluck($spam_comments, 'comment_ID'));

            $notifications[] = [
                'id' => 'wp-comments-spam', // Stable identity (NOT count-based) for dedupe.
                'dedupe_key' => 'wp:comments:spam',
                'type' => 'warning',
                'title' => sprintf('%d Spam Comment%s', $count, $count > 1 ? 's' : ''),
                'message' => sprintf(
                    'You have %d spam comment%s that need attention.',
                    $count,
                    $count > 1 ? 's' : ''
                ),
                'priority' => 'low',
                'source' => 'wordpress',
                'source_type' => 'spam_comments',
                'sender' => 'wordpress_spam_comments', // Specific sender identifier for blocking
                'url' => admin_url('edit-comments.php?comment_status=spam'),
                'icon' => 'dashicons-filter',
                'group_id' => 'spam_comments',
                'meta' => [
                    'id' => 'wp-comments-spam',
                    'count' => $count,
                    'fingerprint' => 'max:' . (empty($spam_ids) ? 0 : max($spam_ids)),
                    'comment_ids' => $spam_ids
                ]
            ];
        }
        
        return $notifications;
    }
    
    /**
     * Collect database notifications
     */
    public function collect_database_notifications($user_id) {
        // Get notifications from database that haven't been processed
        return $this->storage->get_for_user($user_id, [
            'status' => ['new', 'read'],
            'limit' => 50
        ]);
    }
    
    /**
     * Collect banner notifications from database
     * Banners are saved to database by JavaScript via REST API
     * This function only retrieves them from database (100% accurate)
     */
    public function collect_banner_notifications($user_id) {
        $notifications = [];
        
        // Check if banner conversion is enabled
        // Try both option names for compatibility
        $opts = (array) get_option('yooadmin_panel_options', []);
        if (empty($opts)) {
            $opts = (array) get_option('yooadmin_options', []);
        }
        $convert_banners = isset($opts['convert_banners_to_notifications']) 
            ? !empty($opts['convert_banners_to_notifications']) 
            : false;
        
        // If feature is disabled, return empty array
        if (!$convert_banners) {
            return $notifications;
        }
        
        // Get banner notifications from database (100% accurate)
        // Banners are saved by JavaScript via REST API
        $banner_notifications = $this->storage->get_for_user($user_id, [
            'source_type' => 'banner',
            'status' => ['new', 'read'], // Get both read and unread banners
            'limit' => 50
        ]);
        
        // Convert database records to notification format
        foreach ($banner_notifications as $notification) {
            // Decode meta if it's a JSON string
            $meta = $notification['meta'] ?? [];
            if (is_string($notification['meta'] ?? null)) {
                $meta = json_decode($notification['meta'], true) ?: [];
            }
            
            // Skip if notification is dismissed
            if (isset($notification['status']) && $notification['status'] === 'dismissed') {
                continue;
            }
            
            // Check if banner was converted more than 7 days ago (auto-cleanup)
            if (isset($meta['converted_at'])) {
                $converted_time = strtotime($meta['converted_at']);
                if ($converted_time && (time() - $converted_time) > (7 * 24 * 60 * 60)) {
                    // Banner is older than 7 days, mark as read (but don't delete)
                    if (($notification['status'] ?? 'new') === 'new') {
                        $this->storage->mark_as_read($notification['id'], $user_id);
                    }
                    continue;
                }
            }
            
            // Ensure all required fields are present
            if (empty($notification['title'])) {
                $notification['title'] = $meta['title'] ?? 'Admin Notice';
            }
            if (empty($notification['message'])) {
                $notification['message'] = $meta['message'] ?? 'Please check this notification.';
            }
            if (empty($notification['source_type'])) {
                $notification['source_type'] = 'banner';
            }
            if (empty($notification['status'])) {
                $notification['status'] = 'new';
            }
            
            $notifications[] = $notification;
        }
        
        return $notifications;
    }
    
    /**
     * Get license status
     */
    private function get_license_status() {
        // Use actual License Manager if available
        if (class_exists('YOOAdmin_License_Manager')) {
            $license_manager = YOOAdmin_License_Manager::get_instance();
            $license_data = $license_manager->get_license_data();
            
            if (empty($license_data) || empty($license_data['activation_code'])) {
                return 'not_activated';
            }
            
            // Check if license is active
            if ($license_manager->is_license_active()) {
                return 'active';
            }
            
            // Check status from license data
            $status = $license_data['status'] ?? '';
            
            if (in_array($status, ['suspended', 'revoked'])) {
                return 'deactivated';
            }
            
            if ($status === 'active') {
                return 'active';
            }
            
            // Check if expired
            if (!empty($license_data['expires_at'])) {
                $expires = strtotime($license_data['expires_at']);
                if ($expires < time()) {
                    return 'expired';
                }
            }
            
            // If has activation code but not active, it's deactivated
            if (!empty($license_data['activation_code']) && empty($license_data['jwt_token'])) {
                return 'deactivated';
            }
            
            return 'inactive';
        }
        
        // Fallback to old method
        $license_key = get_option('yooadmin_license_key', '');
        $license_status = get_option('yooadmin_license_status', 'not_activated');
        
        return $license_status ?: 'not_activated';
    }
    
    /**
     * Find admin banners from WordPress admin notices
     * Note: This is a simplified version that works with the JavaScript conversion system
     * The actual banner conversion happens in JavaScript (yp-admin-utilities.js)
     * This function is called to check for banners that were already converted
     */
    private function find_admin_banners() {
        $banners = [];
        
        // Get current screen to determine page context
        $current_screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $page = $current_screen ? $current_screen->id : 'unknown';
        
        // Since banner conversion happens in JavaScript on the frontend,
        // we need a different approach. We'll check for banners stored in a transient
        // that JavaScript can populate, or we'll return empty and let JavaScript handle it
        
        // Check for banners stored in transient (populated by JavaScript via AJAX)
        $stored_banners = get_transient('yooadmin_banner_notifications_' . get_current_user_id());
        if (is_array($stored_banners) && !empty($stored_banners)) {
            return $stored_banners;
        }
        
        // Alternative: Try to capture admin notices using output buffering
        // This only works if we're in the right context (not REST API)
        if (!defined('REST_REQUEST') || !REST_REQUEST) {
            ob_start();
            
            // Trigger admin_notices hook to capture all notices
            do_action('admin_notices'); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WordPress core hook.
            
            $notices_output = ob_get_clean();
            
            // If we got output, parse it for notices
            if (!empty($notices_output)) {
            // Use DOMDocument to parse HTML notices
            if (class_exists('DOMDocument')) {
                libxml_use_internal_errors(true);
                $dom = new DOMDocument();
                @$dom->loadHTML('<?xml encoding="UTF-8">' . $notices_output);
                libxml_clear_errors();
                
                $xpath = new DOMXPath($dom);
                
                // Find all notice elements
                $notice_elements = $xpath->query('//*[contains(@class, "notice") or contains(@class, "update-nag") or contains(@class, "error") or contains(@class, "updated")]');
                
                foreach ($notice_elements as $index => $element) {
                    $banner_id = $element->getAttribute('id') ?: 'banner_' . $page . '_' . $index;
                    $classes = $element->getAttribute('class') ?: '';

                    if (
                        strpos($classes, 'yooadmin-login-turnstile-incomplete-notice') !== false
                        || strpos($classes, 'yooadmin-brand-notice') !== false
                        || strpos($classes, 'yooadmin-wizard-notice') !== false
                        || strpos($classes, 'yp-settings-callout') !== false
                    ) {
                        continue;
                    }

                    // Extract text content
                    $text_content = trim($element->textContent);
                    $html_content = $dom->saveHTML($element);
                    
                    // Determine banner type and priority
                    $banner_type = 'notice';
                    $priority = 'medium';
                    
                    if (strpos($classes, 'error') !== false || strpos($classes, 'notice-error') !== false) {
                        $banner_type = 'error';
                        $priority = 'high';
                    } elseif (strpos($classes, 'updated') !== false || strpos($classes, 'notice-success') !== false) {
                        $banner_type = 'success';
                        $priority = 'low';
                    } elseif (strpos($classes, 'notice-warning') !== false) {
                        $banner_type = 'warning';
                        $priority = 'medium';
                    } elseif (strpos($classes, 'update-nag') !== false) {
                        $banner_type = 'update';
                        $priority = 'high';
                    }
                    
                    // Extract title (improved logic - same as JavaScript)
                    $title = '';
                    $strong_elements = $xpath->query('.//strong', $element);
                    if ($strong_elements->length > 0) {
                        $title = trim($strong_elements->item(0)->textContent);
                    }
                    
                    // If no title from strong, try first paragraph
                    if (empty($title)) {
                        $para_elements = $xpath->query('.//p', $element);
                        if ($para_elements->length > 0) {
                            $title = trim($para_elements->item(0)->textContent);
                        }
                    }
                    
                    // If still no title, use first meaningful line
                    if (empty($title)) {
                        $lines = explode("\n", $text_content);
                        foreach ($lines as $line) {
                            $line = trim($line);
                            if (strlen($line) > 5) {
                                $title = $line;
                                break;
                            }
                        }
                    }
                    
                    // Clean up title
                    $title = preg_replace('/\s+/', ' ', $title);
                    if (strlen($title) > 100) {
                        $title = substr($title, 0, 100) . '...';
                    }
                    if (empty($title) || strlen($title) < 3) {
                        $title = 'Admin Notice';
                    }
                    
                    // Extract message (all text except title)
                    $message = $text_content;
                    if (!empty($title) && strpos($message, $title) === 0) {
                        $message = trim(substr($message, strlen($title)));
                    }
                    if (empty($message)) {
                        $message = $text_content;
                    }
                    if (strlen($message) > 500) {
                        $message = substr($message, 0, 500) . '...';
                    }
                    
                    // Extract URL from links
                    $url = '';
                    $link_elements = $xpath->query('.//a[@href]', $element);
                    if ($link_elements->length > 0) {
                        $url = $link_elements->item(0)->getAttribute('href');
                    }
                    
                    $banners[] = [
                        'id' => $banner_id,
                        'type' => $banner_type,
                        'title' => $title ?: 'Admin Notice',
                        'message' => $message ?: 'Please check this notification.',
                        'html' => $html_content,
                        'page' => $page,
                        'classes' => $classes,
                        'priority' => $priority
                    ];
                }
            } else {
                // Fallback: simple regex parsing if DOMDocument not available
                preg_match_all('/<div[^>]*class=["\'][^"\']*(?:notice|update-nag|error|updated)[^"\']*["\'][^>]*>(.*?)<\/div>/is', $notices_output, $matches);
                
                foreach ($matches[0] as $index => $html) {
                    $banner_id = 'banner_' . $page . '_' . $index;
                    $text = wp_strip_all_tags($html);
                    
                    $banners[] = [
                        'id' => $banner_id,
                        'type' => 'notice',
                        'title' => substr($text, 0, 100),
                        'message' => substr($text, 0, 500),
                        'html' => $html,
                        'page' => $page,
                        'classes' => '',
                        'priority' => 'medium'
                    ];
                }
            }
            }
        }
        
        // Also check for transients that might contain banner data
        // Some plugins store banner data in transients
        global $wpdb;
        $transient_banners = $wpdb->get_results(
            "SELECT option_name, option_value FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_%_admin_notice%' 
             OR option_name LIKE '_transient_%_banner%'
             LIMIT 10",
            ARRAY_A
        );
        
        foreach ($transient_banners as $transient) {
            $value = maybe_unserialize($transient['option_value']);
            if (is_array($value) && isset($value['message'])) {
                $banners[] = [
                    'id' => 'transient_' . $transient['option_name'],
                    'type' => $value['type'] ?? 'notice',
                    'title' => $value['title'] ?? 'Admin Notice',
                    'message' => $value['message'] ?? '',
                    'html' => '',
                    'page' => $page,
                    'classes' => '',
                    'priority' => $value['priority'] ?? 'medium'
                ];
            }
        }
        
        return $banners;
    }
    
    /**
     * Extract banner title
     */
    private function extract_banner_title($banner) {
        return $banner['title'] ?? 'Admin Notification';
    }
    
    /**
     * Extract banner message
     */
    private function extract_banner_message($banner) {
        return $banner['message'] ?? 'Please check this important notification.';
    }
    
    /**
     * Extract banner URL
     */
    private function extract_banner_url($banner) {
        if (isset($banner['url']) && !empty($banner['url'])) {
            return $banner['url'];
        }
        
        // Default to current page or dashboard
        $current_screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($current_screen) {
            return admin_url($current_screen->parent_file ?? 'index.php');
        }
        
        return admin_url('admin.php?page=yooadmin-dashboard');
    }
    
    /**
     * Extract banner priority
     */
    private function extract_banner_priority($banner) {
        if (isset($banner['priority']) && in_array($banner['priority'], ['low', 'medium', 'high', 'critical'])) {
            return $banner['priority'];
        }
        
        // Determine priority from banner type
        $type = $banner['type'] ?? 'notice';
        switch ($type) {
            case 'error':
                return 'high';
            case 'update':
                return 'high';
            case 'warning':
                return 'medium';
            case 'success':
                return 'low';
            default:
                return 'medium';
        }
    }
    
    /**
     * Extract banner icon
     */
    private function extract_banner_icon($banner) {
        $type = $banner['type'] ?? 'notice';
        switch ($type) {
            case 'error':
                return 'dashicons-warning';
            case 'update':
                return 'dashicons-update';
            case 'warning':
                return 'dashicons-flag';
            case 'success':
                return 'dashicons-yes-alt';
            default:
                return 'dashicons-megaphone';
        }
    }
    
    /**
     * Store collected notifications
     */
    private function store_collected_notifications($user_id, $notifications) {
        $stored_count = 0;
        $updated_count = 0;
        $skipped_count = 0;
        
        foreach ($notifications as $notification) {
            // Ensure source_type is set
            if (!isset($notification['source_type'])) {
                $notification['source_type'] = $notification['source'] ?? 'system';
            }
            
            // Ensure group_id is set (use source_type as fallback)
            if (!isset($notification['group_id'])) {
                $notification['group_id'] = $notification['source_type'] ?? 'system';
            }
            
            // Ensure meta is an array
            if (!isset($notification['meta']) || !is_array($notification['meta'])) {
                $notification['meta'] = [];
            }
            
            // Store custom 'id' in meta for accurate searching
            if (!empty($notification['id'])) {
                $notification['meta']['id'] = $notification['id'];
            }
            
            // CRITICAL: Ensure 'id' is in meta for accurate duplicate detection
            $meta_for_storage = $notification['meta'] ?? [];
            if (!empty($notification['id']) && !isset($meta_for_storage['id'])) {
                $meta_for_storage['id'] = $notification['id'];
            }
            
            // Encode meta for storage
            $meta_encoded = json_encode($meta_for_storage);
            
            // Check if similar notification already exists
            $existing = $this->find_similar_notification($user_id, $notification);
            
            if ($existing) {
                // Check if notification was archived/invalid (item was removed and reinstalled)
                $existing_status = $existing['status'] ?? '';
                $existing_meta = is_array($existing['meta'] ?? null) ? $existing['meta'] : [];
                if (!is_array($existing_meta) && is_string($existing_meta)) {
                    $existing_meta = json_decode($existing_meta, true) ?: [];
                }
                $was_archived = $existing_status === 'archived';
                $was_invalid = isset($existing_meta['invalid']) && $existing_meta['invalid'] === true;
                $user_archived = isset($existing_meta['user_archived']) && $existing_meta['user_archived'] === true;
                
                // Merge new meta with existing meta to preserve user flags
                $new_meta = $meta_for_storage;
                
                // Preserve important flags from existing meta
                if (isset($existing_meta['user_archived']) && $existing_meta['user_archived'] === true) {
                    $new_meta['user_archived'] = true;
                    if (isset($existing_meta['archived_at'])) {
                        $new_meta['archived_at'] = $existing_meta['archived_at'];
                    }
                }
                if (isset($existing_meta['invalid'])) {
                    $new_meta['invalid'] = $existing_meta['invalid'];
                }
                if (isset($existing_meta['previous_status'])) {
                    $new_meta['previous_status'] = $existing_meta['previous_status'];
                }
                
                $merged_meta_encoded = json_encode($new_meta);
                
                // Update existing notification - PRESERVE status and other important fields
                $update_data = [
                    'title' => $notification['title'],
                    'message' => $notification['message'],
                    'meta' => $merged_meta_encoded,
                    'updated_at' => current_time('mysql')
                ];
                
                // If notification was archived/invalid, restore it (item was reinstalled)
                // BUT: don't restore if it was manually archived by user
                if (($was_archived || $was_invalid) && !$user_archived) {
                    // Remove invalid flags from meta
                    $restored_meta = $notification['meta'];
                    unset($restored_meta['invalid']);
                    unset($restored_meta['item_removed']);
                    unset($restored_meta['invalid_since']);
                    unset($restored_meta['archive_after']);
                    // Keep previous_status for reference, but don't restore it (use current status logic)
                    $update_data['meta'] = json_encode($restored_meta);
                    
                    // Restore status: if it was read before archiving, keep it read; otherwise set to 'new'
                    $previous_status = $existing_meta['previous_status'] ?? null;
                    $restore_to_new = false;
                    if ($previous_status && in_array($previous_status, ['new', 'read'])) {
                        $update_data['status'] = $previous_status;
                        // If restoring to 'new', use mark_as_new to move to top
                        if ($previous_status === 'new') {
                            $restore_to_new = true;
                        }
                    } else {
                        // If no previous status saved, default to 'new' (unread) since item was reinstalled
                        $update_data['status'] = 'new';
                        $restore_to_new = true;
                    }
                    
                    
                    
                    // If restoring to 'new', use mark_as_new to update created_at and move to top
                    if ($restore_to_new) {
                        // First update other fields (meta, priority, url) if needed
                        $other_updates = [];
                        if (isset($update_data['meta'])) {
                            $other_updates['meta'] = $update_data['meta'];
                        }
                        if (isset($notification['priority']) && $notification['priority'] !== ($existing['priority'] ?? '')) {
                            $other_updates['priority'] = $notification['priority'];
                        }
                        if (isset($notification['url']) && $notification['url'] !== ($existing['url'] ?? '')) {
                            $other_updates['url'] = $notification['url'];
                        }
                        
                        // Update other fields first if needed
                        if (!empty($other_updates)) {
                            $this->storage->update($existing['id'], $other_updates);
                        }
                        
                        // Then use mark_as_new to update status, created_at, and updated_at
                        $this->storage->mark_as_new($existing['id'], $user_id);
                        $updated_count++;
                        
                    } else {
                        // If restoring to 'read', just update normally
                        // Only update priority if it's explicitly provided and different
                        if (isset($notification['priority']) && $notification['priority'] !== ($existing['priority'] ?? '')) {
                            $update_data['priority'] = $notification['priority'];
                        }
                        
                        // Only update URL if it's explicitly provided and different
                        if (isset($notification['url']) && $notification['url'] !== ($existing['url'] ?? '')) {
                            $update_data['url'] = $notification['url'];
                        }
                        
                        $this->storage->update($existing['id'], $update_data);
                        $updated_count++;
                        
                    }
                } else {
                    // Not restoring - normal update
                    // Only update priority if it's explicitly provided and different
                    if (isset($notification['priority']) && $notification['priority'] !== ($existing['priority'] ?? '')) {
                        $update_data['priority'] = $notification['priority'];
                    }
                    
                    // Only update URL if it's explicitly provided and different
                    if (isset($notification['url']) && $notification['url'] !== ($existing['url'] ?? '')) {
                        $update_data['url'] = $notification['url'];
                    }
                    
                    // DO NOT update status if not restoring (preserve existing status read/unread)
                    // DO NOT update created_at - preserve original creation time
                    
                    $this->storage->update($existing['id'], $update_data);
                    $updated_count++;
                    
                }
            } else {
                // Create new notification with default status 'new'
                // Remove 'id' from main data (it's stored in meta)
                $notification_data = $notification;
                unset($notification_data['id']); // Remove custom id, it's in meta
                
                $new_notification = array_merge($notification_data, [
                    'user_id' => $user_id,
                    'status' => $notification['status'] ?? 'new',
                    'created_at' => $notification['created_at'] ?? current_time('mysql'),
                    'meta' => $meta_encoded
                ]);
                
                $this->storage->create($new_notification);
                $stored_count++;
            }
        }
        
        return $stored_count + $updated_count;
    }
    
    /**
     * Find similar notification
     * Improved to match more accurately using id, group_id, and source_type
     */
    private function find_similar_notification($user_id, $notification) {
        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_notifications';
        
        // Check if table exists (may not exist during setup wizard)
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
        if (!$table_exists) {
            return null;
        }
        
        // First, try to find by explicit 'id' in meta if provided (most accurate)
        // Include archived/invalid notifications to restore them when item is reinstalled
        if (!empty($notification['id'])) {
            // Use JSON_EXTRACT for precise matching (MySQL 5.7+)
            // Fallback to JSON_UNQUOTE if available, otherwise use LIKE as last resort
            $mysql_version = $wpdb->db_version();
            $use_json_extract = version_compare($mysql_version, '5.7.0', '>=');
            
            if ($use_json_extract) {
                // Use JSON_EXTRACT for accurate JSON field matching
                $result = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT * FROM {$table} WHERE user_id = %d AND JSON_UNQUOTE(JSON_EXTRACT(meta, '$.id')) = %s AND status != 'archived' LIMIT 1",
                        $user_id,
                        $notification['id']
                    ),
                    ARRAY_A
                );
            } else {
                // Fallback for older MySQL versions - use LIKE but verify in PHP
                $result = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT * FROM {$table} WHERE user_id = %d AND meta LIKE %s AND status != 'archived' LIMIT 1",
                        $user_id,
                        '%"id":"' . $wpdb->esc_like($notification['id']) . '"%'
                    ),
                    ARRAY_A
                );
            }
            
            if ($result) {
                // Always verify the id matches exactly (even with JSON_EXTRACT)
                $meta = json_decode($result['meta'] ?? '{}', true);
                if (isset($meta['id']) && $meta['id'] === $notification['id']) {
                    $result['meta'] = $meta;
                    
                    return $result;
                } else {
                    
                }
            } else {
                // If not found by id, also check archived ones (to restore if needed)
                if ($use_json_extract) {
                    $result_archived = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT * FROM {$table} WHERE user_id = %d AND JSON_UNQUOTE(JSON_EXTRACT(meta, '$.id')) = %s AND status = 'archived' LIMIT 1",
                            $user_id,
                            $notification['id']
                        ),
                        ARRAY_A
                    );
                } else {
                    $result_archived = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT * FROM {$table} WHERE user_id = %d AND meta LIKE %s AND status = 'archived' LIMIT 1",
                            $user_id,
                            '%"id":"' . $wpdb->esc_like($notification['id']) . '"%'
                        ),
                        ARRAY_A
                    );
                }
                if ($result_archived) {
                    $meta = json_decode($result_archived['meta'] ?? '{}', true);
                    if (isset($meta['id']) && $meta['id'] === $notification['id']) {
                        $result_archived['meta'] = $meta;
                        
                        return $result_archived;
                    }
                }
            }
        }
        
        // Second, try to find by group_id + source_type (for grouped notifications)
        // IMPORTANT: Always verify meta.id matches to prevent false matches
        if (!empty($notification['group_id']) && !empty($notification['source_type'])) {
            // For plugin/theme updates, also check meta.item.file or meta.item.slug
            if (in_array($notification['source_type'], ['plugin_updates', 'theme_updates'])) {
                // Get all notifications with same source_type and group_id
                $all_similar = $this->storage->get_for_user($user_id, [
                    'source_type' => $notification['source_type'],
                    'group_id' => $notification['group_id'],
                    'limit' => 100 // Get all to check meta
                ]);
                
                // Check meta.item.file for plugins or meta.item.slug for themes
                $item_identifier = null;
                if ($notification['source_type'] === 'plugin_updates' && isset($notification['meta']['item']['file'])) {
                    $item_identifier = $notification['meta']['item']['file'];
                } elseif ($notification['source_type'] === 'theme_updates' && isset($notification['meta']['item']['slug'])) {
                    $item_identifier = $notification['meta']['item']['slug'];
                }
                
                if ($item_identifier) {
                    foreach ($all_similar as $similar) {
                        $similar_meta = is_array($similar['meta']) ? $similar['meta'] : (is_string($similar['meta']) ? json_decode($similar['meta'], true) : []);
                        if (isset($similar_meta['item'])) {
                            if (($notification['source_type'] === 'plugin_updates' && isset($similar_meta['item']['file']) && $similar_meta['item']['file'] === $item_identifier) ||
                                ($notification['source_type'] === 'theme_updates' && isset($similar_meta['item']['slug']) && $similar_meta['item']['slug'] === $item_identifier)) {
                                // Verify meta.id matches if provided
                                if (!empty($notification['id']) && isset($similar_meta['id']) && $similar_meta['id'] !== $notification['id']) {
                                    
                                    continue; // Skip this match, continue searching
                                }
                                
                                return $similar;
                            }
                        }
                    }
                }
                } else {
                    // For other types (like wordpress_update), use group_id + source_type but verify meta.id matches
                    $all_by_group = $this->storage->get_for_user($user_id, [
                        'source_type' => $notification['source_type'],
                        'group_id' => $notification['group_id'],
                        'limit' => 100 // Get all to check meta.id
                    ]);
                    
                    // If notification has an id, verify it matches
                    if (!empty($notification['id'])) {
                        foreach ($all_by_group as $candidate) {
                            $candidate_meta = is_array($candidate['meta']) ? $candidate['meta'] : (is_string($candidate['meta']) ? json_decode($candidate['meta'], true) : []);
                            if (isset($candidate_meta['id']) && $candidate_meta['id'] === $notification['id']) {
                                return $candidate;
                            }
                        }
                        // No match found with matching id - this is a potential duplicate issue
                    } else {
                    // No id provided, return first match (less accurate but acceptable)
                    if (!empty($all_by_group)) {
                        return $all_by_group[0];
                    }
                }
            }
        }
        
        // Final fallback: For wordpress_update specifically, check by source_type + available_version in meta
        // This handles edge cases where id might not match exactly
        if (!empty($notification['source_type']) && $notification['source_type'] === 'wordpress_update' && !empty($notification['meta']['available_version'])) {
            $all_wordpress_updates = $this->storage->get_for_user($user_id, [
                'source_type' => 'wordpress_update',
                'limit' => 10
            ]);
            
            foreach ($all_wordpress_updates as $candidate) {
                $candidate_meta = is_array($candidate['meta']) ? $candidate['meta'] : (is_string($candidate['meta']) ? json_decode($candidate['meta'], true) : []);
                if (isset($candidate_meta['available_version']) && $candidate_meta['available_version'] === $notification['meta']['available_version']) {
                    // Found by version - this is the same WordPress update
                    
                    return $candidate;
                }
            }
        }
        
        return null;
    }
}

// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter

// Initialize collector
function yooadmin_get_collector() {
    static $collector = null;
    
    if ($collector === null) {
        $collector = new YOOAdmin_Smart_Collector();
    }
    
    return $collector;
}
