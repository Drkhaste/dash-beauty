<?php
/**
 * YOOAdmin - Notifications storage layer
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom notification tables; caching handled by notification cache layer.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.SchemaChange -- Table creation and migration required for notification system.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Table names from $wpdb->prefix + hardcoded strings; dynamic WHERE clauses built from whitelisted placeholders.
// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- Dynamic placeholder count matches dynamic params array via array_fill().
// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Dynamic WHERE clause placeholders built programmatically.
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names from $wpdb->prefix + hardcoded strings; all user input passed through $wpdb->prepare().
class YOOAdmin_Database_Storage
{
    /**
     * Bumping this triggers a one-time clean slate of the notification tables
     * so the dedupe_key + UNIQUE(user_id, dedupe_key) schema is established cleanly.
     */
    const SCHEMA_VERSION = '2.0';
    const SCHEMA_VERSION_OPTION = 'yooadmin_notifications_schema_version';

    private $wpdb;
    private $notifications_table;
    private $dismissed_table;

    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->notifications_table = $wpdb->prefix . 'yooadmin_notifications';
        $this->dismissed_table = $wpdb->prefix . 'yooadmin_dismissed_notifications';

        if (function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled()) {
            $this->create_tables();
        }
    }

    /**
     * Ensure notification tables exist when Focus Mode is on (e.g. after data cleanup).
     */
    public function ensure_notifications_tables(): bool {
        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_notifications';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string.
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'")) {
            return true;
        }

        $this->create_tables();

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return (bool) $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
    }

    /**
     * Get notification count
     */
    public function get_notification_count($user_id, $status = 'new')
    {
        global $wpdb;

        // Table name built from $wpdb->prefix and static string.
        // Safe: 'yooadmin_notifications' is a hardcoded string, not user input.
        $table = $wpdb->prefix . 'yooadmin_notifications';

        // Check if table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");

        if (!$table_exists) {
            return 0;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        // Direct query required for notification system. Table name is safe (hardcoded prefix + static string).
        return (int)$wpdb->get_var(
            $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND status = %s",
            $user_id,
            $status
        )
        );
    }

    /**
     * Store notification
     */
    public function store_notification($data)
    {
        global $wpdb;

        $table = $wpdb->prefix . 'yooadmin_notifications';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");

        if (!$table_exists) {
            if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
                return false;
            }
            $this->create_tables();
        }

        // Ensure all required fields are set
        if (!isset($data['source_type'])) {
            $data['source_type'] = $data['source'] ?? 'system';
        }

        if (!isset($data['icon'])) {
            $data['icon'] = '';
        }

        if (!isset($data['group_id'])) {
            $data['group_id'] = '';
        }

        // Encode meta if it's an array (but not if it's already a JSON string)
        $meta_array = null;
        if (isset($data['meta'])) {
            if (is_array($data['meta'])) {
                $meta_array = $data['meta'];
                $data['meta'] = json_encode($data['meta']);
            }
            elseif (is_string($data['meta']) && !empty($data['meta'])) {
                // Already a JSON string, keep it as is
                // Just verify it's valid JSON
                $decoded = json_decode($data['meta'], true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    // Invalid JSON, encode as empty array
                    $data['meta'] = json_encode([]);
                    $meta_array = [];
                }
                else {
                    $meta_array = $decoded;
                }
            }
            else {
                $data['meta'] = json_encode([]);
                $meta_array = [];
            }
        }
        else {
            $data['meta'] = json_encode([]);
            $meta_array = [];
        }

        // Preserve status if provided, otherwise default to 'new'
        if (!isset($data['status'])) {
            $data['status'] = 'new';
        }

        // Preserve created_at if provided, otherwise use current time
        if (!isset($data['created_at'])) {
            $data['created_at'] = current_time('mysql');
        }

        // Resolve a stable identity for this notification so duplicates collapse
        // onto a single row via UNIQUE(user_id, dedupe_key).
        $data['dedupe_key'] = $this->resolve_dedupe_key($data, $meta_array);

        // Preferred path: atomic UPSERT keyed on (user_id, dedupe_key).
        if ($this->dedupe_active() && $data['dedupe_key'] !== '' && !empty($data['user_id'])) {
            return $this->upsert_by_dedupe_key($data);
        }

        // Legacy fallback (schema not yet migrated): match by meta.id then insert.
        if (!empty($meta_array['id']) && !empty($data['user_id'])) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $existing = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM {$table} WHERE user_id = %d AND JSON_UNQUOTE(JSON_EXTRACT(meta, '$.id')) = %s LIMIT 1",
                $data['user_id'],
                $meta_array['id']
            ), ARRAY_A);

            if ($existing) {
                $existing_row_id = (int) $existing['id'];
                $update = ['updated_at' => current_time('mysql'), 'meta' => $meta_array];
                foreach (['title', 'message', 'type', 'priority', 'url', 'icon', 'source', 'source_type', 'group_id'] as $field) {
                    if (array_key_exists($field, $data)) {
                        $update[$field] = $data[$field];
                    }
                }
                if ($this->update($existing_row_id, $update)) {
                    return $existing_row_id;
                }
                return false;
            }
        }

        // Don't try to write the dedupe_key column when the schema has not been migrated.
        unset($data['dedupe_key']);

        $result = $wpdb->insert($table, $data);

        if ($result) {
            $insert_id = $wpdb->insert_id;
            do_action('yooadmin_notification_created', $insert_id, $data, $data['user_id'] ?? null);
            return $insert_id;
        }

        return false;
    }

    /**
     * Whether the dedupe_key + UNIQUE schema is active (clean slate completed).
     */
    private function dedupe_active(): bool
    {
        static $active = null;
        if ($active === null) {
            $active = version_compare(
                (string) get_option(self::SCHEMA_VERSION_OPTION, '0'),
                self::SCHEMA_VERSION,
                '>='
            );
        }
        return $active;
    }

    /**
     * Derive a stable identity key for a notification.
     *
     * Order: explicit dedupe_key → logical meta.id → deterministic hash of
     * (source_type|group_id|title) so every row still gets a non-empty key.
     *
     * @param array<string,mixed> $data
     * @param array<string,mixed>|null $meta_array
     */
    private function resolve_dedupe_key(array $data, $meta_array): string
    {
        $key = '';
        if (!empty($data['dedupe_key'])) {
            $key = (string) $data['dedupe_key'];
        } elseif (is_array($meta_array) && !empty($meta_array['id'])) {
            $key = (string) $meta_array['id'];
        } else {
            $basis = ($data['source_type'] ?? 'system')
                . '|' . ($data['group_id'] ?? '')
                . '|' . ($data['title'] ?? '');
            $key = 'auto:' . md5($basis);
        }

        // Keep within the indexed column width.
        if (strlen($key) > 150) {
            $key = 'h:' . md5($key);
        }

        return $key;
    }

    /**
     * Insert-or-update a notification by its (user_id, dedupe_key) identity.
     *
     * On conflict the existing row's content is refreshed but its status and
     * created_at are preserved (re-collecting a live condition must not silently
     * mark a read item unread or reorder it).
     *
     * @param array<string,mixed> $data Fully prepared row (meta already JSON-encoded).
     * @return int|false Row id on success, false on failure.
     */
    private function upsert_by_dedupe_key($data)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_notifications';

        $now = current_time('mysql');

        $row = [
            'user_id'     => (int) $data['user_id'],
            'dedupe_key'  => (string) $data['dedupe_key'],
            'title'       => (string) ($data['title'] ?? ''),
            'message'     => (string) ($data['message'] ?? ''),
            'type'        => (string) ($data['type'] ?? 'info'),
            'priority'    => (string) ($data['priority'] ?? 'medium'),
            'status'      => (string) ($data['status'] ?? 'new'),
            'source'      => (string) ($data['source'] ?? 'system'),
            'source_type' => (string) ($data['source_type'] ?? 'system'),
            'sender'      => (string) ($data['sender'] ?? ''),
            'url'         => (string) ($data['url'] ?? ''),
            'icon'        => (string) ($data['icon'] ?? ''),
            'group_id'    => (string) ($data['group_id'] ?? ''),
            'meta'        => is_string($data['meta'] ?? null) ? $data['meta'] : json_encode($data['meta'] ?? []),
            'created_at'  => (string) ($data['created_at'] ?? $now),
            'updated_at'  => $now,
        ];

        $columns = array_keys($row);
        $placeholders = [];
        $values = [];
        foreach ($columns as $col) {
            $placeholders[] = ($col === 'user_id') ? '%d' : '%s';
            $values[] = $row[$col];
        }

        $expires_sql = '';
        if (!empty($data['expires_at'])) {
            $columns[] = 'expires_at';
            $placeholders[] = '%s';
            $values[] = (string) $data['expires_at'];
        }

        // On conflict refresh content but NOT status / created_at.
        $update_cols = ['title', 'message', 'type', 'priority', 'source', 'source_type', 'sender', 'url', 'icon', 'group_id', 'meta', 'updated_at'];
        $update_sql = [];
        foreach ($update_cols as $col) {
            $update_sql[] = "{$col} = VALUES({$col})";
        }

        $sql = "INSERT INTO {$table} (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ") "
            . "ON DUPLICATE KEY UPDATE " . implode(', ', $update_sql);

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Column/placeholder lists are code-controlled; all values bound via prepare().
        $result = $wpdb->query($wpdb->prepare($sql, $values));

        if ($result === false) {
            return false;
        }

        $was_insert = ((int) $result === 1);

        // Resolve the row id for the returned value / hooks.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $row_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE user_id = %d AND dedupe_key = %s LIMIT 1",
            $row['user_id'],
            $row['dedupe_key']
        ));

        if ($row_id <= 0) {
            return false;
        }

        if ($was_insert) {
            do_action('yooadmin_notification_created', $row_id, $data, $row['user_id']);
        }

        return $row_id;
    }

    /**
     * Create tables
     */
    public function create_tables()
    {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $notifications_table = $wpdb->prefix . 'yooadmin_notifications';
        $dismissed_table     = $wpdb->prefix . 'yooadmin_dismissed_notifications';

        // One-time clean slate for the dedupe_key + UNIQUE schema.
        //
        // The notification tables are a rebuildable projection of live WordPress state
        // (pending comments, available updates, license status). Wiping them lets the
        // collector re-derive everything cleanly, so we avoid a risky in-place backfill /
        // de-duplication migration before adding the UNIQUE(user_id, dedupe_key) index.
        $schema_version = (string) get_option(self::SCHEMA_VERSION_OPTION, '0');
        if (version_compare($schema_version, self::SCHEMA_VERSION, '<')) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names from $wpdb->prefix + hardcoded strings.
            $wpdb->query("DROP TABLE IF EXISTS {$notifications_table}");
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names from $wpdb->prefix + hardcoded strings.
            $wpdb->query("DROP TABLE IF EXISTS {$dismissed_table}");
        }

        // Notifications table
        $sql1 = "CREATE TABLE IF NOT EXISTS {$notifications_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            dedupe_key varchar(150) NOT NULL DEFAULT '',
            title varchar(255) NOT NULL,
            message text NOT NULL,
            type varchar(50) DEFAULT 'info',
            priority varchar(20) DEFAULT 'medium',
            status varchar(20) DEFAULT 'new',
            source varchar(50) DEFAULT 'system',
            source_type varchar(50) DEFAULT 'system',
            sender varchar(100) DEFAULT '',
            url varchar(255) DEFAULT '',
            icon varchar(50) DEFAULT '',
            group_id varchar(50) DEFAULT '',
            meta longtext DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            expires_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_dedupe (user_id, dedupe_key),
            KEY user_id (user_id),
            KEY status (status),
            KEY type (type),
            KEY priority (priority),
            KEY source (source),
            KEY source_type (source_type),
            KEY sender (sender),
            KEY created_at (created_at),
            KEY updated_at (updated_at),
            KEY expires_at (expires_at),
            KEY user_source_type (user_id, source_type)
        ) $charset_collate;";

        // User preferences table
        $preferences_table = $wpdb->prefix . 'yooadmin_user_preferences';
        $sql2 = "CREATE TABLE IF NOT EXISTS {$preferences_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            preference_key varchar(100) NOT NULL,
            preference_value longtext DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_preference (user_id, preference_key),
            KEY user_id (user_id),
            KEY preference_key (preference_key)
        ) $charset_collate;";

        // Dismissed notifications table
        // dedupe_key + fingerprint enable identity-stable, condition-aware dismissals
        // (a dismissed item only reappears when its underlying condition materially changes).
        $sql3 = "CREATE TABLE IF NOT EXISTS {$dismissed_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            notification_id bigint(20) DEFAULT NULL,
            dedupe_key varchar(150) DEFAULT NULL,
            fingerprint varchar(191) DEFAULT NULL,
            group_id varchar(50) DEFAULT NULL,
            dismissal_type varchar(20) DEFAULT 'permanent',
            snooze_until datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY notification_id (notification_id),
            KEY dedupe_key (dedupe_key),
            KEY group_id (group_id),
            KEY dismissal_type (dismissal_type),
            KEY snooze_until (snooze_until),
            KEY created_at (created_at),
            KEY updated_at (updated_at),
            KEY user_notification (user_id, notification_id),
            KEY user_dedupe (user_id, dedupe_key)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql1);
        dbDelta($sql2);
        dbDelta($sql3);

        // Migration: Convert notification_id from varchar to bigint (if needed)
        $this->migrate_dismissed_notifications_table();

        // Legacy migration: sender column is now in the CREATE TABLE schema above.
        // dbDelta handles adding it if missing. No manual ALTER needed.

        // Blocked senders table: not created in Lite (no UI). Extended creates it.
        // filters.php and integration.php handle missing table gracefully.

        // Check if source_type column exists, add if missing
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $column_exists = $wpdb->get_results(
            "SHOW COLUMNS FROM {$notifications_table} LIKE 'source_type'"
        );

        if (empty($column_exists)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $wpdb->query("ALTER TABLE {$notifications_table} ADD COLUMN source_type varchar(50) DEFAULT 'system' AFTER source");
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $wpdb->query("ALTER TABLE {$notifications_table} ADD INDEX source_type (source_type)");
        }

        // Check if icon column exists, add if missing
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $icon_exists = $wpdb->get_results(
            "SHOW COLUMNS FROM {$notifications_table} LIKE 'icon'"
        );

        if (empty($icon_exists)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $wpdb->query("ALTER TABLE {$notifications_table} ADD COLUMN icon varchar(50) DEFAULT '' AFTER url");
        }

        // Check if group_id column exists, add if missing
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $group_exists = $wpdb->get_results(
            "SHOW COLUMNS FROM {$notifications_table} LIKE 'group_id'"
        );

        if (empty($group_exists)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $wpdb->query("ALTER TABLE {$notifications_table} ADD COLUMN group_id varchar(50) DEFAULT '' AFTER icon");
        }

        // Check if updated_at column exists, add if missing
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $updated_exists = $wpdb->get_results(
            "SHOW COLUMNS FROM {$notifications_table} LIKE 'updated_at'"
        );

        if (empty($updated_exists)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $wpdb->query("ALTER TABLE {$notifications_table} ADD COLUMN updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at");
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $wpdb->query("ALTER TABLE {$notifications_table} ADD INDEX updated_at (updated_at)");
        }

        // Defensive: ensure dedupe_key exists + is unique even if the table predates the clean slate
        // (e.g. the schema-version option was set out of band). Safe no-ops when already present.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $dedupe_exists = $wpdb->get_results("SHOW COLUMNS FROM {$notifications_table} LIKE 'dedupe_key'");
        if (empty($dedupe_exists)) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $wpdb->query("ALTER TABLE {$notifications_table} ADD COLUMN dedupe_key varchar(150) NOT NULL DEFAULT '' AFTER user_id");
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $dedupe_index = $wpdb->get_results("SHOW INDEX FROM {$notifications_table} WHERE Key_name = 'user_dedupe'");
        if (empty($dedupe_index)) {
            // Only attempt UNIQUE if there are no colliding rows (safe given empty defaults after clean slate).
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $collisions = (int) $wpdb->get_var("SELECT COUNT(*) FROM (SELECT user_id, dedupe_key FROM {$notifications_table} WHERE dedupe_key <> '' GROUP BY user_id, dedupe_key HAVING COUNT(*) > 1) c");
            if ($collisions === 0) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
                $wpdb->query("ALTER TABLE {$notifications_table} ADD UNIQUE KEY user_dedupe (user_id, dedupe_key)");
            }
        }

        // Mark schema as migrated so the clean slate runs only once.
        update_option(self::SCHEMA_VERSION_OPTION, self::SCHEMA_VERSION, false);
    }

    /**
     * Clean up expired notifications
     */
    public function cleanup_expired()
    {
        global $wpdb;

        $table = $wpdb->prefix . 'yooadmin_notifications';

        // Check if table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");

        if (!$table_exists) {
            return 0;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $result = $wpdb->query(
            "DELETE FROM {$table} WHERE expires_at IS NOT NULL AND expires_at < NOW()"
        );

        return $result ? $result : 0;
    }

    /**
     * Retention: delete READ notifications older than $days days.
     *
     * Only read items are removed so the user never loses something they have not
     * seen. $days <= 0 disables the rule (returns 0). Returns the number of deleted rows.
     */
    public function cleanup_old_read($days)
    {
        $days = (int) $days;
        if ($days <= 0) {
            return 0;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_notifications';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        if (!$wpdb->get_var("SHOW TABLES LIKE '{$table}'")) {
            return 0;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $result = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table} WHERE status = 'read' AND created_at < (NOW() - INTERVAL %d DAY)",
            $days
        ));

        return $result ? (int) $result : 0;
    }

    /**
     * Retention: cap the number of stored notifications per user.
     *
     * Keeps the newest $max rows for each user and deletes the rest (oldest first).
     * $max <= 0 disables the rule. Returns the number of deleted rows.
     */
    public function enforce_per_user_cap($max)
    {
        $max = (int) $max;
        if ($max <= 0) {
            return 0;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_notifications';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        if (!$wpdb->get_var("SHOW TABLES LIKE '{$table}'")) {
            return 0;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $user_ids = $wpdb->get_col("SELECT user_id FROM {$table} GROUP BY user_id HAVING COUNT(*) > {$max}");
        if (empty($user_ids)) {
            return 0;
        }

        $deleted = 0;
        foreach ($user_ids as $user_id) {
            $user_id = (int) $user_id;
            // Find the cutoff id: the id of the newest row that must be KEPT, then
            // delete everything older than it for this user.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $cutoff_id = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table} WHERE user_id = %d ORDER BY id DESC LIMIT %d, 1",
                $user_id,
                $max - 1
            ));
            if ($cutoff_id <= 0) {
                continue;
            }
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $result = $wpdb->query($wpdb->prepare(
                "DELETE FROM {$table} WHERE user_id = %d AND id < %d",
                $user_id,
                $cutoff_id
            ));
            $deleted += $result ? (int) $result : 0;
        }

        return $deleted;
    }

    /**
     * Retention: prune old dismissal tombstones.
     *
     * Removes expired snooze tombstones (snooze window already passed) and very old
     * permanent tombstones whose protection is no longer needed. $days <= 0 keeps
     * permanent tombstones forever (only expired snoozes are removed). Returns deleted count.
     */
    public function cleanup_old_tombstones($days)
    {
        $days = (int) $days;

        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        if (!$wpdb->get_var("SHOW TABLES LIKE '{$table}'")) {
            return 0;
        }

        $deleted = 0;

        // Always drop snoozes whose window has elapsed (they no longer hide anything).
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $expired = $wpdb->query(
            "DELETE FROM {$table} WHERE snooze_until IS NOT NULL AND snooze_until < NOW()"
        );
        $deleted += $expired ? (int) $expired : 0;

        // Optionally prune permanent tombstones older than $days.
        if ($days > 0) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $old = $wpdb->query($wpdb->prepare(
                "DELETE FROM {$table} WHERE snooze_until IS NULL AND created_at < (NOW() - INTERVAL %d DAY)",
                $days
            ));
            $deleted += $old ? (int) $old : 0;
        }

        return $deleted;
    }

    /**
     * Update notification
     */
    public function update($id, $data)
    {
        global $wpdb;

        $table = $wpdb->prefix . 'yooadmin_notifications';

        // Check if table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");

        if (!$table_exists) {
            return false;
        }

        // Get old data before update (for cache invalidation hook)
        $old_data = null;
        if (has_action('yooadmin_notification_updated')) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
            $old_data = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d",
                $id
            ), ARRAY_A);
        }

        // Check if updated_at column exists, add if missing
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $updated_exists = $wpdb->get_results(
            "SHOW COLUMNS FROM {$table} LIKE 'updated_at'"
        );

        if (empty($updated_exists)) {
            $wpdb->query("ALTER TABLE {$table} ADD COLUMN updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at");
        }

        // Encode meta if it's an array (but not if it's already a JSON string)
        if (isset($data['meta'])) {
            if (is_array($data['meta'])) {
                $data['meta'] = json_encode($data['meta']);
            }
            elseif (is_string($data['meta']) && !empty($data['meta'])) {
                // Already a JSON string, keep it as is
                // Just verify it's valid JSON
                $decoded = json_decode($data['meta'], true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    // Invalid JSON, encode as empty array
                    $data['meta'] = json_encode([]);
                }
            }
            else {
                $data['meta'] = json_encode([]);
            }
        }

        // Add updated_at if not present
        if (!isset($data['updated_at'])) {
            $data['updated_at'] = current_time('mysql');
        }

        $result = $wpdb->update($table, $data, ['id' => $id]);

        if ($result !== false && $old_data) {
            // Fire hook for notification updated (only if we have old data)
            do_action('yooadmin_notification_updated', $id, $data, $old_data);
        }

        return $result !== false;
    }

    /**
     * Create notification (alias for store_notification)
     */
    public function create($data)
    {
        return $this->store_notification($data);
    }

    /**
     * Get notifications for user (alias for compatibility)
     */
    public function get_for_user($user_id, $options = [])
    {
        $defaults = [
            'status' => null,
            'limit' => 50,
            'offset' => 0,
            'priority' => null,
            'source_type' => null,
            'id' => null,
            'group_id' => null,
            'order_by' => 'created_at DESC'
        ];

        $options = array_merge($defaults, $options);

        global $wpdb;
        // Table name built from $wpdb->prefix and static string.
        // Safe: 'yooadmin_notifications' is a hardcoded string, not user input.
        $table = $wpdb->prefix . 'yooadmin_notifications';

        // Check if table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");

        if (!$table_exists) {
            return [];
        }

        $where = ["user_id = %d"];
        $params = [$user_id];

        // Add filters
        if ($options['status']) {
            if (is_array($options['status'])) {
                $placeholders = implode(',', array_fill(0, count($options['status']), '%s'));
                $where[] = "status IN ($placeholders)";
                $params = array_merge($params, $options['status']);
            }
            else {
                $where[] = "status = %s";
                $params[] = $options['status'];
            }
        }

        if ($options['priority']) {
            if (is_array($options['priority'])) {
                $placeholders = implode(',', array_fill(0, count($options['priority']), '%s'));
                $where[] = "priority IN ($placeholders)";
                $params = array_merge($params, $options['priority']);
            }
            else {
                $where[] = "priority = %s";
                $params[] = $options['priority'];
            }
        }

        if ($options['source_type']) {
            $where[] = "source_type = %s";
            $params[] = $options['source_type'];
        }

        // Support for id search (search in meta JSON for 'id' field)
        if ($options['id']) {
            // Note: This searches for 'id' in the notification's meta JSON
            // For exact database ID match, use get_by_id() instead
            // Use JSON_EXTRACT for precise matching (MySQL 5.7+)
            $mysql_version = $wpdb->db_version();
            $use_json_extract = version_compare($mysql_version, '5.7.0', '>=');

            if ($use_json_extract) {
                // Use JSON_EXTRACT for accurate JSON field matching
                $where[] = "JSON_UNQUOTE(JSON_EXTRACT(meta, '$.id')) = %s";
                $params[] = $options['id'];
            }
            else {
                // Fallback for older MySQL versions
                $where[] = "meta LIKE %s";
                $params[] = '%"id":"' . $wpdb->esc_like($options['id']) . '"%';
            }
        }

        // Support for group_id search
        if ($options['group_id']) {
            $where[] = "group_id = %s";
            $params[] = $options['group_id'];
        }

        // Support for ids array (get multiple notifications by their database IDs)
        if (isset($options['ids']) && is_array($options['ids']) && !empty($options['ids'])) {
            $ids = array_map('intval', $options['ids']);
            $ids = array_filter($ids, function ($id) {
                return $id > 0;
            });
            if (!empty($ids)) {
                $placeholders = implode(',', array_fill(0, count($ids), '%d'));
                $where[] = "id IN ($placeholders)";
                $params = array_merge($params, $ids);
            }
        }

        // Don't show expired notifications
        $where[] = "(expires_at IS NULL OR expires_at > NOW())";

        // Whitelist for ORDER BY to prevent SQL injection
        $allowed_order_by = [
            'created_at DESC' => 'created_at DESC',
            'created_at ASC' => 'created_at ASC',
            'priority DESC, created_at DESC' => 'priority DESC, created_at DESC',
            'updated_at DESC' => 'updated_at DESC',
        ];
        $order_by = isset($allowed_order_by[$options['order_by']])
            ? $allowed_order_by[$options['order_by']]
            : 'created_at DESC';

        $params[] = $options['limit'];
        $params[] = $options['offset'];

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table, not cacheable.
        $notifications = $wpdb->get_results(
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $where built from whitelisted placeholders; $order_by from whitelist; table name is hardcoded prefix.
            $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "yooadmin_notifications WHERE " . implode(' AND ', $where) . " ORDER BY {$order_by} LIMIT %d OFFSET %d",
            $params
        ),
            ARRAY_A
        );

        // Decode meta for each notification
        foreach ($notifications as &$notification) {
            $notification['meta'] = json_decode($notification['meta'] ?? '{}', true);

            // If searching by id, filter results to match exact id in meta
            if ($options['id']) {
                $meta_id = $notification['meta']['id'] ?? null;
                if ($meta_id !== $options['id']) {
                    // Remove from results if id doesn't match
                    $notification = null;
                }
            }
        }

        // Remove null entries if any
        $notifications = array_filter($notifications);

        return array_values($notifications);
    }

    /**
     * Mark notification as read
     */
    public function mark_as_read($notification_id, $user_id = null)
    {
        global $wpdb;

        $table = $wpdb->prefix . 'yooadmin_notifications';

        // Ensure notification_id is an integer
        $notification_id = intval($notification_id);

        if ($notification_id <= 0) {
            // Silent
            return false;
        }

        $data = ['status' => 'read', 'updated_at' => current_time('mysql')];
        $where = ['id' => $notification_id];

        if ($user_id !== null) {
            $where['user_id'] = intval($user_id);
        }

        $result = $wpdb->update($table, $data, $where);

        if ($result !== false) {
            // Fire hook for notification read
            do_action('yooadmin_notification_read', $notification_id, $user_id);
        }

        return $result;
    }

    /**
     * Mark notification as new (renew/restore)
     * Updates created_at to current time to move it to top of list
     */
    public function mark_as_new($notification_id, $user_id = null)
    {
        global $wpdb;

        $table = $wpdb->prefix . 'yooadmin_notifications';

        // Ensure notification_id is an integer
        $notification_id = intval($notification_id);

        if ($notification_id <= 0) {
            // Silent
            return false;
        }

        $current_time = current_time('mysql');
        // Update created_at to current time to move notification to top of list
        // Also update status to 'new' and updated_at
        $data = [
            'status' => 'new',
            'created_at' => $current_time, // Update created_at to move to top
            'updated_at' => $current_time
        ];
        $where = ['id' => $notification_id];

        if ($user_id !== null) {
            $where['user_id'] = intval($user_id);
        }

        $result = $wpdb->update($table, $data, $where);

        if ($result === false) {
        // Silent
        }
        else {
        // Silent
        }

        return $result;
    }

    /**
     * Mark multiple notifications as read
     */
    public function mark_multiple_as_read($notification_ids, $user_id = null)
    {
        global $wpdb;

        // Table name built from $wpdb->prefix and static string.
        // Safe: 'yooadmin_notifications' is a hardcoded string, not user input.
        $table = $wpdb->prefix . 'yooadmin_notifications';

        if (empty($notification_ids)) {
            // Silent
            return 0;
        }

        // Validate and sanitize notification IDs
        $notification_ids = array_map('intval', $notification_ids);
        $notification_ids = array_filter($notification_ids, function ($id) {
            return $id > 0;
        });

        if (empty($notification_ids)) {
            // Silent
            return 0;
        }

        // Build WHERE clause safely using prepare
        $placeholders = implode(',', array_fill(0, count($notification_ids), '%d'));
        $where_clause = "id IN ($placeholders)";

        if ($user_id !== null) {
            $user_id = intval($user_id);
            $where_clause .= " AND user_id = %d";
            $result = $wpdb->query(
                $wpdb->prepare(
                "UPDATE {$table} SET status = 'read', updated_at = %s WHERE {$where_clause}",
                array_merge([current_time('mysql')], $notification_ids, [$user_id])
            )
            );
        }
        else {
            $result = $wpdb->query(
                $wpdb->prepare(
                "UPDATE {$table} SET status = 'read', updated_at = %s WHERE {$where_clause}",
                array_merge([current_time('mysql')], $notification_ids)
            )
            );
        }

        if ($result === false) {
            // Silent
            return false;
        }
        else {
            // Silent
            return $result;
        }
    }

    /**
     * Delete notification permanently
     */
    public function delete_notification($notification_id, $user_id = null)
    {
        global $wpdb;

        $table = $wpdb->prefix . 'yooadmin_notifications';

        // Ensure notification_id is an integer
        $notification_id = intval($notification_id);

        if ($notification_id <= 0) {
            // Silent
            return false;
        }

        $where = ['id' => $notification_id];

        if ($user_id !== null) {
            $where['user_id'] = intval($user_id);
        }

        $result = $wpdb->delete($table, $where);

        if ($result === false) {
            // Silent
            return false;
        }
        else {
            // Silent
            return $result > 0;
        }
    }

    /**
     * Delete multiple notifications permanently
     */
    public function delete_multiple_notifications($notification_ids, $user_id = null)
    {
        global $wpdb;

        // Table name built from $wpdb->prefix and static string.
        // Safe: 'yooadmin_notifications' is a hardcoded string, not user input.
        $table = $wpdb->prefix . 'yooadmin_notifications';

        if (empty($notification_ids)) {
            // Silent
            return 0;
        }

        // Validate and sanitize notification IDs
        $notification_ids = array_map('intval', $notification_ids);
        $notification_ids = array_filter($notification_ids, function ($id) {
            return $id > 0;
        });

        if (empty($notification_ids)) {
            // Silent
            return 0;
        }

        // Build WHERE clause safely using prepare
        $placeholders = implode(',', array_fill(0, count($notification_ids), '%d'));
        $where_clause = "id IN ($placeholders)";

        if ($user_id !== null) {
            $user_id = intval($user_id);
            $where_clause .= " AND user_id = %d";
            $result = $wpdb->query(
                $wpdb->prepare(
                "DELETE FROM {$table} WHERE {$where_clause}",
                array_merge($notification_ids, [$user_id])
            )
            );
        }
        else {
            $result = $wpdb->query(
                $wpdb->prepare(
                "DELETE FROM {$table} WHERE {$where_clause}",
                $notification_ids
            )
            );
        }

        if ($result === false) {
            // Silent
            return false;
        }
        else {
            // Silent
            return $result;
        }
    }

    /**
     * Migrate dismissed_notifications table: Convert notification_id from varchar to bigint
     */
    private function migrate_dismissed_notifications_table()
    {
        global $wpdb;

        $dismissed_table = $wpdb->prefix . 'yooadmin_dismissed_notifications';

        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$dismissed_table}'");
        if (!$table_exists) {
            return; // Table doesn't exist yet, will be created with correct type
        }

        // Check current column type
        $column_info = $wpdb->get_row("SHOW COLUMNS FROM {$dismissed_table} WHERE Field = 'notification_id'");
        if (!$column_info) {
            return; // Column doesn't exist
        }

        // If column is still varchar, migrate it
        if (strpos($column_info->Type, 'varchar') !== false) {
            // Silent

            // Get all dismissed notifications with string IDs (non-numeric)
            $dismissed_with_strings = $wpdb->get_results(
                "SELECT d.id, d.user_id, d.notification_id, d.dismissal_type, d.snooze_until, d.created_at
                FROM {$dismissed_table} d
                WHERE d.notification_id IS NOT NULL 
                AND d.notification_id NOT REGEXP '^[0-9]+$'",
                ARRAY_A
            );

            if (!empty($dismissed_with_strings)) {
                $notifications_table = $wpdb->prefix . 'yooadmin_notifications';
                $migrated = 0;
                $failed = 0;

                foreach ($dismissed_with_strings as $dismissed) {
                    $string_id = $dismissed['notification_id'];

                    // Find database ID by meta.id
                    $db_id = $wpdb->get_var($wpdb->prepare(
                        "SELECT id FROM {$notifications_table} 
                        WHERE user_id = %d 
                        AND (meta LIKE %s OR meta LIKE %s)
                        LIMIT 1",
                        $dismissed['user_id'],
                        '%"id":"' . $wpdb->esc_like($string_id) . '"%',
                        '%"banner_id":"' . $wpdb->esc_like($string_id) . '"%'
                    ));

                    if ($db_id) {
                        // Update to use database ID
                        $wpdb->update(
                            $dismissed_table,
                        ['notification_id' => intval($db_id)],
                        ['id' => $dismissed['id']],
                        ['%d'],
                        ['%d']
                        );
                        $migrated++;
                    }
                    else {
                        // Cannot find database ID, delete this record
                        $wpdb->delete($dismissed_table, ['id' => $dismissed['id']], ['%d']);
                        $failed++;
                    }
                }

            // Silent
            }

            // Now alter the column type
            $wpdb->query("ALTER TABLE {$dismissed_table} MODIFY notification_id bigint(20) DEFAULT NULL");
        // Silent
        }
    }

    /**
     * Get storage statistics
     */
    public function get_stats()
    {
        global $wpdb;

        $notifications_table = $wpdb->prefix . 'yooadmin_notifications';
        $dismissed_table = $wpdb->prefix . 'yooadmin_dismissed_notifications';

        $stats = [
            'total' => 0,
            'unread' => 0,
            'read' => 0,
            'critical' => 0,
            'high' => 0,
            'medium' => 0,
            'low' => 0
        ];

        // Check if tables exist
        $notifications_exists = $wpdb->get_var("SHOW TABLES LIKE '{$notifications_table}'");

        if ($notifications_exists) {
            $stats['total'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$notifications_table}");
            $stats['unread'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$notifications_table} WHERE status = 'new'");
            $stats['read'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$notifications_table} WHERE status = 'read'");
            $stats['critical'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$notifications_table} WHERE priority = 'critical'");
            $stats['high'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$notifications_table} WHERE priority = 'high'");
            $stats['medium'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$notifications_table} WHERE priority = 'medium'");
            $stats['low'] = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$notifications_table} WHERE priority = 'low'");
        }

        return $stats;
    }
}

// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
// phpcs:enable WordPress.DB.DirectDatabaseQuery.SchemaChange
// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
// phpcs:enable WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
// phpcs:enable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter

// Simple alias for compatibility (only if not already defined)
if (!class_exists('YOOAdmin_Storage')) {
    class_alias('YOOAdmin_Database_Storage', 'YOOAdmin_Storage');
}

// Create global instance
function yooadmin_get_storage()
{
    static $storage = null;

    if ($storage === null) {
        $storage = new YOOAdmin_Database_Storage();
    }

    return $storage;
}
