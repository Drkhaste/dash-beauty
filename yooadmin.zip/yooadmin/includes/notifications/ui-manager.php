<?php
/**
 * YOOAdmin - UI manager (notification assets)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

class YOOAdmin_UI_Manager
{

    private $styles_loaded = false;
    private $scripts_loaded = false;

    public function __construct()
    {
        $this->initialize_ui_components();
    }

    /**
     * Initialize UI components
     */
    private function initialize_ui_components()
    {
        // Load styles and scripts
        add_action('admin_enqueue_scripts', [$this, 'load_ui_assets']);
    }

    /**
     * Load UI assets
     */
    public function load_ui_assets($hook)
    {
        // ui.php is the canonical loader (full l10n + single script handle).
        if (function_exists('yooadmin_get_notification_ui')) {
            return;
        }

        // Only load notification UI when Focus Mode is enabled
        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return;
        }

        // Load CSS
        $main = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(dirname(__DIR__)) . '/yooadmin.php';
        $notifications_css_path = dirname($main) . '/assets/css/admin/notifications-ui.css';
        $notifications_css_ver = file_exists($notifications_css_path) ? (string) filemtime($notifications_css_path) : '1.0.0';
        wp_enqueue_style(
            'yp-notifications-ui',
            plugins_url('assets/css/admin/notifications-ui.css', $main),
            ['yooadmin-yoo-buttons'],
            $notifications_css_ver
        );

        wp_enqueue_script(
            'yp-notifications-ui',
            plugins_url('assets/js/admin/notifications-ui.js', $main),
        ['jquery'],
            '1.0.0',
            true
        );

        // Get user preferences for show_count_badge
        $user_id = get_current_user_id();
        $user_prefs = get_user_meta($user_id, 'yooadmin_notification_preferences', true);
        $show_count_badge = true; // Default
        if (is_array($user_prefs) && isset($user_prefs['show_count_badge'])) {
            $show_count_badge = !empty($user_prefs['show_count_badge']);
        }

        // Get notification sound setting (default: enabled)
        $notification_sound_enabled = true;
        if (isset($user_prefs['notification_sound_enabled'])) {
            $notification_sound_enabled = !empty($user_prefs['notification_sound_enabled']);
        }

        // Localize script
        if (function_exists('yooadmin_get_notifications_ui_localize_data')) {
            wp_localize_script('yp-notifications-ui', 'yooadmNotifications', yooadmin_get_notifications_ui_localize_data());
        }

        $this->styles_loaded = true;
        $this->scripts_loaded = true;
    }
}

// Create global instance
function yooadmin_get_ui_manager()
{
    static $ui_manager = null;

    if ($ui_manager === null) {
        $ui_manager = new YOOAdmin_UI_Manager();
    }

    return $ui_manager;
}

// Auto-initialize
yooadmin_get_ui_manager();
