<?php
/**
 * YOOAdmin - REST API compatibility (notifications)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

function yooadmin_rest_settings_allowed_keys(): array {
    return [
        'yooadmin_primary_color',
        'yooadmin_secondary_color',
        'yooadmin_focus_active',
        'convert_banners_to_notifications',
    ];
}

add_action('rest_api_init', function() {
    
    // Banner notifications endpoint (compatibility)
    register_rest_route('yooadmin/v1', '/banner-notifications', [
        [
            'methods' => 'POST',
            'callback' => 'yooadmin_handle_banner_notifications_compatibility',
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
            'args' => [
                'action' => [
                    'required' => false,
                    'type' => 'string',
                    'enum' => ['clear'],
                    'default' => 'clear',
                ],
            ],
        ]
    ]);
    
    // Settings endpoint for admin utilities
    register_rest_route('yooadmin/v1', '/settings', [
        [
            'methods' => 'POST',
            'callback' => 'yooadmin_handle_settings_save',
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
            'args' => [
                'key' => [
                    'required' => true,
                    'type' => 'string'
                ],
                'value' => [
                    'required' => true,
                    'type' => 'string'
                ]
            ]
        ],
        [
            'methods' => 'GET',
            'callback' => 'yooadmin_handle_settings_get',
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
            'args' => [
                'key' => [
                    'required' => true,
                    'type' => 'string'
                ]
            ]
        ]
    ]);
});

/**
 * Handle banner notifications (compatibility mode)
 */
function yooadmin_handle_banner_notifications_compatibility($request) {
    $action = $request->get_param('action');
    
    switch ($action) {
        case 'clear':
            // Return success to prevent errors
            return [
                'success' => true,
                'message' => 'Banner notifications cleared (compatibility mode)',
                'cleared' => 0,
                'timestamp' => current_time('mysql')
            ];
            
        default:
            return new WP_Error(
                'invalid_action',
                'Invalid action specified',
                ['status' => 400]
            );
    }
}

/**
 * Handle settings save
 */
function yooadmin_handle_settings_save($request) {
    $key = $request->get_param('key');
    $value = $request->get_param('value');
    
    $allowed_keys = yooadmin_rest_settings_allowed_keys();

    if (!in_array($key, $allowed_keys, true)) {
        return new WP_Error(
            'invalid_key',
            'Invalid setting key',
            ['status' => 400]
        );
    }

    // Sanitize value based on key type
    $color_keys   = ['yooadmin_primary_color', 'yooadmin_secondary_color'];
    $boolean_keys = ['yooadmin_focus_active', 'convert_banners_to_notifications'];

    if (in_array($key, $color_keys, true)) {
        $value = sanitize_hex_color((string) $value);
        if (null === $value) {
            return new WP_Error('invalid_value', 'Invalid color value', ['status' => 400]);
        }
    } elseif (in_array($key, $boolean_keys, true)) {
        $value = rest_sanitize_boolean($value) ? '1' : '0';
    } else {
        $value = sanitize_text_field((string) $value);
    }

    // Save setting
    $updated = update_option($key, $value);
    
    return [
        'success' => $updated,
        'key' => $key,
        'value' => $value,
        'timestamp' => current_time('mysql')
    ];
}

/**
 * Handle settings get
 */
function yooadmin_handle_settings_get($request) {
    $key = $request->get_param('key');
    if (!in_array($key, yooadmin_rest_settings_allowed_keys(), true)) {
        return new WP_Error(
            'invalid_key',
            'Invalid setting key',
            ['status' => 400]
        );
    }

    $value = get_option($key, '');

    return [
        'key' => $key,
        'value' => $value,
        'timestamp' => current_time('mysql'),
    ];
}
