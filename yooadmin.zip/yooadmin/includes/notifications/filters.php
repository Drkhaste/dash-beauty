<?php
/**
 * YOOAdmin - Filter system (notifications)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom notification tables; caching handled by notification cache layer.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Table names from $wpdb->prefix + hardcoded strings.
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names from $wpdb->prefix + hardcoded strings; all user input passed through $wpdb->prepare().
class YOOAdmin_Filters {
    
    private $storage;
    private $cache;
    
    public function __construct() {
        $this->storage = yooadmin_get_storage();
        $this->cache = new YOOAdmin_Cache();
    }
    
    /**
     * Filter out generic/incomplete notifications
     */
    private function filter_generic($notifications) {
        return array_filter($notifications, function($notification) {
            $title = $notification['title'] ?? '';
            $message = $notification['message'] ?? '';
            
            // Filter out generic notifications with placeholder text
            if ($title === 'Admin Notice' && $message === 'Please check this notification.') {
                return false; // Skip this notification
            }
            
            // Filter out notifications with very short or empty content
            if (strlen($title) < 3 && strlen($message) < 10) {
                return false;
            }
            
            return true;
        });
    }
    
    /**
     * Filter notifications for user
     */
    public function filter_notifications($user_id, $notifications, $options = []) {
        $defaults = [
            'show_dismissed' => false,
            'show_expired' => false,
            'show_invalid' => false, // Show notifications for removed items (plugins/themes)
            'show_archived' => false, // Show archived notifications
            'priority_filter' => null,
            'source_filter' => null,
            'group_filter' => null,
            'limit' => 50,
            'offset' => 0,
            'sort_by' => 'created_at',
            'sort_order' => 'DESC'
        ];
        
        $options = array_merge($defaults, $options);
        
        // Apply filters
        $filtered = $notifications;
        
        // Filter invalid notifications (items that no longer exist)
        // Filter generic/incomplete notifications first
        $filtered = $this->filter_generic($filtered);
        
        // Don't filter invalid when showing archived — archived items may be invalid.
        if (!$options['show_invalid'] && !$options['show_archived']) {
            $filtered = $this->filter_invalid($filtered);
        }

        if (!$options['show_archived']) {
            $filtered = $this->filter_archived($filtered);
        }

        // Blocked senders filter: Plus via yooadmin_notifications_before_grouping

        $show_snoozed = isset($options['status']) && $options['status'] === 'snoozed';
        if (!$options['show_dismissed'] && !$options['show_archived'] && !$show_snoozed) {
            $filtered = $this->filter_dismissed($user_id, $filtered);
        } elseif ($show_snoozed) {
            // For snoozed view, only show snoozed notifications
            $filtered = $this->filter_snoozed_only($user_id, $filtered);
        }
        
        // Filter expired notifications
        if (!$options['show_expired']) {
            $filtered = $this->filter_expired($filtered);
        }
        
        // Filter by priority
        if ($options['priority_filter']) {
            $filtered = $this->filter_by_priority($filtered, $options['priority_filter']);
        }
        
        // Filter by source
        if ($options['source_filter']) {
            $filtered = $this->filter_by_source($filtered, $options['source_filter']);
        }
        
        // Filter by group
        if ($options['group_filter']) {
            $filtered = $this->filter_by_group($filtered, $options['group_filter']);
        }

        /**
         * Filter notifications before grouping (Plus: blocked senders, etc.).
         *
         * @param array<int, array<string, mixed>> $filtered
         * @param int $user_id
         * @param array<string, mixed> $options
         */
        $filtered = apply_filters('yooadmin_notifications_before_grouping', $filtered, $user_id, $options);
        
        // Apply smart grouping
        $grouped = $this->apply_smart_grouping($filtered);
        
        // Apply user preferences
        $grouped = $this->apply_user_preferences($user_id, $grouped);
        // Count banners after preferences
        $banner_count_after_prefs = 0;
        foreach ($grouped as $item) {
            if (isset($item['type']) && $item['type'] === 'group') {
                $banner_count_after_prefs += count(array_filter($item['items'] ?? [], function($n) { return ($n['source_type'] ?? '') === 'banner'; }));
            } else if (($item['source_type'] ?? '') === 'banner') {
                $banner_count_after_prefs++;
            }
        }
        
        // Sort
        $before_sort = $banner_count_after_prefs;
        $grouped = $this->sort_notifications($grouped, $options['sort_by'], $options['sort_order']);
        // Count banners after sort
        $banner_count_after_sort = 0;
        foreach ($grouped as $item) {
            if (isset($item['type']) && $item['type'] === 'group') {
                $banner_count_after_sort += count(array_filter($item['items'] ?? [], function($n) { return ($n['source_type'] ?? '') === 'banner'; }));
            } else if (($item['source_type'] ?? '') === 'banner') {
                $banner_count_after_sort++;
            }
        }
        
        // Apply limit and offset
        $before_pagination = $banner_count_after_sort;
        $grouped = $this->apply_pagination($grouped, $options['limit'], $options['offset']);
        // Count banners after pagination
        $banner_count_after_pagination = 0;
        foreach ($grouped as $item) {
            if (isset($item['type']) && $item['type'] === 'group') {
                $banner_count_after_pagination += count(array_filter($item['items'] ?? [], function($n) { return ($n['source_type'] ?? '') === 'banner'; }));
            } else if (($item['source_type'] ?? '') === 'banner') {
                $banner_count_after_pagination++;
            }
        }
        
        /**
         * Filter notifications after all Lite filters (Plus: blocked senders, etc.).
         *
         * @param array<int, array<string, mixed>> $grouped
         * @param int $user_id
         * @param array<string, mixed> $options
         */
        return apply_filters('yooadmin_notifications_filtered', $grouped, $user_id, $options);
    }
    
    /**
     * Filter out dismissed notifications
     */
    private function filter_dismissed($user_id, $notifications) {
        $dismissed = $this->get_dismissed_notifications($user_id);

        // Identity-stable tombstones keyed on dedupe_key. A row keeps hiding while its
        // condition is unchanged, and only resurfaces when the fingerprint differs.
        $dedupe_map = [];
        // Legacy fallback keyed on the database row id (pre-dedupe dismissals).
        $id_map = [];

        foreach ($dismissed as $dismissed_item) {
            $snooze_until = $dismissed_item['snooze_until'] ?? null;
            $dedupe_key = $dismissed_item['dedupe_key'] ?? '';

            if ($dedupe_key !== '' && $dedupe_key !== null) {
                $dedupe_map[$dedupe_key] = [
                    'snooze_until' => $snooze_until,
                    'fingerprint'  => $dismissed_item['fingerprint'] ?? null,
                ];
            }

            $notif_id = $dismissed_item['notification_id'] ?? null;
            if ($notif_id) {
                $notif_id = intval($notif_id);
                if ($notif_id > 0) {
                    $id_map[$notif_id] = $snooze_until;
                }
            }
        }

        $now = current_time('mysql');

        return array_filter($notifications, function($notification) use ($dedupe_map, $id_map, $now) {
            // 1) Identity-based (dedupe_key + fingerprint) tombstone.
            $dedupe_key = (string) ($notification['dedupe_key'] ?? '');
            if ($dedupe_key === '') {
                $meta = is_array($notification['meta'] ?? null)
                    ? $notification['meta']
                    : (is_string($notification['meta'] ?? null) ? json_decode($notification['meta'], true) : []);
                if (is_array($meta) && !empty($meta['id'])) {
                    $dedupe_key = (string) $meta['id'];
                }
            }

            if ($dedupe_key !== '' && isset($dedupe_map[$dedupe_key])) {
                $tomb = $dedupe_map[$dedupe_key];
                $snooze_until = $tomb['snooze_until'];

                if ($snooze_until === null) {
                    // Permanent dismissal. If both sides carry a fingerprint, only keep it
                    // hidden while the condition is unchanged; otherwise hide unconditionally.
                    $tomb_fp = (string) ($tomb['fingerprint'] ?? '');
                    $current_fp = $this->notification_fingerprint($notification);
                    if ($tomb_fp !== '' && $current_fp !== '' && $tomb_fp !== $current_fp) {
                        return true; // Condition materially changed -> resurface.
                    }
                    return false; // Still the same condition -> stay dismissed.
                }

                // Snooze is purely time-based.
                if ($snooze_until && $snooze_until > $now) {
                    return false;
                }
                return true;
            }

            // 2) Legacy id-based fallback (dismissals recorded before dedupe_key existed).
            $notification_id = $notification['id'] ?? null;
            if ($notification_id) {
                $notification_id = intval($notification_id);
            }
            if (!$notification_id || !isset($id_map[$notification_id])) {
                return true;
            }
            $snooze_until = $id_map[$notification_id];
            if ($snooze_until === null) {
                return false;
            }
            if ($snooze_until && $snooze_until > $now) {
                return false;
            }
            return true;
        });
    }

    /**
     * Extract a notification's current condition fingerprint from its meta.
     */
    private function notification_fingerprint($notification) {
        $meta = is_array($notification['meta'] ?? null)
            ? $notification['meta']
            : (is_string($notification['meta'] ?? null) ? json_decode($notification['meta'], true) : []);
        if (is_array($meta) && !empty($meta['fingerprint'])) {
            return (string) $meta['fingerprint'];
        }
        return '';
    }
    
    /**
     * Filter to show only snoozed notifications
     */
    private function filter_snoozed_only($user_id, $notifications) {
        $dismissed = $this->get_dismissed_notifications($user_id);
        
        // Build lookup map: notification_id => snooze_until (only for snoozed items)
        $snoozed_map = [];
        foreach ($dismissed as $dismissed_item) {
            $notif_id = $dismissed_item['notification_id'] ?? null;
            $dismissal_type = $dismissed_item['dismissal_type'] ?? '';
            $snooze_until = $dismissed_item['snooze_until'] ?? null;
            
            // Only include snoozed items with valid snooze_until
            if ($notif_id && $dismissal_type === 'snooze' && $snooze_until) {
                $notif_id = intval($notif_id);
                if ($notif_id > 0) {
                    $snoozed_map[$notif_id] = $snooze_until;
                }
            }
        }
        
        $now = current_time('mysql');
        
        return array_filter($notifications, function($notification) use ($snoozed_map, $now) {
            $notification_id = $notification['id'] ?? null;
            
            if ($notification_id) {
                $notification_id = intval($notification_id);
            }
            
            // Only show if it's in snoozed map and snooze_until is in the future
            if ($notification_id && isset($snoozed_map[$notification_id])) {
                $snooze_until = $snoozed_map[$notification_id];
                return $snooze_until && $snooze_until > $now;
            }
            
            return false; // Not snoozed
        });
    }
    
    /**
     * Filter out expired notifications
     */
    private function filter_expired($notifications) {
        $now = current_time('mysql');
        
        return array_filter($notifications, function($notification) use ($now) {
            return empty($notification['expires_at']) || $notification['expires_at'] > $now;
        });
    }

    /**
     * Filter out archived notifications.
     */
    private function filter_archived($notifications) {
        return array_filter($notifications, function ($notification) {
            return ($notification['status'] ?? '') !== 'archived';
        });
    }

    /**
     * Filter out invalid notifications (items that no longer exist)
     * Checks if plugin/theme still exists before showing notification
     */
    private function filter_invalid($notifications) {
        return array_filter($notifications, function($notification) {
            if (isset($notification['status']) && in_array($notification['status'], ['archived', 'invalid'])) {
                return false;
            }
            
            // Check meta for invalid flag
            $meta = is_array($notification['meta'] ?? null) ? $notification['meta'] : [];
            if (isset($meta['invalid']) && $meta['invalid'] === true) {
                return false;
            }
            if (isset($meta['item_removed']) && $meta['item_removed'] === true) {
                return false;
            }
            
            // For plugin/theme updates, verify the item still exists
            $source_type = $notification['source_type'] ?? '';
            if ($source_type === 'plugin_updates') {
                return $this->verify_plugin_exists($notification);
            } elseif ($source_type === 'theme_updates') {
                return $this->verify_theme_exists($notification);
            }
            
            // For other types, assume valid
            return true;
        });
    }
    
    /**
     * Verify if plugin still exists
     */
    private function verify_plugin_exists($notification) {
        $meta = is_array($notification['meta'] ?? null) ? $notification['meta'] : [];
        $item = $meta['item'] ?? [];
        $plugin_file = $item['file'] ?? null;
        
        if (!$plugin_file) {
            return true; // Can't verify, assume valid
        }
        
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $all_plugins = get_plugins();
        return isset($all_plugins[$plugin_file]);
    }
    
    /**
     * Verify if theme still exists
     */
    private function verify_theme_exists($notification) {
        $meta = is_array($notification['meta'] ?? null) ? $notification['meta'] : [];
        $item = $meta['item'] ?? [];
        $theme_slug = $item['slug'] ?? null;
        
        if (!$theme_slug) {
            return true; // Can't verify, assume valid
        }
        
        $theme = wp_get_theme($theme_slug);
        return $theme->exists();
    }
    
    /**
     * Filter by priority
     */
    private function filter_by_priority($notifications, $priorities) {
        if (!is_array($priorities)) {
            $priorities = [$priorities];
        }
        
        return array_filter($notifications, function($notification) use ($priorities) {
            return in_array($notification['priority'], $priorities);
        });
    }
    
    /**
     * Filter by source
     */
    private function filter_by_source($notifications, $sources) {
        if (!is_array($sources)) {
            $sources = [$sources];
        }
        
        return array_filter($notifications, function($notification) use ($sources) {
            return in_array($notification['source'], $sources);
        });
    }
    
    /**
     * Filter by group
     */
    private function filter_by_group($notifications, $groups) {
        if (!is_array($groups)) {
            $groups = [$groups];
        }
        
        return array_filter($notifications, function($notification) use ($groups) {
            return in_array($notification['group_id'], $groups);
        });
    }
    
    /**
     * Apply smart grouping
     */
    private function apply_smart_grouping($notifications) {
        $grouped = [];
        $ungrouped = [];
        
        foreach ($notifications as $notification) {
            if (!empty($notification['group_id'])) {
                $group_id = $notification['group_id'];
                
                if (!isset($grouped[$group_id])) {
                    $grouped[$group_id] = [
                        'type' => 'group',
                        'group_id' => $group_id,
                        'title' => $this->get_group_title($group_id, $notification),
                        'priority' => $notification['priority'],
                        'count' => 0,
                        'items' => [],
                        'created_at' => $notification['created_at'] ?? current_time('mysql')
                    ];
                }
                
                $grouped[$group_id]['items'][] = $notification;
                $grouped[$group_id]['count']++;
                
                // Update group priority to highest priority in group
                $priorities = ['critical' => 4, 'high' => 3, 'medium' => 2, 'low' => 1];
                $current_priority = $priorities[$grouped[$group_id]['priority']] ?? 0;
                $item_priority = $priorities[$notification['priority']] ?? 0;
                
                if ($item_priority > $current_priority) {
                    $grouped[$group_id]['priority'] = $notification['priority'];
                }
            } else {
                $ungrouped[] = $notification;
            }
        }
        
        // Combine grouped and ungrouped
        $result = array_values($grouped);
        
        // Add ungrouped notifications
        foreach ($ungrouped as $notification) {
            $notification['type'] = 'single';
            $result[] = $notification;
        }
        
        return $result;
    }
    
    /**
     * Get group title
     */
    private function get_group_title($group_id, $sample_notification) {
        $group_titles = [
            'wordpress_updates' => 'WordPress Updates',
            'plugin_updates' => 'Plugin Updates',
            'theme_updates' => 'Theme Updates',
            'pending_comments' => 'Pending Comments',
            'spam_comments' => 'Spam Comments',
            'license_activation' => 'License Activation',
            'license_welcome' => 'License Status',
            'license_deactivated' => 'License Deactivated',
            'admin_banners' => 'Admin Notifications'
        ];
        
        return $group_titles[$group_id] ?? ucfirst(str_replace('_', ' ', $group_id));
    }
    
    /**
     * Apply user preferences
     */
    private function apply_user_preferences($user_id, $notifications) {
        $preferences = $this->get_user_preferences($user_id);
        
        $banner_count_before = 0;
        foreach ($notifications as $item) {
            if (isset($item['type']) && $item['type'] === 'group') {
                $banner_count_before += count(array_filter($item['items'] ?? [], function($n) { return ($n['source_type'] ?? '') === 'banner'; }));
            } else if (($item['source_type'] ?? '') === 'banner') {
                $banner_count_before++;
            }
        }
        
        // Apply priority preferences
        // NOTE: Banner notifications are excluded from priority filtering because they are converted from admin notices
        // and should always be shown regardless of user's priority preferences
        if (!empty($preferences['hidden_priorities'])) {
            $before_priority = $banner_count_before;
            $notifications = array_filter($notifications, function($notification) use ($preferences, $banner_count_before) {
                // Always show banner notifications regardless of priority filter
                if (isset($notification['source_type']) && $notification['source_type'] === 'banner') {
                    return true;
                }
                if ($notification['type'] === 'group') {
                    // Check if this is a banner group
                    if (isset($notification['items']) && is_array($notification['items'])) {
                        $has_banners = false;
                        foreach ($notification['items'] as $item) {
                            if (($item['source_type'] ?? '') === 'banner') {
                                $has_banners = true;
                            }
                        }
                        if ($has_banners) {
                            return true; // Always show banner groups
                        }
                    }
                    // Not a banner group, apply normal priority filter
                    $should_show = !in_array($notification['priority'], $preferences['hidden_priorities']);
                    return $should_show;
                } else {
                    // Not a banner, apply normal priority filter
                    $should_show = !in_array($notification['priority'], $preferences['hidden_priorities']);
                    return $should_show;
                }
            });
            // Count banners after priority filter
            $banner_count_after_priority = 0;
            foreach ($notifications as $item) {
                if (isset($item['type']) && $item['type'] === 'group') {
                    $banner_count_after_priority += count(array_filter($item['items'] ?? [], function($n) { return ($n['source_type'] ?? '') === 'banner'; }));
                } else if (($item['source_type'] ?? '') === 'banner') {
                    $banner_count_after_priority++;
                }
            }
        }
        
        // Apply source preferences
        if (!empty($preferences['hidden_sources'])) {
            $before_source = 0;
            foreach ($notifications as $item) {
                if (isset($item['type']) && $item['type'] === 'group') {
                    $before_source += count(array_filter($item['items'] ?? [], function($n) { return ($n['source_type'] ?? '') === 'banner'; }));
                } else if (($item['source_type'] ?? '') === 'banner') {
                    $before_source++;
                }
            }
            $notifications = array_filter($notifications, function($notification) use ($preferences) {
                if ($notification['type'] === 'group') {
                    $sources = array_unique(array_column($notification['items'], 'source'));
                    return !array_intersect($sources, $preferences['hidden_sources']);
                } else {
                    return !in_array($notification['source'], $preferences['hidden_sources']);
                }
            });
            // Count banners after source filter
            $banner_count_after_source = 0;
            foreach ($notifications as $item) {
                if (isset($item['type']) && $item['type'] === 'group') {
                    $banner_count_after_source += count(array_filter($item['items'] ?? [], function($n) { return ($n['source_type'] ?? '') === 'banner'; }));
                } else if (($item['source_type'] ?? '') === 'banner') {
                    $banner_count_after_source++;
                }
            }
        }
        
        return array_values($notifications);
    }
    
    /**
     * Sort notifications
     */
    private function sort_notifications($notifications, $sort_by, $sort_order) {
        usort($notifications, function($a, $b) use ($sort_by, $sort_order) {
            $a_value = $this->get_sort_value($a, $sort_by);
            $b_value = $this->get_sort_value($b, $sort_by);
            
            $comparison = 0;
            
            if (is_numeric($a_value) && is_numeric($b_value)) {
                $comparison = $a_value <=> $b_value;
            } else {
                $comparison = strcmp($a_value, $b_value);
            }
            
            return $sort_order === 'DESC' ? -$comparison : $comparison;
        });
        
        return $notifications;
    }
    
    /**
     * Get sort value for notification
     */
    private function get_sort_value($notification, $sort_by) {
        switch ($sort_by) {
            case 'priority':
                $priorities = ['critical' => 4, 'high' => 3, 'medium' => 2, 'low' => 1];
                return $priorities[$notification['priority']] ?? 0;
            
            case 'title':
                return $notification['title'] ?? '';
            
            case 'created_at':
                return strtotime($notification['created_at'] ?? 'now');
            
            default:
                return $notification[$sort_by] ?? '';
        }
    }
    
    /**
     * Apply pagination
     */
    private function apply_pagination($notifications, $limit, $offset) {
        return array_slice($notifications, $offset, $limit);
    }
    
    /**
     * Get dismissed notifications for user
     */
    private function get_dismissed_notifications($user_id) {
        global $wpdb;
        
        // Table name built from $wpdb->prefix and static string.
        // Safe: 'yooadmin_dismissed_notifications' is a hardcoded string, not user input.
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';

        // Check if table exists (may not exist during setup wizard)
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
        if (!$table_exists) {
            return [];
        }

        // CRITICAL: Get ALL dismissed notifications (including snoozed ones)
        // We'll filter by snooze_until in PHP to handle timezone correctly
        $results = $wpdb->get_results(
            $wpdb->prepare("
                SELECT notification_id, dedupe_key, fingerprint, group_id, snooze_until, dismissal_type
                FROM {$table}
                WHERE user_id = %d AND 
                      (dismissal_type = 'permanent' OR 
                       dismissal_type = 'snooze' OR
                       dismissal_type = 'dismiss')
            ", $user_id),
            ARRAY_A
        );
        
        // Filter in PHP to handle timezone correctly
        $now = current_time('mysql');
        $filtered = [];
        foreach ($results as $item) {
            $snooze_until = $item['snooze_until'] ?? null;
            $dismissal_type = $item['dismissal_type'] ?? 'dismiss';
            
            // If permanently dismissed, include it
            if ($dismissal_type === 'permanent' || $snooze_until === null) {
                $filtered[] = $item;
            }
            // If snoozed and snooze_until is in the future, include it
            elseif ($snooze_until && $snooze_until > $now) {
                $filtered[] = $item;
            }
            // If snooze expired, exclude it (notification should be shown)
        }
        
        return $filtered;
    }
    
    /**
     * Get user preferences
     */
    private function get_user_preferences($user_id) {
        $defaults = [
            'hidden_priorities' => ['low'],
            'hidden_sources' => [],
            'auto_dismiss_low' => true,
            'group_similar' => true,
            'show_count_badge' => true
        ];
        
        $preferences = get_user_meta($user_id, 'yooadmin_notification_preferences', true);
        
        return array_merge($defaults, $preferences ?: []);
    }
    
    /**
     * Set user preference
     */
    public function set_user_preference($user_id, $key, $value) {
        $preferences = $this->get_user_preferences($user_id);
        $preferences[$key] = $value;
        
        update_user_meta($user_id, 'yooadmin_notification_preferences', $preferences);
        
        // Clear cache
        $this->cache->delete('user_preferences_' . $user_id);
    }
    
    /**
     * Resolve a notification's stable identity (dedupe_key + fingerprint).
     *
     * The dedupe_key survives row deletion/recreation, and the fingerprint captures
     * the underlying condition (comment count, available version, license status, …).
     * Together they let a dismissal behave like a tombstone that only lifts when the
     * condition materially changes.
     *
     * @return array{dedupe_key:string,fingerprint:string}
     */
    private function get_notification_identity($user_id, $notification_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_notifications';

        // SELECT * so a not-yet-migrated schema (no dedupe_key column) degrades gracefully.
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d AND user_id = %d LIMIT 1",
            $notification_id,
            $user_id
        ), ARRAY_A);

        $identity = ['dedupe_key' => '', 'fingerprint' => ''];
        if (!$row) {
            return $identity;
        }

        $identity['dedupe_key'] = isset($row['dedupe_key']) ? (string) $row['dedupe_key'] : '';

        $meta = json_decode($row['meta'] ?? '{}', true);
        if (is_array($meta)) {
            if (!empty($meta['fingerprint'])) {
                $identity['fingerprint'] = (string) $meta['fingerprint'];
            }
            if ($identity['dedupe_key'] === '' && !empty($meta['id'])) {
                $identity['dedupe_key'] = (string) $meta['id'];
            }
        }

        return $identity;
    }

    /**
     * Dismiss notification
     */
    public function dismiss_notification($user_id, $notification_id, $type = 'dismiss', $snooze_until = null) {
        global $wpdb;
        
        // CRITICAL: notification_id MUST be database ID (integer), not meta.id (string)
        // Convert to integer - if not numeric, it's invalid
        if (!is_numeric($notification_id)) {
            return false;
        }
        
        $notification_id = intval($notification_id);
        
        if ($notification_id <= 0) {
            return false;
        }
        
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';

        // Capture the stable identity BEFORE any row deletion so the dismissal
        // survives the notification being deleted and re-collected with a new id.
        $identity = $this->get_notification_identity($user_id, $notification_id);
        $dedupe_key = $identity['dedupe_key'];
        $fingerprint = $identity['fingerprint'];

        $snooze_value = $snooze_until ? gmdate('Y-m-d H:i:s', strtotime($snooze_until)) : null;

        // Prefer one tombstone per (user_id, dedupe_key): re-dismissing after the
        // condition changed should refresh the same record, not pile up duplicates.
        $existing_id = null;
        if ($dedupe_key !== '') {
            $existing_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table} WHERE user_id = %d AND dedupe_key = %s LIMIT 1",
                $user_id,
                $dedupe_key
            ));
        }
        if (!$existing_id) {
            $existing_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table} WHERE user_id = %d AND notification_id = %d LIMIT 1",
                $user_id,
                $notification_id
            ));
        }

        if ($existing_id) {
            $data = [
                'notification_id' => $notification_id,
                'dismissal_type'  => $type,
                'snooze_until'    => $snooze_value,
            ];
            if ($dedupe_key !== '') {
                $data['dedupe_key']  = $dedupe_key;
                $data['fingerprint'] = $fingerprint;
            }
            $result = $wpdb->update($table, $data, ['id' => (int) $existing_id]);
        } else {
            $data = [
                'user_id'         => $user_id,
                'notification_id' => $notification_id,
                'dedupe_key'      => $dedupe_key !== '' ? $dedupe_key : null,
                'fingerprint'     => $dedupe_key !== '' ? $fingerprint : null,
                'dismissal_type'  => $type,
                'snooze_until'    => $snooze_value,
            ];
            $result = $wpdb->insert($table, $data);
        }
        
        if ($result !== false) {
            // Clear cache
            $this->cache->delete('dismissed_notifications_' . $user_id);
            return true;
        }
        
        return false;
    }
    
    /**
     * Dismiss notification group
     */
    public function dismiss_group($user_id, $group_id, $type = 'dismiss', $snooze_until = null) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';
        
        $data = [
            'user_id' => $user_id,
            'group_id' => $group_id,
            'dismissal_type' => $type
        ];
        
        if ($snooze_until) {
            $data['snooze_until'] = gmdate('Y-m-d H:i:s', strtotime($snooze_until));
        }
        
        $format = ['%d', '%s', '%s'];
        if ($snooze_until) {
            $format[] = '%s';
        }
        
        $result = $wpdb->insert($table, $data, $format);
        
        if ($result) {
            // Clear cache
            $this->cache->delete('dismissed_notifications_' . $user_id);
        }
        
        return $result;
    }
    
    /**
     * Snooze notification
     */
    public function snooze_notification($user_id, $notification_id, $duration) {
        // Use current_time for WordPress timezone consistency
        $snooze_until = gmdate('Y-m-d H:i:s', strtotime('+' . $duration, current_time('timestamp')));
        
        return $this->dismiss_notification($user_id, $notification_id, 'snooze', $snooze_until);
    }
    
    /**
     * Snooze notification group
     */
    public function snooze_group($user_id, $group_id, $duration) {
        // Use current_time for WordPress timezone consistency
        $snooze_until = gmdate('Y-m-d H:i:s', strtotime('+' . $duration, current_time('timestamp')));
        
        return $this->dismiss_group($user_id, $group_id, 'snooze', $snooze_until);
    }
    
    /**
     * Restore dismissed notification
     */
    public function restore_notification($user_id, $notification_id, $mark_as_new = false) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';
        
        $result = $wpdb->delete($table, [
            'user_id' => $user_id,
            'notification_id' => $notification_id
        ], ['%d', '%d']);
        
        if ($result) {
            // If restoring from snooze, mark notification as new/unread
            if ($mark_as_new) {
                $notifications_table = $wpdb->prefix . 'yooadmin_notifications';
                $wpdb->update(
                    $notifications_table,
                    [
                        'status' => 'new',
                        'updated_at' => current_time('mysql')
                    ],
                    [
                        'id' => $notification_id,
                        'user_id' => $user_id
                    ],
                    ['%s', '%s'],
                    ['%d', '%d']
                );
                
                // Clear notification caches to show updated count.
                // IMPORTANT: the count is stored under suffixed keys
                // (notification_count_<user>_new / _read / _all). Deleting the
                // bare key is a no-op on persistent object caches (Redis/Memcached),
                // which left the bell badge stuck on cached sites.
                $this->cache->delete('notifications_' . $user_id);
                $this->cache->delete('notification_count_' . $user_id . '_new');
                $this->cache->delete('notification_count_' . $user_id . '_read');
                $this->cache->delete('notification_count_' . $user_id . '_all');
                if (method_exists($this->cache, 'delete_by_pattern')) {
                    $this->cache->delete_by_pattern('notifications_' . $user_id);
                    $this->cache->delete_by_pattern('notification_count_' . $user_id);
                }
            }
            
            // Clear dismissed cache
            $this->cache->delete('dismissed_notifications_' . $user_id);
        }
        
        return $result;
    }
    
    /**
     * Restore snoozed notifications globally (for all users)
     */
    public function restore_snoozed_globally() {
        global $wpdb;
        
        // Table name built from $wpdb->prefix and static string.
        // Safe: 'yooadmin_dismissed_notifications' is a hardcoded string, not user input.
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';
        $now = current_time('mysql');

        // Check if table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
        if (!$table_exists) {
            return [];
        }
        
        return $wpdb->get_results(
            $wpdb->prepare("
                SELECT user_id, notification_id, group_id
                FROM {$table}
                WHERE dismissal_type = 'snooze' 
                  AND snooze_until IS NOT NULL 
                  AND snooze_until <= %s
            ", $now),
            ARRAY_A
        );
    }
    
    /**
     * Restore snoozed notifications for a specific user (called on every poll)
     */
    public function restore_snoozed_for_user($user_id) {
        global $wpdb;
        
        // Table name built from $wpdb->prefix and static string.
        // Safe: 'yooadmin_dismissed_notifications' is a hardcoded string, not user input.
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';
        $now = current_time('mysql');
        
        // Get expired snoozes for this user only
        $to_restore = $wpdb->get_results(
            $wpdb->prepare("
                SELECT notification_id, group_id
                FROM {$table}
                WHERE user_id = %d
                  AND dismissal_type = 'snooze' 
                  AND snooze_until IS NOT NULL 
                  AND snooze_until <= %s
            ", $user_id, $now),
            ARRAY_A
        );
        
        if (empty($to_restore)) {
            return 0;
        }
        
        $restored = 0;
        foreach ($to_restore as $item) {
            if ($item['notification_id']) {
                $this->restore_notification($user_id, $item['notification_id'], true);
                $restored++;
            } elseif ($item['group_id']) {
                // Restore group
                $wpdb->delete($table, [
                    'user_id' => $user_id,
                    'group_id' => $item['group_id']
                ], ['%d', '%s']);
                
                // Mark all notifications in group as new
                $notifications_table = $wpdb->prefix . 'yooadmin_notifications';
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$notifications_table} 
                     SET status = 'new', updated_at = %s 
                     WHERE user_id = %d AND meta LIKE %s",
                    current_time('mysql'),
                    $user_id,
                    '%"group_id":"' . $wpdb->esc_like($item['group_id']) . '"%'
                ));
                
                $restored++;
            }
        }
        
        return $restored;
    }
    
    /**
     * Restore snoozed notifications (for all users - cron backup)
     */
    public function restore_snoozed_notifications() {
        $to_restore = $this->restore_snoozed_globally();
        $restored = 0;
        
        foreach ($to_restore as $item) {
            if ($item['notification_id']) {
                // Mark as new when restoring from snooze
                $this->restore_notification($item['user_id'], $item['notification_id'], true);
                $restored++;
            } else {
                // Restore group
                global $wpdb;
                $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';
                
                $wpdb->delete($table, [
                    'user_id' => $item['user_id'],
                    'group_id' => $item['group_id']
                ], ['%d', '%s']);
                
                // For groups, we need to mark all notifications in the group as new
                if ($item['group_id']) {
                    $notifications_table = $wpdb->prefix . 'yooadmin_notifications';
                    $wpdb->query($wpdb->prepare(
                        "UPDATE {$notifications_table} 
                         SET status = 'new', updated_at = %s 
                         WHERE user_id = %d AND meta LIKE %s",
                        current_time('mysql'),
                        $item['user_id'],
                        '%"group_id":"' . $wpdb->esc_like($item['group_id']) . '"%'
                    ));
                    
                    // Clear notification caches for this user (use the real
                    // suffixed count keys so persistent object caches are flushed)
                    $this->cache->delete('notifications_' . $item['user_id']);
                    $this->cache->delete('notification_count_' . $item['user_id'] . '_new');
                    $this->cache->delete('notification_count_' . $item['user_id'] . '_read');
                    $this->cache->delete('notification_count_' . $item['user_id'] . '_all');
                    $this->cache->delete('dismissed_notifications_' . $item['user_id']);
                    if (method_exists($this->cache, 'delete_by_pattern')) {
                        $this->cache->delete_by_pattern('notification_count_' . $item['user_id']);
                    }
                }
                $restored++;
            }
        }
        
        return $restored;
    }
    
    /**
     * Get filter statistics
     */
    public function get_filter_stats($user_id) {
        $dismissed = $this->get_dismissed_notifications($user_id);
        $preferences = $this->get_user_preferences($user_id);
        
        return [
            'dismissed_count' => count($dismissed),
            'permanently_dismissed' => count(array_filter($dismissed, function($d) {
                return $d['dismissal_type'] === 'permanent';
            })),
            'snoozed_count' => count(array_filter($dismissed, function($d) {
                return $d['dismissal_type'] === 'snooze';
            })),
            'hidden_priorities' => $preferences['hidden_priorities'],
            'hidden_sources' => $preferences['hidden_sources']
        ];
    }
}

// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter

// Initialize filters
function yooadmin_get_filters() {
    static $filters = null;
    
    if ($filters === null) {
        $filters = new YOOAdmin_Filters();
    }
    
    return $filters;
}
