<?php
/**
 * YOOAdmin - Notifications integration (collection, storage, REST API)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Control logging - keep disabled by default unless explicitly enabled
if (!defined('YOOADMIN_NOTIFICATIONS_DEBUG')) {
    define('YOOADMIN_NOTIFICATIONS_DEBUG', false);
}

if (!function_exists('yooadmin_integration_log')) {
    /**
     * Lightweight logger (disabled in production).
     */
    function yooadmin_integration_log($message)
    { /* no-op */
    }
}

// Load compatibility functions first
require_once __DIR__ . '/compatibility.php';

// Custom cron intervals must be registered on every request (including wp-cron) or reschedule fails with invalid_schedule.
if (!function_exists('yooadmin_register_notification_cron_schedules')) {
    /**
     * @param array<string, array{interval:int, display:string}> $schedules
     * @return array<string, array{interval:int, display:string}>
     */
    function yooadmin_register_notification_cron_schedules(array $schedules): array
    {
        $schedules['yooadmin_6h'] = [
            'interval' => 6 * HOUR_IN_SECONDS,
            'display'    => __('Every 6 hours (YOOAdmin)', 'yooadmin'),
        ];
        $schedules['yooadmin_hourly'] = [
            'interval' => HOUR_IN_SECONDS,
            'display'    => __('Every hour (YOOAdmin)', 'yooadmin'),
        ];

        return $schedules;
    }
}

add_action(
    'after_setup_theme',
    static function (): void {
        add_filter('cron_schedules', 'yooadmin_register_notification_cron_schedules', 5);
    },
    1
);

// Load REST API compatibility endpoints
require_once __DIR__ . '/rest-api-compatibility.php';

// Load cache constants first
require_once __DIR__ . '/cache-constants.php';

// Load core components in correct order with safety checks
(function () {
    $component_files = [
        'storage.php',
        'cache.php',
        'filters.php',
        'collector.php',
        'ui-manager.php'
    ];

    foreach ($component_files as $file) {
        $file_path = __DIR__ . '/' . $file;
        if (file_exists($file_path)) {
            require_once $file_path;
        }
    }
})();

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom notification tables; caching handled by notification cache layer.
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Table names from $wpdb->prefix + hardcoded strings; dynamic WHERE clauses built from whitelisted placeholders.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.SchemaChange -- Table creation required for notification system.
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names from $wpdb->prefix + hardcoded strings; all user input passed through $wpdb->prepare().
class YOOAdmin_Integration
{

    private $collector;
    private $storage;
    private $hash;
    private $filters;
    private $cache;

    public function __construct()
    {
        // Safe initialization with checks
        $this->collector = function_exists('yooadmin_get_collector') ? yooadmin_get_collector() : null;
        $this->storage = function_exists('yooadmin_get_storage') ? yooadmin_get_storage() : null;
        $this->filters = function_exists('yooadmin_get_filters') ? yooadmin_get_filters() : null;
        $this->cache = function_exists('yooadmin_get_cache') ? yooadmin_get_cache() : null;
        $this->hash = null; // Skip hash optimizer for now

        // Initialize only if essential components are available
        if ($this->collector && $this->storage && $this->cache) {
            $this->initialize();
        }
    }

    /**
     * Initialize the new notification system
     */
    public function initialize()
    {
        // Schedule cleanup tasks
        $this->schedule_cleanup_tasks();

        // Register hooks
        $this->register_integration_hooks();

        // Initialize REST API
        $this->initialize_rest_api();
    }

    /**
     * Get notifications for user (main entry point)
     */
    private function localize_notifications_for_ui(array $notifications): array
    {
        if (function_exists('yooadmin_translate_notifications_for_display')) {
            return yooadmin_translate_notifications_for_display($notifications);
        }

        return $notifications;
    }

    public function get_notifications($user_id, $options = [])
    {
        // Don't process notifications if Focus Mode is OFF (e.g., after data cleanup)
        // This prevents any options/transients from being recreated
        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return [];
        }

        $start_time = microtime(true);

        $skip_list_cache = !empty($options['skip_list_cache']);
        unset($options['skip_list_cache']);

        // Check cache first (inbox pagination bypasses — cached pages can truncate lists).
        // The key embeds namespace version tokens (global + per-user) so the list can be
        // invalidated by bumping a token — the only invalidation that is reliable on a
        // persistent object cache (Redis/Memcached), where pattern deletes do not work.
        $cache_key = $this->list_cache_key($user_id, $options);
        $cached    = $skip_list_cache ? null : $this->cache->get($cache_key);

        if ($cached !== null) {
            /**
             * Allow Plus/extensions to rewrite cached notifications (e.g. license copy).
             *
             * @param array<int, array<string, mixed>> $cached
             * @param int $user_id
             * @param array<string, mixed> $options
             */
            $cached = apply_filters('yooadmin_notifications_cached', $cached, $user_id, $options);
            $cached = $this->localize_notifications_for_ui($cached);
            if (function_exists('yooadmin_filter_notifications_by_user_capability')) {
                return yooadmin_filter_notifications_by_user_capability($cached);
            }

            return $cached;
        }

        // STEP 1: Collect new notifications from sources and store them in database
        // This ensures database is up-to-date with latest notifications
        // Force collection ONLY on initial load (once) - then rely on Webhooks
        $last_collection = $this->cache->get(YOOAdmin_Cache_Constants::PREFIX_LAST_COLLECTION . $user_id);
        $force_collection = false;

        // فقط للـ initial load (مرة واحدة)
        if (!$last_collection) {
            $force_collection = true;
            $this->cache->set(YOOAdmin_Cache_Constants::PREFIX_LAST_COLLECTION . $user_id, time(), YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS_COLLECTION);
        }

        // بعدها → الاعتماد فقط على Webhooks (لا Pull تلقائي)

        if ($this->collector) {
            $this->collector->collect_all($user_id, $force_collection);
        }

        // STEP 1.6: Auto-dismiss low priority notifications after 24 hours
        // Run this periodically (not on every request to avoid performance impact)
        $last_auto_dismiss_check = get_transient(YOOAdmin_Cache_Constants::PREFIX_AUTO_DISMISS_CHECK . $user_id);
        if (!$last_auto_dismiss_check) {
            $this->auto_dismiss_low_priority_notifications($user_id);
            set_transient(YOOAdmin_Cache_Constants::PREFIX_AUTO_DISMISS_CHECK . $user_id, time(), YOOAdmin_Cache_Constants::TTL_AUTO_DISMISS_CHECK);
        }

        // STEP 2: Get notifications from database (with actual status: new/read)
        // This ensures we get the real status from database, not just collected data
        $db_notifications = [];
        if ($this->storage) {
            // Special handling for snoozed notifications
            if (isset($options['status']) && $options['status'] === 'snoozed') {
                // Get snoozed notifications from dismissed table
                global $wpdb;
                $now = current_time('mysql');

                // Get snoozed notification IDs
                $snoozed_ids = $wpdb->get_col(
                    $wpdb->prepare(
                    "SELECT notification_id
                        FROM " . $wpdb->prefix . "yooadmin_dismissed_notifications
                        WHERE user_id = %d
                        AND dismissal_type = %s
                        AND snooze_until IS NOT NULL
                        AND snooze_until > %s
                        ORDER BY snooze_until ASC
                        LIMIT %d
                        OFFSET %d",
                    $user_id,
                    'snooze',
                    $now,
                    $options['limit'] ?? 100,
                    $options['offset'] ?? 0
                )
                );

                if (!empty($snoozed_ids)) {
                    // Get actual notifications by IDs
                    $db_options = [
                        'ids' => array_map('intval', $snoozed_ids),
                        'limit' => count($snoozed_ids),
                        'offset' => 0
                    ];
                    $db_notifications = $this->storage->get_for_user($user_id, $db_options);
                }
            }
            else {
                $db_options = array_merge([
                    'status' => null, // Get both new and read
                    'limit' => $options['limit'] ?? 100,
                    'offset' => $options['offset'] ?? 0
                ], $options);

                $db_notifications = $this->storage->get_for_user($user_id, $db_options);
            }

            // Decode meta if it's a JSON string and validate items
            foreach ($db_notifications as &$notification) {
                if (isset($notification['meta']) && is_string($notification['meta'])) {
                    $notification['meta'] = json_decode($notification['meta'], true) ?: [];
                }
                // Ensure meta.id is set from meta array if notification has custom id
                if (empty($notification['meta']['id']) && !empty($notification['id'])) {
                    // Try to extract custom id from meta JSON string if available
                    if (is_string($notification['meta'])) {
                        $decoded = json_decode($notification['meta'], true);
                        if ($decoded && isset($decoded['id'])) {
                            $notification['meta']['id'] = $decoded['id'];
                        }
                    }
                }

                // Validate item existence for plugin/theme updates
                $source_type = $notification['source_type'] ?? '';
                if (in_array($source_type, ['plugin_updates', 'theme_updates'])) {
                    $is_valid = $this->validate_notification_item($notification);
                    if (!$is_valid) {
                        // Mark as invalid (filtered out when show_invalid is false)
                        $this->mark_notification_invalid($notification, $user_id);
                    }
                }
            }
            unset($notification);
        }

        // Apply user preferences for show_invalid and show_archived
        $user_prefs = get_user_meta($user_id, 'yooadmin_notification_preferences', true);
        if (is_array($user_prefs)) {
            if (!isset($options['show_invalid']) && isset($user_prefs['show_invalid'])) {
                $options['show_invalid'] = !empty($user_prefs['show_invalid']);
            }
            if (!isset($options['show_archived']) && isset($user_prefs['show_archived'])) {
                $options['show_archived'] = !empty($user_prefs['show_archived']);
            }
        }

        // If snoozed view, handle via dismissed table directly (skip standard filtering)
        $is_snoozed_view = isset($options['status']) && $options['status'] === 'snoozed';
        if ($is_snoozed_view) {
            // Get active snoozed notification IDs with snooze_until times
            global $wpdb;
            $dismissed_table = $wpdb->prefix . 'yooadmin_dismissed_notifications';
            $now = current_time('mysql');

            $snoozed_rows = $wpdb->get_results($wpdb->prepare("
                SELECT notification_id, snooze_until
                FROM {$dismissed_table}
                WHERE user_id = %d
                  AND dismissal_type = 'snooze'
                  AND snooze_until IS NOT NULL
                  AND snooze_until > %s
            ", $user_id, $now), ARRAY_A);

            if (empty($snoozed_rows)) {
                $this->cache->set($cache_key, [], YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS);
                return [];
            }

            // Build map of notification_id => snooze_until
            $snoozed_map = [];
            $snoozed_ids = [];
            foreach ($snoozed_rows as $row) {
                $nid = intval($row['notification_id'] ?? 0);
                if ($nid > 0) {
                    $snoozed_ids[] = $nid;
                    $snoozed_map[$nid] = $row['snooze_until'];
                }
            }

            // Fetch notifications by IDs
            $db_notifications = $this->storage->get_for_user($user_id, [
                'ids' => $snoozed_ids,
                'limit' => count($snoozed_ids),
                'offset' => 0
            ]);

            // Add snooze_until to each notification
            foreach ($db_notifications as &$notification) {
                $notif_id = intval($notification['id'] ?? 0);
                if (isset($snoozed_map[$notif_id])) {
                    $notification['snooze_until'] = $snoozed_map[$notif_id];
                }

                if (isset($notification['meta']) && is_string($notification['meta'])) {
                    $notification['meta'] = json_decode($notification['meta'], true) ?: [];
                }
                if (empty($notification['meta']['id']) && !empty($notification['id'])) {
                    if (is_string($notification['meta'])) {
                        $decoded = json_decode($notification['meta'], true);
                        if ($decoded && isset($decoded['id'])) {
                            $notification['meta']['id'] = $decoded['id'];
                        }
                    }
                }
            }
            unset($notification);

            // For snoozed, skip grouping/sorting to avoid private methods; return as-is
            $this->cache->set($cache_key, $db_notifications, YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS);
            if (function_exists('yooadmin_filter_notifications_by_user_capability')) {
                $db_notifications = yooadmin_filter_notifications_by_user_capability($db_notifications);
            }
            return $this->localize_notifications_for_ui($db_notifications);
        }

        // Apply filters
        $banner_count_before_filter = count(array_filter($db_notifications, function ($n) {
            return ($n['source_type'] ?? '') === 'banner';
        }));
        $filtered = $this->filters->filter_notifications($user_id, $db_notifications, $options);

        // If NOT snoozed view, exclude items with status 'snoozed' from other tabs
        if (!$is_snoozed_view) {
            $filtered = array_filter($filtered, function ($n) {
                return ($n['status'] ?? '') !== 'snoozed';
            });
        }

        // For snoozed view, keep only still-snoozed items (re-implement here to avoid calling private methods)
        if ($is_snoozed_view) {
            $filtered = $this->filter_snoozed_integration($user_id, $filtered);
        }

        // Count banners after filter (including banners in groups)
        $banner_count_after_filter = 0;
        foreach ($filtered as $item) {
            if (isset($item['type']) && $item['type'] === 'group') {
                // Count banners inside groups
                $banner_count_after_filter += count(array_filter($item['items'] ?? [], function ($n) {
                    return ($n['source_type'] ?? '') === 'banner' ||
                    ($n['source_type'] ?? '') === 'banner-conversion' ||
                    ($n['source_type'] ?? '') === 'wp_admin_banner';
                }));
            }
            else if (($item['source_type'] ?? '') === 'banner' ||
            ($item['source_type'] ?? '') === 'banner-conversion' ||
            ($item['source_type'] ?? '') === 'wp_admin_banner') {
                $banner_count_after_filter++;
            }
        }

        // Cache result (skip when inbox needs the full list in one pass).
        if (!$skip_list_cache) {
            $this->cache->set($cache_key, $filtered, YOOAdmin_Cache_Constants::TTL_NOTIFICATIONS);
        }

        $execution_time = microtime(true) - $start_time;

        if (function_exists('yooadmin_filter_notifications_by_user_capability')) {
            $filtered = yooadmin_filter_notifications_by_user_capability($filtered);
        }

        return $this->localize_notifications_for_ui($filtered);
    }

    /**
     * Get notification count
     * Excludes banner notifications if convert_banners_to_notifications is not enabled
     * Also excludes invalid notifications if show_invalid is disabled (same as display)
     * Uses the same filters as get_notifications to ensure consistency
     */
    public function get_notification_count($user_id, $status = 'new')
    {
        // Don't count notifications if Focus Mode is OFF
        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return 0;
        }

        $cache_key = 'notification_count_' . $user_id . '_' . ($status ?: 'all');

        return $this->cache->remember($cache_key, function () use ($user_id, $status) {
            // Get user preferences for show_invalid (same as get_notifications)
            $user_prefs = get_user_meta($user_id, 'yooadmin_notification_preferences', true);
            $show_invalid = isset($user_prefs['show_invalid']) && !empty($user_prefs['show_invalid']);

            // Check if banner conversion is enabled
            $opts = (array)get_option('yooadmin_panel_options', []);
            if (empty($opts)) {
                $opts = (array)get_option('yooadmin_options', []);
            }
            $convert_banners = isset($opts['convert_banners_to_notifications'])
                ? !empty($opts['convert_banners_to_notifications'])
                : false;

            // Handle special statuses
            if ($status === 'snoozed') {
                // Snoozed uses dismissed table directly to keep counts consistent with view
                $snoozed_ids = $this->get_active_snoozed_ids($user_id);
                if (empty($snoozed_ids)) {
                    return 0;
                }
                $notifications = $this->storage->get_for_user($user_id, [
                    'ids' => array_map('intval', $snoozed_ids),
                    'limit' => count($snoozed_ids),
                    'offset' => 0
                ]);
            }
            elseif (empty($status) || $status === 'all') {
                // All: get all notifications (exclude snoozed)
                $options = [
                    'show_dismissed' => false,
                    'show_expired' => false,
                    'limit' => 1000,
                    'offset' => 0
                ];
                $notifications = $this->get_notifications($user_id, $options);

                // Exclude snoozed items from "all" count
                $notifications = array_filter($notifications, function ($n) {
                            return ($n['status'] ?? '') !== 'snoozed';
                        }
                        );
                    }
                    else {
                        // Use get_notifications with same filters, then count
                        // This ensures count matches what user actually sees
                        $options = [
                            'status' => $status,
                            'show_invalid' => $show_invalid,
                            'show_dismissed' => false, // Don't count dismissed
                            'show_expired' => false, // Don't count expired
                            'limit' => 1000, // Get all to count accurately
                            'offset' => 0
                        ];

                        $notifications = $this->get_notifications($user_id, $options);

                        // Exclude snoozed items from other counts
                        $notifications = array_filter($notifications, function ($n) {
                            return ($n['status'] ?? '') !== 'snoozed';
                        }
                        );
                    }

                    return $this->count_unread_in_feed($notifications, !$convert_banners);
                }, 60); // 1 minute cache
    }

    /**
     * Get active snoozed notification IDs (snooze_until > now)
     */
    private function get_active_snoozed_ids($user_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';
        $now = current_time('mysql');

        $rows = $wpdb->get_results($wpdb->prepare("
            SELECT notification_id
            FROM {$table}
            WHERE user_id = %d
              AND dismissal_type = 'snooze'
              AND snooze_until IS NOT NULL
              AND snooze_until > %s
        ", $user_id, $now), ARRAY_A);

        if (empty($rows)) {
            return [];
        }

        $ids = [];
        foreach ($rows as $row) {
            $nid = intval($row['notification_id'] ?? 0);
            if ($nid > 0) {
                $ids[] = $nid;
            }
        }

        $ids = array_values(array_unique($ids));

        return $ids;
    }

    /**
     * Banner source types stored when admin notices are converted to notifications.
     */
    private function is_banner_source_type($source_type)
    {
        return in_array((string) $source_type, ['banner', 'banner-conversion', 'wp_admin_banner'], true);
    }

    /**
     * Collect database IDs for unread rows from a notification feed (including grouped items).
     *
     * @param array<int, array<string, mixed>> $notifications
     * @return array<int, int>
     */
    private function collect_unread_notification_ids_from_feed(array $notifications)
    {
        $ids = [];

        foreach ($notifications as $notification) {
            if (isset($notification['type']) && $notification['type'] === 'group') {
                foreach ($notification['items'] ?? [] as $item) {
                    if (($item['status'] ?? 'new') !== 'new') {
                        continue;
                    }
                    $id = (int) ($item['id'] ?? 0);
                    if ($id > 0) {
                        $ids[] = $id;
                    }
                }
                continue;
            }

            if (($notification['status'] ?? 'new') !== 'new') {
                continue;
            }

            $id = (int) ($notification['id'] ?? 0);
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * Count unread notifications in a feed (optionally excluding banner rows).
     *
     * @param array<int, array<string, mixed>> $notifications
     */
    private function count_unread_in_feed(array $notifications, $exclude_banners = false)
    {
        $count = 0;

        foreach ($notifications as $item) {
            if (isset($item['type']) && $item['type'] === 'group') {
                foreach ($item['items'] ?? [] as $sub) {
                    if (($sub['status'] ?? '') !== 'new') {
                        continue;
                    }
                    if ($exclude_banners && $this->is_banner_source_type($sub['source_type'] ?? '')) {
                        continue;
                    }
                    $count++;
                }
                continue;
            }

            if (($item['status'] ?? '') !== 'new') {
                continue;
            }
            if ($exclude_banners && $this->is_banner_source_type($item['source_type'] ?? '')) {
                continue;
            }
            $count++;
        }

        return $count;
    }

    /**
     * Public helper: unread database IDs from a notification feed (groups expanded).
     *
     * @param array<int, array<string, mixed>> $notifications
     * @return array<int, int>
     */
    public function collect_unread_ids_from_notifications(array $notifications)
    {
        return $this->collect_unread_notification_ids_from_feed($notifications);
    }

    /**
     * Mark notification as read
     */
    public function mark_as_read($user_id, $notification_id)
    {
        $result = $this->storage->mark_as_read($notification_id, $user_id);

        if ($result) {
            // Clear cache (including count cache)
            $this->clear_user_cache($user_id);
            // Also clear count cache specifically
            $this->cache->delete('notification_count_' . $user_id . '_new');
            $this->cache->delete('notification_count_' . $user_id . '_read');
        }

        return $result;
    }

    /**
     * Mark notification as new (renew/restore)
     * Updates created_at to move notification to top of list
     */
    public function mark_as_new($user_id, $notification_id)
    {
        $result = $this->storage->mark_as_new($notification_id, $user_id);

        if ($result) {
            // Clear cache (including count cache)
            $this->clear_user_cache($user_id);
            // Also clear count cache specifically
            $this->cache->delete('notification_count_' . $user_id . '_new');
            $this->cache->delete('notification_count_' . $user_id . '_read');
        }

        return $result;
    }

    /**
     * Validate if notification item (plugin/theme) still exists
     */
    private function validate_notification_item($notification)
    {
        $source_type = $notification['source_type'] ?? '';
        $meta = $notification['meta'] ?? [];
        $item = $meta['item'] ?? [];

        if ($source_type === 'plugin_updates') {
            $plugin_file = $item['file'] ?? null;
            if (!$plugin_file) {
                return true; // Can't verify, assume valid
            }

            if (!function_exists('get_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }

            $all_plugins = get_plugins();
            return isset($all_plugins[$plugin_file]);

        }
        elseif ($source_type === 'theme_updates') {
            $theme_slug = $item['slug'] ?? null;
            if (!$theme_slug) {
                return true; // Can't verify, assume valid
            }

            $theme = wp_get_theme($theme_slug);
            return $theme->exists();
        }

        // For other types, assume valid
        return true;
    }

    /**
     * Mark notification as invalid (item removed)
     */
    private function mark_notification_invalid($notification, $user_id)
    {
        $notification_id = $notification['id'] ?? null;
        if (!$notification_id) {
            return false;
        }

        $meta = $notification['meta'] ?? [];

        // Save previous status before marking as invalid (for restoration later)
        $current_status = $notification['status'] ?? 'new';
        if (!isset($meta['previous_status'])) {
            $meta['previous_status'] = $current_status;
        }

        $meta['invalid'] = true;
        $meta['item_removed'] = true;
        $meta['invalid_since'] = current_time('mysql');

        $update_data = [
            'meta' => json_encode($meta),
            'updated_at' => current_time('mysql')
        ];

        $result = $this->storage->update($notification_id, $update_data);

        if ($result) {
            $this->clear_user_cache($user_id);
        }

        return $result;
    }

    /**
     * Auto-dismiss low priority notifications after 24 hours
     */
    public function auto_dismiss_low_priority_notifications($user_id = null)
    {
        // Check if auto-dismiss is enabled for this user
        $user_prefs = get_user_meta($user_id ?: get_current_user_id(), 'yooadmin_notification_preferences', true);
        if (empty($user_prefs['auto_dismiss_low'])) {
            return 0; // Feature disabled
        }

        global $wpdb;

        // Get low priority notifications older than 24 hours
        $twenty_four_hours_ago = gmdate('Y-m-d H:i:s', strtotime('-24 hours'));

        if ($user_id) {
            $notifications = $wpdb->get_results(
                $wpdb->prepare(
                "SELECT id FROM " . $wpdb->prefix . "yooadmin_notifications WHERE priority = %s AND status = %s AND user_id = %d AND created_at <= %s",
                'low',
                'new',
                $user_id,
                $twenty_four_hours_ago
            ),
                ARRAY_A
            );
        }
        else {
            $notifications = $wpdb->get_results(
                $wpdb->prepare(
                "SELECT id FROM " . $wpdb->prefix . "yooadmin_notifications WHERE priority = %s AND status = %s AND created_at <= %s",
                'low',
                'new',
                $twenty_four_hours_ago
            ),
                ARRAY_A
            );
        }

        if (empty($notifications)) {
            return 0;
        }

        $dismissed_count = 0;
        $notification_ids = array_column($notifications, 'id');

        // Dismiss all low priority notifications older than 24 hours
        $target_user_id = $user_id ?: get_current_user_id();
        foreach ($notification_ids as $notification_id) {
            $result = $this->dismiss_notification($target_user_id, $notification_id, 'dismiss');
            if ($result) {
                $dismissed_count++;
            }
        }

        if ($dismissed_count > 0 && $user_id) {
            $this->clear_user_cache($user_id);
        }

        return $dismissed_count;
    }

    /**
     * Mark multiple notifications as read
     */
    public function mark_multiple_as_read($user_id, $notification_ids)
    {
        $result = $this->storage->mark_multiple_as_read($notification_ids, $user_id);

        if ($result) {
            $this->clear_user_cache($user_id);
            $this->cache->delete('notification_count_' . $user_id . '_new');
            $this->cache->delete('notification_count_' . $user_id . '_read');
        }

        return $result;
    }

    /**
     * Dismiss notification
     */
    public function dismiss_notification($user_id, $notification_id, $type = 'dismiss', $snooze_until = null)
    {
        // REST/JS often sends type=permanent for "delete". That must remove the row from yooadmin_notifications,
        // not only add a dismissed_notifications record (which hides the item but leaves the DB row).
        // delete_notification() now writes the tombstone itself, so just delegate.
        if ($type === 'permanent' && $user_id > 0) {
            $deleted = $this->delete_notification($user_id, $notification_id);
            if ($deleted) {
                return true;
            }
        }

        $result = $this->filters->dismiss_notification($user_id, $notification_id, $type, $snooze_until);

        if ($result) {
            // Clear cache
            $this->clear_user_cache($user_id);
        }

        return $result;
    }

    /**
     * Delete notification permanently
     */
    public function delete_notification($user_id, $notification_id)
    {
        // Write a condition-aware tombstone (dedupe_key + fingerprint) BEFORE removing the
        // row, while it still exists. This is what stops a live-state notification or a
        // re-injected admin banner from being immediately re-created on the next page load
        // ("I deleted it and it came back"). It stays hidden until its condition changes.
        if ($this->filters && method_exists($this->filters, 'dismiss_notification') && (int) $user_id > 0) {
            $this->filters->dismiss_notification($user_id, $notification_id, 'permanent');
        }

        $result = $this->storage->delete_notification($notification_id, $user_id);

        if ($result) {
            // Clear cache
            $this->cache->delete('notification_count_' . $user_id . '_new');
            $this->cache->delete('notification_count_' . $user_id . '_read');
            $this->cache->delete_by_pattern('notifications_' . $user_id . '_');
            $this->clear_user_cache($user_id);
        }

        return $result;
    }

    /**
     * Delete multiple notifications permanently
     */
    public function delete_multiple_notifications($user_id, $notification_ids)
    {
        // Tombstone each row before deletion (same guarantee as single delete) so
        // none of them silently re-appear on the next collection / page load.
        $count = 0;
        foreach ((array) $notification_ids as $notification_id) {
            $notification_id = intval($notification_id);
            if ($notification_id > 0 && $this->delete_notification($user_id, $notification_id)) {
                $count++;
            }
        }

        if ($count > 0) {
            // Clear cache
            $this->cache->delete('notification_count_' . $user_id . '_new');
            $this->cache->delete('notification_count_' . $user_id . '_read');
            $this->cache->delete_by_pattern('notifications_' . $user_id . '_');
        }

        return $count;
    }

    /**
     * Dismiss notification group
     */
    public function dismiss_group($user_id, $group_id, $type = 'dismiss', $snooze_until = null)
    {
        $result = $this->filters->dismiss_group($user_id, $group_id, $type, $snooze_until);

        if ($result) {
            // Clear cache
            $this->clear_user_cache($user_id);
        }

        return $result;
    }

    /**
     * Create notification
     */
    public function create_notification($user_id, $data)
    {
        $result = $this->storage->create(array_merge($data, ['user_id' => $user_id]));

        if ($result) {
            // Clear cache
            $this->clear_user_cache($user_id);
        }

        return $result;
    }

    /**
     * Get notifications feed (for API)
     */
    public function get_notifications_feed($user_id)
    {
        $notifications = $this->get_notifications($user_id);
        $hash = $this->hash ? $this->hash->generate($notifications) : md5(serialize($notifications));

        return [
            'notifications' => $notifications,
            'hash' => $hash,
            'count' => count($notifications),
            'unread_count' => $this->get_notification_count($user_id),
            'timestamp' => current_time('mysql')
        ];
    }

    /**
     * Check for updates (trigger check)
     */
    public function check_for_updates($user_id)
    {
        $old_hash = $this->hash ? $this->hash->get_cached_hash($user_id) : null;

        // Force collection
        $notifications = $this->collector->collect_all($user_id);
        $new_hash = $this->hash ? $this->hash->generate($notifications) : md5(serialize($notifications));

        $has_updates = $old_hash !== $new_hash;

        if ($has_updates) {
            // Clear cache
            $this->clear_user_cache($user_id);
        }

        return [
            'has_updates' => $has_updates,
            'old_hash' => $old_hash,
            'new_hash' => $new_hash,
            'count' => count($notifications)
        ];
    }

    /**
     * Register integration hooks
     */
    private function register_integration_hooks()
    {
        // Cache invalidation hooks
        add_action('yooadmin_notification_created', [$this, 'invalidate_cache_on_notification_created'], 10, 3);
        add_action('yooadmin_notification_updated', [$this, 'invalidate_cache_on_notification_updated'], 10, 3);
        add_action('yooadmin_notification_read', [$this, 'invalidate_cache_on_notification_read'], 10, 2);
        // WordPress updates
        add_action('upgrader_process_complete', [$this, 'handle_wordpress_updates'], 10, 2);

        // Plugin/theme changes
        add_action('activated_plugin', [$this, 'handle_plugin_activation']);
        add_action('deactivated_plugin', [$this, 'handle_plugin_deactivation']);
        add_action('switch_theme', [$this, 'handle_theme_switch']);

        // Comment events
        add_action('wp_insert_comment', [$this, 'handle_new_comment']);
        add_action('transition_comment_status', [$this, 'handle_comment_status_change'], 10, 3);

        // License events
        add_action('yooadmin_license_activated', [$this, 'handle_license_activated']);
        add_action('yooadmin_license_deactivated', [$this, 'handle_license_deactivated']);

        // User events
        add_action('wp_login', [$this, 'handle_user_login'], 10, 2);
        add_action('user_register', [$this, 'handle_user_register']);

        // Professional banner interception using Output Buffering (PHP-based, not JavaScript)
        // This is more reliable and professional than JavaScript DOM manipulation
        $opts = (array)get_option('yooadmin_options', []);
        $convert_banners = !empty($opts['convert_banners_to_notifications']);

        if ($convert_banners) {
            // NOTE: Banner conversion is handled by the JavaScript path
            // (assets/js/admin/yp-admin-utilities.js -> REST /notifications/banner ->
            // rest_save_banner_notification), which sees the actually-rendered DOM and
            // also hides the original banner. Running this server-side admin_footer
            // capture in parallel produced a SECOND notification for the same banner
            // (with a different identity), which both duplicated banners and broke
            // "delete stays deleted" (deleting one system's row didn't stop the other
            // from re-creating it). Keep a single capture path. Re-enable only if the
            // JS path is intentionally disabled.
            // add_action('admin_footer', [$this, 'capture_banners_from_dom'], 999);
        }

        // Inbox load-more must work even if rest_api_init order differs on admin-ajax.
        add_action('wp_ajax_yooadmin_load_more_notifications', [$this, 'ajax_load_more_notifications']);
    }

    /**
     * Handle WordPress updates
     */
    public function handle_wordpress_updates($upgrader_object, $options)
    {
        if (isset($options['type']) && $options['type'] === 'core') {
            // Clear all caches
            $this->cache->clear();
        }
    }

    /**
     * Handle plugin activation
     */
    public function handle_plugin_activation($plugin)
    {
        $this->cache->delete_by_pattern('plugin_updates');
    }

    /**
     * Handle plugin deactivation
     */
    public function handle_plugin_deactivation($plugin)
    {
        $this->cache->delete_by_pattern('plugin_updates');
    }

    /**
     * Handle theme switch
     */
    public function handle_theme_switch($new_theme)
    {
        $this->cache->delete_by_pattern('theme_updates');
    }

    /**
     * Handle new comment
     */
    public function handle_new_comment($comment_id)
    {
        $comment = get_comment($comment_id);

        if ($comment && $comment->comment_approved === '0') {
            // Clear comment caches
            $this->cache->delete_by_pattern('pending_comments');
        }
    }

    /**
     * Handle comment status change
     */
    public function handle_comment_status_change($new_status, $old_status, $comment)
    {
        if ($new_status !== $old_status) {
            // Clear comment caches
            $this->cache->delete_by_pattern('pending_comments');
            $this->cache->delete_by_pattern('spam_comments');
        }
    }

    /**
     * Handle license activation
     */
    public function handle_license_activated()
    {
        // Clear license cache
        $this->cache->delete('license_status');

        // Clear all user caches
        $this->clear_all_user_caches();
    }

    /**
     * Handle license deactivation
     */
    public function handle_license_deactivated()
    {
        // Clear license cache
        $this->cache->delete('license_status');

        // Clear all user caches
        $this->clear_all_user_caches();
    }

    /**
     * Handle user login
     */
    public function handle_user_login($user_login, $user)
    {
        // Clear user's cache
        $this->clear_user_cache($user->ID);

        // Warm up cache for this user
        $this->collector->collect_all($user->ID);
    }

    /**
     * Handle user registration
     */
    public function handle_user_register($user_id)
    {
        // Create welcome notification
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $this->create_notification($user_id, [
            'type' => 'success',
            'title' => __('Welcome to YOOAdmin!', 'yooadmin'),
            'message' => __('Thanks for joining! Explore our features and settings.', 'yooadmin'),
            'priority' => 'medium',
            'source' => 'yooadmin',
            'source_type' => 'user_welcome',
            'url' => admin_url('admin.php?page=yooadmin-dashboard'),
            'icon' => 'dashicons-smiley',
            'meta' => [
                'id' => 'yooadmin_user_welcome',
            ],
        ]);
    }

    /**
     * Initialize REST API
     */
    private function initialize_rest_api()
    {
        // Prevent multiple REST API initializations
        static $rest_api_initialized = false;

        if ($rest_api_initialized) {
            return; // Already initialized
        }

        $rest_api_initialized = true;

        // Register REST routes - use both init and rest_api_init for maximum compatibility
        $register_routes = function () {
        // Prevent duplicate route registration
            static $routes_registered = false;

            if ($routes_registered) {
                return; // Routes already registered
            }

            $routes_registered = true;

            // Get integration instance (use function to ensure we get the right instance)
            $integration = function_exists('yooadmin_get_integration') ? yooadmin_get_integration() : null;

            if (!$integration) {
                return;
            }

            // Get notifications
            register_rest_route('yooadmin/v1', '/notifications', [
                'methods' => 'GET',
                'callback' => [$integration, 'rest_get_notifications'],
                'permission_callback' => [$integration, 'rest_permissions_check']
            ]);

            // Get notifications feed
            register_rest_route('yooadmin/v1', '/notifications/feed', [
                'methods' => 'GET',
                'callback' => [$integration, 'rest_get_notifications_feed'],
                'permission_callback' => [$integration, 'rest_permissions_check']
            ]);

            // Mark as read
            register_rest_route('yooadmin/v1', '/notifications/(?P<id>\d+)/read', [
                'methods' => 'POST',
                'callback' => [$integration, 'rest_mark_as_read'],
                'permission_callback' => [$integration, 'rest_permissions_check']
            ]);

            // Dismiss notification
            register_rest_route('yooadmin/v1', '/notifications/(?P<id>\d+)/dismiss', [
                'methods' => 'POST',
                'callback' => [$integration, 'rest_dismiss_notification'],
                'permission_callback' => [$integration, 'rest_permissions_check']
            ]);

            // Mark all notifications as read
            register_rest_route('yooadmin/v1', '/notifications/mark-all-read', [
                'methods' => 'POST',
                'callback' => [$integration, 'rest_mark_all_as_read'],
                'permission_callback' => [$integration, 'rest_permissions_check']
            ]);

            // Force refresh notifications (bypass cache)
            register_rest_route('yooadmin/v1', '/notifications/refresh', [
                'methods' => 'POST',
                'callback' => [$integration, 'rest_force_refresh'],
                'permission_callback' => [$integration, 'rest_permissions_check']
            ]);

            // Save banner as notification (from JavaScript)
            register_rest_route('yooadmin/v1', '/notifications/banner', [
                'methods' => 'POST',
                'callback' => [$integration, 'rest_save_banner_notification'],
                'permission_callback' => [$integration, 'rest_permissions_check']
            ]);

            // Block sender endpoints: Extended only (Lite has no Block Sender UI)

            // Get counts
            register_rest_route('yooadmin/v1', '/notifications/counts', [
                'methods' => 'GET',
                'callback' => [$integration, 'rest_get_counts'],
                'permission_callback' => [$integration, 'rest_permissions_check']
            ]);

        };

        // Register on rest_api_init (standard way)
        add_action('rest_api_init', $register_routes, 10);

        // Also register on init for early registration (if REST API is already loaded)
        if (did_action('rest_api_init')) {
            $register_routes();
        }

        // Fallback: register on init hook as well (for maximum compatibility)
        add_action('init', function () use ($register_routes) {
            if (did_action('rest_api_init')) {
                $register_routes();
            }
        }, 20);

    }

    /**
     * Register REST routes immediately (for late registration)
     */
    private function register_rest_routes_immediately()
    {
        // Get notifications
        register_rest_route('yooadmin/v1', '/notifications', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_get_notifications'],
            'permission_callback' => [$this, 'rest_permissions_check']
        ]);

        // Get notifications feed
        register_rest_route('yooadmin/v1', '/notifications/feed', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_get_notifications_feed'],
            'permission_callback' => [$this, 'rest_permissions_check']
        ]);

        // Force refresh notifications (bypass cache)
        register_rest_route('yooadmin/v1', '/notifications/refresh', [
            'methods' => 'POST',
            'callback' => [$this, 'rest_force_refresh'],
            'permission_callback' => [$this, 'rest_permissions_check']
        ]);
    }

    /**
     * REST API: Permissions check
     */
    public function rest_permissions_check($request = null)
    {
        if (!is_user_logged_in()) {
            return new \WP_Error(
                'rest_not_logged_in',
                __('You must be logged in to access this endpoint.', 'yooadmin'),
                ['status' => 401]
            );
        }

        $cap = function_exists('yooadmin_notification_preferences_capability')
            ? yooadmin_notification_preferences_capability()
            : 'read';

        if (!current_user_can($cap)) {
            return new \WP_Error(
                'rest_forbidden',
                __('Sorry, you are not allowed to do that.', 'yooadmin'),
                ['status' => 403]
            );
        }

        // Require valid nonce for all cookie-authenticated requests (prevents CSRF)
        if ($request && method_exists($request, 'get_header')) {
            $nonce = $request->get_header('X-WP-Nonce');
            if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
                return new \WP_Error(
                    'rest_cookie_invalid_nonce',
                    __('Invalid nonce. Please reload the page and try again.', 'yooadmin'),
                    ['status' => 403]
                );
            }
        }

        return true;
    }

    /**
     * @param array $list
     * @return array
     */
    private function sanitize_notifications_for_rest_output($list)
    {
        if (!is_array($list)) {
            return [];
        }
        $out = [];
        foreach ($list as $n) {
            if (!is_array($n)) {
                continue;
            }
            $out[] = $this->sanitize_single_notification_for_rest_output($n);
        }
        return $out;
    }

    /**
     * @param array $n
     * @return array
     */
    private function sanitize_single_notification_for_rest_output(array $n)
    {
        if (!empty($n['message']) && is_string($n['message'])) {
            $n['message'] = wp_kses_post($n['message']);
        }
        if (!empty($n['description']) && is_string($n['description'])) {
            $n['description'] = wp_kses_post($n['description']);
        }
        if (!empty($n['title']) && is_string($n['title'])) {
            $n['title'] = wp_kses_post($n['title']);
        }
        if (!empty($n['items']) && is_array($n['items'])) {
            foreach ($n['items'] as $i => $item) {
                if (is_array($item)) {
                    $n['items'][$i] = $this->sanitize_single_notification_for_rest_output($item);
                }
            }
        }
        return $n;
    }

    /**
     * Flatten grouped rows for inbox-style lists.
     *
     * @param array<int, array<string, mixed>> $notifications
     * @return array<int, array<string, mixed>>
     */
    private function flatten_notifications_list(array $notifications): array
    {
        $flat = [];

        foreach ($notifications as $notification) {
            if (isset($notification['type']) && $notification['type'] === 'group') {
                foreach ($notification['items'] ?? [] as $item) {
                    if (is_array($item)) {
                        $flat[] = $item;
                    }
                }
            } else {
                $flat[] = $notification;
            }
        }

        return $flat;
    }

    /**
     * Paginate inbox rows after flattening groups (Plus inbox + AJAX load more).
     *
     * @return array{items: array<int, array<string, mixed>>, has_more: bool, count: int}
     */
    public function get_notifications_flat_page(int $user_id, array $options, int $flat_offset, int $page_limit): array
    {
        $page_limit  = max(1, min(200, $page_limit));
        $flat_offset = max(0, $flat_offset);

        // Load a stable flattened list (grouping before flatten; skip cache to avoid truncated pages).
        $fetch_options                 = $options;
        $fetch_options['limit']        = 1000;
        $fetch_options['offset']       = 0;
        $fetch_options['skip_list_cache'] = true;
        $flat                          = $this->flatten_notifications_list(
            $this->get_notifications($user_id, $fetch_options)
        );

        $items    = array_slice($flat, $flat_offset, $page_limit);
        $has_more = count($flat) > ($flat_offset + count($items));

        return [
            'items'    => $items,
            'has_more' => $has_more,
            'count'    => count($items),
            'total'    => count($flat),
        ];
    }

    /**
     * Paginate notifications after filter/group (DB limit alone under-counts rows).
     *
     * @return array{items: array<int, array<string, mixed>>, has_more: bool, next_offset: int}
     */
    private function get_notifications_display_page(int $user_id, array $options, int $display_offset, int $page_limit): array
    {
        $want      = $page_limit + 1;
        $collected = [];
        $skipped   = 0;
        $db_offset = 0;
        $batch     = max(50, ($display_offset + $page_limit) * 5);
        $guard     = 0;
        $max_loops = 25;

        while (count($collected) < $want && $guard < $max_loops) {
            $guard++;
            $batch_options           = $options;
            $batch_options['limit']  = $batch;
            $batch_options['offset'] = $db_offset;
            $chunk                   = $this->get_notifications($user_id, $batch_options);

            if ($chunk === []) {
                break;
            }

            foreach ($chunk as $row) {
                if ($skipped < $display_offset) {
                    $skipped++;
                    continue;
                }
                $collected[] = $row;
                if (count($collected) >= $want) {
                    break 2;
                }
            }

            if (count($chunk) < $batch) {
                break;
            }

            $db_offset += $batch;
        }

        $has_more = count($collected) > $page_limit;
        $items    = array_slice($collected, 0, $page_limit);

        return [
            'items'       => $items,
            'has_more'    => $has_more,
            'next_offset' => $display_offset + count($items),
        ];
    }

    /**
     * REST API: Get notifications
     */
    public function rest_get_notifications($request)
    {
        try {
            $user_id = get_current_user_id();
            $options = $request->get_params();

            // Restore expired snoozes for this user (same as new notifications detection)
            $this->restore_expired_snoozes_for_user($user_id);

            $offset          = isset($options['offset']) ? max(0, (int) $options['offset']) : 0;
            $requested_limit = isset($options['limit']) ? (int) $options['limit'] : 0;
            $has_more        = false;

            if ($requested_limit > 0) {
                $page_limit = max(1, min(200, $requested_limit));
                unset($options['limit'], $options['offset']);
                $page          = $this->get_notifications_flat_page($user_id, $options, $offset, $page_limit);
                $notifications = $page['items'];
                $has_more      = $page['has_more'];
                $offset        = $offset + (int) $page['count'];
            } else {
                $notifications = $this->get_notifications($user_id, $options);
            }

            // Ensure we return an array
            if (!is_array($notifications)) {
                $notifications = [];
            }

            $notifications = $this->sanitize_notifications_for_rest_output($notifications);

            // Get unread count from database
            $unread_count = $this->get_notification_count($user_id, 'new');

            $payload = [
                'success' => true,
                'data' => $notifications,
                'count' => count($notifications),
                'has_more' => $has_more,
                'offset' => $offset,
                'unread_count' => $unread_count,
                'timestamp' => current_time('mysql')
            ];

            if ($requested_limit > 0 && isset($page['total'])) {
                $payload['total'] = (int) $page['total'];
            }

            return rest_ensure_response($payload);
        }
        catch (Exception $e) {
            return rest_ensure_response([
                'success' => false,
                'data' => [],
                'error' => $e->getMessage(),
                'count' => 0,
                'timestamp' => current_time('mysql')
            ]);
        }
    }

    /**
     * REST API: Get notifications feed
     */
    public function rest_get_notifications_feed($request)
    {
        try {
            $user_id = get_current_user_id();

            $feed = $this->get_notifications_feed($user_id);
            if (isset($feed['notifications']) && is_array($feed['notifications'])) {
                $feed['notifications'] = $this->sanitize_notifications_for_rest_output($feed['notifications']);
            }

            return rest_ensure_response($feed);
        }
        catch (Exception $e) {
            return rest_ensure_response([
                'error' => $e->getMessage(),
                'notifications' => [],
                'hash' => '',
                'count' => 0,
                'unread_count' => 0,
                'timestamp' => current_time('mysql')
            ]);
        }
    }

    /**
     * REST API: Mark as read
     */
    public function rest_mark_as_read($request)
    {
        try {
            $user_id = get_current_user_id();
            $notification_id = isset($request['id']) ? intval($request['id']) : 0;

            if ($notification_id <= 0) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'Invalid notification ID'
                ], 400);
            }

            if ($user_id <= 0) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'User not logged in'
                ], 401);
            }

            $result = $this->mark_as_read($user_id, $notification_id);

            if ($result === false) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'Failed to mark notification as read'
                ], 500);
            }

            return rest_ensure_response([
                'success' => $result !== false,
                'rows_affected' => $result
            ]);
        }
        catch (Exception $e) {
            return rest_ensure_response([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * REST API: Dismiss notification
     */
    public function rest_dismiss_notification($request)
    {
        try {
            $user_id = get_current_user_id();
            $notification_id = $request['id'];
            $params = $request->get_json_params();

            $type = $params['type'] ?? 'dismiss';
            $snooze_until = $params['snooze_until'] ?? null;

            $result = $this->dismiss_notification($user_id, $notification_id, $type, $snooze_until);

            return rest_ensure_response(['success' => $result]);
        }
        catch (Exception $e) {
            return rest_ensure_response([
                'success' => false,
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * REST API: Mark all notifications as read
     */
    public function rest_mark_all_as_read($request)
    {
        try {
            $user_id = get_current_user_id();

            if ($user_id <= 0) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'User not logged in'
                ], 401);
            }

            $params = $request->get_json_params();

            // Get notification IDs from request (optional - if not provided, mark all unread)
            $notification_ids = $params['notification_ids'] ?? null;

            if ($notification_ids && is_array($notification_ids)) {
                // Mark specific notifications as read
                $notification_ids = array_map('intval', $notification_ids);
                $notification_ids = array_filter($notification_ids, function ($id) {
                    return $id > 0;
                });

                if (empty($notification_ids)) {
                    return rest_ensure_response([
                        'success' => false,
                        'error' => 'No valid notification IDs provided',
                        'marked_count' => 0
                    ]);
                }

                $result = $this->mark_multiple_as_read($user_id, $notification_ids);

                if ($result === false) {
                    return rest_ensure_response([
                        'success' => false,
                        'error' => 'Failed to mark notifications as read. Please check server logs.',
                        'marked_count' => 0
                    ], 500);
                }

                return rest_ensure_response([
                    'success' => true,
                    'marked_count' => $result
                ]);
            }
            else {
                // Mark all unread notifications as read (including items inside groups).
                $notifications = $this->get_notifications($user_id, [
                    'status' => 'new',
                    'limit' => 1000,
                    'offset' => 0,
                ]);
                $unread_ids = $this->collect_unread_notification_ids_from_feed($notifications);

                if (empty($unread_ids)) {
                    return rest_ensure_response([
                        'success' => true,
                        'marked_count' => 0,
                        'message' => 'No unread notifications to mark as read'
                    ]);
                }

                $result = $this->mark_multiple_as_read($user_id, $unread_ids);

                if ($result === false) {
                    return rest_ensure_response([
                        'success' => false,
                        'error' => 'Failed to mark notifications as read. Please check server logs.',
                        'marked_count' => 0
                    ], 500);
                }

                return rest_ensure_response([
                    'success' => true,
                    'marked_count' => $result
                ]);
            }
        }
        catch (Exception $e) {
            return rest_ensure_response([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * REST API: Check updates
     */
    public function rest_check_updates($request)
    {
        try {
            $user_id = get_current_user_id();

            $has_updates = $this->check_for_updates($user_id);

            return rest_ensure_response([
                'has_updates' => $has_updates,
                'timestamp' => current_time('mysql')
            ]);
        }
        catch (Exception $e) {
            return rest_ensure_response([
                'has_updates' => false,
                'error' => $e->getMessage(),
                'timestamp' => current_time('mysql')
            ]);
        }
    }

    /**
     * REST API: Save banner as notification (from JavaScript)
     */
    public function rest_save_banner_notification($request)
    {
        try {
            $user_id = get_current_user_id();

            if ($user_id <= 0) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'User not logged in'
                ], 401);
            }

            // Check if banner conversion is enabled (same sources as assets/header).
            $opts = function_exists('yooadmin_get_options')
                ? (array) yooadmin_get_options()
                : (array) get_option('yooadmin_options', []);
            $panel_opts = (array) get_option('yooadmin_panel_options', []);
            if (!empty($panel_opts)) {
                $opts = array_merge($opts, $panel_opts);
            }
            $convert_banners = !empty($opts['convert_banners_to_notifications']);

            if (!$convert_banners) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'Banner conversion is disabled'
                ], 403);
            }

            if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'Focus Mode is disabled'
                ], 403);
            }

            if (!$this->storage || !$this->storage->ensure_notifications_tables()) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'Notifications storage unavailable'
                ], 503);
            }

            $params = $request->get_json_params();

            // Validate required fields
            if (empty($params['banner_id']) || empty($params['title'])) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'Missing required fields: banner_id, title'
                ], 400);
            }

            $banner_id = sanitize_text_field($params['banner_id']);
            $title = sanitize_text_field($params['title']);
            $message = isset($params['message']) ? sanitize_textarea_field($params['message']) : '';
            $banner_type = isset($params['type']) ? sanitize_text_field($params['type']) : 'notice';
            $url = isset($params['url']) ? esc_url_raw($params['url']) : '';
            $html = isset($params['html']) ? wp_kses_post($params['html']) : '';
            $page = isset($params['page']) ? sanitize_text_field($params['page']) : '';
            $classes = isset($params['classes']) ? sanitize_text_field($params['classes']) : '';
            $component_name = isset($params['component_name']) ? sanitize_text_field($params['component_name']) : '';
            if ($component_name === '') {
                $component_name = $this->infer_banner_component_name($banner_id, $classes, $title . ' ' . $message);
            }
            $source_label = $component_name !== '' ? $component_name : __('WordPress Admin', 'yooadmin');

            // Extract URLs array from banner data (with text labels)
            $urls = [];
            if (isset($params['urls']) && is_array($params['urls'])) {
                foreach ($params['urls'] as $url_item) {
                    if (isset($url_item['url']) && !empty($url_item['url'])) {
                        $clean_url = esc_url_raw($url_item['url']);
                        $clean_text = isset($url_item['text']) ? sanitize_text_field($url_item['text']) : 'View';

                        // Check for duplicates
                        $is_duplicate = false;
                        foreach ($urls as $existing_url) {
                            if ($existing_url['url'] === $clean_url) {
                                $is_duplicate = true;
                                break;
                            }
                        }

                        if (!$is_duplicate && $clean_url !== '#' && $clean_url !== 'javascript:void(0)') {
                            $urls[] = [
                                'url' => $clean_url,
                                'text' => $clean_text ?: 'View'
                            ];
                        }
                    }
                }
            }

            // If no URLs array but we have single URL, create array from it
            if (empty($urls) && !empty($url)) {
                $urls[] = [
                    'url' => $url,
                    'text' => 'View'
                ];
            }

            // Determine priority and icon from banner type
            $priority = 'medium';
            $icon = 'dashicons-megaphone';

            switch ($banner_type) {
                case 'error':
                    $priority = 'high';
                    $icon = 'dashicons-warning';
                    break;
                case 'update':
                    $priority = 'high';
                    $icon = 'dashicons-update';
                    break;
                case 'warning':
                    $priority = 'medium';
                    $icon = 'dashicons-flag';
                    break;
                case 'success':
                    $priority = 'low';
                    $icon = 'dashicons-yes-alt';
                    break;
            }

            // Extract sender from banner (plugin/theme name or banner source)
            $sender = 'banner_' . $banner_id;
            if ($component_name !== '') {
                $sender = 'plugin_' . sanitize_key($component_name);
            }
            if (!empty($classes)) {
                // Try to extract plugin/theme name from classes
                if (preg_match('/plugin-([a-z0-9\-]+)/i', $classes, $matches)) {
                    $sender = 'plugin_' . $matches[1];
                }
                elseif (preg_match('/theme-([a-z0-9\-]+)/i', $classes, $matches)) {
                    $sender = 'theme_' . $matches[1];
                }
                elseif (preg_match('/([a-z0-9\-]+)-admin-notice/i', $classes, $matches)) {
                    $sender = 'plugin_' . $matches[1];
                }
            }

            // Canonical, content-based identity (path-independent). Falls back to the
            // client id only when title+message are empty.
            $canonical_id = $this->canonical_banner_dedupe_key($title, $message);
            $identity_id = $canonical_id !== '' ? $canonical_id : 'banner_' . $banner_id;

            // If the user already deleted (or snoozed) this banner, do NOT recreate it.
            if ($canonical_id !== '' && $this->is_dedupe_tombstoned($user_id, $canonical_id)) {
                return rest_ensure_response([
                    'success' => true,
                    'action'  => 'skipped_dismissed'
                ]);
            }

            // Check if banner notification already exists
        // Search by multiple criteria to prevent duplicates after version updates
            // 1. First, try exact match by meta.id
            $existing = $this->storage->get_for_user($user_id, [
                'id' => $identity_id,
                'source_type' => 'banner', // Also filter by source_type to ensure we only get banners
                'limit' => 10 // Get more to check for duplicates
            ]);

            // Filter to find exact match by meta.id
            $exact_match = null;
            foreach ($existing as $notif) {
                $meta_id = $notif['meta']['id'] ?? null;
                if ($meta_id === $identity_id) {
                    $exact_match = $notif;
                    break;
                }
            }

            // 2. If no exact match, try to find by title + message similarity (for version updates)
            // This prevents duplicates when banner_id changes after version update
            if (!$exact_match) {
                $all_banners = $this->storage->get_for_user($user_id, [
                    'source_type' => 'banner',
                    'limit' => 100 // Get all banners to check for similarity
                ]);

                // Normalize title and message for comparison (remove extra spaces, lowercase)
                $normalized_title = strtolower(trim(preg_replace('/\s+/', ' ', $title)));
                $normalized_message = strtolower(trim(preg_replace('/\s+/', ' ', $message)));

                foreach ($all_banners as $notif) {
                    $notif_title = strtolower(trim(preg_replace('/\s+/', ' ', $notif['title'] ?? '')));
                    $notif_message = strtolower(trim(preg_replace('/\s+/', ' ', $notif['message'] ?? '')));

                    // Check if title matches (exact or very similar - 90% similarity)
                    $title_similarity = 0;
                    if (!empty($normalized_title) && !empty($notif_title)) {
                        similar_text($normalized_title, $notif_title, $title_similarity);
                    }

                    // Check if message matches (exact or very similar - 85% similarity)
                    $message_similarity = 0;
                    if (!empty($normalized_message) && !empty($notif_message)) {
                        similar_text($normalized_message, $notif_message, $message_similarity);
                    }

                    // If title is very similar (90%+) and message is similar (85%+), consider it a match
                    // OR if title matches exactly and message is similar (80%+)
                    if (($title_similarity >= 90 && $message_similarity >= 85) ||
                    ($title_similarity >= 100 && $message_similarity >= 80)) {
                        $exact_match = $notif;
                        break;
                    }
                }
            }

            if ($exact_match) {
                // Update existing notification
        // Preserve existing status (read stays read, new stays new)
                // This ensures that updating a banner after version update doesn't reset its read status
                $notification_id = $exact_match['id'];
                $existing_status = $exact_match['status'] ?? 'new';


                $update_data = [
                    'title' => $title,
                    'message' => $message,
                    'url' => $url,
                    'priority' => $priority,
                    'source' => $source_label,
                    'dedupe_key' => $identity_id,
                    'sender' => $sender, // Update sender if changed
                    'meta' => json_encode([
                        'id' => $identity_id,
                        'banner_id' => $banner_id,
                        'banner_type' => $banner_type,
                        'original_html' => substr($html, 0, 1000),
                        'page' => $page,
                        'classes' => $classes,
                        'converted_at' => current_time('mysql'),
                        'urls' => $urls, // Store all URLs with their text labels
                        'component_name' => $component_name // Store component name for better sender labeling
                    ]),
                    'updated_at' => current_time('mysql')
                ];

                // Preserve existing status - do NOT change read/unread status
                // Only update status if it's missing (shouldn't happen, but safety check)
                if (empty($existing_status)) {
                    $update_data['status'] = 'new';
                }
                // Otherwise, status is preserved automatically by not including it in update_data

                $this->storage->update($notification_id, $update_data);


                return rest_ensure_response([
                    'success' => true,
                    'notification_id' => $notification_id,
                    'action' => 'updated',
                    'status_preserved' => $existing_status
                ]);
            }
            else {
                // Check if there are duplicate banners with similar IDs (for debugging)
                $all_banners = $this->storage->get_for_user($user_id, [
                    'source_type' => 'banner',
                    'limit' => 100
                ]);
                $similar_banners = array_filter($all_banners, function ($n) use ($banner_id) {
                    $meta_banner_id = $n['meta']['banner_id'] ?? null;
                    return $meta_banner_id === $banner_id ||
                    (is_string($meta_banner_id) && strpos($meta_banner_id, $banner_id) !== false) ||
                    (is_string($banner_id) && strpos($banner_id, $meta_banner_id) !== false);
                });

                if (count($similar_banners) > 0) {
                    foreach ($similar_banners as $idx => $sim) {
                    }
                }

                // Create new notification
                $notification_data = [
                    'user_id' => $user_id,
                    'title' => $title,
                    'message' => $message,
                    'type' => 'info',
                    'priority' => $priority,
                    'source' => $source_label,
                    'source_type' => 'banner',
                    'sender' => $sender, // Specific sender identifier for blocking
                    'url' => $url,
                    'icon' => $icon,
                    'group_id' => 'admin_banners',
                    'status' => 'new',
                    'dedupe_key' => $identity_id,
                    'created_at' => current_time('mysql'),
                    'meta' => json_encode([
                        'id' => $identity_id,
                        'banner_id' => $banner_id,
                        'banner_type' => $banner_type,
                        'original_html' => substr($html, 0, 1000),
                        'page' => $page,
                        'classes' => $classes,
                        'converted_at' => current_time('mysql'),
                        'urls' => $urls, // Store all URLs with their text labels
                        'component_name' => $component_name // Store component name for better sender labeling
                    ])
                ];

                $notification_id = $this->storage->create($notification_data);

                // Clear cache to force refresh
                $this->clear_user_cache($user_id);

                return rest_ensure_response([
                    'success' => true,
                    'notification_id' => $notification_id,
                    'action' => 'created'
                ]);
            }
        }
        catch (Exception $e) {
            return rest_ensure_response([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * REST API: Force refresh notifications (bypass cache)
     */
    public function rest_force_refresh($request)
    {
        try {
            $user_id = get_current_user_id();

            if ($user_id <= 0) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'User not logged in'
                ], 401);
            }

            // Clear cache
            $this->clear_user_cache($user_id);

            // Force collection (bypass hash check)
            if ($this->collector) {
                $this->collector->collect_all($user_id, true);
            }

            // Get fresh notifications
            $notifications = $this->get_notifications($user_id);
            $unread_count = $this->get_notification_count($user_id, 'new');

            return rest_ensure_response([
                'success' => true,
                'notifications' => $notifications,
                'count' => count($notifications),
                'unread_count' => $unread_count,
                'timestamp' => current_time('mysql')
            ]);
        }
        catch (Exception $e) {
            return rest_ensure_response([
                'success' => false,
                'error' => $e->getMessage(),
                'timestamp' => current_time('mysql')
            ], 500);
        }
    }

    /**
     * Schedule cleanup tasks
     */
    private function schedule_cleanup_tasks()
    {
        // Clean up old cron hooks from before yooadmin_ → yooadmin_ rename
        wp_clear_scheduled_hook('yooadmin_notifications_cleanup');
        wp_clear_scheduled_hook('yooadmin_notifications_restore_snoozed');

        // Intervals are registered globally via yooadmin_register_notification_cron_schedules().

        // Schedule cleanup every 6 hours
        if (!wp_next_scheduled('yooadmin_notifications_cleanup')) {
            wp_schedule_event(time(), 'yooadmin_6h', 'yooadmin_notifications_cleanup');
        }

        // Hook cleanup functions
        add_action('yooadmin_notifications_cleanup', [$this, 'perform_cleanup']);

        // Schedule snooze restore hourly (backup for offline users)
        // REST API handles online users instantly via restore_expired_snoozes_for_user()
        if (!wp_next_scheduled('yooadmin_notifications_restore_snoozed')) {
            wp_schedule_event(time(), 'yooadmin_hourly', 'yooadmin_notifications_restore_snoozed');
        }
        add_action('yooadmin_notifications_restore_snoozed', [$this, 'restore_snoozed_notifications']);

        // Cache invalidation hooks
        add_action('yooadmin_notification_created', [$this, 'invalidate_cache_on_notification_created'], 10, 3);
        add_action('yooadmin_notification_updated', [$this, 'invalidate_cache_on_notification_updated'], 10, 3);
        add_action('yooadmin_notification_read', [$this, 'invalidate_cache_on_notification_read'], 10, 2);
    }

    /**
     * Invalidate cache when notification is created
     */
    public function invalidate_cache_on_notification_created($notification_id, $data, $user_id)
    {
        if ($user_id && $this->cache) {
            // Reliable list invalidation on persistent object caches.
            $this->invalidate_user_list_cache($user_id);
            // Clear user-specific cache
            $this->cache->delete_by_pattern('notifications_' . $user_id);
            // Clear hash cache
            $this->cache->delete(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATIONS_HASH . $user_id);
        }
    }

    /**
     * Invalidate cache when notification is updated
     */
    public function invalidate_cache_on_notification_updated($notification_id, $data, $old_data)
    {
        if ($this->cache && isset($old_data['user_id'])) {
            $user_id = $old_data['user_id'];
            // Reliable list invalidation on persistent object caches.
            $this->invalidate_user_list_cache($user_id);
            // Clear user-specific cache
            $this->cache->delete_by_pattern('notifications_' . $user_id);
            // Clear hash cache
            $this->cache->delete(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATIONS_HASH . $user_id);
            // Clear notification-specific cache
            $this->cache->delete(YOOAdmin_Cache_Constants::PREFIX_NOTIFICATION_HASH . $notification_id);
        }
    }

    /**
     * Invalidate cache when notification is read
     */
    public function invalidate_cache_on_notification_read($notification_id, $user_id)
    {
        if ($user_id && $this->cache) {
            // Reliable list invalidation on persistent object caches.
            $this->invalidate_user_list_cache($user_id);
            // Clear user-specific cache (status changed from 'new' to 'read')
            $this->cache->delete_by_pattern('notifications_' . $user_id);
        }
    }

    /**
     * Retention settings (site-wide) with sane defaults.
     *
     * @return array{enabled:bool,read_days:int,max_per_user:int,tombstone_days:int}
     */
    public function get_retention_settings()
    {
        $opts = function_exists('yooadmin_get_options')
            ? (array) yooadmin_get_options()
            : (array) get_option('yooadmin_options', []);

        return [
            'enabled'        => array_key_exists('notif_auto_cleanup', $opts) ? !empty($opts['notif_auto_cleanup']) : true,
            'read_days'      => isset($opts['notif_retention_days']) ? max(0, (int) $opts['notif_retention_days']) : 45,
            'max_per_user'   => isset($opts['notif_max_per_user']) ? max(0, (int) $opts['notif_max_per_user']) : 200,
            'tombstone_days' => isset($opts['notif_tombstone_days']) ? max(0, (int) $opts['notif_tombstone_days']) : 90,
        ];
    }

    /**
     * Run retention rules (expired + age-based read + per-user cap + tombstone prune).
     *
     * @return array{expired:int,old_read:int,capped:int,tombstones:int,total:int}
     */
    public function run_retention()
    {
        $r = $this->get_retention_settings();
        $result = ['expired' => 0, 'old_read' => 0, 'capped' => 0, 'tombstones' => 0, 'total' => 0];

        if (!$this->storage) {
            return $result;
        }

        if (method_exists($this->storage, 'cleanup_expired')) {
            $result['expired'] = (int) $this->storage->cleanup_expired();
        }
        if ($r['read_days'] > 0 && method_exists($this->storage, 'cleanup_old_read')) {
            $result['old_read'] = (int) $this->storage->cleanup_old_read($r['read_days']);
        }
        if ($r['max_per_user'] > 0 && method_exists($this->storage, 'enforce_per_user_cap')) {
            $result['capped'] = (int) $this->storage->enforce_per_user_cap($r['max_per_user']);
        }
        if (method_exists($this->storage, 'cleanup_old_tombstones')) {
            $result['tombstones'] = (int) $this->storage->cleanup_old_tombstones($r['tombstone_days']);
        }

        $result['total'] = $result['expired'] + $result['old_read'] + $result['capped'] + $result['tombstones'];

        if ($result['total'] > 0) {
            $this->clear_all_user_caches();
        }

        return $result;
    }

    /**
     * Manual cleanup triggered from the settings UI (ignores the enabled toggle).
     *
     * @return array Counts from run_retention().
     */
    public function run_manual_cleanup()
    {
        return $this->run_retention();
    }

    /**
     * Perform cleanup (scheduled cron entry point)
     */
    public function perform_cleanup()
    {
        $cleaned = 0;

        // Age-based retention (expired + old read + per-user cap + tombstones),
        // honoring the site-wide enable toggle.
        $r = $this->get_retention_settings();
        if (!empty($r['enabled'])) {
            $retention = $this->run_retention();
            $cleaned += (int) $retention['total'];
        }
        elseif ($this->storage && method_exists($this->storage, 'cleanup_expired')) {
            // Even when auto-cleanup is off, still drop already-expired rows.
            $cleaned += (int) $this->storage->cleanup_expired();
        }

        // Clean up cache
        if ($this->cache && method_exists($this->cache, 'cleanup')) {
            $cleaned += $this->cache->cleanup();
        }

        // Optimize hash cache
        if ($this->hash && method_exists($this->hash, 'optimize_cache')) {
            $this->hash->optimize_cache();
        }

        return $cleaned;
    }

    /**
     * Restore expired snoozes for a specific user (called on every poll for instant response)
     */
    private function restore_expired_snoozes_for_user($user_id)
    {
        // Use filters method to get expired snoozes for this user
        $restored = $this->filters->restore_snoozed_for_user($user_id);

        if ($restored > 0) {
            // Clear caches for this user only (use the real suffixed count keys
            // so the bell badge is flushed on persistent object caches too)
            if ($this->cache) {
                $this->clear_user_cache($user_id);
                $this->cache->delete('dismissed_notifications_' . $user_id);
            }
        }

        return $restored;
    }

    /**
     * Restore snoozed notifications (for all users - cron job)
     */
    public function restore_snoozed_notifications()
    {
        // Don't run restore if Focus Mode is OFF
        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return 0;
        }

        $restored = $this->filters->restore_snoozed_notifications();

        if ($restored > 0) {
            // Clear all caches since notifications changed
            $this->clear_all_user_caches();
        }

        return $restored;
    }

    /**
     * Build the versioned cache key for a user's notification list.
     *
     * @param int $user_id
     * @param array<string,mixed> $options
     */
    private function list_cache_key($user_id, array $options)
    {
        $user_id = (int) $user_id;

        $global_version = $this->cache->get_namespace_version('notif_list_global');
        $user_version   = $this->cache->get_namespace_version('notif_list_' . $user_id);

        return 'notifications_' . $user_id
            . '_g' . $global_version
            . '_v' . $user_version
            . '_' . md5(serialize($options));
    }

    /**
     * Invalidate a single user's cached notification lists.
     *
     * Public so dependent modules can reuse the same invalidation as the core
     * paths instead of relying on pattern deletes (which do not work across
     * requests on a persistent object cache).
     *
     * @param int $user_id
     */
    public function invalidate_user_list_cache($user_id)
    {
        $this->cache->bump_namespace_version('notif_list_' . (int) $user_id);
    }

    /**
     * Invalidate every user's cached notification lists in one write.
     */
    public function invalidate_all_list_cache()
    {
        $this->cache->bump_namespace_version('notif_list_global');
    }

    /**
     * Clear user cache
     */
    private function clear_user_cache($user_id)
    {
        $user_id = (int) $user_id;

        $this->cache->delete('notification_count_' . $user_id . '_new');
        $this->cache->delete('notification_count_' . $user_id . '_read');
        $this->cache->delete('notification_count_' . $user_id . '_all');

        // Reliable list invalidation on persistent object caches.
        $this->invalidate_user_list_cache($user_id);

        if (method_exists($this->cache, 'delete_by_pattern')) {
            $this->cache->delete_by_pattern('notifications_' . $user_id);
            $this->cache->delete_by_pattern('notification_count_' . $user_id);
            $this->cache->delete_by_pattern('notifications_hash_' . $user_id);
            $this->cache->delete_by_pattern('dismissed_notifications_' . $user_id);
        }
    }

    /**
     * Clear all user caches
     */
    private function clear_all_user_caches()
    {
        $this->invalidate_all_list_cache();

        $this->cache->delete_by_pattern('notifications_');
        $this->cache->delete_by_pattern('notification_count_');
        $this->cache->delete_by_pattern('notifications_hash_');
        $this->cache->delete_by_pattern('dismissed_notifications_');
    }

    /**
     * Public helper to clear all caches (global + per-user patterns)
     */
    public function clear_all_caches()
    {
        // Reliable list invalidation on persistent object caches.
        $this->invalidate_all_list_cache();

        // Clear global patterns
        $this->cache->delete_by_pattern('notifications_');
        $this->cache->delete_by_pattern('notification_count_');
        $this->cache->delete_by_pattern('notifications_hash_');
        $this->cache->delete_by_pattern('dismissed_notifications_');
        // Also run cache cleanup if available
        if ($this->cache && method_exists($this->cache, 'cleanup')) {
            $this->cache->cleanup();
        }
    }

    /**
     * Keep only notifications that are currently snoozed (snooze_until in future)
     */
    private function filter_snoozed_integration($user_id, $notifications)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';
        $now = current_time('mysql');

        $rows = $wpdb->get_results($wpdb->prepare("
            SELECT notification_id, snooze_until
            FROM {$table}
            WHERE user_id = %d
              AND dismissal_type = 'snooze'
              AND snooze_until IS NOT NULL
              AND snooze_until > %s
        ", $user_id, $now), ARRAY_A);

        if (empty($rows)) {
            return [];
        }

        $snoozed_map = [];
        foreach ($rows as $row) {
            $nid = intval($row['notification_id'] ?? 0);
            if ($nid > 0) {
                $snoozed_map[$nid] = $row['snooze_until'];
            }
        }

        if (empty($snoozed_map)) {
            return [];
        }

        return array_filter($notifications, function ($n) use ($snoozed_map) {
            $nid = intval($n['id'] ?? 0);
            return $nid > 0 && isset($snoozed_map[$nid]);
        });
    }

    /**
     * Professional PHP-based banner capture using Output Buffering
     * Prevents duplicate saves on refresh using transient cache
     * 
     * This is the MOST PROFESSIONAL approach:
     * 1. Captures banners BEFORE they're sent to browser (no JavaScript needed)
     * 2. Saves directly to database (persistent storage)
     * 3. Prevents duplicates using transient cache (only saves once per page load)
     * 
     * This method is called at admin_footer to capture all notices that were rendered
     */
    private static $banner_capture_buffer = '';
    private static $banners_captured_this_request = false;

    public function capture_banners_from_dom()
    {
        // Only capture when Focus Mode is on (tables may be missing after data cleanup).
        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return;
        }

        // Only capture on admin pages, not REST API or AJAX
        if (defined('REST_REQUEST') && REST_REQUEST) {
            return;
        }
        if (defined('DOING_AJAX') && DOING_AJAX) {
            return;
        }

        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return;
        }
        // Prevent duplicate captures on same page load
        if (self::$banners_captured_this_request) {
            return;
        }
        // Use transient to prevent saving same banners multiple times on refresh
        // Check if we already processed banners for this page in this session
        $current_screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $page_id = $current_screen ? $current_screen->id : 'unknown';
        // Use a more stable cache key that persists across page changes
        // Include page ID but not full URI to allow same banners on different pages
        $cache_key = 'yooadmin_banners_captured_' . $user_id . '_' . $page_id;
        // Increase TTL to 30 seconds to prevent duplicates when changing pages slowly
        // Check if already processed (within last 30 seconds to prevent duplicates on page changes)
        $already_processed = get_transient($cache_key);
        if ($already_processed) {
            // Banners already captured for this page, skip duplicates
            return;
        }

        // Set transient to prevent duplicate processing (30 seconds TTL - longer to prevent slow page changes)
        set_transient($cache_key, true, 30);
        self::$banners_captured_this_request = true;

        // Method 1: Use Output Buffering to capture admin_notices hook output
        // Prevent multiple captures by checking if notices were already captured
        // Some plugins/themes call admin_notices multiple times, causing duplicates
        static $notices_captured = false;

        if ($notices_captured) {
            // Admin notices already captured in this request, skip duplicates
            return;
        }

        ob_start();
        do_action('admin_notices'); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WordPress core hook.
        $notices_html = ob_get_clean();
        $notices_captured = true;

        $banners_saved = 0;

        if (!empty($notices_html)) {
            $banners = $this->parse_banners_from_html($notices_html);

            if (!empty($banners)) {
                foreach ($banners as $banner) {
                    // Save directly to database (no REST API needed - we're in PHP)
                    if ($this->save_banner_directly($user_id, $banner)) {
                        $banners_saved++;
                    }
                }
            }
        }

        if ($banners_saved > 0 && defined('YOOADMIN_NOTIFICATIONS_DEBUG') && YOOADMIN_NOTIFICATIONS_DEBUG) {
        // Captured and saved banners from PHP Output Buffering
        }
    }

    /**
     * Truncate notification text without breaking UTF-8 (Arabic-safe).
     */
    private function truncate_notification_text(string $text, int $max): string
    {
        $text = trim($text);
        if ($text === '' || $max < 1) {
            return '';
        }

        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            if (mb_strlen($text, 'UTF-8') <= $max) {
                return $text;
            }
            $cut = mb_substr($text, 0, $max, 'UTF-8');
            $space = mb_strrpos($cut, ' ', 0, 'UTF-8');
            if ($space !== false && $space > (int) ($max * 0.55)) {
                $cut = mb_substr($cut, 0, $space, 'UTF-8');
            }

            return rtrim($cut) . '...';
        }

        if (strlen($text) <= $max) {
            return $text;
        }

        return rtrim(substr($text, 0, max(1, $max - 3))) . '...';
    }

    /**
     * Whether a string contains Arabic script (for title heuristics).
     */
    private function text_contains_arabic(string $text): bool
    {
        return (bool) preg_match('/[\x{0600}-\x{06FF}\x{0750}-\x{077F}\x{08A0}-\x{08FF}]/u', $text);
    }

    /**
     * Convert common plugin/theme slugs from banner classes into readable labels.
     */
    private function humanize_banner_slug(string $slug): string
    {
        $slug = strtolower(str_replace('_', '-', $slug));
        $known = [
            'abovewp' => 'AboveWP',
            'aioseo' => 'AIOSEO',
            'codevz' => 'Codevz',
            'elementor' => 'Elementor',
            'gutenkit' => 'Gutenkit',
            'malcare' => 'MalCare',
            'rank' => 'Rank Math',
            'vc' => 'WPBakery Page Builder',
            'woocommerce' => 'WooCommerce',
            'wpb' => 'WPBakery Page Builder',
            'xtra' => 'XTRA Theme',
            'yooadmin-login-turnstile-incomplete' => __('YOOAdmin login security', 'yooadmin'),
        ];

        if (isset($known[$slug])) {
            return $known[$slug];
        }

        $first_part = strtok($slug, '-');
        if ($first_part && isset($known[$first_part])) {
            return $known[$first_part];
        }

        $parts = array_filter(explode('-', $slug), static function ($part) {
            return $part !== '' && !in_array($part, ['admin', 'banner', 'content', 'notice', 'notification', 'promo', 'wrapper'], true);
        });

        return trim(ucwords(implode(' ', $parts)));
    }

    /**
     * Infer the plugin/theme responsible for a converted admin banner.
     */
    private function infer_banner_component_name(string $element_id, string $classes, string $text_content): string
    {
        $haystack = trim($element_id . ' ' . $classes);

        if (preg_match('/\b(?:vc|wpb|js_composer)\b/i', $haystack)) {
            return 'WPBakery Page Builder';
        }
        if (preg_match('/\belementor\b/i', $haystack)) {
            return 'Elementor';
        }
        if (preg_match('/\bwoocommerce\b/i', $haystack)) {
            return 'WooCommerce';
        }
        if (preg_match('/\bxtra\b/i', $haystack)) {
            return 'XTRA Theme';
        }

        if (preg_match('/\b([a-z0-9][a-z0-9_-]+?)-(?:promo-)?(?:admin-)?notice\b/i', $haystack, $matches)) {
            return $this->humanize_banner_slug($matches[1]);
        }
        if (preg_match('/\b([a-z0-9][a-z0-9_-]+?)-(?:promo|banner|message|alert)\b/i', $haystack, $matches)) {
            return $this->humanize_banner_slug($matches[1]);
        }
        if (preg_match('/\b(?:plugin|theme)-([a-z0-9][a-z0-9_-]+)\b/i', $haystack, $matches)) {
            return $this->humanize_banner_slug($matches[1]);
        }
        if (preg_match('/\b(?:installing|installed|for)\s+([A-Z][A-Za-z0-9\s]+?)\s+(?:theme|plugin)\b/i', $text_content, $matches)) {
            return trim(substr($matches[1], 0, 50));
        }

        return '';
    }

    /**
     * Canonical, content-based identity for a banner notification.
     *
     * Both banner-conversion entry points (the JS REST path and the server-side DOM
     * scan) MUST derive the same key from the same banner. Previously each path used
     * its own hashing (and sometimes a volatile DOM element id), so one banner became
     * two notifications and a dismissal tombstone stopped matching after the id drifted
     * — which is exactly why "deleted banners came back". Hashing the normalized
     * title+message makes the identity stable and path-independent.
     */
    private function canonical_banner_dedupe_key($title, $message)
    {
        $basis = wp_strip_all_tags((string) $title . ' ' . (string) $message);
        $basis = strtolower(trim(preg_replace('/\s+/', ' ', $basis)));
        if ($basis === '') {
            return '';
        }
        return 'banner_' . substr(md5($basis), 0, 20);
    }

    /**
     * Whether a dedupe_key is currently tombstoned (permanently dismissed or still snoozed).
     *
     * Used to avoid re-creating a banner the user already removed: the conversion
     * simply skips it instead of inserting a row that would be filtered out anyway
     * (prevents resurrection AND table bloat from re-inserting on every page load).
     */
    private function is_dedupe_tombstoned($user_id, $dedupe_key)
    {
        if ($dedupe_key === '' || (int) $user_id <= 0) {
            return false;
        }
        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_dismissed_notifications';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix + hardcoded string; safe.
        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE user_id = %d AND dedupe_key = %s AND (snooze_until IS NULL OR snooze_until > %s) LIMIT 1",
            (int) $user_id,
            $dedupe_key,
            current_time('mysql')
        ));
        return !empty($found);
    }

    /**
     * Parse banners from HTML string (professional DOM parsing)
     */
    private function parse_banners_from_html($html)
    {
        $banners = [];

        if (empty($html) || !class_exists('DOMDocument')) {
            return $banners;
        }

        libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        @$dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);
        $current_screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $page = $current_screen ? $current_screen->id : 'unknown';
        // Better approach - get all notice elements first, then filter to get only top-level ones
        // This prevents splitting one banner into multiple notifications
        $all_notice_elements = $xpath->query('//*[contains(@class, "notice") or contains(@class, "update-nag") or contains(@class, "error") or contains(@class, "updated")]');

        // Filter to get only top-level notices (not nested inside other notices)
        $top_level_notices = [];
        foreach ($all_notice_elements as $element) {
            // Check if this element is inside another notice element
            $parent = $element->parentNode;
            $is_nested = false;

            // Traverse up the DOM tree to check for parent notices
            while ($parent && $parent->nodeType === XML_ELEMENT_NODE) {
                $parent_classes = $parent->getAttribute('class') ?? '';
                // Check if parent is a notice element
                if (preg_match('/(?:^|\s)(?:notice|update-nag|error|updated)(?:\s|$)/i', $parent_classes)) {
                    // Check if this parent is different from current element
                    if ($parent !== $element) {
                        $is_nested = true;
                        break;
                    }
                }
                $parent = $parent->parentNode;
            }

            // Only add if it's a top-level notice
            if (!$is_nested) {
                $top_level_notices[] = $element;
            }
        }

        // Only log in debug mode to avoid performance issues
        if (defined('YOOADMIN_NOTIFICATIONS_DEBUG') && YOOADMIN_NOTIFICATIONS_DEBUG) {
        }

        foreach ($top_level_notices as $index => $element) {
        // Generate stable banner ID using hash of content to prevent duplicates
            $element_id = $element->getAttribute('id') ?: '';
            $remove_nodes = [];
            foreach ($xpath->query('.//style|.//script|.//noscript|.//template|.//svg', $element) as $remove_node) {
                $remove_nodes[] = $remove_node;
            }
            foreach ($remove_nodes as $remove_node) {
                if ($remove_node->parentNode) {
                    $remove_node->parentNode->removeChild($remove_node);
                }
            }
            $text_content = trim(preg_replace('/\s+/', ' ', $element->textContent));
            $html_content = $dom->saveHTML($element);

            $classes = $element->getAttribute('class') ?: '';

            if (
                strpos($classes, 'yooadmin-login-turnstile-incomplete-notice') !== false
                || strpos($classes, 'yooadmin-brand-notice') !== false
                || strpos($classes, 'yooadmin-wizard-notice') !== false
                || strpos($classes, 'yp-settings-callout') !== false
            ) {
                continue;
            }

            // Pre-extract component for stable ID (needed before banner_id is finalized)
            $component_for_id = '';
            $banner_id_attr_pre = $element->getAttribute('id') ?: '';
            if (!empty($banner_id_attr_pre)) {
                if (preg_match('/^(abovewp|vc_|wpb_|js_composer|elementor|woocommerce|xtra)/i', $banner_id_attr_pre)) {
                    $component_for_id = preg_replace('/[^a-z0-9]/i', '_', strtolower($banner_id_attr_pre));
                }
            }
            if (empty($component_for_id) && preg_match('/\b(abovewp|xtra|vc|wpb|elementor|woocommerce)\b/i', $classes)) {
                $component_for_id = preg_replace('/[^a-z0-9]/i', '_', strtolower(trim(preg_replace('/\s+/', '_', $classes))));
                $component_for_id = substr($component_for_id, 0, 40);
            }
            if (empty($component_for_id) && preg_match('/\b(?:thank you for )?installing\s+([A-Z][A-Za-z0-9\s]+?)\s+(?:theme|plugin)\b/i', $text_content, $m)) {
                $component_for_id = sanitize_key(trim($m[1]));
            }

            // Generate stable ID: for known component install banners use fixed ID first (prevents duplicates across pages)
        // Prefer banner_{component}_install over element_id - element_id may vary per page
            if (!empty($component_for_id) && preg_match('/\b(?:thank you for )?(?:installing|installed)\b/i', $text_content)) {
                // Install/welcome banner for known component - stable ID (same on all pages)
                $banner_id = 'banner_' . $component_for_id . '_install';
            }
            elseif (!empty($element_id)) {
                $banner_id = $element_id;
            }
            elseif (preg_match('/wordpress\s+(\d+\.\d+)/i', $text_content, $wp_version_match)) {
                $wp_version = $wp_version_match[1];
                $banner_id = 'wp_update_' . sanitize_key($wp_version);
            }
            else {
                // Same content = same hash = same ID on ALL pages (no page in ID)
                $normalized_content = strtolower(trim(preg_replace('/\s+/', ' ', $text_content)));
                $content_hash = substr(md5($normalized_content), 0, 12);
                $banner_id = 'banner_' . $content_hash;
            }

            // Determine type and priority
            $banner_type = 'notice';
            $priority = 'medium';
            if (strpos($classes, 'error') !== false || strpos($classes, 'notice-error') !== false) {
                $banner_type = 'error';
                $priority = 'high';
            }
            elseif (strpos($classes, 'updated') !== false || strpos($classes, 'notice-success') !== false) {
                // Smart detection: Only skip if it's actually a save/success message
                // Don't skip plugin/theme banners that happen to use "updated" class (like WPBakery license)
                $is_save_message = preg_match('/\b(saved|settings?\s+updated|changes?\s+saved|successfully\s+updated|update\s+complete)\b/i', $text_content);

                if ($is_save_message) {
                    // Real save/success message - skip converting, let it stay visible as native banner
                    continue;
                }
            // Otherwise, it's a plugin/theme banner (like WPBakery license) - continue to convert it
            }
            elseif (strpos($classes, 'notice-warning') !== false) {
                $banner_type = 'warning';
                $priority = 'medium';
            }
            elseif (strpos($classes, 'update-nag') !== false) {
                $banner_type = 'update';
                $priority = 'high';
            }
        // Extract component/plugin name from classes or ID first (e.g., "WPBakery Page Builder")
            $component_name = '';

            // Try to extract component name from ID (e.g., "vc_license-activation-notice" -> "WPBakery Page Builder")
            $banner_id_attr = $element->getAttribute('id') ?: '';
            if (!empty($banner_id_attr)) {
                // Common patterns: vc_*, wpb_*, js_composer_* = WPBakery Page Builder
                if (preg_match('/^(vc_|wpb_|js_composer)/i', $banner_id_attr)) {
                    $component_name = 'WPBakery Page Builder';
                }
                // Add more patterns for other plugins/themes
                elseif (preg_match('/elementor/i', $banner_id_attr)) {
                    $component_name = 'Elementor';
                }
                elseif (preg_match('/woocommerce/i', $banner_id_attr)) {
                    $component_name = 'WooCommerce';
                }
                elseif (preg_match('/xtra/i', $banner_id_attr)) {
                    $component_name = 'XTRA Theme';
                }
            }

            // Try to extract from classes (e.g., "vc_license-activation-notice" class)
            if (empty($component_name) && !empty($classes)) {
                if (preg_match('/\b(vc|wpb|js_composer)\b/i', $classes)) {
                    $component_name = 'WPBakery Page Builder';
                }
                elseif (preg_match('/\belementor\b/i', $classes)) {
                    $component_name = 'Elementor';
                }
                elseif (preg_match('/\bwoocommerce\b/i', $classes)) {
                    $component_name = 'WooCommerce';
                }
                elseif (preg_match('/\bxtra\b/i', $classes)) {
                    $component_name = 'XTRA Theme';
                }
            }
        // Also try to extract from text content (e.g., "Thank you for installing XTRA theme")
            if (empty($component_name) && !empty($text_content)) {
                if (preg_match('/\b(?:installing|installed|for)\s+([A-Z][A-Za-z0-9\s]+?)\s+(?:theme|plugin)\b/i', $text_content, $matches)) {
                    $component_name = trim($matches[1]);
                    // Limit component name length
                    if (strlen($component_name) > 50) {
                        $component_name = $this->truncate_notification_text($component_name, 50);
                    }
                }
            }
            if (empty($component_name)) {
                $component_name = $this->infer_banner_component_name($banner_id_attr, $classes, $text_content);
            }

            // Extract title from visible notice text; component_name is kept for the sender/source.
            $title = '';
            if (!empty($component_name) && empty($text_content)) {
                $title = $component_name;
            }
            else {
        // Try to extract short title from first line or strong tag
                $strong_elements = $xpath->query('.//strong', $element);
                if ($strong_elements->length > 0) {
                    $strong_text = trim($strong_elements->item(0)->textContent);
                    // Only use if it's short (less than 50 chars) - likely a title, not full message
                    if (strlen($strong_text) <= 50) {
                        $title = $strong_text;
                    }
                }

                // If no short strong tag, try first line of text (but limit length)
                if (empty($title)) {
                    $lines = explode("\n", $text_content);
                    foreach ($lines as $line) {
                        $line = trim($line);
                        // Only use if line is meaningful but not too long (likely a title)
                        $line_len = function_exists('mb_strlen') ? mb_strlen($line, 'UTF-8') : strlen($line);
                        if ($line_len > 5 && $line_len <= 60) {
                            // Title heuristics: Latin capital start, short line, or Arabic notice heading.
                            if (preg_match('/^[A-Z]/', $line) || $line_len <= 40 || $this->text_contains_arabic($line)) {
                                $title = $line;
                                break;
                            }
                        }
                    }
                }

                // If still no title, try first sentence (up to 50 chars)
                if (empty($title)) {
                    $first_sentence = trim($text_content);
                    // Extract first sentence (up to first period, exclamation, or question mark)
                    if (preg_match('/^([^.!?؟]{1,80})[.!?؟]/u', $first_sentence, $matches)) {
                        $title = trim($matches[1]);
                    }
                    elseif ((function_exists('mb_strlen') ? mb_strlen($first_sentence, 'UTF-8') : strlen($first_sentence)) <= 50) {
                        $title = $first_sentence;
                    }
                    else {
                        $title = $this->truncate_notification_text($first_sentence, 50);
                    }
                }
            }
        // Clean and limit title length (max 60 chars for popup display)
            $title = preg_replace('/\s+/', ' ', $title);
            $title = trim($title);
            if ((function_exists('mb_strlen') ? mb_strlen($title, 'UTF-8') : strlen($title)) > 60) {
                $title = $this->truncate_notification_text($title, 60);
            }
            if (empty($title) || strlen($title) < 3) {
                $title = 'Admin Notice';
            }

            // Extract message (full text, but remove title if it's at the start)
            $message = $text_content;
            if (!empty($title) && strlen($title) < strlen($message)) {
                // Remove title from start of message if it matches
                $title_escaped = preg_quote($title, '/');
                $message = preg_replace('/^' . $title_escaped . '\s*[.!?]?\s*/i', '', $message);
                $message = trim($message);
            }

            // If message is empty or same as title, use full text content
            if (empty($message) || $message === $title) {
                $message = $text_content;
            }
        // Remove "Dismiss this notice" and similar dismiss links from message
            $message = preg_replace('/\s*(?:Dismiss|Hide|Close)\s+(?:this\s+)?(?:notice|notification|message|banner)\s*/i', '', $message);
            $message = preg_replace('/\s*\[?\s*(?:Dismiss|Hide|Close)\s+(?:this\s+)?(?:notice|notification|message|banner)\s*\]?\s*/i', '', $message);
            $message = trim($message);

            if (empty($message)) {
                $message = $text_content;
            }
            if (strlen($message) > 500) {
                $message = substr($message, 0, 500) . '...';
            }
        // Extract ALL URLs from the banner (not just the first one)
        // Use DOM XPath only (more reliable than regex) and remove duplicates
            $urls = [];
            $seen_urls = []; // Track seen URLs to prevent duplicates

            // Use DOM XPath to extract links (more reliable than regex)
            $link_elements = $xpath->query('.//a[@href]', $element);

            foreach ($link_elements as $link) {
                $href = $link->getAttribute('href');
                $link_text = trim($link->textContent);

                // Skip dismiss/hide/close links
                if (preg_match('/\b(dismiss|hide|close)\b/i', $link_text)) {
                    continue;
                }

                // Skip empty or generic links
                if (empty($href) || $href === '#' || preg_match('/^(javascript:|#)/i', $href)) {
                    continue;
                }
        // Normalize URL to prevent duplicates
                // Remove trailing slashes, convert to lowercase for comparison
                $normalized_href = strtolower(rtrim($href, '/'));
                // Also normalize by removing query params for comparison (but keep original)
                $normalized_for_comparison = preg_replace('/\?.*$/', '', $normalized_href);

                if (isset($seen_urls[$normalized_for_comparison])) {
                    continue; // Already added, skip duplicate
                }
                $seen_urls[$normalized_for_comparison] = true;

                // Use link text, or extract from href if text is empty
                $display_text = !empty($link_text) ? trim($link_text) : 'View';

                // If link text is very short or generic, try to extract meaningful text
                if (strlen($display_text) < 3 || in_array(strtolower($display_text), ['view', 'here', 'click', 'more', 'link'])) {
                    // Try to get text from parent or nearby elements
                    $parent = $link->parentNode;
                    if ($parent && $parent->nodeType === XML_ELEMENT_NODE) {
                        $parent_text = trim($parent->textContent);
                        if (!empty($parent_text) && strlen($parent_text) > strlen($display_text)) {
                            // Use parent text if it's more meaningful
                            $display_text = $parent_text;
                        }
                    }
                }

                $urls[] = [
                    'url' => $href, // Use original href, not normalized
                    'text' => $display_text
                ];
            }

            // Also extract from buttons/elems with data-href, data-url (e.g. XTRA "Install theme plugin")
            $data_url_elements = $xpath->query('.//*[@data-href or @data-url]', $element);
            foreach ($data_url_elements as $el) {
                $href = $el->getAttribute('data-href') ?: $el->getAttribute('data-url');
                if (empty($href) || $href === '#' || preg_match('/^(javascript:|#)/i', $href)) {
                    continue;
                }
                $link_text = trim($el->textContent);
                if (preg_match('/\b(dismiss|hide|close)\b/i', $link_text)) {
                    continue;
                }
                $norm = strtolower(preg_replace('/\?.*$/', '', rtrim($href, '/')));
                if (isset($seen_urls[$norm])) {
                    continue;
                }
                $seen_urls[$norm] = true;
                $display_text = !empty($link_text) && strlen($link_text) <= 60 ? $link_text : 'View';
                $urls[] = ['url' => $href, 'text' => $display_text];
            }

            // Final deduplication
            $final_urls = [];
            $final_seen = [];
            foreach ($urls as $url_item) {
                $url_key = strtolower(trim($url_item['url']));
                if (!isset($final_seen[$url_key])) {
                    $final_seen[$url_key] = true;
                    $final_urls[] = $url_item;
                }
            }
            $urls = $final_urls;
        // Also extract URLs from text content (in case links are in plain text)
            // Note: HTML extraction is already done above, so this is only for plain text URLs
            if (empty($urls)) {
                // Method: Try to find URLs in the text content using regex (fallback)
                if (preg_match_all('/(https?:\/\/[^\s<>"\'\)]+)/i', $text_content, $matches)) {
                    foreach ($matches[1] as $match_url) {
                        // Try to find associated text near the URL
                        $url_text = 'View';
                        $url_pos = stripos($text_content, $match_url);
                        if ($url_pos !== false) {
                            // Get text before URL (up to 50 chars) as potential link text
                            $before_text = substr($text_content, max(0, $url_pos - 50), 50);
                            // Look for common link phrases like "Get 30% off", "Save up", etc.
                            if (preg_match('/(get|save|buy|purchase|shop|deal|offer|discount|off|%)\s*([^\s<>"\'\)]{0,30})$/i', $before_text, $text_match)) {
                                $url_text = trim($text_match[0]);
                            }
                            elseif (preg_match('/([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*' . preg_quote($match_url, '/') . '/i', $text_content, $text_match)) {
                                // Try to get capitalized text before URL
                                $url_text = trim($text_match[1]);
                            }
                        }

                        $urls[] = [
                            'url' => $match_url,
                            'text' => !empty($url_text) ? $url_text : 'View'
                        ];
                    }
                }
            }
        // Try to find "Get 30% off" or similar text and extract nearby URLs (if no URLs found)
            if (empty($urls) && preg_match('/get\s+30%?\s+off/i', $text_content, $match)) {
                // Search for URLs near "Get 30% off" text in HTML
                $match_pos = stripos($html_content, $match[0]);
                if ($match_pos !== false) {
                    // Get HTML after "Get 30% off" (up to 500 chars)
                    $after_html = substr($html_content, $match_pos + strlen($match[0]), 500);
                    // Search for <a> tags in the HTML after "Get 30% off"
                    if (preg_match_all('/<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $after_html, $nearby_matches, PREG_SET_ORDER)) {
                        foreach ($nearby_matches as $nearby_match) {
                            $href = $nearby_match[1];
                            $link_text = wp_strip_all_tags($nearby_match[2]);

                            // Skip dismiss/hide/close links
                            if (preg_match('/\b(dismiss|hide|close)\b/i', $link_text) ||
                            preg_match('/(javascript:void\(0\)|#)/i', $href)) {
                                continue;
                            }

                            if (!empty($href) && $href !== '#' && !preg_match('/^(javascript:|#)/i', $href)) {
                                $urls[] = [
                                    'url' => $href,
                                    'text' => !empty($link_text) ? trim($link_text) : 'Get 30% off'
                                ];
                            }
                        }
                    }
                    // Also search for plain URLs in text after "Get 30% off"
                    $after_text = substr($text_content, stripos($text_content, $match[0]) + strlen($match[0]), 200);
                    if (preg_match_all('/(https?:\/\/[^\s<>"\'\)]+)/i', $after_text, $url_matches)) {
                        foreach ($url_matches[1] as $found_url) {
                            $urls[] = [
                                'url' => $found_url,
                                'text' => 'Get 30% off'
                            ];
                        }
                    }
                }
            }

            // Use first URL as primary URL (for backward compatibility)
            $url = !empty($urls) ? $urls[0]['url'] : '';

            $banners[] = [
                'id' => $banner_id,
                'title' => $title,
                'message' => $message ?: 'Please check this notification.',
                'type' => $banner_type,
                'url' => $url,
                'urls' => $urls,
                'html' => substr($html_content, 0, 1000),
                'page' => $page,
                'classes' => $classes,
                'priority' => $priority,
                'component_name' => $component_name // Store component name for better sender labeling
            ];
        }

        return $banners;
    }

    /**
     * Save banner directly to database (no REST API overhead)
     * This is more efficient than using REST API from PHP
     * 
     * PROFESSIONAL APPROACH:
     * - Direct database access (no HTTP overhead)
     * - Atomic operations (no race conditions)
     * - Better performance (no serialization/deserialization)
     */
    private function save_banner_directly($user_id, $banner_data)
    {
        if (!$this->storage || $user_id <= 0) {
            return false;
        }

        if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
            return false;
        }

        if (!$this->storage->ensure_notifications_tables()) {
            return false;
        }

        // Determine sender
        $sender = 'banner_' . ($banner_data['id'] ?? 'unknown');
        $classes = $banner_data['classes'] ?? '';
        $component_name = $banner_data['component_name'] ?? '';
        if ($component_name === '') {
            $component_name = $this->infer_banner_component_name(
                (string)($banner_data['id'] ?? ''),
                (string)$classes,
                (string)(($banner_data['title'] ?? '') . ' ' . ($banner_data['message'] ?? ''))
            );
        }
        $source_label = $component_name !== '' ? $component_name : __('WordPress Admin', 'yooadmin');
        if ($component_name !== '') {
            $sender = 'plugin_' . sanitize_key($component_name);
        }
        if (!empty($classes)) {
            if (preg_match('/plugin-([a-z0-9\-]+)/i', $classes, $matches)) {
                $sender = 'plugin_' . $matches[1];
            }
            elseif (preg_match('/theme-([a-z0-9\-]+)/i', $classes, $matches)) {
                $sender = 'theme_' . $matches[1];
            }
        }
        // Check if banner already exists (by meta.id for exact match)
        // Canonical, content-based identity shared with the JS REST path so the same
        // banner never becomes two rows and its dismissal tombstone keeps matching.
        $banner_id = $banner_data['id'] ?? 'unknown';
        $canonical_id = $this->canonical_banner_dedupe_key(
            $banner_data['title'] ?? '',
            $banner_data['message'] ?? ''
        );
        $banner_meta_id = $canonical_id !== '' ? $canonical_id : 'banner_' . $banner_id;

        // If the user already deleted (or snoozed) this banner, do NOT recreate it.
        if ($canonical_id !== '' && $this->is_dedupe_tombstoned($user_id, $canonical_id)) {
            return false;
        }

        // Use direct database query for faster duplicate check (more efficient than fetching all)
        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_notifications';

        // Check for existing banner by meta.id using SQL LIKE (faster than fetching all)
        $meta_id_pattern = '%"id":"' . $wpdb->esc_like($banner_meta_id) . '"%';
        $meta_banner_id_pattern = '%"banner_id":"' . $wpdb->esc_like($banner_id) . '"%';

        $existing_row = $wpdb->get_row(
            $wpdb->prepare(
            "SELECT id, title, message, meta FROM {$table} 
                WHERE user_id = %d 
                AND source_type = %s 
                AND (meta LIKE %s OR meta LIKE %s)
                AND (expires_at IS NULL OR expires_at > NOW())
                ORDER BY created_at DESC 
                LIMIT 1",
            $user_id,
            'banner',
            $meta_id_pattern,
            $meta_banner_id_pattern
        ),
            ARRAY_A
        );
        $exact_match = null;

        if ($existing_row) {
            // Parse meta to verify exact match
            $existing_meta = json_decode($existing_row['meta'] ?? '{}', true);
            $existing_meta_id = $existing_meta['id'] ?? null;
            $existing_banner_id = $existing_meta['banner_id'] ?? null;

            // Verify exact match (double-check to avoid false positives)
            if ($existing_meta_id === $banner_meta_id || $existing_banner_id === $banner_id) {
                $exact_match = [
                    'id' => $existing_row['id'],
                    'title' => $existing_row['title'],
                    'message' => $existing_row['message'],
                    'meta' => $existing_meta
                ];
            }
        }

        // Log if duplicate found (only in debug mode)
        if ($exact_match && defined('YOOADMIN_NOTIFICATIONS_DEBUG') && YOOADMIN_NOTIFICATIONS_DEBUG) {
        }

        // Prepare notification data
        $notification_data = [
            'title' => $banner_data['title'] ?? 'Admin Notice',
            'message' => $banner_data['message'] ?? 'Please check this notification.',
            'type' => $banner_data['type'] ?? 'notice',
            'priority' => $banner_data['priority'] ?? 'medium',
            'source' => $source_label,
            'source_type' => 'banner',
            'sender' => $sender,
            'url' => $banner_data['url'] ?? '',
            'status' => 'new',
            'dedupe_key' => $banner_meta_id,
            'meta' => json_encode([
                'id' => $banner_meta_id,
                'banner_id' => $banner_data['id'] ?? 'unknown',
                'banner_type' => $banner_data['type'] ?? 'notice',
                'original_html' => substr($banner_data['html'] ?? '', 0, 1000),
                'page' => $banner_data['page'] ?? 'unknown',
                'classes' => $banner_data['classes'] ?? '',
                'converted_at' => current_time('mysql'),
                'urls' => $banner_data['urls'] ?? [],
                'component_name' => $component_name // Store component name for better sender labeling
            ]),
            'group_id' => 'admin_banners',
            'updated_at' => current_time('mysql')
        ];
        // Log URLs being saved (only in debug mode to avoid performance issues)
        if (defined('YOOADMIN_NOTIFICATIONS_DEBUG') && YOOADMIN_NOTIFICATIONS_DEBUG) {
        }

        if ($exact_match) {
        // Banner already exists - update it but preserve status
            // This ensures that if banner_id changes slightly, we update the existing notification
            // instead of creating a duplicate
            $existing_status = $wpdb->get_var($wpdb->prepare(
                "SELECT status FROM {$table} WHERE id = %d",
                $exact_match['id']
            ));

            // Preserve existing status (don't reset read/dismissed notifications to 'new')
            if (!empty($existing_status) && $existing_status !== 'new') {
                $notification_data['status'] = $existing_status;
            }

            // Update the notification (even if status is preserved, content might have changed)
            $this->storage->update($exact_match['id'], $notification_data);

            if (defined('YOOADMIN_NOTIFICATIONS_DEBUG') && YOOADMIN_NOTIFICATIONS_DEBUG) {
            }
            return true; // Updated existing, prevent duplicate
        }
        else {
            // Create new notification
            $notification_data['user_id'] = $user_id;
            $notification_data['created_at'] = current_time('mysql');
            $notification_id = $this->storage->create($notification_data);
            if ($notification_id) {
                if (defined('YOOADMIN_NOTIFICATIONS_DEBUG') && YOOADMIN_NOTIFICATIONS_DEBUG) {
                }
                return true;
            }
            else {
                // Always log errors, even in production
                return false;
            }
        }
    }

    /**
     * Clear old banner notifications from database
     * This allows re-generating banners correctly after fixing parsing issues
     * Used via the AJAX handler in ui-integration.php
     */
    private function clear_old_banner_notifications($user_id)
    {
        if (!$this->storage || $user_id <= 0) {
            return false;
        }

        if (!$this->storage->ensure_notifications_tables()) {
            return false;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'yooadmin_notifications';
        $dismissed_table = $wpdb->prefix . 'yooadmin_dismissed_notifications';

        $banner_types = ['banner', 'banner-conversion', 'wp_admin_banner'];
        $placeholders = implode(',', array_fill(0, count($banner_types), '%s'));

        // Capture the identities being removed so their tombstones can be cleared too.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix; placeholders for IN list.
        $banner_dedupe_keys = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT dedupe_key FROM {$table} WHERE user_id = %d AND source_type IN ({$placeholders}) AND dedupe_key <> ''",
                array_merge([(int) $user_id], $banner_types)
            )
        );

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix; placeholders for IN list.
        $deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table} WHERE user_id = %d AND source_type IN ({$placeholders})",
                array_merge([(int) $user_id], $banner_types)
            )
        );

        // "Clear Banner Notifications" is a reset: it must let live admin banners be
        // re-converted (and restores snoozed/dismissed banners). The conversion path
        // skips any banner that still has a tombstone, so the banner tombstones have to
        // be removed here too — otherwise nothing comes back. Canonical banner
        // identities use the "banner_" dedupe_key prefix; the LIKE also catches
        // tombstones whose banner row was removed in an earlier session.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix; value bound via prepare().
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$dismissed_table} WHERE user_id = %d AND dedupe_key LIKE %s",
                (int) $user_id,
                $wpdb->esc_like('banner_') . '%'
            )
        );

        // Also clear tombstones for any banner identity that did not use the prefix.
        if (!empty($banner_dedupe_keys)) {
            $dk_placeholders = implode(',', array_fill(0, count($banner_dedupe_keys), '%s'));
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix; placeholders for IN list.
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$dismissed_table} WHERE user_id = %d AND dedupe_key IN ({$dk_placeholders})",
                    array_merge([(int) $user_id], $banner_dedupe_keys)
                )
            );
        }

        $this->clear_user_cache($user_id);
        $this->cache->delete_by_pattern('notifications_');
        $this->cache->delete_by_pattern('notification_count_');
        $this->cache->delete_by_pattern('notifications_hash_');

        return $deleted;
    }

    /**
     * REST API: Bulk actions
     */
    public function rest_bulk_action($request)
    {
        try {
            $user_id = get_current_user_id();

            if ($user_id <= 0) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'User not logged in'
                ], 401);
            }

            $params = $request->get_json_params();
            $action = sanitize_text_field($params['action'] ?? '');
            $ids = $params['ids'] ?? [];

            // Convert IDs to integers, but keep track of which ones are valid
            $processed_ids = [];
            foreach ($ids as $id) {
                // Try to convert to integer
                $int_id = intval($id);
                if ($int_id > 0) {
                    $processed_ids[] = $int_id;
                }
                else {
                    // If not numeric, might be custom_id or hash - keep as is
                    $processed_ids[] = $id;
                }
            }

            if (empty($action) || empty($processed_ids)) {
                return rest_ensure_response([
                    'success' => false,
                    'error' => 'Action and IDs are required'
                ], 400);
            }

            $success_count = 0;
            $failed_ids = [];

            foreach ($processed_ids as $index => $notification_id) {
                // Check if numeric ID
                if (is_numeric($notification_id)) {
                    $int_id = intval($notification_id);
                    if ($int_id <= 0) {
                        $failed_ids[] = $notification_id;
                        continue;
                    }
                    $notification_id = $int_id;
                }

                $result = false;

                switch ($action) {
                    case 'mark_read':
                        // If ID is not numeric, might be custom_id - need to find actual notification
                        if (!is_numeric($notification_id)) {
                            // Try to find notification by custom_id or hash
                            global $wpdb;
                            $table = $wpdb->prefix . 'yooadmin_notifications';
                            $found = $wpdb->get_row($wpdb->prepare(
                                "SELECT id FROM {$table} WHERE user_id = %d AND (meta LIKE %s OR meta LIKE %s)",
                                $user_id,
                                '%"id":"' . $wpdb->esc_like($notification_id) . '"%',
                                '%"custom_id":"' . $wpdb->esc_like($notification_id) . '"%'
                            ), ARRAY_A);

                            if ($found && isset($found['id'])) {
                                $notification_id = intval($found['id']);
                            }
                            else {
                                $failed_ids[] = $notification_id;
                                continue 2; // Skip to next ID
                            }
                        }

                        // Check if notification exists and belongs to user
                        global $wpdb;
                        $table = $wpdb->prefix . 'yooadmin_notifications';
                        $exists = $wpdb->get_var($wpdb->prepare(
                            "SELECT id FROM {$table} WHERE id = %d AND user_id = %d",
                            $notification_id,
                            $user_id
                        ));

                        if (!$exists) {
                            $failed_ids[] = $notification_id;
                            continue 2;
                        }

                        $result = $this->storage->mark_as_read($notification_id, $user_id);
                        break;

                    case 'mark_unread':
                        $result = $this->storage->update($notification_id, [
                            'status' => 'new',
                            'updated_at' => current_time('mysql')
                        ]);
                        break;

                    case 'delete':
                        global $wpdb;
                        $table = $wpdb->prefix . 'yooadmin_notifications';

                        // Resolve non-numeric (meta) ids to the real row id.
                        if (!is_numeric($notification_id)) {
                            $found = $wpdb->get_row($wpdb->prepare(
                                "SELECT id FROM {$table} WHERE user_id = %d AND (meta LIKE %s OR meta LIKE %s)",
                                $user_id,
                                '%"id":"' . $wpdb->esc_like($notification_id) . '"%',
                                '%"custom_id":"' . $wpdb->esc_like($notification_id) . '"%'
                            ), ARRAY_A);

                            if ($found && isset($found['id'])) {
                                $notification_id = intval($found['id']);
                            } else {
                                $failed_ids[] = $notification_id;
                                continue 2;
                            }
                        }

                        // Route through dismiss(permanent): writes a condition-aware
                        // tombstone (dedupe_key + fingerprint) before deleting the row,
                        // so the item does not immediately re-collect.
                        $result = $this->dismiss_notification($user_id, $notification_id, 'permanent');
                        break;

                    case 'snooze':
                        $duration = sanitize_text_field($params['duration'] ?? '1 hour');
                        // Resolve non-numeric IDs to real notification IDs
                        if (!is_numeric($notification_id)) {
                            global $wpdb;
                            $table = $wpdb->prefix . 'yooadmin_notifications';
                            $found = $wpdb->get_row($wpdb->prepare(
                                "SELECT id FROM {$table} WHERE user_id = %d AND (meta LIKE %s OR meta LIKE %s)",
                                $user_id,
                                '%"id":"' . $wpdb->esc_like($notification_id) . '"%',
                                '%"custom_id":"' . $wpdb->esc_like($notification_id) . '"%'
                            ), ARRAY_A);

                            if ($found && isset($found['id'])) {
                                $notification_id = intval($found['id']);
                            }
                            else {
                                $failed_ids[] = $notification_id;
                                continue 2;
                            }
                        }

                        // Confirm the notification belongs to the user
                        global $wpdb;
                        $table = $wpdb->prefix . 'yooadmin_notifications';
                        $exists = $wpdb->get_var($wpdb->prepare(
                            "SELECT id FROM {$table} WHERE id = %d AND user_id = %d",
                            $notification_id,
                            $user_id
                        ));

                        if (!$exists) {
                            $failed_ids[] = $notification_id;
                            continue 2;
                        }

                        if ($this->filters && method_exists($this->filters, 'snooze_notification')) {
                            $result = $this->filters->snooze_notification($user_id, $notification_id, $duration);
                            if ($result) {
                                // Also mark status as snoozed so it leaves the inbox view immediately
                                $this->storage->update($notification_id, [
                                    'status' => 'snoozed',
                                    'updated_at' => current_time('mysql')
                                ]);
                                // Clear caches for this user so snoozed tab refreshes correctly
                                $this->clear_user_cache($user_id);
                            }
                        }
                        break;
                }

                if ($result) {
                    $success_count++;
                }
                else {
                    $failed_ids[] = $notification_id;
                }
            }

            if ($success_count > 0) {
                $this->clear_user_cache($user_id);
            }

            return rest_ensure_response([
                'success' => true,
                'message' => sprintf('%d notification(s) %s', $success_count, $action === 'delete' ? 'deleted' : 'updated'),
                'count' => $success_count,
                'failed_ids' => $failed_ids
            ]);
        }
        catch (Exception $e) {
            return rest_ensure_response([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get notification counts for all tabs
     */
    public function rest_get_counts($request)
    {
        $user_id = get_current_user_id();

        if ($user_id <= 0) {
            return rest_ensure_response([
                'success' => false,
                'error' => 'User not logged in'
            ], 401);
        }

        // Get counts for each view
        $all_notifications = $this->get_notifications($user_id, ['limit' => 1000]);
        $unread_notifications = $this->get_notifications($user_id, ['status' => 'new', 'limit' => 1000]);
        $snoozed_notifications = $this->get_notifications($user_id, ['status' => 'snoozed', 'limit' => 500]);

        return rest_ensure_response([
            'success' => true,
            'data' => [
                'all' => count($all_notifications),
                'unread' => count($unread_notifications),
                'snoozed' => count($snoozed_notifications)
            ]
        ]);
    }

    /**
     * AJAX: Load more notifications (for infinite scroll)
     */
    public function ajax_load_more_notifications()
    {
        check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

        $user_id = get_current_user_id();

        if ($user_id <= 0) {
            wp_send_json_error(['message' => 'User not logged in']);
            exit;
        }

        $view = isset($_POST['view']) ? sanitize_text_field(wp_unslash($_POST['view'])) : 'all';
        $offset = intval($_POST['offset'] ?? 0);
        $limit = intval($_POST['limit'] ?? 10);
        if ($limit < 1) {
            $limit = 10;
        }
        $limit = min(200, $limit);

        // Prepare options based on view
        $options = [];

        switch ($view) {
            case 'unread':
                $options['status'] = 'new';
                break;
            case 'snoozed':
                $options['status'] = 'snoozed';
                break;
            case 'archived':
                $options['show_archived']   = true;
                $options['status']          = 'archived';
                $options['show_dismissed']   = true;
                break;
            default:
                // 'all' - no status filter
                break;
        }

        $page          = $this->get_notifications_flat_page($user_id, $options, $offset, $limit);
        $notifications = $page['items'];
        $has_more      = $page['has_more'];

        // Render HTML for each notification
        ob_start();

        if (!empty($notifications)) {
            foreach ($notifications as $notification) {
                $this->render_notification_item($notification, $view);
            }
        }

        $html = ob_get_clean();

        wp_send_json_success([
            'html'     => $html,
            'has_more' => $has_more,
            'count'    => $page['count'],
            'total'    => $page['total'] ?? count($notifications),
            'offset'   => $offset + $page['count'],
        ]);
        exit;
    }

    /**
     * Render a single notification item (shared by both initial load and AJAX)
     */
    public function render_notification_item($notification, $current_filter = 'all')
    {
        // Extract notification data (storage uses "id"; legacy rows may use notification_id).
        $notification_id = (int) ($notification['id'] ?? $notification['notification_id'] ?? 0);
        $meta          = $notification['meta'] ?? [];
        if (is_string($meta)) {
            $meta = json_decode($meta, true) ?: [];
        }
        if (!is_array($meta)) {
            $meta = [];
        }
        $custom_id = $notification['custom_id'] ?? ($meta['id'] ?? '');
        $hash = $notification['hash'] ?? '';

        // Determine primary ID for actions
        $primary_id = $notification_id > 0 ? $notification_id : ($custom_id ?: ($hash ?: uniqid()));

        $status = $notification['status'] ?? 'new';
        $title = $notification['title'] ?? '';
        $message = $notification['message'] ?? '';
        $source = $notification['source'] ?? '';
        $created = $notification['created_at'] ?? '';
        $url = $notification['url'] ?? '';
        $type = $notification['type'] ?? '';
        $source_type = $notification['source_type'] ?? '';

        // Icon mapping
        $icon_map = [
            'plugin' => 'dashicons-admin-plugins',
            'theme' => 'dashicons-admin-appearance',
            'core' => 'dashicons-wordpress',
            'error' => 'dashicons-warning',
            'update' => 'dashicons-update',
            'success' => 'dashicons-yes-alt',
            'info' => 'dashicons-info',
            'admin' => 'dashicons-admin-site',
        ];
        $icon = $icon_map[$type] ?? $icon_map[$source_type] ?? 'dashicons-bell';

        $time_ago = $created
            ? sprintf(
                /* translators: %s: human-readable time difference */
                __('%s ago', 'yooadmin'),
                human_time_diff(strtotime($created), current_time('timestamp'))
            )
            : '';

        $unread_class = ($status === 'new') ? 'yp-inbox-item-unread' : '';
?>
        <div class="yp-inbox-item <?php echo esc_attr($unread_class); ?>" 
             data-id="<?php echo esc_attr($primary_id); ?>"
             data-db-id="<?php echo esc_attr($notification_id); ?>"
             data-custom-id="<?php echo esc_attr($custom_id); ?>"
             data-title="<?php echo esc_attr($title); ?>"
             data-message="<?php echo esc_attr($message); ?>"
             data-source="<?php echo esc_attr($source); ?>"
             data-time="<?php echo esc_attr($time_ago); ?>"
             data-url="<?php echo esc_attr($url); ?>"
             data-type="<?php echo esc_attr($type); ?>"
             data-source-type="<?php echo esc_attr($source_type); ?>"
             data-icon="<?php echo esc_attr($icon); ?>">
            
            <label class="yp-item-checkbox">
                <input type="checkbox" class="yp-item-select" value="<?php echo esc_attr($primary_id); ?>">
                <span class="yp-checkbox-custom"></span>
            </label>
            
            <div class="yp-item-icon">
                <span class="dashicons <?php echo esc_attr($icon); ?>"></span>
            </div>
            
            <div class="yp-item-content">
                <div class="yp-item-header">
                    <div class="yp-item-title" style="<?php echo $status === 'new' ? 'font-weight: 600;' : 'font-weight: 400;'; ?>">
                        <?php echo esc_html($title); ?>
                        <?php if ($time_ago): ?>
                            <span class="yp-item-time"><?php echo esc_html($time_ago); ?></span>
                        <?php
        endif; ?>
                    </div>
                </div>
                <div class="yp-item-message"><?php echo wp_kses_post($message); ?></div>
                <?php if ($source): ?>
                    <div class="yp-item-source"><?php echo esc_html($source); ?></div>
                <?php
        endif; ?>
            </div>
            
            <div class="yp-item-actions">
                <?php if ($current_filter === 'snoozed'): ?>
                    <!-- Snoozed view: only Unsnooze and Delete -->
                    <button type="button" class="yp-action-icon yp-unsnooze" 
                            data-id="<?php echo esc_attr($primary_id); ?>"
                            title="<?php esc_attr_e('Unsnooze', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-clock"></span>
                    </button>
                    <button type="button" class="yp-action-icon yp-delete" 
                            data-id="<?php echo esc_attr($primary_id); ?>"
                            data-db-id="<?php echo esc_attr($notification_id); ?>"
                            data-custom-id="<?php echo esc_attr($custom_id); ?>"
                            title="<?php esc_attr_e('Delete', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-trash"></span>
                    </button>
                <?php
        else: ?>
                    <!-- Default view: Mark Read/Unread, Snooze, Delete -->
                    <?php if ($status === 'new'): ?>
                        <button type="button" class="yp-action-icon yp-mark-read" 
                                data-id="<?php echo esc_attr($primary_id); ?>"
                                data-db-id="<?php echo esc_attr($notification_id); ?>"
                                data-custom-id="<?php echo esc_attr($custom_id); ?>"
                                title="<?php esc_attr_e('Mark as read', 'yooadmin'); ?>">
                            <span class="dashicons dashicons-yes"></span>
                        </button>
                    <?php
            else: ?>
                        <button type="button" class="yp-action-icon yp-mark-unread" 
                                data-id="<?php echo esc_attr($primary_id); ?>"
                                data-db-id="<?php echo esc_attr($notification_id); ?>"
                                data-custom-id="<?php echo esc_attr($custom_id); ?>"
                                title="<?php esc_attr_e('Mark as unread', 'yooadmin'); ?>">
                            <span class="dashicons dashicons-marker"></span>
                        </button>
                    <?php
            endif; ?>
                    <button type="button" class="yp-action-icon yp-snooze" 
                            data-id="<?php echo esc_attr($primary_id); ?>"
                            title="<?php esc_attr_e('Snooze', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-clock"></span>
                    </button>
                    <button type="button" class="yp-action-icon yp-delete" 
                            data-id="<?php echo esc_attr($primary_id); ?>"
                            data-db-id="<?php echo esc_attr($notification_id); ?>"
                            data-custom-id="<?php echo esc_attr($custom_id); ?>"
                            title="<?php esc_attr_e('Delete', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-trash"></span>
                    </button>
                <?php
        endif; ?>
            </div>
        </div>
        <?php
    }


}

// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
// phpcs:enable WordPress.DB.DirectDatabaseQuery.SchemaChange
// phpcs:enable PluginCheck.Security.DirectDB.UnescapedDBParameter

// Initialize integration
function yooadmin_get_integration()
{
    static $integration = null;
        // Prevent multiple initialization - check if already initialized
    if ($integration === null) {
        $integration = new YOOAdmin_Integration();
        $integration->initialize();
    }

    return $integration;
}

// Auto-initialize on init (after text domain loads; WP 6.7+ disallows translation loading before init).
add_action(
    'init',
    static function () {
        if (!defined('YOOADMIN_NOTIFICATIONS_INITIALIZED')) {
            yooadmin_get_integration();
            define('YOOADMIN_NOTIFICATIONS_INITIALIZED', true);
            yooadmin_integration_log('[YP Notifications] Integration initialized ONCE - FINAL');
        }
    },
    5
);

// Force REST API registration on init hook (for maximum compatibility)
        // Prevent duplicate route registration
add_action('init', function () {
    static $routes_registered = false;

    if ($routes_registered || !defined('YOOADMIN_NOTIFICATIONS_INITIALIZED')) {
        return;
    }

    $routes_registered = true;
    $integration = function_exists('yooadmin_get_integration') ? yooadmin_get_integration() : null;
    if (!$integration) {
        return;
    }

    // Register routes via rest_api_init hook (correct way)
    add_action('rest_api_init', function () use ($integration) {
            if (function_exists('register_rest_route')) {
                // Notifications endpoint
                register_rest_route('yooadmin/v1', '/notifications', [
                    'methods' => 'GET',
                    'callback' => [$integration, 'rest_get_notifications'],
                    'permission_callback' => [$integration, 'rest_permissions_check']
                ]);

                yooadmin_integration_log('[YP Notifications] REST routes registered on rest_api_init hook');
            }
        }
            , 10);
    }, 10);

// REST API registration is handled in initialize_rest_api() method via rest_api_init hook

// Final lock - prevent any other initialization
        // Use static flag to prevent multiple executions
add_action('init', function () {
    static $finalized = false;

    if ($finalized || defined('YOOADMIN_NOTIFICATIONS_FULLY_INITIALIZED')) {
        return;
    }

    $finalized = true;
    define('YOOADMIN_NOTIFICATIONS_FULLY_INITIALIZED', true);
    yooadmin_integration_log('[YP Notifications] System fully initialized - FINAL');
}, 10); // Priority 10 to run last

// System verification
add_action('admin_init', function () {
    // Verify all components are loaded properly
    $components = [
        'YOOAdmin_Database_Storage' => class_exists('YOOAdmin_Database_Storage'),
        'YOOAdmin_Cache' => class_exists('YOOAdmin_Cache'),
        'YOOAdmin_Smart_Collector' => class_exists('YOOAdmin_Smart_Collector'),
        'YOOAdmin_Integration' => class_exists('YOOAdmin_Integration'),
        'YOOAdmin_UI_Manager' => class_exists('YOOAdmin_UI_Manager')
    ];

    $all_loaded = array_reduce($components, function ($carry, $loaded) {
            return $carry && $loaded;
        }
            , true);

        if ($all_loaded) {
            yooadmin_integration_log('[YP Notifications] All components loaded successfully');
        }
        else {
            yooadmin_integration_log('[YP Notifications] Missing components: ' . json_encode($components));

            // Try to load missing components
            $missing = array_filter($components, function ($loaded) {
                    return !$loaded;
                }
                );

                foreach ($missing as $component => $status) {
                    yooadmin_integration_log('[YP Notifications] Attempting to load missing component: ' . $component);
                }
            }
        });
