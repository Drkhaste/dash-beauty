<?php
/**
 * YOOAdmin - User preferences (notifications)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Load compatibility functions first
require_once __DIR__ . '/compatibility.php';

if (!function_exists('yooadmin_notification_preferences_capability')) {
    /**
     * Capability for per-user notification preferences (menu, page, AJAX).
     *
     * Uses `read` by design: any admin-area user who receives notifications may
     * customize their own filters and display options. Site-wide notification
     * settings remain restricted to manage_options in admin settings.
     *
     * @return string
     */
    function yooadmin_notification_preferences_capability(): string
    {
        return (string) apply_filters('yooadmin_notification_preferences_capability', 'read');
    }
}

if (!function_exists('yooadmin_my_preferences_toggle')) {
    /**
     * Render a settings-style toggle (matches YOOAdmin Settings page).
     *
     * @param string $name    Form field name.
     * @param string $label   Visible label beside the switch.
     * @param bool   $checked Whether the toggle is on.
     * @param string $id      Optional input id (auto-generated from $name when empty).
     */
    function yooadmin_my_preferences_toggle(string $name, string $label, bool $checked, string $id = ''): void
    {
        if ($id === '') {
            $id = 'yp-pref-' . preg_replace('/[^a-z0-9_-]/i', '_', $name);
        }
        ?>
        <div class="yp-toggle-container">
            <label class="yp-toggle-switch">
                <input type="checkbox" id="<?php echo esc_attr($id); ?>" name="<?php echo esc_attr($name); ?>" value="1" <?php checked($checked); ?>>
                <span class="yp-toggle-slider"></span>
            </label>
            <div class="yp-toggle-label-wrapper">
                <label for="<?php echo esc_attr($id); ?>" class="yp-toggle-label"><?php echo esc_html($label); ?></label>
            </div>
        </div>
        <?php
    }
}

class YOOAdmin_User_Preferences
{

    private $storage;
    private $cache;

    public function __construct()
    {
        $this->storage = yooadmin_get_storage();
        $this->cache = yooadmin_get_cache();

        add_action('admin_init', [$this, 'maybe_guard_preferences_routes']);
        add_action('admin_init', [$this, 'maybe_redirect_legacy_preferences_slug']);
        add_action('wp_ajax_yooadmin_save_user_preferences', [$this, 'ajax_save_preferences']);
        add_action('wp_ajax_yooadmin_get_user_preferences', [$this, 'ajax_get_preferences']);
        add_action('wp_ajax_yooadmin_reset_user_preferences', [$this, 'ajax_reset_preferences']);

        add_action('admin_menu', [$this, 'add_preferences_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_preferences_assets']);
    }

    /**
     * Block personal preferences when Focus Mode is off; send users to enable-focus instead.
     */
    public function maybe_guard_preferences_routes(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route guard.
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash((string) $_GET['page'])) : '';
        if (!in_array($page, ['yooadmin-my-preferences', 'yooadmin-notification-preferences'], true)) {
            return;
        }

        $enable_focus_url = function_exists('yooadmin_enable_focus_url')
            ? yooadmin_enable_focus_url()
            : admin_url('admin.php?page=yooadmin-enable-focus');

        if ($page === 'yooadmin-notification-preferences') {
            $target = (function_exists('yooadmin_user_can_view_my_preferences') && yooadmin_user_can_view_my_preferences())
                ? admin_url('admin.php?page=yooadmin-my-preferences')
                : $enable_focus_url;
            wp_safe_redirect($target);
            exit;
        }

        if (function_exists('yooadmin_user_can_view_my_preferences') && !yooadmin_user_can_view_my_preferences()) {
            wp_safe_redirect($enable_focus_url);
            exit;
        }
    }

    /**
     * Legacy slug redirect (notification preferences → my preferences).
     */
    public function maybe_redirect_legacy_preferences_slug(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route alias.
        if (!isset($_GET['page']) || sanitize_key(wp_unslash($_GET['page'])) !== 'yooadmin-notification-preferences') {
            return;
        }

        wp_safe_redirect(admin_url('admin.php?page=yooadmin-my-preferences'));
        exit;
    }

    /**
     * Enqueue assets for the preferences page
     */
    public function enqueue_preferences_assets($hook)
    {
        if (
            strpos($hook, 'yooadmin-my-preferences') === false
            && strpos($hook, 'yooadmin-notification-preferences') === false
        ) {
            return;
        }

        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php';
        $base_url = plugin_dir_url($base_file);
        $base_dir = plugin_dir_path($base_file);

        $settings_css = 'assets/css/admin/yp-settings.css';
        if (file_exists($base_dir . $settings_css)) {
            $settings_deps = ['yooadmin-core'];
            if (wp_style_is('yooadmin-yoo-buttons', 'registered') || wp_style_is('yooadmin-yoo-buttons', 'enqueued')) {
                $settings_deps[] = 'yooadmin-yoo-buttons';
            }
            foreach (['yooadmin-studio-hub-dashboard', 'yooadmin-studio-hub-late'] as $theme_style) {
                if (wp_style_is($theme_style, 'registered') || wp_style_is($theme_style, 'enqueued')) {
                    $settings_deps[] = $theme_style;
                }
            }
            wp_enqueue_style(
                'yooadmin-settings',
                $base_url . $settings_css,
                $settings_deps,
                (string) filemtime($base_dir . $settings_css)
            );
        }

        $css_path = 'assets/css/admin/notification-preferences.css';
        if (file_exists($base_dir . $css_path)) {
            $pref_deps = wp_style_is('yooadmin-settings', 'registered') || wp_style_is('yooadmin-settings', 'enqueued')
                ? ['yooadmin-settings']
                : ['yooadmin-core'];
            wp_enqueue_style('yooadmin-notification-preferences', $base_url . $css_path, $pref_deps, (string) filemtime($base_dir . $css_path));
        }

        $js_path = 'assets/js/admin/notification-preferences.js';
        if (file_exists($base_dir . $js_path)) {
            wp_enqueue_script('yooadmin-notification-preferences', $base_url . $js_path, ['jquery'], (string) filemtime($base_dir . $js_path), true);
            wp_localize_script('yooadmin-notification-preferences', 'yooadmNotifPrefs', [
                'saveNonce'    => wp_create_nonce('yooadmin_preferences_nonce'),
                'resetNonce'   => wp_create_nonce('yooadmin_preferences_nonce'),
                'savedMsg'     => __('Preferences saved successfully!', 'yooadmin'),
                'confirmReset' => __('Are you sure you want to reset all preferences to default values?', 'yooadmin'),
            ]);
        }

        if (function_exists('yooadmin_enqueue_focus_toggle_assets')) {
            yooadmin_enqueue_focus_toggle_assets();
        }

        if (class_exists('YOOAdmin_Guided_Tour')) {
            YOOAdmin_Guided_Tour::enqueue_reset_script_for_preferences_page();
        }
    }

    /**
     * Add preferences menu
     */
    public function add_preferences_menu()
    {
        if (
            function_exists('yooadmin_user_can_manage_site_settings')
            && yooadmin_user_can_manage_site_settings()
        ) {
            return;
        }

        if (!function_exists('yooadmin_is_focus_enabled') || !yooadmin_is_focus_enabled()) {
            return;
        }

        $cap = function_exists('yooadmin_user_preferences_page_capability')
            ? yooadmin_user_preferences_page_capability()
            : yooadmin_notification_preferences_capability();

        add_submenu_page(
            'yooadmin-dashboard',
            __('My YOOAdmin Preferences', 'yooadmin'),
            __('My Preferences', 'yooadmin'),
            $cap,
            'yooadmin-my-preferences',
            [$this, 'render_preferences_page'],
            28
        );
    }

    /**
     * Render preferences page
     */
    public function render_preferences_page()
    {
        if (!current_user_can(yooadmin_user_preferences_page_capability())) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'yooadmin'));
        }

        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $user_id = get_current_user_id();
        $preferences = $this->get_user_preferences($user_id);

        // Sync: read notification_sound_enabled from notification settings into display_options
        $notif_prefs = get_user_meta($user_id, 'yooadmin_notification_preferences', true);
        if (is_array($notif_prefs) && isset($notif_prefs['notification_sound_enabled'])) {
            $preferences['display_options']['show_sounds'] = !empty($notif_prefs['notification_sound_enabled']);
        }

        $focus_policy = function_exists('yooadmin_get_focus_policy') ? yooadmin_get_focus_policy() : 'auto';
        $focus_active = function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();
        $dashboard_url = function_exists('yooadmin_dashboard_url')
            ? yooadmin_dashboard_url()
            : admin_url('admin.php?page=yooadmin-dashboard');

        $tpl = plugin_dir_path(
            defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 2) . '/yooadmin.php'
        ) . 'templates/yoopixel/admin/pages/yoopanel/my-preferences.php';

        $pref_notification_types   = $this->get_notification_types();
        $pref_notification_sources   = $this->get_notification_sources();
        $pref_email_triggers         = $this->get_email_triggers();
        $pref_show_email_section     = $pref_email_triggers !== []
            || yooadmin_user_can_manage_site_settings();
        $yp_is_regular_user            = function_exists('yooadmin_is_site_regular_user') && yooadmin_is_site_regular_user();
        $yp_show_notifications_tab     = !$yp_is_regular_user;
        $yp_show_guided_tour_reset       = !$yp_is_regular_user;

        if (is_readable($tpl)) {
            include $tpl;
            return;
        }

        echo '<div class="wrap"><h1>' . esc_html__('My YOOAdmin Preferences', 'yooadmin') . '</h1>';
        echo '<p>' . esc_html__('Template not found:', 'yooadmin') . ' my-preferences.php</p></div>';
    }

    /**
     * Get user preferences
     */
    public function get_user_preferences($user_id)
    {
        $cache_key = "yooadmin_user_preferences_{$user_id}";
        $cached = $this->cache->get($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        $preferences = $this->storage->get_user_preferences($user_id);

        // Merge with defaults
        $defaults = $this->get_default_preferences();
        $merged = array_merge_recursive($defaults, $preferences);

        // Cache for 30 minutes
        $this->cache->set($cache_key, $merged, 1800);

        return $merged;
    }

    /**
     * Save user preferences
     */
    public function save_user_preferences($user_id, $preferences)
    {
        // Validate preferences
        $validated = $this->validate_preferences($preferences);

        // Save to storage
        $result = $this->storage->save_user_preferences($user_id, $validated);

        if ($result) {
            // Clear cache
            $cache_key = "yooadmin_user_preferences_{$user_id}";
            $this->cache->delete($cache_key);

            // Sync show_sounds with notification_sound_enabled used by the notification UI
            if (isset($validated['display_options']['show_sounds'])) {
                $notif_prefs = get_user_meta($user_id, 'yooadmin_notification_preferences', true);
                if (!is_array($notif_prefs)) {
                    $notif_prefs = [];
                }
                $notif_prefs['notification_sound_enabled'] = $validated['display_options']['show_sounds'];
                update_user_meta($user_id, 'yooadmin_notification_preferences', $notif_prefs);
            }

            do_action('yooadmin_user_preferences_saved', $user_id, $validated);
        }

        return $result;
    }

    /**
     * Reset user preferences to defaults
     */
    public function reset_user_preferences($user_id)
    {
        $defaults = $this->get_default_preferences();

        return $this->save_user_preferences($user_id, $defaults);
    }

    /**
     * Get default preferences
     */
    private function get_default_preferences()
    {
        return [
            'notification_types' => [
                'wordpress_core' => true,
                'plugin_updates' => true,
                'theme_updates' => true,
                'translation_updates' => true,
                'security' => true,
                'backup' => true,
                'performance' => true,
                'user_activity' => false,
                'system' => true,
                'comments' => true,
            ],
            'notification_sources' => [
                'wordpress' => true,
                'plugin' => true,
                'theme' => true,
                'system' => true,
                'user' => true
            ],
            'priority_filter' => 'all',
            'display_options' => [
                'show_badge' => true,
                'show_desktop' => false,
                'show_sounds' => false,
                'auto_refresh' => true,
                'refresh_interval' => 30
            ],
            'email_options' => [
                'enabled' => false,
                'frequency' => 'daily',
                'triggers' => [
                    'critical' => true,
                    'security' => true,
                    'backup' => false,
                    'updates' => false
                ]
            ]
        ];
    }

    /**
     * Validate preferences
     */
    private function validate_preferences($preferences)
    {
        $validated = [];
        $defaults = $this->get_default_preferences();

        // Validate notification types
        if (isset($preferences['notification_types']) && is_array($preferences['notification_types'])) {
            $validated['notification_types'] = [];
            foreach (array_keys($defaults['notification_types']) as $type) {
                if (
                    function_exists('yooadmin_user_can_manage_notification_preference_item')
                    && !yooadmin_user_can_manage_notification_preference_item('type', $type)
                ) {
                    $validated['notification_types'][$type] = false;
                    continue;
                }
                $validated['notification_types'][$type] = !empty($preferences['notification_types'][$type]);
            }
        }

        // Validate notification sources
        if (isset($preferences['notification_sources']) && is_array($preferences['notification_sources'])) {
            $validated['notification_sources'] = [];
            foreach (array_keys($defaults['notification_sources']) as $source) {
                if (
                    function_exists('yooadmin_user_can_manage_notification_preference_item')
                    && !yooadmin_user_can_manage_notification_preference_item('source', $source)
                ) {
                    $validated['notification_sources'][$source] = false;
                    continue;
                }
                $validated['notification_sources'][$source] = !empty($preferences['notification_sources'][$source]);
            }
        }

        // Validate priority filter
        $valid_filters = ['all', 'high_only', 'critical_only'];
        $validated['priority_filter'] = in_array($preferences['priority_filter'] ?? 'all', $valid_filters)
            ? $preferences['priority_filter']
            : 'all';

        // Validate display options
        if (isset($preferences['display_options']) && is_array($preferences['display_options'])) {
            $validated['display_options'] = [
                'show_badge' => !empty($preferences['display_options']['show_badge']),
                'show_desktop' => !empty($preferences['display_options']['show_desktop']),
                'show_sounds' => !empty($preferences['display_options']['show_sounds']),
                'auto_refresh' => !empty($preferences['display_options']['auto_refresh']),
                'refresh_interval' => is_numeric($preferences['display_options']['refresh_interval'])
                ? max(10, min(300, intval($preferences['display_options']['refresh_interval'])))
                : 30
            ];
        }

        // Validate email options
        if (isset($preferences['email_options']) && is_array($preferences['email_options'])) {
            $validated['email_options'] = [
                'enabled' => !empty($preferences['email_options']['enabled']),
                'frequency' => in_array($preferences['email_options']['frequency'] ?? 'daily', ['immediate', 'hourly', 'daily', 'weekly'])
                ? $preferences['email_options']['frequency']
                : 'daily'
            ];

            if (isset($preferences['email_options']['triggers']) && is_array($preferences['email_options']['triggers'])) {
                $validated['email_options']['triggers'] = [];
                foreach (array_keys($defaults['email_options']['triggers']) as $trigger) {
                    if (
                        function_exists('yooadmin_user_can_manage_notification_preference_item')
                        && !yooadmin_user_can_manage_notification_preference_item('email_trigger', $trigger)
                    ) {
                        $validated['email_options']['triggers'][$trigger] = false;
                        continue;
                    }
                    $validated['email_options']['triggers'][$trigger] = !empty($preferences['email_options']['triggers'][$trigger]);
                }
            }
        }

        return $validated;
    }

    /**
     * Get notification types
     */
    private function get_notification_types()
    {
        $types = [
            'wordpress_core' => __('WordPress Core Updates', 'yooadmin'),
            'plugin_updates' => __('Plugin Updates', 'yooadmin'),
            'theme_updates' => __('Theme Updates', 'yooadmin'),
            'translation_updates' => __('Translation Updates', 'yooadmin'),
            'security' => __('Security Notifications', 'yooadmin'),
            'backup' => __('Backup Notifications', 'yooadmin'),
            'performance' => __('Performance Notifications', 'yooadmin'),
            'user_activity' => __('User Activity', 'yooadmin'),
            'system' => __('System Notifications', 'yooadmin'),
            'comments' => __('Comments', 'yooadmin'),
        ];

        if (function_exists('yooadmin_filter_notification_preference_options')) {
            return yooadmin_filter_notification_preference_options($types, 'type');
        }

        return $types;
    }

    /**
     * Get notification sources
     */
    private function get_notification_sources()
    {
        $sources = [
            'wordpress' => __('WordPress Core', 'yooadmin'),
            'plugin' => __('Plugins', 'yooadmin'),
            'theme' => __('Themes', 'yooadmin'),
            'system' => __('System', 'yooadmin'),
            'user' => __('Users', 'yooadmin'),
        ];

        if (function_exists('yooadmin_filter_notification_preference_options')) {
            return yooadmin_filter_notification_preference_options($sources, 'source');
        }

        return $sources;
    }

    /**
     * Get email triggers
     */
    private function get_email_triggers()
    {
        $triggers = [
            'critical' => __('Critical notifications', 'yooadmin'),
            'security' => __('Security notifications', 'yooadmin'),
            'backup' => __('Backup notifications', 'yooadmin'),
            'updates' => __('Update notifications', 'yooadmin'),
        ];

        if (function_exists('yooadmin_filter_notification_preference_options')) {
            return yooadmin_filter_notification_preference_options($triggers, 'email_trigger');
        }

        return $triggers;
    }

    /**
     * AJAX handler for saving preferences
     */
    public function ajax_save_preferences()
    {
        if (!check_ajax_referer('yooadmin_preferences_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed', 'yooadmin')]);
        }

        if (!current_user_can(yooadmin_notification_preferences_capability())) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')], 403);
        }

        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(['message' => __('User not logged in', 'yooadmin')]);
        }

        // Parse and validate preferences
        $preferences = [];

        // Parse notification types
        if (isset($_POST['notification_types']) && is_array($_POST['notification_types'])) {
            $preferences['notification_types'] = array_map('sanitize_text_field', wp_unslash($_POST['notification_types']));
        }

        // Parse notification sources
        if (isset($_POST['notification_sources']) && is_array($_POST['notification_sources'])) {
            $preferences['notification_sources'] = array_map('sanitize_text_field', wp_unslash($_POST['notification_sources']));
        }

        // Parse priority filter
        if (isset($_POST['priority_filter'])) {
            $preferences['priority_filter'] = sanitize_text_field(wp_unslash($_POST['priority_filter']));
        }

        // Parse display options
        if (isset($_POST['display_options']) && is_array($_POST['display_options'])) {
            $preferences['display_options'] = array_map('sanitize_text_field', wp_unslash($_POST['display_options']));
        }

        // Parse email options
        if (isset($_POST['email_options']) && is_array($_POST['email_options'])) {
            $preferences['email_options'] = array_map('sanitize_text_field', wp_unslash($_POST['email_options']));
        }

        $result = $this->save_user_preferences($user_id, $preferences);

        if ($result) {
            wp_send_json_success(['message' => __('Preferences saved successfully', 'yooadmin')]);
        }
        else {
            wp_send_json_error(['message' => __('Failed to save preferences', 'yooadmin')]);
        }
    }

    /**
     * AJAX handler for getting preferences
     */
    public function ajax_get_preferences()
    {
        if (!check_ajax_referer('yooadmin_preferences_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed', 'yooadmin')]);
        }

        if (!current_user_can(yooadmin_notification_preferences_capability())) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')], 403);
        }

        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(['message' => __('User not logged in', 'yooadmin')]);
        }

        $preferences = $this->get_user_preferences($user_id);
        wp_send_json_success($preferences);
    }

    /**
     * AJAX handler for resetting preferences
     */
    public function ajax_reset_preferences()
    {
        if (!check_ajax_referer('yooadmin_preferences_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed', 'yooadmin')]);
        }

        if (!current_user_can(yooadmin_notification_preferences_capability())) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')], 403);
        }

        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(['message' => __('User not logged in', 'yooadmin')]);
        }

        $result = $this->reset_user_preferences($user_id);

        if ($result) {
            wp_send_json_success(['message' => __('Preferences reset successfully', 'yooadmin')]);
        }
        else {
            wp_send_json_error(['message' => __('Failed to reset preferences', 'yooadmin')]);
        }
    }
}

// Initialize user preferences
function yooadmin_get_user_preferences()
{
    static $instance = null;

    if ($instance === null) {
        $instance = new YOOAdmin_User_Preferences();
    }

    return $instance;
}
