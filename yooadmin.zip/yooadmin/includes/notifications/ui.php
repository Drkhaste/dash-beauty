<?php
/**
 * YOOAdmin - Notification UI components
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_notifications_ui_script_handles')) {
    /**
     * Script handles that load notifications-ui.js (avoid duplicate enqueue/localize).
     *
     * @return string[]
     */
    function yooadmin_notifications_ui_script_handles(): array
    {
        return ['yooadmin-notifications-ui', 'yp-notifications-ui', 'notifications-ui'];
    }
}

if (!function_exists('yooadmin_notifications_ui_is_enqueued')) {
    function yooadmin_notifications_ui_is_enqueued(): bool
    {
        foreach (yooadmin_notifications_ui_script_handles() as $handle) {
            if (wp_script_is($handle, 'enqueued') || wp_script_is($handle, 'done')) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('yooadmin_get_notifications_ui_localize_data')) {
    /**
     * Shared l10n payload for notifications-ui.js (single source — prevents partial overwrites).
     *
     * @param array<string, mixed> $extra
     * @return array<string, mixed>
     */
    function yooadmin_get_notifications_ui_localize_data(array $extra = []): array
    {
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $opts = (array) get_option('yooadmin_options', []);
        $convert_banners_enabled = !empty($opts['convert_banners_to_notifications']);
        $user_prefs = get_user_meta(get_current_user_id(), 'yooadmin_notification_preferences', true);
        $notification_sound_enabled = true;
        if (is_array($user_prefs) && isset($user_prefs['notification_sound_enabled'])) {
            $notification_sound_enabled = !empty($user_prefs['notification_sound_enabled']);
        }
        $show_count_badge = true;
        if (is_array($user_prefs) && isset($user_prefs['show_count_badge'])) {
            $show_count_badge = !empty($user_prefs['show_count_badge']);
        }

        $license_active = false;
        if (isset($yooadmin_license_shell['is_active'])) {
            $license_active = (bool) $yooadmin_license_shell['is_active'];
        } elseif (isset($license_manager) && is_object($license_manager) && method_exists($license_manager, 'is_license_active')) {
            $license_active = (bool) $license_manager->is_license_active();
        }

        $build_strings = static function () use ($convert_banners_enabled, $license_active, $notification_sound_enabled, $show_count_badge): array {
            return [
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('yooadmin/v1/'),
            'nonce' => wp_create_nonce('wp_rest'),
            'ajax_nonce' => wp_create_nonce('yooadmin_notifications_nonce'),
            'get_notifications_nonce' => wp_create_nonce('yooadmin_notifications_nonce'),
            'delete_nonce' => wp_create_nonce('yooadmin_notifications_nonce'),
            'delete_warning' => __('If this notification comes from WordPress or another external source, it may reappear until that source is addressed.', 'yooadmin'),
            'user_id' => get_current_user_id(),
            'convert_banners_enabled' => $convert_banners_enabled,
            'license_active' => $license_active,
            'notification_sound_enabled' => $notification_sound_enabled,
            'show_count_badge' => $show_count_badge,
            'admin_ui_locale' => function_exists('yooadmin_get_admin_ui_locale')
                ? (string) yooadmin_get_admin_ui_locale()
                : (function_exists('get_user_locale') ? get_user_locale() : get_locale()),
            'strings' => [
                'loading' => __('Loading...', 'yooadmin'),
                'loadMore' => __('Load more', 'yooadmin'),
                'error' => __('Error loading notifications', 'yooadmin'),
                'mark_all_read' => __('Mark all as read', 'yooadmin'),
                'dismiss' => __('Dismiss', 'yooadmin'),
                'snooze' => __('Snooze', 'yooadmin'),
                'settings' => __('Settings', 'yooadmin'),
                'no_notifications' => __('No notifications', 'yooadmin'),
                'from' => __('From:', 'yooadmin'),
                'view' => __('View', 'yooadmin'),
                'viewAction' => __('View', 'yooadmin'),
                'openLink' => __('Open link', 'yooadmin'),
                'translateOnWpOrg' => __('Translate on WordPress.org', 'yooadmin'),
                'notification_deleted' => __('Notification deleted successfully', 'yooadmin'),
                'notification_deleted_fallback' => __('Notification deleted.', 'yooadmin'),
                'failed_to_delete' => __('Failed to delete notification.', 'yooadmin'),
                'failed_to_delete_retry' => __('Failed to delete notification. Please try again.', 'yooadmin'),
                'all_marked_read' => __('All notifications marked as read', 'yooadmin'),
                /* translators: %s: error message */
                'failed_mark_all_read' => __('Failed to mark all as read: %s', 'yooadmin'),
                'no_unread_to_mark' => __('No unread notifications to mark as read', 'yooadmin'),
                /* translators: %s: number of notifications */
                'marked_read_count' => __('Marked %s notification(s) as read', 'yooadmin'),
                'mark_all_read_retry' => __('Failed to mark all as read. Please try again.', 'yooadmin'),
                /* translators: %s: snooze duration or datetime suffix */
                'notification_snoozed' => __('Notification snoozed%s. It will reappear when the time expires.', 'yooadmin'),
                /* translators: %s: snooze datetime */
                'snoozed_until' => __(' until %s', 'yooadmin'),
                /* translators: %s: snooze duration label */
                'snoozed_for' => __(' for %s', 'yooadmin'),
                /* translators: %s: error message */
                'failed_snooze' => __('Failed to snooze notification: %s', 'yooadmin'),
                'failed_snooze_retry' => __('Failed to snooze notification. Please try again.', 'yooadmin'),
                'error_no_notification_id' => __('Error: Cannot find notification ID. Please try again.', 'yooadmin'),
                'error_invalid_notification_id' => __('Error: Invalid notification ID. Please try again.', 'yooadmin'),
                'select_future_time' => __('Please select a future time', 'yooadmin'),
                'select_date_time' => __('Please select a date and time', 'yooadmin'),
                'snooze_for' => __('Snooze for:', 'yooadmin'),
                'snooze_15_min' => __('15 min', 'yooadmin'),
                'snooze_1_hour' => __('1 hour', 'yooadmin'),
                'snooze_4_hours' => __('4 hours', 'yooadmin'),
                'snooze_1_day' => __('1 day', 'yooadmin'),
                'snooze_1_week' => __('1 week', 'yooadmin'),
                'custom' => __('Custom', 'yooadmin'),
                'custom_snooze' => __('Custom Snooze', 'yooadmin'),
                'select_date_time_label' => __('Select date and time:', 'yooadmin'),
                'cancel' => __('Cancel', 'yooadmin'),
                'confirm' => __('Confirm', 'yooadmin'),
                'tabAll' => __('ALL', 'yooadmin'),
                'tabPlugins' => __('Plugins', 'yooadmin'),
                'tabTheme' => __('Theme', 'yooadmin'),
                'tabExtensions' => __('Extensions', 'yooadmin'),
                'tabBanners' => __('Banners', 'yooadmin'),
                'tabLicense' => __('License', 'yooadmin'),
                'tabComments' => __('Comments', 'yooadmin'),
                'justNow' => __('Just now', 'yooadmin'),
                /* translators: %d: number of minutes */
                'timeMinuteAgo' => __('%d min ago', 'yooadmin'),
                /* translators: %d: number of minutes */
                'timeMinutesAgo' => __('%d mins ago', 'yooadmin'),
                /* translators: %d: number of hours */
                'timeHourAgo' => __('%d hour ago', 'yooadmin'),
                /* translators: %d: number of hours */
                'timeHoursAgo' => __('%d hours ago', 'yooadmin'),
                /* translators: %d: number of days */
                'timeDayAgo' => __('%d day ago', 'yooadmin'),
                /* translators: %d: number of days */
                'timeDaysAgo' => __('%d days ago', 'yooadmin'),
                'bannerSourceYooadminLoginSecurity' => __('YOOAdmin login security', 'yooadmin'),
            ],
            ];
        };

        $base = function_exists('yooadmin_with_admin_ui_locale')
            ? yooadmin_with_admin_ui_locale($build_strings)
            : $build_strings();

        $data = array_replace_recursive($base, $extra);

        /**
         * Filter notifications UI script localization (Plus: inbox URLs, etc.).
         *
         * @param array<string, mixed> $data
         */
        return apply_filters('yooadmin_notifications_ui_localize_data', $data);
    }
}

if (!function_exists('yooadmin_get_notifications_dropdown_footer_links')) {
    /**
     * Footer links for the header notifications dropdown.
     *
     * @return array<int, array{url: string, label: string, icon: string}>
     */
    function yooadmin_get_notifications_dropdown_footer_links(): array
    {
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $settings_url = function_exists('yooadmin_plus_notifications_settings_url')
            ? yooadmin_plus_notifications_settings_url()
            : (function_exists('yooadmin_settings_admin_url')
                ? yooadmin_settings_admin_url('tab-notifications')
                : admin_url('admin.php?page=yooadmin-settings#tab-notifications'));

        $links = [
            [
                'url' => $settings_url,
                'label' => __('Settings', 'yooadmin'),
                'icon' => 'dashicons-admin-generic',
            ],
        ];

        /** @param array<int, array{url: string, label: string, icon: string}> $links */
        return apply_filters('yooadmin_notifications_dropdown_footer_links', $links);
    }
}

if (!function_exists('yooadmin_render_notifications_dropdown_footer')) {
    function yooadmin_render_notifications_dropdown_footer(): string
    {
        $links = yooadmin_get_notifications_dropdown_footer_links();
        if ($links === []) {
            return '';
        }

        ob_start();
        ?>
        <div class="yp-notifications-dropdown-footer">
            <?php foreach ($links as $link) : ?>
                <a href="<?php echo esc_url((string) ($link['url'] ?? '')); ?>" class="yp-dropdown-footer-link">
                    <?php if (!empty($link['icon'])) : ?>
                        <span class="dashicons <?php echo esc_attr((string) $link['icon']); ?>" aria-hidden="true"></span>
                    <?php endif; ?>
                    <span class="yp-dropdown-footer-label"><?php echo esc_html((string) ($link['label'] ?? '')); ?></span>
                </a>
            <?php endforeach; ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }
}

class YOOAdmin_Notification_UI {
    
    private $integration;
    
    public function __construct() {
        $this->integration = yooadmin_get_integration();
    }
    
    /**
     * Render notification dropdown container
     */
    public function render_dropdown_container() {
        $user_id = get_current_user_id();
        $unread_count = $this->integration->get_notification_count($user_id);
        
        ob_start();
        ?>
        <div id="yp-notification-dropdown" class="yp-notification-dropdown">
            <!-- Dropdown Header -->
            <div class="yp-dropdown-header">
                <div class="yp-header-left">
                    <h3 class="yp-header-title">Notifications</h3>
                    <span class="yp-unread-count" data-count="<?php echo esc_attr($unread_count); ?>">
                        <?php echo $unread_count > 0 ? esc_html($unread_count) : ''; ?>
                    </span>
                </div>
                <div class="yp-header-right">
                    <button class="yp-notifications-mark-read" title="Mark all as read">
                        <?php esc_html_e('Mark all read', 'yooadmin'); ?>
                    </button>
                    <button class="yp-settings-btn" title="Notification Settings">
                        <i class="dashicons dashicons-admin-generic"></i>
                    </button>
                </div>
            </div>
            
            <!-- Filter Tabs - DYNAMIC: Will be populated by JavaScript based on actual notification data -->
            <div class="yp-filter-tabs">
                <!-- Only "All" tab is static, others will be added dynamically by JavaScript -->
                <button class="yp-filter-tab active" data-filter="all">
                    <?php esc_html_e('ALL', 'yooadmin'); ?> <span class="yp-tab-count">0</span>
                </button>
                <!-- Other tabs (plugins, theme, banners, etc.) will be added dynamically -->
            </div>
            
            <!-- Notifications List -->
            <div class="yp-notifications-list">
                <div class="yp-loading-spinner">
                    <div class="yp-spinner-circle"></div>
                    <span class="yp-loading-text"><?php esc_html_e('Loading...', 'yooadmin'); ?></span>
                </div>
            </div>
            
            <?php echo yooadmin_render_notifications_dropdown_footer(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in renderer. ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render single notification item
     */
    public function render_notification_item($notification) {
        $is_group = isset($notification['type']) && $notification['type'] === 'group';
        $priority_class = 'yp-priority-' . ($notification['priority'] ?? 'medium');
        $is_unread = ($notification['status'] ?? 'new') === 'new';
        
        ob_start();
        ?>
        <div class="yp-notification-item <?php echo esc_attr($priority_class); ?> <?php echo $is_unread ? 'yp-unread' : ''; ?> <?php echo $is_group ? 'yp-group-item' : ''; ?>" 
             data-id="<?php echo esc_attr($notification['id'] ?? ''); ?>" 
             data-group-id="<?php echo esc_attr($notification['group_id'] ?? ''); ?>"
             data-priority="<?php echo esc_attr($notification['priority'] ?? 'medium'); ?>">
            
            <?php if ($is_group): ?>
                <!-- Group Notification -->
                <div class="yp-notification-group">
                    <div class="yp-group-header">
                        <div class="yp-group-avatar">
                            <i class="dashicons <?php echo esc_attr($notification['icon'] ?? 'admin-site'); ?>"></i>
                            <span class="yp-group-count"><?php echo esc_html($notification['count'] ?? 0); ?></span>
                        </div>
                        <div class="yp-group-content">
                            <h4 class="yp-group-title"><?php echo esc_html($notification['title'] ?? ''); ?></h4>
                            <?php 
                            $count = $notification['count'] ?? 0;
                            $summary_text = '';
                            if ($count > 0) {
                                if (isset($notification['meta']['scope'])) {
                                    $scope = $notification['meta']['scope'];
                                    if ($scope === 'plugins') {
                                        /* translators: %d: number of plugin updates */
                                        $summary_text = sprintf(_n('%d plugin update', '%d plugin updates', $count, 'yooadmin'), $count);
                                    } elseif ($scope === 'themes') {
                                        /* translators: %d: number of theme updates */
                                        $summary_text = sprintf(_n('%d theme update', '%d theme updates', $count, 'yooadmin'), $count);
                                    } elseif ($scope === 'core') {
                                        /* translators: %s: WordPress version number */
                                        $summary_text = sprintf(__('WordPress %s available', 'yooadmin'), $notification['meta']['available_version'] ?? '');
                                    } else {
                                        /* translators: %d: number of items */
                                        $summary_text = sprintf(_n('%d item', '%d items', $count, 'yooadmin'), $count);
                                    }
                                } else {
                                    /* translators: %d: number of items */
                                    $summary_text = sprintf(_n('%d item', '%d items', $count, 'yooadmin'), $count);
                                }
                            }
                            if (!empty($summary_text)): ?>
                                <p class="yp-group-summary"><?php echo esc_html($summary_text); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="yp-group-controls">
                            <button class="yp-group-expand" title="Expand/Collapse">
                                <i class="dashicons dashicons-arrow-down"></i>
                            </button>
                            <button class="yp-group-dismiss" title="Dismiss All">
                                <i class="dashicons dashicons-no-alt"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="yp-group-items" style="display: none;">
                        <?php foreach ($notification['items'] ?? [] as $item): ?>
                            <?php echo wp_kses_post($this->render_notification_item($item)); ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php else: ?>
                <!-- Single Notification -->
                <div class="yp-notification-single">
                    <div class="yp-notification-avatar">
                        <i class="dashicons <?php echo esc_attr($notification['icon'] ?? 'admin-site'); ?>"></i>
                    </div>
                    
                    <div class="yp-notification-content">
                        <div class="yp-notification-header">
                            <h4 class="yp-notification-title"><?php echo esc_html($notification['title'] ?? ''); ?></h4>
                            <div class="yp-notification-meta">
                                <span class="yp-notification-time" data-time="<?php echo esc_attr($notification['created_at'] ?? ''); ?>">
                                    <?php echo esc_html($this->format_time($notification['created_at'] ?? '')); ?>
                                </span>
                                <span class="yp-notification-source"><?php echo esc_html(ucfirst($notification['source'] ?? 'system')); ?></span>
                            </div>
                        </div>
                        
                        <div class="yp-notification-message">
                            <?php echo wp_kses_post($notification['message'] ?? ''); ?>
                        </div>
                        
                        <?php if (!empty($notification['url']) || !empty($notification['meta']['actions'])): ?>
                            <div class="yp-notification-actions">
                                <?php if (!empty($notification['url'])): ?>
                                    <a href="<?php echo esc_url($notification['url']); ?>" class="yp-action yp-action-primary">
                                        View Details
                                    </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($notification['meta']['actions'])): ?>
                                    <?php foreach ($notification['meta']['actions'] as $action): ?>
                                        <a href="<?php echo esc_url($action['url'] ?? '#'); ?>" 
                                           class="yp-action yp-action-<?php echo esc_attr($action['type'] ?? 'secondary'); ?>">
                                            <?php echo esc_html($action['text'] ?? 'Action'); ?>
                                        </a>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="yp-notification-controls">
                        <button class="yp-dismiss-btn" title="Dismiss">
                            <i class="dashicons dashicons-no-alt"></i>
                        </button>
                        <button class="yp-snooze-btn" title="Snooze">
                            <i class="dashicons dashicons-clock"></i>
                        </button>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Format time display
     */
    private function format_time($datetime) {
        if (empty($datetime)) {
            return '';
        }

        $timestamp = strtotime($datetime);
        if (!$timestamp) {
            return '';
        }

        $diff = time() - $timestamp;

        if ($diff < 60) {
            return __('Just now', 'yooadmin');
        }

        if ($diff < WEEK_IN_SECONDS) {
            return sprintf(
                /* translators: %s: human-readable time difference */
                __('%s ago', 'yooadmin'),
                human_time_diff($timestamp, current_time('timestamp'))
            );
        }

        return wp_date('M j, Y', $timestamp);
    }
    
    /**
     * Render notification badge
     */
    public function render_notification_badge() {
        $user_id = get_current_user_id();
        $unread_count = $this->integration->get_notification_count($user_id);
        $user_prefs = get_user_meta($user_id, 'yooadmin_notification_preferences', true);
        $show_count_badge = true;
        if (is_array($user_prefs) && isset($user_prefs['show_count_badge'])) {
            $show_count_badge = !empty($user_prefs['show_count_badge']);
        }
        
        ob_start();
        ?>
        <div class="yp-notification-badge-container">
            <button class="yp-notification-toggle" title="Notifications">
                <i class="dashicons dashicons-bell"></i>
                <?php if ($show_count_badge && $unread_count > 0): ?>
                    <span class="yp-notification-count" data-count="<?php echo esc_attr($unread_count); ?>">
                        <?php echo $unread_count > 99 ? esc_html( '99+' ) : esc_html( $unread_count ); ?>
                    </span>
                <?php elseif ($unread_count > 0): ?>
                    <span class="yp-notification-count" data-count="<?php echo esc_attr($unread_count); ?>" style="display: none;"></span>
                <?php endif; ?>
            </button>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Enqueue UI assets
     */
    public function enqueue_assets() {
        $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
        $js_path = $base_file !== '' ? plugin_dir_path($base_file) . 'assets/js/admin/notifications-ui.js' : '';
        $js_ver = ($js_path !== '' && is_readable($js_path)) ? (string) filemtime($js_path) : YOOADMIN_VERSION;
        $css_path = $base_file !== '' ? plugin_dir_path($base_file) . 'assets/css/admin/notifications-ui.css' : '';
        $css_ver = ($css_path !== '' && is_readable($css_path)) ? (string) filemtime($css_path) : YOOADMIN_VERSION;

        // Enqueue CSS
        wp_enqueue_style(
            'yooadmin-notifications-ui',
            YOOADMIN_URL . 'assets/css/admin/notifications-ui.css',
            ['yooadmin-yoo-buttons'],
            $css_ver
        );
        
        // Enqueue JavaScript
        wp_enqueue_script(
            'yooadmin-notifications-ui',
            YOOADMIN_URL . 'assets/js/admin/notifications-ui.js',
            ['jquery', 'yp-admin-core-essential'],
            $js_ver,
            true
        );
        
        // Localize script
        wp_localize_script(
            'yooadmin-notifications-ui',
            'yooadmNotifications',
            yooadmin_get_notifications_ui_localize_data()
        );
    }
}

// Initialize UI
function yooadmin_get_notification_ui() {
    static $ui = null;
    
    if ($ui === null) {
        $ui = new YOOAdmin_Notification_UI();
    }
    
    return $ui;
}

// Hook for enqueuing assets
add_action('admin_enqueue_scripts', function() {
    if (!is_admin()) {
        return;
    }
    
    // Only load notification UI when Focus Mode is enabled
    if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
        return;
    }
    
    yooadmin_get_notification_ui()->enqueue_assets();
});
