<?php
/**
 * Auto-Archive Delay custom dropdown markup.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_archive_delay_select_html')) {
    /**
     * @param int   $value Current archive delay (0, 7, 14, 30, 60).
     * @param array $args {
     *     @type string $id Field id (hidden input + trigger suffix).
     * }
     */
    function yooadmin_archive_delay_select_html(int $value, array $args = []): string
    {
        $allowed = [0, 7, 14, 30, 60];
        if (!in_array($value, $allowed, true)) {
            $value = 14;
        }

        $id = isset($args['id']) ? sanitize_key((string) $args['id']) : 'archive_delay_days';
        if ($id === '') {
            $id = 'archive_delay_days';
        }

        $id_trigger = $id . '_trigger';
        $id_list = $id . '_list';

        $opts = [
            7 => [
                'label' => __('7 days', 'yooadmin'),
                'badge' => '',
            ],
            14 => [
                'label' => __('14 days', 'yooadmin'),
                'badge' => __('Recommended', 'yooadmin'),
            ],
            30 => [
                'label' => __('30 days', 'yooadmin'),
                'badge' => '',
            ],
            60 => [
                'label' => __('60 days', 'yooadmin'),
                'badge' => '',
            ],
            0 => [
                'label' => __('Never (manual only)', 'yooadmin'),
                'badge' => '',
            ],
        ];

        ob_start();
        ?>
<div class="yp-ui-select yp-custom-select" data-yoo-archive-delay="1">
    <input type="hidden"
           name="yooadmin_notification_settings[archive_delay_days]"
           id="<?php echo esc_attr($id); ?>"
           value="<?php echo esc_attr((string) $value); ?>"/>
    <button type="button"
            class="yp-custom-select__trigger"
            id="<?php echo esc_attr($id_trigger); ?>"
            aria-haspopup="listbox"
            aria-expanded="false"
            aria-controls="<?php echo esc_attr($id_list); ?>">
        <span class="yp-custom-select__value" aria-live="polite"></span>
        <span class="yp-custom-select__chevron dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
    </button>
    <ul class="yp-custom-select__drop" id="<?php echo esc_attr($id_list); ?>" role="listbox" hidden>
        <?php foreach ($opts as $v => $row) : ?>
            <?php
            $v = (int) $v;
            $sel = ($value === $v);
            ?>
        <li role="option"
            class="yp-custom-select__option<?php echo $sel ? ' is-selected' : ''; ?>"
            tabindex="-1"
            data-value="<?php echo esc_attr((string) $v); ?>"
            data-label="<?php echo esc_attr($row['label']); ?>"
            aria-selected="<?php echo $sel ? 'true' : 'false'; ?>">
            <span class="yp-custom-select__option-row">
                <span class="yp-custom-select__option-main"><?php echo esc_html($row['label']); ?></span>
                <?php if ($row['badge'] !== '') : ?>
                <span class="yp-custom-select__option-badge"><?php echo esc_html($row['badge']); ?></span>
                <?php endif; ?>
            </span>
        </li>
            <?php endforeach; ?>
    </ul>
</div>
        <?php
        return (string) ob_get_clean();
    }
}
