<?php
/**
 * YOOAdmin - Cache constants (TTL and config)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

class YOOAdmin_Cache_Constants {
    
    /**
     * Cache TTL values (in seconds)
     */
    const TTL_DEFAULT = 300;              // 5 minutes - Default cache TTL
    const TTL_NOTIFICATIONS = 300;         // 5 minutes - Notifications cache
    const TTL_NOTIFICATIONS_HASH = 300;    // 5 minutes - Notification hash cache
    const TTL_NOTIFICATIONS_COLLECTION = 3600; // 1 hour - Last collection timestamp
    const TTL_AUTO_DISMISS_CHECK = 3600; // 1 hour - Auto dismiss check interval
    const TTL_PLUGINS_CHECK = 3600;        // 1 hour - Plugins check interval
    const TTL_THEMES_CHECK = 3600;        // 1 hour - Themes check interval
    const TTL_USER_PREFERENCES = 1800;     // 30 minutes - User preferences cache
    const TTL_STATS = 3600;                // 1 hour - Cache statistics
    const TTL_LOCK = 30;                   // 30 seconds - Lock timeout
    const TTL_TRANSIENT_DUPLICATE = 30;    // 30 seconds - Duplicate processing prevention
    
    /**
     * Cache groups
     */
    const GROUP_NOTIFICATIONS = 'yooadmin_notifications';
    const GROUP_STATS = 'yooadmin_stats';
    const GROUP_LOCKS = 'yooadmin_locks';
    
    /**
     * Cache key prefixes
     */
    const PREFIX_NOTIFICATIONS = 'notifications_';
    const PREFIX_NOTIFICATIONS_HASH = 'notifications_hash_';
    const PREFIX_NOTIFICATION_HASH = 'notification_hash_';
    const PREFIX_SOURCE_HASH = 'source_hash_';
    const PREFIX_LAST_COLLECTION = 'notifications_last_collection_';
    const PREFIX_AUTO_DISMISS_CHECK = 'yooadmin_notifications_auto_dismiss_check_';
    
    /**
     * Get TTL value by name
     * 
     * @param string $name TTL constant name (without TTL_ prefix)
     * @param int $default Default value if not found
     * @return int TTL value in seconds
     */
    public static function get_ttl($name, $default = null) {
        $constant_name = 'TTL_' . strtoupper($name);
        
        if (defined('self::' . $constant_name)) {
            return constant('self::' . $constant_name);
        }
        
        return $default !== null ? $default : self::TTL_DEFAULT;
    }
    
    /**
     * Get cache group by name
     * 
     * @param string $name Group constant name (without GROUP_ prefix)
     * @param string $default Default group name if not found
     * @return string Cache group name
     */
    public static function get_group($name, $default = null) {
        $constant_name = 'GROUP_' . strtoupper($name);
        
        if (defined('self::' . $constant_name)) {
            return constant('self::' . $constant_name);
        }
        
        return $default !== null ? $default : self::GROUP_NOTIFICATIONS;
    }
    
    /**
     * Get all TTL constants
     * 
     * @return array Array of TTL constants
     */
    public static function get_all_ttls() {
        return [
            'default' => self::TTL_DEFAULT,
            'notifications' => self::TTL_NOTIFICATIONS,
            'notifications_hash' => self::TTL_NOTIFICATIONS_HASH,
            'notifications_collection' => self::TTL_NOTIFICATIONS_COLLECTION,
            'auto_dismiss_check' => self::TTL_AUTO_DISMISS_CHECK,
            'plugins_check' => self::TTL_PLUGINS_CHECK,
            'themes_check' => self::TTL_THEMES_CHECK,
            'user_preferences' => self::TTL_USER_PREFERENCES,
            'stats' => self::TTL_STATS,
            'lock' => self::TTL_LOCK,
            'transient_duplicate' => self::TTL_TRANSIENT_DUPLICATE,
        ];
    }
}










