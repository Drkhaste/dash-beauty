<?php
/**
 * YOOAdmin - UI integration (admin and AJAX)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Load compatibility functions first
require_once __DIR__ . '/compatibility.php';

class YOOAdmin_UI_Integration
{

    private $ui;
    private $integration;

    public function __construct()
    {
        // Fallback for missing UI class
        if (function_exists('yooadmin_get_notification_ui')) {
            $this->ui = yooadmin_get_notification_ui();
        }
        else {
            $this->ui = null;
        }

        // Fallback for missing integration class
        if (function_exists('yooadmin_get_integration')) {
            $this->integration = yooadmin_get_integration();
        }
        else {
            $this->integration = null;
        }
    }

    /**
     * Initialize UI integration
     */
    public function initialize()
    {
        $this->register_admin_bar_menu();
        $this->register_admin_menu();
        $this->register_ajax_handlers();
        $this->setup_admin_hooks();
    }

    /**
     * Register admin bar notification menu
     */
    private function register_admin_bar_menu()
    {
        if (!$this->integration) {
            return;
        }

        add_action('admin_bar_menu', function ($wp_admin_bar) {
            // If YOOAdmin Focus UI is disabled, don't show custom notification badge in WP admin bar.
            if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
                return;
            }
            if (!current_user_can('read')) {
                return;
            }

            // Get notification count
            $user_id = get_current_user_id();
            $unread_count = $this->integration->get_notification_count($user_id);

            // Add notification menu item (only when focus UI is active)
            $wp_admin_bar->add_menu([
                'id' => 'yooadmin-notifications',
                'title' => $this->ui ? $this->ui->render_notification_badge() : 'Notifications',
                'href' => '#',
                'meta' => [
                    'class' => 'yooadmin-notifications-menu',
                    'title' => 'Notifications'
                ]
            ]);

            // Add dropdown content
            if ($unread_count > 0) {
                $wp_admin_bar->add_menu([
                    'parent' => 'yooadmin-notifications',
                    'id' => 'yooadmin-notifications-dropdown',
                    'title' => $this->ui ? $this->ui->render_dropdown_container() : 'Loading...',
                    'href' => '#',
                    'meta' => [
                        'class' => 'yooadmin-notifications-dropdown',
                        'tabindex' => '-1'
                    ]
                ]);
            }
        }, 100);
    }

    /**
     * Register admin menu pages
     * Note: Inbox and Blocklist pages removed for Lite - notifications shown in header dropdown only
     */
    private function register_admin_menu()
    {
        // No submenu pages for notifications (Lite: dropdown only)
    }

    /**
     * Register AJAX handlers
     */
    private function register_ajax_handlers()
    {
        // Save notification settings
        add_action('wp_ajax_yooadmin_save_notification_settings', function () {
            check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

            if (!current_user_can(yooadmin_notification_preferences_capability())) {
                wp_send_json_error(['message' => 'Insufficient permissions']);
                return;
            }

            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Array sanitized below per-key.
            $settings = isset($_POST['settings']) && is_array($_POST['settings']) ? wp_unslash($_POST['settings']) : [];
            $user_id = get_current_user_id();

            // Sanitize and prepare settings
            $sanitized = [];

            // Handle hidden_priorities array
            if (isset($settings['hidden_priorities']) && is_array($settings['hidden_priorities'])) {
                $sanitized['hidden_priorities'] = array_map('sanitize_text_field', $settings['hidden_priorities']);
            }
            else {
                $sanitized['hidden_priorities'] = [];
            }

            // Handle boolean settings
            $sanitized['show_invalid'] = !empty($settings['show_invalid']);
            $sanitized['show_archived'] = !empty($settings['show_archived']);
            $sanitized['auto_dismiss_low'] = !empty($settings['auto_dismiss_low']);
            $sanitized['group_similar'] = !empty($settings['group_similar']);
            $sanitized['show_count_badge'] = !empty($settings['show_count_badge']);

            $allowed_archive = [0, 7, 14, 30, 60];
            if (isset($settings['archive_delay_days'])) {
                $v = (int) $settings['archive_delay_days'];
                $sanitized['archive_delay_days'] = in_array($v, $allowed_archive, true) ? $v : 14;
            } else {
                $sanitized['archive_delay_days'] = 14;
            }

            // Save user preferences
            update_user_meta($user_id, 'yooadmin_notification_preferences', $sanitized);

            wp_send_json_success(['message' => __('Settings saved successfully', 'yooadmin')]);
        });

        // Reset notification settings to defaults
        add_action('wp_ajax_yooadmin_reset_notification_settings', function () {
            check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

            if (!current_user_can(yooadmin_notification_preferences_capability())) {
                wp_send_json_error(['message' => 'Insufficient permissions']);
                return;
            }

            $user_id = get_current_user_id();

            // Delete user preferences to reset to defaults
            delete_user_meta($user_id, 'yooadmin_notification_preferences');

            wp_send_json_success(['message' => __('Settings reset to defaults successfully', 'yooadmin')]);
        });

        // Get notification count (AJAX version)
        add_action('wp_ajax_yooadmin_get_notification_count', function () {
            check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

            $user_id = get_current_user_id();
            $count = $this->integration->get_notification_count($user_id);

            wp_send_json_success(['count' => $count]);
        });

        // Mark notification as read (AJAX version)
        add_action('wp_ajax_yooadmin_mark_notification_read', function () {
            check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

            $notification_id_raw = isset($_POST['notification_id']) ? absint(wp_unslash($_POST['notification_id'])) : 0;
            $user_id = get_current_user_id();

            // Try to parse as integer first (database ID)
            $notification_id = intval($notification_id_raw);

            // If not a valid integer, try to find by custom ID (meta.id)
            if (!$notification_id || $notification_id <= 0) {
                // Search for notification by custom ID in meta
                if ($this->integration && $this->integration->storage) {
                    $notifications = $this->integration->storage->get_for_user($user_id, [
                        'id' => $notification_id_raw, // This searches in meta JSON
                        'limit' => 1
                    ]);

                    if (!empty($notifications) && isset($notifications[0]['id'])) {
                        $notification_id = intval($notifications[0]['id']); // Database ID
                    }
                    else {
                        wp_send_json_error(['message' => __('Notification not found', 'yooadmin')]);
                        return;
                    }
                }
                else {
                    wp_send_json_error(['message' => __('Invalid notification ID', 'yooadmin')]);
                    return;
                }
            }

            if (!$notification_id || $notification_id <= 0) {
                wp_send_json_error(['message' => __('Invalid notification ID', 'yooadmin')]);
                return;
            }

            $result = $this->integration->mark_as_read($user_id, $notification_id);

            wp_send_json_success(['success' => $result]);
        });

        // Mark all as read (AJAX version)
        add_action('wp_ajax_yooadmin_mark_all_read', function () {
            check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

            $user_id = get_current_user_id();
            $notifications = $this->integration->get_notifications($user_id, [
                'status' => 'new',
                'limit' => 1000,
                'offset' => 0,
            ]);

            $unread_ids = $this->integration->collect_unread_ids_from_notifications($notifications);

            if (!empty($unread_ids)) {
                $result = $this->integration->mark_multiple_as_read($user_id, $unread_ids);
                wp_send_json_success([
                    'marked_count' => $result !== false ? count($unread_ids) : 0,
                    /* translators: %d: number of notifications */
                    'message' => sprintf(__('%d notification(s) marked as read', 'yooadmin'), count($unread_ids))
                ]);
            }
            else {
                wp_send_json_success([
                    'marked_count' => 0,
                    'message' => __('No unread notifications to mark', 'yooadmin')
                ]);
            }
        });

        // Dismiss notification (AJAX version)
        add_action('wp_ajax_yooadmin_dismiss_notification', function () {
            check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

            $notification_id = intval($_POST['notification_id'] ?? 0);
            $user_id = get_current_user_id();
            $type = isset($_POST['type']) ? sanitize_text_field(wp_unslash($_POST['type'])) : 'dismiss';
            $snooze_until = isset($_POST['snooze_until']) ? sanitize_text_field(wp_unslash($_POST['snooze_until'])) : null;

            $result = $this->integration->dismiss_notification($user_id, $notification_id, $type, $snooze_until);

            wp_send_json_success(['success' => $result]);
        });

        // Delete notification permanently (AJAX version)
        add_action('wp_ajax_yooadmin_delete_notification', function () {
            check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

            $notification_id = intval($_POST['notification_id'] ?? 0);
            $user_id = get_current_user_id();

            if (!$notification_id || $notification_id <= 0) {
                wp_send_json_error(['message' => __('Invalid notification ID', 'yooadmin')]);
                return;
            }

            $result = $this->integration->delete_notification($user_id, $notification_id);

            if ($result) {
                wp_send_json_success(['message' => __('Notification deleted successfully', 'yooadmin')]);
            }
            else {
                wp_send_json_error(['message' => __('Failed to delete notification', 'yooadmin')]);
            }
        });

        // Dismiss group (AJAX version)
        add_action('wp_ajax_yooadmin_dismiss_group', function () {
            check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

            $group_id = isset($_POST['group_id']) ? sanitize_text_field(wp_unslash($_POST['group_id'])) : '';
            $user_id = get_current_user_id();
            $type = isset($_POST['type']) ? sanitize_text_field(wp_unslash($_POST['type'])) : 'dismiss';
            $snooze_until = isset($_POST['snooze_until']) ? sanitize_text_field(wp_unslash($_POST['snooze_until'])) : null;

            $result = $this->integration->dismiss_group($user_id, $group_id, $type, $snooze_until);

            wp_send_json_success(['success' => $result]);
        });

        // AJAX handlers for notification system (logged-in users only)
        add_action('wp_ajax_yooadmin_get_notifications', 'yooadmin_ajax_get_notifications');

        // Clear banner notifications (database cleanup)
        add_action('wp_ajax_yooadmin_clear_banner_notifications', function () {
            check_ajax_referer('yooadmin_clear_banners', 'nonce');

            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')]);
                return;
            }

            $user_id = get_current_user_id();

            if (!$this->integration) {
                wp_send_json_error(['message' => __('Integration not available', 'yooadmin')]);
                return;
            }

            // Use reflection to call private method
            $reflection = new ReflectionClass($this->integration);
            $method = $reflection->getMethod('clear_old_banner_notifications');
            $method->setAccessible(true);
            $deleted = $method->invoke($this->integration, $user_id);

            if ($deleted !== false) {
                wp_send_json_success([
                    'message' => sprintf(
                    /* translators: %d: number of banner notifications */
                    __('Successfully cleared %d banner notification(s). They will be re-generated correctly on the next page load.', 'yooadmin'),
                    $deleted
                ),
                    'deleted' => $deleted,
                    'unread_count' => $this->integration->get_notification_count($user_id, 'new'),
                ]);
            }
            else {
                wp_send_json_error(['message' => __('Failed to clear banner notifications', 'yooadmin')]);
            }
        });

        // Run notifications retention/cleanup now (Phase 3)
        add_action('wp_ajax_yooadmin_run_notifications_cleanup', function () {
            check_ajax_referer('yooadmin_run_notifications_cleanup', 'nonce');

            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => __('Insufficient permissions', 'yooadmin')]);
                return;
            }

            if (!$this->integration || !method_exists($this->integration, 'run_manual_cleanup')) {
                wp_send_json_error(['message' => __('Cleanup is not available', 'yooadmin')]);
                return;
            }

            $result = $this->integration->run_manual_cleanup();
            $total = isset($result['total']) ? (int) $result['total'] : 0;

            $message = $total > 0
                ? sprintf(
                    /* translators: %d: number of removed records */
                    __('Cleanup complete. Removed %d record(s).', 'yooadmin'),
                    $total
                )
                : __('Cleanup complete. Nothing needed removing.', 'yooadmin');

            wp_send_json_success([
                'message' => $message,
                'result'  => $result,
            ]);
        });
    }

    /**
     * Setup admin hooks
     */
    private function setup_admin_hooks()
    {
        add_filter('admin_body_class', [$this, 'add_admin_body_class']);
    }

    /**
     * Add admin body class
     */
    public function add_admin_body_class($classes)
    {
        if (!$this->integration) {
            return $classes;
        }

        $user_id = get_current_user_id();
        $unread_count = $this->integration->get_notification_count($user_id);

        if ($unread_count > 0) {
            $classes .= ' yooadmin-has-notifications';
        }

        return $classes;
    }
}

if (!function_exists('yooadmin_ajax_get_notifications')) {
    function yooadmin_ajax_get_notifications()
    {
        if (!check_ajax_referer('yooadmin_notifications_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Invalid nonce']);
            return;
        }

        $user_id = get_current_user_id();

        if (!current_user_can('read') || $user_id === 0) {
            wp_send_json_error(['message' => 'Permission denied']);
            return;
        }

        if (function_exists('yooadmin_get_integration')) {
            $integration     = yooadmin_get_integration();
            $requested_limit = isset($_POST['limit']) ? (int) $_POST['limit'] : 0;
            $offset          = isset($_POST['offset']) ? max(0, (int) $_POST['offset']) : 0;
            $has_more        = false;
            $options         = [];

            if ($requested_limit > 0) {
                $page_limit    = max(1, min(200, $requested_limit));
                $page          = $integration->get_notifications_flat_page($user_id, $options, $offset, $page_limit);
                $notifications = $page['items'];
                $has_more      = !empty($page['has_more']);
                $offset        = $offset + (int) ($page['count'] ?? count($notifications));
            } else {
                $notifications = $integration->get_notifications($user_id);
            }

            $unread_count = $integration->get_notification_count($user_id, 'new');

            $payload = [
                'data'         => $notifications,
                'has_more'     => $has_more,
                'offset'       => $offset,
                'unread_count' => $unread_count,
            ];

            if ($requested_limit > 0 && isset($page['total'])) {
                $payload['total'] = (int) $page['total'];
            }

            wp_send_json_success($payload);
        }
        else {
            wp_send_json_success(['data' => []]);
        }
    }
}

function yooadmin_initialize_ui_integration()
{
    static $ui_integration = null;

    if ($ui_integration === null) {
        $ui_integration = new YOOAdmin_UI_Integration();
        $ui_integration->initialize();
    }

    return $ui_integration;
}

add_action('init', static function () {
    yooadmin_initialize_ui_integration();
}, 6);
