<?php
/**
 * YOOAdmin - AJAX handlers
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// Text domain hardcoded as 'yooadmin' for WordPress.org compliance

/**
 * AJAX: Return submenu items for a given top-level menu slug.
 *
 * Action: wp_ajax_yooadmin_get_submenu_items
 * Nonce : yooadmin_get_submenu
 *
 * Expects:
 *  - _ajax_nonce : string
 *  - menu_slug   : string
 */
function yooadmin_ajax_get_submenu_items() {
    if (headers_sent() === false) {
        nocache_headers();
        header('Content-Type: application/json; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 401);
    }

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 403);
    }

    $nonce = isset($_REQUEST['_ajax_nonce']) ? sanitize_text_field(wp_unslash($_REQUEST['_ajax_nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'yooadmin_get_submenu')) {
        wp_send_json_error(['message' => __('Invalid nonce', 'yooadmin')], 403);
    }

    $menu_slug = isset($_REQUEST['menu_slug']) ? sanitize_text_field(wp_unslash($_REQUEST['menu_slug'])) : '';
    if ($menu_slug === '') {
        wp_send_json_success([]);
    }

    if (!function_exists('yooadmin_get_submenu_items')) {
        $helpers = dirname(__DIR__) . '/helpers/helper-functions.php';
        if (file_exists($helpers)) {
            require_once $helpers;
        }
    }
    if (!function_exists('yooadmin_get_submenu_items')) {
        wp_send_json_error(['message' => __('Helper not available', 'yooadmin')], 500);
    }

    $items = yooadmin_get_submenu_items($menu_slug);
    if (!is_array($items)) {
        $items = [];
    }

    wp_send_json_success($items, 200);
}
add_action('wp_ajax_yooadmin_get_submenu_items', 'yooadmin_ajax_get_submenu_items');

/**
 * AJAX: Check for new notifications count
 *
 * Action: wp_ajax_yooadmin_check_notifications
 * Nonce : yooadmin_notifications_nonce
 */
function yooadmin_ajax_check_notifications() {
    if (headers_sent() === false) {
        nocache_headers();
        header('Content-Type: application/json; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
    }

    check_ajax_referer('yooadmin_notifications_nonce', 'nonce');

    // Use new notification system if available (priority)
    if (function_exists('yooadmin_get_integration')) {
        $integration = yooadmin_get_integration();
        if ($integration) {
            $user_id = get_current_user_id();
            // Get unread count from database (real count)
            $unread_count = $integration->get_notification_count($user_id, 'new');
            
            wp_send_json_success([
                'count'        => $unread_count,
                'unread_count' => $unread_count,
                'summary'      => ['badge' => $unread_count],
                'hash'         => '',
                'generated_at' => current_time('mysql'),
            ], 200);
            return;
        }
    }

    // Fallback to old system if new system not available
    if (!function_exists('yooadmin_get_notifications_feed')) {
        if (defined('YOOADMIN_DIR')) {
            $notifications_module = YOOADMIN_DIR . 'includes/modules/notifications.php';
            if (file_exists($notifications_module)) {
                require_once $notifications_module;
            }
        }
    }

    if (function_exists('yooadmin_get_notifications_feed')) {
        $feed = yooadmin_get_notifications_feed([
            'summary_only'  => true,
            'include_items' => false,
        ]);

        $counts = isset($feed['counts']) && is_array($feed['counts']) ? $feed['counts'] : [];
        $badge  = isset($counts['badge']) ? (int) $counts['badge'] : 0;

        wp_send_json_success([
            'count'        => $badge,
            'summary'      => $counts,
            'hash'         => $feed['hash'] ?? '',
            'generated_at' => $feed['generated_at'] ?? current_time('mysql'),
        ], 200);
        return;
    }

    // Final fallback: maintain the legacy behaviour if the feed helper is unavailable.
    $updates = wp_get_update_data();
    $wp_count = isset($updates['counts']['total']) ? (int) $updates['counts']['total'] : 0;

    $comments_count   = wp_count_comments();
    $pending_comments = isset($comments_count->moderated) ? (int) $comments_count->moderated : 0;

    $total_count = $wp_count + $pending_comments;

    wp_send_json_success(['count' => $total_count], 200);
}
add_action('wp_ajax_yooadmin_check_notifications', 'yooadmin_ajax_check_notifications');

function yooadmin_ajax_save_quick_actions() {
    if (headers_sent() === false) {
        nocache_headers();
        header('Content-Type: application/json; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
    }

    if (!function_exists('yooadmin_user_can_edit_quick_actions') || !yooadmin_user_can_edit_quick_actions()) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 403);
    }

    $nonce = isset($_REQUEST['_ajax_nonce']) ? sanitize_text_field(wp_unslash($_REQUEST['_ajax_nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'yooadmin_quick_actions')) {
        wp_send_json_error(['message' => __('Invalid nonce', 'yooadmin')], 403);
    }

    $raw = isset($_POST['actions']) ? sanitize_text_field(wp_unslash($_POST['actions'])) : '[]';
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        wp_send_json_error(['message' => __('Invalid payload', 'yooadmin')], 400);
    }

    $sanitized = function_exists('yooadmin_sanitize_quick_actions_payload')
        ? yooadmin_sanitize_quick_actions_payload($decoded)
        : [];

    if (!yooadmin_save_user_quick_actions($sanitized)) {
        wp_send_json_error(['message' => __('Could not save quick actions.', 'yooadmin')], 500);
    }

    if (current_user_can('manage_options')) {
        update_option('yooadmin_quick_actions', $sanitized);
    }

    wp_send_json_success(['actions' => $sanitized], 200);
}
add_action('wp_ajax_yooadmin_save_quick_actions', 'yooadmin_ajax_save_quick_actions');

/**
 * AJAX: Save Welcome card text (title + two paragraphs).
 */
function yooadmin_ajax_save_welcome() {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 401);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 403);
    }

    $nonce = isset($_POST['_ajax_nonce']) ? sanitize_text_field(wp_unslash($_POST['_ajax_nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'yooadmin_welcome')) {
        wp_send_json_error(['message' => __('Invalid nonce', 'yooadmin')], 403);
    }

    $mode = isset($_POST['mode']) ? sanitize_text_field(wp_unslash($_POST['mode'])) : '';

    // Reset: remove option so defaults are used
    if ($mode === 'reset') {
        delete_option('yooadmin_welcome');
        wp_send_json_success(['welcome' => null], 200);
    }

    $title = isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : '';
    $p1    = isset($_POST['p1']) ? wp_kses_post(wp_unslash($_POST['p1'])) : '';
    $p2    = isset($_POST['p2']) ? wp_kses_post(wp_unslash($_POST['p2'])) : '';

    $data = [
        'title' => $title,
        'p1'    => $p1,
        'p2'    => $p2,
    ];

    update_option('yooadmin_welcome', $data);

    wp_send_json_success(['welcome' => $data], 200);
}
add_action('wp_ajax_yooadmin_save_welcome', 'yooadmin_ajax_save_welcome');

/**
 * AJAX: Disconnect portal session and deactivate license.
 */
function yooadmin_ajax_disconnect_portal_session() {
    if (headers_sent() === false) {
        nocache_headers();
        header('Content-Type: application/json; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 401);
    }

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 403);
    }

    $nonce = isset($_REQUEST['nonce']) ? sanitize_text_field(wp_unslash($_REQUEST['nonce'])) : '';

    if (!wp_verify_nonce($nonce, 'yooadmin_license_nonce')) {
        wp_send_json_error(['message' => __('Invalid nonce', 'yooadmin')], 403);
    }

    $token = isset($_REQUEST['token']) ? sanitize_text_field(wp_unslash($_REQUEST['token'])) : '';

    $license_manager = YOOAdmin_License_Manager::get_instance();

    if ($token !== '') {
        $license_manager->logout_portal_session($token);
    }

    $license_manager->clear_portal_profile();
    $license_manager->deactivate_license();

    wp_send_json_success([
        'message' => __('License disconnected successfully.', 'yooadmin'),
    ]);
}
add_action('wp_ajax_yooadmin_disconnect_portal_session', 'yooadmin_ajax_disconnect_portal_session');

// Note: wp_ajax_yooadmin_mark_notification_read is registered in
// includes/notifications/ui-integration.php using the database storage system.

/**
 * AJAX: Get all notification states from server
 *
 * Action: wp_ajax_yooadmin_get_notification_states
 * Nonce: yooadmin_notifications_nonce
 */
function yooadmin_ajax_get_notification_states() {
    if (headers_sent() === false) {
        nocache_headers();
        header('Content-Type: application/json; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 401);
    }

    $nonce = isset($_REQUEST['nonce']) ? sanitize_text_field(wp_unslash($_REQUEST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'yooadmin_notifications_nonce')) {
        wp_send_json_error(['message' => __('Invalid nonce', 'yooadmin')], 403);
    }

    // Get user ID
    $user_id = get_current_user_id();
    
    // Get read notifications from user meta
    $read_notifications = get_user_meta($user_id, 'yooadmin_read_notifications', true);
    if (!is_array($read_notifications)) {
        $read_notifications = [];
    }

    // CLEANUP: Remove old notifications that are no longer active
    if (function_exists('yooadmin_get_notifications_feed')) {
        $current_feed = yooadmin_get_notifications_feed(['include_items' => true]);
        $current_feed_ids = [];
        
        if (isset($current_feed['items']) && is_array($current_feed['items'])) {
            foreach ($current_feed['items'] as $item) {
                if (isset($item['id'])) {
                    $current_feed_ids[] = $item['id'];
                }
            }
        }
        
        // Keep only read notifications that are still in the current feed
        $read_notifications = array_intersect($read_notifications, $current_feed_ids);
        
        // Update user meta with cleaned list
        update_user_meta($user_id, 'yooadmin_read_notifications', $read_notifications);
    }

    wp_send_json_success([
        'read_items' => $read_notifications,
        'total_read' => count($read_notifications)
    ], 200);
}
add_action('wp_ajax_yooadmin_get_notification_states', 'yooadmin_ajax_get_notification_states');

/**
 * AJAX: Save per-user Focus Mode preference.
 *
 * Action: wp_ajax_yooadmin_save_user_focus_mode
 * Nonce : yooadmin_focus_mode
 */
function yooadmin_ajax_save_user_focus_mode() {
    if (headers_sent() === false) {
        nocache_headers();
        header('Content-Type: application/json; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 401);
    }

    $cap = function_exists('yooadmin_focus_preference_capability')
        ? yooadmin_focus_preference_capability()
        : 'read';
    if (!current_user_can($cap)) {
        wp_send_json_error(['message' => __('Unauthorized', 'yooadmin')], 403);
    }

    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'yooadmin_focus_mode')) {
        wp_send_json_error(['message' => __('Invalid nonce', 'yooadmin')], 403);
    }

    $policy = function_exists('yooadmin_get_focus_policy') ? yooadmin_get_focus_policy() : 'auto';
    if ($policy !== 'auto') {
        wp_send_json_error([
            'message'  => __('Focus Mode is controlled by the site administrator.', 'yooadmin'),
            'policy'   => $policy,
            'enforced' => true,
        ], 403);
    }

    $mode = isset($_POST['focus_mode']) ? sanitize_key(wp_unslash($_POST['focus_mode'])) : '';
    if ($mode !== 'on' && $mode !== 'off') {
        wp_send_json_error(['message' => __('Invalid focus mode.', 'yooadmin')], 400);
    }

    if (!function_exists('yooadmin_save_user_focus_preference') || !yooadmin_save_user_focus_preference($mode)) {
        wp_send_json_error(['message' => __('Could not save focus preference.', 'yooadmin')], 500);
    }

    wp_send_json_success([
        'focus_mode' => $mode,
        'is_active'  => $mode === 'on',
    ], 200);
}
add_action('wp_ajax_yooadmin_save_user_focus_mode', 'yooadmin_ajax_save_user_focus_mode');

