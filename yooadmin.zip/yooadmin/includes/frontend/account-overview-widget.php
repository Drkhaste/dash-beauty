<?php
/**
 * Account overview widget for non-administrator dashboard users.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_build_account_overview_items')) {
    /**
     * @return array<int, array<string, string>>
     */
    function yooadmin_build_account_overview_items(): array
    {
        $user = wp_get_current_user();
        if (!$user || !$user->exists()) {
            return [];
        }

        $items = [];

        $items[] = [
            'id'    => 'account_name',
            'icon'  => 'dashicons-admin-users',
            'label' => __('Account', 'yooadmin'),
            'value' => $user->display_name !== '' ? $user->display_name : $user->user_login,
            'url'   => get_edit_profile_url($user->ID),
            'tone'  => '',
        ];

        $role_names = array_values(array_filter(array_map('translate_user_role', $user->roles)));
        if ($role_names !== []) {
            $items[] = [
                'id'    => 'account_role',
                'icon'  => 'dashicons-id',
                'label' => __('Role', 'yooadmin'),
                'value' => implode(', ', $role_names),
                'url'   => '',
                'tone'  => '',
            ];
        }

        $items[] = [
            'id'    => 'member_since',
            'icon'  => 'dashicons-calendar-alt',
            'label' => __('Member since', 'yooadmin'),
            'value' => mysql2date(get_option('date_format'), $user->user_registered),
            'url'   => '',
            'tone'  => '',
        ];

        if (user_can($user, 'edit_posts')) {
            $posts_count = (int) count_user_posts($user->ID, 'post', true);
            $items[] = [
                'id'    => 'my_posts',
                'icon'  => 'dashicons-admin-post',
                'label' => __('Published posts', 'yooadmin'),
                'value' => (string) $posts_count,
                'url'   => admin_url('edit.php?author=' . $user->ID),
                'tone'  => '',
            ];
        }

        if (user_can($user, 'edit_pages')) {
            $pages_count = (int) count_user_posts($user->ID, 'page', true);
            $items[] = [
                'id'    => 'my_pages',
                'icon'  => 'dashicons-admin-page',
                'label' => __('Published pages', 'yooadmin'),
                'value' => (string) $pages_count,
                'url'   => admin_url('edit.php?post_type=page&author=' . $user->ID),
                'tone'  => '',
            ];
        }

        if (user_can($user, 'moderate_comments')) {
            $comments = wp_count_comments();
            $pending  = isset($comments->moderated) ? (int) $comments->moderated : 0;
            $items[] = [
                'id'    => 'comments_pending',
                'icon'  => 'dashicons-admin-comments',
                'label' => __('Comments awaiting moderation', 'yooadmin'),
                'value' => (string) $pending,
                'url'   => admin_url('edit-comments.php?comment_status=moderated'),
                'tone'  => $pending > 0 ? 'warn' : 'ok',
            ];
        }

        return apply_filters('yooadmin_account_overview_items', $items, $user);
    }
}

if (!function_exists('yooadmin_render_account_overview_widget')) {
    function yooadmin_render_account_overview_widget(): void
    {
        if (!function_exists('yooadmin_dw_enqueue_overview_assets')) {
            return;
        }

        yooadmin_dw_enqueue_overview_assets(true);

        $items = yooadmin_build_account_overview_items();
        if ($items === []) {
            return;
        }

        echo '<div class="yooadmin-overview-widget yooadmin-account-overview-widget" data-account-overview-widget>';
        echo '<ul class="yooadmin-overview-grid">';
        foreach ($items as $item) {
            if (function_exists('yooadmin_dw_render_overview_card')) {
                yooadmin_dw_render_overview_card($item, []);
            }
        }
        echo '</ul>';
        echo '</div>';
    }
}

add_action(
    'yooadmin_dashboard_cards_init',
    static function (): void {
        if (!function_exists('yooadmin_register_dashboard_card')) {
            return;
        }

        yooadmin_register_dashboard_card(
            'yooadmin_account_overview',
            [
                'title'       => __('Account overview', 'yooadmin'),
                'description' => __('General information about your account and activity.', 'yooadmin'),
                'icon'        => 'dashicons-id-alt',
                'capability'  => 'read',
                'priority'    => 4,
                'placements'  => [ 'main', 'aside' ],
                'scopes'      => [ 'site', 'network' ],
                'render'      => static function (): void {
                    if (function_exists('yooadmin_render_account_overview_widget')) {
                        yooadmin_render_account_overview_widget();
                    }
                },
            ]
        );
    },
    20
);
