<?php
/**
 * YOOAdmin - Custom admin bar (frontend)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_frontend_bar_is_customizer_preview')) {
    /**
     * Detect the site preview iframe used by customize.php.
     */
    function yooadmin_frontend_bar_is_customizer_preview(): bool {
        if (function_exists('is_customize_preview') && is_customize_preview()) {
            return true;
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only request detection.
        if (!empty($_GET['customize_changeset_uuid']) || !empty($_GET['customize_theme'])) {
            return true;
        }

        if (isset($_GET['wp_customize']) && 'on' === sanitize_text_field(wp_unslash($_GET['wp_customize']))) {
            return true;
        }
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return false;
    }
}

if (!function_exists('yooadmin_frontend_bar_get_appearance_mode')) {
    /**
     * Light/dark/auto — same source as Studio Hub admin appearance (user meta), not login-only settings.
     *
     * @return string light|dark|auto
     */
    function yooadmin_frontend_bar_get_appearance_mode(): string
    {
        if (function_exists('yooadmin_studio_hub_get_color_mode')) {
            $mode = yooadmin_studio_hub_get_color_mode();
            if (in_array($mode, ['light', 'dark', 'auto'], true)) {
                return $mode;
            }
        }

        if (function_exists('yooadmin_custom_login_get_color_mode')) {
            $mode = yooadmin_custom_login_get_color_mode();
            if (in_array($mode, ['light', 'dark', 'auto'], true)) {
                return $mode;
            }
        }

        return 'auto';
    }
}

if (!function_exists('yooadmin_frontend_bar_resolve_effective_color_mode')) {
    /**
     * Resolved light|dark for initial paint (auto defaults to light; JS applies system preference).
     *
     * @return string light|dark
     */
    function yooadmin_frontend_bar_resolve_effective_color_mode(): string
    {
        $mode = yooadmin_frontend_bar_get_appearance_mode();
        if ($mode === 'dark') {
            return 'dark';
        }
        if ($mode === 'light') {
            return 'light';
        }

        return 'light';
    }
}

if (!function_exists('yooadmin_frontend_bar_is_arabic_ui')) {
    function yooadmin_frontend_bar_is_arabic_ui(): bool
    {
        if (function_exists('yooadmin_is_arabic_admin_ui') && yooadmin_is_arabic_admin_ui()) {
            return true;
        }

        if (function_exists('yooadmin_custom_login_is_arabic_locale') && yooadmin_custom_login_is_arabic_locale()) {
            return true;
        }

        $locale = function_exists('get_user_locale') ? get_user_locale() : get_locale();

        return is_string($locale) && strpos($locale, 'ar') === 0;
    }
}

if (!function_exists('yooadmin_frontend_bar_get_brand_palette')) {
    /**
     * Brand palette for the frontend bar — same source as Studio Hub (yooadmin_colors).
     *
     * @return array{primary:string,header_bg:string,header_fg:string}
     */
    function yooadmin_frontend_bar_get_brand_palette(): array
    {
        $primary   = '#eda934';
        $header_bg = '#4B4B4B';
        $header_fg = '#FFFFFF';

        $colors = get_option('yooadmin_colors', []);
        if (!is_array($colors)) {
            $colors = [];
        }

        if (!empty($colors['primary'])) {
            $primary = sanitize_hex_color((string) $colors['primary']) ?: $primary;
        }
        if (!empty($colors['header_bg'])) {
            $header_bg = sanitize_hex_color((string) $colors['header_bg']) ?: $header_bg;
        }
        if (!empty($colors['text_contrast'])) {
            $header_fg = sanitize_hex_color((string) $colors['text_contrast']) ?: $header_fg;
        }

        if ($colors === [] && function_exists('yooadmin_get_brand_options')) {
            $legacy = yooadmin_get_brand_options();
            if (!empty($legacy['primary'])) {
                $primary = sanitize_hex_color((string) $legacy['primary']) ?: $primary;
            }
            if (!empty($legacy['header_bg'])) {
                $header_bg = sanitize_hex_color((string) $legacy['header_bg']) ?: $header_bg;
            }
            if (!empty($legacy['header_fg'])) {
                $header_fg = sanitize_hex_color((string) $legacy['header_fg']) ?: $header_fg;
            }
        }

        if ($colors === [] && function_exists('yooadmin_custom_login_get_merged_theme_colors')) {
            $theme = yooadmin_custom_login_get_merged_theme_colors();
            if (!empty($theme['primary'])) {
                $primary = sanitize_hex_color((string) $theme['primary']) ?: $primary;
            }
            if (!empty($theme['header_bg'])) {
                $header_bg = sanitize_hex_color((string) $theme['header_bg']) ?: $header_bg;
            }
            if (!empty($theme['text_contrast'])) {
                $header_fg = sanitize_hex_color((string) $theme['text_contrast']) ?: $header_fg;
            }
        }

        return [
            'primary'   => sanitize_hex_color($primary) ?: '#eda934',
            'header_bg' => sanitize_hex_color($header_bg) ?: '#4B4B4B',
            'header_fg' => sanitize_hex_color($header_fg) ?: '#FFFFFF',
        ];
    }
}

if (!function_exists('yooadmin_frontend_bar_build_inline_css')) {
    /**
     * Scoped bar colors + :root tokens used by bar CSS (e.g. --yp-primary).
     *
     * @param array{primary:string,header_bg:string,header_fg:string} $palette Brand palette.
     * @param string                                                $effective_mode light|dark.
     */
    function yooadmin_frontend_bar_build_inline_css(array $palette, string $effective_mode): string
    {
        $primary   = $palette['primary'];
        $header_bg = $palette['header_bg'];
        $header_fg = $palette['header_fg'];

        if ($effective_mode === 'dark') {
            $header_bg = '#1a1d23';
            $header_fg = '#e8edf4';
        }

        $latin_font = function_exists('yooadmin_get_latin_font_family_css_value')
            ? yooadmin_get_latin_font_family_css_value()
            : "'Montserrat'";

        return "
:root {
    --yp-primary: {$primary};
    --yooadmin-primary: {$primary};
    --yooadmin-fbar-accent: {$primary};
}

.yooadmin-frontend-bar {
    --yp-primary: {$primary};
    --yooadmin-primary: {$primary};
    --yooadmin-fbar-accent: {$primary};
    --yooadmin-fbar-bg: {$header_bg};
    --yooadmin-fbar-fg: {$header_fg};
    --yooadmin-latin-font-family: {$latin_font};
    background: {$header_bg} !important;
}

.yooadmin-frontend-bar .yooadmin-maintenance-pill--frontend-bar.is-on :is(
    .yooadmin-maintenance-pill__settings-link,
    .yooadmin-maintenance-pill__icon,
    .yooadmin-maintenance-pill__label,
    .yooadmin-maintenance-pill__toggle-btn
),
.yooadmin-frontend-bar .yooadmin-maintenance-pill--frontend-bar.is-off :is(
    .yooadmin-maintenance-pill__settings-link,
    .yooadmin-maintenance-pill__icon,
    .yooadmin-maintenance-pill__label,
    .yooadmin-maintenance-pill__toggle-btn
) {
    color: {$primary} !important;
}

.yooadmin-frontend-bar .yooadmin-maintenance-pill--frontend-bar .yooadmin-maintenance-pill__icon::before {
    color: inherit;
}

.yooadmin-frontend-bar .yooadmin-maintenance-pill__settings-link,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__settings-link:hover,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__settings-link:focus,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__settings-link:focus-visible,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__label,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__icon,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__icon::before {
    text-decoration: none !important;
    border-bottom: none !important;
    box-shadow: none !important;
}

.yooadmin-frontend-bar .yooadmin-maintenance-pill__toggle-btn,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__toggle-btn:hover,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__toggle-btn:focus,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__toggle-btn:active {
    background: transparent !important;
    background-color: transparent !important;
    background-image: none !important;
    box-shadow: none !important;
}

.yooadmin-frontend-bar .yooadmin-maintenance-pill__switch.yp-toggle-switch {
    background: transparent !important;
    background-color: transparent !important;
    box-shadow: none !important;
}

.yooadmin-frontend-bar .yooadmin-maintenance-pill__switch .yp-toggle-slider {
    background-color: color-mix(in srgb, {$primary} 18%, rgba(255, 255, 255, 0.35));
}

.yooadmin-frontend-bar .yooadmin-maintenance-pill__switch input:checked + .yp-toggle-slider {
    background-color: color-mix(in srgb, {$primary} 62%, #fff);
}

.yooadmin-frontend-bar .yooadmin-bar-item,
.yooadmin-frontend-bar .yooadmin-bar-trigger {
    color: {$header_fg} !important;
}

.yooadmin-frontend-bar .yooadmin-bar-item:hover,
.yooadmin-frontend-bar .yooadmin-bar-trigger:hover {
    color: {$primary} !important;
}

.yooadmin-frontend-bar .yooadmin-bar-dropdown-menu {
    background: {$header_bg};
    border-color: color-mix(in srgb, {$header_fg} 14%, transparent);
}

.yooadmin-frontend-bar .yooadmin-bar-dropdown-item {
    color: {$header_fg};
}

.yooadmin-frontend-bar .yooadmin-bar-dropdown-item:hover {
    color: {$primary};
}

.yooadmin-frontend-bar .yooadmin-bar-user-info strong,
.yooadmin-frontend-bar .yooadmin-bar-user-info small {
    color: {$header_fg};
}

.yooadmin-frontend-bar .yooadmin-bar-custom-node.elementor-edit-link,
.yooadmin-frontend-bar .yooadmin-bar-custom-node.fl-builder-edit-link {
    background: {$primary};
}

.yooadmin-frontend-bar .yooadmin-bar-item:focus,
.yooadmin-frontend-bar .yooadmin-bar-trigger:focus,
.yooadmin-frontend-bar .yooadmin-bar-logo:focus,
.yooadmin-frontend-bar .yooadmin-bar-license-badge:focus,
.yooadmin-frontend-bar .yooadmin-bar-dropdown-item:focus,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__settings-link:focus,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__toggle-btn:focus,
.yooadmin-frontend-bar a:focus,
.yooadmin-frontend-bar button:focus {
    outline: none !important;
    border: none !important;
    box-shadow: none !important;
}

.yooadmin-frontend-bar .yooadmin-bar-item:focus-visible,
.yooadmin-frontend-bar .yooadmin-bar-trigger:focus-visible,
.yooadmin-frontend-bar .yooadmin-bar-logo:focus-visible,
.yooadmin-frontend-bar .yooadmin-bar-license-badge:focus-visible,
.yooadmin-frontend-bar .yooadmin-bar-dropdown-item:focus-visible,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__settings-link:focus-visible,
.yooadmin-frontend-bar .yooadmin-maintenance-pill__toggle-btn:focus-visible {
    outline: 2px solid {$primary} !important;
    outline-offset: 2px;
}

.yooadmin-frontend-bar .yooadmin-bar-license-badge.yp-license-status-active {
    color: {$primary};
}

.yooadmin-frontend-bar .yooadmin-bar-license-badge.yp-license-status-inactive {
    color: color-mix(in srgb, {$header_fg} 72%, transparent);
}

.yooadmin-frontend-bar .yooadmin-bar-license-badge.yp-license-status-expiring {
    color: #f1c40f;
}

.yooadmin-frontend-bar .yooadmin-bar-license-badge.yp-license-status-expired,
.yooadmin-frontend-bar .yooadmin-bar-license-badge.yp-license-status-suspended,
.yooadmin-frontend-bar .yooadmin-bar-license-badge.yp-license-status-revoked {
    color: #e74c3c;
}
";
    }
}

if (!function_exists('yooadmin_is_custom_frontend_admin_bar_enabled')) {
    /**
     * Whether the YOOAdmin custom frontend admin bar should render.
     */
    function yooadmin_is_custom_frontend_admin_bar_enabled(): bool {
        if (!is_user_logged_in()) {
            return false;
        }

        if (yooadmin_frontend_bar_is_customizer_preview()) {
            return false;
        }

        $options = (array) get_option('yooadmin_options', []);
        if (empty($options['enable_custom_admin_bar'])) {
            return false;
        }

        return function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();
    }
}

// Hide default WordPress admin bar only if custom bar is enabled
add_filter('show_admin_bar', function($show) {
    if (yooadmin_frontend_bar_is_customizer_preview()) {
        return $show;
    }

    // Check if custom admin bar is enabled in settings
    $options = (array) get_option('yooadmin_options', []);
    $custom_bar_enabled = !empty($options['enable_custom_admin_bar']);
    
    // If custom bar is disabled, keep WordPress admin bar
    if (!$custom_bar_enabled) {
        return $show;
    }
    
    // If Focus Mode is disabled, keep WordPress admin bar
    if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
        return $show; // Keep default behavior
    }
    
    // If user is not logged in, keep default behavior
    if (!is_user_logged_in()) {
        return $show;
    }
    
    // Hide WordPress admin bar (we'll show custom bar)
    return false;
});

/**
 * Enqueue frontend admin bar assets
 */
add_action('wp_enqueue_scripts', function() {
    if (!yooadmin_is_custom_frontend_admin_bar_enabled()) {
        return;
    }

    if (wp_doing_ajax() || (function_exists('wp_is_json_request') && wp_is_json_request())) {
        return;
    }

    // Enqueue Dashicons (required for icons)
    wp_enqueue_style('dashicons');

    $font_deps = [];
    if (defined('YOOADMIN_PLUGIN_FILE')) {
        $base_url = plugin_dir_url(YOOADMIN_PLUGIN_FILE);
        $base_dir = plugin_dir_path(YOOADMIN_PLUGIN_FILE);
        foreach (['assets/fonts/montserrat.css' => 'yooadmin-montserrat', 'assets/fonts/tajawal.css' => 'yooadmin-tajawal'] as $rel => $handle) {
            $abs = $base_dir . $rel;
            if (is_readable($abs)) {
                wp_enqueue_style($handle, $base_url . $rel, [], (string) filemtime($abs));
                $font_deps[] = $handle;
            }
        }
    }

    // Enqueue CSS with version based on brand colors
    $colors_data = get_option('yooadmin_colors', []);
    
    // Fallback to yooadmin_brand if yooadmin_colors not found
    if (empty($colors_data)) {
        $colors_data = get_option('yooadmin_brand', []);
    }
    
    $colors_hash = !empty($colors_data) ? substr(md5((string) wp_json_encode($colors_data)), 0, 8) : '';
    $css_rel     = 'assets/css/frontend/admin-bar.css';
    $css_abs     = defined('YOOADMIN_PLUGIN_FILE')
        ? plugin_dir_path(YOOADMIN_PLUGIN_FILE) . $css_rel
        : '';
    $file_ver    = ($css_abs !== '' && is_readable($css_abs)) ? (string) filemtime($css_abs) : '';
    $style_ver   = YOOADMIN_VERSION;
    if ($file_ver !== '') {
        $style_ver .= '.' . $file_ver;
    }
    if ($colors_hash !== '') {
        $style_ver .= '.' . $colors_hash;
    }

    wp_enqueue_style(
        'yooadmin-frontend-bar',
        YOOADMIN_PANEL_URL . $css_rel,
        array_merge(['dashicons'], $font_deps),
        $style_ver
    );

    $bar_script_deps = ['jquery'];
    if (function_exists('yooadmin_enqueue_maintenance_toggle_script')) {
        yooadmin_enqueue_maintenance_toggle_script();
        if (wp_script_is('yooadmin-maintenance-toggle', 'enqueued') || wp_script_is('yooadmin-maintenance-toggle', 'registered')) {
            $bar_script_deps[] = 'yooadmin-maintenance-toggle';
        }
    }

    wp_enqueue_script(
        'yooadmin-frontend-bar',
        YOOADMIN_PANEL_URL . 'assets/js/frontend/admin-bar.js',
        $bar_script_deps,
        YOOADMIN_VERSION,
        true
    );
    if (function_exists('wp_script_add_data')) {
        wp_script_add_data('yooadmin-frontend-bar', 'strategy', 'defer');
    }

    $appearance_mode = yooadmin_frontend_bar_get_appearance_mode();

    $bar_localize = [
        'ajaxUrl'         => admin_url('admin-ajax.php'),
        'nonce'           => wp_create_nonce('yooadmin_bar_nonce'),
        'appearanceMode'  => $appearance_mode,
        'effectiveMode'   => yooadmin_frontend_bar_resolve_effective_color_mode(),
    ];

    if (function_exists('yooadmin_user_can_toggle_maintenance_mode') && yooadmin_user_can_toggle_maintenance_mode()) {
        $bar_localize['maintenanceToggle'] = [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => function_exists('yooadmin_maintenance_toggle_nonce')
                ? yooadmin_maintenance_toggle_nonce()
                : '',
        ];
    }

    wp_localize_script('yooadmin-frontend-bar', 'yooadmBar', $bar_localize);

    if (function_exists('yooadmin_build_latin_font_variable_css')) {
        wp_add_inline_style('yooadmin-frontend-bar', yooadmin_build_latin_font_variable_css());
    }

    $palette = yooadmin_frontend_bar_get_brand_palette();
    wp_add_inline_style(
        'yooadmin-frontend-bar',
        yooadmin_frontend_bar_build_inline_css($palette, yooadmin_frontend_bar_resolve_effective_color_mode())
    );
});

/**
 * Render custom admin bar
 */
add_action('wp_body_open', function() {
    if (!is_user_logged_in()) {
        return;
    }

    if (yooadmin_frontend_bar_is_customizer_preview()) {
        return;
    }
    
    // Check if custom admin bar is enabled in settings
    $options = (array) get_option('yooadmin_options', []);
    $custom_bar_enabled = !empty($options['enable_custom_admin_bar']);
    
    if (!$custom_bar_enabled) {
        return;
    }
    
    // Don't show custom bar if Focus Mode is disabled
    if (function_exists('yooadmin_is_focus_enabled') && !yooadmin_is_focus_enabled()) {
        return;
    }

    // Get current user
    $current_user = wp_get_current_user();
    $user_display = $current_user->display_name;
    $bar_avatar_source = function_exists('yooadmin_profile_get_avatar_source')
        ? yooadmin_profile_get_avatar_source((int) $current_user->ID)
        : 'yooadmin';
    $user_avatar = function_exists('yooadmin_profile_avatar_url_for_source')
        ? yooadmin_profile_avatar_url_for_source((int) $current_user->ID, $bar_avatar_source, 32)
        : get_avatar_url($current_user->ID, ['size' => 32]);

    // Get YOOAdmin logo (custom or default)
    $logo_url = function_exists('yooadmin_logo_url') ? yooadmin_logo_url() : '';
    if (!$logo_url) {
        $logo_url = YOOADMIN_PANEL_URL . 'assets/images/logo.png';
    }

    // Get counts
    $update_counts = wp_get_update_data();
    $updates_badge = isset($update_counts['counts']['total']) ? (int) $update_counts['counts']['total'] : 0;

    $comments = wp_count_comments();
    $comments_badge = isset($comments->moderated) ? (int) $comments->moderated : 0;

    // Get unread notifications count (if notifications system exists)
    $notifications_badge = 0;
    if (function_exists('yooadmin_get_unread_notifications_count')) {
        $notifications_badge = yooadmin_get_unread_notifications_count();
    }

    $custom_nodes = [];
    $edit_link = '';
    $edit_label = '';

    if (is_singular() && current_user_can('edit_posts')) {
        $post_id = get_queried_object_id();
        if ($post_id && current_user_can('edit_post', $post_id)) {
            $edit_link = admin_url('post.php?post=' . $post_id . '&action=edit');
            $post_type_obj = get_post_type_object(get_post_type($post_id));
            $edit_label = $post_type_obj ? $post_type_obj->labels->edit_item : __('Edit', 'yooadmin');
        }
    } elseif ((is_category() || is_tag() || is_tax()) && current_user_can('manage_categories')) {
        $term = get_queried_object();
        if ($term && isset($term->term_id)) {
            $edit_link = get_edit_term_link($term->term_id, $term->taxonomy);
            $edit_label = __('Edit Term', 'yooadmin');
        }
    }

    global $wp_admin_bar;
    if (!is_admin() && is_object($wp_admin_bar) && method_exists($wp_admin_bar, 'get_nodes')) {
        $all_nodes = $wp_admin_bar->get_nodes();
        $exclude_ids = ['wp-logo', 'site-name', 'my-account', 'search', 'customize', 'updates', 'comments', 'new-content', 'edit', 'view', 'view-site'];
        
        if (is_array($all_nodes)) {
            foreach ($all_nodes as $node) {
                if (isset($node->id) && !in_array($node->id, $exclude_ids) && !isset($node->parent)) {
                    $custom_nodes[] = $node;
                }
            }
        }
    }

    $bar_effective_mode = yooadmin_frontend_bar_resolve_effective_color_mode();
    $bar_ar_class       = yooadmin_frontend_bar_is_arabic_ui() ? ' yooadmin-frontend-bar--ar' : '';
    $license_shell = function_exists('yooadmin_get_shell_license_status')
        ? yooadmin_get_shell_license_status()
        : null;
    $can_manage_license = function_exists('yooadmin_user_can_manage_site_settings') && yooadmin_user_can_manage_site_settings();
    $maintenance_on     = function_exists('yooadmin_maintenance_mode_is_enabled') && yooadmin_maintenance_mode_is_enabled();
    $dashboard_url      = function_exists('yooadmin_shell_home_url')
        ? yooadmin_shell_home_url()
        : (function_exists('yooadmin_dashboard_url')
            ? yooadmin_dashboard_url()
            : admin_url('admin.php?page=yooadmin-dashboard'));

    ?>
    <div id="yooadmin-frontend-bar" class="yooadmin-frontend-bar<?php echo esc_attr($bar_ar_class); ?>" data-yooadmin-bar-mode="<?php echo esc_attr($bar_effective_mode); ?>">
        <div class="yooadmin-bar-inner">
            <!-- Left Side -->
            <div class="yooadmin-bar-left">
                <span class="yooadmin-bar-brand-wrap">
                <!-- Logo -->
                <a href="<?php echo esc_url($dashboard_url); ?>" class="yooadmin-bar-logo" title="<?php esc_attr_e('YOOAdmin Dashboard', 'yooadmin'); ?>">
                    <img src="<?php echo esc_url($logo_url); ?>" alt="<?php esc_attr_e('YOOAdmin Logo', 'yooadmin'); ?>">
                </a>
                <?php if (is_array($license_shell)) :
                    $status_class = (string) ($license_shell['status_class'] ?? 'inactive');
                    $status_text  = (string) ($license_shell['status_text'] ?? '');
                    $status_icon  = (string) ($license_shell['status_icon'] ?? 'dashicons-admin-users');
                    ?>
                    <?php if ($can_manage_license) : ?>
                    <a href="<?php echo esc_url(function_exists('yooadmin_license_admin_url') ? yooadmin_license_admin_url() : admin_url('admin.php?page=yooadmin-license')); ?>"
                       class="yooadmin-bar-license-badge yp-license-status-<?php echo esc_attr($status_class); ?>"
                       aria-label="<?php echo esc_attr($status_text); ?>"
                       title="<?php echo esc_attr($status_text); ?>">
                        <span class="dashicons <?php echo esc_attr($status_icon); ?>" aria-hidden="true"></span>
                    </a>
                    <?php else : ?>
                    <span class="yooadmin-bar-license-badge yp-license-status-<?php echo esc_attr($status_class); ?>"
                          title="<?php echo esc_attr($status_text); ?>"
                          aria-label="<?php echo esc_attr($status_text); ?>">
                        <span class="dashicons <?php echo esc_attr($status_icon); ?>" aria-hidden="true"></span>
                    </span>
                    <?php endif; ?>
                <?php endif; ?>
                </span>

                <!-- Dashboard Link -->
                <a href="<?php echo esc_url($dashboard_url); ?>" class="yooadmin-bar-item">
                    <span class="dashicons dashicons-dashboard"></span>
                    <span class="yooadmin-bar-label"><?php esc_html_e('Dashboard', 'yooadmin'); ?></span>
                </a>
            </div>

            <!-- Right Side -->
            <div class="yooadmin-bar-right">
                <?php if (function_exists('yooadmin_should_render_maintenance_mode_control') && yooadmin_should_render_maintenance_mode_control('frontend-bar')) : ?>
                    <span class="yooadmin-bar-maintenance-wrap">
                        <?php yooadmin_render_maintenance_mode_control('frontend-bar'); ?>
                    </span>
                <?php endif; ?>

                <!-- Notifications -->
                <div class="yooadmin-bar-dropdown">
                    <button class="yooadmin-bar-item yooadmin-bar-trigger" aria-label="<?php esc_attr_e('Notifications', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-bell"></span>
                        <?php if ($notifications_badge > 0): ?>
                            <span class="yooadmin-bar-badge"><?php echo esc_html($notifications_badge); ?></span>
                        <?php endif; ?>
                    </button>
                    <div class="yooadmin-bar-dropdown-menu yooadmin-bar-dropdown-right">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=yooadmin-settings#tab-notifications')); ?>" class="yooadmin-bar-dropdown-item">
                            <span class="dashicons dashicons-admin-generic"></span>
                            <?php esc_html_e('Notification Settings', 'yooadmin'); ?>
                        </a>
                    </div>
                </div>

                <!-- New -->
                <div class="yooadmin-bar-dropdown">
                    <button class="yooadmin-bar-item yooadmin-bar-trigger" aria-label="<?php esc_attr_e('Add New', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-plus-alt"></span>
                    </button>
                    <div class="yooadmin-bar-dropdown-menu yooadmin-bar-dropdown-right">
                        <a href="<?php echo esc_url(admin_url('post-new.php')); ?>" class="yooadmin-bar-dropdown-item">
                            <span class="dashicons dashicons-admin-post"></span>
                            <?php esc_html_e('Post', 'yooadmin'); ?>
                        </a>
                        <a href="<?php echo esc_url(admin_url('post-new.php?post_type=page')); ?>" class="yooadmin-bar-dropdown-item">
                            <span class="dashicons dashicons-admin-page"></span>
                            <?php esc_html_e('Page', 'yooadmin'); ?>
                        </a>
                        <a href="<?php echo esc_url(admin_url('media-new.php')); ?>" class="yooadmin-bar-dropdown-item">
                            <span class="dashicons dashicons-admin-media"></span>
                            <?php esc_html_e('Media', 'yooadmin'); ?>
                        </a>
                        <?php if (current_user_can('edit_users')): ?>
                            <a href="<?php echo esc_url(admin_url('user-new.php')); ?>" class="yooadmin-bar-dropdown-item">
                                <span class="dashicons dashicons-admin-users"></span>
                                <?php esc_html_e('User', 'yooadmin'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Comments -->
                <a href="<?php echo esc_url(admin_url('edit-comments.php')); ?>" class="yooadmin-bar-item" title="<?php esc_attr_e('Comments', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-admin-comments"></span>
                    <?php if ($comments_badge > 0): ?>
                        <span class="yooadmin-bar-badge"><?php echo esc_html($comments_badge); ?></span>
                    <?php endif; ?>
                </a>

                <!-- Updates -->
                <a href="<?php echo esc_url(admin_url('update-core.php')); ?>" class="yooadmin-bar-item" title="<?php esc_attr_e('Updates', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-update"></span>
                    <?php if ($updates_badge > 0): ?>
                        <span class="yooadmin-bar-badge"><?php echo esc_html($updates_badge); ?></span>
                    <?php endif; ?>
                </a>

                <?php if ($edit_link): ?>
                    <a href="<?php echo esc_url($edit_link); ?>" 
                       class="yooadmin-bar-item yooadmin-bar-edit-link"
                       title="<?php echo esc_attr($edit_label); ?>">
                        <span class="dashicons dashicons-edit"></span>
                        <span class="screen-reader-text"><?php echo esc_html($edit_label); ?></span>
                    </a>
                <?php endif; ?>

                <?php if (!empty($custom_nodes)): ?>
                    <?php foreach ($custom_nodes as $node): ?>
                        <?php
                        $node_href = isset($node->href) ? $node->href : '#';
                        $node_title = isset($node->title) ? $node->title : '';
                        $node_meta = isset($node->meta) ? $node->meta : [];
                        $node_class = isset($node_meta['class']) ? $node_meta['class'] : '';
                        $node_target = isset($node_meta['target']) ? $node_meta['target'] : '';
                        ?>
                        <a href="<?php echo esc_url($node_href); ?>" 
                           class="yooadmin-bar-item yooadmin-bar-custom-node <?php echo esc_attr($node_class); ?>"
                           <?php if ($node_target): ?>target="<?php echo esc_attr($node_target); ?>"<?php endif; ?>>
                            <?php echo wp_kses_post($node_title); ?>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>

                <!-- Profile -->
                <div class="yooadmin-bar-dropdown">
                    <button class="yooadmin-bar-item yooadmin-bar-trigger yooadmin-bar-profile" aria-label="<?php esc_attr_e('Profile', 'yooadmin'); ?>">
                        <img src="<?php echo esc_url($user_avatar); ?>" alt="<?php echo esc_attr($user_display); ?>" class="yooadmin-bar-avatar">
                    </button>
                    <div class="yooadmin-bar-dropdown-menu yooadmin-bar-dropdown-right">
                        <div class="yooadmin-bar-user-info">
                            <img src="<?php echo esc_url($user_avatar); ?>" alt="<?php echo esc_attr($user_display); ?>">
                            <div>
                                <strong><?php echo esc_html($user_display); ?></strong>
                                <small><?php echo esc_html($current_user->user_email); ?></small>
                            </div>
                        </div>
                        <div class="yooadmin-bar-dropdown-divider"></div>
                        <a href="<?php echo esc_url(admin_url('profile.php')); ?>" class="yooadmin-bar-dropdown-item">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php esc_html_e('Edit Profile', 'yooadmin'); ?>
                        </a>
                        <a href="<?php echo esc_url(wp_logout_url(function_exists('yooadmin_login_post_logout_redirect_url') ? yooadmin_login_post_logout_redirect_url() : home_url())); ?>" class="yooadmin-bar-dropdown-item">
                            <span class="dashicons dashicons-exit"></span>
                            <?php esc_html_e('Logout', 'yooadmin'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}, 1);

if (!function_exists('yooadmin_should_enqueue_native_admin_bar_compat')) {
    /**
     * Native #wpadminbar is visible on the public site (custom YOOAdmin bar is not replacing it).
     */
    function yooadmin_should_enqueue_native_admin_bar_compat(): bool
    {
        if (!is_user_logged_in() || is_admin()) {
            return false;
        }

        if (yooadmin_frontend_bar_is_customizer_preview()) {
            return false;
        }

        if (!function_exists('is_admin_bar_showing') || !is_admin_bar_showing()) {
            return false;
        }

        return !yooadmin_is_custom_frontend_admin_bar_enabled();
    }
}

if (!function_exists('yooadmin_enqueue_native_admin_bar_compat_assets')) {
    /**
     * Reset theme bleed + optional dark tokens on the native frontend toolbar.
     */
    function yooadmin_enqueue_native_admin_bar_compat_assets(): void
    {
        if (!yooadmin_should_enqueue_native_admin_bar_compat()) {
            return;
        }

        if (!defined('YOOADMIN_URL') || !defined('YOOADMIN_DIR')) {
            return;
        }

        $rel = 'assets/css/frontend/native-admin-bar-compat.css';
        $abs = YOOADMIN_DIR . $rel;
        if (!is_readable($abs)) {
            return;
        }

        wp_enqueue_style(
            'yooadmin-native-admin-bar-compat',
            YOOADMIN_URL . $rel,
            ['admin-bar'],
            (string) filemtime($abs)
        );
    }
}

add_action('wp_enqueue_scripts', 'yooadmin_enqueue_native_admin_bar_compat_assets', 25);

if (!function_exists('yooadmin_print_native_admin_bar_mode_bootstrap')) {
    /**
     * Mirror Studio Hub color mode on the frontend native bar (no flash).
     */
    function yooadmin_print_native_admin_bar_mode_bootstrap(): void
    {
        if (!yooadmin_should_enqueue_native_admin_bar_compat()) {
            return;
        }

        $mode = yooadmin_frontend_bar_get_appearance_mode();
        printf(
            '<script id="yooadmin-native-admin-bar-mode">(function(){var m=%1$s;var eff="light";'
            . 'if(m==="dark"){eff="dark";}else if(m==="auto"){try{eff=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(e){eff="light";}}'
            . 'document.documentElement.setAttribute("data-yooadmin-frontend-bar-mode-effective",eff);'
            . 'document.documentElement.setAttribute("data-yooadmin-studio-color-mode-effective",eff);})();</script>' . "\n",
            wp_json_encode($mode)
        );
    }
}

add_action('wp_head', 'yooadmin_print_native_admin_bar_mode_bootstrap', 2);

/**
 * Add body class for admin bar spacing
 */
add_filter('body_class', function($classes) {
    $options = (array) get_option('yooadmin_options', []);
    $custom_bar_enabled = !empty($options['enable_custom_admin_bar']);

    if (
        is_user_logged_in()
        && $custom_bar_enabled
        && !yooadmin_frontend_bar_is_customizer_preview()
        && (!function_exists('yooadmin_is_focus_enabled') || yooadmin_is_focus_enabled())
    ) {
        $classes[] = 'yooadmin-has-bar';
        $classes[] = 'admin-bar';
    }
    return $classes;
});
