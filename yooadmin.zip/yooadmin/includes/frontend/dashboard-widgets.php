<?php
/**
 * YOOAdmin - Dashboard widgets
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

const YOOADMIN_OVERVIEW_HIDDEN_META = 'yooadmin_overview_hidden_items';
const YOOADMIN_OVERVIEW_DEFAULT_VISIBLE_ITEMS = [
    'updates',
    'comments',
    'wp_version',
    'php_version',
    'ssl',
];

/* -------------------------------------------------------------------------
 * Configuration (defaults) — can be driven later from a settings screen
 * ---------------------------------------------------------------------- */

/**
 * Returns plugin settings with safe defaults.
 */
function yooadmin_dw_get_settings(): array {
    $opt = get_option('yooadmin_panel_settings', []);

    $defaults = [
        'dashboard_widget_enabled' => true,
        'hide_core_widgets'      => [
            'dashboard_quick_press',
            'dashboard_primary',
            'dashboard_activity',
        ],
        'capability'             => 'manage_options',
    ];

    $out = wp_parse_args(is_array($opt) ? $opt : [], $defaults);

    $out['dashboard_widget_enabled'] = (bool) apply_filters(
        'yooadmin_dashboard_widget_enable',
        $out['dashboard_widget_enabled'],
        $out
    );
    $out['hide_core_widgets'] = (array) apply_filters(
        'yooadmin_dashboard_hide_core_widgets',
        $out['hide_core_widgets'],
        $out
    );
    $out['capability'] = (string) apply_filters(
        'yooadmin_dashboard_widget_capability',
        $out['capability'],
        $out
    );

    return $out;
}

/* -------------------------------------------------------------------------
 * Helpers
 * ---------------------------------------------------------------------- */

function yooadmin_dw_is_woo_active(): bool {
    return class_exists('WooCommerce');
}

function yooadmin_dw_text_domain(): string {
    return 'yooadmin';
}

/**
 * @return array{updates:int,comments:int,orders_td:?int,orders_yd:?int}
 */
function yooadmin_dw_collect_counts(): array {
    $counts = [
        'updates'   => 0,
        'comments'  => 0,
        'orders_td' => null,
        'orders_yd' => null,
    ];

    if (function_exists('wp_get_update_data')) {
        $u = wp_get_update_data();
        if (is_array($u) && isset($u['counts']['total'])) {
            $counts['updates'] = (int) $u['counts']['total'];
        }
    }

    $counts['comments'] = (int) get_comments([
        'status' => 'hold',
        'count'  => true,
    ]);

    if (yooadmin_dw_is_woo_active() && function_exists('wc_get_orders')) {
        try {
            $counts['orders_td'] = (int) yooadmin_wc_orders_count_for_date('today');
            $y_start             = (new DateTime('yesterday 00:00:00', wp_timezone()))->format('Y-m-d H:i:s');
            $y_end               = (new DateTime('yesterday 23:59:59', wp_timezone()))->format('Y-m-d H:i:s');
            $counts['orders_yd'] = (int) yooadmin_wc_orders_count_for_date_range($y_start, $y_end);
        } catch (Throwable $e) {
            $counts['orders_td'] = null;
            $counts['orders_yd'] = null;
        }
    }

    return $counts;
}

function yooadmin_wc_orders_count_for_date(string $when): int {
    if (!function_exists('wc_get_orders')) {
        return 0;
    }
    $res = wc_get_orders([
        'limit'        => 1,
        'paginate'     => true,
        'return'       => 'ids',
        'date_created' => $when,
        'status'       => array_keys(wc_get_order_statuses()),
    ]);
    return (int) ($res && isset($res->total) ? $res->total : 0);
}

function yooadmin_wc_orders_count_for_date_range(string $start_gmt, string $end_gmt): int {
    if (!function_exists('wc_get_orders')) {
        return 0;
    }
    $res = wc_get_orders([
        'limit'        => 1,
        'paginate'     => true,
        'return'       => 'ids',
        'date_created' => $start_gmt . '...' . $end_gmt,
        'status'       => array_keys(wc_get_order_statuses()),
    ]);
    return (int) ($res && isset($res->total) ? $res->total : 0);
}

/**
 * Server / environment facts for overview cards.
 *
 * @return array<string, mixed>
 */
function yooadmin_dw_collect_server_info(): array {
    $info = [
        'memory_limit'   => ini_get('memory_limit') ?: '—',
        'max_upload'     => function_exists('wp_max_upload_size') ? size_format((float) wp_max_upload_size()) : '—',
        'disk'           => null,
        'db_size'        => null,
        'ssl'            => is_ssl(),
        'cron_disabled'  => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON,
        'cron_next'      => wp_next_scheduled('wp_version_check'),
        'active_plugins' => 0,
        'theme'          => '',
    ];

    $path = defined('ABSPATH') ? ABSPATH : '';
    if ($path !== '') {
        $free  = @disk_free_space($path);
        $total = @disk_total_space($path);
        if ($free !== false && $total !== false && $total > 0) {
            $used          = $total - $free;
            $info['disk'] = [
                'used'  => $used,
                'free'  => $free,
                'total' => $total,
                'pct'   => round(($used / $total) * 100, 1),
            ];
        }
    }

    global $wpdb;
    if (isset($wpdb) && $wpdb instanceof wpdb) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $db_bytes = $wpdb->get_var(
            $wpdb->prepare(
                'SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = %s',
                DB_NAME
            )
        );
        if ($db_bytes !== null) {
            $info['db_size'] = (int) $db_bytes;
        }
    }

    if (function_exists('get_option')) {
        $plugins = get_option('active_plugins', []);
        $info['active_plugins'] = is_array($plugins) ? count($plugins) : 0;
    }

    $theme = wp_get_theme();
    if ($theme && $theme->exists()) {
        $info['theme'] = $theme->get('Name');
    }

    return $info;
}

/**
 * @return string[]
 */
function yooadmin_dw_get_default_hidden_item_ids(): array {
    $allowed = array_keys(yooadmin_dw_get_overview_item_definitions());
    $visible = array_values(array_intersect(YOOADMIN_OVERVIEW_DEFAULT_VISIBLE_ITEMS, $allowed));

    return array_values(array_diff($allowed, $visible));
}

/**
 * @return string[]
 */
function yooadmin_dw_get_hidden_item_ids(int $user_id = 0): array {
    $user_id = $user_id > 0 ? $user_id : get_current_user_id();
    if ($user_id <= 0) {
        return yooadmin_dw_get_default_hidden_item_ids();
    }
    if (!metadata_exists('user', $user_id, YOOADMIN_OVERVIEW_HIDDEN_META)) {
        return yooadmin_dw_get_default_hidden_item_ids();
    }
    $raw = get_user_meta($user_id, YOOADMIN_OVERVIEW_HIDDEN_META, true);
    if (!is_array($raw)) {
        return [];
    }
    return array_values(array_filter(array_map('sanitize_key', $raw)));
}

/**
 * @param string[] $ids
 */
function yooadmin_dw_save_hidden_item_ids(array $ids, int $user_id = 0): bool {
    $user_id = $user_id > 0 ? $user_id : get_current_user_id();
    if ($user_id <= 0) {
        return false;
    }
    $allowed = array_keys(yooadmin_dw_get_overview_item_definitions());
    $clean   = [];
    foreach ($ids as $id) {
        $id = sanitize_key((string) $id);
        if ($id !== '' && in_array($id, $allowed, true)) {
            $clean[] = $id;
        }
    }
    update_user_meta($user_id, YOOADMIN_OVERVIEW_HIDDEN_META, array_values(array_unique($clean)));
    return true;
}

/**
 * Registry of overview stat ids (for prefs validation).
 *
 * @return array<string, true>
 */
function yooadmin_dw_get_overview_item_definitions(): array {
    $defs = [
        'updates'          => true,
        'comments'         => true,
        'orders_today'     => true,
        'orders_yesterday' => true,
        'wp_version'       => true,
        'php_version'      => true,
        'memory'           => true,
        'disk_space'       => true,
        'db_size'          => true,
        'ssl'              => true,
        'max_upload'       => true,
        'cron'             => true,
        'plugins_count'    => true,
        'active_theme'     => true,
    ];
    if (!yooadmin_dw_is_woo_active()) {
        unset($defs['orders_today'], $defs['orders_yesterday']);
    }
    return $defs;
}

/**
 * Build renderable overview cards.
 *
 * @return array<int, array<string, mixed>>
 */
function yooadmin_dw_build_overview_items(): array {
    $counts = yooadmin_dw_collect_counts();
    $server = yooadmin_dw_collect_server_info();

    $updates_url = network_admin_url('update-core.php');
    $cmnts_url   = admin_url('edit-comments.php');

    $items = [];

    $items[] = [
        'id'    => 'updates',
        'icon'  => 'dashicons-update',
        'label' => __('Updates', 'yooadmin'),
        'value' => $counts['updates'] > 0
            ? sprintf(
                /* translators: %d: number of updates */
                _n('%d update', '%d updates', $counts['updates'], 'yooadmin'),
                $counts['updates']
            )
            : __('All up to date', 'yooadmin'),
        'url'   => $counts['updates'] > 0 ? $updates_url : '',
        'tone'  => $counts['updates'] > 0 ? 'warn' : 'ok',
    ];

    $items[] = [
        'id'    => 'comments',
        'icon'  => 'dashicons-admin-comments',
        'label' => __('Pending Comments', 'yooadmin'),
        'value' => $counts['comments'] > 0
            ? (string) $counts['comments']
            : __('None', 'yooadmin'),
        'url'   => $counts['comments'] > 0 ? $cmnts_url : '',
        'tone'  => $counts['comments'] > 0 ? 'warn' : 'ok',
    ];

    if (yooadmin_dw_is_woo_active()) {
        $items[] = [
            'id'    => 'orders_today',
            'icon'  => 'dashicons-cart',
            'label' => __('Orders Today', 'yooadmin'),
            'value' => $counts['orders_td'] !== null ? (string) (int) $counts['orders_td'] : '—',
            'url'   => '',
            'tone'  => '',
        ];
        $items[] = [
            'id'    => 'orders_yesterday',
            'icon'  => 'dashicons-calendar-alt',
            'label' => __('Orders Yesterday', 'yooadmin'),
            'value' => $counts['orders_yd'] !== null ? (string) (int) $counts['orders_yd'] : '—',
            'url'   => '',
            'tone'  => '',
        ];
    }

    $items[] = [
        'id'    => 'wp_version',
        'icon'  => 'dashicons-wordpress',
        'label' => __('WordPress', 'yooadmin'),
        'value' => get_bloginfo('version'),
        'url'   => '',
        'tone'  => '',
    ];

    $items[] = [
        'id'    => 'php_version',
        'icon'  => 'dashicons-editor-code',
        'label' => __('PHP', 'yooadmin'),
        'value' => PHP_VERSION,
        'url'   => '',
        'tone'  => '',
    ];

    $items[] = [
        'id'    => 'memory',
        'icon'  => 'dashicons-performance',
        'label' => __('Memory limit', 'yooadmin'),
        'value' => (string) $server['memory_limit'],
        'url'   => '',
        'tone'  => '',
    ];

    if (!empty($server['disk']) && is_array($server['disk'])) {
        $disk = $server['disk'];
        $items[] = [
            'id'    => 'disk_space',
            'icon'  => 'dashicons-cloud',
            'label' => __('Disk usage', 'yooadmin'),
            'value' => sprintf(
                /* translators: 1: used size, 2: total size, 3: percent */
                __('%1$s / %2$s (%3$s%%)', 'yooadmin'),
                size_format((float) $disk['used']),
                size_format((float) $disk['total']),
                $disk['pct']
            ),
            'url'   => '',
            'tone'  => $disk['pct'] >= 90 ? 'warn' : '',
        ];
    }

    if ($server['db_size'] !== null) {
        $items[] = [
            'id'    => 'db_size',
            'icon'  => 'dashicons-database',
            'label' => __('Database size', 'yooadmin'),
            'value' => size_format((float) $server['db_size']),
            'url'   => '',
            'tone'  => '',
        ];
    }

    $items[] = [
        'id'    => 'ssl',
        'icon'  => 'dashicons-lock',
        'label' => __('SSL', 'yooadmin'),
        'value' => !empty($server['ssl'])
            ? __('Active (this request)', 'yooadmin')
            : __('Not detected', 'yooadmin'),
        'url'   => '',
        'tone'  => !empty($server['ssl']) ? 'ok' : 'warn',
    ];

    $items[] = [
        'id'    => 'max_upload',
        'icon'  => 'dashicons-upload',
        'label' => __('Max upload', 'yooadmin'),
        'value' => (string) $server['max_upload'],
        'url'   => '',
        'tone'  => '',
    ];

    if (!empty($server['cron_disabled'])) {
        $cron_value = __('WP-Cron disabled', 'yooadmin');
        $cron_tone  = 'warn';
    } elseif (!empty($server['cron_next'])) {
        $cron_value = sprintf(
            /* translators: %s: localized date/time */
            __('Next: %s', 'yooadmin'),
            wp_date(get_option('date_format') . ' ' . get_option('time_format'), (int) $server['cron_next'])
        );
        $cron_tone = 'ok';
    } else {
        $cron_value = __('No scheduled events', 'yooadmin');
        $cron_tone  = 'warn';
    }

    $items[] = [
        'id'    => 'cron',
        'icon'  => 'dashicons-clock',
        'label' => __('Cron', 'yooadmin'),
        'value' => $cron_value,
        'url'   => '',
        'tone'  => $cron_tone,
    ];

    $items[] = [
        'id'    => 'plugins_count',
        'icon'  => 'dashicons-admin-plugins',
        'label' => __('Active plugins', 'yooadmin'),
        'value' => (string) (int) $server['active_plugins'],
        'url'   => admin_url('plugins.php'),
        'tone'  => '',
    ];

    if ($server['theme'] !== '') {
        $items[] = [
            'id'    => 'active_theme',
            'icon'  => 'dashicons-admin-appearance',
            'label' => __('Active theme', 'yooadmin'),
            'value' => (string) $server['theme'],
            'url'   => admin_url('themes.php'),
            'tone'  => '',
        ];
    }

    return apply_filters('yooadmin_overview_items', $items, $counts, $server);
}

/**
 * @param array<string, mixed> $item
 */
function yooadmin_dw_render_overview_card(array $item, array $hidden): void {
    $id    = isset($item['id']) ? sanitize_key((string) $item['id']) : '';
    $icon  = isset($item['icon']) ? (string) $item['icon'] : 'dashicons-info';
    $label = isset($item['label']) ? (string) $item['label'] : '';
    $value = isset($item['value']) ? (string) $item['value'] : '';
    $url   = isset($item['url']) ? (string) $item['url'] : '';
    $tone  = isset($item['tone']) ? sanitize_html_class((string) $item['tone']) : '';

    if ($id === '') {
        return;
    }

    $classes = ['yooadmin-overview-card'];
    if ($tone !== '') {
        $classes[] = 'yooadmin-overview-card--tone-' . $tone;
    }
    if (in_array($id, $hidden, true)) {
        $classes[] = 'is-hidden';
    }

    echo '<li class="' . esc_attr(implode(' ', $classes)) . '" data-overview-item="' . esc_attr($id) . '">';
    echo '<span class="yooadmin-overview-card__icon" aria-hidden="true">';
    echo '<span class="dashicons ' . esc_attr($icon) . '"></span>';
    echo '</span>';
    echo '<span class="yooadmin-overview-card__body">';
    echo '<span class="yooadmin-overview-card__label">' . esc_html($label) . '</span>';
    echo '<span class="yooadmin-overview-card__value">';
    if ($url !== '') {
        echo '<a href="' . esc_url($url) . '">' . esc_html($value) . '</a>';
    } else {
        echo esc_html($value);
    }
    echo '</span></span></li>';
}

function yooadmin_dw_should_enqueue_overview_assets(): bool {
    if (!is_admin()) {
        return false;
    }

    // Do not call yooadmin_studio_hub_is_dashboard_screen() here — it may run before
    // yooadmin_studio_hub_is_active() exists during admin_enqueue_scripts.
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    $slug = function_exists('yooadmin_dashboard_slug')
        ? (string) yooadmin_dashboard_slug()
        : 'yooadmin-dashboard';
    if ($page === $slug) {
        return true;
    }

    global $pagenow;
    return isset($pagenow) && $pagenow === 'index.php';
}

function yooadmin_dw_enqueue_overview_assets(bool $force = false): void {
    if (!$force && !yooadmin_dw_should_enqueue_overview_assets()) {
        return;
    }
    if (!defined('YOOADMIN_PLUGIN_FILE')) {
        return;
    }

    $ver = defined('YOOADMIN_VERSION') ? YOOADMIN_VERSION : '1.0.0';

    wp_enqueue_style(
        'yooadmin-overview-widget',
        plugins_url('assets/css/admin/yooadmin-overview-widget.css', YOOADMIN_PLUGIN_FILE),
        [],
        $ver
    );
    wp_enqueue_script(
        'yooadmin-overview-widget',
        plugins_url('assets/js/admin/yooadmin-overview-widget.js', YOOADMIN_PLUGIN_FILE),
        [],
        $ver,
        true
    );
    wp_localize_script(
        'yooadmin-overview-widget',
        'yooadminOverviewWidget',
        [
            'ajaxUrl'       => admin_url('admin-ajax.php'),
            'nonce'         => wp_create_nonce('yooadmin_overview_prefs'),
            'hidden'        => yooadmin_dw_get_hidden_item_ids(),
            'defaultHidden' => yooadmin_dw_get_default_hidden_item_ids(),
        ]
    );
}

add_action(
    'admin_enqueue_scripts',
    static function (): void {
        yooadmin_dw_enqueue_overview_assets(false);
    },
    25
);

add_action(
    'yooadmin_studio_hub_enqueue_dashboard_widget_assets',
    static function (string $widget_id): void {
        if (in_array($widget_id, ['yooadmin_overview_widget', 'yooadmin_overview'], true)) {
            yooadmin_dw_enqueue_overview_assets(true);
        }
    },
    10,
    1
);

add_action(
    'wp_ajax_yooadmin_overview_save_prefs',
    static function (): void {
        if (!current_user_can('read')) {
            wp_send_json_error(['message' => 'forbidden'], 403);
        }
        check_ajax_referer('yooadmin_overview_prefs', 'nonce');

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON array validated after json_decode.
        $raw = isset($_POST['hidden']) ? wp_unslash($_POST['hidden']) : '[]';
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
        } else {
            $decoded = [];
        }
        if (!is_array($decoded)) {
            $decoded = [];
        }

        yooadmin_dw_save_hidden_item_ids($decoded);
        wp_send_json_success(['hidden' => yooadmin_dw_get_hidden_item_ids()]);
    }
);

/* -------------------------------------------------------------------------
 * Hide unwanted core widgets
 * ---------------------------------------------------------------------- */
add_action('wp_dashboard_setup', function () {
    $s       = yooadmin_dw_get_settings();
    $to_hide = (array) $s['hide_core_widgets'];

    if (empty($to_hide)) {
        return;
    }

    $map = [
        'dashboard_quick_press' => ['dashboard', 'side'],
        'dashboard_primary'     => ['dashboard', 'side'],
        'dashboard_secondary'   => ['dashboard', 'side'],
        'dashboard_activity'    => ['dashboard', 'normal'],
        'dashboard_site_health' => ['dashboard', 'normal'],
        'dashboard_right_now'   => ['dashboard', 'normal'],
    ];

    foreach ($to_hide as $id) {
        if (isset($map[$id])) {
            remove_meta_box($id, $map[$id][0], $map[$id][1]);
        } else {
            remove_meta_box($id, 'dashboard', 'normal');
            remove_meta_box($id, 'dashboard', 'side');
        }
    }
}, 20);

/* -------------------------------------------------------------------------
 * Register our widget
 * ---------------------------------------------------------------------- */
add_action('wp_dashboard_setup', function () {
    $s = yooadmin_dw_get_settings();

    if (empty($s['dashboard_widget_enabled'])) {
        return;
    }
    if (!current_user_can($s['capability'])) {
        return;
    }

    wp_add_dashboard_widget(
        'yooadmin_overview_widget',
        __('YOOAdmin Overview', 'yooadmin'),
        'yooadmin_dw_render_widget'
    );
}, 30);

/* -------------------------------------------------------------------------
 * Render widget
 * ---------------------------------------------------------------------- */
function yooadmin_dw_render_widget(): void {
    $items       = yooadmin_dw_build_overview_items();
    $hidden      = yooadmin_dw_get_hidden_item_ids();
    $hidden_json = wp_json_encode($hidden);
    if (!is_string($hidden_json)) {
        $hidden_json = '[]';
    }

    yooadmin_dw_enqueue_overview_assets(true);

    echo '<div class="yooadmin-overview-widget" data-overview-widget data-overview-hidden="' . esc_attr($hidden_json) . '">';

    echo '<div class="yooadmin-overview-widget__toolbar">';
    echo '<button type="button" class="yooadmin-overview-widget__customize" data-overview-customize-toggle aria-expanded="false">';
    echo '<span class="dashicons dashicons-visibility" aria-hidden="true"></span>';
    echo esc_html__('Customize', 'yooadmin');
    echo '</button></div>';

    echo '<div class="yooadmin-overview-widget__panel" data-overview-customize-panel hidden>';
    echo '<p class="yooadmin-overview-widget__panel-title">' . esc_html__('Show in overview', 'yooadmin') . '</p>';
    echo '<ul class="yooadmin-overview-widget__checks">';
    foreach ($items as $item) {
        $id = isset($item['id']) ? sanitize_key((string) $item['id']) : '';
        if ($id === '') {
            continue;
        }
        $is_visible = !in_array($id, $hidden, true);
        echo '<li class="yooadmin-overview-widget__check' . ($is_visible ? ' is-active' : '') . '">';
        echo '<div class="yooadmin-overview-widget__toggle-row">';
        echo '<label class="yp-toggle-switch yooadmin-overview-widget__toggle">';
        echo '<input type="checkbox" role="switch" data-overview-toggle="' . esc_attr($id) . '" aria-checked="' . ($is_visible ? 'true' : 'false') . '"';
        checked($is_visible, true, false);
        echo ' />';
        echo '<span class="yp-toggle-slider"></span>';
        echo '</label>';
        echo '<span class="yooadmin-overview-widget__check-text">' . esc_html((string) ($item['label'] ?? $id)) . '</span>';
        echo '</div></li>';
    }
    echo '</ul>';
    echo '<div class="yooadmin-overview-widget__panel-actions">';
    echo '<button type="button" class="yooadmin-overview-widget__save" data-overview-save>' . esc_html__('Save', 'yooadmin') . '</button>';
    echo '<button type="button" class="yooadmin-overview-widget__reset" data-overview-reset>' . esc_html__('Reset defaults', 'yooadmin') . '</button>';
    echo '</div></div>';

    echo '<ul class="yooadmin-overview-grid">';
    foreach ($items as $item) {
        yooadmin_dw_render_overview_card($item, $hidden);
    }
    echo '</ul>';

    echo '</div>';

    echo '<script>document.dispatchEvent(new CustomEvent("yooadmin-overview-widget-loaded"));</script>';
}
