(function () {
  'use strict';

  var cfg = window.yooadminLoginToolbar || {};
  var STORAGE_KEY = cfg.sessionStorageKey || 'yoo_login_appearance_override';
  var CSS_VARS = [
    '--yoo-login-primary',
    '--yoo-login-panel-bg',
    '--yoo-login-media-bg',
    '--yoo-login-placeholder-color',
    '--yoo-login-text',
    '--yoo-login-input-bg',
    '--yoo-login-input-border',
    '--yoo-login-link',
    '--yoo-login-footer-text',
    '--yoo-login-card-shadow'
  ];

  function effectiveMode(raw) {
    if (raw === 'auto') {
      try {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      } catch (e) {
        return 'light';
      }
    }
    return raw === 'dark' ? 'dark' : 'light';
  }

  function readStoredMode() {
    try {
      var stored = sessionStorage.getItem(STORAGE_KEY);
      if (stored === 'light' || stored === 'dark' || stored === 'auto') {
        return stored;
      }
    } catch (e) {
      /* ignore */
    }
    return '';
  }

  function getDefaultMode() {
    var d = (cfg.defaultAppearance || 'auto').toString();
    return d === 'light' || d === 'dark' || d === 'auto' ? d : 'auto';
  }

  function getRootEl() {
    return document.querySelector('body.yooadmin-login-standalone.yoo-standalone-login')
      || document.querySelector('body.yooadmin-login-standalone');
  }

  function applyCssVars(eff) {
    var root = getRootEl();
    if (!root) {
      return;
    }
    var map = eff === 'dark' ? (cfg.cssVarsDark || {}) : (cfg.cssVarsLight || {});
    CSS_VARS.forEach(function (k) {
      root.style.removeProperty(k);
    });
    Object.keys(map).forEach(function (k) {
      root.style.setProperty(k, map[k]);
    });
  }

  function syncLogo(eff) {
    if (!cfg.useDualLogos) {
      return;
    }
    var lightImgs = document.querySelectorAll('.yoo-sl-logo-img--light');
    var darkImgs = document.querySelectorAll('.yoo-sl-logo-img--dark');
    lightImgs.forEach(function (img) {
      img.style.display = eff === 'light' ? '' : 'none';
    });
    darkImgs.forEach(function (img) {
      img.style.display = eff === 'dark' ? '' : 'none';
    });
  }

  function setAppearanceMode(mode, persist) {
    var raw = mode || getDefaultMode();
    if (raw !== 'light' && raw !== 'dark' && raw !== 'auto') {
      raw = 'auto';
    }
    var eff = effectiveMode(raw);
    var html = document.documentElement;
    var body = getRootEl();

    html.setAttribute('data-yoo-login-color-mode', raw);
    html.setAttribute('data-yoo-login-color-mode-effective', eff);
    if (body) {
      body.setAttribute('data-yoo-login-color-mode', raw);
      body.setAttribute('data-yoo-login-color-mode-effective', eff);
    }

    document.querySelectorAll('[data-yoo-login-appearance]').forEach(function (btn) {
      var key = btn.getAttribute('data-yoo-login-appearance');
      var active = key === raw;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', active ? 'true' : 'false');
    });

    applyCssVars(eff);
    syncLogo(eff);

    if (persist) {
      try {
        sessionStorage.setItem(STORAGE_KEY, raw);
      } catch (e) {
        /* ignore */
      }
    }
  }

  function initAppearance() {
    var initial = readStoredMode() || getDefaultMode();
    setAppearanceMode(initial, false);

    document.addEventListener('click', function (e) {
      var btn = e.target && e.target.closest ? e.target.closest('[data-yoo-login-appearance]') : null;
      if (!btn) {
        return;
      }
      e.preventDefault();
      var mode = btn.getAttribute('data-yoo-login-appearance');
      setAppearanceMode(mode, true);
    });

    try {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      var onChange = function () {
        var current = readStoredMode() || getDefaultMode();
        if (current === 'auto') {
          setAppearanceMode('auto', false);
        }
      };
      if (typeof mq.addEventListener === 'function') {
        mq.addEventListener('change', onChange);
      } else if (typeof mq.addListener === 'function') {
        mq.addListener(onChange);
      }
    } catch (err) {
      /* ignore */
    }
  }

  function initLanguageMenu() {
    var wrap = document.querySelector('[data-yoo-login-lang-switcher]');
    if (!wrap) {
      return;
    }
    var toggle = wrap.querySelector('.yoo-login-toolbar__lang-toggle');
    var menu = wrap.querySelector('.yoo-login-toolbar__lang-menu');
    if (!toggle || !menu) {
      return;
    }

    toggle.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var open = wrap.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) {
        menu.removeAttribute('hidden');
      } else {
        menu.setAttribute('hidden', '');
      }
    });

    document.addEventListener('click', function (e) {
      if (!wrap.contains(e.target)) {
        wrap.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        menu.setAttribute('hidden', '');
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && wrap.classList.contains('is-open')) {
        wrap.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        menu.setAttribute('hidden', '');
        toggle.focus();
      }
    });
  }

  function boot() {
    initAppearance();
    initLanguageMenu();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
