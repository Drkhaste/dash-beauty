(function () {
  'use strict';

  var cfg = typeof window.yooadminSlAjax === 'object' && window.yooadminSlAjax ? window.yooadminSlAjax : null;

  function ensureMessagesContainer() {
    var el = document.getElementById('yoo-sl-messages');
    if (!el) {
      el = document.createElement('div');
      el.id = 'yoo-sl-messages';
      el.className = 'yoo-sl-messages yoo-sl-messages--fixed';
      el.setAttribute('role', 'region');
      el.setAttribute('aria-live', 'polite');
      el.setAttribute('aria-relevant', 'additions');
      document.body.insertBefore(el, document.body.firstChild);
    }
    return el;
  }

  function iconClass(kind) {
    if (kind === 'error') {
      return 'dashicons-warning';
    }
    if (kind === 'success') {
      return 'dashicons-yes-alt';
    }
    return 'dashicons-info';
  }

  function removeToast(toast) {
    if (!toast || !toast.parentNode) {
      return;
    }
    toast.classList.add('yoo-sl-toast--out');
    window.setTimeout(function () {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
      var wrap = document.getElementById('yoo-sl-messages');
      if (wrap && wrap.children.length === 0) {
        wrap.parentNode.removeChild(wrap);
      }
    }, 280);
  }

  function showToast(kind, text) {
    var wrap = ensureMessagesContainer();
    var toast = document.createElement('div');
    toast.className = 'yoo-sl-toast yoo-sl-toast--' + kind;
    toast.setAttribute('data-yoo-sl-toast', kind);
    toast.setAttribute('role', 'alert');

    var ic = document.createElement('span');
    ic.className = 'yoo-sl-toast__icon dashicons ' + iconClass(kind);
    ic.setAttribute('aria-hidden', 'true');

    var body = document.createElement('div');
    body.className = 'yoo-sl-toast__body';
    body.appendChild(document.createTextNode(text));

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'yoo-sl-toast__close';
    btn.setAttribute('aria-label', (cfg && cfg.i18n && cfg.i18n.dismiss) || 'Dismiss');
    btn.innerHTML = '&times;';
    btn.addEventListener('click', function () {
      removeToast(toast);
    });

    toast.appendChild(ic);
    toast.appendChild(body);
    toast.appendChild(btn);
    wrap.appendChild(toast);

    if (kind === 'success' || kind === 'info') {
      window.setTimeout(function () {
        removeToast(toast);
      }, 6500);
    }
  }

  function parseAjaxJsonPayload(text) {
    var trimmed = (text || '').trim();
    if (trimmed === '-1' || trimmed === '0') {
      return { parsed: null, legacyFail: true };
    }
    try {
      return { parsed: JSON.parse(trimmed), legacyFail: false };
    } catch (e1) {
      var start = trimmed.indexOf('{');
      var end = trimmed.lastIndexOf('}');
      if (start >= 0 && end > start) {
        try {
          return { parsed: JSON.parse(trimmed.slice(start, end + 1)), legacyFail: false };
        } catch (e2) {
          /* fall through */
        }
      }
    }
    return { parsed: null, legacyFail: false };
  }

  function parseAjaxResponse(response) {
    return response.text().then(function (t) {
      return parseAjaxJsonPayload(t);
    });
  }

  function turnstileRequiredFor(actionKey) {
    if (!cfg || !cfg.turnstile || !cfg.turnstile.enabled || !cfg.turnstile.siteKey) {
      return false;
    }
    if (actionKey === 'login' || actionKey === 'resetpass') {
      return true;
    }
    if (actionKey === 'lostpassword') {
      return !!cfg.turnstile.protectLostPassword;
    }
    return false;
  }

  function turnstileActionForForm(form) {
    if (!form || !form.id) {
      return '';
    }
    if (form.id === 'loginform') {
      return 'login';
    }
    if (form.id === 'lostpasswordform') {
      return 'lostpassword';
    }
    if (form.id === 'resetpassform') {
      return 'resetpass';
    }
    return '';
  }

  function getTurnstileToken(form) {
    if (!form) {
      return '';
    }
    var input = form.querySelector('input[name="cf-turnstile-response"]');
    return input && input.value ? String(input.value).trim() : '';
  }

  function turnstileWrapFor(el) {
    if (!el) {
      return null;
    }
    return el.closest('[data-yoo-turnstile-wrap]') || el.closest('.yoo-sl-turnstile-wrap');
  }

  function turnstileI18n(key, fallback) {
    return (cfg.i18n && cfg.i18n[key]) || fallback;
  }

  function formForTurnstileEl(el) {
    if (!el) {
      return null;
    }
    return el.closest('form');
  }

  function setTurnstileSubmitGate(form, ready) {
    if (!form) {
      return;
    }
    var submitBtn = form.querySelector('input[type="submit"],button[type="submit"]');
    var blocked = !ready;
    form.classList.toggle('yoo-sl-form--awaiting-turnstile', blocked);
    if (submitBtn) {
      submitBtn.disabled = blocked;
      submitBtn.setAttribute('aria-disabled', blocked ? 'true' : 'false');
    }
  }

  var TURNSTILE_PENDING_TIMEOUT_MS = 45000;

  function setTurnstileChallengeVisible(el, visible) {
    var wrap = turnstileWrapFor(el);
    if (!wrap) {
      return;
    }
    wrap.classList.toggle('is-challenge-visible', !!visible);
    if (visible) {
      clearTurnstileWatchdog(el);
      wrap.removeAttribute('data-yoo-turnstile-error-reason');
      if (wrap.getAttribute('data-yoo-turnstile-state') === 'pending') {
        wrap.classList.remove('is-error');
        wrap.classList.add('is-pending');
        var textEl = wrap.querySelector('.yoo-sl-turnstile-status__text');
        if (textEl) {
          textEl.textContent = turnstileI18n(
            'securityChallenge',
            'Please complete the security check below.'
          );
        }
        var retryBtn = wrap.querySelector('.yoo-sl-turnstile-retry');
        if (retryBtn) {
          retryBtn.setAttribute('hidden', 'hidden');
        }
      }
      return;
    }
    if (wrap.getAttribute('data-yoo-turnstile-state') === 'pending') {
      startTurnstileWatchdog(el);
    }
  }

  function clearTurnstileWatchdog(el) {
    var wrap = turnstileWrapFor(el);
    if (!wrap) {
      return;
    }
    var raw = wrap.getAttribute('data-yoo-turnstile-watchdog');
    if (raw) {
      window.clearTimeout(parseInt(raw, 10));
      wrap.removeAttribute('data-yoo-turnstile-watchdog');
    }
  }

  function startTurnstileWatchdog(el) {
    clearTurnstileWatchdog(el);
    var wrap = turnstileWrapFor(el);
    if (!wrap) {
      return;
    }
    if (wrap.classList.contains('is-challenge-visible')) {
      return;
    }
    var widget = el;
    var timerId = window.setTimeout(function () {
      if (wrap.getAttribute('data-yoo-turnstile-state') !== 'pending') {
        return;
      }
      if (wrap.classList.contains('is-challenge-visible')) {
        return;
      }
      setTurnstileChallengeVisible(widget, true);
      remountTurnstileWidget(widget);
    }, TURNSTILE_PENDING_TIMEOUT_MS);
    wrap.setAttribute('data-yoo-turnstile-watchdog', String(timerId));
  }

  function syncTurnstileRetryButton(wrap, state) {
    if (!wrap) {
      return;
    }
    var retryBtn = wrap.querySelector('.yoo-sl-turnstile-retry');
    if (!retryBtn) {
      return;
    }
    if (state === 'error') {
      retryBtn.removeAttribute('hidden');
    } else {
      retryBtn.setAttribute('hidden', 'hidden');
    }
  }

  function setTurnstileState(el, state, messageKey) {
    var wrap = turnstileWrapFor(el);
    if (!wrap) {
      return;
    }
    var normalized = state === 'verified' || state === 'error' ? state : 'pending';
    wrap.classList.remove('is-pending', 'is-verified', 'is-error');
    wrap.classList.add('is-' + normalized);
    wrap.setAttribute('data-yoo-turnstile-state', normalized);

    if (normalized === 'verified') {
      clearTurnstileWatchdog(el);
      wrap.removeAttribute('data-yoo-turnstile-error-reason');
      setTurnstileChallengeVisible(el, false);
    } else if (normalized === 'pending') {
      wrap.removeAttribute('data-yoo-turnstile-error-reason');
      if (!wrap.classList.contains('is-challenge-visible')) {
        startTurnstileWatchdog(el);
      }
    } else {
      clearTurnstileWatchdog(el);
      setTurnstileChallengeVisible(el, true);
    }

    var textEl = wrap.querySelector('.yoo-sl-turnstile-status__text');
    var iconEl = wrap.querySelector('.yoo-sl-turnstile-status__icon');
    var reason = wrap.getAttribute('data-yoo-turnstile-error-reason') || '';
    if (textEl) {
      if (normalized === 'verified') {
        textEl.textContent = turnstileI18n('securityVerified', 'Security verification complete');
      } else if (normalized === 'error') {
        if (messageKey === 'securityBlocked' || reason === 'blocked') {
          textEl.textContent = turnstileI18n(
            'securityBlocked',
            'Security service could not load. Check your connection or VPN.'
          );
        } else if (reason === 'challenge') {
          textEl.textContent = turnstileI18n(
            'securityChallenge',
            'Please complete the security check below.'
          );
        } else if (messageKey === 'securityTimeout' || reason === 'timeout') {
          textEl.textContent = turnstileI18n(
            'securityTimeout',
            'Security check timed out. Try again or disable VPN/proxy.'
          );
        } else {
          textEl.textContent = turnstileI18n(
            'securityFailed',
            'Security verification failed. Please try again.'
          );
        }
      } else if (wrap.classList.contains('is-challenge-visible')) {
        textEl.textContent = turnstileI18n(
          'securityChallenge',
          'Please complete the security check below.'
        );
      } else {
        textEl.textContent = turnstileI18n('securityChecking', 'Security verification in progress…');
      }
    }
    if (iconEl) {
      iconEl.classList.remove('dashicons-shield-alt', 'dashicons-yes-alt', 'dashicons-warning');
      if (normalized === 'verified') {
        iconEl.classList.add('dashicons-yes-alt');
      } else if (normalized === 'error') {
        iconEl.classList.add('dashicons-warning');
      } else {
        iconEl.classList.add('dashicons-shield-alt');
      }
    }

    syncTurnstileRetryButton(wrap, normalized);

    var form = formForTurnstileEl(el);
    setTurnstileSubmitGate(form, normalized === 'verified');
  }

  function resetTurnstileInForm(form) {
    if (!form) {
      return;
    }
    var widget = form.querySelector('[data-yoo-turnstile-ready]');
    if (!widget) {
      return;
    }
    setTurnstileState(widget, 'pending');
    setTurnstileChallengeVisible(widget, true);
    remountTurnstileWidget(widget);
  }

  function getLoginColorModeEffective() {
    var html = document.documentElement;
    var body = document.querySelector('body.yooadmin-login-standalone');
    var eff =
      (html && html.getAttribute('data-yoo-login-color-mode-effective')) ||
      (body && body.getAttribute('data-yoo-login-color-mode-effective')) ||
      '';
    if (eff === 'dark' || eff === 'light') {
      return eff;
    }
    var raw =
      (html && html.getAttribute('data-yoo-login-color-mode')) ||
      (body && body.getAttribute('data-yoo-login-color-mode')) ||
      'auto';
    if (raw === 'dark' || raw === 'light') {
      return raw;
    }
    try {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    } catch (e) {
      return 'light';
    }
  }

  function getTurnstileTheme() {
    return getLoginColorModeEffective() === 'dark' ? 'dark' : 'light';
  }

  function getTurnstileLanguage() {
    var lang = cfg.turnstile && cfg.turnstile.language ? String(cfg.turnstile.language) : '';
    if (lang !== '' && lang !== 'auto') {
      return lang;
    }
    var docLang = document.documentElement.getAttribute('lang') || '';
    if (docLang !== '') {
      return docLang.replace(/_/g, '-').split('-')[0];
    }
    return 'auto';
  }

  function removeTurnstileWidget(el) {
    if (!el || !window.turnstile) {
      return;
    }
    var widgetId = el.getAttribute('data-yoo-turnstile-widget-id');
    if (typeof window.turnstile.remove === 'function') {
      try {
        window.turnstile.remove(widgetId || el);
      } catch (e) {
        /* ignore */
      }
    }
    el.removeAttribute('data-yoo-turnstile-ready');
    el.removeAttribute('data-yoo-turnstile-widget-id');
  }

  function mountTurnstileWidget(el) {
    if (!el || !window.turnstile || typeof window.turnstile.render !== 'function') {
      return false;
    }
    if (el.getAttribute('data-yoo-turnstile-ready')) {
      return true;
    }
    var wrap = turnstileWrapFor(el);
    try {
      var widgetId = window.turnstile.render(el, turnstileRenderOptions(el));
      el.setAttribute('data-yoo-turnstile-ready', '1');
      if (widgetId !== undefined && widgetId !== null && widgetId !== '') {
        el.setAttribute('data-yoo-turnstile-widget-id', String(widgetId));
      }
      if (wrap) {
        wrap.setAttribute('data-yoo-turnstile-theme', getTurnstileTheme());
        wrap.setAttribute('data-yoo-turnstile-language', getTurnstileLanguage());
      }
      return true;
    } catch (e) {
      if (wrap) {
        wrap.setAttribute('data-yoo-turnstile-error-reason', 'error');
      }
      setTurnstileState(el, 'error');
      return false;
    }
  }

  function remountTurnstileWidget(el) {
    removeTurnstileWidget(el);
    return mountTurnstileWidget(el);
  }

  function rerenderTurnstileWidgets() {
    if (!cfg.turnstile || !cfg.turnstile.enabled || !window.turnstile) {
      return;
    }
    document.querySelectorAll('[data-yoo-turnstile-ready]').forEach(function (el) {
      var wrap = turnstileWrapFor(el);
      var keepChallenge = wrap && wrap.classList.contains('is-challenge-visible');
      var state = wrap ? wrap.getAttribute('data-yoo-turnstile-state') : 'pending';
      removeTurnstileWidget(el);
      if (wrap && keepChallenge) {
        wrap.classList.add('is-challenge-visible');
      }
      if (wrap && state) {
        wrap.setAttribute('data-yoo-turnstile-state', state);
        wrap.classList.remove('is-pending', 'is-verified', 'is-error');
        wrap.classList.add('is-' + state);
      }
    });
    initTurnstileWidgets();
  }

  function markTurnstileWidgetsBlocked() {
    document.querySelectorAll('[data-yoo-turnstile-context]').forEach(function (el) {
      if (el.getAttribute('data-yoo-turnstile-ready')) {
        return;
      }
      var wrap = turnstileWrapFor(el);
      if (wrap) {
        wrap.setAttribute('data-yoo-turnstile-error-reason', 'blocked');
      }
      setTurnstileState(el, 'error', 'securityBlocked');
    });
  }

  function turnstileRenderOptions(el) {
    var render = (cfg.turnstile && cfg.turnstile.render) || {};
    var language = getTurnstileLanguage();

    return {
      sitekey: cfg.turnstile.siteKey,
      theme: getTurnstileTheme(),
      language: language,
      size: render.size || 'normal',
      appearance: render.appearance || 'interaction-only',
      callback: function () {
        setTurnstileState(el, 'verified');
      },
      'before-interactive-callback': function () {
        setTurnstileChallengeVisible(el, true);
        var wrap = turnstileWrapFor(el);
        var theme = getTurnstileTheme();
        var lang = getTurnstileLanguage();
        if (
          !wrap ||
          wrap.getAttribute('data-yoo-turnstile-theme') !== theme ||
          wrap.getAttribute('data-yoo-turnstile-language') !== lang
        ) {
          remountTurnstileWidget(el);
        }
      },
      'after-interactive-callback': function () {
        setTurnstileChallengeVisible(el, true);
      },
      'error-callback': function () {
        var wrap = turnstileWrapFor(el);
        if (wrap) {
          wrap.setAttribute('data-yoo-turnstile-error-reason', 'error');
        }
        setTurnstileChallengeVisible(el, true);
        setTurnstileState(el, 'error');
      },
      'timeout-callback': function () {
        var wrap = turnstileWrapFor(el);
        if (wrap) {
          wrap.setAttribute('data-yoo-turnstile-error-reason', 'challenge');
        }
        setTurnstileChallengeVisible(el, true);
        setTurnstileState(el, 'pending');
        remountTurnstileWidget(el);
      },
      'unsupported-callback': function () {
        var wrap = turnstileWrapFor(el);
        if (wrap) {
          wrap.setAttribute('data-yoo-turnstile-error-reason', 'blocked');
        }
        setTurnstileState(el, 'error', 'securityBlocked');
      },
      'expired-callback': function () {
        setTurnstileChallengeVisible(el, true);
        setTurnstileState(el, 'pending');
        remountTurnstileWidget(el);
      },
    };
  }

  function initTurnstileSubmitGates() {
    document.querySelectorAll('[data-yoo-turnstile-wrap]').forEach(function (wrap) {
      var form = wrap.closest('form');
      var state = wrap.getAttribute('data-yoo-turnstile-state') || 'pending';
      setTurnstileSubmitGate(form, state === 'verified');
    });
  }

  function initTurnstileWidgets() {
    if (!cfg.turnstile || !cfg.turnstile.enabled || !cfg.turnstile.siteKey) {
      return;
    }

    function renderPending() {
      if (!window.turnstile || typeof window.turnstile.render !== 'function') {
        return false;
      }
      document.querySelectorAll('[data-yoo-turnstile-context]').forEach(function (el) {
        if (el.getAttribute('data-yoo-turnstile-ready')) {
          return;
        }
        var ctx = el.getAttribute('data-yoo-turnstile-context') || 'login';
        if (ctx === 'lostpassword' && !cfg.turnstile.protectLostPassword) {
          return;
        }
        var wrap = turnstileWrapFor(el);
        if (wrap && cfg.turnstile.displayMode) {
          wrap.classList.add('yoo-sl-turnstile-wrap--' + cfg.turnstile.displayMode);
          var appearance = (cfg.turnstile.render && cfg.turnstile.render.appearance) || '';
          if (appearance) {
            wrap.setAttribute('data-turnstile-appearance', appearance);
          }
        }
        setTurnstileState(el, 'pending');
        mountTurnstileWidget(el);
      });
      initTurnstileSubmitGates();
      return true;
    }

    if (!renderPending()) {
      var tries = 0;
      var timer = window.setInterval(function () {
        tries += 1;
        if (renderPending()) {
          window.clearInterval(timer);
          return;
        }
        if (tries > 50) {
          window.clearInterval(timer);
          markTurnstileWidgetsBlocked();
        }
      }, 120);
    }
  }

  function initTurnstileRetryButtons() {
    document.addEventListener('click', function (e) {
      var btn = e.target && e.target.closest ? e.target.closest('.yoo-sl-turnstile-retry') : null;
      if (!btn) {
        return;
      }
      e.preventDefault();
      var wrap = btn.closest('[data-yoo-turnstile-wrap]');
      var form = wrap ? wrap.closest('form') : null;
      if (!form) {
        return;
      }
      btn.setAttribute('hidden', 'hidden');
      resetTurnstileInForm(form);
    });
  }

  function initTurnstileAppearanceSync() {
    document.addEventListener('click', function (e) {
      var appearanceBtn =
        e.target && e.target.closest ? e.target.closest('[data-yoo-login-appearance]') : null;
      if (!appearanceBtn) {
        return;
      }
      window.setTimeout(function () {
        rerenderTurnstileWidgets();
      }, 80);
    });
  }

  function ensureSubmitSpinnerWrap(submitBtn) {
    if (!submitBtn || submitBtn.closest('.yoo-sl-submit__wrap')) {
      return;
    }
    var row = submitBtn.closest('.yoo-sl-submit');
    if (!row) {
      return;
    }
    var wrap = document.createElement('span');
    wrap.className = 'yoo-sl-submit__wrap';
    submitBtn.parentNode.insertBefore(wrap, submitBtn);
    wrap.appendChild(submitBtn);
    var spinner = document.createElement('span');
    spinner.className = 'yoo-sl-btn-spinner';
    spinner.setAttribute('aria-hidden', 'true');
    wrap.appendChild(spinner);
  }

  function setSubmitLoading(submitBtn, loading) {
    if (!submitBtn) {
      return;
    }
    ensureSubmitSpinnerWrap(submitBtn);
    var row = submitBtn.closest('.yoo-sl-submit');
    if (row) {
      row.classList.toggle('is-loading', !!loading);
    }
    if (loading) {
      submitBtn.setAttribute('aria-busy', 'true');
      submitBtn.disabled = true;
    } else {
      submitBtn.removeAttribute('aria-busy');
      submitBtn.disabled = false;
    }
  }

  function initSubmitButtonSpinners() {
    document
      .querySelectorAll('.yoo-sl-form input[type="submit"], .yoo-sl-form button[type="submit"]')
      .forEach(function (btn) {
        ensureSubmitSpinnerWrap(btn);
      });
  }

  var twoFaView = document.getElementById('yoo-sl-view-2fa');
  var twoFaSession = null;
  var twoFaResendCooldownTimer = null;
  var twoFaResendBaseLabel = '';
  var twoFaVerifying = false;
  var TWO_FA_PIN_DIGITS = 6;
  var TWO_FA_PIN_FIELD_NAMES = {
    authcode: true,
    'two-factor-email-code': true,
    googleotp: true,
    'wfls-token': true,
  };

  function twoFaI18n(key, fallback) {
    return (cfg && cfg.i18n && cfg.i18n[key]) || fallback;
  }

  function ajaxErrorMessage(actionKey, code, serverMessage) {
    if (serverMessage) {
      return serverMessage;
    }
    var i18n = cfg && cfg.i18n ? cfg.i18n : {};
    var map = {
      invalidkey: i18n.invalidResetLink,
      bad_key: i18n.invalidResetLink,
      expiredkey: i18n.expiredResetLink,
      expired_key: i18n.expiredResetLink,
      password_reset_mismatch: i18n.passwordMismatch,
      password_reset_empty: i18n.passwordResetEmpty,
      incorrect_password: i18n.incorrectPassword,
      failed: i18n.incorrectPassword,
    };
    if (code && map[code]) {
      return map[code];
    }
    return i18n.loginFailed || i18n.network || 'Error';
  }

  function twoFaLeadText(challenge) {
    if (challenge && challenge.lead) {
      return challenge.lead;
    }
    var provider = challenge && challenge.provider ? String(challenge.provider) : '';
    if (provider === 'totp' || provider === 'google_authenticator') {
      return twoFaI18n('twoFactorLeadTotp', 'Enter the code from your authenticator app.');
    }
    if (provider === 'email') {
      return twoFaI18n('twoFactorLeadEmail', 'A verification code has been sent to your email address.');
    }
    if (provider === 'backup_codes') {
      return twoFaI18n('twoFactorLeadBackup', 'Enter one of your recovery codes.');
    }
    return twoFaI18n('twoFactorLeadDefault', 'Enter your verification code to continue.');
  }

  function isTwoFaPinField(field) {
    if (!field || !field.name || field.type === 'checkbox') {
      return false;
    }
    if (field.pin === false) {
      return false;
    }
    if (field.pin_digits && field.pin_digits > 0) {
      return true;
    }
    if (TWO_FA_PIN_FIELD_NAMES[field.name]) {
      return true;
    }
    if (/backup/i.test(field.name)) {
      return false;
    }
    return field.inputmode === 'numeric' && field.autocomplete === 'one-time-code';
  }

  function getTwoFaForm() {
    return document.getElementById('twofactorform');
  }

  function twoFaDigitAria(index) {
    var tpl = twoFaI18n('twoFactorDigit', 'Digit %1$d of %2$d');
    return tpl.replace('%1$d', String(index + 1)).replace('%2$d', String(TWO_FA_PIN_DIGITS));
  }

  function getTwoFaSubmitBtn() {
    var twofaForm = getTwoFaForm();
    return twofaForm ? twofaForm.querySelector('input[type="submit"],button[type="submit"]') : null;
  }

  function updateOtpSubmitState(pinRoot, submitBtn) {
    var btn = submitBtn || getTwoFaSubmitBtn();
    if (!btn) {
      return;
    }
    var pin = pinRoot;
    if (!pin) {
      var form = getTwoFaForm();
      pin = form ? form.querySelector('.yoo-sl-otp-pin') : null;
    }
    if (!pin) {
      btn.disabled = !!twoFaVerifying;
      return;
    }
    var complete = readOtpPinValue(pin).length >= TWO_FA_PIN_DIGITS;
    btn.disabled = !complete || !!twoFaVerifying;
    pin.querySelectorAll('.yoo-sl-otp-pin__digit').forEach(function (input) {
      input.disabled = !!twoFaVerifying;
    });
  }

  function clearOtpPinInputs(pinRoot) {
    if (!pinRoot) {
      return;
    }
    var digits = pinRoot.querySelectorAll('.yoo-sl-otp-pin__digit');
    digits.forEach(function (input) {
      input.value = '';
    });
    if (digits[0]) {
      digits[0].focus();
    }
    updateOtpSubmitState(pinRoot);
  }

  function readOtpPinValue(pinRoot) {
    if (!pinRoot) {
      return '';
    }
    return Array.prototype.map
      .call(pinRoot.querySelectorAll('.yoo-sl-otp-pin__digit'), function (input) {
        return (input.value || '').replace(/\D/g, '');
      })
      .join('');
  }

  function submitTwoFactorValidate(submitBtn) {
    if (twoFaVerifying) {
      return;
    }
    var twofaForm = getTwoFaForm();
    if (!twofaForm || !twoFaSession) {
      showToast('error', twoFaI18n('twoFactorExpired', 'Session expired.'));
      return;
    }

    var extra = { provider: twoFaSession.provider || '' };
    var pinRoot = twofaForm.querySelector('.yoo-sl-otp-pin');
    if (pinRoot) {
      var fieldName = pinRoot.getAttribute('data-yoo-sl-otp-field') || 'authcode';
      var code = readOtpPinValue(pinRoot);
      if (code.length < TWO_FA_PIN_DIGITS) {
        showToast('error', twoFaI18n('twoFactorIncomplete', 'Enter the full 6-digit code.'));
        updateOtpSubmitState(pinRoot, submitBtn);
        return;
      }
      extra[fieldName] = code;
    }

    twofaForm.querySelectorAll('input[name]').forEach(function (input) {
      if (!input.name || input.classList.contains('yoo-sl-otp-pin__digit')) {
        return;
      }
      if (input.type === 'checkbox' && !input.checked) {
        return;
      }
      if (input.type === 'hidden' && input.classList.contains('yoo-sl-otp-pin__hidden')) {
        return;
      }
      extra[input.name] = input.value || '';
    });

    twoFaVerifying = true;
    if (submitBtn) {
      ensureSubmitSpinnerWrap(submitBtn);
    }
    updateOtpSubmitState(pinRoot, submitBtn);
    postTwoFactorRequest('validate_2fa', twoFaSession, extra, submitBtn).finally(function () {
      twoFaVerifying = false;
      updateOtpSubmitState(pinRoot, submitBtn);
    });
  }

  function bindOtpPinInputs(pinRoot, submitBtn) {
    if (!pinRoot || pinRoot.getAttribute('data-yoo-sl-otp-bound') === '1') {
      return;
    }
    pinRoot.setAttribute('data-yoo-sl-otp-bound', '1');

    var digits = pinRoot.querySelectorAll('.yoo-sl-otp-pin__digit');
    if (!digits.length) {
      return;
    }

    function focusDigit(index) {
      if (index >= 0 && index < digits.length && digits[index]) {
        digits[index].focus();
        digits[index].select();
      }
    }

    function fillFromString(startIndex, raw) {
      var chars = String(raw || '').replace(/\D/g, '').slice(0, TWO_FA_PIN_DIGITS);
      if (!chars) {
        return;
      }
      var idx = Math.max(0, startIndex);
      chars.split('').forEach(function (ch) {
        if (idx >= digits.length) {
          return;
        }
        digits[idx].value = ch;
        idx += 1;
      });
      updateOtpSubmitState(pinRoot, submitBtn);
      if (idx >= digits.length) {
        submitTwoFactorValidate(submitBtn);
      } else {
        focusDigit(idx);
      }
    }

    digits.forEach(function (input, index) {
      input.addEventListener('input', function () {
        var val = (input.value || '').replace(/\D/g, '');
        if (val.length > 1) {
          input.value = val.charAt(0);
          fillFromString(index + 1, val.slice(1));
          return;
        }
        input.value = val;
        updateOtpSubmitState(pinRoot, submitBtn);
        if (val && index < digits.length - 1) {
          focusDigit(index + 1);
          return;
        }
        if (val && index === digits.length - 1) {
          submitTwoFactorValidate(submitBtn);
        }
      });

      input.addEventListener('keydown', function (e) {
        if (e.key === 'Backspace' && !input.value && index > 0) {
          e.preventDefault();
          focusDigit(index - 1);
          return;
        }
        if (e.key === 'ArrowLeft' && index > 0) {
          e.preventDefault();
          focusDigit(index - 1);
          return;
        }
        if (e.key === 'ArrowRight' && index < digits.length - 1) {
          e.preventDefault();
          focusDigit(index + 1);
        }
      });

      input.addEventListener('paste', function (e) {
        e.preventDefault();
        var pasted = '';
        if (e.clipboardData) {
          pasted = e.clipboardData.getData('text') || '';
        }
        fillFromString(index, pasted);
      });
    });

    updateOtpSubmitState(pinRoot, submitBtn);
  }

  function renderOtpPinField(host, field, submitBtn) {
    var wrap = document.createElement('div');
    wrap.className = 'yoo-sl-field yoo-sl-field--otp-pin';

    var label = document.createElement('label');
    label.className = 'screen-reader-text';
    label.setAttribute('for', 'yoo-sl-2fa-' + field.name + '-0');
    label.textContent = field.label || twoFaI18n('twoFactorCodeLabel', 'Authentication code');

    var pinRoot = document.createElement('div');
    pinRoot.className = 'yoo-sl-otp-pin';
    pinRoot.setAttribute('dir', 'ltr');
    pinRoot.setAttribute('data-yoo-sl-otp-field', field.name);
    pinRoot.setAttribute('role', 'group');
    pinRoot.setAttribute(
      'aria-label',
      field.label || twoFaI18n('twoFactorCodeLabel', 'Authentication code')
    );

    for (var i = 0; i < TWO_FA_PIN_DIGITS; i += 1) {
      var digit = document.createElement('input');
      digit.type = 'text';
      digit.inputMode = 'numeric';
      digit.pattern = '[0-9]*';
      digit.maxLength = 1;
      digit.dir = 'ltr';
      digit.autocomplete = i === 0 ? field.autocomplete || 'one-time-code' : 'off';
      digit.className = 'yoo-sl-otp-pin__digit';
      digit.id = 'yoo-sl-2fa-' + field.name + '-' + i;
      digit.setAttribute('aria-label', twoFaDigitAria(i));
      pinRoot.appendChild(digit);
    }

    wrap.appendChild(label);
    wrap.appendChild(pinRoot);
    host.appendChild(wrap);

    if (submitBtn) {
      ensureSubmitSpinnerWrap(submitBtn);
    }
    bindOtpPinInputs(pinRoot, submitBtn);
    updateOtpSubmitState(pinRoot, submitBtn);
    window.setTimeout(function () {
      focusDigitOnPin(pinRoot);
    }, 40);
  }

  function focusDigitOnPin(pinRoot) {
    if (!pinRoot) {
      return;
    }
    var first = pinRoot.querySelector('.yoo-sl-otp-pin__digit');
    if (first) {
      first.focus();
    }
  }

  function hideAllLoginViews() {
    var views = [loginView, resetView, rpView, twoFaView];
    views.forEach(function (view) {
      if (!view) {
        return;
      }
      view.hidden = true;
      view.classList.remove('is-active');
    });
  }

  function getResendActionButton() {
    return document.querySelector('[data-yoo-sl-2fa-action="resend_email_code"]');
  }

  function clearResendCooldown() {
    if (twoFaResendCooldownTimer) {
      window.clearTimeout(twoFaResendCooldownTimer);
      twoFaResendCooldownTimer = null;
    }
  }

  function formatResendWaitLabel(seconds) {
    var template = twoFaI18n('twoFactorResendWait', 'Resend code (%ds)');
    return template.replace('%ds', String(seconds) + 's').replace('%d', String(seconds));
  }

  function applyResendCooldown(seconds) {
    var wait = parseInt(seconds, 10);
    if (!(wait > 0)) {
      return;
    }

    var btn = getResendActionButton();
    if (!btn) {
      return;
    }

    if (!twoFaResendBaseLabel) {
      twoFaResendBaseLabel = btn.textContent || twoFaI18n('twoFactorResend', 'Resend code');
    }

    btn.disabled = true;
    btn.setAttribute('aria-disabled', 'true');
    btn.classList.add('is-cooldown');

    var remaining = wait;
    function tick() {
      var activeBtn = getResendActionButton();
      if (!activeBtn) {
        clearResendCooldown();
        return;
      }
      if (remaining <= 0) {
        activeBtn.disabled = false;
        activeBtn.removeAttribute('aria-disabled');
        activeBtn.classList.remove('is-cooldown');
        activeBtn.textContent = twoFaResendBaseLabel;
        clearResendCooldown();
        return;
      }
      activeBtn.textContent = formatResendWaitLabel(remaining);
      remaining -= 1;
      twoFaResendCooldownTimer = window.setTimeout(tick, 1000);
    }

    clearResendCooldown();
    tick();
  }

  function syncResendCooldownFromChallenge(challenge) {
    if (!challenge) {
      return;
    }
    var retryAfter = parseInt(challenge.resend_retry_after, 10);
    if (retryAfter > 0) {
      applyResendCooldown(retryAfter);
      return;
    }
    var cooldown = parseInt(challenge.resend_cooldown, 10);
    if (cooldown > 0) {
      applyResendCooldown(cooldown);
    }
  }

  function clearTwoFactorLoadingState() {
    var loadingEl = document.getElementById('yoo-sl-2fa-loading');
    if (loadingEl) {
      loadingEl.remove();
    }
    var twoFaView = document.getElementById('yoo-sl-view-2fa');
    if (twoFaView) {
      twoFaView.classList.remove('is-loading');
    }
    var twofaForm = getTwoFaForm();
    if (twofaForm) {
      twofaForm.hidden = false;
    }
    var actionsHost = document.getElementById('yoo-sl-2fa-actions');
    if (actionsHost) {
      actionsHost.hidden = false;
    }
    var alternatesHost = document.getElementById('yoo-sl-2fa-alternates');
    if (alternatesHost) {
      alternatesHost.hidden = false;
    }
  }

  function renderTwoFactorFields(challenge) {
    var host = document.getElementById('yoo-sl-2fa-fields');
    var fragment = document.getElementById('yoo-sl-2fa-fragment');
    var actionsHost = document.getElementById('yoo-sl-2fa-actions');
    var alternatesHost = document.getElementById('yoo-sl-2fa-alternates');
    var lead = document.getElementById('yoo-sl-2fa-lead');
    var providerEl = document.getElementById('yoo-sl-2fa-provider');
    var twofaForm = getTwoFaForm();
    var submitBtn = twofaForm ? twofaForm.querySelector('input[type="submit"],button[type="submit"]') : null;
    var usesOtpPin = false;
    if (!host || !challenge) {
      return;
    }

    if (lead) {
      lead.textContent = twoFaLeadText(challenge);
    }
    if (providerEl) {
      if (challenge.provider_label) {
        providerEl.textContent = challenge.provider_label;
        providerEl.hidden = false;
      } else {
        providerEl.textContent = '';
        providerEl.hidden = true;
      }
    }
    if (fragment) {
      if (challenge.fragment) {
        fragment.innerHTML = challenge.fragment;
        fragment.hidden = false;
      } else {
        fragment.innerHTML = '';
        fragment.hidden = true;
      }
    }

    host.innerHTML = '';
    (challenge.fields || []).forEach(function (field) {
      if (!field || !field.name) {
        return;
      }
      if (isTwoFaPinField(field)) {
        usesOtpPin = true;
        renderOtpPinField(host, field, submitBtn);
        return;
      }
      var wrap = document.createElement('p');
      wrap.className = 'yoo-sl-field yoo-sl-field--with-icon';
      var icon = document.createElement('span');
      icon.className = 'yoo-sl-field__icon dashicons dashicons-shield-alt';
      icon.setAttribute('aria-hidden', 'true');
      var label = document.createElement('label');
      label.className = 'screen-reader-text';
      label.setAttribute('for', 'yoo-sl-2fa-' + field.name);
      label.textContent = field.label || field.name;
      var input;
      if (field.type === 'checkbox') {
        wrap.className = 'yoo-sl-field yoo-sl-field--checkbox';
        wrap.innerHTML = '';
        input = document.createElement('input');
        input.type = 'checkbox';
        input.name = field.name;
        input.id = 'yoo-sl-2fa-' + field.name;
        input.value = '1';
        var checkLabel = document.createElement('label');
        checkLabel.setAttribute('for', input.id);
        checkLabel.textContent = field.label || field.name;
        wrap.appendChild(input);
        wrap.appendChild(checkLabel);
      } else {
        input = document.createElement('input');
        input.type = field.type || 'text';
        input.name = field.name;
        input.id = 'yoo-sl-2fa-' + field.name;
        input.className = 'yoo-sl-input yoo-sl-input--with-icon';
        input.autocomplete = field.autocomplete || 'one-time-code';
        if (field.inputmode) {
          input.setAttribute('inputmode', field.inputmode);
        }
        if (field.placeholder) {
          input.placeholder = field.placeholder;
        }
        if (field.required) {
          input.required = true;
        }
        if (/backup/i.test(field.name)) {
          input.setAttribute('autocapitalize', 'off');
          input.setAttribute('spellcheck', 'false');
          input.setAttribute('maxlength', '16');
          input.addEventListener('input', function () {
            input.value = String(input.value || '')
              .toLowerCase()
              .replace(/[^a-z0-9]/g, '');
          });
        }
        wrap.appendChild(icon);
        wrap.appendChild(label);
        wrap.appendChild(input);
      }
      host.appendChild(wrap);
    });

    clearTwoFactorLoadingState();

    if (actionsHost) {
      actionsHost.innerHTML = '';
      twoFaResendBaseLabel = '';
      clearResendCooldown();
      (challenge.actions || []).forEach(function (action) {
        if (!action || !action.name) {
          return;
        }
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'yoo-sl-btn yoo-sl-btn--secondary yp-yoo-btn yp-yoo-btn--soft';
        btn.setAttribute('data-yoo-sl-2fa-action', action.name);
        btn.textContent = action.label || action.name;
        if (action.name === 'resend_email_code') {
          twoFaResendBaseLabel = btn.textContent;
        }
        actionsHost.appendChild(btn);
      });
      syncResendCooldownFromChallenge(challenge);
    }

    if (alternatesHost) {
      alternatesHost.innerHTML = '';
      (challenge.alternates || []).forEach(function (alt) {
        if (!alt || !alt.provider) {
          return;
        }
        var link = document.createElement('button');
        link.type = 'button';
        link.className = 'yoo-sl-btn yoo-sl-btn--alternate yp-yoo-btn yp-yoo-btn--soft';
        link.setAttribute('data-yoo-sl-2fa-provider', alt.provider);
        link.textContent = alt.label || alt.provider;
        alternatesHost.appendChild(link);
      });
    }

    if (twofaForm) {
      twofaForm.classList.toggle('yoo-sl-form--otp-pin', usesOtpPin);
      if (usesOtpPin && submitBtn) {
        ensureSubmitSpinnerWrap(submitBtn);
        updateOtpSubmitState(twofaForm.querySelector('.yoo-sl-otp-pin'), submitBtn);
      } else if (submitBtn) {
        submitBtn.disabled = false;
      }
    }

    if (!usesOtpPin) {
      var firstInput = host.querySelector('input');
      if (firstInput) {
        window.setTimeout(function () {
          firstInput.focus();
        }, 40);
      }
    }
  }

  function applyAjaxNonce(nextNonce) {
    if (!cfg || typeof nextNonce !== 'string' || nextNonce === '') {
      return;
    }
    cfg.nonce = nextNonce;
  }

  function applyTwoFactorSession(session) {
    if (!session || !session.challenge) {
      var loadingEl = document.getElementById('yoo-sl-2fa-loading');
      if (loadingEl) {
        var loadingText = loadingEl.querySelector('.yoo-sl-2fa-loading__text');
        if (loadingText) {
          loadingText.textContent = twoFaI18n('sessionExpired', 'Your verification session expired. Please sign in again.');
        }
        loadingEl.setAttribute('aria-busy', 'false');
      }
      return;
    }
    twoFaSession = session;
    renderTwoFactorFields(session.challenge);
  }

  function postTwoFactorRequest(actionKey, session, extraFields, submitBtn) {
    if (!cfg || !cfg.ajaxUrl || !cfg.actions || !cfg.nonce || !cfg.actions[actionKey]) {
      return Promise.resolve();
    }

    var fd = new FormData();
    fd.append('action', cfg.actions[actionKey]);
    fd.append('nonce', cfg.nonce);
    fd.append('session', JSON.stringify(session || {}));
    Object.keys(extraFields || {}).forEach(function (key) {
      fd.append(key, extraFields[key]);
    });

    setSubmitLoading(submitBtn, true);
    var keepSubmitLoading = false;

    return window
      .fetch(cfg.ajaxUrl, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin',
      })
      .then(function (response) {
        return parseAjaxResponse(response).then(function (parsedWrap) {
          return { response: response, parsedWrap: parsedWrap };
        });
      })
      .then(function (result) {
        var pw = result.parsedWrap;
        if (pw.legacyFail) {
          showToast('error', twoFaI18n('sessionExpired', 'Session expired.'));
          return;
        }
        var data = pw.parsed;
        if (!data || typeof data.success === 'undefined') {
          showToast('error', twoFaI18n('badResponse', 'Unexpected response.'));
          return;
        }
        if (!data.success) {
          var err = data.data || {};
          if (err.restart) {
            showToast('error', err.message || twoFaI18n('twoFactorExpired', 'Session expired.'));
            if (typeof window.yooSlShowLogin === 'function') {
              window.yooSlShowLogin();
            }
            return;
          }
          if (err.session && err.session.user_id && err.session.challenge) {
            applyTwoFactorSession(err.session);
          }
          var errPin = getTwoFaForm() && getTwoFaForm().querySelector('.yoo-sl-otp-pin');
          twoFaVerifying = false;
          if (errPin) {
            clearOtpPinInputs(errPin);
          }
          var twofaFormErr = getTwoFaForm();
          if (twofaFormErr) {
            twofaFormErr.querySelectorAll('input:not(.yoo-sl-otp-pin__digit)').forEach(function (inp) {
              inp.disabled = false;
              if (/backup/i.test(inp.name || '')) {
                inp.focus();
              }
            });
            updateOtpSubmitState(errPin, submitBtn);
          }
          if (err.retry_after) {
            applyResendCooldown(err.retry_after);
          }
          showToast('error', err.message || twoFaI18n('network', 'Error'));
          return;
        }

        var payload = data.data || {};
        if (payload.session && payload.session.challenge) {
          applyTwoFactorSession(payload.session);
        } else if (payload.user_id && payload.challenge) {
          applyTwoFactorSession(payload);
        } else if (payload.challenge && twoFaSession) {
          twoFaSession.challenge = payload.challenge;
          if (payload.provider) {
            twoFaSession.provider = payload.provider;
          }
          renderTwoFactorFields(payload.challenge);
        }
        if (payload.challenge) {
          syncResendCooldownFromChallenge(payload.challenge);
        }
        if (payload.message) {
          showToast(payload.resent ? 'success' : 'info', payload.message);
        }
        if (payload.redirect) {
          keepSubmitLoading = true;
          window.location.href = payload.redirect;
        }
      })
      .catch(function () {
        showToast('error', twoFaI18n('network', 'Network error'));
      })
      .finally(function () {
        if (!keepSubmitLoading) {
          setSubmitLoading(submitBtn, false);
        }
      });
  }

  function bindTwoFactorUi() {
    var twofaForm = getTwoFaForm();
    if (twofaForm) {
      twofaForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var submitBtn = twofaForm.querySelector('input[type="submit"],button[type="submit"]');
        submitTwoFactorValidate(submitBtn);
      });
    }

    document.addEventListener('click', function (e) {
      var target = e.target;
      if (!(target instanceof Element)) {
        return;
      }
      var actionBtn = target.closest('[data-yoo-sl-2fa-action]');
      if (actionBtn && twoFaSession) {
        if (
          actionBtn.disabled ||
          actionBtn.classList.contains('is-cooldown') ||
          actionBtn.getAttribute('aria-disabled') === 'true'
        ) {
          e.preventDefault();
          return;
        }
        e.preventDefault();
        var actionName = actionBtn.getAttribute('data-yoo-sl-2fa-action') || '';
        var extra = { resend: '1', provider: twoFaSession.provider || '' };
        if (actionName) {
          extra[actionName] = '1';
        }
        postTwoFactorRequest('two_factor_challenge', twoFaSession, extra, actionBtn);
        return;
      }
      var providerBtn = target.closest('[data-yoo-sl-2fa-provider]');
      if (providerBtn && twoFaSession) {
        e.preventDefault();
        var provider = providerBtn.getAttribute('data-yoo-sl-2fa-provider') || '';
        postTwoFactorRequest(
          'two_factor_challenge',
          twoFaSession,
          { provider: provider },
          providerBtn
        );
      }
    });
  }

  function bindAjaxForms() {
    if (!cfg || !cfg.ajaxUrl || !cfg.actions || !cfg.nonce) {
      return;
    }

    function handleForm(form, actionKey) {
      if (!form || !cfg.actions[actionKey]) {
        return;
      }
      form.addEventListener('submit', function (e) {
        e.preventDefault();

        if (actionKey === 'login') {
          var logIn = form.querySelector('#user_login');
          var pwdIn = form.querySelector('#user_pass');
          var logV = logIn && logIn.value ? logIn.value.trim() : '';
          var pwdV = pwdIn && pwdIn.value ? pwdIn.value : '';
          if (!logV) {
            showToast('error', (cfg.i18n && cfg.i18n.emptyUsername) || '');
            return;
          }
          if (!pwdV) {
            showToast('error', (cfg.i18n && cfg.i18n.emptyPassword) || '');
            return;
          }
        }

        if (actionKey === 'lostpassword') {
          var ru = form.querySelector('input[name="user_login"]');
          var ruV = ru && ru.value ? ru.value.trim() : '';
          if (!ruV) {
            showToast('error', (cfg.i18n && cfg.i18n.emptyResetUser) || '');
            return;
          }
        }

        if (turnstileRequiredFor(actionKey)) {
          var token = getTurnstileToken(form);
          if (!token) {
            showToast(
              'error',
              (cfg.i18n && cfg.i18n.captchaRequired) || 'Please complete the security check.'
            );
            return;
          }
        }

        var submitBtn = form.querySelector('input[type="submit"],button[type="submit"]');
        var fd = new FormData(form);
        fd.append('action', cfg.actions[actionKey]);
        fd.append('nonce', cfg.nonce);

        if (turnstileRequiredFor(actionKey)) {
          var turnstileToken = getTurnstileToken(form);
          if (turnstileToken) {
            fd.set('cf-turnstile-response', turnstileToken);
          }
        }

        setSubmitLoading(submitBtn, true);
        var keepSubmitLoading = false;

        window
          .fetch(cfg.ajaxUrl, {
            method: 'POST',
            body: fd,
            credentials: 'same-origin',
          })
          .then(function (response) {
            return parseAjaxResponse(response).then(function (parsedWrap) {
              return { response: response, parsedWrap: parsedWrap };
            });
          })
          .then(function (result) {
            var pw = result.parsedWrap;
            if (pw.legacyFail) {
              showToast('error', (cfg.i18n && cfg.i18n.sessionExpired) || '');
              return;
            }
            var data = pw.parsed;
            if (!data || typeof data.success === 'undefined') {
              showToast('error', (cfg.i18n && cfg.i18n.badResponse) || 'Error');
              return;
            }
            if (!data.success) {
              var errPayload = data.data || {};
              var msg = ajaxErrorMessage(actionKey, errPayload.code, errPayload.message);
              var errKind = errPayload.code === 'rate_limited' ? 'info' : 'error';
              showToast(errKind, msg);
              if (turnstileRequiredFor(actionKey)) {
                resetTurnstileInForm(form);
              }
              return;
            }
            var payload = data.data || {};
            if (actionKey === 'login' && payload.two_factor_required && payload.session) {
              applyAjaxNonce(payload.nonce);
              applyTwoFactorSession(payload.session);
              if (typeof window.yooSlShowTwoFactor === 'function') {
                window.yooSlShowTwoFactor();
              }
              if (payload.message) {
                showToast('info', payload.message);
              }
              return;
            }
            if (actionKey === 'login' && payload.redirect) {
              keepSubmitLoading = true;
              window.location.href = payload.redirect;
              return;
            }
            if (actionKey === 'lostpassword' && payload.message) {
              showToast('success', payload.message);
              var u = form.querySelector('input[name="user_login"]');
              if (u) {
                u.value = '';
              }
              return;
            }
            if (actionKey === 'resetpass' && payload.redirect) {
              if (payload.message) {
                showToast('success', payload.message);
              }
              keepSubmitLoading = true;
              window.setTimeout(function () {
                window.location.href = payload.redirect;
              }, payload.message ? 900 : 0);
            }
          })
          .catch(function () {
            showToast('error', (cfg.i18n && cfg.i18n.network) || 'Network error');
          })
          .finally(function () {
            if (!keepSubmitLoading) {
              setSubmitLoading(submitBtn, false);
            }
            var wrap = form.querySelector('[data-yoo-turnstile-wrap]');
            var verified =
              !wrap || (wrap.getAttribute('data-yoo-turnstile-state') || '') === 'verified';
            setTurnstileSubmitGate(form, verified);
          });
      });
    }

    handleForm(document.getElementById('loginform'), 'login');
    handleForm(document.getElementById('lostpasswordform'), 'lostpassword');
    handleForm(document.getElementById('resetpassform'), 'resetpass');
  }

  function bindNativeTurnstileFormGates() {
    if (!cfg || !cfg.turnstile || !cfg.turnstile.enabled || !cfg.turnstile.siteKey) {
      return;
    }

    ['loginform', 'lostpasswordform', 'resetpassform'].forEach(function (formId) {
      var form = document.getElementById(formId);
      if (!form) {
        return;
      }
      var actionKey = turnstileActionForForm(form);
      if (!turnstileRequiredFor(actionKey)) {
        return;
      }
      if (!form.querySelector('[data-yoo-turnstile-wrap]')) {
        return;
      }

      form.addEventListener('submit', function (e) {
        var token = getTurnstileToken(form);
        if (token) {
          return;
        }
        e.preventDefault();
        var widget = form.querySelector('[data-yoo-turnstile-context]');
        if (widget) {
          setTurnstileChallengeVisible(widget, true);
        }
        setTurnstileSubmitGate(form, false);
      });
    });
  }

  function initLoginTurnstile() {
    if (!cfg || !cfg.turnstile || !cfg.turnstile.enabled || !cfg.turnstile.siteKey) {
      return;
    }
    initTurnstileSubmitGates();
    initTurnstileWidgets();
    initTurnstileRetryButtons();
    initTurnstileAppearanceSync();
    bindNativeTurnstileFormGates();
  }

  var loginView = document.getElementById('yoo-sl-view-login');
  var resetView = document.getElementById('yoo-sl-view-reset');
  var rpView = document.getElementById('yoo-sl-view-rp');
  var btnShowReset = document.getElementById('yoo-sl-toggle-reset');
  var btnShowLogin = document.getElementById('yoo-sl-toggle-login');
  var btnShowLoginFrom2fa = document.getElementById('yoo-sl-toggle-login-from-2fa');

  if (loginView && resetView && btnShowReset && btnShowLogin) {
    function showLogin() {
      twoFaSession = null;
      hideAllLoginViews();
      loginView.hidden = false;
      loginView.classList.add('is-active');
      var log = document.getElementById('user_login');
      if (log) {
        log.focus();
      }
      initTurnstileWidgets();
    }

    function showTwoFactor() {
      if (!twoFaView) {
        return;
      }
      hideAllLoginViews();
      twoFaView.hidden = false;
      twoFaView.classList.add('is-active');
      var first = document.querySelector('#yoo-sl-2fa-fields input');
      if (first) {
        first.focus();
      }
    }

    function showReset() {
      twoFaSession = null;
      hideAllLoginViews();
      resetView.hidden = false;
      resetView.classList.add('is-active');
      var email = document.getElementById('yoo_sl_user_login_reset');
      if (email) {
        email.focus();
      }
      initTurnstileWidgets();
    }

    function showRp() {
      if (!rpView) {
        return;
      }
      twoFaSession = null;
      hideAllLoginViews();
      rpView.hidden = false;
      rpView.classList.add('is-active');
      initTurnstileWidgets();
      var p1 = document.getElementById('pass1');
      if (p1) {
        p1.focus();
      }
    }

    window.yooSlShowLogin = showLogin;
    window.yooSlShowTwoFactor = showTwoFactor;

    btnShowReset.addEventListener('click', function (e) {
      var inlineForgot =
        document.body && document.body.getAttribute('data-yoo-sl-forgot-inline') === '1';
      if (!inlineForgot) {
        return;
      }
      e.preventDefault();
      showReset();
    });

    btnShowLogin.addEventListener('click', function (e) {
      e.preventDefault();
      showLogin();
    });

    if (btnShowLoginFrom2fa) {
      btnShowLoginFrom2fa.addEventListener('click', function (e) {
        e.preventDefault();
        showLogin();
      });
    }

    var initial = (document.body && document.body.getAttribute('data-yoo-sl-initial')) || 'login';
    if (initial === 'reset') {
      showReset();
    } else if (initial === 'rp' && rpView) {
      showRp();
    } else if (initial === '2fa') {
      if (window.yooadminSlBootstrapTwoFactor) {
        applyTwoFactorSession(window.yooadminSlBootstrapTwoFactor);
      }
      showTwoFactor();
      if (btnShowLoginFrom2fa && document.body && document.body.getAttribute('data-yoo-sl-revalidate') === '1') {
        btnShowLoginFrom2fa.hidden = true;
      }
    }

    if (window.location.hash === '#lostpassword' || window.location.hash === '#reset') {
      showReset();
    }
    if (window.location.hash === '#rp') {
      showRp();
    }
  }

  function applyRecoveredLoginPrefill() {
    try {
      var params = new URLSearchParams(window.location.search);
      var login = params.get('recovered_login');
      if (!login) {
        return;
      }
      var log = document.getElementById('user_login');
      if (log && !log.value) {
        log.value = login;
      }
    } catch (e) {
      /* ignore */
    }
  }

  initSubmitButtonSpinners();
  bindAjaxForms();
  bindTwoFactorUi();
  initLoginTurnstile();
  applyRecoveredLoginPrefill();

  function pwIconShow() {
    return (
      '<svg class="yoo-sl-pw-toggle__svg" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<path d="M12 5C7 5 2.73 8.11 1 12.5 2.73 16.89 7 20 12 20s9.27-3.11 11-7.5C21.27 8.11 17 5 12 5zm0 12.5a5 5 0 110-10 5 5 0 010 10zm0-8a3 3 0 100 6 3 3 0 000-6z" fill="currentColor"/>' +
      '</svg>'
    );
  }

  function pwIconHide() {
    return (
      '<svg class="yoo-sl-pw-toggle__svg" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46A11.804 11.804 0 001 12.5c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.3-.08.61-.08.95 0 2.76 2.24 5 5 5 .34 0 .65-.03.96-.08l1.55 1.55A6.99 6.99 0 0112 19c-3.86 0-7-3.14-7-7 0-1.1.25-2.14.7-3.07l2.83 2.87z" fill="currentColor"/>' +
      '</svg>'
    );
  }

  function pwLabelShow() {
    return (cfg && cfg.i18n && cfg.i18n.showPassword) || 'Show password';
  }

  function pwLabelHide() {
    return (cfg && cfg.i18n && cfg.i18n.hidePassword) || 'Hide password';
  }

  function syncStandalonePwToggle(btn, input) {
    var hidden = input.getAttribute('type') === 'password';
    btn.setAttribute('aria-pressed', hidden ? 'false' : 'true');
    btn.setAttribute('aria-label', hidden ? pwLabelShow() : pwLabelHide());
    btn.innerHTML = hidden ? pwIconShow() : pwIconHide();
  }

  function initStandalonePwToggles() {
    document.querySelectorAll('.yoo-sl-pw-toggle').forEach(function (btn) {
      var field = btn.closest('.yoo-sl-field--password');
      if (!field) {
        return;
      }
      var input = field.querySelector('input.yoo-sl-input');
      if (!input) {
        return;
      }
      syncStandalonePwToggle(btn, input);
      btn.addEventListener('click', function () {
        var isPw = input.getAttribute('type') === 'password';
        input.setAttribute('type', isPw ? 'text' : 'password');
        syncStandalonePwToggle(btn, input);
      });
    });
  }

  initStandalonePwToggles();

  var messagesEl = document.getElementById('yoo-sl-messages');
  if (messagesEl) {
    messagesEl.querySelectorAll('.yoo-sl-toast__close').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var toast = btn.closest('.yoo-sl-toast');
        removeToast(toast);
      });
    });

    messagesEl.querySelectorAll('.yoo-sl-toast').forEach(function (toast) {
      var kind = toast.getAttribute('data-yoo-sl-toast') || '';
      if (kind === 'success' || kind === 'info') {
        window.setTimeout(function () {
          removeToast(toast);
        }, 6500);
      }
    });
  }
})();
