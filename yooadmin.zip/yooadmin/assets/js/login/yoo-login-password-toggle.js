(function () {
  'use strict';

  function iconShow() {
    return (
      '<svg class="yoo-login-pw-toggle__svg" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<path d="M12 5C7 5 2.73 8.11 1 12.5 2.73 16.89 7 20 12 20s9.27-3.11 11-7.5C21.27 8.11 17 5 12 5zm0 12.5a5 5 0 110-10 5 5 0 010 10zm0-8a3 3 0 100 6 3 3 0 000-6z" fill="currentColor"/>' +
      '</svg>'
    );
  }

  function iconHide() {
    return (
      '<svg class="yoo-login-pw-toggle__svg" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46A11.804 11.804 0 001 12.5c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.3-.08.61-.08.95 0 2.76 2.24 5 5 5 .34 0 .65-.03.96-.08l1.55 1.55A6.99 6.99 0 0112 19c-3.86 0-7-3.14-7-7 0-1.1.25-2.14.7-3.07l2.83 2.87z" fill="currentColor"/>' +
      '</svg>'
    );
  }

  function labelShow() {
    return (window.yooadminLoginPw && window.yooadminLoginPw.show) || 'Show password';
  }
  function labelHide() {
    return (window.yooadminLoginPw && window.yooadminLoginPw.hide) || 'Hide password';
  }

  function sync(btn, input) {
    var hidden = input.getAttribute('type') === 'password';
    btn.setAttribute('aria-pressed', hidden ? 'false' : 'true');
    btn.setAttribute('aria-label', hidden ? labelShow() : labelHide());
    btn.innerHTML = hidden ? iconShow() : iconHide();
  }

  function bind(input) {
    if (!input || input.dataset.yooPwToggleBound === '1') {
      return;
    }

    var parent = input.parentNode;
    if (!parent || parent.nodeType !== 1) {
      return;
    }

    var next = input.nextElementSibling;
    var wpBtn =
      next && next.classList && next.classList.contains('wp-hide-pw')
        ? next
        : parent.querySelector
          ? parent.querySelector('.wp-hide-pw')
          : null;

    var shell = document.createElement('div');
    shell.className = 'yoo-login-pw-shell';
    parent.insertBefore(shell, input);
    shell.appendChild(input);

    if (wpBtn) {
      wpBtn.setAttribute('hidden', 'hidden');
      wpBtn.setAttribute('aria-hidden', 'true');
      wpBtn.style.display = 'none';
    }

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'yoo-login-pw-toggle';
    btn.setAttribute('data-yoo-pw-toggle', '1');

    sync(btn, input);

    btn.addEventListener('click', function () {
      var isPw = input.getAttribute('type') === 'password';
      input.setAttribute('type', isPw ? 'text' : 'password');
      sync(btn, input);
    });

    shell.appendChild(btn);
    input.dataset.yooPwToggleBound = '1';
  }

  function init() {
    var root = document.querySelector('#login');
    if (!root) {
      return;
    }
    root.querySelectorAll('input[type="password"]').forEach(bind);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
