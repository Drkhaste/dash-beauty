(function () {
  'use strict';

  var cfg =
    typeof window.yooadminSecurityAction === 'object' && window.yooadminSecurityAction
      ? window.yooadminSecurityAction
      : {};

  function ensureMessagesContainer() {
    var el = document.getElementById('yoo-security-action-messages');
    if (!el) {
      el = document.createElement('div');
      el.id = 'yoo-security-action-messages';
      el.className = 'yoo-sl-messages yoo-sl-messages--fixed';
      el.setAttribute('role', 'region');
      el.setAttribute('aria-live', 'polite');
      el.setAttribute('aria-relevant', 'additions');
      document.body.insertBefore(el, document.body.firstChild);
    }
    return el;
  }

  function iconClass(kind) {
    if (kind === 'error') {
      return 'dashicons-warning';
    }
    if (kind === 'success') {
      return 'dashicons-yes-alt';
    }
    return 'dashicons-info';
  }

  function removeToast(toast) {
    if (!toast || !toast.parentNode) {
      return;
    }
    toast.classList.add('yoo-sl-toast--out');
    window.setTimeout(function () {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
      var wrap = document.getElementById('yoo-security-action-messages');
      if (wrap && wrap.children.length === 0) {
        wrap.parentNode.removeChild(wrap);
      }
    }, 280);
  }

  function showToast(kind, text) {
    if (!text) {
      return;
    }

    var wrap = ensureMessagesContainer();
    var toast = document.createElement('div');
    toast.className = 'yoo-sl-toast yoo-sl-toast--' + kind;
    toast.setAttribute('data-yoo-sl-toast', kind);
    toast.setAttribute('role', 'alert');

    var ic = document.createElement('span');
    ic.className = 'yoo-sl-toast__icon dashicons ' + iconClass(kind);
    ic.setAttribute('aria-hidden', 'true');

    var body = document.createElement('div');
    body.className = 'yoo-sl-toast__body';
    body.appendChild(document.createTextNode(text));

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'yoo-sl-toast__close';
    btn.setAttribute('aria-label', (cfg.i18n && cfg.i18n.dismiss) || 'Dismiss');
    btn.innerHTML = '&times;';
    btn.addEventListener('click', function () {
      removeToast(toast);
    });

    toast.appendChild(ic);
    toast.appendChild(body);
    toast.appendChild(btn);
    wrap.appendChild(toast);

    if (kind === 'success' || kind === 'info') {
      window.setTimeout(function () {
        removeToast(toast);
      }, 6500);
    }
  }

  function setSubmitLoading(submitBtn, loading) {
    if (!submitBtn) {
      return;
    }

    var wrap = submitBtn.closest('.yoo-security-action__submit-wrap');
    if (!wrap) {
      return;
    }

    wrap.classList.toggle('is-loading', !!loading);

    if (loading) {
      submitBtn.setAttribute('aria-busy', 'true');
      submitBtn.disabled = true;
    } else {
      submitBtn.removeAttribute('aria-busy');
      submitBtn.disabled = false;
    }
  }

  function initSecurityActionForm() {
    var form = document.querySelector('.yoo-security-action__form');
    if (!form) {
      return;
    }

    var submitBtn = form.querySelector('.yoo-security-action__submit');
    if (!submitBtn) {
      return;
    }

    form.addEventListener('submit', function () {
      if (submitBtn.disabled) {
        return;
      }

      setSubmitLoading(submitBtn, true);
      showToast('info', (cfg.i18n && cfg.i18n.recovering) || 'Recovering your account…');
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSecurityActionForm);
  } else {
    initSecurityActionForm();
  }
})();
