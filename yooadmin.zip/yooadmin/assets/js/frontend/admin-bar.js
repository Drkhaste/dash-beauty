/**
 * YOOAdmin - Custom admin bar (frontend)
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    function effectiveFromMode(mode) {
        if (mode === 'dark') {
            return 'dark';
        }
        if (mode === 'light') {
            return 'light';
        }
        try {
            return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        } catch (err) {
            return 'light';
        }
    }

    function applyFrontendBarColorMode($bar, mode) {
        var effective = effectiveFromMode(mode);
        $bar.attr('data-yooadmin-bar-mode', effective);
        document.documentElement.setAttribute('data-yooadmin-frontend-bar-mode-effective', effective);
        return effective;
    }

    $(document).ready(function() {
        var $bar = $('#yooadmin-frontend-bar');
        if ($bar.length && window.yooadmBar) {
            var mode = window.yooadmBar.appearanceMode || 'auto';
            applyFrontendBarColorMode($bar, mode);

            if (mode === 'auto' && window.matchMedia) {
                var mq = window.matchMedia('(prefers-color-scheme: dark)');
                var onSchemeChange = function() {
                    applyFrontendBarColorMode($bar, 'auto');
                };
                if (typeof mq.addEventListener === 'function') {
                    mq.addEventListener('change', onSchemeChange);
                } else if (typeof mq.addListener === 'function') {
                    mq.addListener(onSchemeChange);
                }
            }
        }

        /**
         * Toggle dropdown menus
         */
        $('.yooadmin-bar-trigger').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();

            const $dropdown = $(this).closest('.yooadmin-bar-dropdown');
            const isActive = $dropdown.hasClass('active');

            // Close all other dropdowns
            $('.yooadmin-bar-dropdown').removeClass('active');

            // Toggle current dropdown
            if (!isActive) {
                $dropdown.addClass('active');
            }
        });

        /**
         * Close dropdowns when clicking outside
         */
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.yooadmin-bar-dropdown').length) {
                $('.yooadmin-bar-dropdown').removeClass('active');
            }
        });

        /**
         * Close dropdown when clicking on a link inside
         */
        $('.yooadmin-bar-dropdown-item').on('click', function() {
            $(this).closest('.yooadmin-bar-dropdown').removeClass('active');
        });

        /**
         * Keyboard navigation
         */
        $('.yooadmin-bar-trigger').on('keydown', function(e) {
            // Enter or Space to toggle
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                $(this).click();
            }
            // Escape to close
            if (e.key === 'Escape') {
                $(this).closest('.yooadmin-bar-dropdown').removeClass('active');
            }
        });

        /**
         * Update notification badge dynamically (optional)
         */
        function updateNotificationBadge() {
            if (typeof yooadmBar === 'undefined') {
                return;
            }

            $.ajax({
                url: yooadmBar.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'yooadmin_get_notification_count',
                    nonce: yooadmBar.nonce
                },
                success: function(response) {
                    if (response.success && response.data.count) {
                        const count = parseInt(response.data.count);
                        const $badge = $('.yooadmin-bar-item .dashicons-bell').siblings('.yooadmin-bar-badge');

                        if (count > 0) {
                            if ($badge.length) {
                                $badge.text(count);
                            } else {
                                $('.yooadmin-bar-item .dashicons-bell').after(
                                    '<span class="yooadmin-bar-badge">' + count + '</span>'
                                );
                            }
                        } else {
                            $badge.remove();
                        }
                    }
                }
            });
        }

        // Update notification badge every 30 seconds
        if (typeof yooadmBar !== 'undefined') {
            setInterval(updateNotificationBadge, 30000);
        }
    });
})(jQuery);
