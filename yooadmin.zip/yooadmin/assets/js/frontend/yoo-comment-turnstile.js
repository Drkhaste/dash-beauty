(function () {
  'use strict';

  var cfg = window.yooadminCommentTurnstile || {};

  function t(key, fallback) {
    return (cfg.i18n && cfg.i18n[key]) || fallback;
  }

  function getForm(wrap) {
    return wrap ? wrap.closest('form.comment-form, form#commentform') : null;
  }

  function setSubmitGate(form, ready) {
    if (!form) {
      return;
    }
    form.classList.toggle('yoo-comment-form--awaiting-turnstile', !ready);
    var submit = form.querySelector('#submit, input[type="submit"]');
    if (submit) {
      submit.disabled = !ready;
    }
  }

  function setChallengeVisible(wrap, visible) {
    if (!wrap) {
      return;
    }
    wrap.classList.toggle('is-challenge-visible', !!visible);
  }

  function syncRetryButton(wrap, state) {
    var retryBtn = wrap.querySelector('.yoo-sl-turnstile-retry');
    if (!retryBtn) {
      return;
    }
    if (state === 'error') {
      retryBtn.removeAttribute('hidden');
    } else {
      retryBtn.setAttribute('hidden', 'hidden');
    }
  }

  function setState(wrap, state, messageKey) {
    if (!wrap) {
      return;
    }

    var normalized = state === 'verified' || state === 'error' ? state : 'pending';
    wrap.classList.remove('is-pending', 'is-verified', 'is-error');
    wrap.classList.add('is-' + normalized);
    wrap.setAttribute('data-yoo-turnstile-state', normalized);

    var textEl = wrap.querySelector('.yoo-sl-turnstile-status__text');
    var iconEl = wrap.querySelector('.yoo-sl-turnstile-status__icon');

    if (textEl) {
      if (normalized === 'verified') {
        textEl.textContent = t('securityVerified', 'Security verification complete');
      } else if (normalized === 'error') {
        textEl.textContent =
          messageKey === 'captchaRequired'
            ? t('captchaRequired', 'Please complete the security check.')
            : t('securityFailed', 'Security verification failed. Please try again.');
      } else if (wrap.classList.contains('is-challenge-visible')) {
        textEl.textContent = t('securityChallenge', 'Please complete the security check below.');
      } else {
        textEl.textContent = t('securityChecking', 'Security verification in progress…');
      }
    }

    if (iconEl) {
      iconEl.classList.remove('dashicons-shield-alt', 'dashicons-yes-alt', 'dashicons-warning');
      if (normalized === 'verified') {
        iconEl.classList.add('dashicons-yes-alt');
      } else if (normalized === 'error') {
        iconEl.classList.add('dashicons-warning');
      } else {
        iconEl.classList.add('dashicons-shield-alt');
      }
    }

    if (normalized === 'verified') {
      setChallengeVisible(wrap, false);
    } else if (normalized === 'error') {
      setChallengeVisible(wrap, true);
    }

    syncRetryButton(wrap, normalized);
    setSubmitGate(getForm(wrap), normalized === 'verified');
  }

  function mountWidget(wrap) {
    var host = wrap.querySelector('[data-yoo-comment-turnstile], .yoo-sl-turnstile');
    if (!host || !cfg.siteKey || !window.turnstile || typeof window.turnstile.render !== 'function') {
      return;
    }

    if (host.getAttribute('data-yoo-comment-turnstile-ready') === '1') {
      try {
        window.turnstile.remove(host);
      } catch (removeErr) {
        /* ignore */
      }
      host.removeAttribute('data-yoo-comment-turnstile-ready');
      host.innerHTML = '';
    }

    var renderOpts = cfg.render || {};
    window.turnstile.render(host, {
      sitekey: cfg.siteKey,
      theme: 'light',
      size: renderOpts.size || 'normal',
      appearance: renderOpts.appearance || 'interaction-only',
      language: renderOpts.language || undefined,
      callback: function () {
        setState(wrap, 'verified');
      },
      'error-callback': function () {
        setState(wrap, 'error');
      },
      'expired-callback': function () {
        setChallengeVisible(wrap, true);
        setState(wrap, 'pending');
        setSubmitGate(getForm(wrap), false);
        mountWidget(wrap);
      },
    });

    host.setAttribute('data-yoo-comment-turnstile-ready', '1');
  }

  function boot() {
    if (!cfg.siteKey) {
      return;
    }

    var wraps = document.querySelectorAll('[data-yoo-comment-turnstile-wrap]');
    if (!wraps.length) {
      return;
    }

    var isStandard = cfg.displayMode === 'standard';

    Array.prototype.forEach.call(wraps, function (wrap) {
      var form = getForm(wrap);
      setSubmitGate(form, false);
      setState(wrap, 'pending');
      if (isStandard) {
        setChallengeVisible(wrap, true);
      }

      var retryBtn = wrap.querySelector('.yoo-sl-turnstile-retry');
      if (retryBtn) {
        retryBtn.addEventListener('click', function () {
          setChallengeVisible(wrap, true);
          setState(wrap, 'pending');
          mountWidget(wrap);
        });
      }

      if (form) {
        form.addEventListener('submit', function (e) {
          var tokenInput = form.querySelector('input[name="cf-turnstile-response"]');
          var token = tokenInput ? tokenInput.value : '';
          if (!token) {
            e.preventDefault();
            setChallengeVisible(wrap, true);
            setState(wrap, 'error', 'captchaRequired');
          }
        });
      }
    });

    function tryMountAll() {
      if (!window.turnstile || typeof window.turnstile.render !== 'function') {
        return false;
      }
      Array.prototype.forEach.call(wraps, function (wrap) {
        mountWidget(wrap);
      });
      return true;
    }

    if (!tryMountAll()) {
      var attempts = 0;
      var timer = window.setInterval(function () {
        attempts += 1;
        if (tryMountAll() || attempts > 40) {
          window.clearInterval(timer);
          if (attempts > 40) {
            Array.prototype.forEach.call(wraps, function (wrap) {
              setChallengeVisible(wrap, true);
              setState(wrap, 'error');
            });
          }
        }
      }, 250);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
