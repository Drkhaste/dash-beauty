(function ($) {
  'use strict';

  $(function () {
    var $root = $('.yoo-network-site-editor-themes');
    if (!$root.length) {
      return;
    }

    var $form = $('#yoo-network-site-themes-form');
    var $bulkBar = $('#yoo-network-site-themes-bulk-bar');
    var $count = $bulkBar.find('[data-yoo-network-site-themes-count]');
    var $bulkAction = $('#yoo-network-site-themes-bulk-action');
    var $bulkApply = $('#yoo-network-site-themes-bulk-apply');
    var $selectAllBtn = $root.find('[data-yoo-network-site-themes-select-all]');
    var $deselectAllBtn = $root.find('[data-yoo-network-site-themes-deselect]');
    var i18n = window.yooNetworkSiteThemes || {};

    function t(key, fallback) {
      return i18n[key] || fallback;
    }

    function selectedCount() {
      return $root.find('[data-yoo-network-site-theme-cb]:checked').length;
    }

    function updateBulkBar() {
      var count = selectedCount();
      var total = $root.find('[data-yoo-network-site-theme-cb]').length;

      if (count > 0) {
        $bulkBar.slideDown(200);
        $count.text(
          count + ' ' + (count === 1 ? t('selectedSingular', 'selected') : t('selectedPlural', 'selected'))
        );
        $bulkApply.prop('disabled', !$bulkAction.val() || $bulkAction.val() === '-1');
        $selectAllBtn.prop('hidden', count >= total);
        $deselectAllBtn.prop('hidden', false);
      } else {
        $bulkBar.slideUp(200);
        $bulkApply.prop('disabled', true);
        $selectAllBtn.prop('hidden', true);
        $deselectAllBtn.prop('hidden', true);
      }

      $root.find('.yoo-theme-card').each(function () {
        var $card = $(this);
        $card.toggleClass('selected', $card.find('[data-yoo-network-site-theme-cb]').is(':checked'));
      });
    }

    $root.on('change', '[data-yoo-network-site-theme-cb]', updateBulkBar);
    $bulkAction.on('change', updateBulkBar);

    $selectAllBtn.on('click', function () {
      $root.find('[data-yoo-network-site-theme-cb]').prop('checked', true);
      updateBulkBar();
    });

    $deselectAllBtn.on('click', function () {
      $root.find('[data-yoo-network-site-theme-cb]').prop('checked', false);
      updateBulkBar();
    });

    $root.find('.yoo-search-box input[type="search"]').on('keydown', function (e) {
      if (e.key === 'Enter') {
        $(this).closest('form').trigger('submit');
      }
    });

    updateBulkBar();
  });
})(jQuery);
