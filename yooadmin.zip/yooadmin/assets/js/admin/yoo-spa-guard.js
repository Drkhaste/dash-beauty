/**
 * YOOAdmin - SPA guard (wc-admin routes)
 *
 * @package YOOAdmin
 */

/* eslint-disable no-var, vars-on-top */
(function () {
	'use strict';

	/* ---------------------------------------------------------------------
	 * Early exits / re-entrancy guard
	 * ------------------------------------------------------------------ */

	/* global __YOOPIXEL_DISABLED__ */
	if (window.__YOOPIXEL_DISABLED__) { return; }

	if (window.__yooadmSpaGuardWired__) { return; }
	window.__yooadmSpaGuardWired__ = true;

	/* ---------------------------------------------------------------------
	 * Constants
	 * ------------------------------------------------------------------ */
	var HEAVY_ROUTES = ['/customize-store', '/launch-your-store'];
	var SAFETY_PARAM = '_ypnav'; // prevents recursive reloads
	var BODY_HEAVY_CLASS = 'yoo-skip-heavy';
	var HEADER_ID = 'yoo-admin-header';

	/* ---------------------------------------------------------------------
	 * URL helpers
	 * ------------------------------------------------------------------ */

	function toURL(u) {
		try { return new URL(u, window.location.href); } catch (e) { return null; }
	}

	function sameOrigin(u) {
		try { return !!u && u.origin === window.location.origin; } catch (e) { return false; }
	}

	function getSearchParams(u) {
		try { return new URLSearchParams(u.search || ''); } catch (e) { return new URLSearchParams(''); }
	}

	function isWcAdmin(u) {
		var qs = getSearchParams(u);
		return qs.get('page') === 'wc-admin';
	}

	function getPath(u) {
		var qs = getSearchParams(u);
		var p = qs.get('path') || '';
		try { return decodeURIComponent(p); } catch (e) { return p; }
	}

	function isHeavyURL(u) {
		if (!u || !sameOrigin(u) || !isWcAdmin(u)) { return false; }
		var p = getPath(u);
		for (var i = 0; i < HEAVY_ROUTES.length; i++) {
			if (typeof p === 'string' && p.indexOf(HEAVY_ROUTES[i]) === 0) { return true; }
		}
		return false;
	}

	function hasParam(u, key) {
		var qs = getSearchParams(u);
		return qs.has(key);
	}

	function addParam(u, key, val) {
		var qs = getSearchParams(u);
		qs.set(key, val);
		u.search = '?' + qs.toString();
		return u;
	}

	function forceFullLoad(u) {
		if (!hasParam(u, SAFETY_PARAM)) { u = addParam(u, SAFETY_PARAM, '1'); }
		// Use replace() to avoid polluting history with an intermediate redirect.
		window.location.replace(u.toString());
	}

	/* ---------------------------------------------------------------------
	 * Cosmetic: header measurements & heavy class
	 * ------------------------------------------------------------------ */

	function setHeaderVars(px) {
		var root = document.documentElement;
		if (!root) { return; }
		root.style.setProperty('--yp-admin-header-h', String(px) + 'px');
		root.style.setProperty('--wp-admin--admin-bar--height', String(px) + 'px');
	}

	function syncSubsiteContextBarHeight() {
		if (typeof window.yooadminSyncSubsiteContextBarHeight === 'function') {
			window.yooadminSyncSubsiteContextBarHeight();
			return;
		}
		var chrome = document.querySelector('.yp-subsite-chrome');
		var bar = document.getElementById('yp-subsite-context-bar');
		var root = document.documentElement;
		if (!root) {
			return;
		}
		var h = chrome && chrome.offsetHeight ? chrome.offsetHeight : (bar && bar.offsetHeight ? bar.offsetHeight : 0);
		if (h > 0) {
			root.style.setProperty('--yp-subsite-context-bar-h', String(h) + 'px');
		}
	}

	function measureHeader() {
		syncSubsiteContextBarHeight();
		var chrome = document.querySelector('.yp-subsite-chrome');
		if (chrome && chrome.offsetHeight) {
			return chrome.offsetHeight;
		}
		var wrapper = document.getElementById('yoo-admin-header-wrapper');
		if (wrapper && wrapper.offsetHeight) {
			return wrapper.offsetHeight;
		}
		var el = document.getElementById(HEADER_ID);
		return el && el.offsetHeight ? el.offsetHeight : 64;
	}

	function applyHeavyClass(heavy) {
		if (!document.body) { return; }
		if (heavy) {
			document.body.classList.add(BODY_HEAVY_CLASS);
			setHeaderVars(0);
		} else {
			document.body.classList.remove(BODY_HEAVY_CLASS);
			setHeaderVars(measureHeader());
		}
	}

	/* ---------------------------------------------------------------------
	 * State & listeners
	 * ------------------------------------------------------------------ */
	var YP_IS_HEAVY = isHeavyURL(toURL(window.location.href));

	function onNavChange() {
		var cur = toURL(window.location.href);
		YP_IS_HEAVY = isHeavyURL(cur);
		applyHeavyClass(YP_IS_HEAVY);
	}

	/* ---------------------------------------------------------------------
	 * Tidy: remove safety param from URL after the hard load
	 * ------------------------------------------------------------------ */
	(function tidyParamOnLoad() {
		var cur = toURL(window.location.href);
		if (!cur || !hasParam(cur, SAFETY_PARAM)) { return; }
		try {
			var qs = getSearchParams(cur);
			qs.delete(SAFETY_PARAM);
			var clean = cur.origin + cur.pathname + (qs.toString() ? ('?' + qs.toString()) : '') + cur.hash;
			history.replaceState(history.state, document.title, clean);
		} catch (e) {
			// no-op
		}
	})();

	/* ---------------------------------------------------------------------
	 * Hook history API: only enforce when moving NON-heavy → heavy
	 * ------------------------------------------------------------------ */
	(function hookHistory() {
		var _push = history.pushState;
		var _replace = history.replaceState;

		history.pushState = function (state, title, url) {
			var target = toURL(url);
			if (!YP_IS_HEAVY && target && isHeavyURL(target) && !hasParam(target, SAFETY_PARAM)) {
				forceFullLoad(target);
				return; // do not call original
			}
			var ret = _push.apply(this, arguments);
			window.dispatchEvent(new Event('locationchange'));
			return ret;
		};

		history.replaceState = function (state, title, url) {
			var target = toURL(url);
			if (!YP_IS_HEAVY && target && isHeavyURL(target) && !hasParam(target, SAFETY_PARAM)) {
				forceFullLoad(target);
				return; // do not call original
			}
			var ret = _replace.apply(this, arguments);
			window.dispatchEvent(new Event('locationchange'));
			return ret;
		};

		window.addEventListener('popstate', function () {
			var cur = toURL(window.location.href);
			// If we navigated back from non-heavy → heavy, enforce one hard load
			if (!YP_IS_HEAVY && cur && isHeavyURL(cur) && !hasParam(cur, SAFETY_PARAM)) {
				forceFullLoad(cur);
				return;
			}
			window.dispatchEvent(new Event('locationchange'));
		});
	})();

	/* ---------------------------------------------------------------------
	 * Click interception (capture): respect user intent & origin
	 * ------------------------------------------------------------------ */
	document.addEventListener('click', function (e) {
		// Respect modifiers / non-primary button / download / target=_blank.
		if (e.defaultPrevented) { return; }
		if (e.button && e.button !== 0) { return; } // primary only
		if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) { return; }

		var a = e.target;
		while (a && a !== document) {
			if (a.tagName === 'A' && a.href) {
				// Skip if explicitly opted-out
				if (a.hasAttribute('download') || a.getAttribute('target') === '_blank' || a.getAttribute('rel') === 'external' || a.dataset.noYpguard === '1') {
					return;
				}
				var target = toURL(a.href);
				if (target && sameOrigin(target)) {
					// Force full reload for ALL WooCommerce pages (not just heavy ones)
					if (isWcAdmin(target) && !hasParam(target, SAFETY_PARAM)) {
						e.preventDefault();
						e.stopImmediatePropagation();
						forceFullLoad(target);
						return;
					}
					// Force full reload for heavy routes only
					if (!YP_IS_HEAVY && isHeavyURL(target) && !hasParam(target, SAFETY_PARAM)) {
						e.preventDefault();
						e.stopImmediatePropagation();
						forceFullLoad(target);
						return;
					}
				}
			}
			a = a.parentNode;
		}
	}, { capture: true }); // capture ensures we precede React/SPA handlers

	/* ---------------------------------------------------------------------
	 * Initial pass + react to virtual navigations
	 * ------------------------------------------------------------------ */
	function boot() {
		onNavChange();
		window.addEventListener('locationchange', onNavChange);
		window.addEventListener('load', function () {
			// If not a heavy route on load, ensure header vars are set.
			if (!isHeavyURL(toURL(window.location.href))) {
				setHeaderVars(measureHeader());
			}
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
