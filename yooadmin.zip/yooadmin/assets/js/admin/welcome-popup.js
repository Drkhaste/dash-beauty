(function ($) {
  'use strict';

  var WelcomePopup = {
    init: function () {
      var $overlay = $('#yooadmin-welcome-popup');
      if (!$overlay.length) {
        return;
      }

      $overlay.removeAttr('hidden').attr('aria-hidden', 'false');
      window.setTimeout(function () {
        $overlay.addClass('ywp-visible');
      }, 450);

      this.bindEvents($overlay);
    },

    hidePopup: function ($overlay) {
      $overlay.addClass('ywp-leaving').removeClass('ywp-visible');

      window.setTimeout(function () {
        $overlay.remove();
      }, 300);
    },

    markAsShown: function () {
      if (!window.yooadmWelcomePopup) {
        return;
      }

      $.ajax({
        url: yooadmWelcomePopup.ajaxUrl,
        type: 'POST',
        data: {
          action: 'yooadmin_mark_welcome_popup_shown',
          nonce: yooadmWelcomePopup.nonce
        }
      });
    },

    dismiss: function ($overlay) {
      this.markAsShown();
      this.hidePopup($overlay);
    },

    bindEvents: function ($overlay) {
      var self = this;

      $overlay.on('click', '.ywp-close, .ywp-welcome-got-it', function (e) {
        e.preventDefault();
        self.dismiss($overlay);
      });

      $overlay.on('click', '.ywp-welcome-open-settings', function () {
        self.markAsShown();
      });

      $overlay.on('click', function (e) {
        if ($(e.target).is('.ywp-overlay')) {
          self.dismiss($overlay);
        }
      });

      $overlay.on('click', '.ywp-dialog', function (e) {
        e.stopPropagation();
      });
    }
  };

  $(document).ready(function () {
    window.setTimeout(function () {
      WelcomePopup.init();
    }, 500);
  });
})(jQuery);
