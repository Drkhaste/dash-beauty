/**
 * YOOAdmin - Users bulk actions
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        const $bulkBar = $('.yoo-bulk-actions-bar');
        const $selectAll = $('#yoo-select-all-users');
        const $selectedCount = $('.yoo-selected-count');
        const $bulkSelect = $('#yoo-bulk-action-select');
        const $bulkApply = $('#yoo-bulk-apply');
        
        // Update selected count and show/hide bulk bar
        function updateBulkBar() {
            const $checked = $('.yoo-user-checkbox:checked');
            const count = $checked.length;
            
            if (count > 0) {
                $bulkBar.slideDown(200);
                $selectedCount.text(count + ' ' + yooadmUsersBulk.i18n.selected);
                $bulkApply.prop('disabled', false);
                
                // Update select all checkbox
                const total = $('.yoo-user-checkbox').length;
                $selectAll.prop('checked', count === total);
                $selectAll.prop('indeterminate', count > 0 && count < total);
            } else {
                $bulkBar.slideUp(200);
                $bulkApply.prop('disabled', true);
                $selectAll.prop('checked', false);
                $selectAll.prop('indeterminate', false);
            }
            
            // Add/remove selected class from cards
            $('.yoo-user-card').each(function() {
                const $card = $(this);
                const $checkbox = $card.find('.yoo-user-checkbox');
                
                if ($checkbox.is(':checked')) {
                    $card.addClass('selected');
                } else {
                    $card.removeClass('selected');
                }
            });
        }
        
        // Select/deselect all
        $selectAll.on('change', function() {
            const isChecked = $(this).is(':checked');
            $('.yoo-user-checkbox').prop('checked', isChecked);
            updateBulkBar();
        });
        
        // Individual checkbox change
        $(document).on('change', '.yoo-user-checkbox', function() {
            updateBulkBar();
        });

        // Card/profile overflow menu — delete or remove (YOOAdmin confirm modal + AJAX).
        $(document).on('click', '.yoo-user-card-menu a.submitdelete', function(e) {
            e.preventDefault();

            const $link = $(this);
            const parsed = parseDestructiveActionLink($link);
            if (!parsed.userId || !parsed.action) {
                return;
            }

            closeUserCardMenus();
            showSingleUserConfirmPopup(parsed.action, parsed.userId, parsed.userName, parsed.isAdmin);
        });
        
        // Apply bulk action
        $bulkApply.on('click', function() {
            const action = $bulkSelect.val();
            const $checked = $('.yoo-user-checkbox:checked');
            
            if (!action || $checked.length === 0) {
                return;
            }
            
            // Show confirmation popup
            showBulkConfirmPopup(action, $checked);
        });
        
        function closeUserCardMenus() {
            $('.yoo-user-card-menu.is-open').removeClass('is-open')
                .find('.yoo-user-card-menu__toggle').attr('aria-expanded', 'false');
            $('.yoo-user-card-menu__dropdown').attr('hidden', 'hidden');
        }

        function parseDestructiveActionLink($link) {
            let action = String($link.data('yooUserAction') || '');
            let userId = parseInt($link.data('userId'), 10) || 0;
            let userName = String($link.data('userName') || '');
            let isAdmin = String($link.data('isAdmin') || '0') === '1';

            const href = String($link.attr('href') || '');
            if (href && href !== '#') {
                try {
                    const url = new URL(href, window.location.origin);
                    action = action || String(url.searchParams.get('action') || '');
                    userId = userId || parseInt(url.searchParams.get('user'), 10) || 0;
                } catch (err) {
                    // Keep data-attribute values when href is not a valid URL.
                }
            }

            if (!userName) {
                userName = $.trim($link.text());
            }

            return {
                action: action,
                userId: userId,
                userName: userName,
                isAdmin: isAdmin
            };
        }

        function validateSingleDelete(userId, isAdmin) {
            const currentUserId = String(yooadmUsersBulk.currentUserId || '');

            if (String(userId) === currentUserId) {
                showNotice(yooadmUsersBulk.i18n.cannotDeleteSelf, 'error');
                return false;
            }

            const adminCount = parseInt(yooadmUsersBulk.adminCount, 10) || 0;
            if (isAdmin && adminCount <= 1) {
                showNotice(yooadmUsersBulk.i18n.cannotDeleteLastAdmin, 'error');
                return false;
            }

            return true;
        }

        function showConfirmOverlay(config) {
            const popupHTML = `
                <div class="yoo-confirm-overlay">
                    <div class="yoo-confirm-modal">
                        <div class="yoo-confirm-header" style="border-bottom-color: ${config.color};">
                            <span class="dashicons ${config.icon}" style="color: ${config.color};"></span>
                            <h3>${config.title}</h3>
                        </div>
                        <div class="yoo-confirm-body">
                            <p>${config.message}</p>
                        </div>
                        <div class="yoo-confirm-footer">
                            <button type="button" class="yoo-confirm-cancel yoo-button yoo-button--ghost">
                                ${yooadmUsersBulk.i18n.cancel}
                            </button>
                            <button type="button" class="yoo-confirm-ok yoo-button yoo-button--primary" style="background: ${config.color}; border-color: ${config.color};">
                                ${config.confirmText}
                            </button>
                        </div>
                    </div>
                </div>
            `;

            $('body').append(popupHTML);

            $('.yoo-confirm-cancel').on('click', function() {
                $('.yoo-confirm-overlay').fadeOut(200, function() {
                    $(this).remove();
                });
            });

            $('.yoo-confirm-ok').on('click', function() {
                $('.yoo-confirm-overlay').fadeOut(200, function() {
                    $(this).remove();
                });
                if (typeof config.onConfirm === 'function') {
                    config.onConfirm();
                }
            });

            $('.yoo-confirm-overlay').on('click', function(e) {
                if ($(e.target).hasClass('yoo-confirm-overlay')) {
                    $(this).fadeOut(200, function() {
                        $(this).remove();
                    });
                }
            });
        }

        function showSingleUserConfirmPopup(action, userId, userName, isAdmin) {
            if (action === 'delete' && !validateSingleDelete(userId, isAdmin)) {
                return;
            }

            let title = yooadmUsersBulk.i18n.delete;
            let confirmText = yooadmUsersBulk.i18n.deletePermanently;
            let message = (yooadmUsersBulk.i18n.deleteSingleConfirm || '').replace('%s', userName);

            if (action === 'remove') {
                title = yooadmUsersBulk.i18n.remove || yooadmUsersBulk.i18n.delete;
                confirmText = yooadmUsersBulk.i18n.removePermanently || confirmText;
                message = (yooadmUsersBulk.i18n.removeSingleConfirm || message).replace('%s', userName);
            }

            showConfirmOverlay({
                title: title,
                icon: 'dashicons-warning',
                color: '#d63638',
                message: message,
                confirmText: confirmText,
                onConfirm: function() {
                    processSingleUserAction(action, userId);
                }
            });
        }

        function getUsersListUrl() {
            if (yooadmUsersBulk.usersListUrl) {
                return yooadmUsersBulk.usersListUrl;
            }

            const adminPath = window.location.pathname.replace(/\/wp-admin\/.*$/, '/wp-admin/admin.php');
            return window.location.origin + adminPath + '?page=yooadmin-users';
        }

        function isUserProfilePage() {
            return /[?&]page=yooadmin-user(?:&|$)/.test(window.location.search);
        }

        function processSingleUserAction(action, userId) {
            $.ajax({
                url: yooadmUsersBulk.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_bulk_users_action',
                    users: [userId],
                    bulk_action: action,
                    nonce: yooadmUsersBulk.nonce
                },
                success: function(response) {
                    if (response.success) {
                        if (
                            isUserProfilePage()
                            && (action === 'delete' || action === 'remove')
                        ) {
                            window.location.replace(getUsersListUrl());
                            return;
                        }

                        showNotice(response.data.message || yooadmUsersBulk.i18n.success, 'success');

                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    } else {
                        showNotice(response.data.message || yooadmUsersBulk.i18n.error, 'error');
                    }
                },
                error: function() {
                    showNotice(yooadmUsersBulk.i18n.error, 'error');
                }
            });
        }

        // Show bulk action confirmation popup
        function validateDeleteSelection($checked) {
            const currentUserId = String(yooadmUsersBulk.currentUserId || '');
            const adminCount = parseInt(yooadmUsersBulk.adminCount, 10) || 0;
            let selectedAdmins = 0;
            let includesSelf = false;

            $checked.each(function() {
                const id = String($(this).val());
                if (id === currentUserId) {
                    includesSelf = true;
                }
                if (String($(this).data('isAdmin')) === '1') {
                    selectedAdmins += 1;
                }
            });

            if (includesSelf) {
                showNotice(yooadmUsersBulk.i18n.cannotDeleteSelf, 'error');
                return false;
            }

            if (selectedAdmins > 0 && selectedAdmins >= adminCount) {
                showNotice(yooadmUsersBulk.i18n.cannotDeleteLastAdmin, 'error');
                return false;
            }

            return true;
        }

        function showBulkConfirmPopup(action, $checked) {
            if (action === 'delete' && !validateDeleteSelection($checked)) {
                return;
            }

            const count = $checked.length;
            let actionText = '';
            let actionIcon = '';
            let actionColor = '';
            let confirmText = '';
            
            switch(action) {
                case 'delete':
                    actionText = yooadmUsersBulk.i18n.delete;
                    actionIcon = 'dashicons-warning';
                    actionColor = '#d63638';
                    confirmText = yooadmUsersBulk.i18n.deletePermanently;
                    break;
                case 'change_role':
                    actionText = yooadmUsersBulk.i18n.changeRole;
                    actionIcon = 'dashicons-admin-users';
                    actionColor = 'var(--_yp-primary)';
                    confirmText = yooadmUsersBulk.i18n.changeRole;
                    break;
            }
            
            const message = action === 'delete' 
                ? yooadmUsersBulk.i18n.deleteConfirm.replace('%d', count)
                : yooadmUsersBulk.i18n.changeRoleConfirm.replace('%d', count);

            showConfirmOverlay({
                title: actionText,
                icon: actionIcon,
                color: actionColor,
                message: message,
                confirmText: confirmText,
                onConfirm: function() {
                    if (action === 'change_role') {
                        showRoleSelector($checked);
                    } else {
                        processBulkAction(action, $checked);
                    }
                }
            });
        }
        
        // Show role selector
        function showRoleSelector($checked) {
            const roles = yooadmUsersBulk.roles;
            let roleOptions = '<option value="">' + yooadmUsersBulk.i18n.selectRole + '</option>';
            
            for (const [key, name] of Object.entries(roles)) {
                roleOptions += `<option value="${key}">${name}</option>`;
            }
            
            const roleSelectorHTML = `
                <div class="yoo-confirm-overlay">
                    <div class="yoo-confirm-modal">
                        <div class="yoo-confirm-header" style="border-bottom-color: var(--_yp-primary);">
                            <span class="dashicons dashicons-admin-users" style="color: var(--_yp-primary);"></span>
                            <h3>${yooadmUsersBulk.i18n.changeRole}</h3>
                        </div>
                        <div class="yoo-confirm-body">
                            <p>${yooadmUsersBulk.i18n.selectNewRole}</p>
                            <select id="yoo-bulk-role-select" class="yoo-bulk-select" style="width: 100%; margin-top: 12px;">
                                ${roleOptions}
                            </select>
                        </div>
                        <div class="yoo-confirm-footer">
                            <button type="button" class="yoo-confirm-cancel yoo-button yoo-button--ghost">
                                ${yooadmUsersBulk.i18n.cancel}
                            </button>
                            <button type="button" class="yoo-confirm-ok yoo-button yoo-button--primary">
                                ${yooadmUsersBulk.i18n.apply}
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(roleSelectorHTML);
            
            $('.yoo-confirm-cancel').on('click', function() {
                $('.yoo-confirm-overlay').fadeOut(200, function() {
                    $(this).remove();
                });
            });
            
            $('.yoo-confirm-ok').on('click', function() {
                const selectedRole = $('#yoo-bulk-role-select').val();
                if (!selectedRole) {
                    alert(yooadmUsersBulk.i18n.selectRole);
                    return;
                }
                
                $('.yoo-confirm-overlay').fadeOut(200, function() {
                    $(this).remove();
                });
                
                processBulkAction('change_role', $checked, selectedRole);
            });
        }
        
        // Process bulk action
        function processBulkAction(action, $checked, role = '') {
            const userIds = [];
            $checked.each(function() {
                userIds.push($(this).val());
            });
            
            $bulkApply.prop('disabled', true).text(yooadmUsersBulk.i18n.processing);
            
            $.ajax({
                url: yooadmUsersBulk.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_bulk_users_action',
                    users: userIds,
                    bulk_action: action,
                    role: role,
                    nonce: yooadmUsersBulk.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showNotice(response.data.message || yooadmUsersBulk.i18n.success, 'success');
                        
                        // Reload page after short delay
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    } else {
                        showNotice(response.data.message || yooadmUsersBulk.i18n.error, 'error');
                        $bulkApply.prop('disabled', false).text(yooadmUsersBulk.i18n.apply);
                    }
                },
                error: function() {
                    showNotice(yooadmUsersBulk.i18n.error, 'error');
                    $bulkApply.prop('disabled', false).text(yooadmUsersBulk.i18n.apply);
                }
            });
        }
        
        // Show notice
        function showNotice(message, type) {
            const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
            const noticeHTML = `
                <div class="notice ${noticeClass} is-dismissible" style="margin: 20px 0;">
                    <p>${message}</p>
                    <button type="button" class="notice-dismiss">
                        <span class="screen-reader-text">Dismiss this notice.</span>
                    </button>
                </div>
            `;
            
            $('.wrap').prepend(noticeHTML);
            
            // Auto dismiss after 5 seconds
            setTimeout(function() {
                $('.notice').fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);
            
            // Manual dismiss
            $('.notice-dismiss').on('click', function() {
                $(this).closest('.notice').fadeOut(300, function() {
                    $(this).remove();
                });
            });
        }
    });
})(jQuery);


























