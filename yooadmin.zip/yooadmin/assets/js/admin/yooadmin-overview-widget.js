(function () {
  'use strict';

  function cfg() {
    return window.yooadminOverviewWidget || {};
  }

  function parseHidden(value) {
    if (!value) {
      return null;
    }
    try {
      var parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : null;
    } catch (err) {
      return null;
    }
  }

  function getDefaultHidden() {
    return Array.isArray(cfg().defaultHidden) ? cfg().defaultHidden : [];
  }

  function getInitialHidden(widget) {
    var widgetHidden = parseHidden(widget.getAttribute('data-overview-hidden'));
    if (widgetHidden !== null) {
      return widgetHidden;
    }
    return Array.isArray(cfg().hidden) ? cfg().hidden : getDefaultHidden();
  }

  function syncToggleState(input) {
    var isVisible = !!input.checked;
    input.setAttribute('aria-checked', isVisible ? 'true' : 'false');

    var slider = input.nextElementSibling;
    if (slider && slider.classList.contains('yp-toggle-slider')) {
      slider.classList.toggle('is-on', isVisible);
    }

    var row = input.closest('.yooadmin-overview-widget__check');
    if (row) {
      row.classList.toggle('is-active', isVisible);
      row.classList.toggle('is-disabled', !!input.disabled);
    }
  }

  function collectHiddenFromCards(widget) {
    var hidden = [];
    widget.querySelectorAll('[data-overview-item]').forEach(function (card) {
      var id = card.getAttribute('data-overview-item');
      if (!id) {
        return;
      }
      if (card.classList.contains('is-hidden')) {
        hidden.push(id);
      }
    });
    return hidden;
  }

  function readHiddenState(widget) {
    var fromAttr = parseHidden(widget.getAttribute('data-overview-hidden'));
    if (fromAttr !== null) {
      return fromAttr;
    }
    var fromCards = collectHiddenFromCards(widget);
    if (fromCards.length || widget.querySelector('[data-overview-item]')) {
      return fromCards;
    }
    return getInitialHidden(widget);
  }

  function syncWidgetState(widget) {
    if (!widget) {
      return;
    }
    applyHidden(widget, readHiddenState(widget));
  }

  function applyHidden(widget, hidden) {
    var set = {};
    (hidden || []).forEach(function (id) {
      set[id] = true;
    });
    widget.setAttribute('data-overview-hidden', JSON.stringify(hidden || []));
    widget.querySelectorAll('[data-overview-item]').forEach(function (card) {
      var id = card.getAttribute('data-overview-item');
      card.classList.toggle('is-hidden', !!set[id]);
    });
    widget.querySelectorAll('[data-overview-toggle]').forEach(function (input) {
      var id = input.getAttribute('data-overview-toggle');
      input.checked = !set[id];
      syncToggleState(input);
    });
  }

  function collectHidden(widget) {
    var hidden = [];
    widget.querySelectorAll('[data-overview-toggle]').forEach(function (input) {
      if (!input.checked) {
        hidden.push(input.getAttribute('data-overview-toggle'));
      }
    });
    return hidden;
  }

  function saveHidden(hidden) {
    var c = cfg();
    if (!c.ajaxUrl || !c.nonce) {
      return Promise.resolve();
    }
    var body = new URLSearchParams();
    body.set('action', 'yooadmin_overview_save_prefs');
    body.set('nonce', c.nonce);
    body.set('hidden', JSON.stringify(hidden));
    return fetch(c.ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString(),
    }).then(function (res) {
      return res.json();
    });
  }

  function bindWidget(widget) {
    if (!widget) {
      return;
    }
    syncWidgetState(widget);
    widget.setAttribute('data-overview-bound', '1');
  }

  function initAll(root) {
    var scope = root && root.querySelectorAll ? root : document;
    scope.querySelectorAll('.yooadmin-overview-widget[data-overview-widget]').forEach(bindWidget);
  }

  document.addEventListener('click', function (e) {
    var toggleBtn = e.target.closest('[data-overview-customize-toggle]');
    if (toggleBtn) {
      e.preventDefault();
      var widget = toggleBtn.closest('[data-overview-widget]');
      if (!widget) {
        return;
      }
      var panel = widget.querySelector('[data-overview-customize-panel]');
      if (!panel) {
        return;
      }
      var open = panel.hasAttribute('hidden');
      if (open) {
        syncWidgetState(widget);
        panel.removeAttribute('hidden');
        toggleBtn.setAttribute('aria-expanded', 'true');
        widget.classList.add('is-customize-open');
      } else {
        panel.setAttribute('hidden', 'hidden');
        toggleBtn.setAttribute('aria-expanded', 'false');
        widget.classList.remove('is-customize-open');
      }
      return;
    }

    var saveBtn = e.target.closest('[data-overview-save]');
    if (saveBtn) {
      e.preventDefault();
      var wSave = saveBtn.closest('[data-overview-widget]');
      if (!wSave) {
        return;
      }
      var hidden = collectHidden(wSave);
      applyHidden(wSave, hidden);
      saveBtn.disabled = true;
      saveHidden(hidden)
        .catch(function () {})
        .finally(function () {
          saveBtn.disabled = false;
          var panel = wSave.querySelector('[data-overview-customize-panel]');
          var toggle = wSave.querySelector('[data-overview-customize-toggle]');
          if (panel) {
            panel.setAttribute('hidden', 'hidden');
          }
          if (toggle) {
            toggle.setAttribute('aria-expanded', 'false');
          }
          wSave.classList.remove('is-customize-open');
        });
      return;
    }

    var resetBtn = e.target.closest('[data-overview-reset]');
    if (resetBtn) {
      e.preventDefault();
      var wReset = resetBtn.closest('[data-overview-widget]');
      if (!wReset) {
        return;
      }
      var defaultHidden = getDefaultHidden();
      applyHidden(wReset, defaultHidden);
      saveHidden(defaultHidden);
    }
  });

  document.addEventListener('change', function (e) {
    var input = e.target;
    if (!input || !input.matches || !input.matches('[data-overview-toggle]')) {
      return;
    }
    var widget = input.closest('[data-overview-widget]');
    if (widget) {
      applyHidden(widget, collectHidden(widget));
    }
  });

  document.addEventListener('yooadmin-overview-widget-loaded', function () {
    initAll();
  });

  document.addEventListener('yooadmin-studio-hub-widget-rendered', function (e) {
    var detail = e && e.detail ? e.detail : {};
    if (detail.widgetId !== 'yooadmin_overview') {
      return;
    }
    if (detail.body && detail.body.querySelector) {
      initAll(detail.body);
      return;
    }
    initAll();
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      initAll();
    });
  } else {
    initAll();
  }

  window.YOOAdminOverviewWidget = { init: initAll, sync: syncWidgetState };
})();
