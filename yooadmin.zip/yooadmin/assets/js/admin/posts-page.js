/**
 * YOOAdmin - Posts page script
 *
 * @package YOOAdmin
 */

(function ($) {
    'use strict';

    function initListScreenUi(root) {
        if (window.yooadminUiSelect && typeof window.yooadminUiSelect.initIn === 'function') {
            window.yooadminUiSelect.initIn(root || document);
        }
    }

    // View Toggle
    function initViewToggle() {
        var storageKey = 'yooadmin_posts_view';
        var $cardsBtn = $('.yoo-view-btn--cards');
        var $tableBtn = $('.yoo-view-btn--table');
        var $content = $('#yoo-posts-content');

        // Get saved preference
        var savedView = localStorage.getItem(storageKey) || 'cards';

        // Set initial view
        if (savedView === 'table') {
            $content.removeClass('yoo-view-cards').addClass('yoo-view-table');
            $cardsBtn.removeClass('is-active');
            $tableBtn.addClass('is-active');
        } else {
            $content.removeClass('yoo-view-table').addClass('yoo-view-cards');
            $cardsBtn.addClass('is-active');
            $tableBtn.removeClass('is-active');
        }

        // Toggle handlers
        $cardsBtn.on('click', function () {
            $content.removeClass('yoo-view-table').addClass('yoo-view-cards');
            $cardsBtn.addClass('is-active');
            $tableBtn.removeClass('is-active');
            localStorage.setItem(storageKey, 'cards');
            if (postsViewNeedsSync('cards') && window.yooadmApplyPostsFilters) {
                window.yooadmApplyPostsFilters();
            }
        });

        $tableBtn.on('click', function () {
            $content.removeClass('yoo-view-cards').addClass('yoo-view-table');
            $tableBtn.addClass('is-active');
            $cardsBtn.removeClass('is-active');
            localStorage.setItem(storageKey, 'table');
            if (postsViewNeedsSync('table') && window.yooadmApplyPostsFilters) {
                window.yooadmApplyPostsFilters();
            }
        });
    }

    function postsViewNeedsSync(view) {
        var $content = $('#yoo-posts-content');
        if (!$content.length || $content.find('.yoo-posts-empty').length) {
            return false;
        }

        var hasCards = $content.find('.yoo-posts-grid .yoo-post-card').length > 0;
        var hasRows = $content.find('.yoo-posts-table tbody tr.yoo-post-row').length > 0;

        if (view === 'table') {
            return !hasRows && hasCards;
        }

        return !hasCards && hasRows;
    }

    // Table Sorting
    function initTableSorting() {
        var currentSort = {
            column: 'title',
            order: 'desc'
        };

        $('.yoo-posts-table .sortable').on('click', function (e) {
            e.preventDefault();
            var $th = $(this);
            var column = $th.data('sort');
            var $table = $('.yoo-posts-table table');
            var $tbody = $table.find('tbody');
            var $rows = $tbody.find('tr').toArray();

            // Toggle sort order if same column
            if (currentSort.column === column) {
                currentSort.order = currentSort.order === 'asc' ? 'desc' : 'asc';
            } else {
                currentSort.column = column;
                currentSort.order = 'desc';
            }

            // Update UI
            $('.sortable').removeClass('sort-asc sort-desc');
            $th.addClass('sort-' + currentSort.order);

            // Sort rows
            $rows.sort(function (a, b) {
                var aVal, bVal;

                if (column === 'title') {
                    aVal = $(a).data('title') || '';
                    bVal = $(b).data('title') || '';
                } else if (column === 'date') {
                    aVal = parseInt($(a).data('date')) || 0;
                    bVal = parseInt($(b).data('date')) || 0;
                }

                if (currentSort.order === 'asc') {
                    return aVal > bVal ? 1 : (aVal < bVal ? -1 : 0);
                } else {
                    return aVal < bVal ? 1 : (aVal > bVal ? -1 : 0);
                }
            });

            // Re-append sorted rows
            $.each($rows, function (index, row) {
                $tbody.append(row);
            });
        });
    }

    // Image Lightbox
    function initImageLightbox() {
        var $lightbox = $('#yoo-image-lightbox');
        var $overlay = $('.yoo-lightbox-overlay');
        var $close = $('.yoo-lightbox-close');
        var $image = $('.yoo-lightbox-image');
        var $title = $('.yoo-lightbox-title');

        // Open lightbox
        $(document).on('click', '.yoo-image-lightbox-trigger', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var imageUrl = $(this).data('image-url');
            var imageTitle = $(this).data('image-title') || '';

            $image.attr('src', imageUrl).attr('alt', imageTitle);
            $title.text(imageTitle);
            $lightbox.fadeIn(200);
            $('body').css('overflow', 'hidden');
        });

        // Close lightbox
        function closeLightbox() {
            $lightbox.fadeOut(200);
            $('body').css('overflow', '');
        }

        $close.on('click', closeLightbox);
        $overlay.on('click', closeLightbox);

        // Close on ESC key
        $(document).on('keydown', function (e) {
            if (e.key === 'Escape' && $lightbox.is(':visible')) {
                closeLightbox();
            }
        });
    }

    function ensurePostsListContainers($content) {
        if (!$content.find('.yoo-posts-grid').length) {
            $content.append('<div class="yoo-posts-grid yoo-view-cards"></div>');
        }

        if (!$content.find('.yoo-posts-table tbody').length) {
            if (!$content.find('.yoo-posts-table').length) {
                $content.append(
                    '<div class="yoo-posts-table yoo-view-table">' +
                    '<table class="wp-list-table widefat fixed striped table-view-list" style="width: 100%;">' +
                    '<thead><tr>' +
                    '<th scope="col" class="manage-column column-cb check-column">' +
                    '<input type="checkbox" id="yoo-select-all-posts-table" class="yoo-checkbox">' +
                    '</th>' +
                    '<th scope="col" class="manage-column column-thumbnail"></th>' +
                    '<th scope="col" class="manage-column column-title column-primary sortable sort-desc" data-sort="title">' +
                    '<a href="#" class="yoo-sort-link"><span>Title</span><span class="sorting-indicator"></span></a></th>' +
                    '<th scope="col" class="manage-column column-author"></th>' +
                    '<th scope="col" class="manage-column column-categories"></th>' +
                    '<th scope="col" class="manage-column column-tags"></th>' +
                    '<th scope="col" class="manage-column column-date sortable" data-sort="date">' +
                    '<a href="#" class="yoo-sort-link"><span>Date</span><span class="sorting-indicator"></span></a></th>' +
                    '<th scope="col" class="manage-column column-comments"></th>' +
                    '<th scope="col" class="manage-column column-status"></th>' +
                    '</tr></thead><tbody></tbody></table></div>'
                );
            } else {
                $content.find('.yoo-posts-table table').append('<tbody></tbody>');
            }
        }
    }

    function renderPostsFilterResult($content, data) {
        $content.find('.yoo-posts-empty').remove();
        $content.find('.yoo-posts-pagination').remove();

        var total = typeof data.total === 'number' ? data.total : null;
        var cardsHtml = data.cards_html || '';
        var tableHtml = data.table_html || '';
        var emptyHtml = data.empty_html || '';
        var paginationHtml = data.pagination_html || '';

        // Legacy single-view payload (html only)
        if (!cardsHtml && !tableHtml && !emptyHtml && data.html) {
            var $legacy = $('<div>').html(data.html);
            var $legacyEmpty = $legacy.find('.yoo-posts-empty').first();
            if ($legacyEmpty.length) {
                emptyHtml = $legacyEmpty.prop('outerHTML');
            } else {
                cardsHtml = data.html;
            }
            var $legacyPagination = $legacy.find('.yoo-posts-pagination');
            if ($legacyPagination.length) {
                paginationHtml = $legacyPagination.prop('outerHTML');
            }
        }

        if (total === 0 || emptyHtml) {
            $content.find('.yoo-posts-grid').empty();
            $content.find('.yoo-posts-table tbody').empty();
            if (emptyHtml) {
                $content.append(emptyHtml);
            }
            return;
        }

        ensurePostsListContainers($content);
        $content.find('.yoo-posts-grid').html(cardsHtml);
        $content.find('.yoo-posts-table tbody').html(tableHtml);

        if (paginationHtml) {
            $content.append(paginationHtml);
        }
    }

    // Infinite Scroll
    function initInfiniteScroll() {
        var isLoading = false;
        var currentPage = parseInt($('.yoo-posts-pagination .yoo-pagination-current').text(), 10) || 1;
        var hasMorePages = $('.yoo-posts-pagination .yoo-pagination-next').length > 0;
        var $content = $('#yoo-posts-content');

        function getPostsView() {
            return $content.hasClass('yoo-view-table') ? 'table' : 'cards';
        }

        // Match filter state with yooadmApplyPostsFilters (chips + dropdowns)
        function getFilters() {
            var status = $('.yoo-filter-chip.is-active').data('status') || '';
            var search = $('#yoo-posts-search-input').val() || '';
            var author = $('.yoo-filter-btn--author').data('value') || '';
            var statusFilter = $('.yoo-filter-btn--status').data('value') || '';

            if (statusFilter) {
                status = statusFilter;
            }

            status = status || '';

            return {
                post_status: status,
                s: search,
                category: '',
                author: author
            };
        }

        // Load more posts
        function loadMorePosts() {
            if (isLoading || !hasMorePages) return;

            var view = getPostsView();
            isLoading = true;
            currentPage++;

            // Show loading indicator
            var $loading = $('<div class="yoo-loading-more"><span class="spinner is-active"></span> <span>' + (view === 'cards' ? 'Loading posts...' : 'Loading rows...') + '</span></div>');

            if (view === 'table') {
                $('.yoo-posts-table tbody').append($loading);
            } else {
                $('.yoo-posts-grid').append($loading);
            }

            var filters = getFilters();

            $.ajax({
                url: yooadmPosts.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_load_more_posts',
                    nonce: yooadmPosts.nonce,
                    paged: currentPage,
                    view: view,
                    post_status: filters.post_status,
                    s: filters.s,
                    category: filters.category,
                    author: filters.author
                },
                success: function (response) {
                    if (response.success) {
                        view = getPostsView();
                        if (view === 'table') {
                            $('.yoo-posts-table tbody .yoo-loading-more').remove();
                            $('.yoo-posts-table tbody').append(response.data.html);
                        } else {
                            $('.yoo-posts-grid .yoo-loading-more').remove();
                            $('.yoo-posts-grid').append(response.data.html);
                        }

                        hasMorePages = response.data.has_more;

                        // Reinitialize lightbox for new images
                        // (lightbox is already bound to document, so it will work automatically)

                        // Reinitialize checkboxes
                        updateBulkBar();

                        isLoading = false;

                        // Update pagination indicator
                        if (!hasMorePages) {
                            $('.yoo-posts-pagination').hide();
                        }

                        // Short page: no scrollbar — load more until content fills or no pages left
                        setTimeout(function tryFillViewport() {
                            if (isLoading || !hasMorePages) return;
                            var docH = $(document).height();
                            var winH = $(window).height();
                            if (docH <= winH + 400) {
                                loadMorePosts();
                            }
                        }, 150);
                    } else {
                        isLoading = false;
                        currentPage--;
                        $('.yoo-loading-more').remove();
                        alert(response.data.message || 'Error loading more posts');
                    }
                },
                error: function () {
                    isLoading = false;
                    currentPage--;
                    $('.yoo-loading-more').remove();
                    alert('Error loading more posts');
                }
            });
        }

        // Scroll handler
        var scrollTimeout;
        $(window).on('scroll', function () {
            if (scrollTimeout) {
                clearTimeout(scrollTimeout);
            }

            scrollTimeout = setTimeout(function () {
                if (isLoading || !hasMorePages) return;

                var scrollTop = $(window).scrollTop();
                var windowHeight = $(window).height();
                var documentHeight = $(document).height();

                // Load more when 300px from bottom
                if (scrollTop + windowHeight > documentHeight - 300) {
                    loadMorePosts();
                }
            }, 100);
        });

        // If first page is shorter than the viewport, fetch more rows without requiring scroll
        $(window).on('load', function () {
            setTimeout(function () {
                if (isLoading || !hasMorePages) return;
                var docH = $(document).height();
                var winH = $(window).height();
                if (docH <= winH + 400) {
                    loadMorePosts();
                }
            }, 400);
        });

        var yooadmApplyPostsFilters = function () {
            var status = $('.yoo-filter-chip.is-active').data('status') || '';
            var search = $('#yoo-posts-search-input').val() || '';
            var author = $('.yoo-filter-btn--author').data('value') || '';
            var statusFilter = $('.yoo-filter-btn--status').data('value') || '';

            // Use dropdown filter if exists
            if (statusFilter) {
                status = statusFilter;
            }

            // Ensure status is empty string when no filter is active
            status = status || '';

            // Clear status if both are empty (user cleared all filters)
            if (!status && !statusFilter && !author && !search) {
                status = '';
                // Also clear the active chip and make sure "All" is active
                $('.yoo-filter-chip').removeClass('is-active');
                $('.yoo-filter-chip[data-status=""]').addClass('is-active');
            }

            // Show loading
            var $content = $('#yoo-posts-content');
            $content.css('opacity', '0.5').css('pointer-events', 'none');

            $.ajax({
                url: yooadmPosts.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_filter_posts',
                    nonce: yooadmPosts.nonce,
                    post_status: status || '',
                    s: search || '',
                    author: author || '',
                    paged: 1
                },
                success: function (response) {
                    if (response.success) {
                        renderPostsFilterResult($content, response.data || {});

                        // Reinitialize
                        initImageLightbox();
                        if (window.initCheckboxes) {
                            window.initCheckboxes();
                        }
                        if (window.updateBulkBar) {
                            setTimeout(function () {
                                window.updateBulkBar();
                            }, 100);
                        }

                        // Update URL without reload
                        var url = new URL(window.location.href);
                        if (status) {
                            url.searchParams.set('post_status', status);
                        } else {
                            url.searchParams.delete('post_status');
                        }
                        if (author) {
                            url.searchParams.set('author', author);
                        } else {
                            url.searchParams.delete('author');
                        }
                        if (search) {
                            url.searchParams.set('s', search);
                        } else {
                            url.searchParams.delete('s');
                        }
                        url.searchParams.delete('paged');
                        window.history.pushState({}, '', url);

                        if (response.data.total_pages !== undefined) {
                            currentPage = 1;
                            hasMorePages = parseInt(response.data.total_pages, 10) > 1;
                            if (!hasMorePages) {
                                $('.yoo-posts-pagination').hide();
                            } else {
                                $('.yoo-posts-pagination').show();
                            }
                        }
                    } else {
                        if (window.showNotice) {
                            window.showNotice('error', response.data.message || 'Error filtering posts');
                        }
                    }
                },
                error: function () {
                    if (window.showNotice) {
                        window.showNotice('error', 'An error occurred while filtering. Please try again.');
                    }
                },
                complete: function () {
                    $content.css('opacity', '1').css('pointer-events', 'auto');
                }
            });
        };

        window.yooadmApplyPostsFilters = yooadmApplyPostsFilters;

        // Update hasMorePages when search changes (with debounce)
        var searchTimeout;
        $('#yoo-posts-search-input').on('keyup input search', function () {
            clearTimeout(searchTimeout);
            var $input = $(this);
            searchTimeout = setTimeout(function () {
                yooadmApplyPostsFilters();
            }, 500);
        });

        // Filter dropdown handlers
        $(document).on('click', '.yoo-filter-btn', function (e) {
            // Don't toggle if clicking remove button (has its own handler)
            if ($(e.target).closest('.yoo-filter-remove').length) {
                return;
            }

            e.preventDefault();
            e.stopPropagation();

            var $btn = $(this);
            var $wrapper = $btn.closest('.yoo-filter-dropdown-wrapper');
            var $dropdown = $wrapper.find('.yoo-filter-dropdown');

            // Close other dropdowns
            $('.yoo-filter-dropdown-wrapper').not($wrapper).removeClass('is-open');

            // Toggle current dropdown
            $wrapper.toggleClass('is-open');
        });

        // Close dropdowns when clicking outside
        $(document).on('click', function (e) {
            if (!$(e.target).closest('.yoo-filter-dropdown-wrapper').length) {
                $('.yoo-filter-dropdown-wrapper').removeClass('is-open');
            }
        });

        // Filter option click (dropdown)
        $(document).on('click', '.yoo-filter-option', function (e) {
            e.preventDefault();
            e.stopPropagation();

            var $option = $(this);
            var filterType = $option.data('filter');
            var value = $option.data('value') || '';
            var label = $option.text().trim();

            var $btn = $('.yoo-filter-btn--' + filterType);
            var $wrapper = $btn.closest('.yoo-filter-dropdown-wrapper');

            // Update button
            $btn.data('value', value);
            $btn.find('.yoo-filter-label').text(label);

            // Update active state
            if (value) {
                $btn.addClass('is-active');
                // Add remove button if not exists
                if (!$btn.find('.yoo-filter-remove').length) {
                    $btn.find('.yoo-filter-label').after(
                        '<span class="yoo-filter-remove" data-filter="' + filterType + '" title="Clear filter">' +
                        '<span class="dashicons dashicons-no-alt"></span></span>'
                    );
                }
            } else {
                $btn.removeClass('is-active');
                $btn.find('.yoo-filter-remove').remove();
            }

            // Update selected state in dropdown
            $wrapper.find('.yoo-filter-option').removeClass('is-selected');
            $option.addClass('is-selected');

            // Close dropdown
            $wrapper.removeClass('is-open');

            // Apply filters
            yooadmApplyPostsFilters();
        });

        // Remove filter button
        $(document).on('click', '.yoo-filter-remove', function (e) {
            e.preventDefault();
            e.stopPropagation();

            var $remove = $(this);
            var filterType = $remove.data('filter');
            var $btn = $('.yoo-filter-btn--' + filterType);
            var $wrapper = $btn.closest('.yoo-filter-dropdown-wrapper');

            // Reset button
            var defaultLabel = filterType === 'status' ? 'Status' : 'Author';
            $btn.data('value', '');
            $btn.find('.yoo-filter-label').text(defaultLabel);
            $btn.removeClass('is-active');
            $remove.remove();

            // Reset dropdown selection
            $wrapper.find('.yoo-filter-option[data-value=""]').addClass('is-selected');
            $wrapper.find('.yoo-filter-option').not('[data-value=""]').removeClass('is-selected');

            // Clear the active chip to show all posts
            if (filterType === 'status') {
                $('.yoo-filter-chip').removeClass('is-active');
                $('.yoo-filter-chip[data-status=""]').addClass('is-active');
            }

            // Apply filters to show all posts
            setTimeout(function () {
                if (window.yooadmApplyPostsFilters) {
                    window.yooadmApplyPostsFilters();
                }
            }, 100);
        });

        // Filter chips click (convert to AJAX)
        $(document).on('click', '.yoo-filter-chip', function (e) {
            e.preventDefault();
            var $chip = $(this);
            var status = $chip.data('status') || '';

            // Update active state
            $('.yoo-filter-chip').removeClass('is-active');
            $chip.addClass('is-active');

            // Clear status filter if chip is used
            if (status !== $('.yoo-filter-btn--status').data('value')) {
                var $statusBtn = $('.yoo-filter-btn--status');
                $statusBtn.data('value', '');
                $statusBtn.find('.yoo-filter-label').text('Status');
                $statusBtn.removeClass('is-active');
                $statusBtn.find('.yoo-filter-remove').remove();
                $('.yoo-filter-dropdown-wrapper').eq(0).find('.yoo-filter-option[data-value=""]').addClass('is-selected');
            }

            // Apply filters
            yooadmApplyPostsFilters();
        });

        // Update when view changes (same pagination; view is read live in loadMorePosts)
        $('.yoo-view-btn').on('click', function () {
            setTimeout(function () {
                hasMorePages = $('.yoo-posts-pagination .yoo-pagination-next').length > 0;
                currentPage = parseInt($('.yoo-posts-pagination .yoo-pagination-current').text(), 10) || 1;
            }, 100);
        });
    }

    function showNotice(type, message, duration) {
        if (window.yooadminShowToast && typeof window.yooadminShowToast === 'function') {
            window.yooadminShowToast(message, type, duration);
            return;
        }
        if (window.yooadminListScreenToast && typeof window.yooadminListScreenToast.show === 'function') {
            window.yooadminListScreenToast.show(type, message, duration);
            return;
        }
    }

    window.showNotice = showNotice;

    // Metrics Toggle
    function initMetricsToggle() {
        var $toggle = $('.yoo-posts-metrics-toggle');
        var $metrics = $('.yoo-posts-hero__metrics');
        var storageKey = 'yooadmin_posts_metrics_expanded';

        // Get saved preference
        var isExpanded = localStorage.getItem(storageKey) === 'true';

        // Set initial state
        if (isExpanded) {
            $metrics.addClass('is-visible');
            $toggle.addClass('is-expanded').attr('aria-expanded', 'true');
            $toggle.find('span:last-child').text(yooadmPosts.i18n.hideStatistics || 'Hide Statistics');
        } else {
            $metrics.removeClass('is-visible');
            $toggle.removeClass('is-expanded').attr('aria-expanded', 'false');
            $toggle.find('span:last-child').text(yooadmPosts.i18n.showStatistics || 'Show Statistics');
        }

        // Toggle handler
        $toggle.on('click', function () {
            var isCurrentlyExpanded = $metrics.hasClass('is-visible');

            if (isCurrentlyExpanded) {
                $metrics.removeClass('is-visible');
                $toggle.removeClass('is-expanded').attr('aria-expanded', 'false');
                $toggle.find('span:last-child').text(yooadmPosts.i18n.showStatistics || 'Show Statistics');
                localStorage.setItem(storageKey, 'false');
            } else {
                $metrics.addClass('is-visible');
                $toggle.addClass('is-expanded').attr('aria-expanded', 'true');
                $toggle.find('span:last-child').text(yooadmPosts.i18n.hideStatistics || 'Hide Statistics');
                localStorage.setItem(storageKey, 'true');
            }
        });
    }

    $(document).ready(function () {
        initViewToggle();
        initTableSorting();
        initImageLightbox();
        initInfiniteScroll();
        initMetricsToggle();
        initListScreenUi(document.querySelector('.yooadmin-posts-page'));

        // Bulk actions
        var $checkboxes = $('.yoo-post-checkbox');
        var $selectAll = $('#yoo-select-all-posts');
        var $bulkBar = $('.yoo-bulk-actions-bar');
        var $selectedCount = $('.yoo-selected-count');
        var $bulkApply = $('#yoo-bulk-apply');
        var $bulkSelect = $('#yoo-bulk-action-select');

        // Initialize checkboxes
        function initCheckboxes() {
            $('.yoo-post-checkbox').off('change.bulk').on('change.bulk', function () {
                updateBulkBar();
            });
        }

        function updateBulkBar() {
            var selected = $('.yoo-post-checkbox:checked').length;
            if (selected > 0) {
                $bulkBar.addClass('show');
                $selectedCount.text(selected + ' ' + (yooadmPosts.i18n.selected || 'selected'));
                $bulkApply.prop('disabled', !$bulkSelect.val());
            } else {
                $bulkBar.removeClass('show');
            }
        }

        initCheckboxes();
        $checkboxes.on('change', updateBulkBar);
        $selectAll.on('change', function () {
            $('.yoo-post-checkbox').prop('checked', $(this).prop('checked'));
            updateBulkBar();
        });

        // Make functions available globally for AJAX calls
        window.updateBulkBar = updateBulkBar;
        window.initCheckboxes = initCheckboxes;

        $bulkSelect.on('change', function () {
            $bulkApply.prop('disabled', !$(this).val());
        });

        // Show delete confirmation popup
        var i18n = yooadmPosts.i18n || {};
        function showDeleteConfirmPopup($btn, $card, postTitle, postId, action) {
            var actionText = action === 'delete' ? (i18n.delete || 'Delete') : (action === 'trash' ? (i18n.moveToTrash || 'Move to Trash') : (i18n.restore || 'Restore'));
            var titleText = action === 'delete' ? (i18n.deletePostTitle || 'Delete Post?') : (action === 'trash' ? (i18n.moveToTrashTitle || 'Move to Trash?') : (i18n.restorePostTitle || 'Restore Post?'));
            var msgFmt = action === 'delete' ? (i18n.deleteConfirmMsg || 'Are you sure you want to delete %s? This action cannot be undone.')
                : (action === 'trash' ? (i18n.moveToTrashConfirmMsg || 'Are you sure you want to move %s to trash?') : (i18n.restoreConfirmMsg || 'Are you sure you want to restore %s?'));
            var messageText = msgFmt.replace(/%s/, '<strong>' + postTitle + '</strong>');

            // Create popup HTML
            var cancelLabel = i18n.cancel || 'Cancel';
            var $popup = $(
                '<div class="yoo-delete-popup-overlay">' +
                '<div class="yoo-delete-popup">' +
                '<div class="yoo-delete-popup-icon">' +
                '<span class="dashicons dashicons-warning"></span>' +
                '</div>' +
                '<h3>' + titleText + '</h3>' +
                '<p>' + messageText + '</p>' +
                '<div class="yoo-delete-popup-actions">' +
                '<button class="yoo-popup-btn yoo-popup-cancel">' + cancelLabel + '</button>' +
                '<button class="yoo-popup-btn yoo-popup-delete">' + actionText + '</button>' +
                '</div>' +
                '</div>' +
                '</div>'
            );

            // Append to body
            $('body').append($popup);

            // Fade in
            setTimeout(function () {
                $popup.addClass('visible');
            }, 10);

            // Handle cancel
            $popup.find('.yoo-popup-cancel').on('click', function () {
                $popup.removeClass('visible');
                setTimeout(function () {
                    $popup.remove();
                }, 300);
            });

            // Handle delete/trash/restore
            $popup.find('.yoo-popup-delete').on('click', function () {
                var $deleteBtn = $(this);
                $deleteBtn.prop('disabled', true).text(action === 'delete' ? (i18n.deleting || 'Deleting...') : (action === 'trash' ? (i18n.moving || 'Moving...') : (i18n.restoring || 'Restoring...')));

                // Send AJAX request
                $.ajax({
                    url: yooadmPosts.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'yooadmin_posts_action',
                        post_action: action,
                        post_id: postId,
                        nonce: yooadmPosts.nonce
                    },
                    success: function (response) {
                        if (response.success) {
                            // Close popup
                            $popup.removeClass('visible');
                            setTimeout(function () {
                                $popup.remove();
                            }, 300);

                            // Show success message FIRST
                            var message = '';
                            if (action === 'delete') {
                                message = i18n.postDeleted || 'Post deleted permanently.';
                            } else if (action === 'trash') {
                                message = i18n.postMovedToTrash || 'Post moved to trash.';
                            } else if (action === 'restore') {
                                message = i18n.postRestored || 'Post restored.';
                            }

                            // Update counts immediately
                            updatePostCounts();

                            // Remove or update card/row
                            if ($card && $card.length) {
                                $card.fadeOut(300, function () {
                                    $(this).remove();
                                    // Show notice AFTER removing card
                                    if (window.showNotice) {
                                        window.showNotice('success', message);
                                    }
                                    // Reload filters to update content (notice will be preserved)
                                    setTimeout(function () {
                                        yooadmApplyPostsFilters();
                                    }, 100);
                                });
                            } else {
                                // Show notice immediately
                                if (window.showNotice) {
                                    window.showNotice('success', message);
                                }
                                // Reload filters if card not found (notice will be preserved)
                                setTimeout(function () {
                                    yooadmApplyPostsFilters();
                                }, 100);
                            }
                        } else {
                            if (window.showNotice) {
                                window.showNotice('error', response.data.message || 'Error occurred');
                            }
                            $deleteBtn.prop('disabled', false).text(actionText);
                        }
                    },
                    error: function () {
                        if (window.showNotice) {
                            window.showNotice('error', 'An error occurred. Please try again.');
                        }
                        $deleteBtn.prop('disabled', false).text(actionText);
                    }
                });
            });

            // Close on overlay click
            $popup.on('click', function (e) {
                if ($(e.target).hasClass('yoo-delete-popup-overlay')) {
                    $popup.removeClass('visible');
                    setTimeout(function () {
                        $popup.remove();
                    }, 300);
                }
            });
        }

        // Function to update post counts in tabs and metrics
        function updatePostCounts() {
            $.ajax({
                url: yooadmPosts.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_get_post_counts',
                    nonce: yooadmPosts.nonce
                },
                success: function (response) {
                    if (response.success && response.data) {
                        var counts = response.data;

                        // Note: Notification sound is now handled centrally by the notification system
                        // which checks for badge/version increases automatically

                        // Helper function to format numbers
                        function formatNumber(num) {
                            return parseInt(num, 10).toLocaleString();
                        }

                        // Update filter chips counts
                        $('.yoo-filter-chip[data-status=""] .yoo-filter-count').text(formatNumber(counts.total_count));
                        $('.yoo-filter-chip[data-status="publish"] .yoo-filter-count').text(formatNumber(counts.publish_count));
                        $('.yoo-filter-chip[data-status="draft"] .yoo-filter-count').text(formatNumber(counts.draft_count));
                        $('.yoo-filter-chip[data-status="trash"] .yoo-filter-count').text(formatNumber(counts.trash_count));

                        // Update metrics in hero section
                        $('.yoo-posts-hero__metrics .yoo-posts-metric').each(function () {
                            var $metric = $(this);
                            var $icon = $metric.find('.dashicons');

                            if ($icon.hasClass('dashicons-admin-post')) {
                                $metric.find('.yoo-posts-metric__value').text(formatNumber(counts.total_count));
                            } else if ($icon.hasClass('dashicons-yes')) {
                                $metric.find('.yoo-posts-metric__value').text(formatNumber(counts.publish_count));
                            } else if ($icon.hasClass('dashicons-edit')) {
                                $metric.find('.yoo-posts-metric__value').text(formatNumber(counts.draft_count));
                            }
                        });
                    }
                }
            });
        }

        // Make updatePostCounts available globally
        window.updatePostCounts = updatePostCounts;

        // Initialize draft count on page load
        $(document).ready(function () {
            // Store initial draft count
            var initialDraftCount = parseInt($('.yoo-filter-chip[data-status="draft"] .yoo-filter-count').text().replace(/,/g, '') || '0', 10);
            if (initialDraftCount > 0) {
                localStorage.setItem('yooadmin_last_draft_count', initialDraftCount.toString());
            }
        });

        // Individual actions (cards view)
        $(document).on('click', '.yoo-action-btn.trash, .yoo-action-btn.delete, .yoo-action-btn.restore', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var $card = $btn.closest('.yoo-post-card');
            var postId = $btn.data('post-id');
            var action = $btn.hasClass('trash') ? 'trash' : ($btn.hasClass('restore') ? 'restore' : 'delete');
            var postTitle = $card.find('.yoo-post-title a').text() || 'this post';

            showDeleteConfirmPopup($btn, $card, postTitle, postId, action);
        });

        // Individual actions (table view)
        $(document).on('click', '.yoo-action-link.trash, .yoo-action-link.delete, .yoo-action-link.restore', function (e) {
            e.preventDefault();
            var $link = $(this);
            var $row = $link.closest('tr.yoo-post-row');
            var postId = $link.data('post-id');
            var action = $link.hasClass('trash') ? 'trash' : ($link.hasClass('restore') ? 'restore' : 'delete');
            var postTitle = $row.find('.row-title').text() || 'this post';

            showDeleteConfirmPopup($link, $row, postTitle, postId, action);
        });

        // Draft / Publish (no trash confirm — same as Quick Edit; no full page reload)
        function runPostStatusAction(postId, action, onAlways) {
            var msg = action === 'draft' ? (i18n.postMovedToDraft || 'Post moved to draft.') : (i18n.postPublished || 'Post published.');
            $.ajax({
                url: yooadmPosts.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_posts_action',
                    post_action: action,
                    post_id: postId,
                    nonce: yooadmPosts.nonce
                },
                success: function (response) {
                    if (typeof onAlways === 'function') {
                        onAlways();
                    }
                    if (response.success) {
                        if (window.showNotice) {
                            window.showNotice('success', response.data && response.data.message ? response.data.message : msg);
                        }
                        if (typeof updatePostCounts === 'function') {
                            updatePostCounts();
                        }
                        if (window.yooadmApplyPostsFilters) {
                            window.yooadmApplyPostsFilters();
                        }
                    } else if (window.showNotice) {
                        window.showNotice('error', (response.data && response.data.message) || (i18n.error || 'Error'));
                    }
                },
                error: function () {
                    if (typeof onAlways === 'function') {
                        onAlways();
                    }
                    if (window.showNotice) {
                        window.showNotice('error', i18n.error || 'An error occurred. Please try again.');
                    }
                }
            });
        }

        $(document).on('click', '.yoo-action-btn.to-draft, .yoo-action-btn.to-publish', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var postId = $btn.data('post-id');
            var action = $btn.hasClass('to-draft') ? 'draft' : 'publish';
            $btn.prop('disabled', true);
            runPostStatusAction(postId, action, function () {
                $btn.prop('disabled', false);
            });
        });

        $(document).on('click', '.yoo-action-link.to-draft, .yoo-action-link.to-publish', function (e) {
            e.preventDefault();
            var $link = $(this);
            if ($link.data('processing')) {
                return;
            }
            var postId = $link.data('post-id');
            var action = $link.hasClass('to-draft') ? 'draft' : 'publish';
            $link.data('processing', 1).css('pointer-events', 'none').css('opacity', '0.55');
            runPostStatusAction(postId, action, function () {
                $link.removeData('processing').css('pointer-events', '').css('opacity', '');
            });
        });

        // Select all for table view
        $('#yoo-select-all-posts-table').on('change', function () {
            $('.yoo-posts-table .yoo-post-checkbox').prop('checked', $(this).prop('checked'));
            updateBulkBar();
        });

        // Bulk apply
        $bulkApply.on('click', function () {
            var action = $bulkSelect.val();
            if (!action) return;

            var selected = $checkboxes.filter(':checked').map(function () {
                return $(this).val();
            }).get();

            if (selected.length === 0) return;

            var $applyBtn = $(this);
            $applyBtn.prop('disabled', true).text('Processing...');

            $.ajax({
                url: yooadmPosts.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_bulk_posts_action',
                    bulk_action: action,
                    posts: selected,
                    nonce: yooadmPosts.nonce
                },
                success: function (response) {
                    if (response.success) {
                        // Show success message
                        var message = '';
                        var count = selected.length;
                        if (action === 'delete') {
                            message = count === 1 ? (i18n.postDeleted || 'Post deleted permanently.') : ((i18n.postsDeleted || '%d posts deleted permanently.').replace(/%d/, count));
                        } else if (action === 'trash') {
                            message = count === 1 ? (i18n.postMovedToTrash || 'Post moved to trash.') : ((i18n.postsMovedToTrash || '%d posts moved to trash.').replace(/%d/, count));
                        } else if (action === 'restore') {
                            message = count === 1 ? (i18n.postRestored || 'Post restored.') : ((i18n.postsRestored || '%d posts restored.').replace(/%d/, count));
                        }

                        if (window.showNotice) {
                            window.showNotice('success', message);
                        }

                        // Update counts immediately
                        updatePostCounts();

                        // Reload filters to update content
                        setTimeout(function () {
                            yooadmApplyPostsFilters();
                        }, 500);
                    } else {
                        if (window.showNotice) {
                            window.showNotice('error', response.data.message || (i18n.error || 'Error occurred'));
                        }
                        $applyBtn.prop('disabled', false).text(i18n.apply || 'Apply');
                    }
                },
                error: function () {
                    if (window.showNotice) {
                        window.showNotice('error', i18n.error || 'An error occurred. Please try again.');
                    }
                    $applyBtn.prop('disabled', false).text(i18n.apply || 'Apply');
                }
            });
        });
    });
})(jQuery);

