(function () {
	'use strict';

	if (window.__yooadminDesktopChromelessColorSync__) {
		return;
	}
	window.__yooadminDesktopChromelessColorSync__ = true;

	if (window.parent === window) {
		return;
	}

	if (!document.body || !document.body.classList.contains('desktop-mode-chromeless')) {
		return;
	}

	function effectiveFromRaw(raw) {
		if (raw === 'auto') {
			try {
				return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
			} catch (e) {
				return 'light';
			}
		}
		return raw === 'dark' ? 'dark' : 'light';
	}

	function applyColorMode(mode, effective) {
		var html = document.documentElement;
		var body = document.body;
		var eff = effective || effectiveFromRaw(mode);

		html.setAttribute('data-yooadmin-studio-color-mode', mode);
		html.setAttribute('data-yooadmin-studio-color-mode-effective', eff);
		html.classList.add('yooadmin-studio-hub-html');
		html.classList.toggle('is-dark-theme', eff === 'dark');
		if (body) {
			body.classList.toggle('is-dark-theme', eff === 'dark');
		}

		try {
			document.dispatchEvent(new CustomEvent('ysh-studio-color-mode-changed'));
		} catch (e) {
			/* ignore */
		}

		if (typeof window.yshSyncStudioShellThemeChrome === 'function') {
			window.yshSyncStudioShellThemeChrome(eff);
		}
		if (typeof window.yshPluginAdminAdaptSyncMode === 'function') {
			window.yshPluginAdminAdaptSyncMode();
		}
	}

	function readParentColorMode() {
		try {
			var parentHtml = window.parent.document.documentElement;
			var mode = parentHtml.getAttribute('data-yooadmin-studio-color-mode') || 'auto';
			var effective =
				parentHtml.getAttribute('data-yooadmin-studio-color-mode-effective') ||
				effectiveFromRaw(mode);
			return { mode: mode, effective: effective };
		} catch (e) {
			return null;
		}
	}

	function syncFromParent() {
		var parentMode = readParentColorMode();
		if (!parentMode) {
			return;
		}
		applyColorMode(parentMode.mode, parentMode.effective);
	}

	function scheduleParentSync() {
		syncFromParent();
		[100, 400, 1200, 2500].forEach(function (delay) {
			window.setTimeout(syncFromParent, delay);
		});
	}

	window.addEventListener('message', function (event) {
		if (event.origin !== window.location.origin) {
			return;
		}
		var data = event.data;
		if (!data || data.type !== 'yooadmin-desktop-color-mode-sync') {
			return;
		}
		var mode = data.mode === 'dark' || data.mode === 'auto' || data.mode === 'light' ? data.mode : 'auto';
		var effective = data.effective === 'dark' ? 'dark' : data.effective === 'light' ? 'light' : effectiveFromRaw(mode);
		applyColorMode(mode, effective);
	});

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', scheduleParentSync);
	} else {
		scheduleParentSync();
	}
})();
