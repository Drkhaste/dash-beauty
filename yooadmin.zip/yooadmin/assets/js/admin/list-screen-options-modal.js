(function () {
  'use strict';

  var cfg = window.yooadminListScreenOptions || {};
  var i18n = cfg.i18n || {};
  var bindings = [];

  function t(key, fallback) {
    return i18n[key] || fallback;
  }

  function getPanel() {
    return document.getElementById('screen-options-wrap');
  }

  function getForm() {
    var panel = getPanel();
    return panel ? panel.querySelector('form') : null;
  }

  function labelText(label, input) {
    if (!label) {
      return input && input.id ? input.id.replace(/-hide$/, '').replace(/[_-]+/g, ' ') : '';
    }
    var clone = label.cloneNode(true);
    Array.prototype.forEach.call(clone.querySelectorAll('input, select, .dashicons'), function (node) {
      if (node.parentNode) {
        node.parentNode.removeChild(node);
      }
    });
    return (clone.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function createScreenOptionsButton(className, id) {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = className;
    if (id) {
      btn.id = id;
    }
    btn.setAttribute('aria-haspopup', 'dialog');
    btn.innerHTML =
      '<span class="dashicons dashicons-screenoptions" aria-hidden="true"></span>' +
      '<span>' + t('button', 'Screen Options') + '</span>';
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      openModal();
    });
    return btn;
  }

  function bindScreenOptionsButton(btn) {
    if (!btn || btn.dataset.yooLsoBound === '1') {
      return false;
    }
    btn.dataset.yooLsoBound = '1';
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      openModal();
    });
    return true;
  }

  function injectIntoHeroActions() {
    var actions = document.querySelector('.yoo-posts-hero__actions, .yoo-pages-hero__actions');
    if (!actions) {
      return false;
    }
    if (
      actions.querySelector(
        '#yoo-plugins-screen-options-btn, #yoo-hero-screen-options-btn, .yoo-hero-screen-options-btn, .yoo-list-screen-options-btn'
      )
    ) {
      return true;
    }

    var btn = createScreenOptionsButton('button yp-yoo-btn yp-yoo-btn--soft yoo-hero-screen-options-btn', 'yoo-hero-screen-options-btn');
    var primary = actions.querySelector('.yp-yoo-btn--primary');
    if (primary) {
      actions.insertBefore(btn, primary);
    } else {
      actions.appendChild(btn);
    }
    btn.dataset.yooLsoBound = '1';
    return true;
  }

  function removeLegacyScreenOptionsRow() {
    document.querySelectorAll('.yoo-list-screen-options-row').forEach(function (row) {
      row.remove();
    });
  }

  function injectButton() {
    if (bindScreenOptionsButton(document.getElementById('yoo-plugins-screen-options-btn'))) {
      return;
    }
    if (injectIntoHeroActions()) {
      return;
    }

    var wrap = document.querySelector('#wpbody-content > .wrap');
    if (!wrap || wrap.querySelector('.yoo-list-screen-options-btn')) {
      return;
    }

    var heading = wrap.querySelector('h1');
    if (!heading) {
      return;
    }

    var row = document.createElement('div');
    row.className = 'yoo-list-screen-options-row';
    heading.parentNode.insertBefore(row, heading);
    row.appendChild(heading);

    var actions = document.createElement('div');
    actions.className = 'yoo-list-screen-options-actions';
    row.appendChild(actions);
    actions.appendChild(createScreenOptionsButton('yoo-list-screen-options-btn'));
  }

  function createToggle(nativeInput, text) {
    var id = 'yoo-lso-' + (nativeInput.id || nativeInput.name || Math.random().toString(36).slice(2));
    var label = document.createElement('label');
    label.className = 'yoo-lso-toggle';
    label.setAttribute('for', id);
    label.innerHTML =
      '<span class="yoo-lso-toggle__text"></span>' +
      '<input id="' + id + '" type="checkbox" role="switch">' +
      '<span class="yoo-lso-toggle__switch" aria-hidden="true"></span>';

    label.querySelector('.yoo-lso-toggle__text').textContent = text;
    var toggle = label.querySelector('input');
    toggle.checked = !!nativeInput.checked;
    toggle.setAttribute('aria-label', text);

    bindings.push({
      type: 'checkbox',
      native: nativeInput,
      modal: toggle,
    });

    return label;
  }

  function createNumberField(nativeInput, text) {
    var wrap = document.createElement('div');
    wrap.className = 'yoo-lso-field';

    var label = document.createElement('span');
    label.className = 'yoo-lso-field__label';
    label.textContent = text;

    var input = document.createElement('input');
    input.type = 'number';
    input.className = 'yoo-lso-field__input';
    input.min = nativeInput.getAttribute('min') || '1';
    input.max = nativeInput.getAttribute('max') || '999';
    input.step = nativeInput.getAttribute('step') || '1';
    input.value = nativeInput.value;
    input.setAttribute('aria-label', text);

    bindings.push({
      type: 'number',
      native: nativeInput,
      modal: input,
    });

    wrap.appendChild(label);
    wrap.appendChild(input);
    return wrap;
  }

  function createRadioGroup(nativeRadios) {
    var wrap = document.createElement('div');
    wrap.className = 'yoo-lso-radios';

    nativeRadios.forEach(function (nativeRadio, index) {
      var text = labelText(nativeRadio.closest('label'), nativeRadio);
      var id = 'yoo-lso-radio-' + (nativeRadio.name || 'mode') + '-' + index;
      var pill = document.createElement('label');
      pill.className = 'yoo-lso-radio' + (nativeRadio.checked ? ' is-active' : '');
      pill.setAttribute('for', id);
      pill.innerHTML = '<input id="' + id + '" type="radio" name="yoo-lso-' + (nativeRadio.name || 'mode') + '">' + text;

      var modalRadio = pill.querySelector('input');
      modalRadio.value = nativeRadio.value;
      modalRadio.checked = !!nativeRadio.checked;

      bindings.push({
        type: 'radio',
        native: nativeRadio,
        modal: modalRadio,
        group: wrap,
      });

      modalRadio.addEventListener('change', function () {
        if (!modalRadio.checked) {
          return;
        }
        Array.prototype.forEach.call(wrap.querySelectorAll('.yoo-lso-radio'), function (el) {
          el.classList.remove('is-active');
        });
        pill.classList.add('is-active');
      });

      wrap.appendChild(pill);
    });

    return wrap;
  }

  function populateFieldsetItems(fieldset, items) {
    var radiosByName = {};
    var handledNumbers = {};

    fieldset.querySelectorAll('input[type="number"]').forEach(function (number) {
      if (!number || number.disabled || handledNumbers[number.id || number.name]) {
        return;
      }
      handledNumbers[number.id || number.name] = true;

      var text = t('perPage', 'Number of items per page:');
      var linkedLabel = number.id ? fieldset.querySelector('label[for="' + number.id + '"]') : null;
      if (linkedLabel) {
        text = labelText(linkedLabel, number);
      }

      var row = createNumberField(number, text);
      row.classList.add('yoo-lso-field--per-page');
      items.appendChild(row);
    });

    fieldset.querySelectorAll('label').forEach(function (label) {
      var checkbox = label.querySelector('input[type="checkbox"]');
      if (checkbox && !checkbox.disabled) {
        items.appendChild(createToggle(checkbox, labelText(label, checkbox)));
        return;
      }

      var nestedNumber = label.querySelector('input[type="number"]');
      if (nestedNumber && !nestedNumber.disabled) {
        if (!handledNumbers[nestedNumber.id || nestedNumber.name]) {
          handledNumbers[nestedNumber.id || nestedNumber.name] = true;
          items.appendChild(createNumberField(nestedNumber, labelText(label, nestedNumber)));
        }
        return;
      }

      var radio = label.querySelector('input[type="radio"]');
      if (radio && !radio.disabled) {
        if (!radiosByName[radio.name]) {
          radiosByName[radio.name] = [];
        }
        radiosByName[radio.name].push(radio);
      }
    });

    Object.keys(radiosByName).forEach(function (name) {
      var group = createRadioGroup(radiosByName[name]);
      group.classList.add('yoo-lso-radios--full');
      items.appendChild(group);
    });
  }

  function buildSections(container) {
    bindings = [];
    container.innerHTML = '';

    var form = getForm();
    if (!form) {
      container.innerHTML = '<p class="yoo-lso-modal__empty">' + t('empty', 'No display options were found for this screen.') + '</p>';
      return;
    }

    var fieldsets = form.querySelectorAll('fieldset');
    if (!fieldsets.length) {
      var prefs = form.querySelector('.metabox-prefs');
      if (prefs) {
        var fallbackSection = document.createElement('div');
        fallbackSection.className = 'yoo-lso-section';
        var fallbackItems = document.createElement('div');
        fallbackItems.className = 'yoo-lso-section__items';
        prefs.querySelectorAll('label input[type="checkbox"]').forEach(function (input) {
          if (!input.id || input.disabled) {
            return;
          }
          fallbackItems.appendChild(createToggle(input, labelText(input.closest('label'), input)));
        });
        fallbackSection.appendChild(fallbackItems);
        container.appendChild(fallbackSection);
        return;
      }
      container.innerHTML = '<p class="yoo-lso-modal__empty">' + t('empty', 'No display options were found for this screen.') + '</p>';
      return;
    }

    Array.prototype.forEach.call(fieldsets, function (fieldset) {
      var items = document.createElement('div');
      items.className = 'yoo-lso-section__items';
      populateFieldsetItems(fieldset, items);

      if (!items.childNodes.length) {
        return;
      }

      var section = document.createElement('div');
      section.className = 'yoo-lso-section';

      var legend = fieldset.querySelector('legend');
      if (legend && legend.textContent.trim() !== '') {
        var legendText = legend.textContent.trim();
        var title = document.createElement('h3');
        title.className = 'yoo-lso-section__title';
        title.textContent = legendText;
        section.appendChild(title);

        if (/pagination/i.test(legendText)) {
          section.classList.add('yoo-lso-section--pagination');
        } else if (/view mode/i.test(legendText)) {
          section.classList.add('yoo-lso-section--view-mode');
        } else if (/columns/i.test(legendText)) {
          section.classList.add('yoo-lso-section--columns');
        }
      }

      section.appendChild(items);
      container.appendChild(section);
    });
  }

  function syncColumnsViaWordPress() {
    var changed = false;
    var columnsApi = window.columns;

    bindings.forEach(function (item) {
      if (item.type !== 'checkbox') {
        return;
      }
      if (item.native.checked === item.modal.checked) {
        return;
      }

      item.native.checked = item.modal.checked;
      changed = true;

      if (!columnsApi || !item.native.value) {
        return;
      }

      if (item.modal.checked && typeof columnsApi.checked === 'function') {
        columnsApi.checked(item.native.value);
      } else if (!item.modal.checked && typeof columnsApi.unchecked === 'function') {
        columnsApi.unchecked(item.native.value);
      }
    });

    if (changed && columnsApi && typeof columnsApi.saveManageColumnsState === 'function') {
      columnsApi.saveManageColumnsState();
    }

    return changed;
  }

  function removeModal() {
    var existing = document.getElementById('yoo-lso-modal');
    if (existing && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }
    document.body.classList.remove('yoo-lso-modal-open');
  }

  function applySettings() {
    syncColumnsViaWordPress();

    var needsReload = false;
    bindings.forEach(function (item) {
      if (item.type === 'checkbox') {
        return;
      }
      if (item.type === 'number') {
        if (String(item.native.value) !== String(item.modal.value)) {
          item.native.value = item.modal.value;
          needsReload = true;
        }
        return;
      }
      if (item.type === 'radio' && item.modal.checked && !item.native.checked) {
        item.native.checked = true;
        needsReload = true;
      }
    });

    var form = getForm();
    removeModal();

    if (!form || !needsReload) {
      return;
    }

    var submitBtn = form.querySelector('[name="screen-options-apply"], #screen-options-apply, .screen-options-apply');
    if (submitBtn && typeof form.requestSubmit === 'function') {
      form.requestSubmit(submitBtn);
      return;
    }

    if (typeof form.requestSubmit === 'function') {
      form.requestSubmit();
    } else {
      form.submit();
    }
  }

  function openModal() {
    removeModal();

    var modal = document.createElement('div');
    modal.id = 'yoo-lso-modal';
    modal.className = 'yoo-lso-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-labelledby', 'yoo-lso-modal-title');
    modal.innerHTML =
      '<div class="yoo-lso-modal__overlay" data-yoo-lso-close></div>' +
      '<div class="yoo-lso-modal__panel">' +
      '<div class="yoo-lso-modal__header">' +
      '<div>' +
      '<p class="yoo-lso-modal__eyebrow"><span class="dashicons dashicons-screenoptions" aria-hidden="true"></span>' + t('eyebrow', 'Display') + '</p>' +
      '<h2 id="yoo-lso-modal-title" class="yoo-lso-modal__title"></h2>' +
      '<p class="yoo-lso-modal__desc">' + t('description', 'Choose which columns and layout options appear on this screen. Changes are saved when you apply.') + '</p>' +
      '</div>' +
      '<button type="button" class="yoo-lso-modal__close" data-yoo-lso-close aria-label="' + t('close', 'Close') + '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>' +
      '</div>' +
      '<div class="yoo-lso-modal__body" data-yoo-lso-body></div>' +
      '<div class="yoo-lso-modal__footer">' +
      '<p class="yoo-lso-modal__hint">' + t('hint', 'Use these toggles instead of the native Screen Options panel.') + '</p>' +
      '<button type="button" class="yoo-lso-modal__apply">' + t('apply', 'Apply') + '</button>' +
      '</div>' +
      '</div>';

    document.body.appendChild(modal);
    document.body.classList.add('yoo-lso-modal-open');

    modal.querySelector('.yoo-lso-modal__title').textContent = cfg.title || t('button', 'Screen Options');
    var bodyEl = modal.querySelector('[data-yoo-lso-body]');
    buildSections(bodyEl);

    document.dispatchEvent(
      new CustomEvent('yooadmin-lso-modal-built', {
        detail: {
          modal: modal,
          body: bodyEl,
          applyButton: modal.querySelector('.yoo-lso-modal__apply'),
        },
      })
    );

    modal.querySelectorAll('[data-yoo-lso-close]').forEach(function (el) {
      el.addEventListener('click', removeModal);
    });
    modal.querySelector('.yoo-lso-modal__apply').addEventListener('click', applySettings);

    var close = modal.querySelector('.yoo-lso-modal__close');
    if (close) {
      close.focus();
    }
  }

  function boot() {
    if (!document.body || !document.body.classList.contains('yoo-list-screen')) {
      return;
    }
    if (!getPanel() || !getForm()) {
      return;
    }
    if (document.body.classList.contains('plugins-php')) {
      document.addEventListener(
        'yooadmin-plugins-layout-ready',
        function () {
          removeLegacyScreenOptionsRow();
          injectButton();
        },
        { once: true }
      );
      return;
    }
    injectButton();
  }

  window.yooadminListScreenOptionsApi = {
    open: openModal,
    apply: applySettings,
  };

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && document.getElementById('yoo-lso-modal')) {
      removeModal();
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
