(function ($) {
  'use strict';

  var cfg = window.yooadminStudioHubUpgrade || {};
  var mediaQuery = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function t(key, fallback) {
    return cfg.i18n && cfg.i18n[key] != null ? String(cfg.i18n[key]) : fallback;
  }

  function systemIsDark() {
    try {
      return !!(mediaQuery && mediaQuery.matches);
    } catch (e) {
      return false;
    }
  }

  function resolveEffective(pref) {
    if (pref === 'dark') {
      return 'dark';
    }
    if (pref === 'light') {
      return 'light';
    }
    return systemIsDark() ? 'dark' : 'light';
  }

  var Modal = {
    init: function () {
      var $overlay = $('#yooadmin-studio-hub-upgrade');
      if (!$overlay.length) {
        return;
      }

      this.applyAppearance($overlay, $overlay.attr('data-ysh-upgrade-pref') || 'auto');

      $overlay.removeAttr('hidden').attr('aria-hidden', 'false');
      window.setTimeout(function () {
        $overlay.addClass('ysh-upgrade-visible');
      }, 450);

      this.bindEvents($overlay);
    },

    applyAppearance: function ($overlay, pref) {
      var normalized = pref === 'dark' || pref === 'light' ? pref : 'auto';
      var effective = resolveEffective(normalized);

      $overlay.attr('data-ysh-upgrade-pref', normalized);
      $overlay.attr('data-ysh-upgrade-effective', effective);
      $overlay.toggleClass('ysh-upgrade--dark', effective === 'dark');

      $overlay.find('.ysh-upgrade-appearance-btn').removeClass('is-active');
      $overlay
        .find('.ysh-upgrade-appearance-btn[data-ysh-upgrade-pref="' + normalized + '"]')
        .addClass('is-active');
    },

    bindEvents: function ($overlay) {
      var self = this;

      $overlay.on('click', '.ysh-upgrade-close, .ysh-upgrade-dismiss', function (e) {
        e.preventDefault();
        self.dismiss($overlay);
      });

      $overlay.on('click', '.ysh-upgrade-appearance-btn', function (e) {
        e.preventDefault();
        var pref = $(this).attr('data-ysh-upgrade-pref') || 'auto';
        self.applyAppearance($overlay, pref);
      });

      if (mediaQuery && typeof mediaQuery.addEventListener === 'function') {
        mediaQuery.addEventListener('change', function () {
          if (($overlay.attr('data-ysh-upgrade-pref') || 'auto') === 'auto') {
            self.applyAppearance($overlay, 'auto');
          }
        });
      } else if (mediaQuery && typeof mediaQuery.addListener === 'function') {
        mediaQuery.addListener(function () {
          if (($overlay.attr('data-ysh-upgrade-pref') || 'auto') === 'auto') {
            self.applyAppearance($overlay, 'auto');
          }
        });
      }

      $overlay.on('click', function (e) {
        if ($(e.target).is('.ysh-upgrade-overlay')) {
          self.dismiss($overlay);
        }
      });

      $overlay.on('click', '.ysh-upgrade-dialog', function (e) {
        e.stopPropagation();
      });

      $overlay.on('click', '.ysh-upgrade-activate', function (e) {
        e.preventDefault();
        self.activate($overlay, $(this));
      });

      $(document).on('keydown.yshUpgrade', function (e) {
        if (e.key === 'Escape' && $overlay.hasClass('ysh-upgrade-visible')) {
          self.dismiss($overlay);
        }
      });
    },

    dismiss: function ($overlay) {
      var self = this;
      $.post(cfg.ajaxUrl, {
        action: 'yooadmin_dismiss_studio_hub_upgrade_modal',
        nonce: cfg.dismissNonce
      }).always(function () {
        self.hide($overlay);
      });
    },

    activate: function ($overlay, $btn) {
      if (!cfg.ajaxUrl || !cfg.activateNonce || !cfg.themeSlug) {
        return;
      }

      var label = $btn.text();
      var self = this;
      $overlay.addClass('ysh-upgrade-busy');
      $btn.prop('disabled', true).text(t('activating', 'Activating…'));

      $.post(cfg.ajaxUrl, {
        action: 'yooadmin_shell_theme_activate',
        nonce: cfg.activateNonce,
        theme_slug: cfg.themeSlug,
        color_mode: $overlay.attr('data-ysh-upgrade-pref') || 'auto'
      })
        .done(function (res) {
          if (res && res.success) {
            self.onActivateSuccess($overlay, $btn);
            return;
          }
          window.alert(
            (res && res.data && res.data.message) ||
              t('activateFail', 'Could not activate Studio Hub.')
          );
        })
        .fail(function () {
          window.alert(t('activateFail', 'Could not activate Studio Hub.'));
        })
        .always(function () {
          if ($overlay.hasClass('ysh-upgrade-success')) {
            return;
          }
          $overlay.removeClass('ysh-upgrade-busy');
          $btn.prop('disabled', false).text(label);
        });
    },

    onActivateSuccess: function ($overlay, $btn) {
      var activatedLabel = t('activated', 'Studio Hub is active');
      $overlay.removeClass('ysh-upgrade-busy').addClass('ysh-upgrade-success');
      $btn
        .prop('disabled', true)
        .addClass('ysh-upgrade-activate--success')
        .html(
          '<span class="dashicons dashicons-yes-alt" aria-hidden="true"></span> ' +
            activatedLabel
        );

      window.setTimeout(function () {
        $overlay.removeClass('ysh-upgrade-visible').addClass('ysh-upgrade-leaving');
      }, 550);

      window.setTimeout(function () {
        var url = cfg.dashboardUrl || window.location.href.split('#')[0];
        var sep = url.indexOf('?') >= 0 ? '&' : '?';
        window.location.href = url + sep + 'ysh_activated=1';
      }, 900);
    },

    hide: function ($overlay) {
      $overlay.removeClass('ysh-upgrade-visible').attr('aria-hidden', 'true');
      $(document).off('keydown.yshUpgrade');
      window.setTimeout(function () {
        $overlay.remove();
      }, 280);
    }
  };

  $(function () {
    Modal.init();
  });
})(jQuery);
