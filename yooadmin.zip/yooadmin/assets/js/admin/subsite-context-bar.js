/**
 * Subsite context bar — collapse / expand with localStorage + motion.
 */
(function () {
	'use strict';

	var STORAGE_KEY = 'yooadmin_subsite_context_bar_collapsed';
	var ANIM_MS = 280;
	var rootEl = document.documentElement;
	var bodyEl = document.body;
	var animating = false;
	var prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	function syncCollapsedClass(collapsed) {
		if (rootEl) {
			rootEl.classList.toggle('yp-subsite-context-bar-is-collapsed', collapsed);
		}
		if (bodyEl) {
			bodyEl.classList.toggle('yp-subsite-context-bar-is-collapsed', collapsed);
		}
	}

	function persistCollapsed(collapsed) {
		try {
			localStorage.setItem(STORAGE_KEY, collapsed ? '1' : '0');
		} catch (e) {
			/* ignore */
		}
	}

	function syncSubsiteContextBarHeight() {
		var root = document.documentElement;
		if (!root) {
			return;
		}
		var chrome = document.querySelector('.yp-subsite-chrome');
		var bar = document.getElementById('yp-subsite-context-bar');
		var h = 0;
		var collapsed = root.classList.contains('yp-subsite-context-bar-is-collapsed')
			|| (bodyEl && bodyEl.classList.contains('yp-subsite-context-bar-is-collapsed'));

		if (collapsed) {
			/* Expand tab overlays header; chrome should not reserve bar height. */
			h = 0;
		} else if (bar && bar.offsetHeight) {
			h = bar.offsetHeight;
		} else if (chrome && chrome.offsetHeight) {
			h = chrome.offsetHeight;
		}

		if (collapsed || h > 0) {
			root.style.setProperty('--yp-subsite-context-bar-h', String(h) + 'px');
		} else {
			root.style.removeProperty('--yp-subsite-context-bar-h');
		}

		document.dispatchEvent(new CustomEvent('yooadmin:subsite-context-bar-height'));
	}

	function syncMotionClass(className, enabled) {
		if (rootEl) {
			rootEl.classList.toggle(className, enabled);
		}
		if (bodyEl) {
			bodyEl.classList.toggle(className, enabled);
		}
	}

	function clearMotionClasses() {
		if (!rootEl) {
			return;
		}
		rootEl.classList.remove(
			'yp-subsite-context-bar-is-animating',
			'yp-subsite-context-bar-is-collapsing',
			'yp-subsite-context-bar-is-expanding',
			'yp-subsite-context-bar-expand-play'
		);
		if (bodyEl) {
			bodyEl.classList.remove(
				'yp-subsite-context-bar-is-animating',
				'yp-subsite-context-bar-is-collapsing',
				'yp-subsite-context-bar-is-expanding',
				'yp-subsite-context-bar-expand-play'
			);
		}
	}

	function finishMotion(collapsed) {
		window.setTimeout(function () {
			clearMotionClasses();
			animating = false;
			persistCollapsed(collapsed);
			syncSubsiteContextBarHeight();
		}, ANIM_MS + 40);
	}

	function canAnimate() {
		return !prefersReducedMotion
			&& rootEl
			&& rootEl.classList.contains('yp-subsite-context-bar-animate-ready');
	}

	function setCollapsedImmediate(collapsed) {
		clearMotionClasses();
		syncCollapsedClass(collapsed);
		persistCollapsed(collapsed);
		syncSubsiteContextBarHeight();
	}

	function setCollapsed(collapsed, options) {
		options = options || {};

		if (options.immediate || !canAnimate()) {
			setCollapsedImmediate(collapsed);
			return;
		}

		if (animating) {
			return;
		}

		var bar = document.getElementById('yp-subsite-context-bar');
		if (!bar) {
			setCollapsedImmediate(collapsed);
			return;
		}

		var currentlyCollapsed = rootEl.classList.contains('yp-subsite-context-bar-is-collapsed')
			|| (bodyEl && bodyEl.classList.contains('yp-subsite-context-bar-is-collapsed'));

		if (currentlyCollapsed === collapsed) {
			persistCollapsed(collapsed);
			syncSubsiteContextBarHeight();
			return;
		}

		animating = true;
		syncMotionClass('yp-subsite-context-bar-is-animating', true);
		syncMotionClass('yp-subsite-context-bar-is-collapsing', false);
		syncMotionClass('yp-subsite-context-bar-is-expanding', false);

		if (collapsed) {
			syncMotionClass('yp-subsite-context-bar-is-collapsing', true);
			requestAnimationFrame(function () {
				requestAnimationFrame(function () {
					syncCollapsedClass(true);
					finishMotion(true);
				});
			});
			return;
		}

		syncMotionClass('yp-subsite-context-bar-is-expanding', true);
		syncCollapsedClass(false);
		requestAnimationFrame(function () {
			requestAnimationFrame(function () {
				syncMotionClass('yp-subsite-context-bar-expand-play', true);
				finishMotion(false);
			});
		});
	}

	function markAnimateReady() {
		if (!rootEl) {
			return;
		}
		requestAnimationFrame(function () {
			rootEl.classList.add('yp-subsite-context-bar-animate-ready');
		});
	}

	function init() {
		var bar = document.getElementById('yp-subsite-context-bar');
		if (!bar) {
			return;
		}

		bodyEl = document.body;
		var dismiss = bar.querySelector('.yp-subsite-context-bar__dismiss');
		var expand = document.getElementById('yp-subsite-context-expand');

		var stored = '';
		try {
			stored = localStorage.getItem(STORAGE_KEY) || '';
		} catch (e) {
			stored = '';
		}
		if (stored === '1') {
			setCollapsedImmediate(true);
		} else {
			syncCollapsedClass(false);
			syncSubsiteContextBarHeight();
		}

		markAnimateReady();

		if (dismiss) {
			dismiss.addEventListener('click', function () {
				setCollapsed(true);
			});
		}
		if (expand) {
			expand.addEventListener('click', function () {
				setCollapsed(false);
			});
		}

		window.addEventListener('resize', syncSubsiteContextBarHeight);
	}

	window.yooadminSyncSubsiteContextBarHeight = syncSubsiteContextBarHeight;

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
