/**
 * YOOAdmin - Core essential (critical admin only)
 *
 * @package YOOAdmin
 */

(function () {
  'use strict';
  
  // Local console shim for this file:
  // - Disables debug/info/warn logs in production
  // - Still forwards real errors to browser console
  var console = {
    log: function() {},
    info: function() {},
    warn: function() {},
    debug: function() {},
    error: function() {}
  };
  if (window.__YPCoreEssentialInit) return;
  window.__YPCoreEssentialInit = true;

  var ypToolbarSwap = (function () {
    var flyoutDocks = new Map();

    function isStripItem(item, bar) {
      if (!item) {
        return false;
      }
      var shortcutsBar = bar || item.closest('.yp-toolbar-shortcuts');
      return !!(
        shortcutsBar &&
        shortcutsBar.classList.contains('yp-toolbar-shortcuts--more-open') &&
        item.closest('.yp-toolbar-overflow-strip')
      );
    }

    function resetMenuStyles(menu) {
      if (!menu) {
        return;
      }
      menu.style.display = '';
      menu.style.opacity = '';
      menu.style.pointerEvents = '';
      menu.style.position = '';
      menu.style.top = '';
      menu.style.left = '';
      menu.style.right = '';
      menu.style.transform = '';
      menu.style.zIndex = '';
      menu.style.visibility = '';
    }

    function restoreFlyout(item) {
      var dock = flyoutDocks.get(item);
      if (!dock || !dock.menu) {
        return;
      }
      var menu = dock.menu;
      menu.classList.remove('yp-toolbar-menu--swapped-portal');
      resetMenuStyles(menu);
      if (dock.parent && dock.parent.isConnected) {
        if (dock.next && dock.next.parentNode === dock.parent) {
          dock.parent.insertBefore(menu, dock.next);
        } else {
          dock.parent.appendChild(menu);
        }
      }
    }

    function openFlyout(item) {
      if (!item) {
        return;
      }
      var menu = item.querySelector(':scope > .yp-toolbar-menu');
      var trigger = item.querySelector(':scope > .yp-toolbar-trigger');
      if (!menu || !trigger) {
        return;
      }
      if (!flyoutDocks.has(item)) {
        flyoutDocks.set(item, {
          menu: menu,
          parent: menu.parentNode,
          next: menu.nextSibling,
        });
      }
      var dock = flyoutDocks.get(item);
      dock.menu = menu;
      if (menu.parentNode !== document.body) {
        document.body.appendChild(menu);
      }
      menu.classList.add('yp-toolbar-menu--swapped-portal');
      menu.style.display = 'flex';
      menu.style.opacity = '1';
      menu.style.pointerEvents = 'auto';
      menu.style.position = 'fixed';
      menu.style.zIndex = '100100';
      menu.style.transform = 'none';
      menu.style.visibility = 'hidden';
      var tr = trigger.getBoundingClientRect();
      var mw = menu.offsetWidth || menu.scrollWidth || 220;
      menu.style.visibility = 'visible';
      var top = Math.round(tr.bottom + 6);
      var left = Math.round(tr.right - mw);
      if (document.documentElement.getAttribute('dir') === 'rtl') {
        left = Math.round(tr.left);
      }
      if (left < 8) {
        left = 8;
      }
      if (left + mw > window.innerWidth - 8) {
        left = Math.max(8, window.innerWidth - mw - 8);
      }
      menu.style.top = top + 'px';
      menu.style.left = left + 'px';
      menu.style.right = 'auto';
    }

    function closeFlyout(item) {
      restoreFlyout(item);
    }

    function closeAllFlyouts(bar) {
      if (!bar) {
        flyoutDocks.forEach(function (_dock, item) {
          restoreFlyout(item);
        });
        flyoutDocks.clear();
        return;
      }
      bar.querySelectorAll('.yp-toolbar-overflow-strip > .yp-toolbar-item.has-children').forEach(function (item) {
        restoreFlyout(item);
      });
    }

    function syncFlyouts(bar) {
      if (!bar) {
        bar = document.querySelector('.yp-toolbar-shortcuts.yp-toolbar-shortcuts--more-open');
      }
      if (!bar) {
        return;
      }
      bar.querySelectorAll('.yp-toolbar-overflow-strip > .yp-toolbar-item.has-children').forEach(function (item) {
        if (item.classList.contains('menu-open') || item.classList.contains('is-flyout-open')) {
          openFlyout(item);
        } else {
          closeFlyout(item);
        }
      });
    }

    return {
      isStripItem: isStripItem,
      openFlyout: openFlyout,
      closeFlyout: closeFlyout,
      closeAllFlyouts: closeAllFlyouts,
      syncFlyouts: syncFlyouts,
    };
  })();

  // ---------------- WC-admin top-offset guard ----------------
  (function wcTopOffsetGuard() {
    var body = document.body;
    if (!body || !body.classList.contains('woocommerce_page_wc-admin')) return;

    var SELECTORS = [
      "main[role='main']",
      "#wpcontent",
      "#wpbody", 
      "#wpbody-content",
      ".wrap"
    ];

    function stripOffsets() {
      try {
        SELECTORS.forEach(function (sel) {
          var el = document.querySelector(sel);
          if (!el || !el.style) return;
          if (el.style.marginTop) el.style.marginTop = "";
          if (el.style.paddingTop) el.style.paddingTop = "";
        });
      } catch (_) {}
    }

    stripOffsets();
    
    // Re-run on SPA route changes (wc-admin)
    try {
      var _push = history.pushState;
      history.pushState = function () {
        var r = _push.apply(this, arguments);
        window.dispatchEvent(new Event('locationchange'));
        return r;
      };
      var _replace = history.replaceState;
      history.replaceState = function () {
        var r = _replace.apply(this, arguments);
        window.dispatchEvent(new Event('locationchange'));
        return r;
      };
      window.addEventListener('popstate', function () {
        window.dispatchEvent(new Event('locationchange'));
      });
      window.addEventListener('locationchange', stripOffsets);
    } catch (_) {}

    // Short-lived observer to catch early inline style injections
    try {
      var mo = new MutationObserver(function () { stripOffsets(); });
      mo.observe(document.getElementById('wpwrap') || document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['style', 'class']
      });
      setTimeout(function () { try { mo.disconnect(); } catch (_) {} }, 3000);
    } catch (_) {}
  })();

  // ---------------- Clean View toggle ----------------
  const bindCleanToggle = () => {
    const toggleBtn = document.getElementById('yp-toggle-clean-view');
    if (!toggleBtn || toggleBtn.dataset.bound === '1') return false;

    toggleBtn.addEventListener('change', function () {
      document.body.classList.toggle('yp-clean-view');
    }, { capture: true });

    toggleBtn.dataset.bound = '1';
    return true;
  };

  let cleanBound = bindCleanToggle();
  const cleanObserver = new MutationObserver(() => {
    if (!cleanBound) cleanBound = bindCleanToggle();
    if (cleanBound) cleanObserver.disconnect();
  });
  cleanObserver.observe(document.documentElement, { childList: true, subtree: true });

  // ---------------- User Dropdown Toggle ----------------
  (function initUserDropdown() {
    function bindUserDropdown() {
      var userInfo = document.querySelector('.yp-user-info');
      var userDropdown = document.querySelector('.yp-user-dropdown');
      
      if (!userInfo || !userDropdown) return false;
      if (userInfo.dataset.bound === '1') return true;
      
      // Toggle dropdown on click
      userInfo.addEventListener('click', function(e) {
        // Don't prevent default if clicking on a link inside dropdown
        if (e.target.tagName === 'A' || e.target.closest('a')) {
          return; // Allow the link to work
        }
        
        e.preventDefault();
        e.stopPropagation();
        
        var isOpen = userDropdown.style.display === 'flex';
        
        // Close all other dropdowns first
        document.querySelectorAll('.yp-user-dropdown').forEach(function(dropdown) {
          if (dropdown !== userDropdown) {
            dropdown.style.display = 'none';
          }
        });
        
        // Toggle this dropdown
        userDropdown.style.display = isOpen ? 'none' : 'flex';
      });
      
      // Close dropdown when clicking outside
      document.addEventListener('click', function(e) {
        if (!userInfo.contains(e.target) && !userDropdown.contains(e.target)) {
          userDropdown.style.display = 'none';
        }
      });
      
      // Close dropdown on escape key
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && userDropdown.style.display === 'flex') {
          userDropdown.style.display = 'none';
        }
      });
      
      userInfo.dataset.bound = '1';
      return true;
    }
    
    var userBound = bindUserDropdown();
    var userObserver = new MutationObserver(function() {
      if (!userBound) userBound = bindUserDropdown();
      if (userBound) userObserver.disconnect();
    });
    userObserver.observe(document.documentElement, { childList: true, subtree: true });
  })();

  // ---------------- Core Admin Initialization ----------------
  (function initCoreAdmin() {
    // Initialize admin panel essentials
    function initializeAdminPanel() {
      // Basic admin panel setup
      if (document.querySelector('#yoopanel')) {
        // Add essential admin panel functionality
      }
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initializeAdminPanel);
    } else {
      initializeAdminPanel();
    }
  })();

  // ---------------- Mirrored toolbar → real #wpadminbar (Site Kit stats panel, etc.) ----------------
  // Same behavior as yooadmin-extended: hover bridge, fixed flyout, z-index/pointer-events via yp-admin-core.css.
  (function initToolbarAdminBarClickForward() {
    var siteKitLeaveTimer = null;
    var siteKitRepositionMo = null;
    var siteKitLiLeaveBound = null;
    var siteKitOpenKey = '';
    var SITE_KIT_BRIDGE_ID = 'yp-site-kit-flyout-bridge';
    var SITE_KIT_LEAVE_MS = 750;

    function isSiteKitToolbarItem(item) {
      if (!item) return false;
      if (item.querySelector('.yp-toolbar-site-kit-icon')) return true;
      var id = (item.getAttribute('data-toolbar-id') || '').toLowerCase();
      return /googlesitekit|google-site-kit|site-kit|sitekit/.test(id);
    }

    function resolveNativeAdminBarTrigger(nodeId) {
      if (!nodeId) return null;
      var li = document.getElementById('wp-admin-bar-' + nodeId);
      if (!li) return null;
      return li.querySelector(':scope > a.ab-item') || li.querySelector(':scope > a');
    }

    function resolveNativeAdminBarClickTarget(nodeId) {
      if (!nodeId) return null;
      var li = document.getElementById('wp-admin-bar-' + nodeId);
      if (!li) return null;
      return (
        li.querySelector(':scope > .ab-item') ||
        li.querySelector(':scope > a') ||
        li.querySelector(':scope > button') ||
        li.querySelector('a.ab-item') ||
        li.querySelector('button')
      );
    }

    function shouldForwardToolbarHref(href) {
      if (!href) return true;
      var trimmed = String(href).trim();
      if (trimmed === '' || trimmed === '#' || trimmed === '#/') return true;
      var lower = trimmed.toLowerCase();
      if (lower.indexOf('javascript:') === 0) return true;
      return false;
    }

    function getToolbarAdminBarId(el) {
      if (!el) return '';
      var fromData = el.getAttribute('data-admin-bar-id');
      if (fromData) return fromData;
      var item = el.closest('.yp-toolbar-item');
      if (item) return item.getAttribute('data-toolbar-id') || '';
      return '';
    }

    function forwardClickToNativeAdminBar(nodeId, e) {
      var nativeTarget = resolveNativeAdminBarClickTarget(nodeId);
      if (!nativeTarget) return false;
      if (e) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
      try {
        nativeTarget.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
      } catch (_) {
        nativeTarget.click();
      }
      return true;
    }

    function preferToolbarClickMenus() {
      try {
        if (window.matchMedia('(max-width: 768px)').matches) return true;
        if (window.matchMedia('(pointer: coarse)').matches) return true;
        if (!window.matchMedia('(hover: hover)').matches) return true;
      } catch (_) {}
      return false;
    }

    function isMobileToolbarBar() {
      try {
        return window.matchMedia('(max-width: 768px)').matches;
      } catch (_) {
        return false;
      }
    }

    function shouldOpenMirroredToolbarMenu(item, bar) {
      if (!item || !item.classList.contains('has-children')) return false;
      return true;
    }

    function forwardGenericToolbarClick(e) {
      var menuLink = e.target.closest && e.target.closest('.yp-toolbar-menu-link');
      if (menuLink) {
        var nestedWrap = menuLink.closest('.yp-toolbar-menu-item.has-submenu');
        if (nestedWrap && nestedWrap.querySelector(':scope > .yp-toolbar-menu-link') === menuLink) {
          return false;
        }
        var menuBarId = getToolbarAdminBarId(menuLink);
        if (menuBarId && shouldForwardToolbarHref(menuLink.getAttribute('href') || '')) {
          return forwardClickToNativeAdminBar(menuBarId, e);
        }
        return false;
      }

      var trigger = e.target.closest && e.target.closest('.yp-toolbar-item > .yp-toolbar-trigger');
      if (!trigger) return false;
      var item = trigger.closest('.yp-toolbar-item');
      if (!item) return false;
      if (isSiteKitToolbarItem(item)) return false;
      var shortcutsBar = item.closest('.yp-toolbar-shortcuts');
      if (ypToolbarSwap.isStripItem(item, shortcutsBar)) {
        if (!item.classList.contains('has-children')) {
          var stripNodeId = getToolbarAdminBarId(trigger);
          var stripHref = trigger.getAttribute('href') || '';
          if (stripNodeId && shouldForwardToolbarHref(stripHref)) {
            return forwardClickToNativeAdminBar(stripNodeId, e);
          }
        }
        return false;
      }
      if (shouldOpenMirroredToolbarMenu(item, shortcutsBar)) return false;

      var nodeId = getToolbarAdminBarId(trigger);
      if (!nodeId) return false;
      if (!shouldForwardToolbarHref(trigger.getAttribute('href') || '')) {
        return false;
      }
      if (forwardClickToNativeAdminBar(nodeId, e)) {
        item.classList.remove('menu-open');
        return true;
      }
      return false;
    }

    function resolveNativeSiteKitLi(nodeId) {
      var id = nodeId ? 'wp-admin-bar-' + nodeId : '';
      var li = id ? document.getElementById(id) : null;
      if (li && li.classList && li.classList.contains('googlesitekit-wp-adminbar')) {
        return li;
      }
      var byClass = document.querySelector('#wpadminbar li.googlesitekit-wp-adminbar');
      return byClass || li;
    }

    function isWpAdminBarHidden() {
      var bar = document.getElementById('wpadminbar');
      if (!bar) return true;
      try {
        var s = window.getComputedStyle(bar);
        return s.display === 'none' || s.visibility === 'hidden';
      } catch (_) {
        return true;
      }
    }

    function clearSiteKitLeaveTimer() {
      if (siteKitLeaveTimer) {
        clearTimeout(siteKitLeaveTimer);
        siteKitLeaveTimer = null;
      }
    }

    function clearSiteKitSubwrapperStyles(li) {
      if (!li) return;
      var sub = li.querySelector('.ab-sub-wrapper');
      if (!sub || sub.getAttribute('data-yp-sk-flyout') !== '1') return;
      sub.style.position = '';
      sub.style.left = '';
      sub.style.top = '';
      sub.style.right = '';
      sub.style.zIndex = '';
      sub.style.margin = '';
      sub.style.marginLeft = '';
      sub.style.marginTop = '';
      sub.style.maxWidth = '';
      sub.style.minWidth = '';
      sub.style.width = '';
      sub.style.boxSizing = '';
      sub.style.overflow = '';
      sub.style.visibility = '';
      sub.removeAttribute('data-yp-sk-flyout');
    }

    function siteKitMirrorAnchorEl(mirrorItem) {
      if (!mirrorItem) return null;
      var t = mirrorItem.querySelector && mirrorItem.querySelector('.yp-toolbar-trigger');
      return t || mirrorItem;
    }

    function ensureSiteKitHoverBridge() {
      var b = document.getElementById(SITE_KIT_BRIDGE_ID);
      if (!b) {
        b = document.createElement('div');
        b.id = SITE_KIT_BRIDGE_ID;
        b.className = 'yp-site-kit-flyout-bridge';
        b.setAttribute('aria-hidden', 'true');
        b.addEventListener('mouseenter', clearSiteKitLeaveTimer, true);
        b.addEventListener('mouseover', clearSiteKitLeaveTimer, true);
        document.body.appendChild(b);
      }
      return b;
    }

    function hideSiteKitHoverBridge() {
      var b = document.getElementById(SITE_KIT_BRIDGE_ID);
      if (b) {
        b.style.display = 'none';
      }
    }

    function repositionSiteKitFlyout(li, mirrorItem) {
      if (!li || !mirrorItem) return;
      var sub = li.querySelector('.ab-sub-wrapper');
      if (!sub) return;
      try {
        var cw = document.documentElement.clientWidth || window.innerWidth || 0;
        var pad = 12;
        var usable = Math.max(280, cw - pad * 2);
        var panelW = Math.min(920, usable);
        sub.setAttribute('data-yp-sk-flyout', '1');
        sub.style.boxSizing = 'border-box';
        sub.style.position = 'fixed';
        sub.style.right = 'auto';
        sub.style.zIndex = '100201';
        sub.style.margin = '0';
        sub.style.marginLeft = '0';
        sub.style.marginTop = '0';
        sub.style.width = panelW + 'px';
        sub.style.minWidth = panelW + 'px';
        sub.style.maxWidth = panelW + 'px';
        sub.style.overflow = 'visible';
        sub.style.visibility = 'visible';

        var anchor = siteKitMirrorAnchorEl(mirrorItem);
        var r = anchor.getBoundingClientRect();
        var panelTop = Math.round(r.bottom) - 20;
        sub.style.top = panelTop + 'px';
        var idealLeft = r.left + r.width / 2 - panelW / 2;
        var left = Math.max(pad, Math.min(idealLeft, cw - panelW - pad));
        sub.style.left = Math.round(left) + 'px';

        var rect = sub.getBoundingClientRect();
        if (rect.width > 0 && rect.right > cw - pad + 0.5) {
          left = Math.max(pad, cw - pad - rect.width);
          sub.style.left = Math.round(left) + 'px';
          rect = sub.getBoundingClientRect();
        }
        if (rect.width > 0 && rect.left < pad - 0.5) {
          sub.style.left = pad + 'px';
          left = pad;
        }

        var bridge = ensureSiteKitHoverBridge();
        bridge.style.display = 'block';
        bridge.style.position = 'fixed';
        bridge.style.left = Math.round(left) + 'px';
        bridge.style.width = panelW + 'px';
        bridge.style.height = '16px';
        bridge.style.top = Math.round(panelTop - 10) + 'px';
        bridge.style.zIndex = '100200';
        bridge.style.pointerEvents = 'auto';
        bridge.style.background = 'transparent';
      } catch (_) {}
    }

    function detachSiteKitRepositionMo() {
      if (siteKitRepositionMo) {
        try {
          siteKitRepositionMo.disconnect();
        } catch (_) {}
        siteKitRepositionMo = null;
      }
    }

    function attachSiteKitRepositionMo(li, mirrorItem) {
      detachSiteKitRepositionMo();
      if (!li || !mirrorItem || !window.MutationObserver) return;
      var t = null;
      siteKitRepositionMo = new MutationObserver(function () {
        if (t) clearTimeout(t);
        t = setTimeout(function () {
          repositionSiteKitFlyout(li, mirrorItem);
        }, 60);
      });
      try {
        siteKitRepositionMo.observe(li, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ['style', 'class']
        });
      } catch (_) {}
    }

    function unbindSiteKitLiLeave() {
      if (siteKitLiLeaveBound && siteKitLiLeaveBound.li && siteKitLiLeaveBound.fn) {
        try {
          siteKitLiLeaveBound.li.removeEventListener('mouseleave', siteKitLiLeaveBound.fn);
        } catch (_) {}
      }
      siteKitLiLeaveBound = null;
    }

    function cleanupSiteKitFlyout(li) {
      clearSiteKitLeaveTimer();
      detachSiteKitRepositionMo();
      unbindSiteKitLiLeave();
      hideSiteKitHoverBridge();
      document.body.classList.remove('yp-site-kit-mirror-hover');
      siteKitOpenKey = '';
      if (li && li.classList) {
        li.classList.remove('hover');
      }
      clearSiteKitSubwrapperStyles(li);
    }

    function scheduleRemoveNativeSiteKitHover(li) {
      clearSiteKitLeaveTimer();
      siteKitLeaveTimer = setTimeout(function () {
        siteKitLeaveTimer = null;
        cleanupSiteKitFlyout(li);
      }, SITE_KIT_LEAVE_MS);
    }

    function bindNativeSiteKitLiLeave(li, mirrorItem) {
      unbindSiteKitLiLeave();
      var fn = function (e) {
        var rel = e.relatedTarget;
        if (rel && rel.closest && rel.closest('.yp-site-kit-flyout-bridge')) return;
        if (rel && li.contains(rel)) return;
        if (rel && mirrorItem && mirrorItem.contains(rel)) return;
        scheduleRemoveNativeSiteKitHover(li);
      };
      li.addEventListener('mouseleave', fn);
      siteKitLiLeaveBound = { li: li, fn: fn };
    }

    function onDocumentMouseOverClearSiteKitLeave(e) {
      if (!e.target || !e.target.closest) return;
      if (e.target.closest('.yp-site-kit-flyout-bridge')) {
        clearSiteKitLeaveTimer();
        return;
      }
      if (e.target.closest('#wpadminbar .ab-sub-wrapper[data-yp-sk-flyout="1"]')) {
        clearSiteKitLeaveTimer();
        return;
      }
      if (e.target.closest('#wpadminbar li.googlesitekit-wp-adminbar')) {
        clearSiteKitLeaveTimer();
      }
    }

    function openSiteKitFromMirror(item) {
      var nodeId = item.getAttribute('data-toolbar-id') || '';
      var li = resolveNativeSiteKitLi(nodeId);
      if (!li) return;
      var key = (li.id || '') + '|' + (item.getAttribute('data-toolbar-id') || '');
      var isSame = key === siteKitOpenKey;

      clearSiteKitLeaveTimer();
      li.classList.add('hover');
      if (!isSame) {
        try {
          li.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, view: window }));
        } catch (_) {}
      }
      if (isWpAdminBarHidden()) {
        document.body.classList.add('yp-site-kit-mirror-hover');
      }
      if (!isSame) {
        bindNativeSiteKitLiLeave(li, item);
        attachSiteKitRepositionMo(li, item);
        siteKitOpenKey = key;
      }
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          repositionSiteKitFlyout(li, item);
        });
      });
    }

    function bind() {
      var bar = document.querySelector('.yp-toolbar-shortcuts');
      if (!bar || bar.dataset.adminBarForwardBound === '1') return false;
      bar.addEventListener(
        'click',
        function (e) {
          if (forwardGenericToolbarClick(e)) {
            return;
          }
          if (e.target.closest && e.target.closest('.yp-toolbar-menu')) return;
          var trigger = e.target.closest && e.target.closest('.yp-toolbar-item > .yp-toolbar-trigger');
          if (!trigger) return;
          var item = trigger.closest('.yp-toolbar-item');
          if (!item) return;
          if (!isSiteKitToolbarItem(item)) return;

          var nodeId = item.getAttribute('data-toolbar-id') || '';
          var nativeA = resolveNativeAdminBarTrigger(nodeId);
          if (!nativeA) return;

          e.preventDefault();
          e.stopImmediatePropagation();
          item.classList.remove('menu-open');
          try {
            nativeA.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
          } catch (_) {
            nativeA.click();
          }
        },
        true
      );

      bar.addEventListener(
        'mouseover',
        function (e) {
          if (e.target.closest && e.target.closest('.yp-toolbar-menu')) return;
          var item = e.target.closest && e.target.closest('.yp-toolbar-item');
          if (!item || !isSiteKitToolbarItem(item)) return;
          if (e.relatedTarget && item.contains(e.relatedTarget)) return;
          openSiteKitFromMirror(item);
        },
        true
      );

      bar.addEventListener(
        'mouseout',
        function (e) {
          if (e.target.closest && e.target.closest('.yp-toolbar-menu')) return;
          var item = e.target.closest && e.target.closest('.yp-toolbar-item');
          if (!item || !isSiteKitToolbarItem(item)) return;
          var rel = e.relatedTarget;
          if (rel && item.contains(rel)) return;
          var nodeId = item.getAttribute('data-toolbar-id') || '';
          var li = resolveNativeSiteKitLi(nodeId);
          if (!li) return;
          if (rel && rel.closest && rel.closest('.yp-site-kit-flyout-bridge')) {
            clearSiteKitLeaveTimer();
            return;
          }
          if (rel && rel.closest && rel.closest('#wpadminbar .ab-sub-wrapper[data-yp-sk-flyout="1"]')) {
            clearSiteKitLeaveTimer();
            return;
          }
          if (rel && rel.closest && rel.closest('#wpadminbar li.googlesitekit-wp-adminbar')) {
            clearSiteKitLeaveTimer();
            return;
          }
          scheduleRemoveNativeSiteKitHover(li);
        },
        true
      );

      document.addEventListener('mouseover', onDocumentMouseOverClearSiteKitLeave, true);

      document.addEventListener(
        'click',
        function (e) {
          if (!e.target.closest || !e.target.closest('.yp-toolbar-menu--swapped-portal')) {
            return;
          }
          forwardGenericToolbarClick(e);
        },
        true
      );

      bar.dataset.adminBarForwardBound = '1';
      return true;
    }
    if (!bind()) {
      var obs = new MutationObserver(function () {
        if (bind()) obs.disconnect();
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
    }
  })();

  // ---------------- Toolbar flyouts: click-only (no hover flyout on shortcuts) ----------------
  (function initToolbarFlyoutHoverIntent() {
    function bind() {
      var bar = document.querySelector('.yp-toolbar-shortcuts');
      if (!bar || bar.dataset.flyoutHoverBound === '1') return false;
      bar.dataset.flyoutHoverBound = '1';
      return true;
    }
    if (!bind()) {
      var obs = new MutationObserver(function () {
        if (bind()) obs.disconnect();
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
    }
  })();

  // ---------------- Toolbar flyouts: keep dropdowns inside the viewport (no horizontal scroll) ----------------
  (function initToolbarMenuViewportClamp() {
    var PAD = 8;

    function isVisible(el) {
      if (!el) return false;
      var cs = window.getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
      return el.getClientRects().length > 0;
    }

    function clampMenu(menu) {
      // Clear any previous horizontal shift before measuring (the CSS resting
      // transform only translates on Y, so X measurements stay accurate).
      menu.style.transform = '';
      if (!isVisible(menu)) return;

      // Leave mobile bottom-sheet / fixed-position menus alone — they are full
      // width and managed separately.
      if (window.getComputedStyle(menu).position === 'fixed') return;

      var rect = menu.getBoundingClientRect();
      var viewportWidth = document.documentElement.clientWidth;
      var shift = 0;

      if (rect.right > viewportWidth - PAD) {
        shift = -(rect.right - (viewportWidth - PAD));
      } else if (rect.left < PAD) {
        shift = PAD - rect.left;
      }

      if (shift) {
        menu.style.transform = 'translateX(' + Math.round(shift) + 'px)';
      }
    }

    function isNested(menu) {
      return !!menu.closest(
        '.yp-toolbar-menu .yp-toolbar-menu, .yp-toolbar-menu .yp-toolbar-submenu'
      );
    }

    function clampAll(bar) {
      var menus = bar.querySelectorAll('.yp-toolbar-menu, .yp-toolbar-submenu');
      // Outer menus first so nested submenus measure against the shifted parent.
      menus.forEach(function (menu) {
        if (!isNested(menu)) clampMenu(menu);
      });
      menus.forEach(function (menu) {
        if (isNested(menu)) clampMenu(menu);
      });
    }

    function schedule(bar) {
      window.requestAnimationFrame(function () {
        window.requestAnimationFrame(function () {
          clampAll(bar);
        });
      });
    }

    function bind() {
      var bars = document.querySelectorAll('.yp-breadcrumbs-bar');
      if (!bars.length) return false;
      bars.forEach(function (bar) {
        if (bar.dataset.menuClampBound === '1') return;
        bar.dataset.menuClampBound = '1';
        ['mouseover', 'focusin', 'click'].forEach(function (evt) {
          bar.addEventListener(
            evt,
            function () {
              schedule(bar);
            },
            true
          );
        });
        window.addEventListener('resize', function () {
          schedule(bar);
        });
      });
      return true;
    }

    if (!bind()) {
      var obs = new MutationObserver(function () {
        if (bind()) obs.disconnect();
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
    }
  })();

  // ---------------- Toolbar shortcuts (submenu on touch / no-hover) ----------------
  (function initToolbarSubmenus() {
    function preferToolbarClickMenus() {
      try {
        if (window.matchMedia('(max-width: 768px)').matches) return true;
        if (window.matchMedia('(pointer: coarse)').matches) return true;
        if (!window.matchMedia('(hover: hover)').matches) return true;
      } catch (_) {}
      return false;
    }

    function isMobileToolbarBar() {
      try {
        return window.matchMedia('(max-width: 768px)').matches;
      } catch (_) {
        return false;
      }
    }

    function syncToolbarMoreSwapChrome(bar, isOpen) {
      if (!bar) {
        return;
      }
      var tools = bar.closest('.yp-breadcrumbs-tools');
      if (tools) {
        tools.classList.toggle('yp-breadcrumbs-tools--shortcuts-swapped', !!isOpen);
      }
    }

    function closeToolbarMoreSwap(bar) {
      if (!bar) {
        return;
      }
      ypToolbarSwap.closeAllFlyouts(bar);
      bar.classList.remove('yp-toolbar-shortcuts--more-open');
      syncToolbarMoreSwapChrome(bar, false);
      var overflow = bar.querySelector('.yp-toolbar-item--overflow');
      if (!overflow) {
        return;
      }
      overflow.classList.remove('is-more-open', 'menu-open', 'is-flyout-open');
      overflow.querySelectorAll('.yp-toolbar-item.menu-open, .yp-toolbar-item.is-flyout-open').forEach(function (el) {
        el.classList.remove('menu-open', 'is-flyout-open');
        var childTrigger = el.querySelector(':scope > .yp-toolbar-trigger');
        if (childTrigger) {
          childTrigger.setAttribute('aria-expanded', 'false');
        }
      });
      overflow.querySelectorAll('.yp-toolbar-menu-item.submenu-open').forEach(function (el) {
        el.classList.remove('submenu-open');
      });
      var trigger = overflow.querySelector('.yp-toolbar-more-trigger, .yp-toolbar-trigger');
      if (trigger) {
        trigger.setAttribute('aria-expanded', 'false');
        var moreLabel = trigger.getAttribute('data-label-more');
        if (moreLabel) {
          trigger.setAttribute('aria-label', moreLabel);
          trigger.setAttribute('title', moreLabel);
        }
      }
    }

    function closeAllToolbarMoreSwap() {
      document.querySelectorAll('.yp-toolbar-shortcuts--more-open').forEach(function (bar) {
        closeToolbarMoreSwap(bar);
      });
    }

    function closeToolbarShortcutMenus(bar) {
      var root = bar || document;
      root.querySelectorAll('.yp-toolbar-shortcuts .yp-toolbar-item.menu-open, .yp-toolbar-shortcuts .yp-toolbar-item.is-flyout-open').forEach(function (el) {
        if (el.classList.contains('yp-toolbar-item--overflow')) {
          return;
        }
        el.classList.remove('menu-open', 'is-flyout-open');
        var childTrigger = el.querySelector(':scope > .yp-toolbar-trigger');
        if (childTrigger) {
          childTrigger.setAttribute('aria-expanded', 'false');
        }
        var shortcutsBar = el.closest('.yp-toolbar-shortcuts');
        if (shortcutsBar && ypToolbarSwap.isStripItem(el, shortcutsBar)) {
          ypToolbarSwap.closeFlyout(el);
        }
      });
      root.querySelectorAll('.yp-toolbar-shortcuts .yp-toolbar-menu-item.submenu-open').forEach(function (el) {
        el.classList.remove('submenu-open');
      });
    }

    function toggleToolbarMoreSwap(bar, overflowItem, trigger) {
      if (!bar || !overflowItem || !trigger) {
        return;
      }
      var isOpen = bar.classList.contains('yp-toolbar-shortcuts--more-open');
      closeAllToolbarMoreSwap();
      if (isOpen) {
        return;
      }
      bar.classList.add('yp-toolbar-shortcuts--more-open');
      syncToolbarMoreSwapChrome(bar, true);
      overflowItem.classList.add('is-more-open', 'menu-open');
      trigger.setAttribute('aria-expanded', 'true');
      var closeLabel = trigger.getAttribute('data-label-close');
      if (closeLabel) {
        trigger.setAttribute('aria-label', closeLabel);
        trigger.setAttribute('title', closeLabel);
      }
    }

    var mobileToolbarSheet = {
      root: null,
      backdrop: null,
      panel: null,
      docks: null,
    };

    function ensureMobileToolbarSheet() {
      if (mobileToolbarSheet.root) {
        return mobileToolbarSheet;
      }
      mobileToolbarSheet.docks = new Map();
      var root = document.createElement('div');
      root.id = 'yp-toolbar-mobile-sheet';
      root.className = 'yp-toolbar-mobile-sheet';
      root.hidden = true;

      var backdrop = document.createElement('div');
      backdrop.className = 'yp-toolbar-mobile-sheet__backdrop';
      backdrop.setAttribute('aria-hidden', 'true');

      var panel = document.createElement('div');
      panel.className = 'yp-toolbar-mobile-sheet__panel';
      panel.setAttribute('role', 'dialog');
      panel.setAttribute('aria-modal', 'true');
      panel.setAttribute('aria-label', 'Shortcuts menu');

      root.appendChild(backdrop);
      root.appendChild(panel);
      document.body.appendChild(root);

      backdrop.addEventListener('click', function () {
        closeMobileToolbarSheet();
      });

      mobileToolbarSheet.root = root;
      mobileToolbarSheet.backdrop = backdrop;
      mobileToolbarSheet.panel = panel;
      return mobileToolbarSheet;
    }

    function restoreMobileToolbarMenu(menu) {
      if (!menu || !mobileToolbarSheet.docks) {
        return;
      }
      var dock = mobileToolbarSheet.docks.get(menu);
      if (!dock || !dock.parent) {
        return;
      }
      menu.classList.remove('yp-toolbar-menu--mobile-sheet');
      if (dock.next && dock.next.parentNode === dock.parent) {
        dock.parent.insertBefore(menu, dock.next);
      } else {
        dock.parent.appendChild(menu);
      }
      mobileToolbarSheet.docks.delete(menu);
    }

    function closeMobileToolbarSheet() {
      if (!mobileToolbarSheet.panel) {
        return;
      }
      mobileToolbarSheet.panel.querySelectorAll('.yp-toolbar-menu').forEach(function (menu) {
        restoreMobileToolbarMenu(menu);
      });
      if (mobileToolbarSheet.root) {
        mobileToolbarSheet.root.classList.remove('is-open');
        mobileToolbarSheet.root.hidden = true;
      }
      document.body.classList.remove('yp-toolbar-sheet-open');
      document.querySelectorAll('.yp-toolbar-item.menu-open').forEach(function (el) {
        el.classList.remove('menu-open');
        var trig = el.querySelector(':scope > .yp-toolbar-trigger');
        if (trig) {
          trig.setAttribute('aria-expanded', 'false');
        }
      });
      document.querySelectorAll('.yp-toolbar-menu-item.submenu-open').forEach(function (el) {
        el.classList.remove('submenu-open');
      });
    }

    function openMobileToolbarSheet(item) {
      if (!item) {
        return;
      }
      var menu = item.querySelector(':scope > .yp-toolbar-menu');
      if (!menu || menu.classList.contains('yp-toolbar-menu--overflow')) {
        return;
      }

      ensureMobileToolbarSheet();
      closeMobileToolbarSheet();

      mobileToolbarSheet.docks.set(menu, {
        parent: menu.parentNode,
        next: menu.nextSibling,
      });
      menu.classList.add('yp-toolbar-menu--mobile-sheet');
      mobileToolbarSheet.panel.appendChild(menu);
      mobileToolbarSheet.root.hidden = false;
      mobileToolbarSheet.root.classList.add('is-open');
      document.body.classList.add('yp-toolbar-sheet-open');

      var trigger = item.querySelector(':scope > .yp-toolbar-trigger');
      if (trigger) {
        trigger.setAttribute('aria-expanded', 'true');
      }
      item.classList.add('menu-open');
    }

    function handleToolbarNestedSubmenuClick(e) {
      var nestedTrigger = e.target.closest && e.target.closest('.yp-toolbar-menu-link');
      if (!nestedTrigger) {
        return false;
      }
      var subWrap = nestedTrigger.closest('.yp-toolbar-menu-item.has-submenu');
      if (!subWrap || subWrap.querySelector(':scope > .yp-toolbar-menu-link') !== nestedTrigger) {
        return false;
      }
      var inPortal = nestedTrigger.closest('.yp-toolbar-menu--swapped-portal');
      var inShortcutsMenu =
        nestedTrigger.closest &&
        nestedTrigger.closest('.yp-toolbar-shortcuts .yp-toolbar-menu');
      if (!preferToolbarClickMenus() && !inPortal && !inShortcutsMenu) {
        return false;
      }
      if (
        !nestedTrigger.closest('#yp-toolbar-mobile-sheet') &&
        !nestedTrigger.closest('.yp-toolbar-shortcuts') &&
        !inPortal &&
        !inShortcutsMenu
      ) {
        return false;
      }
      e.preventDefault();
      e.stopPropagation();
      document.querySelectorAll('.yp-toolbar-menu-item.submenu-open').forEach(function (el) {
        if (el !== subWrap) {
          el.classList.remove('submenu-open');
        }
      });
      subWrap.classList.toggle('submenu-open');
      return true;
    }

    function bind() {
      var bar = document.querySelector('.yp-toolbar-shortcuts');
      if (!bar || bar.dataset.submenuBound === '1') {
        return false;
      }

      document.addEventListener(
        'click',
        function (e) {
          handleToolbarNestedSubmenuClick(e);
        },
        true
      );

      bar.addEventListener('click', function (e) {
        if (handleToolbarNestedSubmenuClick(e)) {
          return;
        }

        var moreTrigger = e.target.closest && e.target.closest('.yp-toolbar-more-trigger');
        if (moreTrigger) {
          var overflowItem = moreTrigger.closest('.yp-toolbar-item--overflow');
          var shortcutsBar = moreTrigger.closest('.yp-toolbar-shortcuts');
          if (overflowItem && shortcutsBar) {
            e.preventDefault();
            e.stopPropagation();
            toggleToolbarMoreSwap(shortcutsBar, overflowItem, moreTrigger);
            return;
          }
        }

        var stripAuxiliary =
          e.target.closest &&
          e.target.closest(
            '.yp-toolbar-overflow-strip .yp-command-palette-trigger, .yp-toolbar-overflow-strip .ysh-width__toggle, .yp-toolbar-overflow-strip .ysh-width__menu'
          );
        if (stripAuxiliary) {
          return;
        }

        var plainStripTrigger =
          e.target.closest &&
          e.target.closest('.yp-toolbar-overflow-strip > .yp-toolbar-item:not(.has-children) > .yp-toolbar-trigger');
        if (plainStripTrigger) {
          return;
        }

        var trigger = e.target.closest && e.target.closest('.yp-toolbar-item.has-children > .yp-toolbar-trigger');
        if (!trigger) return;
        var item = trigger.closest('.yp-toolbar-item');
        if (!item) return;
        if (item.classList.contains('yp-toolbar-item--overflow')) {
          return;
        }
        var shortcutsBar = item.closest('.yp-toolbar-shortcuts') || bar;
        var inOverflowStrip = ypToolbarSwap.isStripItem(item, shortcutsBar);
        e.preventDefault();
        e.stopPropagation();

        var itemMenu = item.querySelector(':scope > .yp-toolbar-menu');
        var isOpen =
          item.classList.contains('menu-open') ||
          item.classList.contains('is-flyout-open') ||
          (itemMenu && mobileToolbarSheet.docks && mobileToolbarSheet.docks.has(itemMenu));

        if (inOverflowStrip && !isMobileToolbarBar()) {
          shortcutsBar.querySelectorAll('.yp-toolbar-overflow-strip .yp-toolbar-item.menu-open, .yp-toolbar-overflow-strip .yp-toolbar-item.is-flyout-open').forEach(function (el) {
            if (el !== item) {
              el.classList.remove('menu-open', 'is-flyout-open');
              ypToolbarSwap.closeFlyout(el);
              var otherTrigger = el.querySelector(':scope > .yp-toolbar-trigger');
              if (otherTrigger) {
                otherTrigger.setAttribute('aria-expanded', 'false');
              }
            }
          });
          if (!isOpen) {
            item.classList.add('menu-open', 'is-flyout-open');
            trigger.setAttribute('aria-expanded', 'true');
            ypToolbarSwap.openFlyout(item);
          } else {
            item.classList.remove('menu-open', 'is-flyout-open');
            trigger.setAttribute('aria-expanded', 'false');
            ypToolbarSwap.closeFlyout(item);
          }
          return;
        }

        closeAllToolbarMoreSwap();
        if (isMobileToolbarBar()) {
          if (!isOpen) {
            openMobileToolbarSheet(item);
          } else {
            closeMobileToolbarSheet();
          }
          return;
        }

        document.querySelectorAll('.yp-toolbar-item.menu-open').forEach(function (el) {
          if (el !== item) el.classList.remove('menu-open');
        });
        document.querySelectorAll('.yp-toolbar-menu-item.submenu-open').forEach(function (el) {
          el.classList.remove('submenu-open');
        });
        if (!isOpen) {
          item.classList.add('menu-open');
          var trig = item.querySelector(':scope > .yp-toolbar-trigger');
          if (trig) {
            trig.setAttribute('aria-expanded', 'true');
          }
        } else {
          item.classList.remove('menu-open');
          var trigClose = item.querySelector(':scope > .yp-toolbar-trigger');
          if (trigClose) {
            trigClose.setAttribute('aria-expanded', 'false');
          }
        }
      }, true);
      document.addEventListener('click', function (e) {
        if (e.target.closest && e.target.closest('#yp-toolbar-mobile-sheet')) {
          return;
        }
        if (
          e.target.closest &&
          !e.target.closest('.yp-toolbar-shortcuts') &&
          !e.target.closest('.yp-toolbar-menu--swapped-portal')
        ) {
          closeAllToolbarMoreSwap();
          closeMobileToolbarSheet();
          closeToolbarShortcutMenus();
        }
      });
      window.addEventListener('resize', function () {
        ypToolbarSwap.syncFlyouts();
      });
      window.addEventListener(
        'scroll',
        function () {
          ypToolbarSwap.syncFlyouts();
        },
        true
      );

      bar.dataset.submenuBound = '1';
      return true;
    }
    if (!bind()) {
      var obs = new MutationObserver(function () {
        if (bind()) {
          obs.disconnect();
        }
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
    }
  })();

  // ---------------- Yoast admin-bar icon sync ----------------
  // In some Yoast versions the icon is an empty placeholder element:
  //   <div id="yoast-ab-icon" class="yoast-logo svg">...</div>
  // and the actual background-image is applied by Yoast CSS/JS inside #wpadminbar.
  // When we mirror icons into YOOAdmin header (outside #wpadminbar), the background
  // may be missing. We sync the computed background-image from the real admin-bar
  // icon to the mirrored placeholder so it doesn't disappear.
  (function initYoastIconSync() {
    function getBackgroundImage(el) {
      try {
        if (!el) return '';
        var inline = el.style && el.style.backgroundImage ? el.style.backgroundImage : '';
        if (inline && inline !== 'none') return inline;
        if (window.getComputedStyle) {
          var cs = window.getComputedStyle(el);
          return cs && cs.backgroundImage ? cs.backgroundImage : '';
        }
      } catch (_) {}
      return '';
    }

    function sync() {
      var src = document.querySelector('#wpadminbar #yoast-ab-icon');
      if (!src) return;
      var bg = getBackgroundImage(src);
      if (!bg || bg === 'none') return;

      // Apply only to the mirrored Yoast item in YOOAdmin header.
      // Avoid syncing any other mirrored elements that might accidentally share the same id.
      var targets = document.querySelectorAll('.yp-toolbar-item[data-toolbar-id="wpseo-menu"] .yoast-logo, .yp-toolbar-item[data-toolbar-id="wpseo-menu"] #yoast-ab-icon');
      targets.forEach(function (t) {
        if (!t) return;
        try {
          t.classList && t.classList.add('ab-icon');
          // Yoast's data-uri SVG often includes fixed grey fill, so we recolor
          // by using the SVG as a mask and painting with currentColor.
          var canMask = false;
          try {
            if (window.CSS && CSS.supports) {
              canMask = CSS.supports('mask-image', bg) || CSS.supports('-webkit-mask-image', bg);
            } else {
              canMask = ('maskImage' in t.style) || ('webkitMaskImage' in t.style);
            }
          } catch (_) {}

          // Ensure theme color flows into currentColor.
          t.style.color = t.style.color || 'var(--_yp-primary)';

          if (canMask) {
            t.style.backgroundImage = 'none';
            t.style.backgroundColor = 'currentColor';
            t.style.webkitMaskImage = bg;
            t.style.maskImage = bg;
            t.style.webkitMaskRepeat = 'no-repeat';
            t.style.maskRepeat = 'no-repeat';
            t.style.webkitMaskPosition = 'center';
            t.style.maskPosition = 'center';
            t.style.webkitMaskSize = 'contain';
            t.style.maskSize = 'contain';
          } else {
            // Fallback: keep original background-image if masks are unsupported.
            t.style.backgroundImage = bg;
            t.style.backgroundSize = t.style.backgroundSize || 'contain';
            t.style.backgroundRepeat = t.style.backgroundRepeat || 'no-repeat';
            t.style.backgroundPosition = t.style.backgroundPosition || 'center';
          }
          t.style.width = t.style.width || '18px';
          t.style.height = t.style.height || '18px';
          t.style.display = t.style.display || 'inline-block';
        } catch (_) {}
      });
    }

    function bind() {
      sync();
      var src = document.querySelector('#wpadminbar #yoast-ab-icon');
      if (!src || !window.MutationObserver) return;

      var mo = new MutationObserver(function () {
        // Yoast may set background-image after init; keep it in sync.
        sync();
      });
      mo.observe(src, { attributes: true, attributeFilter: ['style', 'class'] });
      setTimeout(function () { try { mo.disconnect(); } catch (_) {} }, 6000);
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', bind, { once: true });
    } else {
      bind();
    }
  })();

  // ---------------- Site Kit (and CSS-only admin-bar icons) background sync ----------------
  (function initSiteKitToolbarIconSync() {
    function getBackgroundImage(el) {
      try {
        if (!el) return '';
        var inline = el.style && el.style.backgroundImage ? el.style.backgroundImage : '';
        if (inline && inline !== 'none') return inline;
        if (window.getComputedStyle) {
          var cs = window.getComputedStyle(el);
          return cs && cs.backgroundImage ? cs.backgroundImage : '';
        }
      } catch (_) {}
      return '';
    }

    function paintTarget(target, bg) {
      if (!target || !bg || bg === 'none') return;
      try {
        var canMask = false;
        try {
          if (window.CSS && CSS.supports) {
            canMask = CSS.supports('mask-image', bg) || CSS.supports('-webkit-mask-image', bg);
          } else {
            canMask = ('maskImage' in target.style) || ('webkitMaskImage' in target.style);
          }
        } catch (_) {}

        target.style.display = target.style.display || 'inline-block';
        target.style.width = target.style.width || '18px';
        target.style.height = target.style.height || '18px';
        target.style.maxWidth = target.style.maxWidth || '18px';
        target.style.maxHeight = target.style.maxHeight || '18px';
        target.style.color = target.style.color || 'var(--_yp-primary, #eda934)';

        if (canMask) {
          target.style.backgroundImage = 'none';
          target.style.backgroundColor = 'currentColor';
          target.style.webkitMaskImage = bg;
          target.style.maskImage = bg;
          target.style.webkitMaskRepeat = 'no-repeat';
          target.style.maskRepeat = 'no-repeat';
          target.style.webkitMaskPosition = 'center';
          target.style.maskPosition = 'center';
          target.style.webkitMaskSize = 'contain';
          target.style.maskSize = 'contain';
        } else {
          target.style.backgroundColor = '';
          target.style.backgroundImage = bg;
          target.style.backgroundSize = 'contain';
          target.style.backgroundRepeat = 'no-repeat';
          target.style.backgroundPosition = 'center';
        }
      } catch (_) {}
    }

    function sync() {
      var src = document.querySelector('#wpadminbar .googlesitekit-wp-adminbar__icon');
      if (!src) return;
      var bg = getBackgroundImage(src);
      if (!bg || bg === 'none') return;

      document.querySelectorAll('.yp-toolbar-site-kit-icon').forEach(function (t) {
        paintTarget(t, bg);
      });
    }

    function bind() {
      sync();
      var bar = document.getElementById('wpadminbar');
      var n = 0;
      var iv = setInterval(function () {
        sync();
        n++;
        if (n > 60) clearInterval(iv);
      }, 250);

      if (bar && window.MutationObserver) {
        var mo = new MutationObserver(function () {
          sync();
        });
        try {
          mo.observe(bar, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });
        } catch (_) {}
        setTimeout(function () {
          try {
            mo.disconnect();
          } catch (_) {}
        }, 15000);
      }

      var sk = document.querySelector('#wpadminbar .googlesitekit-wp-adminbar__icon');
      if (sk && window.MutationObserver) {
        var mo2 = new MutationObserver(function () {
          sync();
        });
        try {
          mo2.observe(sk, { attributes: true, attributeFilter: ['style', 'class'] });
        } catch (_) {}
        setTimeout(function () {
          try {
            mo2.disconnect();
          } catch (_) {}
        }, 15000);
      }
    }

    window.addEventListener('load', function () {
      setTimeout(sync, 100);
    }, { once: true });

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', bind, { once: true });
    } else {
      bind();
    }
  })();

  // ---------------- Admin Utilities ----------------
  window.yooadmAdminEssential = {
    // Utility functions for admin panel
    utility: {
      debounce: function(func, wait) {
        var timeout;
        return function executedFunction() {
          var context = this;
          var args = arguments;
          var later = function() {
            timeout = null;
            func.apply(context, args);
          };
          clearTimeout(timeout);
          timeout = setTimeout(later, wait);
        };
      },
      
      throttle: function(func, limit) {
        var inThrottle;
        return function() {
          var args = arguments;
          var context = this;
          if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(function() { inThrottle = false; }, limit);
          }
        };
      }
    }
  };
})();
