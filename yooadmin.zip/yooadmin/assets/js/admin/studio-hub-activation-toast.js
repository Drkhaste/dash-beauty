(function ($) {
  'use strict';

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function cleanUrl() {
    if (!window.history || typeof window.history.replaceState !== 'function') {
      return;
    }

    try {
      var url = new URL(window.location.href);
      url.searchParams.delete('ysh_activated');
      window.history.replaceState({}, document.title, url.toString());
    } catch (e) {
      /* noop */
    }
  }

  $(function () {
    var cfg = window.yooadminStudioHubActivationToast || {};
    if (!cfg.message) {
      return;
    }

    var $toast = $(
      '<div class="ysh-activation-toast" role="status" aria-live="polite">' +
        '<span class="ysh-activation-toast__icon dashicons dashicons-yes-alt" aria-hidden="true"></span>' +
        '<span class="ysh-activation-toast__text">' +
        escapeHtml(cfg.message) +
        '</span>' +
      '</div>'
    );

    $('body').append($toast);
    window.requestAnimationFrame(function () {
      $toast.addClass('is-visible');
    });

    window.setTimeout(function () {
      $toast.removeClass('is-visible');
      window.setTimeout(function () {
        $toast.remove();
      }, 320);
    }, 4200);

    cleanUrl();
  });
})(jQuery);
