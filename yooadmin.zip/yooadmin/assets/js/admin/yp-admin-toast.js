/**
 * YOOAdmin — global admin toast API (top-right yp-toast-message).
 *
 * @package YOOAdmin
 */

(function ($) {
    'use strict';

    var DEFAULT_DURATION = 5000;
    var activeTimer = null;

    function normalizeType(type) {
        var t = String(type || 'info').toLowerCase();
        if (t === 'success' || t === 'error' || t === 'warning' || t === 'info') {
            return t;
        }
        return 'info';
    }

    function toastIcon(type) {
        if (type === 'success') {
            return '✓';
        }
        if (type === 'error') {
            return '✕';
        }
        if (type === 'warning') {
            return '⚠';
        }
        return 'ℹ';
    }

    function escapeHtml(text) {
        return $('<div/>').text(String(text || '')).html();
    }

    function showYpToast(message, type, duration) {
        type = normalizeType(type);
        duration = typeof duration === 'number' && duration > 0 ? duration : DEFAULT_DURATION;

        $('.yp-toast-message.yooadmin-global-toast').remove();
        if (activeTimer) {
            clearTimeout(activeTimer);
            activeTimer = null;
        }

        var $toast = $(
            '<div class="yp-toast-message yp-toast-' +
                type +
                ' yooadmin-global-toast" role="status" aria-live="polite">' +
                '<span class="yp-toast-icon" aria-hidden="true">' +
                toastIcon(type) +
                '</span>' +
                '<span class="yp-toast-text"></span>' +
                '</div>'
        );
        $toast.find('.yp-toast-text').html(escapeHtml(message));
        $('body').append($toast);

        setTimeout(function () {
            $toast.addClass('yp-toast-show');
        }, 10);

        activeTimer = setTimeout(function () {
            $toast.removeClass('yp-toast-show');
            setTimeout(function () {
                $toast.remove();
            }, 300);
            activeTimer = null;
        }, duration);

        return $toast;
    }

    /**
     * @param {string} message
     * @param {string} [type] success|error|warning|info
     * @param {number} [duration]
     */
    function show(message, type, duration) {
        message = String(message || '').trim();
        if (!message) {
            return null;
        }

        type = normalizeType(type);

        if (
            window.yooadmNotificationsUi &&
            typeof window.yooadmNotificationsUi.showToastMessage === 'function'
        ) {
            window.yooadmNotificationsUi.showToastMessage(message, type === 'warning' ? 'info' : type);
            return null;
        }

        return showYpToast(message, type, duration);
    }

    window.yooadminShowToast = show;

    window.yooadmToast = {
        show: function (message, type, duration) {
            return show(message, type, duration);
        },
        success: function (message, duration) {
            return show(message, 'success', duration);
        },
        error: function (message, duration) {
            return show(message, 'error', duration);
        },
        warning: function (message, duration) {
            return show(message, 'warning', duration);
        },
        info: function (message, duration) {
            return show(message, 'info', duration);
        },
    };
})(jQuery);
