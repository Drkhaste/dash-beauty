/**
 * YOOAdmin - Setup wizard script
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    const yooadmWizardModule = {
        initialized: false,
        _revertingBrandingColors: false,
        _brandingDraftSnapshot: null,

        /**
         * Ensure browser cookie is ON before navigating to YOOAdmin dashboard.
         */
        setFocusCookieOn: function() {
            document.cookie = 'yoo_focus=on; path=/; max-age=31536000; SameSite=Lax';
        },

        redirectToDashboard: function(url) {
            this.setFocusCookieOn();
            window.location.href = url || window.yooadmWizard.dashboardUrl;
        },
        
        /**
         * Initialize
         */
        init: function() {
            // Prevent double initialization
            if (this.initialized) {
                return;
            }
            
            // Wait for yooadmWizard to be defined
            if (typeof window.yooadmWizard === 'undefined') {
                setTimeout(() => this.init(), 100);
                return;
            }
            
            // If currentStep is empty, get from URL
            if (!window.yooadmWizard.currentStep || window.yooadmWizard.currentStep === '') {
                const urlStep = new URLSearchParams(window.location.search).get('step') || 'welcome';
                window.yooadmWizard.currentStep = urlStep;
            }
            
            this.forceHideElements();
            this.initAppearance();
            this.bindEvents();
            this.initColorPickers();
            this.initMediaUploader();
            this.initTermsCheckbox();
            this.updateLicenseStepFooter(window.yooadmWizard.isLicenseActive);
            this.applySavedCustomizations();
            
            // Trigger celebration on launch step + prevent browser back
            if (window.yooadmWizard.currentStep === 'launch') {
                setTimeout(() => {
                    this.triggerCelebration();
                }, 300);
                history.pushState(null, '', window.location.href);
                window.addEventListener('popstate', function() {
                    history.pushState(null, '', window.location.href);
                });
            }
            
            // Mark as initialized
            this.initialized = true;
        },
        
        /**
         * Force hide all admin elements
         */
        forceHideElements: function() {
            // Force hide YOOAdmin elements
            $('.yooadmin-header, .yooadmin-sidebar, .yooadmin-main-content, .yooadmin-notification-icon').hide();
            $('#wpadminbar, #adminmenumain, #adminmenuback').hide();
            
            // Clean body classes
            $('body').addClass('yooadmin-wizard-fullscreen');
        },

        /**
         * Light / dark / system appearance (Studio Hub style).
         */
        initAppearance: function() {
            const $page = $('.yooadmin-wizard-page');
            if (!$page.length) {
                return;
            }

            const cfg = window.yooadmWizard || {};
            const mediaQuery = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

            const systemIsDark = function() {
                try {
                    return !!(mediaQuery && mediaQuery.matches);
                } catch (e) {
                    return false;
                }
            };

            const resolveEffective = function(pref) {
                if (pref === 'dark') {
                    return 'dark';
                }
                if (pref === 'light') {
                    return 'light';
                }
                return systemIsDark() ? 'dark' : 'light';
            };

            const applyAppearance = function(pref) {
                const normalized = pref === 'dark' || pref === 'light' ? pref : 'auto';
                const effective = resolveEffective(normalized);

                $page.attr('data-yoo-wizard-pref', normalized);
                $page.attr('data-yoo-wizard-effective', effective);
                $page.toggleClass('yoo-wizard--dark', effective === 'dark');

                document.documentElement.setAttribute('data-yoo-wizard-pref', normalized);
                document.documentElement.setAttribute('data-yoo-wizard-effective', effective);
                document.documentElement.classList.toggle('yoo-wizard-html-dark', effective === 'dark');
                $('body').toggleClass('yoo-wizard-dark-body', effective === 'dark');

                $page.find('.yoo-wizard-appearance-btn').removeClass('is-active');
                $page
                    .find('.yoo-wizard-appearance-btn[data-yoo-wizard-pref="' + normalized + '"]')
                    .addClass('is-active');

                yooadmWizardModule.syncWizardHeader($page, effective);
                yooadmWizardModule.syncBrandingColorsLock();
            };

            applyAppearance($page.attr('data-yoo-wizard-pref') || cfg.colorMode || 'auto');

            $(document).off('click', '.yoo-wizard-appearance-btn');
            $(document).on('click', '.yoo-wizard-appearance-btn', function(e) {
                e.preventDefault();
                const pref = $(this).attr('data-yoo-wizard-pref') || 'auto';
                applyAppearance(pref);

                if (cfg.ajaxurl && cfg.colorModeNonce) {
                    $.post(cfg.ajaxurl, {
                        action: 'yooadmin_wizard_save_color_mode',
                        nonce: cfg.colorModeNonce,
                        color_mode: pref
                    });
                }
            });

            const onSystemChange = function() {
                if (($page.attr('data-yoo-wizard-pref') || 'auto') === 'auto') {
                    applyAppearance('auto');
                }
            };

            if (mediaQuery && typeof mediaQuery.addEventListener === 'function') {
                mediaQuery.addEventListener('change', onSystemChange);
            } else if (mediaQuery && typeof mediaQuery.addListener === 'function') {
                mediaQuery.addListener(onSystemChange);
            }
        },

        /**
         * Header chrome follows appearance (brand tint in light, blended dark in dark).
         */
        syncWizardHeader: function($page, effective) {
            const $root = $page && $page.length ? $page : $('.yooadmin-wizard-page');
            if (!$root.length) {
                return;
            }

            const brand = $root.css('--yoo-wizard-header-brand') || '#4B4B4B';
            if (effective === 'dark') {
                $root[0].style.removeProperty('--yoo-wizard-header');
            } else {
                $root.css('--yoo-wizard-header', brand);
            }
        },

        isWizardEffectiveDark: function() {
            const $page = $('.yooadmin-wizard-page');
            if ($page.hasClass('yoo-wizard--dark')) {
                return true;
            }
            if (document.documentElement.classList.contains('yoo-wizard-html-dark')) {
                return true;
            }

            return ($page.attr('data-yoo-wizard-effective') || '') === 'dark';
        },

        isBrandingStep: function() {
            return $('.yooadmin-wizard-branding').length > 0 ||
                (window.yooadmWizard && window.yooadmWizard.currentStep === 'branding');
        },

        getCurrentColorMode: function() {
            const $page = $('.yooadmin-wizard-page');
            const pref = ($page.attr('data-yoo-wizard-pref') || '').trim();
            if (pref === 'light' || pref === 'dark' || pref === 'auto') {
                return pref;
            }
            const cfg = window.yooadmWizard || {};
            if (cfg.colorMode === 'light' || cfg.colorMode === 'dark' || cfg.colorMode === 'auto') {
                return cfg.colorMode;
            }
            return 'auto';
        },

        getDraftBrandingColors: function() {
            const saved = (window.yooadmWizard && window.yooadmWizard.savedColors) || {};
            const colors = {};

            $('.wizard-color-picker').each(function() {
                const $input = $(this);
                const key = $input.data('color-key');
                if (!key) {
                    return;
                }
                const fallback = $input.data('default-color') || saved[key] || '';
                colors[key] = $input.val() || fallback;
            });

            return colors;
        },

        applyBrandingCssVariables: function(colors) {
            if (!this.isBrandingStep()) {
                return;
            }

            colors = colors || this.getDraftBrandingColors();
            const $page = $('.yooadmin-wizard-page');
            const root = document.documentElement;
            const pageEl = $page[0];

            if (colors.primary) {
                const primaryHover = 'color-mix(in srgb, ' + colors.primary + ' 90%, #000 10%)';
                root.style.setProperty('--yooadmin-brand-source', colors.primary);
                root.style.setProperty('--yooadmin-primary', colors.primary);
                root.style.setProperty('--yooadmin-primary-hover', primaryHover);
                root.style.setProperty('--yp-primary', colors.primary);
                root.style.setProperty('--yp-brand', colors.primary);
                if (pageEl) {
                    pageEl.style.setProperty('--yooadmin-brand-source', colors.primary);
                    pageEl.style.setProperty('--yooadmin-primary', colors.primary);
                    pageEl.style.setProperty('--yooadmin-primary-hover', primaryHover);
                    pageEl.style.setProperty('--yp-primary', colors.primary);
                    pageEl.style.setProperty('--yp-brand', colors.primary);
                }
                if (this.isWizardEffectiveDark()) {
                    if (pageEl) {
                        pageEl.style.removeProperty('--yoo-wizard-brand');
                    }
                } else {
                    $page.css('--yoo-wizard-brand', colors.primary);
                }
            }
            if (colors.header_bg) {
                $page.css('--yoo-wizard-header-brand', colors.header_bg);
                root.style.setProperty('--yooadmin-header-bg-source', colors.header_bg);
                if (pageEl) {
                    pageEl.style.setProperty('--yooadmin-header-bg-source', colors.header_bg);
                }
            }
            if (colors.sidebar_bg) {
                root.style.setProperty('--yooadmin-sidebar-bg-source', colors.sidebar_bg);
                if (pageEl) {
                    pageEl.style.setProperty('--yooadmin-sidebar-bg-source', colors.sidebar_bg);
                }
            }
            if (colors.card_icon) {
                $('.logo-placeholder .dashicons').css('color', colors.card_icon);
                this.syncWizardFaviconPlaceholderColor(colors.card_icon);
            }

            this._brandingDraftSnapshot = Object.assign({}, colors);

            const effective = $page.attr('data-yoo-wizard-effective') ||
                (root.classList.contains('yoo-wizard-html-dark') ? 'dark' : 'light');
            this.syncWizardHeader($page, effective);
        },

        revertBrandingColorInputs: function() {
            if (this._revertingBrandingColors) {
                return;
            }

            this._revertingBrandingColors = true;

            const saved = (window.yooadmWizard && window.yooadmWizard.savedColors) || {};
            const draft = this._brandingDraftSnapshot || saved;

            $('.wizard-color-picker').each(function() {
                const $input = $(this);
                const key = $input.data('color-key');
                const fallback = $input.data('default-color') || '';
                const val = (key && draft[key]) ? draft[key] : fallback;

                if (!val || $input.val() === val) {
                    return;
                }

                $input.val(val);
                if ($.fn.wpColorPicker && $input.closest('.wp-picker-container').length) {
                    try {
                        $input.wpColorPicker('color', val);
                    } catch (e) {
                        // Color picker not ready yet.
                    }
                }
            });

            const self = this;
            $('.wizard-color-picker').each(function() {
                self.syncWizardColorControl($(this));
            });

            this._revertingBrandingColors = false;
        },

        syncBrandingColorsLock: function() {
            const $section = $('.wizard-colors-section');
            if (!$section.length || !this.isBrandingStep()) {
                return;
            }

            const locked = this.isWizardEffectiveDark();
            const strings = (window.yooadmWizard && window.yooadmWizard.strings) || {};

            this._brandingDraftSnapshot = this.getDraftBrandingColors();

            $section.toggleClass('is-colors-locked', locked);

            let $notice = $section.find('.wizard-colors-dark-notice');
            if (locked) {
                if (!$notice.length) {
                    $notice = $(
                        '<div class="wizard-colors-dark-notice" role="status">' +
                            '<span class="wizard-colors-dark-notice__icon dashicons dashicons-lightbulb" aria-hidden="true"></span>' +
                            '<div class="wizard-colors-dark-notice__copy">' +
                                '<p class="wizard-colors-dark-notice__title"></p>' +
                                '<p class="wizard-colors-dark-notice__text"></p>' +
                            '</div>' +
                            '<button type="button" class="wizard-colors-dark-notice__btn"></button>' +
                        '</div>'
                    );
                    $section.prepend($notice);

                    $notice.find('.wizard-colors-dark-notice__btn').on('click', function(e) {
                        e.preventDefault();
                        $('.yoo-wizard-appearance-btn[data-yoo-wizard-pref="light"]').trigger('click');
                    });
                }

                $notice.find('.wizard-colors-dark-notice__title').text(
                    strings.brandingColorsLightTitle || 'Switch to Light mode to edit colors'
                );
                $notice.find('.wizard-colors-dark-notice__text').text(
                    strings.brandingColorsLightText || 'Brand colors can only be changed in Light mode for an accurate preview.'
                );
                $notice.find('.wizard-colors-dark-notice__btn').text(
                    strings.switchToLight || 'Switch to Light'
                );
            } else {
                $notice.remove();
            }

            $('.wizard-color-picker').prop('disabled', locked);
            $section.find('.wp-picker-container').toggleClass('is-disabled', locked);
            $section.find('.wizard-modern-color').toggleClass('is-disabled', locked);
            $section.find('.wizard-modern-color__trigger, .wizard-modern-color__swatch, .wizard-modern-color__hex, .wizard-modern-color__reset').prop('disabled', locked);
            $('#reset-colors').prop('disabled', locked);

            if (locked) {
                this.clearBrandingPreviewStyles();
            } else {
                this.updateBrandingPreview();
            }
        },

        /**
         * Remove live branding preview inline styles (light-mode preview leaks into dark).
         */
        clearBrandingPreviewStyles: function() {
            const $page = $('.yooadmin-wizard-page');

            $('.yooadmin-setup-steps li.active .step-number').css({
                backgroundColor: '',
                borderColor: '',
                boxShadow: ''
            });
            $('.yooadmin-setup-steps li.completed .step-number').css({
                backgroundColor: '',
                borderColor: ''
            });
            $('.yooadmin-setup-steps li.completed').css('color', '');

            $('.wizard-btn-primary, .wizard-btn-next').each(function() {
                this.style.removeProperty('background-color');
                this.style.removeProperty('color');
            });

            $('.yooadmin-wizard-card').css('border-color', '');
            $('.yooadmin-setup-steps').css('border-bottom-color', '');
            $('.wizard-step-footer').css('border-top-color', '');
            $('.wizard-subtitle, .description, .step-name').css('color', '');
            $('.wizard-step-body h3, .wizard-section label').css('color', '');
            $('.yooadmin-wizard-header, .yooadmin-wizard-header *').css('color', '');
            $('.logo-placeholder .dashicons').css('color', '');
            $('#wizard-admin-favicon-preview-wrap:not(.has-icon) .dashicons').css('color', '');
            $('.wizard-compact-setting input[type="checkbox"]:checked ~ .wizard-compact-checkmark').css({
                background: '',
                borderColor: ''
            });
            $('.wizard-section-hint .yoo-hint').css('color', '');

            this.applyBrandingCssVariables(this._brandingDraftSnapshot || this.getDraftBrandingColors());
        },

        /**
         * Bind events
         */
        bindEvents: function() {
            // Remove all previous event listeners to prevent duplicates
            $(document).off('click', '.wizard-btn[data-action]');
            $(document).off('click', '#wizard-launch-btn');
            $(document).off('change', '.wizard-color-picker');
            $(document).off('change', '#logo_id');
            $(document).off('input change', '#wizard-logo-width');
            $(document).off('click', '.wizard-logo-width-reset');
            $(document).off('click', '#skip-popup-close, #skip-popup-overlay');
            $(document).off('change', 'input[name="skip_option"]');
            $(document).off('click', '#skip-enable-btn');
            $(document).off('click', '#skip-continue-btn');
            $(document).off('click', '#reset-logo');
            $(document).off('click', '#reset-colors');
            $(document).off('yooadmin:wizard-license-status', '.yooadmin-wizard-page');
            
            // Navigation buttons
            $(document).on('click', '.wizard-btn[data-action]', this.handleNavigation.bind(this));

            $(document).on('yooadmin:wizard-license-status', '.yooadmin-wizard-page', (e, isActive) => {
                this.updateLicenseStepFooter(isActive);
            });
            
            // Launch button
            $(document).on('click', '#wizard-launch-btn', this.handleLaunch.bind(this));
            
            // License activation
            // Get Free License button is now a direct link to portal - no handler needed
            
            // Convert banners checkbox change
            $(document).on('change', '#wizard-convert-banners', this.handleConvertBannersToggle.bind(this));
            
            // Color picker changes
            $(document).on('change', '.wizard-color-picker', function(e) {
                if (yooadmWizardModule.isWizardEffectiveDark() && yooadmWizardModule.isBrandingStep()) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    yooadmWizardModule.revertBrandingColorInputs();
                    return false;
                }
                yooadmWizardModule.updateBrandingPreview();
            });
            
            // Logo upload changes
            $(document).on('change', '#logo_id', this.updateBrandingPreview.bind(this));
            $(document).on('input change', '#wizard-logo-width', (e) => {
                this.applyWizardLogoWidth($(e.currentTarget).val());
            });
            $(document).on('click', '.wizard-logo-width-reset', (e) => {
                e.preventDefault();
                this.applyWizardLogoWidth(150);
            });
            
            // Skip popup events
            $(document).on('click', '#skip-popup-close, #skip-popup-overlay', this.hideSkipPopup.bind(this));
            
            // Radio button changes
            $(document).on('change', 'input[name="skip_option"]', function() {
                const value = $(this).val();
                
                if (value === 'enable') {
                    $('#skip-enable-btn').show().prop('disabled', false);
                    $('#skip-continue-btn').hide();
                } else if (value === 'wordpress') {
                    $('#skip-enable-btn').hide();
                    $('#skip-continue-btn').show();
                }
            });
            
            // Button clicks
            $(document).on('click', '#skip-enable-btn', this.handleSkipEnableYOOAdmin.bind(this));
            $(document).on('click', '#skip-continue-btn', this.handleSkipContinueWordPress.bind(this));
            
            // Reset buttons
            $(document).on('click', '#reset-logo', this.resetLogo.bind(this));
            $(document).on('click', '#reset-colors', this.resetColors.bind(this));
        },
        
        /**
         * Handle navigation
         */
        handleNavigation: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const action = $btn.data('action');
            
            switch(action) {
                case 'next':
                    this.saveAndNext();
                    break;
                case 'prev':
                    this.goToPrevious();
                    break;
                case 'skip':
                    this.skipWizard();
                    break;
                case 'exit':
                    this.exitAndLaunch();
                    break;
            }
        },
        
        /**
         * Save current step and go to next
         */
        saveAndNext: function() {
            const currentStep = window.yooadmWizard.currentStep;
            
            if (!currentStep || currentStep === '') {
                alert('Configuration error: Unable to determine current step');
                return;
            }
            
            const stepData = this.getStepData(currentStep);
            
            // Show loading
            $('.wizard-btn-next').prop('disabled', true).addClass('loading');
            
            $.ajax({
                url: window.yooadmWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'yooadmin_wizard_save_step',
                    nonce: window.yooadmWizard.nonce,
                    step: currentStep,
                    data: stepData,
                    color_mode: this.getCurrentColorMode()
                },
                success: (response) => {
                    if (response.success) {
                        this.goToNext();
                    } else {
                        alert(response.data.message || window.yooadmWizard.strings.error);
                        $('.wizard-btn-next').prop('disabled', false).removeClass('loading');
                    }
                },
                error: () => {
                    alert(window.yooadmWizard.strings.error);
                    $('.wizard-btn-next').prop('disabled', false).removeClass('loading');
                }
            });
        },
        
        /**
         * Get step data
         */
        getStepData: function(step) {
            const data = {};
            const actualStep = step || window.yooadmWizard.currentStep;
            const selector = '.yooadmin-wizard-' + actualStep + ' input, .yooadmin-wizard-' + actualStep + ' select, .yooadmin-wizard-' + actualStep + ' textarea';
            
            // Get all form inputs in current step
            $(selector).each(function() {
                const $input = $(this);
                const name = $input.attr('name');
                
                if (!name) return;
                
                // Handle colors[key] format - EXACTLY LIKE Theme Settings form
                if (name.match(/^colors\[([^\]]+)\]$/)) {
                    if (!data.colors) {
                        data.colors = {};
                    }
                    const matches = name.match(/^colors\[([^\]]+)\]$/);
                    const colorKey = matches[1];
                    data.colors[colorKey] = $input.val();
                } else if ($input.attr('type') === 'checkbox') {
                    data[name] = $input.is(':checked') ? '1' : '0';
                } else {
                    data[name] = $input.val();
                }
            });
            
            return data;
        },

        /**
         * Branding payload for AJAX (DOM fields + in-memory wizard state).
         */
        getBrandingSnapshot: function() {
            const wizard = window.yooadmWizard || {};
            const data = this.getStepData('branding');
            const logoPreview = $('#logo-preview-img').attr('src') || $('.logo-preview img').attr('src') || '';
            const logoId = $('#logo_id').val() || '';
            const logoAction = $('#wizard-logo-action').val() || '';
            const faviconUrl = $('#wizard-admin-favicon-url').val() || wizard.adminFaviconUrl || '';
            const logoWidth = $('#wizard-logo-width').val() || wizard.savedLogoWidth || 150;

            if (logoId) {
                data.logo_id = logoId;
                data.logo_action = logoAction || 'set';
            } else if (logoAction === 'clear') {
                data.logo_action = 'clear';
                data.logo_w = 150;
            } else if (wizard.savedLogo) {
                data.logo_url = wizard.savedLogo;
            } else if (logoPreview && logoPreview !== wizard.defaultLogoUrl) {
                data.logo_url = logoPreview;
            }

            if (faviconUrl) {
                data.admin_favicon_url = faviconUrl;
            } else if (wizard.adminFaviconUrl) {
                data.admin_favicon_url = wizard.adminFaviconUrl;
            } else {
                data.admin_favicon_url = '';
            }

            if (data.logo_action !== 'clear') {
                data.logo_w = logoWidth;
            }

            if (!data.colors && wizard.savedColors) {
                data.colors = wizard.savedColors;
            }

            return data;
        },

        /**
         * Persist branding (immediate save on upload or before wizard completion).
         */
        persistWizardBranding: function(done) {
            const branding = this.getBrandingSnapshot();
            const hasBranding =
                branding.logo_id ||
                branding.logo_url ||
                branding.logo_action === 'clear' ||
                branding.admin_favicon_url ||
                (branding.colors && Object.keys(branding.colors).length);

            if (!hasBranding) {
                if (typeof done === 'function') {
                    done();
                }
                return;
            }

            $.ajax({
                url: window.yooadmWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'yooadmin_wizard_save_step',
                    nonce: window.yooadmWizard.nonce,
                    step: 'branding',
                    data: branding,
                    color_mode: this.getCurrentColorMode()
                },
                complete: () => {
                    if (branding.logo_url) {
                        window.yooadmWizard.savedLogo = branding.logo_url;
                    }
                    if (branding.admin_favicon_url) {
                        window.yooadmWizard.adminFaviconUrl = branding.admin_favicon_url;
                    }
                    if (typeof done === 'function') {
                        done();
                    }
                }
            });
        },
        
        /**
         * Go to next step
         */
        goToNext: function() {
            const currentIndex = window.yooadmWizard.steps.indexOf(window.yooadmWizard.currentStep);
            const nextStep = window.yooadmWizard.steps[currentIndex + 1];
            
            if (nextStep) {
                window.location.href = window.yooadmWizard.adminUrl + 'admin.php?page=yooadmin-setup&step=' + nextStep;
            }
        },
        
        /**
         * Go to previous step
         */
        goToPrevious: function() {
            const currentIndex = yooadmWizard.steps.indexOf(yooadmWizard.currentStep);
            const prevStep = yooadmWizard.steps[currentIndex - 1];
            if (!prevStep) return;

            const navigate = () => {
                window.location.href = yooadmWizard.adminUrl + 'admin.php?page=yooadmin-setup&step=' + prevStep;
            };

            $.ajax({
                url: yooadmWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'yooadmin_wizard_save_color_mode',
                    nonce: yooadmWizard.colorModeNonce,
                    color_mode: this.getCurrentColorMode()
                },
                complete: navigate
            });
        },
        
        /**
         * Skip wizard or skip step
         */
        skipWizard: function() {
            const currentStep = window.yooadmWizard.currentStep;
            
            // In welcome step: show popup to skip entire wizard
            if (currentStep === 'welcome') {
                this.showSkipPopup();
                return;
            }
            
            // In other steps: skip current step and go to next
            this.skipCurrentStep();
        },
        
        /**
         * Skip current step (not entire wizard)
         */
        skipCurrentStep: function() {
            const currentStep = window.yooadmWizard.currentStep;
            const stepData = this.getStepData(currentStep);
            
            // Save current data (if any) and move to next step
            $.ajax({
                url: window.yooadmWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'yooadmin_wizard_save_step',
                    nonce: window.yooadmWizard.nonce,
                    step: currentStep,
                    data: stepData,
                    color_mode: this.getCurrentColorMode()
                },
                success: (response) => {
                    // Move to next step
                    this.goToNext();
                },
                error: () => {
                    // Even on error, move to next step
                    this.goToNext();
                }
            });
        },
        
        /**
         * Exit wizard and launch YOOAdmin (save progress + complete wizard + enable focus mode)
         */
        exitAndLaunch: function() {
            const currentStep = window.yooadmWizard.currentStep;
            const stepData = this.getStepData(currentStep);
            
            // Show loading
            $('.wizard-btn-exit').prop('disabled', true).text('Launching...');
            
            // First, save current step data
            $.ajax({
                url: window.yooadmWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'yooadmin_wizard_save_step',
                    nonce: window.yooadmWizard.nonce,
                    step: currentStep,
                    data: stepData,
                    color_mode: this.getCurrentColorMode()
                },
                success: () => {
                    // Then complete wizard with Focus Mode
                    this.completeWizardEarly();
                },
                error: () => {
                    // Even on error, try to complete
                    this.completeWizardEarly();
                }
            });
        },
        
        /**
         * Complete wizard early and enable Focus Mode
         */
        completeWizardEarly: function() {
            this.persistWizardBranding(() => {
                $.ajax({
                    url: window.yooadmWizard.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'yooadmin_wizard_complete',
                        nonce: window.yooadmWizard.nonce,
                        branding: this.getBrandingSnapshot()
                    },
                    success: (response) => {
                        if (response.success && response.data.redirect) {
                            yooadmWizardModule.redirectToDashboard(response.data.redirect);
                        } else {
                            yooadmWizardModule.redirectToDashboard(window.yooadmWizard.dashboardUrl);
                        }
                    },
                    error: () => {
                        yooadmWizardModule.redirectToDashboard(window.yooadmWizard.dashboardUrl);
                    }
                });
            });
        },
        
        /**
         * Show skip wizard popup
         */
        showSkipPopup: function() {
            const popup = $('#yooadmin-skip-wizard-popup');
            if (popup.length === 0) return;
            
            popup.fadeIn(200);
            $('body').addClass('yooadmin-popup-active');
        },
        
        /**
         * Hide skip wizard popup
         */
        hideSkipPopup: function() {
            const popup = $('#yooadmin-skip-wizard-popup');
            popup.fadeOut(200);
            $('body').removeClass('yooadmin-popup-active');
            
            // Reset popup state
            $('#skip-enable-yooadmin').prop('checked', false);
            $('#skip-enable-btn').hide().prop('disabled', false);
            $('#skip-continue-btn').hide();
        },
        
        /**
         * Handle skip - Enable YOOAdmin
         */
        handleSkipEnableYOOAdmin: function() {
            this.performSkip(true);
        },
        
        /**
         * Handle skip - Continue with WordPress
         */
        handleSkipContinueWordPress: function() {
            // Skip without Focus Mode
            this.performSkip(false);
        },
        
        /**
         * Perform skip action
         */
        performSkip: function(enableFocusMode) {
            // Close skip popup first
            this.hideSkipPopup();
            
            // If enabling Focus Mode, show animation like Launch
            if (enableFocusMode) {
                // Store skip action for later
                this.skipAction = {
                    enable_focus: '1'
                };
                
                // Start launch animation (same as Launch button)
                this.startLaunchAnimation();
            } else {
                // Skip without Focus Mode - redirect immediately
                $.ajax({
                    url: window.yooadmWizard.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'yooadmin_wizard_skip',
                        nonce: window.yooadmWizard.nonce,
                        enable_focus: '0'
                    },
                    success: (response) => {
                        if (response.success && response.data.redirect) {
                            window.location.href = response.data.redirect;
                        }
                    },
                    error: () => {
                        alert(window.yooadmWizard.strings.error);
                    }
                });
            }
        },
        
        /**
         * Handle launch
         */
        handleLaunch: function(e) {
            e.preventDefault();
            
            // Save final step first
            const stepData = this.getStepData('launch');
            
            $.ajax({
                url: yooadmWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'yooadmin_wizard_save_step',
                    nonce: yooadmWizard.nonce,
                    step: 'launch',
                    data: stepData,
                    color_mode: this.getCurrentColorMode()
                },
                success: () => {
                    this.persistWizardBranding(() => {
                        this.startLaunchAnimation();
                    });
                }
            });
        },
        
        /**
         * Start launch animation
         */
        startLaunchAnimation: function() {
            // Prevent multiple calls
            if (this.launchAnimationRunning) {
                return;
            }
            this.launchAnimationRunning = true;
            
            const $overlay = $('#wizard-launch-overlay');
            const $buildingStage = $('#building-stage');
            const $countdownStage = $('#countdown-stage');
            const $progressFill = $('#progress-fill');
            const $progressMessage = $('#progress-message');
            
            // Show overlay
            $overlay.fadeIn(300);
            
            // Stage 1: Building animation (3 seconds)
            const messages = [
                yooadmWizard.strings.settingUp,
                yooadmWizard.strings.applyingPreferences,
                yooadmWizard.strings.almostReady
            ];
            
            let messageIndex = 0;
            let progress = 0;
            
            const buildingInterval = setInterval(() => {
                progress += 33.33;
                $progressFill.css('width', progress + '%');
                
                if (messageIndex < messages.length) {
                    $progressMessage.text(messages[messageIndex]);
                    messageIndex++;
                }
                
                if (progress >= 100) {
                    clearInterval(buildingInterval);
                    
                    // Stage 2: Countdown (3 seconds)
                    setTimeout(() => {
                        $buildingStage.fadeOut(300, () => {
                            $countdownStage.fadeIn(300);
                            // Reset flag before starting countdown
                            this.launchAnimationRunning = false;
                            this.startCountdown();
                        });
                    }, 500);
                }
            }, 1000);
        },
        
        /**
         * Start countdown
         */
        startCountdown: function() {
            const $countdownNumber = $('#countdown-number');
            let count = 3;
            
            // Show first number (3) with animation
            $countdownNumber.addClass('wizard-countdown-animate');
            
            const showNextNumber = () => {
                count--;
                
                if (count > 0) {
                    // Fade out current number
                    $countdownNumber.removeClass('wizard-countdown-animate').addClass('wizard-countdown-fadeout');
                    
                    // After fade out, change number and fade in
                    setTimeout(() => {
                        // Remove all animation classes and reset
                        $countdownNumber.removeClass('wizard-countdown-animate wizard-countdown-fadeout');
                        // Hide number first (opacity 0) before changing text
                        $countdownNumber.css('opacity', '0');
                        $countdownNumber.text(count);
                        
                        // Force reflow using requestAnimationFrame for better reliability
                        requestAnimationFrame(() => {
                            requestAnimationFrame(() => {
                                // Reset opacity and add animation class - this ensures animation restarts
                                $countdownNumber.css('opacity', '');
                                $countdownNumber.addClass('wizard-countdown-animate');
                                
                                // Wait for fade in animation (1s) then show next number
                                setTimeout(showNextNumber, 1000);
                            });
                        });
                    }, 500); // Wait for fade out to complete
                } else {
                    // Fade out last number (1) then redirect
                    $countdownNumber.removeClass('wizard-countdown-animate').addClass('wizard-countdown-fadeout');
                    setTimeout(() => {
                        // Complete wizard and redirect immediately
                        this.completeWizard();
                    }, 500);
                }
            };
            
            // Start countdown after first number animation (1s)
            setTimeout(showNextNumber, 1000);
        },
        
        /**
         * Complete wizard
         */
        completeWizard: function() {
            // Check if this is a skip action
            if (this.skipAction) {
                $.ajax({
                    url: window.yooadmWizard.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'yooadmin_wizard_skip',
                        nonce: window.yooadmWizard.nonce,
                        enable_focus: this.skipAction.enable_focus
                    },
                    success: (response) => {
                        if (response.success && response.data.redirect) {
                            yooadmWizardModule.redirectToDashboard(response.data.redirect);
                        }
                    },
                    error: () => {
                        alert(window.yooadmWizard.strings.error);
                    }
                });
                
                // Clear skip action
                this.skipAction = null;
            } else {
                // Normal wizard completion
                this.persistWizardBranding(() => {
                    $.ajax({
                        url: yooadmWizard.ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'yooadmin_wizard_complete',
                            nonce: yooadmWizard.nonce,
                            branding: this.getBrandingSnapshot()
                        },
                        success: (response) => {
                            if (response.success && response.data.redirect) {
                                yooadmWizardModule.redirectToDashboard(response.data.redirect);
                            }
                        }
                    });
                });
            }
        },
        
        /**
         * Handle convert banners toggle
         */
        handleConvertBannersToggle: function(e) {
            const isChecked = $(e.target).is(':checked');
            const value = isChecked ? 1 : 0;
            
            // Save immediately via AJAX
            $.ajax({
                url: window.yooadmWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'yooadmin_wizard_save_convert_banners',
                    nonce: window.yooadmWizard.nonce,
                    convert_banners: value
                },
                success: (response) => {
                    if (response.success) {
                        // Option saved successfully
                    } else {
                        // Revert checkbox on error
                        $(e.target).prop('checked', !isChecked);
                    }
                },
                error: () => {
                    // Revert checkbox on error
                    $(e.target).prop('checked', !isChecked);
                }
            });
        },
        
        /**
         * Initialize color pickers
         */
        initColorPickers: function() {
            this.initWizardColorControls();

            // Apply initial colors on page load
            setTimeout(() => {
                this.syncBrandingColorsLock();
                if (!this.isWizardEffectiveDark() || !this.isBrandingStep()) {
                    this.updateBrandingPreview();
                }
            }, 300);
        },

        initWizardColorControls: function() {
            const self = this;
            const defaults = [];

            [
                '#EDA934',
                '#A16207',
                '#111827',
                '#3F3F46',
                '#F8FAFC',
                '#DADDE2',
                '#1E40AF',
                '#075985',
                '#0F766E',
                '#047857',
                '#3F6212',
                '#4338CA',
                '#7E22CE',
                '#BE185D',
                '#B91C1C',
                '#9A3412',
                '#92400E',
                '#134E4A',
                '#475569',
                '#6B7280',
                '#374151',
                '#F3F4F6'
            ].forEach(function(color) {
                const normalized = self.normalizeHexColor(color);
                if (defaults.indexOf(normalized) === -1) {
                    defaults.push(normalized);
                }
            });

            $('.wizard-color-picker').each(function() {
                const $input = $(this);
                if ($input.data('wizard-color-ready')) {
                    return;
                }
                self.detachLegacyColorPicker($input);
                const current = self.normalizeHexColor($input.val() || $input.data('default-color') || '#eda934');
                const title = $input.closest('.color-picker-group').find('label').first().text() || '';
                const control = self.buildWizardColorControl(current, defaults, title);

                $input
                    .data('wizard-color-ready', true)
                    .addClass('wizard-color-picker-source')
                    .attr('type', 'hidden')
                    .after(control);

                self.syncWizardColorControl($input);
            });

            $(document).off('click.yooadminWizardColor');
            $(document).on('click.yooadminWizardColor', function(e) {
                if (!$(e.target).closest('.wizard-modern-color').length) {
                    $('.wizard-modern-color').removeClass('is-open opens-up aligns-right');
                    $('.wizard-modern-color__popover').attr('hidden', 'hidden');
                    $('.wizard-modern-color__custom-panel').attr('hidden', 'hidden');
                }
            });

            $(document).off('click.yooadminWizardColorToggle', '.wizard-modern-color__trigger');
            $(document).on('click.yooadminWizardColorToggle', '.wizard-modern-color__trigger', function(e) {
                e.preventDefault();
                const $control = $(this).closest('.wizard-modern-color');
                const willOpen = !$control.hasClass('is-open');
                $('.wizard-modern-color').not($control).removeClass('is-open opens-up aligns-right').find('.wizard-modern-color__popover').attr('hidden', 'hidden');
                $('.wizard-modern-color').not($control).find('.wizard-modern-color__custom-panel').attr('hidden', 'hidden');
                $control.toggleClass('is-open', willOpen);
                if (willOpen) {
                    $control.find('.wizard-modern-color__popover').removeAttr('hidden');
                } else {
                    $control.find('.wizard-modern-color__popover').attr('hidden', 'hidden');
                    $control.find('.wizard-modern-color__custom-panel').attr('hidden', 'hidden');
                }
                if (willOpen) {
                    self.positionWizardColorPopover($control);
                }
            });

            $(document).off('click.yooadminWizardPalette', '.wizard-modern-color__swatch');
            $(document).on('click.yooadminWizardPalette', '.wizard-modern-color__swatch', function(e) {
                const color = $(this).data('color');
                if (!color) {
                    return;
                }
                e.preventDefault();
                self.applyWizardColorValue($(this).closest('.wizard-modern-color'), color);
            });

            $(document).off('click.yooadminWizardCustomColor', '.wizard-modern-color__custom-swatch');
            $(document).on('click.yooadminWizardCustomColor', '.wizard-modern-color__custom-swatch', function(e) {
                e.preventDefault();
                const $control = $(this).closest('.wizard-modern-color');
                const $panel = $control.find('.wizard-modern-color__custom-panel');
                const willOpen = $panel.is('[hidden]');

                $('.wizard-modern-color__custom-panel').not($panel).attr('hidden', 'hidden');
                if (willOpen) {
                    self.syncCustomPickerFromInput($control);
                    $panel.removeAttr('hidden');
                } else {
                    $panel.attr('hidden', 'hidden');
                }
            });

            $(document).off('click.yooadminWizardResetColor', '.wizard-modern-color__reset');
            $(document).on('click.yooadminWizardResetColor', '.wizard-modern-color__reset', function(e) {
                e.preventDefault();
                const $control = $(this).closest('.wizard-modern-color');
                const fallback = $control.prev('.wizard-color-picker').data('default-color') || '#eda934';
                self.applyWizardColorValue($control, fallback);
            });

            $(document).off('change.yooadminWizardHex', '.wizard-modern-color__hex');
            $(document).on('change.yooadminWizardHex', '.wizard-modern-color__hex', function() {
                self.applyWizardColorValue($(this).closest('.wizard-modern-color'), $(this).val());
            });

            $(document).off('pointerdown.yooadminWizardSpectrum', '.wizard-modern-color__spectrum');
            $(document).on('pointerdown.yooadminWizardSpectrum', '.wizard-modern-color__spectrum', function(e) {
                e.preventDefault();
                const spectrum = this;
                const $spectrum = $(spectrum);
                const applyMove = function(event) {
                    self.applyCustomSpectrumPointer($spectrum, event);
                };

                if (spectrum.setPointerCapture && e.originalEvent && e.originalEvent.pointerId !== undefined) {
                    spectrum.setPointerCapture(e.originalEvent.pointerId);
                }

                applyMove(e.originalEvent || e);
                $(document).on('pointermove.yooadminWizardSpectrumDrag', function(moveEvent) {
                    applyMove(moveEvent.originalEvent || moveEvent);
                });
                $(document).one('pointerup.yooadminWizardSpectrumDrag pointercancel.yooadminWizardSpectrumDrag', function() {
                    $(document).off('pointermove.yooadminWizardSpectrumDrag');
                });
            });

            $(document).off('input.yooadminWizardHue change.yooadminWizardHue', '.wizard-modern-color__hue');
            $(document).on('input.yooadminWizardHue change.yooadminWizardHue', '.wizard-modern-color__hue', function() {
                const $control = $(this).closest('.wizard-modern-color');
                const hue = Math.max(0, Math.min(360, parseFloat($(this).val()) || 0));
                $control.data('wizardColorHue', hue);
                self.applyCustomPickerColor($control);
            });

            $(window).off('resize.yooadminWizardColor scroll.yooadminWizardColor');
            $(window).on('resize.yooadminWizardColor scroll.yooadminWizardColor', function() {
                const $open = $('.wizard-modern-color.is-open').first();
                if ($open.length) {
                    self.positionWizardColorPopover($open);
                }
            });
        },

        detachLegacyColorPicker: function($input) {
            const $container = $input.closest('.wp-picker-container');
            if (!$container.length) {
                return;
            }

            $container.before($input.detach());
            $container.remove();
        },

        normalizeHexColor: function(value) {
            let color = String(value || '').trim();
            if (!color) {
                return '';
            }
            if (color.charAt(0) !== '#') {
                color = '#' + color;
            }
            if (/^#[0-9a-f]{3}$/i.test(color)) {
                color = '#' + color.charAt(1) + color.charAt(1) + color.charAt(2) + color.charAt(2) + color.charAt(3) + color.charAt(3);
            }
            return /^#[0-9a-f]{6}$/i.test(color) ? color.toUpperCase() : '';
        },

        getContrastColor: function(value) {
            const color = this.normalizeHexColor(value);
            if (!color) {
                return '#FFFFFF';
            }

            const r = parseInt(color.slice(1, 3), 16);
            const g = parseInt(color.slice(3, 5), 16);
            const b = parseInt(color.slice(5, 7), 16);
            const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;

            return luminance > 0.62 ? '#4B5563' : '#FFFFFF';
        },

        hexToRgbObject: function(value) {
            const color = this.normalizeHexColor(value);
            if (!color) {
                return null;
            }

            return {
                r: parseInt(color.slice(1, 3), 16),
                g: parseInt(color.slice(3, 5), 16),
                b: parseInt(color.slice(5, 7), 16)
            };
        },

        rgbToHex: function(rgb) {
            const toHex = function(channel) {
                return Math.max(0, Math.min(255, Math.round(channel))).toString(16).padStart(2, '0');
            };

            return ('#' + toHex(rgb.r) + toHex(rgb.g) + toHex(rgb.b)).toUpperCase();
        },

        rgbToHsv: function(rgb) {
            const r = rgb.r / 255;
            const g = rgb.g / 255;
            const b = rgb.b / 255;
            const max = Math.max(r, g, b);
            const min = Math.min(r, g, b);
            const delta = max - min;
            let h = 0;

            if (delta !== 0) {
                if (max === r) {
                    h = ((g - b) / delta) % 6;
                } else if (max === g) {
                    h = (b - r) / delta + 2;
                } else {
                    h = (r - g) / delta + 4;
                }
                h = Math.round(h * 60);
                if (h < 0) {
                    h += 360;
                }
            }

            return {
                h: h,
                s: max === 0 ? 0 : (delta / max) * 100,
                v: max * 100
            };
        },

        hsvToRgb: function(hsv) {
            const h = ((hsv.h % 360) + 360) % 360;
            const s = Math.max(0, Math.min(100, hsv.s)) / 100;
            const v = Math.max(0, Math.min(100, hsv.v)) / 100;
            const c = v * s;
            const x = c * (1 - Math.abs((h / 60) % 2 - 1));
            const m = v - c;
            let r = 0;
            let g = 0;
            let b = 0;

            if (h < 60) {
                r = c; g = x;
            } else if (h < 120) {
                r = x; g = c;
            } else if (h < 180) {
                g = c; b = x;
            } else if (h < 240) {
                g = x; b = c;
            } else if (h < 300) {
                r = x; b = c;
            } else {
                r = c; b = x;
            }

            return {
                r: (r + m) * 255,
                g: (g + m) * 255,
                b: (b + m) * 255
            };
        },

        getWizardColorPickerI18n: function() {
            const i18n = (window.yooadmWizard && window.yooadmWizard.colorPicker) || {};

            return {
                chooseColor: i18n.chooseColor || 'Choose color',
                palette: i18n.palette || 'Palette',
                hex: i18n.hex || 'HEX',
                reset: i18n.reset || 'Reset',
                customColor: i18n.customColor || 'Custom color',
                customSaturationBrightness: i18n.customSaturationBrightness || 'Custom color saturation and brightness',
                colorHue: i18n.colorHue || 'Color hue',
                hexColor: i18n.hexColor || 'Hex color'
            };
        },

        buildWizardColorControl: function(current, defaults, title) {
            const cp = this.getWizardColorPickerI18n();
            const palette = defaults.map(function(color) {
                return '<button type="button" class="wizard-modern-color__swatch" data-color="' + color + '" style="--swatch:' + color + '" aria-label="' + color + '"></button>';
            }).join('');
            const contrast = this.getContrastColor(current);

            return $(
                '<div class="wizard-modern-color">' +
                    '<button type="button" class="wizard-modern-color__trigger">' +
                        '<span class="wizard-modern-color__preview" style="--current:' + current + '"></span>' +
                        '<span class="wizard-modern-color__title" style="--title-color:' + contrast + '">' + title + '</span>' +
                        '<span class="wizard-modern-color__value">' + current + '</span>' +
                    '</button>' +
                    '<div class="wizard-modern-color__popover" hidden>' +
                        '<div class="wizard-modern-color__popover-title">' + cp.chooseColor + '</div>' +
                        '<div class="wizard-modern-color__label">' + cp.palette + '</div>' +
                        '<div class="wizard-modern-color__palette">' +
                            palette +
                            '<button type="button" class="wizard-modern-color__swatch wizard-modern-color__custom-swatch" aria-label="' + cp.customColor + '"><span aria-hidden="true"></span></button>' +
                        '</div>' +
                        '<div class="wizard-modern-color__custom-panel" hidden>' +
                            '<div class="wizard-modern-color__spectrum" role="slider" tabindex="0" aria-label="' + cp.customSaturationBrightness + '">' +
                                '<span class="wizard-modern-color__spectrum-handle" aria-hidden="true"></span>' +
                            '</div>' +
                            '<div class="wizard-modern-color__hue-wrap">' +
                                '<input type="range" class="wizard-modern-color__hue" min="0" max="360" step="1" value="0" aria-label="' + cp.colorHue + '">' +
                                '<span class="wizard-modern-color__hue-handle" aria-hidden="true"></span>' +
                            '</div>' +
                        '</div>' +
                        '<div class="wizard-modern-color__hex-wrap">' +
                            '<span>' + cp.hex + '</span>' +
                            '<input type="text" class="wizard-modern-color__hex" value="' + current + '" aria-label="' + cp.hexColor + '" spellcheck="false">' +
                            '<button type="button" class="wizard-modern-color__reset">' + cp.reset + '</button>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
        },

        syncWizardColorControl: function($input) {
            const color = this.normalizeHexColor($input.val() || $input.data('default-color') || '#eda934');
            const $control = $input.next('.wizard-modern-color');
            $control.find('.wizard-modern-color__preview').css('--current', color);
            $control.find('.wizard-modern-color__title').css('--title-color', this.getContrastColor(color));
            $control.find('.wizard-modern-color__value').text(color);
            $control.find('.wizard-modern-color__hex').val(color);
            this.syncCustomPickerFromInput($control);
        },

        applyWizardColorValue: function($control, value) {
            const color = this.normalizeHexColor(value);
            if (!color || (this.isWizardEffectiveDark() && this.isBrandingStep())) {
                this.revertBrandingColorInputs();
                return;
            }

            const $input = $control.prev('.wizard-color-picker');
            $input.val(color).trigger('change');
            this.syncWizardColorControl($input);
            this.updateBrandingPreview();
        },

        syncCustomPickerFromInput: function($control) {
            const color = this.normalizeHexColor($control.prev('.wizard-color-picker').val() || '#eda934');
            const rgb = this.hexToRgbObject(color);
            const hsv = rgb ? this.rgbToHsv(rgb) : { h: 0, s: 100, v: 100 };

            $control.data('wizardColorHue', hsv.h);
            $control.data('wizardColorSat', hsv.s);
            $control.data('wizardColorVal', hsv.v);
            this.updateCustomPickerUi($control);
        },

        updateCustomPickerUi: function($control) {
            const hue = parseFloat($control.data('wizardColorHue')) || 0;
            const sat = Math.max(0, Math.min(100, parseFloat($control.data('wizardColorSat')) || 0));
            const val = Math.max(0, Math.min(100, parseFloat($control.data('wizardColorVal')) || 0));
            const hueColor = this.rgbToHex(this.hsvToRgb({ h: hue, s: 100, v: 100 }));
            const handleTop = (100 - val) + '%';
            const handleLeft = sat + '%';
            const hueLeft = (hue / 360) * 100 + '%';

            $control.find('.wizard-modern-color__custom-panel').css({
                '--picker-hue': hueColor,
                '--picker-x': handleLeft,
                '--picker-y': handleTop,
                '--hue-x': hueLeft
            });
            $control.find('.wizard-modern-color__spectrum-handle').each(function() {
                this.style.setProperty('left', handleLeft, 'important');
                this.style.setProperty('top', handleTop, 'important');
            });
            $control.find('.wizard-modern-color__hue-handle').each(function() {
                this.style.setProperty('left', hueLeft, 'important');
            });
            $control.find('.wizard-modern-color__hue').val(hue);
        },

        applyCustomSpectrumPointer: function($spectrum, event) {
            const rect = $spectrum[0].getBoundingClientRect();
            const x = Math.max(0, Math.min(rect.width, event.clientX - rect.left));
            const y = Math.max(0, Math.min(rect.height, event.clientY - rect.top));
            const $control = $spectrum.closest('.wizard-modern-color');

            $control.data('wizardColorSat', (x / rect.width) * 100);
            $control.data('wizardColorVal', 100 - ((y / rect.height) * 100));
            this.applyCustomPickerColor($control);
        },

        applyCustomPickerColor: function($control) {
            const rawHue = parseFloat($control.data('wizardColorHue'));
            const rawSat = parseFloat($control.data('wizardColorSat'));
            const rawVal = parseFloat($control.data('wizardColorVal'));
            const hsv = {
                h: Number.isFinite(rawHue) ? rawHue : 0,
                s: Number.isFinite(rawSat) ? rawSat : 100,
                v: Number.isFinite(rawVal) ? rawVal : 100
            };
            const color = this.rgbToHex(this.hsvToRgb(hsv));

            this.updateCustomPickerUi($control);
            this.applyWizardColorValue($control, color);
        },

        positionWizardColorPopover: function($control) {
            const $popover = $control.find('.wizard-modern-color__popover');
            $control.removeClass('opens-up aligns-right');

            $popover.css({
                top: '',
                left: '',
                right: '',
                bottom: ''
            });

            const controlRect = $control[0].getBoundingClientRect();
            const popoverRect = $popover[0].getBoundingClientRect();
            const gap = 8;
            const viewportPadding = 12;
            let top = controlRect.bottom + gap;
            let left = controlRect.left;

            if (top + popoverRect.height > window.innerHeight - viewportPadding) {
                const upwardTop = controlRect.top - popoverRect.height - gap;
                if (upwardTop >= viewportPadding) {
                    top = upwardTop;
                    $control.addClass('opens-up');
                }
            }

            if (left + popoverRect.width > window.innerWidth - viewportPadding) {
                left = window.innerWidth - popoverRect.width - viewportPadding;
                $control.addClass('aligns-right');
            }

            left = Math.max(viewportPadding, left);
            top = Math.max(viewportPadding, top);

            $popover.css({
                top: top + 'px',
                left: left + 'px',
                '--arrow-x': Math.max(18, Math.min(popoverRect.width - 18, controlRect.left + (controlRect.width / 2) - left)) + 'px'
            });
        },
        
        syncWizardLogoRangeFill: function(el) {
            if (!el) {
                el = document.getElementById('wizard-logo-width');
            }
            if (!el) {
                return;
            }
            let min = parseInt(el.getAttribute('min'), 10);
            let max = parseInt(el.getAttribute('max'), 10);
            let v = parseInt(el.value, 10);
            if (!Number.isFinite(min)) {
                min = 60;
            }
            if (!Number.isFinite(max)) {
                max = 320;
            }
            if (!Number.isFinite(v)) {
                v = min;
            }
            let pct = max > min ? ((v - min) / (max - min)) * 100 : 0;
            pct = Math.max(0, Math.min(100, pct));
            el.style.setProperty('--yp-range-fill-pct', pct + '%');
        },

        /**
         * Keep wizard logo preview and header width in sync.
         */
        applyWizardLogoWidth: function(value) {
            let width = parseInt(value, 10);
            if (!Number.isFinite(width)) {
                width = (window.yooadmWizard && parseInt(window.yooadmWizard.savedLogoWidth, 10)) || 150;
            }
            width = Math.max(60, Math.min(320, width));
            const $range = $('#wizard-logo-width');
            $range.val(width);
            $('#wizard-logo-width-val').text(width);
            if ($range.length) {
                $range[0].setAttribute('aria-valuenow', String(width));
                this.syncWizardLogoRangeFill($range[0]);
            }
            $('.logo-preview img, .yooadmin-wizard-logo').css({
                width: width + 'px',
                maxWidth: width + 'px'
            });
        },

        showWizardLogoWidthControl: function() {
            $('.wizard-logo-width-control').removeAttr('hidden');
        },

        setAdminFaviconLink: function(url) {
            const head = document.head;
            if (!head) {
                return;
            }

            Array.prototype.slice
                .call(head.querySelectorAll('link[rel]'))
                .forEach(function(link) {
                    const rel = (link.getAttribute('rel') || '').toLowerCase();
                    if (
                        rel === 'icon' ||
                        rel === 'shortcut icon' ||
                        rel === 'apple-touch-icon' ||
                        rel === 'mask-icon' ||
                        rel.indexOf(' icon') !== -1 ||
                        rel.indexOf('icon ') !== -1
                    ) {
                        link.parentNode.removeChild(link);
                    }
                });
            if (!url) {
                return;
            }

            const cleanUrl = String(url);
            const liveUrl = cleanUrl + (cleanUrl.indexOf('?') === -1 ? '?' : '&') + 'yooadmin_favicon_preview=' + Date.now();
            const ext = (cleanUrl.split('?')[0].split('#')[0].split('.').pop() || '').toLowerCase();
            let type = '';
            if (ext === 'ico') type = 'image/x-icon';
            if (ext === 'svg') type = 'image/svg+xml';
            if (ext === 'png') type = 'image/png';
            if (ext === 'gif') type = 'image/gif';
            if (ext === 'jpg' || ext === 'jpeg') type = 'image/jpeg';

            ['icon', 'shortcut icon', 'apple-touch-icon'].forEach(function(rel) {
                const link = document.createElement('link');
                link.setAttribute('rel', rel);
                link.setAttribute('href', liveUrl);
                link.setAttribute('data-yooadmin', '1');
                link.setAttribute('data-yooadmin-wizard-favicon', '1');
                if (type && rel !== 'apple-touch-icon') {
                    link.setAttribute('type', type);
                }
                head.appendChild(link);
            });

            if (type === 'image/svg+xml') {
                const mask = document.createElement('link');
                mask.setAttribute('rel', 'mask-icon');
                mask.setAttribute('href', liveUrl);
                mask.setAttribute('color', '#333333');
                mask.setAttribute('data-yooadmin', '1');
                mask.setAttribute('data-yooadmin-wizard-favicon', '1');
                head.appendChild(mask);
            }
        },

        updateWizardFaviconPreview: function(url) {
            const $wrap = $('#wizard-admin-favicon-preview-wrap');
            if (!$wrap.length) {
                return;
            }
            if (url) {
                $wrap
                    .addClass('has-icon')
                    .html('<img id="wizard-admin-favicon-preview" src="' + url + '" alt="">');
                $('.wizard-remove-favicon').removeAttr('hidden');
            } else {
                $wrap
                    .removeClass('has-icon')
                    .html('<span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>');
                $('.wizard-remove-favicon').attr('hidden', 'hidden');
            }
            $('#wizard-admin-favicon-url').val(url || '');
            this.syncWizardFaviconPlaceholderColor();
            this.setAdminFaviconLink(url || (window.yooadmWizard && window.yooadmWizard.adminFaviconDefaultUrl) || '');
        },

        syncWizardFaviconPlaceholderColor: function(color) {
            const savedColors = (window.yooadmWizard && window.yooadmWizard.savedColors) || {};
            const fallback = $('#wizard_color_card_icon').val() ||
                savedColors.card_icon ||
                $('#wizard_color_primary').val() ||
                savedColors.primary ||
                '';
            const iconColor = color || fallback;

            if (iconColor) {
                $('.yooadmin-wizard-page').css('--yoo-wizard-card-icon', iconColor);
                $('#wizard-admin-favicon-preview-wrap:not(.has-icon) .dashicons').css('color', iconColor);
            }
        },

        /**
         * Initialize media uploader
         */
        initMediaUploader: function() {
            const self = this;
            let frame;
            let faviconFrame;
            
            // Remove any existing event listeners first to prevent duplicates
            $(document).off('click', '.wizard-upload-logo');
            $(document).off('click', '.logo-preview');
            $(document).off('keydown', '.logo-preview');
            $(document).off('click', '.wizard-logo-remove-overlay');
            $(document).off('click', '.wizard-upload-favicon');
            $(document).off('click', '.wizard-remove-favicon');

            function openLogoFrame() {
                // If the media frame already exists, reopen it.
                if (frame) {
                    frame.open();
                    return;
                }
                
                // Create a new media frame
                frame = wp.media({
                    title: 'Select Logo',
                    button: {
                        text: 'Use this logo'
                    },
                    multiple: false,
                    library: {
                        type: 'image'
                    }
                });
                
                // When an image is selected (remove previous listeners first)
                frame.off('select');
                frame.on('select', function() {
                    const attachment = frame.state().get('selection').first().toJSON();
                    
                    // Update hidden input
                    $('#logo_id').val(attachment.id);
                    $('#wizard-logo-action').val('set');
                    window.yooadmWizard.savedLogo = attachment.url;
                    window.yooadmWizard.savedLogoId = attachment.id;
                    
                    // Update preview
                    $('.logo-preview')
                        .addClass('has-logo')
                        .html(
                            '<img src="' + attachment.url + '" alt="Logo" id="logo-preview-img">' +
                            '<button type="button" class="wizard-logo-remove-overlay" aria-label="Remove logo">' +
                            '<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>' +
                            '</button>'
                        );
                    self.showWizardLogoWidthControl();
                    self.applyWizardLogoWidth($('#wizard-logo-width').val());
                    
                    // Update wizard logo immediately
                    $('.yooadmin-wizard-logo').attr('src', attachment.url);
                    self.persistWizardBranding();
                });
                
                // Open the modal
                frame.open();
            }

            $(document).on('click', '.wizard-upload-logo, .logo-preview', function(e) {
                if ($(e.target).closest('.wizard-logo-remove-overlay').length) {
                    return;
                }
                e.preventDefault();
                openLogoFrame();
            });

            $(document).on('keydown', '.logo-preview', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    openLogoFrame();
                }
            });

            $(document).on('click', '.wizard-logo-remove-overlay', function(e) {
                e.preventDefault();
                e.stopPropagation();
                self.resetLogo();
            });

            $(document).on('click', '.wizard-upload-favicon', function(e) {
                e.preventDefault();

                if (faviconFrame) {
                    faviconFrame.open();
                    return;
                }

                faviconFrame = wp.media({
                    title: 'Admin Favicon',
                    button: {
                        text: 'Use this icon'
                    },
                    multiple: false,
                    library: {
                        type: 'image'
                    }
                });

                faviconFrame.on('select', function() {
                    const attachment = faviconFrame.state().get('selection').first().toJSON();
                    const url = attachment && attachment.url ? attachment.url : '';
                    window.yooadmWizard.adminFaviconUrl = url;
                    self.updateWizardFaviconPreview(url);
                    self.persistWizardBranding();
                });

                faviconFrame.open();
            });

            $(document).on('click', '.wizard-remove-favicon', function(e) {
                e.preventDefault();
                window.yooadmWizard.adminFaviconUrl = '';
                self.updateWizardFaviconPreview('');
                self.persistWizardBranding();
            });
        },
        
        /**
         * Update branding preview (live on wizard itself)
         */
        updateBrandingPreview: function() {
            if (this.isWizardEffectiveDark()) {
                if (this.isBrandingStep()) {
                    this.applyBrandingCssVariables(this.getDraftBrandingColors());
                }
                return;
            }

            if (this.isBrandingStep()) {
                this.applyBrandingCssVariables(this.getDraftBrandingColors());
            }

            // Get saved colors from database
            const savedColors = (window.yooadmWizard && window.yooadmWizard.savedColors) || {};
            
            // Get all color values (from inputs if available, otherwise from saved)
            const primary = $('#wizard_color_primary').val() || savedColors.primary || '';
            const headerBg = $('#wizard_color_header_bg').val() || savedColors.header_bg || '';
            const sidebarBg = $('#wizard_color_sidebar_bg').val() || savedColors.sidebar_bg || '';
            const textContrast = $('#wizard_color_text_contrast').val() || savedColors.text_contrast || '';
            const border = $('#wizard_color_border').val() || savedColors.border || '';
            const cardIcon = $('#wizard_color_card_icon').val() || savedColors.card_icon || '';
            const text600 = $('#wizard_color_text_600').val() || savedColors.text_600 || '';
            const text500 = $('#wizard_color_text_500').val() || savedColors.text_500 || '';
            
            // If no colors at all, return early
            if (!primary && !headerBg && !border && !text600 && !text500) {
                return;
            }
            
            // 1. Update wizard header background
            if (headerBg) {
                $('.yooadmin-wizard-page').css('--yoo-wizard-header-brand', headerBg);
                const effective = $('.yooadmin-wizard-page').attr('data-yoo-wizard-effective') ||
                    (document.documentElement.classList.contains('yoo-wizard-html-dark') ? 'dark' : 'light');
                this.syncWizardHeader($('.yooadmin-wizard-page'), effective);
            }
            
            // 2. Update active step indicator (primary color)
            if (primary) {
                const primaryHover = 'color-mix(in srgb, ' + primary + ' 90%, #000 10%)';
                document.documentElement.style.setProperty('--yooadmin-brand-source', primary);
                document.documentElement.style.setProperty('--yooadmin-primary', primary);
                document.documentElement.style.setProperty('--yooadmin-primary-hover', primaryHover);
                document.documentElement.style.setProperty('--yp-primary', primary);
                document.documentElement.style.setProperty('--yp-brand', primary);
                $('.yooadmin-wizard-page').css({
                    '--yooadmin-brand-source': primary,
                    '--yooadmin-primary': primary,
                    '--yooadmin-primary-hover': primaryHover,
                    '--yp-primary': primary,
                    '--yp-brand': primary,
                    '--yoo-wizard-brand': primary
                });
                $('.yooadmin-setup-steps li.active .step-number').css({
                    'background-color': primary,
                    'border-color': primary,
                    'box-shadow': '0 4px 12px rgba(' + this.hexToRgb(primary) + ', 0.3)'
                });
                
                // Update completed steps
                $('.yooadmin-setup-steps li.completed .step-number').css({
                    'background-color': primary,
                    'border-color': primary
                });
                
                // Update completed step names
                $('.yooadmin-setup-steps li.completed').css('color', primary);
                
                // Update primary buttons - use !important to override
                $('.wizard-btn-primary, .wizard-btn-next').each(function() {
                    this.style.setProperty('background-color', primary, 'important');
                    this.style.setProperty('color', '#fff', 'important');
                });
            }
            
            // 3. Update borders
            if (border) {
                $('.yooadmin-wizard-card').css('border-color', border);
                $('.yooadmin-setup-steps').css('border-bottom-color', border);
                $('.wizard-step-footer').css('border-top-color', border);
                $('.yooadmin-setup-steps ul::before').css('background-color', border);
            }
            
            // 4. Update text colors
            if (text600) {
                $('.wizard-subtitle, .description, .step-name').css('color', text600);
            }
            
            if (text500) {
                $('.wizard-step-body h3, .wizard-section label').css('color', text500);
            }
            
            // 5. Update text contrast (for header logo text if any)
            if (textContrast) {
                $('.yooadmin-wizard-header, .yooadmin-wizard-header *').css('color', textContrast);
            }
            
            // 6. Update card icons (dashicons in logo placeholder)
            if (cardIcon) {
                $('.logo-placeholder .dashicons').css('color', cardIcon);
                this.syncWizardFaviconPlaceholderColor(cardIcon);
            }
            
            // 7. Update wizard logo if changed
            const logoPreview = $('.logo-preview img');
            if (logoPreview.length) {
                const logoSrc = logoPreview.attr('src');
                if (logoSrc) {
                    $('.yooadmin-wizard-logo').attr('src', logoSrc);
                    this.applyWizardLogoWidth($('#wizard-logo-width').val());
                }
            }
            
            // 8. Update checkboxes in General step
            if (primary) {
                $('.wizard-compact-setting input[type="checkbox"]:checked ~ .wizard-compact-checkmark').css({
                    'background': primary,
                    'border-color': primary
                });
                
                // Update hint text
                $('.wizard-section-hint .yoo-hint').css('color', primary);
            }

            if (this.isBrandingStep()) {
                this._brandingDraftSnapshot = this.getDraftBrandingColors();
            }
        },
        
        /**
         * Convert hex to RGB for box-shadow
         */
        hexToRgb: function(hex) {
            const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
            return result 
                ? parseInt(result[1], 16) + ',' + parseInt(result[2], 16) + ',' + parseInt(result[3], 16)
                : '0,0,0';
        },
        
        /**
         * Reset logo to default
         */
        resetLogo: function() {
            // Clear logo
            $('#logo_id').val('');
            $('#wizard-logo-action').val('clear');
            
            // Update preview
            $('.logo-preview')
                .removeClass('has-logo')
                .html(
                    '<div class="logo-placeholder" id="logo-placeholder">' +
                    '<span class="dashicons dashicons-format-image"></span>' +
                    '<p>Upload Logo</p>' +
                    '</div>'
                );
            this.updateBrandingPreview();
            
            // Update wizard header logo (back to default)
            $('.yooadmin-wizard-logo').attr('src', window.yooadmWizard.defaultLogoUrl || '');
            $('.wizard-logo-width-control').attr('hidden', 'hidden');
            this.applyWizardLogoWidth(150);
            
            // Save immediately - clear logo_url from database
            $.ajax({
                url: window.yooadmWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'yooadmin_wizard_save_step',
                    nonce: window.yooadmWizard.nonce,
                    step: 'branding',
                    data: {
                        logo_id: '', // Empty = remove logo
                        logo_action: 'clear',
                        logo_w: 150,
                        admin_favicon_url: $('#wizard-admin-favicon-url').val() || '',
                        colors: {} // Don't change colors
                    }
                },
                success: function(response) {
                    if (response.success) {
                        // Update saved logo
                        window.yooadmWizard.savedLogo = '';
                        window.yooadmWizard.savedLogoWidth = 150;
                    }
                }
            });
        },
        
        /**
         * Reset colors to defaults
         */
        resetColors: function() {
            if (this.isWizardEffectiveDark() && this.isBrandingStep()) {
                this.syncBrandingColorsLock();
                return;
            }

            // Reset each color picker to its default
            const self = this;
            $('.wizard-color-picker').each(function() {
                const $input = $(this);
                const defaultColor = $input.data('default-color');
                
                if (defaultColor) {
                    $input.val(defaultColor);
                    self.syncWizardColorControl($input);
                }
            });
            
            // Trigger preview update
            setTimeout(() => {
                this.updateBrandingPreview();
            }, 100);
        },
        
        /**
         * Apply saved customizations (logo & colors) on page load
         */
        applySavedCustomizations: function() {
            // Apply saved logo to wizard header
            if (window.yooadmWizard && window.yooadmWizard.savedLogo) {
                $('.yooadmin-wizard-logo').attr('src', window.yooadmWizard.savedLogo);
            }
            this.applyWizardLogoWidth($('#wizard-logo-width').val() || (window.yooadmWizard && window.yooadmWizard.savedLogoWidth));
            if (window.yooadmWizard && window.yooadmWizard.adminFaviconUrl) {
                this.setAdminFaviconLink(window.yooadmWizard.adminFaviconUrl);
            }

            this.syncBrandingColorsLock();
            if (!this.isWizardEffectiveDark() || !this.isBrandingStep()) {
                this.updateBrandingPreview();
            }
        },
        
        /**
         * Trigger celebration animation (confetti) from launch emoji
         */
        triggerCelebration: function() {
            const $emoji = $('#wizard-launch-emoji');
            if (!$emoji.length) {
                return;
            }
            
            // Wait a bit for layout to settle
            setTimeout(() => {
                const emojiOffset = $emoji.offset();
                if (!emojiOffset) {
                    return;
                }
                
                const emojiWidth = $emoji.outerWidth() || 32;
                const emojiHeight = $emoji.outerHeight() || 32;
                const startX = emojiOffset.left + emojiWidth / 2;
                const startY = emojiOffset.top + emojiHeight / 2;
            
                const canvas = document.createElement('canvas');
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
                canvas.style.position = 'fixed';
                canvas.style.top = '0';
                canvas.style.left = '0';
                canvas.style.pointerEvents = 'none';
                canvas.style.zIndex = '9999999999';
                document.body.appendChild(canvas);

                const ctx = canvas.getContext('2d');
                const colors = ['#F8C102', '#00C6AE', '#F35D6B', '#7C5CE6', '#3FA1F2'];
                const particles = [];
                const total = 80;

                for (let i = 0; i < total; i++) {
                    particles.push({
                        x: startX,
                        y: startY,
                        r: Math.random() * 6 + 2,
                        c: colors[Math.floor(Math.random() * colors.length)],
                        vx: (Math.random() - 0.5) * 12,
                        vy: (Math.random() - 0.8) * 14,
                        g: 0.35 + Math.random() * 0.2,
                        a: 0.95 + Math.random() * 0.04
                    });
                }

                const endAt = Date.now() + 1500;

                function draw() {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    particles.forEach(p => {
                        p.vx *= p.a;
                        p.vy += p.g;
                        p.x += p.vx;
                        p.y += p.vy;
                        ctx.beginPath();
                        ctx.fillStyle = p.c;
                        ctx.globalAlpha = 0.9;
                        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                        ctx.fill();
                    });
                    if (Date.now() < endAt) {
                        requestAnimationFrame(draw);
                    } else {
                        if (canvas.parentNode) {
                            document.body.removeChild(canvas);
                        }
                    }
                }
                requestAnimationFrame(draw);
            }, 100);
        },
        
        /**
         * Ensure Next button is enabled on all steps
         */
        initTermsCheckbox: function() {
            $('.wizard-btn-next').prop('disabled', false).removeClass('disabled');
        },

        /**
         * License step: Next only after connect; hide Skip once connected.
         */
        updateLicenseStepFooter: function(isActive) {
            if (!window.yooadmWizard || window.yooadmWizard.currentStep !== 'license') {
                return;
            }

            const strings = window.yooadmWizard.strings || {};
            const connected = !!isActive;
            window.yooadmWizard.isLicenseActive = connected;

            const $footerEnd = $('.wizard-step-footer .wizard-footer-end');
            let $next = $footerEnd.find('.wizard-btn-next');
            let $skip = $footerEnd.find('.wizard-btn-skip');

            if (connected) {
                if (!$next.length) {
                    $footerEnd.append(
                        '<button type="button" class="wizard-btn wizard-btn-primary wizard-btn-next" data-action="next"></button>'
                    );
                    $next = $footerEnd.find('.wizard-btn-next');
                }
                $next.text(strings.next || 'Next').show().prop('disabled', false).removeClass('disabled loading');
                $skip.remove();
            } else {
                if ($next.length) {
                    $next.hide();
                }
                if (!$skip.length) {
                    $footerEnd.prepend(
                        '<button type="button" class="wizard-btn wizard-btn-text wizard-btn-skip" data-action="skip"></button>'
                    );
                    $skip = $footerEnd.find('.wizard-btn-skip');
                }
                $skip.text(strings.skipForNow || 'Skip for Now').show();
            }
        }
    };
    
    // Initialize on document ready
    $(document).ready(function() {
        yooadmWizardModule.init();
    });

})(jQuery);

