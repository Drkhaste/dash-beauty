/**
 * YOOAdmin — plugins.php native navigation bridge.
 *
 * This file intentionally does not turn plugins.php into an SPA. WordPress
 * plugin actions are nonce-protected and have several core side effects, so
 * filters, search, activate/deactivate, delete, bulk actions, and pagination
 * should continue through the native request flow.
 *
 * @package YOOAdmin
 */
(function ($) {
	'use strict';

	var cfg = window.yooadminPluginsExperience || {};
	var i18n = cfg.i18n || {};

	function isPluginsExperienceScreen() {
		return (
			document.body.classList.contains('yooadmin-plugins-screen') ||
			document.body.classList.contains('yooadmin-plugins-page') ||
			(document.body.classList.contains('plugins-php') &&
				document.body.classList.contains('yoo-list-screen'))
		);
	}

	function normalizeHref(href) {
		return String(href || '').replace(/&amp;/g, '&');
	}

	function resolveUrl(url) {
		try {
			return new URL(url || window.location.href, window.location.href);
		} catch (err) {
			return new URL(window.location.href);
		}
	}

	function showToast(type, message) {
		if (
			window.yooadminPluginsAdminExperience &&
			typeof window.yooadminPluginsAdminExperience.showToast === 'function'
		) {
			window.yooadminPluginsAdminExperience.showToast(type, message);
		}
	}

	function stripFlashParams(url) {
		var u = resolveUrl(url);
		['activate', 'deactivate', 'deleted', 'error', '_error_nonce'].forEach(function (key) {
			u.searchParams.delete(key);
		});
		return u.pathname + u.search + u.hash;
	}

	function showFlashFromCurrentUrl() {
		var u = resolveUrl(window.location.href);
		if (u.searchParams.get('activate') === 'true') {
			showToast('success', i18n.pluginActivated || 'Plugin activated.');
		}
		if (u.searchParams.get('deactivate') === 'true') {
			showToast('success', i18n.pluginDeactivated || 'Plugin deactivated.');
		}
		if (u.searchParams.get('deleted') === 'true') {
			showToast('success', i18n.pluginDeleted || 'Plugin deleted.');
		}

		var err = u.searchParams.get('error');
		if (err) {
			showToast('error', err);
		}

		if (
			window.history &&
			window.history.replaceState &&
			/(?:[?&])(activate|deactivate|deleted|error|_error_nonce)=/i.test(u.search)
		) {
			try {
				window.history.replaceState({}, '', stripFlashParams(u.href));
			} catch (replaceErr) {}
		}
	}

	function nativeNavigate(url) {
		if (!url) {
			return;
		}
		window.location.href = normalizeHref(url);
	}

	function nativeSubmitBulkForm() {
		var form = document.getElementById('bulk-action-form');
		if (form) {
			form.submit();
		}
	}

	function refreshLayoutOnly() {
		if (typeof window.yooadminPluginsLayoutRefresh === 'function') {
			window.yooadminPluginsLayoutRefresh();
		}
		if (
			window.yooadminPluginsAdminExperience &&
			typeof window.yooadminPluginsAdminExperience.convertNotices === 'function'
		) {
			window.yooadminPluginsAdminExperience.convertNotices();
		}
	}

	window.yooadminPluginsSpa = {
		navigate: function (url) {
			nativeNavigate(url);
		},
		applyHtml: function () {
			refreshLayoutOnly();
		},
		request: function (url) {
			nativeNavigate(url);
			return $.Deferred().resolve().promise();
		},
	};

	window.yooadminPluginsSpaNavigate = nativeNavigate;
	window.yooadminPluginsSpaSubmitBulkDelete = nativeSubmitBulkForm;

	$(document).ready(function () {
		if (!isPluginsExperienceScreen()) {
			return;
		}
		showFlashFromCurrentUrl();
		refreshLayoutOnly();
	});

	document.addEventListener('yooadmin-plugins-layout-ready', refreshLayoutOnly);
})(jQuery);
