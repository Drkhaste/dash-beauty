/**
 * YOOAdmin — compact confirm dialog (matches network site users confirm modal).
 */
(function (global) {
  'use strict';

  var MODAL_CLASS = 'yoo-network-site-users-modal yoo-network-site-users-confirm is-open';
  var BODY_OPEN_CLASSES = ['yoo-network-site-users-modal-open', 'yp-modal-open'];

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function closeModal(modal) {
    if (modal && modal.parentNode) {
      modal.parentNode.removeChild(modal);
    }
    document.body.classList.remove.apply(document.body.classList, BODY_OPEN_CLASSES);
  }

  /**
   * @param {Object} options
   * @param {string} options.title
   * @param {string} options.message
   * @param {string} [options.cancelLabel]
   * @param {string} [options.confirmLabel]
   * @param {function} [options.onConfirm] May return a Promise; modal closes after it resolves.
   * @param {function} [options.onCancel]
   */
  function confirmDialog(options) {
    options = options || {};

    var title = options.title || 'Confirm action';
    var message = options.message || '';
    var cancelLabel = options.cancelLabel || 'Cancel';
    var confirmLabel = options.confirmLabel || 'Confirm';
    var modalId = options.id || 'yoo-confirm-dialog-' + String(Date.now());
    var isBusy = false;

    var modal = document.createElement('div');
    modal.className = MODAL_CLASS;
    modal.id = modalId;
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');

    modal.innerHTML =
      '<div class="yoo-network-site-users-modal__overlay">' +
      '<div class="yoo-network-site-users-modal__content yoo-network-site-users-confirm__content">' +
      '<button type="button" class="yp-modal-close" data-yoo-confirm-close aria-label="' +
      escapeHtml(cancelLabel) +
      '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>' +
      '<div class="yp-modal-header">' +
      '<span class="yp-modal-icon dashicons dashicons-warning" aria-hidden="true"></span>' +
      '<h2 class="yp-modal-title">' +
      escapeHtml(title) +
      '</h2></div>' +
      '<div class="yp-modal-body yoo-network-site-users-confirm__body">' +
      '<p class="yoo-network-site-users-confirm__message">' +
      escapeHtml(message) +
      '</p></div>' +
      '<div class="yp-modal-footer yoo-network-site-users-confirm__footer">' +
      '<button type="button" class="yp-yoo-btn yp-yoo-btn--secondary" data-yoo-confirm-close>' +
      escapeHtml(cancelLabel) +
      '</button>' +
      '<button type="button" class="yp-yoo-btn yp-yoo-btn--primary" data-yoo-confirm-ok>' +
      escapeHtml(confirmLabel) +
      '</button>' +
      '</div></div></div>';

    document.body.appendChild(modal);
    document.body.classList.add.apply(document.body.classList, BODY_OPEN_CLASSES);

    var okBtn = modal.querySelector('[data-yoo-confirm-ok]');
    var overlay = modal.querySelector('.yoo-network-site-users-modal__overlay');
    var escHandler = null;

    function removeEscHandler() {
      if (escHandler) {
        document.removeEventListener('keydown', escHandler);
        escHandler = null;
      }
    }

    function setBusy(busy) {
      isBusy = !!busy;
      if (okBtn) {
        okBtn.disabled = isBusy;
      }
    }

    function finishCancel() {
      if (isBusy) {
        return;
      }
      removeEscHandler();
      closeModal(modal);
      if (typeof options.onCancel === 'function') {
        options.onCancel();
      }
    }

    function finishConfirm() {
      if (isBusy) {
        return;
      }

      var result;
      if (typeof options.onConfirm === 'function') {
        try {
          result = options.onConfirm();
        } catch (err) {
          setBusy(false);
          if (global.console && typeof global.console.error === 'function') {
            global.console.error(err);
          }
          return;
        }
      }

      if (result && typeof result.then === 'function') {
        setBusy(true);
        result
          .then(function () {
            removeEscHandler();
            closeModal(modal);
          })
          .catch(function () {
            setBusy(false);
          });
        return;
      }

      removeEscHandler();
      closeModal(modal);
    }

    modal.addEventListener('click', function (evt) {
      if (evt.target.closest('[data-yoo-confirm-close]')) {
        evt.preventDefault();
        finishCancel();
        return;
      }

      if (evt.target.closest('[data-yoo-confirm-ok]')) {
        evt.preventDefault();
        finishConfirm();
        return;
      }

      if (overlay && evt.target === overlay) {
        finishCancel();
      }
    });

    escHandler = function (evt) {
      if (evt.key === 'Escape' && document.getElementById(modalId)) {
        finishCancel();
      }
    };

    document.addEventListener('keydown', escHandler);

    if (okBtn) {
      window.requestAnimationFrame(function () {
        if (document.getElementById(modalId) && okBtn) {
          okBtn.focus();
        }
      });
    }
  }

  global.yooadminConfirmDialog = confirmDialog;
})(window);
