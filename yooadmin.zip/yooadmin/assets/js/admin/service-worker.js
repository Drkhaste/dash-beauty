/**
 * YOOAdmin - Service worker (notifications, offline)
 *
 * @package YOOAdmin
 */

(function() {
    'use strict';
    
    // Configuration
    const CONFIG = {
        CHANNEL_NAME: 'yp-notifications',
        DEFAULT_POLL_INTERVAL: 60000, // 1 minute
        MIN_POLL_INTERVAL: 15000,     // 15 seconds
        MAX_POLL_INTERVAL: 300000,     // 5 minutes
        OFFLINE_RETRY_INTERVAL: 30000, // 30 seconds
        MAX_RETRIES: 3,
        CACHE_TTL: 300000,            // 5 minutes
        MESSAGE_QUEUE_LIMIT: 50,
        PING_INTERVAL: 30000          // 30 seconds
    };
    
    // State management
    const State = {
        config: {
            restEndpoint: '',
            restNonce: '',
            pollInterval: CONFIG.DEFAULT_POLL_INTERVAL,
            userId: 0
        },
        pollTimer: null,
        pingTimer: null,
        lastHash: null,
        lastPollTime: 0,
        isOnline: navigator.onLine,
        retryCount: 0,
        messageQueue: [],
        cache: new Map(),
        broadcastChannel: null,
        isActive: false,
        performanceMetrics: {
            pollCount: 0,
            successCount: 0,
            errorCount: 0,
            avgResponseTime: 0,
            totalResponseTime: 0
        }
    };
    
    // Initialize service worker
    function init(config) {
        try {
            State.config = sanitizeConfig(config);
            State.isActive = true;
            
            // Initialize broadcast channel
            initBroadcastChannel();
            
            // Start monitoring
            startConnectionMonitoring();
            
            // Start ping interval
            startPingInterval();
            
            // Start polling if configured
            if (State.config.restEndpoint && State.config.restNonce) {
                startPolling();
            }
            
        } catch (error) {
            broadcastError('initialization_failed', error.message);
        }
    }
    
    // Sanitize configuration
    function sanitizeConfig(config) {
        if (!config || typeof config !== 'object') {
            return {};
        }
        
        const sanitized = {
            restEndpoint: String(config.restEndpoint || ''),
            restNonce: String(config.restNonce || ''),
            userId: parseInt(config.userId || 0, 10),
            pollInterval: Math.max(CONFIG.MIN_POLL_INTERVAL, 
                           Math.min(CONFIG.MAX_POLL_INTERVAL, 
                           parseInt(config.pollInterval || CONFIG.DEFAULT_POLL_INTERVAL, 10)))
        };
        
        return sanitized;
    }
    
    // Initialize broadcast channel
    function initBroadcastChannel() {
        if (typeof BroadcastChannel !== 'undefined') {
            try {
                State.broadcastChannel = new BroadcastChannel(CONFIG.CHANNEL_NAME);
                
                State.broadcastChannel.onmessage = handleBroadcastMessage;
                
            } catch (error) {
                State.broadcastChannel = null;
            }
        }
    }
    
    // Handle broadcast messages
    function handleBroadcastMessage(event) {
        const message = event.data;
        
        if (!message || typeof message !== 'object') {
            return;
        }
        
        switch (message.type) {
            case 'config_update':
                updateConfig(message.config);
                break;
                
            case 'force_refresh':
                forceRefresh();
                break;
                
            case 'mark_read':
                markNotificationRead(message.notificationId);
                break;
                
            case 'dismiss':
                dismissNotification(message.notificationId, message.type, message.snoozeUntil);
                break;
                
            case 'ping':
                broadcast('pong', { timestamp: Date.now() });
                break;
                
            default:
                // Unknown message type
        }
    }
    
    // Update configuration
    function updateConfig(newConfig) {
        const oldConfig = { ...State.config };
        State.config = sanitizeConfig({ ...State.config, ...newConfig });
        
        // Restart polling if interval changed
        if (oldConfig.pollInterval !== State.config.pollInterval) {
            restartPolling();
        }
    }
    
    // Start connection monitoring
    function startConnectionMonitoring() {
        window.addEventListener('online', () => {
            State.isOnline = true;
            State.retryCount = 0;
            
            broadcast('connection_restored');
            
            // Restart polling
            if (State.isActive) {
                startPolling();
            }
        });
        
        window.addEventListener('offline', () => {
            State.isOnline = false;
            
            broadcast('connection_lost');
            
            // Stop polling and queue messages
            stopPolling();
        });
    }
    
    // Start ping interval for connection health
    function startPingInterval() {
        if (State.pingTimer) {
            clearInterval(State.pingTimer);
        }
        
        State.pingTimer = setInterval(() => {
            if (State.isOnline && State.broadcastChannel) {
                broadcast('ping', { timestamp: Date.now() });
            }
        }, CONFIG.PING_INTERVAL);
    }
    
    // Start polling
    function startPolling() {
        if (!State.isOnline || !State.config.restEndpoint || !State.config.restNonce) {
            return;
        }
        
        stopPolling();
        
        State.pollTimer = setInterval(() => {
            pollNotifications();
        }, State.config.pollInterval);
        
        // Initial poll
        pollNotifications();
    }
    
    // Stop polling
    function stopPolling() {
        if (State.pollTimer) {
            clearInterval(State.pollTimer);
            State.pollTimer = null;
        }
    }
    
    // Restart polling
    function restartPolling() {
        stopPolling();
        if (State.isActive && State.isOnline) {
            startPolling();
        }
    }
    
    // Poll notifications
    async function pollNotifications() {
        if (!State.isOnline || State.retryCount >= CONFIG.MAX_RETRIES) {
            return;
        }
        
        const startTime = performance.now();
        State.lastPollTime = startTime;
        State.performanceMetrics.pollCount++;
        
        try {
            // Check cache first
            const cacheKey = `notifications_${State.config.userId}`;
            const cached = getFromCache(cacheKey);
            
            if (cached && (Date.now() - cached.timestamp) < CONFIG.CACHE_TTL) {
                // Use cached data
                broadcast('notifications_updated', cached.data);
                return;
            }
            
            // Fetch from server
            const response = await fetch(State.config.restEndpoint, {
                method: 'GET',
                headers: {
                    'X-WP-Nonce': State.config.restNonce,
                    'Content-Type': 'application/json',
                    'X-YP-Client': 'service-worker'
                },
                cache: 'no-cache'
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            
            // Calculate hash
            const newHash = generateHash(data);
            
            // Check if data changed
            if (State.lastHash !== newHash) {
                State.lastHash = newHash;
                
                // Cache the data
                setCache(cacheKey, {
                    data: data,
                    hash: newHash,
                    timestamp: Date.now()
                });
                
                // Broadcast update
                broadcast('notifications_updated', data);
            }
            
            // Update metrics
            const responseTime = performance.now() - startTime;
            updatePerformanceMetrics(responseTime, true);
            
            State.retryCount = 0;
            
        } catch (error) {
            // Update metrics
            const responseTime = performance.now() - startTime;
            updatePerformanceMetrics(responseTime, false);
            
            State.retryCount++;
            
            // Broadcast error
            broadcastError('poll_failed', error.message);
            
            // Implement exponential backoff
            if (State.retryCount < CONFIG.MAX_RETRIES) {
                const backoffInterval = State.config.pollInterval * Math.pow(2, State.retryCount);
                setTimeout(() => pollNotifications(), backoffInterval);
            } else {
                stopPolling();
            }
        }
    }
    
    // Force refresh
    function forceRefresh() {
        // Clear cache
        clearCache();
        
        // Reset hash
        State.lastHash = null;
        
        // Poll immediately
        pollNotifications();
    }
    
    // Mark notification as read
    async function markNotificationRead(notificationId) {
        try {
            const response = await fetch(`${State.config.restEndpoint}/${notificationId}/read`, {
                method: 'POST',
                headers: {
                    'X-WP-Nonce': State.config.restNonce,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                // Update local cache
                updateLocalNotification(notificationId, { status: 'read' });
                
                // Broadcast success
                broadcast('notification_marked_read', { notificationId });
            }
            
        } catch (error) {
            broadcastError('mark_read_failed', error.message);
        }
    }
    
    // Dismiss notification
    async function dismissNotification(notificationId, type = 'dismiss', snoozeUntil = null) {
        try {
            const response = await fetch(`${State.config.restEndpoint}/${notificationId}/dismiss`, {
                method: 'POST',
                headers: {
                    'X-WP-Nonce': State.config.restNonce,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    type: type,
                    snooze_until: snoozeUntil
                })
            });
            
            if (response.ok) {
                // Update local cache
                updateLocalNotification(notificationId, { 
                    status: 'dismissed',
                    dismissal_type: type,
                    snooze_until: snoozeUntil
                });
                
                // Broadcast success
                broadcast('notification_dismissed', { 
                    notificationId, 
                    type, 
                    snoozeUntil 
                });
            }
            
        } catch (error) {
            broadcastError('dismiss_failed', error.message);
        }
    }
    
    // Update local notification cache
    function updateLocalNotification(notificationId, updates) {
        const cacheKey = `notifications_${State.config.userId}`;
        const cached = getFromCache(cacheKey);
        
        if (cached && cached.data.notifications) {
            const notifications = cached.data.notifications;
            const index = notifications.findIndex(n => n.id == notificationId);
            
            if (index !== -1) {
                notifications[index] = { ...notifications[index], ...updates };
                
                // Update cache
                setCache(cacheKey, {
                    ...cached,
                    data: { ...cached.data, notifications },
                    timestamp: Date.now()
                });
                
                // Broadcast updated data
                broadcast('notifications_updated', cached.data);
            }
        }
    }
    
    // Generate hash for data
    function generateHash(data) {
        if (!data) return 'empty';
        
        // Create a normalized string for consistent hashing
        const normalized = JSON.stringify({
            count: data.notifications?.length || 0,
            items: (data.notifications || []).map(n => ({
                id: n.id,
                title: n.title,
                message: n.message,
                status: n.status,
                priority: n.priority,
                updated_at: n.updated_at
            })),
            timestamp: Math.floor(Date.now() / CONFIG.CACHE_TTL) * CONFIG.CACHE_TTL
        });
        
        return btoa(normalized).substring(0, 16);
    }
    
    // Cache management
    function getFromCache(key) {
        const cached = State.cache.get(key);
        
        if (cached && (Date.now() - cached.timestamp) < CONFIG.CACHE_TTL) {
            return cached.data;
        }
        
        State.cache.delete(key);
        return null;
    }
    
    function setCache(key, data) {
        // Limit cache size
        if (State.cache.size >= 100) {
            const firstKey = State.cache.keys().next().value;
            State.cache.delete(firstKey);
        }
        
        State.cache.set(key, {
            data: data,
            timestamp: Date.now()
        });
    }
    
    function clearCache() {
        State.cache.clear();
    }
    
    // Update performance metrics
    function updatePerformanceMetrics(responseTime, success) {
        State.performanceMetrics.totalResponseTime += responseTime;
        State.performanceMetrics.avgResponseTime = 
            State.performanceMetrics.totalResponseTime / State.performanceMetrics.pollCount;
        
        if (success) {
            State.performanceMetrics.successCount++;
        } else {
            State.performanceMetrics.errorCount++;
        }
    }
    
    // Broadcast message
    function broadcast(type, data = {}) {
        const message = {
            type: type,
            data: data,
            timestamp: Date.now(),
            source: 'service-worker'
        };
        
        // Send via broadcast channel
        if (State.broadcastChannel) {
            try {
                State.broadcastChannel.postMessage(message);
            } catch (error) {
            }
        }
        
        // Queue message for offline scenarios
        if (!State.isOnline) {
            queueMessage(message);
        }
        
        // Also send via custom event for local tabs
        const event = new CustomEvent('yp-notification', { detail: message });
        window.dispatchEvent(event);
    }
    
    // Broadcast error
    function broadcastError(errorType, message) {
        broadcast('error', {
            type: errorType,
            message: message,
            retryCount: State.retryCount,
            isOnline: State.isOnline
        });
    }
    
    // Message queuing for offline scenarios
    function queueMessage(message) {
        State.messageQueue.push(message);
        
        // Limit queue size
        if (State.messageQueue.length > CONFIG.MESSAGE_QUEUE_LIMIT) {
            State.messageQueue.shift();
        }
    }
    
    // Process queued messages when back online
    function processQueuedMessages() {
        if (State.messageQueue.length === 0) {
            return;
        }
        
        while (State.messageQueue.length > 0) {
            const message = State.messageQueue.shift();
            broadcast(message.type, message.data);
        }
    }
    
    // Get performance metrics
    function getPerformanceMetrics() {
        return {
            ...State.performanceMetrics,
            successRate: State.performanceMetrics.pollCount > 0 ? 
                (State.performanceMetrics.successCount / State.performanceMetrics.pollCount * 100) : 0,
            errorRate: State.performanceMetrics.pollCount > 0 ? 
                (State.performanceMetrics.errorCount / State.performanceMetrics.pollCount * 100) : 0,
            cacheSize: State.cache.size,
            queueSize: State.messageQueue.length,
            isOnline: State.isOnline,
            retryCount: State.retryCount,
            lastPollTime: State.lastPollTime
        };
    }
    
    // Destroy service worker
    function destroy() {
        State.isActive = false;
        
        // Clear timers
        stopPolling();
        
        if (State.pingTimer) {
            clearInterval(State.pingTimer);
            State.pingTimer = null;
        }
        
        // Close broadcast channel
        if (State.broadcastChannel) {
            State.broadcastChannel.close();
            State.broadcastChannel = null;
        }
        
        // Clear cache
        clearCache();
        
        // Clear message queue
        State.messageQueue = [];
    }
    
    // Public API
    window.yooadmServiceWorker = {
        init: init,
        updateConfig: updateConfig,
        forceRefresh: forceRefresh,
        markAsRead: markNotificationRead,
        dismiss: dismissNotification,
        getMetrics: getPerformanceMetrics,
        destroy: destroy,
        
        // Expose state for debugging
        _state: State,
        _config: CONFIG
    };
    
    // Auto-initialize if config is available
    if (typeof window.yooadmRuntime !== 'undefined' && window.yooadmRuntime.serviceWorkerConfig) {
        init(window.yooadmRuntime.serviceWorkerConfig);
    }
    
    // Listen for config updates
    window.addEventListener('message', function(event) {
        if (event.data && event.data.type === 'yooadmin_service_worker_config') {
            init(event.data.config);
        }
    });
    
})();
