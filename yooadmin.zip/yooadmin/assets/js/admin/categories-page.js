/**
 * YOOAdmin - Categories page script
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        $('.yoo-categories-metrics-toggle').on('click', function() {
            const $btn = $(this);
            const $metrics = $('.yoo-categories-hero__metrics');
            const isExpanded = $btn.attr('aria-expanded') === 'true';
            
            if (isExpanded) {
                $metrics.stop().slideUp(300, function() {
                    $(this).css('display', 'none');
                });
                $btn.attr('aria-expanded', 'false');
                $btn.find('.dashicons').removeClass('dashicons-arrow-up-alt').addClass('dashicons-arrow-down-alt');
                $btn.find('span:last').text('Show Statistics');
            } else {
                $metrics.css('display', 'flex').hide().stop().slideDown(300);
                $btn.attr('aria-expanded', 'true');
                $btn.find('.dashicons').removeClass('dashicons-arrow-down-alt').addClass('dashicons-arrow-up-alt');
                $btn.find('span:last').text('Hide Statistics');
            }
        });

        $('.yoo-filter-chip').on('click', function(e) {
            e.preventDefault();
            
            const $chip = $(this);
            const filter = $chip.attr('href').includes('show=with-posts') ? 'with-posts' : 
                          $chip.attr('href').includes('show=empty') ? 'empty' : 'all';
            
            $('.yoo-filter-chip').removeClass('is-active');
            $chip.addClass('is-active');
            
            const $categories = $('.yoo-category-card');
            
            if (filter === 'all') {
                $categories.fadeIn(200);
            } else if (filter === 'with-posts') {
                $categories.each(function() {
                    const count = parseInt($(this).data('posts-count')) || 0;
                    $(this).toggle(count > 0);
                });
            } else if (filter === 'empty') {
                $categories.each(function() {
                    const count = parseInt($(this).data('posts-count')) || 0;
                    $(this).toggle(count === 0);
                });
            }
        });

        // Add Category Modal
        $('#yoo-add-category-btn, #yoo-add-first-category-btn').on('click', function() {
            $('#yoo-add-category-modal').addClass('is-active');
        });

        $('#yoo-category-modal-close, #yoo-category-modal-cancel').on('click', function() {
            $('#yoo-add-category-modal').removeClass('is-active');
            $('#yoo-add-category-form')[0].reset();
        });

        // Auto-generate slug from name
        var slugManuallyEdited = false;
        
        $('#yoo-cat-name').on('input', function() {
            if (!slugManuallyEdited) {
                var slug = $(this).val()
                    .toLowerCase()
                    .replace(/[^a-z0-9\u0621-\u064A]+/g, '-') // Support Arabic too
                    .replace(/^-+|-+$/g, '');
                $('#yoo-cat-slug').val(slug);
            }
        });
        
        // Track manual slug editing
        $('#yoo-cat-slug').on('input', function() {
            slugManuallyEdited = true;
        });
        
        // Reset flag when modal closes
        $('#yoo-category-modal-close, #yoo-category-modal-cancel').on('click', function() {
            slugManuallyEdited = false;
        });

        // Success popup
        function showSuccessPopup(message) {
            var $popup = $(
                '<div class="yoo-category-popup-overlay">' +
                    '<div class="yoo-category-popup">' +
                        '<div class="yoo-category-popup-icon success">' +
                            '<span class="dashicons dashicons-yes-alt"></span>' +
                        '</div>' +
                        '<h3>Success!</h3>' +
                        '<p>' + message + '</p>' +
                        '<div class="yoo-category-popup-actions">' +
                            '<button class="yoo-category-popup-btn yoo-category-popup-ok">OK</button>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
            
            $('body').append($popup);
            setTimeout(function() { $popup.addClass('visible'); }, 10);
            
            $popup.find('.yoo-category-popup-ok').on('click', function() {
                $popup.removeClass('visible');
                setTimeout(function() {
                    $popup.remove();
                    location.reload();
                }, 300);
            });
        }

        // Delete confirmation popup
        function showDeleteConfirmPopup(categoryId, categoryName) {
            var $popup = $(
                '<div class="yoo-category-popup-overlay">' +
                    '<div class="yoo-category-popup">' +
                        '<div class="yoo-category-popup-icon warning">' +
                            '<span class="dashicons dashicons-warning"></span>' +
                        '</div>' +
                        '<h3>Delete Category?</h3>' +
                        '<p>Are you sure you want to delete <strong>' + categoryName + '</strong>? This action cannot be undone.</p>' +
                        '<div class="yoo-category-popup-actions">' +
                            '<button class="yoo-category-popup-btn yoo-category-popup-cancel">Cancel</button>' +
                            '<button class="yoo-category-popup-btn yoo-category-popup-delete">Delete</button>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
            
            $('body').append($popup);
            setTimeout(function() { $popup.addClass('visible'); }, 10);
            
            $popup.find('.yoo-category-popup-cancel').on('click', function() {
                $popup.removeClass('visible');
                setTimeout(function() { $popup.remove(); }, 300);
            });
            
            $popup.find('.yoo-category-popup-delete').on('click', function() {
                var $deleteBtn = $(this);
                $deleteBtn.prop('disabled', true).text('Deleting...');
                
                $.ajax({
                    url: yooadmCategories.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'yooadmin_categories_action',
                        category_action: 'delete',
                        category_id: categoryId,
                        nonce: yooadmCategories.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $popup.removeClass('visible');
                            setTimeout(function() {
                                $popup.remove();
                                showSuccessPopup(response.data.message || 'Category deleted successfully!');
                            }, 300);
                        } else {
                            alert(response.data.message || 'Failed to delete category.');
                            $deleteBtn.prop('disabled', false).text('Delete');
                        }
                    },
                    error: function() {
                        alert('An error occurred. Please try again.');
                        $deleteBtn.prop('disabled', false).text('Delete');
                    }
                });
            });
        }

        // Handle form submission
        $('#yoo-add-category-form').on('submit', function(e) {
            e.preventDefault();

            var $form = $(this);
            var $submitBtn = $form.find('button[type="submit"]');
            var originalText = $submitBtn.text();

            $submitBtn.prop('disabled', true).text('Adding...');

            $.ajax({
                url: yooadmCategories.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_add_category',
                    name: $('#yoo-cat-name').val(),
                    slug: $('#yoo-cat-slug').val(),
                    parent: $('#yoo-cat-parent').val(),
                    description: $('#yoo-cat-description').val(),
                    nonce: yooadmCategories.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $('#yoo-add-category-modal').removeClass('is-active');
                        setTimeout(function() {
                            showSuccessPopup(response.data.message || 'Category added successfully!');
                        }, 300);
                    } else {
                        alert(response.data.message || 'Failed to add category.');
                        $submitBtn.prop('disabled', false).text(originalText);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            });
        });


        // Bulk actions
        var $checkboxes = $('.yoo-category-checkbox');
        var $selectAll = $('#yoo-select-all-categories');
        var $bulkBar = $('.yoo-bulk-actions-bar');
        var $selectedCount = $('.yoo-selected-count');
        var $bulkApply = $('#yoo-bulk-apply');
        var $bulkSelect = $('#yoo-bulk-action-select');

        function updateBulkBar() {
            var selected = $checkboxes.filter(':checked:not(:disabled)').length;
            if (selected > 0) {
                $bulkBar.addClass('show');
                $selectedCount.text(selected + ' ' + (yooadmCategories.i18n.selected || 'selected'));
                $bulkApply.prop('disabled', !$bulkSelect.val());
            } else {
                $bulkBar.removeClass('show');
            }
        }

        $checkboxes.on('change', updateBulkBar);
        $selectAll.on('change', function() {
            $checkboxes.filter(':not(:disabled)').prop('checked', $(this).prop('checked'));
            updateBulkBar();
        });

        $bulkSelect.on('change', function() {
            $bulkApply.prop('disabled', !$(this).val());
        });

        // Individual actions
        $(document).on('click', '.yoo-action-btn.delete', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var categoryId = $btn.data('category-id');
            var categoryName = $btn.data('category-name');
            
            showDeleteConfirmPopup(categoryId, categoryName);
        });

        // Bulk apply
        $bulkApply.on('click', function() {
            var action = $bulkSelect.val();
            if (!action) return;

            var selected = $checkboxes.filter(':checked:not(:disabled)').map(function() {
                return $(this).val();
            }).get();

            if (selected.length === 0) return;

            $.ajax({
                url: yooadmCategories.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_bulk_categories_action',
                    bulk_action: action,
                    categories: selected,
                    nonce: yooadmCategories.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.data.message || 'Error occurred');
                    }
                }
            });
        });
    });
})(jQuery);






















