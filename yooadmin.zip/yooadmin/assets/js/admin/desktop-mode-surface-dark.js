(function () {
	'use strict';

	if (window.__yooadminDesktopSurfaceDarkWired__) {
		return;
	}
	window.__yooadminDesktopSurfaceDarkWired__ = true;

	function effectiveFromRaw(raw) {
		if (raw === 'auto') {
			try {
				return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
			} catch (e) {
				return 'light';
			}
		}
		return raw === 'dark' ? 'dark' : 'light';
	}

	function readShellColorMode() {
		var html = document.documentElement;
		var mode = html.getAttribute('data-yooadmin-studio-color-mode') || 'auto';
		var effective =
			html.getAttribute('data-yooadmin-studio-color-mode-effective') || effectiveFromRaw(mode);
		return { mode: mode, effective: effective };
	}

	function isDarkEffective() {
		return readShellColorMode().effective === 'dark';
	}

	function applyColorModeToDocument(doc, mode, effective) {
		if (!doc || !doc.documentElement) {
			return;
		}

		var html = doc.documentElement;
		var body = doc.body;
		var eff = effective || effectiveFromRaw(mode);

		html.setAttribute('data-yooadmin-studio-color-mode', mode);
		html.setAttribute('data-yooadmin-studio-color-mode-effective', eff);
		html.classList.add('yooadmin-studio-hub-html');
		html.classList.toggle('is-dark-theme', eff === 'dark');
		if (body) {
			body.classList.toggle('is-dark-theme', eff === 'dark');
		}

		try {
			doc.dispatchEvent(new CustomEvent('ysh-studio-color-mode-changed'));
		} catch (e) {
			/* ignore */
		}

		var win = doc.defaultView;
		if (!win) {
			return;
		}
		if (typeof win.yshSyncStudioShellThemeChrome === 'function') {
			win.yshSyncStudioShellThemeChrome(eff);
		}
		if (typeof win.yshPluginAdminAdaptSyncMode === 'function') {
			win.yshPluginAdminAdaptSyncMode();
		}
	}

	function syncWindowIframes() {
		var modes = readShellColorMode();

		document.querySelectorAll('.desktop-mode-window iframe').forEach(function (frame) {
			try {
				var doc = frame.contentDocument;
				if (doc) {
					applyColorModeToDocument(doc, modes.mode, modes.effective);
				}
			} catch (e) {
				/* cross-origin — ignore */
			}

			try {
				frame.contentWindow.postMessage(
					{
						type: 'yooadmin-desktop-color-mode-sync',
						mode: modes.mode,
						effective: modes.effective,
					},
					window.location.origin
				);
			} catch (postErr) {
				/* ignore */
			}
		});
	}

	function syncDesktopDarkSurface() {
		var shell = document.getElementById('desktop-mode-shell');
		if (shell) {
			shell.classList.toggle('yooadmin-desktop-dark-surface', isDarkEffective());
		}
		syncWindowIframes();
	}

	function registerIframeHooks() {
		var hooks = window.wp && window.wp.hooks;
		if (!hooks || typeof hooks.addAction !== 'function') {
			return;
		}

		hooks.addAction(
			'desktop-mode.iframe.ready',
			'yooadmin/desktop-color-sync',
			function () {
				syncWindowIframes();
			},
			20
		);

		hooks.addAction(
			'desktop-mode.window.opened',
			'yooadmin/desktop-color-sync',
			function () {
				window.setTimeout(syncWindowIframes, 50);
			},
			20
		);
	}

	function watchColorMode() {
		syncDesktopDarkSurface();

		document.addEventListener('ysh-studio-color-mode-changed', syncDesktopDarkSurface);

		if (typeof MutationObserver === 'function') {
			var observer = new MutationObserver(syncDesktopDarkSurface);
			observer.observe(document.documentElement, {
				attributes: true,
				attributeFilter: ['data-yooadmin-studio-color-mode-effective', 'data-yooadmin-studio-color-mode', 'class'],
			});
			if (document.body) {
				observer.observe(document.body, {
					attributes: true,
					attributeFilter: ['class'],
				});
			}
		}

		registerIframeHooks();

		// Re-sync when new native window content mounts (plugins table, etc.).
		if (typeof MutationObserver === 'function') {
			var shell = document.getElementById('desktop-mode-shell');
			if (shell) {
				var windowObserver = new MutationObserver(function () {
					window.setTimeout(syncWindowIframes, 30);
				});
				windowObserver.observe(shell, { childList: true, subtree: true });
			}
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', watchColorMode);
	} else {
		watchColorMode();
	}
})();
