/**
 * YOOAdmin - Focus mode disabled notice
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        
        // Define helper functions first
        function closeModal($targetModal) {
            $targetModal.fadeOut(300, function() {
                $('body').removeClass('yp-modal-open');
            });
        }
        
        function enableFocusMode($btn) {
            // Disable button and show processing state
            $btn.prop('disabled', true).html(
                '<span class="dashicons dashicons-update spin"></span> ' +
                '<span>' + (yooadmFocusNotice.i18n.enabling || 'Enabling...') + '</span>'
            );
            
            $.ajax({
                url: yooadmFocusNotice.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_enable_focus_mode',
                    nonce: yooadmFocusNotice.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Redirect to YOOAdmin dashboard
                        window.location.href = response.data.redirect_url;
                    } else {
                        const message = response.data && response.data.message 
                            ? response.data.message 
                            : 'An error occurred';
                        alert(message);
                        $btn.prop('disabled', false).html(
                            '<span class="dashicons dashicons-visibility"></span> ' +
                            yooadmFocusNotice.i18n.enableButton
                        );
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                    $btn.prop('disabled', false).html(
                        '<span class="dashicons dashicons-visibility"></span> ' +
                        yooadmFocusNotice.i18n.enableButton
                    );
                }
            });
        }
        
        // Create and show modal (for auto-show after deactivation)
        function createModal() {
            const i18n = yooadmFocusNotice.i18n;
            const logoUrl = yooadmFocusNotice.logoUrl || (yooadmFocusNotice.pluginUrl + '/assets/images/logo.png');
            
            const modalHTML = `
                <div id="yooadmin-focus-notice-modal" class="yp-focus-notice-modal">
                    <div class="yp-focus-notice-overlay"></div>
                    <div class="yp-focus-notice-dialog">
                        <div class="yp-focus-notice-header">
                            <div class="yp-focus-notice-icon">
                                <img src="${logoUrl}" alt="YOOAdmin Logo" />
                            </div>
                            <h2>${i18n.title}</h2>
                        </div>
                        <div class="yp-focus-notice-content">
                            <div class="yp-focus-notice-message">
                                <p><strong>${i18n.message}</strong></p>
                                <p>${i18n.info}</p>
                            </div>
                            
                            <div class="yp-focus-notice-list">
                                <p><strong>${i18n.option1}</strong></p>
                                <ul>
                                    <li><span class="dashicons dashicons-yes"></span> ${i18n.bullet1}</li>
                                    <li><span class="dashicons dashicons-yes"></span> ${i18n.bullet2}</li>
                                    <li><span class="dashicons dashicons-yes"></span> ${i18n.bullet3}</li>
                                </ul>
                            </div>
                        </div>
                        <div class="yp-focus-notice-footer">
                            <button type="button" class="button button-secondary yp-focus-notice-continue">${i18n.continueButton}</button>
                            <button type="button" class="button button-primary yp-focus-notice-enable">
                                <span class="dashicons dashicons-visibility"></span>
                                ${i18n.enableButton}
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(modalHTML);
            
            // Get modal elements
            const $modal = $('#yooadmin-focus-notice-modal');
            const $enableBtn = $modal.find('.yp-focus-notice-enable');
            const $continueBtn = $modal.find('.yp-focus-notice-continue');
            
            // Handle Continue button
            $continueBtn.on('click', function() {
                closeModal($modal);
            });
            
            // Handle Enable Focus Mode button
            $enableBtn.on('click', function() {
                enableFocusMode($enableBtn);
            });
            
            // Handle Escape key
            $(document).on('keydown.focusNotice', function(e) {
                if (e.key === 'Escape' && $modal.is(':visible')) {
                    closeModal($modal);
                    $(document).off('keydown.focusNotice');
                }
            });
            
            // Show modal with animation
            setTimeout(function() {
                $modal.fadeIn(300);
                $('body').addClass('yp-modal-open');
            }, 500); // Small delay for better UX
        }
        
        // Check if we should auto-show the popup (after deactivation)
        const urlParams = new URLSearchParams(window.location.search);
        const shouldShowPopup = urlParams.has('yooadmin_focus_disabled');
        
        // Auto-show popup if redirected from YOOAdmin deactivation
        if (shouldShowPopup) {
            // Clean URL immediately to prevent popup from showing again on refresh
            if (window.history && window.history.replaceState) {
                const url = new URL(window.location);
                url.searchParams.delete('yooadmin_focus_disabled');
                window.history.replaceState({}, '', url);
            }
            
            createModal();
        }
        
        // Handle Settings link click when Focus Mode is disabled
        $(document).on('click', '.yooadmin-enable-focus-link', function(e) {
            e.preventDefault();
            showEnableFocusModal();
        });
        
        // Function to show enable focus modal (can be called from Settings link too)
        function showEnableFocusModal() {
            const i18n = yooadmFocusNotice.i18n;
            const logoUrl = yooadmFocusNotice.settingsModalLogoUrl
                || (yooadmFocusNotice.pluginUrl + '/assets/images/logo-dark.png');
            
            const modalHTML = `
                <div id="yooadmin-enable-focus-modal" class="yp-focus-notice-modal">
                    <div class="yp-focus-notice-overlay"></div>
                    <div class="yp-focus-notice-dialog">
                        <div class="yp-focus-notice-header">
                            <div class="yp-focus-notice-icon">
                                <img src="${logoUrl}" alt="YOOAdmin Logo" />
                            </div>
                            <h2>${i18n.enableFocusTitle || 'Enable Focus Mode'}</h2>
                        </div>
                        <div class="yp-focus-notice-content">
                            <div class="yp-focus-notice-message">
                                <p><strong>${i18n.enableFocusMessage || 'Focus Mode is currently disabled.'}</strong></p>
                                <p>${i18n.enableFocusInfo || 'To access YOOAdmin Settings and features, please enable Focus Mode first.'}</p>
                            </div>
                        </div>
                        <div class="yp-focus-notice-footer">
                            <button type="button" class="button button-secondary yp-enable-focus-cancel">${i18n.cancel || 'Cancel'}</button>
                            <button type="button" class="button button-primary yp-enable-focus-confirm">
                                <span class="dashicons dashicons-visibility"></span>
                                ${i18n.enableFocusButton || 'Enable Focus Mode'}
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            // Remove existing modal if any
            $('#yooadmin-enable-focus-modal').remove();
            
            $('body').append(modalHTML);
            
            const $settingsModal = $('#yooadmin-enable-focus-modal');
            
            // Show modal
            setTimeout(function() {
                $settingsModal.fadeIn(300);
                $('body').addClass('yp-modal-open');
            }, 100);
            
            // Handle Cancel
            $settingsModal.find('.yp-enable-focus-cancel, .yp-focus-notice-overlay').on('click', function() {
                $settingsModal.fadeOut(300, function() {
                    $(this).remove();
                    $('body').removeClass('yp-modal-open');
                });
            });
            
            // Handle Confirm
            $settingsModal.find('.yp-enable-focus-confirm').on('click', function() {
                const $btn = $(this);
                $btn.prop('disabled', true).html(
                    '<span class="dashicons dashicons-update spin"></span> ' + (i18n.enabling || 'Enabling...')
                );
                
                $.ajax({
                    url: yooadmFocusNotice.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'yooadmin_enable_focus_mode',
                        nonce: yooadmFocusNotice.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            // Redirect to settings page
                            window.location.href = yooadmFocusNotice.ajaxUrl.replace('admin-ajax.php', 'admin.php?page=yooadmin-settings');
                        } else {
                            alert(response.data && response.data.message ? response.data.message : 'Error');
                            $btn.prop('disabled', false).html(
                                '<span class="dashicons dashicons-visibility"></span> ' + (i18n.enableFocusButton || 'Enable Focus Mode')
                            );
                        }
                    },
                    error: function() {
                        alert('An error occurred. Please try again.');
                        $btn.prop('disabled', false).html(
                            '<span class="dashicons dashicons-visibility"></span> ' + (i18n.enableFocusButton || 'Enable Focus Mode')
                        );
                    }
                });
            });
            
            // Handle Escape key for settings modal
            $(document).on('keydown.enableFocusModal', function(e) {
                if (e.key === 'Escape' && $settingsModal.is(':visible')) {
                    $settingsModal.find('.yp-enable-focus-cancel').trigger('click');
                    $(document).off('keydown.enableFocusModal');
                }
            });
        }
    });
    
})(jQuery);

