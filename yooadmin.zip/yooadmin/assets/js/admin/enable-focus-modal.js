/**
 * YOOAdmin - Enable focus mode modal
 *
 * @package YOOAdmin
 */

(function ($) {
    'use strict';

    var TRANSITION_KEY = 'yooadminFocusTransition';

    function portalModalsToBody() {
        ['yoo-enable-focus-modal', 'yoo-why-focus-modal', 'yoo-focus-page-transition'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el && el.parentNode !== document.body) {
                document.body.appendChild(el);
            }
        });
    }

    function openModal($modal) {
        if (!$modal.length) {
            return;
        }
        portalModalsToBody();
        $('.yoo-focus-split-modal').not($modal).each(function () {
            closeModal($(this));
        });
        $modal.removeAttr('hidden').addClass('ywp-visible').attr('aria-hidden', 'false');
        $('body').addClass('yp-modal-open yoo-focus-modal-open');
    }

    function closeModal($modal) {
        if (!$modal.length) {
            return;
        }
        $modal.removeClass('ywp-visible').attr('aria-hidden', 'true').attr('hidden', 'hidden');
        if (!$('.yoo-focus-split-modal.ywp-visible').length) {
            $('body').removeClass('yp-modal-open yoo-focus-modal-open');
        }
    }

    function showBackgroundTransition() {
        portalModalsToBody();

        var overlay = document.getElementById('yoo-focus-page-transition');
        if (overlay) {
            overlay.removeAttribute('hidden');
            overlay.classList.add('is-visible');
            overlay.setAttribute('aria-hidden', 'false');
        }

        document.body.classList.add('yoo-focus-page-transitioning');
        document.body.classList.remove('yp-modal-open', 'yoo-focus-modal-open');
    }

    function beginFocusTransition($enableModal) {
        closeModal($enableModal);
        showBackgroundTransition();
    }

    /* Mark page visible after DOM ready (FOUC prevention; do not wait for full load). */
    function markEnableFocusLoaded() {
        if (document.body) {
            document.body.classList.add('yoo-loaded');
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', markEnableFocusLoaded, { once: true });
    } else {
        markEnableFocusLoaded();
    }

    $(document).ready(function () {
        portalModalsToBody();

        var $enableModal = $('#yoo-enable-focus-modal');
        var $whyModal = $('#yoo-why-focus-modal');
        var $enableForm = $('#yoo-enable-focus-form');
        var isTransitioning = document.body.classList.contains('yoo-focus-page-transitioning');

        /* Clear stale transition flag (e.g. after disabling focus or revisiting this page). */
        if (!isTransitioning) {
            try {
                sessionStorage.removeItem(TRANSITION_KEY);
            } catch (e) {
                /* ignore */
            }
        }

        $('#yoo-show-enable-modal').on('click', function () {
            if (isTransitioning) {
                return;
            }
            openModal($enableModal);
        });

        $enableModal.on('click', function (e) {
            if (e.target === this && !isTransitioning) {
                closeModal($enableModal);
            }
        });

        $enableModal.on('click', '.yoo-focus-modal-close, .yoo-focus-modal-dismiss', function (e) {
            e.preventDefault();
            if (isTransitioning) {
                return;
            }
            closeModal($enableModal);
        });

        var whyLink = document.getElementById('yoo-why-focus-link');
        if (whyLink && $whyModal.length) {
            whyLink.addEventListener('click', function (e) {
                e.preventDefault();
                if (isTransitioning) {
                    return;
                }
                openModal($whyModal);
            });

            $whyModal.on('click', function (e) {
                if (e.target === this) {
                    closeModal($whyModal);
                }
            });

            $whyModal.on('click', '.yoo-focus-modal-close, .yoo-focus-modal-dismiss', function (e) {
                e.preventDefault();
                closeModal($whyModal);
            });
        }

        $(document).on('keydown', function (e) {
            if (e.key !== 'Escape' || isTransitioning) {
                return;
            }
            if ($enableModal.hasClass('ywp-visible')) {
                closeModal($enableModal);
            }
            if ($whyModal.hasClass('ywp-visible')) {
                closeModal($whyModal);
            }
        });

        if ($enableForm.length) {
            $enableForm.on('submit', function () {
                isTransitioning = true;
                beginFocusTransition($enableModal);
            });
        }
    });
})(jQuery);
