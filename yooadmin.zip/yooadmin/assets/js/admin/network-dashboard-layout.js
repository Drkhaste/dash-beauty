(function ($) {
  'use strict';

  var cfg = window.yooadminNetworkDashboard || {};
  var root = document.querySelector('.yp-studio-hub--dashboard[data-layout-nonce]');
  if (!root) {
    return;
  }

  var layoutEl = root.querySelector('.yp-studio-hub__layout');
  var LAYOUT_VERSION = 1;
  var saveTimer = null;
  var editMode = false;
  var dragged = null;

  function readInitialLayout() {
    var attr = root.getAttribute('data-initial-layout');
    if (!attr) {
      return null;
    }
    try {
      var data = JSON.parse(attr);
      return data && data.version === LAYOUT_VERSION ? data : null;
    } catch (e) {
      return null;
    }
  }

  function sectionNodes(column) {
    if (!column) {
      return [];
    }
    return Array.prototype.slice.call(
      column.querySelectorAll(':scope > [data-layout-section="true"]')
    );
  }

  function currentLayout() {
    var layout = readInitialLayout() || {
      version: LAYOUT_VERSION,
      mainOrder: [],
      asideOrder: [],
      hiddenSections: [],
      hiddenSectionsExplicit: true
    };

    var mainCol = root.querySelector('[data-network-layout-column="main"]');
    var asideCol = root.querySelector('[data-network-layout-column="aside"]');

    layout.mainOrder = sectionNodes(mainCol).map(function (el) {
      return String(el.getAttribute('data-section-id') || '');
    }).filter(Boolean);

    layout.asideOrder = sectionNodes(asideCol).map(function (el) {
      return String(el.getAttribute('data-section-id') || '');
    }).filter(Boolean);

    layout.hiddenSections = [];
    root.querySelectorAll('[data-section-id][data-section-hidden="true"]').forEach(function (el) {
      layout.hiddenSections.push(String(el.getAttribute('data-section-id')));
    });

    layout.version = LAYOUT_VERSION;
    layout.hiddenSectionsExplicit = true;
    layout.savedAt = Date.now();
    return layout;
  }

  function syncDomLayout(layout) {
    if (!layout) {
      return;
    }
    try {
      root.setAttribute('data-initial-layout', JSON.stringify(layout));
    } catch (e) {
      /* ignore */
    }
  }

  function asideHasVisibleSections() {
    var asideCol = root.querySelector('[data-network-layout-column="aside"]');
    if (!asideCol) {
      return false;
    }
    return sectionNodes(asideCol).some(function (section) {
      return section.getAttribute('data-section-hidden') !== 'true';
    });
  }

  function refreshAsideCollapse() {
    if (!layoutEl) {
      return;
    }
    var collapse = !asideHasVisibleSections() && !editMode;
    layoutEl.classList.toggle('yp-studio-hub__layout--aside-empty', collapse);
    var asideCol = root.querySelector('[data-network-layout-column="aside"]');
    if (asideCol) {
      asideCol.classList.toggle('yp-studio-hub__aside--empty', collapse);
      if (collapse) {
        asideCol.setAttribute('aria-hidden', 'true');
      } else {
        asideCol.removeAttribute('aria-hidden');
      }
    }
  }

  function saveLayout() {
    if (!cfg.ajaxUrl || !cfg.nonce) {
      return;
    }
    var layout = currentLayout();
    $.post(cfg.ajaxUrl, {
      action: 'yooadmin_network_dashboard_save_layout',
      nonce: cfg.nonce,
      layout: JSON.stringify(layout)
    }).done(function (resp) {
      if (resp && resp.success && resp.data && resp.data.layout) {
        syncDomLayout(resp.data.layout);
      }
    }).fail(function () {
      /* Layout save failed; prior DOM state kept */
    });
  }

  function queueSave() {
    if (saveTimer) {
      clearTimeout(saveTimer);
    }
    saveTimer = setTimeout(saveLayout, 400);
  }

  function setEditMode(on) {
    editMode = !!on;
    document.body.classList.toggle('yp-layout-edit-mode', editMode);
    document.documentElement.classList.toggle('yp-layout-edit-mode', editMode);

    root.querySelectorAll('[data-layout-section="true"]').forEach(function (section) {
      section.setAttribute('draggable', editMode ? 'true' : 'false');
    });

    root.querySelectorAll('.yp-section-visibility-toggle').forEach(function (toggle) {
      toggle.hidden = !editMode;
    });

    root.querySelectorAll('[data-icon-edit-toggle="network-layout"]').forEach(function (btn) {
      btn.setAttribute('aria-pressed', editMode ? 'true' : 'false');
      btn.classList.toggle('is-active', editMode);
    });

    refreshAsideCollapse();

    if (!editMode) {
      queueSave();
    }
  }

  function readIconEditOn() {
    return (
      document.body.classList.contains('yp-icon-edit-mode') ||
      document.documentElement.classList.contains('yp-icon-edit-mode')
    );
  }

  function hydrateQuickActions() {
    root.querySelectorAll('[data-quick-actions-grid]').forEach(function (grid) {
      grid.classList.add('is-hydrated');
    });
    root.querySelectorAll('.yp-quick-actions-loading').forEach(function (el) {
      el.classList.add('is-hidden');
      el.setAttribute('aria-hidden', 'true');
    });
  }

  function clearDragMarkers() {
    root.querySelectorAll('.yp-layout-column--drag-over').forEach(function (el) {
      el.classList.remove('yp-layout-column--drag-over');
    });
    root.querySelectorAll('.is-section-dragging').forEach(function (el) {
      el.classList.remove('is-section-dragging');
    });
  }

  function moveSection(section, targetColumn, beforeNode) {
    if (!section || !targetColumn) {
      return;
    }
    if (beforeNode) {
      targetColumn.insertBefore(section, beforeNode);
    } else {
      targetColumn.appendChild(section);
    }
    refreshAsideCollapse();
  }

  function bindDragDrop() {
    root.querySelectorAll('[data-layout-section="true"]').forEach(function (section) {
      section.addEventListener('dragstart', function (e) {
        if (!editMode) {
          e.preventDefault();
          return;
        }
        dragged = section;
        section.classList.add('is-section-dragging');
        e.dataTransfer.effectAllowed = 'move';
      });

      section.addEventListener('dragend', function () {
        if (dragged) {
          dragged.classList.remove('is-section-dragging');
        }
        dragged = null;
        clearDragMarkers();
        queueSave();
      });
    });

    root.querySelectorAll('[data-network-layout-column]').forEach(function (column) {
      column.addEventListener('dragover', function (e) {
        if (!editMode || !dragged) {
          return;
        }
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        column.classList.add('yp-layout-column--drag-over');
      });

      column.addEventListener('dragleave', function () {
        column.classList.remove('yp-layout-column--drag-over');
      });

      column.addEventListener('drop', function (e) {
        if (!editMode || !dragged) {
          return;
        }
        e.preventDefault();
        column.classList.remove('yp-layout-column--drag-over');

        var target = e.target.closest('[data-layout-section="true"]');
        if (target && target.parentNode === column && target !== dragged) {
          moveSection(dragged, column, target);
        } else {
          moveSection(dragged, column, null);
        }
      });
    });
  }

  function bindVisibilityToggles() {
    root.querySelectorAll('[data-network-section-visibility]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (!editMode) {
          return;
        }
        var id = btn.getAttribute('data-network-section-visibility');
        var section = root.querySelector('[data-section-id="' + id + '"]');
        if (!section) {
          return;
        }
        var hidden = section.getAttribute('data-section-hidden') === 'true';
        if (hidden) {
          section.removeAttribute('data-section-hidden');
          section.classList.remove('is-dashboard-section-hidden');
          btn.classList.remove('is-active');
          btn.setAttribute('aria-pressed', 'false');
        } else {
          section.setAttribute('data-section-hidden', 'true');
          section.classList.add('is-dashboard-section-hidden');
          btn.classList.add('is-active');
          btn.setAttribute('aria-pressed', 'true');
        }
        refreshAsideCollapse();
        queueSave();
      });
    });
  }

  function bindEditToggle() {
    root.addEventListener(
      'click',
      function (e) {
        var btn = e.target.closest('[data-icon-edit-toggle="network-layout"]');
        if (!btn || !root.contains(btn)) {
          return;
        }
        window.requestAnimationFrame(function () {
          setEditMode(readIconEditOn());
        });
      },
      false
    );
  }

  function watchEditModeClass() {
    function syncFromDom() {
      var on = readIconEditOn();
      if (on !== editMode) {
        setEditMode(on);
      }
    }
    var obs = new MutationObserver(syncFromDom);
    if (document.body) {
      obs.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    }
    if (document.documentElement) {
      obs.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['class'],
      });
    }
  }

  function boot() {
    bindEditToggle();
    watchEditModeClass();
    bindDragDrop();
    bindVisibilityToggles();
    hydrateQuickActions();
    setEditMode(readIconEditOn());
    refreshAsideCollapse();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(jQuery);
