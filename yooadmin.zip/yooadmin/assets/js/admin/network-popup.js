/**
 * Network Admin shell — popup portal + Studio Hub re-mark after move.
 * Keeps shared yp-popup.js unchanged for single-site admin.
 */
(function () {
  'use strict';

  if (window.__YOONetworkPopupInit) {
    return;
  }
  window.__YOONetworkPopupInit = true;

  function isNetworkAdminShell() {
    if (!document.body) {
      return false;
    }
    return (
      document.body.classList.contains('yooadmin-network-admin-shell') ||
      document.body.classList.contains('yp-network-dashboard-screen')
    );
  }

  function byId(id) {
    return document.getElementById(id);
  }

  function markNetworkStudioPopup(popup) {
    if (!popup) {
      popup = byId('yp-popup');
    }
    if (popup) {
      popup.classList.add('yp-popup--studio-hub');
    }
  }

  function scheduleNetworkPopupEnhance() {
    if (typeof window.yshScheduleEnhancePopup === 'function') {
      window.yshScheduleEnhancePopup();
      return;
    }
    if (typeof window.yshMarkStudioPopup === 'function') {
      window.yshMarkStudioPopup();
    }
  }

  function ensureNetworkPopupPortaled() {
    var popup = byId('yp-popup');
    if (!popup) {
      return null;
    }
    if (popup.parentNode !== document.body) {
      document.body.appendChild(popup);
    }
    popup.classList.add('yp-popup--portaled');
    markNetworkStudioPopup(popup);
    return popup;
  }

  function initNetworkPopupObserver() {
    if (typeof MutationObserver === 'undefined') {
      return;
    }
    var wpbody = document.getElementById('wpbody-content');
    if (!wpbody || wpbody.__yooNetworkPopupMO) {
      return;
    }
    var mo = new MutationObserver(function () {
      ensureNetworkPopupPortaled();
    });
    mo.observe(wpbody, { childList: true, subtree: true });
    wpbody.__yooNetworkPopupMO = true;
  }

  function wrapYpShowPopup() {
    var orig = window.ypShowPopup;
    if (typeof orig !== 'function' || orig.__yooNetworkPopupWrapped) {
      return false;
    }
    window.ypShowPopup = function ypShowPopup(menuSlug, customTitle) {
      ensureNetworkPopupPortaled();
      var out = orig.apply(this, arguments);
      scheduleNetworkPopupEnhance();
      return out;
    };
    window.ypShowPopup.__yooNetworkPopupWrapped = true;
    return true;
  }

  function tryWrapYpShowPopup() {
    if (wrapYpShowPopup()) {
      return;
    }
    window.setTimeout(tryWrapYpShowPopup, 80);
  }

  function initNetworkPopup() {
    if (!isNetworkAdminShell()) {
      return;
    }
    ensureNetworkPopupPortaled();
    initNetworkPopupObserver();
    tryWrapYpShowPopup();
  }

  function bootNetworkPopup() {
    initNetworkPopup();
    if (!isNetworkAdminShell()) {
      return;
    }
    /* Body classes from admin_body_class can land after footer scripts start. */
    var tries = 0;
    var retry = window.setInterval(function () {
      if (isNetworkAdminShell()) {
        ensureNetworkPopupPortaled();
        tryWrapYpShowPopup();
      }
      tries += 1;
      if (tries >= 25) {
        window.clearInterval(retry);
      }
    }, 80);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootNetworkPopup);
  } else {
    bootNetworkPopup();
  }
})();
