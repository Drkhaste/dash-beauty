/**
 * YOOAdmin - Pages page script
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    function initListScreenUi(root) {
        if (window.yooadminUiSelect && typeof window.yooadminUiSelect.initIn === 'function') {
            window.yooadminUiSelect.initIn(root || document);
        }
    }

    function showNotice(type, message, duration) {
        if (window.yooadminShowToast && typeof window.yooadminShowToast === 'function') {
            window.yooadminShowToast(message, type, duration);
            return;
        }
        if (window.yooadminListScreenToast && typeof window.yooadminListScreenToast.show === 'function') {
            window.yooadminListScreenToast.show(type, message, duration);
            return;
        }
    }

    window.showNotice = showNotice;

    /**
     * Same modal pattern as posts-page.js (no native confirm()).
     */
    function showPageDeleteConfirmPopup(pageTitle, pageId, action) {
        var i18n = yooadmPages.i18n || {};
        var actionText = action === 'delete' ? (i18n.delete || 'Delete') : (action === 'trash' ? (i18n.moveToTrash || 'Move to Trash') : (i18n.restore || 'Restore'));
        var titleText = action === 'delete' ? (i18n.deletePageTitle || 'Delete Page?') : (action === 'trash' ? (i18n.moveToTrashTitle || 'Move to Trash?') : (i18n.restorePageTitle || 'Restore Page?'));
        var msgFmt = action === 'delete' ? (i18n.deleteConfirmMsg || 'Are you sure you want to delete %s? This action cannot be undone.')
            : (action === 'trash' ? (i18n.moveToTrashConfirmMsg || 'Are you sure you want to move %s to trash?') : (i18n.restoreConfirmMsg || 'Are you sure you want to restore %s?'));
        var messageText = msgFmt.replace(/%s/, '<strong>' + $('<div/>').text(pageTitle).html() + '</strong>');
        var cancelLabel = i18n.cancel || 'Cancel';

        var $popup = $(
            '<div class="yoo-delete-popup-overlay">' +
            '<div class="yoo-delete-popup">' +
            '<div class="yoo-delete-popup-icon">' +
            '<span class="dashicons dashicons-warning"></span>' +
            '</div>' +
            '<h3>' + $('<div/>').text(titleText).html() + '</h3>' +
            '<p>' + messageText + '</p>' +
            '<div class="yoo-delete-popup-actions">' +
            '<button type="button" class="yoo-popup-btn yoo-popup-cancel">' + $('<div/>').text(cancelLabel).html() + '</button>' +
            '<button type="button" class="yoo-popup-btn yoo-popup-delete">' + $('<div/>').text(actionText).html() + '</button>' +
            '</div>' +
            '</div>' +
            '</div>'
        );

        $('body').append($popup);
        setTimeout(function () {
            $popup.addClass('visible');
        }, 10);

        $popup.find('.yoo-popup-cancel').on('click', function () {
            $popup.removeClass('visible');
            setTimeout(function () {
                $popup.remove();
            }, 300);
        });

        $popup.find('.yoo-popup-delete').on('click', function () {
            var $deleteBtn = $(this);
            $deleteBtn.prop('disabled', true).text(action === 'delete' ? (i18n.deleting || 'Deleting...') : (action === 'trash' ? (i18n.moving || 'Moving...') : (i18n.restoring || 'Restoring...')));

            $.ajax({
                url: yooadmPages.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_pages_action',
                    page_action: action,
                    page_id: pageId,
                    nonce: yooadmPages.nonce
                },
                success: function (response) {
                    if (response.success) {
                        $popup.removeClass('visible');
                        setTimeout(function () {
                            $popup.remove();
                        }, 300);
                        var message = (response.data && response.data.message) ? response.data.message : '';
                        if (!message) {
                            if (action === 'delete') {
                                message = i18n.pageDeleted || 'Page permanently deleted.';
                            } else if (action === 'trash') {
                                message = i18n.pageMovedToTrash || 'Page moved to trash.';
                            } else {
                                message = i18n.pageRestored || 'Page restored.';
                            }
                        }
                        showNotice('success', message);
                        filterPages();
                    } else {
                        showNotice('error', (response.data && response.data.message) || (i18n.error || 'Error'));
                        $deleteBtn.prop('disabled', false).text(actionText);
                    }
                },
                error: function () {
                    showNotice('error', i18n.error || 'An error occurred. Please try again.');
                    $deleteBtn.prop('disabled', false).text(actionText);
                }
            });
        });

        $popup.on('click', function (e) {
            if ($(e.target).hasClass('yoo-delete-popup-overlay')) {
                $popup.removeClass('visible');
                setTimeout(function () {
                    $popup.remove();
                }, 300);
            }
        });
    }

    // ── Module-scope state ───────────────────────────────────────────────────
    var isLoading    = false;
    var currentPage  = 1;
    var hasMorePages = false;
    var currentView  = 'cards';

    // ── Helpers ──────────────────────────────────────────────────────────────

    function getFilters() {
        return {
            post_status: $('.yoo-filter-chip.is-active').data('status') || '',
            s:           $('#yoo-pages-search-input').val() || ''
        };
    }

    function ensurePagesListContainers($content) {
        if (!$content.find('.yoo-pages-grid').length) {
            $content.append('<div class="yoo-pages-grid yoo-view-cards"></div>');
        }

        if (!$content.find('.yoo-pages-table tbody').length) {
            if (!$content.find('.yoo-pages-table').length) {
                $content.append(
                    '<div class="yoo-pages-table yoo-view-table">' +
                    '<table class="wp-list-table widefat fixed striped table-view-list" style="width: 100%;">' +
                    '<thead><tr>' +
                    '<td class="manage-column column-cb check-column">' +
                    '<input type="checkbox" id="yoo-select-all-pages-table" class="yoo-checkbox">' +
                    '</td>' +
                    '<th scope="col" class="manage-column column-thumbnail"></th>' +
                    '<th scope="col" class="manage-column column-title column-primary sortable sort-desc" data-sort="title">' +
                    '<a href="#" class="yoo-sort-link"><span>Title</span><span class="sorting-indicator"></span></a></th>' +
                    '<th scope="col" class="manage-column column-author"></th>' +
                    '<th scope="col" class="manage-column column-parent"></th>' +
                    '<th scope="col" class="manage-column column-date sortable" data-sort="date">' +
                    '<a href="#" class="yoo-sort-link"><span>Date</span><span class="sorting-indicator"></span></a></th>' +
                    '<th scope="col" class="manage-column column-status"></th>' +
                    '</tr></thead><tbody></tbody></table></div>'
                );
            } else {
                $content.find('.yoo-pages-table table').append('<tbody></tbody>');
            }
        }
    }

    function updateBulkBar() {
        var selected = $('.yoo-page-checkbox').filter(':checked').length;
        var $bulkBar      = $('.yoo-bulk-actions-bar');
        var $selectedCount = $('.yoo-selected-count');
        var $bulkApply    = $('#yoo-bulk-apply');
        var $bulkSelect   = $('#yoo-bulk-action-select');

        if (selected > 0) {
            $bulkBar.addClass('show');
            $selectedCount.text(selected + ' ' + (yooadmPages.i18n.selected || 'selected'));
            $bulkApply.prop('disabled', !$bulkSelect.val());
        } else {
            $bulkBar.removeClass('show');
        }
    }

    // ── Filter / search (replaces content from page 1) ───────────────────────

    function filterPages() {
        if (isLoading) return;
        isLoading = true;

        var filters  = getFilters();
        var $content = $('#yoo-pages-content');
        $content.css('opacity', '0.6');

        $.ajax({
            url:  yooadmPages.ajaxUrl,
            type: 'POST',
            data: {
                action:      'yooadmin_filter_pages',
                nonce:       yooadmPages.nonce,
                paged:       1,
                post_status: filters.post_status,
                s:           filters.s
            },
            success: function(response) {
                $content.css('opacity', '');
                if (!response.success) { isLoading = false; return; }

                var data = response.data;

                if (data.total === 0) {
                    $content.find('.yoo-pages-empty').remove();
                    $content.prepend(data.empty_html);
                    $content.find('.yoo-pages-grid').empty();
                    $content.find('.yoo-pages-table tbody').empty();
                } else {
                    $content.find('.yoo-pages-empty').remove();
                    ensurePagesListContainers($content);
                    $content.find('.yoo-pages-grid').html(data.cards_html);
                    $content.find('.yoo-pages-table tbody').html(data.table_html);
                }

                currentPage  = 1;
                hasMorePages = data.has_more || false;
                $content.data('max-pages', data.total_pages);
                updateBulkBar();
                isLoading = false;
            },
            error: function() {
                $('#yoo-pages-content').css('opacity', '');
                isLoading = false;
            }
        });
    }

    // ── Load more (infinite scroll, appends next pages) ──────────────────────

    function loadMorePages() {
        if (isLoading || !hasMorePages) return;
        isLoading = true;
        currentPage++;

        var filters   = getFilters();
        var $spinner  = $('<div class="yoo-loading-more"><span class="spinner is-active"></span></div>');

        if (currentView === 'table') {
            $('.yoo-pages-table tbody').append($spinner);
        } else {
            $('.yoo-pages-grid').append($spinner);
        }

        $.ajax({
            url:  yooadmPages.ajaxUrl,
            type: 'POST',
            data: {
                action:      'yooadmin_load_more_pages',
                nonce:       yooadmPages.nonce,
                paged:       currentPage,
                view:        currentView,
                post_status: filters.post_status,
                s:           filters.s
            },
                success: function(response) {
                $('.yoo-loading-more').remove();
                if (response.success) {
                    if (currentView === 'table') {
                        $('.yoo-pages-table tbody').append(response.data.html);
                    } else {
                        $('.yoo-pages-grid').append(response.data.html);
                    }
                    hasMorePages = response.data.has_more;
                    updateBulkBar();
                    setTimeout(function tryFillViewport() {
                        if (isLoading || !hasMorePages) return;
                        if ($(document).height() <= $(window).height() + 400) {
                            loadMorePages();
                        }
                    }, 150);
                } else {
                    currentPage--;
                }
                isLoading = false;
            },
            error: function() {
                $('.yoo-loading-more').remove();
                currentPage--;
                isLoading = false;
            }
        });
    }

    // ── View Toggle ──────────────────────────────────────────────────────────

    function initViewToggle() {
        var storageKey = 'yooadmin_pages_view';
        var $cardsBtn  = $('.yoo-view-btn--cards');
        var $tableBtn  = $('.yoo-view-btn--table');
        var $content   = $('#yoo-pages-content');

        var savedView = localStorage.getItem(storageKey) || 'cards';
        currentView = savedView;

        if (savedView === 'table') {
            $content.removeClass('yoo-view-cards').addClass('yoo-view-table');
            $cardsBtn.removeClass('is-active');
            $tableBtn.addClass('is-active');
        } else {
            $content.removeClass('yoo-view-table').addClass('yoo-view-cards');
            $cardsBtn.addClass('is-active');
            $tableBtn.removeClass('is-active');
        }

        $cardsBtn.on('click', function() {
            currentView = 'cards';
            $content.removeClass('yoo-view-table').addClass('yoo-view-cards');
            $cardsBtn.addClass('is-active');
            $tableBtn.removeClass('is-active');
            localStorage.setItem(storageKey, 'cards');
        });

        $tableBtn.on('click', function() {
            currentView = 'table';
            $content.removeClass('yoo-view-cards').addClass('yoo-view-table');
            $tableBtn.addClass('is-active');
            $cardsBtn.removeClass('is-active');
            localStorage.setItem(storageKey, 'table');
        });
    }

    // ── Table Sorting ────────────────────────────────────────────────────────

    function initTableSorting() {
        var currentSort = { column: 'title', order: 'desc' };

        $(document).on('click', '.yoo-pages-table .sortable', function(e) {
            e.preventDefault();
            var $th    = $(this);
            var column = $th.data('sort');
            var $tbody = $('.yoo-pages-table table tbody');
            var $rows  = $tbody.find('tr').toArray();

            if (currentSort.column === column) {
                currentSort.order = currentSort.order === 'asc' ? 'desc' : 'asc';
            } else {
                currentSort.column = column;
                currentSort.order  = 'desc';
            }

            $('.sortable').removeClass('sort-asc sort-desc');
            $th.addClass('sort-' + currentSort.order);

            $rows.sort(function(a, b) {
                var aVal, bVal;
                if (column === 'title') {
                    aVal = $(a).data('title') || '';
                    bVal = $(b).data('title') || '';
                } else if (column === 'date') {
                    aVal = parseInt($(a).data('date')) || 0;
                    bVal = parseInt($(b).data('date')) || 0;
                }
                if (currentSort.order === 'asc') {
                    return aVal > bVal ? 1 : (aVal < bVal ? -1 : 0);
                } else {
                    return aVal < bVal ? 1 : (aVal > bVal ? -1 : 0);
                }
            });

            $.each($rows, function(i, row) { $tbody.append(row); });
        });
    }

    // ── Image Lightbox ───────────────────────────────────────────────────────

    function initImageLightbox() {
        var $lightbox = $('#yoo-image-lightbox');
        var $overlay  = $('.yoo-lightbox-overlay');
        var $close    = $('.yoo-lightbox-close');
        var $image    = $('.yoo-lightbox-image');
        var $title    = $('.yoo-lightbox-title');

        $(document).on('click', '.yoo-image-lightbox-trigger', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $image.attr('src', $(this).data('image-url')).attr('alt', $(this).data('image-title') || '');
            $title.text($(this).data('image-title') || '');
            $lightbox.fadeIn(200);
            $('body').css('overflow', 'hidden');
        });

        function closeLightbox() {
            $lightbox.fadeOut(200);
            $('body').css('overflow', '');
        }

        $close.on('click', closeLightbox);
        $overlay.on('click', closeLightbox);
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $lightbox.is(':visible')) { closeLightbox(); }
        });
    }

    // ── Infinite Scroll ──────────────────────────────────────────────────────

    function initInfiniteScroll() {
        var $content = $('#yoo-pages-content');

        // Initialize from data attribute rendered by PHP (not DOM pagination)
        hasMorePages = parseInt($content.data('max-pages') || 1) > 1;
        currentPage  = 1;

        var scrollTimeout;
        $(window).on('scroll', function() {
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(function() {
                if (isLoading || !hasMorePages) return;
                var scrollTop      = $(window).scrollTop();
                var windowHeight   = $(window).height();
                var documentHeight = $(document).height();
                if (scrollTop + windowHeight > documentHeight - 300) {
                    loadMorePages();
                }
            }, 100);
        });

        $(window).on('load', function() {
            setTimeout(function() {
                if (isLoading || !hasMorePages) return;
                if ($(document).height() <= $(window).height() + 400) {
                    loadMorePages();
                }
            }, 400);
        });
    }

    // ── Metrics Toggle ───────────────────────────────────────────────────────

    function initMetricsToggle() {
        var $toggle    = $('.yoo-pages-metrics-toggle');
        var $metrics   = $('.yoo-pages-hero__metrics');
        var storageKey = 'yooadmin_pages_metrics_expanded';
        var isExpanded = localStorage.getItem(storageKey) === 'true';

        if (isExpanded) {
            $metrics.addClass('is-visible');
            $toggle.addClass('is-expanded').attr('aria-expanded', 'true');
            $toggle.find('span:last-child').text(yooadmPages.i18n.hideStatistics || 'Hide Statistics');
        } else {
            $metrics.removeClass('is-visible');
            $toggle.removeClass('is-expanded').attr('aria-expanded', 'false');
            $toggle.find('span:last-child').text(yooadmPages.i18n.showStatistics || 'Show Statistics');
        }

        $toggle.on('click', function() {
            var expanded = $metrics.hasClass('is-visible');
            if (expanded) {
                $metrics.removeClass('is-visible');
                $toggle.removeClass('is-expanded').attr('aria-expanded', 'false');
                $toggle.find('span:last-child').text(yooadmPages.i18n.showStatistics || 'Show Statistics');
                localStorage.setItem(storageKey, 'false');
            } else {
                $metrics.addClass('is-visible');
                $toggle.addClass('is-expanded').attr('aria-expanded', 'true');
                $toggle.find('span:last-child').text(yooadmPages.i18n.hideStatistics || 'Hide Statistics');
                localStorage.setItem(storageKey, 'true');
            }
        });
    }

    // ── Document Ready ───────────────────────────────────────────────────────

    $(document).ready(function() {
        initViewToggle();
        initTableSorting();
        initImageLightbox();
        initInfiniteScroll();
        initMetricsToggle();
        initListScreenUi(document.querySelector('.yooadmin-pages-page'));

        // ── Search (debounced) ────────────────────────────────────────────
        var searchTimeout;
        $('#yoo-pages-search-input').on('keyup', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(filterPages, 400);
        });

        // ── Filter chips ──────────────────────────────────────────────────
        $(document).on('click', '.yoo-filter-chip', function(e) {
            e.preventDefault();
            $('.yoo-filter-chip').removeClass('is-active');
            $(this).addClass('is-active');
            filterPages();
        });

        // ── Bulk actions ──────────────────────────────────────────────────
        var $selectAll  = $('#yoo-select-all-pages');
        var $bulkApply  = $('#yoo-bulk-apply');
        var $bulkSelect = $('#yoo-bulk-action-select');

        $(document).on('change', '.yoo-page-checkbox', updateBulkBar);

        $selectAll.on('change', function() {
            $('.yoo-page-checkbox').prop('checked', $(this).prop('checked'));
            updateBulkBar();
        });

        $('#yoo-select-all-pages-table').on('change', function() {
            $('.yoo-pages-table .yoo-page-checkbox').prop('checked', $(this).prop('checked'));
            updateBulkBar();
        });

        $bulkSelect.on('change', function() {
            $bulkApply.prop('disabled', !$(this).val());
        });

        $bulkApply.on('click', function() {
            var action   = $bulkSelect.val();
            if (!action) return;
            var selected = $('.yoo-page-checkbox').filter(':checked').map(function() {
                return $(this).val();
            }).get();
            if (!selected.length) return;

            $.ajax({
                url:  yooadmPages.ajaxUrl,
                type: 'POST',
                data: { action: 'yooadmin_bulk_pages_action', bulk_action: action, pages: selected, nonce: yooadmPages.nonce },
                success: function(response) {
                    if (response.success) {
                        showNotice('success', (response.data && response.data.message) || (yooadmPages.i18n.success || 'Operation completed successfully.'));
                        $('.yoo-page-checkbox').prop('checked', false);
                        $('#yoo-select-all-pages, #yoo-select-all-pages-table').prop('checked', false);
                        updateBulkBar();
                        filterPages();
                    } else {
                        showNotice('error', (response.data && response.data.message) || (yooadmPages.i18n.error || 'Error occurred'));
                    }
                },
                error: function () {
                    showNotice('error', yooadmPages.i18n.error || 'An error occurred. Please try again.');
                }
            });
        });

        // ── Individual page actions (delegated for dynamically loaded items) ─
        $(document).on('click', '.yoo-action-btn.trash, .yoo-action-btn.delete, .yoo-action-btn.restore', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var pageId = $btn.data('page-id');
            var action = $btn.hasClass('trash') ? 'trash' : ($btn.hasClass('restore') ? 'restore' : 'delete');
            var pageTitle = $btn.closest('.yoo-page-card').find('.yoo-page-title a').text() || (yooadmPages.i18n.thisPage || 'this page');
            showPageDeleteConfirmPopup(pageTitle, pageId, action);
        });

        $(document).on('click', '.yoo-action-link.trash, .yoo-action-link.delete, .yoo-action-link.restore', function(e) {
            e.preventDefault();
            var $link = $(this);
            var pageId = $link.data('page-id');
            var action = $link.hasClass('trash') ? 'trash' : ($link.hasClass('restore') ? 'restore' : 'delete');
            var pageTitle = $link.closest('tr').find('.row-title').text() || (yooadmPages.i18n.thisPage || 'this page');
            showPageDeleteConfirmPopup(pageTitle, pageId, action);
        });

        function runPageStatusAjax(pageId, action, onDone) {
            var defMsg = action === 'draft'
                ? (yooadmPages.i18n.pageMovedToDraft || 'Page moved to draft.')
                : (yooadmPages.i18n.pagePublished || 'Page published.');
            $.ajax({
                url: yooadmPages.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_pages_action',
                    page_action: action,
                    page_id: pageId,
                    nonce: yooadmPages.nonce
                },
                success: function (response) {
                    if (typeof onDone === 'function') {
                        onDone();
                    }
                    if (response.success) {
                        showNotice('success', (response.data && response.data.message) || defMsg);
                        filterPages();
                    } else {
                        showNotice('error', (response.data && response.data.message) || 'Error occurred');
                    }
                },
                error: function () {
                    if (typeof onDone === 'function') {
                        onDone();
                    }
                    showNotice('error', yooadmPages.i18n.error || 'An error occurred. Please try again.');
                }
            });
        }

        $(document).on('click', '.yoo-action-btn.to-draft, .yoo-action-btn.to-publish', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var pageId = $btn.data('page-id');
            var action = $btn.hasClass('to-draft') ? 'draft' : 'publish';
            $btn.prop('disabled', true);
            runPageStatusAjax(pageId, action, function () {
                $btn.prop('disabled', false);
            });
        });

        $(document).on('click', '.yoo-action-link.to-draft, .yoo-action-link.to-publish', function (e) {
            e.preventDefault();
            var $link = $(this);
            if ($link.data('processing')) {
                return;
            }
            var pageId = $link.data('page-id');
            var action = $link.hasClass('to-draft') ? 'draft' : 'publish';
            $link.data('processing', 1).css('pointer-events', 'none').css('opacity', '0.55');
            runPageStatusAjax(pageId, action, function () {
                $link.removeData('processing').css('pointer-events', '').css('opacity', '');
            });
        });
    });

})(jQuery);
