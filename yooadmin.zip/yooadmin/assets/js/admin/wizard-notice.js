/**
 * YOOAdmin - Wizard notice dismiss handler
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        var config = window.yooadmWizardNotice || {};
        var dismissData = {
            action: 'yooadmin_dismiss_wizard_notice',
            _ajax_nonce: config.nonce
        };

        $('.yooadmin-dismiss-wizard-notice').on('click', function(e) {
            e.preventDefault();
            $.post(window.ajaxurl, dismissData);
            $('.yooadmin-wizard-notice').fadeOut();
        });

        $('.yooadmin-wizard-notice').on('click', '.notice-dismiss', function() {
            $.post(window.ajaxurl, dismissData);
        });
    });
})(jQuery);
