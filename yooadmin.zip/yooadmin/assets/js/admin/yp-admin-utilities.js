/**
 * YOOAdmin - Admin utilities and helpers
 *
 * @package YOOAdmin
 */

(function () {
  'use strict';
  
  if (window.__YPAdminUtilsInit) return;
  window.__YPAdminUtilsInit = true;

  function ypClassText(node) {
    var cn = node && node.className;
    if (!cn) {
      return '';
    }
    if (typeof cn === 'string') {
      return cn;
    }
    if (typeof cn.baseVal === 'string') {
      return cn.baseVal;
    }
    return String(cn);
  }

  function ypIsInsideReactRoot(el) {
    var node = el;
    while (node && node !== document.body) {
      try {
        var keys = Object.keys(node);
        for (var k = 0; k < keys.length; k++) {
          if (keys[k].lastIndexOf('__react', 0) === 0) return true;
        }
      } catch (e) {}
      node = node.parentElement;
    }
    return false;
  }

  // ---------------- Admin Panel Utilities ----------------
  window.yooadmAdminUtils = {
    
    // Panel management
    panel: {
      toggle: function(panelId) {
        var panel = document.getElementById(panelId);
        if (panel) {
          panel.classList.toggle('active');
        }
      },
      
      show: function(panelId) {
        var panel = document.getElementById(panelId);
        if (panel) {
          panel.classList.add('active');
        }
      },
      
      hide: function(panelId) {
        var panel = document.getElementById(panelId);
        if (panel) {
          panel.classList.remove('active');
        }
      }
    },
    
    // Settings helpers
    settings: {
      save: function(key, value) {
        var base = (window.yooadmUtilities && window.yooadmUtilities.settingsUrl) ? window.yooadmUtilities.settingsUrl : '';
        if (!base && typeof wpApiSettings !== 'undefined' && wpApiSettings.root) {
          base = String(wpApiSettings.root).replace(/\/?$/, '/') + 'yooadmin/v1/settings';
        }
        var nonce = (typeof wpApiSettings !== 'undefined' && wpApiSettings.nonce) ? wpApiSettings.nonce : '';
        if (base && nonce) {
          fetch(base, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': nonce
            },
            body: JSON.stringify({ key: key, value: value })
          })
          .then(function(response) { return response.json(); })
          .then(function(data) {
          })
          .catch(function(error) {
          });
        } else {
          localStorage.setItem('yooadmin_' + key, value);
        }
      },
      
      get: function(key, callback) {
        var base = (window.yooadmUtilities && window.yooadmUtilities.settingsUrl) ? window.yooadmUtilities.settingsUrl : '';
        if (!base && typeof wpApiSettings !== 'undefined' && wpApiSettings.root) {
          base = String(wpApiSettings.root).replace(/\/?$/, '/') + 'yooadmin/v1/settings';
        }
        var nonce = (typeof wpApiSettings !== 'undefined' && wpApiSettings.nonce) ? wpApiSettings.nonce : '';
        if (base && nonce) {
          fetch(base + '/' + encodeURIComponent(key), {
            headers: {
              'X-WP-Nonce': nonce
            }
          })
          .then(function(response) { return response.json(); })
          .then(function(data) { 
            if (callback) callback(data.value);
            return data.value;
          })
          .catch(function(error) {
            if (callback) callback('');
          });
        } else {
          var value = localStorage.getItem('yooadmin_' + key);
          if (callback) callback(value || '');
          return value || '';
        }
      }
    },
    
    // Theme integration
    theme: {
      updateColor: function(variable, value) {
        document.documentElement.style.setProperty(variable, value);
        // Also save to settings
        this.settings.save(variable.replace('--', ''), value);
      },
      
      getColor: function(variable) {
        return getComputedStyle(document.documentElement).getPropertyValue(variable);
      },
      
      applyTheme: function(themeColors) {
        var self = this;
        Object.keys(themeColors).forEach(function(key) {
          var variable = '--' + key;
          self.updateColor(variable, themeColors[key]);
        });
      }
    },
    
    // Banner management utilities
    banner: {
      moveBannersOutsideWrap: function() {
        function resetBannerStyling(banner) {
          // Remove all YOOAdmin added classes
          banner.classList.remove('yp-banner-moved', 'yp-banner-tooltip-added');
          
          // Remove any inline styles
          if (banner.getAttribute('style')) {
            banner.removeAttribute('style');
          }
          
          // Reset all styles to original
          var originalStyles = {
            display: '', position: '', width: '', 'max-width': '', margin: '', padding: '',
            background: '', border: '', 'box-shadow': '', 'font-size': '', 'line-height': '',
            'text-align': '', 'flex-direction': '', 'align-items': '', 'justify-content': '',
            height: '', 'min-height': '', 'overflow': '', 'white-space': '', 'word-wrap': '', 'z-index': ''
          };
          
          Object.keys(originalStyles).forEach(function(prop) {
            banner.style[prop] = originalStyles[prop];
          });
        }
        
        function moveBanners() {
          // Find ONLY REAL banners inside wrap containers - be more specific
          var banners = document.querySelectorAll('.wrap .notice, .wrap .update-nag, .wrap .updated, .wrap .error, .wrap [class*="-admin-notice"], .wrap .codevz-admin-notice, .wrap [id*="wpb-notice"]');
          
          // Filter to move ONLY actual banners, not content
          var realBanners = Array.from(banners).filter(function(banner) {
            if (
              banner.closest &&
              banner.closest('[data-yp-banner-ignore], [data-yp-internal-notice], .yp-alert, .yp-notifications-dropdown')
            ) {
              return false;
            }

            if (ypIsInsideReactRoot(banner)) {
              return false;
            }

            // Check if it's a real banner (has typical banner characteristics)
            var hasBannerClass = banner.classList.contains('notice') || 
                                  banner.classList.contains('update-nag') || 
                                  banner.classList.contains('updated') || 
                                  banner.classList.contains('error') ||
                                  banner.id.startsWith('wpb-notice') ||
                                  banner.className.includes('-admin-notice');
            
            // Check if it has banner-like content (not just random content)
            var text = banner.textContent || '';
            var hasBannerContent = text.length > 10 && (
              text.includes('notice') || 
              text.includes('warning') || 
              text.includes('error') || 
              text.includes('success') || 
              text.includes('update') ||
              text.includes('important') ||
              banner.querySelector('.notice-dismiss') ||
              banner.querySelector('[class*="dismiss"]') ||
              banner.querySelector('button')
            );
            
            // Skip if already moved or if it's a YOOAdmin special banner
            var isSpecial = banner.classList.contains('yp-banner-moved') || 
                           banner.classList.contains('yp-banner-tooltip-added') ||
                           banner.classList.contains('yp-license-activation-notice') ||
                           banner.classList.contains('yp-notification-item');
            
            // Skip specific inline/alternative notice types
            var isInlineOrAlt = banner.classList.contains('notice-alt') ||
                               banner.classList.contains('inline') ||
                               (banner.classList.contains('update-message') && banner.classList.contains('notice'));
            
            // Move only if it's a real banner with banner content and not excluded
            return hasBannerClass && (hasBannerContent || banner.id.startsWith('wpb-notice')) && !isSpecial && !isInlineOrAlt;
          });
          
          // Find the correct parent - wpbody-content or yoo-shell-content
          var targetParent = document.querySelector('#wpbody-content') || document.querySelector('.yoo-shell-content');
          
          if (!targetParent || realBanners.length === 0) return;
          
          // Find the first wrap to position before
          var firstWrap = document.querySelector('.wrap');
          
          // Collect all moved banners to maintain order
          var movedBanners = [];
          
          realBanners.forEach(function(banner) {
            // Mark as moved
            banner.classList.add('yp-banner-moved');
            
            // Reset styling immediately
            resetBannerStyling(banner);
            
            movedBanners.push(banner);
          });
          
          // Insert all banners in correct order
          movedBanners.forEach(function(banner, index) {
            if (firstWrap && firstWrap.parentNode === targetParent) {
              // Insert before the first wrap, maintaining order
              if (index === 0) {
                targetParent.insertBefore(banner, firstWrap);
              } else {
                // Insert after the previous banner
                var previousBanner = movedBanners[index - 1];
                targetParent.insertBefore(banner, previousBanner.nextSibling);
              }
            } else {
              // Insert at the beginning of target parent
              if (index === 0) {
                targetParent.insertBefore(banner, targetParent.firstChild);
              } else {
                // Insert after the previous banner
                var previousBanner = movedBanners[index - 1];
                targetParent.insertBefore(banner, previousBanner.nextSibling);
              }
            }
          });
        }
        
        // Run immediately to prevent jumping
        moveBanners();
        
        // Also run on DOM ready for any late-loading banners
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', moveBanners);
        }
        
        // Use MutationObserver like old system
        var observer = new MutationObserver(function(mutations) {
          var shouldRun = false;
          mutations.forEach(function(mutation) {
            if (mutation.type === 'childList') {
              mutation.addedNodes.forEach(function(node) {
                if (node.nodeType === 1 && !ypIsInsideReactRoot(node)) {
                  if (node.classList && (node.classList.contains('notice') || node.classList.contains('update-nag') || node.classList.contains('updated') || node.classList.contains('error') || ypClassText(node).indexOf('-admin-notice') !== -1)) {
                    shouldRun = true;
                  }
                  if (node.classList && node.classList.contains('wrap')) {
                    var banners = node.querySelectorAll('.notice, .update-nag, .updated, .error, [class*="-admin-notice"]');
                    if (banners.length > 0) shouldRun = true;
                  }
                }
              });
            }
          });
          
          if (shouldRun) moveBanners();
        });
        
        var wpbodyContent = document.querySelector('#wpbody-content');
        if (wpbodyContent) {
          observer.observe(wpbodyContent, {
            childList: true,
            subtree: true
          });
        }
        
        // Run periodically for safety (like old system)
        setInterval(moveBanners, 1000);
        
        // Global functions for manual control (like old system)
        window.moveYooBanners = moveBanners;
        window.resetAllBanners = function() {
          document.querySelectorAll('.notice, .update-nag, .updated, .error, [class*="-admin-notice"], .codevz-admin-notice').forEach(function(banner) {
            resetBannerStyling(banner);
          });
        };
      },
      
      /**
       * Convert admin banners to notifications (100% accurate via database)
       * JavaScript detects banners and sends them to PHP to save in database
       */
      convertBannersToNotifications: function() {
        var self = this;
        var processedBanners = new Set(); // Track processed banners in current session
        var STORAGE_KEY = 'yooadmin_processed_banners'; // localStorage key for persistent tracking
        
        // Check if user wants to clear processed banners (via URL parameter)
        var shouldClearStorage = (window.location.search && window.location.search.indexOf('clear_banner_storage=1') !== -1) ||
                                 localStorage.getItem('yooadmin_clear_banner_storage') === '1';
        
        if (shouldClearStorage) {
          try {
            localStorage.removeItem(STORAGE_KEY);
            localStorage.removeItem('yooadmin_force_reprocess_banners');
            localStorage.removeItem('yooadmin_clear_banner_storage');
          } catch (e) {
          }
        }
        
        // Load previously processed banners from localStorage
        function loadProcessedBanners() {
          try {
            var stored = localStorage.getItem(STORAGE_KEY);
            if (stored) {
              var storedBanners = JSON.parse(stored);
              storedBanners.forEach(function(bannerId) {
                processedBanners.add(bannerId);
              });
            }
          } catch (e) {
          }
        }
        
        // Save processed banner to localStorage
        function saveProcessedBanner(bannerId) {
          try {
            var stored = localStorage.getItem(STORAGE_KEY);
            var storedBanners = stored ? JSON.parse(stored) : [];
            if (storedBanners.indexOf(bannerId) === -1) {
              storedBanners.push(bannerId);
              // Keep only last 1000 banners to prevent localStorage from growing too large
              if (storedBanners.length > 1000) {
                storedBanners = storedBanners.slice(-1000);
              }
              localStorage.setItem(STORAGE_KEY, JSON.stringify(storedBanners));
            }
          } catch (e) {
          }
        }
        
        function getReadableBannerClone(banner) {
          var clone = banner.cloneNode(true);
          clone.querySelectorAll('style, script, noscript, template, svg').forEach(function(node) {
            node.remove();
          });
          clone.querySelectorAll('.notice-dismiss, [class*="dismiss"]').forEach(function(node) {
            node.remove();
          });
          return clone;
        }

        function getReadableBannerText(banner) {
          var clone = getReadableBannerClone(banner);
          return (clone.textContent || clone.innerText || '').replace(/\s+/g, ' ').trim();
        }

        function humanizeBannerSlug(slug) {
          var knownNames = {
            abovewp: 'AboveWP',
            aioseo: 'AIOSEO',
            codevz: 'Codevz',
            elementor: 'Elementor',
            gutenkit: 'Gutenkit',
            malcare: 'MalCare',
            rank: 'Rank Math',
            woocommerce: 'WooCommerce',
            wpb: 'WPBakery Page Builder',
            vc: 'WPBakery Page Builder',
            xtra: 'XTRA Theme'
          };
          slug = String(slug || '').toLowerCase().replace(/_/g, '-');
          var firstPart = slug.split('-')[0];
          if (knownNames[slug]) {
            return knownNames[slug];
          }
          if (knownNames[firstPart]) {
            return knownNames[firstPart];
          }
          return slug
            .split('-')
            .filter(function(part) {
              return part && ['admin', 'banner', 'content', 'notice', 'notification', 'promo', 'wrapper'].indexOf(part) === -1;
            })
            .map(function(part) {
              return part.charAt(0).toUpperCase() + part.slice(1);
            })
            .join(' ');
        }

        function extractBannerComponentName(banner, classes, textContent) {
          var id = banner.id || '';
          var haystack = [id, classes].join(' ');
          var match;

          if (/\b(?:vc|wpb|js_composer)\b/i.test(haystack)) {
            return 'WPBakery Page Builder';
          }
          if (/\belementor\b/i.test(haystack)) {
            return 'Elementor';
          }
          if (/\bwoocommerce\b/i.test(haystack)) {
            return 'WooCommerce';
          }
          if (/\bxtra\b/i.test(haystack)) {
            return 'XTRA Theme';
          }

          match = haystack.match(/\b([a-z0-9][a-z0-9_-]+?)-(?:promo-)?(?:admin-)?notice\b/i);
          if (!match) {
            match = haystack.match(/\b([a-z0-9][a-z0-9_-]+?)-(?:promo|banner|message|alert)\b/i);
          }
          if (!match) {
            match = haystack.match(/\b(?:plugin|theme)-([a-z0-9][a-z0-9_-]+)\b/i);
          }
          if (match && match[1]) {
            return humanizeBannerSlug(match[1]);
          }

          match = String(textContent || '').match(/\b(?:installing|installed|for)\s+([A-Z][A-Za-z0-9\s]+?)\s+(?:theme|plugin)\b/i);
          if (match && match[1]) {
            return match[1].trim().substring(0, 50);
          }

          return '';
        }

        // Generate a stable banner ID based on content hash
        function generateStableBannerId(banner) {
          // If banner has an ID, use it
          if (banner.id) {
            return banner.id;
          }
          
          // Generate ID based on content hash for stability
          var textContent = getReadableBannerText(banner);
          var classes = banner.className || '';
          var hash = textContent.substring(0, 100) + classes;
          
          // Simple hash function
          var hashValue = 0;
          for (var i = 0; i < hash.length; i++) {
            var char = hash.charCodeAt(i);
            hashValue = ((hashValue << 5) - hashValue) + char;
            hashValue = hashValue & hashValue; // Convert to 32bit integer
          }
          
          return 'banner_' + Math.abs(hashValue).toString(36);
        }
        
        // Load processed banners on initialization
        loadProcessedBanners();
        
        function extractBannerData(banner) {
          var bannerId = generateStableBannerId(banner);
          var classes = banner.className || '';
          var readableBanner = getReadableBannerClone(banner);
          var textContent = getReadableBannerText(banner);
          var htmlContent = banner.outerHTML || '';
          var componentName = extractBannerComponentName(banner, classes, textContent);
          
          // Determine banner type
          var bannerType = 'notice';
          if (classes.indexOf('error') !== -1 || classes.indexOf('notice-error') !== -1) {
            bannerType = 'error';
          } else if (classes.indexOf('updated') !== -1 || classes.indexOf('notice-success') !== -1) {
            bannerType = 'success';
          } else if (classes.indexOf('notice-warning') !== -1) {
            bannerType = 'warning';
          } else if (classes.indexOf('update-nag') !== -1) {
            bannerType = 'update';
          }
          
          // Extract title (first strong tag or first meaningful text)
          var title = '';
          var strongEl = readableBanner.querySelector('strong');
          if (strongEl) {
            title = (strongEl.textContent || strongEl.innerText || '').trim();
          }
          
          // If no title from strong tag, try to find first meaningful text
          if (!title) {
            // Try to get text from first paragraph or div
            var firstPara = readableBanner.querySelector('p');
            if (firstPara) {
              title = (firstPara.textContent || firstPara.innerText || '').trim();
            }
            
            // If still no title, use first non-empty line from textContent
            if (!title) {
              var lines = textContent.split(/\n|\r/);
              for (var i = 0; i < lines.length; i++) {
                var line = lines[i].trim();
                if (line && line.length > 5) { // Skip very short lines
                  title = line;
                  break;
                }
              }
            }
            
            // Fallback: use first 100 characters of textContent
            if (!title) {
              title = textContent.trim();
            }
            
            // Clean up title: remove extra whitespace and limit length
            title = title.replace(/\s+/g, ' ').trim();
            if (title.length > 100) {
              title = title.substring(0, 100).trim() + '...';
            }
          }
          
          // Final fallback
          if (!title || title.length < 3) {
            title = 'Admin Notice';
          }
          
          // Extract message (all text except title)
          var message = textContent.trim();
          if (title && message.indexOf(title) === 0) {
            message = message.substring(title.length).trim();
          }
          if (message.length > 500) {
            message = message.substring(0, 500) + '...';
          }
          if (!message) {
            message = textContent.trim().substring(0, 500);
          }
          
          // Extract ALL URLs from links with their text labels
          var urls = [];
          var linkElements = banner.querySelectorAll('a[href]');
          linkElements.forEach(function(linkEl) {
            var href = linkEl.getAttribute('href') || '';
            if (href && href !== '#' && href !== 'javascript:void(0)') {
              // Get link text (use textContent, fallback to innerText, fallback to href)
              var linkText = (linkEl.textContent || linkEl.innerText || '').trim();
              if (!linkText || linkText.length < 1) {
                linkText = href; // Use URL as text if no text found
              }
              // Clean up link text (remove extra spaces, limit length)
              linkText = linkText.replace(/\s+/g, ' ').trim();
              if (linkText.length > 50) {
                linkText = linkText.substring(0, 50).trim() + '...';
              }
              
              // Check if URL already exists (prevent duplicates)
              var urlExists = urls.some(function(u) {
                return u.url === href;
              });
              
              if (!urlExists) {
                urls.push({
                  url: href,
                  text: linkText || 'View'
                });
              }
            }
          });
          
          // Get first URL for backward compatibility
          var url = urls.length > 0 ? urls[0].url : '';
          
          // Get current page
          var page = '';
          if (window.location && window.location.pathname) {
            page = window.location.pathname;
          }
          
          var bannerData = {
            banner_id: bannerId,
            title: title || 'Admin Notice',
            message: message || 'Please check this notification.',
            type: bannerType,
            url: url, // First URL for backward compatibility
            urls: urls, // All URLs with their text labels
            html: htmlContent.substring(0, 1000), // Limit HTML size
            page: page,
            classes: classes,
            component_name: componentName,
            source: componentName || ''
          };
          
          return bannerData;
        }
        
        function refreshNotificationInbox() {
          if (
            window.yooadmNotificationsUi &&
            typeof window.yooadmNotificationsUi.loadNotifications === 'function'
          ) {
            window.yooadmNotificationsUi.loadNotifications(true);
            return;
          }
          if (
            window.yooadmNotifications &&
            typeof window.yooadmNotifications.loadNotifications === 'function'
          ) {
            window.yooadmNotifications.loadNotifications(true);
          }
        }

        function sendBannerToServer(bannerData) {
          // Check if we have REST API endpoint
          if (!window.yooadmRuntime || !window.yooadmRuntime.notifications || !window.yooadmRuntime.notifications.restEndpoint) {
            return;
          }
          
          var restUrl =
            window.yooadmRuntime.notifications.bannerSaveUrl || '';
          if (!restUrl) {
            var restBase = window.yooadmRuntime.notifications.restEndpoint || '';
            if (restBase.indexOf('?') !== -1) {
              restBase = restBase.substring(0, restBase.indexOf('?'));
            }
            if (restBase.endsWith('/')) {
              restBase = restBase.slice(0, -1);
            }
            restUrl = restBase + '/banner';
          }
          var nonce = window.yooadmRuntime.notifications.restNonce;
          
          if (!restUrl || !nonce) {
            return;
          }
          
          // Send banner to server
          fetch(restUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': nonce
            },
            credentials: 'include',
            body: JSON.stringify(bannerData)
          })
          .then(function(response) {
            if (!response.ok) {
              return response.json().then(function(errData) {
                throw new Error('HTTP ' + response.status + ': ' + (errData.error || response.statusText));
              });
            }
            return response.json();
          })
          .then(function(data) {
            if (data.success) {
              // Mark banner as processed in both Set and localStorage ONLY after successful save
              processedBanners.add(bannerData.banner_id);
              saveProcessedBanner(bannerData.banner_id);
              // Hide the original banner (it's now a notification)
              // Use querySelector to find by ID or by data attribute
              var bannerEl = document.getElementById(bannerData.banner_id);
              if (!bannerEl) {
                // Try to find by banner_id in data attribute or by matching content
                var allBanners = document.querySelectorAll('.notice, .update-nag, .updated, .error, [class*="-admin-notice"]');
                for (var i = 0; i < allBanners.length; i++) {
                  var banner = allBanners[i];
                  if (banner.getAttribute('data-yp-notification-converted') !== '1' && 
                      (banner.id === bannerData.banner_id || 
                       banner.textContent.trim().substring(0, 50) === bannerData.title.substring(0, 50))) {
                    bannerEl = banner;
                    break;
                  }
                }
              }
              
              if (bannerEl) {
                bannerEl.setAttribute('data-yp-notification-converted', '1');
                bannerEl.removeAttribute('data-yp-notification-converting');
                bannerEl.style.display = 'none';
                bannerEl.style.visibility = 'hidden';
                bannerEl.style.opacity = '0';
                bannerEl.style.height = '0';
                bannerEl.style.margin = '0';
                bannerEl.style.padding = '0';
                bannerEl.style.overflow = 'hidden';
                bannerEl.style.position = 'absolute';
                bannerEl.style.left = '-9999px';
                bannerEl.style.top = '-9999px';
                bannerEl.style.width = '0';
                bannerEl.style.pointerEvents = 'none';
                bannerEl.classList.add('yp-banner-converted');
              }

              setTimeout(refreshNotificationInbox, 400);
            } else {
              // Remove from processed list if save failed (so it can be retried)
              processedBanners.delete(bannerData.banner_id);
              // Remove from localStorage too
              try {
                var stored = localStorage.getItem(STORAGE_KEY);
                if (stored) {
                  var storedBanners = JSON.parse(stored);
                  var index = storedBanners.indexOf(bannerData.banner_id);
                  if (index !== -1) {
                    storedBanners.splice(index, 1);
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(storedBanners));
                  }
                }
              } catch (e) {
              }
              // Remove processing flag so it can be retried
              var bannerEl = document.querySelector('[data-yp-notification-converting="1"]');
              if (bannerEl && bannerEl.getAttribute('data-yp-notification-converting') === '1') {
                bannerEl.removeAttribute('data-yp-notification-converting');
              }
            }
          })
          .catch(function(error) {
            // Remove from processed list if request failed (so it can be retried)
            processedBanners.delete(bannerData.banner_id);
            // Remove from localStorage too
            try {
              var stored = localStorage.getItem(STORAGE_KEY);
              if (stored) {
                var storedBanners = JSON.parse(stored);
                var index = storedBanners.indexOf(bannerData.banner_id);
                if (index !== -1) {
                  storedBanners.splice(index, 1);
                  localStorage.setItem(STORAGE_KEY, JSON.stringify(storedBanners));
                }
              }
            } catch (e) {
              // Error removing from localStorage
            }
            // Remove processing flag so it can be retried
            var bannerEl = document.querySelector('[data-yp-notification-converting="1"]');
            if (bannerEl && bannerEl.getAttribute('data-yp-notification-converting') === '1') {
              bannerEl.removeAttribute('data-yp-notification-converting');
            }
          });
        }
        
        // Function to hide banner immediately (before conversion)
        function isBannerConversionIgnored(banner) {
          return !!(
            banner &&
            typeof banner.closest === 'function' &&
            banner.closest(
              '[data-yp-banner-ignore], [data-yp-internal-notice], .yp-alert, .yp-notifications-dropdown'
            )
          );
        }

        function shouldRouteToNotifications(banner) {
          if (isBannerConversionIgnored(banner)) {
            return false;
          }
          var classifier = window.yooadminNoticeClassifier;
          if (classifier && typeof classifier.shouldConvertToNotification === 'function') {
            return classifier.shouldConvertToNotification(banner);
          }
          return true;
        }

        function markNoticeIntent(banner) {
          if (isBannerConversionIgnored(banner)) {
            return;
          }
          var classifier = window.yooadminNoticeClassifier;
          if (!classifier) {
            return;
          }
          if (classifier.shouldConvertToNotification(banner)) {
            banner.setAttribute('data-yp-notice-intent', 'promo');
            return;
          }
          if (classifier.shouldConvertToToast(banner)) {
            banner.setAttribute('data-yp-notice-intent', 'operational');
          }
        }

        function tagNoticeIntents() {
          var nodes = document.querySelectorAll(
            '.notice, .update-nag, .updated, .error, [class*="-admin-notice"]'
          );
          nodes.forEach(function (banner) {
            if (hasProtectedNoticeClass(banner)) {
              return;
            }
            markNoticeIntent(banner);
          });
        }

        function hasProtectedNoticeClass(banner) {
          return (
            isBannerConversionIgnored(banner) ||
            banner.classList.contains('yooadmin-brand-notice') ||
            banner.classList.contains('yooadmin-wizard-notice') ||
            banner.classList.contains('yooadmin-notification') ||
            banner.classList.contains('yp-notification-item')
          );
        }

        function hideBannerImmediately(banner) {
          if (isBannerConversionIgnored(banner) || ypIsInsideReactRoot(banner)) {
            return;
          }
          markNoticeIntent(banner);
          banner.style.display = 'none';
          banner.style.visibility = 'hidden';
          banner.style.opacity = '0';
          banner.style.height = '0';
          banner.style.margin = '0';
          banner.style.padding = '0';
          banner.style.overflow = 'hidden';
          banner.style.position = 'absolute';
          banner.style.left = '-9999px';
          banner.style.top = '-9999px';
          banner.style.width = '0';
          banner.style.pointerEvents = 'none';
        }
        
        function processBanners() {
          // Find all admin banners that haven't been converted yet
          // NOTE: This will find banners even if they're hidden (they're still in DOM)
          var banners = document.querySelectorAll(
            '.notice:not([data-yp-notification-converted]):not(.yp-banner-converted), ' +
            '.update-nag:not([data-yp-notification-converted]):not(.yp-banner-converted), ' +
            '.updated:not([data-yp-notification-converted]):not(.yp-banner-converted), ' +
            '.error:not([data-yp-notification-converted]):not(.yp-banner-converted), ' +
            '[class*="-admin-notice"]:not([data-yp-notification-converted]):not(.yp-banner-converted), ' +
            '[data-yp-notice-intent="promo"]:not([data-yp-notification-converted]):not(.yp-banner-converted)'
          );
          
          if (banners.length === 0) {
            return;
          }
          
          var newBannersCount = 0;
          var skippedCount = 0;
          var errorCount = 0;
          
          banners.forEach(function(banner) {
            // Skip if already processed in DOM
            if (banner.getAttribute('data-yp-notification-converted') === '1' || 
                banner.classList.contains('yp-banner-converted')) {
              skippedCount++;
              return;
            }

            if (!shouldRouteToNotifications(banner)) {
              skippedCount++;
              return;
            }

            if (ypIsInsideReactRoot(banner)) {
              skippedCount++;
              return;
            }
            
            // Skip inline/alternative notices
            if (banner.classList.contains('notice-alt') || 
                banner.classList.contains('inline') || 
                banner.classList.contains('update-message') ||
                banner.classList.contains('yp-banner-moved') ||
                banner.classList.contains('yp-notification-item')) {
              skippedCount++;
              return;
            }
            
            // Extract banner data to get stable ID (IMPORTANT: Extract BEFORE hiding)
            var bannerData;
            try {
              bannerData = extractBannerData(banner);
              if (!bannerData || !bannerData.banner_id) {
                errorCount++;
                return;
              }
            } catch (e) {
              errorCount++;
              return;
            }
            
            // Check if already processed in localStorage
            // IMPORTANT: Always reprocess banners if title is generic "Admin Notice" to update with better extraction
            if (processedBanners.has(bannerData.banner_id)) {
              // Check if user wants to force reprocessing (via URL parameter or localStorage flag)
              var forceReprocess = localStorage.getItem('yooadmin_force_reprocess_banners') === '1' || 
                                   (window.location.search && window.location.search.indexOf('force_reprocess_banners=1') !== -1);
              
              // Always reprocess if title is generic "Admin Notice" (means old extraction logic was used)
              // This ensures improved title extraction will update existing banners
              var shouldReprocess = forceReprocess || 
                                    bannerData.title === 'Admin Notice' || 
                                    (bannerData.title && bannerData.title.trim().length < 5);
              
              if (shouldReprocess) {
                processedBanners.delete(bannerData.banner_id);
                try {
                  var stored = localStorage.getItem(STORAGE_KEY);
                  if (stored) {
                    var storedBanners = JSON.parse(stored);
                    var index = storedBanners.indexOf(bannerData.banner_id);
                    if (index !== -1) {
                      storedBanners.splice(index, 1);
                      localStorage.setItem(STORAGE_KEY, JSON.stringify(storedBanners));
                    }
                  }
                } catch (e) {
                  // Error removing from localStorage
                }
                // Continue processing below (don't return)
              } else if (banner.getAttribute('data-yp-notification-converted') === '1') {
                skippedCount++;
                return;
              } else {
                // Recorded locally but may never have reached the server — sync again (API dedupes).
                banner.setAttribute('data-yp-notification-converting', '1');
                hideBannerImmediately(banner);
                sendBannerToServer(bannerData);
                skippedCount++;
                return;
              }
            }
            
            // Ensure banner is hidden (may have been hidden by hideAllBannersImmediately)
            hideBannerImmediately(banner);
            
            // This is a new banner - convert it to notification
            newBannersCount++;
            banner.setAttribute('data-yp-notification-converting', '1');
            
            // Send to server; localStorage is updated only after a successful save
            sendBannerToServer(bannerData);
          });
        }
        
        // Hide all banners immediately on page load (before processing)
        // This function only hides them visually, processBanners() will convert them
        function hideAllBannersImmediately() {
          var allBanners = document.querySelectorAll('.notice:not(.yp-notification-item):not([data-yp-notification]):not([data-yp-banner-restored]):not(.inline), .update-nag:not([data-yp-banner-restored]), .updated:not(.yp-notification-item):not([data-yp-notification]):not([data-yp-banner-restored]):not(.inline), .error:not(.yp-notification-item):not([data-yp-notification]):not([data-yp-banner-restored]), [class*="-admin-notice"]:not(.yp-notification-item):not([data-yp-notification]):not(.yp-notifications-dropdown *):not([data-yp-banner-restored]):not(.inline)');
          
          allBanners.forEach(function(banner) {
            // Skip if already processed or excluded
            if (banner.getAttribute('data-yp-notification-converted') === '1' || 
                banner.classList.contains('yp-banner-converted') ||
                banner.classList.contains('notice-alt') || 
                banner.classList.contains('update-message') ||
                banner.classList.contains('yp-banner-moved') ||
                banner.classList.contains('yp-notification-item')) {
              return;
            }
            // Skip inline notices EXCEPT for update-nag (WordPress update banner)
            if (banner.classList.contains('inline') && !banner.classList.contains('update-nag')) {
              return;
            }

            if (ypIsInsideReactRoot(banner)) {
              return;
            }

            markNoticeIntent(banner);

            if (!shouldRouteToNotifications(banner)) {
              return;
            }
            
            // Hide immediately (but don't mark as converted yet - processBanners will do that)
            hideBannerImmediately(banner);
          });
        }
        
        // Process banners on page load
        // IMPORTANT: hideAllBannersImmediately() hides them visually first,
        // then processBanners() converts them to notifications
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', function() {
            tagNoticeIntents();
            hideAllBannersImmediately();
            setTimeout(function() {
              processBanners();
            }, 100);
          });
        } else {
          tagNoticeIntents();
          hideAllBannersImmediately();
          setTimeout(function() {
            processBanners();
          }, 100);
        }
        
        // Use MutationObserver to detect new banners
        var observer = new MutationObserver(function(mutations) {
          var shouldProcess = false;
          var newBanners = [];
          
          mutations.forEach(function(mutation) {
            if (mutation.type === 'childList') {
              mutation.addedNodes.forEach(function(node) {
                if (node.nodeType === 1 && !ypIsInsideReactRoot(node)) {
                  if (node.classList && (
                    node.classList.contains('notice') || 
                    node.classList.contains('update-nag') || 
                    node.classList.contains('updated') || 
                    node.classList.contains('error') ||
                    ypClassText(node).indexOf('-admin-notice') !== -1
                  )) {
                    // Hide new promotional banner immediately
                    if (!node.classList.contains('yp-notification-item') &&
                        !node.classList.contains('notice-alt') &&
                        !node.classList.contains('inline') &&
                        !node.getAttribute('data-yp-notification-converted') &&
                        shouldRouteToNotifications(node)) {
                      hideBannerImmediately(node);
                      newBanners.push(node);
                    }
                    shouldProcess = true;
                  }
                }
              });
            }
          });
          
          if (shouldProcess) {
            // Note: Banners in newBanners array are already hidden in the loop above
            // Step 2: Convert them to notifications after debounce
            setTimeout(function() {
              processBanners();
            }, 500);
          }
        });
        
        var wpbodyContent = document.querySelector('#wpbody-content');
        if (wpbodyContent) {
          observer.observe(wpbodyContent, {
          childList: true,
          subtree: true
        });
        }
        
        // Process periodically for safety
        setInterval(processBanners, 5000);
      }
    }
  };

  // Auto-initialize banner movement (like old system)
  if (document.body && document.body.classList.contains('wp-admin')) {
    window.yooadmAdminUtils.banner.moveBannersOutsideWrap();
  }

  function isPostEditorAdminScreen() {
    var body = document.body;
    if (!body) {
      return false;
    }
    return body.classList.contains('post-php') || body.classList.contains('post-new-php');
  }

  function scheduleBannerConversionBoot() {
    var run = function () {
      if (window.yooadmRuntime && window.yooadmRuntime.convertBannersToNotifications) {
        window.yooadmAdminUtils.banner.convertBannersToNotifications();
      }
    };

    if (!isPostEditorAdminScreen()) {
      run();
      return;
    }

    var deferredRun = function () {
      setTimeout(run, 2000);
    };

    if (typeof window.requestIdleCallback === 'function') {
      window.requestIdleCallback(deferredRun, { timeout: 5000 });
    } else {
      deferredRun();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleBannerConversionBoot);
  } else {
    scheduleBannerConversionBoot();
  }
})();
