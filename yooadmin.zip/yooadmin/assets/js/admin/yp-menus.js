/**
 * YOOAdmin - Menu behavior (sidebar, popup data)
 *
 * @package YOOAdmin
 */

/* eslint-disable no-var, vars-on-top */
(function () {
	'use strict';

	if (!document.body || !document.body.classList.contains('wp-admin')) {
		return;
	}
	if (window.__YPMenusInit) {
		return;
	}
	window.__YPMenusInit = true;

	// ---- runtime flags from PHP (assets.php) ----
	var RUNTIME = (window.yooadmRuntime || {});
	var REDIRECT_ON = !!RUNTIME.redirectDashboard;
	var DASH_SLUG = String(RUNTIME.dashboardSlug || 'yooadmin-dashboard');
	function isYooDashboardSlug(s) {
		return String(s || '').toLowerCase() === DASH_SLUG.toLowerCase();
	}

	var EXCLUDED_SUB_PAGES = (function () {
		var r = RUNTIME.excludedSubmenuPages;
		if (!Array.isArray(r)) {
			return [];
		}
		var out = [];
		var i = 0;
		for (i = 0; i < r.length; i++) {
			out.push(String(r[i]).toLowerCase());
		}
		return out;
	})();
	function isExcludedSubmenuPageByRuntime(href) {
		if (!href || !EXCLUDED_SUB_PAGES.length) {
			return false;
		}
		try {
			var u = new URL(href, window.location.origin);
			var p = u.searchParams.get('page');
			if (!p) {
				return false;
			}
			var pl = p.toLowerCase();
			var j = 0;
			for (j = 0; j < EXCLUDED_SUB_PAGES.length; j++) {
				if (pl === EXCLUDED_SUB_PAGES[j]) {
					return true;
				}
			}
		} catch (e) {}
		return false;
	}
	function isNavigableSubmenuHref(href) {
		if (!href) {
			return false;
		}
		var h = String(href).trim();
		if (h === '' || h === '#') {
			return false;
		}
		if (/^javascript:/i.test(h)) {
			return false;
		}
		if (isExcludedSubmenuPageByRuntime(href)) {
			return false;
		}
		return true;
	}

	var cssEscape = (window.CSS && CSS.escape) ? CSS.escape : function (s) {
		return String(s || '').replace(/[^a-zA-Z0-9_\-]/g, '\\$&');
	};

	function normalizeTitle(s) {
		if (!s) { return ''; }
		return String(s).replace(/\u00A0|&nbsp;|&#160;/gi, ' ').replace(/\s+/g, ' ').trim();
	}
	function cleanMenuTitle(raw) {
		var t = normalizeTitle(raw);
		t = t
			.replace(/\s*\(\s*\d+\s*\)\s*$/i, '')
			.replace(/\s+[\d,\s]+\s+notifications?$/i, '')
			.replace(/\s+notifications?$/i, '')
			.replace(/\s+[\d,\s]+\s*(?:comments?\s+)?in\s+moderation.*$/i, '')
			.replace(/\s+[\d,\s]+\s+comments?\s.*$/i, '')
			.replace(/\s+\d+\s*$/i, '')
			.replace(/\s+\d+\s+(?:in\s+moderation|new|pending|updates?)\s*$/i, '')
			.trim();
		return t;
	}
	function getMenuTitleFromLi(li) {
		var nameEl = li.querySelector('.wp-menu-name') || li.querySelector('a.menu-top');
		if (!nameEl) { return ''; }
		var clone = nameEl.cloneNode(true);
		var noisy = clone.querySelectorAll('.awaiting-mod, .update-plugins, .count, .plugin-count, .update-count, .screen-reader-text');
		for (var i = 0; i < noisy.length; i++) { noisy[i].remove(); }
		return cleanMenuTitle(clone.textContent || '');
	}
	function getQS(href, key) {
		try {
			var u = new URL(href, window.location.origin);
			return u.searchParams.get(key) || '';
		} catch (e) {
			var m = new RegExp('[?&]' + key + '=([^&#]+)').exec(href || '');
			return m ? decodeURIComponent(m[1]) : '';
		}
	}
	function normURL(href) {
		try {
			var u = new URL(href, window.location.origin);
			var out = u.pathname.replace(/^\//, '');
			if (u.search) { out += u.search; }
			return out.toLowerCase();
		} catch (e) {
			return String(href || '').replace(/^\//, '').toLowerCase();
		}
	}
	function forEachTopMenuLI(adminMenuEl, cb) {
		if (!adminMenuEl) { return; }
		var kids = adminMenuEl.children || [];
		for (var i = 0; i < kids.length; i++) {
			var li = kids[i];
			if (li && li.nodeType === 1 && li.classList.contains('menu-top') && !li.classList.contains('wp-menu-separator')) {
				cb(li);
			}
		}
	}

	/* ---------- icon color ---------- */
	function resolveIconColorFromLink(link) {
		try {
			/* Sidebar icons: use contrast for non-active, primary for active (CSS handles this; we avoid wrong fallbacks) */
			if (link && link.closest && link.closest('#yps-sidebar')) {
				var item = link.closest('.yps-item');
				var isActive = item && item.classList.contains('is-active');
				var root = document.documentElement;
				var val = isActive
					? (getComputedStyle(root).getPropertyValue('--_yp-primary') || getComputedStyle(root).getPropertyValue('--yp-primary'))
					: getComputedStyle(root).getPropertyValue('--yp-text-contrast');
				if (val && val.trim()) { return val.trim(); }
				return isActive ? '#eda934' : '#fff';
			}
			var proxy = link && link.querySelector ? link.querySelector('.yps-wp-icon-proxy') : null;
			if (proxy) {
				var c = getComputedStyle(proxy).color;
				if (c && c.trim()) { return c.trim(); }
			}
			var c2 = link ? getComputedStyle(link).color : '';
			if (c2 && c2.trim()) { return c2.trim(); }
			var root = getComputedStyle(document.documentElement);
			var v1 = root.getPropertyValue('--yp-card-icon-color');
			if (v1 && v1.trim()) { return v1.trim(); }
			var v2 = root.getPropertyValue('--yp-primary');
			if (v2 && v2.trim()) { return v2.trim(); }
		} catch (e) {}
		return '#eda934';
	}

	/* ---------- icons ---------- */
	function readIconData(li) {
		if (!li) { return null; }
		var wrap = li.querySelector('.wp-menu-image');
		if (!wrap) { return null; }

		var img = wrap.querySelector('img');
		if (img && img.src) { return { type: 'img', src: img.src }; }

		var svg = wrap.querySelector('svg');
		if (svg) { return { type: 'svg', node: svg }; }

		var selfCS = getComputedStyle(wrap);
		var bgSelf = selfCS.getPropertyValue('background-image');
		if (bgSelf && bgSelf !== 'none') {
			return { type: 'bg', asMask: true, bg: {
				image: bgSelf,
				repeat: selfCS.getPropertyValue('background-repeat'),
				pos: selfCS.getPropertyValue('background-position'),
				size: selfCS.getPropertyValue('background-size')
			}};
		}
		var beforeCS = getComputedStyle(wrap, '::before');
		if (beforeCS) {
			var bgB = beforeCS.getPropertyValue('background-image');
			if (bgB && bgB !== 'none') {
				return { type: 'bg', asMask: true, bg: {
					image: bgB,
					repeat: beforeCS.getPropertyValue('background-repeat'),
					pos: beforeCS.getPropertyValue('background-position'),
					size: beforeCS.getPropertyValue('background-size')
				}};
			}
			var content = beforeCS.getPropertyValue('content');
			if (content && content !== 'none' && content !== 'normal') {
				content = content.replace(/^["']|["']$/g, '');
				return {
					type: 'glyph',
					glyph: content,
					fontFamily: beforeCS.getPropertyValue('font-family') || 'dashicons',
					fontWeight: beforeCS.getPropertyValue('font-weight'),
					fontStyle:  beforeCS.getPropertyValue('font-style')
				};
			}
		}
		var maskSelf = selfCS.getPropertyValue('-webkit-mask-image') || selfCS.getPropertyValue('mask-image');
		if (maskSelf && maskSelf !== 'none') {
			return { type: 'mask', mask: {
				image: maskSelf,
				repeat: selfCS.getPropertyValue('-webkit-mask-repeat') || selfCS.getPropertyValue('mask-repeat'),
				pos: selfCS.getPropertyValue('-webkit-mask-position') || selfCS.getPropertyValue('mask-position'),
				size: selfCS.getPropertyValue('-webkit-mask-size') || selfCS.getPropertyValue('mask-size')
			}};
		}
		if (beforeCS) {
			var maskB = beforeCS.getPropertyValue('-webkit-mask-image') || beforeCS.getPropertyValue('mask-image');
			if (maskB && maskB !== 'none') {
				return { type: 'mask', mask: {
					image: maskB,
					repeat: beforeCS.getPropertyValue('-webkit-mask-repeat') || beforeCS.getPropertyValue('mask-repeat'),
					pos: beforeCS.getPropertyValue('-webkit-mask-position') || beforeCS.getPropertyValue('mask-position'),
					size: beforeCS.getPropertyValue('-webkit-mask-size') || beforeCS.getPropertyValue('mask-size')
				}};
			}
		}
		return null;
	}
	function ensureFallbackIcon(holder, color) {
		var span = document.createElement('span');
		span.className = 'dashicons dashicons-admin-generic';
		span.style.color = color || 'currentColor';
		holder.appendChild(span);
	}
	function applyMaskToEl(el, image, repeat, pos, size, color) {
		el.style.backgroundColor = color || 'currentColor';
		el.style.webkitMaskImage = image || '';
		el.style.maskImage = image || '';
		if (repeat) { el.style.webkitMaskRepeat = repeat; el.style.maskRepeat = repeat; }
		if (pos) { el.style.webkitMaskPosition = pos; el.style.maskPosition = pos; }
		if (size) { el.style.webkitMaskSize = size; el.style.maskSize = size; }
	}
	function paintIntoProxy(proxy, data) {
		if (!proxy) { return; }
		proxy.textContent = '';
		var holder = proxy.querySelector('.wp-menu-image') || proxy;
		var link = proxy.closest('.yps-link');
		var iconColor = resolveIconColorFromLink(link || document.body);
		holder.style.color = iconColor;

		if (!data) { ensureFallbackIcon(holder, iconColor); return; }

		if (data.type === 'img') {
			var elImg = document.createElement('img');
			elImg.src = data.src; elImg.alt = '';
			var srcL = String(data.src || '').toLowerCase();
			var isColorRaster = /\.(png|jpe?g|gif|webp|avif|ico|bmp)(\?|$)/i.test(srcL)
				|| (srcL.indexOf('data:image/') === 0 && srcL.indexOf('svg+xml') === -1);
			if (isColorRaster) {
				elImg.classList.add('yps-wp-icon-img-native');
			}
			holder.appendChild(elImg); return;
		}
		if (data.type === 'svg' && data.node) {
			var svgEl = data.node.cloneNode(true);
			svgEl.setAttribute('width', '20'); svgEl.setAttribute('height', '20');
			if (!svgEl.getAttribute('fill')) { try { svgEl.setAttribute('fill', 'currentColor'); } catch (e) {} }
			holder.appendChild(svgEl); return;
		}
		if (data.type === 'bg') {
			var bg = data.bg || {};
			if (data.asMask) {
				var inSidebar = !!(link && link.closest && link.closest('#yps-sidebar'));
				if (inSidebar) {
					applyMaskToEl(holder, bg.image, 'no-repeat', 'center', 'contain', iconColor);
				} else {
					applyMaskToEl(holder, bg.image, bg.repeat, bg.pos, bg.size, iconColor);
				}
			} else {
				holder.style.backgroundImage = bg.image || '';
				holder.style.backgroundRepeat = bg.repeat || 'no-repeat';
				holder.style.backgroundPosition = bg.pos || 'center';
				holder.style.backgroundSize = bg.size || 'contain';
			}
			return;
		}
		if (data.type === 'glyph') {
			var glyph = document.createElement('span');
			glyph.textContent = data.glyph;
			if (data.fontFamily) { glyph.style.fontFamily = data.fontFamily; }
			if (data.fontWeight) { glyph.style.fontWeight = data.fontWeight; }
			if (data.fontStyle)  { glyph.style.fontStyle  = data.fontStyle; }
			glyph.style.color = 'currentColor';
			holder.appendChild(glyph);
			return;
		}
		if (data.type === 'mask') {
			// Sidebar proxy: use contain + center (ignore tiny mask-size from #adminmenu flyout)
			applyMaskToEl(holder, data.mask.image, 'no-repeat', 'center', 'contain', iconColor);
			return;
		}
		ensureFallbackIcon(holder, iconColor);
	}

	/* ---------- badges ---------- */
	function extractBadgeForLi(li) {
		if (!li) { return null; }
		var up = li.querySelector('.update-plugins .plugin-count, .update-plugins .update-count, .update-plugins .count');
		if (up && up.textContent && up.textContent.trim() !== '') { return { value: up.textContent.trim(), kind: 'updates' }; }
		var pending = li.querySelector('.awaiting-mod .pending-count');
		if (pending && pending.textContent && pending.textContent.trim() !== '') { return { value: pending.textContent.trim(), kind: 'comments' }; }
		var am = li.querySelector('.awaiting-mod');
		if (am) {
			var m = (am.textContent || '').match(/\d+/);
			if (m) { return { value: m[0], kind: 'comments' }; }
		}
		return null;
	}
	function injectBadgeIntoLink(link, badge) {
		if (!link || !badge) { return; }
		var val = String(badge.value || '').trim();
		if (val === '' || val === '0') { return; }
		if (link.querySelector('.yps-badge')) { return; }
		var badgeEl = document.createElement('span');
		badgeEl.className = 'yps-badge ' + (badge.kind === 'comments' ? 'yps-badge--comments' : 'yps-badge--updates');
		badgeEl.textContent = val;
		var txt = link.querySelector('.yps-text');
		if (txt) { txt.appendChild(badgeEl); }
	}

	/* ---------- mapping ---------- */
	function slugFromAdminLi(li) {
		var a = li.querySelector('a.menu-top');
		if (!a) { return ''; }
		var href = a.getAttribute('href') || '';
		var page = getQS(href, 'page');
		if (page) { return page; }
		try {
			var u = new URL(href, location.origin);
			var out = u.pathname.replace(/^\//, '');
			if (u.search) { out += u.search; }
			return out || href;
		} catch (e) {}
		if (li.id && li.id.indexOf('toplevel_page_') === 0) { return li.id.replace('toplevel_page_', ''); }
		return href;
	}

	/* ---------- label fallback for submenu links ---------- */
	function getLinkLabel(a) {
		if (!a) { return ''; }
		var t = cleanMenuTitle((a.textContent || '').trim());
		if (!t) { t = (a.getAttribute('aria-label') || '').trim(); }
		if (!t) { t = (a.getAttribute('title') || '').trim(); }
		if (!t) {
			var href = a.getAttribute('href') || '';
			if (/wc[-_]?addons|marketplace|extensions/i.test(href)) { t = 'Extensions'; }
		}
		return t;
	}
	function isSubmenuDivider(li) {
		if (!li) { return false; }
		if (li.getAttribute('role') === 'separator') { return true; }
		if (li.classList && (li.classList.contains('separator') || li.classList.contains('wp-submenu-head'))) { return true; }
		return false;
	}

	/* ---------- dedup helpers ---------- */
	function isExtensionsHref(href) {
		return /wc[-_]?addons|marketplace|\/extensions\b/i.test(href || '');
	}
	function subItemKey(href, label) {
		if (isExtensionsHref(href) || String(label).toLowerCase() === 'extensions') {
			return 'wc-extensions';
		}
		return normURL(href);
	}

	/**
	 * Duplicate top-level items (same visible title, slugs like `foo` + `foo-bar`): merge in YOOAdmin sidebar only.
	 * Does not modify WordPress $menu (avoids breaking core / strip_tags and plugin screens).
	 */
	function normalizeTitleKey(raw) {
		return cleanMenuTitle(raw || '').toLowerCase().trim();
	}
	function samePluginFamily(a, b) {
		a = String(a || '').toLowerCase();
		b = String(b || '').toLowerCase();
		if (!a || !b) { return false; }
		if (a === b) { return true; }
		return a.indexOf(b + '-') === 0 || b.indexOf(a + '-') === 0;
	}
	function mergeCanonicalSlug(a, b) {
		a = String(a || '');
		b = String(b || '');
		var la = a.toLowerCase();
		var lb = b.toLowerCase();
		if (la === lb) { return a; }
		if (lb.indexOf(la + '-') === 0) { return a; }
		if (la.indexOf(lb + '-') === 0) { return b; }
		return la.length <= lb.length ? a : b;
	}
	function buildCanonSlugByTitle(admin) {
		var topLis = [];
		forEachTopMenuLI(admin, function(li) { topLis.push(li); });
		var byTitle = {};
		var i = 0;
		for (i = 0; i < topLis.length; i++) {
			var t = normalizeTitleKey(getMenuTitleFromLi(topLis[i]));
			var pk = slugFromAdminLi(topLis[i]);
			if (!t || !pk) { continue; }
			if (!byTitle[t]) { byTitle[t] = []; }
			if (byTitle[t].indexOf(pk) === -1) { byTitle[t].push(pk); }
		}
		var out = {};
		Object.keys(byTitle).forEach(function(t) {
			var slugs = byTitle[t];
			if (slugs.length < 2) { return; }
			var c = slugs[0];
			var j = 0;
			for (j = 1; j < slugs.length; j++) {
				if (!samePluginFamily(c, slugs[j])) {
					return;
				}
				c = mergeCanonicalSlug(c, slugs[j]);
			}
			out[t] = c;
		});
		return out;
	}

	/** First UL inside .wp-submenu, or the .wp-submenu block if it holds direct LI children. */
	function getWpSubmenuContainer(nativeLi) {
		if (!nativeLi) { return null; }
		var sub = nativeLi.querySelector('.wp-submenu');
		if (!sub) { return null; }
		var ul = sub.querySelector(':scope > ul');
		if (ul) { return ul; }
		return sub;
	}
	function directChildUls(li) {
		var out = [];
		if (!li || !li.children) { return out; }
		var ch = li.children;
		var i = 0;
		for (i = 0; i < ch.length; i++) {
			if (ch[i].tagName === 'UL') { out.push(ch[i]); }
		}
		return out;
	}
	function firstLinkInLiExcludingNestedUls(nli, nestedUls) {
		if (!nli) { return null; }
		nestedUls = nestedUls || [];
		var links = nli.querySelectorAll('a');
		var ai = 0;
		for (ai = 0; ai < links.length; ai++) {
			var cand = links[ai];
			var insideNested = false;
			var ni = 0;
			for (ni = 0; ni < nestedUls.length; ni++) {
				if (nestedUls[ni].contains(cand)) { insideNested = true; break; }
			}
			if (!insideNested) { return cand; }
		}
		return null;
	}
	function submenuParentLink(nli, nestedUls) {
		nestedUls = nestedUls || [];
		var sa = nli.querySelector(':scope > a');
		if (sa) {
			var ni = 0;
			for (ni = 0; ni < nestedUls.length; ni++) {
				if (nestedUls[ni].contains(sa)) { sa = null; break; }
			}
			if (sa) { return sa; }
		}
		return firstLinkInLiExcludingNestedUls(nli, nestedUls);
	}
	function collectSeenUrlsAndKeysFromYpsUl(rootUl) {
		var seen = {};
		if (!rootUl) { return seen; }
		var ex = rootUl.querySelectorAll('a.yps-sub-link');
		var ei = 0;
		for (ei = 0; ei < ex.length; ei++) {
			var a = ex[ei];
			try {
				var u = new URL(a.href, location.origin);
				seen[normURL(u.pathname + u.search)] = true;
			} catch (err) {}
			var te = a.querySelector('.yps-text');
			var label = te ? (te.textContent || '') : (a.textContent || '');
			seen[subItemKey(a.href, label)] = true;
		}
		return seen;
	}
	function findYpsSubLinkByHref(rootUl, href) {
		if (!rootUl || !href) { return null; }
		try {
			var want = new URL(href, location.origin).href;
			var links = rootUl.querySelectorAll('a.yps-sub-link');
			var i = 0;
			for (i = 0; i < links.length; i++) {
				try {
					if (new URL(links[i].href, location.origin).href === want) { return links[i]; }
				} catch (e) {}
			}
		} catch (e) {}
		return null;
	}
	function resolveNativeTopLiForIcon(admin, slug, fallbackLi) {
		if (!admin || !slug) { return fallbackLi || null; }
		var candidates = [];
		var s = String(slug);
		try {
			candidates.push(admin.querySelector('#toplevel_page_' + cssEscape(s)));
		} catch (e) {}
		try {
			candidates.push(admin.querySelector('li.toplevel_page_' + cssEscape(s)));
		} catch (e) {}
		if (s.indexOf('elementor') !== -1) {
			candidates.unshift(admin.querySelector('#toplevel_page_elementor-home'));
			candidates.unshift(admin.querySelector('#toplevel_page_elementor'));
		}
		var ci = 0;
		for (ci = 0; ci < candidates.length; ci++) {
			var el = candidates[ci];
			if (el && readIconData(el)) { return el; }
		}
		if (fallbackLi && readIconData(fallbackLi)) { return fallbackLi; }
		for (ci = 0; ci < candidates.length; ci++) {
			if (candidates[ci]) { return candidates[ci]; }
		}
		return fallbackLi || null;
	}

	/**
	 * Mirror WordPress submenu tree (including nested UL under a LI) into YOOAdmin sidebar.
	 */
	function fillYpsSubFromWpContainer(wpContainer, targetUl, seen) {
		if (!wpContainer || !targetUl || !seen) { return; }
		var kids = wpContainer.children;
		var i = 0;
		for (i = 0; i < kids.length; i++) {
			var nli = kids[i];
			if (nli.tagName !== 'LI') { continue; }
			if (isSubmenuDivider(nli)) { continue; }

			var nestedUls = directChildUls(nli);
			var sa = submenuParentLink(nli, nestedUls);
			if (!sa || !sa.href) {
				if (nestedUls.length) {
					fillYpsSubFromWpContainer(nestedUls[0], targetUl, seen);
				}
				continue;
			}
			if (!isNavigableSubmenuHref(sa.href)) {
				if (nestedUls.length) {
					fillYpsSubFromWpContainer(nestedUls[0], targetUl, seen);
				}
				continue;
			}

			var label = getLinkLabel(sa);
			if (!label) { continue; }
			var key = subItemKey(sa.href, label);
			var uk = '';
			try {
				var u2 = new URL(sa.href, location.origin);
				uk = normURL(u2.pathname + u2.search);
			} catch (e2) {}

			if (nestedUls.length > 0) {
				if ((uk && seen[uk]) || seen[key]) {
					var existingA = findYpsSubLinkByHref(targetUl, sa.href);
					if (existingA) {
						var parentLi = existingA.closest('.yps-sub-item');
						var nestedTarget = parentLi && parentLi.querySelector(':scope > ul.yps-sub--nested');
						if (!nestedTarget && parentLi) {
							var nid = 'yps-nested-' + Math.random().toString(36).slice(2);
							nestedTarget = document.createElement('ul');
							nestedTarget.id = nid;
							nestedTarget.className = 'yps-sub yps-sub--nested';
							nestedTarget.hidden = false;
							parentLi.classList.add('yps-sub-item--nested', 'has-nested', 'is-open');
							var row = parentLi.querySelector('.yps-sub-row');
							if (!row) {
								row = document.createElement('div');
								row.className = 'yps-sub-row';
								parentLi.insertBefore(row, existingA);
								row.appendChild(existingA);
								var nbtn = document.createElement('button');
								nbtn.type = 'button';
								nbtn.className = 'yps-nested-expander';
								nbtn.setAttribute('aria-controls', nid);
								nbtn.setAttribute('aria-expanded', 'true');
								nbtn.innerHTML = '<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>';
								row.appendChild(nbtn);
							}
							parentLi.appendChild(nestedTarget);
						}
						if (nestedTarget) {
							fillYpsSubFromWpContainer(nestedUls[0], nestedTarget, seen);
						}
					}
					continue;
				}

				var wrapLi = document.createElement('li');
				wrapLi.className = 'yps-sub-item yps-sub-item--nested has-nested';
				var rowEl = document.createElement('div');
				rowEl.className = 'yps-sub-row';
				var a2 = document.createElement('a');
				a2.className = 'yps-sub-link';
				a2.href = sa.href;
				a2.innerHTML = '<span class="yps-text"></span>';
				a2.querySelector('.yps-text').textContent = label;
				var subBadge = extractBadgeForLi(nli);
				if (subBadge) { injectBadgeIntoLink(a2, subBadge); }

				var nid = 'yps-nested-' + Math.random().toString(36).slice(2);
				var nbtn = document.createElement('button');
				nbtn.type = 'button';
				nbtn.className = 'yps-nested-expander';
				nbtn.setAttribute('aria-controls', nid);
				nbtn.setAttribute('aria-expanded', 'false');
				nbtn.innerHTML = '<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>';

				rowEl.appendChild(a2);
				rowEl.appendChild(nbtn);

				var nul = document.createElement('ul');
				nul.id = nid;
				nul.className = 'yps-sub yps-sub--nested';
				nul.hidden = true;

				wrapLi.appendChild(rowEl);
				wrapLi.appendChild(nul);
				targetUl.appendChild(wrapLi);

				if (uk) { seen[uk] = true; }
				seen[key] = true;
				fillYpsSubFromWpContainer(nestedUls[0], nul, seen);
				continue;
			}

			if ((uk && seen[uk]) || seen[key]) { continue; }
			if (uk) { seen[uk] = true; }
			seen[key] = true;

			var li2 = document.createElement('li');
			li2.className = 'yps-sub-item';
			var a3 = document.createElement('a');
			a3.className = 'yps-sub-link';
			a3.href = sa.href;
			a3.innerHTML = '<span class="yps-text"></span>';
			a3.querySelector('.yps-text').textContent = label;
			var subBadge2 = extractBadgeForLi(nli);
			if (subBadge2) { injectBadgeIntoLink(a3, subBadge2); }
			targetUl.appendChild(li2).appendChild(a3);
		}
	}

	function mergeNativeSubmenuIntoYpsItem(ypsItem, nativeLi) {
		if (!ypsItem || !nativeLi) { return; }
		var ul = ypsItem.querySelector('.yps-sub');
		var seen = {};
		if (ul) {
			seen = collectSeenUrlsAndKeysFromYpsUl(ul);
		} else {
			var subId = 'yps-sub-auto-' + Math.random().toString(36).slice(2);
			ypsItem.classList.add('has-sub');
			var rowEl = ypsItem.querySelector('.yps-row');
			if (rowEl && !rowEl.querySelector('.yps-expander')) {
				var btn = document.createElement('button');
				btn.type = 'button';
				btn.className = 'yps-expander';
				btn.setAttribute('aria-controls', subId);
				btn.setAttribute('aria-expanded', 'false');
				btn.innerHTML = '<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>';
				rowEl.appendChild(btn);
			}
			ul = document.createElement('ul');
			ul.id = subId;
			ul.className = 'yps-sub';
			ul.hidden = true;
			ypsItem.appendChild(ul);
		}
		var wpRoot = getWpSubmenuContainer(nativeLi);
		if (wpRoot) {
			fillYpsSubFromWpContainer(wpRoot, ul, seen);
		} else {
			var nodes = nativeLi.querySelectorAll('.wp-submenu li');
			var ni = 0;
			for (ni = 0; ni < nodes.length; ni++) {
				var nli = nodes[ni];
				if (isSubmenuDivider(nli)) { continue; }
				var sa = nli.querySelector('a');
				if (!sa || !sa.href) { continue; }
				if (!isNavigableSubmenuHref(sa.href)) { continue; }
				var label = getLinkLabel(sa);
				if (!label) { continue; }
				var key = subItemKey(sa.href, label);
				try {
					var u2 = new URL(sa.href, location.origin);
					var uk = normURL(u2.pathname + u2.search);
					if (seen[uk] || seen[key]) { continue; }
					seen[uk] = true;
					seen[key] = true;
				} catch (e2) {
					if (seen[key]) { continue; }
					seen[key] = true;
				}
				var li2 = document.createElement('li');
				li2.className = 'yps-sub-item';
				var a2 = document.createElement('a');
				a2.className = 'yps-sub-link';
				a2.href = sa.href;
				a2.innerHTML = '<span class="yps-text"></span>';
				a2.querySelector('.yps-text').textContent = label;
				var subBadge = extractBadgeForLi(nli);
				if (subBadge) { injectBadgeIntoLink(a2, subBadge); }
				ul.appendChild(li2).appendChild(a2);
			}
		}
	}
	function upgradeYpsTopIconFromNative(ypsItem, nativeLi) {
		if (!ypsItem || !nativeLi) { return; }
		var proxy = ypsItem.querySelector('.yps-wp-icon-proxy');
		if (!proxy) { return; }
		var slugLink = ypsItem.querySelector('.yps-link');
		var slug = slugLink ? slugLink.getAttribute('data-menu-slug') : '';
		var admin = document.getElementById('adminmenu');
		var srcLi = nativeLi;
		if (admin && slug) {
			var resolved = resolveNativeTopLiForIcon(admin, slug, nativeLi);
			if (resolved) { srcLi = resolved; }
		}
		var data = readIconData(srcLi);
		if (!data) { return; }
		paintIntoProxy(proxy, data);
	}

	/* ---------- build/mirror ---------- */
	function appendItemFromNative(nativeLi, dataMenuSlugOverride) {
		var nav = document.querySelector('#yps-sidebar .yps-nav');
		if (!nav) { return; }
		var topA = nativeLi.querySelector('a.menu-top');
		if (!topA) { return; }
		var slug = slugFromAdminLi(nativeLi);
		if (!slug) { return; }
		var menuSlugAttr = dataMenuSlugOverride || sidebarMenuSlugFromNativeLi(nativeLi);
		if (document.querySelector('.yps-link[data-menu-slug="' + cssEscape(menuSlugAttr) + '"]')) { return; }

		var name = getMenuTitleFromLi(nativeLi);
		if (REDIRECT_ON && isYooDashboardSlug(slug)) {
			name = 'Dashboard';
		}
		var hasSub = !!nativeLi.querySelector('.wp-submenu li a');
		if (REDIRECT_ON && isYooDashboardSlug(slug)) {
			hasSub = false;
		}

		var subId = 'yps-sub-auto-' + Math.random().toString(36).slice(2);

		var li = document.createElement('li');
		li.className = 'yps-item' + (hasSub ? ' has-sub' : '');

		var row = document.createElement('div');
		row.className = 'yps-row';

		var a = document.createElement('a');
		a.className = 'yps-link';
		a.href = topA.href;
		a.setAttribute('data-menu-slug', menuSlugAttr);
		a.innerHTML =
			'<span class="yps-wp-icon-proxy"><span class="wp-menu-image dashicons-before" aria-hidden="true"></span></span>' +
			'<span class="yps-text"></span>';
		a.querySelector('.yps-text').textContent = name;
		row.appendChild(a);

		if (hasSub) {
			var btn = document.createElement('button');
			btn.type = 'button';
			btn.className = 'yps-expander';
			btn.setAttribute('aria-controls', subId);
			btn.setAttribute('aria-expanded', 'false');
			btn.innerHTML = '<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>';
			row.appendChild(btn);
		}

		li.appendChild(row);

		if (hasSub) {
			var ul = document.createElement('ul');
			ul.id = subId;
			ul.className = 'yps-sub';
			ul.hidden = true;

			var seen = {};
			var wpRoot = getWpSubmenuContainer(nativeLi);
			if (wpRoot) {
				fillYpsSubFromWpContainer(wpRoot, ul, seen);
			} else {
				var nodes = nativeLi.querySelectorAll('.wp-submenu li');
				for (var i = 0; i < nodes.length; i++) {
					var nli = nodes[i];
					if (isSubmenuDivider(nli)) { continue; }
					var sa = nli.querySelector('a');
					if (!sa || !sa.href) { continue; }
					if (!isNavigableSubmenuHref(sa.href)) { continue; }
					var label = getLinkLabel(sa);
					if (!label) { continue; }

					var key = subItemKey(sa.href, label);
					if (seen[key]) { continue; }
					seen[key] = true;

					var li2 = document.createElement('li');
					li2.className = 'yps-sub-item';
					var a2 = document.createElement('a');
					a2.className = 'yps-sub-link';
					a2.href = sa.href;
					a2.innerHTML = '<span class="yps-text"></span>';
					a2.querySelector('.yps-text').textContent = label;

					var subBadge = extractBadgeForLi(nli);
					if (subBadge) {
						injectBadgeIntoLink(a2, subBadge);
					}

					ul.appendChild(li2).appendChild(a2);
				}
			}

			li.appendChild(ul);
		}

		nav.appendChild(li);

		var proxy = li.querySelector('.yps-wp-icon-proxy');
		if (proxy) {
			var adminM = document.getElementById('adminmenu');
			var srcForIcon = nativeLi;
			if (adminM && menuSlugAttr) {
				var r = resolveNativeTopLiForIcon(adminM, menuSlugAttr, nativeLi);
				if (r) { srcForIcon = r; }
			}
			paintIntoProxy(proxy, readIconData(srcForIcon));
		}

		var badge = extractBadgeForLi(nativeLi);
		if (badge) { injectBadgeIntoLink(a, badge); }
	}

	function hydrateExistingFromNative() {
		var admin = document.getElementById('adminmenu');
		if (!admin) { return; }

		var links = document.querySelectorAll('#yps-sidebar .yps-link');
		// Cache menu-top links once instead of querying for each link
		var allMenuTopLinks = admin.querySelectorAll('a.menu-top');
		
		for (var i = 0; i < links.length; i++) {
			var link = links[i];
			if (link.dataset.hydrated === '1') { continue; }

			var slug = link.getAttribute('data-menu-slug') || '';
			var srcLi = null;

			if (slug) {
				var pageMatch = admin.querySelector('a.menu-top[href*="page=' + cssEscape(slug) + '"]');
				if (pageMatch) { srcLi = pageMatch.closest('li'); }
			}
			if (!srcLi) {
				var target = link.getAttribute('href') || '';
				// Use cached allMenuTopLinks instead of querying again
				for (var j = 0; j < allMenuTopLinks.length; j++) {
					var a = allMenuTopLinks[j];
					try {
						var u1 = new URL(a.href, location.origin);
						var u2 = new URL(target, location.origin);
						if (u1.pathname === u2.pathname && u1.search === u2.search) { srcLi = a.closest('li'); break; }
					} catch (e) {}
				}
			}
			if (!srcLi && slug) {
				var idLi = admin.querySelector('#toplevel_page_' + cssEscape(slug));
				if (idLi) { srcLi = idLi; }
			}
			if (!srcLi) { continue; }

			var aTop = srcLi.querySelector('a.menu-top');
			if (aTop && aTop.href) { link.href = aTop.href; }

			var proxy = link.querySelector('.yps-wp-icon-proxy');
			if (proxy) {
				var srcIcon = srcLi;
				if (admin && slug) {
					var rli = resolveNativeTopLiForIcon(admin, slug, srcLi);
					if (rli) { srcIcon = rli; }
				}
				paintIntoProxy(proxy, readIconData(srcIcon));
			}

		var textEl = link.querySelector('.yps-text');
		if (textEl) {
			// For card-menu items, the PHP title is authoritative — don't let the native
			// WP admin menu (which may show generic labels like "post") override it.
			// Only items NOT built from card-menus get their title from the native menu.
			var builtFromCards = link.getAttribute('data-built-from') === 'cards';
			if (!builtFromCards) {
				var name = getMenuTitleFromLi(srcLi);
				if (name) { textEl.textContent = name; }
			}

			var badge = extractBadgeForLi(srcLi);
			if (badge) { injectBadgeIntoLink(link, badge); }
		}

			if (REDIRECT_ON && slug && isYooDashboardSlug(slug)) {
				var teDash = link.querySelector('.yps-text');
				if (teDash) {
					teDash.textContent = 'Dashboard';
				}
				var dashItem = link.closest('.yps-item');
				if (dashItem) {
					dashItem.classList.remove('has-sub', 'is-open');
					var subRm = dashItem.querySelector('.yps-sub');
					var expRm = dashItem.querySelector('.yps-expander');
					if (subRm) {
						subRm.remove();
					}
					if (expRm) {
						expRm.remove();
					}
				}
			}

			link.dataset.hydrated = '1';
		}
	}

	function addMissingFromNative() {
		var admin = document.getElementById('adminmenu');
		var nav = document.querySelector('#yps-sidebar .yps-nav');
		if (!admin || !nav) { return; }
		var canonByTitle = buildCanonSlugByTitle(admin);
		var topLis = [];
		forEachTopMenuLI(admin, function(li) { topLis.push(li); });
		var i = 0;
		for (i = 0; i < topLis.length; i++) {
			var li = topLis[i];
			var t = normalizeTitleKey(getMenuTitleFromLi(li));
			var slug = slugFromAdminLi(li);
			if (!slug) { continue; }
			var canon = canonByTitle[t];
			if (!canon) {
				appendItemFromNative(li);
			} else if (slug === canon) {
				appendItemFromNative(li, canon);
			}
		}
		for (i = 0; i < topLis.length; i++) {
			var li2 = topLis[i];
			var t2 = normalizeTitleKey(getMenuTitleFromLi(li2));
			var slug2 = slugFromAdminLi(li2);
			if (!slug2) { continue; }
			var canon2 = canonByTitle[t2];
			if (!canon2 || slug2 === canon2) { continue; }
			if (!samePluginFamily(canon2, slug2)) { continue; }
			var link = nav.querySelector('.yps-link[data-menu-slug="' + cssEscape(canon2) + '"]');
			if (!link) { continue; }
			var item = link.closest('.yps-item');
			mergeNativeSubmenuIntoYpsItem(item, li2);
			upgradeYpsTopIconFromNative(item, li2);
		}
	}

	/* ---------- popup data ---------- */
	function feedYoopixelMenus() {
		var admin = document.getElementById('adminmenu');
		if (!admin) {
			return;
		}
		var store = (window.yoopixelMenus = window.yoopixelMenus || {});
		var canonByTitle = buildCanonSlugByTitle(admin);

		forEachTopMenuLI(admin, function (li) {
			var topA = li.querySelector('a.menu-top');
			var title = getMenuTitleFromLi(li);
			var href = topA ? topA.href : '';
			var hrefNorm = normURL(href);
			var page = getQS(href, 'page');
			var idSlug = (li.id && li.id.indexOf('toplevel_page_') === 0) ? li.id.replace('toplevel_page_', '') : '';

			var primaryKey = slugFromAdminLi(li);
			if (REDIRECT_ON && isYooDashboardSlug(primaryKey)) {
				title = 'Dashboard';
			}
			var tnorm = normalizeTitleKey(title);
			var canon = canonByTitle[tnorm];
			var storeKey = primaryKey;
			if (canon && samePluginFamily(canon, primaryKey)) {
				storeKey = canon;
			}

			var items = [];
			if (!(REDIRECT_ON && isYooDashboardSlug(primaryKey))) {
				var seen = {};
				var nodes = li.querySelectorAll('.wp-submenu li');
				for (var i = 0; i < nodes.length; i++) {
					var nli = nodes[i];
					if (isSubmenuDivider(nli)) { continue; }
					var a = nli.querySelector('a');
					if (!a || !a.href) { continue; }
					if (!isNavigableSubmenuHref(a.href)) { continue; }
					var label = getLinkLabel(a);
					if (!label) { continue; }
					var key = subItemKey(a.href, label);
					if (seen[key]) { continue; }
					seen[key] = true;

					var subBadge = extractBadgeForLi(nli);
					var badgeText = subBadge ? subBadge.value : '';

					items.push({ title: label, icon: 'dashicons-admin-links', url: a.href, badge: badgeText });
				}
			}

			if (!store[storeKey]) {
				store[storeKey] = { title: title, items: items };
			} else {
				var seenMerge = new Set((store[storeKey].items || []).map(function (it) { return it.url; }));
				for (var k = 0; k < items.length; k++) { if (!seenMerge.has(items[k].url)) { store[storeKey].items.push(items[k]); } }
				if (title && !store[storeKey].title) { store[storeKey].title = title; }
			}

			var aliasByHref = {
				'edit.php': 'posts',
				'upload.php': 'media',
				'plugins.php': 'plugins',
				'users.php': 'users',
				'edit.php?post_type=page': 'pages',
				'edit.php?post_type=product': 'wc_products'
			};
			var aliasCandidates = {};
			if (aliasByHref[hrefNorm]) { aliasCandidates[aliasByHref[hrefNorm]] = true; }
			if (page && String(page).toLowerCase() === 'yooadmin-media') {
				aliasCandidates.media = true;
			}
			if (idSlug === 'woocommerce' || page === 'wc-admin') { aliasCandidates.store = true; }

			Object.keys(aliasCandidates).forEach(function (aliasKey) {
				if (!store[aliasKey]) {
					store[aliasKey] = { title: title, items: items.slice() };
				} else {
					var seenA = new Set((store[aliasKey].items || []).map(function (it) { return it.url; }));
					for (var m = 0; m < items.length; m++) {
						if (!seenA.has(items[m].url)) { store[aliasKey].items.push(items[m]); }
					}
					if (title && !store[aliasKey].title) { store[aliasKey].title = title; }
				}
			});
		});
	}

	/* ---------- Sidebar + yoopixelMenus from PHP card tree (same source as popup) ---------- */
	function cardMenuSlugKey(s) {
		if (typeof s !== 'string' || !s) {
			return 'menu';
		}
		var k = s.toLowerCase().replace(/[^a-z0-9_.-]/gi, '_');
		return k || 'menu';
	}
	function isNetworkAdminContext() {
		return !!(document.body && document.body.classList.contains('network-admin'));
	}
	function sidebarMenuSlugFromNativeLi(li) {
		var slug = slugFromAdminLi(li);
		if (!slug) {
			return '';
		}
		if (!isNetworkAdminContext()) {
			return slug;
		}
		var page = getQS(slug, 'page');
		if (page) {
			return page;
		}
		var fileMatch = String(slug).match(/([a-z0-9_.-]+\.php)(?:\?.*)?$/i);
		if (fileMatch) {
			return fileMatch[1].toLowerCase();
		}
		return cardMenuSlugKey(slug);
	}
	function fillYpsSubFromCardSubs(ypsItem, subs) {
		if (!ypsItem || !subs || !subs.length) {
			return;
		}
		var ul = ypsItem.querySelector('.yps-sub');
		if (ul && ul.querySelectorAll('.yps-sub-link').length) {
			return;
		}
		var subId = 'yps-sub-auto-' + Math.random().toString(36).slice(2);
		if (!ul) {
			ypsItem.classList.add('has-sub');
			var rowEl = ypsItem.querySelector('.yps-row');
			if (rowEl && !rowEl.querySelector('.yps-expander')) {
				var btn = document.createElement('button');
				btn.type = 'button';
				btn.className = 'yps-expander';
				btn.setAttribute('aria-controls', subId);
				btn.setAttribute('aria-expanded', 'false');
				btn.innerHTML = '<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>';
				rowEl.appendChild(btn);
			}
			ul = document.createElement('ul');
			ul.id = subId;
			ul.className = 'yps-sub';
			ul.hidden = true;
			ypsItem.appendChild(ul);
		}
		var seen = {};
		var si = 0;
		for (si = 0; si < subs.length; si++) {
			var sub = subs[si];
			if (!sub) {
				continue;
			}
			var label = sub.title || '';
			var href = sub.url || '';
			if (!label || !href || !isNavigableSubmenuHref(href)) {
				continue;
			}
			var key = subItemKey(href, label);
			if (seen[key]) {
				continue;
			}
			seen[key] = true;
			var li2 = document.createElement('li');
			li2.className = 'yps-sub-item';
			var a2 = document.createElement('a');
			a2.className = 'yps-sub-link';
			a2.href = href;
			a2.innerHTML = '<span class="yps-text"></span>';
			a2.querySelector('.yps-text').textContent = label;
			ul.appendChild(li2).appendChild(a2);
		}
		if (!ul.querySelector('.yps-sub-link')) {
			ypsItem.classList.remove('has-sub');
			var exp = ypsItem.querySelector('.yps-expander');
			if (exp) {
				exp.remove();
			}
			ul.remove();
		}
	}
	function mergeCardSubsIntoSidebar() {
		var card = window.yooadmCardMenus;
		var nav = document.querySelector('#yps-sidebar .yps-nav');
		if (!card || !Array.isArray(card.items) || !nav) {
			return;
		}
		var ii = 0;
		for (ii = 0; ii < card.items.length; ii++) {
			var it = card.items[ii];
			if (!it || !it.slug || !it.subs || !it.subs.length) {
				continue;
			}
			if (REDIRECT_ON && isYooDashboardSlug(String(it.slug))) {
				continue;
			}
			var keys = [cardMenuSlugKey(it.slug), String(it.slug)];
			var link = null;
			var ki = 0;
			for (ki = 0; ki < keys.length; ki++) {
				link = nav.querySelector('.yps-link[data-menu-slug="' + cssEscape(keys[ki]) + '"]');
				if (link) {
					break;
				}
			}
			if (!link) {
				continue;
			}
			var item = link.closest('.yps-item');
			if (!item) {
				continue;
			}
			fillYpsSubFromCardSubs(item, it.subs);
		}
	}
	function findNativeTopLiBySlug(admin, slug) {
		if (!admin || !slug) {
			return null;
		}
		var s = String(slug);
		var candidates = [];
		if (s.indexOf('elementor') !== -1) {
			candidates.push('elementor');
			candidates.push('elementor-home');
		}
		candidates.push(s);
		var ci = 0;
		for (ci = 0; ci < candidates.length; ci++) {
			try {
				var el = admin.querySelector('#toplevel_page_' + cssEscape(candidates[ci]));
				if (el) {
					return el;
				}
			} catch (e) {}
		}
		try {
			var m = admin.querySelector('a.menu-top[href*="page=' + cssEscape(s) + '"]');
			if (m) {
				return m.closest('li.menu-top');
			}
		} catch (e2) {}
		return null;
	}
	function feedYoopixelMenusFromCardMenus() {
		var card = window.yooadmCardMenus;
		if (!card || !Array.isArray(card.items) || !card.items.length) {
			return false;
		}
		var store = (window.yoopixelMenus = window.yoopixelMenus || {});
		var ii = 0;
		for (ii = 0; ii < card.items.length; ii++) {
			var it = card.items[ii];
			if (!it || !it.slug) {
				continue;
			}
			var title = it.title || 'Menu';
			var primaryKey = String(it.slug);
			if (REDIRECT_ON && isYooDashboardSlug(primaryKey)) {
				title = 'Dashboard';
			}
			var items = [];
			if (!(REDIRECT_ON && isYooDashboardSlug(primaryKey)) && it.subs && it.subs.length) {
				var seen = {};
				var si = 0;
				for (si = 0; si < it.subs.length; si++) {
					var s = it.subs[si];
					if (!s) {
						continue;
					}
					var label = s.title || '';
					var url = s.url || '';
					if (!label || !url) {
						continue;
					}
					if (!isNavigableSubmenuHref(url)) {
						continue;
					}
					var key = subItemKey(url, label);
					if (seen[key]) {
						continue;
					}
					seen[key] = true;
					items.push({
						title: label,
						icon: 'dashicons-admin-links',
						url: url,
						badge: (s.badge && String(s.badge).trim() !== '0') ? String(s.badge).trim() : '',
						badge_kind: (typeof s.badge_kind === 'string') ? s.badge_kind : ''
					});
				}
			}
			var storeKey = cardMenuSlugKey(it.slug || it.title || '');
			store[storeKey] = { title: title, items: items };

			var hrefNorm = normURL(it.url || '');
			var page = getQS(it.url || '', 'page');
			var idSlug = '';
			if (primaryKey.indexOf('.php') === -1 && primaryKey.indexOf('http') !== 0) {
				idSlug = primaryKey;
			}
			var aliasByHref = {
				'edit.php': 'posts',
				'upload.php': 'media',
				'plugins.php': 'plugins',
				'users.php': 'users',
				'edit.php?post_type=page': 'pages',
				'edit.php?post_type=product': 'wc_products'
			};
			var aliasCandidates = {};
			if (aliasByHref[hrefNorm]) {
				aliasCandidates[aliasByHref[hrefNorm]] = true;
			}
			if (page && String(page).toLowerCase() === 'yooadmin-media') {
				aliasCandidates.media = true;
			}
			if (idSlug === 'woocommerce' || page === 'wc-admin') {
				aliasCandidates.store = true;
			}
			Object.keys(aliasCandidates).forEach(function (aliasKey) {
				if (!store[aliasKey]) {
					store[aliasKey] = { title: title, items: items.slice() };
				} else {
					var seenA = new Set((store[aliasKey].items || []).map(function (x) { return x.url; }));
					var m = 0;
					for (m = 0; m < items.length; m++) {
						if (!seenA.has(items[m].url)) {
							store[aliasKey].items.push(items[m]);
						}
					}
					if (title && !store[aliasKey].title) {
						store[aliasKey].title = title;
					}
				}
			});
		}
		return true;
	}
	function appendItemFromCardMenu(it) {
		var nav = document.querySelector('#yps-sidebar .yps-nav');
		if (!nav || !it) {
			return;
		}
		var slug = String(it.slug || '');
		if (!slug) {
			return;
		}
		var menuSlugAttr = slug;
		if (document.querySelector('.yps-link[data-menu-slug="' + cssEscape(menuSlugAttr) + '"]')) {
			return;
		}

		var name    = cleanMenuTitle(it.title || '');
		var topHref = it.url || '#';
		var hasSub  = !!(it.subs && it.subs.length);
		if (REDIRECT_ON && isYooDashboardSlug(slug)) {
			name = 'Dashboard';
			hasSub = false;
		}
		// Resolve dashicon class from PHP data (used as initial icon before hydration)
		var phpIconClass = (typeof it.icon === 'string' && it.icon.indexOf('dashicons-') === 0) ? it.icon : '';

		var subId = 'yps-sub-auto-' + Math.random().toString(36).slice(2);
		var li = document.createElement('li');
		li.className = 'yps-item' + (hasSub ? ' has-sub' : '');

		var row = document.createElement('div');
		row.className = 'yps-row';

		var a = document.createElement('a');
		a.className = 'yps-link';
		a.href = topHref;
		a.setAttribute('data-menu-slug', menuSlugAttr);
		// Mark as card-menu origin so hydrateExistingFromNative skips title override
		a.setAttribute('data-built-from', 'cards');
		a.innerHTML =
			'<span class="yps-wp-icon-proxy"><span class="wp-menu-image dashicons-before' +
			(phpIconClass ? ' ' + phpIconClass : '') +
			'" aria-hidden="true"></span></span>' +
			'<span class="yps-text"></span>';
		a.querySelector('.yps-text').textContent = name;
		row.appendChild(a);

		if (hasSub) {
			var btn = document.createElement('button');
			btn.type = 'button';
			btn.className = 'yps-expander';
			btn.setAttribute('aria-controls', subId);
			btn.setAttribute('aria-expanded', 'false');
			btn.innerHTML = '<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>';
			row.appendChild(btn);
		}

		li.appendChild(row);

		if (hasSub) {
			var ul = document.createElement('ul');
			ul.id = subId;
			ul.className = 'yps-sub';
			ul.hidden = true;
			var seen = {};
			var sj = 0;
			for (sj = 0; sj < it.subs.length; sj++) {
				var sub = it.subs[sj];
				if (!sub) {
					continue;
				}
				var label = sub.title || '';
				var href = sub.url || '';
				if (!label || !href) {
					continue;
				}
				if (!isNavigableSubmenuHref(href)) {
					continue;
				}
				var skey = subItemKey(href, label);
				if (seen[skey]) {
					continue;
				}
				seen[skey] = true;
				var li2 = document.createElement('li');
				li2.className = 'yps-sub-item';
				var a2 = document.createElement('a');
				a2.className = 'yps-sub-link';
				a2.href = href;
				a2.innerHTML = '<span class="yps-text"></span>';
				a2.querySelector('.yps-text').textContent = label;
				var subBadgeVal = sub.badge && String(sub.badge).trim();
				if (subBadgeVal && subBadgeVal !== '0') {
					var subKind = sub.badge_kind === 'comments' ? 'comments' : 'updates';
					injectBadgeIntoLink(a2, { value: subBadgeVal, kind: subKind });
				}
				ul.appendChild(li2).appendChild(a2);
			}
			li.appendChild(ul);
		}

		nav.appendChild(li);
	}
	function buildSidebarFromCardMenus() {
		var nav = document.querySelector('#yps-sidebar .yps-nav');
		var card = window.yooadmCardMenus;
		if (!nav || !card || !Array.isArray(card.items) || !card.items.length) {
			return false;
		}
		nav.innerHTML = '';
		var i = 0;
		for (i = 0; i < card.items.length; i++) {
			appendItemFromCardMenu(card.items[i]);
		}
		return true;
	}

	function syncFromNative() {
		var admin = document.getElementById('adminmenu');
		var nav = document.querySelector('#yps-sidebar .yps-nav');

		if (!admin || !nav) {
			return;
		}

		/* Popup store: card tree (dashboard tiles) then native #adminmenu — not used to paint sidebar HTML. */
		feedYoopixelMenusFromCardMenus();
		feedYoopixelMenus();

		/* Sidebar: mirror #adminmenu top-level order and real .wp-submenu only (avoids duplicating YOO vs card HTML). */
		nav.innerHTML = '';
		addMissingFromNative();
		hydrateExistingFromNative();
		mergeCardSubsIntoSidebar();
		forceDashboardLabel();
	}

	function forceDashboardLabel() {
		if (!REDIRECT_ON) {
			return;
		}
		try {
			var link = document.querySelector('#yps-sidebar .yps-link[data-menu-slug="' + cssEscape(DASH_SLUG) + '"]');
			if (!link) {
				return;
			}
			var textEl = link.querySelector('.yps-text');
			if (textEl && textEl.textContent.trim() !== 'Dashboard') {
				textEl.textContent = 'Dashboard';
			}
			var admin = document.getElementById('adminmenu');
			if (admin) {
				var nativeTop = admin.querySelector('a.menu-top[href*="page=' + cssEscape(DASH_SLUG) + '"]');
				if (nativeTop) {
					var nativeLi = nativeTop.closest('li');
					var badge = extractBadgeForLi(nativeLi);
					if (badge) {
						injectBadgeIntoLink(link, badge);
					}
				}
			}
			var item = link.closest('.yps-item');
			if (item) {
				item.classList.remove('has-sub', 'is-open');
				var sub = item.querySelector('.yps-sub');
				var exp = item.querySelector('.yps-expander');
				if (sub) {
					sub.remove();
				}
				if (exp) {
					exp.remove();
				}
			}
		} catch (e) {}
	}

	function observeAndEnforce() {
		if (!REDIRECT_ON) {
			return;
		}
		var targetSidebar = document.querySelector('#yps-sidebar');
		var targetAdmin = document.getElementById('adminmenu');
		var opts = { childList: true };
		var t = null;
		function handler() {
			clearTimeout(t);
			t = setTimeout(forceDashboardLabel, 100);
		}
		try {
			if (window.__YPOBs) {
				return;
			}
			window.__YPOBs = {
				sidebar: targetSidebar ? new MutationObserver(handler) : null,
				admin: targetAdmin ? new MutationObserver(handler) : null
			};
			if (window.__YPOBs.sidebar) {
				window.__YPOBs.sidebar.observe(targetSidebar, opts);
			}
			if (window.__YPOBs.admin) {
				window.__YPOBs.admin.observe(targetAdmin, opts);
			}
		} catch (e) {}
	}

	/* ---------- Auto-open submenu and mark active page ---------- */

	// Map custom YOOAdmin pages to their "native" WP targets for active state
	// Keys and values are normalized as used by normalizePathForActive().
	var ACTIVE_ALIASES = {
		// Users hub
		'admin.php?page=yooadmin-users': 'users.php',
		// Posts hub
		'admin.php?page=yooadmin-posts': 'edit.php',
		'admin.php?page=yooadmin-comments': 'edit-comments.php',
		// Pages hub
		'admin.php?page=yooadmin-pages': 'edit.php?post_type=page',
		// Categories hub
		'admin.php?page=yooadmin-categories': 'edit-tags.php?taxonomy=category',
		// Plugins page (unified)
		'admin.php?page=yooadmin-plugins': 'plugins.php',
	};

	function normalizePathForActive(href) {
		if (!href) { return ''; }
		try {
			var u = new URL(href, window.location.origin);
			// Strip leading slash and optional wp-admin/ prefix
			var path = (u.pathname || '').replace(/^\/+/, '').replace(/^wp-admin\//i, '');
			if (u.search) { path += u.search; }
			return path.toLowerCase();
		} catch (e) {
			return String(href || '')
				.replace(/^\/+/, '')
				.replace(/^wp-admin\//i, '')
				.toLowerCase();
		}
	}

	function markActivePage() {
		var currentURL = window.location.href;
		var rawCurrentPath = window.location.pathname + window.location.search;
		var currentPath = normalizePathForActive(rawCurrentPath);

		// If current path is a custom yooadmin page, also treat its mapped
		// "native" target as active (e.g. yooadmin-users => users.php).
		var aliasTarget = ACTIVE_ALIASES[currentPath] || '';
		if (REDIRECT_ON) {
			var ds = DASH_SLUG.toLowerCase();
			if (currentPath === 'admin.php?page=' + ds || currentPath === 'index.php?page=' + ds) {
				aliasTarget = 'index.php';
			}
		}

		// Find active main link
		var links = document.querySelectorAll('#yps-sidebar .yps-link');
		for (var i = 0; i < links.length; i++) {
			var link = links[i];
			try {
				var linkURL = new URL(link.href, window.location.origin);
				var linkPath = normalizePathForActive(linkURL.pathname + linkURL.search);
				
				if (currentPath === linkPath || (aliasTarget && aliasTarget === linkPath) || currentURL === link.href) {
					var item = link.closest('.yps-item');
					if (item) {
						item.classList.add('is-active');
					}
				}
			} catch (e) {}
		}
		
		// Find active submenu link and open parent
		var subLinks = document.querySelectorAll('#yps-sidebar .yps-sub-link');
		for (var j = 0; j < subLinks.length; j++) {
			var subLink = subLinks[j];
			try {
				var subURL = new URL(subLink.href, window.location.origin);
				var subPath = normalizePathForActive(subURL.pathname + subURL.search);
				
				if (currentPath === subPath || (aliasTarget && aliasTarget === subPath) || currentURL === subLink.href) {
					subLink.classList.add('is-active');

					var nestedEl = subLink.parentElement;
					while (nestedEl && nestedEl.id !== 'yps-sidebar') {
						if (nestedEl.classList && nestedEl.classList.contains('yps-sub-item') && nestedEl.classList.contains('has-nested')) {
							nestedEl.classList.add('is-open');
							var nestedUl = nestedEl.querySelector(':scope > ul.yps-sub--nested');
							var nestedExp = nestedEl.querySelector('.yps-nested-expander');
							if (nestedUl) { nestedUl.hidden = false; }
							if (nestedExp) { nestedExp.setAttribute('aria-expanded', 'true'); }
						}
						nestedEl = nestedEl.parentElement;
					}

					// Open parent submenu
					var parentItem = subLink.closest('.yps-item');
					if (parentItem && parentItem.classList.contains('has-sub')) {
						parentItem.classList.add('is-open');
						var submenu = parentItem.querySelector('.yps-sub');
						var expander = parentItem.querySelector('.yps-expander');
						if (submenu) {
							submenu.hidden = false;
						}
						if (expander) {
							expander.setAttribute('aria-expanded', 'true');
						}

						// Scroll to active item smoothly
						setTimeout(function() {
							if (subLink.scrollIntoView) {
								subLink.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
							}
						}, 300);
					}
					break;
				}
			} catch (e) {}
		}
	}

	// ---------------- Sidebar menu toggle (like old system) ----------------
	function bindSidebar() {
		var sidebar = document.getElementById('yps-sidebar');
		var toggle = document.getElementById('yps-toggle-btn');
		var overlay = document.querySelector('.yps-overlay');
		if (!sidebar || !toggle || !overlay) return false;
		if (toggle.dataset.bound === '1') return true;

		function syncSidebarOpenBodyClass() {
			if (!document.body) {
				return;
			}
			document.body.classList.toggle('yp-yps-sidebar-open', sidebar.classList.contains('is-open'));
		}

		function openMenu() {
			sidebar.classList.add('is-open');
			sidebar.setAttribute('aria-hidden', 'false');
			overlay.hidden = false;
			toggle.setAttribute('aria-expanded', 'true');
			document.documentElement.style.overflow = 'hidden';
			syncSidebarOpenBodyClass();
		}
		function closeMenu() {
			sidebar.classList.remove('is-open');
			sidebar.setAttribute('aria-hidden', 'true');
			overlay.hidden = true;
			toggle.setAttribute('aria-expanded', 'false');
			document.documentElement.style.overflow = '';
			syncSidebarOpenBodyClass();
		}

		var handler = function (e) {
			e.preventDefault();
			e.stopPropagation();
			var expanded = toggle.getAttribute('aria-expanded') === 'true';
			expanded ? closeMenu() : openMenu();
		};
		toggle.addEventListener('click', handler, { capture: true });

		document.querySelectorAll('[data-yps-close]').forEach(function(el) {
			el.addEventListener('click', closeMenu, { capture: true });
		});
		overlay.addEventListener('click', closeMenu, { capture: true });
		document.addEventListener('keydown', function(e) { 
			if (e.key === 'Escape') closeMenu(); 
		}, { capture: true });

		toggle.dataset.bound = '1';
		return true;
	}

	// ---------------- Accordion for sidebar sub-menus ----------------
	function bindAccordion() {
		var nav = document.querySelector('#yps-sidebar .yps-nav');
		if (!nav) { return; }
		if (nav.dataset.accordionBound === '1') { return; }

		function toggleItem(item, controlEl) {
			if (!item || !item.classList.contains('has-sub')) { return; }
			var sub = item.querySelector('.yps-sub');
			var isOpen = item.classList.toggle('is-open');
			if (sub) {
				sub.hidden = !isOpen;
			}
			if (controlEl && controlEl.setAttribute) {
				controlEl.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
			}
		}

		nav.addEventListener('click', function (e) {
			var nestedBtn = e.target.closest('.yps-nested-expander');
			if (nestedBtn) {
				e.preventDefault();
				e.stopPropagation();
				var subItem = nestedBtn.closest('.yps-sub-item.has-nested');
				if (!subItem) { return; }
				var nestedSub = subItem.querySelector(':scope > ul.yps-sub--nested');
				var isNOpen = subItem.classList.toggle('is-open');
				if (nestedSub) {
					nestedSub.hidden = !isNOpen;
				}
				nestedBtn.setAttribute('aria-expanded', isNOpen ? 'true' : 'false');
				return;
			}

			var btn = e.target.closest('.yps-expander');
			var link = e.target.closest('.yps-link');

			// Click on arrow button
			if (btn) {
				e.preventDefault();
				e.stopPropagation();
				var itemFromBtn = btn.closest('.yps-item');
				toggleItem(itemFromBtn, btn);
				return;
			}

			// Click on main menu label when it has sub items:
			// prevent navigation (so it doesn't "inherit" first submenu link)
			// and just toggle accordion.
			if (link) {
				var itemFromLink = link.closest('.yps-item');
				if (itemFromLink && itemFromLink.classList.contains('has-sub')) {
					e.preventDefault();
					e.stopPropagation();
					var expander = itemFromLink.querySelector('.yps-expander');
					toggleItem(itemFromLink, expander);
				}
			}
		}, { capture: true });

		nav.dataset.accordionBound = '1';
	}

	// Try to bind sidebar toggle
	var sidebarBound = bindSidebar();
	if (!sidebarBound) {
		// Retry a few times if DOM is late
		var attempts = 0;
		var sidebarInterval = setInterval(function() {
			attempts++;
			sidebarBound = bindSidebar();
			if (sidebarBound || attempts > 30) clearInterval(sidebarInterval);
		}, 200);
	}

	function initSync() {
		var tries = 0;
		(function tick() {
			var admin = document.getElementById('adminmenu');
			var nav = document.querySelector('#yps-sidebar .yps-nav');
			var sidebar = document.querySelector('#yps-sidebar');
			
			if (admin && nav) {
				syncFromNative();
				bindAccordion();
				setTimeout(forceDashboardLabel, 0);
				setTimeout(forceDashboardLabel, 250);
				observeAndEnforce();
				setTimeout(markActivePage, 300);
				return;
			}
			if (++tries < 20) { setTimeout(tick, 150); }
		})();
	}

	// Diagnostic function for sidebar (disabled for production)
	function diagnosticCheckSidebar() {
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function() {
			initSync();
			setTimeout(diagnosticCheckSidebar, 1500);
		});
	} else {
		initSync();
		setTimeout(diagnosticCheckSidebar, 1500);
	}
})();
