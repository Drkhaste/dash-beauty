/**
 * YOOAdmin — read-only license status modal (non-admin shell users).
 */
(function ($) {
  'use strict';

  if (window.__YOOAdminLicenseStatusInfoInit) {
    return;
  }
  window.__YOOAdminLicenseStatusInfoInit = true;

  var cfg = window.yooadmLicenseStatusInfo || {};
  var closeLabel = cfg.close || 'Close';

  function openModal($trigger) {
    var $modal = $('#yp-license-status-info-modal');
    if (!$modal.length) {
      return;
    }

    $modal.find('.yp-modal-title').text($trigger.attr('data-modal-title') || '');
    $modal.find('.yp-modal-details').text($trigger.attr('data-modal-message') || '');

    var icon = $trigger.attr('data-modal-icon') || 'dashicons-info';
    var type = $trigger.attr('data-modal-type') || 'info';
    $modal
      .find('.yp-modal-icon')
      .attr('class', 'dashicons yp-modal-icon yp-modal-icon--' + type + ' ' + icon);

    $modal.css('display', 'flex').hide().fadeIn(180);
    $('body').addClass('yp-modal-open');

    var $close = $modal.find('.yp-modal-close, .yp-modal-close-info, .yp-modal-overlay');
    $close.off('click.yooLicenseStatusInfo').on('click.yooLicenseStatusInfo', function () {
      $modal.fadeOut(150, function () {
        $modal.css('display', 'none');
        $('body').removeClass('yp-modal-open');
      });
    });
  }

  $(document).on('click', '[data-yooadmin-license-status-modal]', function (event) {
    event.preventDefault();
    openModal($(this));
  });

  $(document).on('keydown', function (event) {
    if (event.key !== 'Escape') {
      return;
    }
    var $modal = $('#yp-license-status-info-modal');
    if ($modal.length && $modal.is(':visible')) {
      $modal.find('.yp-modal-close').trigger('click');
    }
  });
})(jQuery);
