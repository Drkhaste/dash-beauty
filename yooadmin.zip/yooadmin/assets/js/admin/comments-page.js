/**
 * YOOAdmin - Comments page script (aligned with posts-page.js)
 *
 * @package YOOAdmin
 */

(function ($) {
    'use strict';

    var cfg = window.yooadmComments || {};
    var i18n = cfg.i18n || {};
    var state = {
        commentStatus: '',
        search: '',
        paged: 1,
        perPage: (cfg.screenOptions && cfg.screenOptions.perPage) || 20,
        view: (cfg.screenOptions && cfg.screenOptions.view) || 'list',
        loading: false,
    };

    function t(key, fallback) {
        return i18n[key] || fallback;
    }

    function showNotice(type, message) {
        if (window.yooadminShowToast && typeof window.yooadminShowToast === 'function') {
            window.yooadminShowToast(message, type);
            return;
        }
        if (window.yooadminListScreenToast && typeof window.yooadminListScreenToast.show === 'function') {
            window.yooadminListScreenToast.show(type, message);
            return;
        }
        if (type === 'error') {
            window.alert(message);
        }
    }

    function getActiveStatus() {
        var $active = $('.yooadmin-comments-page .yoo-posts-filters .yoo-filter-chip.is-active');
        return $active.length ? String($active.data('status') || '') : '';
    }

    function updateCounts(counts) {
        if (!counts) {
            return;
        }
        $('.yooadmin-comments-page [data-count]').each(function () {
            var key = $(this).data('count');
            if (counts[key] !== undefined) {
                $(this).text(Number(counts[key]).toLocaleString());
            }
        });
        var deleteAll = document.getElementById('yoo-comments-delete-all');
        if (deleteAll) {
            deleteAll.disabled = !counts.all;
        }
        cfg.totalComments = counts.all || 0;
    }

    function pushUrl() {
        if (!window.history || !window.history.replaceState) {
            return;
        }
        var url = new URL(cfg.listUrl || window.location.href);
        url.searchParams.delete('comment_status');
        url.searchParams.delete('s');
        url.searchParams.delete('paged');
        if (state.commentStatus) {
            url.searchParams.set('comment_status', state.commentStatus);
        }
        if (state.search) {
            url.searchParams.set('s', state.search);
        }
        if (state.paged > 1) {
            url.searchParams.set('paged', String(state.paged));
        }
        window.history.replaceState({}, '', url.toString());
    }

    function applyViewMode(view) {
        view = view || state.view || 'list';
        var $feed = $('.yooadmin-comments-page .yoo-comments-feed');
        $feed.removeClass('yoo-comments-view-list yoo-comments-view-excerpt');
        $feed.addClass(view === 'excerpt' ? 'yoo-comments-view-excerpt' : 'yoo-comments-view-list');
    }

    function applyColumnVisibility(hiddenCols) {
        hiddenCols = hiddenCols || [];
        $('.yooadmin-comments-page .yoo-comments-feed [data-col]').each(function () {
            var col = $(this).data('col');
            $(this).toggleClass('column-hidden', hiddenCols.indexOf(col) !== -1);
        });
    }

    function updateBulkBar() {
        var selected = $('.yoo-comment-checkbox:checked').length;
        var $bulkBar = $('.yooadmin-comments-page .yoo-bulk-actions-bar');
        var $selectedCount = $('.yooadmin-comments-page .yoo-selected-count');
        var $bulkApply = $('#yoo-comments-bulk-apply');
        var $bulkSelect = $('#yoo-comments-bulk-select');

        if (selected > 0) {
            $bulkBar.addClass('show');
            $selectedCount.text(selected + ' ' + (t('selected', 'selected')));
            $bulkApply.prop('disabled', !$bulkSelect.val());
        } else {
            $bulkBar.removeClass('show');
            $('#yoo-comments-select-all').prop('checked', false);
        }
    }

    function syncThreadCheckboxes($rootCheckbox) {
        var $card = $rootCheckbox.closest('.yoo-comment-card');
        if (!$card.length) {
            return;
        }
        var checked = $rootCheckbox.prop('checked');
        $card.find('.yoo-chat-thread__replies .yoo-comment-checkbox').prop('checked', checked);
    }

    function initCheckboxes() {
        $('.yoo-comment-checkbox').off('change.bulk').on('change.bulk', function () {
            if ($(this).closest('.yoo-comment-card__select').length) {
                syncThreadCheckboxes($(this));
            }
            updateBulkBar();
        });
    }

    function applyFilters(options) {
        options = options || {};
        if (typeof options.commentStatus !== 'undefined') {
            state.commentStatus = options.commentStatus;
        } else {
            state.commentStatus = getActiveStatus();
        }
        if (typeof options.search !== 'undefined') {
            state.search = options.search;
        } else {
            state.search = $('#yoo-comments-search-input').val() || '';
        }
        if (typeof options.paged !== 'undefined') {
            state.paged = Math.max(1, parseInt(options.paged, 10) || 1);
        }

        if (state.loading) {
            return;
        }
        syncCommentsListingStatus();
        state.loading = true;
        $('#yoo-comments-content').addClass('is-loading');

        $.ajax({
            url: cfg.ajaxUrl,
            type: 'POST',
            data: {
                action: 'yooadmin_filter_comments',
                nonce: cfg.nonce,
                comment_status: state.commentStatus,
                s: state.search,
                paged: state.paged,
                per_page: state.perPage,
            },
        })
            .done(function (res) {
                if (!res || !res.success) {
                    showNotice('error', (res && res.data && res.data.message) || t('error', 'An error occurred.'));
                    return;
                }
                var data = res.data || {};
                $('#the-comment-list').html(data.table_html || '');
                syncCommentsListingStatus();
                $('#yoo-comments-pagination-wrap').html(data.pagination_html || '');
                updateCounts(data.counts);
                initCheckboxes();
                updateBulkBar();
                applyViewMode();
                initListScreenUi();
                if (data.hidden) {
                    applyColumnVisibility(data.hidden);
                }
                if (!options.silentUrl) {
                    pushUrl();
                }
            })
            .fail(function () {
                showNotice('error', t('error', 'An error occurred.'));
            })
            .always(function () {
                state.loading = false;
                $('#yoo-comments-content').removeClass('is-loading');
            });
    }

    window.yooadmApplyCommentsFilters = applyFilters;

    function confirmAction(opts) {
        if (typeof window.yooadminConfirm === 'function') {
            return window.yooadminConfirm({
                title: opts.title,
                message: opts.message,
                confirmText: opts.confirmText,
                cancelText: opts.cancelText || t('cancel', 'Cancel'),
                variant: opts.variant || (opts.type === 'danger' ? 'danger' : 'default'),
                compact: true,
                useYooButtons: true,
            });
        }
        return Promise.resolve(window.confirm(opts.message || opts.title));
    }

    function runCommentAction(commentId, action) {
        return $.ajax({
            url: cfg.ajaxUrl,
            type: 'POST',
            data: {
                action: 'yooadmin_comments_action',
                nonce: cfg.nonce,
                comment_id: commentId,
                comment_action: action,
            },
        });
    }

    function refreshCommentsList() {
        applyFilters({ silentUrl: true });
    }

    function getCommentPreview($row) {
        var text = $row.find('.yoo-chat-bubble').text() || $row.find('.yoo-comment-content').text() || '';
        text = text.replace(/\s+/g, ' ').trim();
        if (!text) {
            return t('thisComment', 'this comment');
        }
        return text.length > 80 ? text.substring(0, 80) + '…' : text;
    }

    function showCommentActionPopup($trigger, commentId, action) {
        var meta = {
            approve: {
                title: t('approveTitle', 'Approve comment?'),
                confirm: t('approve', 'Approve'),
                success: t('commentApproved', 'Comment approved.'),
                danger: false,
            },
            unapprove: {
                title: t('unapproveTitle', 'Unapprove comment?'),
                confirm: t('unapprove', 'Unapprove'),
                success: t('commentUnapproved', 'Comment unapproved.'),
                danger: false,
            },
            spam: {
                title: t('spamTitle', 'Mark as spam?'),
                confirm: t('spam', 'Spam'),
                success: t('commentSpammed', 'Comment marked as spam.'),
                danger: false,
            },
            trash: {
                title: t('trashTitle', 'Move to trash?'),
                confirm: t('trash', 'Trash'),
                success: t('commentTrashed', 'Comment moved to trash.'),
                danger: false,
            },
            untrash: {
                title: t('restoreTitle', 'Restore comment?'),
                confirm: t('restore', 'Restore'),
                success: t('commentRestored', 'Comment restored.'),
                danger: false,
            },
            unspam: {
                title: t('restoreTitle', 'Restore comment?'),
                confirm: t('restore', 'Restore'),
                success: t('commentRestored', 'Comment restored.'),
                danger: false,
            },
            delete: {
                title: t('deleteTitle', 'Delete permanently?'),
                confirm: t('delete', 'Delete Permanently'),
                success: t('commentDeleted', 'Comment deleted.'),
                danger: true,
            },
        };

        var info = meta[action];
        if (!info) {
            return;
        }

        var $row = $trigger.closest('.yoo-chat-msg, .yoo-comment-card');
        var preview = getCommentPreview($row);

        confirmAction({
            title: info.title,
            message: preview,
            confirmText: info.confirm,
            variant: info.danger ? 'danger' : 'default',
        }).then(function (ok) {
            if (!ok) {
                return;
            }
            runCommentAction(commentId, action)
                .done(function (res) {
                    if (!res || !res.success) {
                        showNotice('error', t('error', 'An error occurred.'));
                        return;
                    }
                    showNotice('success', info.success);
                    updateCounts(res.data.counts);
                    refreshCommentsList();
                })
                .fail(function () {
                    showNotice('error', t('error', 'An error occurred.'));
                });
        });
    }

    function handleRowAction(e) {
        e.preventDefault();
        e.stopPropagation();
        var $link = $(e.currentTarget);
        var action = $link.data('action');
        var id = parseInt($link.data('comment-id'), 10);
        if (!id || !action) {
            return;
        }
        showCommentActionPopup($link, id, action);
    }

    function handleBulkApply() {
        var action = $('#yoo-comments-bulk-select').val();
        if (!action) {
            return;
        }
        var ids = $('.yoo-comment-checkbox:checked')
            .map(function () {
                return parseInt($(this).val(), 10);
            })
            .get()
            .filter(Boolean);

        if (!ids.length) {
            return;
        }

        $.ajax({
            url: cfg.ajaxUrl,
            type: 'POST',
            data: {
                action: 'yooadmin_bulk_comments_action',
                nonce: cfg.nonce,
                bulk_action: action,
                comment_ids: ids,
            },
        }).done(function (res) {
            if (!res || !res.success) {
                showNotice('error', t('error', 'An error occurred.'));
                return;
            }
            var updated = res.data.updated || 0;
            showNotice(
                'success',
                t('bulkDone', '%d comments updated.').replace('%d', String(updated)) ||
                    updated + ' ' + t('success', 'updated')
            );
            updateCounts(res.data.counts);
            $('#yoo-comments-bulk-select').val('');
            updateBulkBar();
            refreshCommentsList();
        });
    }

    function initFilters() {
        $('.yooadmin-comments-page .yoo-posts-filters').on('click', '.yoo-filter-chip', function (e) {
            e.preventDefault();
            var status = String($(this).data('status') || '');
            $('.yooadmin-comments-page .yoo-filter-chip').removeClass('is-active');
            $(this).addClass('is-active');
            applyFilters({ commentStatus: status, paged: 1 });
        });

        var searchTimeout;
        $('#yoo-comments-search-input').on('keyup input search', function () {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(function () {
                applyFilters({ paged: 1 });
            }, 500);
        });

        $('#yoo-comments-pagination-wrap').on('click', 'button[data-paged]', function (e) {
            e.preventDefault();
            applyFilters({ paged: parseInt($(this).data('paged'), 10) || 1 });
        });
    }

    function initBulk() {
        $('#yoo-comments-select-all').on('change', function () {
            var checked = $(this).prop('checked');
            $('.yoo-comment-checkbox').prop('checked', checked);
            updateBulkBar();
        });

        $('#yoo-comments-bulk-select').on('change', function () {
            $('#yoo-comments-bulk-apply').prop('disabled', !$(this).val());
        });

        $('#yoo-comments-bulk-apply').on('click', handleBulkApply);
        initCheckboxes();
        updateBulkBar();
    }

    function initRowActions() {
        $(document).on('click', '.yooadmin-comments-page .yoo-action-link[data-action]', handleRowAction);
    }

    function initMetricsToggle() {
        var $toggle = $('.yooadmin-comments-page .yoo-posts-metrics-toggle');
        var $metrics = $('.yooadmin-comments-page .yoo-posts-hero__metrics');
        var storageKey = 'yooadmin_comments_metrics_expanded';
        var isExpanded = localStorage.getItem(storageKey) === 'true';

        if (isExpanded) {
            $metrics.addClass('is-visible');
            $toggle.addClass('is-expanded').attr('aria-expanded', 'true');
            $toggle.find('span:last-child').text(t('hideStatistics', 'Hide Statistics'));
        }

        $toggle.on('click', function () {
            var open = !$metrics.hasClass('is-visible');
            $metrics.toggleClass('is-visible', open);
            $toggle.toggleClass('is-expanded', open).attr('aria-expanded', open ? 'true' : 'false');
            $toggle
                .find('span:last-child')
                .text(open ? t('hideStatistics', 'Hide Statistics') : t('showStatistics', 'Show Statistics'));
            localStorage.setItem(storageKey, open ? 'true' : 'false');
        });
    }

    function syncCommentsListingStatus() {
        var $status = $('#yoo-comments-listing-status');
        if ($status.length) {
            $status.val(state.commentStatus || '');
        }
    }

    function setCommentsEnabledState(enabled, options) {
        options = options || {};
        enabled = !!enabled;
        cfg.commentsEnabled = enabled;

        var $hero = $('#yoo-comments-hero-status');
        var $heroToggle = $('#yoo-comments-hero-enabled');
        var $modalToggle = document.getElementById('yoo-comments-enabled-toggle');

        if ($hero.length) {
            $hero
                .toggleClass('is-on', enabled)
                .toggleClass('is-off', !enabled)
                .attr('data-enabled', enabled ? '1' : '0');
            $hero.find('[data-status-label]').text(
                enabled ? t('commentsStatusOn', 'Enabled') : t('commentsStatusOff', 'Disabled')
            );
        }

        if ($heroToggle.length) {
            $heroToggle.prop('checked', enabled);
        }

        if ($modalToggle) {
            $modalToggle.checked = enabled;
            var note = document.querySelector('.yoo-lso-moderation-note');
            if (note) {
                updateCommentsEnabledNote(note, enabled);
            }
        }

        if (options.message) {
            showNotice('success', options.message);
        }
    }

    function persistCommentsEnabled(enabled) {
        var previous = !enabled;
        setCommentsEnabledState(enabled);

        var $hero = $('#yoo-comments-hero-status');
        var $toggle = $('#yoo-comments-hero-enabled');
        $toggle.prop('disabled', true);
        $hero.addClass('is-saving');

        return $.post(cfg.ajaxUrl, {
            action: 'yooadmin_comments_set_enabled',
            nonce: cfg.nonce,
            enabled: enabled ? '1' : '0',
        })
            .done(function (res) {
                if (!res || !res.success) {
                    setCommentsEnabledState(previous);
                    showNotice('error', (res && res.data && res.data.message) || t('error', 'An error occurred.'));
                    return;
                }
                var noticeMsg = res.data.enabled
                    ? t('commentsEnabledOn', 'Comments enabled. Existing posts can accept comments again.')
                    : t('commentsDisabledOn', 'Comments disabled and closed on existing posts.');
                setCommentsEnabledState(!!res.data.enabled, { message: noticeMsg });
            })
            .fail(function () {
                setCommentsEnabledState(previous);
                showNotice('error', t('error', 'An error occurred.'));
            })
            .always(function () {
                $toggle.prop('disabled', false);
                $hero.removeClass('is-saving');
            });
    }

    function updateCommentsEnabledNote(noteEl, enabled) {
        if (!noteEl) {
            return;
        }
        noteEl.classList.toggle('is-off', !enabled);
        noteEl.textContent = enabled
            ? t(
                  'commentsEnabledHint',
                  'Matches Settings → Discussion: new posts accept comments. Turning off also closes comments on existing content.'
              )
            : t('commentsDisabledNote', 'Comments are closed site-wide. Existing posts will not accept new comments.');
    }

    function buildScreenOptionsModal() {
        var labels = cfg.columnLabels || {};
        var columns = (cfg.screenOptions && cfg.screenOptions.columns) || [];
        var canManage = !!cfg.canManageOptions;

        var modal = document.createElement('div');
        modal.id = 'yoo-lso-modal';
        modal.className = 'yoo-lso-modal';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', 'yoo-lso-modal-title');
        modal.innerHTML =
            '<div class="yoo-lso-modal__overlay" data-yoo-lso-close></div>' +
            '<div class="yoo-lso-modal__panel">' +
            '<div class="yoo-lso-modal__header">' +
            '<div>' +
            '<p class="yoo-lso-modal__eyebrow"><span class="dashicons dashicons-screenoptions" aria-hidden="true"></span>' +
            t('lsoEyebrow', 'Display') +
            '</p>' +
            '<h2 id="yoo-lso-modal-title" class="yoo-lso-modal__title">' +
            t('screenOptions', 'Screen Options') +
            '</h2>' +
            '<p class="yoo-lso-modal__desc">' +
            t('lsoDesc', 'Choose which columns and layout options appear on this screen. Changes are saved when you apply.') +
            '</p>' +
            '</div>' +
            '<button type="button" class="yoo-lso-modal__close" data-yoo-lso-close aria-label="' +
            t('close', 'Close') +
            '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>' +
            '</div>' +
            '<div class="yoo-lso-modal__body" data-yoo-lso-body></div>' +
            '<div class="yoo-lso-modal__footer">' +
            '<p class="yoo-lso-modal__hint">' +
            t('lsoHint', 'Column, pagination, and view settings apply to this page only.') +
            '</p>' +
            '<button type="button" class="yoo-lso-modal__apply">' +
            t('apply', 'Apply') +
            '</button>' +
            '</div>' +
            '</div>';

        var body = modal.querySelector('[data-yoo-lso-body]');

        var colSection = document.createElement('div');
        colSection.className = 'yoo-lso-section yoo-lso-section--columns';
        colSection.innerHTML =
            '<h3 class="yoo-lso-section__title">' + t('columns', 'Columns') + '</h3><div class="yoo-lso-section__items"></div>';
        var colItems = colSection.querySelector('.yoo-lso-section__items');

        columns.forEach(function (col) {
            var id = 'yoo-col-' + col.id;
            var label = labels[col.id] || col.id;
            var item = document.createElement('label');
            item.className = 'yoo-lso-toggle';
            item.setAttribute('for', id);
            item.innerHTML =
                '<span class="yoo-lso-toggle__text"></span>' +
                '<input id="' +
                id +
                '" type="checkbox" role="switch" data-column="' +
                col.id +
                '">' +
                '<span class="yoo-lso-toggle__switch" aria-hidden="true"></span>';
            item.querySelector('.yoo-lso-toggle__text').textContent = label;
            item.querySelector('input').checked = col.visible !== false;
            colItems.appendChild(item);
        });
        body.appendChild(colSection);

        var pageSection = document.createElement('div');
        pageSection.className = 'yoo-lso-section yoo-lso-section--pagination';
        pageSection.innerHTML =
            '<h3 class="yoo-lso-section__title">' +
            t('pagination', 'Pagination') +
            '</h3><div class="yoo-lso-section__items"></div>';
        var pageItems = pageSection.querySelector('.yoo-lso-section__items');
        var perPageField = document.createElement('div');
        perPageField.className = 'yoo-lso-field yoo-lso-field--per-page';
        perPageField.innerHTML =
            '<span class="yoo-lso-field__label">' +
            t('itemsPerPage', 'Number of items per page') +
            '</span><input type="number" class="yoo-lso-field__input" id="yoo-comments-per-page" min="5" max="200" step="1" value="' +
            state.perPage +
            '">';
        pageItems.appendChild(perPageField);
        body.appendChild(pageSection);

        var viewSection = document.createElement('div');
        viewSection.className = 'yoo-lso-section yoo-lso-section--view-mode';
        viewSection.innerHTML =
            '<h3 class="yoo-lso-section__title">' + t('viewMode', 'View mode') + '</h3><div class="yoo-lso-section__items"></div>';
        var viewItems = viewSection.querySelector('.yoo-lso-section__items');
        var viewRadios = document.createElement('div');
        viewRadios.className = 'yoo-lso-radios yoo-lso-radios--full';
        [
            { value: 'list', label: t('viewList', 'Compact view') },
            { value: 'excerpt', label: t('viewExcerpt', 'Extended view') },
        ].forEach(function (opt, index) {
            var id = 'yoo-comments-view-' + opt.value;
            var pill = document.createElement('label');
            pill.className = 'yoo-lso-radio' + (state.view === opt.value ? ' is-active' : '');
            pill.setAttribute('for', id);
            pill.innerHTML = '<input id="' + id + '" type="radio" name="yoo-comments-view-mode" value="' + opt.value + '">' + opt.label;
            var radio = pill.querySelector('input');
            radio.checked = state.view === opt.value;
            radio.addEventListener('change', function () {
                if (!radio.checked) {
                    return;
                }
                viewRadios.querySelectorAll('.yoo-lso-radio').forEach(function (el) {
                    el.classList.remove('is-active');
                });
                pill.classList.add('is-active');
            });
            viewRadios.appendChild(pill);
        });
        viewItems.appendChild(viewRadios);
        body.appendChild(viewSection);

        var enabledToggle = null;
        if (canManage) {
            var modSection = document.createElement('div');
            modSection.className = 'yoo-lso-section yoo-lso-section--moderation';
            modSection.innerHTML =
                '<h3 class="yoo-lso-section__title">' +
                t('moderationTitle', 'Discussion') +
                '</h3><div class="yoo-lso-section__items"><label class="yoo-lso-toggle" for="yoo-comments-enabled-toggle"><span class="yoo-lso-toggle__text">' +
                t('commentsEnabled', 'Allow comments on the site') +
                '</span><input id="yoo-comments-enabled-toggle" type="checkbox" role="switch"><span class="yoo-lso-toggle__switch" aria-hidden="true"></span></label></div><p class="yoo-lso-moderation-note"></p>';
            enabledToggle = modSection.querySelector('#yoo-comments-enabled-toggle');
            var note = modSection.querySelector('.yoo-lso-moderation-note');
            enabledToggle.checked = !!cfg.commentsEnabled;
            updateCommentsEnabledNote(note, enabledToggle.checked);
            enabledToggle.addEventListener('change', function () {
                updateCommentsEnabledNote(note, enabledToggle.checked);
            });
            body.appendChild(modSection);
        }

        document.body.appendChild(modal);
        document.body.classList.add('yoo-lso-modal-open');

        function closeModal() {
            modal.remove();
            document.body.classList.remove('yoo-lso-modal-open');
        }

        modal.querySelectorAll('[data-yoo-lso-close]').forEach(function (node) {
            node.addEventListener('click', closeModal);
        });

        modal.querySelector('.yoo-lso-modal__apply').addEventListener('click', function () {
            var selectedView = modal.querySelector('input[name="yoo-comments-view-mode"]:checked');
            var formData = {
                action: 'yooadmin_comments_screen_options',
                nonce: cfg.nonce,
                per_page: parseInt(document.getElementById('yoo-comments-per-page').value, 10) || 20,
                view: selectedView ? selectedView.value : state.view,
                columns: {},
            };

            modal.querySelectorAll('input[data-column]').forEach(function (input) {
                formData.columns[input.getAttribute('data-column')] = input.checked ? '1' : '0';
            });

            if (enabledToggle) {
                formData.comments_enabled = enabledToggle.checked ? '1' : '0';
            }

            $.post(cfg.ajaxUrl, formData).done(function (res) {
                if (!res || !res.success) {
                    showNotice('error', t('error', 'An error occurred.'));
                    return;
                }
                state.perPage = res.data.per_page || state.perPage;
                state.view = res.data.view || state.view;
                if (enabledToggle && typeof res.data.comments_enabled !== 'undefined') {
                    var noticeMsg = res.data.comments_enabled
                        ? t('commentsEnabledOn', 'Comments enabled. Existing posts can accept comments again.')
                        : t('commentsDisabledOn', 'Comments disabled and closed on existing posts.');
                    setCommentsEnabledState(!!res.data.comments_enabled, { message: noticeMsg });
                } else {
                    showNotice('success', t('saved', 'Settings saved.'));
                }
                applyColumnVisibility(res.data.hidden || []);
                applyViewMode(state.view);
                closeModal();
                applyFilters({ paged: 1 });
            });
        });
    }

    function initScreenOptions() {
        $('#yoo-comments-screen-options-btn').on('click', function (e) {
            e.preventDefault();
            if (document.getElementById('yoo-lso-modal')) {
                return;
            }
            buildScreenOptionsModal();
        });
    }

    function initDeleteAll() {
        $('#yoo-comments-delete-all').on('click', function () {
            if (!cfg.totalComments) {
                showNotice('error', t('deleteAllEmpty', 'There are no comments to delete.'));
                return;
            }

            confirmAction({
                title: t('deleteAllTitle', 'Delete all comments?'),
                message: t('deleteAllMessage', 'This permanently deletes every comment.'),
                confirmText: t('deleteAllConfirm', 'Delete all'),
                cancelText: t('cancel', 'Cancel'),
                variant: 'danger',
            }).then(function (ok) {
                if (!ok) {
                    return;
                }
                var $btn = $('#yoo-comments-delete-all');
                $btn.prop('disabled', true);

                function step() {
                    return $.post(cfg.ajaxUrl, {
                        action: 'yooadmin_comments_delete_batch',
                        nonce: cfg.nonce,
                    }).then(function (res) {
                        if (!res || !res.success) {
                            throw new Error('delete_failed');
                        }
                        updateCounts(res.data.counts);
                        if (res.data.done) {
                            applyFilters({ paged: 1 });
                            $btn.prop('disabled', true);
                            return;
                        }
                        return step();
                    });
                }

                step().catch(function () {
                    $btn.prop('disabled', false);
                    showNotice('error', t('error', 'An error occurred.'));
                });
            });
        });
    }

    function initFromUrl() {
        var params = new URLSearchParams(window.location.search);
        state.commentStatus = params.get('comment_status') || '';
        state.search = params.get('s') || '';
        state.paged = parseInt(params.get('paged') || '1', 10) || 1;
        $('#yoo-comments-search-input').val(state.search);
    }

    function getCommentHost(commentId) {
        var $msg = $('#comment-' + commentId);
        if (!$msg.length) {
            return $();
        }

        if ($msg.hasClass('yoo-chat-msg--root')) {
            var $cardHost = $msg.closest('.yoo-comment-card').find('.yoo-comment-card__reply-host').first();
            if ($cardHost.length) {
                return $cardHost;
            }
        }

        var $inlineHost = $msg.next('.yoo-chat-msg__inline-host');
        if (!$inlineHost.length) {
            $inlineHost = $('<div class="yoo-chat-msg__inline-host" aria-live="polite"></div>');
            $msg.after($inlineHost);
        }
        return $inlineHost;
    }

    function ensureEditStatusField($replyRow) {
        if ($replyRow.find('#yoo-edit-status-field').length) {
            return;
        }

        var $field = $(
            '<div id="yoo-edit-status-field" class="yoo-chat-edit-status">' +
                '<label class="yoo-chat-edit-status__label" for="yoo-edit-status-select">' +
                t('statusLabel', 'Status') +
                '</label>' +
                '<select id="yoo-edit-status-select" class="yoo-chat-edit-status__select">' +
                '<option value="1">' +
                t('statusApproved', 'Approved') +
                '</option>' +
                '<option value="0">' +
                t('statusPending', 'Pending') +
                '</option>' +
                '<option value="spam">' +
                t('statusSpam', 'Spam') +
                '</option>' +
                '</select>' +
                '</div>'
        );

        $field.find('#yoo-edit-status-select').on('change', function () {
            $('#status').val($(this).val());
        });

        $replyRow.find('#edithead').append($field);
    }

    function syncEditStatusFromInline(commentId) {
        var raw = $('#inline-' + commentId + ' .comment_status').text().trim();
        var val = '1';

        if (raw === '0') {
            val = '0';
        } else if (raw === 'spam') {
            val = 'spam';
        }

        $('#yoo-edit-status-select').val(val);
        $('#status').val(val);
    }

    function enhanceReplyRow() {
        var $replyRow = $('#replyrow');
        if (!$replyRow.length || !$replyRow.is(':visible')) {
            return;
        }

        var isEdit = window.commentReply && window.commentReply.act === 'edit-comment';
        $replyRow.toggleClass('yoo-chat-edit-panel', isEdit);
        $replyRow.toggleClass('yoo-chat-reply-panel', !isEdit);

        if (isEdit) {
            ensureEditStatusField($replyRow);
            if (window.commentReply && window.commentReply.cid) {
                syncEditStatusFromInline(window.commentReply.cid);
            }
            $replyRow.find('#editlegend').removeClass('hidden');
            $replyRow.find('#edithead').show();
            $replyRow.find('#edithead input[type="text"]').addClass('yoo-chat-edit-input');
            $replyRow.find('#yoo-edit-status-select').addClass('yoo-chat-edit-input');
        } else {
            $replyRow.find('#replyhead').removeClass('hidden');
        }

        $replyRow.find('.save').addClass('yp-yoo-btn yp-yoo-btn--primary');
        $replyRow.find('.cancel').addClass('yp-yoo-btn yp-yoo-btn--soft');

        if (window.yooadminUiSelect && typeof window.yooadminUiSelect.initIn === 'function') {
            window.yooadminUiSelect.initIn($replyRow[0]);
        }
    }

    function dockReplyRow(commentId) {
        var $replyRow = $('#replyrow');
        var $host = getCommentHost(commentId);
        if (!$replyRow.length || !$host.length) {
            return;
        }
        if (!$host.find('#replyrow').length) {
            $host.append($replyRow);
        }
        $replyRow.show();
        enhanceReplyRow();
    }

    function isInlineFormOpen() {
        var $replyRow = $('#replyrow');
        return $replyRow.length && $replyRow.is(':visible') && !$replyRow.parent().is('#com-reply');
    }

    function setInlineButtonExpanded(commentId, mode, expanded) {
        var selector = mode === 'edit' ? '.vim-q.comment-inline' : '.vim-r.comment-inline';
        $('#the-comment-list ' + selector).each(function () {
            var $btn = $(this);
            if (String($btn.data('commentId')) === String(commentId)) {
                $btn.attr('aria-expanded', expanded ? 'true' : 'false');
            }
        });
    }

    function patchCommentReply() {
        if (!window.commentReply || window.commentReply._yooPatched) {
            return;
        }

        var originalOpen = window.commentReply.open;
        window.commentReply.open = function (commentId, postId, action) {
            action = action || 'replyto';

            if (action === 'replyto' || action === 'edit') {
                var expectedAct = action === 'edit' ? 'edit-comment' : 'replyto-comment';
                if (
                    isInlineFormOpen() &&
                    String(window.commentReply.cid) === String(commentId) &&
                    window.commentReply.act === expectedAct
                ) {
                    window.commentReply.revert();
                    setInlineButtonExpanded(commentId, action === 'edit' ? 'edit' : 'reply', false);
                    return false;
                }
            }

            var result = originalOpen.apply(this, arguments);
            if (action === 'replyto' || action === 'edit') {
                setInlineButtonExpanded(commentId, action === 'edit' ? 'edit' : 'reply', true);
                window.setTimeout(
                    function () {
                        dockReplyRow(commentId);
                        enhanceReplyRow();
                    },
                    action === 'edit' ? 320 : 40
                );
            }
            return result;
        };

        window.commentReply.show = function (xml) {
            var replyApi = this;
            var parsed;
            var act = replyApi.act;

            if (typeof xml === 'string') {
                replyApi.error({ responseText: xml });
                return false;
            }

            parsed = window.wpAjax.parseAjaxResponse(xml);
            if (parsed.errors) {
                replyApi.error({ responseText: window.wpAjax.broken });
                return false;
            }

            $('#replysubmit .spinner').removeClass('is-active');
            replyApi.revert();

            if (typeof window.yooadmApplyCommentsFilters === 'function') {
                window.yooadmApplyCommentsFilters({ silentUrl: true });
            }

            showNotice(
                'success',
                act === 'edit-comment'
                    ? t('commentUpdated', 'Comment updated.')
                    : t('commentReplied', 'Reply added.')
            );
            return false;
        };

        window.commentReply._yooPatched = true;
    }

    function bindInlineToggle() {
        var $list = $('#the-comment-list');
        // WordPress core (admin-comments) binds its own delegated click on
        // `.comment-inline` to open the reply editor. Because this script now
        // depends on `admin-comments`, the core handler runs first and opens the
        // panel, then our toggle handler runs and immediately closes it again.
        // Remove the core delegated handler so only ours drives the inline editor.
        $list.off('click', '.comment-inline');
        $list.off('click.yooInline', '.comment-inline');
        $list.on('click.yooInline', '.comment-inline', function (e) {
            e.preventDefault();
            e.stopImmediatePropagation();

            var $el = $(this);
            var action = $el.data('action') || 'replyto';
            var commentId = $el.data('commentId');
            var postId = $el.data('postId');

            if (!window.commentReply || (action !== 'replyto' && action !== 'edit')) {
                return false;
            }

            var expectedAct = action === 'edit' ? 'edit-comment' : 'replyto-comment';
            if (
                isInlineFormOpen() &&
                String(window.commentReply.cid) === String(commentId) &&
                window.commentReply.act === expectedAct
            ) {
                window.commentReply.revert();
                $el.attr('aria-expanded', 'false');
                return false;
            }

            $el.attr('aria-expanded', 'true');
            window.commentReply.open(commentId, postId, action);
            window.setTimeout(
                function () {
                    dockReplyRow(commentId);
                    enhanceReplyRow();
                },
                action === 'edit' ? 320 : 40
            );
            return false;
        });
    }

    function initReplyPanel() {
        patchCommentReply();
        bindInlineToggle();

        $(document).on('keydown.yooCommentsReply', function (e) {
            if (e.key !== 'Escape') {
                return;
            }
            var $replyRow = $('#replyrow');
            if (!$replyRow.length || !$replyRow.is(':visible') || !window.commentReply) {
                return;
            }
            e.preventDefault();
            var cid = window.commentReply.cid;
            var act = window.commentReply.act;
            window.commentReply.revert();
            if (cid) {
                if (act === 'edit-comment') {
                    setInlineButtonExpanded(cid, 'edit', false);
                } else if (act === 'replyto-comment') {
                    setInlineButtonExpanded(cid, 'reply', false);
                }
            }
        });
    }

    function initHeroCommentsToggle() {
        var $toggle = $('#yoo-comments-hero-enabled');
        if (!$toggle.length) {
            return;
        }

        $toggle.on('change', function () {
            persistCommentsEnabled($toggle.prop('checked'));
        });
    }

    function initListScreenUi() {
        if (window.yooadminUiSelect && typeof window.yooadminUiSelect.initIn === 'function') {
            window.yooadminUiSelect.initIn(document.querySelector('.yooadmin-comments-page'));
        }
        if (typeof window.yooadminEnhanceGlobalButtons === 'function') {
            window.yooadminEnhanceGlobalButtons(document.querySelector('.yooadmin-comments-page'));
        }
    }

    $(function () {
        if (!$('.yooadmin-comments-page').length) {
            return;
        }
        initFromUrl();
        syncCommentsListingStatus();
        initFilters();
        initBulk();
        initRowActions();
        initReplyPanel();
        initMetricsToggle();
        initHeroCommentsToggle();
        initScreenOptions();
        initDeleteAll();
        initListScreenUi();
        applyViewMode(state.view);
    });
})(jQuery);
