/**
 * YOOAdmin - Data cleanup modal script
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    // Wait for DOM ready
    $(document).ready(function() {
        
        // Create modal HTML
        function createModal() {
            const i18n = yooadmCleanup.i18n;
            
            const modalHTML = `
                <div id="yooadmin-cleanup-modal" class="yp-cleanup-modal" style="display: none;">
                    <div class="yp-cleanup-overlay"></div>
                    <div class="yp-cleanup-dialog">
                        <div class="yp-cleanup-header">
                            <h2>${i18n.title}</h2>
                            <button type="button" class="yp-cleanup-close" aria-label="Close">
                                <span class="dashicons dashicons-no-alt"></span>
                            </button>
                        </div>
                        <div class="yp-cleanup-content">
                            <div class="yp-cleanup-warning">
                                <span class="dashicons dashicons-warning"></span>
                                <p>${i18n.message}</p>
                            </div>
                            
                            <div class="yp-cleanup-list">
                                <p><strong>${i18n.warning}</strong></p>
                                <ul>
                                    <li><span class="dashicons dashicons-yes"></span> ${i18n.item1}</li>
                                    <li><span class="dashicons dashicons-yes"></span> ${i18n.item2}</li>
                                    <li><span class="dashicons dashicons-yes"></span> ${i18n.item3}</li>
                                    ${i18n.item4 ? `<li><span class="dashicons dashicons-yes"></span> ${i18n.item4}</li>` : ''}
                                </ul>
                            </div>
                            
                            <div class="yp-cleanup-safe">
                                <span class="dashicons dashicons-shield-alt"></span>
                                <p>${i18n.safe}</p>
                            </div>
                            
                            <div class="yp-cleanup-confirm">
                                <label for="yp-cleanup-confirmation">${i18n.confirm}</label>
                                <input type="text" id="yp-cleanup-confirmation" class="yp-cleanup-input" autocomplete="off" />
                            </div>
                        </div>
                        <div class="yp-cleanup-footer">
                            <button type="button" class="yp-yoo-btn yp-yoo-btn--soft yp-cleanup-cancel">${i18n.cancelButton}</button>
                            <button type="button" class="yp-yoo-btn yp-yoo-btn--danger yp-cleanup-delete" disabled>${i18n.deleteButton}</button>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(modalHTML);
        }
        
        // Initialize modal
        createModal();
        
        const $modal = $('#yooadmin-cleanup-modal');
        const $deleteBtn = $modal.find('.yp-cleanup-delete');
        const $confirmInput = $modal.find('#yp-cleanup-confirmation');
        
        // Handle Data Cleanup link click
        $(document).on('click', '.yooadmin-data-cleanup-link', function(e) {
            e.preventDefault();
            const $link = $(this);
            const isEnabled = $link.data('enabled') === '1' || $link.data('enabled') === 1;
            
            if (!isEnabled) {
                // Show enable setting modal
                openEnableModal();
            } else {
                // Show normal cleanup modal
                openModal();
            }
        });
        
        // Handle close button
        $modal.find('.yp-cleanup-close, .yp-cleanup-cancel, .yp-cleanup-overlay').on('click', function() {
            closeModal();
        });
        
        // Handle confirmation input
        $confirmInput.on('input', function() {
            const value = $(this).val();
            if (value === 'DELETE') {
                $deleteBtn.prop('disabled', false).removeClass('disabled');
            } else {
                $deleteBtn.prop('disabled', true).addClass('disabled');
            }
        });
        
        // Handle delete button
        $deleteBtn.on('click', function() {
            performCleanup();
        });
        
        // Handle Escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                if ($modal.is(':visible')) {
                    closeModal();
                } else if ($enableModal.is(':visible')) {
                    closeEnableModal();
                }
            }
        });
        
        // Create enable setting modal
        function createEnableModal() {
            const i18n = yooadmCleanup.i18n;
            
            const enableModalHTML = `
                <div id="yooadmin-enable-cleanup-modal" class="yp-cleanup-modal" style="display: none;">
                    <div class="yp-cleanup-overlay"></div>
                    <div class="yp-cleanup-dialog">
                        <div class="yp-cleanup-header">
                            <h2>${i18n.enableTitle || 'Enable Data Cleanup'}</h2>
                            <button type="button" class="yp-cleanup-close" aria-label="Close">
                                <span class="dashicons dashicons-no-alt"></span>
                            </button>
                        </div>
                        <div class="yp-cleanup-content">
                            <div class="yp-cleanup-warning">
                                <span class="dashicons dashicons-info"></span>
                                <p>${i18n.enableMessage || 'Data Cleanup is currently disabled. Please enable it to proceed with data deletion.'}</p>
                            </div>
                            
                            <div class="yp-cleanup-toggle-wrapper">
                                <label class="yp-toggle-label">
                                    <span>${i18n.enableLabel || 'Delete Data on Uninstall'}</span>
                                    <div class="yp-toggle-slider">
                                        <input type="checkbox" id="yp-enable-cleanup-toggle" class="yp-toggle-checkbox">
                                        <span class="yp-toggle-slider-round"></span>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <div class="yp-cleanup-footer">
                            <button type="button" class="yp-yoo-btn yp-yoo-btn--soft yp-cleanup-cancel">${i18n.cancelButton}</button>
                            <button type="button" class="yp-yoo-btn yp-yoo-btn--primary yp-cleanup-enable-save" disabled>${i18n.enableSaveButton || 'Save & Continue'}</button>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(enableModalHTML);
        }
        
        // Initialize enable modal
        createEnableModal();
        const $enableModal = $('#yooadmin-enable-cleanup-modal');
        const $enableToggle = $enableModal.find('#yp-enable-cleanup-toggle');
        const $enableSaveBtn = $enableModal.find('.yp-cleanup-enable-save');
        
        // Handle toggle change
        $enableToggle.on('change', function() {
            $enableSaveBtn.prop('disabled', !$(this).is(':checked'));
        });
        
        // Handle enable save button
        $enableSaveBtn.on('click', function() {
            if (!$enableToggle.is(':checked')) {
                return;
            }
            
            $enableSaveBtn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> Saving...');
            
            $.ajax({
                url: yooadmCleanup.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_enable_delete_data_setting',
                    nonce: yooadmCleanup.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Update link data attribute
                        $('.yooadmin-data-cleanup-link').data('enabled', '1');
                        
                        // Close enable modal
                        closeEnableModal();
                        
                        // Open normal cleanup modal
                        openModal();
                    } else {
                        const message = response.data && response.data.message ? response.data.message : 'Failed to enable setting';
                        showNotification(message, 'error');
                        $enableSaveBtn.prop('disabled', false).text(yooadmCleanup.i18n.enableSaveButton || 'Save & Continue');
                    }
                },
                error: function() {
                    showNotification('Network error. Please try again.', 'error');
                    $enableSaveBtn.prop('disabled', false).text(yooadmCleanup.i18n.enableSaveButton || 'Save & Continue');
                }
            });
        });
        
        // Handle close for enable modal
        $enableModal.find('.yp-cleanup-close, .yp-cleanup-cancel, .yp-cleanup-overlay').on('click', function() {
            closeEnableModal();
        });
        
        function openEnableModal() {
            $enableModal.fadeIn(200);
            $('body').addClass('yp-modal-open');
            $enableToggle.prop('checked', false);
            $enableSaveBtn.prop('disabled', true);
        }
        
        function closeEnableModal() {
            $enableModal.fadeOut(200);
            $('body').removeClass('yp-modal-open');
            $enableToggle.prop('checked', false);
            $enableSaveBtn.prop('disabled', true);
        }
        
        function openModal() {
            $modal.fadeIn(200);
            $('body').addClass('yp-modal-open');
            $confirmInput.val('').trigger('focus');
            $deleteBtn.prop('disabled', true);
        }
        
        function closeModal() {
            $modal.fadeOut(200);
            $('body').removeClass('yp-modal-open');
            $confirmInput.val('');
            $deleteBtn.prop('disabled', true).text(yooadmCleanup.i18n.deleteButton);
        }
        
        function performCleanup() {
            const confirmation = $confirmInput.val();
            
            if (confirmation !== 'DELETE') {
                alert(yooadmCleanup.i18n.typeMismatch);
                return;
            }
            
            // Disable button and show processing state
            $deleteBtn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> ' + yooadmCleanup.i18n.processing);
            
            $.ajax({
                url: yooadmCleanup.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_data_cleanup',
                    nonce: yooadmCleanup.nonce,
                    confirmation: confirmation
                },
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        showNotification(yooadmCleanup.i18n.success, 'success');
                        
                        // Close modal
                        closeModal();
                        
                        // Reload page after 1.5 seconds
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    } else {
                        const message = response.data && response.data.message ? response.data.message : yooadmCleanup.i18n.error;
                        showNotification(message, 'error');
                        $deleteBtn.prop('disabled', false).text(yooadmCleanup.i18n.deleteButton);
                    }
                },
                error: function() {
                    showNotification(yooadmCleanup.i18n.error, 'error');
                    $deleteBtn.prop('disabled', false).text(yooadmCleanup.i18n.deleteButton);
                }
            });
        }
        
        function showNotification(message, type) {
            // Remove existing notification
            $('.yp-cleanup-notification').remove();
            
            const iconClass = type === 'success' ? 'dashicons-yes-alt' : 'dashicons-warning';
            const notification = $('<div class="yp-cleanup-notification yp-cleanup-notification-' + type + '">' +
                '<span class="dashicons ' + iconClass + '"></span>' +
                '<span>' + message + '</span>' +
                '</div>');
            
            $('body').append(notification);
            
            setTimeout(function() {
                notification.addClass('yp-cleanup-notification-visible');
            }, 10);
            
            setTimeout(function() {
                notification.removeClass('yp-cleanup-notification-visible');
                setTimeout(function() {
                    notification.remove();
                }, 300);
            }, 4000);
        }
    });
    
})(jQuery);

