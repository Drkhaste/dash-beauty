/**
 * YOOAdmin - Popup system (universal handler)
 *
 * @package YOOAdmin
 */

(function($){
  'use strict';

  // Global popup system
  window.yooadmPopup = {
    // Create popup
    create: function(options) {
      var defaults = {
        title: 'Popup',
        content: '',
        width: '500px',
        height: 'auto',
        className: '',
        onClose: function() {},
        onOpen: function() {}
      };
      
      var settings = $.extend({}, defaults, options);
      
      // Remove existing popup
      $('.yooadmin-popup-overlay').remove();
      
      var popupHtml = `
        <div class="yooadmin-popup-overlay" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 999999; display: flex; align-items: center; justify-content: center;">
          <div class="yooadmin-popup ${settings.className}" style="background: #fff; border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.3); max-width: ${settings.width}; width: 90%; max-height: 80vh; display: flex; flex-direction: column;">
            <div class="yooadmin-popup-header" style="padding: 20px 24px 16px; border-bottom: 1px solid #e1e5e9; display: flex; align-items: center; justify-content: space-between;">
              <h3 style="margin: 0; font-size: 18px; font-weight: 600; color: var(--yp-text);">${settings.title}</h3>
              <button class="yooadmin-popup-close" style="background: none; border: none; font-size: 24px; color: var(--yp-text); cursor: pointer; padding: 0; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border-radius: 4px; transition: all 0.2s ease;">&times;</button>
            </div>
            <div class="yooadmin-popup-content" style="flex: 1; overflow: hidden; display: flex; flex-direction: column; padding: 20px 24px;">
              ${settings.content}
            </div>
          </div>
        </div>
      `;
      
      $('body').append(popupHtml);
      
      // Bind events
      $('.yooadmin-popup-overlay').on('click', function(e) {
        if (e.target === this) {
          yooadmPopup.close();
        }
      });
      
      $('.yooadmin-popup-close').on('click', function(e) {
        e.preventDefault();
        yooadmPopup.close();
      });
      
      // Call onOpen callback
      if (typeof settings.onOpen === 'function') {
        settings.onOpen();
      }
      
      return $('.yooadmin-popup-overlay');
    },
    
    // Close popup
    close: function() {
      $('.yooadmin-popup-overlay').fadeOut(200, function() {
        $(this).remove();
      });
    },
    
    // Update content
    updateContent: function(content) {
      $('.yooadmin-popup-content').html(content);
    },
    
    // Show loading
    showLoading: function() {
      $('.yooadmin-popup-content').html('<div style="text-align: center; padding: 40px;"><div class="spinner is-active" style="float: none; margin: 0 auto;"></div><p>Loading...</p></div>');
    }
  };

})(jQuery);
