/**
 * YOOAdmin - Focus toggle wiring
 *
 * @package YOOAdmin
 */

/* eslint-disable no-var, vars-on-top */
(function () {
	'use strict';

	/* ---------------------------------------------------------------------
	 * Early exits: skip SPA-like screens and block editor
	 * ------------------------------------------------------------------ */

	/**
	 * Returns a URLSearchParams for the current location safely.
	 * @returns {URLSearchParams}
	 */
	function getSearchParams() {
		try {
			return new URL(window.location.href).searchParams;
		} catch (e) {
			// Fallback: safest no-op params
			return new URLSearchParams(window.location.search || '');
		}
	}

	/**
	 * Check if we're inside WooCommerce Onboarding/Customize Store SPA.
	 * We avoid injecting navigation on these heavy SPA routes.
	 * @returns {boolean}
	 */
	function isWcCustomizeStore() {
		var params = getSearchParams();
		if (params.get('page') !== 'wc-admin') { return false; }
		var p = params.get('path') || '';
		try { p = decodeURIComponent(p); } catch (e) {}
		return typeof p === 'string' && p.indexOf('/customize-store') === 0;
	}

	/**
	 * Check if we're on the block editor.
	 * @returns {boolean}
	 */
	function isBlockEditor() {
		if (!document || !document.body) { return false; }
		var b = document.body.classList;
		return b.contains('block-editor-page') || b.contains('block-editor');
	}

	// Respect a global kill switch if present.
	/* global __YOOPIXEL_DISABLED__ */
	if (isWcCustomizeStore() || isBlockEditor() || window.__YOOPIXEL_DISABLED__) { return; }

	/* ---------------------------------------------------------------------
	 * Re-entrancy guard
	 * ------------------------------------------------------------------ */
	if (window.__yooadmFocusToggleWired__) { return; }
	window.__yooadmFocusToggleWired__ = true;

	/* ---------------------------------------------------------------------
	 * Constants
	 * ------------------------------------------------------------------ */
	var SELECTOR_TOGGLE_INPUT = '#yp-toggle-clean-view';
	var SELECTOR_TOGGLE_WRAP  = '.yps-focus-toggle';

	/* ---------------------------------------------------------------------
	 * Navigation helper
	 * ------------------------------------------------------------------ */

	/**
	 * Navigate to the correct URL to flip focus mode.
	 * @param {boolean} nextOn - True to enable, false to disable
	 */
	function goToFocusState(nextOn) {
		try {
			var policy = window.yooadmFocus && yooadmFocus.policy ? yooadmFocus.policy : 'auto';
			var input = document.querySelector('#yp-toggle-clean-view');
			
			// Check if policy is not "auto"
			if (policy !== 'auto') {
				// Trying to disable when policy is "on" (Force On)
				if (!nextOn && policy === 'on') {
					if (window.yooadmAlerts) {
						window.yooadmAlerts.showPolicyAlert('on', false);
					}
					if (input) {
						input.checked = true;
					}
					return;
				}
				
				// Trying to enable when policy is "off" (Force Off)
				if (nextOn && policy === 'off') {
					if (window.yooadmAlerts) {
						window.yooadmAlerts.showPolicyAlert('off', true);
					}
					if (input) {
						input.checked = false;
					}
					return;
				}
			}

			var url = null;
			var cookieValue = nextOn ? 'on' : 'off';
			var cfg = window.yooadmFocus || {};
			
			// Persist per-user preference when policy allows individual choice.
			if (policy === 'auto' && cfg.ajaxUrl && cfg.saveNonce) {
				try {
					var fd = new FormData();
					fd.append('action', 'yooadmin_save_user_focus_mode');
					fd.append('nonce', cfg.saveNonce);
					fd.append('focus_mode', cookieValue);
					fetch(cfg.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' }).catch(function () {});
				} catch (saveErr) {}
			}
			
			// Set cookie before redirect
			document.cookie = 'yoo_focus=' + cookieValue + '; path=/; max-age=31536000; SameSite=Lax';

			if (!nextOn) {
				try {
					sessionStorage.removeItem('yooadminFocusTransition');
				} catch (clearErr) {}

				if (cfg.enable_focus_url) {
					try {
						var offUrl = new URL(cfg.enable_focus_url, window.location.origin);
						offUrl.searchParams.set('yoo', 'off');
						url = offUrl.toString();
					} catch (offUrlErr) {
						url = cfg.enable_focus_url + (cfg.enable_focus_url.indexOf('?') >= 0 ? '&' : '?') + 'yoo=off';
					}
				} else {
					var adminUrl = window.location.origin + window.location.pathname.replace(/\/[^\/]*$/, '/admin.php');
					url = adminUrl + '?page=yooadmin-enable-focus&yoo=off';
				}
			} else {
				/* global yooadmFocus */
				if (window.yooadmFocus && typeof yooadmFocus === 'object') {
					url = yooadmFocus.toggle_on_url;
				}

				if (!url) {
					var u = new URL(window.location.href);
					u.searchParams.set('yoo', 'on');
					url = u.toString();
				}
			}

			window.location.assign(url);
		} catch (e) {
			// Silent error handling
		}
	}

	/* ---------------------------------------------------------------------
	 * Wiring
	 * ------------------------------------------------------------------ */

	/**
	 * Attempt to wire the toggle. Returns true on success.
	 * @returns {boolean}
	 */
	function wire() {
		var input = document.querySelector(SELECTOR_TOGGLE_INPUT);
		var wrap  = document.querySelector(SELECTOR_TOGGLE_WRAP);
		if (!input || !wrap) { return false; }

		// Initialize checked state from localized data if present
		try {
			if (window.yooadmFocus && typeof yooadmFocus === 'object') {
				input.checked = !!yooadmFocus.is_active;
			}
		} catch (e) {}

		// Use passive: true (no preventDefault) — simple state navigation.
		input.addEventListener('change', function onChange() {
			goToFocusState(!!input.checked);
		}, { passive: true });

		return true;
	}

	/* ---------------------------------------------------------------------
	 * Boot (DOM ready + MutationObserver retry)
	 * ------------------------------------------------------------------ */

	// Try immediately; if not present yet, retry on DOMContentLoaded + MO.
	if (!wire()) {
		function onReady() {
			document.removeEventListener('DOMContentLoaded', onReady);
			wire();
		}

		document.addEventListener('DOMContentLoaded', onReady);

		// In some admin screens the toggle is injected late; watch briefly.
		try {
			var mo = new MutationObserver(function () {
				if (wire()) { mo.disconnect(); }
			});
			mo.observe(document.documentElement, { childList: true, subtree: true });

			// Safety: stop observing after a short window.
			window.setTimeout(function () { try { mo.disconnect(); } catch (e) {} }, 3000);
		} catch (e) {
			// MutationObserver may not be available in very old browsers — safe to ignore.
		}
	}
})();
