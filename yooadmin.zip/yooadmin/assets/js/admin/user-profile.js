/**
 * YOOAdmin - User profile (AJAX edit)
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    const ProfileEditor = {
        init: function() {
            this.initFlashFromQuery();
            this.flushInlineNotices();
            this.initProfileTabs();
            this.initEmailChangeUi();
            this.initAvatarSourceUi();
            this.bindEvents();
        },

        initAvatarSourceUi: function() {
            const $select = $('#yooadmin-avatar-source');
            const $form = $('#yoo-profile-edit-form');
            if (!$select.length || !$form.length) {
                return;
            }

            const profileConfig = window.yooadmProfile || {};
            const $avatar = $('#yoo-profile-avatar');
            const $overlay = $('#yoo-avatar-upload-overlay');
            const $deleteBtn = $('#yoo-avatar-delete-btn');
            const $hint = $('#yoo-profile-avatar-source-hint');
            const $pluginsRow = $('#yoo-profile-photo-plugins-row');
            const $pluginsCell = $('#yoo-profile-photo-plugins-cell');
            const $description = $('#yooadmin-avatar-source-description');
            const hintLabels = profileConfig.avatarSourceHints || {
                gravatar: 'Gravatar',
                plugins: 'Plugin photo'
            };

            const applySource = (source) => {
                if ($avatar.length) {
                    $avatar
                        .attr('data-avatar-source', source)
                        .removeClass('yoo-profile-avatar--source-yooadmin yoo-profile-avatar--source-plugins yoo-profile-avatar--source-gravatar')
                        .addClass('yoo-profile-avatar--source-' + source);
                }

                const isYooadmin = source === 'yooadmin';
                if ($overlay.length) {
                    if (isYooadmin) {
                        $overlay.prop('hidden', false).removeAttr('hidden');
                    } else {
                        $overlay.prop('hidden', true).attr('hidden', 'hidden');
                    }
                }

                if ($deleteBtn.length) {
                    if (isYooadmin) {
                        $deleteBtn.prop('hidden', false).removeAttr('hidden');
                    } else {
                        $deleteBtn.prop('hidden', true).attr('hidden', 'hidden');
                    }
                }

                if ($hint.length) {
                    if (isYooadmin) {
                        $hint.prop('hidden', true).attr('hidden', 'hidden');
                    } else {
                        $hint.text(hintLabels[source] || '').prop('hidden', false).removeAttr('hidden');
                    }
                }

                if ($pluginsRow.length) {
                    if (source === 'plugins') {
                        $pluginsRow.prop('hidden', false).removeAttr('hidden');
                    } else {
                        $pluginsRow.prop('hidden', true).attr('hidden', 'hidden');
                    }
                }

                const $selected = $select.find('option:selected');
                const desc = $selected.data('description') || '';
                if ($description.length && desc) {
                    $description.text(desc);
                }
            };

            const getSourcePreview = (source) => {
                const previews = profileConfig.avatarSourcePreviews || {};

                return previews[source] || {};
            };

            const updateHeroAvatar = (avatarData) => {
                if (!avatarData || !avatarData.url) {
                    return;
                }

                const src = String(avatarData.url);
                const $img = $('.yoo-profile-avatar img');
                if ($img.length) {
                    $img.attr('src', src);
                    if (avatarData.is_placeholder) {
                        $img.addClass('yoo-avatar--no-photo avatar-default');
                    } else {
                        $img.removeClass('yoo-avatar--no-photo avatar-default');
                    }
                }

                if (typeof window.yooadminSyncShellAvatars === 'function') {
                    window.yooadminSyncShellAvatars({
                        avatar_url: src,
                        avatar_is_placeholder: !!avatarData.is_placeholder
                    });
                }
            };

            const getPluginAvatarInputName = () => (
                (window.sua_obj && sua_obj.input_name)
                    ? String(sua_obj.input_name)
                    : 'mm_sua_attachment_id'
            );

            const syncPluginAvatarFromPanel = () => {
                if (!$pluginsCell.length) {
                    return false;
                }

                const $suaImg = $pluginsCell.find('.sua-attachment-avatar');
                if (!$suaImg.length) {
                    return false;
                }

                const attachmentId = parseInt(
                    String($pluginsCell.find('input[name="' + getPluginAvatarInputName() + '"]').val() || ''),
                    10
                );
                const src = String($suaImg.attr('src') || '');
                if (!src) {
                    return false;
                }

                const isPlaceholder = !attachmentId
                    || $pluginsCell.find('#sua-attachment-description:not(.hidden)').length > 0;

                updateHeroAvatar({
                    url: src,
                    is_placeholder: isPlaceholder
                });

                return true;
            };

            const pickAttachmentPreviewUrl = (attachment) => {
                let url = attachment.url || '';
                const sizes = attachment.sizes || {};
                ['thumbnail', 'medium', 'large', 'full'].forEach((sizeKey) => {
                    if (sizes[sizeKey] && sizes[sizeKey].url) {
                        url = sizes[sizeKey].url;
                    }
                });

                return url;
            };

            const applyPluginAttachmentToPanel = (attachment) => {
                const $suaImg = $pluginsCell.find('.sua-attachment-avatar');
                if (!$suaImg.length || !attachment) {
                    return;
                }

                const previewUrl = pickAttachmentPreviewUrl(attachment);
                $pluginsCell.find('input[name="' + getPluginAvatarInputName() + '"]').val(
                    attachment.id ? parseInt(attachment.id, 10) : ''
                );
                $suaImg.attr({
                    src: previewUrl,
                    srcset: previewUrl
                });
                $pluginsCell.find('#sua-attachment-description').addClass('hidden');
                $pluginsCell.find('#btn-media-remove').removeClass('hidden');
                syncPluginAvatarFromPanel();
            };

            const clearPluginAttachmentInPanel = () => {
                const defaultSrc = profileConfig.pluginAvatarDefaultUrl
                    || (window.sua_obj && sua_obj.default_avatar_src)
                    || '';
                const defaultSrcSet = (window.sua_obj && sua_obj.default_avatar_srcset)
                    ? String(sua_obj.default_avatar_srcset)
                    : '';
                const $suaImg = $pluginsCell.find('.sua-attachment-avatar');

                if (!$suaImg.length) {
                    return;
                }

                $pluginsCell.find('input[name="' + getPluginAvatarInputName() + '"]').val('');
                $suaImg.attr({
                    src: defaultSrc,
                    srcset: defaultSrcSet
                });
                $pluginsCell.find('#sua-attachment-description').removeClass('hidden');
                $pluginsCell.find('#btn-media-remove').addClass('hidden');
                syncPluginAvatarFromPanel();
            };

            const openPluginMediaFrame = () => {
                if (!window.wp || !wp.media) {
                    return;
                }

                const frame = wp.media({
                    title: profileConfig.i18nSelectPluginPhoto || 'Select profile photo',
                    button: {
                        text: profileConfig.i18nUsePluginPhoto || 'Use this photo'
                    },
                    multiple: false,
                    library: {
                        type: 'image'
                    }
                });

                frame.on('select', function() {
                    const attachment = frame.state().get('selection').first().toJSON();
                    applyPluginAttachmentToPanel(attachment);
                });

                frame.open();
            };

            const showPluginsPanelPending = () => {
                if (!$pluginsCell.length) {
                    return;
                }

                const pendingText = profileConfig.i18nPluginsPending
                    || 'Loading profile photo options…';
                $pluginsCell.html(
                    '<p class="description yoo-profile-photo-plugins__pending" id="yoo-profile-photo-plugins-pending">'
                    + $('<span>').text(pendingText).html()
                    + '</p>'
                );
            };

            const applyPluginsPanelHtml = (html) => {
                if (!$pluginsCell.length || typeof html !== 'string') {
                    return;
                }

                $pluginsCell.html(html);
                bindPluginPhotoPreview();
            };

            const bindPluginPhotoPreview = () => {
                if (!$pluginsCell.length) {
                    return;
                }

                $pluginsCell.off('click.yooPluginAvatar');
                $pluginsCell.on('click.yooPluginAvatar', '#btn-media-add', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    openPluginMediaFrame();
                });
                $pluginsCell.on('click.yooPluginAvatar', '#btn-media-remove', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    clearPluginAttachmentInPanel();
                });
                $pluginsCell.on('click.yooPluginAvatar', '.sua-attachment-avatar', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    e.stopImmediatePropagation();
                    openPluginMediaFrame();
                });

                syncPluginAvatarFromPanel();
            };

            const persistAvatarSource = (source, options) => {
                options = options || {};
                const userId = parseInt($form.data('user-id') || profileConfig.profileUserId || 0, 10);
                const nonce = profileConfig.setAvatarSourceNonce
                    || String($form.find('[name="yooadmin_profile_nonce"]').val() || '');

                if (!userId || !nonce) {
                    return $.Deferred().reject().promise();
                }

                if (source === 'plugins' && !options.silent) {
                    showPluginsPanelPending();
                }

                return $.post(profileConfig.ajaxUrl || window.ajaxurl, {
                    action: 'yooadmin_set_avatar_source',
                    user_id: userId,
                    avatar_source: source,
                    nonce: nonce
                }).done((response) => {
                    if (!response || !response.success || !response.data) {
                        return;
                    }

                    const data = response.data;
                    const savedSource = String(data.avatar_source || source);
                    $form.data('initial-avatar-source', savedSource);
                    $select.val(savedSource);

                    if (savedSource === 'plugins' && typeof data.plugins_panel_html === 'string') {
                        applyPluginsPanelHtml(data.plugins_panel_html);
                    } else if (savedSource !== 'plugins') {
                        $pluginsCell.empty();
                    }

                    applySource(savedSource);

                    if (savedSource === 'plugins') {
                        if (!syncPluginAvatarFromPanel()) {
                            updateHeroAvatar({
                                url: data.avatar_url,
                                is_placeholder: !!data.avatar_is_placeholder
                            });
                        }
                    } else {
                        updateHeroAvatar({
                            url: data.avatar_url,
                            is_placeholder: !!data.avatar_is_placeholder
                        });
                    }

                    $(document).trigger('yooadminAvatarSourceChanged', [data]);
                });
            };

            const previewSource = (source, options) => {
                options = options || {};
                const preview = getSourcePreview(source);

                applySource(source);

                if (source === 'plugins') {
                    const savedSource = String($form.data('initial-avatar-source') || 'yooadmin');
                    const hasPanel = $pluginsCell.find('#btn-media-add, .sua-attachment-avatar').length > 0;

                    if (!hasPanel || source !== savedSource) {
                        persistAvatarSource(source, options);
                    } else {
                        bindPluginPhotoPreview();
                        if (!options.skipHeroPreview && !syncPluginAvatarFromPanel() && preview.url) {
                            updateHeroAvatar(preview);
                        }
                    }
                    return;
                }

                if (!options.skipHeroPreview && preview.url) {
                    updateHeroAvatar(preview);
                }

                const savedSource = String($form.data('initial-avatar-source') || 'yooadmin');
                if (source !== savedSource) {
                    persistAvatarSource(source, options);
                } else if (savedSource === 'plugins') {
                    $pluginsCell.empty();
                }
            };

            const initialSource = String($form.data('initial-avatar-source') || $select.val() || 'yooadmin');
            previewSource(initialSource, { silent: true });

            $select.on('change', () => {
                previewSource(String($select.val() || 'yooadmin'));
            });

            $(document).on('yooadminAvatarSourceChanged', bindPluginPhotoPreview);
        },

        initEmailChangeUi: function() {
            const $form = $('#yoo-profile-edit-form');
            if (!$form.length) {
                return;
            }

            const profileConfig = window.yooadmProfile || {};
            const pinDigits = parseInt(profileConfig.totpDigits, 10) || 6;
            const $email = $form.find('#yoo-email');
            const $row = $('#yoo-profile-email-2fa-row');
            const $token = $('#yoo-email-change-2fa-token');
            const $status = $('#yoo-profile-email-2fa-status');
            const $pin = $('#yoo-email-change-authcode-pin');
            const currentEmail = String($form.data('current-email') || '');
            const requires2fa = String($form.data('requires-2fa-email')) === '1';
            let verifying2fa = false;

            const $wrap = $('#yoo-profile-email-2fa');

            const getSelectedEmail2faProvider = () => String(
                $form.find('[name="email_change_2fa_provider"]').val() || 'totp'
            ).trim();

            const normalizeEmail2faProvider = (providerKey) => {
                const raw = String(providerKey || 'totp').trim().toLowerCase();
                if (raw === 'totp' || raw === 'two_factor_totp') {
                    return 'totp';
                }
                if (raw === 'backup_codes' || raw === 'two_factor_backup_codes') {
                    return 'backup_codes';
                }

                return raw;
            };

            const setEmail2faStatusIcon = (type) => {
                const $icon = $status.find('.dashicons').first();
                if (!$icon.length) {
                    return;
                }
                $icon.removeClass('dashicons-yes-alt dashicons-warning dashicons-update');
                if (type === 'success') {
                    $icon.addClass('dashicons-yes-alt');
                } else if (type === 'error') {
                    $icon.addClass('dashicons-warning');
                } else if (type === 'verifying') {
                    $icon.addClass('dashicons-update');
                }
            };

            const resetEmail2faVerification = () => {
                $token.val('');
                $status.prop('hidden', true).removeClass('is-error is-verifying');
                setEmail2faStatusIcon('success');
                $form.removeClass('is-email-2fa-verified');
                if ($wrap.length) {
                    $wrap.removeClass('is-verified');
                }
                if ($pin.length) {
                    $pin.removeClass('is-verified is-error is-verifying');
                    $pin.find('.yoo-profile-email-2fa-pin__digit').prop('disabled', false).val('');
                    $('#yoo-email-change-authcode').val('');
                }
            };

            const setEmail2faVerifying = () => {
                $status.prop('hidden', false).removeClass('is-error').addClass('is-verifying');
                setEmail2faStatusIcon('verifying');
                $status.find('.yoo-profile-email-2fa-status__text').text(
                    profileConfig.i18n2faVerifying || 'Verifying…'
                );
                if ($pin.length) {
                    $pin.addClass('is-verifying').removeClass('is-error');
                    $pin.find('.yoo-profile-email-2fa-pin__digit').prop('disabled', true);
                }
            };

            const showEmail2faError = (message) => {
                $token.val('');
                $form.removeClass('is-email-2fa-verified');
                if ($wrap.length) {
                    $wrap.removeClass('is-verified');
                }
                $status.prop('hidden', false).removeClass('is-verifying').addClass('is-error');
                setEmail2faStatusIcon('error');
                $status.find('.yoo-profile-email-2fa-status__text').text(message);
                if ($pin.length) {
                    $pin.removeClass('is-verified is-verifying').addClass('is-error');
                    $pin.find('.yoo-profile-email-2fa-pin__digit').prop('disabled', false).val('');
                    $('#yoo-email-change-authcode').val('');
                    const $first = $pin.find('.yoo-profile-email-2fa-pin__digit').first();
                    if ($first.length) {
                        $first.trigger('focus');
                    }
                }
            };

            const setEmail2faVerified = (message) => {
                if ($wrap.length) {
                    $wrap.addClass('is-verified');
                }
                if ($pin.length) {
                    $pin.addClass('is-verified').removeClass('is-error is-verifying');
                    $pin.find('.yoo-profile-email-2fa-pin__digit').prop('disabled', true);
                }
                $status.prop('hidden', false).removeClass('is-error is-verifying');
                setEmail2faStatusIcon('success');
                if (message) {
                    $status.find('.yoo-profile-email-2fa-status__text').text(message);
                }
                $form.addClass('is-email-2fa-verified');
            };

            const readPinValue = () => {
                if (!$pin.length) {
                    return '';
                }
                return $pin.find('.yoo-profile-email-2fa-pin__digit').map(function() {
                    return String($(this).val() || '').replace(/\D/g, '');
                }).get().join('');
            };

            const syncPinHidden = () => {
                $('#yoo-email-change-authcode').val(readPinValue());
            };

            const requestEmail2faVerify = (payload) => {
                if (verifying2fa) {
                    return $.Deferred().reject().promise();
                }

                if (!ProfileEditor.emailChangeRequiresVerification($form)) {
                    return $.Deferred().reject().promise();
                }

                const userId = $form.data('user-id');
                const nonce = $form.find('[name="yooadmin_profile_nonce"]').val();
                verifying2fa = true;
                setEmail2faVerifying();

                return $.ajax({
                    url: profileConfig.ajaxUrl || window.ajaxurl,
                    type: 'POST',
                    data: Object.assign({
                        action: 'yooadmin_verify_email_change_2fa',
                        user_id: userId,
                        nonce: nonce,
                        user_email: String($email.val() || '').trim()
                    }, payload)
                }).done((response) => {
                    if (response && response.success && response.data && response.data.token) {
                        $token.val(response.data.token);
                        setEmail2faVerified(response.data.message || profileConfig.i18n2faVerified);
                        return;
                    }

                    const message = (response && response.data && response.data.message) || profileConfig.i18n2faInvalid;
                    showEmail2faError(message);
                }).fail((xhr) => {
                    let message = profileConfig.i18n2faInvalid || 'Invalid verification code.';
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        message = xhr.responseJSON.data.message;
                    }
                    showEmail2faError(message);
                }).always(() => {
                    verifying2fa = false;
                    if (!$token.val() && $pin.length) {
                        $pin.removeClass('is-verifying');
                        $pin.find('.yoo-profile-email-2fa-pin__digit').prop('disabled', false);
                    }
                });
            };

            const isValidEmailFormat = (value) => {
                const email = String(value || '').trim();
                return email !== '' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
            };

            const emailChangeIsPending = () => {
                const nextEmail = String($email.val() || '').trim().toLowerCase();
                const original = String(currentEmail).trim().toLowerCase();
                return nextEmail !== '' && nextEmail !== original;
            };

            const isEmail2faRowVisible = () => $row.length && !$row.prop('hidden');

            const hideEmail2faRow = () => {
                if ($row.length) {
                    $row.prop('hidden', true).attr('hidden', 'hidden');
                }
                resetEmail2faVerification();
            };

            const showEmail2faRow = (focusPin = false) => {
                if (!requires2fa || !$row.length) {
                    return;
                }
                if (!emailChangeIsPending() || !isValidEmailFormat($email.val())) {
                    hideEmail2faRow();
                    return;
                }

                $row.prop('hidden', false).removeAttr('hidden');
                sync2faFieldVisibility(false);

                if (focusPin && $pin.length && normalizeEmail2faProvider(getSelectedEmail2faProvider()) === 'totp') {
                    window.setTimeout(() => {
                        focusPinDigit(0);
                    }, 50);
                }
            };

            const submitEmail2faFromUi = () => {
                if ($token.val()) {
                    return;
                }

                if (!ProfileEditor.emailChangeRequiresVerification($form) || !isEmail2faRowVisible()) {
                    return;
                }

                const provider = getSelectedEmail2faProvider();
                const providerField = normalizeEmail2faProvider(provider);
                const payload = { email_change_2fa_provider: provider };

                if (String($form.data('email-password-fallback')) === '1') {
                    const pass = String($form.find('[name="current_pass"]').val() || '');
                    if (!pass) {
                        return;
                    }
                    payload.current_pass = pass;
                    payload.email_change_2fa_provider = 'password';
                } else if (providerField === 'backup_codes') {
                    const backup = String($form.find('[name="backup_code"]').val() || '').trim();
                    if (backup.length < 8) {
                        return;
                    }
                    payload.backup_code = backup;
                } else {
                    const code = readPinValue();
                    if (code.length < pinDigits) {
                        return;
                    }
                    payload.authcode = code;
                }

                requestEmail2faVerify(payload);
            };

            const scheduleAutoVerifyPin = () => {
                window.setTimeout(() => {
                    tryAutoVerifyPin();
                }, 0);
            };

            const tryAutoVerifyPin = () => {
                if ($token.val() || verifying2fa) {
                    return;
                }
                if (!ProfileEditor.emailChangeRequiresVerification($form) || !isEmail2faRowVisible()) {
                    return;
                }
                if (!isValidEmailFormat($email.val())) {
                    return;
                }
                if (normalizeEmail2faProvider(getSelectedEmail2faProvider()) !== 'totp') {
                    return;
                }
                const code = readPinValue();
                if (code.length !== pinDigits) {
                    return;
                }
                submitEmail2faFromUi();
            };

            const getPinDigits = () => $pin.find('.yoo-profile-email-2fa-pin__digit');

            const focusPinDigit = (index) => {
                const $target = getPinDigits().eq(index);
                if ($target.length) {
                    $target.trigger('focus').trigger('select');
                }
            };

            const fillPinFromString = (startIndex, raw) => {
                const $digits = getPinDigits();
                const chars = String(raw || '').replace(/\D/g, '').slice(0, pinDigits);
                if (!chars || !$digits.length) {
                    return;
                }

                let idx = Math.max(0, startIndex);
                chars.split('').forEach((ch) => {
                    if (idx >= pinDigits) {
                        return;
                    }
                    $digits.eq(idx).val(ch);
                    idx += 1;
                });
                syncPinHidden();

                if (readPinValue().length >= pinDigits) {
                    scheduleAutoVerifyPin();
                } else {
                    focusPinDigit(idx);
                }
            };

            const bindEmail2faPin = () => {
                if (!$pin.length || $form.data('yoo-email-pin-bound') === 1) {
                    return;
                }
                $form.data('yoo-email-pin-bound', 1);

                const handlePinDigitInput = ($input) => {
                    const index = getPinDigits().index($input);
                    if (index < 0) {
                        return;
                    }

                    if ($token.val() || verifying2fa) {
                        return;
                    }

                    if ($pin.hasClass('is-error')) {
                        $pin.removeClass('is-error');
                        $status.prop('hidden', true).removeClass('is-error');
                    }

                    let val = String($input.val() || '').replace(/\D/g, '');
                    if (val.length > 1) {
                        $input.val(val.charAt(0));
                        fillPinFromString(index + 1, val.slice(1));
                        return;
                    }

                    $input.val(val);
                    syncPinHidden();

                    if (val && index < pinDigits - 1) {
                        focusPinDigit(index + 1);
                        return;
                    }

                    scheduleAutoVerifyPin();
                };

                $form.on('input.yooEmail2faPin change.yooEmail2faPin', '.yoo-profile-email-2fa-pin__digit', function() {
                    handlePinDigitInput($(this));
                });

                $form.on('keyup.yooEmail2faPin', '.yoo-profile-email-2fa-pin__digit', function(e) {
                    if (e.key === 'Enter') {
                        handlePinDigitInput($(this));
                    }
                });

                $form.on('keydown.yooEmail2faPin', '.yoo-profile-email-2fa-pin__digit', function(e) {
                    const $input = $(this);
                    const index = getPinDigits().index($input);
                    if (index < 0) {
                        return;
                    }

                    if (e.key === 'Backspace' && !$input.val() && index > 0) {
                        e.preventDefault();
                        focusPinDigit(index - 1);
                    } else if (e.key === 'ArrowLeft' && index > 0) {
                        e.preventDefault();
                        focusPinDigit(index - 1);
                    } else if (e.key === 'ArrowRight' && index < pinDigits - 1) {
                        e.preventDefault();
                        focusPinDigit(index + 1);
                    }
                });

                $form.on('paste.yooEmail2faPin', '.yoo-profile-email-2fa-pin__digit', function(e) {
                    e.preventDefault();
                    const $input = $(this);
                    const index = getPinDigits().index($input);
                    const pasted = (e.originalEvent && e.originalEvent.clipboardData)
                        ? e.originalEvent.clipboardData.getData('text')
                        : '';
                    fillPinFromString(index, pasted);
                });
            };

            const commitEmailChangeVerification = () => {
                if (!emailChangeIsPending()) {
                    hideEmail2faRow();
                    return;
                }
                if (!isValidEmailFormat($email.val())) {
                    hideEmail2faRow();
                    return;
                }
                resetEmail2faVerification();
                showEmail2faRow(true);
            };

            const sync2faFieldVisibility = (resetVerification = true) => {
                const fieldKey = normalizeEmail2faProvider(getSelectedEmail2faProvider());
                $form.find('.yoo-profile-email-2fa-field').prop('hidden', true);

                let $target = $form.find(`.yoo-profile-email-2fa-field[data-2fa-field="${fieldKey}"]`);
                if (!$target.length) {
                    $target = $form.find('.yoo-profile-email-2fa-field').filter(function() {
                        const providers = String($(this).data('2fa-providers') || $(this).data('2fa-field') || '')
                            .split(',')
                            .map((item) => normalizeEmail2faProvider(String(item || '').trim()));
                        return providers.includes(fieldKey);
                    }).first();
                }

                if ($target.length) {
                    $target.prop('hidden', false);
                } else {
                    $form.find('.yoo-profile-email-2fa-field--totp').prop('hidden', false);
                }

                if (resetVerification) {
                    resetEmail2faVerification();
                }
            };

            $email.on('input', () => {
                if ($token.val() || $form.hasClass('is-email-2fa-verified')) {
                    resetEmail2faVerification();
                }
                if ($row.length) {
                    $row.prop('hidden', true).attr('hidden', 'hidden');
                }
            });

            $email.on('blur', commitEmailChangeVerification);

            $email.on('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    commitEmailChangeVerification();
                }
            });

            $('#yoo-email-change-2fa-provider').on('change', () => sync2faFieldVisibility(true));
            $('#yoo-email-change-backup').on('input', function() {
                const normalized = String($(this).val() || '').toLowerCase().replace(/[^a-z0-9]/g, '');
                if ($(this).val() !== normalized) {
                    $(this).val(normalized);
                }
            });
            $('#yoo-email-change-backup').on('blur', submitEmail2faFromUi);
            $('#yoo-email-change-backup').on('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    submitEmail2faFromUi();
                }
            });
            $('#yoo-email-change-pass').on('blur', submitEmail2faFromUi);
            $('#yoo-email-change-pass').on('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    submitEmail2faFromUi();
                }
            });

            bindEmail2faPin();
            sync2faFieldVisibility();
            hideEmail2faRow();
        },

        emailChangeRequiresVerification: function($form) {
            const currentEmail = String($form.data('current-email') || '').trim().toLowerCase();
            const nextEmail = String($form.find('#yoo-email').val() || '').trim().toLowerCase();
            return nextEmail !== '' && nextEmail !== currentEmail;
        },

        initProfileTabs: function() {
            const $wrap = $('[data-yoo-profile-tabs]');
            if (!$wrap.length) {
                return;
            }

            const $nav = $wrap.find('.yp-tab-nav').first();
            const $panels = $wrap.find('.yp-tab-panels').first();
            if (!$nav.length || !$panels.length) {
                return;
            }

            let ink = $nav.find('.yp-tab-ink')[0];
            if (!ink) {
                ink = document.createElement('span');
                ink.className = 'yp-tab-ink';
                $nav[0].appendChild(ink);
            }

            const moveInk = ($btn) => {
                if (!$btn || !$btn.length) {
                    return;
                }
                const r = $btn[0].getBoundingClientRect();
                const rn = $nav[0].getBoundingClientRect();
                const isRtl = document.documentElement.dir === 'rtl'
                    || document.body.classList.contains('rtl')
                    || document.body.classList.contains('yooadmin-arabic-ui');
                ink.style.width = `${r.width}px`;
                if (isRtl) {
                    ink.style.left = 'auto';
                    ink.style.right = `${rn.right - r.right}px`;
                } else {
                    ink.style.right = 'auto';
                    ink.style.left = `${r.left - rn.left}px`;
                }
            };

            const activate = ($btn, updateQuery) => {
                const key = $btn.attr('data-profile-tab');
                if (!key) {
                    return;
                }

                $btn.addClass('is-active').attr('aria-selected', 'true')
                    .siblings('.yp-tab').removeClass('is-active').attr('aria-selected', 'false');

                $panels.children('.yoo-profile-tab-panel').removeClass('is-active').attr('hidden', 'hidden');
                $panels.children(`.yoo-profile-tab-panel[data-profile-panel="${key}"]`)
                    .addClass('is-active')
                    .removeAttr('hidden');

                moveInk($btn);

                if (updateQuery !== false && window.history && typeof window.history.replaceState === 'function') {
                    const url = new URL(window.location.href);
                    url.searchParams.set('profile_tab', key);
                    window.history.replaceState(null, '', url.toString());
                }
            };

            $nav.on('click', '.yp-tab', function(e) {
                if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.which === 2) {
                    return;
                }
                e.preventDefault();
                activate($(this), true);
            });

            let $current = $nav.find('.yp-tab.is-active').first();
            if (!$current.length) {
                $current = $nav.find('.yp-tab').first();
                if ($current.length) {
                    activate($current, false);
                }
            } else {
                moveInk($current);
            }

            $(window).on('resize.yooProfileTabs', () => {
                moveInk($nav.find('.yp-tab.is-active').first());
            });

            window.addEventListener('popstate', () => {
                const params = new URLSearchParams(window.location.search);
                const tabKey = params.get('profile_tab') || 'account';
                const $tab = $nav.find(`.yp-tab[data-profile-tab="${tabKey}"]`).first();
                if ($tab.length) {
                    activate($tab, false);
                }
            });
        },

        showToast: function(type, message) {
            const text = String(message || '').trim();
            if (!text) {
                return;
            }

            if (window.yooadmToast) {
                if (type === 'error' && typeof window.yooadmToast.error === 'function') {
                    window.yooadmToast.error(text);
                    return;
                }
                if (type === 'success' && typeof window.yooadmToast.success === 'function') {
                    window.yooadmToast.success(text);
                    return;
                }
                if (typeof window.yooadmToast.show === 'function') {
                    window.yooadmToast.show(text, type || 'success');
                    return;
                }
            }

            if (typeof window.yooadminShowToast === 'function') {
                window.yooadminShowToast(text, type || 'success');
                return;
            }

            this.showInlineNotice(type, text);
        },

        initFlashFromQuery: function() {
            const profileConfig = window.yooadmProfile || {};
            const params = new URLSearchParams(window.location.search);
            const flashes = [
                ['yooadmin_2fa_revalidated', 'success', profileConfig.i18n2faRevalidated],
                ['email_updated', 'success', profileConfig.i18nEmailUpdated],
                ['email_error', 'error', profileConfig.i18nEmailError],
                ['email_dismissed', 'info', profileConfig.i18nEmailDismissed],
            ];
            let changed = false;

            flashes.forEach(([key, type, message]) => {
                if (params.get(key) !== '1' || !message) {
                    return;
                }
                this.showToast(type, message);
                params.delete(key);
                changed = true;
            });

            if (!changed) {
                return;
            }

            const newSearch = params.toString();
            const newUrl = window.location.pathname
                + (newSearch ? '?' + newSearch : '')
                + window.location.hash;
            window.history.replaceState({}, '', newUrl);
        },

        flushInlineNotices: function() {
            $('.yooadmin-user-profile .notice.is-inline, .yooadmin-user-profile .yoo-profile-inline-notice').each((_, element) => {
                const $notice = $(element);
                const message = $notice.text().replace(/\s+/g, ' ').trim();

                if (message) {
                    this.showToast($notice.hasClass('notice-error') ? 'error' : 'success', message);
                }

                $notice.remove();
            });
        },

        bindEvents: function() {
            $(document).on('yooadminAvatarSourceChanged', (e, userData) => {
                if (!userData) {
                    return;
                }

                const $form = $('#yoo-profile-edit-form');
                const $select = $('#yooadmin-avatar-source');
                if (userData.avatar_source && $form.length && $select.length) {
                    const savedSource = String(userData.avatar_source);
                    $form.data('initial-avatar-source', savedSource);
                    $select.val(savedSource);
                    const native = $select[0];
                    if (native) {
                        native.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }

                this.updateProfileHero(userData);
            });

            // Profile edit form
            $('#yoo-profile-edit-form').on('submit', (e) => {
                e.preventDefault();
                this.handleProfileUpdate(e.target);
            });

            // Password change form
            $('#yoo-profile-password-form').on('submit', (e) => {
                e.preventDefault();
                this.handlePasswordUpdate(e.target);
            });

            // Send password reset button
            $('.yoo-send-password-reset').on('click', (e) => {
                e.preventDefault();
                const $btn = $(e.target).closest('.yoo-send-password-reset');
                const userId = $btn.data('user-id');
                this.handleSendPasswordReset(userId, $btn);
            });
        },

        getRoleValue: function($form) {
            const native = $form.find('select[name="role"]')[0];
            if (!native) {
                return null;
            }

            return typeof native.value === 'string' ? native.value : '';
        },

        handleProfileUpdate: function(form) {
            const $form = $(form);
            const $submitBtn = $form.find('button[type="submit"]');
            const userId = $form.data('user-id');
            const originalText = $submitBtn.text();
            const profileConfig = window.yooadmProfile || {};

            // Disable submit button
            $submitBtn.prop('disabled', true).text(profileConfig.i18nSaving || 'Saving...');

            if (String($form.data('requires-2fa-email')) === '1' && this.emailChangeRequiresVerification($form)) {
                const verifyToken = String($form.find('[name="email_change_2fa_token"]').val() || '').trim();
                if (!verifyToken) {
                    this.showToast('error', profileConfig.i18n2faRequired || 'Enter your two-factor code to confirm this email change.');
                    $submitBtn.prop('disabled', false).text(originalText);
                    return;
                }
            }

            let ajaxData = $form.serialize();
            ajaxData += '&action=yooadmin_update_profile';
            ajaxData += '&user_id=' + encodeURIComponent(String(userId));
            ajaxData += '&nonce=' + encodeURIComponent(String($form.find('[name="yooadmin_profile_nonce"]').val() || ''));

            $.ajax({
                url: profileConfig.ajaxUrl || window.ajaxurl,
                type: 'POST',
                data: ajaxData,
                success: (response) => {
                    if (response.success) {
                        this.showToast('success', response.data.message || 'Profile updated successfully.');
                        if (response.data.user && response.data.user.avatar_source) {
                            const savedSource = String(response.data.user.avatar_source);
                            $form.data('initial-avatar-source', savedSource);
                            $('#yooadmin-avatar-source').val(savedSource);
                            if (typeof response.data.plugins_panel_html === 'string') {
                                $('#yoo-profile-photo-plugins-cell').html(response.data.plugins_panel_html);
                            }
                        }
                        if (response.data.emailPending) {
                            $form.data('current-email', response.data.user && response.data.user.user_email ? response.data.user.user_email : $form.data('current-email'));
                            $form.find('#yoo-email').val($form.data('current-email'));
                            $('#yoo-profile-email-2fa-row').prop('hidden', true).attr('hidden', 'hidden');
                            $form.find('[name="authcode"], [name="backup_code"], [name="current_pass"], [name="email_change_2fa_token"]').val('');
                            $('#yoo-profile-email-2fa-status').prop('hidden', true);
                            $form.removeClass('is-email-2fa-verified');
                            $('#yoo-email-change-authcode-pin .yoo-profile-email-2fa-pin__digit').prop('disabled', false).val('');
                        }
                        const savedUser = response.data.user ? Object.assign({}, response.data.user) : null;
                        if (savedUser && String(savedUser.avatar_source) === 'plugins') {
                            const panelSrc = String(
                                $('#yoo-profile-photo-plugins-cell .sua-attachment-avatar').attr('src') || ''
                            );
                            if (panelSrc) {
                                savedUser.avatar_url = panelSrc;
                                savedUser.avatar_is_placeholder = false;
                            }
                        }
                        this.updateProfileHero(savedUser);
                    } else {
                        this.showToast('error', response.data.message || 'Failed to update profile.');
                    }
                },
                error: (xhr) => {
                    let message = 'An error occurred while updating the profile.';
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        message = xhr.responseJSON.data.message;
                    }
                    this.showToast('error', message);
                },
                complete: () => {
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            });
        },

        handlePasswordUpdate: function(form) {
            const $form = $(form);
            const $submitBtn = $form.find('button[type="submit"]');
            const userId = $form.data('user-id');
            const originalText = $submitBtn.text();
            const profileConfig = window.yooadmProfile || {};

            const pass1 = $form.find('[name="pass1"]').val();
            const pass2 = $form.find('[name="pass2"]').val();

            // Validate passwords
            if (!pass1 || !pass2) {
                this.showToast('error', profileConfig.i18nPasswordBoth || 'Please fill in both password fields.');
                return;
            }

            if (pass1 !== pass2) {
                this.showToast('error', profileConfig.i18nPasswordMismatch || 'The passwords do not match.');
                return;
            }

            if (pass1.length < 8) {
                this.showToast('error', profileConfig.i18nPasswordLength || 'Password must be at least 8 characters long.');
                return;
            }

            // Disable submit button
            $submitBtn.prop('disabled', true).text('Updating...');

            const formData = {
                action: 'yooadmin_update_password',
                user_id: userId,
                nonce: $form.find('[name="yooadmin_password_nonce"]').val(),
                pass1: pass1,
                pass2: pass2
            };

            $.ajax({
                url: profileConfig.ajaxUrl || window.ajaxurl,
                type: 'POST',
                data: formData,
                success: (response) => {
                    if (response.success) {
                        this.showToast('success', response.data.message || 'Password updated successfully.');
                        // Clear password fields
                        $form.find('[name="pass1"], [name="pass2"]').val('');
                    } else {
                        this.showToast('error', response.data.message || 'Failed to update password.');
                    }
                },
                error: (xhr) => {
                    let message = 'An error occurred while updating the password.';
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        message = xhr.responseJSON.data.message;
                    }
                    this.showToast('error', message);
                },
                complete: () => {
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            });
        },

        updateProfileHero: function(userData) {
            if (!userData) return;

            // Update avatar if provided
            if (userData.avatar_url) {
                const $img = $('.yoo-profile-avatar img');
                $img.attr('src', userData.avatar_url);
                if (userData.avatar_is_placeholder) {
                    $img.addClass('yoo-avatar--no-photo avatar-default');
                } else {
                    $img.removeClass('yoo-avatar--no-photo avatar-default');
                }

                if (typeof window.yooadminSyncShellAvatars === 'function') {
                    window.yooadminSyncShellAvatars(userData);
                }
            }

            if (userData.avatar_source) {
                const $avatar = $('#yoo-profile-avatar');
                const $overlay = $('#yoo-avatar-upload-overlay');
                const $deleteBtn = $('#yoo-avatar-delete-btn');
                const $hint = $('#yoo-profile-avatar-source-hint');
                const $pluginsRow = $('#yoo-profile-photo-plugins-row');
                const profileConfig = window.yooadmProfile || {};
                const hintLabels = profileConfig.avatarSourceHints || {
                    gravatar: 'Gravatar',
                    plugins: 'Plugin photo'
                };
                const source = String(userData.avatar_source);

                if ($avatar.length) {
                    $avatar
                        .attr('data-avatar-source', source)
                        .removeClass('yoo-profile-avatar--source-yooadmin yoo-profile-avatar--source-plugins yoo-profile-avatar--source-gravatar')
                        .addClass('yoo-profile-avatar--source-' + source);
                }

                const isYooadmin = source === 'yooadmin';
                if ($overlay.length) {
                    if (isYooadmin) {
                        $overlay.prop('hidden', false).removeAttr('hidden');
                    } else {
                        $overlay.prop('hidden', true).attr('hidden', 'hidden');
                    }
                }
                if ($deleteBtn.length) {
                    if (isYooadmin) {
                        $deleteBtn.prop('hidden', false).removeAttr('hidden');
                        $deleteBtn.attr(
                            'data-has-yooadmin-photo',
                            userData.has_custom_avatar ? '1' : '0'
                        );
                    } else {
                        $deleteBtn.prop('hidden', true).attr('hidden', 'hidden');
                    }
                }
                if ($hint.length) {
                    if (isYooadmin) {
                        $hint.prop('hidden', true).attr('hidden', 'hidden');
                    } else {
                        $hint.text(hintLabels[source] || '').prop('hidden', false).removeAttr('hidden');
                    }
                }
                if ($pluginsRow.length) {
                    if (source === 'plugins') {
                        $pluginsRow.prop('hidden', false).removeAttr('hidden');
                    } else {
                        $pluginsRow.prop('hidden', true).attr('hidden', 'hidden');
                    }
                }
            }

            // Update display name
            if (userData.display_name) {
                $('.yoo-profile-name').text(userData.display_name);
            }

            // Update email
            if (userData.user_email) {
                const $emailItem = $('.yoo-profile-meta-item--email a');
                if ($emailItem.length) {
                    $emailItem.attr('href', 'mailto:' + userData.user_email).text(userData.user_email);
                }
            }

            // Update roles
            if (userData.roles && userData.roles.length > 0) {
                const $tagsContainer = $('.yoo-profile-tags');
                $tagsContainer.empty();
                userData.roles.forEach(roleKey => {
                    const roleName = this.getRoleName(roleKey);
                    $tagsContainer.append(`<span class="yoo-role-tag">${roleName}</span>`);
                });

                const rolesLabel = userData.roles_label || userData.roles.map((roleKey) => this.getRoleName(roleKey)).join(', ');
                $('.yoo-profile-details-grid .yoo-profile-detail-row').each(function() {
                    const $row = $(this);
                    if ($row.find('.yoo-profile-detail-label .dashicons-groups').length) {
                        $row.find('.yoo-profile-detail-value').text(rolesLabel);
                    }
                });
            }
        },

        getRoleName: function(roleKey) {
            const profileConfig = window.yooadmProfile || {};
            // This will be localized from PHP
            if (profileConfig.roles && profileConfig.roles[roleKey]) {
                return profileConfig.roles[roleKey];
            }
            return roleKey.charAt(0).toUpperCase() + roleKey.slice(1);
        },

        handleSendPasswordReset: function(userId, $btn) {
            const originalText = $btn.html();
            const profileConfig = window.yooadmProfile || {};
            
            // Disable button
            $btn.prop('disabled', true).html('<span class="dashicons dashicons-update"></span> Sending...');

            const formData = {
                action: 'yooadmin_send_password_reset',
                user_id: userId,
                nonce: (window.yooadmProfile && window.yooadmProfile.nonce) || ''
            };

            $.ajax({
                url: profileConfig.ajaxUrl || window.ajaxurl,
                type: 'POST',
                data: formData,
                success: (response) => {
                    if (response.success) {
                        this.showToast('success', response.data.message || 'Password reset link sent successfully.');
                    } else {
                        this.showToast('error', response.data.message || 'Failed to send password reset link.');
                    }
                },
                error: (xhr) => {
                    let message = 'An error occurred while sending the password reset link.';
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        message = xhr.responseJSON.data.message;
                    }
                    this.showToast('error', message);
                },
                complete: () => {
                    $btn.prop('disabled', false).html(originalText);
                }
            });
        },

        showInlineNotice: function(type, message) {
            $('.yoo-profile-notice').remove();

            const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
            const icon = type === 'success' ? 'dashicons-yes-alt' : 'dashicons-warning';
            const iconColor = type === 'success' ? '#00a32a' : '#d63638';

            const $notice = $(`
                <div class="yoo-profile-notice notice ${noticeClass} is-inline" style="margin: 0 0 20px 0; padding: 12px 16px; background: #fffdf8; border: 1px solid #ffe9c1; border-radius: 4px;">
                    <span class="dashicons ${icon}" style="color: ${iconColor}; margin-right: 8px; vertical-align: middle;"></span>
                    <span style="vertical-align: middle;">${message}</span>
                </div>
            `);

            $('.yoo-profile-hero').after($notice);

            if (type === 'success') {
                setTimeout(() => {
                    $notice.fadeOut(300, function() {
                        $(this).remove();
                    });
                }, 5000);
            }
        }
    };

    // Initialize on document ready
    $(function() {
        if ($('.yooadmin-user-profile').length) {
            ProfileEditor.init();
        }
    });

})(jQuery);


























