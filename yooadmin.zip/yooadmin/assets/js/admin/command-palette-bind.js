(function () {
  if (window.__yooadminCommandPaletteBound) {
    return;
  }
  window.__yooadminCommandPaletteBound = true;

  var DESKTOP_BRIDGE = __DESKTOP_BRIDGE__;
  var APPLE = /Macintosh|Mac OS X|Mac_PowerPC/i;

  function canUseStore() {
    return !!(window.wp && wp.data && typeof wp.data.dispatch === 'function' && typeof wp.data.select === 'function');
  }

  function isDesktopModeBridgeContext() {
    if (DESKTOP_BRIDGE) {
      return true;
    }
    if (document.body && document.body.classList.contains('desktop-mode-chromeless')) {
      return true;
    }
    if (document.getElementById('desktop-mode-shell') || (document.body && document.body.classList.contains('yooadmin-desktop-shell'))) {
      return true;
    }
    try {
      if (window.parent && window.parent !== window && window.parent.document.getElementById('desktop-mode-shell')) {
        return true;
      }
    } catch (err) {
      // Cross-origin parent; fall through.
    }
    return false;
  }

  function openDesktopModePalette(event) {
    if (event && typeof event.preventDefault === 'function') {
      event.preventDefault();
    }
    if (event && typeof event.stopPropagation === 'function') {
      event.stopPropagation();
    }

    var origin = window.location.origin;
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'desktop-mode-palette-cycle' }, origin);
        return true;
      }
    } catch (err) {
      // Fall through to same-window message.
    }

    try {
      window.postMessage({ type: 'desktop-mode-palette-cycle' }, origin);
      return true;
    } catch (err2) {
      return false;
    }
  }

  function toggleCommandPalette(event) {
    if (!canUseStore()) {
      return false;
    }
    try {
      var isOpen = !!wp.data.select('core/commands').isOpen();
      if (isOpen) {
        wp.data.dispatch('core/commands').close();
      } else {
        wp.data.dispatch('core/commands').open();
      }
      if (event && typeof event.preventDefault === 'function') {
        event.preventDefault();
      }
      return true;
    } catch (err) {
      return false;
    }
  }

  function openCommandPalette(event) {
    if (isDesktopModeBridgeContext()) {
      return openDesktopModePalette(event);
    }
    return toggleCommandPalette(event);
  }

  function syncAppleLabel(btn) {
    if (!btn || !APPLE.test(navigator.userAgent)) {
      return;
    }
    var kbd = btn.querySelector('.yp-command-palette-trigger__kbd');
    var apple = btn.getAttribute('data-apple-shortcut');
    if (kbd && apple) {
      kbd.textContent = apple;
    }
  }

  function bindTriggers() {
    var found = false;
    document.querySelectorAll('.yp-command-palette-trigger').forEach(function (btn) {
      found = true;
      if (btn.dataset.cpBound === '1') {
        return;
      }
      syncAppleLabel(btn);
      btn.addEventListener('click', function (e) {
        openCommandPalette(e);
      });
      btn.dataset.cpBound = '1';
    });
    return found;
  }

  window.yooadminOpenCommandPalette = function () {
    if (isDesktopModeBridgeContext()) {
      return openDesktopModePalette(null);
    }
    if (!canUseStore()) {
      return false;
    }
    try {
      if (!wp.data.select('core/commands').isOpen()) {
        wp.data.dispatch('core/commands').open();
      }
      return true;
    } catch (err) {
      return false;
    }
  };

  bindTriggers();
  if (!document.querySelector('.yp-command-palette-trigger')) {
    var obs = new MutationObserver(function () {
      if (bindTriggers()) {
        obs.disconnect();
      }
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });
  }

  if (isDesktopModeBridgeContext()) {
    return;
  }

  function patchCommandPaletteSearchIcon() {
    var icon = document.querySelector('.commands-command-menu__header-search-icon');
    if (!icon || icon.classList.contains('dashicons-search')) {
      return false;
    }
    var dashicon = document.createElement('span');
    dashicon.className = 'commands-command-menu__header-search-icon yp-command-palette-search-icon dashicons dashicons-search';
    dashicon.setAttribute('aria-hidden', 'true');
    icon.replaceWith(dashicon);
    return true;
  }

  function watchCommandPaletteSearchIcon() {
    patchCommandPaletteSearchIcon();
    var iconObs = new MutationObserver(function () {
      patchCommandPaletteSearchIcon();
    });
    iconObs.observe(document.documentElement, { childList: true, subtree: true });
  }

  watchCommandPaletteSearchIcon();
})();
