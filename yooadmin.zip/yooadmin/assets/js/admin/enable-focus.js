/**
 * YOOAdmin - Enable focus mode (redirect after submit)
 *
 * @package YOOAdmin
 */
(function () {
    'use strict';

    function showBackgroundTransition() {
        var overlay = document.getElementById('yoo-focus-page-transition');
        if (overlay) {
            if (overlay.parentNode !== document.body) {
                document.body.appendChild(overlay);
            }
            overlay.removeAttribute('hidden');
            overlay.classList.add('is-visible');
            overlay.setAttribute('aria-hidden', 'false');
        }
        if (document.body) {
            document.body.classList.add('yoo-focus-page-transitioning');
            document.body.classList.remove('yp-modal-open', 'yoo-focus-modal-open');
        }
    }

    if (window.yooadmFocusRedirect && window.yooadmFocusRedirect.url) {
        showBackgroundTransition();
        window.location.replace(window.yooadmFocusRedirect.url);
    }
})();
