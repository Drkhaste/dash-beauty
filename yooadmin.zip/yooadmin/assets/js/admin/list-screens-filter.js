/**
 * YOOAdmin - List screens filter (dropdown)
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // Don't convert filter on WordPress default plugins.php page
        const isDefaultPluginsPage = window.location.pathname.includes('plugins.php');
        
        if (isDefaultPluginsPage) {
            // Setup filter for new plugins page if exists
            setupNewPluginsFilter();
            return;
        }
        
        const $subsubsub = $('.yoo-list-screen .subsubsub');
        
        if (!$subsubsub.length) {
            // If on new plugins page, setup filter
            setupNewPluginsFilter();
            return;
        }

        // Get current URL for building filter links
        const currentUrl = new URL(window.location.href);
        
        // Create select element
        const $select = $('<select>', {
            class: 'yoo-filter-dropdown',
            'aria-label': 'Filter items'
        });

        // Convert each link to option
        $subsubsub.find('a').each(function() {
            const $link = $(this);
            const text = $link.clone().children().remove().end().text().trim();
            const count = $link.find('.count').text().trim();
            const href = $link.attr('href');
            const isCurrent = $link.hasClass('current');
            
            const optionText = count ? `${text} ${count}` : text;
            
            const $option = $('<option>', {
                value: href,
                text: optionText,
                selected: isCurrent
            });
            
            $select.append($option);
        });

        // Create wrapper for better styling
        const $wrapper = $('<div>', {
            class: 'yoo-filter-wrapper'
        });
        
        $wrapper.append($select);
        
        // Replace original filters
        $subsubsub.replaceWith($wrapper);

        // Handle change event
        $select.on('change', function() {
            const url = $(this).val();
            if (url) {
                window.location.href = url;
            }
        });
    });
    
    // Setup filter for new plugins page
    function setupNewPluginsFilter() {
        const $filter = $('#yoo-plugins-filter');
        if (!$filter.length) return;
        
        $filter.on('change', function() {
            const filterValue = $(this).val();
            const $cards = $('.yoo-plugin-card');
            
            $cards.each(function() {
                const $card = $(this);
                const isActive = $card.hasClass('active');
                const hasUpdate = $card.hasClass('has-update');
                
                let show = false;
                
                switch(filterValue) {
                    case 'all':
                        show = true;
                        break;
                    case 'active':
                        show = isActive;
                        break;
                    case 'inactive':
                        show = !isActive;
                        break;
                    case 'update':
                        show = hasUpdate;
                        break;
                }
                
                $card.toggle(show);
            });
        });
    }

})(jQuery);
