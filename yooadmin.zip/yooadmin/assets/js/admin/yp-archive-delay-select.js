(function () {
	'use strict';

	var SETTINGS_ROOTS = [
		'.yooadmin-settings-wrap',
		'.yooadmin-settings-container',
		'.wrap.yoo-upload-wrap',
		'.wrap.yooadmin-extensions-page',
		'.wrap.yooadmin-extensions-manager',
		'.wrap.yooadmin-plugins-page',
		'.yoo-plugins-bulk-bar',
		'.yoo-bulk-actions-bar',
		'.yoo-bulk-actions-left',
		'.yooadmin-posts-page',
		'.yooadmin-pages-page',
		'.yooadmin-users-page',
		'.yooadmin-user-profile',
		'.yooadmin-plugin-install-page'
	];
	/** Native select hooks in Focus Mode (plugin-install filter, wp-filter, bulk bars, etc.). */
	var ADMIN_FOCUS_SELECT_HOOKS = [
		'.wp-filter select:not([multiple])',
		'.search-box select:not([multiple])',
		'form.search-plugins select:not([multiple])',
		'.tablenav.top .actions select:not([multiple])',
		'.tablenav.bottom .actions select:not([multiple])'
	];
	var UI_ROOT = '.yp-ui-select';
	var __ypUiSelUid = 0;

	function isFocusAdminShell() {
		return !!(document.body && document.body.classList.contains('yoo-focus'));
	}

	function inSettingsContext(el) {
		if (!el || !el.closest) return false;
		if (el.closest('body.yoo-wp-settings-experience')) return true;
		for (var i = 0; i < SETTINGS_ROOTS.length; i++) {
			if (el.closest(SETTINGS_ROOTS[i])) return true;
		}
		return false;
	}

	function closest(el, sel) {
		if (!el || !el.closest) return null;
		return el.closest(sel);
	}

	/** Drop list may live under root or be portaled to document.body (aria-controls id). */
	function resolveDropList(root) {
		if (!root) return null;
		var btn = root.querySelector('.yp-custom-select__trigger');
		if (btn) {
			var listId = btn.getAttribute('aria-controls');
			if (listId) {
				var byId = document.getElementById(listId);
				if (byId && byId.classList.contains('yp-custom-select__drop')) {
					return byId;
				}
			}
		}
		return root.querySelector('.yp-custom-select__drop');
	}

	function findUiRootForList(list) {
		if (!list || !list.id) return null;
		var btn = document.querySelector(
			'.yp-custom-select__trigger[aria-controls="' + list.id + '"]'
		);
		return btn && btn.closest ? btn.closest(UI_ROOT) : null;
	}

	function clickIsInsideSelectUi(target) {
		if (!target) return false;
		if (closest(target, UI_ROOT)) return true;
		if (closest(target, '.yp-custom-select__drop')) return true;
		if (closest(target, '.yp-custom-select__option')) return true;
		return false;
	}

	function isPlaceholderValue(val) {
		return val === '' || val === '-1';
	}

	function isPlaceholderOptionEl(optEl, val) {
		if (!optEl) return false;
		if (val == null) {
			val = optEl.getAttribute('data-value');
		}
		if (val == null) val = '';
		return (
			optEl.classList.contains('is-disabled') &&
			isPlaceholderValue(String(val))
		);
	}

	function shouldHighlightSelected(optEl, val, nativeVal) {
		if (val == null) {
			val = optEl.getAttribute('data-value');
		}
		if (val == null) val = '';
		if (String(val) !== String(nativeVal)) return false;
		return !isPlaceholderOptionEl(optEl, val);
	}

	function syncFromHidden(root) {
		var hidden = root.querySelector('input[type="hidden"]');
		var btn = root.querySelector('.yp-custom-select__trigger');
		var valEl = root.querySelector('.yp-custom-select__value');
		var list = resolveDropList(root);
		if (!hidden || !btn || !valEl || !list) return;

		var v = String(hidden.value);
		var opts = list.querySelectorAll('.yp-custom-select__option');
		var label = '';
		for (var i = 0; i < opts.length; i++) {
			var o = opts[i];
			var ov = o.getAttribute('data-value');
			if (ov == null) ov = '';
			var match = shouldHighlightSelected(o, ov, v);
			o.classList.toggle('is-selected', match);
			o.setAttribute('aria-selected', match ? 'true' : 'false');
			if (String(ov) === v) {
				label = o.getAttribute('data-label') || o.textContent || '';
			}
		}
		valEl.textContent = (label || '').trim();
	}

	function syncFromNative(root, native) {
		var btn = root.querySelector('.yp-custom-select__trigger');
		var valEl = root.querySelector('.yp-custom-select__value');
		var list = resolveDropList(root);
		if (!native || !btn || !valEl || !list) return;

		if (
			root.getAttribute('data-yp-lazy-options') === '1' &&
			root.getAttribute('data-yp-lazy-built') !== '1'
		) {
			var selected = native.options[native.selectedIndex];
			valEl.textContent = selected
				? (selected.textContent || '').replace(/\s+/g, ' ').trim()
				: '';
			if (native.disabled) {
				btn.setAttribute('disabled', 'disabled');
				root.classList.add('is-disabled');
			} else {
				btn.removeAttribute('disabled');
				root.classList.remove('is-disabled');
			}
			return;
		}

		var v = String(native.value);
		var opts = list.querySelectorAll('.yp-custom-select__option');
		var label = '';
		for (var i = 0; i < opts.length; i++) {
			var o = opts[i];
			var ov = o.getAttribute('data-value');
			if (ov == null) ov = '';
			var match = shouldHighlightSelected(o, ov, v);
			o.classList.toggle('is-selected', match);
			o.setAttribute('aria-selected', match ? 'true' : 'false');
			if (String(ov) === v) {
				label = o.getAttribute('data-label') || o.textContent || '';
			}
		}
		valEl.textContent = (label || '').trim();
		if (native.disabled) {
			btn.setAttribute('disabled', 'disabled');
			root.classList.add('is-disabled');
		} else {
			btn.removeAttribute('disabled');
			root.classList.remove('is-disabled');
		}
	}

	function needsPortaledDropdown(root) {
		if (!root || !root.closest) return false;
		return !!(
			root.closest('.yp-tabs') ||
			root.closest('#tab-login') ||
			root.closest('#tab-login-security')
		);
	}

	function positionPortaledDropdown(root, list) {
		var btn = root.querySelector('.yp-custom-select__trigger');
		if (!btn || !list) return;
		var rect = btn.getBoundingClientRect();
		var rtl =
			document.documentElement.getAttribute('dir') === 'rtl' ||
			(document.body &&
				(document.body.classList.contains('rtl') ||
					document.body.classList.contains('yooadmin-arabic-ui')));
		list.style.position = 'fixed';
		list.style.top = rect.bottom + 4 + 'px';
		list.style.width = Math.max(rect.width, 160) + 'px';
		list.style.zIndex = '10000100';
		list.style.maxHeight = Math.max(120, window.innerHeight - rect.bottom - 16) + 'px';
		list.style.overflowY = 'auto';
		list.style.pointerEvents = 'auto';
		if (rtl) {
			list.style.left = 'auto';
			list.style.right = window.innerWidth - rect.right + 'px';
		} else {
			list.style.left = rect.left + 'px';
			list.style.right = 'auto';
		}
	}

	function restorePortaledDropdown(root, list) {
		if (!root || !list) return;
		if (root.getAttribute('data-yp-portal-drop') !== '1') return;
		root.appendChild(list);
		root.removeAttribute('data-yp-portal-drop');
		list.classList.remove('yp-custom-select__drop--portal');
		list.removeAttribute('style');
	}

	function setOpen(root, open) {
		var btn = root.querySelector('.yp-custom-select__trigger');
		var list = resolveDropList(root);
		if (!btn || !list) return;
		root.classList.toggle('is-open', !!open);
		btn.setAttribute('aria-expanded', open ? 'true' : 'false');
		if (open) {
			if (needsPortaledDropdown(root)) {
				list.classList.add('yp-custom-select__drop--portal');
				document.body.appendChild(list);
				root.setAttribute('data-yp-portal-drop', '1');
				positionPortaledDropdown(root, list);
			}
			list.removeAttribute('hidden');
		} else {
			list.setAttribute('hidden', 'hidden');
			restorePortaledDropdown(root, list);
		}
	}

	function focusListOption(list) {
		if (!list) return;
		var cur = list.querySelector('.yp-custom-select__option.is-selected:not(.is-disabled)');
		var first = list.querySelector('.yp-custom-select__option:not(.is-disabled)');
		var target = cur || first || list.querySelector('.yp-custom-select__option');
		if (!target || typeof target.focus !== 'function') return;
		target.focus();
		if (typeof target.scrollIntoView === 'function') {
			target.scrollIntoView({ block: 'nearest', inline: 'nearest' });
		}
	}

	function closeOthers(except) {
		var all = document.querySelectorAll('.yp-ui-select.is-open');
		for (var i = 0; i < all.length; i++) {
			if (except && all[i] === except) continue;
			setOpen(all[i], false);
		}
	}

	function bindListNav(list, btn) {
		list.addEventListener('keydown', function (e) {
			var key = e.key || e.keyCode;
			var opts = [].slice.call(list.querySelectorAll('.yp-custom-select__option:not(.is-disabled)'));
			if (!opts.length) return;
			var ix = opts.indexOf(document.activeElement);
			if (key === 'Escape' || key === 'Esc' || key === 27) {
				e.preventDefault();
				var navRoot = findUiRootForList(list) || closest(list, UI_ROOT);
				if (navRoot) {
					setOpen(navRoot, false);
				}
				btn.focus();
				return;
			}
			if (key === 'ArrowDown' || key === 40) {
				e.preventDefault();
				var n = ix < 0 ? 0 : Math.min(opts.length - 1, ix + 1);
				opts[n].focus();
				return;
			}
			if (key === 'ArrowUp' || key === 38) {
				e.preventDefault();
				var p = ix <= 0 ? 0 : ix - 1;
				opts[p].focus();
				return;
			}
			if (key === 'Enter' || key === 13 || key === ' ' || key === 32) {
				if (ix >= 0) {
					e.preventDefault();
					opts[ix].click();
				}
			}
		});
	}

	function initHiddenArchiveRoot(root) {
		if (!root || root.getAttribute('data-yp-ui-select-init') === '1') return;
		var hidden = root.querySelector('input[type="hidden"]');
		var btn = root.querySelector('.yp-custom-select__trigger');
		var list = root.querySelector('.yp-custom-select__drop');
		if (!hidden || !btn || !list) return;
		root.setAttribute('data-yp-ui-select-init', '1');

		syncFromHidden(root);

		btn.addEventListener('click', function (e) {
			e.preventDefault();
			e.stopPropagation();
			var open = !root.classList.contains('is-open');
			closeOthers(root);
			setOpen(root, open);
			if (open) {
				focusListOption(list);
			}
		});

		list.addEventListener('click', function (e) {
			var opt = closest(e.target, '.yp-custom-select__option');
			if (!opt || !list.contains(opt) || opt.classList.contains('is-disabled')) return;
			e.preventDefault();
			var val = opt.getAttribute('data-value');
			if (val == null) return;
			hidden.value = String(val);
			try {
				hidden.dispatchEvent(new Event('change', { bubbles: true }));
			} catch (err) {}
			syncFromHidden(root);
			setOpen(root, false);
			btn.focus();
		});

		bindListNav(list, btn);
	}

	function initNativeEnhanced(root, native) {
		if (!root || !native || root.getAttribute('data-yp-ui-select-init') === '1') return;

		native.classList.add('yp-custom-select__native');

		var btn = root.querySelector('.yp-custom-select__trigger');
		var list = root.querySelector('.yp-custom-select__drop');
		if (!btn || !list) return;

		root.setAttribute('data-yp-ui-select-init', '1');

		syncFromNative(root, native);

		native.addEventListener('change', function () {
			syncFromNative(root, native);
		});

		native.addEventListener('focus', function () {
			requestAnimationFrame(function () {
				if (document.activeElement === native && btn && typeof btn.focus === 'function') {
					btn.focus();
				}
			});
		});

		btn.addEventListener('click', function (e) {
			if (native.disabled) return;
			e.preventDefault();
			e.stopPropagation();
			var open = !root.classList.contains('is-open');
			if (open) {
				ensureListBuilt(root, native, list);
			}
			closeOthers(root);
			setOpen(root, open);
			if (open) {
				focusListOption(list);
			}
		});

		list.addEventListener('mousedown', function (e) {
			e.stopPropagation();
		});

		list.addEventListener('click', function (e) {
			var opt = closest(e.target, '.yp-custom-select__option');
			if (!opt || !list.contains(opt) || opt.classList.contains('is-disabled')) return;
			e.preventDefault();
			e.stopPropagation();
			var val = opt.getAttribute('data-value');
			if (val == null) return;
			native.value = String(val);
			try {
				native.dispatchEvent(new Event('change', { bubbles: true }));
			} catch (err) {}
			if (typeof window.jQuery !== 'undefined' && window.jQuery && window.jQuery(native).trigger) {
				window.jQuery(native).trigger('change');
			}
			syncFromNative(root, native);
			setOpen(root, false);
			btn.focus();
		});

		bindListNav(list, btn);
	}

	function inAdminFocusSelectContext(sel) {
		if (!isFocusAdminShell() || !sel || !sel.closest) return false;
		if (!sel.closest('#wpbody-content')) return false;
		if (inSettingsContext(sel)) return true;
		if (sel.id === 'typeselector') return true;
		if (sel.closest('.search-box, .wp-filter, .yoo-plugin-install-search')) return true;
		if (sel.closest('.tablenav .actions')) return true;
		return false;
	}

	function shouldSkipEvenWhenForced(sel) {
		if (!sel) return true;
		if (sel.id === 'timezone_string' || sel.id === 'WPLANG') return true;
		var n = sel.options ? sel.options.length : 0;
		return n > 80;
	}

	function shouldSkipNativeSelect(sel, options) {
		options = options || {};
		if (!sel || !sel.closest) return true;
		if (sel.closest(UI_ROOT)) return true;
		if (sel.hasAttribute('multiple')) return true;
		if (sel.getAttribute('data-yp-select-native') === '1') return true;
		if (sel.classList && sel.classList.contains('select2-hidden-accessible')) return true;
		if (sel.size > 1) return true;
		if (options.force) {
			if (shouldSkipEvenWhenForced(sel)) return true;
		} else if (!inSettingsContext(sel) && !inAdminFocusSelectContext(sel)) {
			return true;
		}
		return false;
	}

	function appendOptionLi(list, opt, native) {
		var val = opt.value;
		var text = (opt.textContent || '').replace(/\s+/g, ' ').trim();
		var lab = text;
		var dis = opt.disabled;
		var placeholder = dis && isPlaceholderValue(String(val));
		var isCurrent = String(native.value) === String(val);
		var highlight = isCurrent && !placeholder;

		var li = document.createElement('li');
		li.setAttribute('role', 'option');
		li.className =
			'yp-custom-select__option' +
			(highlight ? ' is-selected' : '') +
			(dis ? ' is-disabled' : '') +
			(placeholder ? ' is-placeholder' : '');
		li.setAttribute('tabindex', '-1');
		li.setAttribute('data-value', val);
		li.setAttribute('data-label', lab);
		li.setAttribute('aria-selected', highlight ? 'true' : 'false');
		if (dis) {
			li.setAttribute('aria-disabled', 'true');
		}

		var row = document.createElement('span');
		row.className = 'yp-custom-select__option-row';
		var main = document.createElement('span');
		main.className = 'yp-custom-select__option-main';
		main.textContent = text;
		row.appendChild(main);
		li.appendChild(row);
		list.appendChild(li);
	}

	function populateListFromNative(native, list) {
		if (!native || !list) return;
		list.textContent = '';
		for (var i = 0; i < native.children.length; i++) {
			var child = native.children[i];
			if (child.tagName === 'OPTGROUP') {
				var groupLi = document.createElement('li');
				groupLi.className = 'yp-custom-select__option-group';
				groupLi.setAttribute('role', 'presentation');
				var groupLabel = document.createElement('span');
				groupLabel.className = 'yp-custom-select__option-group-label';
				groupLabel.textContent = (child.label || '').replace(/\s+/g, ' ').trim();
				groupLi.appendChild(groupLabel);
				list.appendChild(groupLi);
				var groupOpts = child.querySelectorAll('option');
				for (var g = 0; g < groupOpts.length; g++) {
					appendOptionLi(list, groupOpts[g], native);
				}
			} else if (child.tagName === 'OPTION') {
				appendOptionLi(list, child, native);
			}
		}
	}

	function shouldLazyBuildOptions(native, optionCount) {
		if (!native) return false;
		if (native.id === 'timezone_string' || native.id === 'WPLANG') return true;
		return optionCount > 60;
	}

	function ensureListBuilt(root, native, list) {
		if (!root || !native || !list) return;
		if (root.getAttribute('data-yp-lazy-options') !== '1') return;
		if (root.getAttribute('data-yp-lazy-built') === '1') return;
		populateListFromNative(native, list);
		root.setAttribute('data-yp-lazy-built', '1');
	}

	function wrapNativeSelect(native, options) {
		if (shouldSkipNativeSelect(native, options)) return;

		var opts = native.querySelectorAll('option');
		if (!opts.length) return;

		var uid = ++__ypUiSelUid;
		var idBase = 'yp_uisel_' + uid;
		var idTrig = idBase + '_trigger';
		var idList = idBase + '_list';

		var wrap = document.createElement('div');
		wrap.className = 'yp-ui-select yp-custom-select';
		wrap.setAttribute('data-yp-native-select', '1');

		var parent = native.parentNode;
		if (!parent) return;

		parent.insertBefore(wrap, native);
		wrap.appendChild(native);

		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'yp-custom-select__trigger';
		btn.id = idTrig;
		btn.setAttribute('aria-haspopup', 'listbox');
		btn.setAttribute('aria-expanded', 'false');
		btn.setAttribute('aria-controls', idList);
		if (native.disabled) {
			btn.setAttribute('disabled', 'disabled');
			wrap.classList.add('is-disabled');
		}

		var spanVal = document.createElement('span');
		spanVal.className = 'yp-custom-select__value';
		spanVal.setAttribute('aria-live', 'polite');

		var chev = document.createElement('span');
		chev.className = 'yp-custom-select__chevron dashicons dashicons-arrow-down-alt2';
		chev.setAttribute('aria-hidden', 'true');

		btn.appendChild(spanVal);
		btn.appendChild(chev);
		wrap.appendChild(btn);

		var list = document.createElement('ul');
		list.className = 'yp-custom-select__drop';
		list.id = idList;
		list.setAttribute('role', 'listbox');
		list.setAttribute('hidden', 'hidden');

		if (shouldLazyBuildOptions(native, opts.length)) {
			wrap.setAttribute('data-yp-lazy-options', '1');
		} else {
			populateListFromNative(native, list);
		}

		wrap.appendChild(list);
		initNativeEnhanced(wrap, native);
	}

	function initAllNativeInSettings() {
		for (var w = 0; w < SETTINGS_ROOTS.length; w++) {
			var wrapEls = document.querySelectorAll(SETTINGS_ROOTS[w]);
			for (var j = 0; j < wrapEls.length; j++) {
				var wrapEl = wrapEls[j];
				var sels = wrapEl.querySelectorAll('select:not([multiple])');
				for (var i = 0; i < sels.length; i++) {
					wrapNativeSelect(sels[i]);
				}
			}
		}
	}

	function isHiddenAdminSelect(sel) {
		if (!sel || !sel.closest) return false;
		var hiddenForm = sel.closest(
			'form[aria-hidden="true"], form[style*="display: none"], form[style*="display:none"]'
		);
		if (hiddenForm) return true;
		var hiddenAncestor = sel.closest('[aria-hidden="true"][hidden], [hidden]');
		return !!hiddenAncestor;
	}

	function initPluginInstallTypeSelector(root) {
		if (!document.body || !document.body.classList.contains('plugin-install-php')) return;
		var scope = root && root.querySelector ? root : document;
		var typeSel =
			scope.querySelector('.yoo-plugin-install-search #typeselector') ||
			scope.querySelector('.yoo-plugin-install-search select[name="type"]') ||
			scope.querySelector('#typeselector');
		if (!typeSel || typeSel.closest(UI_ROOT) || isHiddenAdminSelect(typeSel)) return;
		wrapNativeSelect(typeSel, { force: true });
		var ui = typeSel.closest(UI_ROOT);
		if (ui) {
			ui.classList.add('yp-ui-select--plugin-install-type');
		}
	}

	function initAllNativeInAdminFocus() {
		initPluginInstallTypeSelector(document);

		if (!isFocusAdminShell()) return;
		for (var h = 0; h < ADMIN_FOCUS_SELECT_HOOKS.length; h++) {
			var matches = document.querySelectorAll(ADMIN_FOCUS_SELECT_HOOKS[h]);
			for (var m = 0; m < matches.length; m++) {
				if (isHiddenAdminSelect(matches[m])) continue;
				wrapNativeSelect(matches[m], { force: true });
			}
		}
	}

	function initAll() {
		var roots = document.querySelectorAll('[data-yoo-archive-delay]');
		for (var i = 0; i < roots.length; i++) {
			initHiddenArchiveRoot(roots[i]);
		}
		initAllNativeInSettings();
		initAllNativeInAdminFocus();
	}

	if (!window.__yooUiSelectDocBound) {
		window.__yooUiSelectDocBound = true;
		document.addEventListener('mousedown', function (e) {
			if (clickIsInsideSelectUi(e.target)) return;
			closeOthers(null);
		});
		document.addEventListener('keydown', function (e) {
			if ((e.key || e.keyCode) === 'Escape' || e.keyCode === 27) {
				closeOthers(null);
			}
		});
	}

	if (!window.__yooUiSelectEnhanceBound) {
		window.__yooUiSelectEnhanceBound = true;
		document.addEventListener('yooadmin:enhance-native-selects', function (e) {
			var root = e && e.detail && e.detail.root ? e.detail.root : document;
			initPluginInstallTypeSelector(root);
			if (root && root.querySelectorAll) {
				var sels = root.querySelectorAll('select:not([multiple])');
				for (var i = 0; i < sels.length; i++) {
					if (!sels[i].closest(UI_ROOT)) {
						wrapNativeSelect(sels[i], { force: true });
					}
				}
			}
		});
	}

	window.yooadminUiSelect = {
		wrap: wrapNativeSelect,
		initAll: initAllNativeInSettings,
		initAdminFocus: initAllNativeInAdminFocus,
		initPluginInstallType: initPluginInstallTypeSelector,
		initIn: function (root) {
			if (!root || !root.querySelectorAll) return;
			var sels = root.querySelectorAll('select:not([multiple])');
			for (var i = 0; i < sels.length; i++) {
				wrapNativeSelect(sels[i], { force: true });
			}
		},
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initAll);
	} else {
		initAll();
	}
})();
