/**
 * YOOAi — promotional FAB + modal (no live AI).
 */
(function ($) {
  'use strict';

  var cfg = window.yooadminYooAi || {};
  var i18n = cfg.i18n || {};
  var typingState = { cancelled: false, timers: [] };

  function prefersReducedMotion() {
    return (
      window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
    );
  }

  function escHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function linkifyText(text) {
    var escaped = escHtml(text);
    return escaped.replace(
      /(\bhttps?:\/\/[^\s<]+|\b(?:www\.)?[a-z0-9][-a-z0-9]*\.[a-z]{2,})(?:\/[^\s<]*)?/gi,
      function (match) {
        var url = match;
        var trail = '';
        while (/[.,;:!?)]+$/.test(url)) {
          trail = url.slice(-1) + trail;
          url = url.slice(0, -1);
        }
        if (!url) {
          return match;
        }
        var href = /^https?:\/\//i.test(url) ? url : 'https://' + url;
        return (
          '<a href="' +
          escHtml(href) +
          '" class="yooai-msg__link" target="_blank" rel="noopener noreferrer">' +
          url +
          '</a>' +
          trail
        );
      }
    );
  }

  function setBubbleContent($bubble, plainText) {
    $bubble.html(linkifyText(plainText));
  }

  function scrollMessages($box) {
    if (!$box || !$box.length) {
      return;
    }
    $box.scrollTop($box[0].scrollHeight);
  }

  function appendMessage($box, role, html, meta) {
    var $msg = $('<article class="yooai-msg yooai-msg--' + role + '" />');
    if (meta) {
      $msg.append('<span class="yooai-msg__meta">' + escHtml(meta) + '</span>');
    }
    $msg.append('<div class="yooai-msg__bubble">' + html + '</div>');
    $box.append($msg);
    scrollMessages($box);
    return $msg;
  }

  function cancelTyping() {
    typingState.cancelled = true;
    typingState.timers.forEach(function (id) {
      window.clearTimeout(id);
    });
    typingState.timers = [];
  }

  function defer(fn, ms) {
    var id = window.setTimeout(function () {
      if (!typingState.cancelled) {
        fn();
      }
    }, ms);
    typingState.timers.push(id);
    return id;
  }

  function showTypingIndicator($box, meta) {
    $box.find('.yooai-msg--typing').remove();
    var $msg = $('<article class="yooai-msg yooai-msg--assistant yooai-msg--typing" aria-hidden="true" />');
    $msg.append('<span class="yooai-msg__meta">' + escHtml(meta || 'YOOAi') + '</span>');
    $msg.append(
      '<div class="yooai-msg__bubble"><span class="yooai-typing-dots" aria-hidden="true"><span></span><span></span><span></span></span></div>'
    );
    $box.append($msg);
    scrollMessages($box);
    return $msg;
  }

  function typeMessage($box, role, plainText, meta, done) {
    if (typingState.cancelled || !plainText) {
      if (done) {
        done();
      }
      return;
    }

    var $msg = $('<article class="yooai-msg yooai-msg--' + role + '" />');
    if (meta) {
      $msg.append('<span class="yooai-msg__meta">' + escHtml(meta) + '</span>');
    }
    var $bubble = $('<div class="yooai-msg__bubble" />');
    $msg.append($bubble);
    $box.append($msg);
    scrollMessages($box);

    if (prefersReducedMotion()) {
      setBubbleContent($bubble, plainText);
      scrollMessages($box);
      if (done) {
        done();
      }
      return;
    }

    var len = plainText.length;
    var step = len > 320 ? 4 : len > 160 ? 3 : len > 80 ? 2 : 1;
    var delay = role === 'system' ? 10 : len > 320 ? 12 : 18;
    var index = 0;

    function tick() {
      if (typingState.cancelled) {
        return;
      }
      index = Math.min(index + step, len);
      if (index >= len) {
        setBubbleContent($bubble, plainText);
        scrollMessages($box);
        if (done) {
          done();
        }
        return;
      }
      $bubble.text(plainText.slice(0, index));
      scrollMessages($box);
      typingState.timers.push(window.setTimeout(tick, delay));
    }

    tick();
  }

  function runMessageSequence($box, steps, onComplete) {
    cancelTyping();
    typingState.cancelled = false;
    $box.empty();

    if (!steps.length) {
      if (onComplete) {
        onComplete();
      }
      return;
    }

    if (prefersReducedMotion()) {
      steps.forEach(function (step) {
        appendMessage($box, step.role, linkifyText(step.text), step.meta);
      });
      if (onComplete) {
        onComplete();
      }
      return;
    }

    function runStep(idx) {
      if (typingState.cancelled || idx >= steps.length) {
        if (!typingState.cancelled && onComplete) {
          onComplete();
        }
        return;
      }

      var step = steps[idx];
      var pauseBefore = idx === 0 ? 280 : step.role === 'system' ? 360 : 520;
      var typingPause = step.role === 'system' ? 420 : 560;
      var meta = step.meta || (step.role === 'assistant' ? 'YOOAi' : '');

      defer(function () {
        var $typing = showTypingIndicator($box, meta || 'YOOAi');
        defer(function () {
          $typing.remove();
          typeMessage($box, step.role, step.text, meta, function () {
            defer(function () {
              runStep(idx + 1);
            }, pauseBefore);
          });
        }, typingPause);
      }, idx === 0 ? 120 : 0);
    }

    runStep(0);
  }

  function playWelcomeSequence($box, onComplete) {
    var steps = [];
    if (i18n.welcome) {
      steps.push({ role: 'assistant', text: i18n.welcome, meta: 'YOOAi' });
    }
    if (i18n.welcomeFollowup) {
      steps.push({ role: 'assistant', text: i18n.welcomeFollowup, meta: 'YOOAi' });
    }
    if (i18n.extendedPromo) {
      steps.push({ role: 'assistant', text: i18n.extendedPromo, meta: 'YOOAi' });
    }
    if (i18n.inactiveNotice) {
      steps.push({
        role: 'system',
        text: i18n.inactiveNotice,
        meta: i18n.badge || 'Coming soon'
      });
    }
    runMessageSequence($box, steps, onComplete);
  }

  function openModal($modal) {
    var $messages = $modal.find('[data-yooai-messages]');
    $modal.removeAttr('hidden').addClass('is-open').attr('aria-hidden', 'false');
    $('body').addClass('yooai-modal-open');
    playWelcomeSequence($messages);
  }

  function closeModal($modal) {
    cancelTyping();
    $modal.attr('hidden', 'hidden').removeClass('is-open').attr('aria-hidden', 'true');
    $('body').removeClass('yooai-modal-open');
  }

  var fabHiddenToastTimer = null;
  var fabHiddenToastHideTimer = null;

  /** Same toast as YOOAdmin (yp-toast-message, top-right). */
  function showFabHiddenToast() {
    var msg =
      (cfg.i18n && cfg.i18n.fabHiddenToast) ||
      'YOOAi button hidden. Turn it back on anytime in Settings → Labs.';

    $('.yp-toast-message.yooai-fab-hidden-toast').remove();
    if (fabHiddenToastTimer) {
      window.clearTimeout(fabHiddenToastTimer);
      fabHiddenToastTimer = null;
    }
    if (fabHiddenToastHideTimer) {
      window.clearTimeout(fabHiddenToastHideTimer);
      fabHiddenToastHideTimer = null;
    }

    var studioHub = document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub');
    var toastClass =
      'yp-toast-message yp-toast-info yooai-fab-hidden-toast' +
      (studioHub ? ' ysh-layout-saved-toast' : '');

    var $toast = $(
      '<div class="' +
        toastClass +
        '" role="status" aria-live="polite">' +
        '<span class="yp-toast-icon" aria-hidden="true">ℹ</span>' +
        '<span class="yp-toast-text"></span>' +
        '</div>'
    );
    $toast.find('.yp-toast-text').text(msg);
    $('body').append($toast);

    window.setTimeout(function () {
      $toast.addClass('yp-toast-show');
    }, 10);

    fabHiddenToastHideTimer = window.setTimeout(function () {
      $toast.removeClass('yp-toast-show');
      fabHiddenToastTimer = window.setTimeout(function () {
        $toast.remove();
      }, 300);
    }, 5000);
  }

  function hideFab($fab) {
    $fab.addClass('is-hidden').attr('hidden', 'hidden');
    if (cfg.ajaxUrl && cfg.nonce) {
      $.post(cfg.ajaxUrl, {
        action: 'yooadmin_yooai_hide_fab',
        nonce: cfg.nonce
      });
    }
    try {
      localStorage.setItem('yooadmin_yooai_fab_hidden', '1');
    } catch (e) {}
    showFabHiddenToast();
  }

  $(function () {
    var $fab = $('#yooai-fab');
    var $modal = $('#yooai-modal');
    if (!$fab.length || !$modal.length) {
      return;
    }

    if (cfg.fabHidden) {
      $fab.addClass('is-hidden').attr('hidden', 'hidden');
    } else {
      try {
        localStorage.removeItem('yooadmin_yooai_fab_hidden');
      } catch (e2) {}
      $fab.removeClass('is-hidden').removeAttr('hidden');
    }

    var $messages = $modal.find('[data-yooai-messages]');

    $fab.on('click', '[data-yooai-open]', function (e) {
      e.preventDefault();
      e.stopPropagation();
      openModal($modal);
    });

    $fab.on('click', '[data-yooai-fab-dismiss]', function (e) {
      e.preventDefault();
      e.stopPropagation();
      hideFab($fab);
    });

    $modal.on('click', '[data-yooai-close]', function (e) {
      e.preventDefault();
      closeModal($modal);
    });

    $(document).on('keydown', function (e) {
      if (e.key === 'Escape' && $modal.hasClass('is-open')) {
        closeModal($modal);
      }
    });
  });
})(jQuery);
