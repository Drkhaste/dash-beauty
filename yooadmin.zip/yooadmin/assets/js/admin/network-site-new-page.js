(function () {
  'use strict';

  var root = document.querySelector('.yoo-network-site-new-wrap');
  if (!root) {
    return;
  }

  var form = root.querySelector('#yoo-network-site-new-form');
  if (!form) {
    return;
  }

  form.addEventListener('submit', function () {
    var submitButtons = form.querySelectorAll('button[type="submit"]');
    submitButtons.forEach(function (button) {
      button.disabled = true;
    });
  });
})();
