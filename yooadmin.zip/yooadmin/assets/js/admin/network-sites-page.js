(function ($) {
  'use strict';

  var root = document.querySelector('.yoo-network-sites-wrap');
  if (!root) {
    return;
  }

  var searchInput = root.querySelector('#yoo-network-sites-search-input');
  if (searchInput) {
    searchInput.focus();
    if (searchInput.value) {
      searchInput.select();
    }
  }

  var form = document.getElementById('yoo-network-sites-bulk-form');
  if (!form) {
    return;
  }

  var bar = form.querySelector('.yoo-bulk-actions-bar');
  var checkboxes = form.querySelectorAll('.yoo-site-checkbox');
  var selectAll = document.getElementById('yoo-select-all-sites');
  var applyBtn = document.getElementById('yoo-network-sites-bulk-apply');
  var bulkSelect = document.getElementById('yoo-network-sites-bulk-action');
  var countEl = form.querySelector('.yoo-selected-count');
  var cfg = window.yooNetworkSitesConfirm || {};

  if (!bar || !checkboxes.length) {
    return;
  }

  function t(key, fallback) {
    return cfg[key] !== undefined && cfg[key] !== '' ? cfg[key] : fallback;
  }

  function showToast(message, type) {
    var toastType = type || 'success';
    if (
      window.yooadmNotificationsUi &&
      typeof window.yooadmNotificationsUi.showToastMessage === 'function'
    ) {
      window.yooadmNotificationsUi.showToastMessage(message, toastType);
      return;
    }

    var toast = document.createElement('div');
    toast.className = 'yp-toast-message yp-toast-' + toastType + ' yoo-network-sites-toast';
    toast.setAttribute('role', 'status');
    toast.innerHTML =
      '<span class="yp-toast-icon" aria-hidden="true"></span>' +
      '<span class="yp-toast-text"></span>';
    toast.querySelector('.yp-toast-text').textContent = message;
    document.body.appendChild(toast);
    window.requestAnimationFrame(function () {
      toast.classList.add('yp-toast-show');
    });
    window.setTimeout(function () {
      toast.classList.remove('yp-toast-show');
      window.setTimeout(function () {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3200);
  }

  function parseBulkAjaxResponse(response) {
    return response.text().then(function (text) {
      var trimmed = (text || '').trim();
      if (trimmed === '-1' || trimmed === '0') {
        throw new Error(t('errorGeneric', 'Something went wrong. Please try again.'));
      }

      if (!trimmed) {
        throw new Error(t('errorGeneric', 'Something went wrong. Please try again.'));
      }

      var json;
      try {
        json = JSON.parse(trimmed);
      } catch (parseErr) {
        throw new Error(t('errorGeneric', 'Something went wrong. Please try again.'));
      }

      if (!json || !json.success) {
        var errMsg =
          json && json.data && json.data.message
            ? json.data.message
            : t('errorGeneric', 'Something went wrong. Please try again.');
        throw new Error(errMsg);
      }

      return json.data || {};
    });
  }

  function postBulkAction(bulkAction, ids) {
    var ajaxUrl = t('ajaxUrl', typeof ajaxurl !== 'undefined' ? ajaxurl : '');
    if (!ajaxUrl) {
      return Promise.reject(new Error('missing_ajax_url'));
    }

    var body = new FormData();
    body.append('action', t('ajaxAction', 'yooadmin_network_sites_action'));
    body.append('nonce', t('ajaxNonce', ''));
    body.append('bulk_action', bulkAction);
    ids.forEach(function (id) {
      body.append('ids[]', id);
    });

    return fetch(ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      body: body
    }).then(function (response) {
      if (!response.ok) {
        throw new Error(t('errorGeneric', 'Something went wrong. Please try again.'));
      }
      return parseBulkAjaxResponse(response);
    });
  }

  function removeSiteRows(ids) {
    ids.forEach(function (id) {
      var row = document.querySelector('[data-yoo-site-id="' + String(id) + '"]');
      if (row && row.parentNode) {
        row.parentNode.removeChild(row);
      }
    });
  }

  function syncRowSelectedState(cb) {
    var item = cb.closest('.yoo-network-sites-list__item');
    if (item) {
      item.classList.toggle('yoo-network-sites-list__item--selected', !!cb.checked);
    }
  }

  function updateBar() {
    var checked = Array.prototype.filter.call(checkboxes, function (cb) {
      return cb.checked;
    });
    var n = checked.length;
    if (countEl) {
      countEl.textContent = n + ' selected';
    }
    if (applyBtn) {
      applyBtn.disabled = n === 0;
    }
    if (selectAll) {
      selectAll.checked = n > 0 && n === checkboxes.length;
      selectAll.indeterminate = n > 0 && n < checkboxes.length;
    }
  }

  if (window.yooadminUiSelect && typeof window.yooadminUiSelect.initIn === 'function') {
    window.yooadminUiSelect.initIn(form);
  }

  checkboxes.forEach(function (cb) {
    syncRowSelectedState(cb);
    cb.addEventListener('change', function () {
      syncRowSelectedState(cb);
      updateBar();
    });
  });

  if (selectAll) {
    selectAll.addEventListener('change', function () {
      checkboxes.forEach(function (cb) {
        cb.checked = selectAll.checked;
        syncRowSelectedState(cb);
      });
      updateBar();
    });
  }

  function bulkMessage(action, count) {
    if (action === 'delete') {
      return (t('bulkDeleteConfirm', 'Delete %d selected sites permanently? This cannot be undone.')).replace('%d', String(count));
    }
    if (action === 'spam') {
      return (t('bulkSpamConfirm', 'Mark %d selected sites as spam?')).replace('%d', String(count));
    }
    if (action === 'notspam') {
      return (t('bulkNotSpamConfirm', 'Remove %d selected sites from spam?')).replace('%d', String(count));
    }
    return t('bulkGenericConfirm', 'Apply this action to %d selected sites?').replace('%d', String(count));
  }

  function showBulkConfirm(action, count, onConfirm) {
    var message = bulkMessage(action, count);
    var confirmLabel = action === 'delete'
      ? t('bulkDeleteLabel', 'Delete permanently')
      : t('confirm', 'Confirm');

    if (typeof window.yooadminConfirmDialog === 'function') {
      window.yooadminConfirmDialog({
        title: t('confirmTitle', 'Confirm action'),
        message: message,
        cancelLabel: t('cancel', 'Cancel'),
        confirmLabel: confirmLabel,
        onConfirm: onConfirm
      });
      return;
    }

    if (window.confirm(message)) {
      onConfirm();
    }
  }

  if (applyBtn && bulkSelect) {
    applyBtn.addEventListener('click', function (e) {
      var action = bulkSelect.value;
      if (action === '-1') {
        e.preventDefault();
        return;
      }

      var checked = Array.prototype.filter.call(checkboxes, function (cb) {
        return cb.checked;
      });
      if (!checked.length) {
        e.preventDefault();
        return;
      }

      if (action === 'delete' || action === 'spam' || action === 'notspam') {
        e.preventDefault();
        var ids = checked.map(function (cb) {
          return cb.value;
        });
        showBulkConfirm(action, checked.length, function () {
          return postBulkAction(action, ids)
            .then(function (data) {
              if (data.removed_ids && data.removed_ids.length) {
                removeSiteRows(data.removed_ids);
              } else {
                window.location.reload();
                return data;
              }

              checked.forEach(function (cb) {
                cb.checked = false;
              });
              updateBar();
              showToast(data.message || t('confirm', 'Done'), data.notice_type || 'success');
              return data;
            })
            .catch(function (err) {
              showToast(err.message || t('errorGeneric', 'Something went wrong. Please try again.'), 'error');
              throw err;
            });
        });
      }
    });
  }
})(jQuery);
