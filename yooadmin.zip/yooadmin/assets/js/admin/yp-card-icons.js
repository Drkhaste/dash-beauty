// yp-card-icons.js — hydrate card icons from native #adminmenu (CSS-only styling, with clean titles & badges)
(function () {
  'use strict';
  if (!document.body || !document.body.classList.contains('wp-admin')) return;
  if (window.__YPCardIconsInit) return;
  window.__YPCardIconsInit = true;

  var STORAGE_KEY = 'ypCardCustomIcons';
  var EDIT_MODE_KEY = 'ypCardIconEditMode';
  var cardIconsI18n = window.yooadmCardIconsI18n || {};
  function cardIconT(key, fallback) {
    var v = cardIconsI18n[key];
    return v != null && v !== '' ? v : fallback;
  }
  var ICON_CHOICES = [
    'dashicons-admin-site',
    'dashicons-admin-home',
    'dashicons-admin-generic',
    'dashicons-admin-settings',
    'dashicons-admin-tools',
    'dashicons-admin-appearance',
    'dashicons-admin-customizer',
    'dashicons-admin-plugins',
    'dashicons-admin-users',
    'dashicons-admin-media',
    'dashicons-admin-page',
    'dashicons-admin-post',
    'dashicons-admin-comments',
    'dashicons-admin-links',
    'dashicons-admin-network',
    'dashicons-admin-multisite',
    'dashicons-admin-site-alt2',
    'dashicons-admin-site-alt3',
    'dashicons-dashboard',
    'dashicons-update',
    'dashicons-clock',
    'dashicons-performance',
    'dashicons-chart-pie',
    'dashicons-chart-area',
    'dashicons-chart-bar',
    'dashicons-chart-line',
    'dashicons-megaphone',
    'dashicons-clipboard',
    'dashicons-edit',
    'dashicons-edit-large',
    'dashicons-search',
    'dashicons-filter',
    'dashicons-category',
    'dashicons-tag',
    'dashicons-portfolio',
    'dashicons-layout',
    'dashicons-align-left',
    'dashicons-align-center',
    'dashicons-align-right',
    'dashicons-align-none',
    'dashicons-randomize',
    'dashicons-media-document',
    'dashicons-media-spreadsheet',
    'dashicons-media-interactive',
    'dashicons-media-code',
    'dashicons-format-image',
    'dashicons-format-audio',
    'dashicons-format-video',
    'dashicons-format-gallery',
    'dashicons-format-status',
    'dashicons-format-aside',
    'dashicons-images-alt',
    'dashicons-images-alt2',
    'dashicons-image-filter',
    'dashicons-visibility',
    'dashicons-hidden',
    'dashicons-lock',
    'dashicons-unlock',
    'dashicons-shield',
    'dashicons-superhero',
    'dashicons-vault',
    'dashicons-email',
    'dashicons-email-alt',
    'dashicons-email-alt2',
    'dashicons-share',
    'dashicons-share-alt',
    'dashicons-share-alt2',
    'dashicons-rss',
    'dashicons-facebook',
    'dashicons-facebook-alt',
    'dashicons-twitter',
    'dashicons-googleplus',
    'dashicons-linkedin',
    'dashicons-phone',
    'dashicons-smartphone',
    'dashicons-tablet',
    'dashicons-desktop',
    'dashicons-location',
    'dashicons-location-alt',
    'dashicons-time',
    'dashicons-calendar',
    'dashicons-calendar-alt',
    'dashicons-groups',
    'dashicons-businessman',
    'dashicons-id',
    'dashicons-buddicons-buddypress-logo',
    'dashicons-buddicons-groups',
    'dashicons-buddicons-friends',
    'dashicons-buddicons-activity',
    'dashicons-money',
    'dashicons-tickets-alt',
    'dashicons-cart',
    'dashicons-products',
    'dashicons-store',
    'dashicons-bank',
    'dashicons-calculator',
    'dashicons-cloud',
    'dashicons-cloud-saved',
    'dashicons-backup',
    'dashicons-download',
    'dashicons-upload',
    'dashicons-awards',
    'dashicons-star-filled',
    'dashicons-heart',
    'dashicons-smiley',
    'dashicons-lightbulb',
    'dashicons-yes',
    'dashicons-yes-alt',
    'dashicons-info',
    'dashicons-info-outline',
    'dashicons-warning',
    'dashicons-sos',
    'dashicons-flag',
    'dashicons-rest-api',
    'dashicons-text',
    'dashicons-translation',
    'dashicons-paperclip',
    'dashicons-screenoptions'
  ];
  window.yooadmIconChoices = ICON_CHOICES;
  var customIcons = loadStoredIcons();
  var pickerOverlay = null;
  var pickerEl = null;
  var pickerGrid = null;
  var pickerSearch = null;
  var pickerReset = null;
  var pickerClose = null;
  var pickerEmpty = null;
  var activeKey = '';
  var activeCallback = null;
  var editMode = loadEditMode();

  // ---------- helpers ----------
  var cssEscape = (window.CSS && CSS.escape) ? CSS.escape : function (s) {
    return String(s || '').replace(/[^a-zA-Z0-9_\-]/g, '\\$&');
  };

  function loadStoredIcons() {
    var raw = '';
    try {
      raw = window.localStorage ? localStorage.getItem(STORAGE_KEY) : '';
    } catch (_e) {
      return {};
    }
    if (!raw) return {};
    try {
      var data = JSON.parse(raw);
      return (data && typeof data === 'object') ? data : {};
    } catch (_err) {
      return {};
    }
  }

  function updateToggleButtons() {
    var toggles = document.querySelectorAll('[data-icon-edit-toggle]');
    toggles.forEach(function (btn) {
      btn.setAttribute('aria-pressed', editMode ? 'true' : 'false');
      btn.classList.toggle('is-active', editMode);
      // Keep icon only (like Welcome card) - don't change textContent
    });
  }

  function resetAllIcons() {
    customIcons = {};
    persistCustomIcons();
    syncCustomIcons();
    closePicker();
  }

  function applyEditModeClasses() {
    if (!document.body) return;
    if (editMode) {
      document.body.classList.add('yp-icon-edit-mode');
      document.documentElement.classList.add('yp-icon-edit-mode');
    } else {
      document.body.classList.remove('yp-icon-edit-mode');
      document.documentElement.classList.remove('yp-icon-edit-mode');
    }
    updateToggleButtons();
  }

  function setEditMode(on) {
    var desired = !!on;
    if (desired === editMode) return;
    editMode = desired;
    applyEditModeClasses();
    persistEditMode(editMode);
    if (!editMode) {
      closePicker();
    }
    bindControls();
  }

  function bindControls() {
    updateToggleButtons();
    var toggles = document.querySelectorAll('[data-icon-edit-toggle]');
    toggles.forEach(function (btn) {
      if (btn.dataset.bound === '1') return;
      btn.setAttribute('aria-pressed', editMode ? 'true' : 'false');
      btn.addEventListener('click', function (evt) {
        evt.preventDefault();
        setEditMode(!editMode);
      });
      btn.dataset.bound = '1';
    });

    document.querySelectorAll('[data-icon-edit-reset]').forEach(function (btn) {
      if (btn.dataset.bound === '1') return;
      btn.addEventListener('click', function (evt) {
        evt.preventDefault();
        if (btn.getAttribute('data-icon-edit-reset') === 'main-grid') {
          if (
            window.YOOStudioHubLayout &&
            typeof window.YOOStudioHubLayout.resetAll === 'function'
          ) {
            window.YOOStudioHubLayout.resetAll();
            return;
          }
        }
        resetAllIcons();
      });
      btn.dataset.bound = '1';
    });
  }

  function persistCustomIcons() {
    try {
      if (window.localStorage) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(customIcons));
      }
    } catch (_e) {}
  }

  function getCardsByKey(key) {
    if (!key) return [];
    var selector;
    try {
      selector = '[data-card-key="' + cssEscape(key) + '"]';
    } catch (_e) {
      selector = '[data-card-key="' + key.replace(/"/g, '\\"') + '"]';
    }
    return document.querySelectorAll(selector);
  }

  function getQS(href, key) {
    try {
      var u = new URL(href, window.location.origin);
      return u.searchParams.get(key) || '';
    } catch (_) {
      var m = new RegExp('[?&]' + key + '=([^&#]+)').exec(href || '');
      return m ? decodeURIComponent(m[1]) : '';
    }
  }

  function loadEditMode() {
    try {
      if (window.localStorage) {
        return localStorage.getItem(EDIT_MODE_KEY) === '1';
      }
    } catch (_e) {}
    return false;
  }

  function persistEditMode(on) {
    try {
      if (!window.localStorage) return;
      if (on) {
        localStorage.setItem(EDIT_MODE_KEY, '1');
      } else {
        localStorage.removeItem(EDIT_MODE_KEY);
      }
    } catch (_e) {}
  }

  // ---------- icon extraction (aligned with yp-menus.js: img, svg, bg, mask, glyph) ----------
  function readIconData(li) {
    if (!li) return null;
    var wrap = li.querySelector('.wp-menu-image');
    if (!wrap) return null;

    // 1) <img>
    var img = wrap.querySelector('img');
    if (img && img.src) return { type: 'img', src: img.src };

    // 2) Inline <svg>
    var svg = wrap.querySelector('svg');
    if (svg) return { type: 'svg', node: svg };

    var selfCS = getComputedStyle(wrap);

    // 3) background-image on the wrapper
    var bgSelf = selfCS.getPropertyValue('background-image');
    if (bgSelf && bgSelf !== 'none') {
      return { type: 'bg', image: bgSelf };
    }

    var beforeCS = getComputedStyle(wrap, '::before');

    // 4) ::before — Elementor uses mask-image + background-color:currentColor in admin (not SVG in DOM)
    if (beforeCS) {
      var bgB = beforeCS.getPropertyValue('background-image');
      if (bgB && bgB !== 'none') {
        return { type: 'bg', image: bgB };
      }
      var maskB = beforeCS.getPropertyValue('-webkit-mask-image') || beforeCS.getPropertyValue('mask-image');
      if (maskB && maskB !== 'none') {
        return {
          type: 'mask',
          mask: {
            image: maskB,
            repeat: beforeCS.getPropertyValue('-webkit-mask-repeat') || beforeCS.getPropertyValue('mask-repeat'),
            pos: beforeCS.getPropertyValue('-webkit-mask-position') || beforeCS.getPropertyValue('mask-position'),
            size: beforeCS.getPropertyValue('-webkit-mask-size') || beforeCS.getPropertyValue('mask-size')
          }
        };
      }
      var content = beforeCS.getPropertyValue('content');
      if (content && content !== 'none' && content !== 'normal') {
        content = content.replace(/^["']|["']$/g, '');
        return { type: 'glyph', glyph: content, fontFamily: beforeCS.getPropertyValue('font-family') || 'dashicons' };
      }
    }

    var maskSelf = selfCS.getPropertyValue('-webkit-mask-image') || selfCS.getPropertyValue('mask-image');
    if (maskSelf && maskSelf !== 'none') {
      return {
        type: 'mask',
        mask: {
          image: maskSelf,
          repeat: selfCS.getPropertyValue('-webkit-mask-repeat') || selfCS.getPropertyValue('mask-repeat'),
          pos: selfCS.getPropertyValue('-webkit-mask-position') || selfCS.getPropertyValue('mask-position'),
          size: selfCS.getPropertyValue('-webkit-mask-size') || selfCS.getPropertyValue('mask-size')
        }
      };
    }

    return null;
  }

  // Skip if the tile has a non-generic Dashicon already
  function hasNonGenericDashicon(holder) {
    var d = holder ? holder.querySelector('.dashicons') : null;
    return !!(d && !d.classList.contains('dashicons-admin-generic'));
  }

  // Get clean title from #adminmenu (no counters)
  function cleanTitleFromLi(li) {
    var nameEl = li ? li.querySelector('.wp-menu-name') : null;
    if (!nameEl) return null;

    // Clone and remove counters from the copy
    var copy = nameEl.cloneNode(true);
    copy.querySelectorAll('.update-plugins, .awaiting-mod, .count, .plugin-count, .comment-count, .pending-count').forEach(function (el) {
      el.remove();
    });

    var txt = (copy.textContent || '').trim();
    // Strip trailing numbers/brackets (e.g., Plugins 0)
    txt = txt.replace(/\s*\(?\d+\)?\s*$/,'').trim();
    return txt || null;
  }

  // Extract badge number from native li (comments/plugins/etc.)
  function badgeCountFromLi(li) {
    if (!li) return 0;
    var selectors = [
      '.update-plugins .plugin-count',
      '.update-plugins .update-count',
      '.awaiting-mod .comment-count',
      '.awaiting-mod .pending-count',
      '.awaiting-mod .count',
      '.awaiting-mod',
      '.update-plugins'
    ];
    var max = 0;
    for (var i = 0; i < selectors.length; i++) {
      var el = li.querySelector(selectors[i]);
      if (el && el.textContent) {
        var n = parseInt(el.textContent.replace(/[^\d]/g, ''), 10);
        if (!isNaN(n)) max = Math.max(max, n);
      }
    }
    return max;
  }

  function urlFromCssUrlValue(val) {
    if (!val || typeof val !== 'string') return '';
    var s = val.trim();
    if (!s || s === 'none') return '';
    var m = /url\(\s*["']?([^"')]+)["']?\s*\)/i.exec(s);
    return m ? String(m[1]).trim() : '';
  }

  function maskUrlWrapped(rawSrc) {
    if (!rawSrc) return '';
    var s = String(rawSrc).trim();
    if (s.indexOf('url(') === 0) return s;
    return 'url("' + s.replace(/"/g, '\\"') + '")';
  }

  function isRasterIconUrl(rawOrCss) {
    var s = String(rawOrCss || '').trim();
    if (!s) return false;
    var raw = s.indexOf('url(') === 0 ? urlFromCssUrlValue(s) : s;
    if (!raw) return false;
    var u = raw.split('?')[0].toLowerCase();
    if (u.indexOf('data:image/') === 0) {
      return u.indexOf('data:image/svg+xml') !== 0;
    }
    return /\.(png|jpe?g|gif|webp|avif|ico|bmp)(\?|$)/i.test(u);
  }

  function appendRasterImg(holder, src) {
    if (!src) return;
    var el = document.createElement('img');
    el.className = 'ypi-wp-img ypi-wp-raster-img';
    el.alt = '';
    el.decoding = 'async';
    el.loading = 'lazy';
    el.addEventListener('load', function () {
      var w = el.naturalWidth;
      var h = el.naturalHeight;
      if (!w || !h) return;
      var slot = 48;
      try {
        var root = holder && holder.closest ? holder.closest('.yp-icon') : null;
        if (root) {
          var sp = parseInt(getComputedStyle(root).getPropertyValue('--yp-card-icon-size'), 10);
          if (!isNaN(sp) && sp > 0) {
            slot = sp;
          }
        }
      } catch (_e) {}
      var maxSide = Math.max(w, h);
      var scale = Math.min(1, (slot * 0.92) / maxSide);
      if (scale < 1) {
        el.style.width = Math.round(w * scale) + 'px';
        el.style.height = Math.round(h * scale) + 'px';
      } else if (maxSide < slot * 0.65) {
        el.style.width = w + 'px';
        el.style.height = h + 'px';
        el.style.maxWidth = slot + 'px';
        el.style.maxHeight = slot + 'px';
      }
    });
    el.src = src;
    holder.appendChild(el);
  }

  function paintMaskIcon(holder, maskCss) {
    var val = String(maskCss || '').trim();
    if (!val) return;
    var el = document.createElement('span');
    el.className = 'ypi-wp-bg ypi-wp-img';
    el.style.webkitMaskImage = val;
    el.style.maskImage = val;
    el.style.webkitMaskSize = 'contain';
    el.style.maskSize = 'contain';
    el.style.webkitMaskRepeat = 'no-repeat';
    el.style.maskRepeat = 'no-repeat';
    el.style.webkitMaskPosition = 'center';
    el.style.maskPosition = 'center';
    holder.appendChild(el);
  }

  // Paint icon into holder according to source type
  function paintIntoHolder(holder, data) {
    if (!holder || !data) return;
    holder.innerHTML = '';

    if (data.type === 'img') {
      if (data.src && data.src.indexOf('data:image/svg+xml') === 0) {
        var elSvgData = document.createElement('img');
        elSvgData.className = 'ypi-wp-img';
        elSvgData.src = data.src;
        elSvgData.alt = '';
        holder.appendChild(elSvgData);
        return;
      }
      if (isRasterIconUrl(data.src)) {
        appendRasterImg(holder, data.src);
        return;
      }
      paintMaskIcon(holder, maskUrlWrapped(data.src));
      return;
    }

    if (data.type === 'svg' && data.node) {
      var svgEl = data.node.cloneNode(true);
      svgEl.setAttribute('width', '20');
      svgEl.setAttribute('height', '20');
      if (!svgEl.getAttribute('fill')) {
        try { svgEl.setAttribute('fill', 'currentColor'); } catch (_e) {}
      }
      holder.appendChild(svgEl);
      return;
    }

    // CSS mask (e.g. Elementor: ::before uses mask + currentColor). Only copy the image URL — do not copy
    // mask-size/position from #adminmenu (small sidebar); let .ypi-wp-bg use --yp-card-icon-size + contain.
    if (data.type === 'mask' && data.mask) {
      var mimg = data.mask.image || '';
      if (isRasterIconUrl(mimg)) {
        appendRasterImg(holder, urlFromCssUrlValue(mimg) || mimg);
        return;
      }
      paintMaskIcon(holder, mimg);
      return;
    }

    if (data.type === 'bg') {
      if (data.image && data.image.indexOf('data:image/svg+xml') === 0) {
        var elImg = document.createElement('img');
        elImg.className = 'ypi-wp-img';
        elImg.src = data.image.replace(/^url\(["']?|["']?\)$/g, '');
        elImg.alt = '';
        holder.appendChild(elImg);
        return;
      }
      if (isRasterIconUrl(data.image)) {
        appendRasterImg(holder, urlFromCssUrlValue(data.image) || data.image);
        return;
      }
      paintMaskIcon(holder, data.image || '');
      return;
    }

    if (data.type === 'glyph') {
      var elGl = document.createElement('span');
      elGl.className = 'ypi-wp-glyph dashicons';
      elGl.textContent = data.glyph;
      // Keep font-family if not Dashicons
      if (data.fontFamily && data.fontFamily.toLowerCase().indexOf('dashicons') === -1) {
        elGl.style.fontFamily = data.fontFamily;
      }
      holder.appendChild(elGl);
    }
  }

  function ensureCardOriginalStored(card) {
    if (!card || card.dataset.originalIconStored === '1') return;
    var holder = card.querySelector('.yp-icon');
    if (!holder) return;

    var storeData = null;
    var dash = holder.querySelector('.dashicons');
    if (dash) {
      var classes = (dash.className || '').split(/\s+/);
      var icon = '';
      for (var i = 0; i < classes.length; i++) {
        if (classes[i] && classes[i].indexOf('dashicons-') === 0) {
          icon = classes[i];
          break;
        }
      }
      storeData = icon ? { type: 'dashicon', value: icon } : null;
    } else {
      var img = holder.querySelector('img');
      if (img && img.src) {
        storeData = { type: 'img', src: img.src };
      }
    }

    if (!storeData) {
      var defaultIcon = card.getAttribute('data-default-icon') || '';
      if (defaultIcon.indexOf('dashicons-') === 0) {
        storeData = { type: 'dashicon', value: defaultIcon };
      } else if (defaultIcon && (defaultIcon.indexOf('http') === 0 || defaultIcon.indexOf('data:') === 0)) {
        storeData = { type: 'img', src: defaultIcon };
      }
    }

    if (storeData) {
      card.dataset.originalIcon = JSON.stringify(storeData);
    }
    card.dataset.originalIconStored = '1';
  }

  function restoreOriginalIcon(card) {
    if (!card) return;
    var holder = card.querySelector('.yp-icon');
    if (!holder) return;
    ensureCardOriginalStored(card);

    var parsed = null;
    if (card.dataset.originalIcon) {
      try {
        parsed = JSON.parse(card.dataset.originalIcon);
      } catch (_e) {
        parsed = null;
      }
    }

    holder.innerHTML = '';

    if (parsed && typeof parsed === 'object') {
      if (parsed.type === 'dashicon' && parsed.value) {
        var dash = document.createElement('span');
        dash.className = 'dashicons ' + parsed.value;
        dash.setAttribute('aria-hidden', 'true');
        holder.appendChild(dash);
        delete card.dataset.customIcon;
        return;
      }
      if (parsed.type === 'img' && parsed.src) {
        paintIntoHolder(holder, { type: 'img', src: parsed.src });
        delete card.dataset.customIcon;
        return;
      }
      if ((parsed.type === 'bg' || parsed.type === 'glyph') && (parsed.image || parsed.glyph)) {
        paintIntoHolder(holder, parsed);
        delete card.dataset.customIcon;
        return;
      }
    }

    var fallback = card.getAttribute('data-default-icon') || '';
    if (fallback.indexOf('dashicons-') === 0) {
      var dashFallback = document.createElement('span');
      dashFallback.className = 'dashicons ' + fallback;
      dashFallback.setAttribute('aria-hidden', 'true');
      holder.appendChild(dashFallback);
    } else if (fallback && (fallback.indexOf('http') === 0 || fallback.indexOf('data:') === 0)) {
      paintIntoHolder(holder, { type: 'img', src: fallback });
    } else {
      var generic = document.createElement('span');
      generic.className = 'dashicons dashicons-admin-generic';
      generic.setAttribute('aria-hidden', 'true');
      holder.appendChild(generic);
    }
    delete card.dataset.customIcon;
  }

  function setCardIcon(card, iconClass) {
    if (!card) return;
    var holder = card.querySelector('.yp-icon');
    if (!holder) return;
    ensureCardOriginalStored(card);

    if (!iconClass || iconClass.indexOf('dashicons-') !== 0) {
      restoreOriginalIcon(card);
      return;
    }

    holder.innerHTML = '';
    var span = document.createElement('span');
    span.className = 'dashicons ' + iconClass;
    span.setAttribute('aria-hidden', 'true');
    holder.appendChild(span);
    card.dataset.customIcon = iconClass;
  }

  function applyCustomIconInternal(key, iconClass) {
    var nodes = getCardsByKey(key);
    if (!nodes.length) return;
    for (var i = 0; i < nodes.length; i++) {
      var card = nodes[i];
      if (!card || card.dataset.iconEditDisabled === '1') continue;
      if (iconClass && iconClass.indexOf('dashicons-') === 0) {
        setCardIcon(card, iconClass);
      } else {
        restoreOriginalIcon(card);
      }
    }
  }

  function applyCustomIcon(key, iconClass, options) {
    if (!key) return;
    applyCustomIconInternal(key, iconClass);
    var persist = !options || options.persist !== false;
    if (!persist) return;

    if (iconClass && iconClass.indexOf('dashicons-') === 0) {
      customIcons[key] = iconClass;
    } else {
      delete customIcons[key];
    }
    persistCustomIcons();
    window.dispatchEvent(new CustomEvent('yp-card-icon-updated', {
      detail: { key: key, icon: iconClass || '' }
    }));
  }

  function syncCustomIcons() {
    if (customIcons && typeof customIcons === 'object') {
      for (var key in customIcons) {
        if (Object.prototype.hasOwnProperty.call(customIcons, key)) {
          var icon = customIcons[key];
          applyCustomIconInternal(key, icon);
        }
      }
    }
    var allCards = document.querySelectorAll('[data-card-key]');
    allCards.forEach(function (card) {
      var key = card.getAttribute('data-card-key');
      if (!key) return;
      if (!customIcons[key] && card.dataset.customIcon) {
        restoreOriginalIcon(card);
      }
    });
  }

  function highlightPickerSelection(iconClass) {
    if (!pickerGrid) return;
    var buttons = pickerGrid.querySelectorAll('.yp-icon-picker-option');
    for (var i = 0; i < buttons.length; i++) {
      var btn = buttons[i];
      if (btn.dataset.icon === iconClass && iconClass) {
        btn.classList.add('is-active');
      } else {
        btn.classList.remove('is-active');
      }
    }
  }

  function ensurePicker() {
    if (pickerEl) return pickerEl;
    pickerOverlay = document.createElement('div');
    pickerOverlay.className = 'yp-icon-picker-overlay';
    pickerOverlay.setAttribute('role', 'presentation');

    pickerEl = document.createElement('div');
    pickerEl.className = 'yp-icon-picker';
    pickerEl.setAttribute('role', 'dialog');
    pickerEl.setAttribute('aria-label', cardIconT('chooseIcon', 'Choose icon'));

    var pickerHeader = document.createElement('div');
    pickerHeader.className = 'yp-icon-picker-header';

    var title = document.createElement('h3');
    title.textContent = cardIconT('chooseIcon', 'Choose icon');
    pickerHeader.appendChild(title);

    pickerClose = document.createElement('button');
    pickerClose.type = 'button';
    pickerClose.className = 'yp-icon-picker-close';
    pickerClose.setAttribute('aria-label', cardIconT('closePicker', 'Close icon picker'));
    pickerClose.innerHTML = '<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>';
    pickerHeader.appendChild(pickerClose);

    pickerEl.appendChild(pickerHeader);

    pickerSearch = document.createElement('input');
    pickerSearch.type = 'search';
    pickerSearch.className = 'yp-icon-picker-search';
    pickerSearch.placeholder = cardIconT('searchIcons', 'Search icons…');
    pickerEl.appendChild(pickerSearch);

    pickerGrid = document.createElement('div');
    pickerGrid.className = 'yp-icon-picker-grid';

    ICON_CHOICES.forEach(function (icon) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'yp-icon-picker-option';
      btn.dataset.icon = icon;
      var label = icon.replace('dashicons-', '').replace(/-/g, ' ');
      btn.dataset.search = label.toLowerCase();
      btn.setAttribute('aria-label', label);
      btn.innerHTML = '<span class="dashicons ' + icon + '" aria-hidden="true"></span>';
      pickerGrid.appendChild(btn);
    });

    var actions = document.createElement('div');
    actions.className = 'yp-icon-picker-actions';

    pickerReset = document.createElement('button');
    pickerReset.type = 'button';
    pickerReset.className = 'yp-icon-picker-reset';
    pickerReset.textContent = cardIconT('reset', 'Reset');
    actions.appendChild(pickerReset);

    pickerEl.appendChild(pickerGrid);

    pickerEmpty = document.createElement('div');
    pickerEmpty.className = 'yp-icon-picker-empty';
    pickerEmpty.textContent = cardIconT('noMatch', 'No icons match your search');
    pickerEmpty.hidden = true;
    pickerEl.appendChild(pickerEmpty);
    pickerEl.appendChild(actions);
    pickerOverlay.appendChild(pickerEl);
    pickerOverlay.style.display = 'none';
    document.body.appendChild(pickerOverlay);

    pickerGrid.addEventListener('click', function (evt) {
      var option = evt.target && evt.target.closest ? evt.target.closest('.yp-icon-picker-option') : null;
      if (!option) return;
      var icon = option.dataset.icon || '';
      if (activeCallback) {
        activeCallback(icon);
      } else if (activeKey) {
        applyCustomIcon(activeKey, icon);
      }
      closePicker();
    });

    pickerReset.addEventListener('click', function (evt) {
      if (evt) evt.preventDefault();
      if (activeCallback) {
        activeCallback('');
      } else if (activeKey) {
        applyCustomIcon(activeKey, '');
      }
      closePicker();
    });

    pickerClose.addEventListener('click', function (evt) {
      if (evt) evt.preventDefault();
      closePicker();
    });

    pickerOverlay.addEventListener('click', function (evt) {
      if (evt.target === pickerOverlay) {
        closePicker();
      }
    });

    pickerSearch.addEventListener('input', function () {
      filterIcons(pickerSearch.value || '');
    });

    return pickerEl;
  }

  function handleGlobalPointer(evt) {
    if (!pickerOverlay) return;
    var withinPicker = pickerEl && pickerEl.contains(evt.target);
    var editBtn = evt.target && evt.target.closest ? evt.target.closest('.yp-card-icon-edit') : null;
    if (!withinPicker && !editBtn) closePicker();
  }

  function handleKeydown(evt) {
    if (evt.key === 'Escape') {
      closePicker();
    }
  }

  function showPicker(initialIcon) {
    ensurePicker();
    highlightPickerSelection(initialIcon || '');
    pickerOverlay.style.display = 'flex';
    pickerOverlay.classList.remove('is-visible');
    requestAnimationFrame(function () {
      pickerOverlay.classList.add('is-visible');
    });
    document.documentElement.classList.add('yp-icon-picker-open');
    document.body.classList.add('yp-icon-picker-open');

    document.addEventListener('mousedown', handleGlobalPointer, true);
    document.addEventListener('touchstart', handleGlobalPointer, true);
    document.addEventListener('keydown', handleKeydown, true);

    if (pickerSearch) {
      pickerSearch.value = '';
      filterIcons('');
      pickerSearch.focus();
    }
  }

  function openPicker(button) {
    if (!editMode) return;
    var card = button ? button.closest('[data-card-key]') : null;
    if (!card || card.dataset.iconEditDisabled === '1') return;
    var key = card.getAttribute('data-card-key');
    if (!key) return;

    ensureCardOriginalStored(card);
    activeCallback = null;
    activeKey = key;

    var current = customIcons[key] || card.dataset.customIcon || '';
    showPicker(current);
  }

  function openPickerStandalone(initialIcon, callback) {
    activeKey = '';
    activeCallback = (typeof callback === 'function') ? callback : null;
    showPicker(initialIcon || '');
  }

  function closePicker() {
    if (!pickerOverlay) return;
    pickerOverlay.classList.remove('is-visible');
    pickerOverlay.style.display = 'none';
    activeKey = '';
    activeCallback = null;
    document.documentElement.classList.remove('yp-icon-picker-open');
    document.body.classList.remove('yp-icon-picker-open');
    document.removeEventListener('mousedown', handleGlobalPointer, true);
    document.removeEventListener('touchstart', handleGlobalPointer, true);
    document.removeEventListener('keydown', handleKeydown, true);
  }

  function filterIcons(term) {
    if (!pickerGrid) return;
    var normalized = (term || '').trim().toLowerCase();
    var options = pickerGrid.querySelectorAll('.yp-icon-picker-option');
    var visible = 0;
    options.forEach(function (btn) {
      var iconName = (btn.dataset.icon || '').toLowerCase();
      var label = btn.dataset.search || '';
      var matches = !normalized || iconName.indexOf(normalized) !== -1 || label.indexOf(normalized) !== -1;
      if (matches) {
        btn.style.display = 'flex';
        btn.removeAttribute('aria-hidden');
        visible++;
      } else {
        btn.style.display = 'none';
        btn.setAttribute('aria-hidden', 'true');
      }
    });
    if (pickerEmpty) {
      pickerEmpty.hidden = visible !== 0;
    }
  }

  // Match card to li in #adminmenu
  // Accept cached admin and allMenuTopLinks for better performance
  function findNativeLiForCard(card, cachedAdmin, cachedAllMenuTopLinks) {
    var admin = cachedAdmin || document.getElementById('adminmenu');
    if (!admin) return null;

    var href = card.getAttribute('href') || '';
    var slug = card.getAttribute('data-menu-slug') || '';
    var li = null;

    if (slug) {
      var q = 'a.menu-top[href*="page=' + cssEscape(slug) + '"]';
      var mt = admin.querySelector(q);
      if (mt) li = mt.closest('li');
      if (!li) {
        var idLi = admin.querySelector('#toplevel_page_' + cssEscape(slug));
        if (idLi) li = idLi;
      }
    }

    if (!li && href) {
      // Use cached allMenuTopLinks if provided, otherwise query
      var all = cachedAllMenuTopLinks || admin.querySelectorAll('a.menu-top');
      for (var i = 0; i < all.length; i++) {
        var a = all[i];
        try {
          var u1 = new URL(a.href, location.origin);
          var u2 = new URL(href, location.origin);
          if (u1.pathname === u2.pathname && u1.search === u2.search) { li = a.closest('li'); break; }
        } catch (_) {}
      }
    }

    // wc-admin → Woo top
    if (!li && href.indexOf('page=wc-admin') !== -1) {
      var woo = admin.querySelector('#toplevel_page_woocommerce');
      if (woo) li = woo;
    }

    // Elementor: top-level id may be elementor or elementor-home (mask icon on ::before)
    if (!li && slug && slug.indexOf('elementor') !== -1) {
      li =
        admin.querySelector('#toplevel_page_elementor') ||
        admin.querySelector('#toplevel_page_elementor-home') ||
        admin.querySelector('li.toplevel_page_elementor-home') ||
        li;
    }
    return li;
  }

  // Update card label and badge (do not touch icon)
  function updateTitleAndBadge(card, li) {
    if (!card || !li) return;

    // 1) Clean label
    var label = card.querySelector('.yp-icon-label');
    var clean = cleanTitleFromLi(li);
    if (label && clean) {
      label.textContent = clean;
    }

    // 2) Badge
    var count = badgeCountFromLi(li);
    var badge = card.querySelector('.yp-card-badge');
    if (count > 0) {
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'yp-card-badge';
        card.appendChild(badge);
      }
      badge.textContent = String(count);
      badge.hidden = false;
    } else if (badge) {
      badge.hidden = true;
    }
  }

  function hydrateCards() {
    var cards = document.querySelectorAll('.yp-icon-grid-boxes .yp-icon-tile');
    var admin = document.getElementById('adminmenu');

    if (admin && cards.length) {
      var allMenuTopLinks = admin.querySelectorAll('a.menu-top');

      cards.forEach(function (card) {
        ensureCardOriginalStored(card);
        if (card.dataset.iconHydrated === '1') return;

        var holder = card.querySelector('.yp-icon');
        // Pass cached admin and links to findNativeLiForCard for better performance
        var li = findNativeLiForCard(card, admin, allMenuTopLinks);
        if (!li) return;

        // الأيقونة (لا نلمس لو عندك dashicon غير جنريك)
        if (holder && !hasNonGenericDashicon(holder)) {
          var data = readIconData(li);
          if (data) {
            paintIntoHolder(holder, data);
            try {
              card.dataset.originalIcon = JSON.stringify(data);
              card.dataset.originalIconStored = '1';
            } catch (_e) {}
          }
        } else if (holder) {
          ensureCardOriginalStored(card);
        }

        updateTitleAndBadge(card, li);
        card.dataset.iconHydrated = '1';
      });
    }

    var grids = document.querySelectorAll('.yp-icon-grid-boxes, .yp-action-grid');

    grids.forEach(function(grid) {
      grid.classList.add('is-hydrated');
      if (!grid.hasAttribute('data-quick-actions-grid')) {
        if (
          document.body &&
          document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub') &&
          grid.classList.contains('yp-cards-grid')
        ) {
          grid.style.display = 'grid';
        } else {
          grid.style.display = 'flex';
        }
      } else {
        grid.style.display = '';
      }
    });

    document.querySelectorAll('.yp-network-sites-card__list').forEach(function (list) {
      list.classList.add('is-hydrated');
    });

    var loadingSpinners = document.querySelectorAll(
      '.yp-website-management-loading, .yp-quick-actions-loading, .yp-studio-section-loading, .yp-network-sites-loading'
    );
    loadingSpinners.forEach(function (spinner) {
      spinner.classList.add('is-hidden');
      spinner.style.display = 'none';
    });

    if (document.body && document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub')) {
      document.dispatchEvent(new CustomEvent('yooadmin-studio-hub-grids-ready'));
    }
  }

  function finishStudioHubSectionLoadingFallback() {
    var loadingSpinners = document.querySelectorAll(
      '.yp-website-management-loading, .yp-quick-actions-loading, .yp-studio-section-loading, .yp-network-sites-loading'
    );
    loadingSpinners.forEach(function (spinner) {
      spinner.classList.add('is-hidden');
      spinner.style.display = 'none';
    });
    document.querySelectorAll('.yp-studio-hub--dashboard .yp-network-sites-card__list').forEach(function (list) {
      list.classList.add('is-hydrated');
    });
    var grids = document.querySelectorAll('.yp-studio-hub--dashboard .yp-cards-grid, .yp-studio-hub--dashboard .yp-action-grid');
    grids.forEach(function (grid) {
      grid.classList.add('is-hydrated');
      if (grid.hasAttribute('data-quick-actions-grid')) {
        grid.style.display = '';
      } else if (grid.classList.contains('yp-cards-grid')) {
        grid.style.display = 'grid';
      }
    });
  }

  function init() {
    var tries = 0;
    var maxTries = 10;
    var retryDelay = 50;
    
    (function tick() {
      var admin = document.getElementById('adminmenu');
      var grid  = document.querySelector('.yp-icon-grid-boxes');
      
      if (admin && grid) {
        hydrateCards();
        syncCustomIcons();
        editMode = false;
        persistEditMode(false);
        applyEditModeClasses();
        bindControls();
        return;
      }
      
      if (++tries >= maxTries) {
        var grids = document.querySelectorAll('.yp-icon-grid-boxes, .yp-action-grid');
        grids.forEach(function (g) {
          g.classList.add('is-hydrated');
          if (!g.hasAttribute('data-quick-actions-grid')) {
            if (
              document.body &&
              document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub') &&
              g.classList.contains('yp-cards-grid')
            ) {
              g.style.display = 'grid';
            } else {
              g.style.display = 'flex';
            }
          } else {
            g.style.display = '';
          }
        });
        finishStudioHubSectionLoadingFallback();
        return;
      }
      
      setTimeout(tick, retryDelay);
    })();
  }

  function isQuickActionTileControl(btn) {
    return btn && (btn.classList.contains('qa-tile-edit') || btn.classList.contains('qa-tile-delete'));
  }

  document.addEventListener('click', function (evt) {
    var btn = evt.target && evt.target.closest ? evt.target.closest('.yp-card-icon-edit') : null;
    if (!btn || isQuickActionTileControl(btn)) return;
    evt.preventDefault();
    evt.stopPropagation();
    openPicker(btn);
  }, true);

  document.addEventListener('keydown', function (evt) {
    if (evt.key !== 'Enter' && evt.key !== ' ') return;
    var btn = evt.target && evt.target.closest ? evt.target.closest('.yp-card-icon-edit') : null;
    if (!btn || isQuickActionTileControl(btn)) return;
    evt.preventDefault();
    evt.stopPropagation();
    openPicker(btn);
  }, true);

  window.addEventListener('storage', function (evt) {
    if (!evt) return;
    if (evt.key === STORAGE_KEY) {
      customIcons = loadStoredIcons();
      syncCustomIcons();
    }
    if (evt.key === EDIT_MODE_KEY) {
      var incoming = evt.newValue === '1';
      if (incoming !== editMode) {
        editMode = incoming;
        applyEditModeClasses();
        bindControls();
        if (!editMode) {
          closePicker();
        }
      }
    }
  });
  window.addEventListener('resize', function () { closePicker(); });

  window.YPCardIcons = window.YPCardIcons || {};
  window.YPCardIcons.sync = syncCustomIcons;
  window.YPCardIcons.apply = function (key, icon) {
    applyCustomIcon(key, icon || '', { persist: true });
  };
  window.YPCardIcons.setEditMode = setEditMode;
  window.YPCardIcons.resetAll = resetAllIcons;
  window.YPCardIcons.pickIcon = function (initialIcon, callback) {
    openPickerStandalone(initialIcon || '', callback);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
