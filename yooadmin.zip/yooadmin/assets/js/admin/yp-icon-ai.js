/**
 * YOOAdmin - Icon predictor (URL-first)
 *
 * @package YOOAdmin
 */

(function () {
  'use strict';

  // ===== config: categories → icon + weighted keywords =====
  const CATEGORIES = [
    { key: 'dashboard', icon: 'dashicons-dashboard',
      kw: ['index.php','dashboard','updates','update-core','site-health'] },
    { key: 'posts', icon: 'dashicons-admin-post',
      kw: ['edit.php','post-new.php','category','categories','post_tag','tags','blog','article'] },
    { key: 'media', icon: 'dashicons-admin-media',
      kw: ['upload.php','media-new.php','attachment','library','media'] },
    { key: 'pages', icon: 'dashicons-admin-page',
      kw: ['edit.php?post_type=page','post_type=page'] },
    { key: 'comments', icon: 'dashicons-admin-comments',
      kw: ['edit-comments.php','comments','discussion','reviews'] },
    { key: 'users', icon: 'dashicons-groups',
      kw: ['users.php','user-new.php','profile.php','role','customer','customers','members','user','users','all-users','people','person','persons'] },
    { key: 'profile', icon: 'dashicons-admin-users',
      kw: ['profile','profiles','account','accounts','my-account','personal'] },
    { key: 'appearance', icon: 'dashicons-admin-appearance',
      kw: ['themes.php','customize.php','widgets.php','nav-menus.php','appearance','customizer','theme'] },
    { key: 'plugins', icon: 'dashicons-admin-plugins',
      kw: ['plugins.php','plugin-install.php','plugin-editor.php','addons','extensions'] },
    { key: 'tools', icon: 'dashicons-admin-tools',
      kw: ['tools.php','import.php','export.php','site-health.php','tool','testing','api-testing'] },
    { key: 'settings', icon: 'dashicons-admin-settings',
      kw: ['options-','options-general.php','settings','api-settings','general'] },
    { key: 'writing', icon: 'dashicons-edit',
      kw: ['writing','write','post','posts','article','articles','content'] },
    { key: 'reading', icon: 'dashicons-book',
      kw: ['reading','read','front','front-page','homepage','display'] },
    { key: 'permalinks', icon: 'dashicons-admin-links',
      kw: ['permalink','permalinks','url','urls','link','links','structure'] },
    { key: 'privacy', icon: 'dashicons-shield',
      kw: ['privacy','private','gdpr','data-protection','personal-data'] },

    // WooCommerce / Store
    { key: 'products', icon: 'dashicons-products',
      kw: ['post_type=product','product','products','all-products','all products'] },
    { key: 'brands', icon: 'dashicons-awards',
      kw: ['brand','brands','manufacturer','manufacturers'] },
    { key: 'variations', icon: 'dashicons-randomize',
      kw: ['variation','variations','variant','variants'] },
    { key: 'taxes', icon: 'dashicons-money',
      kw: ['tax','taxes','taxation','vat','gst'] },
    { key: 'cart', icon: 'dashicons-cart',
      kw: ['orders','order','wc-orders','checkout','shipping','woocommerce','wc-admin'] },
    { key: 'coupons', icon: 'dashicons-tickets-alt',
      kw: ['coupon','coupons'] },
    { key: 'analytics', icon: 'dashicons-chart-line',
      kw: ['analytics','revenue','reports','report','stats','stat','chart'] },

    // Import/Export
    { key: 'import', icon: 'dashicons-upload',
      kw: ['import','importer','importing','upload','uploading','bring','brings'] },
    { key: 'export', icon: 'dashicons-download',
      kw: ['export','exporter','exporting','download','downloading','save','saves'] },
    
    // Builders & Editors
    { key: 'builder', icon: 'dashicons-layout',
      kw: ['builder','build','building','construct','construction','layout','layouts','grid','grids'] },
    { key: 'editor', icon: 'dashicons-edit',
      kw: ['editor','editing','edit','modify','modifying','change','changing'] },
    { key: 'code', icon: 'dashicons-editor-code',
      kw: ['code','coding','script','scripts','javascript','js','css','html','php','syntax'] },
    
    // Management & Control
    { key: 'manager', icon: 'dashicons-admin-tools',
      kw: ['manager','manage','managing','control','controls','admin','administration'] },
    { key: 'clients', icon: 'dashicons-groups',
      kw: ['client','clients','customer','customers'] },
    { key: 'extensions', icon: 'dashicons-admin-plugins',
      kw: ['extension','extensions','addon','addons'] },
    { key: 'clients', icon: 'dashicons-groups',
      kw: ['client','clients','customer','customers','user','users'] },
    { key: 'extensions', icon: 'dashicons-admin-plugins',
      kw: ['extension','extensions','addon','addons','plugin','plugins'] },
    { key: 'mapper', icon: 'dashicons-admin-links',
      kw: ['mapper','map','mapping','shortcode','shortcodes','link','links','connect','connection'] },
    
    // Status & Info
    { key: 'status', icon: 'dashicons-dashboard',
      kw: ['status','state','states','info','information','overview','summary','health'] },
    { key: 'system', icon: 'dashicons-admin-generic',
      kw: ['system','systems','server','servers','environment','config','configuration'] },
    
    // Installation & Setup
    { key: 'install', icon: 'dashicons-admin-plugins',
      kw: ['install','installing','installation','setup','set','setting','activate','activation'] },
    { key: 'uninstall', icon: 'dashicons-dismiss',
      kw: ['uninstall','uninstalling','remove','removing','delete','deleting','uninstall'] },
    
    // Bugs & Issues
    { key: 'bug', icon: 'dashicons-warning',
      kw: ['bug','bugs','issue','issues','problem','problems','error','errors','report','reporting'] },
    
    // AI & Smart Features
    { key: 'ai', icon: 'dashicons-star-filled',
      kw: ['ai','artificial','intelligence','smart','auto','automatic','assistant','assist'] },
    
    // Custom & Advanced
    { key: 'custom', icon: 'dashicons-admin-customizer',
      kw: ['custom','customize','customization','advanced','special','specific','personal','personalize'] },
    
    // Reviews & Ratings
    { key: 'reviews', icon: 'dashicons-star-filled',
      kw: ['review','reviews','rating','ratings','rate','rates','feedback','feedbacks','comment','comments'] },
    
    // Tags & Categories
    { key: 'tags', icon: 'dashicons-tag',
      kw: ['tag','tags','label','labels','keyword','keywords'] },
    { key: 'categories', icon: 'dashicons-category',
      kw: ['category','categories','categor','group','groups','classify','classification'] },
    
    // Attributes & Properties
    { key: 'attributes', icon: 'dashicons-filter',
      kw: ['attribute','attributes','property','properties','feature','features','option','options'] },
    
    // Forms & Integration
    { key: 'forms', icon: 'dashicons-feedback',
      kw: ['form','forms','contact-form','contact-forms','form-builder'] },
    { key: 'integration', icon: 'dashicons-admin-links',
      kw: ['integration','integrations','integrate','connecting','connect','api-integration'] },
    
    // Typography & Design
    { key: 'typography', icon: 'dashicons-editor-textcolor',
      kw: ['typography','font','fonts','text','text-style','typeface'] },
    { key: 'color', icon: 'dashicons-art',
      kw: ['color','colors','colour','colours','color-picker','picker'] },

    // Notifications & Alerts
    { key: 'notifications', icon: 'dashicons-bell',
      kw: ['notification','notifications','alert','alerts','bell','announcement','announcements'] },
    { key: 'megaphone', icon: 'dashicons-megaphone',
      kw: ['megaphone','broadcast','announce'] },
    
    // Resources & Files
    { key: 'resources', icon: 'dashicons-portfolio',
      kw: ['resource','resources','manager','file','files','document','documents','portfolio','archive'] },
    { key: 'database', icon: 'dashicons-database',
      kw: ['database','db','data','storage','store'] },
    
    // Monitoring & Activity
    { key: 'activity', icon: 'dashicons-visibility',
      kw: ['activity','monitor','tracking','track','log','logs','history','audit','visitor','visitors'] },
    { key: 'performance', icon: 'dashicons-performance',
      kw: ['performance','speed','optimization','optimize','cache','caching'] },
    
    // Errors & Logs
    { key: 'error', icon: 'dashicons-warning',
      kw: ['error','errors','log','logs','debug','debugging','issue','issues','problem','problems','exception'] },
    { key: 'dismiss', icon: 'dashicons-dismiss',
      kw: ['dismiss','failed','failure','fail','critical'] },
    
    // Updates
    { key: 'updates', icon: 'dashicons-update',
      kw: ['update','updates','upgrade','upgrades','version','versions','changelog'] },
    
    // API & Development
    { key: 'api', icon: 'dashicons-code-standards',
      kw: ['api','rest','endpoint','endpoints','json','xml','webhook','webhooks','testing','test'] },
    { key: 'code', icon: 'dashicons-editor-code',
      kw: ['code','coding','script','scripts','javascript','js','css','html','php','syntax','custom-js'] },
    
    // Home & Dashboard
    { key: 'home', icon: 'dashicons-admin-home',
      kw: ['home','main','dashboard','overview','start','begin'] },
    
    // Health & Status
    { key: 'health', icon: 'dashicons-heart',
      kw: ['health','site-health','wellness','check','checkup','diagnostic','diagnostics'] },
    { key: 'network', icon: 'dashicons-admin-site-alt3',
      kw: ['network','networking','multisite','sites','setup','configuration'] },
    { key: 'scheduled', icon: 'dashicons-backup',
      kw: ['scheduled','schedule','scheduler','cron','action','actions','task','tasks','queue'] },
    
    // Erase & Delete
    { key: 'erase', icon: 'dashicons-trash',
      kw: ['erase','erasing','delete','deleting','remove','removing','clear','clearing','wipe','wiping'] },
    
    // Notices & Center
    { key: 'notices', icon: 'dashicons-megaphone',
      kw: ['notices','notice','center','centre','message','messages','announcement'] },
    { key: 'blocked', icon: 'dashicons-lock',
      kw: ['blocked','block','blocks','ban','banned','restrict','restricted','sender','senders'] },
    
    // Appearance & Theme
    { key: 'themes', icon: 'dashicons-admin-appearance',
      kw: ['themes','theme','appearance','look','style','styles'] },
    { key: 'design', icon: 'dashicons-art',
      kw: ['design','designing','visual','graphic','graphics','styling'] },
    { key: 'customize', icon: 'dashicons-admin-customizer',
      kw: ['customize','customizing','customization','personalize','personalization'] },
    { key: 'widgets', icon: 'dashicons-welcome-widgets-menus',
      kw: ['widget','widgets','sidebar','sidebars'] },
    { key: 'menus', icon: 'dashicons-menu',
      kw: ['menu','menus','navigation','nav','links'] },
    
    // Activation & License
    { key: 'activation', icon: 'dashicons-admin-network',
      kw: ['activation','activate','activating','license','licenses','key','keys','registration','register'] },
    
    // General
    { key: 'money', icon: 'dashicons-money',
      kw: ['payment','payments','gateway','invoice','billing','payout','subscription'] },
    { key: 'security', icon: 'dashicons-shield',
      kw: ['security','firewall','scan','malware','protect','protection','secure'] },
    { key: 'cloud', icon: 'dashicons-cloud',
      kw: ['cloud','backup','backups','sync','synchronize'] },
    { key: 'seo', icon: 'dashicons-chart-area',
      kw: ['seo','rank','search','meta','schema','optimization'] },
    { key: 'email', icon: 'dashicons-email',
      kw: ['email','emails','mail','smtp','message','messages','inbox','email-to','email-to-ticket'] },
    { key: 'ratings', icon: 'dashicons-star-filled',
      kw: ['rating','ratings','rate','rates','review','reviews','feedback','star','stars'] },
    { key: 'tickets', icon: 'dashicons-tickets-alt',
      kw: ['ticket','tickets','support-ticket','support-tickets'] },
    { key: 'calendar', icon: 'dashicons-calendar-alt',
      kw: ['calendar','event','events','schedule','scheduling','appointment','appointments'] },
    { key: 'star', icon: 'dashicons-star-filled',
      kw: ['star','favorite','favorites','bookmark','bookmarks','premium','pro'] },
  ];

  function normParts(url, title) {
    const out = [];
    const seen = new Set();
    
    const add = (s) => {
      if (!s) return;
      const lower = String(s).toLowerCase();
      // Split by non-alphanumeric, but keep compound words
      const parts = lower.split(/[^a-z0-9]+/).filter(p => p.length > 0);
      
      parts.forEach(part => {
        if (part && !seen.has(part)) {
          seen.add(part);
          out.push(part);
        }
        
        // Extract compound words (e.g., "importer" from "demo-importer")
        // Split camelCase and hyphenated words
        const compound = part.split(/(?=[A-Z])|[-_]/).filter(p => p.length > 1);
        compound.forEach(c => {
          if (c && !seen.has(c)) {
            seen.add(c);
            out.push(c);
          }
        });
      });
    };
    
    add(url);
    // Consider URL params like page, post_type, taxonomy for better accuracy
    try {
      const u = new URL(url, location.origin);
      ['page','post_type','taxonomy','path'].forEach(k => {
        const v = u.searchParams.get(k);
        if (v) add(v);
      });
      add(u.pathname);
      add(u.search);
    } catch(_) {}
    
    // Title gets special treatment - split into words and analyze
    if (title) {
      const titleLower = String(title).toLowerCase();
      // Split title into meaningful words
      const titleWords = titleLower.split(/[\s\-_]+/).filter(w => w.length > 1);
      titleWords.forEach(word => {
        add(word);
        // Extract root words (remove common suffixes)
        const root = word.replace(/(er|or|ing|ed|s|ies|ly)$/, '');
        if (root.length > 2 && root !== word) {
          add(root);
        }
      });
    }
    
    return out; // tokens
  }

  function score(tokens, kwList, fullText = '') {
    let s = 0;
    const tokenSet = new Set(tokens);
    const fullLower = fullText.toLowerCase();
    
    for (const k of kwList) {
      // Exact match gets highest score
      if (tokenSet.has(k)) {
        s += 5; // Increased weight for exact match
        continue;
      }
      
      // Check if keyword appears in full text (context-aware)
      if (fullLower.indexOf(k) !== -1) {
        s += 3; // Good match in context
        continue;
      }
      
      // Partial match (token contains keyword or vice versa)
      for (const t of tokens) {
        if (t.indexOf(k) !== -1 || k.indexOf(t) !== -1) {
          s += 1;
          break;
        }
      }
    }
    
    return s;
  }
  
  // Analyze full title to understand context and meaning
  function analyzeTitle(title) {
    if (!title) return { primary: '', secondary: '', action: '', context: [] };
    
    const lower = title.toLowerCase().trim();
    const words = lower.split(/[\s\-_]+/).filter(w => w.length > 1);
    
    // Extract action words (verbs)
    const actions = ['import', 'export', 'install', 'uninstall', 'manage', 'edit', 'create', 'add', 'delete', 'remove', 'erase', 'update', 'activate', 'deactivate', 'report', 'test', 'build', 'map', 'customize', 'design'];
    const action = words.find(w => actions.some(a => w.includes(a) || a.includes(w))) || '';
    
    // Extract primary subject (main noun)
    const primary = words[0] || '';
    
    // Extract secondary subject (if exists)
    const secondary = words.length > 1 ? words[1] : '';
    
    // Build context array with all meaningful words
    const context = words.filter(w => w.length > 2);
    
    return { primary, secondary, action, context, full: lower };
  }

  function predictIcon({ url = '', title = '', parentIcon = '' }) {
    const tokens = normParts(url, title);
    const analysis = analyzeTitle(title);
    const flat = tokens.join(' ').toLowerCase();
    const tokenSet = new Set(tokens);
    const fullText = title + ' ' + url;

    // 1) Smart context-aware scoring with full text analysis
    // Give more weight to title tokens (they're more descriptive)
    const titleTokens = normParts('', title);
    const allTokens = [...titleTokens, ...titleTokens, ...tokens, ...analysis.context]; // Title gets 2x weight + context
    
    // Track all potential matches with scores
    const candidates = [];
    
    // Score all categories with full context
    for (const c of CATEGORIES) {
      let s = score(allTokens, c.kw, fullText);
      
      // Boost score based on action word matching
      if (analysis.action) {
        const actionMatch = c.kw.some(k => {
          const kLower = k.toLowerCase();
          return analysis.action.includes(kLower) || kLower.includes(analysis.action);
        });
        if (actionMatch) s += 4; // Strong boost for action match
      }
      
      // Boost score based on primary word matching
      if (analysis.primary) {
        const primaryMatch = c.kw.some(k => {
          const kLower = k.toLowerCase();
          return analysis.primary.includes(kLower) || kLower.includes(analysis.primary);
        });
        if (primaryMatch) s += 3; // Good boost for primary match
      }
      
      // Boost score based on secondary word matching
      if (analysis.secondary) {
        const secondaryMatch = c.kw.some(k => {
          const kLower = k.toLowerCase();
          return analysis.secondary.includes(kLower) || kLower.includes(analysis.secondary);
        });
        if (secondaryMatch) s += 2; // Moderate boost for secondary match
      }
      
      candidates.push({ icon: c.icon, score: s, key: c.key });
    }
    
    // Sort by score (highest first)
    candidates.sort((a, b) => b.score - a.score);
    
    // Find best match with minimum threshold
    let best = { icon: '', score: -1, key: '' };
    const minScore = 3; // Minimum score threshold
    
    for (const candidate of candidates) {
      if (candidate.score >= minScore) {
        best = candidate;
        break;
      }
    }
    
    // If no good match, use highest score anyway if it's > 0
    if (best.score <= 0 && candidates.length > 0 && candidates[0].score > 0) {
      best = candidates[0];
    }

    // 2) Smart context-based overrides (understand meaning, not just words)
    // Analyze the full meaning of the title
    
    // Import/Export detection
    if (analysis.action === 'import' || analysis.full.includes('importer')) {
      if (analysis.full.includes('demo') || analysis.full.includes('page') || analysis.full.includes('content')) {
        // Differentiate between demo and page importers
        if (analysis.full.includes('demo')) {
          best = { icon: 'dashicons-download', score: 10, key: 'import' };
        } else if (analysis.full.includes('page')) {
          best = { icon: 'dashicons-upload', score: 10, key: 'import' };
        } else {
          best = { icon: 'dashicons-upload', score: 9, key: 'import' };
        }
      }
    }
    
    if (analysis.action === 'export' || analysis.full.includes('exporter')) {
      best = { icon: 'dashicons-download', score: 10, key: 'export' };
    }
    
    // Install/Uninstall detection
    if (analysis.action === 'install' || analysis.full.includes('install')) {
      if (analysis.full.includes('plugin') || analysis.full.includes('extension')) {
        best = { icon: 'dashicons-admin-plugins', score: 10, key: 'install' };
      } else {
        best = { icon: 'dashicons-admin-plugins', score: 9, key: 'install' };
      }
    }
    
    if (analysis.action === 'uninstall' || analysis.full.includes('uninstall')) {
      best = { icon: 'dashicons-dismiss', score: 10, key: 'uninstall' };
    }
    
    // System/Status detection
    if (analysis.full.includes('system') && analysis.full.includes('status')) {
      best = { icon: 'dashicons-dashboard', score: 10, key: 'status' };
    } else if (analysis.full.includes('status') && !analysis.full.includes('plugin')) {
      best = { icon: 'dashicons-info', score: 9, key: 'status' };
    }
    
    // Health detection
    if (analysis.full.includes('health') || analysis.full.includes('site-health')) {
      best = { icon: 'dashicons-heart', score: 10, key: 'health' };
    }
    
    // Erase/Delete detection
    if (analysis.action === 'erase' || analysis.action === 'delete' || analysis.full.includes('erase') || analysis.full.includes('remove')) {
      if (analysis.full.includes('personal') || analysis.full.includes('data')) {
        best = { icon: 'dashicons-trash', score: 10, key: 'erase' };
      } else {
        best = { icon: 'dashicons-trash', score: 9, key: 'erase' };
      }
    }
    
    // Users/Profile detection
    if (analysis.full.includes('all users') || analysis.full === 'users') {
      best = { icon: 'dashicons-groups', score: 10, key: 'users' };
    } else if (analysis.full.includes('profile') || analysis.full.includes('my account')) {
      best = { icon: 'dashicons-admin-users', score: 10, key: 'profile' };
    } else if (analysis.full.includes('user') && !analysis.full.includes('plugin')) {
      best = { icon: 'dashicons-groups', score: 8, key: 'users' };
    }
    
    // Home detection
    if (analysis.full === 'home' || analysis.full.startsWith('home ')) {
      best = { icon: 'dashicons-admin-home', score: 10, key: 'home' };
    }
    
    // Report/Bug detection
    if (analysis.action === 'report' || analysis.full.includes('report') || analysis.full.includes('bug')) {
      best = { icon: 'dashicons-warning', score: 10, key: 'bug' };
    }
    
    // Builder detection
    if (analysis.full.includes('builder') || analysis.full.includes('build')) {
      if (analysis.full.includes('grid')) {
        best = { icon: 'dashicons-layout', score: 10, key: 'builder' };
      } else {
        best = { icon: 'dashicons-layout', score: 9, key: 'builder' };
      }
    }
    
    // Mapper detection
    if (analysis.full.includes('mapper') || analysis.full.includes('map')) {
      if (analysis.full.includes('shortcode')) {
        best = { icon: 'dashicons-admin-links', score: 10, key: 'mapper' };
      } else {
        best = { icon: 'dashicons-admin-links', score: 9, key: 'mapper' };
      }
    }
    
    // Code/JS detection
    if (analysis.full.includes('custom js') || analysis.full.includes('javascript') || (analysis.full.includes('code') && !analysis.full.includes('shortcode'))) {
      best = { icon: 'dashicons-editor-code', score: 10, key: 'code' };
    }
    
    // AI detection
    if (analysis.full.includes('ai') || analysis.full.includes('artificial intelligence')) {
      best = { icon: 'dashicons-star-filled', score: 10, key: 'ai' };
    }
    
    // Email-to-Ticket detection (differentiate from ratings)
    if (analysis.full.includes('email-to-ticket') || (analysis.full.includes('email') && analysis.full.includes('ticket'))) {
      best = { icon: 'dashicons-email', score: 10, key: 'email' };
    }
    
    // Ticket Ratings detection (differentiate from email-to-ticket)
    if (analysis.full.includes('ticket') && analysis.full.includes('rating')) {
      best = { icon: 'dashicons-star-filled', score: 10, key: 'ratings' };
    }
    
    // Products detection
    if (analysis.full.includes('all products') || (analysis.full.includes('products') && !analysis.full.includes('analytics'))) {
      if (analysis.full.includes('brand')) {
        best = { icon: 'dashicons-awards', score: 10, key: 'brands' };
      } else if (analysis.full.includes('attribute')) {
        best = { icon: 'dashicons-filter', score: 10, key: 'attributes' };
      } else {
        best = { icon: 'dashicons-products', score: 10, key: 'products' };
      }
    }
    
    // Variations detection
    if (analysis.full.includes('variation')) {
      best = { icon: 'dashicons-randomize', score: 10, key: 'variations' };
    }
    
    // Taxes detection
    if (analysis.full.includes('tax') && !analysis.full.includes('taxonomy')) {
      best = { icon: 'dashicons-money', score: 10, key: 'taxes' };
    }
    
    // Forms detection
    if (analysis.full.includes('contact form') || (analysis.full.includes('form') && analysis.full.includes('contact'))) {
      best = { icon: 'dashicons-feedback', score: 10, key: 'forms' };
    }
    
    // Integration detection
    if (analysis.full.includes('integration')) {
      best = { icon: 'dashicons-admin-links', score: 10, key: 'integration' };
    }
    
    // Typography detection
    if (analysis.full.includes('typography')) {
      best = { icon: 'dashicons-editor-textcolor', score: 10, key: 'typography' };
    }
    
    // Color Picker detection
    if (analysis.full.includes('color') && analysis.full.includes('picker')) {
      best = { icon: 'dashicons-art', score: 10, key: 'color' };
    }
    
    // Appearance/Theme detection - be more specific
    if (analysis.full.includes('theme') && !analysis.full.includes('editor')) {
      if (analysis.full.includes('options')) {
        best = { icon: 'dashicons-admin-appearance', score: 10, key: 'themes' };
      } else if (analysis.full.includes('file') && analysis.full.includes('editor')) {
        best = { icon: 'dashicons-editor-code', score: 10, key: 'code' };
      } else {
        best = { icon: 'dashicons-admin-appearance', score: 9, key: 'themes' };
      }
    } else if (analysis.full.includes('design') && !analysis.full.includes('theme')) {
      best = { icon: 'dashicons-art', score: 10, key: 'design' };
    } else if (analysis.full.includes('customize') && !analysis.full.includes('theme')) {
      best = { icon: 'dashicons-admin-customizer', score: 10, key: 'customize' };
    } else if (analysis.full.includes('widget')) {
      best = { icon: 'dashicons-welcome-widgets-menus', score: 10, key: 'widgets' };
    } else if (analysis.full.includes('menu') && !analysis.full.includes('item')) {
      best = { icon: 'dashicons-menu', score: 10, key: 'menus' };
    }
    
    // Context-aware filtering - avoid generic icons
    if (best.key === 'appearance' && 
        !analysis.full.match(/\b(theme|appearance|customize|widget|menu|color|design|style|themes)\b/)) {
      // Find next best match from candidates
      const nextBest = candidates.find(c => c.key !== 'appearance' && c.score >= minScore);
      if (nextBest) best = nextBest;
    }

    // Avoid generic icons (editor, manager, system) when we can find better
    const genericKeys = ['editor', 'manager', 'system'];
    if (genericKeys.includes(best.key) && best.score < 5) {
      // Try to find a more specific match from candidates
      const nextBest = candidates.find(c => !genericKeys.includes(c.key) && c.score >= minScore);
      if (nextBest && nextBest.score > best.score) {
        best = nextBest;
      }
    }

    // 5) Smart fallback logic - avoid generic icons
    if (best.score <= 0) {
      // Avoid appearance icon for non-theme items
      if (parentIcon === 'dashicons-admin-appearance' && 
          !flat.match(/\b(theme|appearance|customize|widget|menu|themes|design)\b/)) {
        return '';
      }
      
      // Avoid plug icon as fallback
      if (parentIcon && parentIcon.includes('plug')) {
        return '';
      }
      
      // Use parentIcon only if it's not generic
      if (parentIcon && /^dashicons-/.test(parentIcon)) {
        // Avoid using edit/admin-links/admin-generic/plug as fallback
        if (!parentIcon.match(/admin-links|edit|admin-generic|plug/)) {
          return parentIcon;
        }
      }
      
      return '';
    }
    
    // 6) Minimum score threshold for confidence
    // Only return icon if we have reasonable confidence
    if (best.score < 2 && genericKeys.includes(best.key)) {
      // If generic is low confidence, try parentIcon if available
      if (parentIcon && /^dashicons-/.test(parentIcon) && 
          !parentIcon.match(/admin-links|edit|admin-generic|plug/)) {
        return parentIcon;
      }
    }
    
    return best.icon;
  }

  // API
  window.YPIconAI = {
    predict: predictIcon,
    // Optional: lightweight learning hook
    learn(keyword, key, w = 1) {
      const c = CATEGORIES.find(x => x.key === key);
      if (!c) return;
      if (!c.kw.includes(keyword)) c.kw.push(keyword);
    }
  };
})();
