/**
 * License Management JavaScript for YOOAdmin Panel
 * Panel Connect flow only (OTP/Portal Session removed)
 *
 * @package YOOAdmin_Extended
 * @since 1.3.4
 */

(function($) {
    'use strict';

    /**
     * License Manager Object
     */
    const LicenseManager = {

        portalSession: { token: null, domain: '', licenses: [], selectedLicense: null, user: {} },

        /**
         * Initialize manager.
         */
        init: function() {
            this.bindEvents();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            const handlerContext = this;
            $(document)
                .off('submit.yooadmLicense', '#license-activation-form')
                .on('submit.yooadmLicense', '#license-activation-form', function (event) {
                    handlerContext.handleActivation(event);
                });

            $(document)
                .off('click.yooadmLicense', '#deactivate-license-btn')
                .on('click.yooadmLicense', '#deactivate-license-btn', function (event) {
                    handlerContext.handleDeactivation(event);
                });

            $(document)
                .off('click.yooadmLicense', '#check-license-btn')
                .on('click.yooadmLicense', '#check-license-btn', function (event) {
                    handlerContext.handleCheck(event);
                });

            this.bindPanelConnectEvents();
        },

        /**
         * Refresh dashboard widgets after license status changes.
         */
        notifyDashboardUpdatesRefresh: function(data) {
            try {
                document.dispatchEvent(
                    new CustomEvent('yooadmin:license-status-changed', {
                        detail: data || { is_active: true, status: 'active' },
                    })
                );
            } catch (err) {
                /* ignore */
            }
        },

        /**
         * Bind panel-connect popup events (Get Free License / Login buttons).
         */
        bindPanelConnectEvents: function() {
            const handlerContext = this;
            $(document)
                .off('click.yooadmLicense', '.yooadmin-panel-connect-trigger')
                .on('click.yooadmLicense', '.yooadmin-panel-connect-trigger', function (e) {
                    e.preventDefault();
                    let url = $(this).data('panel-url') || $(this).attr('href');
                    if (url) {
                        try {
                            const u = new URL(url);
                            if (!u.searchParams.has('domain') || u.searchParams.get('domain') === '') {
                                const domain = window.location.hostname || '';
                                if (domain) u.searchParams.set('domain', domain);
                                url = u.toString();
                            }
                        } catch (err) {}
                        const pw = 440, ph = 680;
                        const left = Math.max(0, (window.screen.width - pw) / 2);
                        const top = Math.max(0, (window.screen.height - ph) / 2);
                        const w = window.open(url, 'yooadmPanelConnect', 'width=' + pw + ',height=' + ph + ',left=' + left + ',top=' + top + ',resizable=yes,scrollbars=yes');
                        if (!w) {
                            handlerContext.showNotification('Popup was blocked. Please allow popups and try again.', 'error');
                        }
                    }
                });

            const portalOrigin = (typeof yooadmLicense !== 'undefined' && yooadmLicense.portalOrigin) ? yooadmLicense.portalOrigin : '';
            const originsMatch = (a, b) => {
                if (!a || !b) return !a && !b;
                if (a === b) return true;
                try {
                    const hostA = new URL(a).hostname.replace(/^www\./, '');
                    const hostB = new URL(b).hostname.replace(/^www\./, '');
                    return hostA === hostB;
                } catch (e) {
                    return false;
                }
            };
            window.addEventListener('message', function(event) {
                if (!portalOrigin) return;
                if (!originsMatch(event.origin, portalOrigin)) return;
                const data = event.data || {};
                if (data.type === 'yoopixel-portal-token' && data.activation_code) {
                    handlerContext.activateFromPanelConnect(data.activation_code);
                }
            });
        },

        activateFromPanelConnect: function(activationCode) {
            if (!activationCode || typeof activationCode !== 'string') return;
            const code = activationCode.trim();
            if (!code) return;

            $.ajax({
                url: yooadmLicense.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_activate_license',
                    nonce: yooadmLicense.nonce,
                    activation_code: code,
                },
                success: (response) => {
                    if (response.success) {
                        this.showNotification(response.data.message || 'Account connected successfully!', 'success');
                        this.triggerCelebration();
                        this.notifyDashboardUpdatesRefresh({ is_active: true, status: 'active' });
                        if ($('.yooadmin-setup-wrapper').length && typeof window.yooadmWizard !== 'undefined') {
                            $.ajax({
                                url: window.yooadmWizard.ajaxurl,
                                type: 'POST',
                                data: { action: 'yooadmin_refresh_license_step', nonce: window.yooadmWizard.nonce },
                                success: (r) => {
                                    if (r.success && r.data && r.data.html) {
                                        const $w = $('<div>').html(r.data.html);
                                        $('.wizard-step-header').replaceWith($w.find('.wizard-step-header'));
                                        $('.wizard-step-body').replaceWith($w.find('.wizard-step-body'));
                                        if (r.data.is_active) {
                                            $('.yooadmin-wizard-card').prepend('<div class="notice notice-success is-dismissible" style="margin: 20px 0;"><p><strong>License Activated Successfully!</strong></p></div>');
                                            $('.yooadmin-wizard-page').trigger('yooadmin:wizard-license-status', [true]);
                                        }
                                    }
                                },
                            });
                        } else {
                            this.refreshLicenseView();
                        }
                    } else {
                        this.showNotification((response.data && response.data.message) || 'Activation failed.', 'error');
                    }
                },
                error: (xhr) => {
                    this.showNotification((xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || 'Connection error. Please try again.', 'error');
                },
            });
        },

        handleActivation: function(e) {
            e.preventDefault();

            const $btn = $('#activate-license-btn');
            const activationCode = $('#activation-code-input').val().trim();

            if (!activationCode) {
                this.showNotification('Please enter a valid activation code.', 'error');
                return;
            }

            $btn.prop('disabled', true);
            $btn.find('.dashicons').removeClass('dashicons-yes').addClass('dashicons-update spin');

            $.ajax({
                url: yooadmLicense.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_activate_license',
                    nonce: yooadmLicense.nonce,
                    activation_code: activationCode,
                },
                success: (response) => {
                    if (response.success) {
                        this.showNotification(response.data.message || 'Account connected successfully!', 'success');
                        this.resetButton($btn, 'dashicons-yes');
                        this.triggerCelebration();
                        this.notifyDashboardUpdatesRefresh({ is_active: true, status: 'active' });
                        const activationForm = document.getElementById('license-activation-form');
                        if (activationForm && typeof activationForm.reset === 'function') {
                            activationForm.reset();
                        }
                        this.refreshLicenseView();
                    } else {
                        let errorMsg = 'License activation failed.';
                        if (response.data && response.data.message) {
                            errorMsg = response.data.message;
                        }
                        this.showNotification(errorMsg, 'error');
                        this.resetButton($btn, 'dashicons-yes');
                    }
                },
                error: (xhr) => {
                    let errorMsg = 'Connection error. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errorMsg = xhr.responseJSON.data.message;
                    }
                    this.showNotification(errorMsg, 'error');
                    this.resetButton($btn, 'dashicons-yes');
                },
            });
        },

        handleDeactivation: function(e) {
            e.preventDefault();

            const hasPortal =
                $('.yooadmin-license-status-card').data('has-portal') === 1 ||
                $('.yooadmin-license-status-card').data('has-portal') === '1';
            const title = hasPortal
                ? this.portalMessage('confirmDisconnect', 'Disconnect License')
                : this.portalMessage('confirmDeactivate', 'Are you sure you want to deactivate your license?');
            const message = hasPortal
                ? this.portalMessage('confirmDisconnectMsg', 'Disconnecting will deactivate the license on this site. Continue?')
                : this.portalMessage('confirmDeactivateMsg', 'This will remove the license from this site. You can reactivate it later from your account.');

            const $btn = $(e.currentTarget);
            
            this.showDeactivationModal(title, message, ($modal, $confirmBtn) => {
                if (hasPortal) {
                    this.handlePortalDisconnect($btn, $modal, $confirmBtn);
                } else {
                    this.performDeactivation($btn, $modal, $confirmBtn);
                }
            });
        },
        
        showDeactivationModal: function(title, message, onConfirm) {
            const t = yooadmLicense.portalMessages || {};
            const modalHtml = `
                <div class="yp-modal" id="yp-deactivate-license-modal">
                    <div class="yp-modal-overlay"></div>
                    <div class="yp-modal-content">
                        <button class="yp-modal-close" aria-label="${t.close || 'Close'}">
                            <span class="dashicons dashicons-no-alt"></span>
                        </button>
                        <div class="yp-modal-header">
                            <span class="dashicons dashicons-warning yp-modal-icon" style="color: #d63638;"></span>
                            <h2 class="yp-modal-title">${title}</h2>
                        </div>
                        <div class="yp-modal-body">
                            <p class="yp-modal-details">${message}</p>
                        </div>
                        <div class="yp-modal-footer">
                            <button type="button" class="yp-yoo-btn yp-yoo-btn--secondary yp-modal-cancel">${t.cancel || 'Cancel'}</button>
                            <button type="button" class="yp-yoo-btn yp-yoo-btn--primary yp-modal-confirm">${t.deactivate || 'Disconnect'}</button>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(modalHtml);
            
            const $modal = $('#yp-deactivate-license-modal');
            
            $modal.find('.yp-modal-close, .yp-modal-cancel, .yp-modal-overlay').on('click', function() {
                $modal.fadeOut(200, function() {
                    $modal.remove();
                });
            });
            
            $modal.find('.yp-modal-confirm').on('click', function() {
                const $confirmBtn = $(this);
                $confirmBtn.prop('disabled', true);
                $confirmBtn.html('<span class="dashicons dashicons-update spin"></span> ' + (yooadmLicense.portalMessages && yooadmLicense.portalMessages.processing || 'Processing...'));
                
                if (typeof onConfirm === 'function') {
                    onConfirm($modal, $confirmBtn);
                }
            });
            
            $modal.hide().fadeIn(200);
        },
        
        performDeactivation: function($btn, $modal, $confirmBtn) {
            $.ajax({
                url: yooadmLicense.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_deactivate_license',
                    nonce: yooadmLicense.nonce,
                },
                success: (response) => {
                    if (response.success) {
                        const t = yooadmLicense.portalMessages || {};
                        $modal.find('.yp-modal-header .yp-modal-icon').removeClass('dashicons-warning').addClass('dashicons-yes-alt').css('color', '#00a32a');
                        $modal.find('.yp-modal-title').text(t.licenseDeactivatedTitle || 'License Deactivated Successfully');
                        $modal.find('.yp-modal-details').html('<strong>' + (response.data.message || t.licenseDeactivatedMessage || 'License deactivated successfully!') + '</strong>');
                        $modal.find('.yp-modal-footer').html('<button type="button" class="yp-yoo-btn yp-yoo-btn--primary yp-modal-close-success">' + (t.close || 'Close') + '</button>');
                        
                        $modal.find('.yp-modal-close-success, .yp-modal-close, .yp-modal-overlay').off('click').on('click', function() {
                            $modal.fadeOut(200, function() {
                                $modal.remove();
                            });
                        });
                        
                        this.refreshLicenseView();
                    } else {
                        $modal.find('.yp-modal-details').html('<div style="color: #d63638; margin-top: 10px;"><strong>Error:</strong> ' + (response.data.message || 'Failed to deactivate license.') + '</div>');
                        $confirmBtn.prop('disabled', false).html(yooadmLicense.portalMessages && yooadmLicense.portalMessages.deactivate || 'Deactivate');
                    }
                },
                error: () => {
                    const errMsg = yooadmLicense.portalMessages && yooadmLicense.portalMessages.disconnectFailed || 'Connection error. Please try again.';
                    $modal.find('.yp-modal-details').html('<div style="color: #d63638; margin-top: 10px;"><strong>Error:</strong> ' + errMsg + '</div>');
                    $confirmBtn.prop('disabled', false).html(yooadmLicense.portalMessages && yooadmLicense.portalMessages.deactivate || 'Deactivate');
                },
            });
        },

        handleCheck: function(e) {
            e.preventDefault();

            const $btn = $(e.target);

            $btn.prop('disabled', true);
            $btn.find('.dashicons').removeClass('dashicons-update').addClass('dashicons-update spin');

            $.ajax({
                url: yooadmLicense.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_check_license',
                    nonce: yooadmLicense.nonce,
                },
                success: (response) => {
                    if (response.success) {
                        this.showNotification(response.data.message || 'License status updated successfully.', 'success');
                        this.resetButton($btn, 'dashicons-update');
                        this.refreshLicenseView();
                    } else {
                        const errorMsg = (response.data && response.data.message) || 'License check failed. Please try again.';
                        if (response.data && response.data.reload) {
                            this.showNotification(errorMsg, 'warning');
                            this.resetButton($btn, 'dashicons-update');
                            this.refreshLicenseView();
                        } else {
                            this.showNotification(errorMsg, 'error');
                            this.resetButton($btn, 'dashicons-update');
                        }
                    }
                },
                error: () => {
                    this.showNotification('Connection error. Please try again.', 'error');
                    this.resetButton($btn, 'dashicons-update');
                },
            });
        },

        refreshLicenseView: function(callback) {
            $.ajax({
                url: yooadmLicense.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_refresh_license_view',
                    nonce: yooadmLicense.nonce,
                },
                success: (response) => {
                    if (response.success && response.data && response.data.html) {
                        $('.yooadmin-license-status-card').replaceWith(response.data.html);
                        this.updateHeaderBadge(response.data);
                        if (typeof callback === 'function') {
                            callback(response);
                        }
                    } else {
                        const message = (response.data && response.data.message) || 'Unable to refresh license view.';
                        this.showNotification(message, 'error');
                    }
                },
                error: () => {
                    this.showNotification('Failed to refresh license details. Please reload the page.', 'error');
                    if (typeof callback === 'function') {
                        callback();
                    }
                },
            });
        },
        
        updateHeaderBadge: function(data) {
            data = data || {};
            const $badge = $('.yp-license-status-button');
            if (!$badge.length) return;

            const isActive = data.is_active || false;
            const status = data.status || 'inactive';
            let statusClass = 'inactive';
            let label = 'Connect Account';
            let icon = 'dashicons-admin-users';

            $badge.removeClass(
                'yp-license-status-active yp-license-status-inactive yp-license-status-expired yp-license-status-expiring yp-license-status-suspended'
            );

            if (isActive) {
                statusClass = 'active';
                label = 'Active';
                icon = 'dashicons-yes-alt';
            } else if (status === 'expiring') {
                statusClass = 'expiring';
                label = 'Expiring Soon';
                icon = 'dashicons-clock';
            } else if (status === 'suspended') {
                statusClass = 'suspended';
                label = 'Suspended';
                icon = 'dashicons-warning';
            } else if (status === 'expired' || status === 'revoked') {
                statusClass = 'expired';
                label = status.charAt(0).toUpperCase() + status.slice(1);
                icon = 'dashicons-warning';
            } else {
                statusClass = 'inactive';
                label = 'Connect Account';
                icon = 'dashicons-admin-users';
            }

            $badge.addClass('yp-license-status-' + statusClass);
            $badge.find('.yp-license-status-text, .screen-reader-text').text(label);
            $badge.attr('aria-label', label).attr('title', label);
            $badge.find('.dashicons').first()
                .removeClass('dashicons-admin-users dashicons-yes-alt dashicons-clock dashicons-warning')
                .addClass(icon);
        },

        showNotification: function(message, type) {
            $('#yp-license-feedback-modal').remove();

            const icons = {
                success: 'dashicons-yes-alt',
                error: 'dashicons-dismiss',
                warning: 'dashicons-warning',
                info: 'dashicons-info',
            };

            const safeType = (type && icons[type]) ? type : 'info';
            const titleMap = {
                success: 'Success',
                error: 'License Error',
                warning: 'License Warning',
                info: 'Information',
            };
            const t = yooadmLicense.portalMessages || {};
            const closeText = t.close || 'Close';

            const modalHtml = `
                <div class="yp-modal" id="yp-license-feedback-modal">
                    <div class="yp-modal-overlay"></div>
                    <div class="yp-modal-content">
                        <button class="yp-modal-close" aria-label="${closeText}">
                            <span class="dashicons dashicons-no-alt"></span>
                        </button>
                        <div class="yp-modal-header">
                            <span class="dashicons ${icons[safeType]} yp-modal-icon yp-modal-icon--${safeType}"></span>
                            <h2 class="yp-modal-title">${titleMap[safeType]}</h2>
                        </div>
                        <div class="yp-modal-body">
                            <p class="yp-modal-details"></p>
                        </div>
                        <div class="yp-modal-footer">
                            <button type="button" class="yp-yoo-btn yp-yoo-btn--primary yp-modal-close-feedback">${closeText}</button>
                        </div>
                    </div>
                </div>
            `;

            $('body').append(modalHtml);
            const $modal = $('#yp-license-feedback-modal');
            $modal.find('.yp-modal-details').text(message || '');

            $modal.find('.yp-modal-close, .yp-modal-overlay, .yp-modal-close-feedback').on('click', function() {
                $modal.fadeOut(150, function() {
                    $modal.remove();
                });
            });

            $modal.hide().fadeIn(180);
        },

        resetButton: function($btn, iconClass) {
            $btn.prop('disabled', false);
            $btn.find('.dashicons').removeClass('dashicons-update spin').addClass(iconClass);
        },

        triggerCelebration: function() {
            const canvas = document.createElement('canvas');
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            canvas.style.position = 'fixed';
            canvas.style.top = '0';
            canvas.style.left = '0';
            canvas.style.pointerEvents = 'none';
            canvas.style.zIndex = '9999999999';
            document.body.appendChild(canvas);

            const ctx = canvas.getContext('2d');
            const colors = ['#F8C102', '#00C6AE', '#F35D6B', '#7C5CE6', '#3FA1F2'];
            const particles = [];
            const total = 80;

            for (let i = 0; i < total; i++) {
                particles.push({
                    x: canvas.width / 2,
                    y: canvas.height / 2,
                    r: Math.random() * 6 + 2,
                    c: colors[Math.floor(Math.random() * colors.length)],
                    vx: (Math.random() - 0.5) * 12,
                    vy: (Math.random() - 0.8) * 14,
                    g: 0.35 + Math.random() * 0.2,
                    a: 0.95 + Math.random() * 0.04
                });
            }

            const endAt = Date.now() + 1500;

            function draw() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                particles.forEach(p => {
                    p.vx *= p.a;
                    p.vy += p.g;
                    p.x += p.vx;
                    p.y += p.vy;
                    ctx.beginPath();
                    ctx.fillStyle = p.c;
                    ctx.globalAlpha = 0.9;
                    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                    ctx.fill();
                });
                if (Date.now() < endAt) {
                    requestAnimationFrame(draw);
                } else {
                    document.body.removeChild(canvas);
                }
            }
            requestAnimationFrame(draw);
        },

        portalMessage: function(key, fallback) {
            const messages = yooadmLicense.portalMessages || {};
            return messages[key] || fallback || '';
        },

        resetPortalSession: function() {
            this.portalSession.token = null;
            this.portalSession.domain = '';
            this.portalSession.licenses = [];
            this.portalSession.selectedLicense = null;
            this.portalSession.user = {};
        },

        handlePortalDisconnect: function($btn, $modal, $confirmBtn) {
            $.ajax({
                url: yooadmLicense.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_disconnect_portal_session',
                    nonce: yooadmLicense.nonce,
                    token: this.portalSession.token || '',
                },
                success: (response) => {
                    if (response && response.success) {
                        const message = (response.data && response.data.message) || this.portalMessage('disconnectSuccess', 'License disconnected successfully.');
                        
                        $modal.find('.yp-modal-header .yp-modal-icon').removeClass('dashicons-warning').addClass('dashicons-yes-alt').css('color', '#00a32a');
                        const t = yooadmLicense.portalMessages || {};
                        $modal.find('.yp-modal-title').text(t.licenseDeactivatedTitle || 'License Disconnected Successfully');
                        $modal.find('.yp-modal-details').html('<strong>' + message + '</strong>');
                        $modal.find('.yp-modal-footer').html('<button type="button" class="yp-yoo-btn yp-yoo-btn--primary yp-modal-close-success">' + (t.close || 'Close') + '</button>');
                        
                        $modal.find('.yp-modal-close-success, .yp-modal-close, .yp-modal-overlay').off('click').on('click', function() {
                            $modal.fadeOut(200, function() {
                                $modal.remove();
                            });
                        });
                        
                        this.resetPortalSession();
                        this.refreshLicenseView();
                    } else {
                        const message = (response && response.data && response.data.message) || this.portalMessage('disconnectFailed', 'Connection error. Please try again.');
                        $modal.find('.yp-modal-details').html('<div style="color: #d63638; margin-top: 10px;"><strong>Error:</strong> ' + message + '</div>');
                        $confirmBtn.prop('disabled', false).html(yooadmLicense.portalMessages && yooadmLicense.portalMessages.deactivate || 'Deactivate');
                    }
                },
                error: () => {
                    $modal.find('.yp-modal-details').html('<div style="color: #d63638; margin-top: 10px;"><strong>Error:</strong> ' + (yooadmLicense.portalMessages && yooadmLicense.portalMessages.disconnectFailed || 'Connection error. Please try again.') + '</div>');
                    $confirmBtn.prop('disabled', false).html(yooadmLicense.portalMessages && yooadmLicense.portalMessages.deactivate || 'Deactivate');
                },
            });
        },
    };

    window.LicenseManager = LicenseManager;

    $(document).ready(function() {
        LicenseManager.init();
    });

})(jQuery);
