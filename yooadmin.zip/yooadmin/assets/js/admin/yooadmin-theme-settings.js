/**
 * YOOAdmin - Theme settings (live preview, save)
 *
 * @package YOOAdmin
 */

/* global wp */
(function ($) {
    'use strict';

    var documentElement = document.documentElement;

    function applyCssVar(cssVar, value, fallback) {
        if (!cssVar) {
            return;
        }
        var finalValue = value || fallback || '';
        if (finalValue) {
            documentElement.style.setProperty(cssVar, finalValue);
        } else {
            documentElement.style.removeProperty(cssVar);
        }
    }

    function parseJsonAttr($el, attrName) {
        if (!$el || !$el.length) {
            return {};
        }
        var raw = $el.attr(attrName);
        if (!raw) {
            return {};
        }
        try {
            return JSON.parse(raw);
        } catch (error) {
            return {};
        }
    }

    function isEffectiveDarkMode() {
        return documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') === 'dark';
    }

    function effectiveFromRawColorMode(raw) {
        if (raw === 'auto') {
            try {
                return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
            } catch (error) {
                return 'light';
            }
        }
        return raw === 'dark' ? 'dark' : 'light';
    }

    function applyStudioColorModePreview(mode) {
        var normalized = mode === 'dark' || mode === 'auto' || mode === 'light' ? mode : 'auto';
        documentElement.setAttribute('data-yooadmin-studio-color-mode', normalized);
        documentElement.setAttribute(
            'data-yooadmin-studio-color-mode-effective',
            effectiveFromRawColorMode(normalized)
        );
        if (typeof window.yshPluginAdminAdaptSyncMode === 'function') {
            window.yshPluginAdminAdaptSyncMode();
        }
        try {
            document.dispatchEvent(new CustomEvent('ysh-studio-color-mode-changed'));
        } catch (error) {
            // IE11 — ignore
        }
    }

    function readShellAppearanceMode() {
        var raw = documentElement.getAttribute('data-yooadmin-studio-color-mode');
        return raw === 'light' || raw === 'dark' || raw === 'auto' ? raw : '';
    }

    function syncHeaderAppearanceUI(mode) {
        var root = document.querySelector('[data-ysh-appearance-root]');
        if (!root) {
            return;
        }
        var active = mode === 'dark' || mode === 'auto' || mode === 'light' ? mode : 'auto';
        var togglers = root.querySelectorAll('.ysh-appearance__ti');
        for (var t = 0; t < togglers.length; t++) {
            togglers[t].classList.remove('is-current');
        }
        var currentToggle = root.querySelector('.ysh-appearance__ti--' + active);
        if (currentToggle) {
            currentToggle.classList.add('is-current');
        }
        var options = root.querySelectorAll('.ysh-appearance__menu [data-ysh-appearance]');
        for (var i = 0; i < options.length; i++) {
            var button = options[i];
            var key = button.getAttribute('data-ysh-appearance');
            var isActive = key === active;
            button.classList.toggle('is-active', isActive);
            button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        }
    }

    function initAppearanceMode($form) {
        var $appearance = $form.find('[data-yooadmin-theme-appearance]');
        if (!$appearance.length) {
            return null;
        }

        var $input = $appearance.find('.yooadmin-theme-appearance-input');
        var appearanceInitial = $input.val() || 'auto';
        var appearanceDefault = $appearance.data('appearanceDefault') || 'auto';
        var mediaQuery = null;

        function setActivePill(mode) {
            $appearance.find('.yooadmin-theme-appearance-pill').each(function () {
                var $pill = $(this);
                var isActive = $pill.data('yooadminThemeAppearance') === mode;
                $pill.toggleClass('is-active', isActive);
                $pill.attr('aria-pressed', isActive ? 'true' : 'false');
            });
        }

        function bindAutoMediaListener() {
            if (mediaQuery && typeof mediaQuery.removeEventListener === 'function') {
                mediaQuery.removeEventListener('change', onSystemPreferenceChange);
            } else if (mediaQuery && typeof mediaQuery.removeListener === 'function') {
                mediaQuery.removeListener(onSystemPreferenceChange);
            }
            mediaQuery = null;

            if ($input.val() !== 'auto') {
                return;
            }

            try {
                mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
            } catch (error) {
                return;
            }

            if (typeof mediaQuery.addEventListener === 'function') {
                mediaQuery.addEventListener('change', onSystemPreferenceChange);
            } else if (typeof mediaQuery.addListener === 'function') {
                mediaQuery.addListener(onSystemPreferenceChange);
            }
        }

        function onSystemPreferenceChange() {
            if ($input.val() === 'auto') {
                applyStudioColorModePreview('auto');
            }
        }

        function applyMode(mode) {
            if (mode !== 'light' && mode !== 'dark' && mode !== 'auto') {
                return;
            }
            $input.val(mode);
            setActivePill(mode);
            applyStudioColorModePreview(mode);
            syncHeaderAppearanceUI(mode);
            bindAutoMediaListener();
        }

        $appearance.on('click', '.yooadmin-theme-appearance-pill', function (event) {
            event.preventDefault();
            applyMode($(this).data('yooadminThemeAppearance'));
        });

        bindAutoMediaListener();

        var shellMode = readShellAppearanceMode();
        if (shellMode && shellMode !== ($input.val() || 'auto')) {
            applyMode(shellMode);
        }

        return {
            apply: applyMode,
            syncFromShell: function () {
                var mode = readShellAppearanceMode();
                if (mode) {
                    applyMode(mode);
                }
                return mode || ($input.val() || 'auto');
            },
            getInitial: function () {
                return appearanceInitial;
            },
            getDefault: function () {
                return appearanceDefault;
            },
            setInitial: function (mode) {
                if (mode === 'light' || mode === 'dark' || mode === 'auto') {
                    appearanceInitial = mode;
                }
            }
        };
    }

    function switchToLightMode() {
        var lightBtn = document.querySelector('[data-ysh-appearance="light"]');
        if (lightBtn) {
            lightBtn.click();
        }
    }

    function closeModernColorPickers($current) {
        $('.yooadmin-theme-modern-color').each(function () {
            var $control = $(this);
            if ($current && $control.is($current)) {
                return;
            }
            $control.removeClass('is-open opens-up aligns-right');
            $control.find('.yooadmin-theme-modern-color__popover').attr('hidden', 'hidden');
            $control.find('.yooadmin-theme-modern-color__custom-panel').attr('hidden', 'hidden');
        });
    }

    function closeOtherPickers($current) {
        closeModernColorPickers($current && $current.closest ? $current.closest('.yooadmin-theme-modern-color') : null);

        var hasWpColorPicker = typeof $.fn.wpColorPicker === 'function';

        var $containers = $('.yooadmin-theme-settings-wrap .wp-picker-container.wp-picker-open');
        $containers.each(function () {
            var $container = $(this);
            if ($current && $container.has($current).length) {
                return;
            }

            var $input = $container.find('.yooadmin-color-field');
            if ($input.length && typeof $input.wpColorPicker === 'function') {
                $input.wpColorPicker('close');
            }

            $container.removeClass('wp-picker-active wp-picker-open');
            $container.find('.wp-picker-holder').hide();
            $container.find('.wp-color-result').attr('aria-expanded', 'false');
        });
    }

    function normalizeHexColor(value) {
        var color = String(value || '').trim();
        if (!color) {
            return '';
        }
        if (color.charAt(0) !== '#') {
            color = '#' + color;
        }
        if (/^#[0-9a-f]{3}$/i.test(color)) {
            color = '#' + color.charAt(1) + color.charAt(1) + color.charAt(2) + color.charAt(2) + color.charAt(3) + color.charAt(3);
        }
        return /^#[0-9a-f]{6}$/i.test(color) ? color.toUpperCase() : '';
    }

    function getContrastColor(value) {
        var color = normalizeHexColor(value);
        var r;
        var g;
        var b;
        var luminance;

        if (!color) {
            return '#FFFFFF';
        }

        r = parseInt(color.slice(1, 3), 16);
        g = parseInt(color.slice(3, 5), 16);
        b = parseInt(color.slice(5, 7), 16);
        luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;

        return luminance > 0.62 ? '#4B5563' : '#FFFFFF';
    }

    function hexToRgbObject(value) {
        var color = normalizeHexColor(value);
        if (!color) {
            return null;
        }
        return {
            r: parseInt(color.slice(1, 3), 16),
            g: parseInt(color.slice(3, 5), 16),
            b: parseInt(color.slice(5, 7), 16)
        };
    }

    function rgbToHex(rgb) {
        function toHex(channel) {
            return Math.max(0, Math.min(255, Math.round(channel))).toString(16).padStart(2, '0');
        }

        return ('#' + toHex(rgb.r) + toHex(rgb.g) + toHex(rgb.b)).toUpperCase();
    }

    function rgbToHsv(rgb) {
        var r = rgb.r / 255;
        var g = rgb.g / 255;
        var b = rgb.b / 255;
        var max = Math.max(r, g, b);
        var min = Math.min(r, g, b);
        var delta = max - min;
        var h = 0;

        if (delta !== 0) {
            if (max === r) {
                h = ((g - b) / delta) % 6;
            } else if (max === g) {
                h = (b - r) / delta + 2;
            } else {
                h = (r - g) / delta + 4;
            }
            h = Math.round(h * 60);
            if (h < 0) {
                h += 360;
            }
        }

        return {
            h: h,
            s: max === 0 ? 0 : (delta / max) * 100,
            v: max * 100
        };
    }

    function hsvToRgb(hsv) {
        var h = ((hsv.h % 360) + 360) % 360;
        var s = Math.max(0, Math.min(100, hsv.s)) / 100;
        var v = Math.max(0, Math.min(100, hsv.v)) / 100;
        var c = v * s;
        var x = c * (1 - Math.abs((h / 60) % 2 - 1));
        var m = v - c;
        var r = 0;
        var g = 0;
        var b = 0;

        if (h < 60) {
            r = c; g = x;
        } else if (h < 120) {
            r = x; g = c;
        } else if (h < 180) {
            g = c; b = x;
        } else if (h < 240) {
            g = x; b = c;
        } else if (h < 300) {
            r = x; b = c;
        } else {
            r = c; b = x;
        }

        return {
            r: (r + m) * 255,
            g: (g + m) * 255,
            b: (b + m) * 255
        };
    }

    function getThemeColorPalette() {
        return [
            '#EDA934', '#D97706', '#CA8A04', '#DC2626', '#E11D48', '#BE123C', '#9A3412', '#7C2D12',
            '#2563EB', '#0EA5E9', '#0891B2', '#0D9488', '#059669', '#16A34A', '#65A30D', '#4F46E5',
            '#7C3AED', '#A21CAF', '#DB2777', '#334155', '#64748B', '#94A3B8', '#F8FAFC'
        ];
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function getModernColorPickerI18n() {
        var i18n = (window.yooadminThemeSettings && window.yooadminThemeSettings.colorPicker) || {};

        return {
            chooseColor: i18n.chooseColor || 'Choose color',
            palette: i18n.palette || 'Palette',
            hex: i18n.hex || 'HEX',
            reset: i18n.reset || 'Reset',
            customColor: i18n.customColor || 'Custom color',
            customSaturationBrightness: i18n.customSaturationBrightness || 'Custom color saturation and brightness',
            colorHue: i18n.colorHue || 'Color hue',
            hexColor: i18n.hexColor || 'Hex color'
        };
    }

    function buildModernColorControl(current, title) {
        var cp = getModernColorPickerI18n();
        var palette = getThemeColorPalette().map(function (color) {
            return '<button type="button" class="yooadmin-theme-modern-color__swatch" data-color="' + color + '" style="--swatch:' + color + '" aria-label="' + color + '"></button>';
        }).join('');

        return $(
            '<div class="yooadmin-theme-modern-color">' +
                '<button type="button" class="yooadmin-theme-modern-color__trigger">' +
                    '<span class="yooadmin-theme-modern-color__preview" style="--current:' + current + '"></span>' +
                    '<span class="yooadmin-theme-modern-color__title" style="--title-color:' + getContrastColor(current) + '">' + escapeHtml(title) + '</span>' +
                '</button>' +
                '<div class="yooadmin-theme-modern-color__popover" hidden>' +
                    '<div class="yooadmin-theme-modern-color__popover-title">' + escapeHtml(cp.chooseColor) + '</div>' +
                    '<div class="yooadmin-theme-modern-color__label">' + escapeHtml(cp.palette) + '</div>' +
                    '<div class="yooadmin-theme-modern-color__palette">' +
                        palette +
                        '<button type="button" class="yooadmin-theme-modern-color__swatch yooadmin-theme-modern-color__custom-swatch" aria-label="' + escapeHtml(cp.customColor) + '"><span aria-hidden="true"></span></button>' +
                    '</div>' +
                    '<div class="yooadmin-theme-modern-color__custom-panel" hidden>' +
                        '<div class="yooadmin-theme-modern-color__spectrum" role="slider" tabindex="0" aria-label="' + escapeHtml(cp.customSaturationBrightness) + '">' +
                            '<span class="yooadmin-theme-modern-color__spectrum-handle" aria-hidden="true"></span>' +
                        '</div>' +
                        '<div class="yooadmin-theme-modern-color__hue-wrap">' +
                            '<input type="range" class="yooadmin-theme-modern-color__hue" min="0" max="360" step="1" value="0" aria-label="' + escapeHtml(cp.colorHue) + '">' +
                            '<span class="yooadmin-theme-modern-color__hue-handle" aria-hidden="true"></span>' +
                        '</div>' +
                    '</div>' +
                    '<div class="yooadmin-theme-modern-color__hex-wrap">' +
                        '<span>' + escapeHtml(cp.hex) + '</span>' +
                        '<input type="text" class="yooadmin-theme-modern-color__hex" value="' + current + '" aria-label="' + escapeHtml(cp.hexColor) + '" spellcheck="false">' +
                        '<button type="button" class="yooadmin-theme-modern-color__reset">' + escapeHtml(cp.reset) + '</button>' +
                    '</div>' +
                '</div>' +
            '</div>'
        );
    }

    $(function () {
        var $form = $('.yooadmin-theme-settings-form');
        if (!$form.length) {
            return;
        }

        var $wrap = $form.closest('.yooadmin-theme-settings-wrap');
        if (!$wrap.length) {
            $wrap = $form;
        }

        var appearanceApi = initAppearanceMode($form);

        if (typeof $.fn.wpColorPicker !== 'function') {
            return;
        }

        var $brandSection = $form.find('.yooadmin-theme-settings-section-brand-colors');
        var ajaxUrl = $form.data('ajax-url') || window.ajaxurl || '';
        var successMessage = $form.data('message-saved') || '';
        var errorMessage = $form.data('message-error') || '';
        var resetPreviewMessage = $form.data('message-reset-preview') || 'Preview reset to saved settings.';
        var resetDefaultsMessage = $form.data('message-reset-defaults') || 'Reset to default settings.';
        var brandDefaults = parseJsonAttr($form, 'data-brand-colors-defaults');
        var brandInitial = parseJsonAttr($form, 'data-brand-colors-initial');
        var wasBrandColorsLocked = isEffectiveDarkMode();

        if ($.isEmptyObject(brandInitial)) {
            brandInitial = {};
            $form.find('.yooadmin-brand-color-field').each(function () {
                var $input = $(this);
                var key = $input.data('color-key');
                if (key) {
                    brandInitial[key] = $input.data('initial-color') || $input.val() || $input.data('default-color') || '';
                }
            });
        }

        if ($.isEmptyObject(brandDefaults)) {
            brandDefaults = {};
            $form.find('.yooadmin-brand-color-field').each(function () {
                var $input = $(this);
                var key = $input.data('color-key');
                if (key) {
                    brandDefaults[key] = $input.data('default-color') || '';
                }
            });
        }

        var updatingPicker = false;
        var activePicker = null;
        var isSubmitting = false;
        var revertingBrandColors = false;
        var hasWpColorPicker = typeof $.fn.wpColorPicker === 'function';

        function collectBrandColors() {
            var map = {};
            $form.find('.yooadmin-brand-color-field').each(function () {
                var $input = $(this);
                var key = $input.data('color-key');
                if (key) {
                    map[key] = $input.val() || $input.data('default-color') || '';
                }
            });
            return map;
        }

        function hexToRgbTriplet(hex) {
            var rgb = hexToRgbObject(hex);
            if (!rgb) {
                return '237,169,52';
            }
            return rgb.r + ',' + rgb.g + ',' + rgb.b;
        }

        /** Match PHP yooadmin_get_brand_primary_600_hex() (~12% darker). */
        function darkenPrimaryForHover(hex) {
            var rgb = hexToRgbObject(normalizeHexColor(hex));
            if (!rgb) {
                return '#d8942a';
            }
            return rgbToHex({
                r: Math.max(0, rgb.r - 30),
                g: Math.max(0, rgb.g - 30),
                b: Math.max(0, rgb.b - 30)
            });
        }

        /** Match CSS color-mix(in srgb, brand 88%, #fff 12%). */
        function lightenForButtonTop(hex) {
            var rgb = hexToRgbObject(normalizeHexColor(hex));
            if (!rgb) {
                return hex;
            }
            return rgbToHex({
                r: Math.round(rgb.r * 0.88 + 255 * 0.12),
                g: Math.round(rgb.g * 0.88 + 255 * 0.12),
                b: Math.round(rgb.b * 0.88 + 255 * 0.12)
            });
        }

        var liveBrandTokens = {
            primary: '#eda934',
            primary600: '#d8942a',
            primaryTop: '#eda934',
            primaryHoverTop: '#d8942a'
        };

        function updateLiveBrandTokens(primary, primary600, primaryTop, primaryHoverTop) {
            liveBrandTokens.primary = primary;
            liveBrandTokens.primary600 = primary600;
            liveBrandTokens.primaryTop = primaryTop;
            liveBrandTokens.primaryHoverTop = primaryHoverTop;
        }

        function primaryHoverGradient() {
            return (
                'linear-gradient(180deg,' +
                liveBrandTokens.primaryHoverTop +
                ' 0%,' +
                liveBrandTokens.primary600 +
                ' 100%)'
            );
        }

        function paintPrimaryButtonHover(btn) {
            if (!btn) {
                return;
            }
            btn.style.setProperty('background', primaryHoverGradient(), 'important');
            btn.style.setProperty('background-color', liveBrandTokens.primary600, 'important');
            btn.style.setProperty('border-color', 'transparent', 'important');
            btn.style.setProperty('color', '#fff', 'important');
        }

        function clearPrimaryButtonHover(btn) {
            if (!btn) {
                return;
            }
            btn.style.removeProperty('background');
            btn.style.removeProperty('background-color');
            btn.style.removeProperty('border-color');
            btn.style.removeProperty('color');
        }

        /** Browsers often keep stale :hover paint until the pointer re-enters — refresh under cursor. */
        function refreshLiveHoverTargets() {
            var el = document.querySelector(':hover');
            if (!el) {
                return;
            }

            var btn = el.closest('.yp-yoo-btn--primary, .button.button-primary.yp-yoo-btn--primary');
            if (btn) {
                paintPrimaryButtonHover(btn);
            }

            var focusLabel = el.closest('.yps-focus-label');
            if (focusLabel) {
                var focusInput = focusLabel.querySelector('.yps-focus-input');
                var focusSwitch = focusLabel.querySelector('.yps-focus-switch');
                if (focusInput && focusSwitch && focusInput.checked) {
                    focusSwitch.style.setProperty('background', liveBrandTokens.primary600, 'important');
                }
            }

            var abItem = el.closest('#wp-admin-bar-yooadmin-focus-toggle > .ab-item');
            if (abItem) {
                abItem.style.setProperty('background', liveBrandTokens.primary600, 'important');
                abItem.style.setProperty('border-color', liveBrandTokens.primary600, 'important');
                abItem.style.setProperty('color', '#fff', 'important');
            }
        }

        function applyBrandTokensToNode(node, primary, primary600, primaryTop, primaryHoverTop) {
            if (!node || !node.style) {
                return;
            }
            var map = {
                '--yooadmin-brand-source': primary,
                '--yooadmin-primary': primary,
                '--yooadmin-primary-600': primary600,
                '--yooadmin-primary-hover': primary600,
                '--yp-primary': primary,
                '--yp-primary-600': primary600,
                '--yp-yoo-btn-primary': primary,
                '--yp-yoo-btn-primary-top': primaryTop,
                '--yp-yoo-btn-primary-hover': primary600,
                '--yp-yoo-btn-primary-hover-top': primaryHoverTop,
                '--ysh-brand': primary
            };

            Object.keys(map).forEach(function (key) {
                node.style.setProperty(key, map[key]);
            });
        }

        /**
         * Literal hex rules from brand-hover-fix.php — must update on live preview / reset.
         */
        function syncBrandHoverFixStyles(primary, hover, hoverTop) {
            var styleId = 'yooadmin-brand-hover-fix';
            var el = document.getElementById(styleId);
            var top = hoverTop || hover;
            var gradient = 'linear-gradient(180deg,' + top + ' 0%,' + hover + ' 100%)';
            var hoverButtonSelectors = [
                '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .button.yp-yoo-btn--primary:hover',
                '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .button.yp-yoo-btn--primary:focus-visible',
                '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .yp-yoo-btn--primary:hover',
                '#yooadmin-login-turnstile-info-modal .yooadmin-login-turnstile-info-modal__actions .yp-yoo-btn--primary:focus-visible',
                '.yooadmin-theme-settings-wrap .yooadmin-theme-settings-actions .yp-yoo-btn--primary:hover',
                '.yooadmin-theme-settings-wrap .yooadmin-theme-settings-actions .button.button-primary.yp-yoo-btn--primary:hover',
                '.yooadmin-theme-settings-wrap .yooadmin-theme-settings-actions .yooadmin-save-settings.yp-yoo-btn--primary:hover',
                'body.yoo-focus.wp-admin .yp-yoo-btn--primary:hover',
                'body.yoo-focus.wp-admin .button.button-primary.yp-yoo-btn--primary:hover'
            ].join(',');
            var css =
                hoverButtonSelectors +
                '{background:' +
                gradient +
                '!important;background-color:' +
                hover +
                '!important;border:0!important;color:#fff!important;}' +
                '#yps-sidebar .yps-focus-input:checked~.yps-focus-switch{background:' +
                primary +
                '!important;}' +
                '#yps-sidebar .yps-focus-label:hover .yps-focus-input:checked~.yps-focus-switch{background:' +
                hover +
                '!important;}' +
                '#wpadminbar #wp-admin-bar-yooadmin-focus-toggle>.ab-item:hover,#wpadminbar #wp-admin-bar-yooadmin-focus-toggle.hover>.ab-item{background:' +
                hover +
                '!important;border-color:' +
                hover +
                '!important;color:#fff!important;}';

            if (!el) {
                el = document.createElement('style');
                el.id = styleId;
                document.head.appendChild(el);
            }
            el.textContent = css;
        }

        function syncStudioHubBrandVarsStyle(primary, primary600, headerBg, sidebarBg) {
            var el = document.getElementById('yooadmin-studio-hub-brand-vars');
            if (!el) {
                return;
            }
            var primaryRgb = hexToRgbTriplet(primary);
            el.textContent =
                ':root,:root.yooadmin-studio-hub-html{--ysh-brand:' +
                primary +
                ';--ysh-brand-rgb:' +
                primaryRgb +
                ';--yp-primary-rgb:' +
                primaryRgb +
                ';--yooadmin-brand-source:' +
                primary +
                ';--yooadmin-primary:' +
                primary +
                ';--yooadmin-primary-600:' +
                primary600 +
                ';--yooadmin-primary-hover:' +
                primary600 +
                ';--yp-primary:' +
                primary +
                ';--yp-primary-600:' +
                primary600 +
                ';--yooadmin-header-bg-source:' +
                headerBg +
                ';--yooadmin-sidebar-bg-source:' +
                sidebarBg +
                ';}';
        }

        /**
         * Light shell: mirror print_studio_hub_shell_color_bridge on body so breadcrumbs update live.
         */
        function syncShellBrandTokens(colorMap) {
            var body = document.body;
            if (!body || !body.classList.contains('yooadmin-theme-yooadmin-studio-hub')) {
                return;
            }

            if (isEffectiveDarkMode()) {
                body.style.removeProperty('--ysh-breadcrumbs-bg');
                body.style.removeProperty('--ysh-breadcrumb-fg');
                body.style.removeProperty('--ysh-heading');
                body.style.removeProperty('--ysh-muted');
                return;
            }

            var bcBg = colorMap.breadcrumbs_bg || '#FFFFFF';
            var bcFg = colorMap.breadcrumbs_fg || colorMap.text_600 || '#5d5d5d';
            var text600 = colorMap.text_600 || '#5d5d5d';
            var text500 = colorMap.text_500 || '#555555';

            body.style.setProperty('--ysh-breadcrumbs-bg', bcBg);
            body.style.setProperty('--ysh-breadcrumb-fg', bcFg);
            body.style.setProperty('--ysh-heading', text600);
            body.style.setProperty('--ysh-muted', text500);
        }

        /**
         * Toolbar masks / legacy inline fills can stick after reset — clear so CSS vars apply.
         */
        function refreshBreadcrumbsIconColors() {
            var bar = document.querySelector('.yp-breadcrumbs-bar');
            if (!bar) {
                return;
            }

            var nodes = bar.querySelectorAll(
                '.yp-toolbar-icon, .yp-toolbar-icon .dashicons, .yp-toolbar-icon .ab-icon, ' +
                    '.yp-toolbar-item .yp-toolbar-trigger, .yp-command-palette-trigger, ' +
                    '.yp-command-palette-trigger__icon, .yp-command-palette-trigger .dashicons, ' +
                    '.yp-bc-home-icon, .yp-bc-link .dashicons, .ysh-appearance__dash, .ysh-appearance__svg'
            );
            var i;
            for (i = 0; i < nodes.length; i++) {
                nodes[i].style.removeProperty('color');
                nodes[i].style.removeProperty('-webkit-text-fill-color');
            }
        }

        /**
         * Keep icon/accent aliases in sync with brand color preview (Studio Hub + dashboard tokens).
         */
        function syncBrandDerivedTokens(colorMap) {
            if (!colorMap || $.isEmptyObject(colorMap)) {
                return;
            }

            var primary = normalizeHexColor(colorMap.primary || '#eda934');
            var primary600 = darkenPrimaryForHover(primary);
            var primaryTop = lightenForButtonTop(primary);
            var primaryHoverTop = lightenForButtonTop(primary600);
            var cardIcon = colorMap.card_icon || primary;
            var headerBg = colorMap.header_bg || '#4B4B4B';
            var sidebarBg = colorMap.sidebar_bg || '#4B4B4B';
            var primaryRgb = hexToRgbTriplet(primary);
            var darkPinnedVars = [
                '--yooadmin-primary',
                '--yooadmin-primary-600',
                '--yooadmin-primary-hover',
                '--ysh-brand',
                '--yp-primary',
                '--yp-primary-600',
                '--yp-yoo-btn-primary',
                '--yp-yoo-btn-primary-hover'
            ];
            var i;

            applyCssVar('--yooadmin-brand-source', primary, '#eda934');
            applyCssVar('--yooadmin-header-bg-source', headerBg, '#4B4B4B');
            applyCssVar('--yooadmin-sidebar-bg-source', sidebarBg, '#4B4B4B');
            applyCssVar('--yooadmin-primary', primary, '#eda934');
            applyCssVar('--yooadmin-primary-600', primary600, '#d8942a');
            applyCssVar('--yooadmin-primary-hover', primary600, '#d8942a');
            applyCssVar('--yp-primary', primary, '#eda934');
            applyCssVar('--yp-primary-600', primary600, '#d8942a');
            applyCssVar('--yp-yoo-btn-primary', primary, '#eda934');
            applyCssVar('--yp-yoo-btn-primary-top', primaryTop, primary);
            applyCssVar('--yp-yoo-btn-primary-hover', primary600, '#d8942a');
            applyCssVar('--yp-yoo-btn-primary-hover-top', primaryHoverTop, primary600);
            applyCssVar('--ysh-brand-rgb', primaryRgb, '237,169,52');
            applyCssVar('--yp-primary-rgb', primaryRgb, '237,169,52');
            applyCssVar('--yooadmin-card-icon', cardIcon, primary);
            applyCssVar('--yp-card-icon-color', cardIcon, primary);

            if (isEffectiveDarkMode()) {
                for (i = 0; i < darkPinnedVars.length; i++) {
                    documentElement.style.removeProperty(darkPinnedVars[i]);
                }
            } else {
                applyCssVar('--ysh-brand', primary, '#eda934');
            }

            updateLiveBrandTokens(primary, primary600, primaryTop, primaryHoverTop);
            applyBrandTokensToNode(documentElement, primary, primary600, primaryTop, primaryHoverTop);

            if ($wrap.length && $wrap[0]) {
                applyBrandTokensToNode($wrap[0], primary, primary600, primaryTop, primaryHoverTop);
            }

            var sidebar = document.getElementById('yps-sidebar');
            if (sidebar) {
                applyBrandTokensToNode(sidebar, primary, primary600, primaryTop, primaryHoverTop);
            }

            syncStudioHubBrandVarsStyle(primary, primary600, headerBg, sidebarBg);
            syncBrandHoverFixStyles(primary, primary600, primaryHoverTop);
            syncShellBrandTokens(colorMap);
            refreshBreadcrumbsIconColors();
            refreshLiveHoverTargets();

            try {
                document.dispatchEvent(
                    new CustomEvent('yooadmin-brand-colors-changed', { detail: { colors: colorMap } })
                );
            } catch (error) {
                // IE11 — ignore
            }
        }

        function setFieldColor($input, color, useDefaultFallback) {
            var cssVar = $input.data('css-var');
            var defaultColor = $input.data('default-color') || '';
            var target = color;

            if (!target && useDefaultFallback) {
                target = defaultColor;
            }

            updatingPicker = true;
            if (target) {
                if (hasWpColorPicker && typeof $input.wpColorPicker === 'function' && $input.closest('.wp-picker-container').length) {
                    $input.wpColorPicker('color', target);
                }
                $input.val(target);
                syncModernColorControl($input);
                applyCssVar(cssVar, target, defaultColor);
            } else {
                if (hasWpColorPicker && typeof $input.wpColorPicker === 'function' && $input.closest('.wp-picker-container').length) {
                    $input.wpColorPicker('color', defaultColor);
                }
                $input.val(defaultColor);
                syncModernColorControl($input);
                applyCssVar(cssVar, defaultColor, defaultColor);
            }
            updatingPicker = false;
            syncBrandDerivedTokens(collectBrandColors());
        }

        function syncCustomPickerFromInput($control) {
            var color = normalizeHexColor($control.prev('.yooadmin-brand-color-field').val() || '#eda934');
            var rgb = hexToRgbObject(color);
            var hsv = rgb ? rgbToHsv(rgb) : { h: 0, s: 100, v: 100 };

            $control.data('themeColorHue', hsv.h);
            $control.data('themeColorSat', hsv.s);
            $control.data('themeColorVal', hsv.v);
            updateCustomPickerUi($control);
        }

        function updateCustomPickerUi($control) {
            var rawHue = parseFloat($control.data('themeColorHue'));
            var rawSat = parseFloat($control.data('themeColorSat'));
            var rawVal = parseFloat($control.data('themeColorVal'));
            var hue = Number.isFinite(rawHue) ? rawHue : 0;
            var sat = Math.max(0, Math.min(100, Number.isFinite(rawSat) ? rawSat : 0));
            var val = Math.max(0, Math.min(100, Number.isFinite(rawVal) ? rawVal : 0));
            var hueColor = rgbToHex(hsvToRgb({ h: hue, s: 100, v: 100 }));
            var handleTop = (100 - val) + '%';
            var handleLeft = sat + '%';
            var hueLeft = (hue / 360) * 100 + '%';

            $control.find('.yooadmin-theme-modern-color__custom-panel').css({
                '--picker-hue': hueColor,
                '--picker-x': handleLeft,
                '--picker-y': handleTop,
                '--hue-x': hueLeft
            });
            $control.find('.yooadmin-theme-modern-color__spectrum-handle').each(function () {
                this.style.setProperty('left', handleLeft, 'important');
                this.style.setProperty('top', handleTop, 'important');
            });
            $control.find('.yooadmin-theme-modern-color__hue-handle').each(function () {
                this.style.setProperty('left', hueLeft, 'important');
            });
            $control.find('.yooadmin-theme-modern-color__hue').val(hue);
        }

        function syncModernColorControl($input) {
            var color = normalizeHexColor($input.val() || $input.data('default-color') || '#eda934');
            var $control = $input.next('.yooadmin-theme-modern-color');

            if (!$control.length) {
                return;
            }

            $control.find('.yooadmin-theme-modern-color__preview').css('--current', color);
            $control.find('.yooadmin-theme-modern-color__title').css('--title-color', getContrastColor(color));
            $control.find('.yooadmin-theme-modern-color__hex').val(color);
            syncCustomPickerFromInput($control);
        }

        function applyModernColorValue($control, value, options) {
            var color = normalizeHexColor(value);
            var $input = $control.prev('.yooadmin-brand-color-field');
            var allowLocked = options && options.allowLocked;

            if (!color || !$input.length || (isEffectiveDarkMode() && !allowLocked)) {
                revertBrandColorInputs();
                return;
            }

            setFieldColor($input, color, true);
        }

        function applyCustomSpectrumPointer($spectrum, event) {
            var rect = $spectrum[0].getBoundingClientRect();
            var x = Math.max(0, Math.min(rect.width, event.clientX - rect.left));
            var y = Math.max(0, Math.min(rect.height, event.clientY - rect.top));
            var $control = $spectrum.closest('.yooadmin-theme-modern-color');

            $control.data('themeColorSat', (x / rect.width) * 100);
            $control.data('themeColorVal', 100 - ((y / rect.height) * 100));
            applyCustomPickerColor($control);
        }

        function applyCustomPickerColor($control) {
            var rawHue = parseFloat($control.data('themeColorHue'));
            var rawSat = parseFloat($control.data('themeColorSat'));
            var rawVal = parseFloat($control.data('themeColorVal'));
            var hsv = {
                h: Number.isFinite(rawHue) ? rawHue : 0,
                s: Number.isFinite(rawSat) ? rawSat : 100,
                v: Number.isFinite(rawVal) ? rawVal : 100
            };
            var color = rgbToHex(hsvToRgb(hsv));

            updateCustomPickerUi($control);
            applyModernColorValue($control, color);
        }

        function positionModernColorPopover($control) {
            var $popover = $control.find('.yooadmin-theme-modern-color__popover');
            var controlRect;
            var popoverRect;
            var gap = 8;
            var viewportPadding = 12;
            var top;
            var left;

            $control.removeClass('opens-up aligns-right');
            $popover.css({ top: '', left: '', right: '', bottom: '' });

            controlRect = $control[0].getBoundingClientRect();
            popoverRect = $popover[0].getBoundingClientRect();
            top = controlRect.bottom + gap;
            left = controlRect.left;

            if (top + popoverRect.height > window.innerHeight - viewportPadding) {
                var upwardTop = controlRect.top - popoverRect.height - gap;
                if (upwardTop >= viewportPadding) {
                    top = upwardTop;
                    $control.addClass('opens-up');
                }
            }

            if (left + popoverRect.width > window.innerWidth - viewportPadding) {
                left = window.innerWidth - popoverRect.width - viewportPadding;
                $control.addClass('aligns-right');
            }

            left = Math.max(viewportPadding, left);
            top = Math.max(viewportPadding, top);

            $popover.css({
                top: top + 'px',
                left: left + 'px',
                '--arrow-x': Math.max(18, Math.min(popoverRect.width - 18, controlRect.left + (controlRect.width / 2) - left)) + 'px'
            });
        }

        function revertBrandColorInputs() {
            if (revertingBrandColors || !$brandSection.length) {
                return;
            }

            revertingBrandColors = true;
            closeOtherPickers();

            $form.find('.yooadmin-brand-color-field').each(function () {
                var $input = $(this);
                var key = $input.data('color-key');
                var fallback = $input.data('default-color') || '';
                var val = (key && brandInitial[key]) ? brandInitial[key] : fallback;

                if (!val || $input.val() === val) {
                    return;
                }

                setFieldColor($input, val, true);
            });

            revertingBrandColors = false;
        }

        function syncBrandColorsLock() {
            if (!$brandSection.length) {
                return;
            }

            var locked = isEffectiveDarkMode();
            $brandSection.toggleClass('is-colors-locked', locked);

            var $notice = $brandSection.find('.yooadmin-brand-colors-notice');
            if (locked) {
                if (!$notice.length) {
                    $notice = $(
                        '<div class="yooadmin-brand-colors-notice" role="status">' +
                            '<span class="yooadmin-brand-colors-notice__icon dashicons dashicons-lightbulb" aria-hidden="true"></span>' +
                            '<div class="yooadmin-brand-colors-notice__copy">' +
                                '<p class="yooadmin-brand-colors-notice__title"></p>' +
                                '<p class="yooadmin-brand-colors-notice__text"></p>' +
                            '</div>' +
                            '<button type="button" class="yooadmin-brand-colors-notice__btn"></button>' +
                        '</div>'
                    );
                    $brandSection.prepend($notice);

                    $notice.find('.yooadmin-brand-colors-notice__btn').on('click', function (event) {
                        event.preventDefault();
                        switchToLightMode();
                    });
                }

                $notice.find('.yooadmin-brand-colors-notice__title').text(
                    $brandSection.data('colors-light-title') || 'Switch to Light mode to edit colors'
                );
                $notice.find('.yooadmin-brand-colors-notice__text').text(
                    $brandSection.data('colors-light-text') || 'Brand colors can only be changed in Light mode for an accurate preview.'
                );
                $notice.find('.yooadmin-brand-colors-notice__btn').text(
                    $brandSection.data('switch-to-light') || 'Switch to Light'
                );
            } else {
                $notice.remove();
            }

            $form.find('.yooadmin-brand-color-field').prop('disabled', locked);
            $brandSection.find('.wp-picker-container').toggleClass('is-disabled', locked);
            $brandSection.find('.yooadmin-theme-modern-color').toggleClass('is-locked', locked);
            $brandSection.find('.yooadmin-theme-modern-color__swatch, .yooadmin-theme-modern-color__hex, .yooadmin-theme-modern-color__hue').prop('disabled', locked);
            $brandSection.find('.yooadmin-theme-modern-color__trigger, .yooadmin-theme-modern-color__reset').prop('disabled', false);

            if (locked && !wasBrandColorsLocked) {
                revertBrandColorInputs();
            }

            syncBrandDerivedTokens(collectBrandColors());
            wasBrandColorsLocked = locked;
        }

        $form.find('.yooadmin-color-field').each(function () {
            var $input = $(this);
            var args = {};

            if ($input.hasClass('yooadmin-brand-color-field')) {
                var cssVar = $input.data('css-var');
                var defaultColor = $input.data('default-color') || '';
                var initialColor = $input.data('initial-color') || $input.val() || defaultColor;
                var current = normalizeHexColor($input.val() || defaultColor || '#eda934');
                var title = $input.closest('.yooadmin-theme-settings-option').find('.yooadmin-theme-settings-option__label').first().text() || '';
                var control = buildModernColorControl(current, title);

                $input
                    .addClass('yooadmin-theme-modern-color-source')
                    .attr('type', 'hidden')
                    .after(control);
                syncModernColorControl($input);
                setTimeout(function () {
                    applyCssVar(cssVar, initialColor, defaultColor);
                }, 0);
                return;
            }

            if (!hasWpColorPicker) {
                return;
            }

            $input.wpColorPicker(args);
        });

        $form.on('click', '.yooadmin-theme-modern-color__trigger', function (event) {
            var $control = $(this).closest('.yooadmin-theme-modern-color');
            var willOpen = !$control.hasClass('is-open');

            event.preventDefault();
            closeModernColorPickers($control);
            $control.toggleClass('is-open', willOpen);
            if (willOpen) {
                $control.find('.yooadmin-theme-modern-color__popover').removeAttr('hidden');
                positionModernColorPopover($control);
            } else {
                $control.find('.yooadmin-theme-modern-color__popover').attr('hidden', 'hidden');
                $control.find('.yooadmin-theme-modern-color__custom-panel').attr('hidden', 'hidden');
            }
        });

        $form.on('click', '.yooadmin-theme-modern-color__swatch', function (event) {
            var color = $(this).data('color');

            if (!color) {
                return;
            }

            event.preventDefault();
            applyModernColorValue($(this).closest('.yooadmin-theme-modern-color'), color);
        });

        $form.on('click', '.yooadmin-theme-modern-color__custom-swatch', function (event) {
            var $control = $(this).closest('.yooadmin-theme-modern-color');
            var $panel = $control.find('.yooadmin-theme-modern-color__custom-panel');
            var willOpen = $panel.is('[hidden]');

            event.preventDefault();
            $('.yooadmin-theme-modern-color__custom-panel').not($panel).attr('hidden', 'hidden');
            if (willOpen) {
                syncCustomPickerFromInput($control);
                $panel.removeAttr('hidden');
            } else {
                $panel.attr('hidden', 'hidden');
            }
        });

        $form.on('click', '.yooadmin-theme-modern-color__reset', function (event) {
            var $control = $(this).closest('.yooadmin-theme-modern-color');
            var $input = $control.prev('.yooadmin-brand-color-field');
            var key = $input.data('color-key');
            var fallback = (key && brandDefaults[key]) || $input.data('default-color') || '#eda934';

            event.preventDefault();
            if (!$input.length) {
                return;
            }
            setFieldColor($input, fallback, true);
        });

        $form.on('change', '.yooadmin-theme-modern-color__hex', function () {
            applyModernColorValue($(this).closest('.yooadmin-theme-modern-color'), $(this).val());
        });

        $form.on('pointerdown', '.yooadmin-theme-modern-color__spectrum', function (event) {
            var spectrum = this;
            var $spectrum = $(spectrum);
            var originalEvent = event.originalEvent || event;

            function applyMove(moveEvent) {
                applyCustomSpectrumPointer($spectrum, moveEvent);
            }

            event.preventDefault();
            if (spectrum.setPointerCapture && originalEvent.pointerId !== undefined) {
                spectrum.setPointerCapture(originalEvent.pointerId);
            }

            applyMove(originalEvent);
            $(document).on('pointermove.yooadminThemeSpectrumDrag', function (moveEvent) {
                applyMove(moveEvent.originalEvent || moveEvent);
            });
            $(document).one('pointerup.yooadminThemeSpectrumDrag pointercancel.yooadminThemeSpectrumDrag', function () {
                $(document).off('pointermove.yooadminThemeSpectrumDrag');
            });
        });

        $form.on('input change', '.yooadmin-theme-modern-color__hue', function () {
            var $control = $(this).closest('.yooadmin-theme-modern-color');
            var hue = Math.max(0, Math.min(360, parseFloat($(this).val()) || 0));

            $control.data('themeColorHue', hue);
            applyCustomPickerColor($control);
        });

        $(window).on('resize.yooadminThemeModernColor scroll.yooadminThemeModernColor', function () {
            var $open = $('.yooadmin-theme-modern-color.is-open').first();
            if ($open.length) {
                positionModernColorPopover($open);
            }
        });

        syncBrandDerivedTokens(brandInitial);

        $(document).on(
            'mouseenter.yooadminBrandHover',
            '.yp-yoo-btn--primary, .button.button-primary.yp-yoo-btn--primary',
            function () {
                paintPrimaryButtonHover(this);
            }
        );

        $(document).on(
            'mouseleave.yooadminBrandHover',
            '.yp-yoo-btn--primary, .button.button-primary.yp-yoo-btn--primary',
            function () {
                clearPrimaryButtonHover(this);
            }
        );

        $(document).on('mouseenter.yooadminBrandHover', '.yps-focus-label', function () {
            var input = this.querySelector('.yps-focus-input');
            var switchEl = this.querySelector('.yps-focus-switch');
            if (input && switchEl && input.checked) {
                switchEl.style.setProperty('background', liveBrandTokens.primary600, 'important');
            }
        });

        $(document).on('mouseleave.yooadminBrandHover', '.yps-focus-label', function () {
            var switchEl = this.querySelector('.yps-focus-switch');
            if (switchEl) {
                switchEl.style.removeProperty('background');
            }
        });

        window.yooadminSyncBrandHover = function (colorMap) {
            syncBrandDerivedTokens(colorMap || collectBrandColors());
        };

        $(document).on('mousedown.yooadminColorPicker', function (event) {
            var isModernPickerClick = $(event.target).closest('.yooadmin-theme-modern-color').length > 0;
            var isWpPickerClick = $(event.target).closest('.wp-picker-container').length > 0;

            if (!isModernPickerClick) {
                closeModernColorPickers();
            }
            if (activePicker && !isWpPickerClick) {
                activePicker.wpColorPicker('close');
                activePicker = null;
            }
            if (!isWpPickerClick && !isModernPickerClick) {
                closeOtherPickers();
            }
        });

        function applyColorsMap(map, forceApply) {
            if ($.isEmptyObject(map)) {
                return;
            }
            if (!forceApply && isEffectiveDarkMode()) {
                return;
            }
            closeOtherPickers();
            $form.find('.yooadmin-brand-color-field').each(function () {
                var $input = $(this);
                var key = $input.data('color-key');
                var defaultColor = $input.data('default-color') || '';
                var nextColor = key && map[key] ? map[key] : defaultColor;
                setFieldColor($input, nextColor, true);
            });
            syncBrandDerivedTokens(map);
        }

        function updateInitialState(map) {
            brandInitial = $.extend({}, map);
            try {
                $form.attr('data-brand-colors-initial', JSON.stringify(brandInitial));
            } catch (error) {
                // no-op if JSON serialization fails
            }
        }

        function showFeedback(type, message) {
            if (!message) {
                return;
            }
            if (window.yooadmToast) {
                window.yooadmToast.show(message, type);
                return;
            }

            var $feedback = $('.yooadmin-theme-settings-feedback');
            if (!$feedback.length) {
                return;
            }

            var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
            $feedback.html(
                '<div class="notice ' + noticeClass + ' is-dismissible"><p></p></div>'
            );
            $feedback.find('p').text(message);
            if ($feedback[0] && typeof $feedback[0].scrollIntoView === 'function') {
                $feedback[0].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        }

        $wrap.on('click', '.yooadmin-reset-preview', function (event) {
            event.preventDefault();
            if (appearanceApi) {
                appearanceApi.apply(appearanceApi.getInitial());
            }
            applyColorsMap(brandInitial, true);
            syncBrandDerivedTokens(brandInitial);
            showFeedback('success', resetPreviewMessage);
        });

        $wrap.on('click', '.yooadmin-reset-defaults', function (event) {
            event.preventDefault();
            if (appearanceApi) {
                appearanceApi.apply(appearanceApi.getDefault());
            }
            applyColorsMap(brandDefaults, true);
            syncBrandDerivedTokens(brandDefaults);
            showFeedback('success', resetDefaultsMessage);
        });

        $form.on('submit', function (event) {
            event.preventDefault();

            var $brandFields = $form.find('.yooadmin-brand-color-field');
            var brandFieldsWereDisabled = isEffectiveDarkMode();

            if (brandFieldsWereDisabled) {
                $brandFields.prop('disabled', false);
            }

            $brandFields.each(function () {
                var $input = $(this);
                if (!$input.val()) {
                    $input.val($input.data('default-color') || '');
                }
            });

            if (!ajaxUrl || isSubmitting) {
                if (brandFieldsWereDisabled) {
                    $brandFields.prop('disabled', true);
                }
                return;
            }

            if (appearanceApi && typeof appearanceApi.syncFromShell === 'function') {
                appearanceApi.syncFromShell();
            } else {
                var shellMode = readShellAppearanceMode();
                var $appearanceInput = $form.find('.yooadmin-theme-appearance-input');
                if (shellMode && $appearanceInput.length) {
                    $appearanceInput.val(shellMode);
                }
            }

            isSubmitting = true;

            var $submit = $wrap.find('.yooadmin-save-settings');
            var serialized = $form.serialize();

            if (brandFieldsWereDisabled) {
                $brandFields.prop('disabled', true);
            }

            $submit.prop('disabled', true).addClass('is-busy');

            $.ajax({
                url: ajaxUrl,
                method: 'POST',
                data: serialized,
                dataType: 'json'
            }).done(function (response) {
                if (response && response.success) {
                    var data = response.data || {};
                    var message = data.message || successMessage || '';
                    showFeedback('success', message);

                    if (data.brand_colors) {
                        applyColorsMap(data.brand_colors, true);
                        updateInitialState(data.brand_colors);
                    } else {
                        updateInitialState(collectBrandColors());
                    }

                    if (data.settings && data.settings.color_mode) {
                        var savedMode = data.settings.color_mode;
                        var shellMode = readShellAppearanceMode();
                        var modeToApply = shellMode || savedMode;
                        if (appearanceApi) {
                            appearanceApi.apply(modeToApply);
                            appearanceApi.setInitial(savedMode);
                        } else {
                            var $appearanceInput = $form.find('.yooadmin-theme-appearance-input');
                            if ($appearanceInput.length) {
                                $appearanceInput.val(savedMode);
                                $form.find('.yooadmin-theme-appearance-pill').each(function () {
                                    var $pill = $(this);
                                    var isActive = $pill.data('yooadminThemeAppearance') === savedMode;
                                    $pill.toggleClass('is-active', isActive);
                                    $pill.attr('aria-pressed', isActive ? 'true' : 'false');
                                });
                            }
                            applyStudioColorModePreview(modeToApply);
                            syncHeaderAppearanceUI(modeToApply);
                        }
                    }
                } else {
                    var errMessage = errorMessage;
                    if (response && response.data && response.data.message) {
                        errMessage = response.data.message;
                    }
                    showFeedback('error', errMessage);
                }
            }).fail(function (jqXHR) {
                var errMessage = errorMessage || 'Unable to save theme settings.';
                if (jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.data && jqXHR.responseJSON.data.message) {
                    errMessage = jqXHR.responseJSON.data.message;
                }
                showFeedback('error', errMessage);
            }).always(function () {
                isSubmitting = false;
                $submit.prop('disabled', false).removeClass('is-busy');
            });
        });

        syncBrandColorsLock();
        document.addEventListener('ysh-studio-color-mode-changed', function () {
            if (appearanceApi && typeof appearanceApi.syncFromShell === 'function') {
                appearanceApi.syncFromShell();
            }
            syncBrandColorsLock();
        });

        if (window.MutationObserver) {
            var modeObserver = new MutationObserver(function (mutations) {
                for (var i = 0; i < mutations.length; i++) {
                    if (mutations[i].attributeName === 'data-yooadmin-studio-color-mode-effective') {
                        syncBrandColorsLock();
                        break;
                    }
                }
            });
            modeObserver.observe(documentElement, {
                attributes: true,
                attributeFilter: ['data-yooadmin-studio-color-mode-effective']
            });
        }
    });
})(jQuery);
