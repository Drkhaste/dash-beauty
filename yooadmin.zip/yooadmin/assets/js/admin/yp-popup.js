/**
 * YOOAdmin - Popup behavior (submenu, badges)
 *
 * @package YOOAdmin
 */
(function () {
  'use strict';
  
  if (window.__YPPopupInit) {
    return;
  }
  window.__YPPopupInit = true;

  /* ============================== Utils ============================== */
  function byId(id) { return document.getElementById(id); }
  
  /**
   * Debounce utility - limits function calls for performance
   * @param {Function} func - Function to debounce
   * @param {Number} wait - Wait time in ms
   * @return {Function} Debounced function
   */
  function debounce(func, wait) {
    var timeout;
    return function executedFunction() {
      var context = this;
      var args = arguments;
      var later = function() {
        timeout = null;
        func.apply(context, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
  
  /**
   * RequestAnimationFrame wrapper for smooth animations
   * @param {Function} callback - Animation callback
   */
  function raf(callback) {
    if (window.requestAnimationFrame) {
      window.requestAnimationFrame(callback);
    } else {
      setTimeout(callback, 16); // ~60fps fallback
    }
  }

  function escapeHtml(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/[&<>"'`=\/]/g, function (s) {
      return ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;',
        "'": '&#39;', '/': '&#x2F;', '`': '&#x60;', '=': '&#x3D;'
      })[s];
    });
  }

  function normalizeTitle(s) {
    if (!s) return '';
    // Replace non-breaking spaces and collapse whitespace
    return String(s).replace(/\u00A0|&nbsp;|&#160;/gi, ' ').replace(/\s+/g, ' ').trim();
  }

  function slugKey(s) {
    if (typeof s !== 'string') return 'menu';
    var k = s.toLowerCase().replace(/[^a-z0-9_.-]/gi, '_');
    return k || 'menu';
  }

  /** Align with yp-menus.js: skip broken / placeholder admin.php?page=… targets */
  function isExcludedSubmenuHrefForPopup(href) {
    if (!href || href === '#') return true;
    if (/^javascript:/i.test(href)) return true;
    var pages = (window.yooadmRuntime || {}).excludedSubmenuPages;
    if (!Array.isArray(pages) || !pages.length) return false;
    try {
      var u = new URL(href, window.location.origin);
      var p = u.searchParams.get('page');
      if (!p) return false;
      var pl = p.toLowerCase();
      var i = 0;
      for (i = 0; i < pages.length; i++) {
        if (pl === String(pages[i]).toLowerCase()) return true;
      }
    } catch (e) {}
    return false;
  }

  function has(needle, hay) { return hay.indexOf(needle) !== -1; }
  function hasAny(hay /*, needles... */) {
    for (var i = 1; i < arguments.length; i++) if (has(arguments[i], hay)) return true;
    return false;
  }

  function q(params, key, val) {
    if (!params) return false;
    if (typeof val === 'undefined') return params.has(key);
    return (params.get(key) || '').toLowerCase() === String(val).toLowerCase();
  }

  // Only treat WP left menu or our sidebar container as "menu"
  function isInMenu(el) {
    var cur = el;
    while (cur && cur !== document.body) {
      if (cur.id === 'adminmenu' || cur.id === 'adminmenuwrap') return true;
      if (cur.classList && (cur.classList.contains('yps-sidebar') || cur.classList.contains('yoo-menu'))) return true;
      cur = cur.parentElement;
    }
    return false;
  }

  /* ====================== URL-based icon chooser ====================== */
  function normUrlParts(u) {
    var L = (u || '').toLowerCase();
    var url, params, path = '', full = L;
    try {
      url = new URL(u, location.origin);
      params = url.searchParams;
      var p = params.get('path') || '';
      try { path = decodeURIComponent(p); } catch (_) { path = p; }
      full = (url.pathname + url.search).toLowerCase() + (path ? (' ' + path.toLowerCase()) : '');
    } catch (_e) {}
    return { full: full, params: params, path: (path || '').toLowerCase() };
  }

  // WP core icons
  function wpCoreIcon(full, params) {
    if (has('/index.php', full))                        return 'dashicons-dashboard';
    if (has('/update-core.php', full))                  return 'dashicons-update';
    if (has('/edit.php?', full) && !has('post_type=', full))        return 'dashicons-admin-post';
    if (has('/post-new.php', full) && !has('post_type=page', full)) return 'dashicons-welcome-write-blog';
    if (has('/edit-tags.php', full) && has('taxonomy=category', full) && !has('post_type=product', full)) return 'dashicons-category';
    if (has('/edit-tags.php', full) && has('taxonomy=post_tag', full)) return 'dashicons-tag';
    if (has('/upload.php', full))                       return 'dashicons-admin-media';
    if (has('/media-new.php', full))                    return 'dashicons-format-image';
    if (has('/edit.php?post_type=page', full))          return 'dashicons-admin-page';
    if (has('/post-new.php?post_type=page', full))      return 'dashicons-admin-page';
    if (has('/edit-comments.php', full))                return 'dashicons-admin-comments';
    if (has('/users.php', full))                        return 'dashicons-groups';
    if (has('/user-new.php', full))                     return 'dashicons-plus-alt2';
    if (has('/profile.php', full))                      return 'dashicons-id';
    if (has('/themes.php', full))                       return 'dashicons-admin-appearance';
    if (has('/customize.php', full))                    return 'dashicons-admin-customizer';
    if (has('/nav-menus.php', full))                    return 'dashicons-menu';
    if (has('/widgets.php', full))                      return 'dashicons-welcome-widgets-menus';
    if (has('/site-editor.php', full))                  return 'dashicons-admin-appearance';
    if (has('/export-personal-data.php', full))         return 'dashicons-download';
    if (has('/erase-personal-data.php',  full))         return 'dashicons-trash';
    if (has('/site-health.php', full))                  return 'dashicons-heart';
    if (has('/import.php', full))                       return 'dashicons-download';
    if (has('/export.php', full))                       return 'dashicons-upload';
    if (has('/tools.php', full) && q(params,'page','export_personal_data')) return 'dashicons-download';
    if (has('/tools.php', full) && (q(params,'page','erase_personal_data') || q(params,'page','remove_personal_data'))) return 'dashicons-trash';
    if (has('action-scheduler', full))                  return 'dashicons-schedule';
    if (has('/theme-editor.php', full))                 return 'dashicons-editor-code';
    if (has('/plugin-editor.php', full))                return 'dashicons-editor-code';
    if (has('/plugin-install.php', full))               return 'dashicons-admin-plugins';
    if (has('/tools.php', full))                        return 'dashicons-admin-tools';
    if (has('/options-general.php', full))              return 'dashicons-admin-settings';
    if (has('/options-writing.php', full))              return 'dashicons-edit';
    if (has('/options-reading.php', full))              return 'dashicons-book';
    if (has('/options-discussion.php', full))           return 'dashicons-admin-comments';
    if (has('/options-media.php', full))                return 'dashicons-admin-media';
    if (has('/options-permalink.php', full))            return 'dashicons-admin-links';
    if (has('/privacy.php', full))                      return 'dashicons-shield';
    if (has('contact', full))                           return 'dashicons-email';
    return '';
  }

  // WooCommerce icons
  function wcIcon(full, params) {
    var isWcAdmin = q(params, 'page', 'wc-admin');
    if (has('/analytics/overview', full)) return 'dashicons-chart-area';
    if (has('/analytics/revenue', full))  return 'dashicons-chart-line';
    if (has('/analytics/products', full)) return 'dashicons-products';
    if (has('/analytics/orders', full))   return 'dashicons-cart';
    if (has('/analytics/categories', full)) return 'dashicons-category';
    if (has('/analytics/coupons', full))  return 'dashicons-tickets-alt';
    if (has('/analytics/taxes', full))    return 'dashicons-bank';
    if (has('/analytics/downloads', full))return 'dashicons-download';
    if (has('/analytics/stock', full))    return 'dashicons-archive';
    if (has('/analytics/variations', full)) return 'dashicons-randomize';
    if (has('/analytics/settings', full)) return 'dashicons-admin-settings';

    if (q(params, 'page', 'wc-orders') || has('post_type=shop_order', full)) return 'dashicons-cart';
    if (isWcAdmin && has('/customers', full)) return 'dashicons-groups';
    if (q(params, 'page', 'wc-settings')) return 'dashicons-admin-settings';
    if (q(params, 'page', 'wc-status') || has('/status', full)) return 'dashicons-yes';
    if (q(params, 'page', 'wc-reports') || has('/reports', full)) return 'dashicons-chart-bar';
    if (q(params, 'page', 'wc-addons')  || has('/extensions', full)) return 'dashicons-admin-plugins';

    if (has('edit.php?post_type=product', full) && !has('taxonomy=', full) && !has('page=product_attributes', full)) return 'dashicons-products';
    if (has('taxonomy=product_cat', full) || (isWcAdmin && has('/products/categories', full))) return 'dashicons-category';
    if (has('taxonomy=product_tag', full) || (isWcAdmin && has('/products/tags', full))) return 'dashicons-tag';
    if (has('page=product_attributes', full) || (isWcAdmin && has('/products/attributes', full))) return 'dashicons-filter';
    if (hasAny(full, 'taxonomy=product_brand', '/brands', '/product-brands')) return 'dashicons-awards';
    if (hasAny(full, '/product-reviews', 'page=product_reviews', 'product-reviews')) return 'dashicons-star-filled';
    if (has('post_type=shop_coupon', full) || (isWcAdmin && (has('/marketing/coupons', full) || has('path=/coupons', full) || has('/coupons', full)))) return 'dashicons-tickets-alt';
    if (has('product', full) && has('import', full)) return 'dashicons-upload';
    if (has('product', full) && has('export', full)) return 'dashicons-download';
    if (has('woocommerce', full) || isWcAdmin) return 'dashicons-cart';
    return '';
  }

  // Plugins & others
  function pluginIcon(full, params) {
    if (hasAny(full, 'googlesitekit', 'page=googlesitekit')) {
      if (has('dashboard', full)) return 'dashicons-chart-area';
      if (has('settings', full))  return 'dashicons-admin-settings';
      return 'dashicons-google';
    }
    if (has('wpforms', full) || has('page=wpforms', full)) {
      if (hasAny(full, 'overview', 'all', 'wpforms-overview')) return 'dashicons-feedback';
      if (hasAny(full, 'builder', 'add-new', 'new'))           return 'dashicons-plus-alt2';
      if (has('entries', full))                                return 'dashicons-visibility';
      if (has('payments', full))                               return 'dashicons-money';
      if (hasAny(full, 'templates', 'form-templates'))         return 'dashicons-media-text';
      if (has('settings', full))                               return 'dashicons-admin-settings';
      if (has('tools', full))                                  return 'dashicons-admin-tools';
      if (has('addons', full))                                 return 'dashicons-admin-plugins';
      if (hasAny(full, 'privacy', 'compliance'))               return 'dashicons-shield';
      if (has('smtp', full))                                   return 'dashicons-email-alt';
      if (has('about', full))                                  return 'dashicons-info';
      if (has('community', full))                              return 'dashicons-groups';
      if (hasAny(full, 'upgrade', 'pro', 'license', 'plan'))   return 'dashicons-star-filled';
      return 'dashicons-feedback';
    }
    if (hasAny(full, 'page=bookly', '/bookly')) {
      if (has('dashboard', full)) return 'dashicons-dashboard';
      if (has('calendar', full))  return 'dashicons-calendar-alt';
      if (has('appointments', full)) return 'dashicons-calendar';
      if (hasAny(full, 'staff', 'employee')) return 'dashicons-businessperson';
      if (has('services', full)) return 'dashicons-hammer';
      if (has('customers', full)) return 'dashicons-groups';
      if (hasAny(full, 'email', 'notifications')) return 'dashicons-email';
      if (has('payments', full)) return 'dashicons-money';
      if (has('appearance', full)) return 'dashicons-art';
      if (has('settings', full)) return 'dashicons-admin-settings';
      if (hasAny(full, 'diagnostics', 'debug')) return 'dashicons-search';
      if (has('news', full)) return 'dashicons-megaphone';
      if (has('addons', full)) return 'dashicons-admin-plugins';
      if (hasAny(full, 'get-pro', 'upgrade')) return 'dashicons-star-filled';
      return 'dashicons-calendar';
    }
    if (hasAny(full, 'wordfence', 'page=Wordfence', 'wfhome', 'wfls', 'wf-')) {
      if (hasAny(full, 'dashboard', 'wfhome')) return 'dashicons-shield';
      if (hasAny(full, 'waf', 'firewall'))      return 'dashicons-shield';
      if (has('scan', full))                    return 'dashicons-search';
      if (has('tools', full))                   return 'dashicons-admin-tools';
      if (hasAny(full, 'audit', 'log'))        return 'dashicons-list-view';
      if (hasAny(full, 'login', 'security'))   return 'dashicons-lock';
      if (hasAny(full, 'all-options', 'options')) return 'dashicons-admin-settings';
      if (has('help', full))                    return 'dashicons-sos';
      if (has('install', full))                 return 'dashicons-download';
      if (hasAny(full, 'upgrade', 'premium'))   return 'dashicons-star-filled';
      return 'dashicons-shield';
    }
    if (hasAny(full, 'wpseo', 'yoast')) {
      if (hasAny(full, 'dashboard', 'general')) return 'dashicons-admin-generic';
      if (has('settings', full))                return 'dashicons-admin-settings';
      if (has('integrations', full))            return 'dashicons-admin-network';
      if (has('tools', full))                   return 'dashicons-admin-tools';
      if (has('redirect', full))                return 'dashicons-randomize';
      if (has('workout', full))                 return 'dashicons-yes';
      if (has('support', full))                 return 'dashicons-sos';
      if (has('academy', full))                 return 'dashicons-welcome-learn-more';
      if (hasAny(full, 'plans', 'upgrade', 'license')) return 'dashicons-star-filled';
      return 'dashicons-admin-generic';
    }
    if (hasAny(full, 'wpcf7', 'post_type=wpcf7_contact_form', 'wpcf7-new', 'wpcf7-integration')) return 'dashicons-email';
    return '';
  }

  function guessIconByUrl(u) {
    var P = normUrlParts(u);
    var S = P.full, params = P.params;
    var i = wpCoreIcon(S, params); if (i) return i;
    i = wcIcon(S, params);         if (i) return i;
    i = pluginIcon(S, params);     if (i) return i;
    if (has('payments', S) || has('payment', S) || has('gateway', S)) return 'dashicons-money';
    return '';
  }
  function guessIconForItem(url, parentIcon) {
    var i = guessIconByUrl(url);
    if (i) return i;
    if (parentIcon && /^dashicons-/.test(parentIcon)) return parentIcon;
    return 'dashicons-admin-links';
  }

  /* ===== Slider Revolution helpers ===== */
  function sliderRevIconForTitle(cleanTitle) {
    var t = (cleanTitle || '').toLowerCase();
    if (/^overview$/.test(t))                      return 'dashicons-dashboard';
    if (/getting\s+started/.test(t))               return 'dashicons-welcome-learn-more';
    if (/help\s*center|support\s*center/.test(t))  return 'dashicons-sos';
    if (/template|library|example/.test(t))        return 'dashicons-images-alt2';
    if (/premium\s*support/.test(t))               return 'dashicons-awards';
    if (/go\s*premium|upgrade|pro/.test(t))        return 'dashicons-star-filled';
    return '';
  }
  function isSliderRevKey(menuKey) {
    return /^(revslider|rev_slider|slider[_-]?revolution|sr_)/i.test(menuKey || '');
  }

  /* ========================= Badge propagation ========================= */
  function normalizeBadgeCount(raw) {
    var n = parseInt(String(raw || '').replace(/[^\d]/g, ''), 10);
    return (!isNaN(n) && n > 0) ? String(n) : '';
  }

  function badgeFromDashboardCard(card) {
    if (!card) return '';
    var badgeEl = card.querySelector('.yp-card-badge:not([hidden])');
    if (badgeEl && badgeEl.textContent) {
      var fromEl = normalizeBadgeCount(badgeEl.textContent);
      if (fromEl) return fromEl;
    }
    if (card.dataset && card.dataset.badge) {
      return normalizeBadgeCount(card.dataset.badge);
    }
    return '';
  }

  function popupTileShouldReceiveParentBadge(href, menuSlug) {
    var h = String(href || '').toLowerCase();
    var slug = String(menuSlug || '').toLowerCase();
    if (!h) return false;

    if (slug.indexOf('plugins') !== -1 || slug === 'plugins_php') {
      return h.indexOf('plugins.php') !== -1 && h.indexOf('plugin-install.php') === -1;
    }
    if (slug.indexOf('themes') !== -1 || slug === 'themes_php') {
      return h.indexOf('themes.php') !== -1 && h.indexOf('theme-install.php') === -1;
    }
    if (slug.indexOf('comments') !== -1 || slug.indexOf('edit-comments') !== -1) {
      return h.indexOf('edit-comments.php') !== -1;
    }
    if (slug.indexOf('update') !== -1 || slug === 'index_php') {
      return h.indexOf('update-core.php') !== -1;
    }

    return h.indexOf(slug.replace(/_/g, '.')) !== -1;
  }

  function applyParentBadgeToPopupTiles(container, parentBadge, menuSlug) {
    if (!container) return;
    var badge = normalizeBadgeCount(parentBadge);
    if (!badge) return;

    container.querySelectorAll('a.yp-icon-tile').forEach(function (tile) {
      var href = tile.getAttribute('href') || '';
      if (!popupTileShouldReceiveParentBadge(href, menuSlug)) return;
      tile.classList.add('has-badge');
      tile.setAttribute('data-badge', badge);
      var label = tile.querySelector('.yp-icon-label');
      if (label) {
        label.classList.add('has-badge');
        label.setAttribute('data-badge', badge);
      }
    });
  }

  /* ========================= Badge extraction ========================= */
  function extractBadgeFromTitle(rawTitle) {
    var title = normalizeTitle(rawTitle);
    var badge = '';

    if (!title) return { clean: title, badge: '' };

    // NEW/BETA/PRO/PREMIUM suffix (skip if entire title is the keyword, e.g. "Go Pro")
    var m0 = title.match(/^(.*?)(?:\s*[-–—]?\s*)(new|beta|pro|premium)!?\s*$/i);
    if (m0 && m0[1].trim().length > 0 && m0[1].trim().toLowerCase() !== 'go') return { clean: m0[1].trim(), badge: m0[2].toUpperCase() };

    // Comments (12)
    var m1 = title.match(/^(.*?)[(（]\s*(\d+)\s*[)）]\s*$/);
    if (m1) return { clean: m1[1].trim(), badge: m1[2] };

    // 12 Updates
    var m2 = title.match(/^\s*(\d+)\s+(.+)$/);
    if (m2) {
      var rest = m2[2].trim().toLowerCase();
      if (/(update|updates|pending|comment|comments|order|orders|plugin|plugins|review|reviews|message|messages|coupon|coupons)\b/.test(rest)) {
        return { clean: m2[2].trim(), badge: m2[1] };
      }
    }

    // Comments 3 in moderation
    var m3 = title.match(/^(.*?)(\d+)\s+(?:in\s+moderation|new|pending|updates?)\s*$/i);
    if (m3) return { clean: m3[1].trim(), badge: m3[2] };

    // Home 5 / Extensions 0
    var m4 = title.match(/^(.*?\D)(\d+)\s*$/);
    if (m4) return { clean: m4[1].trim(), badge: m4[2] };

    return { clean: title, badge: '' };
  }

  /* ======================== Rendering (tiles) ======================== */
  function renderSingleTileHTML(item, parentIcon, menuKey) {
    var parsed = extractBadgeFromTitle(item.title || '');
    var cleanTitle = parsed.clean;
    // Use badge from item data if available, otherwise extract from title
    var badge = (item.badge && String(item.badge).trim() !== '') ? String(item.badge).trim() : parsed.badge;
    if (badge === '0') badge = '';
    var rawKey = (item && typeof item.key === 'string' && item.key)
      ? item.key
      : slugKey((item && (item.slug || item.title || item.url)) || '');
    var combinedKey = 'sub_' + menuKey + '_' + rawKey;

    var isSlider = isSliderRevKey(menuKey);
    var baseline = guessIconForItem(item.url || '', parentIcon);
    var predicted = (window.YPIconAI && typeof window.YPIconAI.predict === 'function')
      ? (window.YPIconAI.predict({
          url: item.url || '',
          title: cleanTitle || '',
          parentIcon: parentIcon || '',
          baseline: baseline
        }) || '')
      : '';

    var icon = (item && typeof item.icon === 'string' && item.icon.length)
      ? item.icon
      : (isSlider ? (sliderRevIconForTitle(cleanTitle) || predicted || baseline)
                  : (predicted || baseline));

    var iconHtml;
    if (typeof icon === 'string' && icon.indexOf('dashicons-') === 0) {
      iconHtml = '<span class="dashicons ' + icon + '"></span>';
    } else if (typeof icon === 'string' && (icon.indexOf('http') === 0 || icon.indexOf('data:') === 0)) {
      iconHtml = '<img src="' + icon + '" alt="" />';
    } else {
      iconHtml = '<span class="dashicons dashicons-admin-links"></span>';
    }

    var tileBadgeAttr  = (badge !== '') ? (' data-badge="' + escapeHtml(badge) + '"') : '';
    var labelBadgeAttr = (badge !== '') ? (' data-badge="' + escapeHtml(badge) + '"') : '';
    var disableEdit = /^yooadmin/.test(menuKey) || /^yooadmin/.test(rawKey);
    var editButtonHtml = disableEdit
      ? ''
      : '<span class="yp-card-icon-edit" role="button" tabindex="0" data-card-key="' + escapeHtml(combinedKey) + '" aria-label="Change icon"><span class="dashicons dashicons-edit"></span></span>';

    var isExternal = (item.url || '').indexOf('http') === 0 && (item.url || '').indexOf(window.location.origin) !== 0;
    return '' +
      '<a class="yp-icon-tile' + (badge !== '' ? ' has-badge' : '') + '" href="' + (item.url || '#') + '"' +
        (isExternal ? ' target="_blank" rel="noopener noreferrer"' : '') +
        ' data-card-key="' + escapeHtml(combinedKey) + '"' +
        ' data-default-icon="' + escapeHtml((typeof item.icon === 'string' ? item.icon : '') || '') + '"' +
        (disableEdit ? ' data-icon-edit-disabled="1"' : '') +
        tileBadgeAttr + '>' +
        '<span class="yp-icon">' + iconHtml + '</span>' +
        '<span class="yp-icon-label' + (badge !== '' ? ' has-badge' : '') + '"' + labelBadgeAttr + '>' +
          escapeHtml(cleanTitle) +
        '</span>' +
        editButtonHtml +
      '</a>';
  }

  function renderItemsHTML(items, parentIcon, menuKey) {
    var ITEMS_PER_PAGE = 8;
    var totalItems = items.length;
    var totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);
    
    // If 8 or fewer items, render normally without pagination
    if (totalItems <= ITEMS_PER_PAGE) {
      var html = '';
      items.forEach(function (item) {
        html += renderSingleTileHTML(item, parentIcon, menuKey);
      });
      return html;
    }
    
    // Render with pagination
    var html = '<div class="yp-popup-pages-wrapper">';
    html += '<button type="button" class="yp-popup-nav-arrow yp-popup-nav-prev" aria-label="Previous page" style="display:none;"><span class="dashicons dashicons-arrow-left-alt2"></span></button>';
    html += '<div class="yp-popup-pages">';
    
    // Render all pages (hidden by default, shown via JS)
    for (var page = 0; page < totalPages; page++) {
      var pageClass = page === 0 ? 'yp-popup-page yp-popup-page-active' : 'yp-popup-page';
      html += '<div class="' + pageClass + '" data-page="' + page + '">';
      
      var startIdx = page * ITEMS_PER_PAGE;
      var endIdx = Math.min(startIdx + ITEMS_PER_PAGE, totalItems);
      
      for (var i = startIdx; i < endIdx; i++) {
        html += renderSingleTileHTML(items[i], parentIcon, menuKey);
      }
      
      html += '</div>';
    }
    
    html += '</div>';
    html += '<button type="button" class="yp-popup-nav-arrow yp-popup-nav-next" aria-label="Next page"><span class="dashicons dashicons-arrow-right-alt2"></span></button>';
    html += '</div>';
    
    // Add pagination dots
    if (totalPages > 1) {
      html += '<div class="yp-popup-pagination">';
      for (var p = 0; p < totalPages; p++) {
        var dotClass = p === 0 ? 'yp-popup-dot yp-popup-dot-active' : 'yp-popup-dot';
        html += '<button type="button" class="' + dotClass + '" data-page="' + p + '" aria-label="Page ' + (p + 1) + '"></button>';
      }
      html += '</div>';
    }
    
    return html;
  }

  /* ======================= Data sources & merge ======================= */

  /**
   * Build yoopixelMenus from yooadmCardMenus once (primary source).
   */
  function buildFromCards() {
    var map = {};
    if (!window.yooadmCardMenus || !Array.isArray(window.yooadmCardMenus.items)) return map;

    window.yooadmCardMenus.items.forEach(function (it) {
      if (it && Array.isArray(it.subs) && it.subs.length) {
        var key = slugKey(it.slug || it.title || '');
        var parentBadge = (it && typeof it.badge === 'string') ? normalizeBadgeCount(it.badge) : '';
        map[key] = {
          title: it.title || 'Menu',
          badge: parentBadge,
          items: it.subs.map(function (s) {
            var b = (s && typeof s.badge === 'string') ? s.badge.trim() : '';
            if (b === '0') b = '';
            return {
              title: s.title || '',
              url: s.url || '#',
              icon: (typeof s.icon === 'string' && s.icon.length) ? s.icon : '',
              badge: b,
              badge_kind: (s && typeof s.badge_kind === 'string') ? s.badge_kind : ''
            };
          })
        };
      }
    });
    return map;
  }

  /**
   * Fallback: extract submenu items from live WP left sidebar (#adminmenu)
   * Strategy:
   *  - Try match by data-menu-slug text with toplevel menu title (normalized)
   *  - If not found, try to use current highlighted toplevel (li.wp-has-current-submenu / .current)
   *  - Read .wp-submenu a[href] as items
   */
  function buildFromSidebar(slug) {
    var out = { title: 'Menu', items: [] };
    var targetLi = null;
    var adminMenu = document.getElementById('adminmenu');
    if (!adminMenu) return out;

    var normSlug = String(slug || '').toLowerCase();

    // Cache toplevel query - only query once
    var toplevel = adminMenu.querySelectorAll(':scope > li.menu-top');
    
    // 1) Try to find a toplevel LI by matching its text to slug
    for (var i = 0; i < toplevel.length; i++) {
      var li = toplevel[i];
      var txt = '';
      // Cache anchor query per li
      var a = li.querySelector(':scope > a.menu-top, :scope > a.toplevel_page, :scope > a');
      if (a) txt = normalizeTitle(a.textContent || a.getAttribute('aria-label') || '');
      var liKey = slugKey(txt);
      if (liKey && (liKey === normSlug || normSlug.indexOf(liKey) === 0 || liKey.indexOf(normSlug) === 0)) {
        targetLi = li;
        out.title = txt || out.title;
        break;
      }
    }

    // 2) If not found, use current highlighted toplevel
    if (!targetLi) {
      targetLi = adminMenu.querySelector('li.wp-has-current-submenu, li.menu-top.current, li.opensub');
      if (targetLi) {
        var a2 = targetLi.querySelector(':scope > a');
        var txt2 = normalizeTitle(a2 ? (a2.textContent || a2.getAttribute('aria-label') || '') : '');
        if (txt2) out.title = txt2;
      }
    }

    if (!targetLi) return out;

    // 3) Collect submenu links
    var submenu = targetLi.querySelector(':scope > .wp-submenu, :scope > ul.wp-submenu');
    if (!submenu) return out;

    // Cache links query - only query once
    var links = submenu.querySelectorAll('a[href]');
    links.forEach(function (link) {
      var href = link.getAttribute('href') || '#';
      // Skip anchors that toggle submenu (no href or "#")
      if (!href || href === '#') return;
      if (isExcludedSubmenuHrefForPopup(href)) return;
      var t = normalizeTitle(link.textContent || link.getAttribute('aria-label') || '');
      if (!t) return;
      var itemBadge = '';
      var badgeNode = link.querySelector('.update-plugins .update-count, .update-plugins .plugin-count, .awaiting-mod .pending-count, .awaiting-mod .comment-count, .awaiting-mod');
      if (badgeNode && badgeNode.textContent) {
        itemBadge = normalizeBadgeCount(badgeNode.textContent);
      }
      out.items.push({ title: t, url: href, icon: '', badge: itemBadge });
    });

    if (targetLi && out.items.length) {
      var parentBadgeNode = targetLi.querySelector('.update-plugins .update-count, .update-plugins .plugin-count, .awaiting-mod .pending-count, .awaiting-mod .comment-count, .update-plugins, .awaiting-mod');
      var parentBadge = parentBadgeNode && parentBadgeNode.textContent
        ? normalizeBadgeCount(parentBadgeNode.textContent)
        : '';
      if (parentBadge) {
        out.items.forEach(function (item) {
          if (item.badge && String(item.badge).trim() !== '') return;
          if (popupTileShouldReceiveParentBadge(item.url || '', slugKey(slug || out.title || ''))) {
            item.badge = parentBadge;
          }
        });
      }
    }

    return out;
  }

  /**
   * Ensure a merged menu map in window.yoopixelMenus:
   *  - Start with cards (primary)
   *  - If requested slug has no items, try sidebar fallback and store it under that slug
   */
  function ensureMenusMerged(requestedSlug) {
    if (!window.yoopixelMenus || typeof window.yoopixelMenus !== 'object') {
      window.yoopixelMenus = {};
    }
    // Merge cards once (idempotent)
    if (!window.__YPPopupCardsMerged) {
      var fromCards = buildFromCards();
      for (var k in fromCards) if (Object.prototype.hasOwnProperty.call(fromCards, k)) {
        window.yoopixelMenus[k] = fromCards[k];
      }
      window.__YPPopupCardsMerged = true;
    }

    var key = slugKey(requestedSlug || 'menu');
    var exists = window.yoopixelMenus[key] && Array.isArray(window.yoopixelMenus[key].items) && window.yoopixelMenus[key].items.length > 0;

    if (!exists) {
      var fallback = buildFromSidebar(key);
      if (fallback.items && fallback.items.length > 0) {
        window.yoopixelMenus[key] = fallback; // cache fallback for this slug
      }
    }
  }

  /* ============================ Popup API ============================ */
  window.ypShowPopup = function ypShowPopup(menuSlug, customTitle) {
    var popup   = byId('yp-popup');
    var titleEl = byId('yp-popup-title');
    var iconEl  = byId('yp-popup-icon');
    var content = byId('yp-popup-content');
    
    if (!popup || !titleEl || !content) {
      return;
    }

    ensureMenusMerged(menuSlug);

    var menus = window.yoopixelMenus || {};
    var key   = slugKey(menuSlug);
    var menu  = menus[key];

    var title = customTitle || (menu && menu.title) || 'Options';
    titleEl.textContent = title;
    
    // Set icon if available - try multiple sources
    var parentIcon = '';
    // First try: data attribute (set by click handler)
    parentIcon = popup.getAttribute('data-parent-icon') || '';
    // Second try: menu.icon if available
    if (!parentIcon && menu && menu.icon) {
      parentIcon = menu.icon;
    }
    
    if (iconEl && parentIcon) {
      var iconClass = '';
      if (parentIcon.indexOf('dashicons-') === 0) {
        iconClass = 'dashicons ' + parentIcon;
        iconEl.innerHTML = '<span class="' + iconClass + '"></span>';
        iconEl.style.display = 'flex';
      } else if (parentIcon.indexOf('http') === 0 || parentIcon.indexOf('data:') === 0 || parentIcon.indexOf('/') !== -1) {
        iconEl.innerHTML = '<img src="' + escapeHtml(parentIcon) + '" alt="" />';
        iconEl.style.display = 'flex';
      } else {
        // Fallback to generic icon
        iconEl.innerHTML = '<span class="dashicons dashicons-admin-links"></span>';
        iconEl.style.display = 'flex';
      }
    } else if (iconEl) {
      iconEl.style.display = 'none';
    }

    var items = (menu && Array.isArray(menu.items)) ? menu.items : [];
    
    if (!items.length) {
      // Nothing to show: do not block navigation — caller decides when to preventDefault.
      content.innerHTML = '<p>No options found.</p>';
      popup.style.display = 'flex';
      document.documentElement.classList.add('yoo-popup-open');
      return;
    }

    var parentIcon = popup.getAttribute('data-parent-icon') || '';
    content.innerHTML = renderItemsHTML(items, parentIcon, key);

    var parentBadge = popup.getAttribute('data-parent-badge') || '';
    if (!parentBadge && menu && menu.badge) {
      parentBadge = String(menu.badge);
    }
    applyParentBadgeToPopupTiles(content, parentBadge, key);
    
    // Add class to grid if pagination is used
    if (content.querySelector('.yp-popup-pages')) {
      content.classList.add('yp-has-pagination');
    } else {
      content.classList.remove('yp-has-pagination');
    }
    
    // Initialize pagination if needed
    initPagination(content);
    
    if (window.YPCardIcons && typeof window.YPCardIcons.sync === 'function') {
      window.YPCardIcons.sync();
    }
    if (typeof window.yshScheduleEnhancePopup === 'function') {
      window.yshScheduleEnhancePopup();
    }
    popup.style.display = 'flex';
    document.documentElement.classList.add('yoo-popup-open');
  };
  
  /* ======================== Pagination ======================== */
  function initPagination(container) {
    var pages = container.querySelectorAll('.yp-popup-page');
    var dots = container.querySelectorAll('.yp-popup-dot');
    var prevBtn = container.querySelector('.yp-popup-nav-prev');
    var nextBtn = container.querySelector('.yp-popup-nav-next');
    var pagesWrapper = container.querySelector('.yp-popup-pages-wrapper');
    var popupBox = container.closest('.yp-popup-box');
    var popupBoxWrapper = popupBox ? popupBox.parentElement : null;
    
    if (pages.length <= 1) return; // No pagination needed

    var popupRoot = container.closest('#yp-popup');
    var useStudioHubInnerNav = popupRoot
      && popupRoot.classList.contains('yp-popup--studio-hub')
      && document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub');
    
    // Move arrows to wrapper if available for proper positioning
    if (popupBoxWrapper && prevBtn && nextBtn && !useStudioHubInnerNav) {
      // Remove from pagesWrapper and append to wrapper
      // Check if arrows are still in pagesWrapper or need to be moved
      var prevParent = prevBtn.parentElement;
      var nextParent = nextBtn.parentElement;
      
      if (prevParent === pagesWrapper || prevParent === container) {
        if (prevParent === pagesWrapper) {
          pagesWrapper.removeChild(prevBtn);
        } else if (prevParent === container) {
          container.removeChild(prevBtn);
        }
        popupBoxWrapper.appendChild(prevBtn);
      }
      
      if (nextParent === pagesWrapper || nextParent === container) {
        if (nextParent === pagesWrapper) {
          pagesWrapper.removeChild(nextBtn);
        } else if (nextParent === container) {
          container.removeChild(nextBtn);
        }
        popupBoxWrapper.appendChild(nextBtn);
      }
    }
    
    function getCurrentPage() {
      var activePage = container.querySelector('.yp-popup-page-active');
      if (!activePage) return 0;
      return parseInt(activePage.getAttribute('data-page'), 10);
    }
    
    function goToPage(pageIndex) {
      if (pageIndex < 0 || pageIndex >= pages.length) return;
      
      // Hide all pages
      pages.forEach(function(page) {
        page.classList.remove('yp-popup-page-active');
      });
      
      // Show target page
      var targetPageEl = container.querySelector('.yp-popup-page[data-page="' + pageIndex + '"]');
      if (targetPageEl) {
        targetPageEl.classList.add('yp-popup-page-active');
      }
      
      // Update dots
      dots.forEach(function(d) {
        d.classList.remove('yp-popup-dot-active');
      });
      var targetDot = container.querySelector('.yp-popup-dot[data-page="' + pageIndex + '"]');
      if (targetDot) {
        targetDot.classList.add('yp-popup-dot-active');
      }
      
      // Update arrow visibility (no loop)
      if (prevBtn) {
        prevBtn.style.display = pageIndex > 0 ? 'flex' : 'none';
      }
      if (nextBtn) {
        nextBtn.style.display = pageIndex < pages.length - 1 ? 'flex' : 'none';
      }
    }
    
    // Handle dot clicks
    dots.forEach(function(dot) {
      dot.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var targetPage = parseInt(this.getAttribute('data-page'), 10);
        goToPage(targetPage);
      });
    });
    
    // Handle prev button
    if (prevBtn) {
      prevBtn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var currentPage = getCurrentPage();
        if (currentPage > 0) {
          goToPage(currentPage - 1);
        }
      });
    }
    
    // Handle next button
    if (nextBtn) {
      nextBtn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var currentPage = getCurrentPage();
        if (currentPage < pages.length - 1) {
          goToPage(currentPage + 1);
        }
      });
    }
    
    // Initialize arrow visibility
    goToPage(0);
    
    // Show/hide arrows on hover - use pagesWrapper or popupBoxWrapper
    var hoverTarget = pagesWrapper || popupBoxWrapper;
    var popupBox = container.closest('.yp-popup-box');
    
    // ✅ Debounced show/hide for better performance
    var showArrows = debounce(function() {
      raf(function() {
        var currentPage = getCurrentPage();
        if (prevBtn && currentPage > 0) {
          prevBtn.classList.add('is-visible');
        }
        if (nextBtn && currentPage < pages.length - 1) {
          nextBtn.classList.add('is-visible');
        }
      });
    }, 50);
    
    var hideArrows = debounce(function(e) {
      // Don't hide if mouse is moving to/from an arrow
      if (e && e.relatedTarget) {
        if (prevBtn && (prevBtn.contains(e.relatedTarget) || e.relatedTarget === prevBtn)) {
          return;
        }
        if (nextBtn && (nextBtn.contains(e.relatedTarget) || e.relatedTarget === nextBtn)) {
          return;
        }
        // Don't hide if moving within the popup box
        if (popupBox && popupBox.contains(e.relatedTarget)) {
          return;
        }
      }
      raf(function() {
        if (prevBtn) prevBtn.classList.remove('is-visible');
        if (nextBtn) nextBtn.classList.remove('is-visible');
      });
    }, 50);
    
    // Show arrows when hovering over the popup box or pages wrapper
    if (popupBox) {
      popupBox.addEventListener('mouseenter', showArrows);
      popupBox.addEventListener('mouseleave', hideArrows);
    }
    
    if (hoverTarget) {
      hoverTarget.addEventListener('mouseenter', showArrows);
      hoverTarget.addEventListener('mouseleave', hideArrows);
    }
    
    // Keep arrows visible when hovering over them
    if (prevBtn) {
      prevBtn.addEventListener('mouseenter', function() {
        showArrows();
      });
      prevBtn.addEventListener('mouseleave', function(e) {
        // Only hide if not moving to popup box or other arrow
        if (!popupBox || (!popupBox.contains(e.relatedTarget) && e.relatedTarget !== nextBtn)) {
          hideArrows(e);
        }
      });
    }
    
    if (nextBtn) {
      nextBtn.addEventListener('mouseenter', function() {
        showArrows();
      });
      nextBtn.addEventListener('mouseleave', function(e) {
        // Only hide if not moving to popup box or other arrow
        if (!popupBox || (!popupBox.contains(e.relatedTarget) && e.relatedTarget !== prevBtn)) {
          hideArrows(e);
        }
      });
    }
  }

  window.ypClosePopup = function ypClosePopup() {
    var popup = byId('yp-popup');
    if (popup) {
      popup.style.display = 'none';
      popup.removeAttribute('data-parent-icon');
      popup.removeAttribute('data-parent-badge');
    }
    document.documentElement.classList.remove('yoo-popup-open');
  };

  /* ============================= Events ============================= */

  function attachEvents() {
    // ✅ Optimized: Event delegation only on dashboard grid (not entire document)
    var dashboardGrid = document.querySelector('.yp-icon-grid-boxes');
    var clickHandler = function (e) {
      var link = e.target && e.target.closest ? e.target.closest('[data-menu-slug]') : null;
      
      if (!link) {
        return;
      }

      // Never hijack clicks that are truly inside a real menu
      var inMenu = isInMenu(link);
      if (inMenu) {
        return;
      }

      var slugRaw = link.getAttribute('data-menu-slug') || '';
      var slug    = slugKey(slugRaw);
      var title   = link.getAttribute('data-card-title') || 'Options';

      // Infer parent icon for children fallback - search in multiple locations
      var parentIcon = '';
      // Try to find icon in .yp-icon or .yp-icon-tile first (dashboard cards)
      var iconHolder = link.querySelector('.yp-icon') || link.closest('.yp-icon-tile');
      if (iconHolder) {
        var dash = iconHolder.querySelector('.dashicons');
        var img = iconHolder.querySelector('img');
        if (dash && dash.classList) {
          var cls = Array.prototype.find.call(dash.classList, function (c) { return c.indexOf('dashicons-') === 0; });
          if (cls) parentIcon = cls;
        } else if (img && img.getAttribute('src')) {
          parentIcon = img.getAttribute('src');
        }
      }
      // Fallback: search directly in link
      if (!parentIcon) {
        var dash = link.querySelector('.dashicons');
        var img  = link.querySelector('img');
        if (dash && dash.classList) {
          var cls = Array.prototype.find.call(dash.classList, function (c) { return c.indexOf('dashicons-') === 0; });
          if (cls) parentIcon = cls;
        } else if (img && img.getAttribute('src')) {
          parentIcon = img.getAttribute('src');
        }
      }
      var popup = byId('yp-popup');
      var parentBadge = badgeFromDashboardCard(link);
      
      if (popup) {
        if (parentIcon) popup.setAttribute('data-parent-icon', parentIcon);
        if (parentBadge) {
          popup.setAttribute('data-parent-badge', parentBadge);
        } else {
          popup.removeAttribute('data-parent-badge');
        }
      }

      // Build/merge data from both sources for this slug
      ensureMenusMerged(slug);

      var menus = window.yoopixelMenus || {};
      var menu  = menus[slug];
      var items = (menu && Array.isArray(menu.items)) ? menu.items : [];

      if (items.length > 0) {
        // We have things to show → prevent navigation and open popup
        e.preventDefault();
        // stopImmediatePropagation to avoid document-level "click outside" listeners in other scripts
        if (typeof e.stopImmediatePropagation === 'function') {
          e.stopImmediatePropagation();
        }
        e.stopPropagation();

        window.ypShowPopup(slug, title);
      } else {
        // No items even after fallback → do not block; allow natural navigation
        // Also clear any parent-icon residue
        if (popup) popup.removeAttribute('data-parent-icon');
      }
    };
    
    // ✅ Attach event listener to dashboard grid for better performance
    if (dashboardGrid) {
      dashboardGrid.addEventListener('click', clickHandler, { passive: false });
    }
    // Fallback: Also attach to document for other menu items
    document.addEventListener('click', clickHandler, { passive: false });

    // Close handlers
    document.addEventListener('click', function (e) {
      // Close via X button
      if (e.target.closest && (e.target.closest('#yp-popup .yp-popup-close') || e.target.id === 'yp-popup-close')) {
        e.preventDefault();
        if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
        e.stopPropagation();
        window.ypClosePopup();
        return;
      }
      // Click on overlay (only if clicking the overlay root itself)
      var popup = byId('yp-popup');
      if (popup && e.target === popup) {
        e.preventDefault();
        if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
        e.stopPropagation();
        window.ypClosePopup();
      }
    }, { passive: false });

    // ESC closes popup (do not touch menu ESC handler — keep separation)
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') window.ypClosePopup();
    });
  }

  // Diagnostic function to check system state (disabled for production)
  function diagnosticCheck() {
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      attachEvents();
      setTimeout(diagnosticCheck, 1000);
    });
  } else {
    attachEvents();
    setTimeout(diagnosticCheck, 1000);
  }
})();
