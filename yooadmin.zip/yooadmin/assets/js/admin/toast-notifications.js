/**
 * YOOAdmin - Toast notifications script
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';
    
    // Toast manager
    const ToastManager = {
        container: null,
        toasts: [],
        maxToasts: 5,

        isInsideReactRoot: function(el) {
            if (!el) return false;
            var node = el;
            while (node && node !== document.body) {
                var keys = Object.keys(node);
                for (var k = 0; k < keys.length; k++) {
                    if (keys[k].indexOf('__reactFiber$') === 0 || keys[k].indexOf('__reactContainer$') === 0) {
                        return true;
                    }
                }
                node = node.parentElement;
            }
            return false;
        },

        getClassifier: function() {
            return window.yooadminNoticeClassifier || null;
        },

        shouldHandleAsToast: function(el) {
            var classifier = this.getClassifier();
            if (classifier) {
                if (classifier.shouldConvertToNotification(el)) {
                    return false;
                }
                return classifier.shouldConvertToToast(el);
            }
            return (
                el.classList.contains('notice-success') ||
                el.classList.contains('updated') ||
                el.classList.contains('notice-error') ||
                el.classList.contains('error')
            );
        },
        
        /**
         * Initialize toast system
         */
        init: function() {
            this.createContainer();
            this.interceptNotices();
            this.checkUrlParameters();
        },
        
        /**
         * Check URL parameters and sessionStorage for post-reload toasts
         */
        checkUrlParameters: function() {
            const self = this;
            
            // Check URL parameters (WordPress default)
            const urlParams = new URLSearchParams(window.location.search);
            
            // Plugin activated
            if (urlParams.get('activate') === 'true') {
                setTimeout(function() {
                    self.show('Plugin activated.', 'success');
                }, 100);
            }
            
            // Plugin deactivated
            if (urlParams.get('deactivate') === 'true') {
                setTimeout(function() {
                    self.show('Plugin deactivated.', 'success');
                }, 100);
            }
            
            // Settings updated
            if (urlParams.get('settings-updated') === 'true') {
                setTimeout(function() {
                    self.show('Settings saved.', 'success');
                }, 100);
            }

            // Standalone login success → YOOAdmin (query flag from custom-login-standalone AJAX redirect)
            if (urlParams.get('yooadmin_login') === '1') {
                const loginMsg = (typeof window.yooadmToastI18n !== 'undefined' && window.yooadmToastI18n.loginSuccess)
                    ? window.yooadmToastI18n.loginSuccess
                    : 'Welcome! You are logged in successfully.';
                setTimeout(function() {
                    self.show(loginMsg, 'success');
                }, 100);
                urlParams.delete('yooadmin_login');
                const newSearch = urlParams.toString();
                const newUrl = window.location.pathname + (newSearch ? '?' + newSearch : '') + window.location.hash;
                window.history.replaceState({}, '', newUrl);
            }
            
            // Error
            if (urlParams.get('error')) {
                const errorMsg = decodeURIComponent(urlParams.get('error'));
                setTimeout(function() {
                    self.show(errorMsg, 'error');
                }, 100);
            }
            
            // Check sessionStorage for pending toasts
            const pendingToast = sessionStorage.getItem('yooadmin_pending_toast');
            if (pendingToast) {
                try {
                    const toastData = JSON.parse(pendingToast);
                    setTimeout(function() {
                        self.show(toastData.message, toastData.type, toastData.duration);
                    }, 100);
                    sessionStorage.removeItem('yooadmin_pending_toast');
                } catch (e) {
                    // Invalid JSON, ignore
                }
            }
        },
        
        /**
         * Create toast container
         */
        createContainer: function() {
            if (!this.container) {
                this.container = $('<div class="yooadmin-toast-container"></div>');
                $('body').append(this.container);
            }
        },
        
        /**
         * Intercept WordPress notices and convert to toast
         */
        interceptNotices: function() {
            const self = this;
            
            // Watch for new notices added to DOM
            const observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1) { // Element node
                            self.processNode(node);
                        }
                    });
                });
            });
            
            // Observe body for new notices
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
            
            // Process existing notices on page load
            $(document).ready(function() {
                self.processExistingNotices();
            });
        },
        
        /**
         * Process existing notices on page
         */
        processExistingNotices: function() {
            const self = this;
            
            // Target ONLY is-dismissible success/error notices
            // Exclude .yooadmin-notification (license page) and .yooadmin-brand-notice / .yooadmin-wizard-notice
            const excludes = ':not(.inline):not(.yooadmin-notification):not(.yooadmin-brand-notice):not(.yooadmin-wizard-notice)';
            const notices = $(
                '.notice.is-dismissible.notice-success' + excludes + ',' +
                '.notice.is-dismissible.updated' + excludes + ',' +
                '.updated.is-dismissible' + excludes + ',' +
                '.notice.is-dismissible.notice-error' + excludes + ',' +
                '.notice.is-dismissible.error' + excludes + ',' +
                '.error.is-dismissible' + excludes
            );
            
            notices.each(function() {
                const $notice = $(this);
                
                // Skip if already processed
                if ($notice.data('toast-processed')) {
                    return;
                }

                if (self.isInsideReactRoot(this)) {
                    return;
                }
                
                self.convertNoticeToToast($notice);
            });
        },
        
        /**
         * Process a single DOM node
         */
        processNode: function(node) {
            if (this.isInsideReactRoot(node)) {
                return;
            }

            const $node = $(node);
            
            // Check if node itself is a notice
            if (this.isTargetNotice($node)) {
                this.convertNoticeToToast($node);
            }
            
            // Check for notices within the node
            const notices = $node.find(
                '.notice.is-dismissible:not(.inline):not(.yooadmin-brand-notice):not(.yooadmin-wizard-notice),' +
                '.updated.is-dismissible:not(.inline),' +
                '.error.is-dismissible:not(.inline)'
            );
            
            const self = this;
            notices.each(function() {
                self.convertNoticeToToast($(this));
            });
        },
        
        /**
         * Check if element is a target notice
         */
        isTargetNotice: function($el) {
            var el = $el[0] || $el;
            if (!el || el.nodeType !== 1) {
                return false;
            }

            if (this.isInsideReactRoot(el)) {
                return false;
            }

            if (!this.shouldHandleAsToast(el)) {
                return false;
            }
            
            // Must be a notice
            if (!$el.hasClass('notice') && !$el.hasClass('updated') && !$el.hasClass('error')) {
                return false;
            }
            
            // Must be dismissible
            if (!$el.hasClass('is-dismissible')) {
                return false;
            }
            
            // Must not be inline
            if ($el.hasClass('inline')) {
                return false;
            }
            
            // Must not be YOOAdmin's own notices
            if ($el.hasClass('yooadmin-brand-notice') || $el.hasClass('yooadmin-wizard-notice') || $el.hasClass('yooadmin-notification')) {
                return false;
            }
            
            // Custom posts/pages list screens convert via list-screen-toast.js.
            if ($el.closest('.yooadmin-posts-page, .yooadmin-pages-page, .yooadmin-plugins-page').length) {
                return false;
            }

            // Other YOOAdmin screens handle notices differently.
            if ($el.closest('.yooadmin-page').length) {
                return false;
            }

            if (
                document.body.classList.contains('yooadmin-posts-screen') ||
                document.body.classList.contains('yooadmin-pages-screen') ||
                document.body.classList.contains('yooadmin-plugins-screen')
            ) {
                return false;
            }
            
            return true;
        },
        
        /**
         * Convert WordPress notice to toast
         */
        convertNoticeToToast: function($notice) {
            if ($notice.data('toast-processed')) {
                return;
            }
            var el = $notice[0];
            if (el && !this.shouldHandleAsToast(el)) {
                return;
            }
            $notice.data('toast-processed', true);
            
            // Extract message
            const message = this.extractMessage($notice);
            if (!message) {
                return;
            }
            
            // Determine type
            const type = this.getNoticeType($notice);
            
            // Hide original notice
            $notice.hide();
            
            // Show toast
            this.show(message, type);
        },
        
        /**
         * Extract message from notice
         */
        extractMessage: function($notice) {
            // Clone to avoid modifying original
            const $clone = $notice.clone();
            
            // Remove dismiss button
            $clone.find('.notice-dismiss').remove();
            
            // Get text content
            let message = $clone.text().trim();
            
            // Clean up whitespace
            message = message.replace(/\s+/g, ' ');
            
            return message;
        },
        
        /**
         * Get notice type
         */
        getNoticeType: function($notice) {
            if ($notice.hasClass('notice-success') || $notice.hasClass('updated')) {
                return 'success';
            }
            if ($notice.hasClass('notice-error') || $notice.hasClass('error')) {
                return 'error';
            }
            if ($notice.hasClass('notice-warning')) {
                return 'warning';
            }
            return 'info';
        },
        
        /**
         * Show toast notification
         */
        show: function(message, type, duration) {
            type = type || 'info';
            duration = duration || 5000; // 5 seconds default

            if (window.yooadminShowToast && typeof window.yooadminShowToast === 'function') {
                window.yooadminShowToast(message, type, duration);
                return null;
            }
            
            // Limit number of toasts
            if (this.toasts.length >= this.maxToasts) {
                this.removeOldest();
            }
            
            // Create toast element
            const $toast = this.createToast(message, type, duration);
            
            // Add to container
            this.container.append($toast);
            
            // Track toast
            this.toasts.push($toast);
            
            // Show with animation
            setTimeout(function() {
                $toast.addClass('show');
            }, 10);
            
            // Auto-dismiss
            const self = this;
            const timeoutId = setTimeout(function() {
                self.hide($toast);
            }, duration);
            
            // Store timeout ID for manual dismiss
            $toast.data('timeout-id', timeoutId);
            
            return $toast;
        },
        
        /**
         * Create toast element
         */
        createToast: function(message, type, duration) {
            const icons = {
                success: '✓',
                error: '✕',
                warning: '⚠',
                info: 'ℹ'
            };
            
            const icon = icons[type] || icons.info;
            
            const $toast = $('<div class="yooadmin-toast toast-' + type + '">' +
                '<div class="yooadmin-toast-icon">' + icon + '</div>' +
                '<div class="yooadmin-toast-content">' +
                    '<div class="yooadmin-toast-message">' + this.escapeHtml(message) + '</div>' +
                '</div>' +
                '<button class="yooadmin-toast-close" aria-label="Close">&times;</button>' +
                '<div class="yooadmin-toast-progress" style="width: 100%; transition-duration: ' + duration + 'ms;"></div>' +
            '</div>');
            
            // Start progress animation
            setTimeout(function() {
                $toast.find('.yooadmin-toast-progress').css('width', '0');
            }, 10);
            
            // Close button handler
            const self = this;
            $toast.find('.yooadmin-toast-close').on('click', function(e) {
                e.preventDefault();
                self.hide($toast);
            });
            
            // Pause on hover
            $toast.on('mouseenter', function() {
                const timeoutId = $toast.data('timeout-id');
                if (timeoutId) {
                    clearTimeout(timeoutId);
                }
                $toast.find('.yooadmin-toast-progress').css('transition', 'none');
            });
            
            // Resume on leave
            $toast.on('mouseleave', function() {
                const remainingTime = 2000; // Give 2 more seconds
                const newTimeoutId = setTimeout(function() {
                    self.hide($toast);
                }, remainingTime);
                $toast.data('timeout-id', newTimeoutId);
            });
            
            return $toast;
        },
        
        /**
         * Hide toast
         */
        hide: function($toast) {
            const self = this;
            
            // Clear timeout
            const timeoutId = $toast.data('timeout-id');
            if (timeoutId) {
                clearTimeout(timeoutId);
            }
            
            // Hide animation
            $toast.addClass('hide').removeClass('show');
            
            // Remove from DOM and array after animation
            setTimeout(function() {
                $toast.remove();
                const index = self.toasts.indexOf($toast);
                if (index > -1) {
                    self.toasts.splice(index, 1);
                }
            }, 300);
        },
        
        /**
         * Remove oldest toast
         */
        removeOldest: function() {
            if (this.toasts.length > 0) {
                this.hide(this.toasts[0]);
            }
        },
        
        /**
         * Escape HTML
         */
        escapeHtml: function(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    };
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            ToastManager.init();
        });
    } else {
        ToastManager.init();
    }
    
    // Also initialize on jQuery ready as fallback
    $(document).ready(function() {
        if (!ToastManager.container) {
            ToastManager.init();
        }
    });
    
    // Expose to window for manual usage
    window.yooadmToast = {
        show: function(message, type, duration) {
            return ToastManager.show(message, type, duration);
        },
        success: function(message, duration) {
            return ToastManager.show(message, 'success', duration);
        },
        error: function(message, duration) {
            return ToastManager.show(message, 'error', duration);
        },
        warning: function(message, duration) {
            return ToastManager.show(message, 'warning', duration);
        },
        info: function(message, duration) {
            return ToastManager.show(message, 'info', duration);
        }
    };
    
})(jQuery);
