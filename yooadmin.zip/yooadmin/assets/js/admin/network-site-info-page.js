(function () {
  'use strict';

  var root = document.querySelector('.yoo-network-site-editor-wrap, .yoo-network-site-info-wrap');
  if (!root) {
    return;
  }

  var toastHideTimer = null;
  var toastRemoveTimer = null;

  function showToast(message, type) {
    if (!message) {
      return;
    }

    type = type === 'error' ? 'error' : 'success';

    document.querySelectorAll('.yp-toast-message.yoo-network-site-editor-toast').forEach(function (el) {
      if (el.parentNode) {
        el.parentNode.removeChild(el);
      }
    });

    if (toastHideTimer) {
      clearTimeout(toastHideTimer);
      toastHideTimer = null;
    }
    if (toastRemoveTimer) {
      clearTimeout(toastRemoveTimer);
      toastRemoveTimer = null;
    }

    var iconChar = type === 'error' ? '✕' : '✓';
    var toast = document.createElement('div');
    toast.className = 'yp-toast-message yoo-network-site-editor-toast yp-toast-' + type;
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');

    var icon = document.createElement('span');
    icon.className = 'yp-toast-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = iconChar;

    var text = document.createElement('span');
    text.className = 'yp-toast-text';
    text.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(text);
    document.body.appendChild(toast);

    window.setTimeout(function () {
      toast.classList.add('yp-toast-show');
    }, 10);

    toastHideTimer = window.setTimeout(function () {
      toast.classList.remove('yp-toast-show');
      toastRemoveTimer = window.setTimeout(function () {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3200);
  }

  window.yooadminNetworkSiteEditorShowToast = showToast;

  function initTabs() {
    var wrap = root.querySelector('[data-yp-tabs]');
    if (!wrap) {
      return;
    }

    var nav = wrap.querySelector('.yp-tab-nav');
    if (!nav) {
      return;
    }

    var ink = nav.querySelector('.yp-tab-ink');
    if (!ink) {
      ink = document.createElement('span');
      ink.className = 'yp-tab-ink';
      nav.appendChild(ink);
    }

    function moveInk(target) {
      if (!target) {
        return;
      }

      var rect = target.getBoundingClientRect();
      var navRect = nav.getBoundingClientRect();
      ink.style.width = rect.width + 'px';
      ink.style.left = rect.left - navRect.left + 'px';
    }

    var active = nav.querySelector('.yp-tab.is-active, .yp-tab--link.is-active');
    moveInk(active);

    window.addEventListener('resize', function () {
      moveInk(nav.querySelector('.yp-tab.is-active, .yp-tab--link.is-active'));
    });
  }

  function initFlashNotice() {
    var message = root.getAttribute('data-flash-message') || '';
    var type = root.getAttribute('data-flash-type') || 'success';

    if (!message) {
      return;
    }

    root.removeAttribute('data-flash-message');
    root.removeAttribute('data-flash-type');

    showToast(message, type);

    if (!window.history || !window.history.replaceState) {
      return;
    }

    var url = new URL(window.location.href);
    ['update', 'enabled', 'disabled', 'error'].forEach(function (key) {
      url.searchParams.delete(key);
    });
    window.history.replaceState({}, '', url.toString());
  }

  initTabs();
  initFlashNotice();
  initHelpTooltips();

  function initHelpTooltips() {
    var icons = root.querySelectorAll('.yp-help-icon');
    if (!icons.length) {
      return;
    }

    icons.forEach(function (icon) {
      var tooltip = icon.querySelector('.yp-tooltip');
      if (!tooltip) {
        return;
      }

      function positionTooltip() {
        var iconRect = icon.getBoundingClientRect();
        var tooltipWidth = 320;
        var tooltipHeight = tooltip.offsetHeight || 100;
        var left = iconRect.left + iconRect.width / 2 - tooltipWidth / 2;
        var top = iconRect.top - tooltipHeight - 8;

        if (left < 20) {
          left = 20;
        }
        if (left + tooltipWidth > window.innerWidth - 20) {
          left = window.innerWidth - tooltipWidth - 20;
        }
        if (top < 20) {
          top = iconRect.bottom + 8;
        }

        tooltip.style.position = 'fixed';
        tooltip.style.left = left + 'px';
        tooltip.style.top = top + 'px';
        tooltip.style.bottom = 'auto';
        tooltip.style.transform = 'none';
        tooltip.style.display = 'block';
        tooltip.style.opacity = '1';
        tooltip.style.zIndex = '999999';
      }

      function hideTooltip() {
        tooltip.style.display = 'none';
        tooltip.style.opacity = '0';
      }

      icon.addEventListener('mouseenter', positionTooltip);
      icon.addEventListener('focusin', positionTooltip);
      icon.addEventListener('mouseleave', hideTooltip);
      icon.addEventListener('focusout', hideTooltip);
    });
  }
})();
