(function ($) {
  'use strict';

  var ReviewPopup = {
    init: function () {
      var $overlay = $('#yooadmin-review-popup');
      if (!$overlay.length) {
        return;
      }

      $overlay.removeAttr('hidden').attr('aria-hidden', 'false');
      window.setTimeout(function () {
        $overlay.addClass('ywp-visible');
      }, 500);

      this.bindEvents($overlay);
    },

    hidePopup: function ($overlay) {
      $overlay.addClass('ywp-leaving').removeClass('ywp-visible');

      window.setTimeout(function () {
        $overlay.remove();
      }, 300);
    },

    post: function (action) {
      if (!window.yooadminReviewPopup) {
        return $.Deferred().resolve().promise();
      }

      return $.ajax({
        url: yooadminReviewPopup.ajaxUrl,
        type: 'POST',
        data: {
          action: action,
          nonce: yooadminReviewPopup.nonce,
        },
      });
    },

    showToast: function (message, type) {
      message = String(message || '').trim();
      if (!message) {
        return;
      }

      type = type || 'success';

      if (window.yooadmToast) {
        if (type === 'error' && typeof window.yooadmToast.error === 'function') {
          window.yooadmToast.error(message);
          return;
        }
        if (typeof window.yooadmToast.success === 'function' && type === 'success') {
          window.yooadmToast.success(message);
          return;
        }
        if (typeof window.yooadmToast.show === 'function') {
          window.yooadmToast.show(message, type);
          return;
        }
      }

      if (typeof window.yooadminShowToast === 'function') {
        window.yooadminShowToast(message, type);
      }
    },

    remindLater: function ($overlay) {
      var self = this;
      this.post('yooadmin_review_popup_remind_later')
        .done(function (response) {
          var message =
            response &&
            response.data &&
            typeof response.data.toast_message === 'string'
              ? response.data.toast_message
              : '';
          self.showToast(message, 'success');
        })
        .fail(function () {
          var errMsg =
            window.yooadminReviewPopup &&
            yooadminReviewPopup.i18n &&
            yooadminReviewPopup.i18n.remindError
              ? yooadminReviewPopup.i18n.remindError
              : 'Could not save your reminder. Please try again.';
          self.showToast(errMsg, 'error');
        })
        .always(function () {
          self.hidePopup($overlay);
        });
    },

    markReviewed: function () {
      this.post('yooadmin_review_popup_reviewed');
    },

    bindEvents: function ($overlay) {
      var self = this;

      $overlay.on('click', '.ywp-close, .ywp-review-remind', function (e) {
        e.preventDefault();
        self.remindLater($overlay);
      });

      $overlay.on('click', '.ywp-review-leave', function () {
        self.markReviewed();
        self.hidePopup($overlay);
      });

      $overlay.on('click', function (e) {
        if ($(e.target).is('.ywp-overlay')) {
          self.remindLater($overlay);
        }
      });

      $overlay.on('click', '.ywp-dialog', function (e) {
        e.stopPropagation();
      });
    },
  };

  $(document).ready(function () {
    window.setTimeout(function () {
      ReviewPopup.init();
    }, 600);
  });
})(jQuery);
