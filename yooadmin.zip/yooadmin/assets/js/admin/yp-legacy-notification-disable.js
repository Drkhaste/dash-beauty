/**
 * YOOAdmin - Legacy notification disabler
 *
 * @package YOOAdmin
 */

(function () {
  'use strict';
  
  // Local console shim for this file:
  // - Disables debug/info/warn logs in production
  // - Still forwards real errors to browser console
  var console = {
    log: function() {},
    info: function() {},
    warn: function() {},
    debug: function() {},
    error: function() {}
  };
  if (window.__YPLegacyDisabled) return;
  window.__YPLegacyDisabled = true;

  // ---------------- Disable Legacy Notification Functions ----------------
  function disableLegacyNotifications() {
    // Override specific legacy functions
    var legacyFunctions = [
      'convertAdminBannersToNotifications',
      'setupBannerConversion',
      'clearBannerNotifications',
      'handleBannerEvents',
      'processLegacyNotifications'
    ];
    
    legacyFunctions.forEach(function(funcName) {
      if (typeof window[funcName] === 'function') {
        window[funcName] = function() {
          return false;
        };
      }
    });
    
    // Override global objects if they exist
    if (typeof window.yooadmLegacyNotifications !== 'undefined') {
      window.yooadmLegacyNotifications = {
        disabled: true,
        message: 'Legacy notification system disabled'
      };
    }
    
    // Override banner conversion check
    if (typeof window.isBannerConversionEnabled !== 'undefined') {
      window.isBannerConversionEnabled = function() {
        return false;
      };
    }
  }

  // ---------------- Remove Legacy Event Listeners ----------------
  function removeLegacyEventListeners() {
    // Remove any legacy notification event listeners
    var legacyElements = [
      '.yp-legacy-notification',
      '[data-yp-legacy]',
      '.yp-banner-conversion'
    ];
    
    legacyElements.forEach(function(selector) {
      var elements = document.querySelectorAll(selector);
      elements.forEach(function(element) {
        // Clone element to remove all event listeners
        var clone = element.cloneNode(true);
        element.parentNode.replaceChild(clone, element);
      });
    });
  }

  // ---------------- Clean Up Legacy Data ----------------
  function cleanupLegacyData() {
    // Remove legacy data attributes
    var legacyElements = document.querySelectorAll('[data-yp-notification-converted]');
    legacyElements.forEach(function(element) {
      element.removeAttribute('data-yp-notification-converted');
      element.removeAttribute('data-yp-banner-restored');
    });
    
    // Keep yp-convert-banners-enabled — required for banner→notification CSS (not legacy).
  }

  // ---------------- Initialize ----------------
  function init() {
    // Check if already initialized
    if (window.__YPLegacyInitialized) return;
    window.__YPLegacyInitialized = true;
    
    disableLegacyNotifications();
    removeLegacyEventListeners();
    cleanupLegacyData();
  }

  // Run when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
