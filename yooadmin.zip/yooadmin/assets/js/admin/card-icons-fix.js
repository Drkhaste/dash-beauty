/**
 * YOOAdmin - Card SVG icons fix (mask/color)
 *
 * @package YOOAdmin
 */
(function() {
    'use strict';

    function convertSvgImagesToMask() {
        // NEVER convert inline SVG elements - they should stay as SVG
        // Only convert <img> tags, and skip any marked with ypi-skip-mask class
        const svgImages = document.querySelectorAll('.yp-icon img[src*=".svg"]:not(.ypi-converted):not(.ypi-skip-mask), .yp-icon img[src*="data:image/svg"]:not(.ypi-converted):not(.ypi-skip-mask)');
        
        // Also skip any inline SVG elements (they should never be converted)
        const inlineSvgs = document.querySelectorAll('.yp-icon > svg.ypi-skip-mask');
        inlineSvgs.forEach(svg => {
            svg.classList.add('ypi-converted');
        });
        
        svgImages.forEach(img => {
            const src = img.getAttribute('src');
            if (!src) return;
            
            // Skip ALL data URI SVGs - NEVER convert them to mask-image
            // Data URI SVGs should be displayed as inline SVG or regular img, not mask
            // This prevents size issues and keeps them like normal WordPress icons
            if (src.indexOf('data:image/svg+xml') === 0) {
                img.classList.add('ypi-converted');
                img.classList.add('ypi-skip-mask'); // Mark to prevent future conversion
                return;
            }
            
            // Skip if parent already has ypi-wp-bg or ypi-wp-img class
            const parent = img.parentElement;
            if (parent && (parent.classList.contains('ypi-wp-bg') || parent.classList.contains('ypi-wp-img'))) {
                return;
            }
            
            // Skip if image already has proper styling classes
            if (img.classList.contains('ypi-wp-img') || img.classList.contains('ypi-wp-bg')) {
                return;
            }
            
            // Only convert images that are likely white/problematic
            const srcLower = src.toLowerCase();
            const isWhiteIcon = srcLower.includes('white') || srcLower.includes('-light');
            const isProblematicPlugin = srcLower.includes('js_composer') || 
                                       srcLower.includes('wpbakery') || 
                                       srcLower.includes('vc/logo') ||
                                       srcLower.includes('wpb-logo');
            
            // If it's not a problematic icon, skip it
            if (!isWhiteIcon && !isProblematicPlugin) {
                img.classList.add('ypi-converted');
                return;
            }
            
            // Create a wrapper span
            const wrapper = document.createElement('span');
            wrapper.className = 'ypi-wp-bg';
            wrapper.style.cssText = `
                display: inline-block;
                width: var(--yp-card-icon-size);
                height: var(--yp-card-icon-size);
                margin-bottom: 13px;
                vertical-align: middle;
                background-color: var(--_yp-primary, var(--yp-card-icon-color, var(--yp-primary, #0d6efd)));
                -webkit-mask-image: url('${src}');
                mask-image: url('${src}');
                -webkit-mask-repeat: no-repeat;
                mask-repeat: no-repeat;
                -webkit-mask-position: center;
                mask-position: center;
                -webkit-mask-size: contain;
                mask-size: contain;
            `;
            
            // Replace img with wrapper
            img.parentNode.replaceChild(wrapper, img);
        });
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', convertSvgImagesToMask);
    } else {
        convertSvgImagesToMask();
    }

    // Run once more after a short delay to catch dynamically loaded content
    setTimeout(convertSvgImagesToMask, 500);
    
    // Watch for new images being added with debouncing
    if (typeof MutationObserver !== 'undefined') {
        let debounceTimer = null;
        const observer = new MutationObserver(function(mutations) {
            let shouldRun = false;
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length > 0) {
                    shouldRun = true;
                }
            });
            if (shouldRun) {
                // Debounce: only run after 200ms of no changes
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(convertSvgImagesToMask, 200);
            }
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
})();
