/**
 * YOOAdmin - Admin bar focus toggle modal
 *
 * @package YOOAdmin
 */

(function ($) {
    'use strict';

    var cfg = window.yooadminAdminBarFocus || {};
    var MODAL_ID = 'yoo-admin-bar-focus-modal';
    var MODAL_SEL = '#' + MODAL_ID;

    function ajaxUrl() {
        return cfg.ajaxUrl || window.ajaxurl || '';
    }

    function $modal() {
        return $(MODAL_SEL);
    }

    function portalModalToBody() {
        var el = document.getElementById(MODAL_ID);
        if (el && el.parentNode !== document.body) {
            document.body.appendChild(el);
        }
    }

    function openModal() {
        var $m = $modal();
        if (!$m.length) {
            return;
        }

        portalModalToBody();
        $m.removeAttr('hidden').addClass('ywp-visible').attr('aria-hidden', 'false');
        $('body').addClass('yp-modal-open yoo-focus-modal-open');
    }

    function closeModal() {
        var $m = $modal();
        if (!$m.length) {
            return;
        }

        $m.removeClass('ywp-visible').attr('aria-hidden', 'true').attr('hidden', 'hidden');
        $('body').removeClass('yp-modal-open yoo-focus-modal-open');
    }

    function postToggle(data, onSuccess) {
        var url = ajaxUrl();
        if (!url) {
            return;
        }

        $.ajax({
            url: url,
            type: 'POST',
            data: data,
            success: onSuccess,
            error: function () {
                window.alert('Failed to toggle Focus Mode');
            }
        });
    }

    function handleToggleSuccess(response, $btn, confirmLabel) {
        if (response.success) {
            if (response.data && response.data.redirect) {
                window.location.href = response.data.redirect;
                return;
            }

            if (cfg.focusHomeUrl && String($btn.data('enable')) === '1') {
                window.location.href = cfg.focusHomeUrl;
                return;
            }

            window.location.reload();
            return;
        }

        closeModal();
        $btn.prop('disabled', false).text(confirmLabel);

        var message = response.data && response.data.message ? response.data.message : 'Failed to toggle Focus Mode';
        var code = response.data && response.data.code ? response.data.code : '';

        if (code === 'policy_off_user' && window.yooadmAlerts && window.yooadmAlerts.showPolicyDisabledAlert) {
            window.yooadmAlerts.showPolicyDisabledAlert(function () {
                postToggle({
                    action: 'yooadmin_admin_bar_toggle_focus',
                    nonce: $btn.data('nonce'),
                    scope: 'all',
                    enable: '1',
                    current_url: window.location.href
                }, function (res) {
                    handleToggleSuccess(res, $btn, confirmLabel);
                });
            });
            return;
        }

        window.alert(message);
    }

    $(document).on('click', '#wp-admin-bar-yooadmin-focus-toggle, #wp-admin-bar-yooadmin-focus-toggle .ab-item, #wp-admin-bar-yooadmin-focus-toggle a', function (e) {
        e.preventDefault();
        e.stopPropagation();
        openModal();
    });

    $(document).on('click', MODAL_SEL, function (e) {
        if (e.target === this) {
            closeModal();
        }
    });

    $(document).on('click', MODAL_SEL + ' .yoo-focus-modal-close, ' + MODAL_SEL + ' .yoo-focus-modal-cancel, ' + MODAL_SEL + ' .yoo-focus-modal-dismiss', function (e) {
        e.preventDefault();
        closeModal();
    });

    $(document).on('click', MODAL_SEL + ' .ywp-dialog', function (e) {
        e.stopPropagation();
    });

    $(document).on('keydown', function (e) {
        if (e.key === 'Escape' && $modal().hasClass('ywp-visible')) {
            closeModal();
        }
    });

    $(document).on('click', MODAL_SEL + ' .yoo-focus-modal-confirm', function () {
        var $btn = $(this);
        var scope = $(MODAL_SEL + ' input[name="focus_scope"]:checked').val() || 'user';
        var enable = String($btn.data('enable')) === '1' ? '1' : '0';
        var nonce = $btn.data('nonce');
        var confirmLabel = $btn.text();
        var processingLabel = cfg.processing || 'Processing...';

        if (!ajaxUrl()) {
            return;
        }

        $btn.prop('disabled', true).text(processingLabel);

        if (enable === '0') {
            try {
                sessionStorage.removeItem('yooadminFocusTransition');
            } catch (e) {
                /* ignore */
            }
        }

        postToggle({
            action: 'yooadmin_admin_bar_toggle_focus',
            nonce: nonce,
            scope: scope,
            enable: enable,
            current_url: window.location.href
        }, function (response) {
            handleToggleSuccess(response, $btn, confirmLabel);
        });
    });
})(jQuery);
