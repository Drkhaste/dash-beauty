/* global yooadminShellThemes */
(function ($) {
  'use strict';

  var cfg = window.yooadminShellThemes || {};
  var ajaxUrl = cfg.ajaxurl || '';
  var activateNonce = cfg.activateNonce || '';
  var i18n = cfg.i18n || {};

  function t(key, fallback) {
    return i18n[key] != null ? String(i18n[key]) : fallback;
  }

  function escAttr(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function showNotice(type, message) {
    var cls = type === 'error' ? 'notice-error' : 'notice-success';
    var $n = $('<div class="notice ' + cls + ' is-dismissible"><p></p></div>');
    $n.find('p').text(message);
    var $anchor = $('.yooadmin-shell-notice-anchor').first();
    if (!$anchor.length) {
      $anchor = $('.yooadmin-admin-themes-wrap').first();
    }
    $anchor.empty().append($n);
    window.setTimeout(function () {
      $n.fadeOut(300, function () {
        $n.remove();
      });
    }, 6000);
  }

  function actionsBarHtml(slug, isActive, builtin, settingsUrl) {
    var parts = [];
    if (!isActive) {
      parts.push(
        '<button type="button" class="yoo-media-float-btn yoo-install-btn yooadmin-shell-theme-activate" data-slug="' +
          escAttr(slug) +
          '" title="' +
          escAttr(t('activate', 'Activate')) +
          '" aria-label="' +
          escAttr(t('activate', 'Activate')) +
          '"><span class="dashicons dashicons-yes" aria-hidden="true"></span></button>'
      );
    } else {
      parts.push(
        '<a class="yoo-media-float-btn yoo-theme-customize" href="' +
          escAttr(settingsUrl) +
          '" title="' +
          escAttr(t('adjustSettings', 'Adjust settings')) +
          '" aria-label="' +
          escAttr(t('adjustSettings', 'Adjust settings')) +
          '"><span class="dashicons dashicons-admin-generic" aria-hidden="true"></span></a>'
      );
    }
    if (!builtin && !isActive) {
      var delNonce = (cfg.deleteNonces && cfg.deleteNonces[slug]) || '';
      parts.push(
        '<form method="post" action="' +
          escAttr(cfg.adminPostUrl || '') +
          '" class="yooadmin-shell-theme-inline-form" data-yooadmin-shell-delete-form="1">' +
          '<input type="hidden" name="_wpnonce" value="' +
          escAttr(delNonce) +
          '" />' +
          '<input type="hidden" name="action" value="' +
          escAttr(cfg.deleteAction || '') +
          '" />' +
          '<input type="hidden" name="theme_slug" value="' +
          escAttr(slug) +
          '" />' +
          '<button type="submit" class="yoo-media-float-btn danger yoo-delete-btn" title="' +
          escAttr(t('delete', 'Delete')) +
          '" aria-label="' +
          escAttr(t('delete', 'Delete')) +
          '"><span class="dashicons dashicons-trash" aria-hidden="true"></span></button></form>'
      );
    }
    return '<div class="yoo-theme-card__actions-overlay"><div class="yoo-theme-card__actions-bar">' + parts.join('') + '</div></div>';
  }

  function updateTagsHover($card, isActive) {
    var $tags = $card.find('.yoo-theme-card-top-tags').first();
    $tags.toggleClass('yoo-theme-card-top-tags--inactive-hover-only', !isActive);
  }

  function syncCardsAfterActivate(newSlug) {
    var settingsUrl = cfg.settingsUrl || '';
    $('#wp-results .yoo-plugin-card.yoo-theme-card').each(function () {
      var $card = $(this);
      var slug = $card.attr('data-yooadmin-shell-theme-slug');
      var builtin = $card.attr('data-builtin') === '1';
      var isActive = slug === newSlug;
      $card.toggleClass('active', isActive);
      var $pill = $card.find('.yoo-theme-status-tag__pill');
      $pill.toggleClass('yoo-theme-status-tag__pill--active', isActive);
      $pill.toggleClass('yoo-theme-status-tag__pill--inactive', !isActive);
      $pill.text(isActive ? t('active', 'Active') : t('inactive', 'Inactive'));
      updateTagsHover($card, isActive);
      $card.find('.yoo-theme-card__actions-overlay').remove();
      $card.find('.yoo-theme-card-media-wrap').append(actionsBarHtml(String(slug), isActive, builtin, settingsUrl));
    });
    bindDeleteForms();
  }

  function bindDeleteForms() {
    $('form[data-yooadmin-shell-delete-form="1"]').off('submit.yooShell').on('submit.yooShell', function (e) {
      if (!window.confirm(t('deleteConfirm', 'Delete this admin theme?'))) {
        e.preventDefault();
      }
    });
  }

  $(function () {
    bindDeleteForms();

    $('#wp-results').on('click', '.yooadmin-shell-theme-activate', function () {
      var $btn = $(this);
      var slug = $btn.data('slug') || $btn.attr('data-slug');
      if (!slug || !ajaxUrl || !activateNonce) {
        return;
      }
      $btn.prop('disabled', true);
      $.post(ajaxUrl, {
        action: 'yooadmin_shell_theme_activate',
        nonce: activateNonce,
        theme_slug: slug
      })
        .done(function (res) {
          if (res && res.success) {
            showNotice('success', (res.data && res.data.message) || t('activated', 'Theme activated successfully.'));
            window.setTimeout(function () {
              window.location.reload();
            }, 450);
          } else {
            var m = res && res.data && res.data.message ? res.data.message : t('activateFail', 'Could not activate theme.');
            showNotice('error', m);
          }
        })
        .fail(function () {
          showNotice('error', t('activateFail', 'Could not activate theme.'));
        })
        .always(function () {
          $btn.prop('disabled', false);
        });
    });
  });
})(jQuery);
