/**
 * YOOAdmin - My Preferences page (tabs + AJAX save)
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    function initTabs() {
        var $wrap = $('[data-yp-tabs]');
        if (!$wrap.length) {
            return;
        }

        var $nav = $wrap.find('.yp-tab-nav').first();
        if (!$nav.length) {
            return;
        }

        var ink = $nav.find('.yp-tab-ink')[0];
        if (!ink) {
            ink = document.createElement('span');
            ink.className = 'yp-tab-ink';
            $nav[0].appendChild(ink);
        }

        function moveInk($btn) {
            var r = $btn[0].getBoundingClientRect();
            var rn = $nav[0].getBoundingClientRect();
            ink.style.width = r.width + 'px';
            ink.style.left = (r.left - rn.left) + 'px';
        }

        function activate($btn, updateHash) {
            var key = $btn.data('tab');
            if (!key) {
                return;
            }

            $btn.addClass('is-active').attr('aria-selected', 'true')
                .siblings('.yp-tab').removeClass('is-active').attr('aria-selected', 'false');

            $wrap.find('.yp-tab-panel').removeClass('is-active');
            $wrap.find('.yp-tab-panel[data-panel="' + key + '"]').addClass('is-active');

            moveInk($btn);

            if (updateHash !== false) {
                var newHash = '#tab-' + key;
                if (window.location.hash !== newHash) {
                    window.history.pushState(null, '', newHash);
                }
            }
        }

        $wrap.on('click', '.yp-tab', function() {
            activate($(this), true);
        });

        var $current = $wrap.find('.yp-tab.is-active').first();
        if (!$current.length) {
            var hash = (window.location.hash || '').replace('#', '');
            var targetKey = null;
            if (hash.indexOf('tab-') === 0) {
                targetKey = hash.replace('tab-', '');
            } else if (hash) {
                targetKey = hash;
            }
            if (!targetKey) {
                var params = new URLSearchParams(window.location.search);
                if (params.has('tab')) {
                    targetKey = params.get('tab');
                }
            }
            if (targetKey) {
                $current = $wrap.find('.yp-tab[data-tab="' + targetKey + '"]').first();
            }
            if (!$current.length) {
                $current = $wrap.find('.yp-tab').first();
            }
        }
        if ($current.length) {
            activate($current, false);
        }

        function handleHashChange() {
            var hash = (window.location.hash || '').replace('#', '');
            if (!hash) {
                return;
            }
            var targetKey = hash.indexOf('tab-') === 0 ? hash.replace('tab-', '') : hash;
            if (!targetKey) {
                return;
            }
            var $targetTab = $wrap.find('.yp-tab[data-tab="' + targetKey + '"]').first();
            if ($targetTab.length) {
                activate($targetTab, false);
            }
        }

        $(window).on('hashchange', handleHashChange);
        setTimeout(function() {
            if (window.location.hash) {
                handleHashChange();
            }
        }, 100);

        $(window).on('resize', function() {
            var $active = $wrap.find('.yp-tab.is-active').first();
            if ($active.length) {
                moveInk($active);
            }
        });
    }

    function showNotice(message, type) {
        if (window.YOOAdminToast && typeof window.YOOAdminToast.show === 'function') {
            window.YOOAdminToast.show(message, type === 'error' ? 'error' : 'success');
            return;
        }
        $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>')
            .insertAfter('.yp-my-preferences .yp-titlebar')
            .delay(3000)
            .fadeOut(function() {
                $(this).remove();
            });
    }

    $(document).ready(function() {
        initTabs();

        var config = window.yooadmNotifPrefs || {};

        $('#yp-preferences-form').on('submit', function(e) {
            e.preventDefault();

            var formData = $(this).serialize();

            $.ajax({
                url: window.ajaxurl,
                type: 'POST',
                data: formData + '&action=yooadmin_save_user_preferences&nonce=' + config.saveNonce,
                success: function(response) {
                    if (response.success) {
                        showNotice(config.savedMsg || 'Preferences saved successfully!', 'success');
                    } else {
                        showNotice((response.data && response.data.message) || 'Error', 'error');
                    }
                }
            });
        });

        $('#reset-preferences').on('click', function() {
            if (!confirm(config.confirmReset)) {
                return;
            }

            $.ajax({
                url: window.ajaxurl,
                type: 'POST',
                data: {
                    action: 'yooadmin_reset_user_preferences',
                    nonce: config.resetNonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        showNotice((response.data && response.data.message) || 'Error', 'error');
                    }
                }
            });
        });
    });
})(jQuery);
