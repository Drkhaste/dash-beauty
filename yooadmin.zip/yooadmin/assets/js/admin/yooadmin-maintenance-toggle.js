/**
 * Maintenance mode pill toggle (admin shell + frontend bar).
 */
(function ($) {
  'use strict';

  function getConfig() {
    if (window.yooadminMaintenanceToggle) {
      return window.yooadminMaintenanceToggle;
    }
    if (window.yooadmBar && window.yooadmBar.maintenanceToggle) {
      return window.yooadmBar.maintenanceToggle;
    }
    return null;
  }

  function setPillState($pill, on) {
    $pill.toggleClass('is-on', !!on).toggleClass('is-off', !on);
    var $input = $pill.find('.yooadmin-maintenance-pill__input');
    if ($input.length) {
      $input.prop('checked', !!on);
    }
    var label = on
      ? ($pill.data('titleOn') || '')
      : ($pill.data('titleOff') || '');
    var $toggleBtn = $pill.find('.yooadmin-maintenance-pill__toggle-btn');
    if (label && $toggleBtn.length) {
      $toggleBtn.attr('title', label).attr('aria-pressed', on ? 'true' : 'false');
    }
  }

  $(document).on('click', '.yooadmin-maintenance-pill__toggle-btn', function (e) {
    e.preventDefault();
    e.stopPropagation();

    var $btn = $(this);
    var $pill = $btn.closest('[data-yooadmin-maintenance-pill]');
    if (!$pill.length || $pill.hasClass('is-busy')) {
      return;
    }

    var $input = $pill.find('.yooadmin-maintenance-pill__input');
    if (!$input.length) {
      return;
    }

    $input.prop('checked', !$input.is(':checked')).trigger('change');
  });

  $(document).on('change', '.yooadmin-maintenance-pill__input', function (e) {
    e.stopPropagation();

    var cfg = getConfig();
    if (!cfg || !cfg.ajaxUrl || !cfg.nonce) {
      return;
    }

    var $input = $(this);
    var $pill = $input.closest('[data-yooadmin-maintenance-pill]');
    if (!$pill.length || $pill.hasClass('is-busy')) {
      return;
    }

    var wantOn = $input.is(':checked');
    var prevOn = !wantOn;

    $pill.addClass('is-busy');

    $.ajax({
      url: cfg.ajaxUrl,
      method: 'POST',
      dataType: 'json',
      data: {
        action: 'yooadmin_toggle_maintenance_mode',
        nonce: cfg.nonce,
        enabled: wantOn ? 1 : 0
      }
    })
      .done(function (response) {
        if (response && response.success && response.data) {
          var enabled = !!response.data.enabled;
          $('[data-yooadmin-maintenance-pill]').each(function () {
            setPillState($(this), enabled);
          });
          $('#wp-admin-bar-yooadmin-maintenance')
            .toggleClass('yooadmin-maintenance-ab-item--on', enabled)
            .toggleClass('yooadmin-maintenance-ab-item--off', !enabled);
          $(document).trigger('yooadmin:maintenance-mode-changed', [enabled]);
        } else {
          $input.prop('checked', prevOn);
          setPillState($pill, prevOn);
        }
      })
      .fail(function () {
        $input.prop('checked', prevOn);
        setPillState($pill, prevOn);
      })
      .always(function () {
        $pill.removeClass('is-busy');
      });
  });

  $(document).on('click', '.yooadmin-maintenance-pill__settings-link', function (e) {
    e.stopPropagation();
  });

  $(document).on('click', '#wpadminbar .yooadmin-maintenance-pill', function (e) {
    if ($(e.target).closest('.yooadmin-maintenance-pill__toggle-btn, .yooadmin-maintenance-pill__switch, .yooadmin-maintenance-pill__input').length) {
      e.stopPropagation();
      return;
    }
    if ($(e.target).closest('.yooadmin-maintenance-pill__settings-link').length) {
      e.stopPropagation();
    }
  });
})(jQuery);
