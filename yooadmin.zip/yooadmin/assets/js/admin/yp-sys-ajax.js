/**
 * YOOAdmin - Posts filter AJAX
 *
 * @package YOOAdmin
 */

document.addEventListener('DOMContentLoaded', function () {
  const filterForm = document.querySelector('.yp-posts-filters');
  const resultsContainer = document.querySelector('#yp-posts-results');

  if (!filterForm || !resultsContainer) return;

  const searchInput = filterForm.querySelector('input[name="s"]');
  let timeout = null;

  // Handle <select> filters
  filterForm.querySelectorAll('select').forEach(function (field) {
    field.addEventListener('change', function () {
      const formData = new FormData(filterForm);
      formData.append('action', 'yooadmin_filter_posts');

      fetch(ajaxurl, {
        method: 'POST',
        body: formData
      })
        .then(response => response.text())
        .then(html => {
          resultsContainer.innerHTML = html;
        });
    });
  });

  // Handle text search input
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      clearTimeout(timeout);

      const value = searchInput.value.trim();

      if (value.length >= 3 || value.length === 0) {
        timeout = setTimeout(() => {
          const formData = new FormData(filterForm);
          formData.append('action', 'yooadmin_filter_posts');

          fetch(ajaxurl, {
            method: 'POST',
            body: formData
          })
            .then(response => response.text())
            .then(html => {
              resultsContainer.innerHTML = html;
            });
        }, 400); // Delay while typing
      }
    });
  }

  // Prevent Enter from reloading the page
  filterForm.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      e.target.blur();
    }
  });
});
document.addEventListener('DOMContentLoaded', function () {
  const filterForm = document.querySelector('.yp-posts-filters');
  const resultsContainer = document.querySelector('#yp-posts-results');

  if (!filterForm || !resultsContainer) return;

  const searchInput = filterForm.querySelector('input[name="s"]');
  let timeout = null;

  // Filter when any select changes
  filterForm.querySelectorAll('select').forEach(function (field) {
    field.addEventListener('change', sendAjaxFilter);
  });

  // Filter while typing in the search field
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      clearTimeout(timeout);

      const value = searchInput.value.trim();
      if (value.length >= 3 || value.length === 0) {
        timeout = setTimeout(sendAjaxFilter, 400);
      }
    });
  }

  // Prevent Enter from reloading the page
  filterForm.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      e.target.blur();
    }
  });

  // Reset button
  const resetBtn = document.getElementById('yp-reset-filters');
  if (resetBtn) {
    resetBtn.addEventListener('click', function () {
      filterForm.reset();
      sendAjaxFilter();
    });
  }

  // Reload results via AJAX
  function sendAjaxFilter() {
    const formData = new FormData(filterForm);
    formData.append('action', 'yooadmin_filter_posts');

    fetch(ajaxurl, {
      method: 'POST',
      body: formData
    })
      .then(response => response.text())
      .then(html => {
        resultsContainer.innerHTML = html;
      });
  }
});
