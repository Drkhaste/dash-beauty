/**
 * YOOAdmin - Banner conversion fix
 *
 * @package YOOAdmin
 */

(function() {
  'use strict';

// Enhanced debugging for banner conversion (disabled in production)
window.ypDebugBannerConversion = function() {
  // Debug function disabled in production
};

// Prevent multiple banner conversions by checking timestamps
window.ypLastBannerConversion = 0;
window.ypOriginalConvertBanners = null;

// Hook into the original function if it exists
if (typeof window.convertAdminBannersToNotifications === 'function') {
  window.ypOriginalConvertBanners = window.convertAdminBannersToNotifications;
  
  window.convertAdminBannersToNotifications = function() {
    const now = Date.now();
    
    // Prevent running more than once every 2 seconds
    if (now - window.ypLastBannerConversion < 2000) {
      return;
    }
    
    window.ypLastBannerConversion = now;
    
    // Call original function
    return window.ypOriginalConvertBanners.apply(this, arguments);
  };
}

// Monitor for rapid changes in notification count
let lastNotificationCount = 0;
let notificationCountChanges = 0;

setInterval(() => {
  const currentCount = document.querySelectorAll('.yp-notification-item').length;
  
  if (currentCount !== lastNotificationCount) {
    notificationCountChanges++;
    lastNotificationCount = currentCount;
    
    // Reset counter if stable
    if (notificationCountChanges > 10) {
      notificationCountChanges = 0;
    }
  }
}, 1000);

})();
