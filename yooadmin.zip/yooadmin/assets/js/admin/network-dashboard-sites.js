(function () {
  'use strict';

  function collapseMore(more) {
    if (!more) {
      return;
    }
    more.classList.remove('is-expanded');
    var toggle = more.querySelector('.yp-network-sites-card__actions-toggle');
    if (toggle) {
      toggle.setAttribute('aria-expanded', 'false');
    }
    var item = more.closest('.yp-network-sites-card__item');
    if (item) {
      item.classList.remove('is-actions-expanded');
    }
  }

  function collapseAllExcept(except) {
    document.querySelectorAll('.yp-network-sites-card__actions-more.is-expanded').forEach(function (more) {
      if (more !== except) {
        collapseMore(more);
      }
    });
  }

  function cfg(key, fallback) {
    var c = window.yooNetworkSitesConfirm || {};
    return c[key] !== undefined && c[key] !== '' ? c[key] : fallback;
  }

  function showToast(message, type) {
    var toastType = type || 'success';
    if (
      window.yooadmNotificationsUi &&
      typeof window.yooadmNotificationsUi.showToastMessage === 'function'
    ) {
      window.yooadmNotificationsUi.showToastMessage(message, toastType);
      return;
    }

    var toast = document.createElement('div');
    toast.className = 'yp-toast-message yp-toast-' + toastType + ' yoo-network-sites-toast';
    toast.setAttribute('role', 'status');
    toast.innerHTML =
      '<span class="yp-toast-icon" aria-hidden="true"></span>' +
      '<span class="yp-toast-text"></span>';
    toast.querySelector('.yp-toast-text').textContent = message;
    document.body.appendChild(toast);
    window.requestAnimationFrame(function () {
      toast.classList.add('yp-toast-show');
    });
    window.setTimeout(function () {
      toast.classList.remove('yp-toast-show');
      window.setTimeout(function () {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3200);
  }

  function findSiteRow(siteId, link) {
    if (siteId) {
      var byId = document.querySelector('[data-yoo-site-id="' + String(siteId) + '"]');
      if (byId) {
        return byId;
      }
    }
    if (link) {
      return link.closest('.yp-network-sites-card__item');
    }
    return null;
  }

  function patchSiteRow(row, data) {
    if (!row || !data) {
      return;
    }

    if (data.removed) {
      row.parentNode.removeChild(row);
      return;
    }

    if (typeof data.status_tags_html === 'string') {
      var title = row.querySelector('.yp-network-sites-card__title');
      if (title) {
        var statusWrap = title.querySelector('[data-yoo-site-status]');
        if (statusWrap) {
          statusWrap.remove();
        }
        if (data.status_tags_html) {
          title.insertAdjacentHTML('beforeend', data.status_tags_html);
        }
      }
    }

    if (typeof data.actions_html === 'string') {
      var actions =
        row.querySelector('.yp-network-sites-card__actions') ||
        row.querySelector('.yp-network-sites-card__actions-wrap .yp-network-sites-card__actions');
      if (actions) {
        actions.outerHTML = data.actions_html;
      }
    }
  }

  function parseAjaxResponse(response) {
    return response.text().then(function (text) {
      var trimmed = (text || '').trim();
      if (trimmed === '-1' || trimmed === '0') {
        throw new Error(cfg('errorGeneric', 'Something went wrong. Please try again.'));
      }

      if (!trimmed) {
        throw new Error(cfg('errorGeneric', 'Something went wrong. Please try again.'));
      }

      var json;
      try {
        json = JSON.parse(trimmed);
      } catch (parseErr) {
        throw new Error(cfg('errorGeneric', 'Something went wrong. Please try again.'));
      }

      if (!json || !json.success) {
        var errMsg =
          json && json.data && json.data.message
            ? json.data.message
            : cfg('errorGeneric', 'Something went wrong. Please try again.');
        throw new Error(errMsg);
      }

      return json.data || {};
    });
  }

  function postSiteAction(payload) {
    var ajaxUrl = cfg('ajaxUrl', typeof ajaxurl !== 'undefined' ? ajaxurl : '');
    if (!ajaxUrl) {
      return Promise.reject(new Error('missing_ajax_url'));
    }

    var body = new FormData();
    body.append('action', cfg('ajaxAction', 'yooadmin_network_sites_action'));
    body.append('nonce', cfg('ajaxNonce', ''));

    Object.keys(payload).forEach(function (key) {
      var value = payload[key];
      if (value === undefined || value === null) {
        return;
      }
      if (Array.isArray(value)) {
        value.forEach(function (item) {
          body.append(key + '[]', item);
        });
        return;
      }
      body.append(key, value);
    });

    return fetch(ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      body: body
    }).then(function (response) {
      if (!response.ok) {
        throw new Error(cfg('errorGeneric', 'Something went wrong. Please try again.'));
      }
      return parseAjaxResponse(response);
    });
  }

  function runSiteAction(action, id, nonce, link) {
    if (!action || !id || !nonce) {
      return Promise.reject(new Error('missing_params'));
    }

    return postSiteAction({
      site_action: action,
      id: id,
      site_nonce: nonce
    }).then(function (data) {
      var row = findSiteRow(id, link);
      if (row) {
        patchSiteRow(row, data);
      } else if (link && link.closest('.yoo-network-site-editor-manage-actions')) {
        if (data.removed) {
          var redirectUrl = cfg('referer', '');
          if (redirectUrl) {
            window.location.href = redirectUrl;
            return data;
          }
        }
        window.location.reload();
      }
      collapseAllExcept(null);
      showToast(data.message || cfg('confirm', 'Done'), data.notice_type || 'success');
      return data;
    });
  }

  function buildConfirmMessage(link) {
    var message = link.getAttribute('data-yoo-site-confirm-message') || '';
    var notice = link.getAttribute('data-yoo-site-confirm-notice') || '';
    if (notice) {
      message = message + '\n\n' + notice;
    }
    return message;
  }

  function handleConfirmClick(event) {
    var link = event.target.closest('[data-yoo-site-confirm-action]');
    if (!link) {
      return;
    }

    event.preventDefault();
    event.stopPropagation();

    var action = link.getAttribute('data-yoo-site-confirm-action') || '';
    var id = link.getAttribute('data-yoo-site-confirm-id') || '';
    var nonce = link.getAttribute('data-yoo-site-confirm-nonce') || '';
    var message = buildConfirmMessage(link);
    var confirmLabel = link.getAttribute('data-yoo-site-confirm-label') || cfg('confirm', 'Confirm');

    function onConfirm() {
      return runSiteAction(action, id, nonce, link).catch(function (err) {
        showToast(err.message || cfg('errorGeneric', 'Something went wrong. Please try again.'), 'error');
        throw err;
      });
    }

    if (typeof window.yooadminConfirmDialog === 'function') {
      window.yooadminConfirmDialog({
        title: cfg('confirmTitle', 'Confirm action'),
        message: message,
        cancelLabel: cfg('cancel', 'Cancel'),
        confirmLabel: confirmLabel,
        onConfirm: onConfirm
      });
      return;
    }

    if (window.confirm(message)) {
      onConfirm();
    }
  }

  document.addEventListener('click', function (event) {
    var toggle = event.target.closest('.yp-network-sites-card__actions-toggle');
    if (toggle) {
      event.preventDefault();
      event.stopPropagation();

      var more = toggle.closest('.yp-network-sites-card__actions-more');
      if (!more) {
        return;
      }

      var expanded = toggle.getAttribute('aria-expanded') === 'true';
      if (expanded) {
        collapseMore(more);
        return;
      }

      collapseAllExcept(more);
      more.classList.add('is-expanded');
      toggle.setAttribute('aria-expanded', 'true');
      var item = more.closest('.yp-network-sites-card__item');
      if (item) {
        item.classList.add('is-actions-expanded');
      }
      return;
    }

    if (event.target.closest('[data-yoo-site-confirm-action]')) {
      handleConfirmClick(event);
      return;
    }

    if (!event.target.closest('.yp-network-sites-card__actions-more')) {
      collapseAllExcept(null);
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      collapseAllExcept(null);
    }
  });
})();
