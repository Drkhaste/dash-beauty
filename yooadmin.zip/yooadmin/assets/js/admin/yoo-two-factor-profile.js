(function ($) {
  'use strict';

  var cfg = window.yooadminNative2FA || {};
  var lastBackupCodes = [];

  function post(action, data) {
    data = data || {};
    data.action = action;
    data.nonce = cfg.nonce || '';
    return $.post(cfg.ajaxUrl || ajaxurl, data);
  }

  function showStatus($el, message, isError) {
    if (!$el || !$el.length) {
      return;
    }
    $el.text(message || '');
    $el.toggleClass('is-error', !!isError);
  }

  function syncToggleLabels($root) {
    $root.find('.yoo-native-2fa__toggle-row input[type="checkbox"]').on('change', function () {
      var $state = $(this).closest('.yp-toggle-container').find('[data-yoo-2fa-state]');
      if (!$state.length) {
        return;
      }
      $state.text(
        this.checked
          ? (cfg.i18n && cfg.i18n.enabled) || 'Enabled'
          : (cfg.i18n && cfg.i18n.disabled) || 'Disabled'
      );
    });
  }

  function renderQr($container, uri) {
    if (!$container.length || !uri) {
      return;
    }

    $container.empty();

    if (typeof window.QRCode === 'function') {
      /* global QRCode */
      new QRCode($container[0], {
        text: uri,
        width: 168,
        height: 168,
        colorDark: '#1d2327',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M,
      });
      return;
    }

    $container.append(
      $('<p class="yoo-native-2fa__qr-fallback description"></p>').text(
        (cfg.i18n && cfg.i18n.qrUnavailable) || 'QR preview unavailable. Use the manual key below.'
      )
    );
  }

  function copyText(text) {
    if (!text) {
      return $.Deferred().reject().promise();
    }

    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    }

    var deferred = $.Deferred();
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', 'readonly');
    ta.style.position = 'absolute';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
      deferred.resolve();
    } catch (err) {
      deferred.reject(err);
    } finally {
      document.body.removeChild(ta);
    }
    return deferred.promise();
  }

  function showBackupToast(message, type) {
    if (!message) {
      return;
    }
    if (window.yooadmToast && typeof window.yooadmToast.show === 'function') {
      window.yooadmToast.show(message, type || 'success');
      return;
    }
    if (typeof window.yooadminShowToast === 'function') {
      window.yooadminShowToast(message, type || 'success');
    }
  }

  function renderBackupCodes(codes) {
    var $list = $('#yooadmin-2fa-backup-codes');
    var $actions = $('#yooadmin-2fa-backup-actions');
    var $notice = $('#yooadmin-2fa-backup-once-notice');

    lastBackupCodes = Array.isArray(codes) ? codes.slice() : [];
    $list.empty();

    if (!lastBackupCodes.length) {
      $list.prop('hidden', true);
      $actions.prop('hidden', true);
      $notice.prop('hidden', true);
      return;
    }

    lastBackupCodes.forEach(function (code) {
      $list.append($('<li class="yoo-native-2fa__backup-code"></li>').text(code));
    });

    $list.prop('hidden', false);
    $actions.prop('hidden', false);
    $notice.prop('hidden', false);
  }

  function backupCodesPlainText() {
    var warning = (cfg.i18n && cfg.i18n.codesWarning) || '';
    return warning + '\n\n' + lastBackupCodes.join('\n');
  }

  $(function () {
    var $root = $('#yooadmin-native-two-factor');
    if (!$root.length) {
      return;
    }

    syncToggleLabels($root);
    renderBackupCodes([]);

    function showTotpSetupPanel(res, options) {
      options = options || {};
      var $panel = $('#yooadmin-2fa-totp-panel');
      var $status = $('#yooadmin-2fa-totp-status');

      if (!res || !res.success || !res.data) {
        if (options.$status && options.$status.length) {
          showStatus(
            options.$status,
            (res && res.data && res.data.message) || (cfg.i18n && cfg.i18n.error) || 'Error',
            true
          );
        }
        return false;
      }

      showStatus($status, '', false);
      $('#yooadmin-2fa-totp-secret').text(res.data.secret || '');
      renderQr($('#yooadmin-2fa-totp-qrcode'), res.data.uri || '');
      $('#yooadmin-2fa-totp-code').val('');
      $panel.prop('hidden', false);

      if (options.$trigger && options.$trigger.length) {
        options.$trigger.attr('hidden', 'hidden');
      }
      if (options.$intro && options.$intro.length) {
        options.$intro.attr('hidden', 'hidden');
      }

      return true;
    }

    $('#yooadmin-2fa-setup-totp').on('click', function () {
      var $btn = $(this);
      var $status = $('#yooadmin-2fa-totp-status');

      showStatus($status, '', false);
      $btn.prop('disabled', true);

      post('yooadmin_2fa_setup_totp')
        .done(function (res) {
          showTotpSetupPanel(res, {
            $trigger: $btn,
            $status: $status,
          });
        })
        .fail(function () {
          showStatus($status, (cfg.i18n && cfg.i18n.error) || 'Error', true);
        })
        .always(function () {
          $btn.prop('disabled', false);
        });
    });

    $('#yooadmin-2fa-reset-totp').on('click', function () {
      var $btn = $(this);
      var $status = $('#yooadmin-2fa-reset-status');
      var $intro = $('#yooadmin-2fa-reset-intro');
      var currentCode = ($('#yooadmin-2fa-reset-current-code').val() || '').replace(/\s+/g, '');

      showStatus($status, '', false);
      $btn.prop('disabled', true);

      post('yooadmin_2fa_reset_totp', { current_code: currentCode })
        .done(function (res) {
          if (
            !showTotpSetupPanel(res, {
              $intro: $intro,
              $status: $status,
            })
          ) {
            return;
          }
          showStatus($status, '', false);
        })
        .fail(function (xhr) {
          var message = (cfg.i18n && cfg.i18n.error) || 'Error';
          if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
            message = xhr.responseJSON.data.message;
          }
          showStatus($status, message, true);
          $('#yooadmin-2fa-reset-current-code').val('').trigger('focus');
        })
        .always(function () {
          $btn.prop('disabled', false);
        });
    });

    $('#yooadmin-2fa-copy-secret').on('click', function () {
      var secret = ($('#yooadmin-2fa-totp-secret').text() || '').trim();
      copyText(secret).then(function () {
        var $btn = $('#yooadmin-2fa-copy-secret');
        var original = $btn.attr('title');
        $btn.attr('title', (cfg.i18n && cfg.i18n.copied) || 'Copied');
        window.setTimeout(function () {
          $btn.attr('title', original || '');
        }, 1600);
      });
    });

    $('#yooadmin-2fa-verify-totp').on('click', function () {
      var $status = $('#yooadmin-2fa-totp-status');
      var $input = $('#yooadmin-2fa-totp-code');
      var $btn = $(this);
      var code = ($input.val() || '').replace(/\s+/g, '');

      showStatus($status, '', false);
      $btn.prop('disabled', true);
      $input.prop('disabled', false);

      post('yooadmin_2fa_verify_totp', { code: code })
        .done(function (res) {
          if (!res || !res.success) {
            showStatus(
              $status,
              (res && res.data && res.data.message) || (cfg.i18n && cfg.i18n.error) || 'Error',
              true
            );
            $input.val('').trigger('focus');
            return;
          }
          showStatus($status, (res.data && res.data.message) || 'OK', false);
          window.setTimeout(function () {
            window.location.reload();
          }, 600);
        })
        .fail(function () {
          showStatus($status, (cfg.i18n && cfg.i18n.error) || 'Error', true);
          $input.val('').trigger('focus');
        })
        .always(function () {
          $btn.prop('disabled', false);
          $input.prop('disabled', false);
        });
    });

    $('#yooadmin-2fa-generate-backup').on('click', function () {
      var $btn = $(this);
      $btn.prop('disabled', true);
      post('yooadmin_2fa_generate_backup_codes')
        .done(function (res) {
          if (!res || !res.success || !res.data || !res.data.codes) {
            window.alert((cfg.i18n && cfg.i18n.error) || 'Error');
            return;
          }
          renderBackupCodes(res.data.codes);
          showBackupToast(
            (res.data && res.data.message) || (cfg.i18n && cfg.i18n.codesGenerated) || '',
            'success'
          );
        })
        .fail(function () {
          showBackupToast((cfg.i18n && cfg.i18n.error) || 'Error', 'error');
        })
        .always(function () {
          $btn.prop('disabled', false);
        });
    });

    $('#yooadmin-2fa-download-backup').on('click', function () {
      if (!lastBackupCodes.length) {
        return;
      }
      var blob = new Blob([backupCodesPlainText()], { type: 'text/plain;charset=utf-8' });
      var url = URL.createObjectURL(blob);
      var link = document.createElement('a');
      link.href = url;
      link.download = (cfg.i18n && cfg.i18n.downloadName) || 'yooadmin-recovery-codes.txt';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    });

    $('#yooadmin-2fa-copy-backup').on('click', function () {
      if (!lastBackupCodes.length) {
        return;
      }
      copyText(backupCodesPlainText());
    });

    function collectProviders() {
      var providers = [];
      $root.find('.yoo-native-2fa__toggle-row input[type="checkbox"]').each(function () {
        if (this.checked) {
          providers.push(String(this.value || ''));
        }
      });
      return providers;
    }

    function saveProvidersAjax($form, options) {
      options = options || {};
      var userId = parseInt($root.attr('data-user-id') || '0', 10) || 0;
      var $btn = options.$btn || $form.find('[type="submit"]').first();

      $btn.prop('disabled', true);

      return post('yooadmin_2fa_save_providers', {
        providers: JSON.stringify(collectProviders()),
        user_id: userId > 0 ? userId : '',
      })
        .always(function () {
          $btn.prop('disabled', false);
        });
    }

    function bindTwoFactorFormSubmit($form, options) {
      if (!$form.length) {
        return;
      }

      options = options || {};

      $form.on('submit', function (e) {
        if (!$root.length || $form.data('yoo2faBypass')) {
          return;
        }

        e.preventDefault();

        saveProvidersAjax($form, options)
          .done(function (res) {
            if (!res || !res.success) {
              window.alert(
                (res && res.data && res.data.message) || (cfg.i18n && cfg.i18n.error) || 'Error'
              );
              return;
            }

            var message =
              (res.data && res.data.message) || (cfg.i18n && cfg.i18n.saveSuccess) || 'Saved';
            showBackupToast(message, 'success');

            if (typeof options.onSuccess === 'function') {
              options.onSuccess($form, res);
            }
          })
          .fail(function () {
            window.alert((cfg.i18n && cfg.i18n.error) || 'Error');
          });
      });
    }

    bindTwoFactorFormSubmit($('#yoo-profile-security-form'), {
      onSuccess: function () {
        window.setTimeout(function () {
          var url = new URL(window.location.href);
          url.searchParams.set('profile_tab', 'security');
          url.searchParams.set('security_saved', '1');
          url.searchParams.delete('security_error');
          window.location.assign(url.toString());
        }, 350);
      },
    });

    bindTwoFactorFormSubmit($('#your-profile'), {
      onSuccess: function ($form) {
        $form.data('yoo2faBypass', true);
        if ($form[0] && typeof $form[0].submit === 'function') {
          $form[0].submit();
        }
      },
    });
  });
})(jQuery);
