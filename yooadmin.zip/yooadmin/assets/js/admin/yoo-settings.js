/**
 * YOOAdmin - Settings UI (live preview, AJAX save)
 *
 * @package YOOAdmin
 */

(function ($) {
  'use strict';

  /* ---------------- Utilities ---------------- */
  function applyVar(cssVar, value) {
    if (!cssVar) return;
    document.documentElement.style.setProperty(cssVar, value);
  }
  function hexToRgbTriplet(hex) {
    var h = String(hex || '').trim().replace(/^#/, '');
    if (h.length === 3) {
      h = h.split('').map(function (c) { return c + c; }).join('');
    }
    if (h.length !== 6) return '237,169,52';
    var r = parseInt(h.slice(0, 2), 16);
    var g = parseInt(h.slice(2, 4), 16);
    var b = parseInt(h.slice(4, 6), 16);
    if (!Number.isFinite(r) || !Number.isFinite(g) || !Number.isFinite(b)) return '237,169,52';
    return r + ',' + g + ',' + b;
  }
  function readVar(cssVar) {
    return getComputedStyle(document.documentElement).getPropertyValue(cssVar).trim();
  }
  function normalizeLogoUrl(url) {
    var u = String(url || '').trim();
    if (!u) {
      return '';
    }
    try {
      var parsed = new URL(u, window.location.href);
      parsed.searchParams.delete('_yooLogoPreview');
      return parsed.href;
    } catch (e) {
      return u.replace(/([?&])_yooLogoPreview=\d+/g, '').replace(/[?&]$/, '');
    }
  }
  function bustLogoPreviewUrl(url) {
    var u = String(url || '').trim();
    if (!u || u.indexOf('data:') === 0 || u.indexOf('blob:') === 0) {
      return u;
    }
    try {
      var parsed = new URL(u, window.location.href);
      parsed.searchParams.set('_yooLogoPreview', String(Date.now()));
      return parsed.href;
    } catch (e) {
      return u + (u.indexOf('?') >= 0 ? '&' : '?') + '_yooLogoPreview=' + Date.now();
    }
  }
  function getShellLogoLinks() {
    return document.querySelectorAll(
      '#yoo-admin-header-wrapper .yp-logo-link, #yoo-admin-header .yp-logo-link, .yp-header .yp-logo-link'
    );
  }
  function getHeaderLogoLinkEl() {
    var links = getShellLogoLinks();
    return links.length ? links[0] : null;
  }
  function getHeaderLogoEl() {
    var imgs = document.querySelectorAll(
      '#yoo-admin-header-wrapper img.yp-logo, #yoo-admin-header img.yp-logo, .yp-header img.yp-logo'
    );
    return imgs.length ? imgs[0] : null;
  }
  function applyLogoSrcToImg(img, url, options) {
    if (!img) {
      return;
    }
    options = options || {};
    var raw = String(url || '').trim();
    if (!raw) {
      return;
    }
    var normalized = normalizeLogoUrl(raw);
    var prevNorm = img.getAttribute('data-yoo-logo-normalized') || '';
    var unchanged = normalized === prevNorm && img.complete && img.naturalWidth > 0;
    if (unchanged && !options.force) {
      return;
    }
    var displayUrl = raw;
    if (normalized !== prevNorm || options.force) {
      displayUrl = bustLogoPreviewUrl(raw);
    } else if (img.getAttribute('src')) {
      displayUrl = img.getAttribute('src');
    }
    img.removeAttribute('srcset');
    img.removeAttribute('sizes');
    if (img.getAttribute('src') === displayUrl) {
      img.setAttribute('data-yoo-logo-normalized', normalized);
      return;
    }
    img.setAttribute('data-yoo-logo-normalized', normalized);
    img.src = displayUrl;
    img.style.display = '';
  }
  function ensureShellLogoImg(link, url) {
    if (!link) {
      return null;
    }
    var displayUrl = (typeof url === 'string' ? url : '').trim();
    if (!displayUrl) {
      displayUrl = getDefaultHeaderLogoUrl();
    }
    var img = link.querySelector('img.yp-logo');
    var text = link.querySelector('.yp-logo-text');
    if (!displayUrl) {
      if (img) {
        img.remove();
      }
      if (!text) {
        text = document.createElement('span');
        text.className = 'yp-logo-text';
        text.textContent = 'YOOAdmin';
        link.appendChild(text);
      }
      return null;
    }
    if (text) {
      text.remove();
    }
    if (!img) {
      img = document.createElement('img');
      img.className = 'yp-logo';
      img.alt = 'YOOAdmin Logo';
      var def = getDefaultHeaderLogoUrl();
      if (def) {
        img.setAttribute('data-default-src', def);
      }
      link.insertBefore(img, link.firstChild);
    }
    applyLogoSrcToImg(img, displayUrl);
    return img;
  }
  function setSidebarLogo(url) {
    var displayUrl = (typeof url === 'string' ? url : '').trim() || getDefaultHeaderLogoUrl();
    if (!displayUrl) {
      return;
    }
    document.querySelectorAll('#yps-sidebar .yps-side-logo').forEach(function (side) {
      var sideImg = side.querySelector('img');
      var title = side.querySelector('.yps-side-title');
      if (title) {
        title.remove();
      }
      if (!sideImg) {
        sideImg = document.createElement('img');
        sideImg.alt = '';
        side.appendChild(sideImg);
      }
      applyLogoSrcToImg(sideImg, displayUrl);
    });
  }
  function setFrontendBarLogo(url) {
    var displayUrl = (typeof url === 'string' ? url : '').trim() || getDefaultHeaderLogoUrl();
    if (!displayUrl) {
      return;
    }
    document.querySelectorAll('.yooadmin-bar-logo img').forEach(function (img) {
      applyLogoSrcToImg(img, displayUrl);
    });
  }
  function setHeaderLogo(url) {
    var displayUrl = (typeof url === 'string' ? url : '').trim();
    if (!displayUrl) {
      displayUrl = getDefaultHeaderLogoUrl();
    }
    getShellLogoLinks().forEach(function (link) {
      ensureShellLogoImg(link, displayUrl);
    });
    setSidebarLogo(displayUrl);
    setFrontendBarLogo(displayUrl);
  }
  var lastBrandingLogoNormalized = '';
  function applyBrandingLogoLive(url, options) {
    options = options || {};
    var displayUrl = (typeof url === 'string' ? url : '').trim() || getDefaultHeaderLogoUrl();
    var normalized = normalizeLogoUrl(displayUrl);
    if (!options.force && normalized === lastBrandingLogoNormalized) {
      return;
    }
    lastBrandingLogoNormalized = normalized;
    setHeaderLogo(displayUrl);
    if (options.force || !getHeaderLogoEl()) {
      requestAnimationFrame(function () {
        setHeaderLogo(displayUrl);
      });
    }
  }
  window.yooadminSetShellLogo = applyBrandingLogoLive;
  function getDefaultHeaderLogoUrl() {
    var fromConfig = (window.yooadmSettings && yooadmSettings.logoDefaultUrl) || '';
    if (fromConfig) return fromConfig;
    var img = getHeaderLogoEl();
    return (img && img.dataset && img.dataset.defaultSrc) ? img.dataset.defaultSrc : '';
  }
  function cssEscapeUrl(u) {
    return 'url("' + String(u || '').replace(/"/g, '\\"') + '")';
  }
  function getLoginLogoMaxCap() {
    var c = window.yooadmSettings && yooadmSettings.loginLogoMaxCap;
    c = parseInt(c, 10);
    return Number.isFinite(c) && c > 0 ? c : 268;
  }

  function setPreviewLogoImgs(lightUrl, darkUrl, maxW) {
    var light = (lightUrl || '').trim();
    var dark = (darkUrl || '').trim();
    if (!dark) {
      dark = light;
    }
    var cap = getLoginLogoMaxCap();
    var mw = (typeof maxW === 'number' && maxW > 0) ? Math.min(maxW, cap) : Math.min(120, cap);
    var eff = effectiveLoginColorMode(getLoginAppearanceMode());
    var showUrl = eff === 'dark' ? (dark || light) : (light || dark);

    document.querySelectorAll('.yooadmin-login-preview .ylp-logo-img--light').forEach(function (n) {
      n.src = light || '';
      n.style.display = light ? 'block' : 'none';
      n.style.maxWidth = mw + 'px';
    });
    document.querySelectorAll('.yooadmin-login-preview .ylp-logo-img--dark').forEach(function (n) {
      n.src = dark || '';
      n.style.display = dark ? 'block' : 'none';
      n.style.maxWidth = mw + 'px';
    });
    document.querySelectorAll('.yooadmin-login-preview .ylp-logo-img:not(.ylp-logo-img--light):not(.ylp-logo-img--dark)').forEach(function (n) {
      n.src = showUrl || '';
      n.style.display = showUrl ? 'block' : 'none';
      n.style.maxWidth = mw + 'px';
    });

    var root = getCoreLoginPreviewEl();
    if (root) {
      root.style.setProperty('--yoo-login-logo-max-w', mw + 'px');
      if (showUrl) {
        root.style.setProperty('--yoo-login-logo-url', cssEscapeUrl(showUrl));
      } else {
        root.style.setProperty('--yoo-login-logo-url', 'none');
      }
      if (light) {
        root.style.setProperty('--yoo-login-logo-url-light', cssEscapeUrl(light));
      } else {
        root.style.setProperty('--yoo-login-logo-url-light', 'none');
      }
      if (dark) {
        root.style.setProperty('--yoo-login-logo-url-dark', cssEscapeUrl(dark));
      } else {
        root.style.setProperty('--yoo-login-logo-url-dark', 'none');
      }
    }
    pushLoginPreviewToIframe();
  }

  function resolveBrandingLogoForLoginPreview(mode) {
    mode = mode === 'dark' ? 'dark' : 'light';
    var $brandingUrl = $('#yooadmin-logo-url');
    var url = '';
    if ($brandingUrl.length) {
      url = ($brandingUrl.val() || '').trim();
    } else if (window.yooadmSettings) {
      url = (yooadmSettings.logoUrl || '').trim();
    }
    if (!url && window.yooadmSettings) {
      url = mode === 'dark'
        ? (yooadmSettings.loginDefaultDarkLogoUrl || '').trim()
        : (yooadmSettings.loginDefaultLightLogoUrl || '').trim();
      if (!url) {
        url = (yooadmSettings.loginFormFallbackLogoUrl || '').trim();
      }
    }
    var cap = getLoginLogoMaxCap();
    var maxW = parseInt($('#yooadmin-logo-width').val(), 10);
    if (!Number.isFinite(maxW) && window.yooadmSettings) {
      maxW = yooadmSettings.logoW;
    }
    if (!Number.isFinite(maxW)) {
      maxW = (window.yooadmSettings && yooadmSettings.loginLogoMaxWDefault) || 220;
    }
    maxW = Math.min(Math.max(20, maxW), cap);
    return { url: url, maxW: maxW };
  }

  function resolveLoginPreviewLightLogo() {
    var $src = $('input[name="yooadmin_options[login_page_logo_source]"]:checked');
    var mode = ($src.length && $src.val()) || (window.yooadmSettings && yooadmSettings.loginPageLogoSource) || 'branding';
    var cap = getLoginLogoMaxCap();
    if (mode === 'custom') {
      var url = ($('#yooadmin-login-logo-url').val() || '').trim();
      var maxW = parseInt($('#yooadmin-login-logo-max-w').val(), 10);
      if (!Number.isFinite(maxW)) {
        maxW = parseInt($('#yooadmin-login-logo-max-w-post').val(), 10);
      }
      if (!Number.isFinite(maxW)) {
        maxW = (window.yooadmSettings && yooadmSettings.loginLogoMaxWDefault) || 220;
      }
      return { url: url, maxW: Math.min(maxW, cap) };
    }
    return resolveBrandingLogoForLoginPreview('light');
  }

  function resolveLoginPreviewDarkLogo(light) {
    light = light || resolveLoginPreviewLightLogo();
    var darkUrl = ($('#yooadmin-login-logo-dark-url').val() || '').trim();
    if (darkUrl) {
      return { url: darkUrl, maxW: light.maxW };
    }
    var logoMode = $('input[name="yooadmin_options[login_page_logo_source]"]:checked').val()
      || (window.yooadmSettings && yooadmSettings.loginPageLogoSource)
      || 'branding';
    if (logoMode === 'custom') {
      return light;
    }
    return resolveBrandingLogoForLoginPreview('dark');
  }

  function getLoginPreviewLogoScopes(doc) {
    if (!doc) {
      return [];
    }
    var scopes = [];
    var mini = doc.querySelector('.yooadmin-login-preview');
    if (mini) {
      scopes.push(mini);
    }
    if (doc.body && doc.body.classList.contains('yooadmin-login-standalone')) {
      scopes.push(doc.body);
    }
    if (!scopes.length && doc.body) {
      scopes.push(doc.body);
    }
    return scopes;
  }
  function syncLoginPreviewLogosToDocument(doc) {
    if (!doc) {
      return;
    }
    var light = resolveLoginPreviewLightLogo();
    var dark = resolveLoginPreviewDarkLogo(light);
    var lightUrl = (light.url || '').trim();
    var darkUrl = (dark.url || '').trim();
    var eff = effectiveLoginColorMode(getLoginAppearanceMode());
    var showUrl = eff === 'dark' ? (darkUrl || lightUrl) : (lightUrl || darkUrl);
    var mw = light.maxW || 220;
    var scopes = getLoginPreviewLogoScopes(doc);
    if (!scopes.length) {
      return;
    }

    scopes.forEach(function (scope) {
      scope.querySelectorAll('.ylp-logo-img--light, .yoo-sl-logo-img--light').forEach(function (n) {
        n.src = lightUrl || '';
        n.style.display = lightUrl ? 'block' : 'none';
        n.style.maxWidth = mw + 'px';
      });
      scope.querySelectorAll('.ylp-logo-img--dark, .yoo-sl-logo-img--dark').forEach(function (n) {
        n.src = darkUrl || '';
        n.style.display = darkUrl ? 'block' : 'none';
        n.style.maxWidth = mw + 'px';
      });
      scope.querySelectorAll('.ylp-logo-img:not(.ylp-logo-img--light):not(.ylp-logo-img--dark), .yoo-sl-logo-img:not(.yoo-sl-logo-img--light):not(.yoo-sl-logo-img--dark)').forEach(function (n) {
        n.src = showUrl || '';
        n.style.display = showUrl ? 'block' : 'none';
        n.style.maxWidth = mw + 'px';
      });
    });
  }

  function syncLoginPreviewLogo() {
    if (!document.querySelector('.yooadmin-login-preview')) {
      return;
    }
    var light = resolveLoginPreviewLightLogo();
    var dark = resolveLoginPreviewDarkLogo(light);
    setPreviewLogoImgs(light.url, dark.url, light.maxW);
    syncLoginPreviewLogosToDocument(document);
  }
  window.yooadminSyncLoginPreview = syncLoginPreviewLogo;

  /* Toast — same API as other YOOAdmin admin screens (yooadmToast). */
  function showToast(msg, type) {
    var message = msg || (yooadmSettings.i18n && yooadmSettings.i18n.saved) || 'Saved';
    type = type || 'success';

    if (window.yooadmToast) {
      if (type === 'error' && typeof window.yooadmToast.error === 'function') {
        window.yooadmToast.error(message);
        return;
      }
      if (type === 'success' && typeof window.yooadmToast.success === 'function') {
        window.yooadmToast.success(message);
        return;
      }
      if (typeof window.yooadmToast.show === 'function') {
        window.yooadmToast.show(message, type);
        return;
      }
    }

    if (typeof window.yooadminShowToast === 'function') {
      window.yooadminShowToast(message, type);
    }
  }

  window.yooadminSettingsToast = showToast;

  function refreshBreadcrumbsIconColors() {
    var bar = document.querySelector('.yp-breadcrumbs-bar');
    if (!bar) {
      return;
    }
    bar.querySelectorAll(
      '.yp-toolbar-icon, .yp-toolbar-icon .dashicons, .yp-toolbar-icon .ab-icon, ' +
        '.yp-toolbar-item .yp-toolbar-trigger, .yp-command-palette-trigger, ' +
        '.yp-command-palette-trigger__icon, .yp-command-palette-trigger .dashicons, ' +
        '.yp-bc-home-icon, .yp-bc-link .dashicons, .ysh-appearance__dash, .ysh-appearance__svg'
    ).forEach(function (node) {
      node.style.removeProperty('color');
      node.style.removeProperty('-webkit-text-fill-color');
    });
  }

  function syncBrandVarsFromPrimary() {
    var primary = readVar('--yooadmin-primary') || '#eda934';
    var brandRgb = hexToRgbTriplet(primary);
    applyVar('--yooadmin-brand', primary);
    applyVar('--yooadmin-brand-source', primary);
    applyVar('--ysh-brand', primary);
    applyVar('--yp-primary', primary);
    applyVar('--ysh-brand-rgb', brandRgb);
    applyVar('--yp-primary-rgb', brandRgb);
    applyVar('--yooadmin-link', primary);
    applyVar('--yooadmin-btn-bg-hover', primary);
    applyVar('--yooadmin-link-hover', primary);
    refreshBreadcrumbsIconColors();
    applyLoginPreviewVar('--yoo-login-primary', primary);
    applyLoginPreviewVar('--yoo-login-button-bg', primary);
    applyLoginPreviewVar('--yoo-login-link', primary);
    applyLoginPreviewVar('--yooadmin-primary', primary);
    applyLoginPreviewVar('--yooadmin-brand-source', primary);
    applyLoginPreviewVar('--yp-yoo-btn-primary', primary);
    /* Let CSS color-mix on .yooadmin-login-preview--core re-derive gradient stops. */
    var pr = getCoreLoginPreviewEl();
    if (pr) {
      pr.style.removeProperty('--yp-yoo-btn-primary-top');
      pr.style.removeProperty('--yp-yoo-btn-primary-hover');
      pr.style.removeProperty('--yp-yoo-btn-primary-hover-top');
      pr.style.removeProperty('--yp-yoo-btn-focus-ring');
    }
  }

  function getCoreLoginPreviewEl() {
    return document.querySelector('#yooadmin-core-login-preview');
  }

  /** Same as Extended: preview URL from PHP (reauth + yooadmin_lp + nonce) plus layout query args for iframe. */
  function buildLoginPreviewIframeSrc() {
    var loginUrl = (window.yooadmSettings && window.yooadmSettings.loginPreviewWpLogin) || '/wp-login.php';
    try {
      var u = new URL(loginUrl, window.location.href);
      if (u.search.indexOf('reauth=') === -1) {
        u.searchParams.set('reauth', '1');
      }
      var layout = ($('input.yooadmin-login-layout-input:checked').val() || (window.yooadmSettings && window.yooadmSettings.loginPageLayout) || 'split').toString();
      u.searchParams.set('yooadmin_lp_layout', layout);
      u.searchParams.set('yooadmin_lp_fs_v', ($('#yooadmin-login-fs-v').val() || 'middle').toString());
      u.searchParams.set('yooadmin_lp_fs_h', ($('#yooadmin-login-fs-h').val() || 'center').toString());
      u.searchParams.set('yooadmin_lp_effective', effectiveLoginColorMode(getLoginAppearanceMode()));
      return u.toString();
    } catch (e) {
      return loginUrl;
    }
  }

  function reloadLoginPreviewIframeIfOpen() {
    var modal = document.getElementById('yooadmin-core-login-preview-modal');
    if (!modal || !modal.classList.contains('is-open')) {
      return;
    }
    var iframe = modal.querySelector('.yp-modal__body iframe');
    if (!iframe) {
      return;
    }
    var next = buildLoginPreviewIframeSrc();
    if (iframe.src !== next) {
      var onLoaded = function () {
        iframe.removeEventListener('load', onLoaded);
        pushLoginPreviewToIframe();
      };
      iframe.addEventListener('load', onLoaded);
      iframe.src = next;
    }
  }

  function applyLoginPreviewVar(name, val) {
    var pr = getCoreLoginPreviewEl();
    if (!pr || !name) return;
    if (val === '' || val == null) {
      pr.style.removeProperty(name);
    } else {
      pr.style.setProperty(name, val);
    }
    pushLoginPreviewToIframe();
  }

  function syncLoginPreviewMedia() {
    var root = getCoreLoginPreviewEl();
    if (!root) return;
    var $url = $('#yooadmin-login-image-url');
    var $img = root.querySelector('.ylp-media-img');
    var inner = root.querySelector('.ylp-media-inner');
    if (!$img || !inner) return;
    var u = ($url.length ? $url.val() : '').trim();
    var bundled = (window.yooadmSettings && yooadmSettings.loginPreviewBundledBgUrl)
      ? String(yooadmSettings.loginPreviewBundledBgUrl).trim()
      : '';
    if (!u && bundled) {
      u = bundled;
    }
    if (u) {
      $img.src = u;
      $img.style.display = 'block';
      inner.classList.add('has-image');
    } else {
      $img.removeAttribute('src');
      $img.style.display = 'none';
      inner.classList.remove('has-image');
    }
    pushLoginPreviewToIframe();
  }

  function syncLoginPreviewSide() {
    var root = getCoreLoginPreviewEl();
    if (!root) return;
    var v = ($('#yooadmin-login-image-side').val() || 'left').toString();
    root.classList.remove('yoo-login-preview--media-left', 'yoo-login-preview--media-right');
    root.classList.add(v === 'right' ? 'yoo-login-preview--media-right' : 'yoo-login-preview--media-left');
    pushLoginPreviewToIframe();
  }

  function effectiveLoginColorMode(raw) {
    if (raw === 'auto') {
      try {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      } catch (e) {
        return 'light';
      }
    }
    return raw === 'dark' ? 'dark' : 'light';
  }

  function getLoginAppearanceMode() {
    var $input = $('#yooadmin-login-appearance-mode');
    if ($input.length) {
      return ($input.val() || 'auto').toString();
    }
    return (window.yooadmSettings && yooadmSettings.loginPageAppearanceMode) || 'auto';
  }

  var LOGIN_PREVIEW_CSS_VARS = [
    '--yoo-login-primary',
    '--yoo-login-panel-bg',
    '--yoo-login-media-bg',
    '--yoo-login-placeholder-color',
    '--yoo-login-text',
    '--yoo-login-input-bg',
    '--yoo-login-input-border',
    '--yoo-login-link',
    '--yoo-login-footer-text',
    '--yoo-login-card-shadow'
  ];

  function syncLoginPreviewColorMode(mode) {
    var raw = mode || getLoginAppearanceMode();
    if (raw !== 'light' && raw !== 'dark' && raw !== 'auto') {
      raw = 'auto';
    }
    var eff = effectiveLoginColorMode(raw);
    var root = getCoreLoginPreviewEl();
    if (root) {
      root.setAttribute('data-yoo-login-color-mode', raw);
    }
    document.documentElement.setAttribute('data-yoo-login-color-mode-effective', eff);

    var map = (window.yooadmSettings && (eff === 'dark' ? yooadmSettings.loginCssVarsDark : yooadmSettings.loginCssVarsLight)) || null;
    if (!map && window.yooadmSettings && yooadmSettings.loginCssVars) {
      map = yooadmSettings.loginCssVars;
    }
    if (root) {
      LOGIN_PREVIEW_CSS_VARS.forEach(function (k) {
        root.style.removeProperty(k);
      });
      if (map) {
        Object.keys(map).forEach(function (k) {
          root.style.setProperty(k, map[k]);
        });
      }
    }
    syncLoginPreviewLogo();
    pushLoginPreviewToIframe();
  }

  function applyLoginAppearanceMode(mode) {
    var normalized = (mode || 'auto').toString();
    if (normalized !== 'light' && normalized !== 'dark' && normalized !== 'auto') {
      normalized = 'auto';
    }
    var $hidden = $('#yooadmin-login-appearance-mode');
    if ($hidden.length) {
      $hidden.val(normalized);
    }
    document.querySelectorAll('#tab-login button[data-yooadmin-login-appearance]').forEach(function (btn) {
      var key = btn.getAttribute('data-yooadmin-login-appearance');
      var isActive = key === normalized;
      btn.classList.toggle('is-active', isActive);
      btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    });
    syncLoginPreviewColorMode(normalized);
    reloadLoginPreviewIframeIfOpen();
  }

  function initLoginAppearanceControls() {
    if (!document.getElementById('yooadmin-login-appearance-mode')) {
      return;
    }

    $(document).off('click.yooLoginAppearance', '#tab-login button[data-yooadmin-login-appearance]');
    $(document).on('click.yooLoginAppearance', '#tab-login button[data-yooadmin-login-appearance]', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var mode = this.getAttribute('data-yooadmin-login-appearance');
      applyLoginAppearanceMode(mode);
    });

    try {
      var mq = window.matchMedia('(prefers-color-scheme: dark)');
      var onSystemChange = function () {
        if (getLoginAppearanceMode() === 'auto') {
          syncLoginPreviewColorMode('auto');
          reloadLoginPreviewIframeIfOpen();
        }
      };
      if (mq.addEventListener) {
        mq.removeEventListener('change', onSystemChange);
        mq.addEventListener('change', onSystemChange);
      } else if (mq.addListener) {
        mq.removeListener(onSystemChange);
        mq.addListener(onSystemChange);
      }
    } catch (mediaErr) {}

    applyLoginAppearanceMode(getLoginAppearanceMode());
  }

  function applyLoginPreviewCssVarsFromTheme() {
    syncLoginPreviewColorMode(getLoginAppearanceMode());
  }

  function buildCoreLoginIframeVarCss() {
    var root = getCoreLoginPreviewEl();
    if (!root) {
      return 'body,body.yooadmin-login-custom,body.yooadmin-login-standalone{}';
    }
    var names = [
      '--yoo-login-primary',
      '--yoo-login-panel-bg',
      '--yoo-login-media-bg',
      '--yoo-login-placeholder-color',
      '--yoo-login-text',
      '--yoo-login-input-bg',
      '--yoo-login-input-border',
      '--yoo-login-link',
      '--yoo-login-button-bg',
      '--yoo-login-button-text',
      '--yooadmin-primary',
      '--yooadmin-brand-source',
      '--yp-yoo-btn-primary',
      '--yoo-login-logo-max-w',
      '--yoo-login-logo-url'
    ];
    var css = 'body,body.yooadmin-login-custom,body.yooadmin-login-standalone{';
    names.forEach(function (n) {
      var val = getComputedStyle(root).getPropertyValue(n).trim();
      if (val) {
        css += n + ':' + val + ';';
      }
    });
    css += '}';
    return css;
  }

  function pushLoginPreviewToIframe() {
    var modal = document.getElementById('yooadmin-core-login-preview-modal');
    if (!modal || !modal.classList.contains('is-open')) {
      return;
    }
    var iframe = modal.querySelector('.yp-modal__body iframe');
    if (!iframe) {
      return;
    }
    var doc = iframe.contentDocument;
    if (!doc || !doc.body) {
      return;
    }
    try {
      var style = doc.getElementById('yooadmin-core-login-iframe-vars');
      if (!style) {
        style = doc.createElement('style');
        style.id = 'yooadmin-core-login-iframe-vars';
        if (doc.head) {
          doc.head.appendChild(style);
        }
      }
      style.textContent = buildCoreLoginIframeVarCss();

      var iframeHtml = doc.documentElement;
      if (iframeHtml) {
        iframeHtml.setAttribute('data-yoo-login-color-mode', getLoginAppearanceMode());
        iframeHtml.setAttribute('data-yoo-login-color-mode-effective', effectiveLoginColorMode(getLoginAppearanceMode()));
      }

      var body = doc.body;
      var side = ($('#yooadmin-login-image-side').val() || 'left').toString();
      body.classList.remove('yoo-login--media-left', 'yoo-login--media-right');
      body.classList.add(side === 'right' ? 'yoo-login--media-right' : 'yoo-login--media-left');

      var pr = getCoreLoginPreviewEl();
      var logoVar = pr ? getComputedStyle(pr).getPropertyValue('--yoo-login-logo-url').trim() : '';
      if (!logoVar || logoVar === 'none') {
        body.classList.add('yoo-login--no-logo');
      } else {
        body.classList.remove('yoo-login--no-logo');
      }

      var u = ($('#yooadmin-login-image-url').val() || '').trim();
      var bundled = (window.yooadmSettings && yooadmSettings.loginPreviewBundledBgUrl)
        ? String(yooadmSettings.loginPreviewBundledBgUrl).trim()
        : '';
      if (!u && bundled) {
        u = bundled;
      }
      var media = doc.querySelector('.yoo-login-media');
      if (media) {
        media.classList.remove('yoo-login-media--has-image', 'yoo-login-media--no-image');
        var img = doc.querySelector('.yoo-login-media__img');
        if (u) {
          media.classList.add('yoo-login-media--has-image');
          if (img) {
            img.src = u;
            img.removeAttribute('srcset');
          } else {
            var wrap = doc.createElement('div');
            wrap.className = 'yoo-login-media__img-wrap';
            var nim = doc.createElement('img');
            nim.className = 'yoo-login-media__img';
            nim.setAttribute('alt', '');
            nim.src = u;
            wrap.appendChild(nim);
            media.insertBefore(wrap, media.firstChild);
          }
        } else {
          media.classList.add('yoo-login-media--no-image');
          var wrapEl = doc.querySelector('.yoo-login-media__img-wrap');
          if (wrapEl && wrapEl.parentNode) {
            wrapEl.parentNode.removeChild(wrapEl);
          }
        }
      }
      var wel = doc.querySelector('.yoo-login-welcome');
      if (wel) {
        if (u) {
          wel.classList.add('yoo-login-welcome--over-image');
        } else {
          wel.classList.remove('yoo-login-welcome--over-image');
        }
      }

      syncLoginPreviewLogosToDocument(doc);
    } catch (e) {
      /* cross-origin or blocked */
    }
  }

  function initCoreLoginPreviewUi() {
    var $modal = $('#yooadmin-core-login-preview-modal');
    var $body = $('#yooadmin-core-login-preview-modal-body');
    var $open = $('#yooadmin-core-login-preview-modal-open');
    if (!getCoreLoginPreviewEl()) {
      return;
    }
    if (!$modal.length) {
      applyLoginPreviewCssVarsFromTheme();
      syncLoginPreviewMedia();
      syncLoginPreviewSide();
      if (typeof window.yooadminSyncLoginPreview === 'function') {
        window.yooadminSyncLoginPreview();
      }
      return;
    }
    var modalEl = $modal[0];
    if (modalEl.parentNode !== document.body) {
      document.body.appendChild(modalEl);
    }

    function openModal() {
      $modal.attr('aria-hidden', 'false').addClass('is-open');
      $body.empty().addClass('is-loading');
      var $loading = $('<div class="yooadmin-core-login-modal-loading" role="status" aria-live="polite"><span class="spinner is-active"></span></div>');
      $body.append($loading);
      var loginUrl = buildLoginPreviewIframeSrc();
      var iframe = document.createElement('iframe');
      iframe.setAttribute('loading', 'eager');
      iframe.setAttribute('referrerpolicy', 'same-origin');
      iframe.src = loginUrl;
      iframe.setAttribute('frameborder', '0');
      iframe.style.width = '100%';
      iframe.style.height = '90vh';
      iframe.style.border = '0';
      $body.append(iframe);
      iframe.addEventListener('load', function () {
        $loading.remove();
        $body.removeClass('is-loading');
        pushLoginPreviewToIframe();
      });
      $('body').addClass('yp-modal-open yooadmin-core-login-modal-open');
    }

    function closeModal() {
      $modal.attr('aria-hidden', 'true').removeClass('is-open');
      $body.empty();
      $('body').removeClass('yp-modal-open yooadmin-core-login-modal-open');
    }

    $open.on('click', function (e) {
      e.preventDefault();
      openModal();
    });
    $(document).on('click', '[data-yooadmin-core-login-modal-close]', function (e) {
      e.preventDefault();
      closeModal();
    });
    $(document).on('keydown', function (e) {
      if (e.key === 'Escape' && $modal.hasClass('is-open')) {
        closeModal();
      }
    });

    $('#yooadmin-login-image-side').on('change', function () {
      syncLoginPreviewSide();
      reloadLoginPreviewIframeIfOpen();
    });

    applyLoginPreviewCssVarsFromTheme();
    syncLoginPreviewMedia();
    syncLoginPreviewSide();
    if (typeof window.yooadminSyncLoginPreview === 'function') {
      window.yooadminSyncLoginPreview();
    }
  }

  function initColorPickers() {
    $('.yooadmin-color-field').each(function () {
      var $input = $(this);
      var cssVar = $input.data('css-var');
      var loginVar = $input.data('login-var');

      $input.wpColorPicker({
        change: function (_event, ui) {
          var v = ui.color ? ui.color.toString() : $input.val();
          if (loginVar) applyLoginPreviewVar(loginVar, v);
          if (cssVar) applyVar(cssVar, v);
          if (cssVar === '--yooadmin-primary') {
            syncBrandVarsFromPrimary();
          }
        },
        clear: function () {
          var def = $input.data('default-color') || '';
          if (loginVar) applyLoginPreviewVar(loginVar, def);
          if (cssVar) applyVar(cssVar, def);
          if (cssVar === '--yooadmin-primary') {
            syncBrandVarsFromPrimary();
          }
        }
      });

      var initial = $input.val();
      if (initial && loginVar) applyLoginPreviewVar(loginVar, initial);
      else if (initial && cssVar) applyVar(cssVar, initial);
    });

    $('#yooadmin-preview-reset').on('click', function () {
      $('.yooadmin-color-field').each(function () {
        var $input = $(this);
        var cssVar = $input.data('css-var');
        var loginVar = $input.data('login-var');
        var def = $input.data('default-color') || '';
        $input.wpColorPicker('color', def);
        if (loginVar) applyLoginPreviewVar(loginVar, def);
        if (cssVar) applyVar(cssVar, def);
      });
      syncBrandVarsFromPrimary();
    });

    syncBrandVarsFromPrimary();
  }

  /* ---------------- Admin header logo controls ---------------- */
  var yooadminBrandingLogoFrame = null;

  function getBrandingLogoDefaults() {
    return {
      url: getDefaultHeaderLogoUrl(),
      width: (window.yooadmSettings && parseInt(yooadmSettings.logoDefaultW, 10)) || 150
    };
  }

  function syncBrandingLogoFromForm() {
    var url = ($('#yooadmin-logo-url').val() || '').trim();
    if (window.yooadmSettings) {
      yooadmSettings.logoUrl = url;
    }
    applyBrandingLogoLive(url || getBrandingLogoDefaults().url);
  }

  function onBrandingLogoMediaSelect() {
    if (!yooadminBrandingLogoFrame) {
      return;
    }
    var att = yooadminBrandingLogoFrame.state().get('selection').first().toJSON();
    var url = (att && att.url) || '';
    var $url = $('#yooadmin-logo-url');
    var $prev = $('#yooadmin-logo-preview');
    var $remove = $('#yooadmin-logo-remove');
    var defaults = getBrandingLogoDefaults();

    $url.val(url);
    if (window.yooadmSettings) {
      yooadmSettings.logoUrl = url;
    }
    if (url) {
      $prev.attr('src', url).show();
      $remove.show();
    } else {
      $prev.hide().attr('src', '');
      $remove.hide();
    }
    applyBrandingLogoLive(url || defaults.url, { force: true });
    if (typeof window.yooadminSyncLoginPreview === 'function') {
      window.yooadminSyncLoginPreview();
    }
    if (typeof window.yooadminSyncMaintenanceOverlayPreview === 'function') {
      window.yooadminSyncMaintenanceOverlayPreview();
    }
  }

  function openBrandingLogoMediaPicker(e) {
    if (e) {
      e.preventDefault();
    }
    if (typeof wp === 'undefined' || !wp.media) {
      return;
    }
    if (!yooadminBrandingLogoFrame) {
      yooadminBrandingLogoFrame = wp.media({
        title: (yooadmSettings && yooadmSettings.i18n && yooadmSettings.i18n.chooseLogo) || 'Choose Logo',
        button: { text: (yooadmSettings && yooadmSettings.i18n && yooadmSettings.i18n.useLogo) || 'Use this logo' },
        multiple: false
      });
      yooadminBrandingLogoFrame.on('select', onBrandingLogoMediaSelect);
    }
    yooadminBrandingLogoFrame.open();
  }

  function initLogoControls() {
    var defaults = getBrandingLogoDefaults();
    var initialCustom = (window.yooadmSettings && yooadmSettings.logoUrl) || '';
    applyBrandingLogoLive(initialCustom || defaults.url);

    $(document)
      .off('click.yooadminBrandingLogo', '#yooadmin-logo-choose')
      .on('click.yooadminBrandingLogo', '#yooadmin-logo-choose', openBrandingLogoMediaPicker);

    $(document)
      .off('click.yooadminBrandingLogoRemove', '#yooadmin-logo-remove')
      .on('click.yooadminBrandingLogoRemove', '#yooadmin-logo-remove', function () {
        var $url = $('#yooadmin-logo-url');
        var $prev = $('#yooadmin-logo-preview');
        $url.val('');
        $prev.hide().attr('src', '');
        if (window.yooadmSettings) {
          yooadmSettings.logoUrl = '';
        }
        applyBrandingLogoLive(defaults.url, { force: true });
        $(this).hide();
        $('#yooadmin-logo-width').val(defaults.width).trigger('input');
        if (typeof window.yooadminSyncLoginPreview === 'function') {
          window.yooadminSyncLoginPreview();
        }
        if (typeof window.yooadminSyncMaintenanceOverlayPreview === 'function') {
          window.yooadminSyncMaintenanceOverlayPreview();
        }
      });

    var $range = $('#yooadmin-logo-width');
    var $val   = $('#yooadmin-logo-width-val');

    function syncBrandRangeFill(el) {
      if (!el) {
        return;
      }
      var min = parseInt(el.getAttribute('min'), 10);
      var max = parseInt(el.getAttribute('max'), 10);
      var v = parseInt(el.value, 10);
      if (!Number.isFinite(min)) {
        min = 60;
      }
      if (!Number.isFinite(max)) {
        max = 320;
      }
      if (!Number.isFinite(v)) {
        v = min;
      }
      var pct = max > min ? ((v - min) / (max - min)) * 100 : 0;
      pct = Math.max(0, Math.min(100, pct));
      el.style.setProperty('--yp-range-fill-pct', pct + '%');
    }

    function applyWidth(px) {
      var n = parseInt(px, 10);
      if (!Number.isFinite(n)) return;
      var next = n + 'px';
      if (readVar('--yooadmin-logo-w') === next) {
        $val.text(n);
        return;
      }
      $val.text(n);
      applyVar('--yooadmin-logo-w', next);
    }

    if ($range.length) {
      var start = parseInt($range.val(), 10);
      if (!Number.isFinite(start)) start = (window.yooadmSettings && yooadmSettings.logoW) || defaults.width;
      applyWidth(start);
      syncBrandRangeFill($range[0]);
      $range.on('input change', function () {
        applyWidth(this.value);
        syncBrandRangeFill(this);
        this.setAttribute('aria-valuenow', String(parseInt(this.value, 10) || defaults.width));
        if (typeof window.yooadminSyncLoginPreview === 'function') {
          window.yooadminSyncLoginPreview();
        }
        if (typeof window.yooadminSyncMaintenanceOverlayPreview === 'function') {
          window.yooadminSyncMaintenanceOverlayPreview();
        }
      });
      $('#yooadmin-logo-width-reset').on('click', function (e) {
        e.preventDefault();
        $range.val(defaults.width).trigger('input');
      });
    }
  }

  /* ---------------- Admin Favicon controls ---------------- */
  function initAdminFaviconControls() {
    var frameFav;
    var $favUrl    = $('#yooadmin-admin-favicon-url');
    var $favPrev   = $('#yooadmin-admin-favicon-preview');
    var $favChoose = $('#yooadmin-admin-favicon-choose');
    var $favRemove = $('#yooadmin-admin-favicon-remove');

    var seedFav = (window.yooadmSettings && yooadmSettings.adminFaviconUrl) || '';
    var defFav  = (window.yooadmSettings && yooadmSettings.adminFaviconDefaultUrl) || '';

    function guessType(u){
      var ext = (String(u || '').split('?')[0].split('#')[0].split('.').pop() || '').toLowerCase();
      if (ext === 'ico') return 'image/x-icon';
      if (ext === 'svg') return 'image/svg+xml';
      if (ext === 'png') return 'image/png';
      if (ext === 'gif') return 'image/gif';
      if (ext === 'jpg' || ext === 'jpeg') return 'image/jpeg';
      return '';
    }

    function setAdminFaviconLink(url) {
      var head = document.head;
      if (!head) return;

      // Remove our previous injected tags
      Array.prototype.slice.call(head.querySelectorAll('link[rel="icon"][data-yooadmin="1"], link[rel="shortcut icon"][data-yooadmin="1"], link[rel="mask-icon"][data-yooadmin="1"]'))
        .forEach(function(n){ n.parentNode.removeChild(n); });

      if (!url) return;

      var type = guessType(url);

      // Add standard icon
      var link = document.createElement('link');
      link.setAttribute('rel', 'icon');
      link.setAttribute('href', url);
      if (type) link.setAttribute('type', type);
      link.setAttribute('data-yooadmin', '1');
      head.appendChild(link);

      // Some browsers still check "shortcut icon"
      var link2 = document.createElement('link');
      link2.setAttribute('rel', 'shortcut icon');
      link2.setAttribute('href', url);
      if (type) link2.setAttribute('type', type);
      link2.setAttribute('data-yooadmin', '1');
      head.appendChild(link2);

      // If SVG, also add mask-icon (Safari pinned)
      if (type === 'image/svg+xml') {
        var mask = document.createElement('link');
        mask.setAttribute('rel', 'mask-icon');
        mask.setAttribute('href', url);
        mask.setAttribute('color', '#333333');
        mask.setAttribute('data-yooadmin', '1');
        head.appendChild(mask);
      }
    }

    // Seed on load
    if (seedFav) {
      $favPrev.attr('src', seedFav).show();
      setAdminFaviconLink(seedFav);
      $favRemove.show();
    } else if (defFav) {
      setAdminFaviconLink(defFav);
    }

    $favChoose.on('click', function(e){
      e.preventDefault();
      if (frameFav) { frameFav.open(); return; }
      frameFav = wp.media({
        title: (yooadmSettings && yooadmSettings.i18n && yooadmSettings.i18n.adminFavicon) || 'Admin Favicon',
        button: { text: (yooadmSettings && yooadmSettings.i18n && yooadmSettings.i18n.useFavicon) || 'Use this icon' },
        multiple: false
      });
      frameFav.on('select', function(){
        var att = frameFav.state().get('selection').first().toJSON();
        var url = (att && att.url) || '';
        $favUrl.val(url);
        if (url) {
          $favPrev.attr('src', url).show();
          setAdminFaviconLink(url);
          $favRemove.show();
        }
      });
      frameFav.open();
    });

    $favRemove.on('click', function(){
      $favUrl.val('');
      $favPrev.hide().attr('src','');
      // Revert to default if available, otherwise remove injected tags
      if (defFav) {
        setAdminFaviconLink(defFav);
      } else {
        setAdminFaviconLink('');
      }
      $(this).hide();
    });
  }

  /** Re-wrap native selects inside a panel (e.g. after security sub-tab switch). */
  function enhanceNativeSelectsIn(root) {
    if (!root) {
      return;
    }
    if (window.yooadminUiSelect && typeof window.yooadminUiSelect.initIn === 'function') {
      window.yooadminUiSelect.initIn(root);
    }
    try {
      document.dispatchEvent(new CustomEvent('yooadmin:enhance-native-selects', { detail: { root: root } }));
    } catch (err) { /* ignore */ }
  }

  /* ---------------- Tabs ---------------- */
  function initTabs() {
    var $wrap = $('[data-yp-tabs]');
    if (!$wrap.length) {
      return;
    }

    var $nav  = $wrap.find('.yp-tab-nav').first();
    if (!$nav.length) {
      return;
    }

    var ink = $nav.find('.yp-tab-ink')[0];
    if (!ink) {
      ink = document.createElement('span');
      ink.className = 'yp-tab-ink';
      $nav[0].appendChild(ink);
    }

    function moveInk($btn){
      var r  = $btn[0].getBoundingClientRect();
      var rn = $nav[0].getBoundingClientRect();
      ink.style.width = r.width + 'px';
      ink.style.left  = (r.left - rn.left) + 'px';
    }

    function activate($btn, updateHash){
      var key = $btn.data('tab');
      if (!key) {
        return;
      }
      
      $btn.addClass('is-active').attr('aria-selected','true')
          .siblings('.yp-tab').removeClass('is-active').attr('aria-selected','false');

      // Hide top-level panels only (not security inner sub-panels).
      $wrap.children('.yp-tab-panels').children('.yp-tab-panel').removeClass('is-active');
      
      // Show selected panel
      var $targetPanel = $wrap.children('.yp-tab-panels').children('.yp-tab-panel[data-panel="'+key+'"]');
      if ($targetPanel.length) {
        $targetPanel.addClass('is-active');
        if (key === 'login-security') {
          enhanceNativeSelectsIn($targetPanel[0]);
        }
        if (key === 'login' && typeof window.yooadminSyncLoginPreview === 'function') {
          window.yooadminSyncLoginPreview();
        }
        if (key === 'brand' && typeof window.yooadminSyncLoginPreview === 'function') {
          window.yooadminSyncLoginPreview();
        }
      }

      moveInk($btn);
      
      // Update URL hash
      if (updateHash !== false) {
        var newHash = '#tab-' + key;
        if (window.location.hash !== newHash) {
          window.history.pushState(null, '', newHash);
        }
      }
    }

    $wrap.on('click', '.yp-tab', function(){
      activate($(this), true);
    });

    var $current = $wrap.find('.yp-tab.is-active').first();
    if (!$current.length) {
      // Allow deep-linking via hash or ?tab= param (e.g. yooadmin-settings#tab-notifications)
      var hash = window.location.hash || '';
      var targetKey = null;
      
      // Check for hash (e.g., #tab-notifications)
      if (hash) {
        // Remove # if present
        hash = hash.replace('#', '');
        // Check if it starts with 'tab-'
        if (hash.indexOf('tab-') === 0) {
          targetKey = hash.replace('tab-', '');
        } else {
          // If hash is just the tab name (e.g., #notifications)
          targetKey = hash;
        }
      }
      
      // Fallback to URL parameter
      if (!targetKey) {
        var params = new URLSearchParams(window.location.search);
        if (params.has('tab')) {
          targetKey = params.get('tab');
        } else if (params.has('security_tab')) {
          targetKey = 'login-security';
        }
      }
      
      if (targetKey) {
        $current = $wrap.find('.yp-tab[data-tab="'+targetKey+'"]').first();
      }
      if (!$current.length) {
        $current = $wrap.find('.yp-tab').first();
      }
    }
    if ($current.length) activate($current, false);
    
    // Also handle hash changes after page load (for deep linking)
    function handleHashChange() {
      var hash = window.location.hash || '';
      if (hash) {
        hash = hash.replace('#', '');
        var targetKey = null;
        if (hash.indexOf('tab-') === 0) {
          targetKey = hash.replace('tab-', '');
        } else {
          targetKey = hash;
        }
        if (targetKey) {
          var $targetTab = $wrap.find('.yp-tab[data-tab="'+targetKey+'"]').first();
          if ($targetTab.length) {
            activate($targetTab, false);
          }
        }
      }
    }
    
    $(window).on('hashchange', handleHashChange);
    
    // Also check hash on page load (in case hash is already in URL)
    setTimeout(function() {
      if (window.location.hash) {
        handleHashChange();
      }
    }, 100);

    $(window).on('resize', function(){
      var $active = $wrap.find('.yp-tab.is-active').first();
      if ($active.length) moveInk($active);
    });

    /** Tab widths change when e.g. Login “Off” badge toggles — ink must match or the nav underline looks stretched until resize/refresh */
    window.yooadminReflowSettingsTabs = function () {
      var $active = $wrap.find('.yp-tab.is-active').first();
      if ($active.length) {
        moveInk($active);
      }
    };
  }

  /* ---------------- AJAX Save ---------------- */
  function initAjaxSave() {
    var $btn  = $('#yooadmin-save-ajax');
    var $form = $('#yooadmin-settings-form');
    if (!$btn.length || !$form.length || !window.yooadmSettings || !yooadmSettings.ajax) return;

    $('#yooadmin-native-submit').hide(); // keep for fallback but hidden

    var $unsaved = $('#yooadmin-unsaved-notice');
    var settingsFormBaseline = '';
    function setUnsavedNoticeVisible(show) {
      if (!$unsaved.length) {
        return;
      }
      $unsaved.toggleClass('is-visible', show).attr('aria-hidden', show ? 'false' : 'true');
    }
    function captureSettingsBaseline() {
      settingsFormBaseline = $form.serialize();
      setUnsavedNoticeVisible(false);
    }
    function updateUnsavedNotice() {
      if (!$unsaved.length) {
        return;
      }
      setUnsavedNoticeVisible($form.serialize() !== settingsFormBaseline);
    }
    setTimeout(function () {
      captureSettingsBaseline();
    }, 500);
    $form.on('input change', ':input', function () {
      updateUnsavedNotice();
    });

    // capture initial focus policy once
    window.__ypInitialFocusPolicy = $('input[name="yooadmin_focus_policy"]:checked').val() || null;

    $btn.on('click', function(e){
      e.preventDefault();
      var turnstileErr = typeof window.yooadminValidateLoginTurnstileBeforeSave === 'function'
        ? window.yooadminValidateLoginTurnstileBeforeSave()
        : null;
      if (turnstileErr) {
        showToast(turnstileErr, 'error');
        return;
      }

      var txtSaving = (yooadmSettings.i18n && yooadmSettings.i18n.saving) || 'Saving…';
      var txtSaved  = (yooadmSettings.i18n && yooadmSettings.i18n.saved)  || 'Saved';
      var origHtml  = $btn.html();

      $btn.prop('disabled', true).text(txtSaving);

      $.ajax({
        method: 'POST',
        url: yooadmSettings.ajax.url,
        data: {
          action: yooadmSettings.ajax.action,
          nonce:  yooadmSettings.ajax.nonce,
          data:   $form.serialize()
        }
      }).done(function(resp){
        if (!resp || !resp.success) {
          var errMsg = (resp && resp.data && resp.data.message)
            ? resp.data.message
            : ((yooadmSettings.i18n && yooadmSettings.i18n.error) || 'Error while saving');
          showToast(errMsg, 'error');
          $btn.html(origHtml).prop('disabled', false);
          return;
        }

        $btn.html(txtSaved);
        showToast(txtSaved);

        // if focus policy changed, reload to apply it immediately
        var initialFocus = window.__ypInitialFocusPolicy || null;
        var currentFocus = $('input[name="yooadmin_focus_policy"]:checked').val() || null;

        // Wait for database write to complete and toast to show
        setTimeout(function(){
          if (initialFocus !== currentFocus) {
            // Check if Focus Mode is effectively disabled
            var focusCookie = document.cookie.split('; ').find(function(row) {
              return row.startsWith('yoo_focus=');
            });
            var cookieValue = focusCookie ? focusCookie.split('=')[1] : null;
            
            // Determine if focus is disabled
            var focusDisabled = false;
            if (currentFocus === 'off') {
              focusDisabled = true;
            } else if (currentFocus === 'auto' && cookieValue === 'off') {
              focusDisabled = true;
            }
            
            // Redirect based on focus state
            if (focusDisabled) {
              var adminUrl = (yooadmSettings && yooadmSettings.adminUrl) ? yooadmSettings.adminUrl : '';
              if (!adminUrl) {
                return;
              }
              window.location.href = adminUrl + 'admin.php?page=yooadmin-enable-focus';
            } else {
              // If enabled, just reload
              window.location.reload();
            }
          } else {
            // No focus change, but still reset button
            $btn.html(origHtml).prop('disabled', false);

            // Update form values from response to reflect saved state
            if (resp.success && resp.data && resp.data.options) {
              var savedOptions = resp.data.options;
              if (window.yooadmSettings && Object.prototype.hasOwnProperty.call(savedOptions, 'logo_url')) {
                yooadmSettings.logoUrl = savedOptions.logo_url || '';
              }
              if (window.yooadmSettings && savedOptions.logo_w) {
                yooadmSettings.logoW = parseInt(savedOptions.logo_w, 10) || yooadmSettings.logoW;
              }
              if (Object.prototype.hasOwnProperty.call(savedOptions, 'logo_url')) {
                var savedLogo = (savedOptions.logo_url || '').trim();
                $('#yooadmin-logo-url').val(savedLogo);
                applyBrandingLogoLive(savedLogo || getDefaultHeaderLogoUrl(), { force: true });
              }
            }
            if (typeof window.yooadminSyncLoginPreview === 'function') {
              window.yooadminSyncLoginPreview();
            }
            captureSettingsBaseline();
          }
        }, 1000);
      }).fail(function(){
        var msg = (yooadmSettings.i18n && yooadmSettings.i18n.error) || 'Error while saving';
        alert(msg);
        $btn.html(origHtml).prop('disabled', false);
      });
    });
  }

  /* ---------------- Dynamic Toggle Labels ---------------- */
  function initDynamicToggleLabels() {
    // Get labels from localized script
    var toggleLabels = (yooadmSettings && yooadmSettings.i18n && yooadmSettings.i18n.toggleLabels) || {};

    // Update label when toggle changes
    $('.yp-toggle-switch input[type="checkbox"]').on('change', function() {
      var $input = $(this);
      var fieldId = $input.attr('id');
      var isChecked = $input.is(':checked');
      var labels = toggleLabels[fieldId];
      
      if (labels) {
        var $label = $input.closest('.yp-toggle-container').find('.yp-toggle-label');
        var newText = isChecked ? labels.on : labels.off;
        $label.text(newText);
      }
    });
  }

  /* ---------------- Mutually Exclusive Toggles ---------------- */
  function initMutuallyExclusiveToggles() {
    // Both toggles work independently
  }

  /* ---------------- Tooltip Positioning ---------------- */
  function initTooltips() {
    $(document).on('mouseenter', '.yp-help-icon', function() {
      var $icon = $(this);
      var $tooltip = $icon.find('.yp-tooltip');
      if (!$tooltip.length) return;
      
      // Get icon position
      var iconRect = $icon[0].getBoundingClientRect();
      var tooltipWidth = 280;
      var tooltipHeight = $tooltip.outerHeight() || 100;
      
      // Calculate position
      var left = iconRect.left + (iconRect.width / 2) - (tooltipWidth / 2);
      var top = iconRect.top - tooltipHeight - 8;
      
      // Ensure tooltip stays within viewport
      if (left < 20) left = 20;
      if (left + tooltipWidth > window.innerWidth - 20) {
        left = window.innerWidth - tooltipWidth - 20;
      }
      if (top < 20) {
        // Show below icon if no space above
        top = iconRect.bottom + 8;
      }
      
      // Set position
      $tooltip.css({
        'position': 'fixed',
        'left': left + 'px',
        'top': top + 'px',
        'bottom': 'auto',
        'transform': 'none',
        'display': 'block',
        'opacity': '1',
        'z-index': '999999'
      });
    });
    
    $(document).on('mouseleave', '.yp-help-icon', function() {
      var $icon = $(this);
      var $tooltip = $icon.find('.yp-tooltip');
      if ($tooltip.length) {
        $tooltip.css({
          'display': 'none',
          'opacity': '0'
        });
      }
    });
  }

  /* ---------------- Boot ---------------- */
  function initLoginPageMedia() {
    function yooadminMediaFullUrl(att) {
      if (!att) {
        return '';
      }
      if (att.sizes && att.sizes.full && att.sizes.full.url) {
        return att.sizes.full.url;
      }
      return att.url || '';
    }

    function bindPicker(btnSel, urlSel, prevSel, removeSel, onAfterChange) {
      var frame;
      var $btn = $(btnSel);
      if (!$btn.length) return;
      var $url = $(urlSel);
      var $prev = $(prevSel);
      var $remove = $(removeSel);
      $btn.on('click', function (e) {
        e.preventDefault();
        if (frame) { frame.open(); return; }
        frame = wp.media({
          title: (yooadmSettings && yooadmSettings.i18n && yooadmSettings.i18n.chooseImage) || 'Choose image',
          button: { text: (yooadmSettings && yooadmSettings.i18n && yooadmSettings.i18n.useImage) || 'Use this image' },
          multiple: false
        });
        frame.on('select', function () {
          var att = frame.state().get('selection').first().toJSON();
          var url = yooadminMediaFullUrl(att);
          $url.val(url);
          if (url) {
            $prev.attr('src', url).show();
            $remove.show();
            if (prevSel.indexOf('login-logo') !== -1 && typeof window.yooadminSyncLoginPreview === 'function') {
              window.yooadminSyncLoginPreview();
            }
            if (typeof onAfterChange === 'function') {
              onAfterChange();
            }
          }
        });
        frame.open();
      });
      $remove.on('click', function () {
        $url.val('');
        $prev.hide().attr('src', '');
        $(this).hide();
        if (prevSel.indexOf('login-logo') !== -1 && typeof window.yooadminSyncLoginPreview === 'function') {
          window.yooadminSyncLoginPreview();
        }
        if (typeof onAfterChange === 'function') {
          onAfterChange();
        }
      });
    }
    bindPicker('#yooadmin-login-image-choose', '#yooadmin-login-image-url', '#yooadmin-login-image-preview', '#yooadmin-login-image-remove', syncLoginPreviewMedia);
    bindPicker('#yooadmin-login-logo-choose', '#yooadmin-login-logo-url', '#yooadmin-login-logo-preview', '#yooadmin-login-logo-remove', function () {
      syncLoginCustomLogoWidthVisibility();
      syncLoginPreviewLogo();
    });
    bindPicker('#yooadmin-login-logo-dark-choose', '#yooadmin-login-logo-dark-url', '#yooadmin-login-logo-dark-preview', '#yooadmin-login-logo-dark-remove', syncLoginPreviewLogo);
    function syncMaintenanceOverlayPreview() {
      var $preview = $('#yooadmin-maintenance-overlay-preview');
      var $bgSlider = $('#yooadmin-maintenance-bg-overlay-opacity');
      var $blurSlider = $('#yooadmin-maintenance-bg-blur');
      var $cardSlider = $('#yooadmin-maintenance-card-overlay-opacity');
      if (!$preview.length) {
        return;
      }

      var bgPct = $bgSlider.length ? parseInt($bgSlider.val(), 10) : NaN;
      if (!Number.isFinite(bgPct)) {
        bgPct = parseInt($preview.data('defaultBgOpacity'), 10) || 50;
      }
      bgPct = Math.max(0, Math.min(100, bgPct));

      var blurPct = $blurSlider.length ? parseInt($blurSlider.val(), 10) : NaN;
      if (!Number.isFinite(blurPct)) {
        blurPct = parseInt($preview.data('defaultBgBlur'), 10) || 50;
      }
      blurPct = Math.max(0, Math.min(100, blurPct));

      var cardPct = $cardSlider.length ? parseInt($cardSlider.val(), 10) : NaN;
      if (!Number.isFinite(cardPct)) {
        cardPct = parseInt($preview.data('defaultCardOpacity'), 10) || 50;
      }
      cardPct = Math.max(0, Math.min(100, cardPct));

      $preview[0].style.setProperty('--yooadmin-maint-preview-overlay', String(bgPct / 100));
      $preview[0].style.setProperty('--yooadmin-maint-preview-blur', String(blurPct / 100));
      $preview[0].style.setProperty('--yooadmin-maint-preview-card', String(cardPct / 100));

      var logoMw = parseInt($('#yooadmin-logo-width').val(), 10);
      if (!Number.isFinite(logoMw)) {
        logoMw = (window.yooadmSettings && window.yooadmSettings.logoW) || 150;
      }
      logoMw = Math.max(20, logoMw);
      $preview[0].style.setProperty('--yooadmin-maint-preview-logo-max-w', logoMw + 'px');

      var logoUrl = ($('#yooadmin-logo-url').val() || '').trim();
      if (!logoUrl) {
        logoUrl = ($preview.data('previewLogo') || '').trim();
      }
      var $logoImg = $preview.find('.yooadmin-maintenance-overlay-preview__logo-img');
      if (logoUrl) {
        if (!$logoImg.length) {
          $preview.find('.yooadmin-maintenance-overlay-preview__card').prepend(
            '<div class="yooadmin-maintenance-overlay-preview__logo">' +
              '<img class="yooadmin-maintenance-overlay-preview__logo-img" src="" alt="" />' +
            '</div>'
          );
          $logoImg = $preview.find('.yooadmin-maintenance-overlay-preview__logo-img');
        }
        $logoImg.attr('src', logoUrl).closest('.yooadmin-maintenance-overlay-preview__logo').show();
      } else if ($logoImg.length) {
        $logoImg.closest('.yooadmin-maintenance-overlay-preview__logo').hide();
      }

      var imgUrl = ($('#yooadmin-maintenance-image-url').val() || '').trim();
      var defaultBg = ($preview.data('defaultMaintBg') || '').trim();
      var bgForPreview = imgUrl || defaultBg;
      if (bgForPreview) {
        $preview[0].style.setProperty(
          '--yooadmin-maint-preview-bg',
          'url("' + bgForPreview.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '")'
        );
      } else {
        $preview[0].style.removeProperty('--yooadmin-maint-preview-bg');
      }
    }

    window.yooadminSyncMaintenanceOverlayPreview = syncMaintenanceOverlayPreview;

    function syncMaintenanceImageUi() {
      var $url = $('#yooadmin-maintenance-image-url');
      var $prev = $('#yooadmin-maintenance-image-preview');
      var $remove = $('#yooadmin-maintenance-image-remove');
      if (!$url.length) {
        return;
      }

      var url = ($url.val() || '').trim();
      if ($prev.length) {
        if (url) {
          $prev.attr('src', url).show();
        } else {
          $prev.attr('src', '').hide();
        }
      }
      if ($remove.length) {
        $remove.toggle(!!url);
      }

      syncMaintenanceOverlayPreview();

      $url.trigger('change');
    }

    window.yooadminSyncMaintenanceImageUi = syncMaintenanceImageUi;

    function bindMaintenanceOverlayRange(cfg) {
      var $slider = $(cfg.slider);
      if (!$slider.length || $slider.data('yooadminMaintRangeBound')) {
        return;
      }
      $slider.data('yooadminMaintRangeBound', 1);
      var rangeMin = typeof cfg.min === 'number' ? cfg.min : 0;
      var rangeMax = typeof cfg.max === 'number'
        ? cfg.max
        : (parseInt($slider.attr('max'), 10) || 100);

      $slider.on('input change', function () {
        var v = parseInt(this.value, 10);
        if (!Number.isFinite(v)) {
          v = cfg.defaultVal;
        }
        v = Math.max(rangeMin, Math.min(rangeMax, v));
        $(cfg.post).val(v);
        $(cfg.val).text(v);
        this.setAttribute('aria-valuenow', String(v));
        syncMaintenanceOverlayPreview();
      });

      $(cfg.reset).on('click', function (e) {
        e.preventDefault();
        var $preview = $('#yooadmin-maintenance-overlay-preview');
        var def = parseInt($preview.data(cfg.defaultData), 10) || cfg.defaultVal;
        $slider.val(def).trigger('change');
      });
    }

    function bindMaintenanceImagePicker() {
      var frame;
      var $btn = $('#yooadmin-maintenance-image-choose');
      if (!$btn.length) {
        return;
      }
      var $url = $('#yooadmin-maintenance-image-url');
      var $id = $('#yooadmin-maintenance-image-id');
      var $prev = $('#yooadmin-maintenance-image-preview');
      var $remove = $('#yooadmin-maintenance-image-remove');
      $btn.off('click.yooadminMaintImg').on('click.yooadminMaintImg', function (e) {
        e.preventDefault();
        if (frame) {
          frame.open();
          return;
        }
        frame = wp.media({
          title: (yooadmSettings && yooadmSettings.i18n && yooadmSettings.i18n.chooseImage) || 'Choose image',
          button: { text: (yooadmSettings && yooadmSettings.i18n && yooadmSettings.i18n.useImage) || 'Use this image' },
          multiple: false
        });
        frame.on('select', function () {
          var att = frame.state().get('selection').first().toJSON();
          var url = yooadminMediaFullUrl(att);
          $url.val(url);
          if ($id.length) {
            $id.val(att && att.id ? String(att.id) : '0');
          }
          syncMaintenanceImageUi();
        });
        frame.open();
      });
      $remove.off('click.yooadminMaintImg').on('click.yooadminMaintImg', function (e) {
        e.preventDefault();
        $url.val('');
        if ($id.length) {
          $id.val('0');
        }
        syncMaintenanceImageUi();
      });
    }

    bindMaintenanceImagePicker();

    function initMaintenanceOverlayRanges() {
      bindMaintenanceOverlayRange({
        slider: '#yooadmin-maintenance-bg-overlay-opacity',
        post: '#yooadmin-maintenance-bg-overlay-opacity-post',
        val: '#yooadmin-maintenance-bg-overlay-opacity-val',
        reset: '#yooadmin-maintenance-bg-overlay-opacity-reset',
        defaultData: 'defaultBgOpacity',
        defaultVal: 50
      });
      bindMaintenanceOverlayRange({
        slider: '#yooadmin-maintenance-bg-blur',
        post: '#yooadmin-maintenance-bg-blur-post',
        val: '#yooadmin-maintenance-bg-blur-val',
        reset: '#yooadmin-maintenance-bg-blur-reset',
        defaultData: 'defaultBgBlur',
        defaultVal: 50
      });
      bindMaintenanceOverlayRange({
        slider: '#yooadmin-maintenance-card-overlay-opacity',
        post: '#yooadmin-maintenance-card-overlay-opacity-post',
        val: '#yooadmin-maintenance-card-overlay-opacity-val',
        reset: '#yooadmin-maintenance-card-overlay-opacity-reset',
        defaultData: 'defaultCardOpacity',
        defaultVal: 50
      });
      syncMaintenanceOverlayPreview();
    }

    window.yooadminInitMaintenancePanelMedia = function () {
      bindMaintenanceImagePicker();
      initMaintenanceOverlayRanges();
      syncMaintenanceImageUi();
    };

    initMaintenanceOverlayRanges();

    function syncLoginCustomLogoWidthVisibility() {
      var custom = $('input[name="yooadmin_options[login_page_logo_source]"]:checked').val() === 'custom';
      var hasUrl = ($('#yooadmin-login-logo-url').val() || '').trim() !== '';
      $('#yooadmin-login-custom-logo-width-wrap').toggle(custom && hasUrl);
    }

    $('input[name="yooadmin_options[login_page_logo_source]"]').on('change', function () {
      var custom = $('input[name="yooadmin_options[login_page_logo_source]"]:checked').val() === 'custom';
      $('#yooadmin-login-logo-custom-block').toggle(custom);
      syncLoginCustomLogoWidthVisibility();
      syncLoginPreviewLogo();
    });
    $('#yooadmin-login-logo-max-w').on('input change', function () {
      var v = this.value;
      $('#yooadmin-login-logo-max-w-post').val(v);
      $('#yooadmin-login-logo-max-w-val').text(v);
      syncLoginPreviewLogo();
    });
    $('#yooadmin-login-logo-max-w-reset').on('click', function (e) {
      e.preventDefault();
      var def = (window.yooadmSettings && parseInt(yooadmSettings.loginLogoMaxWDefault, 10)) || 220;
      var cap = getLoginLogoMaxCap();
      if (!Number.isFinite(def)) def = 220;
      def = Math.min(def, cap);
      $('#yooadmin-login-logo-max-w').val(def);
      $('#yooadmin-login-logo-max-w-post').val(def);
      $('#yooadmin-login-logo-max-w-val').text(def);
      syncLoginPreviewLogo();
    });

    syncLoginCustomLogoWidthVisibility();
    syncLoginPreviewLogo();
  }

  /** General login_page_enabled: dim Login tab + glass overlay; overlay switch syncs with General toggle */
  function initLoginPolicyUi() {
    var $mainToggle = $('#login_page_enabled');
    var $fields = $('#yooadmin-login-tab-fields');
    var $overlay = $('#yooadmin-login-glass-overlay');
    var $overlayToggle = $('#yooadmin-login-overlay-enable');
    if (!$mainToggle.length) return;

    function applyState() {
      var on = $mainToggle.is(':checked');
      if ($fields.length) {
        $fields.toggleClass('yooadmin-login-tab-fields--disabled', !on);
      }
      if ($overlay.length) {
        $overlay.toggleClass('yooadmin-login-glass-overlay--hidden', on);
        $overlay.attr('aria-hidden', on ? 'true' : 'false');
      }
      if ($overlayToggle.length) {
        $overlayToggle.prop('checked', on);
      }
      var $loginTab = $('.yp-tab[data-tab="login"]');
      if ($loginTab.length) {
        $loginTab.toggleClass('yp-tab--login-disabled', !on);
        $loginTab.find('.yp-tab-badge--off').prop('hidden', !!on);
      }
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          if (typeof window.yooadminReflowSettingsTabs === 'function') {
            window.yooadminReflowSettingsTabs();
          }
        });
      });
    }

    $mainToggle.on('change', applyState);
    if ($overlayToggle.length) {
      $overlayToggle.on('change', function () {
        var v = $(this).is(':checked');
        if ($mainToggle.is(':checked') !== v) {
          $mainToggle.prop('checked', v).trigger('change');
        } else {
          applyState();
        }
      });
    }
    applyState();
  }

  /** Security tab: inner tabs (same chrome as main yp-tab-nav) */
  function initSecurityInnerTabs() {
    var $wrap = $('[data-yp-security-inner-tabs]');
    if (!$wrap.length) {
      return;
    }

    var $nav = $wrap.find('.yp-tab-nav').first();
    var $panels = $wrap.find('.yp-tab-panels').first();
    if (!$nav.length || !$panels.length) {
      return;
    }

    var ink = $nav.find('.yp-tab-ink')[0];
    if (!ink) {
      ink = document.createElement('span');
      ink.className = 'yp-tab-ink';
      $nav[0].appendChild(ink);
    }

    function moveInk($btn) {
      if (!$btn || !$btn.length) {
        return;
      }
      var r = $btn[0].getBoundingClientRect();
      var rn = $nav[0].getBoundingClientRect();
      var isRtl = document.documentElement.dir === 'rtl'
        || document.body.classList.contains('rtl')
        || document.body.classList.contains('yooadmin-arabic-ui');
      ink.style.width = r.width + 'px';
      if (isRtl) {
        ink.style.left = 'auto';
        ink.style.right = (rn.right - r.right) + 'px';
      } else {
        ink.style.right = 'auto';
        ink.style.left = (r.left - rn.left) + 'px';
      }
    }

    function updateSecurityInnerUrl(inner, replace) {
      if (!window.history || typeof window.history.replaceState !== 'function') {
        return;
      }
      var url = new URL(window.location.href);
      url.searchParams.set('tab', 'login-security');
      if (inner && inner !== 'turnstile') {
        url.searchParams.set('security_tab', inner);
      } else {
        url.searchParams.delete('security_tab');
      }
      url.hash = 'tab-login-security';
      var fn = replace === false ? window.history.pushState : window.history.replaceState;
      fn.call(window.history, null, '', url.toString());
    }

    function activate($btn, updateUrl) {
      var inner = $btn.attr('data-security-inner');
      if (!inner) {
        return;
      }

      $btn.addClass('is-active').attr('aria-selected', 'true')
        .siblings('.yp-tab').removeClass('is-active').attr('aria-selected', 'false');

      $panels.children('.yooadmin-security-inner-panel').removeClass('is-active').attr('hidden', 'hidden');
      var $target = $panels.children('.yooadmin-security-inner-panel[data-security-inner-panel="' + inner + '"]');
      if ($target.length) {
        $target.addClass('is-active').removeAttr('hidden');
        enhanceNativeSelectsIn($target[0]);
      }

      moveInk($btn);

      if (updateUrl !== false) {
        updateSecurityInnerUrl(inner, false);
      }

      if ($btn[0] && typeof $btn[0].blur === 'function') {
        $btn[0].blur();
      }
    }

    $nav.off('click.yooSecurityInnerTabs').on('click.yooSecurityInnerTabs', '.yp-tab', function (e) {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.which === 2) {
        return;
      }
      e.preventDefault();
      activate($(this), true);
    });

    var params = new URLSearchParams(window.location.search);
    var urlInner = params.get('security_tab');
    var $current = urlInner
      ? $nav.find('.yp-tab[data-security-inner="' + urlInner + '"]').first()
      : $nav.find('.yp-tab.is-active').first();
    if (!$current.length) {
      $current = $nav.find('.yp-tab').first();
    }
    if ($current.length) {
      activate($current, false);
    }

    $(window).off('resize.yooSecurityInnerTabs').on('resize.yooSecurityInnerTabs', function () {
      var $active = $nav.find('.yp-tab.is-active').first();
      if ($active.length) {
        moveInk($active);
      }
    });

    if (!window.yooadminSecurityInnerPopstateBound) {
      window.yooadminSecurityInnerPopstateBound = true;
      window.addEventListener('popstate', function () {
        initSecurityInnerTabs();
      });
    }
  }

  function loginTurnstileKeysReadyInForm() {
    var $site = $('#yooadmin-login-turnstile-site-key');
    var $secret = $('#yooadmin-login-turnstile-secret-key');
    var siteVal = $site.length ? $.trim($site.val()) : '';
    var secretVal = $secret.length ? $.trim($secret.val()) : '';
    var cfg = (window.yooadmSettings && window.yooadmSettings.loginTurnstile) || {};
    var hasStoredSecret = !!cfg.hasSecret;

    return siteVal !== '' && (secretVal !== '' || hasStoredSecret);
  }

  function loginTurnstileSaveBlockedMessage() {
    var cfg = (window.yooadmSettings && window.yooadmSettings.loginTurnstile) || {};
    return cfg.saveBlocked || cfg.enableBlocked || 'Add both Turnstile keys before enabling login security.';
  }

  window.yooadminValidateLoginTurnstileBeforeSave = function () {
    var $toggle = $('#login_security_enabled');
    if (!$toggle.length || !$toggle.is(':checked')) {
      return null;
    }
    if (loginTurnstileKeysReadyInForm()) {
      return null;
    }
    return loginTurnstileSaveBlockedMessage();
  };

  /** Security tab: login_security_enabled requires complete Turnstile keys. */
  function initLoginSecurityUi() {
    var $toggle = $('#login_security_enabled');
    var $options = $('#yooadmin-login-security-options');
    var $site = $('#yooadmin-login-turnstile-site-key');
    var $secret = $('#yooadmin-login-turnstile-secret-key');
    if (!$toggle.length) {
      return;
    }

    var cfg = (window.yooadmSettings && window.yooadmSettings.loginTurnstile) || {};
    var blockMsg = cfg.enableBlocked || loginTurnstileSaveBlockedMessage();

    function applyState() {
      var on = $toggle.is(':checked');
      if ($options.length) {
        $options.toggleClass('yooadmin-security-panel-body--disabled', !on);
      }
    }

    $toggle.on('change', function () {
      if ($toggle.is(':checked') && !loginTurnstileKeysReadyInForm()) {
        $toggle.prop('checked', false);
        applyState();
        if (typeof window.yooadminShowToast === 'function') {
          window.yooadminShowToast(blockMsg, 'error');
        } else if (window.yooadmToast && typeof window.yooadmToast.error === 'function') {
          window.yooadmToast.error(blockMsg);
        } else {
          window.alert(blockMsg);
        }
        return;
      }
      applyState();
    });

    function refreshToggleGuard() {
      if ($toggle.is(':checked') && !loginTurnstileKeysReadyInForm()) {
        $toggle.prop('checked', false);
        applyState();
      }
    }

    if ($site.length) {
      $site.on('input change', refreshToggleGuard);
    }
    if ($secret.length) {
      $secret.on('input change', refreshToggleGuard);
    }

    refreshToggleGuard();
    applyState();
  }

  function initMaintenanceModeUi() {
    var $toggle = $('#maintenance_mode_enabled');
    var $body = $('.yooadmin-maintenance-settings-body');
    var $tab = $('.yp-tab[data-tab="maintenance"]');
    if (!$toggle.length) {
      return;
    }

    function applyState() {
      var on = $toggle.is(':checked');
      if ($body.length) {
        $body.toggleClass('yooadmin-security-panel-body--disabled', !on);
      }
      if ($tab.length) {
        $tab.toggleClass('yp-tab--maintenance-off', !on);
        $tab.find('.yp-tab-badge--off').prop('hidden', !!on);
      }
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          if (typeof window.yooadminReflowSettingsTabs === 'function') {
            window.yooadminReflowSettingsTabs();
          }
        });
      });
    }

    $toggle.on('change', applyState);
    applyState();
  }

  function initMaintenanceLocaleUi() {
    var $root = $('[data-yooadmin-maintenance-locales]');
    if (!$root.length) {
      return;
    }

    $root.on('change', '.yooadmin-maintenance-locale-enable', function () {
      var $locale = $(this).closest('.yooadmin-maintenance-locale');
      var $fields = $locale.find('.yooadmin-maintenance-locale__fields');
      var on = $(this).is(':checked');
      $locale.toggleClass('is-enabled', on);
      $fields.toggleClass('is-open', on);
      if (on) {
        $fields.prop('hidden', false);
      } else {
        $fields.prop('hidden', true);
      }
    });
  }

  function initLoginHiddenEntryUi() {
    var $toggle = $('#login_hidden_entry_enabled');
    var $body = $('.yooadmin-login-hidden-entry-body');
    if (!$toggle.length || !$body.length) {
      return;
    }

    function applyState() {
      var on = $toggle.is(':checked');
      $body.toggleClass('yooadmin-security-panel-body--disabled', !on);
    }

    $toggle.on('change', applyState);
    applyState();

    var $compose = $body.find('.yooadmin-login-hidden-entry-url-compose').first();
    var $slugInput = $('#yooadmin-login-hidden-entry-slug');

    function buildLoginHiddenEntryPreviewUrl(slug) {
      if (!$compose.length) {
        return '';
      }
      slug = $.trim(slug || '');
      if (!slug) {
        return '';
      }
      var prefix = $compose.attr('data-site-prefix') || '';
      var pretty = $compose.attr('data-pretty') === '1';
      if (pretty) {
        return prefix + slug + '/';
      }
      var sep = prefix.indexOf('?') >= 0 ? '&' : '?';
      return prefix + sep + 'yooadmin_secret_login=1&hl=' + encodeURIComponent(slug);
    }

    function updateLoginHiddenEntryPreview() {
      var slug = $.trim($slugInput.val() || '');
      var $preview = $body.find('.yooadmin-login-hidden-entry-url-preview');
      var $code = $('#yooadmin-login-hidden-entry-url-value');
      var $copy = $body.find('.yooadmin-login-hidden-entry-url-copy');
      if (!$preview.length || !$code.length) {
        return;
      }
      if (!slug || !$toggle.is(':checked')) {
        return;
      }
      var url = buildLoginHiddenEntryPreviewUrl(slug);
      if (!url) {
        return;
      }
      $code.text(url);
      $copy.attr('data-copy-url', url);
    }

    if ($slugInput.length) {
      $slugInput.on('input', updateLoginHiddenEntryPreview);
    }

    function copyLoginHiddenEntryUrl(text) {
      if (!text) {
        return Promise.reject();
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
      }
      return new Promise(function (resolve, reject) {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', 'readonly');
        ta.style.position = 'absolute';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        try {
          document.execCommand('copy');
          resolve();
        } catch (err) {
          reject(err);
        } finally {
          document.body.removeChild(ta);
        }
      });
    }

    $body.on('click', '.yooadmin-login-hidden-entry-url-copy', function (e) {
      e.preventDefault();
      var url = $(this).attr('data-copy-url') || $('#yooadmin-login-hidden-entry-url-value').text() || '';
      url = $.trim(url);
      if (!url) {
        return;
      }
      copyLoginHiddenEntryUrl(url).then(function () {
        var copiedMsg = (window.yooadmSettings && window.yooadmSettings.i18n && window.yooadmSettings.i18n.copied) || 'Copied to clipboard.';
        if (typeof showToast === 'function') {
          showToast(copiedMsg, 'success');
        }
      });
    });
  }

  function initLoginUserEnumUi() {
    var $toggle = $('#login_prevent_user_enumeration');
    var $body = $('.yooadmin-login-user-enum-body');
    if (!$toggle.length || !$body.length) {
      return;
    }

    function applyState() {
      var on = $toggle.is(':checked');
      $body.toggleClass('yooadmin-security-panel-body--disabled', !on);
    }

    $toggle.on('change', applyState);
    applyState();

    initUserEnumStatsClear();
  }

  function initLoginTwoFactorUi() {
    var $toggle = $('#login_two_factor_enabled');
    var $body = $('.yooadmin-native-2fa-settings-body');
    var $migrate = $('#yooadmin-2fa-run-migration');
    var $result = $('#yooadmin-2fa-migration-result');

    if ($toggle.length && $body.length) {
      function applyState() {
        var on = $toggle.is(':checked');
        $body.toggleClass('yooadmin-security-panel-body--disabled', !on);
        $body.find('input[type="checkbox"], select, button').prop('disabled', !on);
        if ($migrate.length) {
          $migrate.prop('disabled', !on);
        }
      }
      $toggle.on('change', applyState);
      applyState();
    }

    if (!$migrate.length) {
      return;
    }

    var ajaxUrl = (window.yooadmSettings && yooadmSettings.ajax && yooadmSettings.ajax.url) || '';

    $migrate.on('click', function (e) {
      e.preventDefault();
      if ($migrate.prop('disabled')) {
        return;
      }
      var nonce = $migrate.attr('data-nonce') || '';
      var btnHtml = $migrate.html();
      $migrate.prop('disabled', true).text('…');

      $.post(ajaxUrl, {
        action: 'yooadmin_2fa_run_migration',
        nonce: nonce
      })
        .done(function (res) {
          if (!$result.length) {
            return;
          }
          var data = res && res.data ? res.data : {};
          var lines = [];
          if (typeof data.imported === 'number') {
            lines.push('Imported: ' + data.imported);
          }
          if (typeof data.skipped === 'number') {
            lines.push('Skipped: ' + data.skipped);
          }
          if (Array.isArray(data.messages) && data.messages.length) {
            lines = lines.concat(data.messages);
          }
          $result.text(lines.join('\n')).prop('hidden', false);
          if (typeof showToast === 'function') {
            showToast('Import finished.', 'success');
          }
        })
        .fail(function (xhr) {
          var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || 'Import failed.';
          if ($result.length) {
            $result.text(msg).prop('hidden', false);
          }
          if (typeof showToast === 'function') {
            showToast(msg, 'error');
          }
        })
        .always(function () {
          $migrate.html(btnHtml);
          if ($toggle.length && $toggle.is(':checked')) {
            $migrate.prop('disabled', false);
          }
        });
    });
  }

  /** Username protection tab — clear blocked-attempt counter */
  function initUserEnumStatsClear() {
    var $btn = $('#yooadmin-user-enum-clear-stats');
    var $total = $('#yooadmin-user-enum-blocked-count');
    var $breakdown = $('#yooadmin-user-enum-stats-breakdown');
    if (!$btn.length || !$total.length) {
      return;
    }

    var config = (window.yooadmSettings && yooadmSettings.userEnumStats) || {};
    var ajaxUrl = (window.yooadmSettings && yooadmSettings.ajax && yooadmSettings.ajax.url) || '';
    var nonce = $btn.attr('data-nonce') || config.nonce || '';
    var action = config.action || 'yooadmin_clear_user_enum_stats';
    var i18n = (window.yooadmSettings && yooadmSettings.i18n) || {};

    function setCounts(stats) {
      stats = stats || {};
      var total = parseInt(stats.total, 10) || 0;
      var byType = stats.by_type || {};
      $total.text(String(total));
      $btn.prop('disabled', total < 1);
      if ($breakdown.length) {
        $breakdown.find('.yooadmin-user-enum-stats__breakdown-item').each(function () {
          var type = $(this).attr('data-enum-type');
          var count = type && byType[type] !== undefined ? parseInt(byType[type], 10) : 0;
          $(this).find('.yooadmin-user-enum-stats__breakdown-count').text(String(count || 0));
        });
      }
    }

    function runClear() {
      var btnHtml = $btn.html();
      $btn.prop('disabled', true).html('<span class="dashicons dashicons-update" aria-hidden="true"></span> ' + (i18n.userEnumClearing || 'Clearing…'));

      $.post(ajaxUrl, {
        action: action,
        nonce: nonce
      })
        .done(function (res) {
          if (res && res.success && res.data && res.data.stats) {
            setCounts(res.data.stats);
          } else {
            setCounts({ total: 0, by_type: {} });
          }
          showToast(i18n.userEnumCleared || 'Counter cleared.', 'success');
        })
        .fail(function () {
          showToast(i18n.userEnumClearError || 'Could not clear the counter. Please try again.', 'error');
        })
        .always(function () {
          $btn.html(btnHtml);
          var total = parseInt($total.text().replace(/,/g, ''), 10) || 0;
          $btn.prop('disabled', total < 1);
        });
    }

    $btn.on('click', function (e) {
      e.preventDefault();
      if ($btn.prop('disabled')) {
        return;
      }

      var confirmOpts = {
        title: i18n.userEnumClearTitle || 'Clear counter',
        message: i18n.userEnumClearConfirm || 'Clear the blocked enumeration attempts counter? This cannot be undone.',
        confirmText: i18n.userEnumClearConfirmBtn || i18n.userEnumClearTitle || 'Clear counter',
        cancelText: i18n.cancel || 'Cancel',
        compact: true,
        useYooButtons: true
      };

      if (typeof window.yooadminConfirm === 'function') {
        window.yooadminConfirm(confirmOpts).then(function (ok) {
          if (ok) {
            runClear();
          }
        });
        return;
      }

      if (window.confirm(confirmOpts.message)) {
        runClear();
      }
    });
  }

  /** Security tab: login_rate_limit_enabled dims limit fields */
  function initLoginRateLimitUi() {
    var $toggle = $('#login_rate_limit_enabled');
    var $body = $('.yooadmin-login-rate-limit-body');
    if (!$toggle.length || !$body.length) {
      return;
    }

    function applyState() {
      var on = $toggle.is(':checked');
      $body.toggleClass('yooadmin-security-panel-body--disabled', !on);
    }

    $toggle.on('change', applyState);
    applyState();
  }

  /** Security tab — Turnstile setup guide modal (delegated; works in admin-bar AJAX panel when Focus is off). */
  function initLoginTurnstileInfoModal() {
    var $modal = $('#yooadmin-login-turnstile-info-modal');
    if (!$modal.length || $modal.data('yooadminTurnstileInfoBound')) {
      return;
    }

    var modalEl = $modal[0];
    if (modalEl.parentNode !== document.body) {
      document.body.appendChild(modalEl);
    }

    function openModal() {
      $modal.attr('aria-hidden', 'false').addClass('is-open');
      $('body').addClass('yp-modal-open yooadmin-login-turnstile-info-open');
    }

    function closeModal() {
      $modal.attr('aria-hidden', 'true').removeClass('is-open');
      $('body').removeClass('yp-modal-open yooadmin-login-turnstile-info-open');
    }

    $(document).on('click.yooadminTurnstileInfo', '#yooadmin-login-turnstile-info-open', function (e) {
      e.preventDefault();
      e.stopPropagation();
      openModal();
    });
    $(document).on('click.yooadminTurnstileInfo', '[data-yooadmin-login-turnstile-info-close]', function (e) {
      e.preventDefault();
      closeModal();
    });
    $(document).on('keydown.yooadminTurnstileInfo', function (e) {
      if (e.key === 'Escape' && $modal.hasClass('is-open')) {
        closeModal();
      }
    });

    $modal.data('yooadminTurnstileInfoBound', true);
  }

  window.yooadminInitAbSettingsPanel = function (panel) {
    panel = panel || '';
    if (panel === 'login-security') {
      initSecurityInnerTabs();
      initLoginSecurityUi();
      initLoginTurnstileInfoModal();
      initLoginRateLimitUi();
      initLoginUserEnumUi();
      initLoginHiddenEntryUi();
      initLoginTwoFactorUi();
      var $sec = $('#yooadmin-ab-settings-form #tab-login-security');
      if ($sec.length && typeof enhanceNativeSelectsIn === 'function') {
        enhanceNativeSelectsIn($sec[0]);
        var $inner = $sec.find('.yooadmin-security-inner-panel.is-active').first();
        if ($inner.length) {
          enhanceNativeSelectsIn($inner[0]);
        }
      }
    }
    if (panel === 'maintenance') {
      initMaintenanceModeUi();
      initMaintenanceLocaleUi();
      if (typeof window.yooadminInitMaintenancePanelMedia === 'function') {
        window.yooadminInitMaintenancePanelMedia();
      }
    }
  };

  $(document).on('yooadmin:ab-settings-panel-loaded', function (e, panel) {
    if (typeof window.yooadminInitAbSettingsPanel === 'function') {
      window.yooadminInitAbSettingsPanel(panel);
    }
  });

  $(function () {
    initTabs();
    initColorPickers();
    initLogoControls();
    initAdminFaviconControls();
    initLoginPageMedia();
    initLoginAppearanceControls();
    initCoreLoginPreviewUi();
    initLoginPolicyUi();
    initSecurityInnerTabs();
    (function () {
      var $sec = $('#tab-login-security');
      if (!$sec.length) {
        return;
      }
      if ($sec.hasClass('is-active')) {
        enhanceNativeSelectsIn($sec[0]);
      }
      var $inner = $sec.find('.yooadmin-security-inner-panel.is-active').first();
      if ($inner.length) {
        enhanceNativeSelectsIn($inner[0]);
      }
    })();
    initLoginSecurityUi();
    initLoginRateLimitUi();
    initLoginUserEnumUi();
    initLoginHiddenEntryUi();
    initLoginTwoFactorUi();
    initMaintenanceModeUi();
    initMaintenanceLocaleUi();
    initLoginTurnstileInfoModal();
    initAjaxSave();
    initBannerCleanup();
    initNotificationsCleanup();
    initNotificationsHowtoModal();
    initDynamicToggleLabels();
    initMutuallyExclusiveToggles();
    initTooltips();
  });

  /* ---------------- Notifications "How it works" modal ---------------- */
  function initNotificationsHowtoModal() {
    var $modal = jQuery('#yp-notifications-howto-modal');
    if (!$modal.length || $modal.data('yooadminHowtoBound')) return;

    // Move to body so it overlays correctly regardless of tab containers.
    if ($modal[0].parentNode !== document.body) {
      document.body.appendChild($modal[0]);
    }

    function openModal() {
      $modal.attr('aria-hidden', 'false').fadeIn(180);
      jQuery('body').addClass('yp-modal-open');
    }
    function closeModal() {
      $modal.attr('aria-hidden', 'true').fadeOut(180);
      jQuery('body').removeClass('yp-modal-open');
    }

    jQuery(document).on('click.yooadminHowto', '#yp-notifications-howto-open', function(e) {
      e.preventDefault();
      openModal();
    });
    $modal.on('click.yooadminHowto', '[data-yp-notifications-howto-close]', function(e) {
      e.preventDefault();
      closeModal();
    });
    jQuery(document).on('keydown.yooadminHowto', function(e) {
      if (e.key === 'Escape' && $modal.is(':visible')) closeModal();
    });

    $modal.data('yooadminHowtoBound', true);
  }

  /* ---------------- Notifications Retention Cleanup ---------------- */
  function initNotificationsCleanup() {
    var btn = document.getElementById('yp-run-notifications-cleanup');
    if (!btn) return;

    var spinner = document.getElementById('yp-run-cleanup-spinner');
    var messageEl = document.getElementById('yp-run-cleanup-message');
    var ajaxUrl = (window.yooadmSettings && yooadmSettings.ajax && yooadmSettings.ajax.url) || (window.ajaxurl || '');
    var nonce = btn.getAttribute('data-nonce') || '';

    function setMessage(text, isError) {
      if (!messageEl) return;
      messageEl.textContent = text;
      messageEl.className = 'description';
      messageEl.style.color = isError ? '#dc3232' : '#46b450';
      messageEl.style.display = 'block';
    }

    btn.addEventListener('click', function(e) {
      e.preventDefault();

      btn.disabled = true;
      if (spinner) spinner.style.display = 'inline-block';
      if (messageEl) messageEl.style.display = 'none';

      jQuery.ajax({
        url: ajaxUrl,
        method: 'POST',
        data: {
          action: 'yooadmin_run_notifications_cleanup',
          nonce: nonce
        },
        success: function(response) {
          if (response && response.success) {
            var msg = (response.data && response.data.message) || 'Cleanup complete.';
            setMessage(msg, false);
            if (typeof showToast === 'function') showToast(msg);
            if (window.yooadmNotificationsUi) {
              if (typeof window.yooadmNotificationsUi.refreshBadgeCount === 'function') {
                window.yooadmNotificationsUi.refreshBadgeCount();
              }
              if (typeof window.yooadmNotificationsUi.loadNotifications === 'function') {
                window.yooadmNotificationsUi.loadNotifications(true, { silent: true });
              }
            }
          } else {
            var err = (response && response.data && response.data.message) || 'Cleanup failed.';
            setMessage(err, true);
            if (typeof showToast === 'function') showToast(err, 'error');
          }
        },
        error: function(xhr, status, error) {
          setMessage('Error: ' + (error || 'Unknown error occurred'), true);
          if (typeof showToast === 'function') showToast('Cleanup error: ' + (error || 'Unknown error'), 'error');
        },
        complete: function() {
          btn.disabled = false;
          if (spinner) spinner.style.display = 'none';
        }
      });
    });
  }

  /* ---------------- Banner Cleanup ---------------- */
  function initBannerCleanup() {
    var clearBtn = document.getElementById('yp-clear-banner-notifications');
    var spinner = document.getElementById('yp-clear-banners-spinner');
    var messageEl = document.getElementById('yp-clear-banners-message');
    
    if (!clearBtn) return;
    
    var config = (window.yooadmSettings && yooadmSettings.bannerCleanup) || {};
    var ajaxUrl = (window.yooadmSettings && yooadmSettings.ajax && yooadmSettings.ajax.url) || '';
    var nonce = config.nonce || '';
    var action = config.action || 'yooadmin_clear_banner_notifications';
    
    // Create modal HTML (strings from yooadmSettings.i18n)
    var i18n = (window.yooadmSettings && yooadmSettings.i18n) || {};
    var clearBannerTitle = i18n.clearBannerTitle || 'Clear Banner Notifications';
    var clearBannerConfirm = i18n.clearBannerConfirm || 'Are you sure you want to clear all banner notifications?';
    var clearBannerRegen = i18n.clearBannerRegen || 'They will be re-generated correctly on the next page load.';
    var clearNotifications = i18n.clearNotifications || 'Clear Notifications';
    var cancelLabel = i18n.cancel || 'Cancel';
    function createClearBannerModal() {
      var modalHTML = `
        <div id="yp-clear-banner-modal" class="yp-cleanup-modal" style="display: none;">
          <div class="yp-cleanup-overlay"></div>
          <div class="yp-cleanup-dialog">
            <div class="yp-cleanup-header">
              <h2>` + clearBannerTitle + `</h2>
              <button type="button" class="yp-cleanup-close" aria-label="Close">
                <span class="dashicons dashicons-no-alt"></span>
              </button>
            </div>
            <div class="yp-cleanup-content">
              <div class="yp-cleanup-warning">
                <span class="dashicons dashicons-info"></span>
                <p>` + clearBannerConfirm + `</p>
              </div>
              <div class="yp-cleanup-safe">
                <span class="dashicons dashicons-update"></span>
                <p>` + clearBannerRegen + `</p>
              </div>
            </div>
            <div class="yp-cleanup-footer">
              <button type="button" class="button button-secondary yp-yoo-btn yp-yoo-btn--soft yp-clear-banner-cancel">` + cancelLabel + `</button>
              <button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary yp-clear-banner-confirm">` + clearNotifications + `</button>
            </div>
          </div>
        </div>
      `;
      jQuery('body').append(modalHTML);
    }
    
    // Initialize modal
    createClearBannerModal();
    
    var $modal = jQuery('#yp-clear-banner-modal');
    var $confirmBtn = $modal.find('.yp-clear-banner-confirm');
    
    // Open modal
    function openClearBannerModal() {
      $modal.fadeIn(200);
      jQuery('body').addClass('yp-modal-open');
    }
    
    // Close modal
    function closeClearBannerModal() {
      $modal.fadeOut(200);
      jQuery('body').removeClass('yp-modal-open');
    }
    
    // Handle button click - open modal
    clearBtn.addEventListener('click', function(e) {
      e.preventDefault();
      openClearBannerModal();
    });
    
    // Handle close button
    $modal.find('.yp-cleanup-close, .yp-clear-banner-cancel, .yp-cleanup-overlay').on('click', function() {
      closeClearBannerModal();
    });
    
    // Handle confirm button
    $confirmBtn.on('click', function() {
      closeClearBannerModal();
      
      // Disable button and show spinner
      clearBtn.disabled = true;
      if (spinner) spinner.style.display = 'inline-block';
      if (messageEl) {
        messageEl.style.display = 'none';
        messageEl.className = 'description';
      }
      
      // Make AJAX request
      jQuery.ajax({
        url: ajaxUrl,
        method: 'POST',
        data: {
          action: action,
          nonce: nonce
        },
        success: function(response) {
          if (response.success) {
            // Reset the client-side "already processed" tracking so live admin
            // banners are re-sent and re-converted on the next page load
            // (matches the "they will be re-generated" promise of this action).
            try {
              localStorage.removeItem('yooadmin_processed_banners');
              localStorage.removeItem('yooadmin_force_reprocess_banners');
              localStorage.setItem('yooadmin_clear_banner_storage', '1');
            } catch (e) {}

            if (messageEl) {
              messageEl.textContent = response.data.message || 'Banner notifications cleared successfully.';
              messageEl.className = 'description';
              messageEl.style.color = '#46b450';
              messageEl.style.display = 'block';
            }
            showToast(response.data.message || 'Banner notifications cleared successfully.');
            if (window.yooadmNotificationsUi) {
              if (typeof response.data.unread_count === 'number') {
                window.yooadmNotificationsUi.config.unreadCount = response.data.unread_count;
              }
              if (typeof window.yooadmNotificationsUi.refreshBadgeCount === 'function') {
                window.yooadmNotificationsUi.refreshBadgeCount();
              }
              if (typeof window.yooadmNotificationsUi.loadNotifications === 'function') {
                window.yooadmNotificationsUi.loadNotifications(true, { silent: true });
              }
            }
          } else {
            if (messageEl) {
              messageEl.textContent = response.data.message || 'Failed to clear banner notifications.';
              messageEl.className = 'description';
              messageEl.style.color = '#dc3232';
              messageEl.style.display = 'block';
            }
            showToast(response.data.message || 'Failed to clear banner notifications.', 'error');
          }
        },
        error: function(xhr, status, error) {
          if (messageEl) {
            messageEl.textContent = 'Error: ' + (error || 'Unknown error occurred');
            messageEl.className = 'description';
            messageEl.style.color = '#dc3232';
            messageEl.style.display = 'block';
          }
          showToast('Error clearing banner notifications: ' + (error || 'Unknown error occurred'), 'error');
        },
        complete: function() {
          clearBtn.disabled = false;
          if (spinner) spinner.style.display = 'none';
        }
      });
    });
  }

  /* ---------------- Toggle Label Switching ---------------- */
  $('.yp-toggle-switch input[type="checkbox"]').on('change', function() {
    const $checkbox = $(this);
    const $label = $checkbox.closest('.yp-toggle-container').find('.yp-toggle-label');
    const fieldId = $checkbox.attr('id');
    
    const labelPairs = {
      'posts_redirect': {
        on: 'Use YOOAdmin posts pages',
        off: 'Stay on WordPress default posts screen'
      },
      'comments_redirect': {
        on: 'Use YOOAdmin comments page',
        off: 'Stay on WordPress default comments screen'
      },
      'pages_redirect': {
        on: 'Use YOOAdmin pages pages',
        off: 'Stay on WordPress default pages screen'
      },
      'categories_redirect': {
        on: 'Use YOOAdmin categories pages',
        off: 'Stay on WordPress default categories screen'
      },
      'tags_redirect': {
        on: 'Use YOOAdmin tags pages',
        off: 'Stay on WordPress default tags screen'
      }
    };
    
    if (labelPairs[fieldId]) {
      const labels = labelPairs[fieldId];
      $label.text($checkbox.is(':checked') ? labels.on : labels.off);
    }
  });

})(jQuery);
