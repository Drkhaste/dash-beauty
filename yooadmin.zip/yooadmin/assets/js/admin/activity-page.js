/**
 * YOOAdmin - Activity page script
 *
 * @package YOOAdmin
 */

(function ($) {
  'use strict';

  var state = {
    category: 'all',
    range: '30d',
    userId: 0,
    search: '',
    page: 1,
    hasMore: false,
    loading: false,
  };

  var searchTimer = null;
  var scrollObserver = null;

  function getWrap() {
    return $('[data-yooadmin-activity-page="true"]');
  }

  function setLoading(isLoading, append) {
    state.loading = isLoading;
    var $loader = $('#yoo-activity-loading-more');
    $('#yoo-activity-list').toggleClass('is-loading', isLoading && !append);
    if (isLoading && append) {
      $loader.removeAttr('hidden').attr('aria-hidden', 'false');
    } else {
      $loader.attr('hidden', 'hidden').attr('aria-hidden', 'true');
    }
  }

  function readInitialState() {
    var $wrap = getWrap();
    if (!$wrap.length) {
      return;
    }

    var $activeCategory = $wrap.find('[data-activity-category].is-active').first();
    var $activeRange = $wrap.find('[data-activity-range].is-active').first();
    var $userBtn = $wrap.find('.yoo-filter-btn--author').first();

    state.category = $activeCategory.data('activity-category') || 'all';
    state.range = $activeRange.data('activity-range') || '30d';
    state.userId = parseInt($userBtn.data('value'), 10) || 0;
    state.search = ($('#yoo-activity-search').val() || '').trim();
    state.page = 1;
    state.hasMore = !$('#yoo-activity-scroll-sentinel').prop('hidden');
  }

  function setUserFilterButton(userId, label) {
    var $btn = getWrap().find('.yoo-filter-btn--author');
    $btn.data('value', userId);
    $btn.find('.yoo-filter-label').text(label);
    $btn.toggleClass('is-active', userId > 0);
    var $remove = $btn.find('.yoo-filter-remove');
    if (userId > 0 && !$remove.length) {
      $(
        '<span class="yoo-filter-remove" data-filter="user" title="' +
          (yooadmActivity.i18n.clearFilter || 'Clear filter') +
          '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></span>'
      ).insertAfter($btn.find('.yoo-filter-label'));
    } else if (userId === 0) {
      $remove.remove();
    }
  }

  function updateInfiniteState(data) {
    var hasMore = !!(data && data.has_more);
    state.hasMore = hasMore;
    state.page = data && data.page ? parseInt(data.page, 10) : state.page;

    $('#yoo-activity-scroll-sentinel').prop('hidden', !hasMore);
    $('#yoo-activity-end').prop('hidden', hasMore || !data || !data.total);

    if (!hasMore) {
      $('#yoo-activity-loading-more').attr('hidden', 'hidden').attr('aria-hidden', 'true');
    }

    if (data && typeof data.total !== 'undefined') {
      var countText = (yooadmActivity.i18n.eventsCount || '%s events').replace(
        '%s',
        String(data.total)
      );
      $('.yoo-activity-hero__count').text(countText);
    }
  }

  function fetchActivity(append) {
    if (state.loading || typeof yooadmActivity === 'undefined') {
      return;
    }

    setLoading(true, append);

    $.ajax({
      url: yooadmActivity.ajaxUrl,
      type: 'POST',
      data: {
        action: 'yooadmin_filter_activity',
        nonce: yooadmActivity.nonce,
        category: state.category,
        range: state.range,
        user_id: state.userId,
        search: state.search,
        page: state.page,
        per_page: 20,
      },
    })
      .done(function (response) {
        if (!response || !response.success || !response.data) {
          window.alert(yooadmActivity.i18n.error);
          return;
        }

        var html = response.data.html || '';
        var $list = $('#yoo-activity-list');

        if (append) {
          $list.append(html);
        } else {
          $list.html(html);
        }

        updateInfiniteState(response.data);
        tryFillViewport();
      })
      .fail(function () {
        window.alert(yooadmActivity.i18n.error);
        if (append && state.page > 1) {
          state.page -= 1;
        }
      })
      .always(function () {
        setLoading(false, append);
      });
  }

  function loadMoreActivity() {
    if (state.loading || !state.hasMore) {
      return;
    }
    state.page += 1;
    fetchActivity(true);
  }

  function resetAndFetch() {
    state.page = 1;
    fetchActivity(false);
  }

  function tryFillViewport() {
    setTimeout(function () {
      if (state.loading || !state.hasMore) {
        return;
      }
      var docH = $(document).height();
      var winH = $(window).height();
      if (docH <= winH + 400) {
        loadMoreActivity();
      }
    }, 150);
  }

  function closeDropdowns() {
    $('.yoo-filter-dropdown').attr('hidden', true);
    $('.yoo-filter-btn[data-filter="user"]').attr('aria-expanded', 'false');
  }

  function bindScrollObserver() {
    var sentinel = document.getElementById('yoo-activity-scroll-sentinel');
    if (!sentinel || typeof IntersectionObserver === 'undefined') {
      return;
    }

    if (scrollObserver) {
      scrollObserver.disconnect();
    }

    scrollObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            loadMoreActivity();
          }
        });
      },
      { root: null, rootMargin: '240px 0px', threshold: 0 }
    );

    scrollObserver.observe(sentinel);
  }

  function bindScrollFallback() {
    var scrollTimeout;
    $(window).on('scroll.yooActivityInfinite', function () {
      if (scrollTimeout) {
        clearTimeout(scrollTimeout);
      }
      scrollTimeout = setTimeout(function () {
        if (state.loading || !state.hasMore) {
          return;
        }
        var scrollTop = $(window).scrollTop();
        var windowHeight = $(window).height();
        var documentHeight = $(document).height();
        if (scrollTop + windowHeight > documentHeight - 300) {
          loadMoreActivity();
        }
      }, 100);
    });
  }

  function bindFilters() {
    var $wrap = getWrap();
    if (!$wrap.length) {
      return;
    }

    $wrap.on('click', '[data-activity-category]', function () {
      var $chip = $(this);
      $wrap.find('[data-activity-category]').removeClass('is-active');
      $chip.addClass('is-active');
      state.category = $chip.data('activity-category') || 'all';
      resetAndFetch();
    });

    $wrap.on('click', '[data-activity-range]', function () {
      var $chip = $(this);
      $wrap.find('[data-activity-range]').removeClass('is-active');
      $chip.addClass('is-active');
      state.range = $chip.data('activity-range') || 'all';
      resetAndFetch();
    });

    $wrap.on('click', '.yoo-filter-btn--author', function (e) {
      if ($(e.target).closest('.yoo-filter-remove').length) {
        return;
      }
      e.preventDefault();
      e.stopPropagation();
      var $dropdown = $(this).closest('.yoo-filter-dropdown-wrapper').find('.yoo-filter-dropdown');
      var isOpen = !$dropdown.prop('hidden');
      closeDropdowns();
      if (!isOpen) {
        $dropdown.removeAttr('hidden');
        $(this).attr('aria-expanded', 'true');
      }
    });

    $wrap.on('click', '.yoo-filter-option[data-user-id]', function () {
      var userId = parseInt($(this).data('user-id'), 10) || 0;
      var label = $(this).text().trim();
      state.userId = userId;
      setUserFilterButton(userId, label);
      closeDropdowns();
      resetAndFetch();
    });

    $wrap.on('click', '.yoo-filter-remove[data-filter="user"]', function (e) {
      e.preventDefault();
      e.stopPropagation();
      state.userId = 0;
      setUserFilterButton(0, yooadmActivity.i18n.allAdmins || 'All admins');
      closeDropdowns();
      resetAndFetch();
    });

    $(document).on('click.yooActivityDropdown', function (e) {
      if (!$(e.target).closest('.yoo-filter-dropdown-wrapper').length) {
        closeDropdowns();
      }
    });

    $('#yoo-activity-search').on('input', function () {
      var value = ($(this).val() || '').trim();
      if (searchTimer) {
        clearTimeout(searchTimer);
      }
      searchTimer = setTimeout(function () {
        if (state.search === value) {
          return;
        }
        state.search = value;
        resetAndFetch();
      }, 300);
    });

    $('#yoo-activity-search').on('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (searchTimer) {
          clearTimeout(searchTimer);
        }
        state.search = ($(this).val() || '').trim();
        resetAndFetch();
      }
    });
  }

  $(function () {
    if (!getWrap().length || typeof yooadmActivity === 'undefined') {
      return;
    }

    if (!yooadmActivity.i18n.allAdmins) {
      yooadmActivity.i18n.allAdmins = 'All admins';
    }

    readInitialState();
    bindFilters();
    bindScrollObserver();
    bindScrollFallback();
    tryFillViewport();
  });
})(jQuery);
