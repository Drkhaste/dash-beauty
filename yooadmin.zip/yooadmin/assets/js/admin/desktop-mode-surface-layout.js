(function () {
	function isDesktopSurfaceActive() {
		var body = document.body;
		return body
			&& body.classList.contains('yoo-focus')
			&& body.classList.contains('yooadmin-desktop-surface');
	}

	function hasExpandedDesktopWindow() {
		return !!document.querySelector('.desktop-mode-window--maximized, .desktop-mode-window--fullscreen');
	}

	function syncDesktopSurfaceLayout() {
		if (!isDesktopSurfaceActive()) {
			return;
		}

		var breadcrumbs = document.querySelector('.yp-breadcrumbs-bar');
		var shell = document.getElementById('desktop-mode-shell');
		var top = breadcrumbs ? Math.ceil(breadcrumbs.getBoundingClientRect().height) : 0;

		document.documentElement.style.setProperty('--yooadmin-desktop-surface-top', top + 'px');

		if (!shell) {
			return;
		}

		if (hasExpandedDesktopWindow()) {
			shell.style.removeProperty('inset-block-start');
			return;
		}

		shell.style.setProperty('inset-block-start', top + 'px', 'important');
	}

	function observeDesktopWindows() {
		var area = document.getElementById('desktop-mode-area');
		if (!area || area.__yooadminDesktopSurfaceWindowObserver) {
			return;
		}

		var observer = new MutationObserver(syncDesktopSurfaceLayout);
		observer.observe(area, {
			childList: true,
			subtree: true,
			attributes: true,
			attributeFilter: ['class', 'style']
		});
		area.__yooadminDesktopSurfaceWindowObserver = observer;
	}

	function boot() {
		if (!isDesktopSurfaceActive()) {
			return;
		}

		syncDesktopSurfaceLayout();
		observeDesktopWindows();
		window.addEventListener('resize', syncDesktopSurfaceLayout);
		window.addEventListener('load', syncDesktopSurfaceLayout);
		if (typeof ResizeObserver !== 'undefined') {
			var breadcrumbs = document.querySelector('.yp-breadcrumbs-bar');
			if (breadcrumbs) {
				new ResizeObserver(syncDesktopSurfaceLayout).observe(breadcrumbs);
			}
		}
		window.setTimeout(syncDesktopSurfaceLayout, 0);
		window.setTimeout(syncDesktopSurfaceLayout, 200);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
