(function () {
	'use strict';

	var cfg = window.yooadminLangSwitcher || {};
	var ajaxUrl = cfg.ajaxUrl || (window.ajaxurl || '');
	var nonce = cfg.nonce || '';
	var errorText = (cfg.strings && cfg.strings.error) || 'Could not save your language preference. Please try again.';

	function setMenuOpen(root, open) {
		var toggle = root.querySelector('.yp-breadcrumbs-lang__toggle');
		var menu = root.querySelector('.yp-breadcrumbs-lang__menu');
		if (!toggle || !menu) {
		 return;
		}
		if (open) {
			menu.removeAttribute('hidden');
			root.classList.add('is-open');
			toggle.setAttribute('aria-expanded', 'true');
		} else {
			menu.setAttribute('hidden', 'hidden');
			root.classList.remove('is-open');
			toggle.setAttribute('aria-expanded', 'false');
		}
	}

	function closeAllLangMenus(except) {
		document.querySelectorAll('.yp-breadcrumbs-lang.is-open').forEach(function (root) {
			if (except && root === except) {
				return;
			}
			setMenuOpen(root, false);
		});
	}

	function bindDocCloseOnce() {
		if (bindDocCloseOnce.done) {
			return;
		}
		bindDocCloseOnce.done = true;

		document.addEventListener(
			'mousedown',
			function (e) {
				var open = document.querySelector('.yp-breadcrumbs-lang.is-open');
				if (open && !open.contains(e.target)) {
					setMenuOpen(open, false);
				}
			},
			true
		);

		document.addEventListener('keydown', function (e) {
			if (e.key !== 'Escape') {
				return;
			}
			closeAllLangMenus(null);
		});
	}

	function saveLocale(locale, root) {
		if (!ajaxUrl || !nonce) {
			window.location.reload();
			return;
		}

		var body = new URLSearchParams();
		body.set('action', 'yooadmin_set_user_locale');
		body.set('nonce', nonce);
		body.set('locale', locale);

		root.setAttribute('aria-busy', 'true');

		fetch(ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			},
			body: body.toString(),
		})
			.then(function (res) {
				return res.json();
			})
			.then(function (payload) {
				if (!payload || !payload.success) {
					throw new Error((payload && payload.data && payload.data.message) || errorText);
				}
				window.location.reload();
			})
			.catch(function () {
				window.alert(errorText);
				root.removeAttribute('aria-busy');
			});
	}

	function initRoot(root) {
		if (!root || root.getAttribute('data-yooadmin-lang-init') === '1') {
			return;
		}
		root.setAttribute('data-yooadmin-lang-init', '1');

		var toggle = root.querySelector('.yp-breadcrumbs-lang__toggle');
		var menu = root.querySelector('.yp-breadcrumbs-lang__menu');
		if (!toggle || !menu) {
			return;
		}

		bindDocCloseOnce();

		toggle.addEventListener('click', function (e) {
			e.preventDefault();
			e.stopPropagation();
			var isOpen = root.classList.contains('is-open');
			closeAllLangMenus(root);
			setMenuOpen(root, !isOpen);
		});

		menu.addEventListener('click', function (e) {
			var btn = e.target.closest('[data-yooadmin-locale]');
			if (!btn || !menu.contains(btn)) {
				return;
			}
			if (btn.classList.contains('is-active')) {
				setMenuOpen(root, false);
				return;
			}
			if (root.getAttribute('aria-busy') === 'true') {
				return;
			}

			e.preventDefault();
			var locale = btn.getAttribute('data-yooadmin-locale');
			if (locale == null) {
				return;
			}
			setMenuOpen(root, false);
			saveLocale(String(locale), root);
		});
	}

	function initAll() {
		document.querySelectorAll('[data-yooadmin-lang-switcher]').forEach(initRoot);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initAll);
	} else {
		initAll();
	}
})();
