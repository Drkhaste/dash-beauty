/**
 * YOOAdmin — apply global yp-yoo-btn classes to native WordPress admin buttons.
 */
(function () {
	'use strict';

	function shouldSkipButton(btn) {
		if (!btn || !btn.classList) {
			return true;
		}
		if (btn.classList.contains('yp-yoo-btn')) {
			return true;
		}
		if (
			btn.classList.contains('button-link') ||
			btn.classList.contains('button-link-delete') ||
			btn.classList.contains('ed_button') ||
			btn.classList.contains('mce-button') ||
			btn.classList.contains('gkit-onboard-tutorial--link') ||
			btn.classList.contains('gkit-onboard-tutorial--btn')
		) {
			return true;
		}
		if (btn.closest && btn.closest('.yp-ui-select')) {
			return true;
		}
		if (
			btn.closest &&
			btn.closest(
				'.yoo-pages-hero, .yoo-posts-hero, .yoo-users-hero, .yoo-pages-toolbar, .yoo-pages-filters, .tablenav-pages, .yoo-plugins-toolbar-extras'
			)
		) {
			return true;
		}
		if (
			btn.classList.contains('yoo-plugins-search-submit') ||
			btn.classList.contains('yoo-posts-metrics-toggle') ||
			btn.classList.contains('yoo-pages-metrics-toggle') ||
			btn.classList.contains('yoo-users-metrics-toggle') ||
			btn.classList.contains('yoo-categories-metrics-toggle') ||
			btn.classList.contains('yoo-tags-metrics-toggle')
		) {
			return true;
		}
		return false;
	}

	function classifyButton(btn) {
		btn.classList.add('yp-yoo-btn');
		if (
			btn.classList.contains('gkit-onboard-btn') &&
			(btn.classList.contains('prev') || btn.classList.contains('skip-next'))
		) {
			btn.classList.add('yp-yoo-btn--secondary');
			return;
		}
		if (
			btn.classList.contains('button-primary') ||
			btn.classList.contains('button-hero') ||
			btn.classList.contains('wpmet-notice-button') ||
			btn.classList.contains('gkit-onboard-btn') ||
			btn.classList.contains('gkit-pro-btn') ||
			btn.classList.contains('wpmet-pro-btn') ||
			btn.getAttribute('name') === 'publish' ||
			btn.id === 'publish' ||
			btn.id === 'save'
		) {
			btn.classList.add('yp-yoo-btn--primary');
			return;
		}
		if (
			btn.classList.contains('button-secondary') ||
			btn.classList.contains('yoo-button--secondary') ||
			btn.classList.contains('skip-next')
		) {
			btn.classList.add('yp-yoo-btn--secondary');
			return;
		}
		btn.classList.add('yp-yoo-btn--secondary');
	}

	function enhanceRoot(root) {
		if (!root || !root.querySelectorAll) {
			return;
		}
		var nodes = root.querySelectorAll(
			'.wp-core-ui .button, .wp-core-ui input[type="submit"].button, .wp-core-ui input[type="button"].button, .wp-core-ui a.button, #wpbody-content .wpmet-notice-button, #wpbody-content .gkit-onboard-btn, #wpbody-content .gkit-pro-btn, #wpbody-content .wpmet-pro-btn, #wpbody-content a[class*="-onboard-btn"], #wpbody-content button[class*="-onboard-btn"]'
		);
		for (var i = 0; i < nodes.length; i++) {
			var btn = nodes[i];
			if (shouldSkipButton(btn)) {
				continue;
			}
			classifyButton(btn);
		}
	}

	var debounceTimer;
	function debouncedEnhance() {
		clearTimeout(debounceTimer);
		debounceTimer = setTimeout(function () {
			enhanceRoot(document.body);
		}, 80);
	}

	function isNativeListScreen() {
		return (
			document.body &&
			document.body.classList.contains('yoo-list-screen') &&
			(document.body.classList.contains('plugins-php') ||
				document.body.classList.contains('edit-php') ||
				document.body.classList.contains('edit-tags-php') ||
				document.body.classList.contains('users-php'))
		);
	}

	function init() {
		if (!document.body) {
			return;
		}
		var studioHub =
			document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub') &&
			document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') ===
				'dark';
		if (
			!document.body.classList.contains('yoo-focus') &&
			!document.body.classList.contains('yoo-wp-settings-experience') &&
			!studioHub
		) {
			return;
		}

		/* plugins.php layout JS owns hero/toolbar/chips — full-body enhance on DOM churn recolors them. */
		if (!isNativeListScreen()) {
			enhanceRoot(document.body);
		}

		if (typeof MutationObserver !== 'undefined' && !isNativeListScreen()) {
			var observer = new MutationObserver(debouncedEnhance);
			observer.observe(document.body, { childList: true, subtree: true });
		}
	}

	window.yooadminEnhanceGlobalButtons = enhanceRoot;

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init, { once: true });
	} else {
		init();
	}
})();
