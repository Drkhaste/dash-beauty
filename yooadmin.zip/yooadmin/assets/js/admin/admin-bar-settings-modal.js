/**
 * Admin bar settings overlay (Security / Maintenance) when Focus Mode is off.
 * Panel HTML is loaded via AJAX — never opens the full settings admin page.
 *
 * @package YOOAdmin
 */

(function ($) {
  'use strict';

  var cfg = window.yooadminAdminBarSettingsModal || {};
  var $root = $('#yooadmin-ab-settings-modal');
  var activePanel = '';
  var loadedPanels = {};

  function ajaxUrl() {
    return cfg.ajaxUrl || window.ajaxurl || '';
  }

  function portalModal() {
    var el = document.getElementById('yooadmin-ab-settings-modal');
    if (el && el.parentNode !== document.body) {
      document.body.appendChild(el);
    }
  }

  function setLoading(on) {
    $root.find('.yooadmin-ab-settings-modal__loading').prop('hidden', !on);
    $root.find('.yooadmin-ab-settings-modal__content').toggleClass('is-loading', !!on);
  }

  function loadPanel(panel) {
    var deferred = $.Deferred();

    if (loadedPanels[panel]) {
      $root.find('.yooadmin-ab-settings-modal__content').html(loadedPanels[panel]);
      $(document).trigger('yooadmin:ab-settings-panel-loaded', [panel]);
      deferred.resolve();
      return deferred.promise();
    }

    setLoading(true);

    $.ajax({
      url: ajaxUrl(),
      type: 'POST',
      dataType: 'json',
      data: {
        action: 'yooadmin_admin_bar_settings_panel',
        nonce: cfg.nonce,
        panel: panel
      }
    })
      .done(function (response) {
        if (!response || !response.success || !response.data || !response.data.html) {
          deferred.reject();
          return;
        }

        loadedPanels[panel] = response.data.html;
        $root.find('.yooadmin-ab-settings-modal__content').html(response.data.html);
        $(document).trigger('yooadmin:ab-settings-panel-loaded', [panel]);
        deferred.resolve();
      })
      .fail(function () {
        deferred.reject();
      })
      .always(function () {
        setLoading(false);
      });

    return deferred.promise();
  }

  function openModal(panel) {
    if (!$root.length) {
      return;
    }

    activePanel = panel || 'login-security';
    portalModal();

    var title = (cfg.titles && cfg.titles[activePanel]) ? cfg.titles[activePanel] : '';
    $root.find('.yooadmin-ab-settings-modal__title').text(title);
    $root.find('.yooadmin-ab-settings-modal__content').empty();

    $root.removeAttr('hidden').addClass('is-open').attr('aria-hidden', 'false');
    $('body').addClass('yp-modal-open yooadmin-ab-settings-modal-open');

    loadPanel(activePanel).fail(function () {
      window.alert(cfg.loadError || 'Could not load settings.');
      closeModal();
    });
  }

  function closeModal() {
    if (!$root.length) {
      return;
    }

    $root.removeClass('is-open').attr('aria-hidden', 'true').attr('hidden', 'hidden');
    $('body').removeClass('yp-modal-open yooadmin-ab-settings-modal-open');
    activePanel = '';
  }

  function showToast(msg, type) {
    var message = msg || cfg.saveSuccess || 'Settings saved.';
    type = type || 'success';

    if (typeof window.yooadminSettingsToast === 'function') {
      window.yooadminSettingsToast(message, type);
      return;
    }

    if (window.yooadmToast) {
      if (type === 'error' && typeof window.yooadmToast.error === 'function') {
        window.yooadmToast.error(message);
        return;
      }
      if (type === 'success' && typeof window.yooadmToast.success === 'function') {
        window.yooadmToast.success(message);
        return;
      }
      if (typeof window.yooadmToast.show === 'function') {
        window.yooadmToast.show(message, type);
        return;
      }
    }

    if (typeof window.yooadminShowToast === 'function') {
      window.yooadminShowToast(message, type);
    }
  }

  function savePanel() {
    var form = document.getElementById('yooadmin-ab-settings-form');
    if (!form) {
      return $.Deferred().reject().promise();
    }

    return $.ajax({
      url: ajaxUrl(),
      type: 'POST',
      dataType: 'json',
      data: {
        action: 'yooadmin_save_settings',
        nonce: cfg.settingsNonce,
        data: $(form).serialize()
      }
    });
  }

  function onSave() {
    var $btn = $root.find('.yooadmin-ab-settings-modal__save');
    var label = $btn.text();
    var turnstileErr = typeof window.yooadminValidateLoginTurnstileBeforeSave === 'function'
      ? window.yooadminValidateLoginTurnstileBeforeSave()
      : null;
    if (turnstileErr) {
      showToast(turnstileErr, 'error');
      return;
    }

    $btn.prop('disabled', true);

    savePanel()
      .done(function (response) {
        if (response && response.success) {
          var msg = (response.data && response.data.message) ? response.data.message : (cfg.saveSuccess || '');
          showToast(msg, 'success');
          delete loadedPanels[activePanel];
          closeModal();
          return;
        }
        showToast((response && response.data && response.data.message) || cfg.saveError || 'Error', 'error');
      })
      .fail(function () {
        showToast(cfg.saveError || 'Error', 'error');
      })
      .always(function () {
        $btn.prop('disabled', false).text(label);
      });
  }

  window.yooadminAbSettingsModalOpen = openModal;

  $(document).on('click', '[data-yooadmin-ab-settings-close], .yooadmin-ab-settings-modal__backdrop', function (e) {
    e.preventDefault();
    closeModal();
  });

  $(document).on('click', '.yooadmin-ab-settings-modal__save', function (e) {
    e.preventDefault();
    onSave();
  });

  $(document).on('click', '#wp-admin-bar-yooadmin-security-settings, #wp-admin-bar-yooadmin-security-settings .ab-item, #wp-admin-bar-yooadmin-security-settings a', function (e) {
    e.preventDefault();
    e.stopPropagation();
    openModal('login-security');
  });

  $(document).on('click', '#wpadminbar .yooadmin-maintenance-pill__settings-link', function (e) {
    if (typeof window.yooadminAbSettingsModalOpen !== 'function' || !$root.length) {
      return;
    }
    e.preventDefault();
    e.stopPropagation();
    openModal('maintenance');
  });

  $(document).on('keydown', function (e) {
    if (e.key === 'Escape' && $root.hasClass('is-open')) {
      closeModal();
    }
  });

  $(document).ready(function () {
    $root = $('#yooadmin-ab-settings-modal');
  });
})(jQuery);
