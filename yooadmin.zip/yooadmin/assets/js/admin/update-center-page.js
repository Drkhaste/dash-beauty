/**
 * YOOUpdate Center — in-page updates (AJAX), progress UI, no navigation to update-core/update.php.
 */
(function ($) {
    'use strict';

    function getUpdatableBoxes($table) {
        return $table.find('input[type="checkbox"][name="checked[]"]:not(:disabled)');
    }

    function syncSelectAll(tableId, masterIds) {
        var $table = $('#' + tableId);
        if (!$table.length) {
            return;
        }
        var $boxes = getUpdatableBoxes($table);

        function setMasters(state) {
            masterIds.forEach(function (id) {
                var $m = $('#' + id);
                if (!$m.length) {
                    return;
                }
                $m.prop('indeterminate', false);
                $m.prop('checked', state);
            });
        }

        function updateMasterFromBoxes() {
            var total = $boxes.length;
            var checked = $boxes.filter(':checked').length;
            var all = total > 0 && checked === total;
            var none = checked === 0;
            masterIds.forEach(function (id) {
                var $m = $('#' + id);
                if (!$m.length) {
                    return;
                }
                if (all) {
                    $m.prop('indeterminate', false);
                    $m.prop('checked', true);
                } else if (none) {
                    $m.prop('indeterminate', false);
                    $m.prop('checked', false);
                } else {
                    $m.prop('checked', false);
                    $m.prop('indeterminate', true);
                }
            });
        }

        masterIds.forEach(function (id) {
            $(document).off('change.yooUcSync', '#' + id).on('change.yooUcSync', '#' + id, function () {
                var on = $(this).prop('checked');
                $boxes.prop('checked', on);
                setMasters(on);
            });
        });

        $table.off('change.yooUcSync', 'input[name="checked[]"]').on('change.yooUcSync', 'input[name="checked[]"]', updateMasterFromBoxes);
        updateMasterFromBoxes();
    }

    function syncAllUcTables() {
        syncSelectAll('update-plugins-table', ['plugins-select-all']);
        syncSelectAll('update-themes-table', ['themes-select-all']);
    }

    function refreshBulkStrips() {
        $('.yoo-uc-form--plugins').each(function () {
            var $f = $(this);
            var n = $f.find('input[name="checked[]"]:checked').length;
            $f.find('#yoo-uc-plugins-bulk').prop('hidden', n === 0);
        });
        $('.yoo-uc-form--themes').each(function () {
            var $f = $(this);
            var n = $f.find('input[name="checked[]"]:checked').length;
            $f.find('#yoo-uc-themes-bulk').prop('hidden', n === 0);
        });
    }

    function getUcTabNav() {
        return $('#yoo-uc-tabs-root .yp-tab-nav').first();
    }

    /** Same “orange bar” under the active tab as YOOAdmin Settings (.yp-tab-ink + yoo-settings.js). */
    function ensureUcTabInk() {
        var $nav = getUcTabNav();
        if (!$nav.length) {
            return null;
        }
        var ink = $nav.find('.yp-tab-ink')[0];
        if (!ink) {
            ink = document.createElement('span');
            ink.className = 'yp-tab-ink';
            ink.setAttribute('aria-hidden', 'true');
            $nav[0].appendChild(ink);
        }
        return ink;
    }

    function moveUcTabInk($btn) {
        var ink = ensureUcTabInk();
        var $nav = getUcTabNav();
        if (!ink || !$nav.length || !$btn || !$btn.length) {
            return;
        }
        var r = $btn[0].getBoundingClientRect();
        var rn = $nav[0].getBoundingClientRect();
        ink.style.width = r.width + 'px';
        ink.style.left = r.left - rn.left + 'px';
    }

    function activateUcTab(name) {
        if (!name) {
            return;
        }
        $('.yoo-uc-tab').removeClass('active is-active').attr('aria-selected', 'false');
        $('.yoo-uc-tab-panel').removeClass('is-active').prop('hidden', true);
        var $btn = $('.yoo-uc-tab[data-yoo-uc-tab="' + name + '"]');
        var $panel = $('.yoo-uc-tab-panel[data-yoo-uc-panel="' + name + '"]');
        if ($btn.length && $panel.length) {
            $btn.addClass('is-active').attr('aria-selected', 'true');
            $panel.addClass('is-active').prop('hidden', false);
            moveUcTabInk($btn);
        }
    }

    function cfg() {
        return window.yooadminUpdateCenter || {};
    }

    function i18n(key, fb) {
        var o = cfg().i18n || {};
        return o[key] || fb || key;
    }

    function progressSpinnerSet(visible) {
        var $sp = $('#yoo-uc-progress-spinner');
        if (!$sp.length) {
            return;
        }
        $sp.prop('hidden', !visible);
    }

    /** Current WP version from hero or localized fallback; target = core update package version. */
    /**
     * Same toast UX as notifications dropdown (yp-toast-*); uses yooadmNotificationsUi when loaded.
     */
    function showUcToast(message, type) {
        type = type || 'success';
        if (
            window.yooadmNotificationsUi &&
            typeof window.yooadmNotificationsUi.showToastMessage === 'function'
        ) {
            window.yooadmNotificationsUi.showToastMessage(message, type);
            return;
        }
        $('.yp-toast-message.yoo-uc-toast-fallback').remove();
        var icon = type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ';
        var $toast = $(
            '<div class="yp-toast-message yp-toast-' +
                type +
                ' yoo-uc-toast-fallback" role="status">' +
                '<span class="yp-toast-icon" aria-hidden="true">' +
                icon +
                '</span>' +
                '<span class="yp-toast-text"></span></div>'
        );
        $toast.find('.yp-toast-text').text(String(message || ''));
        $('body').append($toast);
        setTimeout(function () {
            $toast.addClass('yp-toast-show');
        }, 10);
        setTimeout(function () {
            $toast.removeClass('yp-toast-show');
            setTimeout(function () {
                $toast.remove();
            }, 300);
        }, 3000);
    }

    function showCoreUpdatedToastAfterOk(version) {
        var v = String(version || '').trim();
        var tpl = i18n('coreUpdatedToast', 'WordPress was updated successfully to %s');
        var msg = tpl.indexOf('%s') >= 0 ? tpl.replace('%s', v || '—') : tpl + (v ? ' ' + v : '');
        showUcToast(msg, 'success');
    }

    function formatCoreUpdateTitle(targetVersion, isReinstall) {
        if (isReinstall) {
            var rv = String(targetVersion || '').trim();
            var rtpl = i18n('coreReinstallingTitle', 'Reinstalling WordPress %s');
            return rtpl.replace('%s', rv || '—');
        }
        var cur =
            (($('#yoo-uc-wp-version-num').text() || '').trim() ||
                (cfg().wpVersion != null ? String(cfg().wpVersion) : '') ||
                '').trim();
        var to = String(targetVersion || '').trim();
        if (!to) {
            return i18n('working', 'Updating WordPress');
        }
        var tpl = i18n('coreUpdatingFromTo', 'Updating from %1$s to %2$s');
        return tpl.replace('%1$s', cur || '—').replace('%2$s', to);
    }

    function ucFailMessage(err) {
        if (err && err.message) {
            return err.message;
        }
        if (err && err.payload && err.payload.data && err.payload.data.message) {
            return err.payload.data.message;
        }
        if (err && err.jqXHR && err.jqXHR.responseJSON && err.jqXHR.responseJSON.data && err.jqXHR.responseJSON.data.message) {
            return err.jqXHR.responseJSON.data.message;
        }
        return i18n('requestFailed', 'Request failed. Please try again.');
    }

    /**
     * Extract one JSON object starting at index of `{` (handles strings with `}` inside).
     */
    function extractBalancedJsonObject(raw, start) {
        var depth = 0;
        var inStr = false;
        var quote = '';
        var esc = false;
        var i;
        for (i = start; i < raw.length; i++) {
            var ch = raw[i];
            if (inStr) {
                if (esc) {
                    esc = false;
                    continue;
                }
                if (ch === '\\') {
                    esc = true;
                    continue;
                }
                if (ch === quote) {
                    inStr = false;
                    quote = '';
                }
                continue;
            }
            if (ch === '"' || ch === "'") {
                inStr = true;
                quote = ch;
                continue;
            }
            if (ch === '{') {
                depth++;
            } else if (ch === '}') {
                depth--;
                if (depth === 0) {
                    return raw.slice(start, i + 1);
                }
            }
        }
        return null;
    }

    /**
     * Parse admin-ajax JSON even when junk precedes the payload or `}` appears inside a string.
     */
    function parseWpAjaxJson(raw) {
        raw = String(raw == null ? '' : raw);
        raw = raw.replace(/^\uFEFF/, '').trim();
        if (!raw) {
            return null;
        }
        function tryParse(s) {
            try {
                return JSON.parse(s);
            } catch (e) {
                return null;
            }
        }
        var direct = tryParse(raw);
        if (direct) {
            return direct;
        }
        var marker = '{"success"';
        var i = raw.indexOf(marker);
        while (i >= 0) {
            var sliceStart = i;
            var balanced = extractBalancedJsonObject(raw, sliceStart);
            var sub = balanced ? tryParse(balanced) : tryParse(raw.slice(i));
            if (sub && typeof sub.success !== 'undefined') {
                return sub;
            }
            i = raw.indexOf(marker, i + 1);
        }
        var fb = raw.indexOf('{');
        while (fb >= 0) {
            var chunk = extractBalancedJsonObject(raw, fb);
            if (chunk) {
                var o = tryParse(chunk);
                if (o && typeof o.success !== 'undefined') {
                    return o;
                }
            }
            fb = raw.indexOf('{', fb + 1);
        }
        return null;
    }

    function ucPost(action, data) {
        return $.ajax({
            url: cfg().ajaxUrl,
            type: 'POST',
            dataType: 'text',
            data: $.extend({ action: action, nonce: cfg().nonce }, data || {}),
        }).then(
            function (text, textStatus, jqXHR) {
                var res = parseWpAjaxJson(text);
                if ((!res || typeof res.success === 'undefined') && jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.success) {
                    res = jqXHR.responseJSON;
                }
                if (res && res.success) {
                    return res;
                }
                var msg = i18n('error', 'Something went wrong.');
                if (res && res.data && res.data.message) {
                    msg = res.data.message;
                }
                return $.Deferred().reject({ message: msg, payload: res, raw: text }).promise();
            },
            function (jqXHR) {
                var raw = jqXHR && jqXHR.responseText ? String(jqXHR.responseText) : '';
                var res = parseWpAjaxJson(raw);
                if ((!res || typeof res.success === 'undefined') && jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.success) {
                    res = jqXHR.responseJSON;
                }
                if (res && res.success) {
                    return res;
                }
                var msg = i18n('requestFailed', 'Request failed. Please try again.');
                if (res && res.data && res.data.message) {
                    msg = res.data.message;
                } else if (jqXHR && jqXHR.status === 200 && raw && !res) {
                    msg = i18n('jsonCorrupt', 'The server sent an incomplete response. If the update finished, refresh this page.');
                }
                return $.Deferred().reject({ message: msg, jqXHR: jqXHR, payload: res, raw: raw }).promise();
            }
        );
    }

    function maybeThickbox() {
        if (typeof window.tb_init === 'function') {
            try {
                window.tb_init('a.thickbox, .thickbox');
            } catch (e) { /* ignore */ }
        }
    }

    /** Sync tab count badges with {@see wp_get_update_data()} payload from AJAX. */
    function applyTabBadges(totals) {
        if (!totals || !totals.counts) {
            return;
        }
        var c = totals.counts;
        function setBadge(tabSelector, key) {
            var $tab = $(tabSelector);
            if (!$tab.length) {
                return;
            }
            var n = parseInt(c[key], 10);
            if (isNaN(n) || n < 0) {
                n = 0;
            }
            var $b = $tab.find('.yoo-uc-tab__badge');
            if (n > 0) {
                if ($b.length) {
                    $b.text(String(n));
                } else {
                    $tab.append($('<span class="yoo-uc-tab__badge"></span>').text(String(n)));
                }
            } else {
                $b.remove();
            }
        }
        setBadge('#yoo-uc-tab-plugins', 'plugins');
        setBadge('#yoo-uc-tab-themes', 'themes');
        setBadge('#yoo-uc-tab-translations', 'translations');
        var $a = $('#yoo-uc-tabs-root .yp-tab.yoo-uc-tab.is-active').first();
        if ($a.length) {
            moveUcTabInk($a);
        }
    }

    function applySections(sections, totals) {
        try {
            if (!sections) {
                return;
            }
            if (sections.core_dynamic_html !== undefined) {
                $('#yoo-uc-core-dynamic').html(sections.core_dynamic_html);
            }
            if (sections.plugins_html !== undefined) {
                $('#yoo-uc-plugins-wrap').html(sections.plugins_html);
            }
            if (sections.themes_html !== undefined) {
                $('#yoo-uc-themes-wrap').html(sections.themes_html);
            }
            if (sections.translations_html !== undefined) {
                $('#yoo-uc-translations-wrap').html(sections.translations_html);
            }
            if (sections.wp_version) {
                $('#yoo-uc-wp-version-num').text(sections.wp_version);
            }
            if (sections.header_core_html !== undefined) {
                $('.yoo-upload-header-actions').html(sections.header_core_html);
            }
            if (sections.hero_aside_html !== undefined) {
                $('#yoo-uc-hero-aside').html(sections.hero_aside_html);
            }
            if (sections.floating_tooltips_html !== undefined) {
                var $floating = $('#yoo-uc-floating-ui');
                if (!$floating.length) {
                    $floating = $('<div id="yoo-uc-floating-ui" class="yoo-uc-floating-ui"></div>').appendTo('body');
                }
                $floating.html(sections.floating_tooltips_html);
            }
            if (sections.hero_maintenance_html !== undefined) {
                $('#yoo-uc-hero-maintenance-slot').html(sections.hero_maintenance_html);
            }
            if (sections.preface_html !== undefined) {
                var $ps = $('#yoo-uc-preface-slot');
                if ($ps.length) {
                    $ps.html(sections.preface_html);
                }
            }
            if (totals) {
                applyTabBadges(totals);
                if (window._wpUpdatesItemCounts) {
                    window._wpUpdatesItemCounts.totals = totals;
                }
            }
            maybeThickbox();
            syncAllUcTables();
            refreshBulkStrips();
            initUcAutoModeTooltips();
        } catch (e) {
            /* applySections failed; UI state unchanged */
        }
    }

    var $root;
    var $bar;
    var $step;
    var $pct;
    var $log;
    var $title;

    function progressOpen(titleText) {
        $root = $('#yoo-uc-progress-root');
        $bar = $('#yoo-uc-progress-bar');
        $step = $('#yoo-uc-progress-step');
        $pct = $('#yoo-uc-progress-pct');
        $log = $('#yoo-uc-progress-log');
        $title = $('#yoo-uc-progress-title');
        $('.yoo-uc-progress-modal').removeClass('yoo-uc-progress-modal--success');
        progressSpinnerSet(true);
        if ($title.length) {
            $title.text(titleText || i18n('working', 'Working…'));
        }
        $step.text('');
        if ($pct.length) {
            $pct.text('0%');
        }
        $log.empty();
        if ($bar.length) {
            $bar.css('width', '0%');
        }
        $('#yoo-uc-progress-footer').prop('hidden', true);
        $('#yoo-uc-progress-ok')
            .prop('disabled', false)
            .off('click.yooUcCoreOk click.yooUcQueueOk click.yooUcTrOk');
        $root.prop('hidden', false).attr('aria-hidden', 'false');
    }

    function progressShowSuccess(stepMessage) {
        progressSpinnerSet(false);
        $('.yoo-uc-progress-modal').addClass('yoo-uc-progress-modal--success');
        if ($title && $title.length) {
            $title.text(i18n('successTitle', 'Update complete'));
        }
        progressSet(100, stepMessage || i18n('allUpdatesDone', 'All updates finished successfully.'));
    }

    function progressSet(pct, line) {
        pct = Math.max(0, Math.min(100, pct));
        var n = Math.round(pct);
        if ($bar && $bar.length) {
            $bar.css('width', pct + '%');
        }
        if ($pct && $pct.length) {
            $pct.text(n + '%');
        }
        if (line !== undefined && line !== null && $step && $step.length) {
            $step.text(line);
        }
    }

    function progressLog(line) {
        if (!$log || !$log.length) {
            return;
        }
        $('<li></li>').text(line).appendTo($log);
    }

    function progressClose() {
        progressSpinnerSet(false);
        var $r = $('#yoo-uc-progress-root');
        $r.prop('hidden', true).attr('aria-hidden', 'true');
    }

    function portalUcOverlays() {
        var $root = $('#yoo-uc-progress-root');
        if ($root.length && !$root.data('yooUcPortaled')) {
            $root.data('yooUcPortaled', 1);
            $('body').append($root);
        }

        var $floating = $('#yoo-uc-floating-ui');
        if ($floating.length && !$floating.data('yooUcPortaled')) {
            $floating.data('yooUcPortaled', 1);
            $('body').append($floating);
        }
    }

    function placeUcAutoModeTooltip($anchor, $tip) {
        if (!$anchor.length || !$tip.length) {
            return;
        }
        var rect = $anchor[0].getBoundingClientRect();
        var gap = 10;
        var margin = 8;
        var tipWidth = Math.min(320, window.innerWidth - margin * 2);
        $tip.css({ width: tipWidth + 'px' });
        var tipHeight = $tip.outerHeight();
        var top = Math.max(margin, rect.top - tipHeight - gap);
        var isRtl = document.documentElement.dir === 'rtl';
        var left = isRtl ? rect.right - tipWidth : rect.left;
        left = Math.max(margin, Math.min(left, window.innerWidth - tipWidth - margin));
        $tip.css({ top: top + 'px', left: left + 'px', right: 'auto', bottom: 'auto' });
    }

    function initUcAutoModeTooltips() {
        $('[data-yoo-uc-tip-target]').each(function () {
            var $anchor = $(this);
            var tipId = $anchor.attr('data-yoo-uc-tip-target');
            if (!tipId) {
                return;
            }

            var $tip = document.getElementById(tipId) ? $('#' + tipId) : $();
            if (!$tip.length) {
                $tip = $anchor.find('.yoo-uc-auto-mode-tooltip').first();
                if ($tip.length && !$tip.data('yooUcPortaled')) {
                    $tip.data('yooUcPortaled', 1);
                    $tip.addClass('yoo-uc-auto-mode-tooltip--portaled');
                    var $floating = $('#yoo-uc-floating-ui');
                    if (!$floating.length) {
                        $floating = $('<div id="yoo-uc-floating-ui" class="yoo-uc-floating-ui"></div>').appendTo('body');
                    }
                    $floating.append($tip);
                }
            }

            if (!$tip.length || $anchor.data('yooUcTipBound')) {
                return;
            }

            $anchor.data('yooUcTipBound', 1);
            $tip.data('yooUcAnchor', $anchor);
            $tip.addClass('yoo-uc-auto-mode-tooltip--portaled');

            function showTip() {
                $tip.addClass('is-visible');
                placeUcAutoModeTooltip($anchor, $tip);
            }

            function hideTip() {
                $tip.removeClass('is-visible');
            }

            $anchor.off('.yooUcAutoTip');
            $tip.off('.yooUcAutoTip');
            $anchor.on('mouseenter.yooUcAutoTip focusin.yooUcAutoTip', showTip);
            $anchor.on('mouseleave.yooUcAutoTip focusout.yooUcAutoTip', function (e) {
                var rel = e.relatedTarget;
                if (rel && ($anchor[0].contains(rel) || $tip[0].contains(rel))) {
                    return;
                }
                hideTip();
            });
            $tip.on('mouseenter.yooUcAutoTip', showTip);
            $tip.on('mouseleave.yooUcAutoTip', hideTip);
        });

        if (!$(window).data('yooUcAutoTipScroll')) {
            $(window).data('yooUcAutoTipScroll', 1);
            $(window).on('resize.yooUcAutoTip scroll.yooUcAutoTip', function () {
                $('.yoo-uc-auto-mode-tooltip--portaled.is-visible').each(function () {
                    var $tip = $(this);
                    var $anchor = $tip.data('yooUcAnchor');
                    if ($anchor && $anchor.length) {
                        placeUcAutoModeTooltip($anchor, $tip);
                    }
                });
            });
        }
    }

    /** Final line in modal (like core updater): singular vs plural. */
    function queueDoneMessage(queueKind, count) {
        count = parseInt(count, 10) || 0;
        if (queueKind === 'themes') {
            return count === 1
                ? i18n('themeUpdatedSuccess', 'Theme updated successfully.')
                : i18n('themesUpdatedSuccess', 'Themes updated successfully.');
        }
        return count === 1
            ? i18n('pluginUpdatedSuccess', 'Plugin updated successfully.')
            : i18n('pluginsUpdatedSuccess', 'Plugins updated successfully.');
    }

    /**
     * Sequential updates: one status line at a time (no stacked log).
     * Section HTML / tab badges refresh once when the queue finishes (not after each item), so lists do not vanish mid-progress.
     * @param {string} queueKind 'plugins' | 'themes'
     */
    function runQueue(label, items, eachFn, queueKind) {
        queueKind = queueKind || 'plugins';
        var total = items.length;
        if (total === 0) {
            return $.Deferred().resolve().promise();
        }
        progressOpen(label);
        var d = $.Deferred();
        var i = 0;
        var pulseTimer = null;
        /** Last successful AJAX payload (sections + totals); applied once at end or on failure (partial state). */
        var lastPayload = null;

        function clearPulse() {
            if (pulseTimer) {
                clearInterval(pulseTimer);
                pulseTimer = null;
            }
        }

        function startPulse(baseLine, floorPct) {
            clearPulse();
            var p = typeof floorPct === 'number' ? floorPct : 6;
            var line = String(baseLine || '');
            pulseTimer = setInterval(function () {
                p = Math.min(p + (93 - p) * 0.055 + Math.random() * 2.2, 93);
                var rounded = Math.round(p);
                progressSet(rounded, line);
            }, 300);
        }

        function queueFinishOk(onDone) {
            var $foot = $('#yoo-uc-progress-footer');
            $foot.prop('hidden', false);
            $('#yoo-uc-progress-ok')
                .text(i18n('progressOk', 'OK'))
                .prop('disabled', false)
                .off('click.yooUcQueueOk')
                .on('click.yooUcQueueOk', function () {
                    $('#yoo-uc-progress-ok').off('click.yooUcQueueOk');
                    progressClose();
                    if (typeof onDone === 'function') {
                        onDone();
                    }
                });
        }

        function next() {
            clearPulse();
            if (i >= total) {
                if (lastPayload && lastPayload.sections) {
                    applySections(lastPayload.sections, lastPayload.totals);
                }
                var finishMsg = queueDoneMessage(queueKind, total);
                progressShowSuccess(finishMsg);
                queueFinishOk(function () {
                    d.resolve();
                });
                return;
            }
            var segmentBase = total ? Math.round((i / total) * 100) : 0;
            var segmentEnd = total ? Math.round(((i + 1) / total) * 100) : 100;
            var item = items[i];
            var baseLabel = String(item.label || '');
            progressSet(segmentBase, baseLabel);
            startPulse(baseLabel, segmentBase + 4);

            $.when(eachFn(item, i))
                .done(function (res) {
                    clearPulse();
                    if (res && res.data && res.data.sections) {
                        lastPayload = { sections: res.data.sections, totals: res.data.totals };
                    }
                    var okMsg = res && res.data && res.data.message ? String(res.data.message) : '';
                    var line = okMsg || baseLabel;
                    i += 1;
                    progressSet(segmentEnd, line);
                    next();
                })
                .fail(function (err) {
                    clearPulse();
                    if (lastPayload && lastPayload.sections) {
                        applySections(lastPayload.sections, lastPayload.totals);
                    }
                    var msg = ucFailMessage(err);
                    progressSet(100, msg);
                    progressSpinnerSet(false);
                    $('.yoo-uc-progress-modal').removeClass('yoo-uc-progress-modal--success');
                    if ($title && $title.length) {
                        $title.text(i18n('updateFailedTitle', 'Update failed'));
                    }
                    queueFinishOk(function () {
                        d.reject(msg);
                    });
                });
        }
        next();
        return d.promise();
    }

    $(function () {
        portalUcOverlays();
        initUcAutoModeTooltips();
        maybeThickbox();
        syncAllUcTables();
        refreshBulkStrips();

        $(document).on('click', '.yoo-uc-check-again', function (e) {
            e.preventDefault();
            progressOpen(i18n('checking', 'Checking for updates…'));
            progressSet(8, i18n('checking', 'Checking for updates…'));
            ucPost('yooadmin_uc_refresh', {})
                .done(function (res) {
                    applySections(res.data.sections, res.data.totals);
                    progressShowSuccess(i18n('done', 'Done.'));
                    setTimeout(progressClose, 700);
                })
                .fail(function (err) {
                    progressLog(ucFailMessage(err));
                    setTimeout(progressClose, 1400);
                });
        });

        $(document).on('click', '.yoo-uc-core-auto-link', function (e) {
            e.preventDefault();
            var val = $(this).data('value');
            if (!val) {
                return;
            }
            progressOpen(i18n('working', 'Working…'));
            progressSet(30, '');
            ucPost('yooadmin_uc_core_auto_major', { value: val })
                .done(function (res) {
                    applySections(res.data.sections, res.data.totals);
                    progressShowSuccess(res.data.message || i18n('done', 'Done.'));
                    setTimeout(progressClose, 800);
                })
                .fail(function (err) {
                    progressLog(ucFailMessage(err));
                    setTimeout(progressClose, 1400);
                });
        });

        $(document).on('change', '.yoo-uc-form--plugins input[name="checked[]"], .yoo-uc-form--themes input[name="checked[]"]', function () {
            refreshBulkStrips();
        });

        $(document).on('change', '#plugins-select-all, #themes-select-all', function () {
            refreshBulkStrips();
        });

        $(document).on('click', '.yoo-uc-tab', function () {
            activateUcTab($(this).attr('data-yoo-uc-tab'));
        });

        $(document).on('click', '[data-yoo-uc-go-tab]', function () {
            activateUcTab($(this).attr('data-yoo-uc-go-tab'));
        });

        var defTab = $('.yoo-update-center-wrap').attr('data-uc-default-tab');
        if (defTab) {
            activateUcTab(defTab);
        }

        var $ucNav = getUcTabNav();
        if ($ucNav.length) {
            $ucNav.on('scroll.yooUcTabInk', function () {
                var $a = $ucNav.find('.yp-tab.yoo-uc-tab.is-active').first();
                if ($a.length) {
                    moveUcTabInk($a);
                }
            });
        }
        $(window).on('resize.yooUcTabInk', function () {
            var $a = $('#yoo-uc-tabs-root .yp-tab.yoo-uc-tab.is-active').first();
            if ($a.length) {
                moveUcTabInk($a);
            }
        });

        $(document).on('submit', '.yoo-uc-form--plugins', function (e) {
            e.preventDefault();
            var $form = $(this);
            var files = $form.find('input[name="checked[]"]:checked').map(function () {
                return $(this).val();
            }).get();
            if (!files.length) {
                window.alert(i18n('selectPlugins', 'Please select one or more plugins.'));
                return;
            }
            var rows = files.map(function (f) {
                var name = f.split('/').pop().replace(/\.php$/i, '') || f;
                return { file: f, label: i18n('updatingItem', 'Updating…').replace('%s', name) };
            });
            runQueue(
                i18n('working', 'Updating plugins'),
                rows,
                function (item) {
                    return ucPost('yooadmin_uc_update_plugin', { plugin: item.file });
                },
                'plugins'
            );
        });

        $(document).on('submit', '.yoo-uc-form--themes', function (e) {
            e.preventDefault();
            var $form = $(this);
            var sheets = $form.find('input[name="checked[]"]:checked').map(function () {
                return $(this).val();
            }).get();
            if (!sheets.length) {
                window.alert(i18n('selectThemes', 'Please select one or more themes.'));
                return;
            }
            var rows = sheets.map(function (s) {
                return { stylesheet: s, label: i18n('updatingItem', 'Updating…').replace('%s', s) };
            });
            runQueue(
                i18n('working', 'Updating themes'),
                rows,
                function (item) {
                    return ucPost('yooadmin_uc_update_theme', { stylesheet: item.stylesheet });
                },
                'themes'
            );
        });

        $(document).on('click', '.yoo-uc-single-plugin-update', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $btn = $(this);
            if ($btn.hasClass('is-updating')) {
                return;
            }
            var $card = $btn.closest('[data-plugin-file]');
            var file = $card.attr('data-plugin-file');
            if (!file) {
                return;
            }
            var name = ($card.find('.yoo-uc-tile-meta-bar__title').first().text() || $card.find('.yoo-theme-card-hover-title').first().text() || file).trim();
            var shortName = file.split('/').pop().replace(/\.php$/i, '') || file;
            if (!name) {
                name = shortName;
            }
            $btn.addClass('is-updating').prop('disabled', true);
            runQueue(
                i18n('working', 'Updating plugins'),
                [{ file: file, label: i18n('updatingItem', 'Updating…').replace('%s', name) }],
                function (item) {
                    return ucPost('yooadmin_uc_update_plugin', { plugin: item.file });
                },
                'plugins'
            ).always(function () {
                $btn.removeClass('is-updating').prop('disabled', false);
            });
        });

        $(document).on('click', '.yoo-uc-single-theme-update', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $btn = $(this);
            if ($btn.hasClass('is-updating')) {
                return;
            }
            var $card = $btn.closest('[data-stylesheet]');
            var sheet = $card.attr('data-stylesheet');
            if (!sheet) {
                return;
            }
            var name = ($card.find('.yoo-uc-tile-meta-bar__title').first().text() || $card.find('.yoo-theme-card-hover-title').first().text() || sheet).trim();
            $btn.addClass('is-updating').prop('disabled', true);
            runQueue(
                i18n('working', 'Updating themes'),
                [{ stylesheet: sheet, label: i18n('updatingItem', 'Updating…').replace('%s', name) }],
                function (item) {
                    return ucPost('yooadmin_uc_update_theme', { stylesheet: item.stylesheet });
                },
                'themes'
            ).always(function () {
                $btn.removeClass('is-updating').prop('disabled', false);
            });
        });

        $(document).on('submit', '.yoo-uc-translations-form', function (e) {
            e.preventDefault();
            progressOpen(i18n('working', 'Updating translations'));
            var tLabel = i18n('working', 'Updating translations');
            progressSet(10, tLabel);
            var trPulse = setInterval(function () {
                var cur = parseInt($('#yoo-uc-progress-pct').text(), 10) || 10;
                var p = Math.min(cur + (92 - cur) * 0.07 + Math.random() * 2, 94);
                var r = Math.round(p);
                progressSet(r, tLabel);
            }, 320);
            ucPost('yooadmin_uc_update_translations', {})
                .done(function (res) {
                    applySections(res.data.sections, res.data.totals);
                    var trDone = res.data.message || i18n('translationsUpdatedSuccess', 'Translations updated successfully.');
                    progressShowSuccess(trDone);
                    $('#yoo-uc-progress-footer').prop('hidden', false);
                    $('#yoo-uc-progress-ok')
                        .text(i18n('progressOk', 'OK'))
                        .prop('disabled', false)
                        .off('click.yooUcTrOk')
                        .on('click.yooUcTrOk', function () {
                            $('#yoo-uc-progress-ok').off('click.yooUcTrOk');
                            progressClose();
                        });
                })
                .fail(function (err) {
                    progressSet(100, ucFailMessage(err));
                    progressSpinnerSet(false);
                    $('.yoo-uc-progress-modal').removeClass('yoo-uc-progress-modal--success');
                    if ($title && $title.length) {
                        $title.text(i18n('updateFailedTitle', 'Update failed'));
                    }
                    $('#yoo-uc-progress-footer').prop('hidden', false);
                    $('#yoo-uc-progress-ok')
                        .text(i18n('progressOk', 'OK'))
                        .prop('disabled', false)
                        .off('click.yooUcTrOk')
                        .on('click.yooUcTrOk', function () {
                            $('#yoo-uc-progress-ok').off('click.yooUcTrOk');
                            progressClose();
                        });
                })
                .always(function () {
                    clearInterval(trPulse);
                });
        });

        $(document).on('submit', '.yoo-uc-core-upgrade-form', function (e) {
            e.preventDefault();
            var $form = $(this);
            var sub = e.originalEvent && e.originalEvent.submitter;
            if (!sub && document.activeElement) {
                sub = document.activeElement;
            }
            var name = sub && sub.getAttribute ? sub.getAttribute('name') : '';
            var version = $form.find('input[name="version"]').val() || '';
            var locale = $form.find('input[name="locale"]').val() || 'en_US';

            if (name === 'dismiss') {
                progressOpen(i18n('working', 'Working…'));
                ucPost('yooadmin_uc_dismiss_core', { version: version, locale: locale })
                    .done(function (res) {
                        applySections(res.data.sections, res.data.totals);
                        progressShowSuccess(res.data.message || i18n('done', 'Done.'));
                        setTimeout(progressClose, 800);
                    })
                    .fail(function (err) {
                        progressLog(ucFailMessage(err));
                        setTimeout(progressClose, 1400);
                    });
                return;
            }
            if (name === 'undismiss') {
                progressOpen(i18n('working', 'Working…'));
                ucPost('yooadmin_uc_undismiss_core', { version: version, locale: locale })
                    .done(function (res) {
                        applySections(res.data.sections, res.data.totals);
                        progressShowSuccess(res.data.message || i18n('done', 'Done.'));
                        setTimeout(progressClose, 800);
                    })
                    .fail(function (err) {
                        progressLog(ucFailMessage(err));
                        setTimeout(progressClose, 1400);
                    });
                return;
            }

            var reinstall = $form.data('reinstall') === 1 || $form.data('reinstall') === '1';
            var coreModalTitle = formatCoreUpdateTitle(version, reinstall);
            progressOpen(coreModalTitle);
            var coreLabel = coreModalTitle;
            progressSet(12, coreLabel);
            var corePulse = setInterval(function () {
                var cur = parseInt($('#yoo-uc-progress-pct').text(), 10) || 12;
                var p = Math.min(cur + (96 - cur) * 0.045 + Math.random() * 1.8, 96);
                var r = Math.round(p);
                progressSet(r, coreLabel);
            }, 350);
            ucPost('yooadmin_uc_update_core', {
                version: version,
                locale: locale,
                reinstall: reinstall ? '1' : ''
            })
                .done(function (res) {
                    clearInterval(corePulse);
                    if (res && res.data && res.data.sections) {
                        applySections(res.data.sections, res.data.totals);
                    }
                    progressShowSuccess(res.data.message || i18n('done', 'Done.'));
                    var newVerFromAjax =
                        res && res.data && res.data.new_version != null ? String(res.data.new_version).trim() : '';
                    var $foot = $('#yoo-uc-progress-footer');
                    $foot.prop('hidden', false);
                    $('#yoo-uc-progress-ok')
                        .text(i18n('progressOk', 'OK'))
                        .prop('disabled', false)
                        .off('click.yooUcCoreOk')
                        .on('click.yooUcCoreOk', function () {
                            var $btn = $('#yoo-uc-progress-ok');
                            if ($btn.prop('disabled')) {
                                return;
                            }
                            $btn.prop('disabled', true);
                            /* Close overlay in one step (footer + modal); refresh runs after */
                            progressClose();
                            ucPost('yooadmin_uc_refresh', {})
                                .done(function (r2) {
                                    if (r2 && r2.data && r2.data.sections) {
                                        applySections(r2.data.sections, r2.data.totals);
                                    }
                                    var v =
                                        (r2 &&
                                            r2.data &&
                                            r2.data.sections &&
                                            r2.data.sections.wp_version &&
                                            String(r2.data.sections.wp_version).trim()) ||
                                        newVerFromAjax ||
                                        ($('#yoo-uc-wp-version-num').text() || '').trim();
                                    showCoreUpdatedToastAfterOk(v);
                                })
                                .fail(function () {
                                    showCoreUpdatedToastAfterOk(
                                        newVerFromAjax || ($('#yoo-uc-wp-version-num').text() || '').trim()
                                    );
                                });
                        });
                })
                .fail(function (err) {
                    progressLog(ucFailMessage(err));
                    setTimeout(progressClose, 2200);
                })
                .always(function () {
                    clearInterval(corePulse);
                });
        });
    });
})(jQuery);
