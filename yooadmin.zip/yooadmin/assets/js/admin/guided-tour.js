/**
 * Studio Hub guided tour.
 */
(function ($) {
  'use strict';

  var cfg = window.yooadminGuidedTour || {};
  var i18n = cfg.i18n || {};
  var coreSteps = cfg.steps || [];
  var extensionTours = cfg.extensionTours || [];
  var segmentCatalog = cfg.segmentCatalog || [];
  var STORAGE_KEY = 'yooadmin_guided_tour_step';
  var STORAGE_EXT_KEY = 'yooadmin_guided_tour_ext';
  var STORAGE_SETTINGS_PENDING_KEY = 'yooadmin_guided_tour_settings_pending';
  var STEP_BODY_CLASSES = [
    'ygt-step-notifications',
    'ygt-step-sidebar',
    'ygt-step-breadcrumbs',
    'ygt-step-workspace-edit',
    'ygt-step-add-section',
    'ygt-step-widget-hide',
    'ygt-step-spotlight-only',
    'ygt-step-layout-demo-focus'
  ];

  var LAYOUT_DEMO_MOVE_MS = 900;
  var LAYOUT_DEMO_CROSS_MOVE_MS = 1150;
  var LAYOUT_DEMO_LEAD_MS = 320;
  var LAYOUT_DEMO_READ_MS = 480;
  var LAYOUT_DEMO_CROSS_READ_MS = 720;
  var LAYOUT_DEMO_GAP_MS = 280;
  var LAYOUT_DEMO_SCROLL_MARGIN = 72;

  function isDocumentRtl() {
    return (
      document.documentElement.getAttribute('dir') === 'rtl' ||
      document.body.classList.contains('rtl') ||
      document.body.classList.contains('yooadmin-arabic-ui')
    );
  }

  /** Map logical placements (start/end) and mirror left/right in RTL. */
  function resolveHorizontalPlacement(placement) {
    var resolved = placement || 'bottom';
    if (resolved === 'end') {
      return isDocumentRtl() ? 'left' : 'right';
    }
    if (resolved === 'start') {
      return isDocumentRtl() ? 'right' : 'left';
    }
    if (isDocumentRtl()) {
      if (resolved === 'left') {
        return 'right';
      }
      if (resolved === 'right') {
        return 'left';
      }
    }
    return resolved;
  }

  function usesSpotlightOnly(step) {
    return !!(
      step &&
      (step.spotlightOnly || step.openSidebar || step.id === 'breadcrumbs')
    );
  }

  function isDashboardCardStep(step) {
    return !!(
      step &&
      (step.id === 'welcome' ||
        step.id === 'quick-actions' ||
        step.id === 'workspace')
    );
  }

  function isWorkspaceEditIntroStep(step) {
    return !!(step && (step.revealEditButton || step.id === 'workspace-layout-edit'));
  }

  function usesWorkspaceEditChrome(step) {
    return isWorkspaceEditIntroStep(step);
  }

  function isSettingsTourStep(step) {
    if (!step) {
      return false;
    }
    var id = step.id || '';
    if (id === 'colors' || id === 'logo' || id === 'login') {
      return true;
    }
    return id.indexOf('settings-') === 0;
  }

  function firstSettingsStepIndex(stepList) {
    var list = stepList || coreSteps;
    var i;
    for (i = 0; i < list.length; i++) {
      if (isSettingsTourStep(list[i])) {
        return i;
      }
    }
    return list.length;
  }

  function isDashboardEndChoice(stepList, idx) {
    if (!stepList || idx < 0) {
      return false;
    }
    var step = stepList[idx];
    var settingsStart = firstSettingsStepIndex(stepList);
    return !!(
      step &&
      step.page === 'dashboard' &&
      settingsStart > 0 &&
      idx === settingsStart - 1
    );
  }

  function isSettingsPageContext() {
    var page = currentPage();
    return page === 'settings' || page === 'theme-settings';
  }

  function stepMetaForIndex(stepList, idx) {
    var settingsStart = firstSettingsStepIndex(stepList);
    if (idx < settingsStart) {
      return { num: idx + 1, total: settingsStart };
    }
    return {
      num: idx - settingsStart + 1,
      total: Math.max(1, stepList.length - settingsStart)
    };
  }

  function readSettingsPendingFlag() {
    try {
      return sessionStorage.getItem(STORAGE_SETTINGS_PENDING_KEY) === '1';
    } catch (e) {
      return false;
    }
  }

  function saveSettingsPendingFlag(on) {
    try {
      if (on) {
        sessionStorage.setItem(STORAGE_SETTINGS_PENDING_KEY, '1');
      } else {
        sessionStorage.removeItem(STORAGE_SETTINGS_PENDING_KEY);
      }
    } catch (e) {
      /* ignore */
    }
  }

  function clearSettingsPendingFlag() {
    saveSettingsPendingFlag(false);
  }

  function syncTourFlagsFromCfg() {
    cfg.dashboardDone = !!cfg.dashboardDone;
    cfg.settingsTour = cfg.settingsTour || '';
    cfg.segments = cfg.segments || {};
  }

  function mergeStateFromResponse(res) {
    if (!res || !res.success || !res.data) {
      return;
    }
    var data = res.data;
    if (data.segments && typeof data.segments === 'object') {
      cfg.segments = data.segments;
    }
    if (typeof data.dashboard_done !== 'undefined') {
      cfg.dashboardDone = !!data.dashboard_done;
    }
    if (typeof data.settings_tour !== 'undefined') {
      cfg.settingsTour = data.settings_tour || '';
    }
    if (typeof data.status === 'string') {
      cfg.inProgress = data.status === 'in_progress';
    }
  }

  function getSegmentStatus(segmentId) {
    syncTourFlagsFromCfg();
    return cfg.segments[segmentId] || '';
  }

  function getPendingSegmentItems() {
    var items = [];
    var i;
    for (i = 0; i < segmentCatalog.length; i++) {
      var item = segmentCatalog[i];
      if (item && item.id && getSegmentStatus(item.id) === 'pending') {
        items.push(item);
      }
    }
    return items;
  }

  function hasPendingSegments() {
    return getPendingSegmentItems().length > 0;
  }

  function segmentMatchesPage(segment, page) {
    if (!segment) {
      return false;
    }
    if (segment.page === page) {
      return true;
    }
    return (
      segment.page === 'settings' &&
      (page === 'settings' || page === 'theme-settings')
    );
  }

  function shouldElevateTourTarget(step) {
    return !!(
      step &&
      (usesSpotlightOnly(step) || step.revealEditButton) &&
      !step.openSidebar &&
      !step.openNotifications &&
      step.id !== 'breadcrumbs' &&
      step.id !== 'add-section'
    );
  }

  function isTourRevealedEditToggle(el) {
    return !!(
      el &&
      (el.matches('[data-icon-edit-toggle]') || el.classList.contains('yp-card-edit-toggle')) &&
      document.body.classList.contains('ygt-step-workspace-edit')
    );
  }

  function clearTourTargetFocus() {
    var nodes = document.querySelectorAll('.ygt-tour-target-focus');
    var i;
    for (i = 0; i < nodes.length; i++) {
      nodes[i].classList.remove('ygt-tour-target-focus');
    }
    clearThemeTourHoldHover();
  }

  function clearThemeTourHoldHover() {
    var wraps = document.querySelectorAll(
      '.yoo-theme-manager-wrap .yoo-theme-card-media-wrap--hold-hover, ' +
        '.yoo-theme-manager-wrap .ygt-tour-theme-hover'
    );
    var i;
    for (i = 0; i < wraps.length; i++) {
      wraps[i].classList.remove('yoo-theme-card-media-wrap--hold-hover');
      wraps[i].classList.remove('ygt-tour-theme-hover');
    }
  }

  function pinThemeTourHoldHover(el) {
    var wrap;
    if (!el) {
      return null;
    }
    wrap =
      el.classList && el.classList.contains('yoo-theme-card-media-wrap')
        ? el
        : el.closest
          ? el.closest('.yoo-theme-card-media-wrap')
          : null;
    if (!wrap) {
      return null;
    }
    clearThemeTourHoldHover();
    wrap.classList.add('yoo-theme-card-media-wrap--hold-hover');
    wrap.classList.add('ygt-tour-theme-hover');
    return wrap;
  }

  function stepNeedsThemeCardHover(step) {
    return !!(
      step &&
      step.page === 'theme-manager' &&
      (step.id === 'themes-install' || step.id === 'themes-card-actions')
    );
  }

  function clearStepSpotlight(tour) {
    clearTourTargetFocus();
    if (!tour) {
      return;
    }
    if (tour.spotlight) {
      tour.spotlight.setAttribute('hidden', 'hidden');
    }
    if (typeof tour.hideExtraSpotlight === 'function') {
      tour.hideExtraSpotlight();
    }
  }

  function isTargetList(target) {
    return Object.prototype.toString.call(target) === '[object Array]';
  }

  var tourLayoutDemo = {
    token: 0,
    timer: null,
    running: false,
    playbackDone: false
  };

  function isLayoutEditDemoStep(step) {
    return !!(step && step.layoutTourDemo && step.id === 'workspace-layout-edit');
  }

  function isLayoutEditDemoAwaitingStart(step) {
    return isLayoutEditDemoStep(step) && !tourLayoutDemo.playbackDone;
  }

  function setLayoutDemoPopoverCopyVisible(visible) {
    [Tour.metaEl, Tour.titleEl, Tour.textEl].forEach(function (el) {
      if (!el) {
        return;
      }
      if (visible) {
        el.removeAttribute('hidden');
      } else {
        el.setAttribute('hidden', 'hidden');
      }
    });
  }

  function isLayoutDemoPopoverSuppressed() {
    return !!(
      tourLayoutDemo.running ||
      (Tour.popover &&
        (Tour.popover.hasAttribute('hidden') ||
          Tour.popover.classList.contains('ygt-popover--demo-chrome-hidden')))
    );
  }

  function setLayoutDemoPopoverChromeVisible(visible) {
    if (!Tour.popover) {
      return;
    }
    if (visible) {
      Tour.popover.removeAttribute('hidden');
      Tour.popover.classList.remove(
        'ygt-popover--demo-chrome-hidden',
        'ygt-popover--demo-playing'
      );
      setLayoutDemoPopoverCopyVisible(true);
      Tour.popover.classList.add('ygt-popover--visible');
    } else {
      Tour.popover.setAttribute('hidden', 'hidden');
      Tour.popover.classList.add('ygt-popover--demo-chrome-hidden');
      Tour.popover.classList.remove('ygt-popover--visible');
      setLayoutDemoPopoverCopyVisible(false);
    }
  }

  function createLayoutBeginButton() {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'button button-primary yp-yoo-btn yp-yoo-btn--primary';
    btn.setAttribute('data-ygt-layout-demo-begin', '');
    btn.textContent = i18n.layoutDemoBegin || 'Show me';
    btn.addEventListener('click', function () {
      startLayoutDemoPlayback();
    });
    return btn;
  }

  function removeLayoutBeginButton() {
    var btn = Tour.layoutBeginBtn;
    if (btn && btn.parentNode) {
      btn.parentNode.removeChild(btn);
    }
  }

  function syncLayoutBeginButton(show, navWrap, insertBefore) {
    if (!show) {
      removeLayoutBeginButton();
      return;
    }
    if (!navWrap) {
      return;
    }
    if (!Tour.layoutBeginBtn) {
      Tour.layoutBeginBtn = createLayoutBeginButton();
    }
    Tour.layoutBeginBtn.textContent = i18n.layoutDemoBegin || 'Show me';
    Tour.layoutBeginBtn.setAttribute('aria-hidden', 'false');
    if (!Tour.layoutBeginBtn.parentNode) {
      if (insertBefore && insertBefore.parentNode === navWrap) {
        navWrap.insertBefore(Tour.layoutBeginBtn, insertBefore);
      } else {
        navWrap.appendChild(Tour.layoutBeginBtn);
      }
    }
  }

  function removeNextButton() {
    var btn = Tour.nextBtn;
    if (btn && btn.parentNode) {
      btn.parentNode.removeChild(btn);
    }
  }

  function restoreNextButton(navWrap, branchWrap) {
    var btn = Tour.nextBtn;
    if (!btn || !navWrap || !branchWrap) {
      return;
    }
    if (!btn.parentNode) {
      navWrap.insertBefore(btn, branchWrap);
    }
    btn.removeAttribute('hidden');
    btn.setAttribute('aria-hidden', 'false');
    btn.textContent = i18n.next || 'Next';
  }

  function shouldShowLayoutDemoBegin(step) {
    return !!(
      step &&
      step.id === 'workspace-layout-edit' &&
      step.layoutTourDemo &&
      !tourLayoutDemo.playbackDone &&
      !tourLayoutDemo.running
    );
  }

  function layoutDemoStepText(step) {
    if (
      isLayoutEditDemoStep(step) &&
      tourLayoutDemo.playbackDone &&
      !tourLayoutDemo.running
    ) {
      return step.layoutDemoDoneText || step.text || '';
    }
    return step && step.text ? step.text : '';
  }

  function startLayoutDemoPlayback() {
    var step = Tour.getStepList()[Tour.index];
    if (!isLayoutEditDemoAwaitingStart(step) || tourLayoutDemo.running) {
      return;
    }
    if (tourLayoutDemo.timer) {
      window.clearTimeout(tourLayoutDemo.timer);
      tourLayoutDemo.timer = null;
    }
    var demoToken = tourLayoutDemo.token + 1;
    tourLayoutDemo.token = demoToken;
    clearStudioLayoutDropGaps();
    hideLayoutEditTourFrameForDemo();
    setLayoutDemoPopoverChromeVisible(false);
    if (Tour.popover) {
      Tour.popover.classList.add('ygt-popover--demo-playing');
    }
    Tour.updateNavButtons(Tour.index);
    if (!isLayoutEditActive()) {
      enableLayoutEdit();
    }
    runWorkspaceLayoutTourDemos(demoToken).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      tourLayoutDemo.playbackDone = true;
      setLayoutDemoPopoverChromeVisible(true);
      if (Tour.popover) {
        Tour.popover.classList.remove('ygt-popover--demo-playing');
      }
      if (Tour.textEl) {
        Tour.textEl.textContent = layoutDemoStepText(step);
      }
      Tour.updateNavButtons(Tour.index);
    });
  }

  function tourDemoDelay(ms) {
    return new Promise(function (resolve) {
      window.setTimeout(resolve, ms);
    });
  }

  function scrollIntoViewForDemo(el) {
    if (!el || typeof el.scrollIntoView !== 'function') {
      return;
    }
    try {
      el.scrollIntoView({
        block: 'center',
        inline: 'nearest',
        behavior: tourLayoutDemo.running ? 'auto' : 'smooth'
      });
    } catch (eScroll) {
      el.scrollIntoView(true);
    }
  }

  function ensureLayoutDemoScrollable() {
    if (
      tourLayoutDemo.running &&
      !document.body.classList.contains('ygt-step-scrollable')
    ) {
      document.body.classList.add('ygt-step-scrollable');
    }
  }

  function scrollRectInScrollContainer(container, rect, margin) {
    if (!container || !rect) {
      return;
    }
    var cr = container.getBoundingClientRect();
    if (cr.width < 1 && cr.height < 1) {
      return;
    }
    var viewTop = cr.top + margin;
    var viewBottom = cr.bottom - margin;
    var viewLeft = cr.left + margin;
    var viewRight = cr.right - margin;
    var deltaTop = 0;
    var deltaLeft = 0;
    if (rect.top < viewTop) {
      deltaTop = rect.top - viewTop;
    } else if (rect.bottom > viewBottom) {
      deltaTop = rect.bottom - viewBottom;
    }
    if (rect.left < viewLeft) {
      deltaLeft = rect.left - viewLeft;
    } else if (rect.right > viewRight) {
      deltaLeft = rect.right - viewRight;
    }
    if (Math.abs(deltaTop) > 2) {
      var maxTop = Math.max(0, container.scrollHeight - container.clientHeight);
      container.scrollTop = Math.max(
        0,
        Math.min(maxTop, container.scrollTop + deltaTop)
      );
    }
    if (Math.abs(deltaLeft) > 2) {
      var maxLeft = Math.max(0, container.scrollWidth - container.clientWidth);
      container.scrollLeft = Math.max(
        0,
        Math.min(maxLeft, container.scrollLeft + deltaLeft)
      );
    }
  }

  function layoutDemoAnimatingBegin() {
    document.body.classList.add('ygt-layout-demo-animating');
  }

  function layoutDemoAnimatingEnd() {
    document.body.classList.remove('ygt-layout-demo-animating');
  }

  function scrollDemoViewportForRect(rect, margin) {
    var vh = window.innerHeight || document.documentElement.clientHeight;
    var scrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
    var top = rect.top + scrollY;
    var bottom =
      (rect.bottom != null ? rect.bottom : rect.top + rect.height) + scrollY;
    var viewTop = scrollY + margin;
    var viewBottom = scrollY + vh - margin;
    var targetScroll = scrollY;
    if (top < viewTop) {
      targetScroll = top - margin;
    } else if (bottom > viewBottom) {
      targetScroll = bottom - vh + margin;
    }
    if (Math.abs(targetScroll - scrollY) > 6) {
      window.scrollTo({ top: Math.max(0, targetScroll), behavior: 'auto' });
    }
  }

  function scrollDemoRectIntoView(rect, opts) {
    opts = opts || {};
    if (!rect || (rect.width < 1 && rect.height < 1)) {
      return;
    }
    var margin =
      typeof opts.margin === 'number' ? opts.margin : LAYOUT_DEMO_SCROLL_MARGIN;
    ensureLayoutDemoScrollable();
    scrollDemoViewportForRect(rect, margin);
    var scrollParent = opts.anchorEl ? getScrollableParent(opts.anchorEl) : null;
    if (scrollParent) {
      scrollRectInScrollContainer(scrollParent, rect, margin);
    }
  }

  function scrollDemoRectsIntoView(rects, opts) {
    if (!rects || !rects.length) {
      return;
    }
    var union = unionRectFromPlainRects(rects);
    if (union.width > 0 || union.height > 0) {
      scrollDemoRectIntoView(union, opts);
    }
  }

  function scrollDemoFocusIntoView(el, opts) {
    opts = opts || {};
    if (!el) {
      return;
    }
    ensureLayoutDemoScrollable();
    if (!opts.anchorEl) {
      opts.anchorEl = el;
    }
    scrollDemoRectIntoView(el.getBoundingClientRect(), opts);
  }

  function scrollDemoMovePair(originEl, destinationEl, opts) {
    opts = opts || {};
    var rects = [];
    if (originEl) {
      rects.push(originEl.getBoundingClientRect());
    }
    if (destinationEl) {
      rects.push(destinationEl.getBoundingClientRect());
    }
    if (!opts.anchorEl) {
      opts.anchorEl = originEl || destinationEl || null;
    }
    scrollDemoRectsIntoView(rects, opts);
  }

  function hideLayoutEditTourFrameForDemo() {
    clearTourTargetFocus();
    if (Tour.clearWorkspaceEditChrome) {
      Tour.clearWorkspaceEditChrome();
    }
    document.body.classList.add('ygt-step-layout-demo-focus');
    document.body.classList.add('ygt-step-spotlight-only');
    document.body.classList.remove('ygt-step-workspace-edit');
    if (Tour.spotlight) {
      Tour.spotlight.removeAttribute('hidden');
      Tour.spotlight.style.width = '';
      Tour.spotlight.style.height = '';
    }
    if (Tour.hideExtraSpotlight) {
      Tour.hideExtraSpotlight();
    }
  }

  function releaseLayoutDemoSpotlightSnap() {
    document.body.classList.remove('ygt-step-layout-demo-focus');
    if (Tour.spotlight) {
      Tour.spotlight.classList.remove('ygt-spotlight--snap');
    }
    if (Tour.popover) {
      Tour.popover.classList.remove('ygt-popover--demo-pinned');
    }
  }

  function trackLayoutDemoSpotlightRect(rect, pad) {
    if (!rect || !Tour.spotlight || (rect.width < 2 && rect.height < 2)) {
      return;
    }
    var inset = typeof pad === 'number' ? pad : 8;
    Tour.spotlight.classList.add('ygt-spotlight--snap');
    Tour.spotlight.removeAttribute('hidden');
    Tour.positionSpotlightRect(rect, inset);
  }

  function trackLayoutDemoSpotlight(spotlightEl, pad) {
    if (!spotlightEl) {
      return;
    }
    trackLayoutDemoSpotlightRect(spotlightEl.getBoundingClientRect(), pad);
  }

  function pinLayoutDemoPopover(title, text) {
    if (
      !Tour.popover ||
      tourLayoutDemo.running ||
      Tour.popover.classList.contains('ygt-popover--demo-chrome-hidden')
    ) {
      return;
    }
    if (Tour.titleEl && title) {
      Tour.titleEl.textContent = title;
    }
    if (Tour.textEl && text) {
      Tour.textEl.textContent = text;
    }
    Tour.popover.classList.add('ygt-popover--visible', 'ygt-popover--demo-pinned');
    var pop = Tour.popover;
    pop.style.top = Math.max(16, (window.innerHeight - pop.offsetHeight) * 0.08) + 'px';
    pop.style.left =
      Math.max(16, (window.innerWidth - pop.offsetWidth) / 2) + 'px';
  }

  function focusLayoutDemoMovement(targetEl, opts) {
    opts = opts || {};
    if (!targetEl || !Tour.root || !Tour.root.classList.contains('ygt-active')) {
      return;
    }
    var spotlightEl = opts.spotlightEl || targetEl;
    var pad = typeof opts.spotlightPad === 'number' ? opts.spotlightPad : 10;

    if (!opts.skipScroll) {
      scrollIntoViewForDemo(spotlightEl);
    }
    document.body.classList.add('ygt-step-layout-demo-focus');
    clearTourTargetFocus();
    if (!tourLayoutDemo.running) {
      targetEl.classList.add('ygt-tour-target-focus');
    }

    if (Tour.hideExtraSpotlight) {
      Tour.hideExtraSpotlight();
    }
    if (tourLayoutDemo.running && !opts.skipSpotlightTrack) {
      trackLayoutDemoSpotlight(spotlightEl, pad);
    }

    if (!opts.spotlightOnly) {
      pinLayoutDemoPopover(opts.title, opts.text);
    }
  }

  function restoreLayoutEditStepChrome(step, target) {
    tourLayoutDemo.running = false;
    releaseLayoutDemoSpotlightSnap();
    if (Tour.popover) {
      Tour.popover.classList.remove('ygt-popover--demo-pinned');
    }
    if (!step) {
      return;
    }
    if (usesWorkspaceEditChrome(step)) {
      document.body.classList.add('ygt-step-workspace-edit');
      document.body.classList.add('ygt-step-spotlight-only');
      var wsSection = document.querySelector('[data-section-id="your-workspace"]');
      if (wsSection) {
        wsSection.classList.add('ygt-tour-reveal-edit');
      }
    }
    if (Tour.titleEl) {
      Tour.titleEl.textContent = step.title || '';
    }
    if (Tour.textEl) {
      Tour.textEl.textContent = layoutDemoStepText(step);
    }
    if (target) {
      setTourTargetFocus(target, step);
      if (Tour.spotlight) {
        Tour.spotlight.removeAttribute('hidden');
        Tour.spotlight.style.width = '';
        Tour.spotlight.style.height = '';
      }
      Tour.positionSpotlight(target, spotlightPad(step));
      Tour.positionPopoverForEditToggle(target, step.placement || 'left');
    }
  }

  function cancelTourLayoutDemo() {
    tourLayoutDemo.token += 1;
    tourLayoutDemo.running = false;
    if (tourLayoutDemo.timer) {
      window.clearTimeout(tourLayoutDemo.timer);
      tourLayoutDemo.timer = null;
    }
    releaseLayoutDemoSpotlightSnap();
    layoutDemoAnimatingEnd();
    clearStudioLayoutDropGaps();
    var clones = document.querySelectorAll('.ygt-tour-drag-clone');
    var c;
    for (c = 0; c < clones.length; c++) {
      if (clones[c].parentNode) {
        clones[c].parentNode.removeChild(clones[c]);
      }
    }
    var animating = document.querySelectorAll('.ygt-tour-layout-demo-active');
    var i;
    for (i = 0; i < animating.length; i++) {
      animating[i].classList.remove(
        'ygt-tour-layout-demo-active',
        'is-dragging',
        'is-section-dragging',
        'ygt-tour-source-ghost'
      );
      animating[i].style.transition = '';
      animating[i].style.transform = '';
      animating[i].style.zIndex = '';
      animating[i].style.opacity = '';
      animating[i].style.visibility = '';
    }
    if (Tour.popover) {
      Tour.popover.classList.remove(
        'ygt-popover--demo-pinned',
        'ygt-popover--demo-playing',
        'ygt-popover--demo-chrome-hidden'
      );
    }
    setLayoutDemoPopoverChromeVisible(true);
  }

  function showTourDropTarget(rect) {
    if (!rect) {
      return;
    }
    var el = document.getElementById('ygt-tour-drop-target');
    if (!el) {
      el = document.createElement('div');
      el.id = 'ygt-tour-drop-target';
      el.className = 'ygt-tour-drop-target';
      el.setAttribute('aria-hidden', 'true');
      document.body.appendChild(el);
    }
    el.style.top = rect.top + 'px';
    el.style.left = rect.left + 'px';
    el.style.width = rect.width + 'px';
    el.style.height = rect.height + 'px';
    el.removeAttribute('hidden');
  }

  function hideTourDropTarget() {
    var el = document.getElementById('ygt-tour-drop-target');
    if (el && el.parentNode) {
      el.parentNode.removeChild(el);
    }
    if (Tour.hideExtraSpotlight) {
      Tour.hideExtraSpotlight();
    }
  }

  function clearStudioLayoutDropGaps() {
    var nodes = document.querySelectorAll(
      '.yp-layout-drop-gap, .yp-layout-edit-slots, [data-layout-slot], .ygt-tour-flip-placeholder'
    );
    var i;
    for (i = 0; i < nodes.length; i++) {
      if (nodes[i].parentNode) {
        nodes[i].parentNode.removeChild(nodes[i]);
      }
    }
    hideTourDropTarget();
  }

  function createFlipPlaceholder(firstRect) {
    var placeholder = document.createElement('div');
    placeholder.className = 'ygt-tour-flip-placeholder';
    placeholder.setAttribute('aria-hidden', 'true');
    var h = Math.max(1, Math.round(firstRect.height));
    placeholder.style.setProperty('--ygt-flip-ph-h', h + 'px');
    placeholder.style.height = h + 'px';
    placeholder.style.minHeight = h + 'px';
    return placeholder;
  }

  function trackLayoutDemoDropTarget(rect) {
    if (!rect) {
      return;
    }
    showTourDropTarget(rect);
    if (Tour.spotlightExtra) {
      Tour.spotlightExtra.classList.add('ygt-spotlight--snap');
      Tour.spotlightExtra.removeAttribute('hidden');
      Tour.positionSpotlightRectOn(Tour.spotlightExtra, rect, 2);
    }
  }

  function pickCardDemoMoveTarget(cards, fromCard) {
    if (!cards || cards.length < 2 || !fromCard) {
      return null;
    }
    var fromRect = fromCard.getBoundingClientRect();
    var best = null;
    var bestScore = 0;
    var i;
    for (i = 0; i < cards.length; i++) {
      if (cards[i] === fromCard) {
        continue;
      }
      var r = cards[i].getBoundingClientRect();
      var score =
        Math.abs(r.left - fromRect.left) + Math.abs(r.top - fromRect.top) * 1.15;
      if (score > bestScore) {
        bestScore = score;
        best = cards[i];
      }
    }
    return best || (cards[1] !== fromCard ? cards[1] : cards[0]);
  }

  function isLayoutCardVisible(card) {
    return !!(
      card &&
      isTargetVisible(card) &&
      !card.classList.contains('yp-layout-card--hidden') &&
      !card.hidden
    );
  }

  function getVisibleLayoutCards(grid) {
    if (!grid) {
      return [];
    }
    var nodes = grid.querySelectorAll('[data-card-id]');
    var list = [];
    var i;
    for (i = 0; i < nodes.length; i++) {
      if (isLayoutCardVisible(nodes[i])) {
        list.push(nodes[i]);
      }
    }
    return list;
  }

  function tourAnimateFlipMove(el, mutateDom, durationMs, options) {
    options = options || {};
    var duration =
      typeof durationMs === 'number' ? durationMs : LAYOUT_DEMO_MOVE_MS;
    if (!el || typeof mutateDom !== 'function') {
      return Promise.resolve();
    }

    var first = el.getBoundingClientRect();
    var parent = el.parentNode;
    var placeholder = null;
    if (parent) {
      placeholder = createFlipPlaceholder(first);
      parent.insertBefore(placeholder, el);
    }

    el.classList.add('ygt-tour-layout-demo-active');
    if (options.draggingClass) {
      el.classList.add(options.draggingClass);
    }

    clearStudioLayoutDropGaps();
    mutateDom();

    var last = el.getBoundingClientRect();
    var dx = first.left - last.left;
    var dy = first.top - last.top;
    if (Math.abs(dx) < 2 && Math.abs(dy) < 2) {
      el.classList.remove('ygt-tour-layout-demo-active');
      if (options.draggingClass) {
        el.classList.remove(options.draggingClass);
      }
      if (placeholder && placeholder.parentNode) {
        placeholder.parentNode.removeChild(placeholder);
      }
      clearStudioLayoutDropGaps();
      if (typeof options.onAfter === 'function') {
        options.onAfter(el);
      }
      return Promise.resolve();
    }

    el.style.transition = 'none';
    el.style.transform = 'translate(' + dx + 'px, ' + dy + 'px)';
    el.style.zIndex = '1000010';
    el.style.position = 'relative';

    layoutDemoAnimatingBegin();

    return new Promise(function (resolve) {
      var settled = false;
      var trackRaf = 0;
      var demoPad = typeof options.spotlightPad === 'number' ? options.spotlightPad : 8;

      function trackMovingFocus() {
        if (settled) {
          return;
        }
        trackLayoutDemoSpotlight(el, demoPad);
        trackRaf = window.requestAnimationFrame(trackMovingFocus);
      }

      function cleanupStyles() {
        el.style.transition = '';
        el.style.transform = '';
        el.style.zIndex = '';
        el.style.position = '';
        el.classList.remove('ygt-tour-layout-demo-active');
        if (options.draggingClass) {
          el.classList.remove(options.draggingClass);
        }
        if (placeholder && placeholder.parentNode) {
          placeholder.parentNode.removeChild(placeholder);
        }
        clearStudioLayoutDropGaps();
      }

      function finish() {
        if (settled) {
          return;
        }
        settled = true;
        if (trackRaf) {
          window.cancelAnimationFrame(trackRaf);
          trackRaf = 0;
        }
        el.removeEventListener('transitionend', onEnd);
        cleanupStyles();
        hideTourDropTarget();
        layoutDemoAnimatingEnd();
        if (typeof options.onAfter === 'function') {
          options.onAfter(el);
        }
        resolve();
      }

      function onEnd(e) {
        if (e && e.propertyName && e.propertyName !== 'transform') {
          return;
        }
        finish();
      }

      trackRaf = window.requestAnimationFrame(trackMovingFocus);
      window.requestAnimationFrame(function () {
        window.requestAnimationFrame(function () {
          el.style.transition = 'transform ' + duration + 'ms ease-out';
          el.style.transform = '';
          el.addEventListener('transitionend', onEnd);
        });
      });
      window.setTimeout(finish, duration + 120);
    });
  }

  function tourAnimateFlipMoveAcrossGrids(el, mutateDom, durationMs, options) {
    options = options || {};
    var duration =
      typeof durationMs === 'number' ? durationMs : LAYOUT_DEMO_MOVE_MS;
    if (!el || typeof mutateDom !== 'function') {
      return Promise.resolve();
    }

    var first = el.getBoundingClientRect();
    var originParent = el.parentNode;
    var placeholder = null;
    if (originParent) {
      placeholder = createFlipPlaceholder(first);
      originParent.insertBefore(placeholder, el);
    }

    el.classList.remove('ygt-tour-layout-demo-active');
    if (options.draggingClass) {
      el.classList.remove(options.draggingClass);
    }

    var clone = el.cloneNode(true);
    clone.className = (el.className || '')
      .replace(/\bygt-tour-layout-demo-active\b/g, '')
      .replace(/\bygt-tour-source-ghost\b/g, '')
      .trim();
    clone.className += ' ygt-tour-drag-clone ygt-tour-layout-demo-active';
    if (options.draggingClass) {
      clone.classList.add(options.draggingClass);
    }
    clone.setAttribute('aria-hidden', 'true');
    clone.style.position = 'fixed';
    clone.style.zIndex = '1000065';
    clone.style.left = first.left + 'px';
    clone.style.top = first.top + 'px';
    clone.style.width = first.width + 'px';
    clone.style.height = first.height + 'px';
    clone.style.margin = '0';
    clone.style.transform = '';
    clone.style.transition = '';
    clone.style.visibility = 'visible';
    clone.style.opacity = '1';
    document.body.appendChild(clone);

    el.classList.add('ygt-tour-source-ghost');
    el.style.visibility = 'hidden';

    clearStudioLayoutDropGaps();
    mutateDom();

    var last = el.getBoundingClientRect();
    var tdx = last.left - first.left;
    var tdy = last.top - first.top;

    layoutDemoAnimatingBegin();

    return new Promise(function (resolve) {
      var settled = false;
      var trackRaf = 0;
      var demoPad = typeof options.spotlightPad === 'number' ? options.spotlightPad : 8;

      function trackMovingFocus() {
        if (settled) {
          return;
        }
        trackLayoutDemoSpotlightRect(clone.getBoundingClientRect(), demoPad);
        trackRaf = window.requestAnimationFrame(trackMovingFocus);
      }

      function finish() {
        if (settled) {
          return;
        }
        settled = true;
        if (trackRaf) {
          window.cancelAnimationFrame(trackRaf);
          trackRaf = 0;
        }
        if (clone.parentNode) {
          clone.parentNode.removeChild(clone);
        }
        if (placeholder && placeholder.parentNode) {
          placeholder.parentNode.removeChild(placeholder);
        }
        el.style.visibility = '';
        el.classList.remove('ygt-tour-source-ghost');
        el.classList.add('ygt-tour-layout-demo-active');
        clearStudioLayoutDropGaps();
        layoutDemoAnimatingEnd();
        if (typeof options.onAfter === 'function') {
          options.onAfter(el);
        }
        resolve();
      }

      function onEnd(e) {
        if (e && e.propertyName && e.propertyName !== 'transform') {
          return;
        }
        finish();
      }

      if (Math.abs(tdx) < 2 && Math.abs(tdy) < 2) {
        finish();
        return;
      }

      trackRaf = window.requestAnimationFrame(trackMovingFocus);
      window.requestAnimationFrame(function () {
        window.requestAnimationFrame(function () {
          clone.style.transition = 'transform ' + duration + 'ms ease-out';
          clone.style.transform = 'translate(' + tdx + 'px, ' + tdy + 'px)';
          clone.addEventListener('transitionend', onEnd);
          window.setTimeout(finish, duration + 120);
        });
      });
    });
  }

  function tourAnimateCardMove(card, grid, insertBefore, durationMs, options) {
    options = options || {};
    if (!card || !grid) {
      return Promise.resolve();
    }
    var mutateDom = function () {
      if (insertBefore) {
        grid.insertBefore(card, insertBefore);
      } else {
        grid.appendChild(card);
      }
    };
    var crossGrid = !!(card.parentNode && card.parentNode !== grid);
    if (crossGrid) {
      return tourAnimateFlipMoveAcrossGrids(card, mutateDom, durationMs, options);
    }
    if (!insertBefore) {
      return tourAnimateFlipMove(card, mutateDom, durationMs, options);
    }
    return tourAnimateFlipMove(card, mutateDom, durationMs, options);
  }

  function tourAnimateSectionMove(section, mainEl, insertBefore, durationMs, options) {
    options = options || {};
    if (!section || !mainEl || !insertBefore) {
      return Promise.resolve();
    }
    return tourAnimateFlipMove(
      section,
      function () {
        mainEl.insertBefore(section, insertBefore);
        section.setAttribute('data-custom-placement', 'main');
      },
      durationMs,
      {
        draggingClass: 'is-section-dragging',
        spotlightPad: options.spotlightPad,
        onTrack: options.onTrack,
        onAfter: options.onAfter
      }
    );
  }

  function runWorkspaceCardTourDemo(demoToken) {
    var workspace = document.querySelector('[data-section-id="your-workspace"]');
    var grid =
      workspace &&
      workspace.querySelector('.yp-cards-grid[data-sortable="true"]');
    if (!grid || demoToken !== tourLayoutDemo.token) {
      return Promise.resolve();
    }
    var cards = getVisibleLayoutCards(grid);
    if (cards.length < 2) {
      return Promise.resolve();
    }
    var card = cards[0];
    var insertBefore = pickCardDemoMoveTarget(cards, card);
    if (!insertBefore || insertBefore === card) {
      return Promise.resolve();
    }
    return tourDemoDelay(LAYOUT_DEMO_LEAD_MS).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      clearStudioLayoutDropGaps();
      focusLayoutDemoMovement(workspace, {
        spotlightEl: workspace,
        spotlightPad: 4,
        spotlightOnly: true,
        skipScroll: true,
        skipSpotlightTrack: true
      });
      trackLayoutDemoSpotlight(workspace, 4);
      return tourDemoDelay(LAYOUT_DEMO_READ_MS);
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      scrollDemoMovePair(card, insertBefore, { margin: LAYOUT_DEMO_SCROLL_MARGIN });
      pinLayoutDemoPopover(
        i18n.demoMoveTileTitle || 'Moving a tile',
        i18n.demoMoveTileText || ''
      );
      return tourAnimateCardMove(card, grid, insertBefore, LAYOUT_DEMO_MOVE_MS, {
        onAfter: function () {
          scrollDemoFocusIntoView(card, { margin: LAYOUT_DEMO_SCROLL_MARGIN });
          if (workspace) {
            trackLayoutDemoSpotlight(workspace, 4);
          }
        }
      });
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      return tourDemoDelay(LAYOUT_DEMO_GAP_MS);
    });
  }

  function getPluginsSectionGrid(section) {
    if (!section) {
      return null;
    }
    return (
      section.querySelector(
        '.yp-studio-extensions-grid[data-sortable="true"]'
      ) ||
      section.querySelector('.yp-cards-grid[data-sortable="true"]')
    );
  }

  /** Card: Your workspace → Your plugins (same flip move as tile reorder). */
  function runWorkspaceCardToPluginsTourDemo(demoToken) {
    var workspace = document.querySelector('[data-section-id="your-workspace"]');
    var pluginsSection = document.querySelector('[data-section-id="from-extensions"]');
    var wsGrid =
      workspace &&
      workspace.querySelector('.yp-cards-grid[data-sortable="true"]');
    var pluginsGrid = getPluginsSectionGrid(pluginsSection);
    if (
      !workspace ||
      !pluginsSection ||
      !wsGrid ||
      !pluginsGrid ||
      demoToken !== tourLayoutDemo.token
    ) {
      return Promise.resolve();
    }
    var cards = getVisibleLayoutCards(wsGrid);
    if (!cards.length) {
      return Promise.resolve();
    }
    var card = cards.length > 1 ? cards[1] : cards[0];
    var insertBefore = pluginsGrid.querySelector('[data-card-id]');
    document.body.classList.add('ygt-tour-cross-grid-demo');
    var destCard = insertBefore || pluginsGrid;
    return tourDemoDelay(LAYOUT_DEMO_LEAD_MS).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      scrollDemoMovePair(card, pluginsSection, { margin: LAYOUT_DEMO_SCROLL_MARGIN });
      focusLayoutDemoMovement(workspace, {
        spotlightEl: workspace,
        spotlightPad: 4,
        spotlightOnly: true,
        skipScroll: true,
        skipSpotlightTrack: true
      });
      trackLayoutDemoSpotlight(workspace, 4);
      return tourDemoDelay(LAYOUT_DEMO_CROSS_READ_MS);
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      scrollDemoMovePair(card, destCard, { margin: LAYOUT_DEMO_SCROLL_MARGIN });
      pinLayoutDemoPopover(
        i18n.demoMoveCardTitle || i18n.demoMoveTileTitle || 'Moving a card',
        i18n.demoMoveCardText || i18n.demoMoveTileText || ''
      );
      return tourAnimateCardMove(card, pluginsGrid, insertBefore, LAYOUT_DEMO_CROSS_MOVE_MS, {
        onAfter: function () {
          document.body.classList.remove('ygt-tour-cross-grid-demo');
          scrollDemoFocusIntoView(card, { margin: LAYOUT_DEMO_SCROLL_MARGIN });
          trackLayoutDemoSpotlight(card, 6);
        }
      });
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      document.body.classList.remove('ygt-tour-cross-grid-demo');
      return tourDemoDelay(LAYOUT_DEMO_GAP_MS);
    });
  }

  function runPluginsSectionTourDemo(demoToken) {
    var section = document.querySelector('[data-section-id="from-extensions"]');
    var workspace = document.querySelector('[data-section-id="your-workspace"]');
    var mainEl = document.querySelector('.yp-studio-hub__main');
    if (
      !section ||
      !workspace ||
      !mainEl ||
      demoToken !== tourLayoutDemo.token
    ) {
      return Promise.resolve();
    }
    return tourDemoDelay(LAYOUT_DEMO_LEAD_MS).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      scrollDemoFocusIntoView(section, { margin: LAYOUT_DEMO_SCROLL_MARGIN });
      trackLayoutDemoSpotlight(section, 8);
      return tourDemoDelay(LAYOUT_DEMO_READ_MS);
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      scrollDemoMovePair(section, workspace, { margin: LAYOUT_DEMO_SCROLL_MARGIN });
      trackLayoutDemoSpotlight(section, 8);
      pinLayoutDemoPopover(
        i18n.demoMovePluginsTitle || 'Moving Your plugins',
        i18n.demoMovePluginsText || ''
      );
      return tourAnimateSectionMove(
        section,
        mainEl,
        workspace,
        LAYOUT_DEMO_MOVE_MS,
        {
          spotlightPad: 8,
          onAfter: function () {
            scrollDemoFocusIntoView(section, { margin: LAYOUT_DEMO_SCROLL_MARGIN });
            trackLayoutDemoSpotlight(section, 8);
          }
        }
      );
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      return tourDemoDelay(LAYOUT_DEMO_GAP_MS);
    });
  }

  function runWorkspaceLayoutTourDemos(demoToken) {
    var step = Tour.getStepList()[Tour.index];
    var workspace = document.querySelector('[data-section-id="your-workspace"]');
    var editTarget = resolveTarget(
      '[data-section-id="your-workspace"] .yp-card-edit-toggle, [data-section-id="your-workspace"] [data-icon-edit-toggle="main-grid"]',
      true
    );
    tourLayoutDemo.running = true;
    ensureLayoutDemoScrollable();
    if (workspace) {
      scrollIntoViewForDemo(workspace);
    }
    return tourDemoDelay(450).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      return runWorkspaceCardTourDemo(demoToken);
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      return tourDemoDelay(LAYOUT_DEMO_GAP_MS + 120);
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      return runWorkspaceCardToPluginsTourDemo(demoToken);
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      return tourDemoDelay(LAYOUT_DEMO_GAP_MS + 120);
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      return runPluginsSectionTourDemo(demoToken);
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      return tourDemoDelay(400);
    }).then(function () {
      if (demoToken !== tourLayoutDemo.token) {
        return;
      }
      restoreLayoutEditStepChrome(step, editTarget);
      $(window).trigger('resize.ygtTour');
    });
  }

  function resetDashboardLayoutPositionsOnly() {
    if (
      window.YOOStudioHubLayout &&
      typeof window.YOOStudioHubLayout.resetAll === 'function'
    ) {
      try {
        window.YOOStudioHubLayout.resetAll();
      } catch (eReset) {
        /* ignore */
      }
      return;
    }
    var resetBtn = document.querySelector('[data-icon-edit-reset="main-grid"]');
    if (resetBtn) {
      resetBtn.click();
    }
  }

  function resetDashboardLayoutAfterDrag() {
    disableLayoutEdit();
    resetDashboardLayoutPositionsOnly();
  }

  function isAddSectionButtonTarget(el) {
    if (!el || !el.classList || !el.classList.contains('yp-studio-layout-add')) {
      return false;
    }
    var r = el.getBoundingClientRect();
    return r.width >= 24 && r.height >= 24;
  }

  /** Spotlight covers the full dashed add-row (main / aside), not just the + icon. */
  function getAddSectionSpotlightRect(btn) {
    if (!btn) {
      return null;
    }
    var r = btn.getBoundingClientRect();
    if (r.width < 8 || r.height < 8) {
      return null;
    }
    return {
      top: r.top,
      left: r.left,
      width: r.width,
      height: r.height,
      right: r.right,
      bottom: r.bottom
    };
  }

  function stabilizeAddSectionSpotlights(tour, seedTargets, token) {
    if (!tour) {
      return;
    }
    function align() {
      if (token !== tour._stepToken) {
        return;
      }
      var step = tour.getStepList()[tour.index];
      if (!step || step.id !== 'add-section') {
        return;
      }
      var list = getAddSectionTargets();
      if (!list.length && seedTargets && seedTargets.length) {
        list = seedTargets;
      }
      if (!list.length) {
        return;
      }
      scrollAddSectionTargetsIntoView(list);
      var pad =
        step && typeof step.spotlightPad === 'number' ? step.spotlightPad : 4;
      tour.positionAddSectionSpotlights(list, pad);
      tour.positionPopoverForAddSectionTargets(list);
    }
    afterLayoutPaint(function () {
      afterLayoutPaint(align);
    });
    window.setTimeout(align, 90);
    window.setTimeout(align, 220);
    window.setTimeout(align, 480);
  }

  function getAddSectionTargets() {
    if (!isLayoutEditActive()) {
      return [];
    }
    var main = document.querySelector(
      '.yp-studio-layout-add.yp-studio-layout-add--main.is-visible'
    );
    var aside = document.querySelector(
      '.yp-studio-layout-add.yp-studio-layout-add--aside.is-visible'
    );
    var list = [];
    if (main && isTargetVisible(main) && isAddSectionButtonTarget(main)) {
      list.push(main);
    }
    if (aside && isTargetVisible(aside) && isAddSectionButtonTarget(aside)) {
      list.push(aside);
    }
    return list;
  }

  function ensureLayoutEditForAddSection(callback) {
    if (typeof callback !== 'function') {
      return;
    }
    if (isLayoutEditActive()) {
      window.requestAnimationFrame(function () {
        window.requestAnimationFrame(callback);
      });
      return;
    }
    enableLayoutEdit();
    window.requestAnimationFrame(function () {
      if (!isLayoutEditActive()) {
        enableLayoutEdit();
      }
      window.requestAnimationFrame(callback);
    });
  }

  function unionRectFromElements(elements) {
    var minTop = Infinity;
    var minLeft = Infinity;
    var maxRight = -Infinity;
    var maxBottom = -Infinity;
    var i;
    var r;
    for (i = 0; i < elements.length; i++) {
      r = elements[i].getBoundingClientRect();
      minTop = Math.min(minTop, r.top);
      minLeft = Math.min(minLeft, r.left);
      maxRight = Math.max(maxRight, r.right);
      maxBottom = Math.max(maxBottom, r.bottom);
    }
    return {
      top: minTop,
      left: minLeft,
      right: maxRight,
      bottom: maxBottom,
      width: maxRight - minLeft,
      height: maxBottom - minTop
    };
  }

  function unionRectFromPlainRects(rects) {
    var minTop = Infinity;
    var minLeft = Infinity;
    var maxRight = -Infinity;
    var maxBottom = -Infinity;
    var i;
    var r;
    for (i = 0; i < rects.length; i++) {
      r = rects[i];
      if (!r) {
        continue;
      }
      minTop = Math.min(minTop, r.top);
      minLeft = Math.min(minLeft, r.left);
      maxRight = Math.max(maxRight, r.right);
      maxBottom = Math.max(maxBottom, r.bottom);
    }
    return {
      top: minTop,
      left: minLeft,
      right: maxRight,
      bottom: maxBottom,
      width: maxRight - minLeft,
      height: maxBottom - minTop
    };
  }

  function lowestElementFromList(elements) {
    var lowest = null;
    var lowestBottom = -Infinity;
    var i;
    var rect;
    if (!elements || !elements.length) {
      return null;
    }
    for (i = 0; i < elements.length; i++) {
      if (!elements[i] || !elements[i].getBoundingClientRect) {
        continue;
      }
      rect = elements[i].getBoundingClientRect();
      if (rect.bottom > lowestBottom) {
        lowestBottom = rect.bottom;
        lowest = elements[i];
      }
    }
    return lowest || elements[0];
  }

  function setTourTargetFocus(target, step) {
    clearTourTargetFocus();
    if (!target || !shouldElevateTourTarget(step)) {
      return;
    }
    if (isTargetList(target)) {
      var i;
      for (i = 0; i < target.length; i++) {
        target[i].classList.add('ygt-tour-target-focus');
      }
      return;
    }
    target.classList.add('ygt-tour-target-focus');
  }

  function rectsOverlap(a, b) {
    return !(
      a.right < b.left ||
      a.left > b.right ||
      a.bottom < b.top ||
      a.top > b.bottom
    );
  }

  function spotlightPad(step) {
    if (step && typeof step.spotlightPad === 'number') {
      return step.spotlightPad;
    }
    if (usesSpotlightOnly(step)) {
      return step && step.revealEditButton ? 6 : 0;
    }
    return 8;
  }

  function clearStepBodyClasses() {
    var i;
    for (i = 0; i < STEP_BODY_CLASSES.length; i++) {
      document.body.classList.remove(STEP_BODY_CLASSES[i]);
    }
  }

  function ajax(task, extra) {
    return $.post(
      cfg.ajaxUrl,
      $.extend(
        {
          action: 'yooadmin_guided_tour_action',
          nonce: cfg.nonce,
          task: task
        },
        extra || {}
      )
    );
  }

  function currentPage() {
    var params = new URLSearchParams(window.location.search);
    var page = params.get('page') || '';
    if (page === 'yooadmin-dashboard') {
      return 'dashboard';
    }
    if (page === 'yooadmin-settings') {
      return 'settings';
    }
    if (page === 'yooadmin-admin-theme-settings') {
      return 'theme-settings';
    }
    if (page === 'yooadmin-plugins') {
      return 'plugins';
    }
    if (page === 'yooadmin-theme-manager') {
      return 'theme-manager';
    }
    if (page === 'yooadmin-media') {
      return 'media';
    }
    return 'other';
  }

  function readExtSession() {
    try {
      var raw = sessionStorage.getItem(STORAGE_EXT_KEY);
      if (!raw) {
        return null;
      }
      return JSON.parse(raw);
    } catch (eExt) {
      return null;
    }
  }

  function saveExtSession(payload) {
    try {
      sessionStorage.setItem(STORAGE_EXT_KEY, JSON.stringify(payload || {}));
    } catch (eExtSave) {}
  }

  function clearExtSession() {
    try {
      sessionStorage.removeItem(STORAGE_EXT_KEY);
    } catch (eExtClear) {}
  }

  function managerWrapSelector(page) {
    if (page === 'plugins') {
      return '.yoo-upload-wrap[data-type="plugin"]';
    }
    if (page === 'theme-manager') {
      return '.yoo-theme-manager-wrap';
    }
    return '';
  }

  function activateBrowseTab(tab, wrapSelector) {
    if (!tab || !wrapSelector) {
      return;
    }
    var wrap = document.querySelector(wrapSelector);
    if (!wrap) {
      return;
    }
    var btn = wrap.querySelector('.yoo-category-btn[data-browse="' + tab + '"]');
    if (btn && !btn.classList.contains('active')) {
      btn.click();
    }
  }

  function activateMediaTypeTab(type) {
    var value = typeof type === 'string' ? type : '';
    var tab = document.querySelector(
      '.yoo-media-filter-tab[data-type="' + value + '"]'
    );
    if (tab && !tab.classList.contains('active')) {
      tab.click();
    }
  }

  function activateManagerListView(page) {
    var wrapSelector = managerWrapSelector(page);
    if (!wrapSelector) {
      return;
    }
    var wrap = document.querySelector(wrapSelector);
    if (!wrap) {
      return;
    }
    var listBtn = wrap.querySelector('.yoo-view-mode-btn[data-mode="list"]');
    if (listBtn && !listBtn.classList.contains('active')) {
      listBtn.click();
    }
  }

  function fillManagerRepoSearch(page, query, browseTab) {
    var wrap = managerWrapSelector(page);
    if (!query || !wrap) {
      return;
    }
    activateBrowseTab(browseTab || 'popular', wrap);
    window.setTimeout(function () {
      var input = document.querySelector(wrap + ' #wp-search-input');
      if (!input) {
        return;
      }
      input.value = query;
      if (window.jQuery) {
        window.jQuery(input).trigger('input');
      } else {
        input.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }, 720);
  }

  function fillPluginsRepoSearch(query, browseTab) {
    fillManagerRepoSearch('plugins', query, browseTab);
  }

  function fillThemesRepoSearch(query, browseTab) {
    fillManagerRepoSearch('theme-manager', query, browseTab);
  }

  function isPluginsInstalledTabActive() {
    return !!document.querySelector(
      managerWrapSelector('plugins') +
        ' .yoo-category-btn[data-browse="installed"].active'
    );
  }

  function switchPluginsToInstalledTab(callback) {
    var wrap = managerWrapSelector('plugins');
    activateBrowseTab('installed', wrap);
    var input = document.querySelector(wrap + ' #wp-search-input');
    if (input && input.value.trim()) {
      input.value = '';
      if (window.jQuery) {
        window.jQuery(input).trigger('input');
      } else {
        input.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }
    var gridBtn = document.querySelector(
      wrap + ' .yoo-view-mode-btn[data-mode="grid"]'
    );
    if (gridBtn && !gridBtn.classList.contains('active')) {
      gridBtn.click();
    }
    window.setTimeout(function () {
      if (typeof callback === 'function') {
        callback();
      }
    }, 520);
  }

  function needsPluginsInstalledWait(step) {
    return (
      step &&
      step.page === 'plugins' &&
      step.browseTab === 'installed' &&
      (step.id === 'plugins-installed' ||
        step.id === 'plugins-card-actions' ||
        step.id === 'plugins-auto-update')
    );
  }

  function triggerPluginsSelectAll() {
    var wrap = document.querySelector(managerWrapSelector('plugins'));
    var selectAll = document.getElementById('yoo-select-all-plugins-upload');
    var cards;
    var i;
    var cb;
    if (!wrap || !isPluginsInstalledTabActive()) {
      return;
    }
    cards = wrap.querySelectorAll(
      '.yoo-plugin-card[data-plugin-file]:not([data-plugin-file=""])'
    );
    for (i = 0; i < cards.length; i++) {
      cb = cards[i].querySelector('.yoo-plugin-checkbox');
      if (cb && !cb.disabled) {
        cb.checked = true;
      }
    }
    if (selectAll) {
      selectAll.checked = cards.length > 0;
      if (window.jQuery) {
        window.jQuery(selectAll).trigger('change');
      } else {
        selectAll.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
    if (window.jQuery) {
      window.jQuery('#upload-bulk-actions-bar').stop(true, true).show();
      window.jQuery(wrap).find('.yoo-plugin-checkbox').trigger('change');
    } else {
      var bar = document.getElementById('upload-bulk-actions-bar');
      if (bar) {
        bar.style.display = '';
      }
    }
  }

  function resolvePluginsBulkSelectedCards() {
    var wrap = document.querySelector(managerWrapSelector('plugins'));
    if (!wrap || !isPluginsInstalledTabActive()) {
      return null;
    }
    var cards = wrap.querySelectorAll(
      '.yoo-plugin-card[data-plugin-file]:not([data-plugin-file=""])'
    );
    var selected = [];
    var i;
    var cb;
    for (i = 0; i < cards.length; i++) {
      cb = cards[i].querySelector('.yoo-plugin-checkbox');
      if (cb && cb.checked && isTargetVisible(cards[i])) {
        selected.push(cards[i]);
      }
    }
    return selected.length ? selected : null;
  }

  function forcePluginsBulkSelectedCards() {
    triggerPluginsSelectAll();
    return resolvePluginsBulkSelectedCards();
  }

  function isThemesInstalledTabActive() {
    return !!document.querySelector(
      managerWrapSelector('theme-manager') +
        ' .yoo-category-btn[data-browse="installed"].active'
    );
  }

  function isThemesBrowseTabActive(tab) {
    if (!tab) {
      return false;
    }
    return !!document.querySelector(
      managerWrapSelector('theme-manager') +
        ' .yoo-category-btn[data-browse="' +
        tab +
        '"].active'
    );
  }

  function isThemesRepoBrowseReady(tab) {
    if (!tab || tab === 'installed') {
      return isThemesInstalledTabActive();
    }
    if (!isThemesBrowseTabActive(tab) || isThemesInstalledTabActive()) {
      return false;
    }
    var installedControls = document.querySelector(
      managerWrapSelector('theme-manager') + ' #installed-view-controls'
    );
    if (installedControls && isTargetVisible(installedControls)) {
      return false;
    }
    return true;
  }

  function switchThemesBrowseTab(tab, callback) {
    var wrap = managerWrapSelector('theme-manager');
    activateBrowseTab(tab, wrap);
    window.setTimeout(function () {
      if (typeof callback === 'function') {
        callback();
      }
    }, 680);
  }

  function switchThemesToInstalledTab(callback) {
    var wrap = managerWrapSelector('theme-manager');
    activateBrowseTab('installed', wrap);
    var input = document.querySelector(wrap + ' #wp-search-input');
    if (input && input.value.trim()) {
      input.value = '';
      if (window.jQuery) {
        window.jQuery(input).trigger('input');
      } else {
        input.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }
    var gridBtn = document.querySelector(
      wrap + ' .yoo-view-mode-btn[data-mode="grid"]'
    );
    if (gridBtn && !gridBtn.classList.contains('active')) {
      gridBtn.click();
    }
    window.setTimeout(function () {
      if (typeof callback === 'function') {
        callback();
      }
    }, 520);
  }

  function needsThemesInstalledWait(step) {
    return (
      step &&
      step.page === 'theme-manager' &&
      step.browseTab === 'installed' &&
      (step.id === 'themes-installed' ||
        step.id === 'themes-card-actions' ||
        step.id === 'themes-bulk')
    );
  }

  function needsThemesRepoBrowseWait(step) {
    return (
      step &&
      step.page === 'theme-manager' &&
      step.browseTab &&
      step.browseTab !== 'installed' &&
      !step.tourKeepRepoSearch &&
      (step.id === 'themes-wp-tabs' || step.id === 'themes-search')
    );
  }

  function themesRepoSearchMatches(slug) {
    var wrap = managerWrapSelector('theme-manager');
    var input = document.querySelector(wrap + ' #wp-search-input');
    var needle;
    if (!input) {
      return false;
    }
    needle = String(slug || '')
      .toLowerCase()
      .replace(/\s+/g, '');
    return (
      String(input.value || '')
        .toLowerCase()
        .replace(/\s+/g, '')
        .indexOf(needle) !== -1
    );
  }

  function resolveThemesAstraInstallTarget() {
    var card = resolveThemesRepoCardBySlug('astra');
    var btn;
    var actionsBar;
    if (!card) {
      return null;
    }
    btn = card.querySelector('.yoo-repo-install');
    if (btn) {
      pinThemeTourHoldHover(btn);
      return btn;
    }
    actionsBar = card.querySelector('.yoo-theme-card__actions-bar');
    if (actionsBar) {
      pinThemeTourHoldHover(actionsBar);
      return actionsBar.querySelector('.yoo-media-float-btn') || actionsBar;
    }
    pinThemeTourHoldHover(card);
    return card;
  }

  function triggerThemesSelectAll() {
    var wrap = document.querySelector(managerWrapSelector('theme-manager'));
    var cbs;
    var i;
    var cb;
    if (!wrap || !isThemesInstalledTabActive()) {
      return;
    }
    cbs = wrap.querySelectorAll('[data-yoo-theme-installed-cb]');
    for (i = 0; i < cbs.length; i++) {
      cb = cbs[i];
      if (!cb.disabled) {
        cb.checked = true;
      }
    }
    if (window.jQuery) {
      window.jQuery(cbs).trigger('change');
      window.jQuery('#yoo-theme-installed-bulk-bar').removeAttr('hidden');
    }
    var selectBtn = document.querySelector('[data-yoo-theme-installed-select-all]');
    if (selectBtn && !selectBtn.hasAttribute('hidden')) {
      selectBtn.click();
    }
  }

  function isThemeBulkSelectableCard(card) {
    if (!card) {
      return false;
    }
    if (card.classList.contains('active')) {
      return false;
    }
    if (card.classList.contains('yoo-theme-card--installed-hero')) {
      return false;
    }
    return !!card.querySelector('[data-yoo-theme-installed-cb]');
  }

  function resolveThemesRepoCardBySlug(slug) {
    var wrap = document.querySelector(managerWrapSelector('theme-manager'));
    var needle;
    var cards;
    var i;
    var card;
    var cardSlug;
    if (!wrap || !slug) {
      return null;
    }
    needle = String(slug).toLowerCase().replace(/\s+/g, '');
    cards = wrap.querySelectorAll('.yoo-plugin-card.yoo-theme-card[data-slug]');
    for (i = 0; i < cards.length; i++) {
      card = cards[i];
      cardSlug = (card.getAttribute('data-slug') || '').toLowerCase();
      if (cardSlug === needle || cardSlug.indexOf(needle) !== -1) {
        if (isTargetVisible(card)) {
          return card;
        }
      }
    }
    return null;
  }

  function resolveThemesBulkSelectedCards() {
    var wrap = document.querySelector(managerWrapSelector('theme-manager'));
    if (!wrap || !isThemesInstalledTabActive()) {
      return null;
    }
    var cbs = wrap.querySelectorAll('[data-yoo-theme-installed-cb]:checked');
    var selected = [];
    var i;
    var card;
    for (i = 0; i < cbs.length; i++) {
      card = cbs[i].closest('.yoo-plugin-card');
      if (card && isThemeBulkSelectableCard(card) && isTargetVisible(card)) {
        selected.push(card);
      }
    }
    return selected.length ? selected : null;
  }

  function forceThemesBulkSelectedCards() {
    triggerThemesSelectAll();
    return resolveThemesBulkSelectedCards();
  }

  function resolveThemesRepoInstallTarget(query) {
    var wrap = document.querySelector(managerWrapSelector('theme-manager'));
    if (!wrap) {
      return null;
    }
    var needle =
      typeof query === 'string'
        ? query.toLowerCase().replace(/\s+/g, '')
        : '';
    var cards = wrap.querySelectorAll('.yoo-plugin-card.yoo-theme-card[data-slug]');
    var i;
    var card;
    var btn;
    var slug;
    var actionsBar;

    for (i = 0; i < cards.length; i++) {
      card = cards[i];
      slug = (card.getAttribute('data-slug') || '').toLowerCase();
      if (needle && slug.indexOf(needle) === -1) {
        continue;
      }
      btn = card.querySelector('.yoo-repo-install');
      if (btn) {
        pinThemeTourHoldHover(btn);
        return btn;
      }
    }

    btn = wrap.querySelector(
      '.yoo-plugin-card.yoo-theme-card[data-slug] .yoo-repo-install'
    );
    if (btn) {
      pinThemeTourHoldHover(btn);
      return btn;
    }

    card = wrap.querySelector('.yoo-plugin-card.yoo-theme-card[data-slug]');
    if (card) {
      actionsBar = card.querySelector('.yoo-theme-card__actions-bar');
      if (actionsBar) {
        pinThemeTourHoldHover(actionsBar);
        return actionsBar;
      }
    }

    return null;
  }

  function resolvePluginsRepoInstallTarget(query) {
    var wrap = document.querySelector(managerWrapSelector('plugins'));
    if (!wrap) {
      return null;
    }
    var needle = String(query || '')
      .toLowerCase()
      .replace(/\s+/g, '');
    var cards = wrap.querySelectorAll('.yoo-plugin-card[data-slug]');
    var i;
    var card;
    var btn;
    var slug;

    for (i = 0; i < cards.length; i++) {
      card = cards[i];
      slug = (card.getAttribute('data-slug') || '').toLowerCase();
      if (needle && slug.indexOf(needle) === -1) {
        continue;
      }
      btn = card.querySelector(
        '.yoo-install-btn:not(.yoo-btn-activate):not(.yoo-btn-deactivate)'
      );
      if (!btn) {
        btn = card.querySelector('.yoo-install-btn');
      }
      if (btn && isTargetVisible(btn)) {
        return btn;
      }
    }

    btn = wrap.querySelector(
      '.yoo-plugin-card[data-slug] .yoo-install-btn:not(.yoo-btn-activate):not(.yoo-btn-deactivate)'
    );
    if (btn && isTargetVisible(btn)) {
      return btn;
    }

    return null;
  }

  function prepareManagerStep(step) {
    if (!step) {
      return;
    }
    if (step.browseTab && (step.page === 'plugins' || step.page === 'theme-manager')) {
      activateBrowseTab(step.browseTab, managerWrapSelector(step.page));
    }
    if (step.tourRepoSearch && step.page === 'plugins') {
      fillPluginsRepoSearch(step.tourRepoSearch, step.browseTab || 'popular');
    }
    if (step.tourRepoSearch && step.page === 'theme-manager') {
      fillThemesRepoSearch(step.tourRepoSearch, step.browseTab || 'featured');
    }
    if (
      step.tourRepoSearchWait &&
      typeof step.tourRepoSearchWait === 'string' &&
      step.page === 'theme-manager' &&
      !step.tourKeepRepoSearch
    ) {
      fillThemesRepoSearch(step.tourRepoSearchWait, step.browseTab || 'featured');
    }
    if (step.tourRepoSearchWait && step.page === 'plugins') {
      fillPluginsRepoSearch(step.tourRepoSearchWait, step.browseTab || 'popular');
    }
    if (step.mediaType !== undefined && step.page === 'media') {
      activateMediaTypeTab(step.mediaType);
    }
    if (step.listView && (step.page === 'plugins' || step.page === 'theme-manager')) {
      activateManagerListView(step.page);
    }
  }

  function getExtensionTours() {
    var live = window.yooadminGuidedTour || {};
    if (live.extensionTours && live.extensionTours.length) {
      return live.extensionTours;
    }
    return extensionTours;
  }

  function extensionTourById(id) {
    var tours = getExtensionTours();
    var i;
    for (i = 0; i < tours.length; i++) {
      if (tours[i] && tours[i].id === id) {
        return tours[i];
      }
    }
    return null;
  }

  function settingsTabUrl(tab) {
    var key = 'settings' + tab.charAt(0).toUpperCase() + tab.slice(1);
    if (tab === 'colors') {
      return cfg.themeSettingsUrl || cfg.settingsColors;
    }
    if (cfg[key]) {
      return cfg[key];
    }
    return (cfg.settingsUrl || '') + '#tab-' + tab;
  }

  function stepIndexFromStorage() {
    try {
      var raw = sessionStorage.getItem(STORAGE_KEY);
      if (raw === null || raw === '') {
        return 0;
      }
      var n = parseInt(raw, 10);
      return isNaN(n) ? 0 : Math.max(0, n);
    } catch (e) {
      return 0;
    }
  }

  function saveStepIndex(idx) {
    try {
      sessionStorage.setItem(STORAGE_KEY, String(idx));
    } catch (e2) {}
  }

  function clearStepStorage() {
    try {
      sessionStorage.removeItem(STORAGE_KEY);
    } catch (e3) {}
  }

  function navigateUrl(key) {
    if (key === 'settings-colors') {
      return cfg.themeSettingsUrl || cfg.settingsColors || cfg.settingsUrl + '#tab-colors';
    }
    if (key === 'settings-brand') {
      return cfg.settingsBrand || cfg.settingsUrl + '#tab-brand';
    }
    if (key === 'settings-login') {
      return cfg.settingsLogin || cfg.settingsUrl + '#tab-login';
    }
    if (key && key.indexOf('settings-') === 0) {
      var tab = key.replace('settings-', '');
      return settingsTabUrl(tab);
    }
    return cfg.dashboardUrl || '';
  }

  function pageUrlForSlug(slug) {
    if (slug === 'dashboard') {
      return cfg.dashboardUrl || '';
    }
    if (slug === 'settings') {
      return cfg.settingsUrl || '';
    }
    if (slug === 'theme-settings') {
      return cfg.themeSettingsUrl || '';
    }
    if (slug === 'plugins') {
      return cfg.pluginsUrl || '';
    }
    if (slug === 'theme-manager') {
      return cfg.themeManagerUrl || '';
    }
    if (slug === 'media') {
      return cfg.mediaUrl || '';
    }
    return '';
  }

  function stepDestinationUrl(step) {
    if (step && step.url) {
      return step.url;
    }
    if (step && step.navigate) {
      return navigateUrl(step.navigate);
    }
    if (step && step.page) {
      return pageUrlForSlug(step.page);
    }
    return '';
  }

  function requiredPageForStep(step) {
    if (step && step.page) {
      return step.page;
    }
    if (step && step.navigate) {
      return step.navigate === 'settings-colors' ? 'theme-settings' : 'settings';
    }
    return '';
  }

  function isTargetVisible(el) {
    if (!el || !el.getBoundingClientRect) {
      return false;
    }
    if (el.hidden || el.getAttribute('aria-hidden') === 'true') {
      return false;
    }
    var style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') {
      return false;
    }
    if (style.opacity === '0' && !isTourRevealedEditToggle(el)) {
      return false;
    }
    var rect = el.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) {
      return false;
    }
    var panel = el.closest('.yp-tab-panel');
    if (panel && !panel.classList.contains('is-active')) {
      return false;
    }
    return true;
  }

  function resolveTarget(selector, requireVisible) {
    if (!selector) {
      return null;
    }
    var parts = String(selector).split(',');
    var i;
    for (i = 0; i < parts.length; i++) {
      var el = document.querySelector(parts[i].trim());
      if (el && (!requireVisible || isTargetVisible(el))) {
        return el;
      }
    }
    return null;
  }

  function getScrollableParent(el) {
    var node = el && el.parentElement;
    while (node && node !== document.body && node !== document.documentElement) {
      var style = window.getComputedStyle(node);
      var overflowY = style.overflowY;
      if (
        (overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay') &&
        node.scrollHeight > node.clientHeight + 1
      ) {
        return node;
      }
      node = node.parentElement;
    }
    return null;
  }

  function afterLayoutPaint(callback) {
    if (typeof callback !== 'function') {
      return;
    }
    window.requestAnimationFrame(function () {
      window.requestAnimationFrame(callback);
    });
  }

  function scrollTargetIntoView(el, options) {
    if (!el) {
      return;
    }
    options = options || {};
    var block = options.block || 'center';
    var behavior = options.behavior || 'smooth';
    var hadScrollClass = document.body.classList.contains('ygt-step-scrollable');
    if (!hadScrollClass) {
      document.body.classList.add('ygt-step-scrollable');
    }

    function restoreScrollClass() {
      if (
        !hadScrollClass &&
        (!Tour.root || !Tour.root.classList.contains('ygt-active'))
      ) {
        document.body.classList.remove('ygt-step-scrollable');
      }
    }

    var scrollParent = getScrollableParent(el);
    if (scrollParent) {
      var parentRect = scrollParent.getBoundingClientRect();
      var targetRect = el.getBoundingClientRect();
      var offset =
        targetRect.top -
        parentRect.top -
        (parentRect.height / 2 - targetRect.height / 2);
      scrollParent.scrollTo({
        top: Math.max(0, scrollParent.scrollTop + offset),
        behavior: behavior
      });
      window.setTimeout(restoreScrollClass, behavior === 'smooth' ? 420 : 0);
      return;
    }

    try {
      el.scrollIntoView({ block: block, behavior: behavior, inline: 'nearest' });
    } catch (eScroll) {
      var rect = el.getBoundingClientRect();
      var scrollTop = window.pageYOffset || document.documentElement.scrollTop || 0;
      var targetY =
        scrollTop + rect.top - (window.innerHeight / 2) + rect.height / 2;
      window.scrollTo({ top: Math.max(0, targetY), behavior: behavior });
    }
    window.setTimeout(restoreScrollClass, behavior === 'smooth' ? 420 : 0);
  }

  var ADD_SECTION_SCROLL_BOTTOM = 120;

  function scrollAddSectionTargetsIntoView(elements) {
    if (!elements || !elements.length) {
      return;
    }
    if (!document.body.classList.contains('ygt-step-scrollable')) {
      document.body.classList.add('ygt-step-scrollable');
    }
    var rects = [];
    var i;
    for (i = 0; i < elements.length; i++) {
      rects.push(elements[i].getBoundingClientRect());
    }
    var union = unionRectFromPlainRects(rects);
    if (union.width < 2 && union.height < 2) {
      return;
    }
    var margin = 56;
    var vh = window.innerHeight || document.documentElement.clientHeight;
    var scrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
    var viewMid = scrollY + vh * 0.4;
    var unionMid = union.top + scrollY + union.height / 2;
    var targetScroll = Math.max(0, scrollY + (unionMid - viewMid));
    if (union.bottom + scrollY > scrollY + vh - ADD_SECTION_SCROLL_BOTTOM) {
      targetScroll = Math.max(
        targetScroll,
        scrollY + union.bottom - vh + ADD_SECTION_SCROLL_BOTTOM
      );
    }
    if (union.top < margin) {
      targetScroll = Math.min(targetScroll, scrollY + union.top - margin);
    }
    if (Math.abs(targetScroll - scrollY) > 4) {
      window.scrollTo({ top: targetScroll, behavior: 'auto' });
    }
    var anchor = lowestElementFromList(elements);
    var parent = anchor ? getScrollableParent(anchor) : null;
    if (parent) {
      scrollRectInScrollContainer(parent, union, margin);
    }
  }

  function waitForTarget(getTarget, callback, options) {
    options = options || {};
    var tries = 0;
    var maxTries = typeof options.maxTries === 'number' ? options.maxTries : 20;
    var intervalMs = typeof options.intervalMs === 'number' ? options.intervalMs : 40;
    var wait = window.setInterval(function () {
      tries += 1;
      var target = getTarget();
      if (target && (isTargetList(target) ? target.length : isTargetVisible(target))) {
        window.clearInterval(wait);
        callback(target);
        return;
      }
      if (tries >= maxTries) {
        window.clearInterval(wait);
        callback(target || null);
      }
    }, intervalMs);
    return wait;
  }

  function openNotifications(callback) {
    var $bell = $('.yp-notifications');
    var $dropdown = $('.yp-notifications-dropdown');
    if (!$bell.length) {
      if (callback) {
        callback(null);
      }
      return;
    }
    if (!$dropdown.hasClass('show')) {
      $bell.trigger('click');
    }
    var tries = 0;
    var wait = window.setInterval(function () {
      tries += 1;
      var el = document.querySelector('.yp-notifications-dropdown.show');
      if (el && el.getBoundingClientRect().height > 40) {
        window.clearInterval(wait);
        if (callback) {
          callback(el);
        }
        return;
      }
      if (tries >= 50) {
        window.clearInterval(wait);
        if (callback) {
          callback(resolveTarget('.yp-notifications-dropdown.show, .yp-notifications'));
        }
      }
    }, 60);
  }

  function restoreNotificationsDropdown() {
    var dropdown = document.querySelector('.yp-notifications-dropdown');
    if (!dropdown || dropdown.getAttribute('data-ygt-portaled') !== '1') {
      return;
    }
    dropdown.classList.remove('ygt-notifications-dropdown--tour');
    var parent = dropdown._ygtRestoreParent;
    if (parent) {
      if (dropdown._ygtRestoreNext) {
        parent.insertBefore(dropdown, dropdown._ygtRestoreNext);
      } else {
        parent.appendChild(dropdown);
      }
    }
    dropdown.removeAttribute('data-ygt-portaled');
    dropdown._ygtRestoreParent = null;
    dropdown._ygtRestoreNext = null;
  }

  function elevateNotificationsDropdown() {
    var dropdown = document.querySelector('.yp-notifications-dropdown');
    if (!dropdown) {
      return;
    }
    if (dropdown.getAttribute('data-ygt-portaled') !== '1') {
      dropdown._ygtRestoreParent = dropdown.parentNode;
      dropdown._ygtRestoreNext = dropdown.nextSibling;
      document.body.appendChild(dropdown);
      dropdown.setAttribute('data-ygt-portaled', '1');
      dropdown.classList.add('ygt-notifications-dropdown--tour');
    }
    pinNotificationsDropdown();
  }

  function closeNotifications() {
    $('.yp-notifications-dropdown').removeClass('show');
    restoreNotificationsDropdown();
    document.body.style.removeProperty('--ygt-notif-dropdown-top');
    document.body.style.removeProperty('--ygt-notif-dropdown-right');
    document.body.style.removeProperty('--ygt-notif-dropdown-left');
  }

  function pinNotificationsDropdown() {
    var bell = document.querySelector('.yp-header .yp-notifications');
    var dropdown = document.querySelector('.yp-notifications-dropdown.show');
    if (!bell || !dropdown) {
      return;
    }
    var rect = bell.getBoundingClientRect();
    document.body.style.setProperty('--ygt-notif-dropdown-top', rect.bottom + 10 + 'px');
    if (isDocumentRtl()) {
      document.body.style.setProperty(
        '--ygt-notif-dropdown-left',
        Math.max(12, rect.left) + 'px'
      );
      document.body.style.removeProperty('--ygt-notif-dropdown-right');
    } else {
      document.body.style.setProperty(
        '--ygt-notif-dropdown-right',
        Math.max(12, window.innerWidth - rect.right) + 'px'
      );
      document.body.style.removeProperty('--ygt-notif-dropdown-left');
    }
  }

  function openSidebar() {
    var sidebar = document.getElementById('yps-sidebar');
    var toggle = document.getElementById('yps-toggle-btn');
    var overlay = document.querySelector('.yps-overlay');
    var tourActive = document.body.classList.contains('ygt-tour-active');
    if (!sidebar) {
      return;
    }
    if (sidebar.classList.contains('is-open')) {
      return;
    }
    if (toggle && toggle.getAttribute('aria-expanded') !== 'true') {
      toggle.click();
    }
    sidebar.classList.add('is-open');
    sidebar.setAttribute('aria-hidden', 'false');
    if (toggle) {
      toggle.setAttribute('aria-expanded', 'true');
    }
    if (overlay && !tourActive) {
      overlay.hidden = false;
    }
    if (!tourActive) {
      document.documentElement.style.overflow = 'hidden';
    }
  }

  function closeSidebar() {
    var sidebar = document.getElementById('yps-sidebar');
    var toggle = document.getElementById('yps-toggle-btn');
    var overlay = document.querySelector('.yps-overlay');
    if (!sidebar || !sidebar.classList.contains('is-open')) {
      return;
    }
    if (toggle && toggle.getAttribute('aria-expanded') === 'true') {
      toggle.click();
      return;
    }
    sidebar.classList.remove('is-open');
    sidebar.setAttribute('aria-hidden', 'true');
    if (overlay) {
      overlay.hidden = true;
    }
    if (toggle) {
      toggle.setAttribute('aria-expanded', 'false');
    }
    document.documentElement.style.overflow = '';
  }

  function isLayoutEditActive() {
    return (
      document.body.classList.contains('yp-icon-edit-mode') ||
      document.body.classList.contains('yp-layout-edit-mode') ||
      document.documentElement.classList.contains('yp-icon-edit-mode') ||
      document.documentElement.classList.contains('yp-layout-edit-mode')
    );
  }

  function enableLayoutEdit() {
    var btn = document.querySelector(
      '[data-section-id="your-workspace"] .yp-card-edit-toggle[data-icon-edit-toggle="main-grid"]'
    );
    if (!btn) {
      return;
    }
    if (!isLayoutEditActive()) {
      btn.click();
    }
  }

  function disableLayoutEdit() {
    var btn = document.querySelector(
      '[data-section-id="your-workspace"] .yp-card-edit-toggle[data-icon-edit-toggle="main-grid"]'
    );
    if (!btn) {
      return;
    }
    if (
      document.body.classList.contains('yp-icon-edit-mode') ||
      document.body.classList.contains('yp-layout-edit-mode')
    ) {
      btn.click();
    }
  }

  function activateSettingsTab(hashKey) {
    var tab = hashKey.replace('settings-', '');
    var $btn = $('[data-yp-tabs] .yp-tab[data-tab="' + tab + '"]');
    if ($btn.length) {
      $btn.trigger('click');
      return true;
    }
    if (window.location.hash !== '#tab-' + tab) {
      window.location.hash = 'tab-' + tab;
    }
    return false;
  }

  function scrollSettingsToTop() {
    try {
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    } catch (eScroll) {
      window.scrollTo(0, 0);
    }
    var wrap =
      document.querySelector('.yooadmin-settings-wrap') ||
      document.querySelector('.yooadmin-theme-settings-wrap');
    if (wrap) {
      wrap.scrollTop = 0;
    }
    var panels = document.querySelector('.yooadmin-settings-wrap .yp-tab-panels');
    if (panels) {
      panels.scrollTop = 0;
    }
  }

  var Intro = {
    show: function () {
      var $el = $('#yooadmin-guided-tour-intro');
      if (!$el.length) {
        return;
      }
      $el.removeAttr('hidden').attr('aria-hidden', 'false');
      window.setTimeout(function () {
        $el.addClass('ygt-visible');
      }, 80);
    },
    hide: function () {
      var $el = $('#yooadmin-guided-tour-intro');
      $el.removeClass('ygt-visible').attr('aria-hidden', 'true');
      window.setTimeout(function () {
        $el.attr('hidden', 'hidden');
      }, 280);
    }
  };

  function postSegmentTourEnd() {
    clearStepStorage();
    clearExtSession();
    clearSettingsPendingFlag();
    if (hasPendingSegments()) {
      TourPicker.show();
      return;
    }
    Complete.show();
    ajax('complete');
  }

  var TourPicker = {
    show: function () {
      var pending = getPendingSegmentItems();
      if (!pending.length) {
        Complete.show();
        return;
      }
      var $el = $('#yooadmin-guided-tour-picker');
      if (!$el.length) {
        return;
      }
      this.renderList(pending);
      $el.find('[data-ygt-picker-eyebrow]').text(i18n.pickerEyebrow || '');
      $el.find('[data-ygt-picker-title]').text(i18n.pickerTitle || '');
      $el.find('[data-ygt-picker-lead]').text(i18n.pickerLead || '');
      $el.find('[data-ygt-picker-finish]').text(i18n.pickerFinishAll || i18n.finish || 'Finish');
      $el.removeAttr('hidden').attr('aria-hidden', 'false');
      window.setTimeout(function () {
        $el.addClass('ygt-visible');
      }, 80);
    },

    hide: function () {
      var $el = $('#yooadmin-guided-tour-picker');
      if (!$el.length) {
        return;
      }
      $el.removeClass('ygt-visible').attr('aria-hidden', 'true');
      window.setTimeout(function () {
        $el.attr('hidden', 'hidden');
      }, 280);
    },

    renderList: function (items) {
      var $list = $('[data-ygt-picker-list]');
      if (!$list.length) {
        return;
      }
      $list.empty();
      items.forEach(function (item) {
        var $row = $('<div/>', {
          class: 'ygt-tour-picker-item',
          role: 'listitem',
          'data-ygt-picker-item': item.id
        });
        var $copy = $('<div/>', { class: 'ygt-tour-picker-item__copy' });
        $copy.append(
          $('<h3/>', { class: 'ygt-tour-picker-item__title', text: item.title || item.id })
        );
        $copy.append(
          $('<p/>', { class: 'ygt-tour-picker-item__text', text: item.text || '' })
        );
        var $actions = $('<div/>', { class: 'ygt-tour-picker-item__actions' });
        $actions.append(
          $('<button/>', {
            type: 'button',
            class: 'button button-primary yp-yoo-btn yp-yoo-btn--primary',
            'data-ygt-picker-start': '',
            'data-segment-id': item.id,
            text: i18n.pickerStart || i18n.startTour || 'Start tour'
          })
        );
        $actions.append(
          $('<button/>', {
            type: 'button',
            class: 'button yp-yoo-btn yp-yoo-btn--soft',
            'data-ygt-picker-later': '',
            'data-segment-id': item.id,
            title: i18n.pickerLaterHint || '',
            text: i18n.pickerLater || 'Not now'
          })
        );
        $row.append($copy, $actions);
        $list.append($row);
      });
    },

    startSegment: function (segmentId) {
      this.hide();
      if (segmentId === 'settings') {
        var startIdx = firstSettingsStepIndex(coreSteps);
        var step = coreSteps[startIdx];
        saveSettingsPendingFlag(true);
        saveStepIndex(startIdx);
        Tour.phase = 'core';
        Tour.activeExtensionId = null;
        Tour.stepList = coreSteps;
        if (isSettingsPageContext()) {
          Tour.start(startIdx);
          return;
        }
        if (step) {
          window.location.assign(
            stepDestinationUrl(step) || cfg.settingsUrl || navigateUrl(step.navigate)
          );
        }
        return;
      }
      var tour = extensionTourById(segmentId);
      if (tour) {
        ExtensionTour.beginTour(segmentId);
      }
    },

    deferSegment: function (segmentId) {
      var self = this;
      ajax('segment_pending', { segment_id: segmentId }).done(function (res) {
        mergeStateFromResponse(res);
        self.hide();
        if (!hasPendingSegments()) {
          Complete.show();
          ajax('complete');
        }
      });
    },

    finishAll: function () {
      this.hide();
      Complete.show();
      ajax('finish_all').done(function (res) {
        mergeStateFromResponse(res);
        clearStepStorage();
        clearExtSession();
        clearSettingsPendingFlag();
      });
    }
  };

  var ExtensionTour = {
    beginTour: function (tourId) {
      var tour = extensionTourById(tourId);
      if (!tour || !tour.steps || !tour.steps.length) {
        ajax('segment_complete', { segment_id: tourId }).done(function (res) {
          mergeStateFromResponse(res);
          postSegmentTourEnd();
        });
        return;
      }
      TourPicker.hide();
      saveExtSession({ id: tourId, step: 0 });
      Tour.phase = 'extension';
      Tour.activeExtensionId = tourId;
      Tour.stepList = tour.steps;
      if (currentPage() !== tour.page && tour.url) {
        saveStepIndex(0);
        window.location.assign(tour.url);
        return;
      }
      Tour.start(0);
    }
  };

  var Complete = {
    applyCopy: function (variant) {
      var $el = $('#yooadmin-guided-tour-complete');
      if (!$el.length) {
        return;
      }
      var skipped = variant === 'skipped';
      $el.find('[data-ygt-complete-eyebrow]').text(
        i18n.completeEyebrow || i18n.introEyebrow || 'Guided tour'
      );
      $el.find('[data-ygt-complete-title]').text(
        skipped
          ? i18n.skipCompleteTitle || 'Tour skipped'
          : i18n.completeTitle || 'Thank you!'
      );
      $el.find('[data-ygt-complete-thanks]').text(
        skipped
          ? i18n.skipCompleteThanks || ''
          : i18n.completeThanks || ''
      );
      $el.find('[data-ygt-complete-note]').text(
        skipped
          ? i18n.skipCompleteLead || i18n.completeLead || ''
          : i18n.completeLead || ''
      );
      $el.find('[data-ygt-replay-tour]').text(i18n.replayTour || 'Replay tour');
      $el.find('[data-ygt-finish-tour]').text(i18n.finish || 'Finish');
    },

    show: function (variant) {
      var $el = $('#yooadmin-guided-tour-complete');
      if (!$el.length) {
        return;
      }
      this.applyCopy(variant);
      $el.removeAttr('hidden').attr('aria-hidden', 'false');
      window.setTimeout(function () {
        $el.addClass('ygt-visible');
      }, 80);
    },
    hide: function () {
      var $el = $('#yooadmin-guided-tour-complete');
      $el.removeClass('ygt-visible').attr('aria-hidden', 'true');
      window.setTimeout(function () {
        $el.attr('hidden', 'hidden');
      }, 280);
    }
  };

  var Tour = {
    index: 0,
    phase: 'core',
    activeExtensionId: null,
    stepList: coreSteps,
    root: null,
    spotlight: null,
    popover: null,
    popoverParent: null,
    titleEl: null,
    textEl: null,
    metaEl: null,

    getStepList: function () {
      return this.stepList && this.stepList.length ? this.stepList : coreSteps;
    },

    purgeLegacyLayoutBeginButton: function () {
      if (this.root) {
        var legacy = this.root.querySelector('[data-ygt-layout-demo-begin]');
        if (legacy && legacy.parentNode) {
          legacy.parentNode.removeChild(legacy);
        }
      }
      removeLayoutBeginButton();
      this.layoutBeginBtn = null;
    },

    mount: function () {
      if (this.root) {
        this.purgeLegacyLayoutBeginButton();
        return;
      }
      var root = document.createElement('div');
      root.className = 'ygt-tour-root';
      root.setAttribute('aria-hidden', 'true');
      root.innerHTML =
        '<div class="ygt-backdrop" data-ygt-backdrop></div>' +
        '<div class="ygt-spotlight" hidden></div>' +
        '<div class="ygt-spotlight ygt-spotlight--extra" hidden></div>' +
        '<div class="ygt-popover" role="dialog" aria-live="polite">' +
        '<p class="ygt-popover__meta"></p>' +
        '<h3 class="ygt-popover__title"></h3>' +
        '<p class="ygt-popover__text"></p>' +
        '<div class="ygt-popover__actions">' +
        '<div class="ygt-popover__nav">' +
        '<button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" data-ygt-back>' +
        (i18n.back || 'Back') +
        '</button>' +
        '<button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary" data-ygt-next>' +
        (i18n.next || 'Next') +
        '</button>' +
        '<div class="ygt-popover__branch" data-ygt-dashboard-end hidden>' +
        '<button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" data-ygt-end-tour>' +
        (i18n.endTour || i18n.finish || 'Finish') +
        '</button>' +
        '<button type="button" class="button button-primary yp-yoo-btn yp-yoo-btn--primary" data-ygt-continue-settings>' +
        (i18n.continueSettings || i18n.next || 'Continue') +
        '</button>' +
        '</div>' +
        '</div>' +
        '<button type="button" class="ygt-skip" data-ygt-skip>' +
        (i18n.skip || 'Skip tour') +
        '</button>' +
        '</div>' +
        '</div>';
      document.body.appendChild(root);
      this.root = root;
      this.spotlight = root.querySelector('.ygt-spotlight:not(.ygt-spotlight--extra)');
      this.spotlightExtra = root.querySelector('.ygt-spotlight--extra');
      this.popover = root.querySelector('.ygt-popover');
      this.metaEl = root.querySelector('.ygt-popover__meta');
      this.titleEl = root.querySelector('.ygt-popover__title');
      this.textEl = root.querySelector('.ygt-popover__text');
      this.navWrap = root.querySelector('.ygt-popover__nav');
      this.nextBtn = root.querySelector('[data-ygt-next]');
      this.layoutBeginBtn = null;
      this.branchWrap = root.querySelector('[data-ygt-dashboard-end]');

      var self = this;
      if (this.nextBtn) {
        this.nextBtn.addEventListener('click', function () {
          self.next();
        });
      }
      this.updateNavButtons(0);
      root.querySelector('[data-ygt-back]').addEventListener('click', function () {
        self.back();
      });
      root.querySelector('[data-ygt-skip]').addEventListener('click', function () {
        self.skip();
      });
      root.querySelector('[data-ygt-end-tour]').addEventListener('click', function () {
        self.finishDashboardOnly();
      });
      root.querySelector('[data-ygt-continue-settings]').addEventListener('click', function () {
        self.continueFromDashboard();
      });
      root.querySelector('[data-ygt-backdrop]').addEventListener('click', function () {
        if (isDashboardEndChoice(self.getStepList(), self.index)) {
          return;
        }
        if (isLayoutEditDemoAwaitingStart(self.getStepList()[self.index])) {
          return;
        }
        self.next();
      });

      $(document).on('keydown.ygtTour', function (e) {
        if (!self.root || !self.root.classList.contains('ygt-active')) {
          return;
        }
        if (e.key === 'Escape') {
          e.preventDefault();
          self.skip();
        }
      });

      var positionCurrentRaf = 0;
      $(window).on('resize.ygtTour scroll.ygtTour', function () {
        if (tourLayoutDemo.running) {
          return;
        }
        if (!self.root || !self.root.classList.contains('ygt-active')) {
          return;
        }
        var step = self.getStepList()[self.index];
        if (positionCurrentRaf) {
          window.cancelAnimationFrame(positionCurrentRaf);
        }
        positionCurrentRaf = window.requestAnimationFrame(function () {
          positionCurrentRaf = 0;
          if (step && step.id === 'add-section') {
            var addList = getAddSectionTargets();
            if (addList.length) {
              self.positionAddSectionSpotlights(
                addList,
                typeof step.spotlightPad === 'number' ? step.spotlightPad : 4
              );
              self.positionPopoverForAddSectionTargets(addList);
            }
            return;
          }
          self.positionCurrent();
        });
      });
    },

    start: function (startIndex) {
      this.mount();
      this.purgeLegacyLayoutBeginButton();
      var ext = readExtSession();
      if (ext && ext.id && !extensionTourById(ext.id)) {
        clearExtSession();
        return;
      }
      if (ext && ext.id && extensionTourById(ext.id)) {
        this.phase = 'extension';
        this.activeExtensionId = ext.id;
        this.stepList = extensionTourById(ext.id).steps;
      } else if (this.phase !== 'extension') {
        this.phase = 'core';
        this.stepList = coreSteps;
      }
      this.index = typeof startIndex === 'number' ? startIndex : 0;
      if (this.phase === 'extension' && ext && typeof ext.step === 'number') {
        this.index = ext.step;
      }
      saveStepIndex(this.index);
      if (this.phase === 'extension') {
        saveExtSession({ id: this.activeExtensionId, step: this.index });
      }
      document.body.classList.add('ygt-tour-active');
      this.root.classList.add('ygt-active');
      this.root.setAttribute('aria-hidden', 'false');
      this.elevatePopover();
      this.showStep(this.index);
    },

    elevatePopover: function () {
      if (!this.popover) {
        return;
      }
      if (this.popover.parentNode !== document.body) {
        this.popoverParent = this.root;
        document.body.appendChild(this.popover);
      }
      this.popover.classList.add('ygt-popover--detached');
    },

    restorePopover: function () {
      if (!this.popover) {
        return;
      }
      this.popover.classList.remove('ygt-popover--detached');
      if (this.popoverParent && this.popover.parentNode === document.body) {
        this.popoverParent.appendChild(this.popover);
      }
      this.popoverParent = null;
    },

    clearWorkspaceEditChrome: function () {
      document.body.classList.remove('ygt-step-workspace-edit');
      var ws = document.querySelector('[data-section-id="your-workspace"]');
      if (ws) {
        ws.classList.remove('ygt-tour-reveal-edit');
      }
    },

    clearWidgetHideChrome: function () {
      document.body.classList.remove('ygt-step-widget-hide');
    },

    applyStepChrome: function (step) {
      clearStepBodyClasses();
      clearTourTargetFocus();
      this.clearWorkspaceEditChrome();
      this.clearWidgetHideChrome();
      if (step && step.openSidebar) {
        document.body.classList.add('ygt-step-sidebar');
      }
      if (step && step.id === 'breadcrumbs') {
        document.body.classList.add('ygt-step-breadcrumbs');
      }
      if (step && usesWorkspaceEditChrome(step)) {
        document.body.classList.add('ygt-step-workspace-edit');
        var wsSection = document.querySelector('[data-section-id="your-workspace"]');
        if (wsSection) {
          wsSection.classList.add('ygt-tour-reveal-edit');
        }
      }
      if (step && step.openNotifications) {
        document.body.classList.add('ygt-step-notifications');
      }
      if (step && step.id === 'add-section') {
        document.body.classList.add('ygt-step-add-section');
      }
      if (step && (step.revealHideToggle || (step.id && step.id.indexOf('widget-hide') === 0))) {
        document.body.classList.add('ygt-step-widget-hide');
      }
      if (usesSpotlightOnly(step)) {
        document.body.classList.add('ygt-step-spotlight-only');
      }
      document.body.classList.remove('ygt-step-scrollable');
      if (
        step &&
        (step.scrollCenter ||
          step.id === 'add-section' ||
          step.layoutEdit ||
          step.id === 'colors' ||
          step.id === 'logo' ||
          step.id === 'login' ||
          step.id === 'workspace' ||
          isWorkspaceEditIntroStep(step) ||
          step.id === 'workspace-notes' ||
          step.id === 'quick-actions' ||
          (step.id && step.id.indexOf('widget-hide') === 0) ||
          (step.id && step.id.indexOf('settings-') === 0) ||
          (step.navigate && step.navigate.indexOf('settings-') === 0))
      ) {
        document.body.classList.add('ygt-step-scrollable');
      }
      if (!this.root) {
        return;
      }
      var spotlight = this.spotlight;
      if (step && step.openNotifications) {
        if (spotlight) {
          spotlight.setAttribute('hidden', 'hidden');
        }
      } else if (spotlight) {
        spotlight.removeAttribute('hidden');
      }
    },

    cancelPendingStepWork: function () {
      if (this._stepDelayTimer) {
        window.clearTimeout(this._stepDelayTimer);
        this._stepDelayTimer = null;
      }
      if (this._waitInterval) {
        window.clearInterval(this._waitInterval);
        this._waitInterval = null;
      }
      cancelTourLayoutDemo();
      clearStepSpotlight(this);
    },

    teardown: function () {
      this.cancelPendingStepWork();
      closeNotifications();
      closeSidebar();
      disableLayoutEdit();
      this.restorePopover();
      this.clearWorkspaceEditChrome();
      clearTourTargetFocus();
      clearStepBodyClasses();
      document.body.classList.remove('ygt-step-scrollable');
      if (this.root) {
        this.root.classList.remove('ygt-active');
        this.root.setAttribute('aria-hidden', 'true');
      }
      document.body.classList.remove('ygt-tour-active');
      if (this.spotlight) {
        this.spotlight.setAttribute('hidden', 'hidden');
      }
      this.hideExtraSpotlight();
      if (this.popover) {
        this.popover.classList.remove('ygt-popover--visible');
      }
    },

    isActiveSegmentTour: function () {
      if (this.phase === 'extension') {
        return true;
      }
      if (!cfg.dashboardDone || this.phase !== 'core') {
        return false;
      }
      return this.index >= firstSettingsStepIndex(this.getStepList());
    },

    getActiveSegmentId: function () {
      if (this.phase === 'extension') {
        return this.activeExtensionId || '';
      }
      if (cfg.dashboardDone && this.phase === 'core') {
        return 'settings';
      }
      return '';
    },

    skip: function () {
      var self = this;
      var step = self.getStepList()[self.index];
      if (step && step.id === 'workspace-layout-edit') {
        resetDashboardLayoutAfterDrag();
      }
      if (self.isActiveSegmentTour()) {
        var segmentId = self.getActiveSegmentId();
        self.teardown();
        ajax('segment_pending', { segment_id: segmentId }).done(function (res) {
          mergeStateFromResponse(res);
          self.phase = 'core';
          self.activeExtensionId = null;
          self.stepList = coreSteps;
          if (hasPendingSegments()) {
            TourPicker.show();
          }
        });
        return;
      }
      self.teardown();
      ajax('skip').always(function () {
        clearStepStorage();
        clearExtSession();
        clearSettingsPendingFlag();
        cfg.dashboardDone = false;
        cfg.settingsTour = '';
        cfg.segments = {};
        cfg.inProgress = false;
        self.phase = 'core';
        Complete.show('skipped');
      });
    },

    finish: function () {
      var self = this;
      var settingsStart = firstSettingsStepIndex(self.getStepList());

      if (self.phase === 'extension') {
        var finishedId = self.activeExtensionId;
        self.teardown();
        ajax('segment_complete', { segment_id: finishedId }).done(function (res) {
          mergeStateFromResponse(res);
          self.phase = 'core';
          self.activeExtensionId = null;
          self.stepList = coreSteps;
          postSegmentTourEnd();
        });
        return;
      }

      if (cfg.dashboardDone && self.phase === 'core' && self.index >= settingsStart) {
        self.teardown();
        ajax('segment_complete', { segment_id: 'settings' }).done(function (res) {
          mergeStateFromResponse(res);
          self.phase = 'core';
          postSegmentTourEnd();
        });
        return;
      }

      self.teardown();
      postSegmentTourEnd();
    },

    beforeStep: function (step) {
      this.applyStepChrome(step);
      if (!step.openNotifications) {
        closeNotifications();
      }
      if (!step.openSidebar) {
        closeSidebar();
      }
      if (step.openSidebar) {
        openSidebar();
      }
      if (step.layoutEdit) {
        enableLayoutEdit();
      }
      if (step.navigate) {
        var url = navigateUrl(step.navigate);
        if (url && window.location.href.split('#')[0] !== url.split('#')[0]) {
          saveStepIndex(this.index);
          window.location.assign(url);
          return false;
        }
        if (step.navigate === 'settings-colors') {
          if (currentPage() === 'settings') {
            activateSettingsTab(step.navigate);
          }
        } else if (currentPage() === 'settings') {
          activateSettingsTab(step.navigate);
        }
      }
      return true;
    },

    resolveLoginPanelTarget: function () {
      var panel = document.querySelector('#tab-login.is-active');
      if (!panel || !isTargetVisible(panel)) {
        return null;
      }
      var split = panel.querySelector('.yp-login-split');
      if (split && isTargetVisible(split)) {
        return split;
      }
      var stack =
        panel.querySelector('#yooadmin-login-tab-stack') ||
        panel.querySelector('.yooadmin-login-tab-stack');
      if (stack && isTargetVisible(stack)) {
        return stack;
      }
      var card = panel.querySelector('.yp-settings-card');
      if (card && isTargetVisible(card)) {
        return card;
      }
      return null;
    },

    resolveSettingsTabPanel: function (tab) {
      var panel = document.querySelector('#tab-' + tab + '.is-active');
      if (!panel || !isTargetVisible(panel)) {
        return null;
      }
      var blocks = panel.querySelectorAll(
        '.yp-settings-card, .yp-notifications-split, .yooadmin-login-tab-stack, .form-table'
      );
      var i;
      for (i = 0; i < blocks.length; i++) {
        if (isTargetVisible(blocks[i])) {
          return blocks[i];
        }
      }
      return panel;
    },

    resolveHideToggleTarget: function (step) {
      var host = null;
      if (step.hideScope === 'section' && step.target && step.target.indexOf(',') !== -1) {
        var selectors = step.target.split(',');
        var s;
        for (s = 0; s < selectors.length; s++) {
          var sel = selectors[s].trim();
          if (!sel) {
            continue;
          }
          var nodes = document.querySelectorAll(sel);
          var n;
          for (n = 0; n < nodes.length; n++) {
            if (!isTargetVisible(nodes[n])) {
              continue;
            }
            var toggle = nodes[n].querySelector('.yp-section-visibility-toggle');
            if (toggle && isTargetVisible(toggle)) {
              return step.hideSpotlightCard ? nodes[n] : toggle;
            }
          }
        }
      }
      if (step.target) {
        host = resolveTarget(step.target, true);
      }
      if (!host) {
        return null;
      }
      if (step.hideScope === 'section') {
        var sectionToggle = host.querySelector('.yp-section-visibility-toggle');
        if (sectionToggle && isTargetVisible(sectionToggle)) {
          return step.hideSpotlightCard
            ? sectionToggle.closest('[data-section-id]') || host
            : sectionToggle;
        }
      } else {
        var cards = host.matches('[data-card-id]')
          ? [host]
          : host.querySelectorAll('[data-card-id]');
        var c;
        for (c = 0; c < cards.length; c++) {
          var cardToggle = cards[c].querySelector('.yp-card-visibility-toggle');
          if (cardToggle && isTargetVisible(cardToggle)) {
            return step.hideSpotlightCard ? cards[c] : cardToggle;
          }
        }
        cardToggle = host.querySelector('.yp-card-visibility-toggle');
        if (cardToggle && isTargetVisible(cardToggle)) {
          return step.hideSpotlightCard
            ? cardToggle.closest('[data-card-id]') || host
            : cardToggle;
        }
      }
      return isTargetVisible(host) ? host : null;
    },

    resolveBrandPanelTarget: function () {
      var panel = document.querySelector('#tab-brand.is-active');
      if (!panel || !isTargetVisible(panel)) {
        return null;
      }
      var card = panel.querySelector('.yp-settings-card');
      if (card && isTargetVisible(card)) {
        return card;
      }
      var table = panel.querySelector('.form-table');
      if (table && isTargetVisible(table)) {
        return table;
      }
      return null;
    },

    resolveStepTarget: function (step) {
      prepareManagerStep(step);
      if (step.tourRepoSearchWait && step.page === 'plugins') {
        var installBtn = resolvePluginsRepoInstallTarget(step.tourRepoSearchWait);
        if (installBtn) {
          return installBtn;
        }
      }
      if (step.hideToggle) {
        var hideTarget = this.resolveHideToggleTarget(step);
        if (hideTarget) {
          return hideTarget;
        }
      }
      if (step.target) {
        var explicit = resolveTarget(step.target, true);
        if (explicit) {
          return explicit;
        }
      }
      if (step.navigate && step.navigate.indexOf('settings-') === 0) {
        var settingsTab = step.navigate.replace('settings-', '');
        if (currentPage() === 'settings') {
          activateSettingsTab(step.navigate);
        }
        var tabPanel = this.resolveSettingsTabPanel(settingsTab);
        if (tabPanel) {
          return tabPanel;
        }
      }
      if (step.id === 'logo' || step.navigate === 'settings-brand') {
        if (currentPage() === 'settings') {
          activateSettingsTab('settings-brand');
        }
        var brandPanel = this.resolveBrandPanelTarget();
        if (brandPanel) {
          return brandPanel;
        }
      }
      if (step.id === 'login' || step.navigate === 'settings-login') {
        if (currentPage() === 'settings') {
          activateSettingsTab('settings-login');
        }
        var loginPanel = this.resolveLoginPanelTarget();
        if (loginPanel) {
          return loginPanel;
        }
      }
      if (step.id === 'settings-maintenance' || step.navigate === 'settings-maintenance') {
        if (currentPage() === 'settings') {
          activateSettingsTab('settings-maintenance');
        }
        var maintRoot = document.querySelector(
          '#tab-maintenance.is-active .yooadmin-maintenance-settings'
        );
        if (maintRoot && isTargetVisible(maintRoot)) {
          return maintRoot;
        }
        return resolveTarget(
          '#tab-maintenance.is-active .yooadmin-maintenance-settings, #tab-maintenance.is-active .yooadmin-maintenance-settings-body',
          true
        );
      }
      if (step.navigate === 'settings-colors') {
        if (currentPage() === 'theme-settings') {
          var brandSection = document.querySelector(
            '.yooadmin-theme-settings-section-brand-colors'
          );
          if (brandSection && isTargetVisible(brandSection)) {
            return brandSection;
          }
          return resolveTarget(
            '.yooadmin-theme-settings-section-brand-colors, .yooadmin-brand-color-field',
            true
          );
        }
        if (currentPage() === 'settings') {
          activateSettingsTab('settings-colors');
          return resolveTarget(
            '#tab-colors.is-active .yooadmin-color-field, #tab-colors.is-active .yp-settings-card',
            true
          );
        }
        return null;
      }
      if (step.navigate) {
        var tab = step.navigate.replace('settings-', '');
        if (currentPage() === 'settings') {
          activateSettingsTab(step.navigate);
        }
        if (step.navigate === 'settings-brand') {
          var brandCard = this.resolveBrandPanelTarget();
          if (brandCard) {
            return brandCard;
          }
        }
        if (step.navigate === 'settings-login') {
          var loginStack = this.resolveLoginPanelTarget();
          if (loginStack) {
            return loginStack;
          }
        }
        var panel = document.querySelector('#tab-' + tab + '.is-active');
        if (panel && isTargetVisible(panel)) {
          if (step.preferControls) {
            return (
              panel.querySelector('.yp-settings-card') ||
              panel.querySelector('p.yp-help') ||
              panel
            );
          }
          return (
            panel.querySelector('.yp-tab-intro') ||
            panel.querySelector('p.yp-help') ||
            panel.querySelector('.yp-settings-card') ||
            panel
          );
        }
        return resolveTarget(
          '#tab-' +
            tab +
            '.is-active, [data-yp-tabs] .yp-tab[data-tab="' +
            tab +
            '"].is-active',
          true
        );
      }
      return null;
    },

    getSettingsTarget: function (navKey) {
      return this.resolveStepTarget({ navigate: navKey });
    },

    resolveTargetForStep: function (step) {
      if (step.id === 'plugins-bulk' && step.page === 'plugins') {
        return resolvePluginsBulkSelectedCards();
      }
      if (step.id === 'themes-bulk' && step.page === 'theme-manager') {
        return resolveThemesBulkSelectedCards();
      }
      if (
        step.page === 'theme-manager' &&
        step.browseTab &&
        step.browseTab !== 'installed' &&
        !isThemesRepoBrowseReady(step.browseTab)
      ) {
        return null;
      }
      if (step.id === 'themes-card-actions' && step.page === 'theme-manager') {
        if (!isThemesInstalledTabActive()) {
          return null;
        }
        var themeActions = resolveTarget(
          managerWrapSelector('theme-manager') +
            ' #wp-results .yoo-plugin-card:not(.active) .yoo-theme-card__actions-bar',
          true
        );
        if (themeActions) {
          pinThemeTourHoldHover(themeActions);
        }
        return themeActions;
      }
      if (step.id === 'plugins-card-actions' && step.page === 'plugins') {
        if (!isPluginsInstalledTabActive()) {
          return null;
        }
        return resolveTarget(
          managerWrapSelector('plugins') +
            ' .yoo-plugin-card[data-plugin-file]:not([data-plugin-file=""]) .yoo-plugin-actions',
          true
        );
      }
      if (step.id === 'plugins-auto-update' && step.page === 'plugins') {
        if (!isPluginsInstalledTabActive()) {
          return null;
        }
        return resolveTarget(
          managerWrapSelector('plugins') +
            ' .yoo-plugin-card[data-plugin-file]:not([data-plugin-file=""]) .yoo-auto-update-toggle',
          true
        );
      }
      if (step.navigate) {
        return this.resolveStepTarget(step);
      }
      if (step.dualAddSection || step.id === 'add-section') {
        var addTargets = getAddSectionTargets();
        return addTargets.length ? addTargets : null;
      }
      return resolveTarget(step.target, true);
    },

    queueStepTarget: function (step, renderWithTarget) {
      var self = this;
      var token = this._stepToken;

      function scrollBlockForStep() {
        if (step.id === 'add-section') {
          return 'center';
        }
        if (step.hideToggle) {
          return 'nearest';
        }
        if (step.scrollCenter || step.layoutEdit || step.navigate) {
          return 'center';
        }
        return 'nearest';
      }

      function deliver(target) {
        if (token !== self._stepToken) {
          return;
        }
        if (step.id === 'add-section') {
          if (target && isTargetList(target) && target.length) {
            scrollAddSectionTargetsIntoView(target);
          }
          afterLayoutPaint(function () {
            if (token !== self._stepToken) {
              return;
            }
            afterLayoutPaint(function () {
              if (token !== self._stepToken) {
                return;
              }
              renderWithTarget(
                target && isTargetList(target) && target.length ? target : null
              );
              if (target && isTargetList(target) && target.length) {
                stabilizeAddSectionSpotlights(self, target, token);
              }
            });
          });
          return;
        }
        afterLayoutPaint(function () {
          if (token !== self._stepToken) {
            return;
          }
          if (target) {
            if (
              step.navigate &&
              (currentPage() === 'settings' || currentPage() === 'theme-settings')
            ) {
              scrollSettingsToTop();
            }
            var scrollEl = target;
            if (step.id === 'plugins-bulk' && isTargetList(target)) {
              scrollEl =
                document.querySelector(
                  managerWrapSelector('plugins') + ' #wp-results'
                ) || target[0];
            } else if (step.id === 'themes-bulk' && isTargetList(target)) {
              scrollEl =
                document.querySelector(
                  managerWrapSelector('theme-manager') + ' #wp-results'
                ) || target[0];
            }
            if (scrollEl) {
              scrollTargetIntoView(
                isTargetList(scrollEl) ? scrollEl[0] : scrollEl,
                {
                  block: scrollBlockForStep(),
                  behavior:
                    step.id === 'add-section' || tourLayoutDemo.running
                      ? 'auto'
                      : 'smooth'
                }
              );
            }
          }
          afterLayoutPaint(function () {
            if (token !== self._stepToken) {
              return;
            }
            renderWithTarget(target || null);
          });
        });
      }

      function targetIsReady(candidate) {
        if (!candidate) {
          return false;
        }
        if (isTargetList(candidate)) {
          return !!candidate.length;
        }
        return isTargetVisible(candidate);
      }

      if (step.id === 'add-section') {
        ensureLayoutEditForAddSection(function () {
          if (token !== self._stepToken) {
            return;
          }
          self._waitInterval = waitForTarget(
            function () {
              var list = getAddSectionTargets();
              return list.length >= 1 ? list : null;
            },
            function (target) {
              self._waitInterval = null;
              var list =
                target && target.length >= 1
                  ? target
                  : getAddSectionTargets();
              deliver(list.length >= 1 ? list : null);
            },
            { maxTries: 40, intervalMs: 80 }
          );
        });
        return;
      }

      if (step.tourRepoSearchWait && step.page === 'plugins') {
        prepareManagerStep(step);
        this._waitInterval = waitForTarget(
          function () {
            return resolvePluginsRepoInstallTarget(step.tourRepoSearchWait);
          },
          function (target) {
            self._waitInterval = null;
            deliver(target || resolveTarget(step.target, true));
          },
          { maxTries: 70, intervalMs: 200 }
        );
        return;
      }

      if (
        step.id === 'themes-install' &&
        step.page === 'theme-manager' &&
        step.tourKeepRepoSearch
      ) {
        function deliverThemesInstallTarget() {
          if (token !== self._stepToken) {
            return;
          }
          self._waitInterval = waitForTarget(
            function () {
              if (!isThemesRepoBrowseReady(step.browseTab || 'featured')) {
                return null;
              }
              if (!resolveThemesRepoCardBySlug(step.tourRepoSlug || 'astra')) {
                return null;
              }
              return resolveThemesAstraInstallTarget();
            },
            function (target) {
              self._waitInterval = null;
              deliver(target);
            },
            { maxTries: 45, intervalMs: 120 }
          );
        }

        if (
          isThemesRepoBrowseReady(step.browseTab || 'featured') &&
          themesRepoSearchMatches(step.tourRepoSlug || 'astra') &&
          resolveThemesRepoCardBySlug(step.tourRepoSlug || 'astra')
        ) {
          deliverThemesInstallTarget();
        } else {
          var themesWrapSel = managerWrapSelector('theme-manager');
          if (!isThemesBrowseTabActive(step.browseTab || 'featured')) {
            activateBrowseTab(step.browseTab || 'featured', themesWrapSel);
          }
          window.setTimeout(deliverThemesInstallTarget, 200);
        }
        return;
      }

      if (step.id === 'themes-bulk' && step.page === 'theme-manager') {
        var themesWrap = managerWrapSelector('theme-manager');
        switchThemesToInstalledTab(function () {
          if (token !== self._stepToken) {
            return;
          }
          self._waitInterval = waitForTarget(
            function () {
              var cbs = document.querySelectorAll(
                themesWrap + ' [data-yoo-theme-installed-cb]'
              );
              var j;
              var card;
              for (j = 0; j < cbs.length; j++) {
                card = cbs[j].closest('.yoo-plugin-card');
                if (isThemeBulkSelectableCard(card)) {
                  return cbs[j];
                }
              }
              return null;
            },
            function () {
              if (token !== self._stepToken) {
                return;
              }
              triggerThemesSelectAll();
              window.setTimeout(function () {
                if (token !== self._stepToken) {
                  return;
                }
                self._waitInterval = waitForTarget(
                  function () {
                    return resolveThemesBulkSelectedCards();
                  },
                  function (target) {
                    self._waitInterval = null;
                    var bulkCards =
                      target && target.length
                        ? target
                        : forceThemesBulkSelectedCards();
                    deliver(
                      bulkCards && bulkCards.length ? bulkCards : null
                    );
                  },
                  { maxTries: 60, intervalMs: 150 }
                );
              }, 450);
            },
            { maxTries: 55, intervalMs: 180 }
          );
        });
        return;
      }

      if (needsThemesInstalledWait(step)) {
        switchThemesToInstalledTab(function () {
          if (token !== self._stepToken) {
            return;
          }
          self._waitInterval = waitForTarget(
            function () {
              return self.resolveTargetForStep(step);
            },
            function (target) {
              self._waitInterval = null;
              deliver(target);
            },
            { maxTries: 55, intervalMs: 180 }
          );
        });
        return;
      }

      if (needsThemesRepoBrowseWait(step)) {
        switchThemesBrowseTab(step.browseTab, function () {
          if (token !== self._stepToken) {
            return;
          }
          prepareManagerStep(step);
          self._waitInterval = waitForTarget(
            function () {
              if (!isThemesRepoBrowseReady(step.browseTab)) {
                return null;
              }
              if (step.id === 'themes-search' && step.tourRepoSearch) {
                if (!resolveThemesRepoCardBySlug(step.tourRepoSearch)) {
                  return null;
                }
              }
              return self.resolveTargetForStep(step);
            },
            function (target) {
              self._waitInterval = null;
              deliver(target);
            },
            { maxTries: 60, intervalMs: 200 }
          );
        });
        return;
      }

      if (step.id === 'plugins-bulk' && step.page === 'plugins') {
        var pluginsWrap = managerWrapSelector('plugins');
        switchPluginsToInstalledTab(function () {
          if (token !== self._stepToken) {
            return;
          }
          self._waitInterval = waitForTarget(
            function () {
              return document.querySelector(
                pluginsWrap +
                  ' .yoo-plugin-card[data-plugin-file]:not([data-plugin-file=""])'
              );
            },
            function () {
              if (token !== self._stepToken) {
                return;
              }
              triggerPluginsSelectAll();
              window.setTimeout(function () {
                if (token !== self._stepToken) {
                  return;
                }
                self._waitInterval = waitForTarget(
                  function () {
                    return resolvePluginsBulkSelectedCards();
                  },
                  function (target) {
                    self._waitInterval = null;
                    deliver(
                      target && target.length
                        ? target
                        : forcePluginsBulkSelectedCards()
                    );
                  },
                  { maxTries: 60, intervalMs: 150 }
                );
              }, 450);
            },
            { maxTries: 55, intervalMs: 180 }
          );
        });
        return;
      }

      if (needsPluginsInstalledWait(step)) {
        switchPluginsToInstalledTab(function () {
          if (token !== self._stepToken) {
            return;
          }
          self._waitInterval = waitForTarget(
            function () {
              return self.resolveTargetForStep(step);
            },
            function (target) {
              self._waitInterval = null;
              deliver(target);
            },
            { maxTries: 55, intervalMs: 180 }
          );
        });
        return;
      }

      var immediate = this.resolveTargetForStep(step);
      if (targetIsReady(immediate)) {
        deliver(immediate);
        return;
      }

      this._waitInterval = waitForTarget(
        function () {
          return self.resolveTargetForStep(step);
        },
        function (target) {
          self._waitInterval = null;
          deliver(target);
        },
        {
          maxTries:
            step.layoutEdit ||
            step.hideToggle ||
            step.revealHideToggle ||
            step.navigate ||
            step.browseTab ||
            step.listView ||
            step.tourRepoSearch
              ? 36
              : 12,
          intervalMs: step.tourRepoSearch ? 120 : 40
        }
      );
    },

    positionPopoverForThemeColors: function (sectionEl, placement) {
      var pop = this.popover;
      if (!pop || !sectionEl) {
        this.positionPopoverCenter();
        return;
      }
      var rect = sectionEl.getBoundingClientRect();
      var margin = 18;
      var left = rect.left - pop.offsetWidth - margin;
      var top = rect.top + 24;
      if (placement === 'right' || placement === 'end') {
        left = rect.right + margin;
      } else if (placement === 'top') {
        left = rect.left + Math.max(0, (rect.width - pop.offsetWidth) / 2);
        top = rect.top - pop.offsetHeight - margin;
      } else if (placement === 'bottom') {
        left = rect.left + Math.max(0, (rect.width - pop.offsetWidth) / 2);
        top = rect.bottom + margin;
      }
      if (left < 12) {
        left = rect.right + margin;
        top = rect.top + 24;
      }
      if (left + pop.offsetWidth > window.innerWidth - 12) {
        left = Math.max(12, (window.innerWidth - pop.offsetWidth) / 2);
        top = Math.max(72, rect.top - pop.offsetHeight - margin);
      }
      left = Math.max(12, Math.min(left, window.innerWidth - pop.offsetWidth - 12));
      top = Math.max(12, Math.min(top, window.innerHeight - pop.offsetHeight - 12));
      pop.style.top = top + 'px';
      pop.style.left = left + 'px';
    },

    positionPopoverForSettings: function (el, placement) {
      var pop = this.popover;
      if (!pop || !el) {
        this.positionPopoverCenter();
        return;
      }
      if (placement === 'bottom' || placement === 'top') {
        var step = this.getStepList()[this.index] || {};
        this.positionPopoverNear(el, placement || 'bottom', step);
        return;
      }
      var margin = 16;
      var rect = el.getBoundingClientRect();
      var top = rect.top - pop.offsetHeight - margin;
      var left = rect.left + Math.max(0, (rect.width - pop.offsetWidth) / 2);
      if (top < 72 || rect.top > window.innerHeight * 0.5) {
        top = 72;
        left = Math.max(16, (window.innerWidth - pop.offsetWidth) / 2);
      }
      left = Math.max(12, Math.min(left, window.innerWidth - pop.offsetWidth - 12));
      top = Math.max(12, Math.min(top, window.innerHeight - pop.offsetHeight - 12));
      pop.style.top = top + 'px';
      pop.style.left = left + 'px';
    },

    updateNavButtons: function (idx) {
      if (!this.popover) {
        return;
      }
      var stepList = this.getStepList();
      var step = stepList[idx];
      var showBranch =
        this.phase === 'core' && isDashboardEndChoice(stepList, idx);
      var showLayoutBegin = shouldShowLayoutDemoBegin(step);
      var layoutPlaying =
        tourLayoutDemo.running && isLayoutEditDemoStep(step);
      var navWrap = this.navWrap;
      var nextBtn = this.nextBtn;
      var branchWrap = this.branchWrap;

      if (navWrap) {
        navWrap.classList.toggle('ygt-popover__nav--dashboard-end', showBranch);
      }
      if (showBranch) {
        removeLayoutBeginButton();
        if (nextBtn && nextBtn.parentNode) {
          nextBtn.parentNode.removeChild(nextBtn);
        }
        if (branchWrap) {
          branchWrap.removeAttribute('hidden');
          branchWrap.setAttribute('aria-hidden', 'false');
        }
        return;
      }
      if (showLayoutBegin || layoutPlaying) {
        removeNextButton();
        syncLayoutBeginButton(showLayoutBegin, navWrap, branchWrap);
      } else {
        removeLayoutBeginButton();
        restoreNextButton(navWrap, branchWrap);
      }
      if (branchWrap) {
        branchWrap.setAttribute('hidden', 'hidden');
        branchWrap.setAttribute('aria-hidden', 'true');
      }
    },

    updatePopoverChrome: function (step, idx) {
      var stepList = this.getStepList();
      var meta = stepMetaForIndex(stepList, idx);
      if (!this.metaEl || !this.titleEl || !this.textEl) {
        return;
      }
      var metaTemplate = i18n.stepOf || 'Step %1$s of %2$s';
      this.metaEl.textContent = metaTemplate
        .replace('%1$s', String(meta.num))
        .replace('%2$s', String(meta.total));
      this.titleEl.textContent = step.title || '';
      this.textEl.textContent = layoutDemoStepText(step);
      var backBtn = this.popover ? this.popover.querySelector('[data-ygt-back]') : null;
      if (backBtn) {
        backBtn.disabled = idx === 0;
      }
      this.updateNavButtons(idx);
      if (this.popover && !isLayoutDemoPopoverSuppressed()) {
        this.popover.classList.add('ygt-popover--visible');
      }
    },

    showStep: function (idx) {
      var self = this;
      var stepList = this.getStepList();
      if (idx >= stepList.length) {
        this.finish();
        return;
      }

      var step = stepList[idx];
      var settingsStart = firstSettingsStepIndex(stepList);
      syncTourFlagsFromCfg();
      if (
        this.phase === 'core' &&
        cfg.dashboardDone &&
        idx >= settingsStart
      ) {
        if (
          getSegmentStatus('settings') !== 'pending' &&
          !readSettingsPendingFlag()
        ) {
          this.teardown();
          postSegmentTourEnd();
          return;
        }
      }

      this.cancelPendingStepWork();
      this._stepToken = (this._stepToken || 0) + 1;
      var token = this._stepToken;
      var fromIdx = this.index;
      if (fromIdx !== idx && idx > fromIdx) {
        var leavingStep = stepList[fromIdx];
        var nextStep = stepList[idx];
        if (leavingStep && leavingStep.layoutResetAfter) {
          resetDashboardLayoutPositionsOnly();
          if (!nextStep || nextStep.id !== 'add-section') {
            disableLayoutEdit();
          }
        }
        if (
          nextStep &&
          nextStep.id === 'security-tools' &&
          leavingStep &&
          (leavingStep.layoutEdit || leavingStep.hideToggle)
        ) {
          disableLayoutEdit();
        }
      }
      this.index = idx;
      saveStepIndex(idx);

      if (step.id === 'security-tools') {
        disableLayoutEdit();
      }

      if (step.id === 'workspace-layout-edit') {
        tourLayoutDemo.playbackDone = false;
        setLayoutDemoPopoverChromeVisible(true);
        if (this.popover) {
          this.popover.classList.remove('ygt-popover--demo-playing');
        }
      } else {
        removeLayoutBeginButton();
      }

      if (step.page === 'dashboard' && currentPage() !== 'dashboard') {
        saveStepIndex(idx);
        window.location.assign(cfg.dashboardUrl);
        return;
      }

      var neededPage = requiredPageForStep(step);
      if (neededPage && neededPage !== currentPage()) {
        saveStepIndex(idx);
        if (this.phase === 'extension') {
          saveExtSession({ id: this.activeExtensionId, step: idx });
        }
        window.location.assign(stepDestinationUrl(step) || navigateUrl(step.navigate));
        return;
      }

      if (!this.beforeStep(step)) {
        return;
      }

      this.updatePopoverChrome(step, idx);
      clearStepSpotlight(this);

      function renderWithTarget(target) {
        self.renderStep(step, target, idx);
      }

      if (step.openNotifications) {
        openNotifications(function (dropdownEl) {
          elevateNotificationsDropdown();
          renderWithTarget(dropdownEl || resolveTarget(step.target));
        });
        return;
      }

      if (step.openSidebar) {
        this._stepDelayTimer = window.setTimeout(function () {
          self._stepDelayTimer = null;
          if (token !== self._stepToken) {
            return;
          }
          var sidebarTarget =
            document.querySelector('#yps-sidebar.is-open') ||
            document.getElementById('yps-sidebar');
          renderWithTarget(sidebarTarget);
        }, 280);
        return;
      }

      this.queueStepTarget(step, renderWithTarget);
    },

    renderStep: function (step, target, idx) {
      var stepList = this.getStepList();
      var meta = stepMetaForIndex(stepList, idx);
      var metaTemplate = i18n.stepOf || 'Step %1$s of %2$s';
      this.metaEl.textContent = metaTemplate
        .replace('%1$s', String(meta.num))
        .replace('%2$s', String(meta.total));
      this.titleEl.textContent = step.title || '';
      this.textEl.textContent =
        target && (!isTargetList(target) || target.length)
          ? layoutDemoStepText(step)
          : i18n.targetMissing || step.text || '';

      var backBtn = this.popover ? this.popover.querySelector('[data-ygt-back]') : null;
      if (backBtn) {
        backBtn.disabled = idx === 0;
      }
      this.updateNavButtons(idx);

      setTourTargetFocus(target, step);

      if (stepNeedsThemeCardHover(step) && target) {
        pinThemeTourHoldHover(isTargetList(target) ? target[0] : target);
      }

      if (!target || (isTargetList(target) && !target.length)) {
        if (this.spotlight) {
          this.spotlight.setAttribute('hidden', 'hidden');
        }
        this.hideExtraSpotlight();
        this.positionPopoverCenter();
      } else {
        if (step.openNotifications) {
          if (this.spotlight) {
            this.spotlight.setAttribute('hidden', 'hidden');
          }
          this.hideExtraSpotlight();
        } else if (step.id === 'add-section' && isTargetList(target) && target.length) {
          this.positionAddSectionSpotlights(target, spotlightPad(step));
        } else if (
          step.dualSpotlights &&
          isTargetList(target) &&
          target.length > 1
        ) {
          this.positionDualSpotlights(target, spotlightPad(step));
        } else {
          this.hideExtraSpotlight();
          if (this.spotlight) {
            this.spotlight.removeAttribute('hidden');
          }
          if (isTargetList(target)) {
            this.positionSpotlightOnElements(target, spotlightPad(step));
          } else {
            this.positionSpotlight(target, spotlightPad(step));
          }
        }
        if (step.openNotifications) {
          pinNotificationsDropdown();
          this.positionPopoverForNotifications(target);
        } else if (step.openSidebar) {
          this.positionPopoverForSidebar(target, step.placement);
        } else if (step.id === 'breadcrumbs') {
          this.positionPopoverForHeaderBar(target, step.placement);
        } else if (isDashboardCardStep(step)) {
          this.positionPopoverForDashboardCard(target, step.placement);
        } else if (isWorkspaceEditIntroStep(step)) {
          this.positionPopoverForEditToggle(target, step.placement);
        } else if (step.id === 'add-section' && isTargetList(target)) {
          this.positionPopoverForAddSectionTargets(target);
        } else if (step.id === 'plugins-bulk') {
          var bulkBar = document.getElementById('upload-bulk-actions-bar');
          if (bulkBar && isTargetVisible(bulkBar)) {
            this.positionPopoverForThemeColors(bulkBar, 'bottom');
          } else if (isTargetList(target) && target.length) {
            this.positionPopoverForThemeColors(target[0], 'bottom');
          } else {
            this.positionPopoverCenter();
          }
        } else if (step.id === 'themes-bulk') {
          var themeBulkBar = document.getElementById('yoo-theme-installed-bulk-bar');
          if (themeBulkBar && isTargetVisible(themeBulkBar)) {
            this.positionPopoverForThemeColors(themeBulkBar, 'bottom');
          } else if (isTargetList(target) && target.length) {
            this.positionPopoverForThemeColors(target[0], 'bottom');
          } else {
            this.positionPopoverCenter();
          }
        } else if (
          step.id === 'colors' ||
          step.id === 'logo' ||
          step.id === 'login' ||
          (step.id && step.id.indexOf('settings-') === 0) ||
          (step.navigate && step.navigate.indexOf('settings-') === 0) ||
          step.page === 'plugins' ||
          step.page === 'theme-manager' ||
          step.page === 'media'
        ) {
          this.positionPopoverForThemeColors(target, step.placement);
        } else if (step.hideToggle || (step.id && step.id.indexOf('widget-hide') === 0)) {
          this.positionPopoverForThemeColors(target, step.placement || 'left');
        } else {
          if (step.navigate) {
            this.positionPopoverForSettings(target, step.placement);
          } else {
            this.positionPopoverNear(target, step.placement, step);
          }
        }
      }

      if (!isLayoutDemoPopoverSuppressed()) {
        this.popover.classList.add('ygt-popover--visible');
      }
    },

    positionCurrent: function () {
      if (tourLayoutDemo.running) {
        return;
      }
      var stepList = this.getStepList();
      var step = stepList[this.index];
      if (!step) {
        return;
      }
      var self = this;
      function place(target) {
        if (!target) {
          self.positionPopoverCenter();
          return;
        }
        if (step.openNotifications) {
          if (self.spotlight) {
            self.spotlight.setAttribute('hidden', 'hidden');
          }
        } else if (step.id === 'add-section' && isTargetList(target) && target.length) {
          self.positionAddSectionSpotlights(target, spotlightPad(step));
        } else if (
          step.dualSpotlights &&
          isTargetList(target) &&
          target.length > 1
        ) {
          self.positionDualSpotlights(target, spotlightPad(step));
        } else if (isTargetList(target)) {
          self.hideExtraSpotlight();
          self.positionSpotlightOnElements(target, spotlightPad(step));
        } else {
          self.hideExtraSpotlight();
          self.positionSpotlight(target, spotlightPad(step));
        }
        if (step.openNotifications) {
          pinNotificationsDropdown();
          self.positionPopoverForNotifications(target);
        } else if (step.openSidebar) {
          self.positionPopoverForSidebar(target, step.placement);
        } else if (step.id === 'breadcrumbs') {
          self.positionPopoverForHeaderBar(target, step.placement);
        } else if (isDashboardCardStep(step)) {
          self.positionPopoverForDashboardCard(target, step.placement);
        } else if (isWorkspaceEditIntroStep(step)) {
          self.positionPopoverForEditToggle(target, step.placement);
        } else if (step.id === 'add-section' && isTargetList(target)) {
          self.positionPopoverForAddSectionTargets(target);
        } else if (step.id === 'plugins-bulk') {
          var bulkBarResize = document.getElementById('upload-bulk-actions-bar');
          if (bulkBarResize && isTargetVisible(bulkBarResize)) {
            self.positionPopoverForThemeColors(bulkBarResize, 'bottom');
          } else if (isTargetList(target) && target.length) {
            self.positionPopoverForThemeColors(target[0], 'bottom');
          } else {
            self.positionPopoverCenter();
          }
        } else if (step.id === 'themes-bulk') {
          var themeBulkBarResize = document.getElementById(
            'yoo-theme-installed-bulk-bar'
          );
          if (themeBulkBarResize && isTargetVisible(themeBulkBarResize)) {
            self.positionPopoverForThemeColors(themeBulkBarResize, 'bottom');
          } else if (isTargetList(target) && target.length) {
            self.positionPopoverForThemeColors(target[0], 'bottom');
          } else {
            self.positionPopoverCenter();
          }
        } else if (
          step.id === 'colors' ||
          step.id === 'logo' ||
          step.id === 'login' ||
          (step.id && step.id.indexOf('settings-') === 0) ||
          (step.navigate && step.navigate.indexOf('settings-') === 0) ||
          step.page === 'plugins' ||
          step.page === 'theme-manager' ||
          step.page === 'media'
        ) {
          self.positionPopoverForThemeColors(target, step.placement);
        } else if (step.hideToggle || (step.id && step.id.indexOf('widget-hide') === 0)) {
          self.positionPopoverForThemeColors(target, step.placement || 'left');
        } else {
          try {
            if (step.navigate) {
              scrollSettingsToTop();
            }
          } catch (eScrollSettings2) {}
          if (step.navigate) {
            self.positionPopoverForSettings(target, step.placement);
          } else {
            self.positionPopoverNear(target, step.placement, step);
          }
        }
      }
      if (step.openNotifications) {
        elevateNotificationsDropdown();
        place(document.querySelector('.yp-notifications-dropdown.show') || resolveTarget(step.target));
        return;
      }
      if (step.openSidebar) {
        place(
          document.querySelector('#yps-sidebar.is-open') ||
            document.getElementById('yps-sidebar')
        );
        return;
      }
      place(this.resolveTargetForStep(step));
    },

    syncSpotlightRadius: function (el) {
      var radius = '12px';
      var cs;
      if (el && document.body.classList.contains('ygt-step-spotlight-only')) {
        cs = window.getComputedStyle(el);
        if (cs && cs.borderRadius && cs.borderRadius !== '0px') {
          radius = cs.borderRadius;
        }
      }
      if (this.spotlight) {
        this.spotlight.style.borderRadius = radius;
      }
      if (this.spotlightExtra) {
        this.spotlightExtra.style.borderRadius = radius;
      }
    },

    positionSpotlight: function (el, pad) {
      var inset = typeof pad === 'number' ? pad : 8;
      var rect = el.getBoundingClientRect();
      this.syncSpotlightRadius(el);
      this.positionSpotlightRect(rect, inset);
    },

    positionSpotlightOnElements: function (elements, pad) {
      var inset = typeof pad === 'number' ? pad : 8;
      if (!elements || !elements.length) {
        return;
      }
      this.syncSpotlightRadius(elements[0]);
      this.positionSpotlightRect(unionRectFromElements(elements), inset);
    },

    hideExtraSpotlight: function () {
      if (this.spotlightExtra) {
        this.spotlightExtra.setAttribute('hidden', 'hidden');
      }
    },

    positionSpotlightRectOn: function (spotlightEl, rect, inset) {
      if (!spotlightEl || !rect) {
        return;
      }
      spotlightEl.style.top = Math.max(0, rect.top - inset) + 'px';
      spotlightEl.style.left = Math.max(0, rect.left - inset) + 'px';
      spotlightEl.style.width = rect.width + inset * 2 + 'px';
      spotlightEl.style.height = rect.height + inset * 2 + 'px';
    },

    positionSpotlightRect: function (rect, inset) {
      if (!this.spotlight) {
        return;
      }
      this.positionSpotlightRectOn(this.spotlight, rect, inset);
    },

    positionDualSpotlights: function (elements, pad) {
      var inset = typeof pad === 'number' ? pad : 8;
      if (!elements || !elements.length) {
        this.hideExtraSpotlight();
        return;
      }
      if (this.spotlight) {
        this.spotlight.removeAttribute('hidden');
        this.positionSpotlight(elements[0], inset);
      }
      if (elements.length > 1 && this.spotlightExtra) {
        this.spotlightExtra.removeAttribute('hidden');
        this.positionSpotlightRectOn(
          this.spotlightExtra,
          elements[1].getBoundingClientRect(),
          inset
        );
      } else {
        this.hideExtraSpotlight();
      }
    },

    positionAddSectionSpotlights: function (elements, pad) {
      var inset = typeof pad === 'number' ? pad : 4;
      if (!elements || !elements.length) {
        this.hideExtraSpotlight();
        return;
      }
      var firstRect = getAddSectionSpotlightRect(elements[0]);
      if (this.spotlight) {
        this.spotlight.removeAttribute('hidden');
        this.spotlight.classList.add('ygt-spotlight--snap');
        this.syncSpotlightRadius(elements[0]);
        if (firstRect) {
          this.positionSpotlightRectOn(this.spotlight, firstRect, inset);
        } else {
          this.positionSpotlight(elements[0], inset);
        }
      }
      if (elements.length > 1 && this.spotlightExtra) {
        var secondRect = getAddSectionSpotlightRect(elements[1]);
        this.spotlightExtra.removeAttribute('hidden');
        this.spotlightExtra.classList.add('ygt-spotlight--snap');
        this.syncSpotlightRadius(elements[1]);
        if (secondRect) {
          this.positionSpotlightRectOn(this.spotlightExtra, secondRect, inset);
        } else {
          this.positionSpotlightRectOn(
            this.spotlightExtra,
            elements[1].getBoundingClientRect(),
            inset
          );
        }
      } else {
        this.hideExtraSpotlight();
      }
    },

    positionPopoverForAddSectionTargets: function (elements) {
      var pop = this.popover;
      if (!pop || !elements || !elements.length) {
        this.positionPopoverCenter();
        return;
      }
      var rects = [];
      var i;
      for (i = 0; i < elements.length; i++) {
        var sr = getAddSectionSpotlightRect(elements[i]);
        if (sr) {
          rects.push(sr);
        }
      }
      var rect =
        rects.length >= 2
          ? unionRectFromPlainRects(rects)
          : rects.length === 1
            ? rects[0]
            : unionRectFromElements(elements);
      var margin = 16;
      var bottomSafe = 88;
      var left = rect.left + Math.max(0, (rect.width - pop.offsetWidth) / 2);
      var top = rect.top - pop.offsetHeight - margin;
      if (top < 12) {
        top = rect.bottom + margin;
      }
      left = Math.max(12, Math.min(left, window.innerWidth - pop.offsetWidth - 12));
      top = Math.max(12, Math.min(top, window.innerHeight - pop.offsetHeight - bottomSafe));
      pop.style.top = top + 'px';
      pop.style.left = left + 'px';
    },

    positionPopoverForHeaderBar: function (barEl, placement) {
      var pop = this.popover;
      if (!pop || !barEl) {
        this.positionPopoverCenter();
        return;
      }
      var rect = barEl.getBoundingClientRect();
      var margin = 14;
      var horizontal = resolveHorizontalPlacement(placement);
      var left = rect.left + Math.max(0, (rect.width - pop.offsetWidth) / 2);
      var top = rect.bottom + margin;
      if (placement === 'top') {
        top = rect.top - pop.offsetHeight - margin;
      } else if (horizontal === 'left') {
        left = rect.left - pop.offsetWidth - margin;
        top = rect.top;
      } else if (horizontal === 'right') {
        left = rect.right + margin;
        top = rect.top;
      }
      left = Math.max(12, Math.min(left, window.innerWidth - pop.offsetWidth - 12));
      top = Math.max(12, Math.min(top, window.innerHeight - pop.offsetHeight - 12));
      pop.style.top = top + 'px';
      pop.style.left = left + 'px';
    },

    positionPopoverForSidebar: function (sidebarEl, placement) {
      var pop = this.popover;
      if (!pop || !sidebarEl) {
        this.positionPopoverCenter();
        return;
      }
      var rect = sidebarEl.getBoundingClientRect();
      var margin = 18;
      var horizontal = resolveHorizontalPlacement(placement || 'end');
      var top = rect.top + 24;
      var left;

      if (placement === 'top') {
        left = rect.left + margin;
        top = rect.top - pop.offsetHeight - margin;
      } else if (placement === 'bottom') {
        left = rect.left + margin;
        top = rect.bottom + margin;
      } else if (horizontal === 'left') {
        left = rect.left - pop.offsetWidth - margin;
      } else {
        left = rect.right + margin;
      }

      left = Math.max(12, Math.min(left, window.innerWidth - pop.offsetWidth - 12));
      top = Math.max(12, Math.min(top, window.innerHeight - pop.offsetHeight - 12));
      pop.style.top = top + 'px';
      pop.style.left = left + 'px';
    },

    positionPopoverForNotifications: function (dropdownEl) {
      var pop = this.popover;
      if (!pop) {
        return;
      }
      pinNotificationsDropdown();
      var margin = 18;
      if (!dropdownEl) {
        this.positionPopoverCenter();
        return;
      }
      var rect = dropdownEl.getBoundingClientRect();
      var left = rect.left - pop.offsetWidth - margin;
      var top = rect.top + Math.max(0, (rect.height - pop.offsetHeight) / 2);
      if (left < 16) {
        left = Math.max(16, rect.left);
        top = rect.bottom + margin;
      }
      left = Math.max(12, Math.min(left, window.innerWidth - pop.offsetWidth - 12));
      top = Math.max(12, Math.min(top, window.innerHeight - pop.offsetHeight - 12));
      pop.style.top = top + 'px';
      pop.style.left = left + 'px';
    },

    positionPopoverForEditToggle: function (btnEl, placement) {
      var pop = this.popover;
      if (!pop || !btnEl) {
        this.positionPopoverCenter();
        return;
      }
      var rect = btnEl.getBoundingClientRect();
      var margin = 16;
      var bottomSafe = 72;
      var horizontal = resolveHorizontalPlacement(placement);
      var left = rect.left - pop.offsetWidth - margin;
      var top = rect.top + Math.max(0, (rect.height - pop.offsetHeight) / 2);

      if (horizontal === 'right') {
        left = rect.right + margin;
        top = rect.top;
      } else if (placement === 'bottom') {
        left = Math.max(12, rect.left - pop.offsetWidth * 0.5);
        top = rect.bottom + margin;
      }

      if (left < 12) {
        left = rect.right + margin;
      }
      if (left + pop.offsetWidth > window.innerWidth - 12) {
        left = Math.max(12, rect.left - pop.offsetWidth - margin);
        top = rect.bottom + margin;
      }

      left = Math.max(12, Math.min(left, window.innerWidth - pop.offsetWidth - 12));
      top = Math.max(12, Math.min(top, window.innerHeight - pop.offsetHeight - bottomSafe));
      pop.style.top = top + 'px';
      pop.style.left = left + 'px';
    },

    positionPopoverForDashboardCard: function (cardEl, preferredPlacement) {
      var pop = this.popover;
      if (!pop || !cardEl) {
        this.positionPopoverCenter();
        return;
      }
      var rect = cardEl.getBoundingClientRect();
      var margin = 16;
      var bottomSafe = 72;
      var order = ['bottom', 'end', 'left', 'top'];
      var i;
      var p;
      var top;
      var left;
      var popRect;

      if (preferredPlacement === 'top') {
        order = ['top', 'bottom', 'end', 'left'];
      } else if (preferredPlacement === 'left') {
        order = ['left', 'bottom', 'end', 'top'];
      } else if (preferredPlacement === 'end' || preferredPlacement === 'right') {
        order = ['end', 'bottom', 'left', 'top'];
      }

      for (i = 0; i < order.length; i++) {
        p = order[i];
        if (p === 'bottom') {
          top = rect.bottom + margin;
          left = rect.left;
        } else if (p === 'top') {
          top = rect.top - pop.offsetHeight - margin;
          left = rect.left;
        } else if (p === 'left') {
          top = rect.top;
          left = rect.left - pop.offsetWidth - margin;
        } else {
          top = rect.top;
          left = rect.right + margin;
        }
        left = Math.max(12, Math.min(left, window.innerWidth - pop.offsetWidth - 12));
        top = Math.max(12, Math.min(top, window.innerHeight - pop.offsetHeight - bottomSafe));
        popRect = {
          top: top,
          left: left,
          right: left + pop.offsetWidth,
          bottom: top + pop.offsetHeight
        };
        if (!rectsOverlap(popRect, rect)) {
          pop.style.top = top + 'px';
          pop.style.left = left + 'px';
          return;
        }
      }

      top = rect.bottom + margin;
      left = Math.max(12, Math.min(rect.left, window.innerWidth - pop.offsetWidth - 12));
      pop.style.top = top + 'px';
      pop.style.left = left + 'px';
    },

    positionPopoverNear: function (el, placement, step) {
      var rect = el.getBoundingClientRect();
      var pop = this.popover;
      var margin = 14;
      var bottomSafe = step && (step.layoutEdit || step.id === 'add-section') ? 88 : 72;
      var topSafe = 12;
      var top = rect.bottom + margin;
      var left = rect.left;
      var effectivePlacement = placement || 'bottom';

      if (effectivePlacement === 'top') {
        top = rect.top - pop.offsetHeight - margin;
        if (top < topSafe) {
          top = rect.bottom + margin;
          effectivePlacement = 'bottom';
        }
      } else if (effectivePlacement === 'bottom') {
        top = rect.bottom + margin;
        left = rect.left;
      } else {
        var horizontal = resolveHorizontalPlacement(effectivePlacement);
        top = rect.top;
        if (horizontal === 'left') {
          left = rect.left - pop.offsetWidth - margin;
        } else if (horizontal === 'right') {
          left = rect.right + margin;
        }
      }

      if (
        effectivePlacement !== 'top' &&
        top + pop.offsetHeight > window.innerHeight - bottomSafe
      ) {
        top = rect.top - pop.offsetHeight - margin;
      }
      if (top < topSafe) {
        top = Math.max(
          topSafe,
          Math.min(rect.top, window.innerHeight - pop.offsetHeight - bottomSafe)
        );
      }

      left = Math.max(12, Math.min(left, window.innerWidth - pop.offsetWidth - 12));
      top = Math.max(topSafe, Math.min(top, window.innerHeight - pop.offsetHeight - bottomSafe));

      pop.style.top = top + 'px';
      pop.style.left = left + 'px';
    },

    positionPopoverCenter: function () {
      var pop = this.popover;
      pop.style.top = Math.max(24, (window.innerHeight - pop.offsetHeight) / 2) + 'px';
      pop.style.left = Math.max(16, (window.innerWidth - pop.offsetWidth) / 2) + 'px';
    },

    next: function () {
      var stepList = this.getStepList();
      if (isLayoutEditDemoAwaitingStart(stepList[this.index])) {
        return;
      }
      if (this.phase === 'core' && isDashboardEndChoice(stepList, this.index)) {
        return;
      }
      var nextIdx = this.index + 1;
      if (nextIdx >= stepList.length) {
        this.finish();
        return;
      }
      if (this.phase === 'extension') {
        saveExtSession({ id: this.activeExtensionId, step: nextIdx });
      }
      this.showStep(nextIdx);
    },

    finishDashboardOnly: function () {
      if (this.phase !== 'core' || !isDashboardEndChoice(this.getStepList(), this.index)) {
        this.finish();
        return;
      }
      this.teardown();
      clearStepStorage();
      clearExtSession();
      clearSettingsPendingFlag();
      Complete.show();
      ajax('finish_all').done(function (res) {
        mergeStateFromResponse(res);
      });
    },

    continueFromDashboard: function () {
      if (this.phase !== 'core' || !isDashboardEndChoice(this.getStepList(), this.index)) {
        return;
      }
      this.teardown();
      clearStepStorage();
      ajax('dashboard_done').done(function (res) {
        mergeStateFromResponse(res);
        cfg.dashboardDone = true;
        TourPicker.show();
      });
    },

    back: function () {
      if (this.index > 0) {
        this.showStep(this.index - 1);
      }
    }
  };

  function bindIntro() {
    var $intro = $('#yooadmin-guided-tour-intro');
    if (!$intro.length) {
      return;
    }

    $intro.on('click', '[data-ygt-start-tour]', function (e) {
      e.preventDefault();
      var $btn = $(this);
      if ($btn.prop('disabled') || $btn.attr('aria-busy') === 'true') {
        return;
      }

      var originalLabel = $btn.data('ygt-label');
      if (!originalLabel) {
        originalLabel = $btn.text();
        $btn.data('ygt-label', originalLabel);
      }

      var startingLabel = i18n.startingTour || 'Starting tour…';
      var $dismiss = $intro.find('[data-ygt-intro-dismiss]');

      function restoreStartBtn() {
        $btn
          .prop('disabled', false)
          .removeAttr('aria-busy')
          .removeClass('is-loading')
          .empty()
          .text(originalLabel);
        $dismiss.prop('disabled', false);
      }

      $btn
        .prop('disabled', true)
        .attr('aria-busy', 'true')
        .addClass('is-loading')
        .empty()
        .append(
          $('<span class="ygt-btn-spinner" aria-hidden="true"></span>'),
          $('<span class="ygt-btn-label"></span>').text(startingLabel)
        );
      $dismiss.prop('disabled', true);

      ajax('start')
        .done(function (res) {
          if (!res || !res.success) {
            restoreStartBtn();
            return;
          }
          Intro.hide();
          Tour.start(0);
        })
        .fail(function () {
          restoreStartBtn();
        });
    });

    $intro.on('click', '[data-ygt-intro-dismiss]', function (e) {
      e.preventDefault();
      ajax('intro_dismiss').always(function () {
        Intro.hide();
      });
    });
  }

  function bindComplete() {
    $(document).on('click', '[data-ygt-replay-tour]', function (e) {
      e.preventDefault();
      Complete.hide();
      ajax('reset')
        .done(function () {
          clearStepStorage();
          clearExtSession();
          clearSettingsPendingFlag();
          cfg.dashboardDone = false;
          cfg.settingsTour = '';
          cfg.segments = {};
          Tour.phase = 'core';
          Tour.stepList = coreSteps;
          return ajax('start');
        })
        .done(function () {
          if (currentPage() !== 'dashboard' && cfg.dashboardUrl) {
            saveStepIndex(0);
            window.location.assign(cfg.dashboardUrl);
            return;
          }
          Tour.start(0);
        });
    });

    $(document).on('click', '[data-ygt-finish-tour]', function (e) {
      e.preventDefault();
      Complete.hide();
      if (currentPage() !== 'dashboard' && cfg.dashboardUrl) {
        window.location.assign(cfg.dashboardUrl);
      }
    });
  }

  function bindPicker() {
    $(document).on('click', '[data-ygt-picker-start]', function (e) {
      e.preventDefault();
      var segmentId = $(this).attr('data-segment-id') || '';
      if (segmentId) {
        TourPicker.startSegment(segmentId);
      }
    });
    $(document).on('click', '[data-ygt-picker-later]', function (e) {
      e.preventDefault();
      var segmentId = $(this).attr('data-segment-id') || '';
      if (segmentId) {
        TourPicker.deferSegment(segmentId);
      }
    });
    $(document).on('click', '[data-ygt-picker-finish]', function (e) {
      e.preventDefault();
      TourPicker.finishAll();
    });
    $(document).on('click', '[data-ygt-picker-item]', function (e) {
      if ($(e.target).closest('[data-ygt-picker-start], [data-ygt-picker-later]').length) {
        return;
      }
      var $item = $(this);
      $item
        .addClass('is-selected')
        .siblings('.ygt-tour-picker-item')
        .removeClass('is-selected');
    });
  }

  function maybeResumeTour() {
    syncTourFlagsFromCfg();
    if (!cfg.inProgress) {
      return;
    }
    var delay = cfg.showIntro ? 900 : 500;
    var ext = readExtSession();
    if (ext && ext.id) {
      if (extensionTourById(ext.id)) {
        window.setTimeout(function () {
          Tour.phase = 'extension';
          Tour.activeExtensionId = ext.id;
          Tour.stepList = extensionTourById(ext.id).steps;
          Tour.start(typeof ext.step === 'number' ? ext.step : 0);
        }, delay);
        return;
      }
      clearExtSession();
    }

    var page = currentPage();
    var pending = getPendingSegmentItems();
    var i;
    var seg;

    if (cfg.dashboardDone) {
      for (i = 0; i < pending.length; i++) {
        seg = pending[i];
        if (!segmentMatchesPage(seg, page)) {
          continue;
        }
        if (seg.id === 'settings') {
          if (!isSettingsPageContext()) {
            continue;
          }
          var settingsStart = firstSettingsStepIndex(coreSteps);
          var idx = stepIndexFromStorage();
          if (idx < settingsStart) {
            idx = settingsStart;
          }
          window.setTimeout(function () {
            Tour.phase = 'core';
            Tour.activeExtensionId = null;
            Tour.stepList = coreSteps;
            Tour.start(idx);
          }, delay);
          return;
        }
        if (extensionTourById(seg.id)) {
          window.setTimeout(function () {
            ExtensionTour.beginTour(seg.id);
          }, delay);
          return;
        }
      }
      return;
    }

    // Dashboard-phase steps only exist on the YOOAdmin dashboard. If the tour is
    // still in progress while the user is on any other admin screen (e.g. the
    // WooCommerce product editor), don't render a misplaced step with no target —
    // it resumes correctly when they return to the dashboard.
    if (currentPage() !== 'dashboard') {
      return;
    }

    var dashboardIdx = stepIndexFromStorage();
    var dashSettingsStart = firstSettingsStepIndex(coreSteps);
    if (dashboardIdx >= dashSettingsStart) {
      dashboardIdx = Math.max(0, dashSettingsStart - 1);
    }

    window.setTimeout(function () {
      Tour.phase = 'core';
      Tour.activeExtensionId = null;
      Tour.stepList = coreSteps;
      Tour.start(dashboardIdx);
    }, delay);
  }

  $(function () {
    syncTourFlagsFromCfg();
    bindIntro();
    bindComplete();
    bindPicker();

    if (cfg.showIntro) {
      window.setTimeout(function () {
        Intro.show();
      }, 600);
      return;
    }

    maybeResumeTour();

    $(document).on('yooadmin:plus-tour-welcome:started', function (_e, res) {
      mergeStateFromResponse(res);
      TourPicker.show();
    });
  });
})(jQuery);
