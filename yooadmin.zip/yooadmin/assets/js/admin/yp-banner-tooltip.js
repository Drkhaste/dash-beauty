/**
 * YOOAdmin - Banner tooltip script
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';
    
    // Only run if YOOAdmin is active
    if (!window.yooadmRuntime) {
        return;
    }
    
    let currentTooltip = null;
    let hideTimeout = null;
    let showTimeout = null;
    let lastMouseX = 0;
    let lastMouseY = 0;
    
    /**
     * Create tooltip HTML
     */
    function createTooltip() {
        const i18n = (window.yooadmBannerTooltip || {});
        const tip = i18n.tip || 'Tip: Convert all banners to notifications!';
        const enableInSettings = i18n.enableInSettings || 'Enable in Settings';
        const tooltip = $('<div class="yp-banner-tooltip">' +
            '<span class="yp-banner-tooltip-icon">💡</span> ' +
            '<strong>' + tip + '</strong> ' +
            '<a href="' + (window.yooadmRuntime && window.yooadmRuntime.settingsUrl) + '" class="yp-banner-tooltip-link">' +
                enableInSettings +
                '<span class="dashicons dashicons-arrow-right-alt"></span>' +
            '</a>' +
        '</div>');
        
        $('body').append(tooltip);
        return tooltip;
    }
    
    /**
     * Position tooltip near mouse cursor
     */
    function positionTooltip($tooltip, mouseX, mouseY) {
        const tooltipHeight = $tooltip.outerHeight();
        const tooltipWidth = $tooltip.outerWidth();
        const windowWidth = $(window).width();
        const windowHeight = $(window).height();
        const scrollTop = $(window).scrollTop();
        const scrollLeft = $(window).scrollLeft();
        
        let top, left;
        
        // Position to the right of cursor
        left = mouseX + 15;
        top = mouseY - (tooltipHeight / 2);
        
        // If tooltip goes off-screen to the right, show it on the left
        if (left + tooltipWidth > windowWidth + scrollLeft - 20) {
            left = mouseX - tooltipWidth - 15;
            $tooltip.addClass('arrow-right').removeClass('arrow-left');
        } else {
            $tooltip.addClass('arrow-left').removeClass('arrow-right');
        }
        
        // If tooltip goes off-screen to the left
        if (left < scrollLeft + 20) {
            left = scrollLeft + 20;
        }
        
        // Make sure tooltip doesn't go too high or too low
        const minTop = scrollTop + 20;
        const maxTop = scrollTop + windowHeight - tooltipHeight - 20;
        
        if (top < minTop) {
            top = minTop;
        } else if (top > maxTop) {
            top = maxTop;
        }
        
        $tooltip.css({
            top: top + 'px',
            left: left + 'px'
        });
    }
    
    /**
     * Show tooltip
     */
    function showTooltip(mouseX, mouseY) {
        // Clear any existing timeouts
        clearTimeout(hideTimeout);
        clearTimeout(showTimeout);
        
        // Store mouse position
        lastMouseX = mouseX;
        lastMouseY = mouseY;
        
        // Show tooltip after a short delay (300ms)
        showTimeout = setTimeout(function() {
            // Create tooltip if it doesn't exist
            if (!currentTooltip) {
                currentTooltip = createTooltip();
                
                // Keep tooltip visible when hovering over it
                currentTooltip.on('mouseenter', function() {
                    clearTimeout(hideTimeout);
                });
                
                currentTooltip.on('mouseleave', function() {
                    hideTooltip();
                });
            }
            
            // Position and show tooltip near mouse
            positionTooltip(currentTooltip, lastMouseX, lastMouseY);
            
            // Use setTimeout to ensure CSS transition works
            setTimeout(function() {
                currentTooltip.addClass('show');
            }, 10);
        }, 300);
    }
    
    /**
     * Hide tooltip with delay
     */
    function hideTooltip() {
        clearTimeout(hideTimeout);
        clearTimeout(showTimeout);
        
        // Hide after 500ms delay to allow user to move mouse to tooltip
        hideTimeout = setTimeout(function() {
            if (currentTooltip) {
                currentTooltip.removeClass('show');
            }
        }, 500);
    }

    /**
     * Keep plugin update rows focused on the actual update information.
     */
    function isPluginsUpdateNotice($banner) {
        if (!$banner || !$banner.length || !document.body || !document.body.classList.contains('plugins-php')) {
            return false;
        }

        return (
            $banner.hasClass('update-message') ||
            $banner.closest('.update-message').length > 0 ||
            $banner.closest('.plugin-update-tr').length > 0
        );
    }
    
    /**
     * Initialize tooltips on all notices
     */
    function initTooltips() {
        // Target all WordPress admin notices + third-party banners
        const noticeSelectors = '.notice, .update-nag, .error, .updated, .is-dismissible, [class*="-admin-notice"], .wpb-notice, .vc_license-activation-notice';
        
        $(document).on('mouseenter', noticeSelectors, function(e) {
            const $banner = $(this);

            if (isPluginsUpdateNotice($banner)) {
                hideTooltip();
                return;
            }
            
            // Skip if this is inside YOOAdmin's own pages
            if ($banner.closest('.yooadmin-page').length) {
                return;
            }
            
            // Skip YOOAdmin's own notices
            if ($banner.hasClass('yooadmin-brand-notice') || $banner.hasClass('yooadmin-wizard-notice')) {
                return;
            }
            
            // Skip update/plugin count badges
            if ($banner.find('.update-plugins, .plugin-count, .update-count, .awaiting-mod').length) {
                return;
            }
            
            showTooltip(e.pageX, e.pageY);
        });
        
        $(document).on('mousemove', noticeSelectors, function(e) {
            if (isPluginsUpdateNotice($(this))) {
                return;
            }

            // Update mouse position while hovering
            lastMouseX = e.pageX;
            lastMouseY = e.pageY;
            
            // Update tooltip position if it's visible
            if (currentTooltip && currentTooltip.hasClass('show')) {
                positionTooltip(currentTooltip, e.pageX, e.pageY);
            }
        });
        
        $(document).on('mouseleave', noticeSelectors, function() {
            hideTooltip();
        });
    }
    
    // Initialize when document is ready
    $(document).ready(function() {
        initTooltips();
    });
    
})(jQuery);

