/**
 * YOOAdmin - Dashboard API (sections, cards, layout)
 *
 * @package YOOAdmin
 */

(function() {
  'use strict';
  
  // Guard against multiple initialization
  if (window.yooadmDashboard) {
    return;
  }
  
  /* ============================== Constants ============================== */
  const STORAGE_KEY = 'yooadmin_dashboard_layout';
  const LAYOUT_VERSION = '1.0';
  
  /* ============================== Utilities ============================== */
  
  /**
   * Get element by selector
   * @param {string} selector - CSS selector
   * @return {Element|null}
   */
  function $(selector) {
    return document.querySelector(selector);
  }
  
  /**
   * Get all elements by selector
   * @param {string} selector - CSS selector
   * @return {NodeList}
   */
  function $$(selector) {
    return document.querySelectorAll(selector);
  }
  
  /**
   * Trigger custom event
   * @param {string} eventName - Event name
   * @param {Object} detail - Event data
   */
  function triggerEvent(eventName, detail) {
    var event = new CustomEvent(eventName, {
      detail: detail,
      bubbles: true,
      cancelable: true
    });
    document.dispatchEvent(event);
  }
  
  /* ============================== Section Management ============================== */
  
  var sections = {
    /**
     * Get section element by ID
     * @param {string} sectionId - Section ID
     * @return {Element|null}
     */
    get: function(sectionId) {
      return $('[data-section-id="' + sectionId + '"]');
    },
    
    /**
     * Get all sections
     * @return {NodeList}
     */
    getAll: function() {
      return $$('[data-section-id]');
    },
    
    /**
     * Collapse section
     * @param {string} sectionId - Section ID
     */
    collapse: function(sectionId) {
      var section = this.get(sectionId);
      if (section) {
        section.classList.add('is-collapsed');
        section.dataset.collapsed = 'true';
        triggerEvent('yoodashboard:section:collapsed', { sectionId: sectionId });
        layout.save();
      }
    },
    
    /**
     * Expand section
     * @param {string} sectionId - Section ID
     */
    expand: function(sectionId) {
      var section = this.get(sectionId);
      if (section) {
        section.classList.remove('is-collapsed');
        section.dataset.collapsed = 'false';
        triggerEvent('yoodashboard:section:expanded', { sectionId: sectionId });
        layout.save();
      }
    },
    
    /**
     * Toggle section
     * @param {string} sectionId - Section ID
     */
    toggle: function(sectionId) {
      var section = this.get(sectionId);
      if (section) {
        if (section.classList.contains('is-collapsed')) {
          this.expand(sectionId);
        } else {
          this.collapse(sectionId);
        }
      }
    },
    
    /**
     * Check if section is collapsed
     * @param {string} sectionId - Section ID
     * @return {boolean}
     */
    isCollapsed: function(sectionId) {
      var section = this.get(sectionId);
      return section ? section.classList.contains('is-collapsed') : false;
    }
  };
  
  /* ============================== Card Management ============================== */
  
  var cards = {
    /**
     * Get card element by ID
     * @param {string} cardId - Card ID
     * @return {Element|null}
     */
    get: function(cardId) {
      return $('[data-card-id="' + cardId + '"]');
    },
    
    /**
     * Get all cards
     * @return {NodeList}
     */
    getAll: function() {
      return $$('[data-card-id]');
    },
    
    /**
     * Get cards in section
     * @param {string} sectionId - Section ID
     * @return {NodeList}
     */
    getInSection: function(sectionId) {
      var section = sections.get(sectionId);
      return section ? section.querySelectorAll('[data-card-id]') : [];
    },
    
    /**
     * Move card to another section
     * @param {string} cardId - Card ID
     * @param {string} toSectionId - Target section ID
     * @param {number} position - Position in target section (optional)
     */
    move: function(cardId, toSectionId, position) {
      var card = this.get(cardId);
      var toSection = sections.get(toSectionId);
      var grid = toSection ? toSection.querySelector('.yp-cards-grid') : null;
      
      if (card && grid) {
        var cards = Array.from(grid.children);
        if (typeof position !== 'undefined' && position < cards.length) {
          grid.insertBefore(card, cards[position]);
        } else {
          grid.appendChild(card);
        }
        triggerEvent('yoodashboard:card:moved', {
          cardId: cardId,
          toSectionId: toSectionId,
          position: position
        });
        layout.save();
      }
    },
    
    /**
     * Resize card
     * @param {string} cardId - Card ID
     * @param {string} size - Size: 'small', 'normal', 'large'
     */
    resize: function(cardId, size) {
      var card = this.get(cardId);
      if (card) {
        card.dataset.size = size;
        triggerEvent('yoodashboard:card:resized', {
          cardId: cardId,
          size: size
        });
        layout.save();
      }
    },
    
    /**
     * Hide card
     * @param {string} cardId - Card ID
     */
    hide: function(cardId) {
      var card = this.get(cardId);
      if (card) {
        card.dataset.hidden = 'true';
        triggerEvent('yoodashboard:card:hidden', { cardId: cardId });
        layout.save();
      }
    },
    
    /**
     * Show card
     * @param {string} cardId - Card ID
     */
    show: function(cardId) {
      var card = this.get(cardId);
      if (card) {
        card.dataset.hidden = 'false';
        triggerEvent('yoodashboard:card:shown', { cardId: cardId });
        layout.save();
      }
    },
    
    /**
     * Check if card is hidden
     * @param {string} cardId - Card ID
     * @return {boolean}
     */
    isHidden: function(cardId) {
      var card = this.get(cardId);
      return card ? card.dataset.hidden === 'true' : false;
    }
  };
  
  /* ============================== Layout Management ============================== */
  
  var layout = {
    /**
     * Serialize current layout to JSON
     * @return {Object} Layout data
     */
    serialize: function() {
      var layoutData = {
        version: LAYOUT_VERSION,
        timestamp: Date.now(),
        sections: []
      };
      
      sections.getAll().forEach(function(section) {
        var sectionData = {
          id: section.dataset.sectionId,
          collapsed: section.dataset.collapsed === 'true',
          order: section.dataset.order || '0',
          cards: []
        };
        
        var sectionCards = section.querySelectorAll('[data-card-id]');
        sectionCards.forEach(function(card, index) {
          sectionData.cards.push({
            id: card.dataset.cardId,
            size: card.dataset.size || 'normal',
            hidden: card.dataset.hidden === 'true',
            order: index
          });
        });
        
        layoutData.sections.push(sectionData);
      });
      
      return layoutData;
    },
    
    /**
     * Apply layout from JSON
     * @param {Object} layoutData - Layout data
     */
    apply: function(layoutData) {
      if (!layoutData || !layoutData.sections) {
        return;
      }
      
      layoutData.sections.forEach(function(sectionData) {
        var section = sections.get(sectionData.id);
        if (!section) return;
        
        // Apply section state
        if (sectionData.collapsed) {
          sections.collapse(sectionData.id);
        } else {
          sections.expand(sectionData.id);
        }
        
        // Apply card states
        sectionData.cards.forEach(function(cardData) {
          var card = cards.get(cardData.id);
          if (!card) return;
          
          // Resize
          if (cardData.size) {
            cards.resize(cardData.id, cardData.size);
          }
          
          // Hide/show
          if (cardData.hidden) {
            cards.hide(cardData.id);
          } else {
            cards.show(cardData.id);
          }
        });
      });
      
      triggerEvent('yoodashboard:layout:applied', { layout: layoutData });
    },
    
    /**
     * Save layout to LocalStorage
     */
    save: function() {
      var layoutData = this.serialize();
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(layoutData));
        triggerEvent('yoodashboard:layout:saved', { layout: layoutData });
      } catch (e) {
      }
    },
    
    /**
     * Load layout from LocalStorage
     */
    load: function() {
      try {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          var layoutData = JSON.parse(saved);
          this.apply(layoutData);
          triggerEvent('yoodashboard:layout:loaded', { layout: layoutData });
          return true;
        }
      } catch (e) {
      }
      return false;
    },
    
    /**
     * Reset layout to default
     */
    reset: function() {
      try {
        localStorage.removeItem(STORAGE_KEY);
        triggerEvent('yoodashboard:layout:reset');
        // Reload page to apply default layout
        if (confirm('Reset dashboard layout? Page will reload.')) {
          location.reload();
        }
      } catch (e) {
      }
    },
    
    /**
     * Export layout as JSON file
     */
    export: function() {
      var layoutData = this.serialize();
      var json = JSON.stringify(layoutData, null, 2);
      var blob = new Blob([json], { type: 'application/json' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'yooadmin-dashboard-layout-' + Date.now() + '.json';
      a.click();
      URL.revokeObjectURL(url);
      triggerEvent('yoodashboard:layout:exported', { layout: layoutData });
    },
    
    /**
     * Import layout from JSON file
     * @param {File} file - JSON file
     */
    import: function(file) {
      var reader = new FileReader();
      reader.onload = function(e) {
        try {
          var layoutData = JSON.parse(e.target.result);
          layout.apply(layoutData);
          layout.save();
          triggerEvent('yoodashboard:layout:imported', { layout: layoutData });
          alert('Layout imported successfully!');
        } catch (err) {
          alert('Failed to import layout: Invalid JSON');
        }
      };
      reader.readAsText(file);
    }
  };
  
  /* ============================== Drag & Drop ============================== */
  
  var dragDrop = {
    enabled: false,
    
    /**
     * Enable drag & drop
     */
    enable: function() {
      if (this.enabled) return;
      this.enabled = true;
      
      var allCards = cards.getAll();
      allCards.forEach(function(card) {
        card.setAttribute('draggable', 'true');
        card.addEventListener('dragstart', dragDrop._onDragStart);
        card.addEventListener('dragend', dragDrop._onDragEnd);
      });
      
      var allGrids = $$('.yp-cards-grid');
      allGrids.forEach(function(grid) {
        grid.addEventListener('dragover', dragDrop._onDragOver);
        grid.addEventListener('drop', dragDrop._onDrop);
        grid.addEventListener('dragleave', dragDrop._onDragLeave);
      });
      
      triggerEvent('yoodashboard:dragdrop:enabled');
    },
    
    /**
     * Disable drag & drop
     */
    disable: function() {
      if (!this.enabled) return;
      this.enabled = false;
      
      var allCards = cards.getAll();
      allCards.forEach(function(card) {
        card.removeAttribute('draggable');
        card.removeEventListener('dragstart', dragDrop._onDragStart);
        card.removeEventListener('dragend', dragDrop._onDragEnd);
      });
      
      var allGrids = $$('.yp-cards-grid');
      allGrids.forEach(function(grid) {
        grid.removeEventListener('dragover', dragDrop._onDragOver);
        grid.removeEventListener('drop', dragDrop._onDrop);
        grid.removeEventListener('dragleave', dragDrop._onDragLeave);
      });
      
      triggerEvent('yoodashboard:dragdrop:disabled');
    },
    
    _onDragStart: function(e) {
      this.classList.add('is-dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/html', this.innerHTML);
      e.dataTransfer.setData('cardId', this.dataset.cardId);
    },
    
    _onDragEnd: function(e) {
      this.classList.remove('is-dragging');
      $$('.yp-cards-grid.is-drag-over').forEach(function(el) {
        el.classList.remove('is-drag-over');
      });
    },
    
    _onDragOver: function(e) {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      this.classList.add('is-drag-over');
    },
    
    _onDrop: function(e) {
      e.preventDefault();
      this.classList.remove('is-drag-over');
      
      var cardId = e.dataTransfer.getData('cardId');
      var draggedCard = $('[data-card-id="' + cardId + '"]');
      var targetSection = this.closest('[data-section-id]');
      
      if (draggedCard && targetSection) {
        this.appendChild(draggedCard);
        layout.save();
        triggerEvent('yoodashboard:card:dropped', {
          cardId: cardId,
          sectionId: targetSection.dataset.sectionId
        });
      }
    },
    
    _onDragLeave: function(e) {
      if (e.target === this) {
        this.classList.remove('is-drag-over');
      }
    }
  };
  
  /* ============================== Public API ============================== */
  
  window.yooadmDashboard = {
    version: '1.0.0',
    sections: sections,
    cards: cards,
    layout: layout,
    dragDrop: dragDrop,
    
    /**
     * Initialize dashboard API
     */
    init: function() {
      // Load saved layout on page load
      layout.load();
      
      // Setup section toggle buttons if they exist
      $$('.yp-section-toggle').forEach(function(btn) {
        btn.addEventListener('click', function() {
          var sectionId = this.dataset.sectionToggle || this.closest('[data-section-id]').dataset.sectionId;
          if (sectionId) {
            sections.toggle(sectionId);
          }
        });
      });
      
      triggerEvent('yoodashboard:initialized');
    }
  };
  
  // Auto-initialize on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', window.yooadmDashboard.init);
  } else {
    window.yooadmDashboard.init();
  }
  
})();











