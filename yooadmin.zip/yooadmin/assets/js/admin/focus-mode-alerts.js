/**
 * YOOAdmin - Focus mode alert modals
 *
 * @package YOOAdmin
 */

(function() {
    'use strict';

    window.yooadmAlerts = {
        canManageFocusPolicy: function(t, focusCfg) {
            if (focusCfg.canManagePolicy === true || t.canManagePolicy === true) {
                return true;
            }
            if (focusCfg.canManagePolicy || t.canManagePolicy) {
                return true;
            }
            var input = document.getElementById('yp-toggle-clean-view');
            return !!(input && input.getAttribute('data-can-manage-policy') === '1');
        },

        /**
         * Show policy alert with current policy state
         */
        showPolicyAlert: function(currentPolicy, attemptingToEnable) {
            var t = (typeof yooadmFocusAlerts !== 'undefined') ? yooadmFocusAlerts : {};
            var focusCfg = (typeof yooadmFocus !== 'undefined') ? yooadmFocus : {};
            var canManage = this.canManageFocusPolicy(t, focusCfg);
            var adminUrl = window.location.origin + window.location.pathname.replace(/\/[^\/]*$/, '/admin.php');
            var settingsUrl = adminUrl + '?page=yooadmin-settings#tab-focus';
            
            var message;
            var title;
            if (currentPolicy === 'on') {
                title = canManage
                    ? (t.focusModePolicy || 'Focus Mode Policy')
                    : (t.focusModePolicyUser || 'Focus Mode Is Locked');
                message = canManage
                    ? (t.policyOnMessage || 'Focus Mode policy is currently set to <strong>"Force On"</strong>. To allow users to control Focus Mode, change the policy to <strong>"Auto"</strong> in settings.')
                    : (t.policyOnMessageUser || 'Your site administrator requires Focus Mode for all users. You cannot turn it off while this policy is active. Please contact your administrator if you need the classic WordPress admin.');
            } else {
                title = canManage
                    ? (t.focusModePolicy || 'Focus Mode Policy')
                    : (t.focusModePolicyUser || 'Focus Mode Is Locked');
                message = canManage
                    ? (t.policyOffMessage || 'Focus Mode policy is currently set to <strong>"Force Off"</strong>. To enable Focus Mode, change the policy to <strong>"Auto"</strong> in settings.')
                    : (t.policyOffMessageUser || 'Focus Mode is turned off for all users by your site administrator. You cannot enable it yourself. Please contact your administrator if you need access.');
            }
            
            var settingsBtn = canManage
                ? '<a href="' + settingsUrl + '" class="yp-alert-btn yp-alert-btn-primary">' + (t.focusModeSettings || 'Focus Mode Settings') + '</a>'
                : '';
            
            var html = '<div class="yp-alert-modal yp-alert-modal--focus" id="yp-policy-alert">' +
                '<div class="yp-alert-overlay"></div>' +
                '<div class="yp-alert-content">' +
                    '<div class="yp-alert-header">' +
                        '<span class="yp-alert-icon warning dashicons dashicons-info"></span>' +
                        '<h2 class="yp-alert-title">' + title + '</h2>' +
                    '</div>' +
                    '<div class="yp-alert-body">' +
                        '<p class="yp-alert-message">' + message + '</p>' +
                    '</div>' +
                    '<div class="yp-alert-footer">' +
                        '<button type="button" class="yp-alert-btn yp-alert-btn-secondary yp-alert-close">' + (t.close || 'Close') + '</button>' +
                        settingsBtn +
                    '</div>' +
                '</div>' +
            '</div>';
            
            document.body.insertAdjacentHTML('beforeend', html);
            document.body.classList.add('yp-alert-open');
            
            this.bindCloseEvents('yp-policy-alert');
        },

        /**
         * Show policy disabled alert (cannot enable for user only)
         */
        showPolicyDisabledAlert: function(onEnableAuto) {
            var t = (typeof yooadmFocusAlerts !== 'undefined') ? yooadmFocusAlerts : {};
            var focusCfg = (typeof yooadmFocus !== 'undefined') ? yooadmFocus : {};
            var canManage = this.canManageFocusPolicy(t, focusCfg);
            var disabledMessage = canManage
                ? (t.focusDisabledMessage || 'Focus Mode is disabled by the administrator. To enable it for yourself only, the policy must be set to "Auto" to allow users to choose their preference.')
                : (t.focusDisabledMessageUser || 'Focus Mode is turned off for all users by your site administrator. You cannot enable it yourself. Please contact your administrator if you need access.');
            var enableAutoBtn = canManage
                ? '<button type="button" class="yp-alert-btn yp-alert-btn-primary yp-enable-auto">' + (t.enableAutoMode || 'Enable Auto Mode') + '</button>'
                : '';
            var html = '<div class="yp-alert-modal yp-alert-modal--focus" id="yp-policy-disabled-alert">' +
                '<div class="yp-alert-overlay"></div>' +
                '<div class="yp-alert-content">' +
                    '<div class="yp-alert-header">' +
                        '<span class="yp-alert-icon error dashicons dashicons-dismiss"></span>' +
                        '<h2 class="yp-alert-title">' + (t.focusModeDisabled || 'Focus Mode Disabled') + '</h2>' +
                    '</div>' +
                    '<div class="yp-alert-body">' +
                        '<p class="yp-alert-message">' + disabledMessage + '</p>' +
                    '</div>' +
                    '<div class="yp-alert-footer">' +
                        '<button type="button" class="yp-alert-btn yp-alert-btn-secondary yp-alert-close">' + (t.cancel || 'Cancel') + '</button>' +
                        enableAutoBtn +
                    '</div>' +
                '</div>' +
            '</div>';
            
            document.body.insertAdjacentHTML('beforeend', html);
            document.body.classList.add('yp-alert-open');
            
            var modal = document.getElementById('yp-policy-disabled-alert');
            var enableBtn = modal.querySelector('.yp-enable-auto');
            
            if (enableBtn && onEnableAuto) {
                enableBtn.addEventListener('click', function() {
                    onEnableAuto();
                });
            }
            
            this.bindCloseEvents('yp-policy-disabled-alert');
        },

        /**
         * Bind close events to modal
         */
        bindCloseEvents: function(modalId) {
            var modal = document.getElementById(modalId);
            if (!modal) return;
            
            var closeBtn = modal.querySelector('.yp-alert-close');
            var overlay = modal.querySelector('.yp-alert-overlay');
            
            var closeModal = function() {
                modal.style.display = 'none';
                document.body.classList.remove('yp-alert-open');
                setTimeout(function() {
                    if (modal.parentNode) {
                        modal.parentNode.removeChild(modal);
                    }
                }, 300);
            };
            
            if (closeBtn) {
                closeBtn.addEventListener('click', closeModal);
            }
            
            if (overlay) {
                overlay.addEventListener('click', closeModal);
            }
        },
        
        // Legacy compatibility
        showPolicyEnforcedAlert: function() {
            this.showPolicyAlert('on', false);
        }
    };

})();
