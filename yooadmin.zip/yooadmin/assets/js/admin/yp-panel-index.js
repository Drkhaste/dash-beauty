(function () {
  'use strict';
  var root = document.querySelector('#yoopanel');

  function mountCards() {
    if (!root) return;
    var cards = root.querySelectorAll('.yp-card');
    if (!cards.length) return;
    
    // Use requestAnimationFrame for better performance
    var index = 0;
    function mountNext() {
      if (index < cards.length) {
        cards[index].classList.add('is-mounted');
        index++;
        requestAnimationFrame(mountNext);
      }
    }
    requestAnimationFrame(mountNext);
  }

  // Clear cache visual feedback
  var cc = document.getElementById('yp-clear-cache');
  if (cc) {
    cc.addEventListener('click', function () {
      cc.classList.add('is-busy');
      setTimeout(function(){ cc.classList.remove('is-busy'); }, 1500);
    });
  }

  // Slider
  var slider = root ? root.querySelector('[data-slider]') : null;
  if (slider) {
    var track = slider.querySelector('.yp-slider__track');
    var slides = Array.from(slider.querySelectorAll('.yp-slide'));
    var idx = 0;
    function go(i){ idx = (i + slides.length) % slides.length; track.style.transform = 'translateX(' + (-idx * 100) + '%)'; }
    var prev = slider.querySelector('.yp-slider__nav.-prev');
    var next = slider.querySelector('.yp-slider__nav.-next');
    if (prev) prev.addEventListener('click', function(){ go(idx-1); });
    if (next) next.addEventListener('click', function(){ go(idx+1); });
    setInterval(function(){ go(idx+1); }, 5000);
  }

  // Tiny sparkline charts (demo data)
  function drawSpark(canvas) {
    if (!canvas) return;
    var ctx = canvas.getContext('2d'), w = canvas.width, h = canvas.height;
    var pts = []; for (var i=0;i<20;i++) pts.push(50 + (Math.random()-0.5)*35);
    var min = Math.min.apply(null, pts), max = Math.max.apply(null, pts);
    var step = w/(pts.length-1);
    ctx.clearRect(0,0,w,h);
    ctx.beginPath();
    pts.forEach(function(v,x){
      var y = h - ((v-min)/(max-min||1))*h;
      if (x===0) ctx.moveTo(0,y); else ctx.lineTo(x*step,y);
    });
    ctx.strokeStyle = '#555';
    ctx.lineWidth = 2;
    ctx.stroke();
  }
  if (root) {
    root.querySelectorAll('.yp-spark').forEach(function(c){ drawSpark(c); });
  }

  // Drag & Drop (respect locked + drop hint)
  var grid = document.querySelector('[data-draggable-grid]');
  if (grid) {
    var key = 'yoopanel_order_v3';
    localStorage.removeItem('yoopanel_order_v2'); // cleanup old key

    function getOrder(){
      return Array.from(grid.children).map(function(s){
        return s.getAttribute('data-card');
      });
    }
    function save(){ localStorage.setItem(key, JSON.stringify(getOrder())); }
    function load(){
      try{
        var stored = JSON.parse(localStorage.getItem(key) || '[]');
        if (!stored.length) return;
        var map = {};
        Array.from(grid.children).forEach(function(s){
          map[s.getAttribute('data-card')] = s;
        });
        stored.forEach(function(id){
          var el = map[id];
          if (!el || el.hasAttribute('data-lock')) return; // keep locked in place
          grid.appendChild(el);
        });
      }catch(e){}
    }
    load();

    var dropHint = document.createElement('div');
    dropHint.className = 'yp-drop-hint';
    var dragging = null;

    Array.from(grid.children).forEach(function(sec){
      if (sec.hasAttribute('data-lock')) return; // locked cards not draggable
      sec.setAttribute('draggable','true');

      sec.addEventListener('dragstart', function(e){
        dragging = sec;
        e.dataTransfer.setData('text/plain', sec.getAttribute('data-card'));
        sec.classList.add('dragging');
      });

      sec.addEventListener('dragend', function(){
        if (dragging) dragging.classList.remove('dragging');
        dragging = null;
        if (dropHint.parentNode) dropHint.parentNode.removeChild(dropHint);
        save();
      });
    });

    grid.addEventListener('dragover', function(e){
      if (!dragging) return;
      e.preventDefault();

      var after = Array.from(grid.children).filter(function(c){return c!==dragging;})
        .reduce(function(closest, child){
          var r = child.getBoundingClientRect();
          var offset = e.clientY - r.top - r.height/2;
          if (offset < 0 && offset > closest.offset) { return {offset: offset, element: child}; }
          return closest;
        }, {offset: Number.NEGATIVE_INFINITY, element: null}).element;

      if (after == null) { grid.appendChild(dropHint); }
      else { grid.insertBefore(dropHint, after); }
    });

    grid.addEventListener('drop', function(e){
      e.preventDefault();
      if (!dragging) return;
      if (dropHint.parentNode) {
        grid.insertBefore(dragging, dropHint);
        dropHint.parentNode.removeChild(dropHint);
      }
    });
  }

  function initQuickActions() {
    var card = document.querySelector('[data-quick-actions-card]');
    if (!card) return;
    var grid = card.querySelector('[data-quick-actions-grid]');
    var toggleBtn = card.querySelector('[data-qa-toggle]');
    var resetBtn = card.querySelector('[data-icon-edit-reset]');
    var addSlot = grid ? grid.querySelector('.qa-tile--add-slot') : null;
    var addTile = grid ? grid.querySelector('[data-qa-add]') : null;
    var qaNav = card.querySelector('[data-qa-nav]');
    var qaPrev = card.querySelector('[data-qa-prev]');
    var qaNext = card.querySelector('[data-qa-next]');
    var qaNavLabel = card.querySelector('[data-qa-nav-label]');
    if (!grid || !toggleBtn) return;

    var cfg = window.yooadmPanelQa || {};
    var ajaxUrl = cfg.ajaxUrl || (window.ajaxurl || '');
    var nonce = cfg.nonce || '';
    var isStudioHub = document.body && document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub');
    var maxItems = parseInt(cfg.maxItems || grid.getAttribute('data-max-items') || '5', 10) || 5;
    if (isStudioHub) {
      maxItems = parseInt(grid.getAttribute('data-max-items') || cfg.maxItems || '24', 10) || 24;
    }
    var itemsPerPage = isStudioHub ? (parseInt(cfg.itemsPerPage || '6', 10) || 6) : 0;
    var currentPage = 0;
    var qaDragFromIndex = -1;
    var qaDropHint = null;
    var qaDragGhost = null;
    var QA_DRAG_THRESHOLD_PX = 8;
    var qaPointerDrag = {
      active: false,
      pending: false,
      pointerId: null,
      startX: 0,
      startY: 0,
      lastX: 0,
      lastY: 0,
      tile: null
    };
    var qaPageFlipTimer = null;
    var qaLastDropKey = '';
    var iconChoices = Array.isArray(window.yooadmIconChoices) ? window.yooadmIconChoices.slice() : [];
    if (!iconChoices.length && Array.isArray(cfg.icons)) {
      iconChoices = cfg.icons.slice();
    }

    var strings = cfg.strings || {};
    function __(key, fallback) { return strings[key] || fallback; }

    var defaultActions = [];
    var defaultsAttr = card.getAttribute('data-default-actions');
    if (defaultsAttr) {
      try {
        var parsedDefaults = JSON.parse(defaultsAttr);
        if (Array.isArray(parsedDefaults)) {
          defaultActions = parsedDefaults.map(function (item) {
            return {
              label: (item && item.label) ? String(item.label) : '',
              url: (item && item.url) ? String(item.url) : '',
              icon: (item && item.icon) ? String(item.icon) : 'dashicons-admin-links',
              target: (item && item.target === '_self') ? '_self' : '_blank',
              aria_label: (item && item.aria_label) ? String(item.aria_label) : ''
            };
          });
        }
      } catch (_err) {}
    }

    var state = {
      actions: []
    };

    function readInitial() {
      state.actions = Array.from(grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot)')).map(function (tile) {
        return {
          label: tile.getAttribute('data-qa-label') || '',
          url: tile.getAttribute('data-qa-url') || '',
          icon: tile.getAttribute('data-qa-icon') || 'dashicons-admin-links',
          target: tile.getAttribute('data-qa-target') === '_self' ? '_self' : '_blank',
          aria_label: tile.getAttribute('data-qa-aria-label') || ''
        };
      });
    }

    function ensureActionsState() {
      readInitial();
      if (state.actions.length || !defaultActions.length) {
        return;
      }
      state.actions = defaultActions.map(function (item) {
        return {
          label: item.label || '',
          url: item.url || '',
          icon: item.icon || 'dashicons-admin-links',
          target: item.target === '_self' ? '_self' : '_blank',
          aria_label: item.aria_label || ''
        };
      }).filter(function (item) {
        return item.label && item.url;
      });
    }

    function getRenderInsertBefore() {
      var slot = grid.querySelector('.qa-tile--add-slot');
      if (slot && slot.parentNode === grid) {
        return slot;
      }
      var addBtn = grid.querySelector('[data-qa-add]');
      if (addBtn && addBtn.parentNode === grid) {
        return addBtn;
      }
      if (addBtn && addBtn.parentNode && addBtn.parentNode.parentNode === grid) {
        return addBtn.parentNode;
      }
      return null;
    }

    function sanitizeQaIconClass(icon) {
      var value = String(icon || 'dashicons-admin-links').trim();
      var parts = value.split(/\s+/).filter(function (part) {
        return /^[a-z0-9_-]+$/i.test(part);
      });
      return parts.length ? parts.join(' ') : 'dashicons-admin-links';
    }

    function needsQaClientRender() {
      if (!isStudioHub || !itemsPerPage) {
        return false;
      }
      if (card.classList.contains('is-editing')) {
        return true;
      }
      if (state.actions.length > itemsPerPage) {
        return true;
      }
      return (
        state.actions.length > 0 &&
        grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot)').length === 0
      );
    }

    ensureActionsState();

    function tileToAction(tile) {
      return {
        label: tile.getAttribute('data-qa-label') || '',
        url: tile.getAttribute('data-qa-url') || '',
        icon: tile.getAttribute('data-qa-icon') || 'dashicons-admin-links',
        target: tile.getAttribute('data-qa-target') === '_self' ? '_self' : '_blank',
        aria_label: tile.getAttribute('data-qa-aria-label') || '',
      };
    }

    function getPageSlice() {
      if (!isStudioHub || !itemsPerPage) {
        return {
          actions: state.actions,
          showAdd: false,
          start: 0,
          actionSlots: state.actions.length,
          pages: 1
        };
      }
      var editing = card.classList.contains('is-editing');
      var canAdd = editing && state.actions.length < maxItems;
      var actionSlots = getQaActionSlots();
      var pagesForActions = Math.max(1, Math.ceil(state.actions.length / actionSlots) || 1);
      var extraAddPage =
        editing &&
        canAdd &&
        state.actions.length > 0 &&
        state.actions.length % actionSlots === 0;
      var pages = extraAddPage ? pagesForActions + 1 : pagesForActions;

      if (currentPage >= pages) {
        currentPage = pages - 1;
      }
      if (currentPage < 0) {
        currentPage = 0;
      }

      if (extraAddPage && currentPage === pagesForActions) {
        return {
          actions: [],
          showAdd: true,
          start: state.actions.length,
          actionSlots: actionSlots,
          pages: pages
        };
      }

      var start = currentPage * actionSlots;
      var actions = state.actions.slice(start, start + actionSlots);
      var onLastActionPage = currentPage >= pagesForActions - 1;
      var showAdd =
        editing &&
        canAdd &&
        onLastActionPage &&
        start + actions.length >= state.actions.length &&
        actions.length < actionSlots;

      return {
        actions: actions,
        showAdd: showAdd,
        start: start,
        actionSlots: actionSlots,
        pages: pages
      };
    }

    function syncStateFromDomOrder() {
      var pageTiles = Array.prototype.map.call(
        grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot)'),
        tileToAction
      );
      if (!isStudioHub || !itemsPerPage || !card.classList.contains('is-editing')) {
        state.actions = pageTiles;
        return;
      }
      var slice = getPageSlice();
      var start = slice.start;
      var end = start + pageTiles.length;
      state.actions = state.actions.slice(0, start).concat(pageTiles, state.actions.slice(end));
    }

    function getVisibleActions() {
      if (!isStudioHub || !itemsPerPage) {
        return state.actions;
      }
      return getPageSlice().actions;
    }

    function getQaGridColumnCount() {
      if (!isStudioHub || !grid || !window.getComputedStyle) {
        return 0;
      }
      var columns = window.getComputedStyle(grid).gridTemplateColumns || '';
      if (!columns || columns === 'none') {
        return 0;
      }
      return columns.split(/\s+/).filter(function (part) {
        return part && part !== 'none';
      }).length;
    }

    function getQaActionSlots() {
      if (!isStudioHub || !itemsPerPage) {
        return itemsPerPage || 0;
      }
      var columns = getQaGridColumnCount();
      if (!columns) {
        return itemsPerPage;
      }
      return Math.max(itemsPerPage, columns * 2);
    }

    function getTileGlobalIndex(tile) {
      var tiles = grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot)');
      var idxOnPage = Array.prototype.indexOf.call(tiles, tile);
      if (idxOnPage < 0) {
        return -1;
      }
      return getPageSlice().start + idxOnPage;
    }

    function resolveTileActionIndex(tile) {
      if (!tile) {
        return -1;
      }
      var label = tile.getAttribute('data-qa-label') || '';
      var url = tile.getAttribute('data-qa-url') || '';
      for (var i = 0; i < state.actions.length; i++) {
        var action = state.actions[i];
        if (action && action.label === label && action.url === url) {
          return i;
        }
      }
      return getTileGlobalIndex(tile);
    }

    function handleQaEditClick(evt) {
      evt.preventDefault();
      evt.stopPropagation();
      if (!card.classList.contains('is-editing')) {
        return;
      }
      var tile = evt.currentTarget.closest('.qa-tile:not(.qa-tile--add-slot)');
      if (!tile) {
        return;
      }
      var idx = resolveTileActionIndex(tile);
      if (idx < 0) {
        return;
      }
      openModal(state.actions[idx], idx);
    }

    function confirmQaDeleteModal(onConfirm) {
      if (typeof window.yooadminConfirmDialog === 'function') {
        window.yooadminConfirmDialog({
          title: __('deleteModalTitle', 'Delete quick action?'),
          message: __('deleteConfirm', 'Are you sure you want to delete this quick action?'),
          cancelLabel: __('cancel', 'Cancel'),
          confirmLabel: __('deleteButton', 'Delete'),
          onConfirm: onConfirm
        });
        return;
      }
      if (window.confirm(__('deleteConfirm', 'Are you sure you want to delete this quick action?'))) {
        onConfirm();
      }
    }

    function handleQaDeleteClick(evt) {
      evt.preventDefault();
      evt.stopPropagation();
      if (!card.classList.contains('is-editing')) {
        return;
      }
      var tile = evt.currentTarget.closest('.qa-tile:not(.qa-tile--add-slot)');
      if (!tile) {
        return;
      }
      var index = resolveTileActionIndex(tile);
      if (index < 0) {
        return;
      }
      confirmQaDeleteModal(function () {
        state.actions.splice(index, 1);
        saveActions();
      });
    }

    function bindQaTileActionButtons() {
      grid.querySelectorAll('.qa-tile-edit').forEach(function (btn) {
        btn.removeEventListener('click', handleQaEditClick);
        btn.addEventListener('click', handleQaEditClick);
      });
      grid.querySelectorAll('.qa-tile-delete').forEach(function (btn) {
        btn.removeEventListener('click', handleQaDeleteClick);
        btn.addEventListener('click', handleQaDeleteClick);
      });
    }

    function updateQaPagination() {
      if (!isStudioHub) {
        return;
      }
      var dotsEl = card.querySelector('[data-qa-dots]');
      var editing = card.classList.contains('is-editing');
      var slice = getPageSlice();
      var pages = slice.pages;

      if (dotsEl) {
        var needsDots = !editing && state.actions.length > itemsPerPage;
        if (!needsDots) {
          dotsEl.hidden = true;
          dotsEl.setAttribute('aria-hidden', 'true');
          dotsEl.innerHTML = '';
        } else {
          var viewPages = Math.ceil(state.actions.length / itemsPerPage);
          dotsEl.hidden = false;
          dotsEl.setAttribute('aria-hidden', 'false');
          dotsEl.innerHTML = '';
          for (var p = 0; p < viewPages; p++) {
            (function (pageIndex) {
              var dot = document.createElement('button');
              dot.type = 'button';
              dot.className = 'yp-studio-qa-dots__dot' + (pageIndex === currentPage ? ' is-active' : '');
              dot.setAttribute('aria-label', 'Page ' + (pageIndex + 1));
              dot.addEventListener('click', function (evt) {
                evt.preventDefault();
                currentPage = pageIndex;
                render();
              });
              dotsEl.appendChild(dot);
            })(p);
          }
        }
      }

      if (qaNav) {
        var needsNav = editing && pages > 1;
        qaNav.hidden = !needsNav;
        qaNav.setAttribute('aria-hidden', needsNav ? 'false' : 'true');
        if (qaPrev) {
          qaPrev.disabled = currentPage <= 0;
        }
        if (qaNext) {
          qaNext.disabled = currentPage >= pages - 1;
        }
        if (qaNavLabel) {
          qaNavLabel.textContent = (currentPage + 1) + ' / ' + pages;
        }
      }
    }

    function reorderActions(fromIndex, toIndex) {
      if (fromIndex < 0 || toIndex < 0 || fromIndex === toIndex) {
        return;
      }
      if (fromIndex >= state.actions.length) {
        return;
      }
      var item = state.actions.splice(fromIndex, 1)[0];
      if (fromIndex < toIndex) {
        toIndex -= 1;
      }
      if (toIndex < 0) {
        toIndex = 0;
      }
      if (toIndex > state.actions.length) {
        toIndex = state.actions.length;
      }
      state.actions.splice(toIndex, 0, item);
    }

    function getVisibleQaTiles() {
      return Array.prototype.filter.call(
        grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot)'),
        function (tile) {
          return tile !== qaDropHint;
        }
      );
    }

    function groupQaTilesIntoRows(items) {
      if (!items.length) {
        return [];
      }
      var sorted = items.slice().sort(function (a, b) {
        var ra = a.getBoundingClientRect();
        var rb = b.getBoundingClientRect();
        if (Math.abs(ra.top - rb.top) > 12) {
          return ra.top - rb.top;
        }
        return ra.left - rb.left;
      });
      var rows = [];
      var current = [];
      var rowTop = null;
      sorted.forEach(function (item) {
        var top = item.getBoundingClientRect().top;
        if (rowTop === null || Math.abs(top - rowTop) <= 12) {
          current.push(item);
          if (rowTop === null) {
            rowTop = top;
          }
        } else {
          rows.push(current);
          current = [item];
          rowTop = top;
        }
      });
      if (current.length) {
        rows.push(current);
      }
      return rows;
    }

    function unionQaTileRects(elements) {
      var top = Infinity;
      var bottom = -Infinity;
      for (var i = 0; i < elements.length; i++) {
        var r = elements[i].getBoundingClientRect();
        top = Math.min(top, r.top);
        bottom = Math.max(bottom, r.bottom);
      }
      return { top: top, bottom: bottom };
    }

    function getQaInsertBeforeElement(items, clientX, clientY) {
      if (!items.length) {
        return null;
      }

      for (var h = 0; h < items.length; h++) {
        var hit = items[h].getBoundingClientRect();
        if (
          clientX >= hit.left &&
          clientX <= hit.right &&
          clientY >= hit.top &&
          clientY <= hit.bottom
        ) {
          var afterX = clientX > hit.left + hit.width * 0.5;
          var afterY = clientY > hit.top + hit.height * 0.5;
          if (afterX || afterY) {
            var n = items[h].nextElementSibling;
            while (n && (n === qaDropHint || !n.classList.contains('qa-tile') || n.classList.contains('qa-tile--add-slot'))) {
              n = n.nextElementSibling;
            }
            return n || null;
          }
          return items[h];
        }
      }

      var rows = groupQaTilesIntoRows(items);
      var rowIndex = rows.length;
      for (var r = 0; r < rows.length; r++) {
        var rowBox = unionQaTileRects(rows[r]);
        if (clientY < rowBox.top + (rowBox.bottom - rowBox.top) * 0.5) {
          rowIndex = r;
          break;
        }
      }

      if (rowIndex >= rows.length) {
        return null;
      }

      var row = rows[rowIndex];
      for (var c = 0; c < row.length; c++) {
        var cell = row[c].getBoundingClientRect();
        if (clientX < cell.left + cell.width * 0.5) {
          return row[c];
        }
      }
      var lastInRow = row[row.length - 1];
      var next = lastInRow.nextElementSibling;
      while (next && (next === qaDropHint || !next.classList.contains('qa-tile') || next.classList.contains('qa-tile--add-slot'))) {
        next = next.nextElementSibling;
      }
      return next || null;
    }

    function getVisibleGlobalIndices() {
      var slice = getPageSlice();
      var indices = [];
      for (var i = 0; i < slice.actions.length; i++) {
        var globalIdx = slice.start + i;
        if (qaPointerDrag.active && globalIdx === qaDragFromIndex) {
          continue;
        }
        indices.push(globalIdx);
      }
      return indices;
    }

    function getInsertGlobalIndex(clientX, clientY) {
      var indices = getVisibleGlobalIndices();
      var slice = getPageSlice();
      var items = getVisibleQaTiles();

      if (!indices.length) {
        return slice.start;
      }
      if (!items.length) {
        return indices[0];
      }

      var beforeEl = getQaInsertBeforeElement(items, clientX, clientY);
      var localInsert = beforeEl ? items.indexOf(beforeEl) : items.length;
      if (localInsert < 0) {
        localInsert = items.length;
      }

      if (localInsert >= indices.length) {
        return indices[indices.length - 1] + 1;
      }
      return indices[localInsert];
    }

    function removeQaDragGhost() {
      if (qaDragGhost && qaDragGhost.parentNode) {
        qaDragGhost.parentNode.removeChild(qaDragGhost);
      }
      qaDragGhost = null;
    }

    function createQaDragGhost(tile, clientX, clientY) {
      removeQaDragGhost();
      qaDragGhost = tile.cloneNode(true);
      qaDragGhost.className = 'qa-drag-ghost';
      qaDragGhost.setAttribute('aria-hidden', 'true');
      document.body.appendChild(qaDragGhost);
      positionQaDragGhost(clientX, clientY);
    }

    function positionQaDragGhost(clientX, clientY) {
      if (!qaDragGhost) {
        return;
      }
      var rect = qaDragGhost.getBoundingClientRect();
      qaDragGhost.style.left = (clientX - rect.width / 2) + 'px';
      qaDragGhost.style.top = (clientY - rect.height / 2) + 'px';
    }

    function ensureQaDropHint() {
      if (!qaDropHint) {
        qaDropHint = document.createElement('div');
        qaDropHint.className = 'qa-drop-hint';
        qaDropHint.setAttribute('aria-hidden', 'true');
      }
      return qaDropHint;
    }

    function applyQaDropHint(clientX, clientY) {
      var items = getVisibleQaTiles();
      var beforeEl = getQaInsertBeforeElement(items, clientX, clientY);
      var dropKey =
        getPageSlice().start +
        '|' +
        (beforeEl ? Array.prototype.indexOf.call(items, beforeEl) : items.length);
      if (dropKey === qaLastDropKey && qaDropHint && qaDropHint.parentNode === grid) {
        return;
      }
      qaLastDropKey = dropKey;

      var hint = ensureQaDropHint();
      if (beforeEl && beforeEl.parentNode === grid) {
        grid.insertBefore(hint, beforeEl);
      } else {
        var anchor = getRenderInsertBefore();
        if (anchor) {
          grid.insertBefore(hint, anchor);
        } else {
          grid.appendChild(hint);
        }
      }
    }

    function clearQaPageFlipTimer() {
      if (qaPageFlipTimer) {
        clearTimeout(qaPageFlipTimer);
        qaPageFlipTimer = null;
      }
      if (qaPrev) {
        qaPrev.classList.remove('is-page-flip-active');
      }
      if (qaNext) {
        qaNext.classList.remove('is-page-flip-active');
      }
    }

    function maybeQaPageFlip(clientX, clientY) {
      if (!qaPointerDrag.active || qaPointerDrag.pending || !card.classList.contains('is-editing')) {
        return;
      }
      var pages = getPageSlice().pages;
      if (pages <= 1) {
        clearQaPageFlipTimer();
        return;
      }

      var gridRect = grid.getBoundingClientRect();
      var edge = 44;
      var flipPrev = clientX < gridRect.left + edge && currentPage > 0;
      var flipNext = clientX > gridRect.right - edge && currentPage < pages - 1;

      if (!flipPrev && !flipNext && qaPrev) {
        var prevRect = qaPrev.getBoundingClientRect();
        flipPrev =
          currentPage > 0 &&
          clientX >= prevRect.left &&
          clientX <= prevRect.right &&
          clientY >= prevRect.top &&
          clientY <= prevRect.bottom;
      }
      if (!flipPrev && !flipNext && qaNext) {
        var nextRect = qaNext.getBoundingClientRect();
        flipNext =
          currentPage < pages - 1 &&
          clientX >= nextRect.left &&
          clientX <= nextRect.right &&
          clientY >= nextRect.top &&
          clientY <= nextRect.bottom;
      }

      if (!flipPrev && !flipNext) {
        clearQaPageFlipTimer();
        return;
      }

      if (qaPageFlipTimer) {
        return;
      }

      if (flipPrev && qaPrev) {
        qaPrev.classList.add('is-page-flip-active');
      }
      if (flipNext && qaNext) {
        qaNext.classList.add('is-page-flip-active');
      }

      qaPageFlipTimer = setTimeout(function () {
        qaPageFlipTimer = null;
        if (!qaPointerDrag.active) {
          return;
        }
        if (flipPrev && currentPage > 0) {
          currentPage -= 1;
        } else if (flipNext && currentPage < pages - 1) {
          currentPage += 1;
        } else {
          return;
        }
        qaLastDropKey = '';
        render();
        updateQaPagination();
        applyQaDropHint(qaPointerDrag.lastX, qaPointerDrag.lastY);
        if (qaDragGhost) {
          positionQaDragGhost(qaPointerDrag.lastX, qaPointerDrag.lastY);
        }
      }, 380);
    }

    function cleanupQaDrag() {
      clearQaPageFlipTimer();
      qaPointerDrag.active = false;
      qaPointerDrag.pending = false;
      qaPointerDrag.pointerId = null;
      qaPointerDrag.tile = null;
      qaDragFromIndex = -1;
      qaLastDropKey = '';
      removeQaDragGhost();
      if (qaDropHint && qaDropHint.parentNode) {
        qaDropHint.parentNode.removeChild(qaDropHint);
      }
      document.removeEventListener('pointermove', onQaDocumentPointerMove);
      document.removeEventListener('pointerup', onQaDocumentPointerUp);
      document.removeEventListener('pointercancel', onQaDocumentPointerUp);
      card.classList.remove('is-qa-dragging');
    }

    function finishQaPointerDrag(clientX, clientY) {
      if (qaDragFromIndex < 0) {
        cleanupQaDrag();
        render();
        return;
      }
      var toIndex = getInsertGlobalIndex(clientX, clientY);
      reorderActions(qaDragFromIndex, toIndex);
      cleanupQaDrag();
      render();
      saveActions(true);
    }

    function beginQaPointerDrag(tile, clientX, clientY) {
      qaPointerDrag.active = true;
      qaPointerDrag.pending = false;
      qaLastDropKey = '';
      createQaDragGhost(tile, clientX, clientY);
      card.classList.add('is-qa-dragging');
      render();
      applyQaDropHint(clientX, clientY);
    }

    function onQaDocumentPointerMove(e) {
      if (e.pointerId !== qaPointerDrag.pointerId) {
        return;
      }
      if (!qaPointerDrag.active && !qaPointerDrag.pending) {
        return;
      }

      qaPointerDrag.lastX = e.clientX;
      qaPointerDrag.lastY = e.clientY;

      if (!qaPointerDrag.active) {
        var dx = e.clientX - qaPointerDrag.startX;
        var dy = e.clientY - qaPointerDrag.startY;
        if ((dx * dx) + (dy * dy) < QA_DRAG_THRESHOLD_PX * QA_DRAG_THRESHOLD_PX) {
          return;
        }
        if (!qaPointerDrag.tile) {
          cleanupQaDrag();
          return;
        }
        beginQaPointerDrag(qaPointerDrag.tile, e.clientX, e.clientY);
      }

      e.preventDefault();
      positionQaDragGhost(e.clientX, e.clientY);
      maybeQaPageFlip(e.clientX, e.clientY);
      applyQaDropHint(e.clientX, e.clientY);
    }

    function onQaDocumentPointerUp(e) {
      if (e.pointerId !== qaPointerDrag.pointerId) {
        return;
      }
      if (qaPointerDrag.pending && !qaPointerDrag.active) {
        cleanupQaDrag();
        return;
      }
      if (!qaPointerDrag.active) {
        return;
      }
      finishQaPointerDrag(e.clientX, e.clientY);
    }

    function onQaTileLinkPointerDown(e) {
      if (!card.classList.contains('is-editing')) {
        return;
      }
      if (e.button !== 0) {
        return;
      }

      var link = e.currentTarget;
      var tile = link.closest('.qa-tile:not(.qa-tile--add-slot)');
      if (!tile) {
        return;
      }

      qaDragFromIndex = getTileGlobalIndex(tile);
      if (qaDragFromIndex < 0) {
        return;
      }

      qaPointerDrag.pending = true;
      qaPointerDrag.active = false;
      qaPointerDrag.pointerId = e.pointerId;
      qaPointerDrag.startX = e.clientX;
      qaPointerDrag.startY = e.clientY;
      qaPointerDrag.lastX = e.clientX;
      qaPointerDrag.lastY = e.clientY;
      qaPointerDrag.tile = tile;

      document.addEventListener('pointermove', onQaDocumentPointerMove);
      document.addEventListener('pointerup', onQaDocumentPointerUp);
      document.addEventListener('pointercancel', onQaDocumentPointerUp);
      e.preventDefault();
    }

    function unbindQaTileDragSort() {
      grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot) :is(.qa-tile-link, .qa-tile-drag-handle)').forEach(function (trigger) {
        trigger.removeEventListener('pointerdown', onQaTileLinkPointerDown);
      });
      grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot)').forEach(function (tile) {
        tile.classList.remove('is-dragging');
      });
      if (!qaPointerDrag.active) {
        cleanupQaDrag();
      }
    }

    function bindQaTileDragSort() {
      if (!card.classList.contains('is-editing')) {
        unbindQaTileDragSort();
        return;
      }
      grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot)').forEach(function (tile) {
        tile.removeAttribute('draggable');
      });
      grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot) :is(.qa-tile-link, .qa-tile-drag-handle)').forEach(function (trigger) {
        trigger.removeEventListener('pointerdown', onQaTileLinkPointerDown);
        trigger.addEventListener('pointerdown', onQaTileLinkPointerDown);
      });
    }

    function render() {
      var tiles = grid.querySelectorAll('.qa-tile:not(.qa-tile--add-slot)');
      tiles.forEach(function (tile) { tile.parentNode && tile.parentNode.removeChild(tile); });
      var emptyMsg = card.querySelector('[data-qa-empty]');
      if (emptyMsg) {
        emptyMsg.remove();
      }

      var frag = document.createDocumentFragment();
      var pageSlice = isStudioHub && itemsPerPage ? getPageSlice() : null;
      getVisibleActions().forEach(function (item, localIdx) {
        if (pageSlice) {
          var globalIdx = pageSlice.start + localIdx;
          if (qaPointerDrag.active && globalIdx === qaDragFromIndex) {
            return;
          }
        }
        var wrapper = document.createElement('div');
        wrapper.className = 'qa-tile';
        wrapper.setAttribute('data-qa-label', item.label);
        wrapper.setAttribute('data-qa-url', item.url);
        wrapper.setAttribute('data-qa-icon', item.icon);
        wrapper.setAttribute('data-qa-target', item.target === '_self' ? '_self' : '_blank');
        if (item.aria_label) {
          wrapper.setAttribute('data-qa-aria-label', item.aria_label);
        }

        if (isStudioHub) {
          var dragHandle = document.createElement('span');
          dragHandle.className = 'qa-tile-drag-handle';
          dragHandle.setAttribute('aria-hidden', 'true');
          dragHandle.innerHTML = '<span class="dashicons dashicons-move" aria-hidden="true"></span>';
          wrapper.appendChild(dragHandle);
        }

        var anchor = document.createElement('a');
        anchor.className = isStudioHub ? 'yp-icon-tile qa-tile-link yp-studio-qa-tile' : 'yp-icon-tile qa-tile-link';
        anchor.href = item.url;
        anchor.target = item.target === '_self' ? '_self' : '_blank';
        anchor.rel = item.target === '_blank' ? 'noopener noreferrer' : 'nofollow';
        if (item.aria_label) {
          anchor.setAttribute('aria-label', item.aria_label);
        }
        var iconClass = sanitizeQaIconClass(item.icon);
        if (isStudioHub) {
          anchor.innerHTML = '<span class="yp-studio-qa-tile__icon-well"><span class="dashicons ' + iconClass + '" aria-hidden="true"></span></span><span class="yp-icon-label"></span>';
        } else {
          anchor.innerHTML = '<span class="dashicons ' + iconClass + '" aria-hidden="true"></span><span class="yp-icon-label"></span>';
        }
        anchor.querySelector('.yp-icon-label').textContent = item.label;

        var controls = document.createElement('div');
        controls.className = isStudioHub
          ? 'qa-tile-actions yp-studio-card-edit-actions'
          : 'qa-tile-actions';
        controls.setAttribute('aria-hidden', 'true');
        if (isStudioHub) {
          controls.innerHTML =
            '<button type="button" class="qa-tile-edit yp-card-icon-edit" aria-label="' +
            __('editAction', 'Edit quick action') +
            '"><span class="dashicons dashicons-edit" aria-hidden="true"></span></button>' +
            '<button type="button" class="qa-tile-delete yp-card-icon-edit yp-qa-tile-delete" aria-label="' +
            __('deleteAction', 'Delete quick action') +
            '"><span class="dashicons dashicons-trash" aria-hidden="true"></span></button>';
        } else {
          controls.innerHTML =
            '<button type="button" class="qa-tile-edit" aria-label="' +
            __('editAction', 'Edit quick action') +
            '"><span class="dashicons dashicons-edit"></span></button>' +
            '<button type="button" class="qa-tile-delete" aria-label="' +
            __('deleteAction', 'Delete quick action') +
            '"><span class="dashicons dashicons-trash"></span></button>';
        }

        wrapper.appendChild(anchor);
        wrapper.appendChild(controls);
        frag.appendChild(wrapper);
      });

      var insertBefore = getRenderInsertBefore();
      try {
        if (insertBefore) {
          grid.insertBefore(frag, insertBefore);
        } else {
          grid.appendChild(frag);
        }
      } catch (err) {
        grid.appendChild(frag);
      }
      updateAddTileVisibility();
      updateQaPagination();
      bindQaTileDragSort();
      bindQaTileActionButtons();

      if (!state.actions.length) {
        emptyMsg = document.createElement('div');
        emptyMsg.className = 'qa-empty';
        emptyMsg.setAttribute('data-qa-empty', '1');
        emptyMsg.innerHTML = '<span class="dashicons dashicons-info-outline" aria-hidden="true"></span>' +
          '<span class="qa-empty-text">' + __('emptyMessage', 'No quick actions configured yet.') + '</span>';
        card.insertBefore(emptyMsg, grid);
      }
    }

    function updateAddTileVisibility() {
      if (!addTile) return;
      var isEditing = card.classList.contains('is-editing');
      var slice = isStudioHub && itemsPerPage ? getPageSlice() : { showAdd: false };
      if (!isEditing) {
        addTile.classList.add('is-hidden');
        addTile.classList.remove('is-disabled');
        addTile.disabled = true;
        if (addSlot) {
          addSlot.classList.add('is-hidden');
        }
        return;
      }
      var hasCapacity = state.actions.length < maxItems;
      var showAdd = hasCapacity && slice.showAdd;
      addTile.classList.toggle('is-hidden', !showAdd);
      addTile.classList.toggle('is-disabled', !showAdd);
      addTile.disabled = !showAdd;
      if (addSlot) {
        addSlot.classList.toggle('is-hidden', !showAdd);
      }
    }

    function setEditing(on) {
      on = !!on;
      card.classList.toggle('is-editing', on);
      toggleBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
      // Keep icon only (like Welcome card) - don't change textContent
      if (resetBtn) {
        resetBtn.hidden = !on;
        resetBtn.disabled = !on;
      }
      if (!on) {
        currentPage = 0;
        unbindQaTileDragSort();
      }
      if (on || needsQaClientRender()) {
        render();
      } else {
        updateAddTileVisibility();
        updateQaPagination();
      }
    }

    function openModal(existing, index) {
      var overlay = document.createElement('div');
      overlay.className = 'qa-modal-overlay';
      var initialIcon = existing && existing.icon ? existing.icon : 'dashicons-admin-links';
      overlay.innerHTML = '<div class="qa-modal">' +
        '<h3>' + (existing ? __('editTitle', 'Edit Quick Action') : __('addTitle', 'Add Quick Action')) + '</h3>' +
        '<form>' +
        '<label>' + __('label', 'Label') + '<input type="text" name="label" value="' + (existing ? existing.label : '') + '" required></label>' +
        '<label>' + __('url', 'URL') + '<input type="url" name="url" value="' + (existing ? existing.url : '') + '" required></label>' +
        '<label>' + __('target', 'Target') + '<select name="target"><option value="_blank"' + (!existing || existing.target !== '_self' ? ' selected' : '') + '>' + __('targetBlank', 'Open in new tab') + '</option><option value="_self"' + (existing && existing.target === '_self' ? ' selected' : '') + '>' + __('targetSelf', 'Open in same tab') + '</option></select></label>' +
        '<label class="qa-icon-picker-label">' + __('icon', 'Icon') +
          '<div class="qa-icon-picker-field">' +
            '<button type="button" class="qa-icon-trigger" data-default-icon="dashicons-admin-links">' +
              '<span class="dashicons qa-icon-trigger-icon ' + initialIcon + '" aria-hidden="true"></span>' +
              '<span class="qa-icon-trigger-label">' + initialIcon + '</span>' +
            '</button>' +
            '<span class="qa-icon-trigger-hint">' + __('iconHint', 'Click to choose from the icon library') + '</span>' +
            '<input type="hidden" name="icon" value="' + initialIcon + '">' +
          '</div>' +
        '</label>' +
        '<div class="qa-modal-actions"><button type="button" class="qa-modal-secondary">' + __('cancel', 'Cancel') + '</button><button type="submit" class="qa-modal-submit">' + __('save', 'Save') + '</button></div>' +
        '</form>' +
        '</div>';
      // Insert overlay at the beginning of header (like sidebar overlay) to ensure proper stacking
      var header = document.getElementById('yoo-admin-header');
      if (header) {
        // Insert at the beginning (like yps-overlay) to ensure it's in the same stacking context
        header.insertBefore(overlay, header.firstChild);
      } else {
        document.body.appendChild(overlay);
      }
      document.body.classList.add('qa-modal-open');
      requestAnimationFrame(function(){ overlay.classList.add('is-visible'); });

      var iconInput = overlay.querySelector('input[name="icon"]');
      var iconTrigger = overlay.querySelector('.qa-icon-trigger');
      var iconLabelEl = iconTrigger ? iconTrigger.querySelector('.qa-icon-trigger-label') : null;
      var iconGlyph = iconTrigger ? iconTrigger.querySelector('.qa-icon-trigger-icon') : null;
      var defaultIcon = iconTrigger ? iconTrigger.getAttribute('data-default-icon') || 'dashicons-admin-links' : 'dashicons-admin-links';

      function normalizeIcon(val) {
        var icon = (val || '').trim();
        return icon ? icon : defaultIcon;
      }

      function updateIconPreview(icon) {
        var value = normalizeIcon(icon);
        if (iconInput) iconInput.value = value;
        if (iconGlyph) iconGlyph.className = 'dashicons qa-icon-trigger-icon ' + value;
        if (iconLabelEl) iconLabelEl.textContent = value;
      }

      updateIconPreview(initialIcon);

      if (iconTrigger) {
        iconTrigger.addEventListener('click', function (evt) {
          evt.preventDefault();
          var startIcon = iconInput ? iconInput.value : defaultIcon;
          if (window.YPCardIcons && typeof window.YPCardIcons.pickIcon === 'function') {
            window.YPCardIcons.pickIcon(startIcon, function (chosen) {
              updateIconPreview(chosen);
            });
          } else if (iconChoices.length) {
            // Fallback to prompt if picker is not available (should not happen)
            var manual = window.prompt(__('iconPrompt', 'Enter Dashicon class (e.g., dashicons-admin-links)'), startIcon);
            if (manual !== null) {
              updateIconPreview(manual);
            }
          } else {
            alert(__('iconPickerUnavailable', 'Icon picker is not available.'));
          }
        });
      }

      overlay.addEventListener('click', function (evt) {
        if (evt.target === overlay) {
          closeModal();
        }
      });

      overlay.querySelector('.qa-modal-secondary').addEventListener('click', function () {
        closeModal();
      });

      overlay.querySelector('form').addEventListener('submit', function (evt) {
        evt.preventDefault();
        var form = evt.currentTarget;
        var label = form.label.value.trim();
        var url = form.url.value.trim();
        var icon = (form.icon.value || '').trim() || 'dashicons-admin-links';
        var target = form.target.value === '_self' ? '_self' : '_blank';
        if (!label || !url) {
          alert(__('validation', 'Please provide both label and URL.'));
          return;
        }
        var item = { label: label, url: url, icon: icon, target: target };
        if (existing && existing.aria_label) {
          item.aria_label = existing.aria_label;
        }
        if (typeof index === 'number') {
          state.actions[index] = item;
        } else {
          if (state.actions.length >= maxItems) {
            alert(__('maxReached', 'Maximum items reached'));
            return;
          }
          state.actions.push(item);
        }
        closeModal();
        saveActions();
      });

      function closeModal() {
        overlay.classList.remove('is-visible');
        setTimeout(function(){ 
          if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
          document.body.classList.remove('qa-modal-open');
        }, 180);
      }
    }

    function saveActions(skipRender) {
      if (!skipRender) {
        render();
      }
      if (!ajaxUrl || !nonce) { return; }
      var payload = new URLSearchParams();
      payload.append('action', 'yooadmin_save_quick_actions');
      payload.append('_ajax_nonce', nonce);
      payload.append('actions', JSON.stringify(state.actions));

      toggleBtn.disabled = true;
      addTile.disabled = true;
      if (resetBtn) resetBtn.disabled = true;

      fetch(ajaxUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: payload.toString()
      }).then(function (res) { return res.json(); }).then(function (res) {
        if (!res || !res.success || !Array.isArray(res.data.actions)) {
          throw new Error('error');
        }
        state.actions = res.data.actions;
        render();
      }).catch(function () {
        alert(__('error', 'Something went wrong, please try again.'));
        render();
      }).finally(function () {
        toggleBtn.disabled = false;
        updateAddTileVisibility();
        if (resetBtn) {
          var stillEditing = card.classList.contains('is-editing');
          resetBtn.disabled = !stillEditing;
        }
      });
    }

    if (qaPrev) {
      qaPrev.addEventListener('click', function (evt) {
        evt.preventDefault();
        if (currentPage > 0) {
          currentPage -= 1;
          render();
        }
      });
    }
    if (qaNext) {
      qaNext.addEventListener('click', function (evt) {
        evt.preventDefault();
        var pages = getPageSlice().pages;
        if (currentPage < pages - 1) {
          currentPage += 1;
          render();
        }
      });
    }

    grid.addEventListener('click', function (evt) {
      if (!card.classList.contains('is-editing')) return;
      if (evt.target.closest('.qa-tile-edit, .qa-tile-delete')) {
        return;
      }
      if (evt.target.closest('.qa-tile-link')) {
        evt.preventDefault();
      }
    });

    if (addTile) {
      addTile.addEventListener('click', function () {
        if (!card.classList.contains('is-editing')) return;
        if (state.actions.length >= maxItems) {
          alert(__('maxReached', 'Maximum items reached'));
          return;
        }
        openModal(null, null);
      });
    }

    if (resetBtn) {
      resetBtn.addEventListener('click', function (evt) {
        evt.preventDefault();
        if (!card.classList.contains('is-editing')) return;
        var restored = [];
        if (defaultActions && defaultActions.length) {
          for (var i = 0; i < defaultActions.length && restored.length < maxItems; i++) {
            var item = defaultActions[i];
            if (!item || !item.label || !item.url) continue;
            restored.push({
              label: item.label,
              url: item.url,
              icon: item.icon || 'dashicons-admin-links',
              target: item.target === '_self' ? '_self' : '_blank',
              aria_label: item.aria_label || ''
            });
          }
        }
        state.actions = restored;
        saveActions();
      });
    }

    toggleBtn.addEventListener('click', function () {
      var nowEditing = !card.classList.contains('is-editing');
      setEditing(nowEditing);
    });

    function ensureGridVisible() {
      if (isStudioHub) {
        return;
      }
      if (!grid.classList.contains('is-hydrated')) {
        grid.classList.add('is-hydrated');
      }
      grid.style.display = '';
      var loading = card.querySelector('.yp-quick-actions-loading');
      if (loading) {
        loading.style.display = 'none';
      }
    }
    ensureGridVisible();

    card.classList.remove('is-editing');
    toggleBtn.setAttribute('aria-pressed', 'false');
    if (resetBtn) {
      resetBtn.hidden = true;
      resetBtn.disabled = true;
    }
    currentPage = 0;
    if (needsQaClientRender()) {
      render();
    } else {
      updateAddTileVisibility();
      updateQaPagination();
    }
  }

  function initWelcomeEditor() {
    var card = document.querySelector('[data-welcome-card]');
    if (!card) return;
    var toggleBtn = card.querySelector('[data-welcome-toggle]');
    if (!toggleBtn) return;

    var cfg = window.yooadmPanelWelcome || {};
    var ajaxUrl = cfg.ajaxUrl || window.ajaxurl || '';
    var nonce = cfg.nonce || '';

    function openWelcomeModal() {
      var titleEl = card.querySelector('.yp-card-welcome');
      // Extract text only (skip icon span)
      var currentTitle = '';
      if (titleEl) {
        var titleClone = titleEl.cloneNode(true);
        var iconSpan = titleClone.querySelector('.dashicons');
        if (iconSpan) iconSpan.remove();
        currentTitle = titleClone.textContent.trim();
      }
      var pNodes = card.querySelectorAll('.yp-card-text');
      var currentP1 = pNodes[0] ? pNodes[0].textContent.trim() : '';
      var currentP2 = pNodes[1] ? pNodes[1].textContent.trim() : '';

      var lblTitle = cfg.title || 'Title';
      var lblP1 = cfg.paragraph1 || 'Paragraph 1';
      var lblP2 = cfg.paragraph2 || 'Paragraph 2';
      var lblReset = cfg.reset || 'Reset';
      var lblCancel = cfg.cancel || 'Cancel';
      var lblSave = cfg.save || 'Save';
      var lblResetting = cfg.resetting || 'Resetting…';
      var modalTitle = cfg.customizeText || toggleBtn.getAttribute('data-label-edit') || 'Customize text';

      var overlay = document.createElement('div');
      overlay.className = 'qa-modal-overlay';
      overlay.innerHTML =
        '<div class="qa-modal">' +
          '<h3>' + modalTitle + '</h3>' +
          '<form>' +
            '<label>' + lblTitle + '<input type="text" name="title" value="' + currentTitle.replace(/"/g, '&quot;') + '" required></label>' +
            '<label>' + lblP1 + '<textarea name="p1" rows="3" required>' + currentP1 + '</textarea></label>' +
            '<label>' + lblP2 + '<textarea name="p2" rows="3" required>' + currentP2 + '</textarea></label>' +
            '<div class="qa-modal-actions">' +
              '<button type="button" class="qa-modal-reset yp-yoo-btn yp-yoo-btn--soft">' + lblReset + '</button>' +
              '<button type="button" class="qa-modal-secondary yp-yoo-btn yp-yoo-btn--soft">' + lblCancel + '</button>' +
              '<button type="submit" class="qa-modal-submit yp-yoo-btn yp-yoo-btn--primary">' + lblSave + '</button>' +
            '</div>' +
          '</form>' +
        '</div>';

      // Insert overlay at the beginning of header (like sidebar overlay) to ensure proper stacking
      var header = document.getElementById('yoo-admin-header');
      if (header) {
        // Insert at the beginning (like yps-overlay) to ensure it's in the same stacking context
        header.insertBefore(overlay, header.firstChild);
      } else {
        document.body.appendChild(overlay);
      }
      document.body.classList.add('qa-modal-open');
      requestAnimationFrame(function(){ overlay.classList.add('is-visible'); });

      function closeModal() {
        overlay.classList.remove('is-visible');
        setTimeout(function(){ 
          if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
          document.body.classList.remove('qa-modal-open');
        }, 180);
      }

      overlay.querySelector('.qa-modal-secondary').addEventListener('click', function(e){
        e.preventDefault();
        closeModal();
        setEditing(false);
      });

      overlay.addEventListener('click', function(e){
        if (e.target === overlay) {
          closeModal();
          setEditing(false);
        }
      });

      // Reset button inside modal
      var resetBtnModal = overlay.querySelector('.qa-modal-reset');
      if (resetBtnModal && defaultWelcome) {
        resetBtnModal.addEventListener('click', function(e){
          e.preventDefault();
          if (!ajaxUrl || !nonce) {
            applyWelcomeContent(defaultWelcome);
            closeModal();
            setEditing(false);
            return;
          }

          var payload = new URLSearchParams();
          payload.append('action', 'yooadmin_save_welcome');
          payload.append('_ajax_nonce', nonce);
          payload.append('mode', 'reset');

          resetBtnModal.disabled = true;
          var originalText = resetBtnModal.textContent;
          resetBtnModal.textContent = lblResetting;

          fetch(ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: payload.toString()
          }).then(function(res){ return res.json(); }).then(function(res){
            applyWelcomeContent(defaultWelcome);
            closeModal();
            setEditing(false);
          }).catch(function(){
            alert('Something went wrong, please try again.');
          }).finally(function(){
            resetBtnModal.disabled = false;
            resetBtnModal.textContent = originalText;
          });
        });
      }

      overlay.querySelector('form').addEventListener('submit', function(e){
        e.preventDefault();
        if (!ajaxUrl || !nonce) {
          closeModal();
          return;
        }
        var form = e.currentTarget;
        var title = form.title.value.trim();
        var p1 = form.p1.value.trim();
        var p2 = form.p2.value.trim();
        if (!title || !p1 || !p2) {
          alert('Please fill in all fields.');
          return;
        }

        var payload = new URLSearchParams();
        payload.append('action', 'yooadmin_save_welcome');
        payload.append('_ajax_nonce', nonce);
        payload.append('title', title);
        payload.append('p1', p1);
        payload.append('p2', p2);

        // Save original icon HTML
        var originalIcon = toggleBtn.querySelector('.dashicons');
        var originalIconHtml = originalIcon ? originalIcon.outerHTML : '<span class="dashicons dashicons-edit" aria-hidden="true"></span>';
        
        toggleBtn.disabled = true;
        // Show saving state (keep icon structure)
        var savingIcon = toggleBtn.querySelector('.dashicons');
        if (savingIcon) {
          savingIcon.className = 'dashicons dashicons-update';
          savingIcon.style.animation = 'spin 1s linear infinite';
        }

        fetch(ajaxUrl, {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
          body: payload.toString()
        }).then(function(res){ return res.json(); }).then(function(res){
          if (!res || !res.success || !res.data || !res.data.welcome) {
            throw new Error('error');
          }
          var w = res.data.welcome;
          applyWelcomeContent(w);
          closeModal();
          setEditing(false);
        }).catch(function(){
          alert('Something went wrong, please try again.');
        }).finally(function(){
          toggleBtn.disabled = false;
          // Restore original icon
          var currentIcon = toggleBtn.querySelector('.dashicons');
          if (currentIcon) {
            currentIcon.className = 'dashicons dashicons-edit';
            currentIcon.style.animation = '';
          } else {
            toggleBtn.innerHTML = originalIconHtml;
          }
        });
      });
    }

    var defaultWelcome = null;
    var defAttr = card.getAttribute('data-default-welcome');
    if (defAttr) {
      try {
        defaultWelcome = JSON.parse(defAttr);
      } catch (_e) {
        defaultWelcome = null;
      }
    }

    function applyWelcomeContent(w) {
      if (!w) return;
      var pNodes = card.querySelectorAll('.yp-card-text');
      var titleEl = card.querySelector('.yp-card-welcome');
      if (titleEl) {
        // Keep icon, update text only
        var iconSpan = titleEl.querySelector('.dashicons');
        var iconHtml = iconSpan ? iconSpan.outerHTML : '';
        titleEl.innerHTML = iconHtml + (w.title || '');
      }
      if (pNodes[0]) pNodes[0].textContent = w.p1 || '';
      if (pNodes[1]) pNodes[1].textContent = w.p2 || '';
    }

    function setEditing(on) {
      on = !!on;
      card.classList.toggle('is-editing', on);
      toggleBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
      var editLabel = toggleBtn.getAttribute('data-label-edit') || 'Edit';
      var doneLabel = toggleBtn.getAttribute('data-label-done') || 'Done';
      toggleBtn.setAttribute('aria-label', on ? doneLabel : editLabel);
      // Keep icon but change text via title attribute only (visual label stays icon)
    }

    toggleBtn.addEventListener('click', function(e){
      e.preventDefault();
      var nowEditing = !card.classList.contains('is-editing');
      setEditing(nowEditing);
      if (nowEditing) {
        openWelcomeModal();
      }
    });
  }

  // Initialize Quick Actions & Welcome editor even if not in YOOPanel page (e.g., Dashboard)
  // These must run regardless of #yoopanel existence
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      initQuickActions();
      initWelcomeEditor();
    });
  } else {
    initQuickActions();
    initWelcomeEditor();
  }
  
  // Mount cards only if root exists
  if (root) {
    mountCards();
  }
})();
