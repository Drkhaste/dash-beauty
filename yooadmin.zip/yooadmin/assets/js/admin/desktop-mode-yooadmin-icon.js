(function () {
	'use strict';

	var ICON_ID = 'yooadmin-panel';
	var busy = false;

	function getYooadminConfig() {
		return window.yooadminDesktopIcon && typeof window.yooadminDesktopIcon === 'object'
			? window.yooadminDesktopIcon
			: {};
	}

	function getDesktopModeConfig() {
		return window.desktopModeAdminBar && typeof window.desktopModeAdminBar === 'object'
			? window.desktopModeAdminBar
			: {};
	}

	function canonicalIconSlug(slug) {
		if (!slug) {
			return '';
		}
		if (slug.indexOf('dock-core:') === 0) {
			return slug.slice(10);
		}
		if (slug.indexOf('dock:') === 0) {
			return slug.slice(5);
		}
		if (slug.indexOf('desktop:') === 0) {
			return slug.slice(8);
		}
		return slug;
	}

	function isYooadminSlug(slug) {
		return canonicalIconSlug(slug) === ICON_ID;
	}

	function resolveLandingUrl() {
		var yooCfg = getYooadminConfig();
		if (yooCfg.url) {
			return yooCfg.url;
		}

		if (window.yooadmFocus && window.yooadmFocus.toggle_on_url) {
			return window.yooadmFocus.toggle_on_url;
		}

		var dmCfg = getDesktopModeConfig();
		var fallback = dmCfg.classicUrl || '/wp-admin/';

		try {
			var url = new URL(fallback, window.location.origin);
			url.searchParams.set('yoo', 'on');
			return url.toString();
		} catch (err) {
			return fallback;
		}
	}

	function navigateTop(url) {
		try {
			window.top.location.href = url;
		} catch (err) {
			window.location.href = url;
		}
	}

	/**
	 * Same flow as desktop-mode/assets/js/admin-bar.js when disabling
	 * Desktop Mode, plus navigation to YOOAdmin Focus afterward.
	 */
	function exitDesktopModeAndOpenYooadmin() {
		if (busy) {
			return;
		}
		busy = true;

		var dmCfg = getDesktopModeConfig();
		var yooCfg = getYooadminConfig();
		var fallback = resolveLandingUrl();
		var ajaxUrl = dmCfg.ajaxUrl || yooCfg.ajaxUrl || '';
		var nonce = dmCfg.nonce || yooCfg.nonce || '';

		document.cookie = 'yoo_focus=on; path=/; max-age=31536000; SameSite=Lax';

		if (!ajaxUrl || !nonce) {
			navigateTop(fallback);
			return;
		}

		var body = new URLSearchParams();
		body.set('action', 'save-desktop-mode');
		body.set('nonce', nonce);
		body.set('enabled', '');

		var xhr = new XMLHttpRequest();
		xhr.open('POST', ajaxUrl, true);
		xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		xhr.onload = function () {
			var target = fallback;
			if (xhr.status === 200) {
				try {
					var resp = JSON.parse(xhr.responseText);
					if (resp && resp.success && resp.data && resp.data.redirect) {
						target = fallback;
					}
				} catch (parseErr) {
					// Keep YOOAdmin landing URL.
				}
			}
			navigateTop(target);
		};
		xhr.onerror = function () {
			navigateTop(fallback);
		};
		xhr.send(body.toString());
	}

	function bindExitClick(node) {
		if (!node || node.dataset.yooadminExitBound === '1') {
			return;
		}
		node.dataset.yooadminExitBound = '1';

		node.addEventListener(
			'click',
			function (event) {
				event.preventDefault();
				event.stopPropagation();
				event.stopImmediatePropagation();
				exitDesktopModeAndOpenYooadmin();
			},
			true
		);
	}

	function wireDockTile(payload) {
		if (!payload || !payload.item || !payload.el || !isYooadminSlug(payload.item.id)) {
			return;
		}

		bindExitClick(payload.el.querySelector('.desktop-mode-dock__item-primary') || payload.el);
	}

	function wireBreadcrumbsBrand() {
		document
			.querySelectorAll('.yp-breadcrumbs-brand, .yp-breadcrumbs-brand__button')
			.forEach(bindExitClick);
	}

	function registerHooks() {
		var hooks = window.wp && window.wp.hooks;
		if (!hooks || typeof hooks.addAction !== 'function') {
			return;
		}

		hooks.addAction(
			'desktop-mode.desktop-icon.clicked',
			'yooadmin/desktop-exit',
			function (payload) {
				if (!payload || !isYooadminSlug(payload.id)) {
					return;
				}
				exitDesktopModeAndOpenYooadmin();
			},
			1
		);

		hooks.addAction('desktop-mode.dock.tile-rendered', 'yooadmin/desktop-exit', wireDockTile, 100);
		hooks.addAction(
			'desktop-mode.dock.after-render',
			'yooadmin/desktop-exit',
			function () {
				document.querySelectorAll('.desktop-mode-dock__item[data-menu-slug]').forEach(function (tile) {
					if (isYooadminSlug(tile.getAttribute('data-menu-slug'))) {
						bindExitClick(tile.querySelector('.desktop-mode-dock__item-primary') || tile);
					}
				});
			},
			100
		);
	}

	function boot() {
		registerHooks();
		wireBreadcrumbsBrand();

		if (window.MutationObserver && !window.__yooadminDesktopExitObserver__) {
			window.__yooadminDesktopExitObserver__ = true;
			var observer = new MutationObserver(function () {
				wireBreadcrumbsBrand();
			});
			observer.observe(document.body, { childList: true, subtree: true });
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
