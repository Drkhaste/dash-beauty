/**
 * YOOAdmin — classify WP admin notices (operational toast vs promotional banner).
 *
 * @package YOOAdmin
 */

(function () {
  'use strict';

  var PROTECTED_CLASSES = [
    'yooadmin-brand-notice',
    'yooadmin-wizard-notice',
    'yooadmin-login-turnstile-incomplete-notice',
    'yooadmin-notification',
    'yp-notification-item',
    'yp-banner-converted',
    'inline',
    'notice-alt',
    'update-message',
  ];

  var PROMO_CLASS_HINTS = [
    'wpmet-notice',
    'jhanda',
    'fs-notice',
    'e-notice--extended',
    'codevz-admin-notice',
    'wpb-notice',
    'gutenkit',
    'wpmudev',
    'elementor-message',
    'rank-math-notice',
    'aioseo',
  ];

  var PROMO_TEXT_RE = [
    /\blimited\s+time\b/i,
    /\b\d+\s*%\s*off\b/i,
    /\bsave\s+\$?\d/i,
    /\ball[- ]in[- ]one\b/i,
    /\bplugin\s+bundle\b/i,
    /\bupgrade\s+(to\s+)?(pro|premium|plus)\b/i,
    /\bget\s+(pro|premium|plus)\b/i,
    /\bspecial\s+offer\b/i,
    /\bexclusive\s+deal\b/i,
    /\bblack\s+friday\b/i,
    /\bcyber\s+monday\b/i,
    /\bdiscount\b/i,
    /\bcoupon\b/i,
    /\btry\s+for\s+free\b/i,
    /\bgo\s+premium\b/i,
    /\bbuy\s+now\b/i,
  ];

  var EDITOR_INFO_TEXT_RE = [
    /\buse\s+classic\s+editor\s+for\s+new\s+posts\b/i,
    /\bclassic\s+editor\s+by\s+default\b/i,
    /\bpost\s+type\s+is\s+set\s+to\s+use\s+the\s+classic\s+editor\b/i,
  ];

  var OPERATIONAL_TEXT_RE = [
    /\bsettings\s+saved\b/i,
    /\bsaved successfully\b/i,
    /\bupdated successfully\b/i,
    /\bdeleted successfully\b/i,
    /\btrashed\b/i,
    /\brestored\b/i,
    /\bactivated\b/i,
    /\bdeactivated\b/i,
    /\binstalled successfully\b/i,
    /\bplugin\s+activated\b/i,
    /\bplugin\s+deactivated\b/i,
    /\bpage\s+(published|updated|created)\b/i,
    /\bpost\s+(published|updated|created)\b/i,
    /\bmoved\s+to\s+the\s+trash\b/i,
    /\bremoved\s+from\s+the\s+trash\b/i,
    /\berror\b/i,
    /\bfailed\b/i,
    /\bcould\s+not\b/i,
    /\bunable\s+to\b/i,
    /\binvalid\b/i,
    /\bpermission\b/i,
    /\bwordpress\s+\d+(?:\.\d+)+\s+is\s+available\b/i,
    /\bplease\s+update\b/i,
    /\bnew\s+version\s+is\s+available\b/i,
  ];

  function normalizeEl(el) {
    if (!el || el.nodeType !== 1) {
      return null;
    }
    return el;
  }

  function classString(el) {
    return String(el.className || '');
  }

  function noticeText(el) {
    var clone = el.cloneNode(true);
    var dismiss = clone.querySelector('.notice-dismiss, [class*="dismiss"]');
    if (dismiss) {
      dismiss.remove();
    }
    return String(clone.textContent || clone.innerText || '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function hasProtectedClass(el) {
    var i;
    for (i = 0; i < PROTECTED_CLASSES.length; i++) {
      if (el.classList.contains(PROTECTED_CLASSES[i])) {
        return true;
      }
    }
    return false;
  }

  function hasProtectedContext(el) {
    return !!(
      el &&
      typeof el.closest === 'function' &&
      el.closest('[data-yp-banner-ignore], [data-yp-internal-notice], .yp-alert, .yp-notifications-dropdown')
    );
  }

  function hasPromoClassHint(el) {
    var cls = classString(el).toLowerCase();
    var i;
    for (i = 0; i < PROMO_CLASS_HINTS.length; i++) {
      if (cls.indexOf(PROMO_CLASS_HINTS[i]) !== -1) {
        return true;
      }
    }
    if (cls.indexOf('-admin-notice') !== -1 && !el.classList.contains('notice-success') && !el.classList.contains('updated')) {
      return true;
    }
    return false;
  }

  function matchesAny(reList, text) {
    var i;
    for (i = 0; i < reList.length; i++) {
      if (reList[i].test(text)) {
        return true;
      }
    }
    return false;
  }

  function isBannerConversionEnabled() {
    return !!(window.yooadmRuntime && window.yooadmRuntime.convertBannersToNotifications);
  }

  function isNoticeElement(el) {
    el = normalizeEl(el);
    if (!el) {
      return false;
    }
    return (
      el.classList.contains('notice') ||
      el.classList.contains('update-nag') ||
      el.classList.contains('updated') ||
      el.classList.contains('error') ||
      classString(el).indexOf('-admin-notice') !== -1
    );
  }

  function isClassicEditorInformationalNotice(el) {
    el = normalizeEl(el);
    if (!el || !isNoticeElement(el)) {
      return false;
    }

    var haystack = [el.id || '', classString(el), noticeText(el)].join(' ');
    if (/\bclassic[-_]?editor\b/i.test(haystack)) {
      return true;
    }

    return matchesAny(EDITOR_INFO_TEXT_RE, noticeText(el));
  }

  function isPromotionalBanner(el) {
    el = normalizeEl(el);
    if (!el || !isNoticeElement(el) || hasProtectedClass(el) || hasProtectedContext(el)) {
      return false;
    }

    if (el.getAttribute('data-yp-notification-converted') === '1') {
      return false;
    }

    if (isClassicEditorInformationalNotice(el)) {
      return false;
    }

    var text = noticeText(el);
    if (!text) {
      return false;
    }

    if (hasPromoClassHint(el)) {
      return true;
    }

    if (matchesAny(PROMO_TEXT_RE, text)) {
      return true;
    }

    var hasImage = !!el.querySelector('img');
    var hasCta = !!el.querySelector(
      'a.button, a.button-primary, a.button-secondary, .button-primary, .button-secondary, [class*="cta"]'
    );
    if (hasImage && hasCta && text.length > 50) {
      return true;
    }

    if (
      (el.classList.contains('notice-info') || el.classList.contains('notice-warning')) &&
      text.length > 90 &&
      !matchesAny(OPERATIONAL_TEXT_RE, text)
    ) {
      return true;
    }

    return false;
  }

  function isOperationalNotice(el) {
    el = normalizeEl(el);
    if (!el || !isNoticeElement(el) || hasProtectedClass(el) || hasProtectedContext(el)) {
      return false;
    }

    if (isPromotionalBanner(el)) {
      return false;
    }

    var text = noticeText(el);

    if (
      el.classList.contains('notice-success') ||
      el.classList.contains('updated') ||
      el.classList.contains('notice-error') ||
      el.classList.contains('error')
    ) {
      return text.length > 0;
    }

    if (el.classList.contains('update-nag')) {
      return matchesAny(OPERATIONAL_TEXT_RE, text) || text.length < 120;
    }

    if (matchesAny(OPERATIONAL_TEXT_RE, text) && text.length < 220) {
      return true;
    }

    return false;
  }

  function shouldConvertToToast(el) {
    return isOperationalNotice(el);
  }

  function shouldConvertToNotification(el) {
    return isBannerConversionEnabled() && isPromotionalBanner(el);
  }

  window.yooadminNoticeClassifier = {
    isNoticeElement: isNoticeElement,
    isPromotionalBanner: isPromotionalBanner,
    isOperationalNotice: isOperationalNotice,
    shouldConvertToToast: shouldConvertToToast,
    shouldConvertToNotification: shouldConvertToNotification,
    isBannerConversionEnabled: isBannerConversionEnabled,
    noticeText: noticeText,
  };
})();
