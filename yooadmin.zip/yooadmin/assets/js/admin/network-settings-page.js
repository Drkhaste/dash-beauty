(function () {
  'use strict';

  var root = document.querySelector('.yoo-network-settings-wrap');
  if (!root) {
    return;
  }

  var cfg = window.yooadminNetworkSettings || {};
  var i18n = cfg.i18n || {};
  var toastHideTimer = null;
  var toastRemoveTimer = null;

  function t(key, fallback) {
    return i18n[key] || fallback || '';
  }

  function showToast(message, type) {
    if (!message) {
      return;
    }

    type = type === 'error' ? 'error' : 'success';

    document.querySelectorAll('.yp-toast-message.yoo-network-settings-toast').forEach(function (el) {
      if (el.parentNode) {
        el.parentNode.removeChild(el);
      }
    });

    if (toastHideTimer) {
      clearTimeout(toastHideTimer);
      toastHideTimer = null;
    }
    if (toastRemoveTimer) {
      clearTimeout(toastRemoveTimer);
      toastRemoveTimer = null;
    }

    var iconChar = type === 'error' ? '✕' : '✓';
    var toast = document.createElement('div');
    toast.className = 'yp-toast-message yoo-network-settings-toast yp-toast-' + type;
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');

    var icon = document.createElement('span');
    icon.className = 'yp-toast-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = iconChar;

    var text = document.createElement('span');
    text.className = 'yp-toast-text';
    text.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(text);
    document.body.appendChild(toast);

    window.setTimeout(function () {
      toast.classList.add('yp-toast-show');
    }, 10);

    toastHideTimer = window.setTimeout(function () {
      toast.classList.remove('yp-toast-show');
      toastRemoveTimer = window.setTimeout(function () {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3200);
  }

  function setSaveButtonsBusy(isBusy) {
    var buttons = root.querySelectorAll('#yoo-network-settings-save, #yoo-network-settings-save-mobile');
    buttons.forEach(function (btn) {
      if (!(btn instanceof HTMLButtonElement)) {
        return;
      }

      if (!btn.dataset.defaultHtml) {
        btn.dataset.defaultHtml = btn.innerHTML;
      }

      btn.disabled = isBusy;
      if (isBusy) {
        btn.textContent = btn.getAttribute('data-saving-label') || t('saving', 'Saving…');
      } else {
        btn.innerHTML = btn.dataset.defaultHtml;
      }
    });
  }

  function saveSettings() {
    var form = document.getElementById('yoo-network-settings-form');
    if (!form || !cfg.ajaxUrl || !cfg.action) {
      return;
    }

    setSaveButtonsBusy(true);

    var data = new FormData(form);
    data.set('action', cfg.action);

    fetch(cfg.ajaxUrl, {
      method: 'POST',
      body: data,
      credentials: 'same-origin',
    })
      .then(function (response) {
        return response.json().then(function (payload) {
          return { ok: response.ok, payload: payload };
        });
      })
      .then(function (result) {
        if (result.payload && result.payload.success) {
          showToast(
            (result.payload.data && result.payload.data.message) || t('saved', 'Settings saved.'),
            'success'
          );
          return;
        }

        var message =
          (result.payload && result.payload.data && result.payload.data.message) ||
          t('error', 'Settings could not be saved.');
        showToast(message, 'error');
      })
      .catch(function () {
        showToast(t('generic', 'Something went wrong. Please try again.'), 'error');
      })
      .finally(function () {
        setSaveButtonsBusy(false);
      });
  }

  function initSave() {
    var form = document.getElementById('yoo-network-settings-form');
    if (!form) {
      return;
    }

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      saveSettings();
    });

    root.querySelectorAll('#yoo-network-settings-save, #yoo-network-settings-save-mobile').forEach(function (btn) {
      btn.addEventListener('click', function (event) {
        event.preventDefault();
        saveSettings();
      });
    });

    if (root.getAttribute('data-flash-saved') === '1') {
      var tabInput = document.getElementById('yoo-network-settings-tab-input');
      var flashTab = tabInput && tabInput.value ? tabInput.value : '';
      var flashMessage = flashTab === 'yooadmin'
        ? t('defaultsSaved', 'Network YOOAdmin defaults saved.')
        : t('saved', 'Settings saved.');
      showToast(flashMessage, 'success');
      root.removeAttribute('data-flash-saved');

      if (window.history && window.history.replaceState) {
        var url = new URL(window.location.href);
        url.searchParams.delete('updated');
        window.history.replaceState({}, '', url.toString());
      }
    }
  }

  function initTabs() {
    var wrap = root.querySelector('[data-yp-tabs]');
    if (!wrap) {
      return;
    }

    var nav = wrap.querySelector('.yp-tab-nav');
    if (!nav) {
      return;
    }

    var tabInput = document.getElementById('yoo-network-settings-tab-input');
    var ink = nav.querySelector('.yp-tab-ink');

    if (!ink) {
      ink = document.createElement('span');
      ink.className = 'yp-tab-ink';
      nav.appendChild(ink);
    }

    function moveInk(btn) {
      if (!btn) {
        return;
      }

      var rect = btn.getBoundingClientRect();
      var navRect = nav.getBoundingClientRect();
      ink.style.width = rect.width + 'px';
      ink.style.left = rect.left - navRect.left + 'px';
    }

    function activate(btn, updateUrl) {
      var key = btn.getAttribute('data-tab');
      if (!key) {
        return;
      }

      nav.querySelectorAll('.yp-tab').forEach(function (tabBtn) {
        var isActive = tabBtn === btn;
        tabBtn.classList.toggle('is-active', isActive);
        tabBtn.setAttribute('aria-selected', isActive ? 'true' : 'false');
      });

      wrap.querySelectorAll('.yp-tab-panel').forEach(function (panel) {
        panel.classList.toggle('is-active', panel.getAttribute('data-panel') === key);
      });

      if (tabInput) {
        tabInput.value = key;
      }

      moveInk(btn);

      if (updateUrl !== false && window.history && window.history.replaceState) {
        var url = new URL(window.location.href);
        url.searchParams.set('tab', key);
        window.history.replaceState({}, '', url.toString());
      }
    }

    nav.querySelectorAll('.yp-tab').forEach(function (btn) {
      btn.addEventListener('click', function () {
        activate(btn, true);
      });
    });

    var current = nav.querySelector('.yp-tab.is-active') || nav.querySelector('.yp-tab');
    if (current) {
      activate(current, false);
    }

    window.addEventListener('resize', function () {
      var active = nav.querySelector('.yp-tab.is-active');
      if (active) {
        moveInk(active);
      }
    });
  }

  initTabs();
  initSave();
  initHelpTooltips();

  function initHelpTooltips() {
    var icons = root.querySelectorAll('.yp-help-icon');
    if (!icons.length) {
      return;
    }

    icons.forEach(function (icon) {
      var tooltip = icon.querySelector('.yp-tooltip');
      if (!tooltip) {
        return;
      }

      function positionTooltip() {
        var iconRect = icon.getBoundingClientRect();
        var tooltipWidth = 320;
        var tooltipHeight = tooltip.offsetHeight || 100;
        var left = iconRect.left + iconRect.width / 2 - tooltipWidth / 2;
        var top = iconRect.top - tooltipHeight - 8;

        if (left < 20) {
          left = 20;
        }
        if (left + tooltipWidth > window.innerWidth - 20) {
          left = window.innerWidth - tooltipWidth - 20;
        }
        if (top < 20) {
          top = iconRect.bottom + 8;
        }

        tooltip.style.position = 'fixed';
        tooltip.style.left = left + 'px';
        tooltip.style.top = top + 'px';
        tooltip.style.bottom = 'auto';
        tooltip.style.transform = 'none';
        tooltip.style.display = 'block';
        tooltip.style.opacity = '1';
        tooltip.style.zIndex = '999999';
      }

      function hideTooltip() {
        tooltip.style.display = 'none';
        tooltip.style.opacity = '0';
      }

      icon.addEventListener('mouseenter', positionTooltip);
      icon.addEventListener('focusin', positionTooltip);
      icon.addEventListener('mouseleave', hideTooltip);
      icon.addEventListener('focusout', hideTooltip);
    });
  }
})();
