/**
 * YOOAdmin - Tags page script
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        $('.yoo-tags-metrics-toggle').on('click', function() {
            const $btn = $(this);
            const $metrics = $('.yoo-tags-hero__metrics');
            const isExpanded = $btn.attr('aria-expanded') === 'true';
            
            if (isExpanded) {
                $metrics.stop().slideUp(300, function() {
                    $(this).css('display', 'none');
                });
                $btn.attr('aria-expanded', 'false');
                $btn.find('.dashicons').removeClass('dashicons-arrow-up-alt').addClass('dashicons-arrow-down-alt');
                $btn.find('span:last').text('Show Statistics');
            } else {
                $metrics.css('display', 'flex').hide().stop().slideDown(300);
                $btn.attr('aria-expanded', 'true');
                $btn.find('.dashicons').removeClass('dashicons-arrow-down-alt').addClass('dashicons-arrow-up-alt');
                $btn.find('span:last').text('Hide Statistics');
            }
        });

        $('.yoo-filter-chip').on('click', function(e) {
            e.preventDefault();
            
            const $chip = $(this);
            const filter = $chip.attr('href').includes('show=with-posts') ? 'with-posts' : 
                          $chip.attr('href').includes('show=empty') ? 'empty' : 'all';
            
            $('.yoo-filter-chip').removeClass('is-active');
            $chip.addClass('is-active');
            
            const $tags = $('.yoo-tag-card');
            
            if (filter === 'all') {
                $tags.fadeIn(200);
            } else if (filter === 'with-posts') {
                $tags.each(function() {
                    const count = parseInt($(this).data('posts-count')) || 0;
                    $(this).toggle(count > 0);
                });
            } else if (filter === 'empty') {
                $tags.each(function() {
                    const count = parseInt($(this).data('posts-count')) || 0;
                    $(this).toggle(count === 0);
                });
            }
        });

        // Add Category Modal
        $('#yoo-add-tag-btn, #yoo-add-first-tag-btn').on('click', function() {
            $('#yoo-add-tag-modal').addClass('is-active');
        });

        $('#yoo-tag-modal-close, #yoo-tag-modal-cancel').on('click', function() {
            $('#yoo-add-tag-modal').removeClass('is-active');
            $('#yoo-add-tag-form')[0].reset();
        });

        var slugManuallyEdited = false;
        
        $('#yoo-tag-name').on('input', function() {
            if (!slugManuallyEdited) {
                var slug = $(this).val()
                    .toLowerCase()
                    .replace(/[^a-z0-9\u0621-\u064A]+/g, '-')
                    .replace(/^-+|-+$/g, '');
                $('#yoo-tag-slug').val(slug);
            }
        });
        
        $('#yoo-tag-slug').on('input', function() {
            slugManuallyEdited = true;
        });
        
        // Reset flag when modal closes
        $('#yoo-tag-modal-close, #yoo-tag-modal-cancel').on('click', function() {
            slugManuallyEdited = false;
        });

        // Success popup
        function showSuccessPopup(message) {
            var $popup = $(
                '<div class="yoo-tag-popup-overlay">' +
                    '<div class="yoo-tag-popup">' +
                        '<div class="yoo-tag-popup-icon success">' +
                            '<span class="dashicons dashicons-yes-alt"></span>' +
                        '</div>' +
                        '<h3>Success!</h3>' +
                        '<p>' + message + '</p>' +
                        '<div class="yoo-tag-popup-actions">' +
                            '<button class="yoo-tag-popup-btn yoo-tag-popup-ok">OK</button>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
            
            $('body').append($popup);
            setTimeout(function() { $popup.addClass('visible'); }, 10);
            
            $popup.find('.yoo-tag-popup-ok').on('click', function() {
                $popup.removeClass('visible');
                setTimeout(function() {
                    $popup.remove();
                    location.reload();
                }, 300);
            });
        }

        // Delete confirmation popup
        function showDeleteConfirmPopup(tagId, tagName) {
            var $popup = $(
                '<div class="yoo-tag-popup-overlay">' +
                    '<div class="yoo-tag-popup">' +
                        '<div class="yoo-tag-popup-icon warning">' +
                            '<span class="dashicons dashicons-warning"></span>' +
                        '</div>' +
                        '<h3>Delete Category?</h3>' +
                        '<p>Are you sure you want to delete <strong>' + tagName + '</strong>? This action cannot be undone.</p>' +
                        '<div class="yoo-tag-popup-actions">' +
                            '<button class="yoo-tag-popup-btn yoo-tag-popup-cancel">Cancel</button>' +
                            '<button class="yoo-tag-popup-btn yoo-tag-popup-delete">Delete</button>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
            
            $('body').append($popup);
            setTimeout(function() { $popup.addClass('visible'); }, 10);
            
            $popup.find('.yoo-tag-popup-cancel').on('click', function() {
                $popup.removeClass('visible');
                setTimeout(function() { $popup.remove(); }, 300);
            });
            
            $popup.find('.yoo-tag-popup-delete').on('click', function() {
                var $deleteBtn = $(this);
                $deleteBtn.prop('disabled', true).text('Deleting...');
                
                $.ajax({
                    url: yooadmTags.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'yooadmin_tags_action',
                        tag_action: 'delete',
                        tag_id: tagId,
                        nonce: yooadmTags.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $popup.removeClass('visible');
                            setTimeout(function() {
                                $popup.remove();
                                showSuccessPopup(response.data.message || 'Category deleted successfully!');
                            }, 300);
                        } else {
                            alert(response.data.message || 'Failed to delete tag.');
                            $deleteBtn.prop('disabled', false).text('Delete');
                        }
                    },
                    error: function() {
                        alert('An error occurred. Please try again.');
                        $deleteBtn.prop('disabled', false).text('Delete');
                    }
                });
            });
        }

        // Handle form submission
        $('#yoo-add-tag-form').on('submit', function(e) {
            e.preventDefault();

            var $form = $(this);
            var $submitBtn = $form.find('button[type="submit"]');
            var originalText = $submitBtn.text();

            $submitBtn.prop('disabled', true).text('Adding...');

            $.ajax({
                url: yooadmTags.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_add_tag',
                    name: $('#yoo-tag-name').val(),
                    slug: $('#yoo-tag-slug').val(),
                    description: $('#yoo-tag-description').val(),
                    nonce: yooadmTags.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $('#yoo-add-tag-modal').removeClass('is-active');
                        setTimeout(function() {
                            showSuccessPopup(response.data.message || 'Category added successfully!');
                        }, 300);
                    } else {
                        alert(response.data.message || 'Failed to add tag.');
                        $submitBtn.prop('disabled', false).text(originalText);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            });
        });


        // Bulk actions
        var $checkboxes = $('.yoo-tag-checkbox');
        var $selectAll = $('#yoo-select-all-tags');
        var $bulkBar = $('.yoo-bulk-actions-bar');
        var $selectedCount = $('.yoo-selected-count');
        var $bulkApply = $('#yoo-bulk-apply');
        var $bulkSelect = $('#yoo-bulk-action-select');

        function updateBulkBar() {
            var selected = $checkboxes.filter(':checked:not(:disabled)').length;
            if (selected > 0) {
                $bulkBar.addClass('show');
                $selectedCount.text(selected + ' ' + (yooadmTags.i18n.selected || 'selected'));
                $bulkApply.prop('disabled', !$bulkSelect.val());
            } else {
                $bulkBar.removeClass('show');
            }
        }

        $checkboxes.on('change', updateBulkBar);
        $selectAll.on('change', function() {
            $checkboxes.filter(':not(:disabled)').prop('checked', $(this).prop('checked'));
            updateBulkBar();
        });

        $bulkSelect.on('change', function() {
            $bulkApply.prop('disabled', !$(this).val());
        });

        // Individual actions
        $(document).on('click', '.yoo-action-btn.delete', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var tagId = $btn.data('tag-id');
            var tagName = $btn.data('tag-name');
            
            showDeleteConfirmPopup(tagId, tagName);
        });

        // Bulk apply
        $bulkApply.on('click', function() {
            var action = $bulkSelect.val();
            if (!action) return;

            var selected = $checkboxes.filter(':checked:not(:disabled)').map(function() {
                return $(this).val();
            }).get();

            if (selected.length === 0) return;

            $.ajax({
                url: yooadmTags.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'yooadmin_bulk_tags_action',
                    bulk_action: action,
                    tags: selected,
                    nonce: yooadmTags.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.data.message || 'Error occurred');
                    }
                }
            });
        });
    });
})(jQuery);






















