(function ($) {
  'use strict';

  $(function () {
    var $root = $('.yoo-network-site-editor-users');
    if (!$root.length) {
      return;
    }

    var cfg = window.yooNetworkSiteUsers || {};
    var blogId = parseInt($root.data('blogId') || cfg.blogId || 0, 10);
    var $form = $('#yoo-network-site-users-form');
    var $bulkBar = $('#yoo-network-site-users-bulk-bar');
    var $selectAll = $('#yoo-network-site-select-all-users');
    var $selectedCount = $bulkBar.find('.yoo-selected-count');
    var $bulkAction = $('#yoo-network-site-users-bulk-action');
    var $roleSelect = $('#yoo-network-site-users-new-role');
    var $bulkApply = $('#yoo-network-site-users-bulk-apply');
    var $content = $('#yoo-network-site-users-content');
    var $loading = $('#yoo-network-site-users-loading');
    var $filters = $('#yoo-network-site-users-role-filters .yoo-filter-chip');
    var $search = $('#yoo-network-site-users-search');
    var $totalLabel = $('#yoo-network-site-users-total-label');
    var $reset = $('#yoo-network-site-users-reset');
    var searchTimer = null;
    var activeRequest = null;

    $('.yoo-network-site-users-modal').each(function () {
      if (this.parentNode !== document.body) {
        document.body.appendChild(this);
      }
    });

    function t(key, fallback) {
      return cfg[key] || fallback;
    }

    function initUiSelects(root) {
      if (!window.yooadminUiSelect) {
        return;
      }
      if (typeof window.yooadminUiSelect.initIn === 'function') {
        window.yooadminUiSelect.initIn(root || $root[0]);
      }
    }

    function currentRole() {
      return $filters.filter('.is-active').data('role') || '';
    }

    function currentSearch() {
      return $.trim($search.val() || '');
    }

    function pageSlug() {
      return cfg.pageSlug || 'yooadmin-network-site-users';
    }

    function pushUrl(role, search, paged) {
      var url = new URL(window.location.href);
      url.searchParams.set('page', pageSlug());
      url.searchParams.set('id', String(blogId));
      url.searchParams.set('paged', String(paged || 1));
      if (role) {
        url.searchParams.set('role', role);
      } else {
        url.searchParams.delete('role');
      }
      if (search) {
        url.searchParams.set('s', search);
      } else {
        url.searchParams.delete('s');
      }
      window.history.pushState({}, '', url.toString());
    }

    function setLoading(isLoading) {
      if (isLoading) {
        $loading.removeAttr('hidden');
        $content.attr('aria-busy', 'true');
      } else {
        $loading.attr('hidden', 'hidden');
        $content.removeAttr('aria-busy');
      }
    }

    function loadUsers(options) {
      options = options || {};
      var role = options.role !== undefined ? options.role : currentRole();
      var search = options.search !== undefined ? options.search : currentSearch();
      var paged = options.paged || 1;

      if (activeRequest) {
        activeRequest.abort();
      }

      setLoading(true);
      pushUrl(role, search, paged);

      activeRequest = $.ajax({
        url: cfg.ajaxUrl || ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: {
          action: 'yooadmin_network_site_users_filter',
          nonce: cfg.nonce,
          id: blogId,
          role: role,
          s: search,
          paged: paged
        }
      })
        .done(function (response) {
          if (response && response.success && response.data && response.data.html !== undefined) {
            $content.html(response.data.html);
            if (response.data.total_label && $totalLabel.length) {
              $totalLabel.text(response.data.total_label);
            }
            if ($reset.length) {
              if (response.data.has_filters) {
                $reset.removeAttr('hidden');
              } else {
                $reset.attr('hidden', 'hidden');
              }
            }
            updateBulkBar();
          } else {
            window.alert(
              response && response.data && response.data.message
                ? response.data.message
                : t('loadError', 'Error loading users.')
            );
          }
        })
        .fail(function (_xhr, status) {
          if (status !== 'abort') {
            window.alert(t('loadError', 'Error loading users. Please refresh the page.'));
          }
        })
        .always(function () {
          activeRequest = null;
          setLoading(false);
        });
    }

    function ensureModalPortaled($modal) {
      if ($modal.length && $modal[0].parentNode !== document.body) {
        document.body.appendChild($modal[0]);
      }
    }

    function openModal(id) {
      var $modal = $('#yoo-network-site-' + id + '-modal');
      if (!$modal.length) {
        return;
      }
      ensureModalPortaled($modal);
      $modal.removeAttr('hidden');
      $('body').addClass('yoo-network-site-users-modal-open yp-modal-open');
      initUiSelects($modal[0]);
      var $focus = $modal.find('.yp-modal-body input[type="text"], .yp-modal-body input[type="email"]').filter(':visible').first();
      if ($focus.length) {
        $focus.trigger('focus');
      }
    }

    function closeModals() {
      if (window.yooadminUiSelect && typeof window.yooadminUiSelect.closeOpen === 'function') {
        window.yooadminUiSelect.closeOpen();
      }
      $('.yoo-network-site-users-modal').attr('hidden', 'hidden');
      $('body').removeClass('yoo-network-site-users-modal-open yp-modal-open');
    }

    function getRoleSelectEl() {
      if (!$roleSelect.length) {
        return $();
      }
      var $wrap = $roleSelect.closest('.yp-ui-select');
      return $wrap.length ? $wrap : $roleSelect;
    }

    function submitBulkForm() {
      if (!$form.length || !$form[0]) {
        return;
      }
      $form[0].submit();
    }

    function setRoleSelectVisible(show) {
      var $target = getRoleSelectEl();
      if (!$target.length) {
        return;
      }
      if (show) {
        $target.removeClass('yoo-network-site-users-role-field--hidden').show();
        initUiSelects($bulkBar[0]);
      } else {
        if (window.yooadminUiSelect && typeof window.yooadminUiSelect.closeOpen === 'function') {
          window.yooadminUiSelect.closeOpen();
        }
        $target.addClass('yoo-network-site-users-role-field--hidden').hide();
      }
    }

    function updateBulkBar() {
      var $checked = $content.find('.yoo-user-checkbox:checked');
      var count = $checked.length;
      var action = $bulkAction.val();

      if (count > 0) {
        $bulkBar.slideDown(200);
        $selectedCount.text(
          count + ' ' + (count === 1 ? t('selectedSingular', 'selected') : t('selectedPlural', 'selected'))
        );
        $bulkApply.prop('disabled', !action || action === '-1');

        var total = $content.find('.yoo-user-checkbox').length;
        $selectAll.prop('checked', count === total);
        $selectAll.prop('indeterminate', count > 0 && count < total);
      } else {
        $bulkBar.slideUp(200);
        $bulkApply.prop('disabled', true);
        $selectAll.prop('checked', false).prop('indeterminate', false);
      }

      if ($roleSelect.length) {
        setRoleSelectVisible(count > 0 && action === 'promote');
      }

      $content.find('.yoo-user-card').each(function () {
        var $card = $(this);
        $card.toggleClass('selected', $card.find('.yoo-user-checkbox').is(':checked'));
      });
    }

    function showConfirm(message, onConfirm) {
      if (typeof window.yooadminConfirmDialog === 'function') {
        window.yooadminConfirmDialog({
          title: t('confirmTitle', 'Confirm action'),
          message: message,
          cancelLabel: t('cancel', 'Cancel'),
          confirmLabel: t('confirm', 'Confirm'),
          onConfirm: onConfirm
        });
        return;
      }
      if (window.confirm(message)) {
        onConfirm();
      }
    }

    function getRemovableChecked() {
      return $content.find('.yoo-user-checkbox:checked:not(:disabled)');
    }

    $root.on('click', '[data-yoo-network-site-open-modal]', function () {
      openModal($(this).data('yooNetworkSiteOpenModal'));
    });

    $(document).on('click', '.yoo-network-site-users-modal__overlay', function (e) {
      if (e.target === this) {
        closeModals();
      }
    });

    $(document).on('click', '.yoo-network-site-users-modal .yp-modal-close, .yoo-network-site-users-modal button[data-yoo-network-site-close-modal]', function (e) {
      e.preventDefault();
      closeModals();
    });

    $(document).on('keydown', function (e) {
      if (e.key === 'Escape') {
        if ($('.yoo-network-site-users-confirm').length) {
          $('.yoo-network-site-users-confirm').remove();
          $('body').removeClass('yoo-network-site-users-modal-open yp-modal-open');
          return;
        }
        closeModals();
      }
    });

    $filters.on('click', function () {
      var $chip = $(this);
      var role = $chip.data('role') || '';

      $filters.removeClass('is-active');
      $chip.addClass('is-active');
      loadUsers({ role: role, search: currentSearch(), paged: 1 });
    });

    $search.on('input', function () {
      window.clearTimeout(searchTimer);
      searchTimer = window.setTimeout(function () {
        loadUsers({ role: currentRole(), search: currentSearch(), paged: 1 });
      }, 350);
    });

    $search.on('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        window.clearTimeout(searchTimer);
        loadUsers({ role: currentRole(), search: currentSearch(), paged: 1 });
      }
    });

    $reset.on('click', function (e) {
      e.preventDefault();
      $search.val('');
      $filters.removeClass('is-active');
      $filters.filter('[data-role=""]').addClass('is-active');
      loadUsers({ role: '', search: '', paged: 1 });
    });

    $content.on('click', '.yoo-users-pagination a', function (e) {
      e.preventDefault();
      var href = $(this).attr('href');
      if (!href) {
        return;
      }
      var url = new URL(href, window.location.origin);
      loadUsers({
        role: url.searchParams.get('role') || '',
        search: url.searchParams.get('s') || '',
        paged: parseInt(url.searchParams.get('paged') || '1', 10)
      });
    });

    $selectAll.on('change', function () {
      var checked = $(this).is(':checked');
      $content.find('.yoo-user-checkbox:not(:disabled)').prop('checked', checked);
      updateBulkBar();
    });

    $content.on('change', '.yoo-user-checkbox', updateBulkBar);
    $bulkAction.on('change', updateBulkBar);

    $bulkApply.on('click', function () {
      var action = $bulkAction.val();
      if (!action || action === '-1') {
        return;
      }

      var $removable = getRemovableChecked();
      var count = $removable.length;
      if (!count) {
        if (action === 'remove' && $content.find('.yoo-user-checkbox:checked').length) {
          window.alert(t('superAdminProtected', 'Network super admins cannot be removed from a site.'));
        }
        return;
      }

      if (action === 'remove') {
        $content.find('.yoo-user-checkbox:checked:disabled').prop('checked', false);
        showConfirm(t('removeConfirm', 'Remove the selected users from this site?'), function () {
          submitBulkForm();
        });
        return;
      }

      if (action === 'promote') {
        if ($roleSelect.length && !$roleSelect.val()) {
          window.alert(t('selectRole', 'Select a role.'));
          return;
        }
        submitBulkForm();
      }
    });

    initUiSelects($root[0]);
    $('.yoo-network-site-users-modal').each(function () {
      initUiSelects(this);
    });

    updateBulkBar();
  });
})(jQuery);
