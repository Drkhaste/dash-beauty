(function () {
	'use strict';

	var wrapTimer = null;

	function isDesktopIntegrationActive() {
		var body = document.body;
		if (!body || !body.classList.contains('yoo-focus')) {
			return false;
		}

		return body.classList.contains('desktop-mode-active')
			|| body.classList.contains('desktop-mode-chromeless');
	}

	function isSidebarMenuLink(link) {
		return link && !!link.closest('#yps-sidebar, .yps-sidebar, .yps-nav, #adminmenu, #adminmenuwrap');
	}

	function isDesktopModeUiElement(el) {
		return el && !!el.closest(
			'#desktop-mode-shell, #desktop-mode-side-dock, .desktop-mode-dock, .desktop-mode-icons, .desktop-mode-icon'
		);
	}

	function isYooadminSubmenuPopupLink(link) {
		if (!link || link.tagName !== 'A' || !link.hasAttribute('data-menu-slug')) {
			return false;
		}

		return !isSidebarMenuLink(link) && !isDesktopModeUiElement(link);
	}

	function shouldBypassSubmenuPopup(link) {
		return link && isDesktopIntegrationActive() && isYooadminSubmenuPopupLink(link);
	}

	function suppressPopup() {
		if (typeof window.ypClosePopup === 'function') {
			window.ypClosePopup();
		}

		var popup = document.getElementById('yp-popup');
		if (popup) {
			popup.style.display = 'none';
			popup.classList.remove('is-ysh-popup-loading');
			popup.removeAttribute('data-parent-icon');
		}

		document.documentElement.classList.remove('yoo-popup-open');
	}

	function navigateLink(link) {
		if (!link) {
			return;
		}

		var href = link.getAttribute('href') || '';
		if (!href || href === '#' || href.indexOf('javascript:') === 0) {
			return;
		}

		var target = (link.getAttribute('target') || '').toLowerCase();
		if (target === '_blank') {
			window.open(link.href, '_blank', 'noopener,noreferrer');
			return;
		}

		window.location.assign(link.href);
	}

	function wrapYpShowPopup() {
		var current = window.ypShowPopup;
		if (typeof current !== 'function') {
			return false;
		}
		if (current.__yooadminDesktopPopupGuardWrapped) {
			return true;
		}

		window.ypShowPopup = function () {
			if (isDesktopIntegrationActive()) {
				suppressPopup();
				return;
			}

			return current.apply(this, arguments);
		};
		window.ypShowPopup.__yooadminDesktopPopupGuardWrapped = true;

		return true;
	}

	function maintainPopupWrap() {
		if (!isDesktopIntegrationActive()) {
			return;
		}

		wrapYpShowPopup();
	}

	function startPopupWrapLoop() {
		if (wrapTimer) {
			window.clearInterval(wrapTimer);
		}

		maintainPopupWrap();
		wrapTimer = window.setInterval(maintainPopupWrap, 80);
		window.setTimeout(function () {
			if (wrapTimer) {
				window.clearInterval(wrapTimer);
				wrapTimer = null;
			}
		}, 10000);
	}

	function bindDirectNavigationGuard() {
		if (document.documentElement.getAttribute('data-yooadmin-desktop-popup-guard') === '1') {
			return;
		}

		document.documentElement.setAttribute('data-yooadmin-desktop-popup-guard', '1');
		document.addEventListener('click', function (e) {
			var link = e.target && e.target.closest ? e.target.closest('a[data-menu-slug]') : null;
			if (!shouldBypassSubmenuPopup(link)) {
				return;
			}

			if (typeof e.stopImmediatePropagation === 'function') {
				e.stopImmediatePropagation();
			}
			e.stopPropagation();
			e.preventDefault();

			suppressPopup();
			navigateLink(link);
		}, true);
	}

	function watchPopupVisibility() {
		var popup = document.getElementById('yp-popup');
		if (!popup || popup.__yooadminDesktopPopupWatch) {
			return;
		}

		var observer = new MutationObserver(function () {
			if (!isDesktopIntegrationActive()) {
				return;
			}
			if (document.documentElement.classList.contains('yoo-popup-open') || popup.style.display === 'flex') {
				suppressPopup();
			}
		});

		observer.observe(popup, { attributes: true, attributeFilter: ['style', 'class'] });
		observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
		popup.__yooadminDesktopPopupWatch = true;
	}

	function boot() {
		if (!isDesktopIntegrationActive()) {
			return;
		}

		suppressPopup();
		startPopupWrapLoop();
		bindDirectNavigationGuard();
		watchPopupVisibility();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}

	window.addEventListener('load', boot);
})();
