(function ($) {
  'use strict';

  var PORTAL_ID = 'yoo-wp-settings-tooltip-portal';
  var cfg = window.yooWpSettingsExperience || {};
  var bootStarted = false;
  var TITLE_ICONS = {
    'options-general': 'dashicons-admin-settings',
    'options-reading': 'dashicons-book',
    'options-writing': 'dashicons-edit',
    'options-discussion': 'dashicons-admin-comments',
    'options-media': 'dashicons-admin-media',
    'options-permalink': 'dashicons-admin-links',
    'options-privacy': 'dashicons-shield',
    'options-connectors': 'dashicons-networking',
    'settings_page_ai-wp-admin': 'dashicons-superhero-alt',
    'font-library': 'dashicons-editor-textcolor',
    tools: 'dashicons-admin-tools',
    import: 'dashicons-download',
    export: 'dashicons-upload',
    'site-health': 'dashicons-heart',
    'export-personal-data': 'dashicons-download',
    'erase-personal-data': 'dashicons-trash',
    'theme-editor': 'dashicons-editor-code',
    'plugin-editor': 'dashicons-editor-code',
    network: 'dashicons-admin-site-alt3',
  };

  var TOOLS_CORE_SCREENS = {
    tools: 1,
    import: 1,
    export: 1,
    'site-health': 1,
    'export-personal-data': 1,
    'erase-personal-data': 1,
    'theme-editor': 1,
    'plugin-editor': 1,
    network: 1,
  };

  function isToolsScreen() {
    var screen = cfg.screen || '';
    if (TOOLS_CORE_SCREENS[screen]) {
      return true;
    }
    return screen.indexOf('tools_page_') === 0;
  }

  function getBootLayoutAppId() {
    if (cfg.bootLayoutAppId) {
      return cfg.bootLayoutAppId;
    }
    var content = document.getElementById('wpbody-content');
    if (!content) {
      return '';
    }
    var mount =
      content.querySelector(':scope > .boot-layout-container[id$="-wp-admin-app"]') ||
      content.querySelector(':scope > [id$="-wp-admin-app"].boot-layout-container') ||
      content.querySelector(':scope > [id$="-wp-admin-app"]');
    return mount && mount.id ? mount.id : '';
  }

  function isBootLayoutScreen() {
    return !!getBootLayoutAppId();
  }

  function getBootLayoutApp() {
    var appId = getBootLayoutAppId();
    return appId ? document.getElementById(appId) : null;
  }

  function ensureBootLayoutWrap(app) {
    var content = document.getElementById('wpbody-content');
    if (!content) {
      return null;
    }
    var wrap =
      content.querySelector(':scope > .wrap.yp-wp-settings-boot-layout-wrap') ||
      content.querySelector(':scope > .wrap');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.className = 'wrap yp-wp-settings-boot-layout-wrap';
      if (app && app.parentNode === content) {
        content.insertBefore(wrap, app);
      } else {
        content.insertBefore(wrap, content.firstChild);
      }
    } else {
      wrap.classList.add('yp-wp-settings-boot-layout-wrap');
    }
    if (app && app.parentNode !== wrap) {
      wrap.appendChild(app);
    }
    hideBootLayoutShellChrome(wrap);
    return wrap;
  }

  function hideBootLayoutShellChrome(wrap) {
    if (!wrap) {
      return;
    }
    wrap.querySelectorAll(':scope > h1, :scope > .yp-wp-settings-boot-layout-intro').forEach(function (el) {
      el.setAttribute('aria-hidden', 'true');
      el.style.display = 'none';
    });
  }

  function toolsTitleIcon() {
    var screen = cfg.screen || '';
    if (TITLE_ICONS[screen]) {
      return TITLE_ICONS[screen];
    }
    if (screen.indexOf('tools_page_') === 0) {
      return 'dashicons-admin-tools';
    }
    return 'dashicons-admin-tools';
  }

  function wrapThContent(th) {
    if (!th || th.querySelector('.yp-th-content')) {
      return;
    }
    var wrap = document.createElement('div');
    wrap.className = 'yp-th-content';
    var nodes = [];
    while (th.firstChild) {
      nodes.push(th.firstChild);
      th.removeChild(th.firstChild);
    }
    nodes.forEach(function (node) {
      wrap.appendChild(node);
    });
    th.appendChild(wrap);
  }

  function ensureHelpInTh(row, text) {
    if (!text) {
      return;
    }
    var th = row.querySelector('th');
    if (!th || th.querySelector('.yp-help-icon')) {
      return;
    }
    wrapThContent(th);

    var icon = document.createElement('span');
    icon.className = 'yp-help-icon';
    icon.setAttribute('role', 'button');
    icon.setAttribute('tabindex', '0');
    icon.setAttribute('aria-label', text);

    var glyph = document.createElement('span');
    glyph.className = 'dashicons dashicons-editor-help';
    glyph.setAttribute('aria-hidden', 'true');

    var tip = document.createElement('span');
    tip.className = 'yp-tooltip';
    tip.setAttribute('hidden', 'hidden');
    tip.textContent = text;

    icon.appendChild(glyph);
    icon.appendChild(tip);

    var content = th.querySelector('.yp-th-content') || th;
    content.appendChild(icon);
  }

  function collectDescriptionNodes(td) {
    var nodes = [];
    if (!td) {
      return nodes;
    }
    td.querySelectorAll(
      ':scope > p.description, :scope > .description, :scope > p.timezone-info, fieldset > p.description, fieldset > .description'
    ).forEach(function (node) {
      nodes.push(node);
    });
    var fieldset = td.querySelector('fieldset');
    if (fieldset) {
      fieldset.querySelectorAll(':scope > p').forEach(function (p) {
        if (p.classList.contains('description') || nodes.indexOf(p) >= 0) {
          return;
        }
        if (p.querySelector('label, input, textarea, select')) {
          return;
        }
        var text = (p.textContent || '').replace(/\s+/g, ' ').trim();
        if (text.length >= 48) {
          nodes.push(p);
        }
      });
    }
    return nodes;
  }

  function ensureHelpOnSectionHead(headWrap, text) {
    if (!headWrap || !text || headWrap.querySelector('.yp-help-icon')) {
      return;
    }
    var icon = document.createElement('span');
    icon.className = 'yp-help-icon';
    icon.setAttribute('role', 'button');
    icon.setAttribute('tabindex', '0');
    icon.setAttribute('aria-label', text);
    var glyph = document.createElement('span');
    glyph.className = 'dashicons dashicons-editor-help';
    glyph.setAttribute('aria-hidden', 'true');
    var tip = document.createElement('span');
    tip.className = 'yp-tooltip';
    tip.setAttribute('hidden', 'hidden');
    tip.textContent = text;
    icon.appendChild(glyph);
    icon.appendChild(tip);
    headWrap.appendChild(icon);
  }

  function moveDescriptionsToTooltips(root) {
    if (!root) {
      return;
    }
    root.querySelectorAll('.form-table tr').forEach(function (row) {
      var td = row.querySelector('td');
      if (!td) {
        return;
      }
      var descNodes = collectDescriptionNodes(td);
      if (!descNodes.length) {
        return;
      }
      var text = Array.from(descNodes)
        .map(function (node) {
          return (node.textContent || '').replace(/\s+/g, ' ').trim();
        })
        .filter(Boolean)
        .join(' ');
      if (!text) {
        return;
      }
      ensureHelpInTh(row, text);
      descNodes.forEach(function (node) {
        node.setAttribute('aria-hidden', 'true');
        node.style.display = 'none';
      });
    });
    root.querySelectorAll('.form-table th').forEach(wrapThContent);
  }

  function moveSectionIntrosToTooltips(root) {
    if (!root) {
      return;
    }
    root.querySelectorAll('.yp-wp-settings-media-section-intro').forEach(function (intro) {
      var block = intro.closest(
        '.yp-wp-settings-section-block, .yp-wp-settings-writing-subsection, .yp-wp-settings-media-section, .yp-wp-settings-media-uploads-wrap'
      );
      var head = block && block.querySelector('.yp-wp-settings-media-section-head');
      if (!head) {
        return;
      }
      var text = (intro.textContent || '').replace(/\s+/g, ' ').trim();
      if (!text) {
        return;
      }
      ensureHelpOnSectionHead(head, text);
      intro.setAttribute('aria-hidden', 'true');
      intro.style.display = 'none';
    });
  }

  function enhancePageTitle() {
    if (isBootLayoutScreen()) {
      return;
    }
    var h1 = document.querySelector(
      '.wrap > h1, .yp-wp-settings-header > h1, .privacy-settings-title-section h1, .yp-wp-settings-privacy-card-head h1'
    );
    if (!h1 || h1.querySelector('.yp-wp-settings-title-icon')) {
      return;
    }
    h1.classList.add('yp-wp-settings-page-title');
    var icon = document.createElement('span');
    var iconClass = isToolsScreen()
      ? toolsTitleIcon()
      : TITLE_ICONS[cfg.screen] || 'dashicons-admin-settings';
    icon.className = 'dashicons ' + iconClass + ' yp-wp-settings-title-icon';
    icon.setAttribute('aria-hidden', 'true');
    h1.insertBefore(icon, h1.firstChild);
  }

  function ensureSettingsFormId(form) {
    if (!form) {
      return '';
    }
    if (!form.id) {
      form.id = 'yp-wp-settings-form';
    }
    return form.id;
  }

  function getWpSettingsSaveBtn() {
    return document.querySelector('.yp-wp-settings-save-btn');
  }

  function setWpSettingsSaveBtnState(btn, state) {
    if (!btn) {
      return;
    }
    var icon = btn.querySelector('.yp-wp-settings-save-icon');
    var labelNode = btn.querySelector('.yp-wp-settings-save-label');
    var i18n = cfg.i18n || {};
    var idleLabel = btn.dataset.ypSaveLabel || i18n.save || 'Save Changes';

    btn.classList.remove('is-saving', 'is-saved');
    btn.disabled = state === 'saving';

    if (state === 'saving') {
      btn.classList.add('is-saving');
      if (icon) {
        icon.className = 'dashicons dashicons-update yp-wp-settings-save-icon';
      }
      if (labelNode) {
        labelNode.textContent = i18n.saving || 'Saving…';
      }
      return;
    }

    if (state === 'saved') {
      btn.classList.add('is-saved');
      if (icon) {
        icon.className = 'dashicons dashicons-yes yp-wp-settings-save-icon';
      }
      if (labelNode) {
        labelNode.textContent = i18n.saved || 'Saved';
      }
      window.setTimeout(function () {
        setWpSettingsSaveBtnState(btn, 'idle');
      }, 2200);
      return;
    }

    if (icon) {
      icon.className = 'dashicons dashicons-saved yp-wp-settings-save-icon';
    }
    if (labelNode) {
      labelNode.textContent = idleLabel;
    }
  }

  function showWpSettingsToast(message, type) {
    if (window.yooadmToast) {
      if (type === 'error' && typeof window.yooadmToast.error === 'function') {
        window.yooadmToast.error(message);
        return;
      }
      if (typeof window.yooadmToast.success === 'function' && type !== 'error') {
        window.yooadmToast.success(message);
        return;
      }
      if (typeof window.yooadmToast.show === 'function') {
        window.yooadmToast.show(message, type || 'success');
        return;
      }
    }
  }

  function ajaxSaveWpSettingsForm(form, submitter) {
    var btn = getWpSettingsSaveBtn();
    if (!form || (btn && btn.disabled)) {
      return Promise.resolve();
    }

    var i18n = cfg.i18n || {};
    var formData = new FormData(form);
    if (submitter && submitter.name) {
      formData.set(submitter.name, submitter.value || '1');
    }

    setWpSettingsSaveBtnState(btn, 'saving');

    var action =
      form.getAttribute('action') ||
      cfg.optionsUrl ||
      (typeof window.ajaxurl === 'string'
        ? window.ajaxurl.replace('admin-ajax.php', 'options.php')
        : 'options.php');

    return fetch(action, {
      method: 'POST',
      body: formData,
      credentials: 'same-origin',
      redirect: 'follow',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
      },
    })
      .then(function (res) {
        return res.text().then(function (html) {
          var url = res.url || '';
          var ok =
            url.indexOf('settings-updated=true') !== -1 ||
            url.indexOf('updated=true') !== -1;
          if (!ok && html) {
            ok =
              html.indexOf('settings-updated') !== -1 &&
              html.indexOf('notice-error') === -1 &&
              html.indexOf('error notice') === -1;
          }
          if (!ok) {
            throw new Error('save_failed');
          }
        });
      })
      .then(function () {
        setWpSettingsSaveBtnState(btn, 'saved');
        showWpSettingsToast(i18n.saved || 'Settings saved.', 'success');
      })
      .catch(function () {
        setWpSettingsSaveBtnState(btn, 'idle');
        showWpSettingsToast(
          i18n.error || 'Could not save settings. Please try again.',
          'error'
        );
      });
  }

  function initAjaxFormSave(form) {
    if (
      !form ||
      form.dataset.ypAjaxSave === '1' ||
      isToolsDownloadForm(form) ||
      isPrivacyToolsRequestForm(form)
    ) {
      return;
    }
    form.dataset.ypAjaxSave = '1';

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      ajaxSaveWpSettingsForm(form, e.submitter || getWpSettingsSaveBtn());
    });

    var btn = getWpSettingsSaveBtn();
    if (btn && !form.contains(btn) && btn.dataset.ypSaveWired !== '1') {
      btn.dataset.ypSaveWired = '1';
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        ajaxSaveWpSettingsForm(form, btn);
      });
    }
  }

  function enhanceSaveButton(submit, form) {
    if (!submit || submit.dataset.ypSaveEnhanced === '1') {
      return;
    }
    var input = submit.querySelector('input[type="submit"], button[type="submit"]');
    if (!input) {
      return;
    }

    if (isToolsDownloadForm(form)) {
      input.classList.add('yp-wp-settings-save-btn', 'yp-wp-settings-download-btn');
      submit.dataset.ypSaveEnhanced = '1';
      return;
    }

    if (isPrivacyToolsRequestForm(form)) {
      applyYooButtonClasses(input, 'primary');
      submit.dataset.ypSaveEnhanced = '1';
      return;
    }

    var btn = input;
    if (input.tagName === 'INPUT') {
      btn = document.createElement('button');
      btn.type = 'button';
      if (input.id) {
        btn.id = input.id;
      }
      if (input.name) {
        btn.name = input.name;
      }
      btn.className = input.className + ' yp-wp-settings-save-btn';
      input.parentNode.replaceChild(btn, input);
    } else {
      btn.type = 'button';
      btn.classList.add('yp-wp-settings-save-btn');
    }
    applyYooButtonClasses(btn, 'primary');
    btn.dataset.ypSaveEnhanced = '1';

    ensureSettingsFormId(form);

    var saveIcon = document.createElement('span');
    saveIcon.className = 'dashicons dashicons-saved yp-wp-settings-save-icon';
    saveIcon.setAttribute('aria-hidden', 'true');

    if (!btn.querySelector('.yp-wp-settings-save-icon')) {
      var label = (input.value || (btn.textContent || '')).trim() || 'Save Changes';
      btn.dataset.ypSaveLabel = label;
      btn.textContent = '';
      btn.appendChild(saveIcon);
      var labelSpan = document.createElement('span');
      labelSpan.className = 'yp-wp-settings-save-label';
      labelSpan.textContent = label;
      btn.appendChild(labelSpan);
    } else if (!btn.dataset.ypSaveLabel) {
      var existing = btn.querySelector('.yp-wp-settings-save-label');
      btn.dataset.ypSaveLabel =
        (existing && existing.textContent) || (btn.textContent || '').trim() || 'Save Changes';
    }

    submit.dataset.ypSaveEnhanced = '1';
  }

  function relocateSaveButton() {
    var wrap = document.querySelector('body.yoo-wp-settings-experience .wrap');
    if (!wrap) {
      return;
    }

    var h1 =
      wrap.querySelector('.yp-wp-settings-header h1') ||
      wrap.querySelector(':scope > h1') ||
      wrap.querySelector('h1');
    var form =
      wrap.querySelector('form.wp-privacy-request-form') ||
      wrap.querySelector('form.yp-wp-settings-export-form') ||
      wrap.querySelector('form.yp-wp-settings-tools-form') ||
      wrap.querySelector(':scope > form') ||
      wrap.querySelector('form');
    var submit = form && form.querySelector('p.submit, .submit');
    if (
      !h1 ||
      !submit ||
      submit.dataset.ypWpMoved === '1' ||
      (form && form.dataset.ypPrivacySubmitInline === '1')
    ) {
      return;
    }

    if (isPrivacyToolsRequestForm(form)) {
      return;
    }

    var header = wrap.querySelector('.yp-wp-settings-header');
    if (!header) {
      header = document.createElement('div');
      header.className = 'yp-wp-settings-header';
      wrap.insertBefore(header, h1);
      header.appendChild(h1);
    }

    ensureSettingsFormId(form);
    enhanceSaveButton(submit, form);

    var saveSlot = header.querySelector('.yp-wp-settings-save');
    if (!saveSlot) {
      saveSlot = document.createElement('div');
      saveSlot.className = 'yp-wp-settings-save';
      header.appendChild(saveSlot);
    }

    saveSlot.appendChild(submit);
    submit.dataset.ypWpMoved = '1';
  }

  function findRowByInput(rows, selector) {
    for (var i = 0; i < rows.length; i++) {
      if (rows[i].querySelector(selector)) {
        return rows[i];
      }
    }
    return null;
  }

  function convertSiteIconButtonsToIcons(choose, remove) {
    if (choose && !choose.dataset.ypIcon) {
      var chooseLabel =
        choose.textContent.trim() ||
        choose.getAttribute('data-update-text') ||
        choose.getAttribute('data-choose-text') ||
        'Change Site Icon';
      choose.dataset.ypIcon = '1';
      choose.setAttribute('aria-label', chooseLabel);
      choose.className = 'yp-icon-action yp-icon-action--primary';
      choose.innerHTML =
        '<span class="dashicons dashicons-admin-media yp-icon-action__glyph" aria-hidden="true"></span>';
    }
    if (remove && !remove.dataset.ypIcon) {
      remove.dataset.ypIcon = '1';
      remove.setAttribute('aria-label', remove.getAttribute('aria-label') || 'Remove Site Icon');
      remove.className = 'yp-icon-action yp-icon-action--ghost';
      remove.innerHTML =
        '<span class="dashicons dashicons-trash yp-icon-action__glyph" aria-hidden="true"></span>';
    }
  }

  function enhanceSiteIconRow(row) {
    row.classList.add('yp-wp-settings-site-icon-row');

    var td = row.querySelector('td');
    var th = row.querySelector('th');
    if (!td) {
      return row;
    }

    var preview = td.querySelector('#site-icon-preview');
    var buttons = td.querySelector('.site-icon-action-buttons');
    var hidden = td.querySelector('#site_icon_hidden_field');
    var desc = td.querySelector('p.description');

    if (desc && th) {
      var text = (desc.textContent || '').replace(/\s+/g, ' ').trim();
      if (text) {
        ensureHelpInTh(row, text);
      }
      desc.remove();
    }

    var layout = document.createElement('div');
    layout.className = 'yp-wp-settings-site-icon-layout';

    var main = document.createElement('div');
    main.className = 'yp-wp-settings-site-icon-main';

    if (preview) {
      main.appendChild(preview);
    }

    if (buttons) {
      var choose = buttons.querySelector('#choose-from-library-button');
      var remove = buttons.querySelector('#js-remove-site-icon');
      convertSiteIconButtonsToIcons(choose, remove);

      var actions = document.createElement('div');
      actions.className = 'yp-wp-settings-site-icon-actions';
      actions.appendChild(buttons);
      main.appendChild(actions);
    }

    layout.appendChild(main);

    var keep = [];
    td.childNodes.forEach(function (node) {
      if (
        node === preview ||
        node === buttons ||
        node === desc ||
        (node.nodeType === 1 && node.id === 'site_icon_hidden_field')
      ) {
        return;
      }
      if (node.nodeType === 1 && node.tagName === 'STYLE') {
        keep.push(node);
      }
    });

    td.textContent = '';
    keep.forEach(function (node) {
      td.appendChild(node);
    });
    td.appendChild(layout);
    if (hidden) {
      td.appendChild(hidden);
    }

    return row;
  }

  function buildSiteIconBlock(row) {
    enhanceSiteIconRow(row);

    var th = row.querySelector('th');
    var td = row.querySelector('td');
    var block = document.createElement('div');
    block.className = 'yp-wp-settings-site-icon-block';

    if (th) {
      var head = document.createElement('div');
      head.className = 'yp-wp-settings-site-icon-head';
      while (th.firstChild) {
        head.appendChild(th.firstChild);
      }
      block.appendChild(head);
    }

    if (td) {
      var body = document.createElement('div');
      body.className = 'yp-wp-settings-site-icon-body';
      while (td.firstChild) {
        body.appendChild(td.firstChild);
      }
      block.appendChild(body);
    }

    row.remove();
    return block;
  }

  function reorganizeDatetimeFieldset(fieldset) {
    fieldset.classList.add('yp-wp-settings-datetime-fieldset');
    fieldset.querySelectorAll('br').forEach(function (br) {
      br.remove();
    });

    var options = [];
    var customLabel = null;
    var customInput = null;
    var previewP = null;
    var docP = null;

    Array.from(fieldset.children).forEach(function (node) {
      if (node.tagName === 'LABEL') {
        if (node.querySelector('#date_format_custom_radio, #time_format_custom_radio')) {
          customLabel = node;
        } else if (node.querySelector('input[type="radio"]')) {
          node.classList.add('yp-wp-settings-datetime-chip');
          options.push(node);
        }
      } else if (node.tagName === 'P') {
        if (node.querySelector('.example')) {
          previewP = node;
        } else if (node.classList.contains('date-time-doc')) {
          docP = node;
        }
      } else if (node.tagName === 'INPUT' && node.classList.contains('small-text')) {
        customInput = node;
      }
    });

    var body = document.createElement('div');
    body.className = 'yp-wp-settings-datetime-body';

    var grid = document.createElement('div');
    grid.className = 'yp-wp-settings-datetime-grid';
    options.forEach(function (label) {
      grid.appendChild(label);
    });

    if (customLabel || previewP) {
      var footer = document.createElement('div');
      footer.className = 'yp-wp-settings-datetime-footer';

      if (customLabel) {
        customLabel.classList.add('yp-wp-settings-datetime-chip', 'yp-wp-settings-datetime-chip--custom');
        if (customInput) {
          customInput.classList.add('yp-wp-settings-datetime-custom-input');
          if (!customLabel.contains(customInput)) {
            customLabel.appendChild(customInput);
          }
        }
        footer.appendChild(customLabel);
      }

      if (previewP) {
        var example = previewP.querySelector('.example');
        var spinner = previewP.querySelector('.spinner');
        var previewChip = document.createElement('div');
        previewChip.className = 'yp-wp-settings-datetime-chip yp-wp-settings-datetime-chip--preview';
        previewChip.setAttribute('aria-live', 'polite');
        var previewLabel = document.createElement('span');
        previewLabel.className = 'yp-wp-settings-datetime-preview-label';
        previewLabel.textContent = 'Preview:';
        previewChip.appendChild(previewLabel);
        if (example) {
          previewChip.appendChild(example);
        }
        if (spinner) {
          previewChip.appendChild(spinner);
        }
        footer.appendChild(previewChip);
      }

      grid.appendChild(footer);
    }

    body.appendChild(grid);

    if (docP) {
      docP.classList.add('yp-wp-settings-datetime-doc');
      body.appendChild(docP);
    }

    fieldset.textContent = '';
    fieldset.appendChild(body);
  }

  function extractDatetimePanel(row, kind) {
    var panel = document.createElement('div');
    panel.className = 'yp-wp-settings-datetime-col yp-wp-settings-datetime-col--' + kind;

    var th = row.querySelector('th');
    var td = row.querySelector('td');
    if (th) {
      var heading = document.createElement('h3');
      heading.className = 'yp-wp-settings-datetime-title';
      heading.textContent = (th.textContent || '').replace(/\s+/g, ' ').trim();
      panel.appendChild(heading);
    }
    if (td) {
      var fieldset = td.querySelector('fieldset');
      if (fieldset) {
        reorganizeDatetimeFieldset(fieldset);
        panel.appendChild(fieldset);
      } else {
        panel.appendChild(td);
      }
    }
    row.remove();
    return panel;
  }

  function buildDateTimeBlock(dateRow, timeRow) {
    var wrap = document.createElement('div');
    wrap.className = 'yp-wp-settings-full yp-wp-settings-datetime-wrap';

    var inner = document.createElement('div');
    inner.className = 'yp-wp-settings-datetime-split';

    if (dateRow) {
      inner.appendChild(extractDatetimePanel(dateRow, 'date'));
    }
    if (timeRow) {
      inner.appendChild(extractDatetimePanel(timeRow, 'time'));
    }

    wrap.appendChild(inner);
    return wrap;
  }

  function findHomepageRow(rows) {
    return (
      rows.find(function (r) {
        return r.querySelector('#front-static-pages, input[name="show_on_front"]');
      }) || null
    );
  }

  function wrapHomepageRadioChip(input) {
    var label = input && input.closest ? input.closest('label') : null;
    if (!label || label.classList.contains('yp-wp-settings-homepage-chip')) {
      return;
    }
    label.classList.add('yp-wp-settings-homepage-chip');
    if (label.querySelector('.yp-wp-settings-homepage-chip__text')) {
      return;
    }
    var textWrap = document.createElement('span');
    textWrap.className = 'yp-wp-settings-homepage-chip__text';
    var node = label.firstChild;
    while (node) {
      var next = node.nextSibling;
      if (node === input) {
        node = next;
        continue;
      }
      if (node.nodeType === 3 && !(node.textContent || '').trim()) {
        label.removeChild(node);
      } else if (node.nodeName === 'BR') {
        label.removeChild(node);
      } else {
        textWrap.appendChild(node);
      }
      node = next;
    }
    if (textWrap.childNodes.length) {
      label.appendChild(textWrap);
    }
  }

  function enhanceHomepageFieldset(fieldset) {
    if (!fieldset || fieldset.dataset.ypHomepageEnhanced === '1') {
      return;
    }
    fieldset.dataset.ypHomepageEnhanced = '1';
    fieldset.classList.add('yp-wp-settings-homepage-fieldset');
    fieldset.querySelectorAll('br').forEach(function (br) {
      br.remove();
    });
    var radios = fieldset.querySelectorAll('input[name="show_on_front"]');
    if (radios.length) {
      var choices = document.createElement('div');
      choices.className = 'yp-wp-settings-homepage-choices';
      radios.forEach(function (input) {
        wrapHomepageRadioChip(input);
        var radioLabel = input.closest('label');
        if (radioLabel) {
          choices.appendChild(radioLabel);
        }
      });
      fieldset.insertBefore(choices, fieldset.firstChild);
    }
    var pagesList = fieldset.querySelector('ul');
    if (!pagesList) {
      return;
    }
    pagesList.classList.add('yp-wp-settings-homepage-pages');
    pagesList.querySelectorAll('li').forEach(function (li) {
      var label = li.querySelector('label');
      var select = li.querySelector('select');
      if (!select) {
        return;
      }
      li.classList.add('yp-wp-settings-homepage-page-row');
      var rowLabel = document.createElement('span');
      rowLabel.className = 'yp-wp-settings-homepage-page-label';
      var labelText = '';
      if (label) {
        labelText = Array.from(label.childNodes)
          .filter(function (n) {
            return n !== select && !(n.nodeType === 1 && n.contains && n.contains(select));
          })
          .map(function (n) {
            return n.textContent || '';
          })
          .join('')
          .replace(/\s+/g, ' ')
          .trim()
          .replace(/:+\s*$/, '');
      }
      rowLabel.textContent =
        labelText || (select.id === 'page_on_front' ? 'Homepage' : 'Posts page');
      var field = document.createElement('div');
      field.className = 'yp-wp-settings-homepage-page-field';
      if (label && label.contains(select)) {
        select.parentNode.removeChild(select);
      }
      field.appendChild(select);
      li.textContent = '';
      li.appendChild(rowLabel);
      li.appendChild(field);
    });
  }

  function buildHomepageBlock(row) {
    var wrap = document.createElement('div');
    wrap.className = 'yp-wp-settings-full yp-wp-settings-homepage-wrap';
    var block = document.createElement('div');
    block.className = 'yp-wp-settings-homepage-block';
    var th = row.querySelector('th');
    var td = row.querySelector('td');
    if (th) {
      var head = document.createElement('div');
      head.className = 'yp-wp-settings-homepage-head';
      var thClone = th.cloneNode(true);
      thClone.querySelectorAll('br').forEach(function (br) {
        br.remove();
      });
      head.appendChild(thClone);
      block.appendChild(head);
    }
    var body = document.createElement('div');
    body.className = 'yp-wp-settings-homepage-body';
    if (td) {
      var fieldset = td.querySelector('fieldset');
      if (fieldset) {
        enhanceHomepageFieldset(fieldset);
        body.appendChild(fieldset);
      } else {
        while (td.firstChild) {
          body.appendChild(td.firstChild);
        }
      }
    }
    block.appendChild(body);
    wrap.appendChild(block);
    row.remove();
    return wrap;
  }

  function syncHomepageSelectDisabled(wrap) {
    if (!wrap) {
      return;
    }
    var staticOn = wrap.querySelector('input[name="show_on_front"][value="page"]:checked');
    var pages = wrap.querySelector('.yp-wp-settings-homepage-pages');
    var selects = wrap.querySelectorAll('select#page_on_front, select#page_for_posts');
    selects.forEach(function (sel) {
      var disabled = !staticOn;
      sel.disabled = disabled;
      var ui = sel.closest('.yp-ui-select');
      if (!ui) {
        return;
      }
      var btn = ui.querySelector('.yp-custom-select__trigger');
      if (disabled) {
        if (btn) {
          btn.setAttribute('disabled', 'disabled');
        }
        ui.classList.add('is-disabled');
        ui.classList.remove('is-open');
        var list = ui.querySelector('.yp-custom-select__drop');
        if (list) {
          list.setAttribute('hidden', 'hidden');
        }
        if (btn) {
          btn.setAttribute('aria-expanded', 'false');
        }
      } else if (btn) {
        btn.removeAttribute('disabled');
        ui.classList.remove('is-disabled');
      }
    });
    if (pages) {
      pages.classList.toggle('is-disabled', !staticOn);
    }
  }

  function initReadingHomepageControls(root) {
    var scope = root || document;
    var wrap = scope.querySelector('.yp-wp-settings-homepage-wrap');
    if (!wrap) {
      return;
    }
    if (wrap.dataset.ypHomepageBound !== '1') {
      wrap.dataset.ypHomepageBound = '1';
      wrap.querySelectorAll('input[name="show_on_front"]').forEach(function (radio) {
        radio.addEventListener('change', function () {
          syncHomepageSelectDisabled(wrap);
        });
      });
    }
    syncHomepageSelectDisabled(wrap);
    window.addEventListener('load', function () {
      syncHomepageSelectDisabled(wrap);
    });
  }

  function appendSplitRows(rows, splitEl) {
    var colL = document.createElement('div');
    colL.className = 'yp-wp-settings-col';
    var colR = document.createElement('div');
    colR.className = 'yp-wp-settings-col';
    var tableL = document.createElement('table');
    tableL.className = 'form-table';
    var tbodyL = document.createElement('tbody');
    var tableR = document.createElement('table');
    tableR.className = 'form-table';
    var tbodyR = document.createElement('tbody');
    tableL.appendChild(tbodyL);
    tableR.appendChild(tbodyR);
    colL.appendChild(tableL);
    colR.appendChild(tableR);
    rows.forEach(function (row, index) {
      (index % 2 === 0 ? tbodyL : tbodyR).appendChild(row);
    });
    splitEl.appendChild(colL);
    splitEl.appendChild(colR);
  }

  function createMediaRowTable(row) {
    var table = document.createElement('table');
    table.className = 'form-table yp-wp-settings-discussion-table yp-wp-settings-media-table';
    var tbody = document.createElement('tbody');
    tbody.appendChild(row);
    table.appendChild(tbody);
    enhanceMediaTable(table);
    return table;
  }

  function buildMediaPairedGrid(rows) {
    var grid = document.createElement('div');
    grid.className = 'yp-wp-settings-discussion-grid yp-wp-settings-media-grid';

    for (var i = 0; i < rows.length; i += 2) {
      var pair = document.createElement('div');
      pair.className = 'yp-wp-settings-discussion-pair';

      var colL = document.createElement('div');
      colL.className = 'yp-wp-settings-discussion-pair-col';
      colL.appendChild(createMediaRowTable(rows[i]));
      pair.appendChild(colL);

      if (rows[i + 1]) {
        var colR = document.createElement('div');
        colR.className = 'yp-wp-settings-discussion-pair-col';
        colR.appendChild(createMediaRowTable(rows[i + 1]));
        pair.appendChild(colR);
      } else {
        colL.classList.add('yp-wp-settings-discussion-pair-col--solo');
      }

      grid.appendChild(pair);
    }

    return grid;
  }

  function buildMediaSectionBlock(heading, intro, table) {
    var section = document.createElement('div');
    section.className = 'yp-wp-settings-media-section';
    if (heading) {
      var head = document.createElement('div');
      head.className = 'yp-wp-settings-media-section-head';
      head.appendChild(heading);
      section.appendChild(head);
    }
    if (intro) {
      intro.classList.add('yp-wp-settings-media-section-intro');
      section.appendChild(intro);
    }
    if (table) {
      var tbody = table.tBodies[0] || table;
      var rows = Array.from(tbody.querySelectorAll(':scope > tr'));
      if (rows.length) {
        section.appendChild(buildMediaPairedGrid(rows));
      }
    }
    return section;
  }

  function buildWritingSubsectionBlock(heading, intro, table) {
    var wrap = document.createElement('div');
    wrap.className = 'yp-wp-settings-full yp-wp-settings-writing-subsection';
    if (heading) {
      var head = document.createElement('div');
      head.className = 'yp-wp-settings-media-section-head';
      head.appendChild(heading);
      wrap.appendChild(head);
    }
    if (intro) {
      intro.classList.add('yp-wp-settings-media-section-intro');
      wrap.appendChild(intro);
    }
    if (table) {
      table.classList.add('yp-wp-settings-writing-table');
      wrap.appendChild(table);
    }
    return wrap;
  }

  function buildMediaSettingsLayout(form) {
    if (!form || form.dataset.ypWpMediaLayout === '1') {
      return;
    }
    var imageHeading = form.querySelector('h2.title');
    var imageTable = form.querySelector('table.form-table');
    if (!imageHeading || !imageTable) {
      return;
    }
    var intro = imageHeading.nextElementSibling;
    if (intro && intro.tagName !== 'P') {
      intro = null;
    }
    if (intro && intro.nextElementSibling !== imageTable) {
      intro = null;
    }
    var uploadsInput = form.querySelector('#uploads_use_yearmonth_folders');
    var uploadsTable = uploadsInput ? uploadsInput.closest('table.form-table') : null;
    var uploadsHeading =
      uploadsTable &&
      uploadsTable.previousElementSibling &&
      uploadsTable.previousElementSibling.tagName === 'H2'
        ? uploadsTable.previousElementSibling
        : null;
    var embedsSections = [];
    form.querySelectorAll('h2.title').forEach(function (heading) {
      if (heading === imageHeading || heading === uploadsHeading) {
        return;
      }
      var next = heading.nextElementSibling;
      if (next && next.matches && next.matches('table.form-table')) {
        embedsSections.push({ heading: heading, table: next });
      }
    });
    var shell = document.createElement('div');
    shell.className = 'yp-wp-settings-shell yp-wp-settings-media-shell';
    shell.appendChild(buildMediaSectionBlock(imageHeading, intro, imageTable));
    embedsSections.forEach(function (section) {
      shell.appendChild(buildMediaSectionBlock(section.heading, null, section.table));
    });
    if (uploadsHeading && uploadsTable) {
      shell.appendChild(buildMediaSectionBlock(uploadsHeading, null, uploadsTable));
    }
    imageTable.parentNode.replaceChild(shell, imageTable);
    form.classList.add('yp-wp-settings-media-form');
    form.dataset.ypWpMediaLayout = '1';
  }

  function enhanceWritingEmailTable(table) {
    if (!table || table.dataset.ypWritingEmailEnhanced === '1') {
      return;
    }
    table.dataset.ypWritingEmailEnhanced = '1';

    var mailUrl = table.querySelector('#mailserver_url');
    if (mailUrl) {
      var mailTd = mailUrl.closest('td');
      var mailRow = mailUrl.closest('tr');
      if (mailRow) {
        mailRow.classList.add('yp-wp-settings-writing-mailserver-row');
      }
      if (mailTd) {
        var portLabel = mailTd.querySelector('label[for="mailserver_port"]');
        var portInput = mailTd.querySelector('#mailserver_port');
        var fields = document.createElement('div');
        fields.className = 'yp-wp-settings-writing-mail-fields';
        fields.appendChild(mailUrl);
        if (portLabel && portInput) {
          var portWrap = document.createElement('div');
          portWrap.className = 'yp-wp-settings-writing-mail-port';
          portWrap.appendChild(portLabel);
          portWrap.appendChild(portInput);
          fields.appendChild(portWrap);
        }
        mailTd.textContent = '';
        mailTd.appendChild(fields);
      }
    }

    var passRow = table.querySelector('.mailserver-pass-wrap');
    if (passRow) {
      passRow.classList.add('yp-wp-settings-writing-password-row');
      var wpPwd = passRow.querySelector('.wp-pwd');
      if (wpPwd) {
        wpPwd.classList.add('yp-wp-settings-writing-password-field');
      }
      var toggle = passRow.querySelector('.wp-hide-pw');
      if (toggle && !toggle.dataset.ypWritingPwToggle) {
        toggle.dataset.ypWritingPwToggle = '1';
        toggle.classList.add('yp-wp-settings-writing-password-toggle');
        toggle.setAttribute('type', 'button');
      }
    }
  }

  function enhanceWritingServicesBlock(wrap) {
    if (!wrap || wrap.dataset.ypWritingServicesEnhanced === '1') {
      return;
    }
    wrap.dataset.ypWritingServicesEnhanced = '1';
    var body = wrap.querySelector('.yp-wp-settings-writing-services-body');
    if (!body) {
      return;
    }
    var intro = body.querySelector('p');
    if (intro) {
      intro.classList.add('yp-wp-settings-media-section-intro');
    }
    var textarea = body.querySelector('textarea#ping_sites');
    if (textarea) {
      textarea.classList.add('yp-wp-settings-writing-services-textarea');
      if (!textarea.getAttribute('rows') || parseInt(textarea.getAttribute('rows'), 10) < 4) {
        textarea.setAttribute('rows', '4');
      }
    }
  }

  function buildWritingServicesBlock(heading) {
    var wrap = document.createElement('div');
    wrap.className =
      'yp-wp-settings-full yp-wp-settings-writing-subsection yp-wp-settings-writing-services-wrap';
    if (heading) {
      var head = document.createElement('div');
      head.className = 'yp-wp-settings-media-section-head';
      var cursor = heading.nextElementSibling;
      head.appendChild(heading);
      wrap.appendChild(head);
      var body = document.createElement('div');
      body.className = 'yp-wp-settings-writing-services-body';
      while (cursor) {
        var next = cursor.nextElementSibling;
        if (cursor.nodeType === 1 && cursor.tagName === 'H2') {
          break;
        }
        if (cursor.nodeType === 1 && cursor.tagName === 'P' && cursor.classList.contains('submit')) {
          break;
        }
        body.appendChild(cursor);
        cursor = next;
      }
      if (body.childNodes.length) {
        wrap.appendChild(body);
      }
    }
    enhanceWritingServicesBlock(wrap);
    return wrap;
  }

  function buildWritingSettingsLayout(form) {
    if (!form || form.dataset.ypWpWritingLayout === '1') {
      return;
    }
    var primaryTable = form.querySelector('table.form-table');
    if (!primaryTable) {
      return;
    }
    var mailInput = form.querySelector('#mailserver_url');
    var emailTable = mailInput ? mailInput.closest('table.form-table') : null;
    var emailHeading = null;
    var emailIntro = null;
    if (emailTable) {
      var beforeTable = emailTable.previousElementSibling;
      if (beforeTable && beforeTable.tagName === 'P') {
        emailIntro = beforeTable;
        beforeTable = beforeTable.previousElementSibling;
      }
      if (beforeTable && beforeTable.tagName === 'H2') {
        emailHeading = beforeTable;
      }
    }
    var servicesHeading = null;
    form.querySelectorAll('h2.title').forEach(function (heading) {
      if (heading === emailHeading) {
        return;
      }
      servicesHeading = heading;
    });
    var shell = document.createElement('div');
    shell.className = 'yp-wp-settings-shell yp-wp-settings-writing-shell';
    var primary = buildMediaSectionBlock(null, null, primaryTable);
    primary.classList.add('yp-wp-settings-writing-primary');
    shell.appendChild(primary);
    if (emailHeading && emailTable) {
      var emailBlock = buildWritingSubsectionBlock(emailHeading, emailIntro, emailTable);
      enhanceWritingEmailTable(emailTable);
      shell.appendChild(emailBlock);
    }
    if (servicesHeading) {
      shell.appendChild(buildWritingServicesBlock(servicesHeading));
    }
    primaryTable.parentNode.replaceChild(shell, primaryTable);
    form.classList.add('yp-wp-settings-writing-form');
    form.dataset.ypWpWritingLayout = '1';
  }

  function buildTableSection(heading, intro, table, splitRows) {
    if (splitRows && table) {
      var splitSection = buildMediaSectionBlock(heading, intro, table);
      splitSection.classList.add('yp-wp-settings-section-block');
      return splitSection;
    }
    var block = buildWritingSubsectionBlock(heading, intro, table);
    block.classList.add('yp-wp-settings-section-block');
    return block;
  }

  function stackDiscussionRow(row) {
    var th = row.querySelector('th');
    var td = row.querySelector('td');
    if (!td) {
      return;
    }
    row.classList.add('yp-wp-settings-field-row');
    if (!th) {
      Array.from(td.querySelectorAll(':scope > input[type="checkbox"]')).forEach(function (input) {
        wrapDiscussionCheckboxChoice(td, input);
      });
      td.querySelectorAll(':scope > label').forEach(function (label) {
        if (label.querySelector('input[type="checkbox"], input[type="radio"]')) {
          label.classList.add('yp-wp-settings-choice');
        }
      });
      return;
    }
    wrapThContent(th);
  }

  function wrapDiscussionCheckboxChoice(container, input) {
    if (!container || !input || input.type !== 'checkbox' || input.closest('label.yp-wp-settings-choice')) {
      return;
    }
    var next = input.nextElementSibling;
    if (!next || next.tagName !== 'LABEL') {
      return;
    }
    var wrap = document.createElement('label');
    wrap.className = 'yp-wp-settings-choice';
    container.insertBefore(wrap, input);
    wrap.appendChild(input);
    wrap.appendChild(next);
  }

  function enhanceDiscussionTextareaBlocks(fieldset) {
    fieldset.querySelectorAll('textarea').forEach(function (textarea) {
      var textWrap = textarea.closest('p');
      if (textWrap) {
        textWrap.classList.add('yp-wp-settings-textarea-wrap');
      }
      var desc = textWrap && textWrap.previousElementSibling;
      if (!desc || desc.tagName !== 'P') {
        return;
      }
      desc.classList.add('yp-wp-settings-field-desc');
      var label = desc.querySelector('label');
      if (!label || label.querySelector('input, textarea, select')) {
        return;
      }
      var text = document.createElement('div');
      text.className = 'yp-wp-settings-field-desc__text';
      text.innerHTML = label.innerHTML;
      label.replaceWith(text);
    });
  }

  function enhanceDiscussionFieldsets(table) {
    table.querySelectorAll('fieldset').forEach(function (fieldset) {
      if (fieldset.closest('.defaultavatarpicker')) {
        return;
      }

      fieldset.querySelectorAll('br').forEach(function (br) {
        br.remove();
      });

      Array.from(fieldset.querySelectorAll('input[type="checkbox"]')).forEach(function (input) {
        wrapDiscussionCheckboxChoice(fieldset, input);
      });

      fieldset.querySelectorAll('label').forEach(function (label) {
        if (label.classList.contains('yp-wp-settings-choice')) {
          return;
        }
        if (label.querySelector('input[type="checkbox"], input[type="radio"]')) {
          label.classList.add('yp-wp-settings-choice');
        }
      });

      fieldset.querySelectorAll(':scope > ul').forEach(function (ul) {
        ul.classList.add('yp-wp-settings-subfields');
        ul.querySelectorAll(':scope > li').forEach(function (li) {
          li.classList.add('yp-wp-settings-subfield');
        });
      });

      var maxLinks = fieldset.querySelector('#comment_max_links');
      if (maxLinks) {
        var holder = maxLinks.closest('p, label');
        if (holder) {
          holder.classList.add('yp-wp-settings-max-links');
        }
      }

      enhanceDiscussionTextareaBlocks(fieldset);
    });

    var avatarFieldset = table.querySelector('.defaultavatarpicker fieldset');
    if (avatarFieldset) {
      avatarFieldset.querySelectorAll('br').forEach(function (br) {
        br.remove();
      });
      avatarFieldset.classList.add('yp-wp-settings-avatar-grid');
      avatarFieldset.querySelectorAll('label').forEach(function (label) {
        label.classList.add('yp-wp-settings-avatar-option');
      });
    }
  }

  function enhanceDiscussionTable(table) {
    if (!table || table.dataset.ypDiscussionStacked === '1') {
      return;
    }
    table.dataset.ypDiscussionStacked = '1';
    table.classList.add('yp-wp-settings-discussion-table');

    var rows = table.querySelectorAll(':scope > tbody > tr, :scope > tr');
    rows.forEach(stackDiscussionRow);
    enhanceDiscussionFieldsets(table);
  }

  function enhanceMediaFieldsets(table) {
    table.querySelectorAll('fieldset').forEach(function (fieldset) {
      fieldset.querySelectorAll('br').forEach(function (br) {
        br.remove();
      });

      Array.from(fieldset.querySelectorAll('label[for]')).forEach(function (label) {
        if (label.closest('.yp-wp-settings-subfield')) {
          return;
        }
        var id = label.getAttribute('for');
        var input = id ? fieldset.querySelector('#' + id) : null;
        if (!input && label.nextElementSibling && label.nextElementSibling.matches('input, select')) {
          input = label.nextElementSibling;
        }
        if (!input) {
          return;
        }
        var wrap = document.createElement('div');
        wrap.className = 'yp-wp-settings-subfield';
        label.parentNode.insertBefore(wrap, label);
        wrap.appendChild(label);
        wrap.appendChild(input);
      });
    });

    table.querySelectorAll('td').forEach(function (td) {
      Array.from(td.querySelectorAll(':scope > input[type="checkbox"]')).forEach(function (input) {
        wrapDiscussionCheckboxChoice(td, input);
      });
    });

    enhanceDiscussionFieldsets(table);
  }

  function enhanceMediaTable(table) {
    if (!table || table.dataset.ypMediaStacked === '1') {
      return;
    }
    table.dataset.ypMediaStacked = '1';
    table.classList.add('yp-wp-settings-discussion-table', 'yp-wp-settings-media-table');

    var rows = table.querySelectorAll(':scope > tbody > tr, :scope > tr');
    rows.forEach(stackDiscussionRow);
    enhanceMediaFieldsets(table);
  }

  function createDiscussionRowTable(row) {
    var table = document.createElement('table');
    table.className = 'form-table yp-wp-settings-discussion-table';
    var tbody = document.createElement('tbody');
    tbody.appendChild(row);
    table.appendChild(tbody);
    enhanceDiscussionTable(table);
    return table;
  }

  function buildDiscussionPairedGrid(rows) {
    var grid = document.createElement('div');
    grid.className = 'yp-wp-settings-discussion-grid';

    for (var i = 0; i < rows.length; i += 2) {
      var pair = document.createElement('div');
      pair.className = 'yp-wp-settings-discussion-pair';

      var colL = document.createElement('div');
      colL.className = 'yp-wp-settings-discussion-pair-col';
      colL.appendChild(createDiscussionRowTable(rows[i]));
      pair.appendChild(colL);

      if (rows[i + 1]) {
        var colR = document.createElement('div');
        colR.className = 'yp-wp-settings-discussion-pair-col';
        colR.appendChild(createDiscussionRowTable(rows[i + 1]));
        pair.appendChild(colR);
      } else {
        colL.classList.add('yp-wp-settings-discussion-pair-col--solo');
      }

      grid.appendChild(pair);
    }

    return grid;
  }

  function shouldSkipDiscussionRow(row, skip) {
    if (!skip) {
      return false;
    }
    if (typeof skip === 'function') {
      return skip(row);
    }
    if (skip instanceof Set) {
      return skip.has(row);
    }
    return row === skip;
  }

  function collectDiscussionRowsFromTable(table, rows, skip) {
    if (!table) {
      return;
    }
    var tbody = table.tBodies[0] || table;
    Array.from(tbody.querySelectorAll(':scope > tr')).forEach(function (row) {
      if (shouldSkipDiscussionRow(row, skip)) {
        return;
      }
      rows.push(row);
    });
  }

  function buildDiscussionSettingsLayout(form) {
    if (!form || form.dataset.ypWpDiscussionLayout === '1') {
      return;
    }

    var firstTable = form.querySelector('table.form-table');
    if (!firstTable) {
      return;
    }

    var avatarHeading = form.querySelector('h2.title');
    var avatarIntro = null;
    var avatarTable = null;
    if (avatarHeading) {
      var cursor = avatarHeading.nextElementSibling;
      if (cursor && cursor.tagName === 'P') {
        avatarIntro = cursor;
        cursor = cursor.nextElementSibling;
      }
      if (cursor && cursor.classList && cursor.classList.contains('form-table')) {
        avatarTable = cursor;
      }
    }

    var avatarDisplayRow = null;
    var maximumRatingRow = null;
    var defaultAvatarRow = null;
    if (avatarTable) {
      var showAvatars = avatarTable.querySelector('#show_avatars');
      if (showAvatars) {
        avatarDisplayRow = showAvatars.closest('tr');
      }
      var ratingInput = avatarTable.querySelector('input[name="avatar_rating"]');
      if (ratingInput) {
        maximumRatingRow = ratingInput.closest('tr');
      }
      var pickerCell = avatarTable.querySelector('.defaultavatarpicker');
      if (pickerCell) {
        defaultAvatarRow = pickerCell.closest('tr');
      }
    }

    var avatarBottomRows = new Set();
    if (avatarDisplayRow) {
      avatarBottomRows.add(avatarDisplayRow);
    }
    if (defaultAvatarRow) {
      avatarBottomRows.add(defaultAvatarRow);
    }

    var gridRows = [];
    collectDiscussionRowsFromTable(firstTable, gridRows);
    collectDiscussionRowsFromTable(avatarTable, gridRows, avatarBottomRows);

    var shell = document.createElement('div');
    shell.className = 'yp-wp-settings-shell yp-wp-settings-discussion-shell';

    if (gridRows.length) {
      var mainSection = document.createElement('div');
      mainSection.className = 'yp-wp-settings-discussion-section yp-wp-settings-discussion-section--main';
      mainSection.appendChild(buildDiscussionPairedGrid(gridRows));
      shell.appendChild(mainSection);
    }

    if (avatarDisplayRow || defaultAvatarRow) {
      var avatarSection = document.createElement('div');
      avatarSection.className =
        'yp-wp-settings-discussion-section yp-wp-settings-discussion-section--default-avatar';

      if (avatarIntro) {
        avatarIntro.classList.add('yp-wp-settings-discussion-default-avatar-intro');
        avatarSection.appendChild(avatarIntro);
      }

      if (avatarDisplayRow) {
        avatarSection.appendChild(createDiscussionRowTable(avatarDisplayRow));
      }
      if (defaultAvatarRow) {
        avatarSection.appendChild(createDiscussionRowTable(defaultAvatarRow));
      }

      shell.appendChild(avatarSection);
    }

    if (avatarHeading) {
      avatarHeading.remove();
    }
    if (firstTable && !firstTable.querySelector('tr')) {
      firstTable.remove();
    }
    if (avatarTable && !avatarTable.querySelector('tr')) {
      avatarTable.remove();
    }

    form.classList.add('yp-wp-settings-discussion-form');

    var insertRef = form.querySelector('p.submit, .submit');
    form.insertBefore(shell, insertRef || null);
    form.dataset.ypWpDiscussionLayout = '1';
  }

  function convertPermalinkOptionalRow(tr) {
    var th = tr.querySelector('th');
    var td = tr.querySelector('td');
    if (!td) {
      return null;
    }

    var card = document.createElement('div');
    card.className = 'yp-wp-settings-permalink-field';

    if (th) {
      var labelWrap = document.createElement('div');
      labelWrap.className = 'yp-wp-settings-permalink-field__label';
      var label = th.querySelector('label');
      if (label) {
        labelWrap.appendChild(label);
      } else {
        while (th.firstChild) {
          labelWrap.appendChild(th.firstChild);
        }
      }
      card.appendChild(labelWrap);
    }

    var control = document.createElement('div');
    control.className = 'yp-wp-settings-permalink-field__control';
    while (td.firstChild) {
      control.appendChild(td.firstChild);
    }
    card.appendChild(control);
    return card;
  }

  function getPermalinkOptionalFieldKey(tr) {
    var input = tr.querySelector('input[id], input[name], select, textarea');
    return input ? input.id || input.name || '' : '';
  }

  function getPermalinkOptionalColumn(tr) {
    var key = getPermalinkOptionalFieldKey(tr).toLowerCase();
    if (key.indexOf('category') !== -1) {
      return 'left';
    }
    if (key.indexOf('tag') !== -1 || key.indexOf('attribute') !== -1) {
      return 'right';
    }
    var thText = ((tr.querySelector('th') && tr.querySelector('th').textContent) || '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
    if (thText.indexOf('category') !== -1) {
      return 'left';
    }
    if (thText.indexOf('tag') !== -1 || thText.indexOf('attribute') !== -1) {
      return 'right';
    }
    return 'left';
  }

  function sortPermalinkOptionalRows(rows) {
    var order = {
      category_base: 0,
      woocommerce_product_category_slug: 1,
      tag_base: 0,
      woocommerce_product_tag_slug: 1,
      woocommerce_product_attribute_slug: 2
    };
    return rows.slice().sort(function (a, b) {
      var ka = getPermalinkOptionalFieldKey(a);
      var kb = getPermalinkOptionalFieldKey(b);
      return (order[ka] !== undefined ? order[ka] : 99) - (order[kb] !== undefined ? order[kb] : 99);
    });
  }

  function buildPermalinkOptionalFields(rows) {
    var grid = document.createElement('div');
    grid.className = 'yp-wp-settings-permalink-optional-grid';

    var colL = document.createElement('div');
    colL.className = 'yp-wp-settings-permalink-optional-col';
    var colR = document.createElement('div');
    colR.className = 'yp-wp-settings-permalink-optional-col';

    var leftRows = [];
    var rightRows = [];
    rows.forEach(function (tr) {
      (getPermalinkOptionalColumn(tr) === 'right' ? rightRows : leftRows).push(tr);
    });

    sortPermalinkOptionalRows(leftRows).forEach(function (tr) {
      var card = convertPermalinkOptionalRow(tr);
      if (card) {
        colL.appendChild(card);
      }
    });
    sortPermalinkOptionalRows(rightRows).forEach(function (tr) {
      var card = convertPermalinkOptionalRow(tr);
      if (card) {
        colR.appendChild(card);
      }
    });

    grid.appendChild(colL);
    grid.appendChild(colR);
    return grid;
  }

  function isPermalinkOptionalSection(heading, table) {
    if (table && table.querySelector('#category_base, #tag_base, #woocommerce_product_category_slug')) {
      return true;
    }
    return /optional/i.test(((heading && heading.textContent) || '').replace(/\s+/g, ' ').trim());
  }

  function convertWooPermalinkTable(table) {
    var wrap = document.createElement('div');
    wrap.className =
      'yp-wp-settings-woocommerce-permalink-structure wc-permalink-structure';

    Array.from(table.querySelectorAll('tbody tr')).forEach(function (tr) {
      var th = tr.querySelector('th');
      var td = tr.querySelector('td');
      var radio = tr.querySelector('input[type="radio"]');
      if (!radio) {
        return;
      }

      var option = document.createElement('div');
      option.className = 'yp-wp-settings-permalink-option';
      option.appendChild(radio);

      var body = document.createElement('div');
      var label = th && th.querySelector('label');
      if (label) {
        var title = document.createElement('label');
        if (radio.id) {
          title.setAttribute('for', radio.id);
        }
        var labelClone = label.cloneNode(true);
        labelClone.querySelectorAll('input').forEach(function (input) {
          input.remove();
        });
        title.textContent = (labelClone.textContent || '').replace(/\s+/g, ' ').trim();
        body.appendChild(title);
      }

      if (td) {
        Array.from(td.childNodes).forEach(function (node) {
          body.appendChild(node);
        });
      }

      option.appendChild(body);
      wrap.appendChild(option);
    });

    table.replaceWith(wrap);
    return wrap;
  }

  function absorbPermalinkExtras(form, shell) {
    var wcHeading = Array.from(form.querySelectorAll('h2')).find(function (heading) {
      return /product\s+permalinks/i.test((heading.textContent || '').replace(/\s+/g, ' ').trim());
    });

    if (wcHeading && !shell.contains(wcHeading)) {
      var wcSection = document.createElement('div');
      wcSection.className =
        'yp-wp-settings-permalink-section yp-wp-settings-permalink-section--woocommerce';

      var wcNodes = [];
      var cursor = wcHeading.nextElementSibling;
      while (cursor && !cursor.matches('p.submit, .submit') && cursor.tagName !== 'H2') {
        wcNodes.push(cursor);
        cursor = cursor.nextElementSibling;
      }

      var wcHead = document.createElement('div');
      wcHead.className = 'yp-wp-settings-media-section-head';
      wcHead.appendChild(wcHeading);
      wcSection.appendChild(wcHead);

      wcNodes.forEach(function (node) {
        if (node.tagName === 'P') {
          node.classList.add('yp-wp-settings-media-section-intro');
          wcSection.appendChild(node);
        } else if (node.matches && node.matches('table.wc-permalink-structure')) {
          wcSection.appendChild(convertWooPermalinkTable(node));
        } else if (node.tagName === 'SCRIPT' || node.tagName === 'INPUT') {
          wcSection.appendChild(node);
        }
      });

      shell.appendChild(wcSection);

      if (window.jQuery) {
        window.jQuery('.permalink-structure input:checked').trigger('change');
      }
    }

    Array.from(form.querySelectorAll('table.form-table')).forEach(function (table) {
      if (shell.contains(table)) {
        return;
      }
      var isDupOptional =
        table.querySelector('#woocommerce_product_category_slug, #woocommerce_product_tag_slug') ||
        (table.querySelector('#category_base') && shell.querySelector('#category_base'));
      if (!isDupOptional) {
        return;
      }
      var prev = table.previousElementSibling;
      if (prev && prev.tagName === 'H2') {
        prev.remove();
      }
      table.remove();
    });
  }

  function buildPermalinkSettingsLayout(form) {
    if (!form || form.dataset.ypWpPermalinkLayout === '1') {
      return;
    }
    var structureTable = form.querySelector('table.permalink-structure') || form.querySelector('table.form-table');
    if (!structureTable) {
      return;
    }

    var shell = document.createElement('div');
    shell.className = 'yp-wp-settings-shell yp-wp-settings-permalink-shell';

    var commonDesc = structureTable.previousElementSibling;
    var commonHeading =
      commonDesc && commonDesc.tagName === 'P' ? commonDesc.previousElementSibling : null;
    if (commonHeading && commonHeading.tagName !== 'H2') {
      commonHeading = null;
    }
    var mainIntro =
      commonHeading && commonHeading.previousElementSibling && commonHeading.previousElementSibling.tagName === 'P'
        ? commonHeading.previousElementSibling
        : null;

    if (mainIntro) {
      var leadWrap = document.createElement('div');
      leadWrap.className = 'yp-wp-settings-section-lead';
      leadWrap.appendChild(mainIntro);
      shell.appendChild(leadWrap);
    }

    var fieldset = structureTable.querySelector('.structure-selection');
    if (fieldset) {
      var structureSection = document.createElement('div');
      structureSection.className = 'yp-wp-settings-permalink-section';

      if (commonHeading) {
        var structureHead = document.createElement('div');
        structureHead.className = 'yp-wp-settings-media-section-head';
        structureHead.appendChild(commonHeading);
        structureSection.appendChild(structureHead);
      }
      if (commonDesc && commonDesc.tagName === 'P') {
        commonDesc.classList.add('yp-wp-settings-media-section-intro');
        structureSection.appendChild(commonDesc);
      }

      fieldset.querySelectorAll('.row').forEach(function (row) {
        row.classList.add('yp-wp-settings-permalink-option');
      });
      structureSection.appendChild(fieldset);
      shell.appendChild(structureSection);
    }

    structureTable.remove();

    Array.from(form.querySelectorAll('h2.title')).forEach(function (heading) {
      var intro = heading.nextElementSibling;
      if (!intro || intro.tagName !== 'P') {
        intro = null;
      }
      var table = intro ? intro.nextElementSibling : heading.nextElementSibling;
      if (!table || !table.matches || !table.matches('table.form-table')) {
        return;
      }

      var section = document.createElement('div');
      section.className = 'yp-wp-settings-permalink-section';
      var head = document.createElement('div');
      head.className = 'yp-wp-settings-media-section-head';
      head.appendChild(heading);
      section.appendChild(head);
      if (intro) {
        intro.classList.add('yp-wp-settings-media-section-intro');
        section.appendChild(intro);
      }

      var tbody = table.tBodies[0] || table;
      var rows = Array.from(tbody.querySelectorAll(':scope > tr'));
      if (rows.length) {
        if (isPermalinkOptionalSection(heading, table)) {
          section.appendChild(buildPermalinkOptionalFields(rows));
        } else {
          section.appendChild(buildMediaPairedGrid(rows));
        }
      }
      shell.appendChild(section);
      table.remove();
    });

    var insertRef = form.querySelector('p.submit, .submit');
    form.insertBefore(shell, insertRef || null);
    absorbPermalinkExtras(form, shell);
    form.classList.add('yp-wp-settings-permalink-form');
    form.dataset.ypWpPermalinkLayout = '1';
  }

  function buildSectionedPageLayout(form, options) {
    if (!form || form.dataset.ypWpSectionedLayout === '1') {
      return;
    }
    options = options || {};
    var splitPrimary = options.splitPrimary !== false;
    var splitSections = !!options.splitSections;
    var shellClass = options.shellClass || '';
    var firstTable = form.querySelector('table.form-table');
    if (!firstTable) {
      return;
    }
    var shell = document.createElement('div');
    shell.className = 'yp-wp-settings-shell yp-wp-settings-sectioned-shell';
    if (shellClass) {
      shell.classList.add(shellClass);
    }
    var leadWrap = null;
    while (form.firstElementChild && form.firstElementChild !== firstTable) {
      var leadNode = form.firstElementChild;
      if (leadNode.nodeType === 1 && leadNode.tagName === 'P') {
        if (!leadWrap) {
          leadWrap = document.createElement('div');
          leadWrap.className = 'yp-wp-settings-section-lead';
          shell.appendChild(leadWrap);
        }
        leadWrap.appendChild(leadNode);
      } else {
        break;
      }
    }
    var insertRef = firstTable.nextSibling;
    shell.appendChild(buildTableSection(null, null, firstTable, splitPrimary));
    Array.from(form.querySelectorAll('h2.title')).forEach(function (heading) {
      var intro = null;
      var next = heading.nextElementSibling;
      if (next && next.tagName === 'P') {
        intro = next;
        next = next.nextElementSibling;
      }
      var table = next && next.classList && next.classList.contains('form-table') ? next : null;
      shell.appendChild(buildTableSection(heading, intro, table, splitSections));
    });
    form.insertBefore(shell, insertRef);
    form.dataset.ypWpSectionedLayout = '1';
  }

  function isPrivacyPolicyGuide() {
    if (cfg.screen !== 'options-privacy') {
      return false;
    }
    try {
      return new URL(window.location.href, window.location.origin).searchParams.get('tab') === 'policyguide';
    } catch (e) {
      return /(?:^|[?&])tab=policyguide(?:&|$)/.test(window.location.search || '');
    }
  }

  function positionPrivacyTabInk() {
    var nav = document.querySelector('.yp-wp-settings-privacy-root .yp-tab-nav');
    if (!nav) {
      return;
    }
    var ink = nav.querySelector('.yp-tab-ink');
    var active = nav.querySelector('.yp-tab.is-active');
    if (!ink || !active) {
      return;
    }
    var navRect = nav.getBoundingClientRect();
    var tabRect = active.getBoundingClientRect();
    ink.style.width = tabRect.width + 'px';
    ink.style.left = tabRect.left - navRect.left + 'px';
  }

  function initPrivacyTabInk() {
    var root = document.querySelector('.yp-wp-settings-privacy-root');
    if (!root || root.dataset.ypPrivacyInk === '1') {
      return;
    }
    root.dataset.ypPrivacyInk = '1';
    positionPrivacyTabInk();
    window.addEventListener('resize', positionPrivacyTabInk);
  }

  function enhancePrivacyChrome() {
    var header = document.querySelector('.privacy-settings-header');
    var body = document.querySelector('.privacy-settings-body');
    if (!header || !body || header.dataset.ypWpPrivacyChrome === '1') {
      return;
    }
    header.dataset.ypWpPrivacyChrome = '1';

    var root = document.createElement('div');
    root.className = 'yp-wp-settings-privacy-root yooadmin-settings-wrap';

    var tabsCard = document.createElement('div');
    tabsCard.className = 'yp-tabs yp-wp-settings-privacy-tabs-card';
    tabsCard.setAttribute('data-yp-wp-privacy-tabs', '1');

    var cardHead = document.createElement('div');
    cardHead.className = 'yp-wp-settings-privacy-card-head';

    var titleSection = header.querySelector('.privacy-settings-title-section');
    if (titleSection) {
      var h1 = titleSection.querySelector('h1');
      if (h1) {
        cardHead.appendChild(h1);
      }
    }
    if (cardHead.childNodes.length) {
      tabsCard.appendChild(cardHead);
    }

    var tabNav = document.createElement('div');
    tabNav.className = 'yp-tab-nav';
    tabNav.setAttribute('role', 'tablist');

    var tabsWrapper = header.querySelector('.privacy-settings-tabs-wrapper');
    if (tabsWrapper) {
      tabsWrapper.querySelectorAll('a.privacy-settings-tab').forEach(function (link) {
        link.classList.remove('privacy-settings-tab', 'active');
        link.classList.add('yp-tab');
        if (link.getAttribute('aria-current') === 'true' || link.classList.contains('active')) {
          link.classList.add('is-active');
          link.setAttribute('aria-selected', 'true');
        } else {
          link.setAttribute('aria-selected', 'false');
        }
        link.setAttribute('role', 'tab');
        tabNav.appendChild(link);
      });
    }

    var tabInk = document.createElement('span');
    tabInk.className = 'yp-tab-ink';
    tabInk.setAttribute('aria-hidden', 'true');
    tabNav.appendChild(tabInk);

    var tabPanels = document.createElement('div');
    tabPanels.className = 'yp-tab-panels';

    var panel = document.createElement('section');
    panel.className = 'yp-tab-panel is-active';
    panel.setAttribute('data-panel', isPrivacyPolicyGuide() ? 'policyguide' : 'settings');
    panel.appendChild(body);

    tabPanels.appendChild(panel);
    tabsCard.appendChild(tabNav);
    tabsCard.appendChild(tabPanels);

    root.appendChild(tabsCard);

    var hr = document.querySelector('hr.wp-header-end');
    header.parentNode.insertBefore(root, header);
    header.remove();
    if (hr) {
      hr.remove();
    }

    initPrivacyTabInk();
  }

  function enhancePrivacyPolicyGuideLayout() {
    var body = document.querySelector('.privacy-settings-body');
    if (!body || body.dataset.ypWpPrivacyGuideLayout === '1') {
      return;
    }
    if (!body.querySelector('.privacy-settings-accordion')) {
      return;
    }
    body.dataset.ypWpPrivacyGuideLayout = '1';

    var shell = document.createElement('div');
    shell.className =
      'yp-wp-settings-shell yp-wp-settings-privacy-shell yp-wp-settings-privacy-guide-shell';

    var leadWrap = document.createElement('div');
    leadWrap.className = 'yp-wp-settings-section-lead yp-wp-settings-privacy-guide-lead';

    while (body.firstElementChild) {
      var node = body.firstElementChild;
      if (
        node.tagName === 'H2' ||
        (node.tagName === 'P' && !node.querySelector('.privacy-settings-accordion'))
      ) {
        leadWrap.appendChild(node);
        continue;
      }
      if (node.tagName === 'HR') {
        node.remove();
        continue;
      }
      break;
    }

    if (leadWrap.childNodes.length) {
      shell.appendChild(leadWrap);
    }

    while (body.firstElementChild) {
      var block = document.createElement('div');
      block.className = 'yp-wp-settings-section-block yp-wp-settings-privacy-guide-block';

      if (
        body.firstElementChild.tagName === 'H3' &&
        body.firstElementChild.classList.contains('section-title')
      ) {
        var title = body.firstElementChild;
        block.appendChild(title);
      }

      while (body.firstElementChild) {
        var next = body.firstElementChild;
        if (next.tagName === 'H3' && next.classList.contains('section-title')) {
          break;
        }
        block.appendChild(next);
      }

      shell.appendChild(block);
    }

    body.appendChild(shell);
  }

  function enhancePrivacySettingsLayout() {
    var body = document.querySelector('.privacy-settings-body');
    if (!body || body.dataset.ypWpPrivacyLayout === '1') {
      return;
    }
    var table = body.querySelector('table.form-table');
    if (!table) {
      return;
    }
    var shell = document.createElement('div');
    shell.className = 'yp-wp-settings-shell yp-wp-settings-privacy-shell';
    var leadWrap = document.createElement('div');
    leadWrap.className = 'yp-wp-settings-section-lead';
    while (body.firstElementChild && body.firstElementChild !== table) {
      leadWrap.appendChild(body.firstElementChild);
    }
    if (leadWrap.childNodes.length) {
      shell.appendChild(leadWrap);
    }
    var section = document.createElement('div');
    section.className = 'yp-wp-settings-section-block yp-wp-settings-privacy-section';
    section.appendChild(table);
    shell.appendChild(section);
    body.insertBefore(shell, body.firstChild);
    body.dataset.ypWpPrivacyLayout = '1';
  }

  function enhanceToolsHubCards(wrap) {
    if (!wrap || wrap.dataset.ypWpToolsHub === '1') {
      return;
    }
    wrap.dataset.ypWpToolsHub = '1';
    wrap.querySelectorAll(':scope > .card').forEach(function (card) {
      card.classList.add('yp-wp-settings-tools-card');
    });
  }

  function enhanceToolsPanelLayout(wrap) {
    if (!wrap || wrap.dataset.ypWpToolsPanel === '1') {
      return;
    }
    wrap.dataset.ypWpToolsPanel = '1';
    wrap.classList.add('yp-wp-settings-tools-panel');
  }

  function isToolsDownloadForm(form) {
    return cfg.screen === 'export' || !!(form && form.id === 'export-filters');
  }

  function isPersonalDataToolsScreen() {
    return cfg.screen === 'export-personal-data' || cfg.screen === 'erase-personal-data';
  }

  function isPrivacyToolsRequestForm(form) {
    return !!(form && form.classList && form.classList.contains('wp-privacy-request-form'));
  }

  function enhanceYooButtons(root) {
    var scope =
      root ||
      document.querySelector('.yp-wp-settings-privacy-root') ||
      document.querySelector('.privacy-settings-body') ||
      document.querySelector('.wrap') ||
      document;
    if (!scope || !scope.querySelectorAll) {
      return;
    }
    scope
      .querySelectorAll(
        'input[type="submit"].button, input[type="button"].button, button.button, a.button'
      )
      .forEach(function (el) {
        if (
          el.classList.contains('button-link') ||
          el.classList.contains('button-link-delete') ||
          el.classList.contains('yp-wp-settings-save-btn')
        ) {
          return;
        }
        el.classList.add('yp-yoo-btn');
        if (el.classList.contains('button-primary')) {
          el.classList.add('yp-yoo-btn--primary');
          el.classList.remove('yp-yoo-btn--secondary', 'yp-yoo-btn--soft');
        } else if (el.classList.contains('button-secondary')) {
          el.classList.add('yp-yoo-btn--secondary');
          el.classList.remove('yp-yoo-btn--primary', 'yp-yoo-btn--soft');
        } else {
          el.classList.add('yp-yoo-btn--secondary');
          el.classList.remove('yp-yoo-btn--primary', 'yp-yoo-btn--soft');
        }
      });
  }

  function applyYooButtonClasses(el, variant) {
    if (!el) {
      return;
    }
    var v = variant === 'secondary' ? 'secondary' : 'primary';
    el.classList.add('yp-yoo-btn', 'yp-yoo-btn--' + v, 'button');
    if (v === 'secondary') {
      el.classList.add('button-secondary');
      el.classList.remove('button-primary');
    } else {
      el.classList.add('button-primary');
      el.classList.remove('button-secondary');
    }
  }

  function isWpUiPrimaryButton(el) {
    var cn = el && el.className ? el.className : '';
    return (
      cn.indexOf('__is-brand') !== -1 ||
      cn.indexOf('__is-solid') !== -1 ||
      cn.indexOf('__is-primary') !== -1
    );
  }

  function enhanceBootLayoutButtons(root) {
    if (!root || !root.querySelectorAll) {
      return;
    }
    root.querySelectorAll('button[class*="__button"]').forEach(function (el) {
      if (el.classList.contains('yp-yoo-btn')) {
        return;
      }
      applyYooButtonClasses(el, isWpUiPrimaryButton(el) ? 'primary' : 'secondary');
    });
  }

  function buildPrivacyAddInlineRow(rows, submitWrap) {
    var panel = document.createElement('div');
    panel.className = 'yp-wp-settings-privacy-tools-add-panel';

    var row = document.createElement('div');
    row.className = 'yp-wp-settings-privacy-tools-add-row';

    rows.forEach(function (tr) {
      var cell = document.createElement('div');
      cell.className = 'yp-wp-settings-privacy-tools-add-cell';

      var th = tr.querySelector('th');
      var td = tr.querySelector('td');
      if (th) {
        var lbl = document.createElement('label');
        lbl.className = 'yp-wp-settings-privacy-tools-add-cell__label';
        var thLabel = th.querySelector('label[for]');
        if (thLabel) {
          lbl.setAttribute('for', thLabel.getAttribute('for') || '');
          lbl.textContent = thLabel.textContent.replace(/:?\s*$/, '').trim();
        } else {
          lbl.textContent = th.textContent.replace(/:?\s*$/, '').trim();
        }
        cell.appendChild(lbl);
      }

      if (td) {
        var ctrl = document.createElement('div');
        ctrl.className = 'yp-wp-settings-privacy-tools-add-cell__control';
        while (td.firstChild) {
          ctrl.appendChild(td.firstChild);
        }
        ctrl.querySelectorAll('label').forEach(function (label) {
          if (label.querySelector('input[type="checkbox"]')) {
            label.classList.add('yp-wp-settings-privacy-tools-checkbox');
          }
        });
        cell.appendChild(ctrl);
      }

      row.appendChild(cell);
    });

    if (submitWrap) {
      var actions = document.createElement('div');
      actions.className = 'yp-wp-settings-privacy-tools-add-actions';
      actions.appendChild(submitWrap);
      row.appendChild(actions);
    }

    panel.appendChild(row);
    return panel;
  }

  function buildPrivacyRequestFormLayout(form) {
    if (!form || form.dataset.ypWpPrivacyRequestLayout === '1') {
      return;
    }

    var h2 = form.querySelector('h2');
    var fieldWrap = form.querySelector('.wp-privacy-request-form-field');
    var table = fieldWrap && fieldWrap.querySelector('table.form-table');
    if (!table) {
      return;
    }

    var tbody = table.tBodies[0] || table;
    var rows = Array.from(tbody.querySelectorAll(':scope > tr'));
    if (!rows.length) {
      return;
    }

    var section = document.createElement('div');
    section.className = 'yp-wp-settings-privacy-tools-add-block';

    if (h2) {
      var head = document.createElement('div');
      head.className = 'yp-wp-settings-privacy-tools-add-head';
      head.appendChild(h2);
      section.appendChild(head);
    }

    var submitWrap = fieldWrap.querySelector('p.submit, .submit');
    section.appendChild(buildPrivacyAddInlineRow(rows, submitWrap));

    if (submitWrap) {
      var submitInput = submitWrap.querySelector('input[type="submit"], button[type="submit"]');
      applyYooButtonClasses(submitInput, 'primary');
      submitWrap.classList.add('yp-wp-settings-privacy-tools-add-submit');
      submitWrap.dataset.ypSaveEnhanced = '1';
      form.dataset.ypPrivacySubmitInline = '1';
    }

    table.remove();
    fieldWrap.classList.add('yp-wp-settings-privacy-tools-add-fields');
    fieldWrap.insertBefore(section, fieldWrap.firstChild);
    form.classList.add('yp-wp-settings-privacy-tools-form', 'yp-wp-settings-tools-form');
    form.dataset.ypWpPrivacyRequestLayout = '1';
  }

  function normalizePrivacyViewsList(views) {
    if (!views) {
      return;
    }
    views.querySelectorAll(':scope > li').forEach(function (li) {
      li.classList.add('yp-wp-settings-privacy-tools-view-item');
    });
  }

  function enhancePrivacyRequestsList(section) {
    if (!section || section.dataset.ypWpPrivacyList === '1') {
      return;
    }
    section.dataset.ypWpPrivacyList = '1';

    var views = section.querySelector('.subsubsub');
    var searchForm = section.querySelector('form.search-form');
    var listForm = section.querySelector('form:not(.search-form)');
    var nodes = Array.from(section.childNodes);

    var card = document.createElement('div');
    card.className = 'yp-wp-settings-privacy-tools-table-card';

    var toolbar = document.createElement('div');
    toolbar.className = 'yp-wp-settings-privacy-tools-table-toolbar';

    if (views) {
      views.classList.add('yp-wp-settings-privacy-tools-views');
      normalizePrivacyViewsList(views);
      toolbar.appendChild(views);
    }

    if (searchForm) {
      searchForm.classList.add('yp-wp-settings-privacy-tools-search');
      toolbar.appendChild(searchForm);
    }

    if (toolbar.childNodes.length) {
      card.appendChild(toolbar);
    }

    if (listForm) {
      listForm.classList.add('yp-wp-settings-privacy-tools-list-form');
      listForm.querySelectorAll('.wp-list-table').forEach(function (table) {
        table.classList.add('yp-wp-settings-privacy-tools-table');
        var wrap = table.closest('.yp-wp-settings-privacy-tools-table-scroll');
        if (!wrap) {
          wrap = document.createElement('div');
          wrap.className = 'yp-wp-settings-privacy-tools-table-scroll';
          table.parentNode.insertBefore(wrap, table);
          wrap.appendChild(table);
        }
      });
      listForm.querySelectorAll('.tablenav').forEach(function (nav) {
        nav.classList.add('yp-wp-settings-privacy-tools-tablenav');
        if (nav.classList.contains('top')) {
          nav.classList.add('yp-wp-settings-privacy-tools-tablenav--top');
        }
        if (nav.classList.contains('bottom')) {
          nav.classList.add('yp-wp-settings-privacy-tools-tablenav--bottom');
        }
      });
      card.appendChild(listForm);
    } else {
      nodes.forEach(function (node) {
        if (node.nodeType === 1 && node.querySelector && node.querySelector('.wp-list-table')) {
          card.appendChild(node);
        }
      });
    }

    while (section.firstChild) {
      section.removeChild(section.firstChild);
    }
    section.appendChild(card);
  }

  function collectPrivacyToolsListNodes(wrap) {
    var nodes = [];
    if (!wrap) {
      return nodes;
    }
    Array.from(wrap.children).forEach(function (node) {
      if (node.nodeType !== 1) {
        return;
      }
      if (
        node.classList &&
        (node.classList.contains('yp-wp-settings-shell') ||
          node.classList.contains('yp-wp-settings-header'))
      ) {
        return;
      }
      if (
        node.tagName === 'HR' ||
        node.classList.contains('subsubsub') ||
        (node.tagName === 'FORM' &&
          (node.classList.contains('search-form') || node.querySelector('.wp-list-table')))
      ) {
        nodes.push(node);
      }
    });
    return nodes;
  }

  function mergeOrphanPrivacyListNodes(wrap, card) {
    if (!wrap || !card) {
      return;
    }
    var toolbar = card.querySelector('.yp-wp-settings-privacy-tools-table-toolbar');
    Array.from(wrap.children).forEach(function (node) {
      if (node.nodeType !== 1) {
        return;
      }
      if (node.classList && node.classList.contains('yp-wp-settings-shell')) {
        return;
      }
      if (node.classList.contains('subsubsub')) {
        node.classList.add('yp-wp-settings-privacy-tools-views');
        normalizePrivacyViewsList(node);
        if (toolbar) {
          toolbar.insertBefore(node, toolbar.firstChild);
        } else {
          card.insertBefore(node, card.firstChild);
        }
      } else if (
        node.tagName === 'FORM' &&
        (node.classList.contains('search-form') || node.querySelector('.wp-list-table')) &&
        !card.contains(node)
      ) {
        card.appendChild(node);
      }
    });
  }

  function buildPersonalDataToolsLayout(wrap) {
    if (!wrap || wrap.dataset.ypWpPrivacyToolsLayout === '1' || !isPersonalDataToolsScreen()) {
      return false;
    }

    var intro =
      wrap.querySelector(':scope > p') ||
      wrap.querySelector('.yp-wp-settings-header + p');
    var addForm = wrap.querySelector('form.wp-privacy-request-form');

    var shell = document.createElement('div');
    shell.className = 'yp-wp-settings-shell yp-wp-settings-privacy-tools-shell';

    if (intro) {
      var introBlock = document.createElement('div');
      introBlock.className = 'yp-wp-settings-privacy-tools-intro';
      intro.classList.add('yp-wp-settings-privacy-tools-lead');
      introBlock.appendChild(intro);
      shell.appendChild(introBlock);
    }

    var listNodes = collectPrivacyToolsListNodes(wrap);

    if (addForm) {
      buildPrivacyRequestFormLayout(addForm);
      var addWrap = document.createElement('div');
      addWrap.className = 'yp-wp-settings-privacy-tools-add';
      addWrap.appendChild(addForm);
      shell.appendChild(addWrap);
    }

    if (listNodes.length) {
      var listWrap = document.createElement('div');
      listWrap.className = 'yp-wp-settings-privacy-tools-requests';
      listNodes.forEach(function (node) {
        listWrap.appendChild(node);
      });
      enhancePrivacyRequestsList(listWrap);
      shell.appendChild(listWrap);
    }

    var anchor =
      wrap.querySelector(':scope > .notice, :scope > .updated, :scope > .error') ||
      wrap.querySelector(':scope > hr.wp-header-end') ||
      wrap.querySelector(':scope > .yp-wp-settings-header') ||
      wrap.querySelector(':scope > h1');

    if (anchor) {
      var after = anchor;
      while (after.nextElementSibling && after.nextElementSibling.matches('hr.wp-header-end')) {
        after = after.nextElementSibling;
      }
      wrap.insertBefore(shell, after.nextElementSibling);
    } else {
      wrap.insertBefore(shell, wrap.firstChild);
    }

    wrap.classList.add('yp-wp-settings-privacy-tools-wrap');
    document.body.classList.add('yp-wp-settings-privacy-tools-active');
    wrap.dataset.ypWpPrivacyToolsLayout = '1';

    var card = wrap.querySelector('.yp-wp-settings-privacy-tools-table-card');
    if (card) {
      mergeOrphanPrivacyListNodes(wrap, card);
    }

    document.body.dataset.ypWpBooted = '1';
    return true;
  }

  function createExportFilterField(labelText, control) {
    var field = document.createElement('div');
    field.className = 'yp-wp-settings-export-filter-field';

    if (labelText) {
      var lbl = document.createElement('span');
      lbl.className = 'yp-wp-settings-export-filter-label';
      lbl.textContent = labelText;
      field.appendChild(lbl);
    }

    if (control) {
      var ctrlWrap = document.createElement('div');
      ctrlWrap.className = 'yp-wp-settings-export-filter-control';
      ctrlWrap.appendChild(control);
      field.appendChild(ctrlWrap);
    }

    return field;
  }

  function getExportFilterLabelText(li, label, control) {
    var span = li.querySelector('.label-responsive');
    if (span) {
      return span.textContent.replace(/:?\s*$/, '').trim();
    }
    if (label) {
      var clone = label.cloneNode(true);
      clone.querySelectorAll('select, input').forEach(function (node) {
        node.remove();
      });
      return clone.textContent.replace(/:?\s*$/, '').trim();
    }
    if (control && control.id) {
      return control.id.replace(/[-_]/g, ' ');
    }
    return '';
  }

  function enhanceExportFilterListItem(li) {
    if (!li || li.dataset.ypWpExportFilter === '1') {
      return;
    }
    li.dataset.ypWpExportFilter = '1';
    li.classList.remove('yp-wp-settings-subfield');

    var nestedFieldset = li.querySelector(':scope > fieldset');
    if (nestedFieldset) {
      nestedFieldset.querySelectorAll('br').forEach(function (br) {
        br.remove();
      });

      var startSelect = nestedFieldset.querySelector('select[id*="start"]');
      var endSelect = nestedFieldset.querySelector('select[id*="end"]');
      var startLabel = nestedFieldset.querySelector('label[for*="start"]');
      var endLabel = nestedFieldset.querySelector('label[for*="end"]');
      var datesRow = document.createElement('div');
      datesRow.className = 'yp-wp-settings-export-filters-dates';

      if (startSelect) {
        datesRow.appendChild(
          createExportFilterField(
            getExportFilterLabelText(li, startLabel, startSelect) || 'Start date',
            startSelect
          )
        );
      }
      if (endSelect) {
        datesRow.appendChild(
          createExportFilterField(
            getExportFilterLabelText(li, endLabel, endSelect) || 'End date',
            endSelect
          )
        );
      }

      li.classList.add('yp-wp-settings-export-filter-dates-li');
      li.textContent = '';
      li.appendChild(datesRow);
      return;
    }

    var label = li.querySelector('label');
    var control =
      (label && label.getAttribute('for')
        ? document.getElementById(label.getAttribute('for'))
        : null) || li.querySelector('select, input');

    if (label && control && label.contains(control)) {
      var labelText = getExportFilterLabelText(li, label, control);
      li.textContent = '';
      li.appendChild(createExportFilterField(labelText, control));
      return;
    }

    if (control) {
      li.textContent = '';
      li.appendChild(createExportFilterField(getExportFilterLabelText(li, label, control), control));
    }
  }

  function enhanceExportFiltersList(ul) {
    if (!ul || ul.dataset.ypWpExportFilters === '1') {
      return;
    }
    ul.dataset.ypWpExportFilters = '1';
    ul.classList.add('yp-wp-settings-export-filters');
    ul.querySelectorAll(':scope > li').forEach(enhanceExportFilterListItem);
  }

  function enhanceExportFieldset(fieldset) {
    if (!fieldset || fieldset.dataset.ypWpExportFieldset === '1') {
      return;
    }
    fieldset.dataset.ypWpExportFieldset = '1';
    fieldset.classList.add('yp-wp-settings-export-fieldset');

    fieldset.querySelectorAll('br').forEach(function (br) {
      br.remove();
    });

    fieldset.querySelectorAll(':scope > p > label').forEach(function (label) {
      if (!label.querySelector('input[type="radio"]')) {
        return;
      }
      label.classList.add('yp-wp-settings-choice');
      var row = label.parentNode;
      if (row && row.tagName === 'P') {
        row.classList.add('yp-wp-settings-export-choice-row');
      }
    });

    fieldset.querySelectorAll(':scope > p.description').forEach(function (desc) {
      desc.classList.add('yp-wp-settings-field-desc');
    });

    fieldset.querySelectorAll(':scope > ul.export-filters').forEach(enhanceExportFiltersList);

    fieldset.querySelectorAll('label').forEach(function (label) {
      if (label.classList.contains('yp-wp-settings-choice')) {
        return;
      }
      if (label.querySelector('input[type="checkbox"], input[type="radio"]')) {
        label.classList.add('yp-wp-settings-choice');
      }
    });
  }

  function buildExportSettingsLayout(wrap, form) {
    if (!wrap || !form || form.dataset.ypWpExportLayout === '1') {
      return false;
    }

    var fieldset = form.querySelector('fieldset');
    if (!fieldset) {
      return false;
    }

    var h1 = wrap.querySelector(':scope > h1');
    var h2 = wrap.querySelector(':scope > h2');
    var introParas = [];
    var node = h1 ? h1.nextElementSibling : wrap.firstElementChild;
    while (node && node !== h2 && node !== form) {
      if (node.tagName === 'P') {
        introParas.push(node);
      }
      node = node.nextElementSibling;
    }

    var shell = document.createElement('div');
    shell.className = 'yp-wp-settings-shell yp-wp-settings-export-shell';

    if (introParas.length) {
      var introSection = document.createElement('div');
      introSection.className =
        'yp-wp-settings-export-section yp-wp-settings-export-section--intro yp-wp-settings-discussion-section';
      introParas.forEach(function (p) {
        p.classList.add('yp-wp-settings-export-intro');
        introSection.appendChild(p);
      });
      shell.appendChild(introSection);
    }

    var choicesSection = document.createElement('div');
    choicesSection.className =
      'yp-wp-settings-export-section yp-wp-settings-export-section--choices yp-wp-settings-discussion-section';

    if (h2) {
      var head = document.createElement('div');
      head.className = 'yp-wp-settings-export-section-head';
      head.appendChild(h2);
      choicesSection.appendChild(head);
    }

    enhanceExportFieldset(fieldset);
    choicesSection.appendChild(fieldset);
    shell.appendChild(choicesSection);

    var insertRef = form.querySelector('p.submit, .submit');
    form.insertBefore(shell, insertRef || fieldset);

    form.classList.add('yp-wp-settings-export-form', 'yp-wp-settings-tools-form');
    form.dataset.ypWpExportLayout = '1';
    form.dataset.ypWpToolsLayout = '1';
    form.dataset.ypWpBooted = '1';
    return true;
  }

  function buildToolsCodeEditorLayout(form) {
    if (!form || form.dataset.ypWpToolsCodeLayout === '1') {
      return;
    }
    form.classList.add('yp-wp-settings-tools-form', 'yp-wp-settings-tools-form--code');
    var table = form.querySelector('table.form-table');
    if (table && table.dataset.ypWpToolsCodeTable !== '1') {
      table.dataset.ypWpToolsCodeTable = '1';
      var section = document.createElement('div');
      section.className = 'yp-wp-settings-tools-code-section';
      var parent = table.parentNode;
      parent.insertBefore(section, table);
      section.appendChild(table);
    }
    form.dataset.ypWpToolsCodeLayout = '1';
    form.dataset.ypWpBooted = '1';
  }

  function buildToolsSettingsLayout(wrap, form) {
    if (!form || form.dataset.ypWpToolsLayout === '1') {
      return;
    }

    if (cfg.screen === 'export') {
      if (buildExportSettingsLayout(wrap, form)) {
        return;
      }
    }

    if (isPersonalDataToolsScreen()) {
      return;
    }

    form.classList.add('yp-wp-settings-tools-form');
    if (form.querySelector('table.form-table')) {
      buildTwoColumnLayout(form);
    }
    form.dataset.ypWpToolsLayout = '1';
    form.dataset.ypWpBooted = '1';
  }

  function bootBootLayoutPage() {
    var app = getBootLayoutApp();
    if (!app) {
      return false;
    }
    if (app.dataset.ypWpBooted === '1') {
      return true;
    }
    app.dataset.ypWpBooted = '1';
    app.classList.add('yp-wp-settings-boot-layout-app');

    var wrap = ensureBootLayoutWrap(app);
    if (wrap) {
      Array.from(wrap.children).forEach(function (child) {
        if (child === app) {
          return;
        }
        child.setAttribute('aria-hidden', 'true');
        child.style.display = 'none';
      });
    }

    watchBootLayoutPage(app, wrap);
    document.body.dataset.ypWpBooted = '1';
    return true;
  }

  function syncBootLayoutIntro() {
    return;
  }

  function fixBootLayoutPage(app) {
    if (!app) {
      return;
    }
    app.classList.add('yp-wp-settings-boot-layout-app', 'yp-wp-boot-layout-fixed');
    var boot = app.querySelector('.boot-layout');
    if (boot) {
      boot.classList.add('yp-wp-boot-layout-shell');
    }
  }

  function watchBootLayoutPage(app, wrap) {
    if (!app || app.__ypBootLayoutWatch) {
      return;
    }
    app.__ypBootLayoutWatch = true;

    var apply = function () {
      fixBootLayoutPage(app);
      hideBootLayoutShellChrome(wrap);
      enhanceBootLayoutButtons(app);
    };

    apply();

    if (typeof MutationObserver === 'undefined') {
      window.setInterval(apply, 400);
      return;
    }

    var mo = new MutationObserver(function () {
      apply();
    });
    mo.observe(app, { childList: true, subtree: true });

    window.setTimeout(apply, 120);
    window.setTimeout(apply, 500);
    window.setTimeout(apply, 1200);
  }

  function bootToolsLayout(wrap, form) {
    if (wrap) {
      wrap.classList.add('yp-wp-settings-tools-hub');
    }

    if (cfg.screen === 'tools') {
      enhanceToolsHubCards(wrap);
      document.body.dataset.ypWpBooted = '1';
      return true;
    }

    if (isPersonalDataToolsScreen() && wrap) {
      if (buildPersonalDataToolsLayout(wrap)) {
        return true;
      }
    }

    if (form) {
      if (cfg.screen === 'theme-editor' || cfg.screen === 'plugin-editor') {
        buildToolsCodeEditorLayout(form);
      } else {
        buildToolsSettingsLayout(wrap, form);
      }
      document.body.dataset.ypWpBooted = '1';
      return true;
    }

    enhanceToolsPanelLayout(wrap);
    document.body.dataset.ypWpBooted = '1';
    return true;
  }

  function buildTwoColumnLayout(form) {
    if (
      form &&
      (form.dataset.ypWpMediaLayout === '1' ||
        form.dataset.ypWpWritingLayout === '1' ||
        form.dataset.ypWpSectionedLayout === '1')
    ) {
      return;
    }
    var table = form.querySelector('table.form-table');
    if (!table || table.dataset.ypWpSplit === '1') {
      return;
    }
    var tbody = table.tBodies[0] || table;
    var rows = Array.from(tbody.querySelectorAll(':scope > tr'));
    if (rows.length < 2) {
      return;
    }
    var siteIconRow = rows.find(function (r) {
      return r.classList.contains('site-icon-section');
    });
    var homepageRow = findHomepageRow(rows);
    var dateRow = findRowByInput(rows, 'input[name="date_format"]');
    var timeRow = findRowByInput(rows, 'input[name="time_format"]');
    var shell = document.createElement('div');
    shell.className = 'yp-wp-settings-shell';
    if (siteIconRow) {
      var siteWrap = document.createElement('div');
      siteWrap.className = 'yp-wp-settings-full yp-wp-settings-site-icon-wrap';
      siteWrap.appendChild(buildSiteIconBlock(siteIconRow));
      shell.appendChild(siteWrap);
    }
    if (homepageRow) {
      shell.appendChild(buildHomepageBlock(homepageRow));
    }
    var split = document.createElement('div');
    split.className = 'yp-wp-settings-split';
    var colL = document.createElement('div');
    colL.className = 'yp-wp-settings-col';
    var colR = document.createElement('div');
    colR.className = 'yp-wp-settings-col';
    var tableL = document.createElement('table');
    tableL.className = 'form-table';
    var tbodyL = document.createElement('tbody');
    var tableR = document.createElement('table');
    tableR.className = 'form-table';
    var tbodyR = document.createElement('tbody');
    tableL.appendChild(tbodyL);
    tableR.appendChild(tbodyR);
    colL.appendChild(tableL);
    colR.appendChild(tableR);
    var skip = new Set();
    if (siteIconRow) {
      skip.add(siteIconRow);
    }
    if (homepageRow) {
      skip.add(homepageRow);
    }
    if (dateRow) {
      skip.add(dateRow);
    }
    if (timeRow) {
      skip.add(timeRow);
    }
    var regular = rows.filter(function (r) {
      return !skip.has(r);
    });
    regular.forEach(function (row, index) {
      (index % 2 === 0 ? tbodyL : tbodyR).appendChild(row);
    });
    split.appendChild(colL);
    split.appendChild(colR);
    shell.appendChild(split);
    if (dateRow || timeRow) {
      shell.appendChild(buildDateTimeBlock(dateRow, timeRow));
    }
    table.parentNode.replaceChild(shell, table);
    table.dataset.ypWpSplit = '1';
  }

  function markReady() {
    document.body.classList.add('yp-wp-settings-ready');
  }

  function initWpSettingsSelects(root) {
    if (!root || !window.yooadminUiSelect) {
      return;
    }
    if (typeof window.yooadminUiSelect.initIn === 'function') {
      window.yooadminUiSelect.initIn(root);
      return;
    }
    if (typeof window.yooadminUiSelect.wrap !== 'function') {
      return;
    }
    root.querySelectorAll('select:not([multiple])').forEach(function (sel) {
      window.yooadminUiSelect.wrap(sel);
    });
  }

  function bootLayout() {
    if (!document.body || !document.body.classList.contains('yoo-wp-settings-experience')) {
      return;
    }

    var wrap = document.querySelector('.wrap');
    var form = document.querySelector('.wrap form');

    if (isBootLayoutScreen()) {
      if (bootBootLayoutPage()) {
        return;
      }
    }

    if (isToolsScreen()) {
      if (bootToolsLayout(wrap, form)) {
        return;
      }
    }

    if (cfg.screen === 'options-privacy') {
      enhancePrivacyChrome();
      if (isPrivacyPolicyGuide()) {
        enhancePrivacyPolicyGuideLayout();
      } else {
        enhancePrivacySettingsLayout();
      }
      var privacyRoot = document.querySelector('.privacy-settings-body') || document.querySelector('.wrap') || document;
      moveDescriptionsToTooltips(privacyRoot);
      moveSectionIntrosToTooltips(privacyRoot);
      document.body.dataset.ypWpBooted = '1';
      if (!form) {
        return;
      }
    }

    if (!form || form.dataset.ypWpBooted === '1') {
      return;
    }

    form.dataset.ypWpBooted = '1';

    if (cfg.screen === 'options-general') {
      form.classList.add('yp-wp-settings-general-form');
    }

    if (cfg.screen === 'options-reading') {
      form.classList.add('yp-wp-settings-reading-form');
    }

    if (cfg.screen === 'options-media') {
      form.classList.add('yp-wp-settings-media-form');
      buildMediaSettingsLayout(form);
    } else if (cfg.screen === 'options-writing') {
      buildWritingSettingsLayout(form);
    } else if (cfg.screen === 'options-discussion') {
      buildDiscussionSettingsLayout(form);
    } else if (cfg.screen === 'options-permalink') {
      form.classList.add('yp-wp-settings-permalink-form');
      buildPermalinkSettingsLayout(form);
    } else {
      buildTwoColumnLayout(form);
    }

    var tooltipRoot = document.querySelector('.wrap') || document;
    moveDescriptionsToTooltips(tooltipRoot);
    moveSectionIntrosToTooltips(tooltipRoot);
  }

  function finishBoot(form) {
    enhancePageTitle();
    var activeForm =
      form ||
      document.querySelector('.wrap form.wp-privacy-request-form') ||
      document.querySelector('.wrap form');
    relocateSaveButton();
    if (activeForm) {
      initAjaxFormSave(activeForm);
      initReadingHomepageControls(activeForm);
    }
    var settingsRoot =
      activeForm || document.querySelector('.privacy-settings-body') || document.querySelector('.wrap');
    initWpSettingsSelects(settingsRoot);
    initInteractions();
    if (cfg.screen === 'options-privacy') {
      initPrivacyTabInk();
    }
    enhanceYooButtons(settingsRoot);
    if (isBootLayoutScreen()) {
      var bootApp = getBootLayoutApp();
      if (bootApp) {
        enhanceBootLayoutButtons(bootApp);
      }
    }
    markReady();
  }

  function runBoot() {
    if (bootStarted) {
      return;
    }
    bootStarted = true;

    if (!document.body || !document.body.classList.contains('yoo-wp-settings-experience')) {
      return;
    }

    var wrap = document.querySelector('.wrap');
    var form = document.querySelector('.wrap form');
    var privacyPage = cfg.screen === 'options-privacy';
    var toolsPage = isToolsScreen();
    var bootLayoutPage = isBootLayoutScreen();

    if (!form && !privacyPage && !toolsPage && !bootLayoutPage) {
      markReady();
      return;
    }

    if (bootLayoutPage) {
      bootLayout();
      var bootApp = getBootLayoutApp();
      if (!bootApp) {
        finishBoot(null);
        return;
      }
      var bootWrap = document.querySelector('.wrap.yp-wp-settings-boot-layout-wrap');
      var bootWait = 0;
      var bootTimer = window.setInterval(function () {
        bootWait += 100;
        fixBootLayoutPage(bootApp);
        hideBootLayoutShellChrome(bootWrap);
        if (bootApp.querySelector('.boot-layout') || bootWait >= 8000) {
          window.clearInterval(bootTimer);
          finishBoot(null);
        }
      }, 100);
      return;
    }

    if (!form && toolsPage) {
      bootLayout();
      finishBoot(null);
      return;
    }

    if (document.body.dataset.ypWpBooted === '1') {
      finishBoot(form || null);
      return;
    }

    bootLayout();

    if (form && form.dataset.ypWpBooted === '1') {
      finishBoot(form);
      return;
    }

    finishBoot(form || null);
  }

  function useYooMedia() {
    return !!(
      cfg.useYooMedia &&
      typeof window.yooadminOpenPickModalBrowseOnly === 'function' &&
      document.getElementById('yoo-media-pick-modal')
    );
  }

  function applySiteIconAttributes(attributes) {
    var $hidden = $('#site_icon_hidden_field');
    var $preview = $('#site-icon-preview');
    var $choose = $('#choose-from-library-button');
    var $remove = $('#js-remove-site-icon');
    var $browser = $('#browser-icon-preview');
    var $app = $('#app-icon-preview');

    if (!$hidden.length || !attributes || !attributes.url) {
      return;
    }

    var id = attributes.id || attributes.ID || '';
    if (id) {
      $hidden.val(id);
    }

    var alt = attributes.alt || '';
    var filename = attributes.filename || '';
    var appAlt;
    var browserAlt;

    if (typeof wp !== 'undefined' && wp.i18n) {
      if (alt) {
        appAlt = wp.i18n.sprintf(wp.i18n.__('App icon preview: Current image: %s'), alt);
        browserAlt = wp.i18n.sprintf(wp.i18n.__('Browser icon preview: Current image: %s'), alt);
      } else {
        appAlt = wp.i18n.sprintf(
          wp.i18n.__('App icon preview: The current image has no alternative text. The file name is: %s'),
          filename
        );
        browserAlt = wp.i18n.sprintf(
          wp.i18n.__('Browser icon preview: The current image has no alternative text. The file name is: %s'),
          filename
        );
      }
    } else {
      appAlt = alt || filename;
      browserAlt = alt || filename;
    }

    $app.attr({ src: attributes.url, alt: appAlt });
    $browser.attr({ src: attributes.url, alt: browserAlt });
    $preview.removeClass('hidden');
    $remove.removeClass('hidden');

    document.documentElement.style.setProperty('--site-icon-url', 'url(' + attributes.url + ')');

    if ($choose.length) {
      convertSiteIconButtonsToIcons($choose[0], null);
      var updateLabel = $choose.attr('data-update-text') || 'Change Site Icon';
      $choose.attr('aria-label', updateLabel);
      if ($choose.attr('data-state') !== '1') {
        $choose.attr({
          class: $choose.attr('data-alt-classes'),
          'data-alt-classes': $choose.attr('class'),
          'data-state': '1',
        });
        $choose.removeClass('button button-hero').addClass('yp-icon-action yp-icon-action--primary');
      }
    }
  }

  function openYooSiteIconPicker() {
    window.yooadminOpenPickModalBrowseOnly({
      onSelect: function (data) {
        var att = data && data.attachment;
        var attrs = {};
        if (att && typeof att.toJSON === 'function') {
          attrs = att.toJSON();
        } else if (data) {
          attrs = {
            id: data.id,
            url: data.url,
            alt: '',
            filename: data.url ? String(data.url).split('/').pop() : '',
          };
        }
        if (!attrs.url && data && data.url) {
          attrs.url = data.url;
        }
        if (!attrs.id && data && data.id) {
          attrs.id = data.id;
        }
        applySiteIconAttributes(attrs);
      },
      imagesOnly: false,
    });
  }

  /**
   * Replace the choose button so core site-icon.js handlers (bound to the old node) never run.
   */
  function hijackSiteIconChooseForYooMedia() {
    if (!useYooMedia()) {
      return;
    }

    var btn = document.getElementById('choose-from-library-button');
    if (!btn || btn.dataset.yooWpYooMedia === '1') {
      return;
    }

    var parent = btn.parentNode;
    if (!parent) {
      return;
    }

    var replacement = btn.cloneNode(true);
    replacement.dataset.yooWpYooMedia = '1';
    parent.replaceChild(replacement, btn);

    convertSiteIconButtonsToIcons(replacement, null);

    replacement.addEventListener(
      'click',
      function (e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        openYooSiteIconPicker();
      },
      true
    );
  }

  function initSiteIconRemove() {
    var removeBtn = document.getElementById('js-remove-site-icon');
    if (!removeBtn || removeBtn.dataset.yooWpRemove === '1') {
      return;
    }
    removeBtn.dataset.yooWpRemove = '1';

    removeBtn.addEventListener('click', function () {
      var hidden = document.getElementById('site_icon_hidden_field');
      var preview = document.getElementById('site-icon-preview');
      var choose = document.getElementById('choose-from-library-button');
      var browser = document.getElementById('browser-icon-preview');
      var app = document.getElementById('app-icon-preview');

      if (hidden) {
        hidden.value = 'false';
      }
      removeBtn.classList.add('hidden');
      if (preview) {
        preview.classList.add('hidden');
      }
      if (browser) {
        browser.setAttribute('src', '');
        browser.setAttribute('alt', '');
      }
      if (app) {
        app.setAttribute('src', '');
        app.setAttribute('alt', '');
      }
      document.documentElement.style.setProperty('--site-icon-url', '');

      if (choose && choose.getAttribute('data-state') === '1') {
        var altClasses = choose.getAttribute('data-alt-classes') || '';
        choose.setAttribute('class', altClasses);
        choose.setAttribute('data-alt-classes', choose.className);
        choose.setAttribute('data-state', '');
        convertSiteIconButtonsToIcons(choose, null);
        choose.setAttribute(
          'aria-label',
          choose.getAttribute('data-choose-text') || 'Choose a Site Icon'
        );
      }
    });
  }

  function initSiteIconYooMedia() {
    if (!useYooMedia()) {
      return;
    }
    hijackSiteIconChooseForYooMedia();
    initSiteIconRemove();
    window.requestAnimationFrame(function () {
      hijackSiteIconChooseForYooMedia();
      initSiteIconRemove();
    });
  }

  function getPortal() {
    var $portal = $('#' + PORTAL_ID);
    if ($portal.length) {
      return $portal;
    }
    return $('<div>', { id: PORTAL_ID, class: 'yp-tooltip yp-wp-settings-tooltip-portal', 'aria-hidden': 'true' })
      .appendTo('body');
  }

  function hidePortal() {
    $('#' + PORTAL_ID).removeClass('is-visible').attr('aria-hidden', 'true').css({ display: 'none', opacity: 0 });
  }

  function positionTooltip($icon) {
    var $source = $icon.find('.yp-tooltip');
    if (!$source.length) {
      return;
    }

    var text = ($source.text() || '').trim();
    if (!text) {
      return;
    }

    var margin = 12;
    var maxWidth = Math.min(320, Math.max(200, window.innerWidth - margin * 2));
    var $portal = getPortal();
    $portal.text(text).attr('aria-hidden', 'false');
    $portal.css({
      display: 'block',
      visibility: 'hidden',
      opacity: 0,
      position: 'fixed',
      left: '0',
      top: '0',
      width: maxWidth + 'px',
      maxWidth: maxWidth + 'px',
    });

    var tooltipWidth = $portal.outerWidth() || maxWidth;
    var tooltipHeight = $portal.outerHeight() || 80;
    var iconRect = $icon[0].getBoundingClientRect();
    var gap = 8;
    var viewportW = window.innerWidth;
    var viewportH = window.innerHeight;
    var left;
    var top = iconRect.bottom + gap;

    if (iconRect.left > viewportW * 0.5 || iconRect.right > viewportW - margin - 80) {
      left = iconRect.right - tooltipWidth;
    } else {
      left = iconRect.left;
    }

    if (left + tooltipWidth > viewportW - margin) {
      left = viewportW - margin - tooltipWidth;
    }
    if (left < margin) {
      left = margin;
    }

    if (top + tooltipHeight > viewportH - margin) {
      top = iconRect.top - tooltipHeight - gap;
    }
    if (top < margin) {
      top = margin;
    }

    $portal.css({
      width: tooltipWidth + 'px',
      maxWidth: maxWidth + 'px',
      left: left + 'px',
      top: top + 'px',
      visibility: 'visible',
      display: 'block',
      opacity: 1,
      'z-index': '10000000',
    });
    $portal.addClass('is-visible');
  }

  function initTooltips() {
    var $root = $('body.yoo-wp-settings-experience');

    $root.on('mouseenter focusin', '.yp-help-icon', function () {
      positionTooltip($(this));
    });

    $root.on('mouseleave focusout', '.yp-help-icon', function () {
      hidePortal();
    });

    $(window).on('scroll.yooWpSettingsTip resize.yooWpSettingsTip', hidePortal);
  }

  function initInteractions() {
    initSiteIconYooMedia();
    initTooltips();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runBoot);
  } else {
    runBoot();
  }
})(jQuery);
