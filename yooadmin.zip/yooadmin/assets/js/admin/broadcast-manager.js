/**
 * YOOAdmin - Broadcast channel manager (cross-tab)
 *
 * @package YOOAdmin
 */

(function() {
    'use strict';
    
    // Configuration
    const CONFIG = {
        CHANNEL_NAME: 'yp-notifications',
        MESSAGE_TIMEOUT: 5000,
        MAX_QUEUE_SIZE: 100,
        RETRY_ATTEMPTS: 3,
        CONNECTION_CHECK_INTERVAL: 30000,
        PING_TIMEOUT: 3000
    };
    
    // Message types
    const MESSAGE_TYPES = {
        NOTIFICATION_UPDATE: 'notification_update',
        CONFIG_UPDATE: 'config_update',
        TAB_STATUS: 'tab_status',
        PING: 'ping',
        PONG: 'pong',
        ERROR: 'error',
        HEARTBEAT: 'heartbeat',
        SYNC_REQUEST: 'sync_request',
        SYNC_RESPONSE: 'sync_response',
        CACHE_INVALIDATE: 'cache_invalidate',
        USER_ACTION: 'user_action'
    };
    
    // State management
    const State = {
        channel: null,
        isActive: false,
        tabId: generateTabId(),
        isLeader: false,
        connectedTabs: new Map(),
        messageQueue: [],
        pendingMessages: new Map(),
        connectionTimer: null,
        heartbeatTimer: null,
        metrics: {
            messagesSent: 0,
            messagesReceived: 0,
            messagesQueued: 0,
            connectionErrors: 0,
            lastActivity: Date.now()
        }
    };
    
    // Generate unique tab ID
    function generateTabId() {
        return 'tab_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    // Initialize broadcast manager
    function init() {
        try {
            // Check if BroadcastChannel is supported
            if (typeof BroadcastChannel === 'undefined') {
                initLocalStorageFallback();
                return;
            }
            
            // Create broadcast channel
            State.channel = new BroadcastChannel(CONFIG.CHANNEL_NAME);
            State.channel.onmessage = handleMessage;
            State.channel.onmessageerror = handleError;
            
            // Start heartbeat
            startHeartbeat();
            
            // Start connection monitoring
            startConnectionMonitoring();
            
            // Announce tab presence
            announceTabPresence();
            
            State.isActive = true;
            
        } catch (error) {
            initLocalStorageFallback();
        }
    }
    
    // Initialize localStorage fallback
    function initLocalStorageFallback() {
        // Use storage events for cross-tab communication
        window.addEventListener('storage', handleStorageEvent);
        
        // Simulate broadcast with localStorage
        State.channel = {
            postMessage: function(message) {
                try {
                    localStorage.setItem(CONFIG.CHANNEL_NAME + '_message', JSON.stringify({
                        ...message,
                        _tabId: State.tabId,
                        _timestamp: Date.now()
                    }));
                    
                    // Trigger storage event for same tab
                    window.dispatchEvent(new StorageEvent('storage', {
                        key: CONFIG.CHANNEL_NAME + '_message',
                        newValue: localStorage.getItem(CONFIG.CHANNEL_NAME + '_message')
                    }));
                    
                } catch (error) {
                }
            },
            close: function() {
                window.removeEventListener('storage', handleStorageEvent);
            }
        };
        
        State.isActive = true;
    }
    
    // Handle storage events (fallback)
    function handleStorageEvent(event) {
        if (event.key === CONFIG.CHANNEL_NAME + '_message' && event.newValue) {
            try {
                const message = JSON.parse(event.newValue);
                
                // Ignore messages from same tab
                if (message._tabId === State.tabId) {
                    return;
                }
                
                // Clean up localStorage
                localStorage.removeItem(CONFIG.CHANNEL_NAME + '_message');
                
                // Process message
                handleMessage({ data: message });
                
            } catch (error) {
            }
        }
    }
    
    // Handle incoming messages
    function handleMessage(event) {
        const message = event.data;
        
        if (!message || typeof message !== 'object') {
            return;
        }
        
        State.metrics.messagesReceived++;
        State.metrics.lastActivity = Date.now();
        
        // Update connected tabs
        if (message._tabId) {
            State.connectedTabs.set(message._tabId, {
                lastSeen: Date.now(),
                isLeader: message.isLeader || false
            });
        }
        
        switch (message.type) {
            case MESSAGE_TYPES.PING:
                handlePing(message);
                break;
                
            case MESSAGE_TYPES.PONG:
                handlePong(message);
                break;
                
            case MESSAGE_TYPES.TAB_STATUS:
                handleTabStatus(message);
                break;
                
            case MESSAGE_TYPES.SYNC_REQUEST:
                handleSyncRequest(message);
                break;
                
            case MESSAGE_TYPES.SYNC_RESPONSE:
                handleSyncResponse(message);
                break;
                
            case MESSAGE_TYPES.CACHE_INVALIDATE:
                handleCacheInvalidate(message);
                break;
                
            case MESSAGE_TYPES.USER_ACTION:
                handleUserAction(message);
                break;
                
            case MESSAGE_TYPES.NOTIFICATION_UPDATE:
                handleNotificationUpdate(message);
                break;
                
            case MESSAGE_TYPES.CONFIG_UPDATE:
                handleConfigUpdate(message);
                break;
                
            case MESSAGE_TYPES.ERROR:
                handleError(message);
                break;
                
            default:
                // Unknown message type - ignore
        }
    }
    
    // Handle errors
    function handleError(event) {
        State.metrics.connectionErrors++;
        
        // Try to reconnect
        setTimeout(() => {
            if (State.isActive) {
                init();
            }
        }, 5000);
    }
    
    // Handle ping messages
    function handlePing(message) {
        // Respond with pong
        send({
            type: MESSAGE_TYPES.PONG,
            originalPingId: message.pingId,
            tabId: State.tabId,
            isLeader: State.isLeader
        });
    }
    
    // Handle pong messages
    function handlePong(message) {
        const pendingPing = State.pendingMessages.get(message.originalPingId);
        
        if (pendingPing) {
            clearTimeout(pendingPing.timeout);
            State.pendingMessages.delete(message.originalPingId);
            
            // Update tab status
            State.connectedTabs.set(message.tabId, {
                lastSeen: Date.now(),
                isLeader: message.isLeader || false
            });
        }
    }
    
    // Handle tab status messages
    function handleTabStatus(message) {
        State.connectedTabs.set(message.tabId, {
            lastSeen: Date.now(),
            isLeader: message.isLeader || false,
            url: message.url,
            title: message.title
        });
        
        // Elect leader if needed
        electLeader();
    }
    
    // Handle sync requests
    function handleSyncRequest(message) {
        // Request current notifications from service worker
        if (window.yooadmServiceWorker && window.yooadmServiceWorker.forceRefresh) {
            window.yooadmServiceWorker.forceRefresh();
        }
        
        // Respond with current state
        send({
            type: MESSAGE_TYPES.SYNC_RESPONSE,
            requestId: message.requestId,
            tabId: State.tabId,
            timestamp: Date.now()
        });
    }
    
    // Handle sync responses
    function handleSyncResponse(message) {
        // Forward to service worker
        if (window.yooadmServiceWorker) {
            window.yooadmServiceWorker.forceRefresh();
        }
        
        // Trigger UI update
        const event = new CustomEvent('yp-notification-sync', {
            detail: { source: 'broadcast', message: message }
        });
        window.dispatchEvent(event);
    }
    
    // Handle cache invalidation
    function handleCacheInvalidate(message) {
        // Clear specific cache entries
        if (window.yooadmServiceWorker && window.yooadmServiceWorker.clearCache) {
            window.yooadmServiceWorker.clearCache();
        }
        
        // Trigger cache invalidation event
        const event = new CustomEvent('yp-cache-invalidate', {
            detail: { keys: message.keys, reason: message.reason }
        });
        window.dispatchEvent(event);
    }
    
    // Handle user actions
    function handleUserAction(message) {
        // Forward to service worker
        if (window.yooadmServiceWorker) {
            switch (message.action) {
                case 'mark_read':
                    if (message.notificationId) {
                        window.yooadmServiceWorker.markAsRead(message.notificationId);
                    }
                    break;
                case 'dismiss':
                    if (message.notificationId) {
                        window.yooadmServiceWorker.dismiss(
                            message.notificationId, 
                            message.type, 
                            message.snoozeUntil
                        );
                    }
                    break;
                case 'force_refresh':
                    window.yooadmServiceWorker.forceRefresh();
                    break;
            }
        }
        
        // Broadcast to other tabs
        broadcastAction(message.action, message.data);
    }
    
    // Handle notification updates
    function handleNotificationUpdate(message) {
        // Trigger notification update event
        const event = new CustomEvent('yp-notification-update', {
            detail: message.data
        });
        window.dispatchEvent(event);
    }
    
    // Handle config updates
    function handleConfigUpdate(message) {
        // Update service worker config
        if (window.yooadmServiceWorker && window.yooadmServiceWorker.updateConfig) {
            window.yooadmServiceWorker.updateConfig(message.config);
        }
        
        // Trigger config update event
        const event = new CustomEvent('yp-config-update', {
            detail: message.config
        });
        window.dispatchEvent(event);
    }
    
    // Send message
    function send(message, options = {}) {
        if (!State.isActive || !State.channel) {
            return false;
        }
        
        const enhancedMessage = {
            ...message,
            _tabId: State.tabId,
            _timestamp: Date.now(),
            isLeader: State.isLeader
        };
        
        try {
            State.channel.postMessage(enhancedMessage);
            State.metrics.messagesSent++;
            
            return true;
            
        } catch (error) {
            // Queue message for retry
            if (options.queue !== false) {
                queueMessage(enhancedMessage);
            }
            
            return false;
        }
    }
    
    // Queue message for retry
    function queueMessage(message) {
        State.messageQueue.push({
            ...message,
            _queueTimestamp: Date.now(),
            _retryCount: 0
        });
        
        // Limit queue size
        if (State.messageQueue.length > CONFIG.MAX_QUEUE_SIZE) {
            State.messageQueue.shift();
        }
        
        State.metrics.messagesQueued++;
    }
    
    // Process queued messages
    function processQueuedMessages() {
        if (State.messageQueue.length === 0) {
            return;
        }
        
        const processed = [];
        const failed = [];
        
        State.messageQueue.forEach((queuedMessage, index) => {
            // Remove old messages (older than 5 minutes)
            if (Date.now() - queuedMessage._queueTimestamp > 300000) {
                return;
            }
            
            // Retry failed messages
            if (queuedMessage._retryCount < CONFIG.RETRY_ATTEMPTS) {
                if (send(queuedMessage, { queue: false })) {
                    processed.push(index);
                } else {
                    queuedMessage._retryCount++;
                    failed.push(index);
                }
            } else {
                // Max retries reached, remove
                processed.push(index);
            }
        });
        
        // Remove processed messages
        processed.reverse().forEach(index => {
            State.messageQueue.splice(index, 1);
        });
        
        // Messages processed successfully
    }
    
    // Start heartbeat
    function startHeartbeat() {
        if (State.heartbeatTimer) {
            clearInterval(State.heartbeatTimer);
        }
        
        State.heartbeatTimer = setInterval(() => {
            send({
                type: MESSAGE_TYPES.HEARTBEAT,
                tabId: State.tabId,
                isLeader: State.isLeader,
                url: window.location.href,
                title: document.title
            });
            
            // Clean up old tabs
            cleanupOldTabs();
            
            // Process queued messages
            processQueuedMessages();
            
        }, CONFIG.CONNECTION_CHECK_INTERVAL);
    }
    
    // Start connection monitoring
    function startConnectionMonitoring() {
        // Ping other tabs to establish connection
        setTimeout(() => {
            pingTabs();
        }, 1000);
    }
    
    // Ping all tabs
    function pingTabs() {
        const pingId = generatePingId();
        
        send({
            type: MESSAGE_TYPES.PING,
            pingId: pingId,
            tabId: State.tabId
        });
        
        // Wait for responses
        const timeout = setTimeout(() => {
            State.pendingMessages.delete(pingId);
            electLeader(); // Elect leader based on current tabs
        }, CONFIG.PING_TIMEOUT);
        
        State.pendingMessages.set(pingId, {
            timeout: timeout,
            timestamp: Date.now()
        });
    }
    
    // Generate ping ID
    function generatePingId() {
        return 'ping_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    // Announce tab presence
    function announceTabPresence() {
        send({
            type: MESSAGE_TYPES.TAB_STATUS,
            tabId: State.tabId,
            url: window.location.href,
            title: document.title,
            isLeader: State.isLeader
        });
    }
    
    // Elect leader tab
    function electLeader() {
        if (State.connectedTabs.size === 0) {
            State.isLeader = true;
            return;
        }
        
        // Simple leader election: tab with smallest ID becomes leader
        const allTabs = [State.tabId, ...Array.from(State.connectedTabs.keys())];
        const leaderTab = allTabs.sort()[0];
        
        State.isLeader = leaderTab === State.tabId;
    }
    
    // Clean up old tabs
    function cleanupOldTabs() {
        const now = Date.now();
        const timeout = CONFIG.CONNECTION_CHECK_INTERVAL * 3; // 3 heartbeat intervals
        
        for (const [tabId, tabInfo] of State.connectedTabs) {
            if (now - tabInfo.lastSeen > timeout) {
                State.connectedTabs.delete(tabId);
            }
        }
    }
    
    // Broadcast action
    function broadcastAction(action, data = {}) {
        send({
            type: MESSAGE_TYPES.USER_ACTION,
            action: action,
            data: data,
            tabId: State.tabId
        });
    }
    
    // Invalidate cache
    function invalidateCache(keys, reason = 'broadcast_request') {
        send({
            type: MESSAGE_TYPES.CACHE_INVALIDATE,
            keys: keys || [],
            reason: reason,
            tabId: State.tabId
        });
    }
    
    // Request sync
    function requestSync() {
        const requestId = generatePingId();
        
        send({
            type: MESSAGE_TYPES.SYNC_REQUEST,
            requestId: requestId,
            tabId: State.tabId
        });
    }
    
    // Get metrics
    function getMetrics() {
        return {
            ...State.metrics,
            connectedTabs: State.connectedTabs.size,
            isLeader: State.isLeader,
            queueSize: State.messageQueue.length,
            pendingMessages: State.pendingMessages.size,
            uptime: Date.now() - (State.metrics.lastActivity - State.metrics.lastActivity)
        };
    }
    
    // Destroy broadcast manager
    function destroy() {
        State.isActive = false;
        
        // Clear timers
        if (State.heartbeatTimer) {
            clearInterval(State.heartbeatTimer);
            State.heartbeatTimer = null;
        }
        
        if (State.connectionTimer) {
            clearTimeout(State.connectionTimer);
            State.connectionTimer = null;
        }
        
        // Clear pending messages
        State.pendingMessages.forEach(pending => {
            clearTimeout(pending.timeout);
        });
        State.pendingMessages.clear();
        
        // Close channel
        if (State.channel && State.channel.close) {
            State.channel.close();
            State.channel = null;
        }
        
        // Clear state
        State.connectedTabs.clear();
        State.messageQueue = [];
    }
    
    // Public API
    window.yooadmBroadcast = {
        init: init,
        send: send,
        broadcastAction: broadcastAction,
        invalidateCache: invalidateCache,
        requestSync: requestSync,
        getMetrics: getMetrics,
        destroy: destroy,
        
        // Expose constants
        MESSAGE_TYPES: MESSAGE_TYPES,
        
        // Expose state for debugging
        _state: State,
        _config: CONFIG
    };
    
    // Auto-initialize
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Cleanup on page unload
    window.addEventListener('beforeunload', destroy);
    
})();
