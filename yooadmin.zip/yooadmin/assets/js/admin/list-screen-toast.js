/**
 * YOOAdmin — list screen toasts (posts/pages custom screens).
 * Uses global yooadminShowToast (yp-admin-toast.js, top-right); converts WP admin notices on load.
 *
 * @package YOOAdmin
 */

(function ($) {
    'use strict';

    function isListScreenContext() {
        return (
            $('.wrap.yooadmin-posts-page, .wrap.yooadmin-pages-page').length > 0 ||
            $('.wrap.yooadmin-comments-page').length > 0 ||
            document.body.classList.contains('yooadmin-posts-screen') ||
            document.body.classList.contains('yooadmin-comments-screen') ||
            document.body.classList.contains('yooadmin-pages-screen')
        );
    }

    /**
     * @param {string} type success|error|warning|info
     * @param {string} message
     * @param {number} [duration]
     */
    function show(type, message, duration) {
        type = type || 'info';
        message = String(message || '').trim();
        if (!message) {
            return;
        }

        if (window.yooadminShowToast && typeof window.yooadminShowToast === 'function') {
            window.yooadminShowToast(message, type, duration);
            return;
        }
        if (window.yooadmToast && typeof window.yooadmToast.show === 'function') {
            window.yooadmToast.show(message, type, duration);
            return;
        }

        // Minimal fallback if toast script did not load.
        var $legacy = $('.yoo-notice.yoo-list-screen-toast-fallback');
        $legacy.remove();
        var $notice = $(
            '<div class="yoo-notice yoo-notice-' +
                type +
                ' yoo-list-screen-toast-fallback" role="status"><p></p></div>'
        );
        $notice.find('p').text(message);
        $('body').append($notice);
        setTimeout(function () {
            $notice.addClass('visible');
        }, 10);
        setTimeout(function () {
            $notice.removeClass('visible');
            setTimeout(function () {
                $notice.remove();
            }, 300);
        }, duration || 5000);
    }

    function getNoticeType($notice) {
        if ($notice.hasClass('notice-success') || $notice.hasClass('updated')) {
            return 'success';
        }
        if ($notice.hasClass('notice-error') || $notice.hasClass('error')) {
            return 'error';
        }
        if ($notice.hasClass('notice-warning')) {
            return 'warning';
        }
        return 'info';
    }

    function extractMessage($notice) {
        var $clone = $notice.clone();
        $clone.find('.notice-dismiss').remove();
        return $clone.text().replace(/\s+/g, ' ').trim();
    }

    function shouldHandleAsToast($notice) {
        var el = $notice[0];
        if (!el) {
            return false;
        }
        var classifier = window.yooadminNoticeClassifier;
        if (classifier) {
            if (classifier.shouldConvertToNotification(el)) {
                return false;
            }
            return classifier.shouldConvertToToast(el);
        }
        return (
            $notice.hasClass('notice-success') ||
            $notice.hasClass('updated') ||
            $notice.hasClass('notice-error') ||
            $notice.hasClass('error')
        );
    }

    function convertWpNotice($notice) {
        if (!$notice.length || $notice.data('list-screen-toast-done')) {
            return;
        }
        if (!shouldHandleAsToast($notice)) {
            return;
        }
        $notice.data('list-screen-toast-done', true);

        var message = extractMessage($notice);
        if (!message) {
            return;
        }

        $notice.hide();
        show(getNoticeType($notice), message);
    }

    function convertListScreenWpNotices() {
        if (!isListScreenContext()) {
            return;
        }

        var excludes =
            ':not(.inline):not(.yooadmin-notification):not(.yooadmin-brand-notice):not(.yooadmin-wizard-notice):not(.update-nag)';

        var selectors =
            '#wpbody-content > .notice' +
            excludes +
            ', #wpbody-content > .updated' +
            excludes +
            ', #wpbody-content > .error' +
            excludes +
            ', .wrap.yooadmin-posts-page .notice' +
            excludes +
            ', .wrap.yooadmin-pages-page .notice' +
            excludes;

        $(selectors).each(function () {
            convertWpNotice($(this));
        });
    }

    window.yooadminListScreenToast = {
        show: show,
        success: function (message, duration) {
            show('success', message, duration);
        },
        error: function (message, duration) {
            show('error', message, duration);
        },
        warning: function (message, duration) {
            show('warning', message, duration);
        },
        info: function (message, duration) {
            show('info', message, duration);
        },
        convertWpNotices: convertListScreenWpNotices,
    };

    // Alias used by posts-page.js / pages-page.js
    window.showNotice = function (type, message, duration) {
        show(type, message, duration);
    };

    $(document).ready(function () {
        convertListScreenWpNotices();
        setTimeout(convertListScreenWpNotices, 100);
    });
})(jQuery);
