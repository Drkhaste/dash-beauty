/**
 * YOOAdmin - About modal toggle
 *
 * @package YOOAdmin
 */

(function() {
    'use strict';

    var modal = document.getElementById('yp-about-modal');
    var trigger = document.querySelector('.yp-open-about-modal');
    if (!modal || !trigger) return;

    function openAbout() {
        modal.classList.add('is-visible');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('yp-about-modal-open');
        document.body.style.overflow = 'hidden';
    }

    function closeAbout() {
        modal.classList.remove('is-visible');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('yp-about-modal-open');
        document.body.style.overflow = '';
    }

    trigger.addEventListener('click', function(e) {
        e.preventDefault();
        openAbout();
    });

    modal.querySelectorAll('.yp-about-close').forEach(function(el) {
        el.addEventListener('click', closeAbout);
    });

    modal.addEventListener('click', function(e) {
        if (e.target === modal) closeAbout();
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('is-visible')) {
            closeAbout();
        }
    });
})();
