/**
 * YOOAdmin — plugins.php lightweight experience.
 *
 * Keep action handling native. This script only converts safe WordPress
 * notices into YOOAdmin toasts and leaves activate/deactivate/delete/bulk
 * actions, filters, search, pagination, and auto-updates to WordPress core.
 *
 * @package YOOAdmin
 */

(function ($) {
    'use strict';

    function isPluginsExperienceScreen() {
        return (
            document.body.classList.contains('yooadmin-plugins-screen') ||
            document.body.classList.contains('yooadmin-plugins-page') ||
            (document.body.classList.contains('plugins-php') &&
                document.body.classList.contains('yoo-list-screen'))
        );
    }

    function showToast(type, message, duration) {
        message = String(message || '').trim();
        if (!message) {
            return;
        }
        if (window.yooadminShowToast && typeof window.yooadminShowToast === 'function') {
            window.yooadminShowToast(message, type, duration);
            return;
        }
        if (window.yooadmToast && typeof window.yooadmToast.show === 'function') {
            window.yooadmToast.show(message, type, duration);
        }
    }

    function getNoticeType($notice) {
        if ($notice.hasClass('notice-success') || $notice.hasClass('updated')) {
            return 'success';
        }
        if ($notice.hasClass('notice-error') || $notice.hasClass('error')) {
            return 'error';
        }
        if ($notice.hasClass('notice-warning')) {
            return 'warning';
        }
        return 'info';
    }

    function extractNoticeMessage($notice) {
        var $clone = $notice.clone();
        $clone.find('.notice-dismiss').remove();
        return $clone.text().replace(/\s+/g, ' ').trim();
    }

    function shouldHandleAsToast($notice) {
        var el = $notice[0];
        var classifier = window.yooadminNoticeClassifier;

        if (!el) {
            return false;
        }

        if (classifier) {
            if (classifier.shouldConvertToNotification(el)) {
                return false;
            }
            return classifier.shouldConvertToToast(el);
        }

        return (
            $notice.hasClass('notice-success') ||
            $notice.hasClass('updated') ||
            $notice.hasClass('notice-error') ||
            $notice.hasClass('error')
        );
    }

    function convertWpNotice($notice) {
        if (!$notice.length || $notice.data('plugins-toast-done')) {
            return;
        }
        if (!shouldHandleAsToast($notice)) {
            return;
        }

        var message = extractNoticeMessage($notice);
        if (!message) {
            return;
        }

        $notice.data('plugins-toast-done', true);
        $notice.hide();
        showToast(getNoticeType($notice), message);
    }

    function convertPluginsNotices() {
        if (!isPluginsExperienceScreen()) {
            return;
        }

        var excludes =
            ':not(.inline):not(.yooadmin-notification):not(.yooadmin-brand-notice):not(.yooadmin-wizard-notice):not(.update-nag)';
        var selectors =
            '#wpbody-content .notice' +
            excludes +
            ', #wpbody-content .updated' +
            excludes +
            ', #wpbody-content .error' +
            excludes +
            ', .yooadmin-plugins-page .notice' +
            excludes +
            ', .yoo-pages-content-section .notice' +
            excludes +
            ', .yoo-pages-content-section .updated' +
            excludes +
            ', .yoo-pages-content-section .error' +
            excludes;

        $(selectors).each(function () {
            convertWpNotice($(this));
        });
    }

    function initPluginsNoticeObserver() {
        var root =
            document.querySelector('.yoo-pages-content-section') ||
            document.querySelector('.yooadmin-plugins-page') ||
            document.getElementById('wpbody-content');

        if (!root || typeof MutationObserver === 'undefined') {
            return;
        }

        if (root.getAttribute('data-yoo-plugins-notice-observer') === '1') {
            return;
        }
        root.setAttribute('data-yoo-plugins-notice-observer', '1');

        var timer = null;
        new MutationObserver(function () {
            if (timer) {
                clearTimeout(timer);
            }
            timer = setTimeout(convertPluginsNotices, 80);
        }).observe(root, { childList: true, subtree: true });
    }

    window.yooadminPluginsAdminExperience = {
        showToast: showToast,
        convertNotices: convertPluginsNotices,
    };

    $(document).ready(function () {
        if (!isPluginsExperienceScreen()) {
            return;
        }
        convertPluginsNotices();
        setTimeout(convertPluginsNotices, 150);
        setTimeout(convertPluginsNotices, 450);
        initPluginsNoticeObserver();
    });

    document.addEventListener('yooadmin-plugins-layout-ready', function () {
        if (!isPluginsExperienceScreen()) {
            return;
        }
        initPluginsNoticeObserver();
        convertPluginsNotices();
        setTimeout(convertPluginsNotices, 150);
    });
})(jQuery);
