/**
 * YOOAdmin - User avatar upload (cropping)
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    var cropper = null;
    var currentUserId = null;
    var pendingDeleteBtn = null;
    var cropperInitGen = 0;
    var activeSaveGen = 0;

    function i18n(key, fallback) {
        var bag = window.yooadminAvatarUpload && window.yooadminAvatarUpload.i18n;
        return (bag && bag[key]) ? bag[key] : fallback;
    }

    function getSaveButtonLabels() {
        var $btn = $('#yoo-cropper-save');
        return {
            save: $btn.data('yoo-label-save') || i18n('save', 'Save'),
            saving: $btn.data('yoo-label-saving') || i18n('saving', 'Saving…')
        };
    }

    function resetCropperSaveButton() {
        var labels = getSaveButtonLabels();
        $('#yoo-cropper-save').prop('disabled', false).text(labels.save);
    }

    function teardownCropperStage($stage, $img) {
        if (cropper) {
            try {
                cropper.destroy();
            } catch (err) {
                /* ignore destroy races when re-opening quickly */
            }
            cropper = null;
        }
        $stage.find('cropper-canvas').remove();
        $img.css('display', '').removeAttr('style');
        $stage.css({ width: '', height: '' });
    }

    function centerCropperCanvas($stage, sw, sh) {
        var cv = $stage.find('cropper-canvas')[0];
        if (!cv) {
            return;
        }

        cv.style.width = sw + 'px';
        cv.style.height = sh + 'px';
        cv.getBoundingClientRect();

        var ci = cv.querySelector('cropper-image');
        if (ci) {
            if (typeof ci.$handleLoad === 'function') {
                ci.$handleLoad();
            } else if (ci.$image && ci.$image.complete && ci.$image.naturalWidth > 0) {
                if (typeof ci.$setStyles === 'function') {
                    ci.$setStyles({ width: ci.$image.naturalWidth, height: ci.$image.naturalHeight });
                }
                if (typeof ci.$center === 'function') {
                    ci.$center('contain');
                }
            }
        }

        var sel = cv.querySelector('cropper-selection');
        if (sel && typeof sel.$initSelection === 'function') {
            sel.$initSelection(true, true);
        }
    }

    /**
     * Update every avatar image visible in the admin shell/header.
     *
     * @param {string|{avatar_url?: string, avatar_is_placeholder?: boolean}} payload
     */
    function syncShellAvatars(payload) {
        var src = '';
        var isPlaceholder = false;

        if (payload && typeof payload === 'object') {
            src = payload.avatar_url || '';
            isPlaceholder = !!payload.avatar_is_placeholder;
        } else if (typeof payload === 'string') {
            src = payload;
        }

        if (!src) {
            return;
        }

        $('.yp-user-photo').each(function () {
            $(this).attr('src', src);
            $(this).toggleClass('yp-user-photo--placeholder', isPlaceholder);
        });

        $('.yooadmin-bar-avatar, .yooadmin-bar-user-info img, #wp-admin-bar-my-account img').attr('src', src);
    }

    function updateBarAvatars(src) {
        syncShellAvatars({
            avatar_url: src,
            avatar_is_placeholder: false
        });
    }

    window.yooadminSyncShellAvatars = syncShellAvatars;

    function getCropperCtor() {
        var C = window.Cropper;
        if (!C) { return null; }
        if (typeof C.default === 'function') { return C.default; }
        if (typeof C === 'function') { return C; }
        return null;
    }

    function mountAvatarDialogs() {
        ['#yoo-avatar-delete-modal', '#yoo-avatar-cropper-modal'].forEach(function (selector) {
            var $modal = $(selector);
            if ($modal.length && !$modal.data('yoo-portaled')) {
                $modal.appendTo(document.body).data('yoo-portaled', 1);
            }
        });
    }

    $(document).ready(function() {
        mountAvatarDialogs();

        $('#yoo-avatar-upload-input').on('change', function(e) {
            var file = e.target.files[0];
            if (!file) { return; }

            if (!file.type.match('image.*')) {
                window.yooadmToast && yooadmToast.error(i18n('invalidImage', 'Please select an image file.'));
                return;
            }
            if (file.size > 5 * 1024 * 1024) {
                window.yooadmToast && yooadmToast.error(i18n('fileTooLarge', 'File size must be less than 5MB.'));
                return;
            }

            currentUserId = $(this).data('user-id');

            var reader = new FileReader();
            reader.onload = function(ev) { showCropper(ev.target.result); };
            reader.readAsDataURL(file);
            $(e.target).val('');
        });

        $('#yoo-cropper-close, #yoo-cropper-cancel').on('click', closeCropper);
        $('#yoo-cropper-save').on('click', saveCroppedImage);

        $(document).on('click', '#yoo-avatar-delete-btn', openDeleteAvatarModal);

        $('#yoo-avatar-delete-cancel').on('click', closeDeleteAvatarModal);
        $('#yoo-avatar-delete-confirm').on('click', confirmDeleteAvatar);
        $(document).on('click', '#yoo-avatar-delete-modal', function (e) {
            if (e.target === this) {
                closeDeleteAvatarModal();
            }
        });
        $(document).on('keydown', function (e) {
            if (e.key === 'Escape' && $('#yoo-avatar-delete-modal').hasClass('show')) {
                closeDeleteAvatarModal();
            }
        });
    });

    function openDeleteAvatarModal(e) {
        e.preventDefault();
        pendingDeleteBtn = $(e.currentTarget);
        $('#yoo-avatar-delete-modal').addClass('show').attr('aria-hidden', 'false').prop('hidden', false).removeAttr('hidden');
    }

    function closeDeleteAvatarModal() {
        $('#yoo-avatar-delete-modal').removeClass('show').attr('aria-hidden', 'true').prop('hidden', true).attr('hidden', 'hidden');
        pendingDeleteBtn = null;
    }

    function confirmDeleteAvatar() {
        var $btn = pendingDeleteBtn;
        closeDeleteAvatarModal();
        if (!$btn || !$btn.length) {
            return;
        }
        runDeleteAvatar($btn);
    }

    function runDeleteAvatar($btn) {
        var userId = $btn.data('user-id');
        var nonce = $btn.data('nonce');

        $btn.prop('disabled', true);

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: { action: 'yooadmin_delete_avatar', user_id: userId, nonce: nonce },
            success: function (response) {
                if (response.success) {
                    var data = response.data || {};
                    var base2 = data.avatar_url || '';
                    var sep2 = base2.indexOf('?') !== -1 ? '&' : '?';
                    var defaultSrc = base2 ? (base2 + sep2 + '_=' + Date.now()) : '';
                    if (defaultSrc) {
                        $('.yoo-profile-avatar img')
                            .attr('src', defaultSrc)
                            .removeClass('yoo-avatar--no-photo avatar-default');
                        syncShellAvatars({
                            avatar_url: defaultSrc,
                            avatar_is_placeholder: !!data.avatar_is_placeholder
                        });
                    }
                    $btn.attr('data-has-yooadmin-photo', '0').prop('hidden', true).attr('hidden', 'hidden');
                    $(document).trigger('yooadminAvatarSourceChanged', [{
                        avatar_url: defaultSrc,
                        avatar_source: data.avatar_source || 'gravatar',
                        avatar_is_placeholder: !!data.avatar_is_placeholder,
                        has_custom_avatar: !!data.has_custom_avatar
                    }]);
                    window.yooadmToast && yooadmToast.success(
                        data.message || i18n('deleteSuccess', 'Profile photo removed.')
                    );
                } else {
                    window.yooadmToast && yooadmToast.error(response.data.message || i18n('deleteFailed', 'Failed to delete avatar.'));
                    $btn.prop('disabled', false);
                }
            },
            error: function () {
                window.yooadmToast && yooadmToast.error(i18n('errorGeneric', 'An error occurred. Please try again.'));
                $btn.prop('disabled', false);
            }
        });
    }

    function showCropper(imageSrc) {
        var $modal = $('#yoo-avatar-cropper-modal');
        var $stage = $modal.find('.yoo-cropper-stage');
        var $img = $('#yoo-cropper-image');
        var initGen = ++cropperInitGen;

        activeSaveGen++;
        resetCropperSaveButton();
        teardownCropperStage($stage, $img);
        $img.attr('src', imageSrc);
        $modal.addClass('show').attr('aria-hidden', 'false').prop('hidden', false).removeAttr('hidden');

        function init() {
            if (initGen !== cropperInitGen) {
                return;
            }

            var img = $img[0];
            var nw = img.naturalWidth;
            var nh = img.naturalHeight;
            if (!nw || !nh) {
                return;
            }

            var Ctor = getCropperCtor();
            if (!Ctor) {
                window.yooadmToast && yooadmToast.error(i18n('cropperLoadFailed', 'Cropper failed to load. Please refresh the page.'));
                return;
            }

            var $panel = $modal.find('.yoo-avatar-dialog__panel').first();
            var boxW = $panel.innerWidth() || Math.floor(window.innerWidth() * 0.85);
            var maxW = Math.max(200, boxW - 40);
            var maxH = Math.min(500, Math.floor(window.innerHeight * 0.60));
            var sc = Math.min(maxW / nw, maxH / nh, 1);
            var sw = Math.max(100, Math.floor(nw * sc));
            var sh = Math.max(100, Math.floor(nh * sc));

            $stage.css({ width: sw + 'px', height: sh + 'px' });

            cropper = new Ctor(img, {
                template:
                    '<cropper-canvas background>' +
                    '<cropper-image scalable translatable></cropper-image>' +
                    '<cropper-shade hidden></cropper-shade>' +
                    '<cropper-handle action="select" plain></cropper-handle>' +
                    '<cropper-selection initial-coverage="0.8" aspect-ratio="1" movable resizable>' +
                    '<cropper-grid role="grid" bordered covered></cropper-grid>' +
                    '<cropper-crosshair centered></cropper-crosshair>' +
                    '<cropper-handle action="move" theme-color="rgba(255,255,255,0.35)"></cropper-handle>' +
                    '<cropper-handle action="n-resize"></cropper-handle>' +
                    '<cropper-handle action="e-resize"></cropper-handle>' +
                    '<cropper-handle action="s-resize"></cropper-handle>' +
                    '<cropper-handle action="w-resize"></cropper-handle>' +
                    '<cropper-handle action="ne-resize"></cropper-handle>' +
                    '<cropper-handle action="nw-resize"></cropper-handle>' +
                    '<cropper-handle action="se-resize"></cropper-handle>' +
                    '<cropper-handle action="sw-resize"></cropper-handle>' +
                    '</cropper-selection>' +
                    '</cropper-canvas>',
            });

            requestAnimationFrame(function() {
                if (initGen !== cropperInitGen) {
                    return;
                }
                $img.css('display', 'none');
                centerCropperCanvas($stage, sw, sh);
                requestAnimationFrame(function() {
                    if (initGen !== cropperInitGen) {
                        return;
                    }
                    centerCropperCanvas($stage, sw, sh);
                });
            });
        }

        if ($img[0].complete && $img[0].naturalWidth > 0) {
            requestAnimationFrame(function() {
                requestAnimationFrame(init);
            });
        } else {
            $img.one('load', function() {
                requestAnimationFrame(function() {
                    requestAnimationFrame(init);
                });
            });
        }
    }

    function closeCropper() {
        var $modal = $('#yoo-avatar-cropper-modal');
        var $stage = $modal.find('.yoo-cropper-stage');
        var $img = $('#yoo-cropper-image');

        cropperInitGen++;
        activeSaveGen++;
        $modal.removeClass('show').attr('aria-hidden', 'true').prop('hidden', true).attr('hidden', 'hidden');
        teardownCropperStage($stage, $img);
        resetCropperSaveButton();
    }

    function saveCroppedImage() {
        if (!cropper) {
            return;
        }

        var labels = getSaveButtonLabels();
        var $btn = $('#yoo-cropper-save');
        var saveGen = ++activeSaveGen;

        $btn.prop('disabled', true).text(labels.saving);

        var selection = cropper.getCropperSelection();
        if (!selection) {
            if (saveGen === activeSaveGen) {
                resetCropperSaveButton();
            }
            return;
        }

        selection.$toCanvas({ width: 300, height: 300 }).then(function(canvas) {
            if (saveGen !== activeSaveGen) {
                return;
            }
            canvas.toBlob(function(blob) {
                if (saveGen !== activeSaveGen || !blob) {
                    if (saveGen === activeSaveGen) {
                        resetCropperSaveButton();
                    }
                    return;
                }

                var formData = new FormData();
                formData.append('action', 'yooadmin_upload_avatar');
                formData.append('user_id', currentUserId);
                formData.append('avatar', blob, 'avatar.jpg');
                formData.append('nonce', $('#yoo-avatar-upload-input').data('nonce') || '');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (saveGen !== activeSaveGen) {
                            return;
                        }
                        if (response.success) {
                            var data = response.data || {};
                            var newSrc = '';
                            if (data.avatar_url) {
                                var base = data.avatar_url;
                                var sep = base.indexOf('?') !== -1 ? '&' : '?';
                                newSrc = base + sep + '_=' + Date.now();
                            }

                            if (newSrc && window.yooadmProfile && window.yooadmProfile.avatarSourcePreviews) {
                                window.yooadmProfile.avatarSourcePreviews.yooadmin = {
                                    url: newSrc,
                                    is_placeholder: false,
                                    has_custom_avatar: true
                                };
                            }

                            if (newSrc) {
                                $('.yoo-profile-avatar img')
                                    .attr('src', newSrc)
                                    .removeClass('yoo-avatar--no-photo avatar-default');
                                syncShellAvatars({
                                    avatar_url: newSrc,
                                    avatar_is_placeholder: false
                                });
                            }

                            var $form = $('#yoo-profile-edit-form');
                            if ($form.length) {
                                $form.data('initial-avatar-source', 'yooadmin');
                            }

                            $(document).trigger('yooadminAvatarSourceChanged', [{
                                avatar_url: newSrc,
                                avatar_source: data.avatar_source || 'yooadmin',
                                avatar_is_placeholder: false,
                                has_custom_avatar: true
                            }]);

                            var $deleteBtn = $('#yoo-avatar-delete-btn');
                            if (!$deleteBtn.length) {
                                var $input = $('#yoo-avatar-upload-input');
                                var $delBtn = $(
                                    '<button type="button" id="yoo-avatar-delete-btn"' +
                                    ' class="yoo-avatar-delete-btn" data-has-yooadmin-photo="1"' +
                                    ' title="Remove Photo" aria-label="Remove Photo">' +
                                    '<span class="dashicons dashicons-trash" aria-hidden="true"></span>' +
                                    '</button>'
                                );
                                $delBtn.data('user-id', $input.data('user-id'));
                                $delBtn.data('nonce', $input.data('nonce'));
                                $delBtn.attr('data-has-yooadmin-photo', '1');
                                var $avatar = $input.closest('#yoo-profile-avatar');
                                if (!$avatar.length) {
                                    $avatar = $input.closest('.yoo-profile-avatar');
                                }
                                if ($avatar.length) {
                                    $avatar.append($delBtn);
                                }
                            } else {
                                $deleteBtn.attr('data-has-yooadmin-photo', '1').prop('hidden', false).removeAttr('hidden');
                            }
                            closeCropper();
                            window.yooadmToast && yooadmToast.success(i18n('saveSuccess', 'Profile photo updated successfully.'));
                        } else {
                            window.yooadmToast && yooadmToast.error(response.data.message || i18n('saveFailed', 'Failed to upload avatar.'));
                            resetCropperSaveButton();
                        }
                    },
                    error: function() {
                        if (saveGen !== activeSaveGen) {
                            return;
                        }
                        window.yooadmToast && yooadmToast.error(i18n('errorGeneric', 'An error occurred. Please try again.'));
                        resetCropperSaveButton();
                    }
                });
            }, 'image/jpeg', 0.9);
        }).catch(function() {
            if (saveGen !== activeSaveGen) {
                return;
            }
            window.yooadmToast && yooadmToast.error(i18n('processFailed', 'Could not process image. Please try again.'));
            resetCropperSaveButton();
        });
    }

})(jQuery);
