(function () {
  'use strict';

  var root = document.querySelector('.yoo-network-classic-wrap');
  if (!root) {
    return;
  }

  var cfg = window.yooadminNetworkClassicPage || {};
  var i18n = cfg.i18n || {};
  var toastHideTimer = null;
  var toastRemoveTimer = null;

  function t(key, fallback) {
    return i18n[key] || fallback || '';
  }

  function showToast(message, type) {
    if (!message) {
      return;
    }
    type = type === 'error' ? 'error' : 'success';
    document.querySelectorAll('.yp-toast-message.yoo-network-classic-toast').forEach(function (el) {
      if (el.parentNode) {
        el.parentNode.removeChild(el);
      }
    });
    if (toastHideTimer) {
      clearTimeout(toastHideTimer);
      toastHideTimer = null;
    }
    if (toastRemoveTimer) {
      clearTimeout(toastRemoveTimer);
      toastRemoveTimer = null;
    }

    var iconChar = type === 'error' ? '✕' : '✓';
    var toast = document.createElement('div');
    toast.className = 'yp-toast-message yoo-network-classic-toast yp-toast-' + type;
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');

    var icon = document.createElement('span');
    icon.className = 'yp-toast-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = iconChar;

    var text = document.createElement('span');
    text.className = 'yp-toast-text';
    text.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(text);
    document.body.appendChild(toast);

    window.setTimeout(function () {
      toast.classList.add('yp-toast-show');
    }, 10);

    toastHideTimer = window.setTimeout(function () {
      toast.classList.remove('yp-toast-show');
      toastRemoveTimer = window.setTimeout(function () {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3200);
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', 'readonly');
      ta.style.position = 'absolute';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        resolve();
      } catch (err) {
        reject(err);
      } finally {
        document.body.removeChild(ta);
      }
    });
  }

  root.addEventListener('click', function (event) {
    var btn = event.target.closest('.yoo-network-classic-copy');
    if (!btn || !root.contains(btn)) {
      return;
    }
    event.preventDefault();
    var targetId = btn.getAttribute('data-copy-target');
    var block = targetId ? document.getElementById(targetId) : null;
    if (!block) {
      showToast(t('copyError', 'Could not copy.'), 'error');
      return;
    }
    copyText(block.textContent || '')
      .then(function () {
        showToast(t('copied', 'Copied to clipboard.'), 'success');
      })
      .catch(function () {
        showToast(t('copyError', 'Could not copy.'), 'error');
      });
  });

  root.querySelectorAll('[data-yoo-tip]').forEach(function (el) {
    el.setAttribute('title', el.getAttribute('data-yoo-tip') || '');
  });

  var tabsRoot = root.querySelector('[data-yoo-network-classic-tabs]');
  if (tabsRoot) {
    tabsRoot.addEventListener('click', function (event) {
      var tabBtn = event.target.closest('.yp-tab[data-tab]');
      if (!tabBtn || !tabsRoot.contains(tabBtn)) {
        return;
      }
      var tabId = tabBtn.getAttribute('data-tab');
      tabsRoot.querySelectorAll('.yp-tab').forEach(function (btn) {
        var active = btn === tabBtn;
        btn.classList.toggle('is-active', active);
        btn.setAttribute('aria-selected', active ? 'true' : 'false');
      });
      tabsRoot.querySelectorAll('.yp-tab-panel').forEach(function (panel) {
        panel.classList.toggle('is-active', panel.getAttribute('data-panel') === tabId);
      });
    });
  }
})();
