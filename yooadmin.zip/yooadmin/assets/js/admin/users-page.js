/**
 * YOOAdmin - Users page script
 *
 * @package YOOAdmin
 */

(function($){
  'use strict';

  function bindDisplayName() {
    var $first = $('#yooadmin-first-name, #yoo-first-name');
    var $last  = $('#yooadmin-last-name, #yoo-last-name');
    var $display = $('#yoo-display-name');

    if (!$display.length) {
      return;
    }

    var update = function() {
      if ($display.data('yooadmin-manual')) {
        return;
      }
      var first = $first.first().val() || '';
      var last  = $last.first().val() || '';
      var suggestion = (first + ' ' + last).trim();
      if (suggestion.length) {
        $display.val(suggestion);
      }
    };

    $first.on('input', update);
    $last.on('input', update);
    $display.on('input', function(){
      if ($(this).val().length) {
        $(this).data('yooadmin-manual', true);
      } else {
        $(this).data('yooadmin-manual', false);
        update();
      }
    });
  }

  function randomPassword(length) {
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*()';
    var result = '';
    for (var i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  function strengthLabel(score, value) {
    if (!value || !value.length) {
      return 'empty';
    }
    // Mirror wp-admin/js/user-profile.js (zxcvbn 0–4; 5 = confirm mismatch).
    if (score < 0 || score <= 2) {
      return 'weak';
    }
    if (score === 3) {
      return 'medium';
    }
    if (score === 4) {
      return 'strong';
    }
    return 'weak';
  }

  function buildDisallowedList(extraFields) {
    var list = [];
    if (window.wp && wp.passwordStrength && typeof wp.passwordStrength.userInputDisallowedList === 'function') {
      list = wp.passwordStrength.userInputDisallowedList();
    }
    (extraFields || []).forEach(function (field) {
      if (field && list.indexOf(field) === -1) {
        list.push(field);
      }
    });
    return list;
  }

  function fallbackStrengthScore(value) {
    if (value.length < 4) {
      return 0;
    }
    if (value.length < 8) {
      return 1;
    }
    var checks = 0;
    if (/[A-Z]/.test(value)) { checks++; }
    if (/[a-z]/.test(value)) { checks++; }
    if (/\d/.test(value)) { checks++; }
    if (/[!@#$%^&*()_\-+=]/.test(value)) { checks++; }
    if (checks <= 1) {
      return 2;
    }
    if (checks <= 2) {
      return 3;
    }
    return 4;
  }

  function initPasswordTools() {
    var $password = $('#yooadmin-user-pass');
    if (!$password.length) {
      return;
    }

    var $meter = $('.yoo-password-meter');
    var $bar = $meter.find('.yoo-password-meter__bar');
    var $label = $meter.find('.yoo-password-meter__label');
    var $toggle = $('.yoo-password-toggle');
    var $generate = $('.yoo-generate-password');

    var updateStrength = function(value) {
      value = value || '';
      var disallowed = [];
      var userFields = [
        $('#yooadmin-user-login').val(),
        $('#yooadmin-user-email').val(),
        $('#yooadmin-first-name').val(),
        $('#yooadmin-last-name').val()
      ];

      var strength = 0;
      if (!value.length) {
        strength = 0;
      } else if (window.wp && wp.passwordStrength && typeof wp.passwordStrength.meter === 'function') {
        // Third arg is the confirm field (pass2); pass the same value so mismatch (5) is never returned.
        disallowed = buildDisallowedList(userFields);
        strength = wp.passwordStrength.meter(value, disallowed, value);
        if (strength < 0) {
          strength = fallbackStrengthScore(value);
        }
      } else {
        strength = fallbackStrengthScore(value);
      }

      var labelKey = strengthLabel(strength, value);
      $meter.attr('data-strength', labelKey);
      switch (labelKey) {
        case 'weak':
          $label.text(yooadmUsers && yooadmUsers.i18nWeak ? yooadmUsers.i18nWeak : 'Strength: Weak');
          break;
        case 'medium':
          $label.text(yooadmUsers && yooadmUsers.i18nMedium ? yooadmUsers.i18nMedium : 'Strength: Medium');
          break;
        case 'strong':
          $label.text(yooadmUsers && yooadmUsers.i18nStrong ? yooadmUsers.i18nStrong : 'Strength: Strong');
          break;
        default:
          $label.text(yooadmUsers && yooadmUsers.i18nEmpty ? yooadmUsers.i18nEmpty : 'Strength: Empty');
      }
    };

    $password.on('input keyup change', function(){
      updateStrength($(this).val());
    });

    $toggle.on('click', function(){
      var type = $password.attr('type') === 'password' ? 'text' : 'password';
      $password.attr('type', type);
      var pressed = type === 'text';
      $(this).attr('aria-pressed', pressed);
      $(this).find('.dashicons').toggleClass('dashicons-visibility', !pressed).toggleClass('dashicons-hidden', pressed);
    });

    $generate.on('click', function(e){
      e.preventDefault();
      var generated = randomPassword(14);
      $password.val(generated).trigger('input');
      $password.focus();
    });

    updateStrength($password.val());
  }

  function initUsersSearch() {
    var $searchInput = $('#yoo-users-search-input');
    if (!$searchInput.length) {
      return;
    }

    var searchTimeout;
    var currentUrl = new URL(window.location.href);
    var baseUrl = currentUrl.pathname + '?page=yooadmin-users';

    $searchInput.on('input', function() {
      var searchValue = $(this).val().trim();
      clearTimeout(searchTimeout);

      searchTimeout = setTimeout(function() {
        var url = baseUrl;
        
        // Preserve role filter if exists
        var role = currentUrl.searchParams.get('role');
        if (role) {
          url += '&role=' + encodeURIComponent(role);
        }

        var sort = currentUrl.searchParams.get('sort');
        if (sort) {
          url += '&sort=' + encodeURIComponent(sort);
        }

        // Add search query
        if (searchValue) {
          url += '&s=' + encodeURIComponent(searchValue);
        } else {
          // Remove search from URL if empty
          url = url.replace(/[&?]s=.*?(&|$)/, '$1');
        }

        // Navigate to new URL
        window.location.href = url;
      }, 500); // Wait 500ms after user stops typing
    });

    // Also handle Enter key for immediate search
    $searchInput.on('keypress', function(e) {
      if (e.which === 13) {
        e.preventDefault();
        clearTimeout(searchTimeout);
        var searchValue = $(this).val().trim();
        var url = baseUrl;
        
        var role = currentUrl.searchParams.get('role');
        if (role) {
          url += '&role=' + encodeURIComponent(role);
        }

        var sortOnEnter = currentUrl.searchParams.get('sort');
        if (sortOnEnter) {
          url += '&sort=' + encodeURIComponent(sortOnEnter);
        }

        if (searchValue) {
          url += '&s=' + encodeURIComponent(searchValue);
        } else {
          url = url.replace(/[&?]s=.*?(&|$)/, '$1');
        }

        window.location.href = url;
      }
    });
  }

  function initUsersFilters() {
    var $filters = $('.yoo-filter-chip');
    if (!$filters.length) {
      return;
    }

    $filters.on('click', function(e) {
      e.preventDefault();
      var $chip = $(this);
      var role = $chip.data('role') || '';
      var currentUrl = new URL(window.location.href);
      var search = currentUrl.searchParams.get('s') || '';
      var sort = currentUrl.searchParams.get('sort') || 'recent';

      // Update active state
      $filters.removeClass('is-active');
      $chip.addClass('is-active');

      // Update URL without reload
      var newUrl = new URL(window.location.href);
      newUrl.searchParams.set('page', 'yooadmin-users');
      newUrl.searchParams.set('paged', '1');
      if (role) {
        newUrl.searchParams.set('role', role);
      } else {
        newUrl.searchParams.delete('role');
      }
      if (search) {
        newUrl.searchParams.set('s', search);
      } else {
        newUrl.searchParams.delete('s');
      }
      if (sort && sort !== 'recent') {
        newUrl.searchParams.set('sort', sort);
      } else {
        newUrl.searchParams.delete('sort');
      }
      window.history.pushState({}, '', newUrl);

      // Show loading state
      var $content = $('#yoo-users-content');
      $content.css('opacity', '0.5').css('pointer-events', 'none');

      // Load users via AJAX
      $.ajax({
        url: yooadmUsers.ajaxUrl,
        type: 'GET',
        data: {
          action: 'yooadmin_filter_users',
          nonce: yooadmUsers.nonce,
          role: role,
          s: search,
          sort: sort,
          paged: 1
        },
        success: function(response) {
          if (response.success && response.data && response.data.html) {
            $content.html(response.data.html);
            $content.css('opacity', '1').css('pointer-events', 'auto');
          } else {
            $content.css('opacity', '1').css('pointer-events', 'auto');
            alert(response.data && response.data.message ? response.data.message : 'Error loading users');
          }
        },
        error: function() {
          $content.css('opacity', '1').css('pointer-events', 'auto');
          alert('Error loading users. Please refresh the page.');
        }
      });
    });
  }

  function initUsersPagination() {
    $(document).on('click', '.yoo-users-pagination a', function(e) {
      e.preventDefault();
      var $link = $(this);
      var href = $link.attr('href');
      if (!href) {
        return;
      }

      var url = new URL(href);
      var role = url.searchParams.get('role') || '';
      var search = url.searchParams.get('s') || '';
      var sort = url.searchParams.get('sort') || 'recent';
      var paged = url.searchParams.get('paged') || '1';

      // Show loading state
      var $content = $('#yoo-users-content');
      $content.css('opacity', '0.5').css('pointer-events', 'none');

      // Load users via AJAX
      $.ajax({
        url: yooadmUsers.ajaxUrl,
        type: 'GET',
        data: {
          action: 'yooadmin_filter_users',
          nonce: yooadmUsers.nonce,
          role: role,
          s: search,
          sort: sort,
          paged: paged
        },
        success: function(response) {
          if (response.success && response.data && response.data.html) {
            $content.html(response.data.html);
            $content.css('opacity', '1').css('pointer-events', 'auto');
            
            // Update URL without reload
            window.history.pushState({}, '', href);
            
            // Scroll to top
            $('html, body').animate({
              scrollTop: $('.yoo-users-toolbar').offset().top - 100
            }, 300);
          } else {
            $content.css('opacity', '1').css('pointer-events', 'auto');
            alert(response.data && response.data.message ? response.data.message : 'Error loading users');
          }
        },
        error: function() {
          $content.css('opacity', '1').css('pointer-events', 'auto');
          alert('Error loading users. Please refresh the page.');
        }
      });
    });
  }

  function initUserFormSelects(selector, extraClass) {
    var selects = document.querySelectorAll(selector);
    if (!selects.length) {
      return;
    }

    var wrapFn = window.yooadminUiSelect && window.yooadminUiSelect.wrap;
    selects.forEach(function (sel) {
      var ui = sel.closest('.yp-ui-select');
      if (!ui && typeof wrapFn === 'function') {
        wrapFn(sel, { force: true });
        ui = sel.closest('.yp-ui-select');
      }
      if (ui) {
        ui.classList.add('yoo-user-form-select-ui');
        if (extraClass) {
          ui.classList.add(extraClass);
        }
      }
    });
  }

  function initUserFormRoleSelect() {
    initUserFormSelects('select.yoo-user-form-select[data-yoo-user-role-select]', 'yoo-user-role-select');
  }

  function initUserProfileFormSelects() {
    initUserFormSelects('select.yoo-user-form-select[data-yoo-user-form-select]', 'yoo-user-2fa-provider-select');
  }

  function initUserFormHelpTooltips() {
    var roots = document.querySelectorAll('.yooadmin-user-create, .yooadmin-user-profile, .yooadmin-network-user-create, .yoo-wp-core-profile-2fa');
    if (!roots.length) {
      return;
    }

    var icons = [];
    roots.forEach(function (root) {
      root.querySelectorAll('.yp-help-icon').forEach(function (icon) {
        icons.push(icon);
      });
    });
    icons.forEach(function (icon) {
      var tooltip = icon.querySelector('.yp-tooltip');
      if (!tooltip || icon.getAttribute('data-yoo-user-tooltip-bound') === '1') {
        return;
      }
      icon.setAttribute('data-yoo-user-tooltip-bound', '1');
      tooltip.classList.add('yoo-user-form-tooltip');

      function positionTooltip() {
        if (tooltip.parentNode !== document.body) {
          document.body.appendChild(tooltip);
        }

        tooltip.style.setProperty('position', 'fixed', 'important');
        tooltip.style.setProperty('transform', 'none', 'important');
        tooltip.style.setProperty('margin', '0', 'important');
        tooltip.style.setProperty('z-index', '9999999', 'important');
        tooltip.style.setProperty('bottom', 'auto', 'important');

        var tooltipWidth = Math.min(320, window.innerWidth - 40);
        tooltip.style.setProperty('width', tooltipWidth + 'px', 'important');

        tooltip.style.setProperty('display', 'block', 'important');
        tooltip.style.setProperty('opacity', '1', 'important');
        tooltip.style.setProperty('visibility', 'visible', 'important');

        var iconRect = icon.getBoundingClientRect();
        var tooltipHeight = tooltip.offsetHeight || 80;
        var left = iconRect.left + iconRect.width / 2 - tooltipWidth / 2;
        var top = iconRect.top - tooltipHeight - 8;

        if (left < 20) {
          left = 20;
        }
        if (left + tooltipWidth > window.innerWidth - 20) {
          left = window.innerWidth - tooltipWidth - 20;
        }
        if (top < 20) {
          top = iconRect.bottom + 8;
        }

        tooltip.style.setProperty('left', left + 'px', 'important');
        tooltip.style.setProperty('top', top + 'px', 'important');
      }

      function hideTooltip() {
        tooltip.style.setProperty('display', 'none', 'important');
        tooltip.style.setProperty('opacity', '0', 'important');
        tooltip.style.setProperty('visibility', 'hidden', 'important');
        if (tooltip.parentNode === document.body) {
          icon.appendChild(tooltip);
        }
      }

      icon.addEventListener('mouseenter', positionTooltip);
      icon.addEventListener('focusin', positionTooltip);
      icon.addEventListener('mouseleave', hideTooltip);
      icon.addEventListener('focusout', hideTooltip);
    });
  }

  function initListScreenUi(root) {
    if (window.yooadminUiSelect && typeof window.yooadminUiSelect.initIn === 'function') {
      window.yooadminUiSelect.initIn(root || document);
    }
  }

  function initUsersListSelects() {
    var root = document.querySelector('.yooadmin-users-page');
    if (!root) {
      return;
    }

    initListScreenUi(root);

    var wrapFn = window.yooadminUiSelect && window.yooadminUiSelect.wrap;
    if (typeof wrapFn !== 'function') {
      return;
    }

    root.querySelectorAll('select.yoo-sort-select, select.yoo-bulk-select').forEach(function(sel) {
      var ui = sel.closest('.yp-ui-select');
      if (!ui) {
        wrapFn(sel, { force: true });
        ui = sel.closest('.yp-ui-select');
      }
      if (ui) {
        ui.classList.add('yoo-users-list-select-ui');
        if (sel.classList.contains('yoo-sort-select')) {
          ui.classList.add('yoo-users-sort-select-ui');
        }
        if (sel.classList.contains('yoo-bulk-select')) {
          ui.classList.add('yoo-users-bulk-select-ui');
        }
      }
    });
  }

  function initUsersSort() {
    var $sort = $('#yoo-users-sort');
    if (!$sort.length) {
      return;
    }

    $sort.on('change', function() {
      var sortValue = $(this).val() || 'recent';
      var currentUrl = new URL(window.location.href);
      currentUrl.searchParams.set('page', 'yooadmin-users');
      currentUrl.searchParams.set('paged', '1');
      if (sortValue === 'recent') {
        currentUrl.searchParams.delete('sort');
      } else {
        currentUrl.searchParams.set('sort', sortValue);
      }
      window.location.href = currentUrl.toString();
    });
  }

  function initUserProfileLocaleSelect() {
    var sel = document.getElementById('yoo-locale');
    if (!sel) {
      return;
    }
    var wrapFn = window.yooadminUiSelect && window.yooadminUiSelect.wrap;
    if (typeof wrapFn === 'function') {
      wrapFn(sel, { force: true });
      var ui = sel.closest('.yp-ui-select');
      if (ui) {
        ui.classList.add('yoo-user-locale-select', 'yoo-user-form-select-ui');
      }
    }
  }

  function initUsersMetricsToggle() {
    var $toggle = $('.yoo-users-metrics-toggle');
    var $metrics = $('.yoo-users-hero__metrics');
    
    if (!$toggle.length || !$metrics.length) {
      return;
    }

    var i18n = (window.yooadmUsers && window.yooadmUsers.i18n) ? window.yooadmUsers.i18n : {};
    var showText = i18n.showStatistics || 'Show Statistics';
    var hideText = i18n.hideStatistics || 'Hide Statistics';
    
    var storageKey = 'yooadmin_users_metrics_expanded';
    
    // Get saved preference
    var isExpanded = localStorage.getItem(storageKey) === 'true';
    
    // Set initial state
    if (isExpanded) {
      $metrics.addClass('is-visible');
      $toggle.addClass('is-expanded').attr('aria-expanded', 'true');
      $toggle.find('span:last-child').text(hideText);
    } else {
      $metrics.removeClass('is-visible');
      $toggle.removeClass('is-expanded').attr('aria-expanded', 'false');
      $toggle.find('span:last-child').text(showText);
    }
    
    // Toggle handler
    $toggle.on('click', function() {
      var isCurrentlyExpanded = $metrics.hasClass('is-visible');
      
      if (isCurrentlyExpanded) {
        $metrics.removeClass('is-visible');
        $toggle.removeClass('is-expanded').attr('aria-expanded', 'false');
        $toggle.find('span:last-child').text(showText);
        localStorage.setItem(storageKey, 'false');
      } else {
        $metrics.addClass('is-visible');
        $toggle.addClass('is-expanded').attr('aria-expanded', 'true');
        $toggle.find('span:last-child').text(hideText);
        localStorage.setItem(storageKey, 'true');
      }
    });
  }

  function closeUserCardMenus() {
    $('.yoo-user-card-menu.is-open').removeClass('is-open')
      .find('.yoo-user-card-menu__toggle').attr('aria-expanded', 'false');
    $('.yoo-user-card-menu__dropdown').attr('hidden', 'hidden');
  }

  function initUserCardMenus() {
    $(document).on('click', '.yoo-user-card-menu__toggle', function(e) {
      e.preventDefault();
      e.stopPropagation();

      var $menu = $(this).closest('.yoo-user-card-menu');
      var isOpen = $menu.hasClass('is-open');

      closeUserCardMenus();

      if (!isOpen) {
        $menu.addClass('is-open');
        $(this).attr('aria-expanded', 'true');
        $menu.find('.yoo-user-card-menu__dropdown').removeAttr('hidden');
      }
    });

    $(document).on('click', function(e) {
      if (!$(e.target).closest('.yoo-user-card-menu').length) {
        closeUserCardMenus();
      }
    });

    $(document).on('keydown', function(e) {
      if (e.key === 'Escape') {
        closeUserCardMenus();
      }
    });
  }

  function initUserProfilePageSelects() {
    var profileRoot = document.querySelector('.yooadmin-user-profile');
    if (profileRoot) {
      initUserFormRoleSelect();
      initUserProfileFormSelects();
      initUserProfileLocaleSelect();
      return;
    }

    if (document.querySelector('.yooadmin-user-create, .yooadmin-network-user-create')) {
      initUserFormRoleSelect();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initUserProfilePageSelects);
  } else {
    initUserProfilePageSelects();
  }

  $(function(){
    bindDisplayName();
    initPasswordTools();
    initUserProfilePageSelects();
    initUserFormHelpTooltips();
    initUsersListSelects();
    initUsersSearch();
    initUsersFilters();
    initUsersPagination();
    initUsersSort();
    initUsersMetricsToggle();
    initUserCardMenus();
  });

})(jQuery);
