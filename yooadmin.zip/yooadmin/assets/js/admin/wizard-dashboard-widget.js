/**
 * YOOAdmin - Wizard dashboard widget
 *
 * @package YOOAdmin
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        var config = window.yooadmWizardWidget || {};

        $('.yooadmin-dismiss-wizard-widget').on('click', function(e) {
            e.preventDefault();

            $.post(window.ajaxurl, {
                action: 'yooadmin_wizard_skip',
                nonce: config.nonce
            }, function() {
                $('#yooadmin_setup_wizard_widget').fadeOut(function() {
                    $(this).remove();
                });
            });
        });
    });
})(jQuery);
