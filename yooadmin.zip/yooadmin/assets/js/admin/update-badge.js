/**
 * YOOAdmin - Update badge (live check)
 *
 * @package YOOAdmin
 */
(function($) {
    'use strict';
    
    // Check for updates when page loads
    function checkForUpdates() {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'yooadmin_get_update_count'
            },
            success: function(response) {
                if (response.success && response.data.count !== undefined) {
                    updateBadge(response.data.count);
                }
            }
        });
    }
    
    // Update badge in menu
    function updateBadge(count) {
        const $menuItems = $('#toplevel_page_yooadmin-dashboard');
        
        $menuItems.each(function() {
            const $item = $(this);
            const $existing = $item.find('.update-plugins');
            
            if (count > 0) {
                if ($existing.length) {
                    // Update existing badge
                    $existing.attr('class', 'update-plugins count-' + count);
                    $existing.find('.update-count').text(count);
                } else {
                    // Add new badge
                    const badge = ' <span class="update-plugins count-' + count + '"><span class="update-count">' + count + '</span></span>';
                    
                    if ($item.is('a')) {
                        // Submenu item
                        const text = $item.contents().filter(function() {
                            return this.nodeType === 3;
                        }).text();
                        $item.html(text + badge);
                    } else {
                        // Top menu item
                        $item.find('.wp-menu-name').append(badge);
                    }
                }
            } else {
                // Remove badge if count is 0
                $existing.remove();
            }
        });
    }
    
    // Check on page load
    $(document).ready(function() {
        // Wait a bit to avoid blocking page load
        setTimeout(checkForUpdates, 1000);
    });
    
})(jQuery);
