/**
 * YOOAdmin — global confirm modal API + native confirm bypass helper.
 *
 * @package YOOAdmin
 */

(function ($) {
    'use strict';

    var nativeConfirm = window.confirm;
    var i18n = window.yooadminConfirmI18n || {};

    /**
     * @param {object} options
     * @param {string} [options.title]
     * @param {string} [options.message] HTML allowed for message only when options.messageHtml is true.
     * @param {string} [options.messageHtml]
     * @param {string} [options.confirmText]
     * @param {string} [options.cancelText]
     * @param {string} [options.variant] default|danger
     * @param {boolean} [options.compact] Smaller dialog typography and spacing.
     * @param {boolean} [options.useYooButtons] Use YOOAdmin yp-yoo-btn button classes.
     * @returns {Promise<boolean>}
     */
    function yooadminConfirm(options) {
        options = options || {};

        return new Promise(function (resolve) {
            var title = options.title || i18n.title || 'Are you sure?';
            var confirmText = options.confirmText || options.confirmLabel || i18n.confirm || 'OK';
            var cancelText = options.cancelText || options.cancelLabel || i18n.cancel || 'Cancel';
            var variant = options.variant === 'danger' ? 'danger' : 'default';
            var messageHtml = options.messageHtml || options.message || '';
            var compact = !!options.compact;
            var useYooButtons = !!options.useYooButtons;
            var iconClass =
                variant === 'danger'
                    ? 'yoo-confirm-popup-icon yoo-confirm-popup-icon--danger'
                    : 'yoo-confirm-popup-icon';
            var popupClass = 'yoo-confirm-popup' + (compact ? ' yoo-confirm-popup--compact' : '');
            var cancelBtnClass = useYooButtons
                ? 'button yp-yoo-btn yp-yoo-btn--soft yoo-popup-cancel'
                : 'yoo-popup-btn yoo-popup-cancel';
            var confirmBtnClass = useYooButtons
                ? 'button yp-yoo-btn yp-yoo-btn--primary ' +
                  (variant === 'danger' ? 'yoo-popup-delete' : 'yoo-popup-primary-action')
                : 'yoo-popup-btn ' + (variant === 'danger' ? 'yoo-popup-delete' : 'yoo-popup-primary-action');

            var $popup = $(
                '<div class="yoo-confirm-popup-overlay" role="dialog" aria-modal="true">' +
                    '<div class="' +
                    popupClass +
                    '">' +
                    '<div class="' +
                    iconClass +
                    '">' +
                    '<span class="dashicons dashicons-warning" aria-hidden="true"></span>' +
                    '</div>' +
                    '<h3></h3>' +
                    '<p></p>' +
                    '<div class="yoo-confirm-popup-actions">' +
                    '<button type="button" class="' +
                    cancelBtnClass +
                    '"></button>' +
                    '<button type="button" class="' +
                    confirmBtnClass +
                    '"></button>' +
                    '</div>' +
                    '</div>' +
                    '</div>'
            );

            $popup.find('h3').text(title);
            if (options.messageHtml) {
                $popup.find('p').html(messageHtml);
            } else {
                $popup.find('p').text(messageHtml);
            }
            $popup.find('.yoo-popup-cancel').text(cancelText);
            $popup.find('.' + (variant === 'danger' ? 'yoo-popup-delete' : 'yoo-popup-primary-action')).text(confirmText);

            function close(result) {
                $popup.removeClass('visible');
                setTimeout(function () {
                    $popup.remove();
                    resolve(!!result);
                }, 280);
            }

            $popup.find('.yoo-popup-cancel').on('click', function () {
                close(false);
            });
            $popup.find('.yoo-popup-delete, .yoo-popup-primary-action').on('click', function () {
                close(true);
            });
            $popup.on('click', function (e) {
                if ($(e.target).hasClass('yoo-confirm-popup-overlay')) {
                    close(false);
                }
            });

            $(document).on('keydown.yooadminConfirm', function (e) {
                if (e.key === 'Escape') {
                    $(document).off('keydown.yooadminConfirm');
                    close(false);
                }
            });

            $('body').append($popup);
            setTimeout(function () {
                $popup.addClass('visible');
                $popup.find('.yoo-popup-cancel').trigger('focus');
            }, 10);
        });
    }

    function patchNativeConfirm() {
        window.confirm = function (message) {
            if (window.__yooadminConfirmApproved) {
                window.__yooadminConfirmApproved = false;
                return true;
            }
            if (window.__yooadminConfirmRejected) {
                window.__yooadminConfirmRejected = false;
                return false;
            }
            return nativeConfirm.call(window, String(message || ''));
        };
    }

    /**
     * Run action after modal confirm; re-dispatched clicks use __yooadminConfirmApproved for sync window.confirm.
     *
     * @param {object} options Modal options.
     * @param {function} actionFn Called when user confirms.
     */
    function yooadminConfirmThen(options, actionFn) {
        return yooadminConfirm(options).then(function (ok) {
            if (!ok || typeof actionFn !== 'function') {
                return;
            }
            window.__yooadminConfirmApproved = true;
            actionFn();
        });
    }

    window.yooadminConfirm = yooadminConfirm;
    window.yooadminConfirmThen = yooadminConfirmThen;
    window.yooadminConfirmPatchNative = patchNativeConfirm;
    window.yooadminNativeConfirm = nativeConfirm;
})(jQuery);
