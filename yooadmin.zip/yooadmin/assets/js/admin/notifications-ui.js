/**
 * YOOAdmin Notifications UI - Modern Notifications Interactions
 * This script adjusts WordPress notifications to a cleaner UI.
 * No external data transfer, no tracking, no analytics, no user profiling.
 * All operations are local to wp-admin interface.
 */

(function($) {
    'use strict';
    
    // Local console shim for this file:
    // - Suppresses all debug/info/warn logs in production
    // - Still forwards errors to the real browser console (for real failures)
    // This affects ONLY this file because 'console' here is a local variable.
    var console = {
        log: function() {},
        info: function() {},
        warn: function() {},
        debug: function() {},
        error: (window.console && window.console.error)
            ? window.console.error.bind(window.console)
            : function() {}
    };
    
    function buildRestUrl(endpoint, params) {
        var base = yooadmNotifications.rest_url + endpoint;
        if (!params) return base;
        var pairs = [];
        for (var key in params) {
            if (params.hasOwnProperty(key)) {
                pairs.push(encodeURIComponent(key) + '=' + encodeURIComponent(params[key]));
            }
        }
        if (!pairs.length) return base;
        return base + (base.indexOf('?') !== -1 ? '&' : '?') + pairs.join('&');
    }

    // Global namespace
    window.yooadmNotificationsUi = {
        
        getUiString: function(key, fallback) {
            if (
                typeof yooadmNotifications !== 'undefined'
                && yooadmNotifications.strings
            ) {
                if (yooadmNotifications.strings[key]) {
                    return yooadmNotifications.strings[key];
                }
                if (key === 'viewAction' && yooadmNotifications.strings.view) {
                    return yooadmNotifications.strings.view;
                }
            }
            return fallback;
        },

        getTabLabel: function(filter) {
            var $tabs = $('.yp-filter-tabs');
            var dataKey = 'tab' + filter.charAt(0).toUpperCase() + filter.slice(1);
            if ($tabs.length && $tabs.data(dataKey)) {
                return $tabs.data(dataKey);
            }
            var stringKey = 'tab' + filter.charAt(0).toUpperCase() + filter.slice(1);
            var fallbacks = {
                all: 'ALL',
                plugins: 'Plugins',
                theme: 'Theme',
                extensions: 'Extensions',
                banners: 'Banners',
                license: 'License',
                comments: 'Comments'
            };
            return this.getUiString(stringKey, fallbacks[filter] || filter);
        },

        localizeActionText: function(text) {
            var value = (text === null || text === undefined) ? '' : String(text).trim();
            if (value === '' || value.toLowerCase() === 'view' || value.toLowerCase() === 'open link') {
                return this.getUiString('viewAction', 'View');
            }
            if (value === 'Translate on WordPress.org') {
                return this.getUiString('translateOnWpOrg', 'Translate on WordPress.org');
            }
            return text;
        },

        /**
         * Whether an action label is really a dismiss/close control (so it should not
         * be rendered as an action button — the modal has its own dismiss controls).
         */
        isDismissActionLabel: function(text) {
            var value = (text === null || text === undefined) ? '' : String(text).trim();
            if (value === '' || value.length >= 30) {
                return false;
            }
            return /^(dismiss|dismiss\s+this\s+notice|hide(\s+this)?(\s+notice)?|close|ignore(\s+this)?(\s+notice)?|no\s+thanks|إخفاء|اخفاء|تجاهل|إغلاق|اغلاق|لا\s+شكرا|لا\s+شكراً)\b/i.test(value);
        },

        // Configuration
        config: {
            dropdown: null,
            badge: null,
            list: null,
            searchInput: null,
            filterTabs: null,
            currentFilter: 'all',
            searchTerm: '',
            notifications: [],
            unreadCount: 0,
            isLoading: false,
            autoRefreshInterval: null,
            refreshInterval: 30000, // 30 seconds
            debounceTimer: null,
            initialized: false,
            isInitialLoad: true, // Prevent sound on initial load
            knownUnreadBaseline: null, // Last synced unread count (session)
            pageLoadSoundArmedAt: 0, // When initial load finished (ms)
            soundGraceMs: 3500, // Ignore sounds briefly after page load (banner sync)
            sessionId: 'yp-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9), // Unique session ID for this tab
            lastBroadcastTimestamp: 0, // Throttle broadcasts
            lastNotificationHash: null, // Track notification data changes
            broadcastDebounceTimer: null, // Debounce broadcast-triggered reloads
            maintenanceModeDetected: false, // Track if server is in maintenance mode
            initialLimit: 10,
            loadMoreLimit: 10,
            loadOffset: 0,
            hasMore: true,
            isLoadingMore: false
        },
        
        // Audio state
        audioState: {
            context: null,
            unlocked: false,
            pendingPlay: false
        },
        
        // BroadcastChannel for multi-tab sync
        broadcastChannel: null,
        
        /**
         * Initialize the notification system
         */
        init: function() {
            // Prevent multiple initialization
            if (this.config.initialized) {
                return;
            }
            
            this.cacheElements();
            this.bindEvents();
            this.bindLoadMoreScroll();
            this.config.knownUnreadBaseline = this.getInitialUnreadBaseline();
            
            this.loadNotifications();
            this.startAutoRefresh();
            this.startTimeUpdater();
            this.setupKeyboardShortcuts();
            this.setupAudioUnlock();
            this.setupBroadcastChannel();
            this.ensureNotificationModalPortaled();
            this.syncModalSnoozeButton();

            this.config.initialized = true;
        },

        /**
         * Baseline unread count from session or server-rendered badge (avoid sound on every page load).
         */
        getInitialUnreadBaseline: function() {
            try {
                var stored = sessionStorage.getItem('yooadmin_notif_unread_baseline');
                if (stored !== null && stored !== '') {
                    return parseInt(stored, 10) || 0;
                }
            } catch (e) {}
            return parseInt($('.yp-notification-count, .notification-count').attr('data-count') || '0', 10) || 0;
        },

        setUnreadBaseline: function(count) {
            var n = parseInt(count, 10) || 0;
            this.config.knownUnreadBaseline = n;
            try {
                sessionStorage.setItem('yooadmin_notif_unread_baseline', String(n));
            } catch (e) {}
        },

        isSoundGraceActive: function() {
            if (this.config.isInitialLoad) {
                return true;
            }
            var armed = this.config.pageLoadSoundArmedAt || 0;
            return armed > 0 && (Date.now() - armed) < (this.config.soundGraceMs || 3500);
        },

        shouldPlayNotificationSound: function(currentCount, previousCount) {
            if (typeof yooadmNotifications !== 'undefined' && yooadmNotifications.notification_sound_enabled === false) {
                return false;
            }
            if (this.isSoundGraceActive()) {
                return false;
            }
            currentCount = parseInt(currentCount, 10) || 0;
            previousCount = parseInt(previousCount, 10) || 0;
            var baseline = this.config.knownUnreadBaseline;
            if (baseline !== null && baseline !== undefined && currentCount <= baseline) {
                return false;
            }
            return currentCount > previousCount && previousCount >= 0;
        },

        markInitialLoadComplete: function() {
            if (!this.config.isInitialLoad) {
                return;
            }
            this.config.isInitialLoad = false;
            this.config.pageLoadSoundArmedAt = Date.now();
            this.setUnreadBaseline(this.config.unreadCount);
        },

        /**
         * Scroll the horizontal filter strip so the clicked tab is fully visible.
         * Scrollbar is hidden in CSS; movement is smooth via scroll-behavior + scrollBy.
         */
        scrollFilterTabIntoView: function($tab) {
            var tab = $tab && $tab[0];
            if (!tab || typeof tab.getBoundingClientRect !== 'function') {
                return;
            }
            var strip = tab.closest('.yp-filter-tabs');
            if (!strip || strip.scrollWidth <= strip.clientWidth + 1) {
                return;
            }
            var pad = 12;
            var sRect = strip.getBoundingClientRect();
            var tRect = tab.getBoundingClientRect();
            if (tRect.left >= sRect.left + pad && tRect.right <= sRect.right - pad) {
                return;
            }
            var delta = 0;
            if (tRect.left < sRect.left + pad) {
                delta = tRect.left - sRect.left - pad;
            } else if (tRect.right > sRect.right - pad) {
                delta = tRect.right - sRect.right + pad;
            }
            if (delta !== 0) {
                if (typeof strip.scrollBy === 'function') {
                    try {
                        strip.scrollBy({ left: delta, behavior: 'smooth' });
                    } catch (err) {
                        strip.scrollLeft += delta;
                    }
                } else {
                    strip.scrollLeft += delta;
                }
            }
        },
        
        /**
         * Ensure notifications is always an array
         */
        ensureNotificationsArray: function() {
            if (!Array.isArray(this.config.notifications)) {
                this.config.notifications = [];
            }
            return this.config.notifications;
        },
        
        /**
         * Cache DOM elements
         */
        cacheElements: function() {
            this.config.dropdown = $('.yp-notifications-dropdown');
            this.config.badge = $('.yp-notifications');
            this.config.list = $('.yp-notifications-list');
            this.config.searchInput = $('.yp-search-input');
            this.config.filterTabs = $('.yp-filter-tab');
            
            // Check if elements exist
            if (this.config.dropdown.length === 0) {
                // Dropdown element not found
            }
            if (this.config.badge.length === 0) {
                // Badge element not found
            }
            if (this.config.list.length === 0) {
                // List element not found
            }
        },
        
        /**
         * Bind scroll-to-load-more on the list (must re-run after cacheElements).
         */
        bindLoadMoreScroll: function() {
            var self = this;
            if (!this.config.list || !this.config.list.length) {
                return;
            }
            this.config.list.off('scroll.ypLoadMore').on('scroll.ypLoadMore', function() {
                var el = this;
                if (!self.config.hasMore || self.config.isLoadingMore) {
                    return;
                }
                if (el.scrollHeight - el.scrollTop - el.clientHeight < 80) {
                    self.loadMoreNotifications();
                }
            });
        },

        maybeAutoLoadMore: function() {
            if (!this.config.hasMore || this.config.isLoadingMore || !this.config.list || !this.config.list.length) {
                return;
            }
            var el = this.config.list[0];
            if (el.scrollHeight <= el.clientHeight + 4) {
                this.loadMoreNotifications();
            }
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            var self = this;
            
            // Remove all existing handlers first to prevent duplicates
            $('.yp-notifications').off('click.yp-notifications click.yp-notifications-delayed');
            $(document).off('click.yp-notifications-delegated', '.yp-notifications');
            
            // Use delegation as primary handler (works even if element is added later)
            $(document).on('click.yp-notifications-delegated', '.yp-notifications', function(e) {
                // Don't toggle when clicking inside dropdown (e.g. links, buttons) - let them work
                if ($(e.target).closest('.yp-notifications-dropdown').length) {
                    return;
                }
                e.stopPropagation();
                if (typeof e.stopImmediatePropagation === 'function') {
                    e.stopImmediatePropagation();
                }
                self.toggleDropdown();
                return false;
            });
            
            // Close dropdown when clicking outside
            // But ignore clicks on popup and sidebar elements to avoid conflicts
            $(document).on('click', function(e) {
                // Only handle if dropdown is open
                if (!self.config.dropdown || !self.config.dropdown.hasClass('active')) {
                    return;
                }
                
                var target = $(e.target);
                var closestPopup = target.closest('#yp-popup, .yp-popup');
                var closestSidebar = target.closest('#yps-sidebar, .yps-sidebar, .yps-link, .yps-item, .yps-expander, .yps-sub, .yps-sub-link');
                var closestAdminMenu = target.closest('#adminmenu, #adminmenuback, #adminmenuwrap');
                var closestNotifications = target.closest('.yp-notifications, .yp-notifications-dropdown');
                
                // Don't close if clicking on popup elements
                if (closestPopup.length) {
                    return;
                }
                
                // Don't close if clicking on sidebar menu elements (IMPORTANT: Allow clicks to work normally)
                // Just return without preventing default - let sidebar handle the click naturally
                if (closestSidebar.length) {
                    return;
                }
                
                // Don't close if clicking on WordPress admin menu
                if (closestAdminMenu.length) {
                    return;
                }
                
                // Don't close if clicking on notifications dropdown itself
                if (closestNotifications.length) {
                    return;
                }
                
                // Close dropdown for all other clicks
                self.closeDropdown();
            });
            
            // Mark all as read
            $(document).on('click', '.yp-notifications-mark-read', function(e) {
                e.preventDefault();
                self.markAllAsRead();
            });
            
            // Open modal when clicking on notification (like old system)
            $(document).on('click', '.yp-notification-item', function(e) {
                // Don't trigger if clicking on expand arrow (it's handled separately)
                if ($(e.target).hasClass('dashicons-arrow-right-alt2') || $(e.target).closest('.yp-notification-expand').length) {
                    return;
                }
                // Don't trigger if clicking on action buttons (archive, snooze, dismiss)
                if ($(e.target).closest('.yp-action-btn, .yp-notification-actions').length) {
                    return;
                }
                
                var $item = $(this);
                
                // Check if expandable (like old system)
                if ($item.hasClass('yp-notification-expandable')) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Get data from data attributes (like old system)
                    var feedId = $item.data('feed-id') || $item.data('id') || '';
                    var notifType = $item.data('notif-type') || '';
                    var fullTitle = $item.data('full-title') || '';
                    var itemName = $item.data('item-name') || '';
                    var summaryText = $item.data('summary') || '';
                    var description = $item.data('description') || '';
                    var versionText = $item.data('version-text') || '';
                    var currentVersion = $item.data('current-version') || '';
                    var newVersion = $item.data('new-version') || '';
                    var linkUrl = $item.data('link-url') || '';
                    var linkText = self.localizeActionText($item.data('link-text') || '');
                    var source = $item.data('source-original') || ''; // Get original source (YOOAdmin, WordPress, etc.)
                    
                    // Get icon
                    var dashiconEl = $item.find('.dashicons').first();
                    var iconClass = dashiconEl.length ? dashiconEl.attr('class').replace('dashicons ', '').trim() : 'dashicons-info';
                    
                    // Build notification type label (like old system)
                    var notifTypeLabel = '';
                    if (notifType === 'wp-plugin-updates') {
                        notifTypeLabel = 'Plugin update';
                    } else if (notifType === 'wp-theme-updates') {
                        notifTypeLabel = 'Theme update';
                    } else if (notifType === 'wp-core-update') {
                        notifTypeLabel = 'WordPress update';
                    } else if (notifType === 'yooadmin-extensions-update') {
                        notifTypeLabel = 'Extension update';
                    } else {
                        // Extract from full title
                        var colonIndex = fullTitle.indexOf(':');
                        notifTypeLabel = colonIndex > 0 ? fullTitle.substring(0, colonIndex) : fullTitle;
                    }
                    
                    // Build version info
                    var versionInfo = '';
                    if (currentVersion && newVersion) {
                        versionInfo = currentVersion + ' → ' + newVersion;
                    } else if (versionText) {
                        versionInfo = versionText.replace(/^version\s*/i, '').trim();
                    }
                    
                    // FIXED: Extract URLs from notification meta (for banners)
                    var dbIdFromItem = $item.data('db-id') || $item.attr('data-db-id') || '';
                    var notificationData = self.findNotificationInConfig(feedId, dbIdFromItem);
                    var fullMessage = self.resolveNotificationItemMessage($item, notificationData);
                    
                    // Get source for sender display (from item or notification)
                    var source = $item.data('source-original') || '';
                    if (!source && notificationData && notificationData.source) {
                        source = notificationData.source;
                    }
                    
                    // Get source_type for license detection (from data attribute or notificationData)
                    var sourceType = $item.data('source-type') || '';
                    if (!sourceType && notificationData && notificationData.source_type) {
                        sourceType = notificationData.source_type;
                    }
                    
                    // Build modal data (like old system) - use title, not notifTypeLabel
                    var modalData = {
                        icon: iconClass,
                        title: fullTitle, // Use full title (not notifTypeLabel)
                        notifTypeLabel: notifTypeLabel,
                        itemName: itemName,
                        source: source, // Pass source for sender display
                        source_type: sourceType, // Pass source_type for license detection
                        text: fullMessage,
                        summaryText: summaryText,
                        description: fullMessage,
                        versionText: versionText,
                        currentVersion: currentVersion,
                        newVersion: newVersion,
                        versionInfo: versionInfo,
                        linkUrl: linkUrl,
                        linkText: linkText,
                        type: notifType,
                        feedId: feedId
                    };
                    
                    // Get meta data (including actions) from item
                    var itemMeta = {};
                    try {
                        var itemMetaJson = $item.data('meta');
                        if (itemMetaJson) {
                            if (typeof itemMetaJson === 'string') {
                                itemMeta = JSON.parse(itemMetaJson);
                            } else {
                                itemMeta = itemMetaJson;
                            }
                        }
                    } catch(e) {
                        itemMeta = {};
                    }
                    
                    // Priority 1: Check for actions in meta (for license notifications)
                    var urls = [];
                    if (itemMeta.actions && Array.isArray(itemMeta.actions) && itemMeta.actions.length > 0) {
                        itemMeta.actions.forEach(function(action) {
                            var actionUrl = action.url || linkUrl;
                            if (actionUrl && actionUrl !== '#') {
                                urls.push({
                                    url: actionUrl,
                                    text: action.text || self.getUiString('viewAction', 'View'),
                                    target: action.target || (actionUrl.indexOf('http') === 0 && actionUrl.indexOf(window.location.origin) === -1 ? '_blank' : '_self')
                                });
                            }
                        });
                    }
                    
                    // Priority 2: Check for urls in notificationData.meta (for banner notifications)
                    if (notificationData && notificationData.meta) {
                        var nMeta = notificationData.meta;
                        if (typeof nMeta === 'string') {
                            try {
                                nMeta = JSON.parse(nMeta);
                            } catch(e) {
                                nMeta = {};
                            }
                        }
                        if (nMeta.urls && Array.isArray(nMeta.urls) && nMeta.urls.length > 0) {
                            nMeta.urls.forEach(function(link) {
                                var linkUrlFromMeta = link.url || '';
                                // Check if already added from actions
                                var alreadyAdded = urls.some(function(u) {
                                    return u.url === linkUrlFromMeta;
                                });
                                if (!alreadyAdded && linkUrlFromMeta && linkUrlFromMeta !== '#') {
                                    var isExternal = linkUrlFromMeta.indexOf('http') === 0 && 
                                                    linkUrlFromMeta.indexOf(window.location.origin) === -1;
                                    urls.push({
                                        url: linkUrlFromMeta,
                                        text: link.text || self.getUiString('viewAction', 'View'),
                                        target: link.target || (isExternal ? '_blank' : '_self')
                                    });
                                }
                            });
                        }
                    }
                    
                    // Priority 3: Use single linkUrl as fallback ONLY if not already in urls
                    if (linkUrl && linkUrl !== '#') {
                        var linkUrlInUrls = urls.some(function(link) {
                            return (link.url || '') === linkUrl;
                        });
                        if (!linkUrlInUrls) {
                            var isExternal = linkUrl.indexOf('http') === 0 && 
                                            linkUrl.indexOf(window.location.origin) === -1;
                            urls.push({
                                url: linkUrl,
                                text: linkText || self.getUiString('viewAction', 'View'),
                                target: isExternal ? '_blank' : '_self'
                            });
                        }
                    }
                    
                    // Add URLs and meta to modalData
                    modalData.urls = urls;
                    modalData.meta = itemMeta; // Pass meta so actions can be used in openNotificationModalFromData
                    
                    // Mark as read - ALWAYS use database ID (db-id) for marking as read
                    var dbId = $item.data('db-id');
                    var customId = $item.data('id') || $item.data('feed-id');
                    
                    // Validate dbId - must be a number (database ID), not a string (custom ID)
                    var dbIdIsValid = dbId && !isNaN(parseInt(dbId, 10)) && isFinite(dbId);
                    
                    // Find notification to get database ID if not in HTML or if dbId is a string (custom ID)
                    if ((!dbIdIsValid || !dbId) && customId) {
                        self.ensureNotificationsArray();
                        
                        // Search in all notifications (including expanded groups)
                        var allNotifications = [];
                        self.config.notifications.forEach(function(n) {
                            if (n.type === 'group' && n.items && n.items.length > 0) {
                                n.items.forEach(function(item) {
                                    allNotifications.push(item);
                                });
                            } else {
                                allNotifications.push(n);
                            }
                        });
                        
                        var foundNotif = allNotifications.find(function(n) {
                            // Get custom ID from meta
                            var metaId = null;
                            var metaObj = null;
                            
                            // Parse meta if it's a string
                            if (n.meta) {
                                if (typeof n.meta === 'string') {
                                    try {
                                        metaObj = JSON.parse(n.meta);
                                        metaId = metaObj.id || null;
                                    } catch(e) {
                                        // Not JSON, ignore
                                    }
                                } else if (typeof n.meta === 'object') {
                                    metaObj = n.meta;
                                    metaId = metaObj.id || null;
                                }
                            }
                            
                            // Match by custom ID (meta.id) - exact match
                            var customIdMatch = (metaId && String(metaId) === String(customId));
                            
                            // Match by database ID if customId is numeric
                            var dbIdMatch = false;
                            if (n.id) {
                                var nIdStr = String(n.id);
                                var customIdStr = String(customId);
                                dbIdMatch = (nIdStr === customIdStr);
                            }
                            
                            // Also check if customId matches the notification's custom ID in meta
                            // This handles cases where customId is like "wp-plugin-akismet_5-6"
                            var metaIdMatch = false;
                            if (metaId) {
                                metaIdMatch = (String(metaId) === String(customId));
                            }
                            
                            return customIdMatch || dbIdMatch || metaIdMatch;
                        });
                        
                        if (foundNotif) {
                            // Ensure we have a valid database ID
                            if (foundNotif.id && !isNaN(parseInt(foundNotif.id, 10))) {
                                dbId = parseInt(foundNotif.id, 10);
                            }
                        }
                    }
                    
                    // Validate dbId again after search
                    dbIdIsValid = dbId && !isNaN(parseInt(dbId, 10)) && isFinite(dbId);
                    
                    // CRITICAL: Add dbId to modalData so it's available in openNotificationModalFromData
                    if (dbIdIsValid) {
                        dbId = parseInt(dbId, 10); // Ensure it's a number
                        modalData.dbId = dbId;
                        modalData.id = dbId; // Also set id for compatibility
                        // Mark as read using database ID
                        self.markAsRead(dbId);
                        // Update local status immediately for visual feedback
                        $item.removeClass('yp-notification-unread').addClass('yp-notification-read');
                    } else {
                        console.error('[yooadm Notifications] Cannot mark as read - no valid database ID found! dbId:', dbId, 'customId:', customId);
                        // Try AJAX fallback with custom ID as last resort
                        if (customId) {
                            self.markAsReadAjax(customId);
                        }
                    }
                    
                    // Open modal using old system's openModal function if available
                    if (typeof window.ypShowNotificationModal === 'function') {
                        window.ypShowNotificationModal(modalData);
                    } else {
                        // Fallback: use our modal
                        self.openNotificationModalFromData(modalData);
                    }
                    
                    return false;
                }
                
                // For non-expandable items, just navigate
                // (old system behavior - no modal for non-expandable)
                
                var notificationId = $item.data('id') || $item.data('notification-id') || $item.closest('[data-id]').data('id') || $item.closest('[data-notification-id]').data('notification-id');
                
                if (notificationId) {
                    // Find the notification data
                    self.ensureNotificationsArray();
                    
                    // Convert notificationId to number for comparison
                    var notificationIdNum = parseInt(notificationId, 10);
                    var notificationIdStr = String(notificationId);
                    var isCustomId = typeof notificationId === 'string' && 
                                     (notificationId.indexOf('wp-plugin-') === 0 || 
                                      notificationId.indexOf('wp-theme-') === 0 ||
                                      notificationId.indexOf('wp-core-') === 0);
                    
                    // Search in all notifications (including expanded groups)
                    var allNotifications = [];
                    self.config.notifications.forEach(function(n) {
                        if (n.type === 'group' && n.items && n.items.length > 0) {
                            // Expand group items
                            n.items.forEach(function(item) {
                                allNotifications.push(item);
                            });
                        } else {
                            allNotifications.push(n);
                        }
                    });
                    
                    var notification = allNotifications.find(function(n) {
                        // Get custom ID from meta (handle both string and object)
                        var customId = null;
                        if (n.meta) {
                            if (typeof n.meta === 'string') {
                                try {
                                    var parsed = JSON.parse(n.meta);
                                    customId = parsed.id || null;
                                } catch(e) {
                                    // Not JSON, ignore
                                }
                            } else if (typeof n.meta === 'object') {
                                customId = n.meta.id || null;
                            }
                        }
                        
                        var dbId = n.id;
                        
                        // Search by database ID first (most reliable)
                        if (dbId == notificationIdNum || dbId == notificationId || 
                            String(dbId) == notificationIdStr || String(dbId) == String(notificationIdNum)) {
                            return true;
                        }
                        
                        // If notificationId is a custom ID format, search by custom ID
                        if (isCustomId) {
                            if (customId && customId === notificationId) {
                                return true;
                            }
                            // Also check if customId matches (case-insensitive)
                            if (customId && customId.toLowerCase() === notificationId.toLowerCase()) {
                                return true;
                            }
                        }
                        
                        // Search by custom ID (exact match)
                        if (customId && (customId == notificationId || customId === notificationIdStr)) {
                            return true;
                        }
                        
                        return false;
                    });
                    
                    if (notification) {
                        // Mark as read when opening modal (like old system)
                        if (notification.status === 'new') {
                            // Use database ID for mark as read (ALWAYS use database ID)
                            var dbId = notification.id;
                            if (dbId) {
                                // Mark as read in database
                                self.markAsRead(dbId);
                                // Update local status immediately for visual feedback
                                notification.status = 'read';
                                $item.removeClass('yp-notification-unread').addClass('yp-notification-read');
                                // Re-render to update UI
                                self.renderNotifications();
                            }
                        }
                        
                        // Open modal with full details
                        self.openNotificationModal(notification);
                    }
                }
            });
            
            // Snooze notification
            $(document).on('click', '.yp-snooze-btn', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var notificationId = $(this).data('db-id') || $(this).data('id') || $(this).closest('[data-id]').data('db-id') || $(this).closest('[data-id]').data('id');
                if (notificationId) {
                    self.showSnoozeOptions(notificationId, $(this));
                }
            });
            
            // Archive notification
            $(document).on('click', '.yp-archive-btn', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var notificationId = $(this).data('db-id') || $(this).data('id') || $(this).closest('[data-id]').data('db-id') || $(this).closest('[data-id]').data('id');
                if (notificationId) {
                    self.archiveNotification(notificationId);
                }
            });
            
            // Dismiss notification
            $(document).on('click', '.yp-notification-dismiss, .yp-dismiss-btn', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var notificationId = $(this).data('db-id') || $(this).data('id') || $(this).closest('[data-id]').data('db-id') || $(this).closest('[data-id]').data('id');
                if (notificationId) {
                    self.dismissNotification(notificationId);
                }
            });
            
            // Expand/Collapse group notifications
            $(document).on('click', '.yp-group-expand', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var $button = $(this);
                var $groupItem = $button.closest('.yp-notification-item');
                var $groupItems = $groupItem.find('.yp-group-items');
                var $icon = $button.find('.dashicons');
                
                if ($groupItems.length) {
                    var isExpanded = $groupItems.is(':visible');
                    
                    if (isExpanded) {
                        // Collapse
                        $groupItems.slideUp(200);
                        $icon.removeClass('dashicons-arrow-up').addClass('dashicons-arrow-down');
                        $groupItem.removeClass('yp-group-expanded');
                    } else {
                        // Expand
                        $groupItems.slideDown(200);
                        $icon.removeClass('dashicons-arrow-down').addClass('dashicons-arrow-up');
                        $groupItem.addClass('yp-group-expanded');
                    }
                }
            });
            
            // Dismiss all items in a group
            $(document).on('click', '.yp-group-dismiss', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var $button = $(this);
                var $groupItem = $button.closest('.yp-notification-item');
                var groupId = $groupItem.data('group-id') || $groupItem.data('id');
                
                if (groupId) {
                    self.dismissGroup(groupId);
                }
            });
            
            // Close modal on overlay click
            $(document).on('click', '.yp-modal-overlay', function(e) {
                if (e.target === this) {
                    self.closeNotificationModal();
                }
            });
            
            // Close modal on close button
            $(document).on('click', '.yp-modal-close', function(e) {
                e.preventDefault();
                self.closeNotificationModal();
            });
            
            // Close modal on Escape key
            $(document).on('keydown', function(e) {
                if (e.key === 'Escape' && $('#yp-notification-modal').is(':visible')) {
                    self.closeNotificationModal();
                }
            });
            
            // Search functionality
            $(document).on('input', '.yp-search-input', function(e) {
                var searchTerm = $(this).val().toLowerCase();
                self.filterNotifications(searchTerm);
            });
            
            // Filter tabs
            $(document).on('click', '.yp-filter-tab', function(e) {
                e.preventDefault();
                e.stopPropagation(); // Prevent closing dropdown
                var $t = $(this);
                self.scrollFilterTabIntoView($t);
                self.setFilter($t.data('filter'));
            });
            
            // Handle "more" button for tabs
            $(document).on('click', '.yp-filter-tabs-more', function(e) {
                e.preventDefault();
                e.stopPropagation(); // Prevent closing dropdown
                self.toggleHiddenTabs();
            });
            
            // Keyboard shortcuts
            $(document).on('keydown', function(e) {
                self.handleKeyboardShortcuts(e);
            });
        },
        
        /**
         * Toggle dropdown
         */
        toggleDropdown: function() {
            if (this.config.dropdown.length === 0) {
                console.error('[yooadm Notifications UI] Dropdown element not found, cannot toggle');
                return;
            }
            
            if (this.config.dropdown.hasClass('show')) {
                this.closeDropdown();
            } else {
                this.openDropdown();
            }
        },
        
        /**
         * Open dropdown
         */
        openDropdown: function() {
            var self = this;
            
            if (this.config.dropdown.length === 0) {
                console.error('[yooadm Notifications UI] Cannot open dropdown - element not found');
                // Try to re-cache elements
                this.cacheElements();
                if (this.config.dropdown.length === 0) {
                    console.error('[yooadm Notifications UI] Dropdown still not found after re-caching');
                    return;
                }
            }
            
            // Close any other dropdowns first
            $('.yp-notifications-dropdown').removeClass('show');
            
            // Open this dropdown
            this.config.dropdown.addClass('show');
            this.bindLoadMoreScroll();
            
            // Show loading first to prevent empty state flash
            this.showLoading();
            
            // Load notifications if not loaded or if stale
            this.ensureNotificationsArray();
            if (this.config.notifications.length === 0) {
                this.loadNotifications();
            } else {
                // Even if we have notifications, render them immediately
                this.renderNotifications();
                this.updateCounts();
                // Then refresh in background
                this.loadNotifications();
            }
            
            // Close on escape key
            $(document).on('keydown.yp-notifications', function(e) {
                if (e.keyCode === 27) { // Escape key
                    self.closeDropdown();
                }
            });
        },
        
        /**
         * Close dropdown
         */
        closeDropdown: function() {
            this.config.dropdown.removeClass('show');
            
            // Remove escape key listener
            $(document).off('keydown.yp-notifications');
        },
        
        /**
         * Load notifications from API
         */
        loadNotifications: function(fromBroadcast, loadOpts) {
            var self = this;
            loadOpts = loadOpts || {};
            var silent = !!loadOpts.silent;
            
            // Skip if maintenance mode was recently detected (avoid spam)
            if (this.config.maintenanceModeDetected && !fromBroadcast) {
                return;
            }

            // Do not wipe the list / show full-page spinner while user is loading more via scroll.
            if (this.config.isLoadingMore && !fromBroadcast) {
                return;
            }
            
            // Prevent multiple simultaneous requests
            if (this.config.isLoading) {
                return;
            }
            
            // If this is from broadcast, check if data actually changed
            if (fromBroadcast) {
                // Calculate hash of current notifications to compare
                var currentHash = this.calculateNotificationsHash();
                if (currentHash === this.config.lastNotificationHash) {
                    return;
                }
            }
            
            this.config.isLoading = true;
            if (!silent) {
                this.showLoading();
            }
            
            if (typeof yooadmNotifications === 'undefined' || !yooadmNotifications.rest_url || !yooadmNotifications.ajax_url) {
                this.config.isLoading = false;
                return;
            }
            if (!yooadmNotifications.ajax_nonce) {
                yooadmNotifications.ajax_nonce = yooadmNotifications.nonce || '';
            }

            var pageLimit = this.config.initialLimit;
            var fetchLimit = pageLimit + 1;
            var restUrl = buildRestUrl('notifications', {limit: fetchLimit, offset: 0});
            
            // Try REST API first (paginated — never load full inbox in the header)
            $.ajax({
                url: restUrl,
                method: 'GET',
                xhrFields: {
                    withCredentials: true  // Send cookies with request
                },
                headers: {
                    'X-WP-Nonce': yooadmNotifications.nonce
                },
                success: function(response) {
                    // Handle both direct array and wrapped response formats
                    var notifications = [];
                    if (response && typeof response === 'object') {
                        if (response.data && Array.isArray(response.data)) {
                            notifications = response.data;
                        } else if (Array.isArray(response)) {
                            notifications = response;
                        } else {
                            notifications = [];
                        }
                    } else {
                        notifications = [];
                    }
                    
                    if (!Array.isArray(notifications)) {
                        notifications = [];
                    }
                    
                    notifications.forEach(function(n) {
                        if (n.meta && typeof n.meta === 'string') {
                            try {
                                n.meta = JSON.parse(n.meta);
                            } catch(e) {
                                n.meta = {};
                            }
                        }
                        if (!n.meta || typeof n.meta !== 'object') {
                            n.meta = {};
                        }
                    });
                    
                    if (response && response.has_more !== undefined) {
                        self.config.hasMore = !!response.has_more;
                    } else {
                        self.config.hasMore = notifications.length >= fetchLimit;
                    }

                    var toUse = notifications.length >= fetchLimit
                        ? notifications.slice(0, pageLimit)
                        : notifications;
                    if (response && response.offset !== undefined) {
                        self.config.loadOffset = parseInt(response.offset, 10) || toUse.length;
                    } else {
                        self.config.loadOffset = toUse.length;
                    }
                    self.config.notifications = toUse;
                    
                    // Store previous count before applying server unread count.
                    var previousCount = self.config.unreadCount;
                    
                    // Update unread count from response if available
                    if (response && response.unread_count !== undefined) {
                        self.config.unreadCount = parseInt(response.unread_count) || 0;
                    } else if (response && response.data && response.data.unread_count !== undefined) {
                        self.config.unreadCount = parseInt(response.data.unread_count) || 0;
                    }
                    
                    // Calculate hash of new data
                    var newHash = self.calculateNotificationsHash(self.config.notifications, self.config.unreadCount);
                    
                    // Use previous count from broadcast if available (for cross-tab sound)
                    var countForSoundCheck = previousCount;
                    if (fromBroadcast && self.config.previousCountForBroadcast !== undefined) {
                        countForSoundCheck = self.config.previousCountForBroadcast;
                        self.config.previousCountForBroadcast = undefined; // Clear after use
                    }
                    
                    // Only update and broadcast if data actually changed
                    if (newHash !== self.config.lastNotificationHash) {
                        self.config.lastNotificationHash = newHash;
                        
                    self.renderNotifications();
                    self.updateCounts();
                        self.updateBadgeCount(countForSoundCheck); // Update badge immediately (pass previous count for sound check)
                        
                        // Broadcast update to other tabs (only if not from broadcast to prevent loops)
                        if (!fromBroadcast) {
                            // Throttle broadcasts: only send if enough time has passed since last broadcast
                            var now = Date.now();
                            if (now - self.config.lastBroadcastTimestamp > 1000) { // 1 second throttle
                                self.config.lastBroadcastTimestamp = now;
                                self.broadcastMessage('NOTIFICATION_UPDATE', {
                                    unreadCount: self.config.unreadCount,
                                    count: self.config.notifications.length,
                                    sessionId: self.config.sessionId
                                });
                                
                                // Also broadcast badge update separately for immediate UI update
                                self.broadcastMessage('BADGE_UPDATE', {
                                    unreadCount: self.config.unreadCount,
                                    sessionId: self.config.sessionId
                                });
                            }
                        }
                    } else {
                        // Even if data unchanged, still render to ensure UI is updated (especially after loading state)
                        // This fixes the issue where "Loading notifications..." stays visible after refresh
                        if (self.config.isLoading) {
                            self.renderNotifications();
                            self.updateCounts();
                        }
                    }
                    
                    self.config.isLoading = false;
                    
                    // Mark initial load as complete after first successful load
                    self.markInitialLoadComplete();
                },
                error: function(xhr, status, error) {
                    console.error('[yooadm Notifications] REST API Error:', error);
                    console.error('[yooadm Notifications] Status:', status);
                    console.error('[yooadm Notifications] XHR status:', xhr.status);
                    
                    // Check if response is HTML (maintenance mode or server error)
                    var responseText = xhr.responseText || '';
                    var trimmedText = responseText.trim();
                    var isHtmlResponse = trimmedText.startsWith('<!DOCTYPE') || 
                                        trimmedText.startsWith('<!doctype') ||
                                        trimmedText.startsWith('<html') ||
                                        trimmedText.startsWith('<HTML') ||
                                        (trimmedText.toLowerCase().includes('maintenance') && xhr.status === 503) ||
                                        (xhr.status === 503 && trimmedText.length > 100); // 503 with content likely means maintenance
                    
                    // Don't log full HTML response in console (too verbose)
                    if (isHtmlResponse) {
                        console.error('[yooadm Notifications] Server returned HTML instead of JSON (likely maintenance mode or server error)');
                    } else {
                        console.error('[yooadm Notifications] Response text:', responseText);
                    }
                    
                    // If server is in maintenance mode (503) or returning HTML, don't try AJAX fallback
                    if (xhr.status === 503 || isHtmlResponse) {
                        self.config.isLoading = false;
                        // Show error state but don't spam retries
                        if (!self.config.maintenanceModeDetected) {
                            self.config.maintenanceModeDetected = true;
                            self.showError(true); // Pass true to indicate maintenance mode
                            // Clear maintenance flag after 30 seconds to allow retry
                            setTimeout(function() {
                                self.config.maintenanceModeDetected = false;
                            }, 30000);
                        }
                        return;
                    }
                    
                    // Fallback to AJAX if REST fails (only for non-maintenance errors)
                    self.loadNotificationsAjax(fromBroadcast);
                }
            });
        },
        
        /**
         * Load more notifications on scroll
         */
        loadMoreNotifications: function() {
            var self = this;
            if (!this.config.hasMore || this.config.isLoadingMore || this.config.isLoading) return;
            
            this.config.isLoadingMore = true;
            var offset = this.config.loadOffset || 0;
            var limit = this.config.loadMoreLimit + 1;

            if (this.config.list && this.config.list.length && !this.config.list.find('.yp-notifications-loading-more').length) {
                this.config.list.append(
                    '<div class="yp-notifications-loading-more" role="status" aria-live="polite">' +
                    '<div class="yp-spinner-circle"></div></div>'
                );
            }
            
            $.ajax({
                url: buildRestUrl('notifications', {limit: limit, offset: offset}),
                method: 'GET',
                xhrFields: { withCredentials: true },
                headers: { 'X-WP-Nonce': yooadmNotifications.nonce },
                success: function(response) {
                    var notifications = [];
                    if (response && response.data && Array.isArray(response.data)) {
                        notifications = response.data;
                    } else if (response && Array.isArray(response)) {
                        notifications = response;
                    }
                    
                    notifications.forEach(function(n) {
                        if (n.meta && typeof n.meta === 'string') {
                            try { n.meta = JSON.parse(n.meta); } catch(e) { n.meta = {}; }
                        }
                        if (!n.meta || typeof n.meta !== 'object') n.meta = {};
                    });
                    
                    var useLimit = self.config.loadMoreLimit;
                    if (response && response.has_more !== undefined) {
                        self.config.hasMore = !!response.has_more;
                    } else {
                        self.config.hasMore = notifications.length >= limit;
                    }
                    var toAppend = notifications.length >= limit ? notifications.slice(0, useLimit) : notifications;
                    if (response && response.offset !== undefined) {
                        self.config.loadOffset = parseInt(response.offset, 10) || (offset + toAppend.length);
                    } else {
                        self.config.loadOffset = offset + toAppend.length;
                    }
                    self.config.notifications = (self.config.notifications || []).concat(toAppend);
                    
                    // Append rows only — full renderNotifications() replaces the list (looks like a reload).
                    if (self.config.currentFilter !== 'all' || self.config.searchTerm) {
                        self.renderNotifications();
                    } else {
                        self.appendNotificationItems(toAppend);
                    }
                    self.updateCounts();
                },
                error: function() {
                    self.config.hasMore = false;
                },
                complete: function() {
                    self.config.isLoadingMore = false;
                    self.config.list.find('.yp-notifications-loading-more').remove();
                    self.maybeAutoLoadMore();
                }
            });
        },

        /**
         * Append notification rows for infinite scroll (no full list replace).
         */
        appendNotificationItems: function(notifications) {
            var self = this;

            if (!notifications || !notifications.length || !this.config.list || !this.config.list.length) {
                return;
            }

            var html = '';
            notifications.forEach(function(notification) {
                html += self.renderNotificationItem(notification);
            });

            if (!html) {
                return;
            }

            this.config.list.find('.yp-notifications-loading-more').remove();
            this.config.list.append(html);
            this.updateTimeDisplays();
        },
        
        /**
         * Load notifications via AJAX fallback
         */
        loadNotificationsAjax: function(fromBroadcast) {
            var self = this;
            
            // Skip if maintenance mode was detected (unless from broadcast)
            if (this.config.maintenanceModeDetected && !fromBroadcast) {
                return;
            }
            
            // Prevent multiple simultaneous requests
            if (this.config.isLoading) {
                return;
            }
            
            // If this is from broadcast, check if data actually changed
            if (fromBroadcast) {
                var currentHash = this.calculateNotificationsHash();
                if (currentHash === this.config.lastNotificationHash) {
                    return;
                }
            }
            
            this.config.isLoading = true;
            
            var pageLimit = self.config.initialLimit;
            var fetchLimit = pageLimit + 1;

            $.ajax({
                url: yooadmNotifications.ajax_url,
                method: 'POST',
                data: {
                    action: 'yooadmin_get_notifications',
                    nonce: yooadmNotifications.get_notifications_nonce || yooadmNotifications.ajax_nonce || yooadmNotifications.nonce,
                    limit: fetchLimit,
                    offset: 0
                },
                success: function(response) {
                    // Handle both direct array and wrapped response formats
                    var notifications = [];
                    var payload = null;
                    if (response && typeof response === 'object') {
                        if (response.success && response.data) {
                            payload = response.data;
                            if (response.data.data && Array.isArray(response.data.data)) {
                                notifications = response.data.data;
                            } else if (Array.isArray(response.data)) {
                            notifications = response.data;
                            } else {
                                notifications = [];
                            }
                        } else if (response.data && Array.isArray(response.data)) {
                            notifications = response.data;
                        } else if (Array.isArray(response)) {
                            notifications = response;
                        } else {
                            notifications = [];
                        }
                    } else {
                        notifications = [];
                    }
                    
                    // Ensure notifications is always an array
                    if (!Array.isArray(notifications)) {
                        notifications = [];
                    }
                    
                    // Parse meta if it's a JSON string (from database)
                    notifications.forEach(function(n) {
                        if (n.meta && typeof n.meta === 'string') {
                            try {
                                n.meta = JSON.parse(n.meta);
                            } catch(e) {
                                // If parsing fails, keep as string or set to empty object
                                n.meta = {};
                            }
                        }
                        // Ensure meta is an object
                        if (!n.meta || typeof n.meta !== 'object') {
                            n.meta = {};
                        }
                    });

                    if (payload && payload.has_more !== undefined) {
                        self.config.hasMore = !!payload.has_more;
                    } else {
                        self.config.hasMore = notifications.length >= fetchLimit;
                    }

                    var toUse = notifications.length >= fetchLimit
                        ? notifications.slice(0, pageLimit)
                        : notifications;
                    if (payload && payload.offset !== undefined) {
                        self.config.loadOffset = parseInt(payload.offset, 10) || toUse.length;
                    } else {
                        self.config.loadOffset = toUse.length;
                    }
                    self.config.notifications = toUse;
                    
                    // Store previous count before applying server unread count.
                    var previousCount = self.config.unreadCount;
                    
                    // Update unread count from response if available (from database)
                    if (response && response.unread_count !== undefined) {
                        self.config.unreadCount = parseInt(response.unread_count) || 0;
                    } else if (response && response.data && response.data.unread_count !== undefined) {
                        self.config.unreadCount = parseInt(response.data.unread_count) || 0;
                    }
                    
                    // Calculate hash of new data
                    var newHash = self.calculateNotificationsHash(self.config.notifications, self.config.unreadCount);
                    
                    // Use previous count from broadcast if available (for cross-tab sound)
                    var countForSoundCheck = previousCount;
                    if (fromBroadcast && self.config.previousCountForBroadcast !== undefined) {
                        countForSoundCheck = self.config.previousCountForBroadcast;
                        self.config.previousCountForBroadcast = undefined; // Clear after use
                    }
                    
                    // Only update and broadcast if data actually changed
                    if (newHash !== self.config.lastNotificationHash) {
                        self.config.lastNotificationHash = newHash;
                        
                    self.renderNotifications();
                    self.updateCounts();
                        self.updateBadgeCount(countForSoundCheck); // Update badge immediately (pass previous count for sound check)
                        
                        // Broadcast update to other tabs (only if not from broadcast to prevent loops)
                        if (!fromBroadcast) {
                            // Throttle broadcasts: only send if enough time has passed since last broadcast
                            var now = Date.now();
                            if (now - self.config.lastBroadcastTimestamp > 1000) { // 1 second throttle
                                self.config.lastBroadcastTimestamp = now;
                                self.broadcastMessage('NOTIFICATION_UPDATE', {
                                    unreadCount: self.config.unreadCount,
                                    count: notifications.length,
                                    sessionId: self.config.sessionId
                                });
                                
                                // Also broadcast badge update separately for immediate UI update
                                self.broadcastMessage('BADGE_UPDATE', {
                                    unreadCount: self.config.unreadCount,
                                    sessionId: self.config.sessionId
                                });
                            }
                        }
                    }
                    
                    self.config.isLoading = false;
                    
                    // Mark initial load as complete after first successful load
                    self.markInitialLoadComplete();
                },
                error: function(xhr, status, error) {
                    console.error('[yooadm Notifications] AJAX failed:', error);
                    console.error('[yooadm Notifications] Status:', status);
                    console.error('[yooadm Notifications] XHR status:', xhr.status);
                    
                    // Check if response is HTML (maintenance mode or server error)
                    var responseText = xhr.responseText || '';
                    var trimmedText = responseText.trim();
                    var isHtmlResponse = trimmedText.startsWith('<!DOCTYPE') || 
                                        trimmedText.startsWith('<!doctype') ||
                                        trimmedText.startsWith('<html') ||
                                        trimmedText.startsWith('<HTML') ||
                                        (trimmedText.toLowerCase().includes('maintenance') && xhr.status === 503) ||
                                        (xhr.status === 503 && trimmedText.length > 100); // 503 with content likely means maintenance
                    
                    // Don't log full HTML response in console (too verbose)
                    if (isHtmlResponse) {
                        console.error('[yooadm Notifications] Server returned HTML instead of JSON (likely maintenance mode or server error)');
                    } else {
                        console.error('[yooadm Notifications] Response text:', responseText);
                    }
                    
                    // Mark maintenance mode if detected
                    var isMaintenance = xhr.status === 503 || isHtmlResponse;
                    if (isMaintenance) {
                        if (!self.config.maintenanceModeDetected) {
                            self.config.maintenanceModeDetected = true;
                            setTimeout(function() {
                                self.config.maintenanceModeDetected = false;
                            }, 30000);
                        }
                        self.showError(true); // Pass true to indicate maintenance mode
                    } else {
                        self.showError(false); // Regular error
                    }
                    self.config.isLoading = false;
                }
            });
        },
        
        /**
         * Render notifications in the list
         */
        renderNotifications: function() {
            var self = this;
            this.ensureNotificationsArray();
            var filteredNotifications = this.getFilteredNotifications();
            
            // Debug: Check for banner notifications (including in groups)
            var bannerNotifications = [];
            var bannerGroups = [];
            this.config.notifications.forEach(function(n) {
                if ((n.source_type || '') === 'banner' || (n.source_type || '') === 'banner-conversion' || (n.source_type || '') === 'wp_admin_banner') {
                    bannerNotifications.push(n);
                } else if (n.type === 'group' && n.items && n.items.length > 0) {
                    var groupBanners = n.items.filter(function(item) {
                        return (item.source_type || '') === 'banner' || (item.source_type || '') === 'banner-conversion' || (item.source_type || '') === 'wp_admin_banner';
                    });
                    if (groupBanners.length > 0) {
                        bannerGroups.push({
                            group: n,
                            banners: groupBanners
                        });
                        bannerNotifications = bannerNotifications.concat(groupBanners);
                    }
                }
            });
            
            if (filteredNotifications.length === 0) {
                if (this.config.list && this.config.list.length > 0) {
                    this.renderEmptyState();
                } else {
                    // List element not found, cannot render empty state
                    // Try to re-cache elements
                    this.cacheElements();
                    if (this.config.list && this.config.list.length > 0) {
                        this.renderEmptyState();
                    }
                }
                return;
            }
            
            var html = '';
            var bannerRenderedCount = 0;
            filteredNotifications.forEach(function(notification) {
                var isBanner = (notification.source_type || '') === 'banner' || 
                               (notification.source_type || '') === 'banner-conversion' || 
                               (notification.source_type || '') === 'wp_admin_banner';
                if (isBanner) {
                    bannerRenderedCount++;
                }
                html += self.renderNotificationItem(notification);
            });
            
            this.config.list.html(html);
            
            // Update time displays
            this.updateTimeDisplays();
            this.maybeAutoLoadMore();
        },
        
        /**
         * Render single notification item (like old system - no grouping)
         */
        renderNotificationItem: function(notification) {
            // If this is a group notification, expand it to individual items
            if (notification.type === 'group' && notification.items && notification.items.length > 0) {
                var html = '';
                notification.items.forEach(function(item) {
                    html += this.renderSingleNotificationItem(item);
                }.bind(this));
                return html;
            }
            
            // Render single notification
            return this.renderSingleNotificationItem(notification);
        },
        
        /**
         * Render single notification item (like old system)
         */
        renderSingleNotificationItem: function(notification) {
            var priorityClass = 'yp-priority-' + (notification.priority || 'medium');
            var isUnread = notification.status === 'new';
            
            // Get notification type for filtering
            var notifType = notification.type || notification.source_type || '';
            var sourceType = notification.source_type || '';
            
            // Use custom ID from meta if available (like old system), otherwise use database ID
            var meta = notification.meta || {};
            var customId = null;
            
            // Handle meta as string or object
            if (typeof meta === 'string' && meta) {
                try {
                    var parsed = JSON.parse(meta);
                    customId = parsed.id || null;
                    meta = parsed;
                } catch(e) {
                    // Not JSON, ignore
                }
            } else if (typeof meta === 'object' && meta) {
                customId = meta.id || null;
            }
            
            var dbId = notification.id || null;
            // Use custom ID for data-id if available (like old system uses feed-id), otherwise use database ID
            var dataId = customId || dbId || '';
            
            // Ensure dbId is always set (use dataId as fallback if dbId is missing)
            if (!dbId && dataId) {
                // If dataId is a number, use it as dbId
                var dataIdNum = parseInt(dataId, 10);
                if (!isNaN(dataIdNum) && String(dataIdNum) === String(dataId)) {
                    dbId = dataIdNum;
                }
            }
            
            // Get icon based on notification type/priority (like old system)
            var icon = this.getNotificationIcon(notification);
            // Normalize icon: remove 'dashicons' class if present, we'll add it in HTML
            if (icon && icon.startsWith('dashicons ')) {
                icon = icon.replace('dashicons ', '').trim();
            } else if (icon && icon.startsWith('dashicons-')) {
                icon = icon.replace('dashicons-', '').trim();
            }
            
            // Extract data for modal (like old system)
            var metaItem = meta.item || {};
            
            // For license notifications: don't use title as itemName (use source instead)
            // For plugin/theme updates: use metaItem.name (plugin/theme name)
            var isLicenseNotification = (sourceType === 'license') ||
                                       (notification.source && notification.source.toLowerCase() === 'yooadmin');
            
            var itemName = '';
            if (isLicenseNotification) {
                // License notifications: leave itemName empty (will use source)
                itemName = '';
            } else {
                // Plugin/theme updates: use metaItem.name (like "WPBakery Page Builder")
                itemName = metaItem.name || '';
            }
            
            var currentVersion = metaItem.current_version || '';
            var newVersion = metaItem.new_version || '';
            var upgradeNotice = metaItem.upgrade_notice || '';
            var rowNotice = metaItem.row_notice || '';
            var description = upgradeNotice || rowNotice || notification.message || '';
            
            // Build version text
            var versionText = '';
            if (currentVersion && newVersion) {
                versionText = 'Version ' + currentVersion + ' → ' + newVersion;
            } else if (currentVersion) {
                versionText = 'Version ' + currentVersion;
            } else if (newVersion) {
                versionText = 'Version ' + newVersion;
            }
            
            // Determine if expandable (updates, banners, or has description/version)
            var isUpdateType = notifType === 'wp-plugin-updates' || notifType === 'wp-theme-updates' || 
                              notifType === 'yooadmin-extensions-update' || sourceType === 'plugin_updates' || 
                              sourceType === 'theme_updates';
            var isBannerType = sourceType === 'banner' || sourceType === 'banner-conversion' || sourceType === 'wp_admin_banner';
            var inferredBannerSource = isBannerType ? this.inferBannerComponentName(meta.banner_id || '', meta.classes || '') : '';
            if (isBannerType && (meta.component_name || inferredBannerSource)) {
                itemName = meta.component_name || inferredBannerSource;
            }
            var isExpandable = isUpdateType || isBannerType || (description && description.length > 60) || versionText;
            var expandableClass = isExpandable ? 'yp-notification-expandable' : '';
            
            // Build summary text (short message for list view)
            // Strip HTML tags for dropdown display
            var rawMessage = notification.message || '';
            var summaryText = this.stripHtml(rawMessage);
            if (isUpdateType && versionText) {
                summaryText = versionText;
            }
            
            // Get meta data for actions (for license notifications)
            var metaJson = '';
            var actionText = notification.action_text || this.getUiString('viewAction', 'View');
            try {
                var metaObj = meta;
                if (typeof meta === 'string' && meta) {
                    metaObj = JSON.parse(meta);
                }
                if (metaObj && typeof metaObj === 'object') {
                    metaJson = JSON.stringify(metaObj);
                    // Try to get action text from meta.actions[0].text
                    if (metaObj.actions && Array.isArray(metaObj.actions) && metaObj.actions.length > 0 && metaObj.actions[0].text) {
                        actionText = metaObj.actions[0].text;
                    } else if (metaObj.action_text) {
                        actionText = metaObj.action_text;
                    }
                }
            } catch(e) {
                metaJson = '';
            }
            actionText = this.localizeActionText(actionText);
            
            // Get source for sender display (YOOAdmin, WordPress, etc.)
            var source = notification.source || '';
            if (
                isBannerType &&
                (meta.component_name || inferredBannerSource) &&
                (!source || source === 'system' || source === 'admin_banner')
            ) {
                source = meta.component_name || inferredBannerSource;
            }
            source = this.normalizeBannerSourceLabel(source);
            
            // Build HTML exactly like old system: <div class="yp-notification-item">
            var html = '<div class="yp-notification-item ' + priorityClass + ' ' + expandableClass + ' ' + 
                      (isUnread ? 'yp-notification-unread' : 'yp-notification-read') + '" ' +
                      'data-id="' + this.escapeHtml(dataId) + '" ' +
                      'data-feed-id="' + this.escapeHtml(dataId) + '" ' + // Like old system
                      (dbId ? 'data-db-id="' + this.escapeHtml(String(dbId)) + '" ' : '') +
                      'data-notif-type="' + this.escapeHtml(notifType) + '" ' +
                      'data-source="' + this.escapeHtml(sourceType) + '" ' +
                      'data-source-type="' + this.escapeHtml(sourceType) + '" ' + // Add source_type for license detection
                      (source ? 'data-source-original="' + this.escapeHtml(source) + '" ' : '') +
                      'data-full-title="' + this.escapeHtml(notification.title || '') + '" ' +
                      'data-summary="' + this.escapeHtml(summaryText) + '" ' +
                      'data-full-text="' + this.escapeHtml(notification.message || '') + '" ' +
                      (description ? 'data-description="' + this.escapeHtml(description) + '" ' : '') +
                      'data-link-url="' + this.escapeHtml(notification.url || '#') + '" ' +
                      'data-link-text="' + this.escapeHtml(actionText) + '" ' +
                      (metaJson ? 'data-meta="' + this.escapeHtml(metaJson) + '" ' : '') +
                      (itemName ? 'data-item-name="' + this.escapeHtml(itemName) + '" ' : '') +
                      (currentVersion ? 'data-current-version="' + this.escapeHtml(currentVersion) + '" ' : '') +
                      (newVersion ? 'data-new-version="' + this.escapeHtml(newVersion) + '" ' : '') +
                      (versionText ? 'data-version-text="' + this.escapeHtml(versionText) + '" ' : '') +
                      '>' +
                      '<div class="yp-notification-icon">' +
                      '<span class="dashicons ' + (icon.startsWith('dashicons-') ? icon : 'dashicons-' + icon) + '"></span>' +
                      '</div>' +
                      '<div class="yp-notification-body">' +
                      '<div class="yp-notification-actions">' +
                      '<button type="button" class="yp-action-btn yp-archive-btn dashicons dashicons-archive" data-id="' + this.escapeHtml(dataId) + '"' + (dbId ? ' data-db-id="' + this.escapeHtml(String(dbId)) + '"' : '') + ' title="Archive" aria-label="Archive"></button>' +
                      '<button type="button" class="yp-action-btn yp-snooze-btn dashicons dashicons-clock" data-id="' + this.escapeHtml(dataId) + '"' + (dbId ? ' data-db-id="' + this.escapeHtml(String(dbId)) + '"' : '') + ' title="' + this.escapeHtml(this.getUiString('snooze', 'Snooze')) + '" aria-label="' + this.escapeHtml(this.getUiString('snooze', 'Snooze')) + '"></button>' +
                      '<button type="button" class="yp-action-btn yp-dismiss-btn dashicons dashicons-trash" data-id="' + this.escapeHtml(dataId) + '"' + (dbId ? ' data-db-id="' + this.escapeHtml(String(dbId)) + '"' : '') + ' title="Delete" aria-label="Delete"></button>' +
                      (isExpandable ? '<span class="yp-notification-expand dashicons dashicons-arrow-right-alt2" title="View details"></span>' : '') +
                      '</div>' +
                      '<div class="yp-notification-content">' +
                      '<strong' + this.getMixedTextDirectionAttrs(notification.title || 'Notification') + '>' + this.escapeHtml(notification.title || 'Notification') + '</strong>' +
                      '<span class="yp-notification-text"' + this.getMixedTextDirectionAttrs(summaryText) + '>' + this.escapeHtml(this.truncateNotificationText(summaryText, 120)) + '</span>' +
                      (notification.created_at ? '<span class="yp-notification-time" data-time="' + notification.created_at + '">' + this.formatTime(notification.created_at) + '</span>' : '') +
                      '</div></div></div>';
            
            return html;
        },
        
        /**
         * Get notification icon based on type/priority (like old system)
         */
        getNotificationIcon: function(notification) {
            // First check if icon is provided directly (like old system)
            if (notification.icon) {
                var icon = notification.icon;
                // Ensure icon has 'dashicons-' prefix if it doesn't already
                if (icon && !icon.startsWith('dashicons-') && !icon.startsWith('dashicons ')) {
                    // If it's a WordPress admin icon (like 'admin-plugins'), add dashicons- prefix
                    if (icon.startsWith('admin-')) {
                        icon = 'dashicons-' + icon;
                    } else {
                        // Otherwise, assume it's a dashicon class name and add dashicons- prefix
                        icon = 'dashicons-' + icon;
                    }
                }
                return icon;
            }
            
            // Check meta.icon (like old system)
            var meta = notification.meta || {};
            if (meta.icon) {
                var icon = meta.icon;
                // Ensure icon has 'dashicons-' prefix if it doesn't already
                if (icon && !icon.startsWith('dashicons-') && !icon.startsWith('dashicons ')) {
                    if (icon.startsWith('admin-')) {
                        icon = 'dashicons-' + icon;
                    } else {
                        icon = 'dashicons-' + icon;
                    }
                }
                return icon;
            }
            
            var type = notification.type || '';
            var sourceType = notification.source_type || '';
            var title = (notification.title || '').toLowerCase();
            
            // Check for plugin updates (check both type and source_type)
            if (type === 'wp-plugin-updates' || sourceType === 'plugin_updates' || 
                type === 'plugin_update' || title.includes('plugin update')) {
                return 'dashicons-update';
            }
            
            // Check for theme updates
            if (type === 'wp-theme-updates' || sourceType === 'theme_updates' || 
                type === 'theme_update' || title.includes('theme update')) {
                return 'dashicons-update';
            }
            
            // Check for extension updates
            if (type === 'yooadmin-extensions-update' || sourceType === 'extensions' || 
                sourceType === 'yooadmin_extensions') {
                return 'dashicons-update';
            }
            
            // Default fallback
            return 'dashicons-bell';
        },
        
        /**
         * Render empty state
         */
        renderEmptyState: function() {
            var emptyMessages = {
                all: { icon: 'dashicons-bell', title: 'All caught up!', message: 'You have no notifications at the moment.' },
                unread: { icon: 'dashicons-yes', title: 'No unread notifications', message: 'You\'ve read all your notifications.' },
                critical: { icon: 'dashicons-shield-alt', title: 'No critical notifications', message: 'Everything looks good!' },
                updates: { icon: 'dashicons-update', title: 'No updates available', message: 'Your system is up to date.' }
            };
            
            var state = emptyMessages[this.config.currentFilter] || emptyMessages.all;
            
            var html = '<div class="yp-empty-state">' +
                      '<div class="yp-empty-icon">' +
                      '<i class="dashicons ' + state.icon + '"></i>' +
                      '</div>' +
                      '<h3 class="yp-empty-title">' + state.title + '</h3>' +
                      '<p class="yp-empty-message">' + state.message + '</p>' +
                      '</div>';
            
            this.config.list.html(html);
        },
        
        /**
         * Move modal to document.body so backdrop-filter blurs full dashboard (like YOOMedia).
         */
        ensureNotificationModalPortaled: function() {
            var el = document.getElementById('yp-notification-modal');
            if (!el || !document.body) {
                return;
            }
            if (el.parentNode !== document.body) {
                document.body.appendChild(el);
            }
            el.classList.add('ysh-notification-modal--portaled');
        },

        /**
         * Open notification modal from data attributes (like old system)
         */
        openNotificationModalFromData: function(data) {
            var self = this;
            self.ensureNotificationModalPortaled();
            self.syncModalSnoozeButton();
            var modal = $('#yp-notification-modal');
            if (!modal.length) {
                return;
            }
            var notificationView = modal.find('.yp-modal-notification-view');
            var deleteConfirmView = modal.find('.yp-modal-delete-confirm-view');
            var snoozeConfirmView = modal.find('.yp-modal-snooze-confirm-view');
            
            // Set feedId as data attribute for CSS targeting
            if (data.feedId) {
                modal.attr('data-feed-id', data.feedId);
            }
            
            // Set icon
            var icon = data.icon || 'info';
            // Normalize icon: remove 'dashicons' or 'dashicons-' prefix if present
            if (icon && icon.startsWith('dashicons ')) {
                icon = icon.replace('dashicons ', '').trim();
            } else if (icon && icon.startsWith('dashicons-')) {
                icon = icon.replace('dashicons-', '').trim();
            }
            // Set classes: yp-modal-icon dashicons dashicons-[icon-name]
            notificationView.find('.yp-modal-icon').attr('class', 'yp-modal-icon dashicons dashicons-' + icon);
            
            // Set title (notification type label like old system)
            // FIXED: Use title first (not notifTypeLabel), then fallback to notifTypeLabel
            var titleText = data.title || data.notifTypeLabel || 'Notification';
            var $title = notificationView.find('.yp-modal-title');
            $title.text(titleText);
            this.applyTextDirection($title, titleText);
            
            // Set sender/source as subtitle (format as "From: YOOAdmin" like email)
            var modalText = notificationView.find('.yp-modal-text');
            var senderText = '';
            
            // Check if this is a license notification (should use source, not itemName)
            var isLicenseNotification = (data.source_type === 'license') ||
                                        (data.source && data.source.toLowerCase() === 'yooadmin');
            
            // Priority 1: Use itemName if available (for update notifications like plugins)
            // But skip itemName for license notifications - use source instead
            if (!isLicenseNotification && data.itemName && data.itemName.trim() !== '') {
                senderText = data.itemName.trim();
            }
            // Priority 2: Use source field if available (for license notifications or when itemName is not available)
            else if (data.source && data.source.trim() !== '') {
                senderText = this.normalizeBannerSourceLabel(data.source.trim());
            }
            
            // Format "yooadmin" to "YOOAdmin" (capitalize properly)
            if (senderText.toLowerCase() === 'yooadmin') {
                senderText = 'YOOAdmin';
            } else if (
                (data.source_type === 'banner' || data.source_type === 'banner-conversion' || data.source_type === 'wp_admin_banner') &&
                (senderText.toLowerCase() === 'system' || senderText.toLowerCase() === 'admin_banner')
            ) {
                senderText = 'WordPress Admin';
            } else if (senderText && senderText.length > 0 && !this.containsArabic(senderText)) {
                // Capitalize Latin source labels only (do not alter Arabic).
                senderText = senderText.split(' ').map(function(word) {
                    return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
                }).join(' ');
            }
            
            if (senderText && senderText.trim() !== '') {
                modalText.text(this.getUiString('from', 'From:') + ' ' + senderText).show();
                modalText.css({
                    'font-weight': '500',
                    'font-size': '12px',
                    'color': '#666',
                    'margin-bottom': '8px',
                    'text-align': 'start'
                });
                this.applyTextDirection(modalText, senderText);
            } else {
                modalText.hide();
                modalText.removeAttr('dir').removeAttr('lang');
            }
            
            // Set details (like old system)
            var details = notificationView.find('.yp-modal-details');
            details.empty();
            var frag = document.createDocumentFragment();
            var hasContent = false;
            var modalTextContent = this.cleanNotificationHtml(data.text || '');
            var modalDescription = this.cleanNotificationHtml(data.description || '');
            
            // Add description/text if available (HTML sanitized server-side: wp_kses_post — same as Lite)
            if (modalTextContent && modalTextContent.trim() !== '') {
                var textHasVersionInfo = /^(version\s*\d+.*|update\s*:.*|.*?\s*→\s*\d+.*)$/i.test(modalTextContent.trim()) &&
                                       modalTextContent.trim().length < 150;

                if (!textHasVersionInfo) {
                    var descP = document.createElement('div');
                    descP.innerHTML = modalTextContent;
                    descP.style.margin = '0 0 8px 0';
                    descP.style.fontSize = '12px';
                    descP.style.lineHeight = '1.48';
                    descP.style.color = '#666';
                    descP.style.textAlign = 'start';
                    descP.style.wordBreak = 'break-word';
                    if (this.containsArabic(modalTextContent)) {
                        descP.setAttribute('dir', 'rtl');
                        descP.setAttribute('lang', 'ar');
                    }
                    frag.appendChild(descP);
                    hasContent = true;
                }
            }

            if (modalDescription && modalDescription.trim() !== '' && modalDescription !== modalTextContent) {
                var descP2 = document.createElement('div');
                descP2.innerHTML = modalDescription;
                descP2.style.margin = '0 0 8px 0';
                descP2.style.fontSize = '12px';
                descP2.style.lineHeight = '1.48';
                descP2.style.color = '#666';
                descP2.style.textAlign = 'start';
                descP2.style.wordBreak = 'break-word';
                if (this.containsArabic(modalDescription)) {
                    descP2.setAttribute('dir', 'rtl');
                    descP2.setAttribute('lang', 'ar');
                }
                frag.appendChild(descP2);
                hasContent = true;
            }
            
            // Add version info at the end if available (like old system)
            if (data.versionInfo && data.versionInfo.trim() !== '') {
                var versionDiv = document.createElement('div');
                versionDiv.innerHTML = '<strong style="color: #1a1a1a;">Version:</strong> <span style="color: #666;">' + this.escapeHtml(data.versionInfo) + '</span>';
                versionDiv.style.marginTop = hasContent ? '10px' : '0';
                versionDiv.style.paddingTop = hasContent ? '10px' : '0';
                versionDiv.style.borderTop = hasContent ? '1px solid #e5e5e5' : 'none';
                versionDiv.style.fontSize = '12px';
                frag.appendChild(versionDiv);
                hasContent = true;
            }
            
            if (hasContent) {
                details[0].appendChild(frag);
                var combinedDetailsText = (modalTextContent + ' ' + modalDescription).trim();
                this.applyTextDirection(details, combinedDetailsText);
                this.applyTextDirectionToDescendants(details);
                details.show();
            } else {
                details.removeAttr('dir').removeAttr('lang');
                details.hide();
            }
            
            // Set footer buttons (like old system)
            var footer = notificationView.find('.yp-modal-footer');
            var actionBtn = footer.find('.yp-modal-action-btn');
            var deleteBtn = footer.find('.yp-modal-delete-btn');
            var dismissBtn = footer.find('.yp-modal-dismiss-btn');
            var snoozeBtn = footer.find('.yp-modal-snooze-btn');
            
            // Reset visibility
            notificationView.show();
            deleteConfirmView.hide();
            snoozeConfirmView.hide();
            actionBtn.show();
            deleteBtn.show();
            dismissBtn.show();
            snoozeBtn.show();
            
            // CRITICAL: MUST use database ID only (not meta.id/feedId)
            // notification.id is the database ID - use it directly
            var notificationId = data.dbId || data.id || null;
            
            // Validate: notificationId must be a number (database ID)
            if (notificationId && !isNaN(parseInt(notificationId, 10)) && isFinite(notificationId)) {
                notificationId = parseInt(notificationId, 10);
            } else {
                // If no valid database ID, try to find it from notifications array
                // Search in all notifications (including expanded groups)
                this.ensureNotificationsArray();
                var allNotifications = [];
                this.config.notifications.forEach(function(n) {
                    if (n.type === 'group' && n.items && n.items.length > 0) {
                        n.items.forEach(function(item) {
                            allNotifications.push(item);
                        });
                    } else {
                        allNotifications.push(n);
                    }
                });
                
                // Try to find by feedId (meta.id) first
                if (data.feedId) {
                    var foundNotif = allNotifications.find(function(n) {
                        // Get custom ID from meta
                        var metaId = null;
                        var metaObj = null;
                        
                        // Parse meta if it's a string
                        if (n.meta) {
                            if (typeof n.meta === 'string') {
                                try {
                                    metaObj = JSON.parse(n.meta);
                                    metaId = metaObj.id || null;
                                } catch(e) {
                                    // Not JSON, ignore
                                }
                            } else if (typeof n.meta === 'object') {
                                metaObj = n.meta;
                                metaId = metaObj.id || null;
                            }
                        }
                        
                        // Match by custom ID (meta.id) - exact match
                        var customIdMatch = (metaId && String(metaId) === String(data.feedId));
                        
                        // Match by database ID if feedId is numeric
                        var dbIdMatch = false;
                        if (n.id) {
                            var nIdStr = String(n.id);
                            var feedIdStr = String(data.feedId);
                            dbIdMatch = (nIdStr === feedIdStr);
                        }
                        
                        return customIdMatch || dbIdMatch;
                    });
                    
                    if (foundNotif && foundNotif.id && !isNaN(parseInt(foundNotif.id, 10))) {
                        notificationId = parseInt(foundNotif.id, 10);
                    }
                }
                
                // If still not found, try to find by title or other attributes
                if (!notificationId && data.title) {
                    var foundByTitle = allNotifications.find(function(n) {
                        return n.title && String(n.title).trim() === String(data.title).trim();
                    });
                    if (foundByTitle && foundByTitle.id && !isNaN(parseInt(foundByTitle.id, 10))) {
                        notificationId = parseInt(foundByTitle.id, 10);
                    }
                }
            }
            
            // Store database ID in modal action buttons
            if (notificationId && notificationId > 0) {
                snoozeBtn.add(deleteBtn).add(dismissBtn)
                    .data('id', notificationId)
                    .data('db-id', notificationId)
                    .attr('data-notification-id', notificationId);
            } else {
                console.error('[yooadm Notifications] ERROR: Invalid or missing database ID for modal actions', data);
            }
            
            // Store notificationId in closure for handler
            var storedNotificationId = notificationId;
            
            // FIXED: Show all links from notification (from meta.urls for banners, or single linkUrl)
            var links = [];
            
            // Priority 1: Check if notification has multiple URLs (from banner meta.urls)
            if (data.urls && Array.isArray(data.urls) && data.urls.length > 0) {
                links = data.urls;
                // CRITICAL: Remove duplicates based on URL
                var seenUrls = {};
                links = links.filter(function(link) {
                    var url = link.url || '';
                    if (seenUrls[url]) {
                        return false; // Duplicate, skip
                    }
                    seenUrls[url] = true;
                    return true;
                });
            }
            
            // Priority 2: Check for actions in meta (for license notifications)
            if (data.meta && typeof data.meta === 'object') {
                var metaActions = data.meta.actions;
                if (metaActions && Array.isArray(metaActions) && metaActions.length > 0) {
                    metaActions.forEach(function(action) {
                        var actionUrl = action.url || '';
                        // Check if this action URL is already in links
                        var actionUrlInLinks = links.some(function(link) {
                            return (link.url || '') === actionUrl;
                        });
                        if (!actionUrlInLinks && actionUrl && actionUrl !== '#') {
                            links.push({
                                url: actionUrl,
                                text: action.text || self.getUiString('viewAction', 'View'),
                                target: action.target || (actionUrl.indexOf('http') === 0 && actionUrl.indexOf(window.location.origin) === -1 ? '_blank' : '_self')
                            });
                        }
                    });
                }
            }
            
            // Priority 3: Use single linkUrl as fallback ONLY if not already in links
            // CRITICAL: Check if linkUrl is already in links to prevent duplicates
            if (data.linkUrl && data.linkUrl !== '#') {
                var linkUrlInLinks = links.some(function(link) {
                    return (link.url || '') === data.linkUrl;
                });
                if (!linkUrlInLinks) {
                    // Auto-detect target for linkUrl
                    var isExternal = data.linkUrl.indexOf('http') === 0 && 
                                    data.linkUrl.indexOf(window.location.origin) === -1;
                    links.push({
                        url: data.linkUrl,
                        text: self.localizeActionText(data.linkText || ''),
                        target: isExternal ? '_blank' : '_self'
                    });
                }
            }
            
            // Clear ALL existing action buttons (including the default one)
            footer.find('.yp-modal-action-btn').remove();

            // Drop dismiss/close pseudo-actions: the modal already has its own
            // dismiss/snooze/delete controls, so they must never appear as action buttons.
            links = links.filter(function(link) {
                var url = (link.url || '').trim();
                if (!url || url === '#' || url.toLowerCase().indexOf('javascript:') === 0) {
                    return false;
                }
                return !self.isDismissActionLabel(link.text);
            });

            // Add all links as buttons
            if (links.length > 0) {
                links.forEach(function(link, index) {
                    // Determine target: use link.target if provided, otherwise check if external
                    var target = link.target || '_self';
                    if (!link.target) {
                        // Auto-detect: external links open in new tab, internal in same tab
                        var isExternal = link.url && link.url.indexOf('http') === 0 && 
                                        link.url.indexOf(window.location.origin) === -1;
                        target = isExternal ? '_blank' : '_self';
                    }
                    
                    // Create new button for each link
                    var btn = $('<a class="yp-modal-action-btn button button-primary"></a>');
                    btn.attr('href', link.url)
                       .attr('target', target);
                    
                    // Add rel="noopener" for external links
                    if (target === '_blank') {
                        btn.attr('rel', 'noopener');
                    }
                    
                    btn.text(self.localizeActionText(link.text));
                    // Add before dismiss/snooze buttons
                    footer.prepend(btn);
                });
            }
            
            // Show modal
            modal.css('display', 'flex');
            modal[0].classList.add('is-open');
            $('body').css('overflow', 'hidden');
            $('body').addClass('yp-notification-modal-open');
            
            // Close dropdown
            this.closeDropdown();
            
            // Bind close handlers
            modal.find('.yp-modal-close, .yp-modal-overlay').off('click').on('click', function() {
                self.closeNotificationModal();
            });
            
            var getModalNotificationId = function(button) {
                var notifId = storedNotificationId || button.data('db-id') || button.data('id') || button.attr('data-notification-id');
                if (notifId && !isNaN(parseInt(notifId, 10)) && isFinite(notifId)) {
                    notifId = parseInt(notifId, 10);
                    if (notifId > 0) {
                        return notifId;
                    }
                }
                return null;
            };
            
            deleteBtn.add(dismissBtn).off('click').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var notifId = getModalNotificationId($(this));
                if (!notifId) {
                    console.error('[yooadm Notifications] Cannot find valid database ID for delete.');
                    alert('Error: Cannot find notification ID. Please try again.');
                    return;
                }
                
                if (deleteConfirmView.length) {
                    notificationView.hide();
                    snoozeConfirmView.hide();
                    deleteConfirmView.show();
                    return;
                }
                
                self.dismissNotification(notifId);
                self.closeNotificationModal();
            });
            
            modal.find('.yp-delete-confirm-cancel').off('click').on('click', function(e) {
                e.preventDefault();
                deleteConfirmView.hide();
                notificationView.show();
            });
            
            modal.find('.yp-delete-confirm-ok').off('click').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var notifId = getModalNotificationId(deleteBtn);
                if (!notifId) {
                    console.error('[yooadm Notifications] Cannot find valid database ID for delete confirmation.');
                    alert('Error: Cannot find notification ID. Please try again.');
                    return;
                }
                
                self.dismissNotification(notifId);
                self.closeNotificationModal();
            });
            
            // Snooze button handler
            snoozeBtn.off('click').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                // Get database ID (must be numeric)
                var notifId = getModalNotificationId($(this));
                if (notifId) {
                    self.showSnoozeOptions(notifId, $(this));
                } else {
                    console.error('[yooadm Notifications] Cannot find valid database ID for snooze. ID:', notifId);
                    alert('Error: Cannot find notification ID. Please try again.');
                }
            });
            
            // Modal opened successfully
        },
        
        /**
         * Open notification modal with full details (legacy method - uses notification object)
         */
        openNotificationModal: function(notification) {
            var self = this;
            // Convert notification object to modal data format (like old system)
            // FIXED: Parse meta if it's a string (from database)
            var meta = notification.meta || {};
            if (typeof meta === 'string' && meta) {
                try {
                    meta = JSON.parse(meta);
                } catch(e) {
                    meta = {};
                }
            } else if (!meta || typeof meta !== 'object') {
                meta = {};
            }
            
            var metaItem = meta.item || {};
            var notifType = notification.type || notification.source_type || '';
            
            // Build notification type label
            var notifTypeLabel = '';
            if (notifType === 'wp-plugin-updates') {
                notifTypeLabel = 'Plugin update';
            } else if (notifType === 'wp-theme-updates') {
                notifTypeLabel = 'Theme update';
            } else if (notifType === 'wp-core-update') {
                notifTypeLabel = 'WordPress update';
            } else if (notifType === 'yooadmin-extensions-update') {
                notifTypeLabel = 'Extension update';
            } else {
                notifTypeLabel = notification.title || 'Notification';
            }
            
            // Build version info
            var currentVersion = metaItem.current_version || '';
            var newVersion = metaItem.new_version || '';
            var versionInfo = '';
            if (currentVersion && newVersion) {
                versionInfo = currentVersion + ' → ' + newVersion;
            } else if (currentVersion) {
                versionInfo = currentVersion;
            } else if (newVersion) {
                versionInfo = newVersion;
            }
            
            // Get description
            var description = metaItem.upgrade_notice || metaItem.row_notice || notification.message || '';
            
            // Build modal data
            // FIXED: Extract URLs from meta (for banners) or use single URL
            // FIXED: Ensure meta is parsed if it's a string
            var parsedMeta = meta;
            if (typeof meta === 'string' && meta) {
                try {
                    parsedMeta = JSON.parse(meta);
                } catch(e) {
                    parsedMeta = {};
                }
            } else if (!meta || typeof meta !== 'object') {
                parsedMeta = {};
            }
            
            var urls = [];
            
            // Priority 1: Check for actions in meta (for license notifications)
            if (parsedMeta.actions && Array.isArray(parsedMeta.actions) && parsedMeta.actions.length > 0) {
                parsedMeta.actions.forEach(function(action) {
                    var actionUrl = action.url || '';
                    if (actionUrl && actionUrl !== '#') {
                        var isExternal = actionUrl.indexOf('http') === 0 && 
                                        actionUrl.indexOf(window.location.origin) === -1;
                        urls.push({
                            url: actionUrl,
                            text: action.text || self.getUiString('viewAction', 'View'),
                            target: action.target || (isExternal ? '_blank' : '_self')
                        });
                    }
                });
            }
            
            // Priority 2: Check for urls in meta (for banner notifications)
            if (parsedMeta.urls && Array.isArray(parsedMeta.urls) && parsedMeta.urls.length > 0) {
                // Banner notifications with multiple URLs
                parsedMeta.urls.forEach(function(link) {
                    var linkUrl = link.url || '';
                    // Check if already added from actions
                    var alreadyAdded = urls.some(function(u) {
                        return u.url === linkUrl;
                    });
                    if (!alreadyAdded && linkUrl && linkUrl !== '#') {
                        var isExternal = linkUrl.indexOf('http') === 0 && 
                                        linkUrl.indexOf(window.location.origin) === -1;
                        urls.push({
                            url: linkUrl,
                            text: link.text || self.getUiString('viewAction', 'View'),
                            target: link.target || (isExternal ? '_blank' : '_self')
                        });
                    }
                });
            }
            
            // Priority 3: Add notification.url only if it's not already in urls
            var linkUrl = notification.url || '#';
            if (linkUrl && linkUrl !== '#') {
                var linkUrlInUrls = urls.some(function(link) {
                    return link.url === linkUrl;
                });
                if (!linkUrlInUrls) {
                    // Auto-detect target for linkUrl
                    var isExternal = linkUrl.indexOf('http') === 0 && 
                                    linkUrl.indexOf(window.location.origin) === -1;
                    urls.push({
                        url: linkUrl,
                        text: self.getUiString('viewAction', 'View'),
                        target: isExternal ? '_blank' : '_self'
                    });
                }
            }
            
            // Check if linkUrl is in urls for modalData
            var linkUrlInUrls = urls.some(function(link) {
                return link.url === linkUrl;
            });
            
            // Get source for sender display
            var source = notification.source || '';
            
            var modalData = {
                icon: this.getNotificationIcon(notification),
                title: notification.title || '', // Use title, not notifTypeLabel
                notifTypeLabel: notifTypeLabel,
                itemName: metaItem.name || notification.title || '',
                source: source, // Pass source for sender display
                text: description,
                description: description,
                versionInfo: versionInfo,
                linkUrl: linkUrlInUrls ? null : linkUrl, // Only set if not already in urls
                linkText: self.getUiString('viewAction', 'View'),
                urls: urls, // FIXED: Pass all URLs for footer links (no duplicates)
                type: notifType,
                feedId: (meta.id) ? meta.id : notification.id,
                dbId: notification.id, // CRITICAL: Pass database ID for snooze/dismiss
                id: notification.id // Also pass as id for backward compatibility
            };
            
            this.openNotificationModalFromData(modalData);
        },
        
        /**
         * Close notification modal
         */
        closeNotificationModal: function() {
            var modal = $('#yp-notification-modal');
            modal.css('display', 'none');
            if (modal[0]) {
                modal[0].classList.remove('is-open');
            }
            $('body').css('overflow', '');
            $('body').removeClass('yp-notification-modal-open');
        },
        
        /**
         * Get filtered notifications
         */
        getFilteredNotifications: function() {
            var self = this;
            this.ensureNotificationsArray();
            var filtered = this.config.notifications;
            
            // Expand groups to individual items first
            var expanded = [];
            var bannerCountInGroups = 0;
            filtered.forEach(function(notification) {
                if (notification.type === 'group' && notification.items && notification.items.length > 0) {
                    // Count banners in this group
                    var groupBannerCount = 0;
                    notification.items.forEach(function(item) {
                        var itemSourceType = item.source_type || '';
                        if (itemSourceType === 'banner' || itemSourceType === 'banner-conversion' || itemSourceType === 'wp_admin_banner') {
                            groupBannerCount++;
                            bannerCountInGroups++;
                        }
                    });
                    
                    // Expand group to individual items
                    notification.items.forEach(function(item) {
                        expanded.push(item);
                    });
                } else {
                    expanded.push(notification);
                }
            });
            
            // Filter by tab type using real source_type (ALL | plugins | Theme | Extensions | Banners)
            if (this.config.currentFilter !== 'all') {
                expanded = expanded.filter(function(n) {
                    // Use real source_type from notification
                    var sourceType = n.source_type || '';
                    
                    if (this.config.currentFilter === 'plugins') {
                        return sourceType === 'plugin_updates';
                    } else if (this.config.currentFilter === 'theme') {
                        return sourceType === 'theme_updates';
                    } else if (this.config.currentFilter === 'extensions') {
                        return sourceType === 'extensions' || sourceType === 'yooadmin_extensions';
                    } else if (this.config.currentFilter === 'banners') {
                        return sourceType === 'banner' || sourceType === 'banner-conversion' || sourceType === 'wp_admin_banner';
                    }
                    return true;
                }.bind(this));
            }
            
            // Filter by search term
            if (this.config.searchTerm) {
                var searchTerm = this.config.searchTerm.toLowerCase();
                expanded = expanded.filter(function(n) {
                    var title = (n.title || '').toLowerCase();
                    var message = (n.message || '').toLowerCase();
                    return title.includes(searchTerm) || message.includes(searchTerm);
                });
            }
            
            // Filter out banner notifications if convert_banners is disabled
            if (typeof yooadmNotifications !== 'undefined' && yooadmNotifications.convert_banners_enabled === false) {
                expanded = expanded.filter(function(n) {
                    var sourceType = n.source_type || '';
                    return sourceType !== 'banner' && sourceType !== 'banner-conversion' && sourceType !== 'wp_admin_banner';
                });
            }
            
            return expanded;
        },
        
        /**
         * Set filter
         */
        setFilter: function(filter) {
            this.config.currentFilter = filter;
            
            // Update tab states
            this.config.filterTabs.removeClass('active');
            this.config.filterTabs.filter('[data-filter="' + filter + '"]').addClass('active');
            
            // Re-render notifications
            this.renderNotifications();
        },
        
        /**
         * Search notifications
         */
        search: function(searchTerm) {
            var self = this;
            
            // Update search container state
            $('.yp-search-container').toggleClass('has-text', searchTerm.length > 0);
            
            // Debounce search
            clearTimeout(this.config.debounceTimer);
            this.config.debounceTimer = setTimeout(function() {
                self.config.searchTerm = searchTerm;
                self.renderNotifications();
            }, 300);
        },
        
        /**
         * Mark notification as read
         */
        markAsRead: function(notificationId) {
            var self = this;
            
            $.ajax({
                url: yooadmNotifications.rest_url + 'notifications/' + notificationId + '/read',
                method: 'POST',
                xhrFields: {
                    withCredentials: true  // Send cookies with request
                },
                headers: {
                    'X-WP-Nonce': yooadmNotifications.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Update notification status in local array
                        self.updateNotificationStatus(notificationId, 'read');
                        // Update unread count
                        self.updateUnreadCount(-1);
                        // Re-render to update UI
                        self.renderNotifications();
                        // Reload notifications to get fresh data from server
                        self.loadNotifications();
                        // Broadcast to other tabs
                        self.broadcastMessage('MARK_AS_READ', {
                            notificationId: notificationId,
                            unreadCount: self.config.unreadCount
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error('[yooadm Notifications] Error marking as read:', error);
                    console.error('[yooadm Notifications] XHR status:', xhr.status);
                    console.error('[yooadm Notifications] Response text:', xhr.responseText);
                    
                    // Try AJAX fallback if REST API fails (404 = not found, 403/401 = auth issues)
                    if (xhr.status === 403 || xhr.status === 401 || xhr.status === 404) {
                        // If notificationId is not a number, try to find database ID first
                        if (isNaN(parseInt(notificationId, 10))) {
                            // notificationId is a custom ID (string), need to find database ID
                            self.ensureNotificationsArray();
                            var allNotifications = [];
                            self.config.notifications.forEach(function(n) {
                                if (n.type === 'group' && n.items && n.items.length > 0) {
                                    n.items.forEach(function(item) {
                                        allNotifications.push(item);
                                    });
                                } else {
                                    allNotifications.push(n);
                                }
                            });
                            
                            var foundNotif = allNotifications.find(function(n) {
                                var metaId = null;
                                if (n.meta) {
                                    if (typeof n.meta === 'string') {
                                        try {
                                            var parsed = JSON.parse(n.meta);
                                            metaId = parsed.id || null;
                                        } catch(e) {}
                                    } else if (typeof n.meta === 'object') {
                                        metaId = n.meta.id || null;
                                    }
                                }
                                return (metaId && String(metaId) === String(notificationId)) || 
                                       (n.id && String(n.id) === String(notificationId));
                            });
                            
                            if (foundNotif && foundNotif.id) {
                                notificationId = parseInt(foundNotif.id, 10);
                            }
                        }
                        self.markAsReadAjax(notificationId);
                    }
                }
            });
        },
        
        /**
         * Mark notification as read using AJAX fallback
         */
        markAsReadAjax: function(notificationId) {
            var self = this;
            
            // Ensure notificationId is a number (database ID) for AJAX
            if (isNaN(parseInt(notificationId, 10))) {
                // Try to find database ID from custom ID
                self.ensureNotificationsArray();
                var allNotifications = [];
                self.config.notifications.forEach(function(n) {
                    if (n.type === 'group' && n.items && n.items.length > 0) {
                        n.items.forEach(function(item) {
                            allNotifications.push(item);
                        });
                    } else {
                        allNotifications.push(n);
                    }
                });
                
                var foundNotif = allNotifications.find(function(n) {
                    var metaId = null;
                    if (n.meta) {
                        if (typeof n.meta === 'string') {
                            try {
                                var parsed = JSON.parse(n.meta);
                                metaId = parsed.id || null;
                            } catch(e) {}
                        } else if (typeof n.meta === 'object') {
                            metaId = n.meta.id || null;
                        }
                    }
                    return (metaId && String(metaId) === String(notificationId)) || 
                           (n.id && String(n.id) === String(notificationId));
                });
                
                if (foundNotif && foundNotif.id) {
                    notificationId = parseInt(foundNotif.id, 10);
                } else {
                    console.error('[yooadm Notifications] AJAX fallback: Cannot find database ID for custom ID:', notificationId);
                    return; // Cannot proceed without database ID
                }
            } else {
                notificationId = parseInt(notificationId, 10); // Ensure it's a number
            }
            
            $.ajax({
                url: yooadmNotifications.ajax_url,
                method: 'POST',
                data: {
                    action: 'yooadmin_mark_notification_read',
                    notification_id: notificationId,
                    nonce: yooadmNotifications.ajax_nonce || yooadmNotifications.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Update notification status in local array
                        self.updateNotificationStatus(notificationId, 'read');
                        // Update unread count
                        self.updateUnreadCount(-1);
                        // Re-render to update UI
                        self.renderNotifications();
                        // Reload notifications to get fresh data from server
                        self.loadNotifications();
                        // Broadcast to other tabs
                        self.broadcastMessage('MARK_AS_READ', {
                            notificationId: notificationId,
                            unreadCount: self.config.unreadCount
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error('[yooadm Notifications] AJAX fallback error:', error);
                }
            });
        },
        
        /**
         * Mark all notifications as read
         */
        markAllAsRead: function() {
            var self = this;
            this.ensureNotificationsArray();
            
            // Get all notifications including groups
            var allNotifications = [];
            this.config.notifications.forEach(function(n) {
                if (n.type === 'group' && n.items && n.items.length > 0) {
                    n.items.forEach(function(item) {
                        allNotifications.push(item);
                    });
                } else {
                    allNotifications.push(n);
                }
            });
            
            var unreadIds = allNotifications
                .filter(function(n) { 
                    return (n.status === 'new' || n.status === undefined || !n.status); 
                })
                .map(function(n) { 
                    return parseInt(n.id, 10); 
                })
                .filter(function(id) { 
                    return id && id > 0 && !isNaN(id); 
                });
            
            if (unreadIds.length === 0) {
                self.showToastMessage('No unread notifications to mark as read', 'info');
                return;
            }
            
            // Mark all as read via REST API (more efficient than individual calls)
            $.ajax({
                url: yooadmNotifications.rest_url + 'notifications/mark-all-read',
                method: 'POST',
                xhrFields: {
                    withCredentials: true
                },
                headers: {
                    'X-WP-Nonce': yooadmNotifications.nonce
                },
                contentType: 'application/json',
                data: JSON.stringify({
                    notification_ids: unreadIds
                }),
                success: function(response) {
                    if (response && response.success) {
                        // Update all notifications status in local array
                        unreadIds.forEach(function(id) {
                            self.updateNotificationStatus(id, 'read');
                        });
                        
                        // Update unread count
                        var previousCount = self.config.unreadCount;
                        self.config.unreadCount = Math.max(0, self.config.unreadCount - unreadIds.length);
                        self.updateBadgeCount(previousCount);
                        self.updateHeaderCount();
                        
                        // Re-render to update UI
                        self.renderNotifications();
                        
                        // Reload notifications to get fresh data from server
                        setTimeout(function() {
                            self.loadNotifications();
                        }, 300);
                        
                        // Broadcast to other tabs
                        self.broadcastMessage('MARK_ALL_AS_READ', {
                            unreadCount: self.config.unreadCount,
                            sessionId: self.config.sessionId
                        });
                        
                        // Show success message
                        self.showToastMessage('All notifications marked as read', 'success');
                    } else {
                        console.error('[yooadm Notifications] Mark all as read failed:', response);
                        var errorMsg = (response && response.error) ? response.error : 'Unknown error';
                        self.showToastMessage('Failed to mark all as read: ' + errorMsg, 'error');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('[yooadm Notifications] Error marking all as read:', error);
                    console.error('[yooadm Notifications] XHR status:', xhr.status);
                    console.error('[yooadm Notifications] Response text:', xhr.responseText);
                    
                    // Try to parse error message
                    var errorMsg = 'Failed to mark all as read. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMsg = xhr.responseJSON.error;
                    } else if (xhr.responseText) {
                        try {
                            var response = JSON.parse(xhr.responseText);
                            if (response.error) {
                                errorMsg = response.error;
                            }
                        } catch(e) {
                            // Keep default error message
                        }
                    }
                    
                    // Fallback: mark individually
                    var markedCount = 0;
                    unreadIds.forEach(function(id) {
                        self.markAsRead(id);
                        markedCount++;
                    });
                    
                    if (markedCount > 0) {
                        setTimeout(function() {
                            self.loadNotifications();
                        }, 500);
                        self.showToastMessage('Marked ' + markedCount + ' notification(s) as read', 'success');
                    } else {
                        self.showToastMessage(errorMsg, 'error');
                    }
                }
            });
        },
        
        /**
         * Archive notification
         */
        archiveNotification: function(notificationId) {
            var self = this;
            
            $.ajax({
                url: yooadmNotifications.rest_url + 'notifications/' + notificationId + '/archive',
                method: 'POST',
                xhrFields: {
                    withCredentials: true
                },
                headers: {
                    'X-WP-Nonce': yooadmNotifications.nonce
                },
                success: function(response) {
                    if (response.success) {
                        self.removeNotification(notificationId);
                        self.updateUnreadCount(-1);
                        self.showToastMessage('Notification archived', 'success');
                        setTimeout(function() { self.loadNotifications(); }, 500);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('[yooadm Notifications] Error archiving notification:', error);
                }
            });
        },
        
        /**
         * Dismiss notification
         */
        dismissNotification: function(notificationId) {
            var self = this;
            var dbId = parseInt(notificationId, 10);
            if (!dbId || isNaN(dbId)) {
                console.error('[yooadm Notifications] Delete requires numeric notification ID');
                return;
            }
            
            /* Use same AJAX delete as Inbox (delete_notification) */
            $.ajax({
                url: yooadmNotifications.ajax_url || (window.ajaxurl || ''),
                method: 'POST',
                data: {
                    action: 'yooadmin_delete_notification',
                    notification_id: dbId,
                    nonce: yooadmNotifications.delete_nonce || yooadmNotifications.ajax_nonce
                },
                success: function(response) {
                    if (response && response.success) {
                        self.removeNotification(notificationId);
                        self.updateUnreadCount(-1);
                        self.showToastMessage(
                            self.getUiString('notification_deleted', 'Notification deleted successfully'),
                            'success'
                        );
                        setTimeout(function() { self.loadNotifications(); }, 500);
                    } else {
                        self.dismissViaRest(notificationId);
                    }
                },
                error: function() {
                    self.dismissViaRest(notificationId);
                }
            });
        },
        
        /* Fallback: dismiss via REST (for collector items not in storage) */
        dismissViaRest: function(notificationId) {
            var self = this;
            var dbId = parseInt(notificationId, 10);
            if (!dbId || isNaN(dbId)) return;
            
            $.ajax({
                url: yooadmNotifications.rest_url + 'notifications/' + dbId + '/dismiss',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ type: 'permanent' }),
                xhrFields: { withCredentials: true },
                headers: { 'X-WP-Nonce': yooadmNotifications.nonce },
                success: function(response) {
                    if (response && response.success) {
                        self.removeNotification(notificationId);
                        self.updateUnreadCount(-1);
                        self.showToastMessage(
                            self.getUiString('notification_deleted', 'Notification deleted successfully'),
                            'success'
                        );
                        setTimeout(function() { self.loadNotifications(); }, 500);
                    }
                }
            });
        },
        
        /**
         * Dismiss notification group
         */
        dismissGroup: function(groupId) {
            var self = this;
            
            // For now, we'll dismiss individual items in the group
            this.ensureNotificationsArray();
            var groupNotifications = this.config.notifications.filter(function(n) {
                return n.group_id === groupId;
            });
            
            groupNotifications.forEach(function(notification) {
                if (notification.id) {
                    self.dismissNotification(notification.id);
                }
            });
        },
        
        /**
         * Show snooze options
         */
        showSnoozeOptions: function(notificationId, button) {
            var self = this;
            
            if (!notificationId) {
                console.error('[yooadm Notifications] showSnoozeOptions: notificationId is missing');
                alert('Error: Cannot find notification ID. Please try again.');
                return;
            }
            
            // Remove existing snooze options
            $('.yp-snooze-options').remove();
            
            // Create snooze options inline (next to buttons)
            var snoozeHtml = '<div class="yp-snooze-options">' +
                           '<span class="yp-snooze-header" dir="auto">' + this.escapeHtml(this.getUiString('snooze_for', 'Snooze for:')) + '</span>' +
                           '<div class="yp-snooze-buttons">' +
                           '<button type="button" class="yp-snooze-option" data-duration="15 minutes">' + this.escapeHtml(this.getUiString('snooze_15_min', '15 min')) + '</button>' +
                           '<button type="button" class="yp-snooze-option" data-duration="1 hour">' + this.escapeHtml(this.getUiString('snooze_1_hour', '1 hour')) + '</button>' +
                           '<button type="button" class="yp-snooze-option" data-duration="4 hours">' + this.escapeHtml(this.getUiString('snooze_4_hours', '4 hours')) + '</button>' +
                           '<button type="button" class="yp-snooze-option" data-duration="1 day">' + this.escapeHtml(this.getUiString('snooze_1_day', '1 day')) + '</button>' +
                           '<button type="button" class="yp-snooze-option" data-duration="1 week">' + this.escapeHtml(this.getUiString('snooze_1_week', '1 week')) + '</button>' +
                           '<button type="button" class="yp-snooze-custom-btn">' + this.escapeHtml(this.getUiString('custom', 'Custom')) + '</button>' +
                           '</div></div>';
            
            // Add snooze options to modal footer or notification item (dropdown)
            var container = button.closest('.yp-modal-footer');
            if (!container.length) {
                container = button.closest('.yp-notification-item');
            }
            if (!container.length) {
                container = button.closest('.yp-notifications-dropdown');
            }
            if (!container.length) {
                console.error('[yooadm Notifications] Cannot find container for snooze options');
                return;
            }
            container.append(snoozeHtml);
            
            var snoozeOptions = container.find('.yp-snooze-options').last();
            
            // Store current snoozing ID
            this.config.currentSnoozingId = notificationId;
            
            // Handle quick options
            container.find('.yp-snooze-option').off('click').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var duration = $(this).data('duration');
                self.snoozeNotification(notificationId, duration);
                $('.yp-snooze-options').remove();
            });
            
            // Handle custom button - show popup
            container.find('.yp-snooze-custom-btn').off('click').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                self.showCustomSnoozePopup(notificationId);
            });
            
            // Close on outside click
            setTimeout(function() {
                $(document).one('click', function(e) {
                    if (!$(e.target).closest('.yp-snooze-options, .yp-snooze-btn, .yp-modal-snooze-btn').length) {
                        $('.yp-snooze-options').remove();
                    }
                });
            }, 100);
        },
        
        /**
         * Show custom snooze popup
         */
        showCustomSnoozePopup: function(notificationId) {
            var self = this;
            
            // Remove existing custom popup
            $('.yp-snooze-custom-popup').remove();
            
            // Create popup overlay
            var popupHtml = '<div class="yp-snooze-custom-popup-overlay">' +
                          '<div class="yp-snooze-custom-popup" dir="auto">' +
                          '<div class="yp-snooze-custom-popup-header">' +
                          '<h3>' + this.escapeHtml(this.getUiString('custom_snooze', 'Custom Snooze')) + '</h3>' +
                          '<button type="button" class="yp-snooze-custom-popup-close" aria-label="' + this.escapeHtml(this.getUiString('cancel', 'Cancel')) + '">' +
                          '<span class="dashicons dashicons-no-alt"></span>' +
                          '</button>' +
                          '</div>' +
                          '<div class="yp-snooze-custom-popup-body">' +
                          '<label>' + this.escapeHtml(this.getUiString('select_date_time_label', 'Select date and time:')) + '</label>' +
                          '<input type="datetime-local" class="yp-snooze-custom-time-input" min="' + new Date().toISOString().slice(0, 16) + '">' +
                          '</div>' +
                          '<div class="yp-snooze-custom-popup-footer">' +
                          '<button type="button" class="yp-snooze-custom-popup-cancel yp-yoo-btn">' + this.escapeHtml(this.getUiString('cancel', 'Cancel')) + '</button>' +
                          '<button type="button" class="yp-snooze-custom-popup-confirm yp-yoo-btn yp-yoo-btn--primary">' + this.escapeHtml(this.getUiString('confirm', 'Confirm')) + '</button>' +
                          '</div>' +
                          '</div>' +
                          '</div>';
            
            $('body').append(popupHtml);
            
            // Keep above #yp-notification-modal (portaled at z-index 1000100)
            var overlay = $('.yp-snooze-custom-popup-overlay').last();
            overlay.css('z-index', 1000200);
            
            var popup = overlay.find('.yp-snooze-custom-popup');
            
            // Close handlers
            overlay.find('.yp-snooze-custom-popup-close, .yp-snooze-custom-popup-cancel').off('click').on('click', function() {
                overlay.remove();
            });
            
            overlay.off('click').on('click', function(e) {
                if (e.target === overlay[0]) {
                    overlay.remove();
                }
            });
            
            // Confirm handler
            popup.find('.yp-snooze-custom-popup-confirm').off('click').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var customTime = popup.find('.yp-snooze-custom-time-input').val();
                if (customTime) {
                    var customDate = new Date(customTime);
                    var now = new Date();
                    if (customDate > now) {
                        self.snoozeNotification(notificationId, customDate.toISOString());
                        overlay.remove();
                        $('.yp-snooze-options').remove();
                    } else {
                        alert(self.getUiString('select_future_time', 'Please select a future time'));
                    }
                } else {
                    alert(self.getUiString('select_date_time', 'Please select a date and time'));
                }
            });
            
            // Focus on input
            setTimeout(function() {
                popup.find('.yp-snooze-custom-time-input').focus();
            }, 100);
        },
        
        /**
         * Hide snooze options
         */
        hideSnoozeOptions: function() {
            $('.yp-snooze-options').remove();
            this.config.currentSnoozingId = null;
        },
        
        /**
         * Snooze notification
         */
        snoozeNotification: function(notificationId, duration) {
            var self = this;
            
            // CRITICAL: notificationId MUST be database ID (integer), not meta.id (string)
            // Validate and convert to integer
            if (!notificationId || isNaN(parseInt(notificationId, 10)) || !isFinite(notificationId)) {
                console.error('[yooadm Notifications] Invalid notification ID (must be database ID):', notificationId);
                alert('Error: Invalid notification ID. Please try again.');
                return;
            }
            
            var dbId = parseInt(notificationId, 10);
            
            if (dbId <= 0) {
                console.error('[yooadm Notifications] Invalid notification ID (must be positive):', dbId);
                alert('Error: Invalid notification ID. Please try again.');
                return;
            }
            
            // Convert duration string to ISO datetime if needed
            var snoozeUntil = duration;
            if (typeof duration === 'string' && !duration.includes('T') && !duration.includes('Z')) {
                // It's a relative duration like "15 minutes" or "1 hour"
                var now = new Date();
                var durationMatch = duration.match(/(\d+)\s*(minute|hour|day|week)s?/i);
                if (durationMatch) {
                    var amount = parseInt(durationMatch[1]);
                    var unit = durationMatch[2].toLowerCase();
                    if (unit === 'minute' || unit === 'minutes') {
                        now.setMinutes(now.getMinutes() + amount);
                    } else if (unit === 'hour' || unit === 'hours') {
                        now.setHours(now.getHours() + amount);
                    } else if (unit === 'day' || unit === 'days') {
                        now.setDate(now.getDate() + amount);
                    } else if (unit === 'week' || unit === 'weeks') {
                        now.setDate(now.getDate() + (amount * 7));
                    }
                    snoozeUntil = now.toISOString();
                }
            }
            
            $.ajax({
                url: yooadmNotifications.rest_url + 'notifications/' + dbId + '/dismiss',
                method: 'POST',
                xhrFields: {
                    withCredentials: true
                },
                headers: {
                    'X-WP-Nonce': yooadmNotifications.nonce
                },
                contentType: 'application/json',
                data: JSON.stringify({
                    type: 'snooze',
                    snooze_until: snoozeUntil
                }),
                success: function(response) {
                    if (response && response.success) {
                        // Close snooze options
                        $('.yp-snooze-options').remove();
                        // Close modal
                        self.closeNotificationModal();
                        
                        // Remove from local list immediately (for instant UI feedback)
                        self.removeNotification(notificationId);
                        
                        // Update count
                        self.updateUnreadCount(-1);
                        
                        // Reload notifications from server to ensure consistency
                        // This ensures the notification is properly filtered by the backend
                        setTimeout(function() {
                            self.loadNotifications();
                        }, 300);
                        
                        // Show success notification (toast-style)
                        self.showToastMessage(self.buildSnoozedMessage(duration), 'success');
                    } else {
                        var errorMsg = (response && response.error) ? response.error : 'Unknown error';
                        console.error('[yooadm Notifications] Snooze failed:', errorMsg);
                        alert(self.formatUiTemplate('failed_snooze', 'Failed to snooze notification: %s', [errorMsg]));
                    }
                },
                error: function(xhr, status, error) {
                    console.error('[yooadm Notifications] Error snoozing notification:', error);
                    console.error('[yooadm Notifications] XHR status:', xhr.status);
                    console.error('[yooadm Notifications] Response text:', xhr.responseText);
                    
                    var errorMsg = self.getUiString('failed_snooze_retry', 'Failed to snooze notification. Please try again.');
                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMsg = xhr.responseJSON.error;
                    } else if (xhr.responseText) {
                        try {
                            var response = JSON.parse(xhr.responseText);
                            if (response.error) {
                                errorMsg = response.error;
                            }
                        } catch(e) {
                            // Keep default error message
                        }
                    }
                    alert(errorMsg);
                }
            });
        },
        
        /**
         * Show toast message (success/error/info)
         */
        showToastMessage: function(message, type) {
            type = type || 'info';
            
            // Remove existing toast
            $('.yp-toast-message').remove();
            
            // Create toast element
            var toast = $('<div class="yp-toast-message yp-toast-' + type + '">' + 
                         '<span class="yp-toast-icon">' + 
                         (type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ') + 
                         '</span>' + 
                         '<span class="yp-toast-text">' + this.escapeHtml(message) + '</span>' + 
                         '</div>');
            
            // Add to body
            $('body').append(toast);
            
            // Show with animation
            setTimeout(function() {
                toast.addClass('yp-toast-show');
            }, 10);
            
            // Auto-remove after 3 seconds
            setTimeout(function() {
                toast.removeClass('yp-toast-show');
                setTimeout(function() {
                    toast.remove();
                }, 300);
            }, 3000);
        },
        
        /**
         * Toggle settings panel
         */
        toggleSettings: function() {
            if ($('.yp-settings-panel').length > 0) {
                this.hideSettings();
            } else {
                this.showSettings();
            }
        },
        
        /**
         * Show settings panel
         */
        showSettings: function() {
            var settingsHtml = '<div class="yp-settings-panel">' +
                              '<h3>Notification Settings</h3>' +
                              '<div class="yp-settings-section">' +
                              '<h4>Priority Filters</h4>' +
                              '<div class="yp-setting-item">' +
                              '<label>' +
                              '<input type="checkbox" name="hidden_priorities[]" value="low"> Hide Low Priority' +
                              '</label>' +
                              '</div>' +
                              '<div class="yp-setting-item">' +
                              '<label>' +
                              '<input type="checkbox" name="hidden_priorities[]" value="medium"> Hide Medium Priority' +
                              '</label>' +
                              '</div>' +
                              '</div>' +
                              '<div class="yp-settings-section">' +
                              '<h4>Display Options</h4>' +
                              '<div class="yp-setting-item">' +
                              '<label>' +
                              '<input type="checkbox" name="auto_dismiss_low" value="1"> Auto-dismiss Low Priority' +
                              '</label>' +
                              '</div>' +
                              '<div class="yp-setting-item">' +
                              '<label>' +
                              '<input type="checkbox" name="group_similar" value="1" checked> Group Similar Notifications' +
                              '</label>' +
                              '</div>' +
                              '<div class="yp-setting-item">' +
                              '<label>' +
                              '<input type="checkbox" name="show_count_badge" value="1" checked> Show Count Badge' +
                              '</label>' +
                              '</div>' +
                              '</div>' +
                              '<div class="yp-settings-actions">' +
                              '<button class="yp-save-settings">Save Settings</button>' +
                              '<button class="yp-reset-settings">Reset to Default</button>' +
                              '</div>' +
                              '</div>';
            
            // Remove existing settings panel
            $('.yp-settings-panel').remove();
            
            // Add new settings panel
            $('.yp-settings-btn').after(settingsHtml);
            
            // Load current settings
            this.loadSettings();
        },
        
        /**
         * Hide settings panel
         */
        hideSettings: function() {
            $('.yp-settings-panel').remove();
        },
        
        /**
         * Load settings
         */
        loadSettings: function() {
            // This would load user preferences from the server
            // For now, we'll use defaults
        },
        
        /**
         * Save settings
         */
        saveSettings: function() {
            var settings = {};
            
            // Collect settings from form
            $('.yp-setting-item input:checked').each(function() {
                var name = $(this).attr('name');
                var value = $(this).val();
                
                if (name.includes('[]')) {
                    name = name.replace('[]', '');
                    if (!settings[name]) settings[name] = [];
                    settings[name].push(value);
                } else {
                    settings[name] = value;
                }
            });
            
            // Save to server
            $.ajax({
                url: yooadmNotifications.ajax_url,
                method: 'POST',
                data: {
                    action: 'yooadmin_save_notification_settings',
                    settings: settings,
                    nonce: yooadmNotifications.ajax_nonce || yooadmNotifications.nonce
                },
                success: function(response) {
                },
                error: function(xhr, status, error) {
                    console.error('[yooadm Notifications] Error saving settings:', error);
                }
            });
            
            this.hideSettings();
        },
        
        /**
         * Reset settings
         */
        resetSettings: function() {
            $('.yp-setting-item input').prop('checked', false);
            $('.yp-setting-item input[name="group_similar"], .yp-setting-item input[name="show_count_badge"]').prop('checked', true);
            
            this.saveSettings();
        },
        
        /**
         * Update notification status
         */
        updateNotificationStatus: function(notificationId, status) {
            this.ensureNotificationsArray();
            
            // Search in all notifications (including expanded groups)
            var allNotifications = [];
            this.config.notifications.forEach(function(n) {
                if (n.type === 'group' && n.items && n.items.length > 0) {
                    n.items.forEach(function(item) {
                        allNotifications.push({notification: item, parent: n});
                    });
                } else {
                    allNotifications.push({notification: n, parent: null});
                }
            });
            
            // Find notification by database ID (most reliable)
            var found = allNotifications.find(function(item) {
                var n = item.notification;
                return n.id == notificationId || String(n.id) === String(notificationId);
            });
            
            if (found) {
                found.notification.status = status;
                // If it was in a group, update the parent group status too
                if (found.parent) {
                    // Check if all items in group are read
                    var allRead = found.parent.items.every(function(item) {
                        return item.status === 'read';
                    });
                    if (allRead) {
                        found.parent.status = 'read';
                    }
                }
                // Re-render to update UI
                this.renderNotifications();
            }
        },
        
        /**
         * Remove notification
         */
        removeNotification: function(notificationId) {
            var self = this;
            var idStr = String(notificationId);
            var notificationElement = $('.yp-notification-item[data-id="' + idStr + '"], .yp-notification-item[data-db-id="' + idStr + '"]').first();
            
            if (notificationElement.length > 0) {
                notificationElement.addClass('yp-removing');
                
                setTimeout(function() {
                    notificationElement.remove();
                    
                    // Remove from data
                    self.ensureNotificationsArray();
                    self.config.notifications = self.config.notifications.filter(function(n) {
                        if (n.type === 'group' && n.items && n.items.length > 0) {
                            n.items = n.items.filter(function(item) { return item.id != notificationId; });
                            return n.items.length > 0;
                        }
                        return n.id != notificationId;
                    });
                    
                    // Re-render
                    self.renderNotifications();
                }, 400);
            }
        },
        
        /**
         * Update unread count
         */
        updateUnreadCount: function(change) {
            var previousCount = this.config.unreadCount;
            this.config.unreadCount = Math.max(0, this.config.unreadCount + change);
            
            if (this.shouldPlayNotificationSound(this.config.unreadCount, previousCount)) {
                this.playNotificationSound();
                this.setUnreadBaseline(this.config.unreadCount);
            }
            
            this.updateBadgeCount(previousCount);
            this.updateHeaderCount();
        },
        
        /**
         * Update badge count
         * @param {number} previousCount - Optional previous count (if not provided, will read from badge attribute)
         */
        updateBadgeCount: function(previousCount) {
            var self = this;
            // Use provided previousCount, or read from badge attribute
            if (typeof previousCount === 'undefined' || previousCount === null) {
                previousCount = parseInt($('.yp-notification-count, .notification-count').attr('data-count') || '0', 10);
            }
            var currentCount = this.config.unreadCount;
            
            // If convert_banners is disabled, exclude banner notifications from count
            if (typeof yooadmNotifications !== 'undefined' && yooadmNotifications.convert_banners_enabled === false) {
                // Recalculate count excluding banners
                this.ensureNotificationsArray();
                var expanded = [];
                this.config.notifications.forEach(function(notification) {
                    if (notification.type === 'group' && notification.items && notification.items.length > 0) {
                        notification.items.forEach(function(item) {
                            expanded.push(item);
                        });
                    } else {
                        expanded.push(notification);
                    }
                });
                
                // Filter out banners and count only unread non-banner notifications
                currentCount = expanded.filter(function(n) {
                    var sourceType = n.source_type || '';
                    return n.status === 'new' && 
                           sourceType !== 'banner' && 
                           sourceType !== 'banner-conversion' && 
                           sourceType !== 'wp_admin_banner';
                }).length;
            }
            
            // Check if show_count_badge is enabled
            var showBadge = true; // Default
            if (typeof yooadmNotifications !== 'undefined' && typeof yooadmNotifications.show_count_badge !== 'undefined') {
                showBadge = yooadmNotifications.show_count_badge;
            }
            
            // Update both .yp-notification-count and .notification-count (for compatibility)
            var badge = $('.yp-notification-count, .notification-count');
            badge.attr('data-count', currentCount);
            
            // Only show badge if enabled and count > 0
            if (showBadge && currentCount > 0) {
                var displayCount = currentCount > 99 ? '99+' : currentCount;
                badge.text(displayCount);
                badge.show();
            } else {
                badge.hide();
            }
            
            if (this.shouldPlayNotificationSound(currentCount, previousCount)) {
                this.playNotificationSound();
                this.setUnreadBaseline(currentCount);
            }
        },
        
        /**
         * Play notification sound (like old system)
         */
        playNotificationSound: function() {
            // Check if sound is enabled in settings (default: enabled)
            if (typeof yooadmNotifications !== 'undefined' && yooadmNotifications.notification_sound_enabled === false) {
                return;
            }
            
            // Skip sound on initial load / grace window
            if (this.isSoundGraceActive()) {
                return;
            }
            
            try {
                var audioContext = this.getAudioContext();
                if (!audioContext) {
                    return;
                }
                
                var self = this;
                var finishPlay = function() {
                    try {
                        self.audioState.unlocked = true;
                        self.audioState.pendingPlay = false;
                        self.runNotificationSound(audioContext);
                    } catch (e) {
                        console.error('[yooadm Notifications] Error playing sound:', e);
                    }
                };
                
                // Always try to resume first (browsers require user interaction)
                if (audioContext.state === 'suspended' || audioContext.state !== 'running') {
                    audioContext.resume().then(function() {
                        if (audioContext.state === 'running') {
                            finishPlay();
                        } else {
                            self.audioState.pendingPlay = true;
                        }
                    }).catch(function(err) {
                        console.error('[yooadm Notifications] Failed to resume audio context:', err);
                        self.audioState.pendingPlay = true;
                    });
                } else {
                    // Already running, play immediately
                    finishPlay();
                }
            } catch (e) {
                console.error('[yooadm Notifications] Error in playNotificationSound:', e);
            }
        },
        
        /**
         * Get audio context
         */
        getAudioContext: function() {
            if (!this.audioState) {
                this.audioState = {
                    context: null,
                    unlocked: false,
                    pendingPlay: false
                };
            }
            
            if (!this.audioState.context) {
                try {
                    this.audioState.context = new (window.AudioContext || window.webkitAudioContext)();
                } catch (e) {
                    this.audioState.context = null;
                }
            }
            return this.audioState.context;
        },
        
        /**
         * Run notification sound (like old system)
         */
        runNotificationSound: function(audioContext) {
            var oscillator = audioContext.createOscillator();
            var gainNode = audioContext.createGain();
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            var startTime = audioContext.currentTime;
            oscillator.frequency.value = 800;
            gainNode.gain.setValueAtTime(0.3, startTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + 0.1);
            oscillator.start(startTime);
            oscillator.stop(startTime + 0.1);
            
            var self = this;
            setTimeout(function() {
                var ctx = self.getAudioContext();
                if (!ctx) return;
                var osc2 = ctx.createOscillator();
                var gain2 = ctx.createGain();
                osc2.connect(gain2);
                gain2.connect(ctx.destination);
                var t = ctx.currentTime;
                osc2.frequency.value = 1000;
                gain2.gain.setValueAtTime(0.2, t);
                gain2.gain.exponentialRampToValueAtTime(0.01, t + 0.1);
                osc2.start(t);
                osc2.stop(t + 0.1);
            }, 100);
        },
        
        /**
         * Setup audio unlock (like old system)
         */
        setupAudioUnlock: function() {
            var self = this;
            var unlockAudio = function() {
                var ctx = self.getAudioContext();
                if (ctx) {
                    ctx.resume().then(function() {
                        self.audioState.unlocked = true;
                        if (self.audioState.pendingPlay) {
                            self.audioState.pendingPlay = false;
                            if (!self.isSoundGraceActive()) {
                                self.runNotificationSound(ctx);
                            }
                        }
                    }).catch(function() {});
                }
                document.removeEventListener('pointerdown', unlockAudio);
                document.removeEventListener('keydown', unlockAudio);
            };
            
            document.addEventListener('pointerdown', unlockAudio, { once: true });
            document.addEventListener('keydown', unlockAudio, { once: true });
        },
        
        /**
         * Update header count
         */
        updateHeaderCount: function() {
            $('.yp-unread-count').attr('data-count', this.config.unreadCount);
            
            if (this.config.unreadCount > 0) {
                $('.yp-unread-count').text(this.config.unreadCount);
            } else {
                $('.yp-unread-count').text('');
            }
        },
        
        /**
         * Update counts
         */
        updateCounts: function() {
            var self = this;
            
            // Ensure notifications is an array
            var notifications = this.config.notifications;
            if (!Array.isArray(notifications)) {
                notifications = [];
                this.config.notifications = notifications;
            }
            
            // Expand groups to individual items for counting
            var expanded = [];
            notifications.forEach(function(notification) {
                if (notification.type === 'group' && notification.items && notification.items.length > 0) {
                    notification.items.forEach(function(item) {
                        expanded.push(item);
                    });
                } else {
                    expanded.push(notification);
                }
            });
            
            // Filter out banner notifications if convert_banners is disabled
            var filteredExpanded = expanded;
            if (typeof yooadmNotifications !== 'undefined' && yooadmNotifications.convert_banners_enabled === false) {
                filteredExpanded = expanded.filter(function(n) {
                    var sourceType = n.source_type || '';
                    return sourceType !== 'banner' && sourceType !== 'banner-conversion' && sourceType !== 'wp_admin_banner';
                });
            }
            
            // Count by type (ALL | plugins | Theme | Extensions | Banners)
            var counts = {
                all: filteredExpanded.length,
                plugins: 0,
                theme: 0,
                extensions: 0,
                banners: 0
            };
            
            filteredExpanded.forEach(function(n) {
                // Use real source_type from notification (not custom types)
                var sourceType = n.source_type || '';
                
                // Count by real source_type
                if (sourceType === 'plugin_updates') {
                    counts.plugins++;
                } else if (sourceType === 'theme_updates') {
                    counts.theme++;
                } else if (sourceType === 'extensions' || sourceType === 'yooadmin_extensions') {
                    counts.extensions++;
                } else if (sourceType === 'banner' || sourceType === 'banner-conversion' || sourceType === 'wp_admin_banner') {
                    counts.banners++;
                }
            });
            
            // FIXED: Create tabs dynamically based on actual notification data (not static)
            var $tabsContainer = $('.yp-filter-tabs');
            var visibleTabs = [];
            
            // Define available filter types with labels
            var filterTypes = {
                'all': self.getTabLabel('all'),
                'plugins': self.getTabLabel('plugins'),
                'theme': self.getTabLabel('theme'),
                'extensions': self.getTabLabel('extensions'),
                'banners': self.getTabLabel('banners'),
                'license': self.getTabLabel('license'),
                'comments': self.getTabLabel('comments')
            };
            
            // Remove all tabs except "all" (we'll recreate them dynamically)
            $tabsContainer.find('.yp-filter-tab[data-filter!="all"]').remove();
            
            // FIXED: Create tabs dynamically based on counts - only show tabs with count > 0 (except "all")
            for (var filter in filterTypes) {
                if (filter === 'all') {
                    // "All" tab already exists, just update it
                    var $allTab = $tabsContainer.find('.yp-filter-tab[data-filter="all"]');
                    if ($allTab.length) {
                var count = counts[filter] || 0;
                        $allTab.contents().filter(function() {
                            return this.nodeType === 3;
                        }).first().replaceWith(filterTypes.all + ' ');
                        var $countEl = $allTab.find('.yp-tab-count');
                        if ($countEl.length) {
                            $countEl.text(count);
                        } else {
                            $allTab.append(' <span class="yp-tab-count">' + count + '</span>');
                        }
                        visibleTabs.push({filter: filter, count: count, element: $allTab});
                    }
                } else {
                    // FIXED: Only create tab if it has notifications (count > 0)
                    var count = counts[filter] || 0;
                    
                    // Only show tabs with actual notifications
                    if (count > 0) {
                        var $tab = $('<button class="yp-filter-tab" data-filter="' + filter + '">' + 
                                    filterTypes[filter] + ' <span class="yp-tab-count">' + count + '</span></button>');
                        $tabsContainer.append($tab);
                        visibleTabs.push({filter: filter, count: count, element: $tab});
                    }
                }
            }
            
            // Re-cache filter tabs after dynamic creation
            this.config.filterTabs = $('.yp-filter-tab');
            
            // Smart tabs display: show max 3 tabs + "more" button if needed
            this.updateTabsDisplay(visibleTabs);
            
            // Update unread count (for badge) - count only notifications with status 'new'
            // BUT: Don't update from local array - use database count from refreshBadgeCount
            // This ensures accuracy even if local array is out of sync
            // IMPORTANT: Only count 'new' status, not null/undefined (null means read in database)
            // Also exclude banners if convert_banners is disabled
            var localUnreadCount = filteredExpanded.filter(function(n) { 
                // Only count as unread if status is explicitly 'new'
                // null/undefined/'' means read in database, so don't count them
                return n.status === 'new'; 
            }).length;
            
            // Only update if we don't have a database count yet (initial load)
            // Otherwise, refreshBadgeCount will update it from database
            if (this.config.unreadCount === 0 && localUnreadCount > 0) {
                this.config.unreadCount = localUnreadCount;
            this.updateUnreadCount(0);
            }
        },
        
        /**
         * Update tabs display - show all tabs in full width (no more button)
         */
        updateTabsDisplay: function(visibleTabs) {
            var $moreButton = $('.yp-filter-tabs').find('.yp-filter-tabs-more');
            $moreButton.remove();
            visibleTabs.forEach(function(tab) {
                tab.element.show().removeClass('yp-tab-hidden yp-tab-visible');
            });
        },
        
        /**
         * Toggle hidden tabs visibility
         * FIXED: Properly toggle between shown and hidden tabs without scroll
         */
        toggleHiddenTabs: function() {
            var $tabsContainer = $('.yp-filter-tabs');
            var $hiddenTabs = $('.yp-filter-tab.yp-tab-hidden');
            var $shownTabs = $('.yp-filter-tab:not(.yp-tab-hidden)');
            var $moreButton = $('.yp-filter-tabs-more');
            
            if ($hiddenTabs.length === 0) {
                return; // No hidden tabs to show
            }
            
            if ($hiddenTabs.is(':visible')) {
                // Currently showing hidden tabs - switch back to shown tabs
                $hiddenTabs.hide().removeClass('yp-tab-visible');
                $shownTabs.show();
                if ($moreButton.length) {
                    $moreButton.text('...');
                    $moreButton.attr('title', 'Show more tabs');
                }
            } else {
                // Currently showing shown tabs - switch to hidden tabs
                $shownTabs.hide();
                $hiddenTabs.show().addClass('yp-tab-visible');
                if ($moreButton.length) {
                    $moreButton.text('...');
                    $moreButton.attr('title', 'Show less tabs');
                }
            }
        },
        
        /**
         * Start time updater (updates every minute)
         */
        startTimeUpdater: function() {
            var self = this;
            
            // Update time displays every minute
            setInterval(function() {
                self.updateTimeDisplays();
            }, 60000); // 60 seconds
        },
        
        /**
         * Update time displays
         */
        updateTimeDisplays: function() {
            var self = this;
            
            $('.yp-notification-time').each(function() {
                var time = $(this).data('time');
                if (time) {
                    $(this).text(self.formatTime(time));
                }
            });
        },
        
        /**
         * Plus/Extended: replace Lite "Hide 30 days" modal label with Snooze when localized.
         */
        syncModalSnoozeButton: function() {
            var label = this.getUiString('modal_snooze_label', '');
            if (!label) {
                return;
            }
            var title = this.getUiString('modal_snooze_title', label);
            var modal = $('#yp-notification-modal');
            if (!modal.length) {
                return;
            }
            modal.find('.yp-modal-snooze-btn').each(function() {
                var $btn = $(this);
                $btn.attr('title', title).attr('aria-label', label);
                $btn.find('.yp-snooze-text').text(label);
            });
        },

        formatTimeAgo: function(count, singularKey, pluralKey, singularFallback, pluralFallback) {
            var key = count === 1 ? singularKey : pluralKey;
            var fallback = count === 1 ? singularFallback : pluralFallback;
            var template = this.getUiString(key, fallback);
            return template.replace('%d', String(count));
        },

        formatUiTemplate: function(key, fallback, values) {
            var template = this.getUiString(key, fallback);
            if (!values || !values.length) {
                return template;
            }
            var index = 0;
            return template.replace(/%s/g, function() {
                var value = values[index];
                index += 1;
                return value !== undefined && value !== null ? String(value) : '';
            });
        },

        formatSnoozeDate: function(date) {
            var locale = '';
            if (typeof yooadmNotifications !== 'undefined' && yooadmNotifications.admin_ui_locale) {
                locale = String(yooadmNotifications.admin_ui_locale).replace('_', '-');
            }
            try {
                return date.toLocaleString(locale || undefined, {
                    year: 'numeric',
                    month: 'numeric',
                    day: 'numeric',
                    hour: 'numeric',
                    minute: '2-digit'
                });
            } catch (e) {
                return date.toLocaleString();
            }
        },

        getSnoozeDurationLabel: function(duration) {
            var map = {
                '15 minutes': this.getUiString('snooze_15_min', '15 min'),
                '1 hour': this.getUiString('snooze_1_hour', '1 hour'),
                '4 hours': this.getUiString('snooze_4_hours', '4 hours'),
                '1 day': this.getUiString('snooze_1_day', '1 day'),
                '1 week': this.getUiString('snooze_1_week', '1 week')
            };
            return map[duration] || duration;
        },

        buildSnoozedMessage: function(duration) {
            var suffix = '';
            if (typeof duration === 'string') {
                if (duration.includes('T') || duration.includes('Z')) {
                    suffix = this.formatUiTemplate(
                        'snoozed_until',
                        ' until %s',
                        [this.formatSnoozeDate(new Date(duration))]
                    );
                } else {
                    suffix = this.formatUiTemplate(
                        'snoozed_for',
                        ' for %s',
                        [this.getSnoozeDurationLabel(duration)]
                    );
                }
            }
            return this.formatUiTemplate(
                'notification_snoozed',
                'Notification snoozed%s. It will reappear when the time expires.',
                [suffix]
            );
        },

        /**
         * Format time display
         */
        formatTime: function(datetime) {
            if (!datetime) return '';

            var self = this;
            
            // Convert MySQL datetime (YYYY-MM-DD HH:MM:SS) to proper format
            // Replace space with 'T' for ISO 8601 compatibility
            var isoDatetime = datetime.replace(' ', 'T');
            var timestamp = new Date(isoDatetime).getTime();
            
            // Check if timestamp is valid
            if (isNaN(timestamp)) {
                return '';
            }
            
            var now = Date.now();
            var diff = now - timestamp;
            
            // Handle negative diff (future dates - shouldn't happen but safety check)
            if (diff < 0) {
                return self.getUiString('justNow', 'Just now');
            }
            
            if (diff < 60000) {
                return self.getUiString('justNow', 'Just now');
            } else if (diff < 3600000) {
                var mins = Math.floor(diff / 60000);
                return self.formatTimeAgo(mins, 'timeMinuteAgo', 'timeMinutesAgo', '%d min ago', '%d mins ago');
            } else if (diff < 86400000) {
                var hours = Math.floor(diff / 3600000);
                return self.formatTimeAgo(hours, 'timeHourAgo', 'timeHoursAgo', '%d hour ago', '%d hours ago');
            } else if (diff < 604800000) {
                var days = Math.floor(diff / 86400000);
                return self.formatTimeAgo(days, 'timeDayAgo', 'timeDaysAgo', '%d day ago', '%d days ago');
            } else {
                return new Date(timestamp).toLocaleDateString();
            }
        },
        
        /**
         * Show loading state
         * FIXED: Only show loading if dropdown is actually open and visible
         */
        showLoading: function() {
            // FIXED: Only show loading message if dropdown is open
            // If dropdown is closed, don't show loading (prevents "Loading notifications..." from appearing during auto-refresh)
            if (!this.config.dropdown || !this.config.dropdown.hasClass('show')) {
                return; // Don't show loading if dropdown is closed
            }
            
            if (this.config.list.length === 0) {
                return;
            }
            
            this.config.list.html('<div class="yp-loading-spinner">' +
                                '<div class="yp-spinner-circle"></div>' +
                                '<span class="yp-loading-text">' + this.escapeHtml(this.getUiString('loading', 'Loading...')) + '</span>' +
                                '</div>');
        },
        
        /**
         * Show error state
         */
        showError: function(isMaintenanceMode) {
            var title = isMaintenanceMode ? 'Maintenance Mode Active' : 'Error Loading Notifications';
            var message = isMaintenanceMode 
                ? 'The website is currently under maintenance. Notifications will be available once maintenance is complete.'
                : 'Please try again later.';
            var icon = isMaintenanceMode ? 'dashicons-admin-tools' : 'dashicons-warning';
            
            this.config.list.html('<div class="yp-empty-state">' +
                                '<div class="yp-empty-icon">' +
                                '<i class="dashicons ' + icon + '"></i>' +
                                '</div>' +
                                '<h3 class="yp-empty-title">' + title + '</h3>' +
                                '<p class="yp-empty-message">' + message + '</p>' +
                                '</div>');
        },
        
        /**
         * Start auto refresh
         */
        startAutoRefresh: function() {
            var self = this;
            
            // Periodic sync: badge always; full list only when dropdown is closed (see checkForUpdates).
            this.config.autoRefreshInterval = setInterval(function() {
                self.refreshBadgeCount();
                self.checkForUpdates();
            }, this.config.refreshInterval);
        },
        
        /**
         * Refresh badge count only (lightweight check)
         */
        refreshBadgeCount: function() {
            var self = this;
            
            // Skip if maintenance mode was detected
            if (this.config.maintenanceModeDetected) {
                return;
            }
            
            // Use REST API feed endpoint to get unread count from database
            $.ajax({
                url: yooadmNotifications.rest_url + 'notifications/feed',
                method: 'GET',
                xhrFields: {
                    withCredentials: true
                },
                headers: {
                    'X-WP-Nonce': yooadmNotifications.nonce
                },
                success: function(response) {
                    // Response can be WP_REST_Response object or plain object
                    var data = response.data || response;
                    var unreadCount = 0;
                    
                    if (data && typeof data.unread_count !== 'undefined') {
                        unreadCount = parseInt(data.unread_count) || 0;
                    } else if (data && typeof data.count !== 'undefined') {
                        // Fallback to total count if unread_count not available
                        unreadCount = parseInt(data.count) || 0;
                    }
                    
                    if (unreadCount !== self.config.unreadCount) {
                        var previousCount = self.config.unreadCount;
                        self.config.unreadCount = unreadCount;
                        self.updateBadgeCount(previousCount);
                        self.updateHeaderCount();
                        
                        // Broadcast badge update to other tabs
                        self.broadcastMessage('BADGE_UPDATE', {
                            unreadCount: unreadCount
                        });
                        
                        // New unread: refresh list; silent when dropdown is open (no full-page spinner).
                        if (unreadCount > previousCount) {
                            var dropdownOpen = self.config.dropdown && self.config.dropdown.hasClass('show');
                            self.loadNotifications(false, { silent: dropdownOpen });
                        }
                    }
                },
                error: function(xhr, status, error) {
                    // Check if response is HTML (maintenance mode)
                    var responseText = xhr.responseText || '';
                    var trimmedText = responseText.trim();
                    var isHtmlResponse = trimmedText.startsWith('<!DOCTYPE') || 
                                        trimmedText.startsWith('<!doctype') ||
                                        trimmedText.startsWith('<html') ||
                                        trimmedText.startsWith('<HTML') ||
                                        (trimmedText.toLowerCase().includes('maintenance') && xhr.status === 503) ||
                                        (xhr.status === 503 && trimmedText.length > 100); // 503 with content likely means maintenance
                    
                    if (xhr.status === 503 || isHtmlResponse) {
                        // Mark maintenance mode
                        if (!self.config.maintenanceModeDetected) {
                            self.config.maintenanceModeDetected = true;
                            setTimeout(function() {
                                self.config.maintenanceModeDetected = false;
                            }, 30000);
                        }
                        return;
                    }
                    
                    // Try AJAX fallback if REST API fails (only for non-maintenance errors)
                    if (xhr.status === 403 || xhr.status === 401) {
                        self.refreshBadgeCountAjax();
                    }
                }
            });
        },
        
        /**
         * Refresh badge count using AJAX fallback
         */
        refreshBadgeCountAjax: function() {
            var self = this;
            
            // Skip if maintenance mode was detected
            if (this.config.maintenanceModeDetected) {
                return;
            }
            
            $.ajax({
                url: yooadmNotifications.ajax_url,
                method: 'POST',
                data: {
                    action: 'yooadmin_get_notifications',
                    nonce: yooadmNotifications.get_notifications_nonce || yooadmNotifications.ajax_nonce || yooadmNotifications.nonce
                },
                success: function(response) {
                    if (response.success && response.data) {
                        var notifications = response.data.data || response.data || [];
                        // Count unread notifications
                        var unreadCount = notifications.filter(function(n) {
                            return n.status === 'new' || n.status === null || n.status === undefined || n.status === '';
                        }).length;
                        
                        var previousCount = self.config.unreadCount;
                        
                        if (unreadCount !== self.config.unreadCount) {
                            self.config.unreadCount = unreadCount;
                            self.updateBadgeCount(previousCount);
                            self.updateHeaderCount();
                            
                            // Broadcast badge update to other tabs
                            self.broadcastMessage('BADGE_UPDATE', {
                                unreadCount: unreadCount
                            });
                            
                            if (unreadCount > previousCount) {
                                var dropdownOpen = self.config.dropdown && self.config.dropdown.hasClass('show');
                                self.loadNotifications(false, { silent: dropdownOpen });
                            }
                        }
                    }
                },
                error: function() {
                    // Silently fail - don't spam console
                }
            });
        },
        
        /**
         * Stop auto refresh
         */
        stopAutoRefresh: function() {
            if (this.config.autoRefreshInterval) {
                clearInterval(this.config.autoRefreshInterval);
                this.config.autoRefreshInterval = null;
            }
        },
        
        /**
         * Check for updates
         */
        checkForUpdates: function() {
            // Skip if maintenance mode was detected
            if (this.config.maintenanceModeDetected) {
                return;
            }

            // Dropdown open: user may be scrolling / loading more — do not full-reload (no big spinner).
            if (this.config.dropdown && this.config.dropdown.hasClass('show')) {
                return;
            }

            // Background sync when closed so the next open shows fresh data (no visible spinner).
            this.loadNotifications(false, { silent: true });
        },
        
        /**
         * Setup keyboard shortcuts
         */
        setupKeyboardShortcuts: function() {
            // Keyboard shortcuts will be handled in handleKeyboardShortcuts
        },
        
        /**
         * Handle keyboard shortcuts
         */
        handleKeyboardShortcuts: function(e) {
            // Only handle shortcuts when dropdown is open
            if (!this.config.dropdown || this.config.dropdown.length === 0 || !this.config.dropdown.hasClass('active')) return;
            
            switch (e.key) {
                case 'Escape':
                    e.preventDefault();
                    this.closeDropdown();
                    break;
                case '/':
                    e.preventDefault();
                    if (this.config.searchInput && this.config.searchInput.length > 0) {
                        this.config.searchInput.focus();
                    }
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    this.navigateNotifications(1);
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    this.navigateNotifications(-1);
                    break;
                case 'Enter':
                    e.preventDefault();
                    this.activateSelectedNotification();
                    break;
            }
        },
        
        /**
         * Navigate notifications with keyboard
         */
        navigateNotifications: function(direction) {
            var items = $('.yp-notification-item:not(.yp-removing)');
            var currentIndex = items.index($('.yp-notification-item.selected'));
            var newIndex = currentIndex + direction;
            
            if (newIndex >= 0 && newIndex < items.length) {
                items.removeClass('selected');
                $(items[newIndex]).addClass('selected');
                
                // Scroll into view if needed
                var item = $(items[newIndex]);
                var list = this.config.list;
                var itemTop = item.position().top;
                var listScrollTop = list.scrollTop();
                var listHeight = list.height();
                
                if (itemTop < 0) {
                    list.scrollTop(listScrollTop + itemTop);
                } else if (itemTop + item.outerHeight() > listHeight) {
                    list.scrollTop(listScrollTop + itemTop + item.outerHeight() - listHeight);
                }
            }
        },
        
        /**
         * Activate selected notification
         */
        activateSelectedNotification: function() {
            var selected = $('.yp-notification-item.selected');
            if (selected.length > 0) {
                var notificationId = selected.data('id');
                if (notificationId) {
                    this.markAsRead(notificationId);
                }
                
                // Click first action link if available
                var actionLink = selected.find('.yp-action').first();
                if (actionLink.length > 0) {
                    window.location.href = actionLink.attr('href');
                }
            }
        },
        
        /**
         * Escape HTML
         */
        escapeHtml: function(text) {
            var div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        },

        containsArabic: function(text) {
            if (!text) {
                return false;
            }
            return /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(String(text));
        },

        containsLatin: function(text) {
            if (!text) {
                return false;
            }
            return /[A-Za-z]/.test(String(text));
        },

        isMixedDirectionText: function(text) {
            return this.containsArabic(text) && this.containsLatin(text);
        },

        normalizeBannerSourceLabel: function(source) {
            var label = String(source || '').trim();
            if (!label) {
                return '';
            }
            var strings = (window.yooadmNotifications && yooadmNotifications.strings) || {};
            var legacy = {
                'Yooadmin Login Turnstile Incomplete': strings.bannerSourceYooadminLoginSecurity,
                'YOOAdmin login security': strings.bannerSourceYooadminLoginSecurity
            };
            if (legacy[label]) {
                return legacy[label];
            }
            return label;
        },

        truncateNotificationText: function(text, max) {
            var value = String(text || '').trim();
            if (!value || max < 1) {
                return '';
            }
            if (value.length <= max) {
                return value;
            }
            var cut = value.substring(0, max);
            var space = cut.lastIndexOf(' ');
            if (space > Math.floor(max * 0.55)) {
                cut = cut.substring(0, space);
            }
            return cut.replace(/\s+$/, '') + '...';
        },

        getMixedTextDirectionAttrs: function(text) {
            if (!this.containsArabic(text)) {
                return '';
            }
            if (this.isMixedDirectionText(text)) {
                return ' dir="auto"';
            }
            return ' dir="rtl" lang="ar"';
        },

        applyTextDirection: function(element, text) {
            if (!element) {
                return;
            }
            var el = element.jquery ? element[0] : element;
            if (!el) {
                return;
            }
            el.removeAttribute('dir');
            el.removeAttribute('lang');
            if (!this.containsArabic(text)) {
                // Latin-only content stays left-to-right even under an RTL admin
                // UI, so English titles/messages don't get mirrored or misaligned.
                if (this.containsLatin(text)) {
                    el.setAttribute('dir', 'ltr');
                    el.setAttribute('lang', 'en');
                }
                return;
            }
            if (this.isMixedDirectionText(text)) {
                el.setAttribute('dir', 'auto');
                return;
            }
            el.setAttribute('dir', 'rtl');
            el.setAttribute('lang', 'ar');
        },

        applyTextDirectionToDescendants: function(root) {
            if (!root) {
                return;
            }
            var container = root.jquery ? root[0] : root;
            if (!container || !container.querySelectorAll) {
                return;
            }
            var rootDir = container.getAttribute('dir') || '';
            var rtlNotice = container.querySelector('.yoo-plus-license-notice[dir="rtl"]');
            if (rtlNotice) {
                rootDir = 'rtl';
            }
            var nodes = container.querySelectorAll('p, div, span, li');
            for (var i = 0; i < nodes.length; i++) {
                var node = nodes[i];
                if (node.classList && node.classList.contains('yoo-latin-inline')) {
                    node.setAttribute('dir', 'ltr');
                    node.setAttribute('lang', 'en');
                    continue;
                }
                var nodeText = node.textContent || '';
                if (this.isMixedDirectionText(nodeText)) {
                    node.setAttribute('dir', 'auto');
                    node.removeAttribute('lang');
                } else if (this.containsArabic(nodeText)) {
                    node.setAttribute('dir', 'rtl');
                    node.setAttribute('lang', 'ar');
                } else if (rootDir === 'rtl' && node.tagName === 'LI') {
                    node.setAttribute('dir', 'rtl');
                    node.setAttribute('lang', 'ar');
                } else if (rootDir === 'rtl' && node.classList && node.classList.contains('yoo-plus-license-notice')) {
                    node.setAttribute('dir', 'rtl');
                    node.setAttribute('lang', 'ar');
                } else if (this.containsLatin(nodeText)) {
                    // Latin-only text (e.g. an English notification) must read
                    // left-to-right even when the admin UI is RTL; otherwise the
                    // leading emoji, trailing period, and inline bold reorder badly.
                    node.setAttribute('dir', 'ltr');
                    node.setAttribute('lang', 'en');
                } else {
                    node.removeAttribute('dir');
                    node.removeAttribute('lang');
                }
            }
            var emphasis = container.querySelectorAll('strong, b');
            for (var j = 0; j < emphasis.length; j++) {
                var em = emphasis[j];
                var emText = em.textContent || '';
                if (this.containsArabic(emText)) {
                    em.setAttribute('dir', 'rtl');
                    em.setAttribute('lang', 'ar');
                } else {
                    em.removeAttribute('dir');
                    em.removeAttribute('lang');
                }
            }
        },
        
        /**
         * Remove style/script noise that can be captured from converted admin banners.
         */
        cleanNotificationHtml: function(html) {
            if (!html) return '';

            // Strip tags from an anchor/button inner HTML to inspect its label.
            var innerText = function(markup) {
                return String(markup).replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
            };
            // Dismiss/close controls that must NOT appear as bare text or inline links
            // (the notification UI provides its own dismiss/snooze/delete buttons).
            var dismissAttrRe = /(notice-dismiss|is-dismissible|js-dismiss|\bdismiss\b|data-dismiss)/i;
            var dismissTextRe = /^(dismiss|dismiss\s+this\s+notice|hide(\s+this)?(\s+notice)?|close|ignore(\s+this)?(\s+notice)?|no\s+thanks|إخفاء|اخفاء|تجاهل|إغلاق|اغلاق|لا\s+شكرا|لا\s+شكراً)\b/i;

            // Decide whether an <a>/<button> match is a dismiss control.
            var isDismissControl = function(match) {
                var attrPart = (match.match(/^<[^>]*>/) || [''])[0];
                if (dismissAttrRe.test(attrPart)) {
                    return true;
                }
                var label = innerText(match);
                return label.length > 0 && label.length < 30 && dismissTextRe.test(label);
            };

            return String(html)
                .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
                .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
                // Remove dismiss/close controls entirely (markup + label).
                .replace(/<a\b[^>]*>[\s\S]*?<\/a>/gi, function(m) { return isDismissControl(m) ? '' : m; })
                .replace(/<button\b[^>]*>[\s\S]*?<\/button>/gi, function(m) { return isDismissControl(m) ? '' : m; })
                // Real actions are surfaced as footer buttons, so the body must not carry
                // inline links/buttons: unwrap any remaining ones to plain text.
                .replace(/<a\b[^>]*>([\s\S]*?)<\/a>/gi, '$1')
                .replace(/<button\b[^>]*>([\s\S]*?)<\/button>/gi, '$1')
                .replace(/(?:^|\s)(?:[#.][^{]+|[a-z0-9_-]+)\s*\{[^{}]*:[^{}]*\}/gi, ' ')
                .replace(/\s+/g, ' ')
                .trim();
        },

        /**
         * Infer a readable source label for old converted banners that predate component_name.
         */
        inferBannerComponentName: function(bannerId, classes) {
            var haystack = String((bannerId || '') + ' ' + (classes || '')).toLowerCase().replace(/_/g, '-');
            var known = {
                abovewp: 'AboveWP',
                aioseo: 'AIOSEO',
                codevz: 'Codevz',
                elementor: 'Elementor',
                gutenkit: 'Gutenkit',
                malcare: 'MalCare',
                rank: 'Rank Math',
                vc: 'WPBakery Page Builder',
                woocommerce: 'WooCommerce',
                wpb: 'WPBakery Page Builder',
                xtra: 'XTRA Theme',
                'yooadmin-login-turnstile-incomplete': 'YOOAdmin login security'
            };
            var match;
            Object.keys(known).some(function(key) {
                if (haystack.indexOf(key) !== -1) {
                    match = known[key];
                    return true;
                }
                return false;
            });
            if (match) {
                return match;
            }
            match = haystack.match(/\b([a-z0-9][a-z0-9-]+?)-(?:promo-)?(?:admin-)?notice\b/);
            if (!match) {
                match = haystack.match(/\b([a-z0-9][a-z0-9-]+?)-(?:promo|banner|message|alert)\b/);
            }
            if (!match || !match[1]) {
                return '';
            }
            return match[1]
                .split('-')
                .filter(function(part) {
                    return part && ['admin', 'banner', 'content', 'notice', 'notification', 'promo', 'wrapper'].indexOf(part) === -1;
                })
                .map(function(part) {
                    return part.charAt(0).toUpperCase() + part.slice(1);
                })
                .join(' ');
        },
        
        /**
         * Find a notification in the in-memory list (including grouped items).
         */
        findNotificationInConfig: function(feedId, dbId) {
            this.ensureNotificationsArray();
            var feedKey = feedId ? String(feedId) : '';
            var dbKey = dbId ? String(dbId) : '';
            var matches = [];

            this.config.notifications.forEach(function(n) {
                if (n.type === 'group' && n.items && n.items.length) {
                    n.items.forEach(function(item) {
                        matches.push(item);
                    });
                } else {
                    matches.push(n);
                }
            });

            return matches.find(function(n) {
                if (!n) {
                    return false;
                }

                var meta = n.meta || {};
                if (typeof meta === 'string' && meta) {
                    try {
                        meta = JSON.parse(meta);
                    } catch (e) {
                        meta = {};
                    }
                }

                var metaId = meta && meta.id ? String(meta.id) : '';
                var nId = n.id !== undefined && n.id !== null ? String(n.id) : '';

                if (dbKey && nId === dbKey) {
                    return true;
                }
                if (feedKey && (metaId === feedKey || nId === feedKey)) {
                    return true;
                }

                return false;
            }) || null;
        },

        /**
         * Resolve full HTML/plain message for modal display.
         */
        resolveNotificationItemMessage: function($item, notificationData) {
            if (notificationData && notificationData.message && String(notificationData.message).trim() !== '') {
                return notificationData.message;
            }

            var fullText = $item.attr('data-full-text') || '';
            if (fullText.trim() !== '') {
                return fullText;
            }

            fullText = $item.attr('data-description') || '';
            if (fullText.trim() !== '') {
                return fullText;
            }

            return $item.attr('data-summary') || $item.data('summary') || '';
        },

        /**
         * Strip HTML tags from text (for displaying in dropdown list)
         */
        stripHtml: function(html) {
            if (!html) return '';
            var tmp = document.createElement('div');
            tmp.innerHTML = this.cleanNotificationHtml(html);
            return (tmp.textContent || tmp.innerText || '').replace(/\s+/g, ' ').trim();
        },
        
        /**
         * Setup BroadcastChannel for multi-tab synchronization (like old system)
         */
        setupBroadcastChannel: function() {
            var self = this;
            
            // Check if BroadcastChannel is supported
            if (typeof BroadcastChannel === 'undefined') {
                this.setupLocalStorageSync();
                return;
            }
            
            try {
                // Create BroadcastChannel with same name as old system
                this.broadcastChannel = new BroadcastChannel('yp-notifications');
                
                // Listen for messages from other tabs
                this.broadcastChannel.addEventListener('message', function(event) {
                    var data = event && event.data ? event.data : {};
                    
                    switch (data.type) {
                        case 'NOTIFICATION_UPDATE':
                            // Another tab updated notifications, reload (with debounce to prevent loops)
                            
                            // Ignore if this message came from this tab
                            if (data.data && data.data.sessionId === self.config.sessionId) {
                                return;
                            }
                            
                            // Store previous count BEFORE reloading (for sound check)
                            var previousCountBeforeReload = self.config.unreadCount;
                            
                            // Debounce: only reload if not already loading and enough time has passed
                            if (self.config.isLoading) {
                                return;
                            }
                            
                            // Clear existing debounce timer
                            if (self.config.broadcastDebounceTimer) {
                                clearTimeout(self.config.broadcastDebounceTimer);
                            }
                            
                            // Debounce reload by 500ms to prevent rapid-fire reloads
                            self.config.broadcastDebounceTimer = setTimeout(function() {
                                // Only reload if not currently loading
                                if (!self.config.isLoading) {
                                    // Store previous count for sound check after reload
                                    self.config.previousCountForBroadcast = previousCountBeforeReload;
                                    self.loadNotifications(true); // Pass true to indicate this is from broadcast
                                }
                            }, 500);
                            break;
                            
                        case 'BADGE_UPDATE':
                            // Another tab updated badge count
                            if (data.data && data.data.unreadCount !== undefined) {
                                var previousCount = self.config.unreadCount;
                                var newCount = parseInt(data.data.unreadCount) || 0;
                                
                                // Only update if count actually changed
                                if (newCount !== previousCount) {
                                    self.config.unreadCount = newCount;
                                    self.updateBadgeCount(previousCount);
                                    self.updateHeaderCount();
                                    
                                    if (self.shouldPlayNotificationSound(newCount, previousCount)) {
                                        self.playNotificationSound();
                                        self.setUnreadBaseline(newCount);
                                    }
                                }
                            }
                            break;
                            
                        case 'MARK_AS_READ':
                            // Another tab marked notification as read
                            if (data.notificationId) {
                                // Debounce reload
                                if (self.config.broadcastDebounceTimer) {
                                    clearTimeout(self.config.broadcastDebounceTimer);
                                }
                                self.config.broadcastDebounceTimer = setTimeout(function() {
                                    if (!self.config.isLoading) {
                                        self.loadNotifications(true);
                                    }
                                }, 500);
                            }
                            break;
                            
                        case 'DISMISS':
                            // Another tab dismissed notification
                            if (data.notificationId) {
                                // Debounce reload
                                if (self.config.broadcastDebounceTimer) {
                                    clearTimeout(self.config.broadcastDebounceTimer);
                                }
                                self.config.broadcastDebounceTimer = setTimeout(function() {
                                    if (!self.config.isLoading) {
                                        self.loadNotifications(true);
                                    }
                                }, 500);
                            }
                            break;
                    }
                });
            } catch (e) {
                console.error('[yooadm Notifications] Failed to setup BroadcastChannel:', e);
                this.setupLocalStorageSync();
            }
        },
        
        /**
         * Setup localStorage sync as fallback (for browsers without BroadcastChannel)
         */
        setupLocalStorageSync: function() {
            var self = this;
            
            // Listen for storage events (cross-tab communication)
            window.addEventListener('storage', function(event) {
                if (!event.key || !event.key.startsWith('yooadmin_notifications_')) {
                    return;
                }
                
                // Reload notifications when storage changes
                if (event.key === 'yooadmin_notifications_update' || event.key === 'yooadmin_notifications_badge') {
                    self.loadNotifications();
                }
            });
        },
        
        /**
         * Calculate hash of notifications data to detect changes
         */
        calculateNotificationsHash: function(notifications, unreadCount) {
            var dataToHash = {
                count: notifications ? notifications.length : this.config.notifications.length,
                unread: unreadCount !== undefined ? unreadCount : this.config.unreadCount,
                items: []
            };
            
            var notifs = notifications || this.config.notifications;
            if (Array.isArray(notifs)) {
                // Create a simplified representation of notifications for hashing
                notifs.forEach(function(n) {
                    dataToHash.items.push({
                        id: n.id || (n.meta && n.meta.id) || '',
                        status: n.status || 'new',
                        source_type: n.source_type || ''
                    });
                });
            }
            
            // Simple hash function
            var str = JSON.stringify(dataToHash);
            var hash = 0;
            for (var i = 0; i < str.length; i++) {
                var char = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & hash; // Convert to 32bit integer
            }
            return hash.toString();
        },
        
        /**
         * Broadcast message to other tabs
         */
        broadcastMessage: function(type, data) {
            var message = {
                type: type,
                timestamp: Date.now(),
                data: data || {}
            };
            
            // Use BroadcastChannel if available (PRIMARY METHOD)
            if (this.broadcastChannel) {
                try {
                    this.broadcastChannel.postMessage(message);
                    return; // Success, no need for localStorage fallback
                } catch (e) {
                    console.error('[yooadm Notifications] Failed to broadcast message:', e);
                }
            }
            
            // Fallback to localStorage (ONLY if BroadcastChannel fails)
            try {
                localStorage.setItem('yooadmin_notifications_update', JSON.stringify(message));
                // Trigger storage event manually (won't fire in same tab, but will in other tabs)
                setTimeout(function() {
                    localStorage.removeItem('yooadmin_notifications_update');
                }, 100);
            } catch (e) {
                // localStorage may be disabled
            }
        }
    };
    
    // Initialize when DOM is ready
    $(document).ready(function() {
        if (typeof yooadmNotifications !== 'undefined') {
            yooadmNotificationsUi.init();
        }

        $(window).on('beforeunload pagehide', function() {
            if (window.yooadmNotificationsUi && typeof yooadmNotificationsUi.setUnreadBaseline === 'function') {
                yooadmNotificationsUi.setUnreadBaseline(yooadmNotificationsUi.config.unreadCount);
            }
        });
    });

})(jQuery);
