(function () {
	'use strict';

	if (window.__yooadminDesktopLoadingBrand__) {
		return;
	}
	window.__yooadminDesktopLoadingBrand__ = true;

	var cfg =
		window.yooadminDesktopLoadingBrand &&
		typeof window.yooadminDesktopLoadingBrand === 'object'
			? window.yooadminDesktopLoadingBrand
			: {};

	function isLightModeEffective() {
		var html = document.documentElement;
		var effective = html.getAttribute('data-yooadmin-studio-color-mode-effective');
		if (effective === 'light') {
			return true;
		}
		if (effective === 'dark') {
			return false;
		}

		var mode = html.getAttribute('data-yooadmin-studio-color-mode') || 'auto';
		if (mode === 'light') {
			return true;
		}
		if (mode === 'dark') {
			return false;
		}

		try {
			return !window.matchMedia('(prefers-color-scheme: dark)').matches;
		} catch (e) {
			return true;
		}
	}

	function logoUrl() {
		if (isLightModeEffective()) {
			var darkUrl =
				typeof cfg.logoDarkUrl === 'string' && cfg.logoDarkUrl ? cfg.logoDarkUrl : '';
			if (darkUrl) {
				return darkUrl;
			}
		}

		return typeof cfg.logoUrl === 'string' && cfg.logoUrl ? cfg.logoUrl : '';
	}

	function spinnerColor() {
		return typeof cfg.spinnerColor === 'string' && cfg.spinnerColor
			? cfg.spinnerColor
			: '#eda934';
	}

	var MARK_HIDE_CSS =
		'.root svg .mark{display:none!important;visibility:hidden!important}' +
		'.root svg>g:first-child>circle:first-child,' +
		'.root svg>g:first-of-type>circle:first-of-type{display:none!important;fill:transparent!important;opacity:0!important}';

	function injectSpinnerHideStyle(shadowRoot) {
		if (!shadowRoot) {
			return;
		}
		var style = shadowRoot.querySelector('[data-yooadmin-hide-mark]');
		if (!style) {
			style = document.createElement('style');
			style.setAttribute('data-yooadmin-hide-mark', '1');
			shadowRoot.appendChild(style);
		}
		style.textContent = MARK_HIDE_CSS;
	}

	function watchSpinnerShadow(spinner) {
		if (!spinner || spinner.dataset.yooadminSpinnerWatch === '1') {
			return;
		}

		function attach(shadowRoot) {
			if (!shadowRoot) {
				return false;
			}
			injectSpinnerHideStyle(shadowRoot);

			var paintedRoot = shadowRoot.querySelector('.root');
			if (!paintedRoot) {
				return false;
			}

			spinner.dataset.yooadminSpinnerWatch = '1';

			if (paintedRoot.dataset.yooadminRootWatch === '1') {
				return true;
			}
			paintedRoot.dataset.yooadminRootWatch = '1';

			try {
				new MutationObserver(function () {
					injectSpinnerHideStyle(shadowRoot);
				}).observe(paintedRoot, { childList: true, subtree: true });
			} catch (e) {
				/* ignore */
			}
			return true;
		}

		if (attach(spinner.shadowRoot)) {
			return;
		}

		var tries = 0;
		var timer = window.setInterval(function () {
			tries += 1;
			if (attach(spinner.shadowRoot) || tries > 80) {
				window.clearInterval(timer);
			}
		}, 50);
	}

	function brandSpinner(spinner) {
		if (!spinner) {
			return;
		}
		spinner.setAttribute('accent', 'transparent');
		spinner.setAttribute('color', spinnerColor());
		watchSpinnerShadow(spinner);
	}

	function brandLoadingOverlay(overlay) {
		if (!(overlay instanceof HTMLElement)) {
			return;
		}
		overlay.classList.add('yooadmin-desktop-loading-overlay');

		brandSpinner(overlay.querySelector('wpd-spinner'));

		var url = logoUrl();
		if (!url) {
			return;
		}

		var brand = overlay.querySelector('.yooadmin-desktop-loading-brand');
		if (brand) {
			var existingImg = brand.querySelector('img');
			if (existingImg && existingImg.src !== url) {
				existingImg.src = url;
			}
			overlay.dataset.yooadminLoadingBranded = '1';
			return;
		}

		overlay.dataset.yooadminLoadingBranded = '1';

		brand = document.createElement('div');
		brand.className = 'yooadmin-desktop-loading-brand';
		brand.setAttribute('aria-hidden', 'true');

		var img = document.createElement('img');
		img.src = url;
		img.alt = '';
		img.decoding = 'async';
		img.loading = 'eager';
		brand.appendChild(img);
		overlay.appendChild(brand);
	}

	function scanShell(root) {
		if (!root || !root.querySelectorAll) {
			return;
		}
		root.querySelectorAll('.desktop-mode-window__loading').forEach(brandLoadingOverlay);
	}

	function observeShell() {
		var shell = document.getElementById('desktop-mode-shell');
		if (!shell || shell.dataset.yooadminLoadingBrandObserved === '1') {
			return;
		}
		shell.dataset.yooadminLoadingBrandObserved = '1';
		scanShell(shell);

		try {
			new MutationObserver(function (mutations) {
				mutations.forEach(function (mutation) {
					mutation.addedNodes.forEach(function (node) {
						if (!(node instanceof HTMLElement)) {
							return;
						}
						if (node.matches('.desktop-mode-window__loading')) {
							brandLoadingOverlay(node);
							return;
						}
						scanShell(node);
					});
				});
			}).observe(shell, { childList: true, subtree: true });
		} catch (e) {
			/* ignore */
		}
	}

	function registerHooks() {
		var hooks = window.wp && window.wp.hooks;
		if (!hooks || typeof hooks.addFilter !== 'function') {
			return false;
		}

		if (!registerHooks.done) {
			registerHooks.done = true;

			hooks.addFilter(
				'desktop-mode.window.loading-overlay',
				'yooadmin/desktop-loading-brand',
				function (overlay) {
					brandLoadingOverlay(overlay);
					return overlay;
				}
			);

			if (typeof hooks.addAction === 'function') {
				hooks.addAction(
					'desktop-mode.window.content-loading',
					'yooadmin/desktop-loading-brand',
					function () {
						window.setTimeout(function () {
							scanShell(document.getElementById('desktop-mode-shell'));
						}, 0);
					},
					20
				);
			}
		}

		return true;
	}

	function boot() {
		if (!registerHooks()) {
			return false;
		}
		observeShell();
		[100, 500, 1500].forEach(function (delay) {
			window.setTimeout(observeShell, delay);
		});
		return true;
	}

	function bootWithRetry() {
		if (boot()) {
			return;
		}
		var tries = 0;
		var timer = window.setInterval(function () {
			tries += 1;
			if (boot() || tries > 40) {
				window.clearInterval(timer);
			}
		}, 50);
	}

	document.addEventListener('ysh-studio-color-mode-changed', function () {
		scanShell(document.getElementById('desktop-mode-shell'));
	});

	if (window.wp && window.wp.hooks) {
		bootWithRetry();
	} else if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', bootWithRetry);
	} else {
		bootWithRetry();
	}
})();
