/**
 * Settings → Behavior — reset guided tour for current user.
 */
(function ($) {
  'use strict';

  function showSettingsToast(message, type) {
    if (!message) {
      return;
    }

    if (typeof window.yooadminSettingsToast === 'function') {
      window.yooadminSettingsToast(message, type || 'success');
      return;
    }

    if (window.yooadmToast) {
      type = type || 'success';
      if (type === 'error' && typeof window.yooadmToast.error === 'function') {
        window.yooadmToast.error(message);
        return;
      }
      if (typeof window.yooadmToast.success === 'function' && type !== 'error') {
        window.yooadmToast.success(message);
        return;
      }
      if (typeof window.yooadmToast.show === 'function') {
        window.yooadmToast.show(message, type);
        return;
      }
    }

    if (typeof window.yooadminShowToast === 'function') {
      window.yooadminShowToast(message, type || 'success');
    }
  }

  $(function () {
    var $btn = $('#yooadmin-guided-tour-reset');
    if (!$btn.length) {
      return;
    }

    $btn.on('click', function () {
      if ($btn.prop('disabled') || $btn.attr('aria-busy') === 'true') {
        return;
      }

      var nonce = $btn.data('nonce');
      var successMsg = $btn.data('toast-success') || 'Guided tour reset.';
      var errorMsg = $btn.data('toast-error') || 'Could not reset the guided tour.';

      $btn.prop('disabled', true).attr('aria-busy', 'true').addClass('is-busy');

      $.post(
        (window.yooadminGuidedTourReset && yooadminGuidedTourReset.ajaxUrl) ||
          (window.ajaxurl || ''),
        {
          action: 'yooadmin_guided_tour_action',
          nonce: nonce,
          task: 'reset'
        }
      )
        .done(function (res) {
          if (res && res.success) {
            showSettingsToast(successMsg);
            try {
              sessionStorage.removeItem('yooadmin_guided_tour_step');
              sessionStorage.removeItem('yooadmin_guided_tour_ext');
              sessionStorage.removeItem('yooadmin_guided_tour_settings_pending');
            } catch (e) {
              /* ignore */
            }
          } else {
            showSettingsToast(errorMsg, 'error');
          }
        })
        .fail(function () {
          showSettingsToast(errorMsg, 'error');
        })
        .always(function () {
          $btn.prop('disabled', false).removeAttr('aria-busy').removeClass('is-busy');
        });
    });
  });
})(jQuery);
