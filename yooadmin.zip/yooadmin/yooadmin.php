<?php
/**
 * Plugin Name: YOOAdmin
 * Plugin URI:  https://www.yooadmin.io
 * Description: Clean your WordPress dashboard and take control of admin notices. YOOAdmin transforms cluttered banners into organized notifications and delivers a modern, distraction-free admin experience with a powerful new dark mode engine — without modifying core functionality.
 * Version:     1.5.15
 * Author:      YOOPixel
 * Author URI:  https://www.yoopixel.com
 * Text Domain: yooadmin
 * Domain Path: /languages
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;

define('YOOADMIN_BASE_LOADED', __FILE__);

if (defined('YOOADMIN_PANEL_LOADED')) {
    add_action('admin_notices', function () {
        if (!current_user_can('activate_plugins')) {
            return;
        }
        $plugins_url = admin_url('plugins.php');
        echo '<div class="notice notice-warning is-dismissible"><p>';
        echo esc_html__('YOOAdmin Extended is active. Please deactivate the standalone YOOAdmin plugin to avoid loading two versions.', 'yooadmin');
        echo ' <a href="' . esc_url($plugins_url) . '">' . esc_html__('Plugins', 'yooadmin') . '</a>';
        echo '</p></div>';
    });
    set_transient('yooadmin_conflict_notice', 'base_skipped', 300);
    return;
}

// YOOADMIN_VERSION: defined in config/constants.php from the "Version" plugin header (avoid drift).

// Plugin directory
if (!defined('YOOADMIN_PANEL_DIR')) {
    define('YOOADMIN_PANEL_DIR', plugin_dir_path(__FILE__));
}

// Plugin URL
if (!defined('YOOADMIN_PANEL_URL')) {
    define('YOOADMIN_PANEL_URL', plugin_dir_url(__FILE__));
}

// Plugin basename
if (!defined('YOOADMIN_PANEL_BASENAME')) {
    define('YOOADMIN_PANEL_BASENAME', plugin_basename(__FILE__));
}


/** Safe require helper */
if (!function_exists('yooadmin_require_if_exists')) {
    function yooadmin_require_if_exists($path)
    {
        if (is_string($path) && $path !== '' && file_exists($path)) {
            require_once $path;
            return true;
        }
        return false;
    }
}


/* ------------------------------------------------------------------------
 * 0) Core constants (early)
 * --------------------------------------------------------------------- */
if (!defined('YOOADMIN_PLUGIN_FILE'))
    define('YOOADMIN_PLUGIN_FILE', __FILE__);
if (!defined('YOOADMIN_DIR'))
    define('YOOADMIN_DIR', plugin_dir_path(__FILE__));
if (!defined('YOOADMIN_URL'))
    define('YOOADMIN_URL', plugin_dir_url(__FILE__));

/* ------------------------------------------------------------------------
 * Admin themes: bundled (plugin/themes/) + external (wp-content/yooadmin/themes/)
 * --------------------------------------------------------------------- */
if (!defined('YOOADMIN_ADMIN_THEMES_DIR')) {
    $yooadmin_themes_dir = trailingslashit(wp_normalize_path(WP_CONTENT_DIR)) . 'yooadmin/themes/';

    if (!is_dir($yooadmin_themes_dir)) {
        wp_mkdir_p($yooadmin_themes_dir);
    }

    define('YOOADMIN_ADMIN_THEMES_DIR', $yooadmin_themes_dir);
}

if (!defined('YOOADMIN_ADMIN_THEMES_URL')) {
    define('YOOADMIN_ADMIN_THEMES_URL', trailingslashit(content_url('yooadmin/themes')));
}

if (!defined('YOOADMIN_BUNDLED_ADMIN_THEMES_DIR')) {
    define('YOOADMIN_BUNDLED_ADMIN_THEMES_DIR', trailingslashit(wp_normalize_path(__DIR__)) . 'themes/');
}

if (!defined('YOOADMIN_BUNDLED_ADMIN_THEMES_URL')) {
    define('YOOADMIN_BUNDLED_ADMIN_THEMES_URL', trailingslashit(plugins_url('themes', __FILE__)));
}

if (!function_exists('yooadmin_bundled_admin_theme_path')) {
    function yooadmin_bundled_admin_theme_path(string $slug, string $relative = ''): string {
        $base = trailingslashit(YOOADMIN_BUNDLED_ADMIN_THEMES_DIR) . sanitize_key($slug) . '/';
        if ($relative === '') {
            return untrailingslashit($base);
        }

        return $base . ltrim($relative, '/');
    }
}

/**
 * WP 6.7+: JIT translation loading before {@see after_setup_theme} triggers _doing_it_wrong.
 * WordPress.org loads plugin translations automatically (WP 4.6+); we only preload via
 * {@see load_textdomain()} when a concrete .mo exists so early-loaded code can call __() safely.
 */
if (!function_exists('yooadmin_bootstrap_textdomain')) {
    function yooadmin_bootstrap_textdomain(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;

        if (!function_exists('load_textdomain')) {
            return;
        }

        $locale = function_exists('get_locale') ? get_locale() : 'en_US';
        if (did_action('after_setup_theme') && function_exists('determine_locale')) {
            $locale = determine_locale();
        }

        if (function_exists('yooadmin_load_yooadmin_textdomain')) {
            yooadmin_load_yooadmin_textdomain($locale);
            return;
        }

        $domain = 'yooadmin';
        $rel    = dirname(plugin_basename(YOOADMIN_PLUGIN_FILE));

        if (defined('WP_PLUGIN_DIR')) {
            $mofile = WP_PLUGIN_DIR . '/' . $rel . '/languages/' . $domain . '-' . $locale . '.mo';
            if (is_readable($mofile)) {
                load_textdomain($domain, $mofile);
            }
        }

        if (!is_textdomain_loaded($domain) && defined('WP_LANG_DIR')) {
            $mofile_global = WP_LANG_DIR . '/plugins/' . $domain . '-' . $locale . '.mo';
            if (is_readable($mofile_global)) {
                load_textdomain($domain, $mofile_global);
            }
        }
    }
}
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/i18n.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/wp-compat.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/outbound-api-url.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/standalone-login-rate-limit.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/wp-login-rate-limit.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/user-enumeration-guard.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/hidden-login-entry.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/maintenance-mode.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/public-site-error-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/login-security-dashboard-score.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/yooadmin-rest-route-audit.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/login-turnstile.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/comment-security.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/standalone-login-two-factor.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/profile-plugin-sections.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/profile-avatar-source.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/profile-two-factor.php');
yooadmin_require_if_exists(__DIR__ . '/includes/security/two-factor/bootstrap.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/branded-account-emails.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/branded-public-security-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/profile-email-recovery.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/profile-email-change.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/cloudflare-turnstile-guide.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/login-page-toolbar.php');
add_action('after_setup_theme', 'yooadmin_bootstrap_textdomain', 0);

/* ------------------------------------------------------------------------
 * 1) Config & constants
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/config/constants.php');
yooadmin_require_if_exists(__DIR__ . '/config/plugin-config.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/custom-login.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/custom-login-standalone.php');

// Load external API guard FIRST (WordPress.org compliance)
yooadmin_require_if_exists(__DIR__ . '/includes/core/external-api-guard.php');

// if (!defined('YOOADMIN_DIR') && defined('YOOPIXEL_DIR')) {
//     define('YOOADMIN_DIR', YOOPIXEL_DIR);
// }

/* ------------------------------------------------------------------------
 * 2) Helpers (data-only, no HTML/CSS/JS)
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/helper-functions.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/appearance-icons.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/visibility.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/dashboard-data.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/dynamic-styles.php');
yooadmin_require_if_exists(__DIR__ . '/includes/helpers/template-functions.php');


/* ------------------------------------------------------------------------
 * 3) Frontend tweaks
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/frontend/dashboard-widgets.php');
yooadmin_require_if_exists(__DIR__ . '/includes/api/dashboard-cards.php');
yooadmin_require_if_exists(__DIR__ . '/includes/frontend/custom-admin-bar.php');

/* ------------------------------------------------------------------------
 * 4) Core modules
 *    Order: menu -> guards -> focus -> assets -> shell -> popup -> redirects
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/core/menu.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/wc-guards.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/focus-mode.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/customizer-arabic.php');
yooadmin_require_if_exists(__DIR__ . '/includes/integrations/desktop-mode.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/multisite.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-dashboard.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-dashboard-tips.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-settings.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-sites.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-site-new.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-site-info.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-site-editor.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-site-users.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-users.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-site-themes.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-site-settings.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-site-yooadmin.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-update-center.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-setup.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/network-upgrade.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/focus-mode-notice.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/plugins-layout-handler.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/assets.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/command-palette.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/focus-split-modal.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/admin-bar-focus-toggle.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/admin-bar-settings-modal.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/brand-hover-fix.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/shell.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/popup.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/redirects.php');
if (is_multisite()) {
    yooadmin_require_if_exists(__DIR__ . '/includes/core/network-admin-page-registry.php');
    yooadmin_require_if_exists(__DIR__ . '/includes/core/network-redirects.php');
}
yooadmin_require_if_exists(__DIR__ . '/includes/core/data-cleanup.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/plugin-actions.php');

/**
 * PHP 8.1+ fix: Ensure $title is never null before admin-header.php calls strip_tags().
 * Hidden pages (parent_slug='') — e.g. yooadmin-admin-theme-settings — leave $title null until
 * the page callback runs, which is *after* admin-header.php. admin_head fires too late; admin_init runs first.
 */
add_action(
    'admin_init',
    static function () {
        global $title;
        if (null === $title) {
            $title = '';
        }
    },
    0
);

/* ------------------------------------------------------------------------
 * 5) Admin UI
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/admin/admin-permissions.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/regular-user-experience.php');
yooadmin_require_if_exists(__DIR__ . '/includes/frontend/account-overview-widget.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/quick-actions-storage.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/shell-license-status.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/class-yooadmin-labs-prefs.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/class-yooadmin-guided-tour.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/class-yooai-promo.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/admin-settings.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/settings-plus-promo.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-settings-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-sites-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-site-new-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-site-info-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-site-users-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-users-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-site-themes-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-site-settings-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-site-yooadmin-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-update-center-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/update-center-ajax.php');
add_action(
    'init',
    static function (): void {
        if (!is_admin() || !class_exists('YOOAdmin_Update_Center_Ajax')) {
            return;
        }

        YOOAdmin_Update_Center_Ajax::get_instance();
    },
    6
);
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-setup-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/network-upgrade-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/core/wp-settings-experience.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/users-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/list-screen-toast.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/list-screens-ui.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/list-screen-options-modal.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/native-list-screen-critical.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/comments-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/global-admin-ui.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/admin-language-switcher.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/yp-admin-confirm.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/plugins-admin-experience.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/posts-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/pages-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/categories-page.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/tags-page.php');

// Register Experience options
add_action('admin_init', function () {
    register_setting('yooadmin_content_management', 'yooadmin_posts_experience', ['type' => 'boolean', 'default' => false, 'sanitize_callback' => 'rest_sanitize_boolean']);
    register_setting('yooadmin_content_management', 'yooadmin_pages_experience', ['type' => 'boolean', 'default' => false, 'sanitize_callback' => 'rest_sanitize_boolean']);
    register_setting('yooadmin_content_management', 'yooadmin_categories_experience', ['type' => 'boolean', 'default' => false, 'sanitize_callback' => 'rest_sanitize_boolean']);
    register_setting('yooadmin_content_management', 'yooadmin_tags_experience', ['type' => 'boolean', 'default' => false, 'sanitize_callback' => 'rest_sanitize_boolean']);
});

yooadmin_require_if_exists(__DIR__ . '/includes/admin/class-admin-dashboard.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/class-admin-theme-manager.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/class-studio-hub-upgrade-modal.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/class-welcome-popup.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/class-yooadmin-review-popup.php');
if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
    add_action(
        'after_setup_theme',
        static function (): void {
            YOOAdmin_Admin_Theme_Manager::get_instance()->init();
        },
        2
    );

    add_action(
        'init',
        static function (): void {
            if (!is_admin()) {
                return;
            }
            $widgets = yooadmin_bundled_admin_theme_path('yooadmin-studio-hub', 'includes/studio-hub-dashboard-widgets.php');
            if (!is_readable($widgets)) {
                $widgets = trailingslashit(YOOADMIN_ADMIN_THEMES_DIR) . 'yooadmin-studio-hub/includes/studio-hub-dashboard-widgets.php';
            }
            if (is_readable($widgets) && !function_exists('yooadmin_studio_hub_register_dashboard_widget_hooks')) {
                require_once $widgets;
            }

            $builtin_cards = yooadmin_bundled_admin_theme_path('yooadmin-studio-hub', 'includes/studio-hub-builtin-dashboard-cards.php');
            if (is_readable($builtin_cards) && !function_exists('yooadmin_studio_hub_register_builtin_dashboard_cards')) {
                require_once $builtin_cards;
            }
        },
        5
    );
}

if (class_exists('YOOAdmin_Studio_Hub_Upgrade_Modal')) {
    YOOAdmin_Studio_Hub_Upgrade_Modal::init();
}

if (class_exists('YOOAdmin_Welcome_Popup')) {
    YOOAdmin_Welcome_Popup::init();
}

if (class_exists('YOOAdmin_Review_Popup')) {
    YOOAdmin_Review_Popup::init();
}

// AJAX handlers
yooadmin_require_if_exists(__DIR__ . '/includes/admin/ajax/avatar-upload.php');

/* ------------------------------------------------------------------------
 * 5.1) License Manager
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/class-license-manager.php');
if (class_exists('YOOAdmin_License_Manager')) {
    add_action(
        'after_setup_theme',
        static function (): void {
            YOOAdmin_License_Manager::get_instance()->init();
        },
        2
    );
}

/* ------------------------------------------------------------------------
 * 5.2) Webhook Receiver (for real-time license status updates)
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/class-webhook-receiver.php');

/* ------------------------------------------------------------------------
 * 8.1) Setup Wizard (loaded on init to avoid early translation loading)
 * --------------------------------------------------------------------- */
add_action('init', function() {
    yooadmin_require_if_exists(__DIR__ . '/includes/class-setup-wizard.php');
    yooadmin_require_if_exists(__DIR__ . '/includes/class-activation-redirect.php');
    yooadmin_require_if_exists(__DIR__ . '/includes/class-wizard-notice.php');
    yooadmin_require_if_exists(__DIR__ . '/includes/class-wizard-dashboard-widget.php');
}, 5);

// Trigger wizard on plugin activation
register_activation_hook(__FILE__, function () {
    // Set redirect flag for single activation only
    if (!get_option('yooadmin_wizard_completed') && !get_option('yooadmin_wizard_dismissed')) {
        // CRITICAL: Set cookie ONLY to disable Focus Mode temporarily for wizard
        // DO NOT change yooadmin_focus_policy - it breaks routing and settings save!
        if (!headers_sent()) {
            setcookie('yoo_focus', 'off', time() + (365 * DAY_IN_SECONDS), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        }

        set_transient('yooadmin_activation_redirect', 1, 30);
    }
});

/* ------------------------------------------------------------------------
 * 6) AJAX handlers (centralized)
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/ajax/ajax-handlers.php');

/* ------------------------------------------------------------------------
 * 7.2) Notification system compatibility (load early)
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/notifications/compatibility.php');
yooadmin_require_if_exists(__DIR__ . '/includes/notifications/archive-delay-field.php');

/* ------------------------------------------------------------------------
 * 7.3) Notification system UI components
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/notifications/ui.php');

/* ------------------------------------------------------------------------
 * 7.3) Notification system integration (activate new system)
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/notifications/integration.php');

/* ------------------------------------------------------------------------
 * 7.3.1) Workspace Notes (Studio Hub — todos/reminders + bell notifications)
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/workspace-notes/bootstrap.php');

/* ------------------------------------------------------------------------
 * 7.3.2) Activity log (Studio Hub widget + Activity page)
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/activity/bootstrap.php');
yooadmin_require_if_exists(__DIR__ . '/includes/admin/activity-page.php');

/* ------------------------------------------------------------------------
 * 7.4) Notification system UI integration
 * --------------------------------------------------------------------- */
yooadmin_require_if_exists(__DIR__ . '/includes/notifications/ui-integration.php');
yooadmin_require_if_exists(__DIR__ . '/includes/notifications/user-preferences.php');

add_action('init', static function () {
    if (function_exists('yooadmin_get_user_preferences')) {
        yooadmin_get_user_preferences();
    }
}, 6);

yooadmin_require_if_exists(__DIR__ . '/includes/integrations/woocommerce-optimizer.php');

/* ------------------------------------------------------------------------
 * 7.4) Admin scripts (new loading strategy)
 * --------------------------------------------------------------------- */
add_action('admin_enqueue_scripts', function ($hook) {

    // 1. Load essential core functions FIRST
    wp_enqueue_script('yp-admin-core-essential',
        plugins_url('assets/js/admin/yp-admin-core-essential.js', __FILE__),
    [], '1.0.0', true);

    wp_enqueue_script(
        'yooadmin-notice-classifier',
        plugins_url('assets/js/admin/yp-notice-classifier.js', __FILE__),
        ['yp-admin-core-essential'],
        '1.0.0',
        true
    );

    // 2. Load admin utilities
    wp_enqueue_script('yp-admin-utilities',
        plugins_url('assets/js/admin/yp-admin-utilities.js', __FILE__),
    ['yp-admin-core-essential', 'yooadmin-notice-classifier'], '1.0.0', true);

    // 3. Load legacy notification disabler
    wp_enqueue_script('yp-legacy-notification-disable',
        plugins_url('assets/js/admin/yp-legacy-notification-disable.js', __FILE__),
    ['yp-admin-core-essential'], '1.0.0', true);

    // Notifications UI: enqueued in includes/notifications/ui.php (single handle + l10n).

// 5. Load other admin scripts (if they exist)
// ... other scripts ...
});

/* ------------------------------------------------------------------------
 * 8) Activation/Deactivation hooks
 * --------------------------------------------------------------------- */
register_activation_hook(__FILE__, function () {
    // Migrate selected legacy options to new keys if not set
    $map = [
        'yoopixel_primary_color' => 'yooadmin_primary_color',
        'yoopixel_secondary_color' => 'yooadmin_secondary_color',
        'yoopixel_focus_active' => 'yooadmin_focus_active',
        'yoopixel_options' => 'yooadmin_options',
    ];
    foreach ($map as $old => $new) {
        $old_val = get_option($old, null);
        if ($old_val !== null && get_option($new, null) === null) {
            update_option($new, $old_val);
        }
    }

    // Ensure defaults for new options
    if (get_option('yooadmin_primary_color', null) === null) {
        add_option('yooadmin_primary_color', '#eda934');
    }
    if (get_option('yooadmin_secondary_color', null) === null) {
        add_option('yooadmin_secondary_color', '#1A1A1A');
    }

    // Ensure focus policy default is set to 'on' if not present
    if (get_option('yooadmin_focus_policy', null) === null) {
        add_option('yooadmin_focus_policy', 'on');
    // Clear any stale cookie value (server side can't clear browser cookie, but we can set a flag if needed later)
    }

    // Ensure routing defaults exist if missing
    $opts = (array)get_option('yooadmin_options', []);
    $defaults = [
        'redirect_dashboard' => 1,
        'users_redirect' => 1,
        'posts_redirect' => 1,
        'comments_redirect' => 1,
        'pages_redirect' => 1,
        'categories_redirect' => 1,
        'tags_redirect' => 1,
        'plugin_install_basic' => 1,
        'delete_data_on_uninstall' => 0,
    ];
    $changed = false;
    foreach ($defaults as $k => $v) {
        if (!array_key_exists($k, $opts)) {
            $opts[$k] = $v;
            $changed = true;
        }
    }
    if ($changed) {
        update_option('yooadmin_options', $opts);
    }

    if (function_exists('yooadmin_standalone_login_flush_rewrite_rules')) {
        yooadmin_standalone_login_flush_rewrite_rules();
    }

    if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
        YOOAdmin_Admin_Theme_Manager::get_instance()->handle_plugin_activation();
    }
});

register_deactivation_hook(__FILE__, function () {
// Keep options on deactivation; cleanup handled by uninstall.php
});
