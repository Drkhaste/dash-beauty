<?php
/**
 * YOOAdmin - Wizard step: Connect Account
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

$license_manager = YOOAdmin_License_Manager::get_instance();
$has_license = $license_manager->has_license();
$is_active = $license_manager->is_license_active();
?>

<div class="wizard-step-header">
        <h1><?php esc_html_e('Connect Your Account', 'yooadmin'); ?></h1>
        <p class="wizard-subtitle">
            <?php esc_html_e('Optionally link your free YOOAdmin account to access your account features', 'yooadmin'); ?>
        </p>
    </div>

    <div class="wizard-step-body">
        <?php if ($is_active): ?>
            <div class="wizard-message-box wizard-success">
                <span class="dashicons dashicons-yes-alt"></span>
                <div>
                    <h3><?php esc_html_e('Account Connected!', 'yooadmin'); ?></h3>
                    <p>
                        <?php esc_html_e('Your account is linked. Visit your account page to see what\'s available.', 'yooadmin'); ?>
                        <a href="https://www.yooadmin.io/#account" target="_blank" rel="noopener noreferrer" style="color: var(--yooadmin-primary, #eda934); font-weight: 600; text-decoration: none;">yooadmin.io</a>
                    </p>
                </div>
            </div>
        <?php else: ?>
            <div class="wizard-license-content">
                <div class="wizard-license-info">
                    <h3><?php esc_html_e('Why Connect Your Account?', 'yooadmin'); ?></h3>
                    <p style="margin: 0 0 12px; font-size: 13px; line-height: 1.6;">
                        <?php esc_html_e('Linking your YOOAdmin account gives you access to account features.', 'yooadmin'); ?>
                        <a href="https://www.yooadmin.io/#account" target="_blank" rel="noopener noreferrer" style="color: var(--yooadmin-primary, #eda934); font-weight: 600; text-decoration: none;">
                            <?php esc_html_e('Learn more →', 'yooadmin'); ?>
                        </a>
                    </p>
                    <p class="wizard-info-hint" style="margin-top: 12px;">
                        <span class="dashicons dashicons-info-outline"></span>
                        <?php esc_html_e('YOOAdmin works fully without an account — this step is optional', 'yooadmin'); ?>
                    </p>
                </div>

                <div class="wizard-license-action">
                    <?php
                    $license_context = $license_manager->get_license_view_context();
                    $panel_url = $license_context['portal_connect_url'] ?? 'https://www.yooadmin.io/portal/panel-connect/';
                    $origin = wp_parse_url(admin_url(), PHP_URL_SCHEME) . '://' . wp_parse_url(admin_url(), PHP_URL_HOST);
                    $domain = $license_context['site_domain'] ?? wp_parse_url(get_site_url(), PHP_URL_HOST);
                    $panel_url = add_query_arg(['origin' => $origin, 'domain' => $domain], $panel_url);
                    ?>
                    <a href="<?php echo esc_url($panel_url); ?>"
                       class="yp-yoo-btn yp-yoo-btn--primary wizard-activate-license yooadmin-panel-connect-trigger"
                       id="wizard-activate-license-btn"
                       data-panel-url="<?php echo esc_attr($panel_url); ?>">
                        <span class="dashicons dashicons-admin-users"></span>
                        <?php esc_html_e('Connect Free Account', 'yooadmin'); ?>
                    </a>
                    <p class="description" style="margin-top: 12px;">
                        <span class="dashicons dashicons-clock"></span>
                        <?php esc_html_e('Create a new account or log in with an existing one', 'yooadmin'); ?>
                    </p>
                </div>
            </div>

            <div class="wizard-info-box">
                <span class="dashicons dashicons-info"></span>
                <p><?php esc_html_e('You can skip this step and connect your account later from the Connect Account page', 'yooadmin'); ?></p>
            </div>
        <?php endif; ?>
    </div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
