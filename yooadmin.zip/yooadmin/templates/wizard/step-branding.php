<?php
/**
 * YOOAdmin - Wizard step: Branding
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

// Get current settings from the correct options arrays - SAME AS YOOAdmin does
$options = get_option('yooadmin_options', []);
$colors = get_option('yooadmin_colors', []);

$raw_logo = isset($options['logo_url']) ? trim((string) $options['logo_url']) : '';
$theme_logo_default_for_preview = '';
if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
    $theme_manager = YOOAdmin_Admin_Theme_Manager::get_instance();
    if ($theme_manager && method_exists($theme_manager, 'get_active_theme')) {
        $active_theme = $theme_manager->get_active_theme();
        if (!empty($active_theme['branding']['default_logo_url'])) {
            $theme_logo_default_for_preview = esc_url($active_theme['branding']['default_logo_url']);
        }
    }
}
$has_custom_logo = $raw_logo !== '';
$current_logo_url = function_exists('yooadmin_branding_user_logo_preview_url')
    ? yooadmin_branding_user_logo_preview_url($raw_logo, $theme_logo_default_for_preview)
    : '';
$logo_width = isset($options['logo_w']) ? max(60, min(320, (int) $options['logo_w'])) : 150;
$admin_favicon_url = isset($options['admin_favicon_url']) ? esc_url($options['admin_favicon_url']) : '';

// All brand colors from the theme system
$brand_color_definitions = [
    'primary'       => ['label' => __('Primary', 'yooadmin'),           'default' => '#eda934'],
    'border'        => ['label' => __('Border', 'yooadmin'),            'default' => '#e0e0e0'],
    'header_bg'     => ['label' => __('Header Background', 'yooadmin'), 'default' => '#4B4B4B'],
    'sidebar_bg'    => ['label' => __('Sidebar Background', 'yooadmin'),'default' => '#4B4B4B'],
    'text_contrast' => ['label' => __('Text Contrast', 'yooadmin'),     'default' => '#FFFFFF'],
    'text_600'      => ['label' => __('Primary Text', 'yooadmin'),      'default' => '#5d5d5d'],
    'text_500'      => ['label' => __('Secondary Text', 'yooadmin'),    'default' => '#555555'],
    'card_icon'     => ['label' => __('Card Icon', 'yooadmin'),         'default' => '#eda934'],
];
?>
    <div class="wizard-step-header">
        <h1><?php esc_html_e('Customize Your Dashboard', 'yooadmin'); ?></h1>
        <p class="wizard-subtitle">
            <?php esc_html_e('Choose your logo and colors to match your brand', 'yooadmin'); ?>
        </p>
        <p class="wizard-info-hint wizard-info-hint-center">
            <?php
            printf(
                /* translators: %s: YOOAdmin Settings label */
                esc_html__('Changes apply instantly. You can reset everything later from %s.', 'yooadmin'),
                '<span class="wizard-info-hint__settings">' . esc_html__('YOOAdmin Settings', 'yooadmin') . '</span>'
            );
            ?>
        </p>
    </div>
    
    <div class="wizard-step-body">
        <div class="wizard-branding-layout">
            <!-- Logo Section -->
            <div class="wizard-section wizard-logo-section">
                <div class="wizard-section-header">
                    <h3><?php esc_html_e('Dashboard Logo', 'yooadmin'); ?></h3>
                    <button type="button" class="wizard-reset-btn" id="reset-logo">
                        <?php esc_html_e('Reset', 'yooadmin'); ?>
                    </button>
                </div>
                <div class="logo-upload-wrapper">
                    <div class="logo-preview<?php echo $has_custom_logo ? ' has-logo' : ''; ?>" role="button" tabindex="0" aria-label="<?php esc_attr_e('Upload Logo', 'yooadmin'); ?>">
                        <?php if ($current_logo_url): ?>
                            <img src="<?php echo esc_url($current_logo_url); ?>" alt="Logo" id="logo-preview-img" style="width: <?php echo esc_attr((string) $logo_width); ?>px;">
                            <?php if ($has_custom_logo): ?>
                                <button type="button" class="wizard-logo-remove-overlay" aria-label="<?php esc_attr_e('Remove logo', 'yooadmin'); ?>">
                                    <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                                </button>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="logo-placeholder" id="logo-placeholder">
                                <span class="dashicons dashicons-format-image"></span>
                                <p><?php esc_html_e('Upload Logo', 'yooadmin'); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" name="logo_id" id="logo_id" value="">
                    <input type="hidden" name="logo_action" id="wizard-logo-action" value="">
                    <div class="wizard-logo-width-control" hidden>
                        <label for="wizard-logo-width"><?php esc_html_e('Logo Width', 'yooadmin'); ?></label>
                        <div class="wizard-logo-width-row yp-range yp-range--modern">
                            <div class="yp-range__track-wrap">
                                <input type="range"
                                       min="60"
                                       max="320"
                                       step="1"
                                       name="logo_w"
                                       id="wizard-logo-width"
                                       value="<?php echo esc_attr((string) $logo_width); ?>"
                                       aria-label="<?php esc_attr_e('Logo width', 'yooadmin'); ?>"
                                       aria-valuemin="60"
                                       aria-valuemax="320"
                                       aria-valuenow="<?php echo (int) $logo_width; ?>">
                            </div>
                            <span class="yp-range__value">
                                <strong id="wizard-logo-width-val"><?php echo esc_html((string) $logo_width); ?></strong> px
                            </span>
                            <button type="button" class="button wizard-logo-width-reset">
                                <?php esc_html_e('Reset', 'yooadmin'); ?>
                            </button>
                        </div>
                    </div>
                    <div class="wizard-favicon-control">
                        <div class="wizard-favicon-preview<?php echo $admin_favicon_url ? ' has-icon' : ''; ?>" id="wizard-admin-favicon-preview-wrap">
                            <?php if ($admin_favicon_url): ?>
                                <img id="wizard-admin-favicon-preview" src="<?php echo esc_url($admin_favicon_url); ?>" alt="">
                            <?php else: ?>
                                <span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
                            <?php endif; ?>
                        </div>
                        <input type="hidden" name="admin_favicon_url" id="wizard-admin-favicon-url" value="<?php echo esc_attr($admin_favicon_url); ?>">
                        <div class="wizard-favicon-actions">
                            <button type="button" class="button wizard-upload-favicon">
                                <?php esc_html_e('Choose Favicon', 'yooadmin'); ?>
                            </button>
                            <button type="button" class="button wizard-remove-favicon" <?php echo $admin_favicon_url ? '' : 'hidden'; ?>>
                                <?php esc_html_e('Remove', 'yooadmin'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Colors Section -->
            <div class="wizard-section wizard-colors-section">
                <div class="wizard-section-header">
                    <h3><?php esc_html_e('Brand Colors', 'yooadmin'); ?></h3>
                    <button type="button" class="wizard-reset-btn" id="reset-colors">
                        <?php esc_html_e('Reset', 'yooadmin'); ?>
                    </button>
                </div>
                <p class="description" style="margin-bottom: 16px;">
                    <?php esc_html_e('Changes preview instantly on the wizard.', 'yooadmin'); ?>
                </p>
                <div class="color-pickers wizard-color-grid-compact">
                    <?php foreach ($brand_color_definitions as $key => $definition): ?>
                        <?php
                        $current_value = !empty($colors[$key]) ? $colors[$key] : $definition['default'];
                        $input_id = 'wizard_color_' . sanitize_html_class($key);
                        ?>
                        <div class="color-picker-group"><label for="<?php echo esc_attr($input_id); ?>"><?php echo esc_html($definition['label']); ?></label><input type="text" class="wizard-color-picker" id="<?php echo esc_attr($input_id); ?>" name="colors[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($current_value); ?>" data-default-color="<?php echo esc_attr($definition['default']); ?>" data-color-key="<?php echo esc_attr($key); ?>"></div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
