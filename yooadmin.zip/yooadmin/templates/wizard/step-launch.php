<?php
/**
 * YOOAdmin - Wizard step: Launch
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;
?>

<div class="wizard-step-body">
        <div class="wizard-launch-content">
            <div class="wizard-launch-icon" id="wizard-launch-icon">
                <span class="wizard-launch-text"><?php esc_html_e('Congratulations', 'yooadmin'); ?></span>
                <span class="wizard-launch-emoji" id="wizard-launch-emoji">🎉</span>
            </div>
            
            <div class="wizard-step-header wizard-step-header-centered">
                <h1><?php esc_html_e('Congratulations!', 'yooadmin'); ?></h1>
                <p class="wizard-subtitle">
                    <?php esc_html_e('You\'ve successfully completed all the setup steps to make YOOAdmin reflect your unique style and brand!', 'yooadmin'); ?>
                </p>
            </div>
            
            <div class="wizard-launch-message">
                <h2><?php esc_html_e('Are you ready to experience the magic?', 'yooadmin'); ?></h2>
                <p><?php esc_html_e('Click the button below to launch your new workspace', 'yooadmin'); ?></p>
            </div>
        </div>
    </div>

<!-- Launch Animation Overlay -->
<div class="wizard-launch-overlay" id="wizard-launch-overlay" style="display: none;">
    <div class="wizard-launch-animation">
        <!-- Building Animation -->
        <div class="wizard-building-stage" id="building-stage">
            <div class="wizard-progress-bar">
                <div class="wizard-progress-fill" id="progress-fill"></div>
            </div>
            <p class="wizard-progress-message" id="progress-message">
                <?php esc_html_e('Setting up your dashboard...', 'yooadmin'); ?>
            </p>
        </div>
        
        <!-- Countdown Stage -->
        <div class="wizard-countdown-stage" id="countdown-stage" style="display: none;">
            <div class="wizard-countdown-number" id="countdown-number">3</div>
        </div>
    </div>
</div>


