<?php
/**
 * YOOAdmin - Wizard step: Welcome
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;
?>

<div class="wizard-step-header">
    <h1><?php esc_html_e('Welcome to YOOAdmin', 'yooadmin'); ?></h1>
    <p class="wizard-main-message">
        <?php esc_html_e('Your admin should be a workspace — not a billboard.', 'yooadmin'); ?>
    </p>
    <p class="wizard-description">
        <?php esc_html_e('That\'s why YOOAdmin focuses on clarity, calm, and control', 'yooadmin'); ?><br>
        <?php esc_html_e('without ads, nags, or unnecessary noise.', 'yooadmin'); ?>
    </p>
</div>

<div class="wizard-step-body">
    <div class="wizard-quick-info">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
            <path d="M12 6v6l4 2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <div class="wizard-quick-info-text">
            <strong><?php esc_html_e('Takes less than a minute.', 'yooadmin'); ?></strong>
            <span><?php esc_html_e('You can change everything later.', 'yooadmin'); ?></span>
        </div>
    </div>
    
    <div class="wizard-privacy-notice">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <p><?php esc_html_e('We respect your privacy and don\'t collect personal data without your permission.', 'yooadmin'); ?></p>
    </div>
</div>

