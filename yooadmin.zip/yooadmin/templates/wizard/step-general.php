<?php
/**
 * YOOAdmin - Wizard step: General settings
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

// Get current settings from yooadmin_options array
$options = get_option('yooadmin_options', []);
$options = is_array($options) ? $options : [];
$posts_redirect = !empty($options['posts_redirect']);
$comments_redirect = !empty($options['comments_redirect']);
$pages_redirect = !empty($options['pages_redirect']);
$categories_redirect = !empty($options['categories_redirect']);
$tags_redirect = !empty($options['tags_redirect']);
$users_redirect = !empty($options['users_redirect']);
$wp_settings_experience = array_key_exists('wp_settings_experience', $options) ? !empty($options['wp_settings_experience']) : true;
$plugin_install_basic = array_key_exists('plugin_install_basic', $options) ? !empty($options['plugin_install_basic']) : true;
$enable_custom_admin_bar = isset($options['enable_custom_admin_bar']) ? !empty($options['enable_custom_admin_bar']) : true;
// Merge plugin defaults so missing keys use configured defaults (e.g. convert banners on).
$defaults = function_exists('yooadmin_default_options') ? yooadmin_default_options() : [];
$merged = array_merge($defaults, $options);
$convert_banners = !empty($merged['convert_banners_to_notifications']);
$delete_data_on_uninstall = !empty($merged['delete_data_on_uninstall']);

$login_page_enabled_w = !empty($merged['login_page_enabled']);
$login_rate_limit_enabled_w = !empty($merged['login_rate_limit_enabled']);
$show_login_wizard = function_exists('yooadmin_has_feature') && yooadmin_has_feature('login_customizer');
?>

<div class="wizard-step-header">
    <h1><?php esc_html_e('General Settings', 'yooadmin'); ?></h1>
    <p class="wizard-subtitle">
        <?php esc_html_e('Configure content management and system preferences', 'yooadmin'); ?>
    </p>
</div>

<div class="wizard-step-body">
    <div class="wizard-section wizard-general-section">
        <div class="wizard-section-header">
            <h3><?php esc_html_e('Content Management', 'yooadmin'); ?></h3>
            <p class="wizard-section-hint">
                <span class="wizard-legend-item yoo-hint">
                    <span class="wizard-legend-icon wizard-legend-icon--on dashicons dashicons-yes" aria-hidden="true"></span>
                    <span><?php esc_html_e('YOOAdmin experience', 'yooadmin'); ?></span>
                </span>
                <span class="wizard-legend-item wp-hint">
                    <span class="wizard-legend-icon wizard-legend-icon--off" aria-hidden="true"></span>
                    <span><?php esc_html_e('WordPress default', 'yooadmin'); ?></span>
                </span>
            </p>
        </div>
        <div class="wizard-settings-compact-grid wizard-content-management-grid">
            <label class="wizard-compact-setting">
                <input type="checkbox" name="posts_redirect" id="posts_redirect" value="1" <?php checked($posts_redirect, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Posts', 'yooadmin'); ?>
                </span>
            </label>
            <label class="wizard-compact-setting">
                <input type="checkbox" name="comments_redirect" id="comments_redirect" value="1" <?php checked($comments_redirect, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Comments', 'yooadmin'); ?>
                </span>
            </label>
            <label class="wizard-compact-setting">
                <input type="checkbox" name="pages_redirect" id="pages_redirect" value="1" <?php checked($pages_redirect, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Pages', 'yooadmin'); ?>
                </span>
            </label>
            <label class="wizard-compact-setting">
                <input type="checkbox" name="categories_redirect" id="categories_redirect" value="1" <?php checked($categories_redirect, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Categories', 'yooadmin'); ?>
                </span>
            </label>
            <label class="wizard-compact-setting">
                <input type="checkbox" name="tags_redirect" id="tags_redirect" value="1" <?php checked($tags_redirect, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Tags', 'yooadmin'); ?>
                </span>
            </label>
        </div>
    </div>
    
    <div class="wizard-section wizard-general-section">
        <div class="wizard-section-header">
            <h3><?php esc_html_e('System & Users', 'yooadmin'); ?></h3>
            <p class="wizard-section-hint">
                <span class="wizard-legend-item yoo-hint">
                    <span class="wizard-legend-icon wizard-legend-icon--on dashicons dashicons-yes" aria-hidden="true"></span>
                    <span><?php esc_html_e('YOOAdmin experience', 'yooadmin'); ?></span>
                </span>
                <span class="wizard-legend-item wp-hint">
                    <span class="wizard-legend-icon wizard-legend-icon--off" aria-hidden="true"></span>
                    <span><?php esc_html_e('WordPress default', 'yooadmin'); ?></span>
                </span>
            </p>
        </div>
        <div class="wizard-settings-compact-grid">
            <label class="wizard-compact-setting">
                <input type="checkbox" name="users_redirect" id="users_redirect" value="1" <?php checked($users_redirect, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Users', 'yooadmin'); ?>
                </span>
            </label>
            <label class="wizard-compact-setting">
                <input type="checkbox" name="wp_settings_experience" id="wp_settings_experience" value="1" <?php checked($wp_settings_experience, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('WP Settings', 'yooadmin'); ?>
                </span>
            </label>
            <?php if (apply_filters('yooadmin_settings_show_plugin_install_basic', true, $options)) : ?>
            <label class="wizard-compact-setting">
                <input type="checkbox" name="plugin_install_basic" id="plugin_install_basic" value="1" <?php checked($plugin_install_basic, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Plugin Basic', 'yooadmin'); ?>
                </span>
            </label>
            <?php endif; ?>
            <?php do_action('yooadmin_wizard_general_system_row', $options); ?>
            <label class="wizard-compact-setting wizard-setting-with-tooltip">
                <input type="checkbox" name="enable_custom_admin_bar" id="enable_custom_admin_bar" value="1" <?php checked($enable_custom_admin_bar, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Admin Bar', 'yooadmin'); ?>
                    <span class="wizard-info-icon dashicons dashicons-info-outline" aria-hidden="true"></span>
                </span>
                <span class="wizard-tooltip">
                    <span class="tooltip-title"><?php esc_html_e('Frontend Admin Bar', 'yooadmin'); ?></span>
                    <p><?php esc_html_e('Replace WordPress admin bar with custom YOOAdmin bar on frontend.', 'yooadmin'); ?></p>
                    <span class="tooltip-checked"><?php esc_html_e('✓ Enabled: Show custom YOOAdmin bar (requires Focus Mode)', 'yooadmin'); ?></span><br>
                    <span class="tooltip-unchecked"><?php esc_html_e('☐ Disabled: Keep WordPress default admin bar', 'yooadmin'); ?></span>
                </span>
            </label>
            <label class="wizard-compact-setting wizard-setting-with-tooltip">
                <input type="checkbox" name="convert_banners_to_notifications" id="convert_banners_to_notifications" value="1" <?php checked($convert_banners, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Notifications', 'yooadmin'); ?>
                    <span class="wizard-info-icon dashicons dashicons-info-outline" aria-hidden="true"></span>
                </span>
                <span class="wizard-tooltip">
                    <span class="tooltip-title"><?php esc_html_e('Admin Banner Conversion', 'yooadmin'); ?></span>
                    <p><?php esc_html_e('Automatically capture WordPress admin notices and display them as notification items instead of banners.', 'yooadmin'); ?></p>
                </span>
            </label>
            <?php if ($show_login_wizard) : ?>
            <label class="wizard-compact-setting wizard-setting-with-tooltip">
                <input type="checkbox" name="login_page_enabled" id="wizard_login_page_enabled" value="1" <?php checked($login_page_enabled_w, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Login page', 'yooadmin'); ?>
                    <span class="wizard-info-icon dashicons dashicons-info-outline" aria-hidden="true"></span>
                </span>
                <span class="wizard-tooltip">
                    <span class="tooltip-title"><?php esc_html_e('YOOAdmin login', 'yooadmin'); ?></span>
                    <p><?php esc_html_e('Use the YOOAdmin-styled wp-login layout when Focus Mode allows YOOAdmin UI. Turn off to always use the standard WordPress login screen.', 'yooadmin'); ?></p>
                </span>
            </label>
            <?php endif; ?>
            <label class="wizard-compact-setting wizard-setting-with-tooltip">
                <input type="checkbox" name="login_rate_limit_enabled" id="wizard_login_rate_limit_enabled" value="1" <?php checked($login_rate_limit_enabled_w, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Login rate limit', 'yooadmin'); ?>
                    <span class="wizard-info-icon dashicons dashicons-info-outline" aria-hidden="true"></span>
                </span>
                <span class="wizard-tooltip">
                    <span class="tooltip-title"><?php esc_html_e('Brute-force protection', 'yooadmin'); ?></span>
                    <p><?php esc_html_e('Slows repeated failed sign-ins using safe defaults (for example 10 attempts per 15 minutes). You can change limits anytime. Additional security options—username protection, Cloudflare Turnstile, and scope—are available under Settings → Login → Security.', 'yooadmin'); ?></p>
                    <span class="tooltip-checked"><?php esc_html_e('✓ On: wp-login.php always; YOOAdmin login page too when that layout is enabled.', 'yooadmin'); ?></span><br>
                    <span class="tooltip-unchecked"><?php esc_html_e('☐ Off: no limits on either login route.', 'yooadmin'); ?></span>
                </span>
            </label>
            <label class="wizard-compact-setting wizard-setting-with-tooltip">
                <input type="checkbox" name="delete_data_on_uninstall" id="delete_data_on_uninstall" value="1" <?php checked($delete_data_on_uninstall, true); ?>>
                <span class="wizard-compact-checkmark"></span>
                <span class="wizard-compact-label">
                    <?php esc_html_e('Data cleanup', 'yooadmin'); ?>
                    <span class="wizard-info-icon dashicons dashicons-info-outline" aria-hidden="true"></span>
                </span>
                <span class="wizard-tooltip">
                    <span class="tooltip-title"><?php esc_html_e('Delete Data on Uninstall', 'yooadmin'); ?></span>
                    <p><?php esc_html_e('When enabled, all YOOAdmin data (settings, wp-login customization, notifications, database tables) will be permanently deleted when you uninstall the plugin. This does NOT affect your WordPress content.', 'yooadmin'); ?></p>
                </span>
            </label>
        </div>
    </div>

    <p class="wizard-info-hint">
        <span class="dashicons dashicons-admin-generic"></span>
        <?php esc_html_e('You can change these settings anytime from YOOAdmin Settings page', 'yooadmin'); ?>
    </p>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
