<?php
/**
 * Multisite access denied / dead-site splash (YOOAdmin styled).
 *
 * @package YOOAdmin
 *
 * @var string   $blog_name Target site name.
 * @var object[] $blogs     Sites the current user can access.
 * @var string   $variant   no_privileges|archived|deleted
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.WP.EnqueuedResources, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Full HTML document rendered from wp_die handler.

$assets = function_exists('yooadmin_multisite_access_denied_assets')
    ? yooadmin_multisite_access_denied_assets()
    : [
        'css_url'         => '',
        'css_ver'         => '1',
        'buttons_css_url' => '',
        'buttons_css_ver' => '1',
        'logo_url'     => '',
        'logo_w'       => 220,
        'site_name'    => '',
        'network_name' => '',
        'variant'      => 'no_privileges',
    ];

$variant = isset($variant) ? (string) $variant : (string) ($assets['variant'] ?? 'no_privileges');
if (!in_array($variant, ['no_privileges', 'archived', 'deleted'], true)) {
    $variant = 'no_privileges';
}

$logo_url      = (string) ($assets['logo_url'] ?? '');
$logo_w        = (int) ($assets['logo_w'] ?? 220);
$no_logo       = ($logo_url === '');
$has_sites     = !empty($blogs);
$network_name  = (string) ($assets['network_name'] ?? get_bloginfo('name', 'display'));
$display_name  = $blog_name !== '' ? $blog_name : (string) ($assets['site_name'] ?? '');

if ($variant === 'archived') {
    $page_title = __('Site unavailable', 'yooadmin');
    $heading    = __('Site archived or suspended', 'yooadmin');
    $lead       = sprintf(
        /* translators: %s: site name */
        __('The "%s" site has been archived or suspended and is no longer available.', 'yooadmin'),
        $display_name
    );
    $help = __('If you need assistance, please contact your network administrator.', 'yooadmin');
} elseif ($variant === 'deleted') {
    $page_title = __('Site unavailable', 'yooadmin');
    $heading    = __('Site no longer available', 'yooadmin');
    $lead       = sprintf(
        /* translators: %s: site name */
        __('The "%s" site is no longer available.', 'yooadmin'),
        $display_name
    );
    $help = __('If you need assistance, please contact your network administrator.', 'yooadmin');
} else {
    $page_title = __('Access denied', 'yooadmin');
    $heading    = __('Permission denied', 'yooadmin');
    $lead       = sprintf(
        /* translators: %s: site name */
        __('You attempted to access the "%s" dashboard, but you do not currently have privileges on this site.', 'yooadmin'),
        $display_name
    );
    $help = __('If you believe you should have access, please contact your network administrator.', 'yooadmin');
}

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noindex, nofollow" />
    <title><?php echo esc_html($page_title . ' — ' . $network_name); ?></title>
    <?php
    if (!empty($assets['buttons_css_url'])) {
        echo '<link rel="stylesheet" href="' . esc_url($assets['buttons_css_url']) . '?ver=' . esc_attr($assets['buttons_css_ver'] ?? '1') . '" />' . "\n";
    }
    if (!empty($assets['css_url'])) {
        echo '<link rel="stylesheet" href="' . esc_url($assets['css_url']) . '?ver=' . esc_attr($assets['css_ver']) . '" />' . "\n";
    }
    if (function_exists('includes_url')) {
        echo '<link rel="stylesheet" href="' . esc_url(includes_url('css/dashicons.min.css')) . '?ver=' . esc_attr(get_bloginfo('version')) . '" />' . "\n";
    }
    if (function_exists('yooadmin_multisite_access_denied_inline_vars')) {
        echo yooadmin_multisite_access_denied_inline_vars(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
    ?>
</head>
<body class="yooadmin-access-denied yoo-ad--<?php echo esc_attr($variant); ?><?php echo $no_logo ? ' yoo-ad--no-logo' : ''; ?>">
<div class="yoo-ad-shell">
    <div class="yoo-ad-card" role="alert">
        <div class="yoo-ad-card-bg" aria-hidden="true">
            <span class="dashicons dashicons-lock yoo-ad-lock-deco"></span>
        </div>
        <header class="yoo-ad-header">
            <?php if (!$no_logo) : ?>
                <img
                    class="yoo-ad-logo"
                    src="<?php echo esc_url($logo_url); ?>"
                    alt="<?php echo esc_attr($network_name); ?>"
                    width="<?php echo esc_attr((string) $logo_w); ?>"
                    decoding="async"
                />
            <?php else : ?>
                <span class="yoo-ad-logo-text">YOOAdmin</span>
            <?php endif; ?>
        </header>

        <div class="yoo-ad-body">
            <div class="yoo-ad-body-content">
                <h1 class="yoo-ad-title"><?php echo esc_html($heading); ?></h1>

                <p class="yoo-ad-lead"><?php echo esc_html($lead); ?></p>

                <p class="yoo-ad-help"><?php echo esc_html($help); ?></p>
            </div>
        </div>

        <?php if ($variant === 'no_privileges' && $has_sites) : ?>
            <section class="yoo-ad-sites" aria-labelledby="yoo-ad-sites-title">
                <h2 id="yoo-ad-sites-title" class="yoo-ad-sites-title"><?php esc_html_e('Your sites', 'yooadmin'); ?></h2>
                <p class="yoo-ad-sites-intro">
                    <?php esc_html_e('If you reached this screen by accident, use one of your sites below.', 'yooadmin'); ?>
                </p>
                <ul class="yoo-ad-sites-list">
                    <?php foreach ($blogs as $blog) : ?>
                        <?php
                        $dash_url = get_admin_url((int) $blog->userblog_id);
                        $home_url = get_home_url((int) $blog->userblog_id);
                        ?>
                        <li class="yoo-ad-site">
                            <div class="yoo-ad-site-main">
                                <span class="yoo-ad-site-icon dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
                                <span class="yoo-ad-site-name"><?php echo esc_html($blog->blogname); ?></span>
                            </div>
                            <div class="yoo-ad-site-actions">
                                <a class="yp-yoo-btn yp-yoo-btn--primary" href="<?php echo esc_url($dash_url); ?>">
                                    <span class="dashicons dashicons-dashboard" aria-hidden="true"></span>
                                    <?php esc_html_e('Visit dashboard', 'yooadmin'); ?>
                                </a>
                                <a class="yp-yoo-btn yp-yoo-btn--soft" href="<?php echo esc_url($home_url); ?>">
                                    <span class="dashicons dashicons-external" aria-hidden="true"></span>
                                    <?php esc_html_e('View site', 'yooadmin'); ?>
                                </a>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </section>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
