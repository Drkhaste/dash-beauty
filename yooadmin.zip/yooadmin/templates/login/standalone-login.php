<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

$yooadmin_sl_locale = function_exists('yooadmin_custom_login_get_login_locale')
    ? yooadmin_custom_login_get_login_locale()
    : (function_exists('determine_locale') ? determine_locale() : get_locale());
if (function_exists('yooadmin_load_yooadmin_textdomain')) {
    yooadmin_load_yooadmin_textdomain($yooadmin_sl_locale);
}
if (function_exists('switch_to_locale')) {
    switch_to_locale($yooadmin_sl_locale);
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals -- Full-page template; variables are file-local, not global state.
// phpcs:disable WordPress.WP.EnqueuedResources -- Full HTML document; assets echoed here (not via wp_enqueue_*).
// phpcs:disable PluginCheck.CodeAnalysis.Offloading.OffloadedContent -- Turnstile uses official Cloudflare CDN via wp_enqueue when enabled.
// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public login GET args (same class of URLs as wp-login.php).

if (!function_exists('yooadmin_custom_login_resolve_logo')
    || !function_exists('yooadmin_get_options')) {
    wp_safe_redirect(wp_login_url());
    exit;
}

$opts = yooadmin_get_options();
$side = isset($opts['login_page_image_side']) ? (string) $opts['login_page_image_side'] : 'left';
$side_class = $side === 'right' ? 'yoo-sl--media-right' : 'yoo-sl--media-left';

$resolved = yooadmin_custom_login_resolve_logo_light();
$resolved_light = $resolved;
$resolved_dark  = function_exists('yooadmin_custom_login_resolve_logo')
    ? yooadmin_custom_login_resolve_logo('dark')
    : $resolved_light;
$logo_url = $resolved_light['url'];
$logo_w = (int) $resolved_light['max_w'];
$logo_dark_url = $resolved_dark['url'];
$use_dual_logos = ($logo_dark_url !== '' && $logo_url !== '' && $logo_dark_url !== $logo_url);
$no_logo = ($logo_url === '' && $logo_dark_url === '');

$img_raw = isset($opts['login_page_image_url']) ? (string) $opts['login_page_image_url'] : '';
$img_url = $img_raw !== '' ? esc_url($img_raw) : '';

$bundled_welcome_bg_url = '';
if (defined('YOOADMIN_DIR') && defined('YOOADMIN_PLUGIN_FILE')
    && is_readable(YOOADMIN_DIR . 'assets/images/login-background.jpg')) {
    $bundled_welcome_bg_url = plugins_url('assets/images/login-background.jpg', YOOADMIN_PLUGIN_FILE);
}
$has_visual_media_bg = ($img_url !== '') || ($bundled_welcome_bg_url !== '');
$sl_ar_class = (function_exists('yooadmin_custom_login_is_arabic_locale') && yooadmin_custom_login_is_arabic_locale()) ? ' yoo-login--ar' : '';

$redirect_to = '';
if (isset($_GET['redirect_to'])) {
    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Validated by wp_validate_redirect().
    $redirect_to = wp_validate_redirect(wp_unslash($_GET['redirect_to']), admin_url());
}

$form_action = site_url('wp-login.php', 'login_post');
$sl_lostpassword_url = function_exists('yooadmin_login_lostpassword_url')
    ? yooadmin_login_lostpassword_url()
    : site_url('wp-login.php?action=lostpassword', 'login');
$sl_forgot_password_inline = function_exists('yooadmin_custom_login_uses_standalone_page')
    && yooadmin_custom_login_uses_standalone_page();
$lostpassword_action = $sl_lostpassword_url;
$resetpass_action = network_site_url('wp-login.php?action=resetpass', 'login_post');
$site_name = get_bloginfo('name', 'display');

$ga = isset($_GET['action']) ? sanitize_key(wp_unslash($_GET['action'])) : '';
if (isset($_GET['key'])) {
    $ga = 'resetpass';
}

$rp_session = (function_exists('yooadmin_standalone_login_get_valid_rp_session'))
    ? yooadmin_standalone_login_get_valid_rp_session()
    : null;
$show_rp_form = $rp_session && ($ga === 'rp' || $ga === 'resetpass');

$sl_revalidate_session = null;
$sl_is_revalidate = ($ga === 'revalidate_2fa');

if ($sl_is_revalidate) {
    if (!is_user_logged_in()) {
        $login_dest = function_exists('yooadmin_standalone_login_public_url')
            ? yooadmin_standalone_login_public_url()
            : (function_exists('yooadmin_standalone_login_public_url') ? yooadmin_standalone_login_public_url() : wp_login_url());
        if ($redirect_to !== '') {
            $login_dest = add_query_arg('redirect_to', $redirect_to, $login_dest);
        }
        wp_safe_redirect($login_dest);
        exit;
    }

    if (function_exists('yooadmin_standalone_login_two_factor_begin_revalidate')) {
        $sl_revalidate_session = yooadmin_standalone_login_two_factor_begin_revalidate(wp_get_current_user(), $redirect_to);
        if (is_wp_error($sl_revalidate_session)) {
            $sl_revalidate_session = null;
        }
    }
}

if ($sl_is_revalidate && is_array($sl_revalidate_session)) {
    $sl_initial_view = '2fa';
} elseif ($ga === 'lostpassword' || $ga === 'retrievepassword') {
    $sl_initial_view = 'reset';
} elseif ($show_rp_form) {
    $sl_initial_view = 'rp';
} else {
    $sl_initial_view = 'login';
}

$sl_color_mode = function_exists('yooadmin_custom_login_get_color_mode') ? yooadmin_custom_login_get_color_mode() : 'auto';
if (!in_array($sl_color_mode, ['light', 'dark', 'auto'], true)) {
    $sl_color_mode = 'auto';
}
$sl_color_effective = function_exists('yooadmin_custom_login_resolve_effective_color_mode')
    ? yooadmin_custom_login_resolve_effective_color_mode()
    : 'light';
$sl_dark_class = ($sl_color_effective === 'dark') ? ' yoo-login--dark' : '';

$rp_login = $rp_session['rp_login'] ?? '';
$rp_key = $rp_session['rp_key'] ?? '';

$base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
$css_url = $base_file ? plugin_dir_url($base_file) . 'assets/css/login/yoo-standalone-login.css' : '';
$css_path = $base_file ? plugin_dir_path($base_file) . 'assets/css/login/yoo-standalone-login.css' : '';
$css_ver = ($css_path && is_readable($css_path)) ? (string) filemtime($css_path) : '1';
$yoo_btn_css_url = $base_file ? plugin_dir_url($base_file) . 'assets/css/admin/yp-yoo-buttons.css' : '';
$yoo_btn_css_path = $base_file ? plugin_dir_path($base_file) . 'assets/css/admin/yp-yoo-buttons.css' : '';
$yoo_btn_css_ver = ($yoo_btn_css_path && is_readable($yoo_btn_css_path)) ? (string) filemtime($yoo_btn_css_path) : '1';
$js_url = $base_file ? plugin_dir_url($base_file) . 'assets/js/login/yoo-standalone-login.js' : '';
$js_path = $base_file ? plugin_dir_path($base_file) . 'assets/js/login/yoo-standalone-login.js' : '';
$js_ver = ($js_path && is_readable($js_path)) ? (string) filemtime($js_path) : '1';

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noindex, nofollow" />
    <title><?php
    if ($sl_is_revalidate && is_array($sl_revalidate_session)) {
        echo esc_html(sprintf(/* translators: %s: site name */ __('Verify your identity — %s', 'yooadmin'), $site_name));
    } elseif ($show_rp_form) {
        echo esc_html(sprintf(/* translators: %s: site name */ __('Reset password — %s', 'yooadmin'), $site_name));
    } else {
        echo esc_html(sprintf(/* translators: %s: site name */ __('Log in to %s', 'yooadmin'), $site_name));
    }
    ?></title>
    <?php
    if ($bundled_welcome_bg_url !== '') {
        echo '<link rel="preload" as="image" href="' . esc_url($bundled_welcome_bg_url) . '" fetchpriority="high" />' . "\n";
    }
    if ($yoo_btn_css_url !== '') {
        echo '<link rel="stylesheet" href="' . esc_url($yoo_btn_css_url) . '?ver=' . esc_attr($yoo_btn_css_ver) . '" />' . "\n";
    }
    if ($css_url !== '') {
        echo '<link rel="stylesheet" href="' . esc_url($css_url) . '?ver=' . esc_attr($css_ver) . '" />' . "\n";
    }
    if (function_exists('includes_url')) {
        echo '<link rel="stylesheet" href="' . esc_url(includes_url('css/dashicons.min.css')) . '?ver=' . esc_attr(get_bloginfo('version')) . '" />' . "\n";
    }
    if (function_exists('yooadmin_custom_login_print_head_assets')) {
        yooadmin_custom_login_print_head_assets();
    }
    if (function_exists('yooadmin_custom_login_print_standalone_inline_vars')) {
        yooadmin_custom_login_print_standalone_inline_vars();
    }
    if (function_exists('yooadmin_login_toolbar_print_assets')) {
        yooadmin_login_toolbar_print_assets();
    }
    if ($bundled_welcome_bg_url !== '' && $has_visual_media_bg) {
        echo '<style id="yooadmin-standalone-login-welcome-fallback">body.yooadmin-login-standalone .yoo-sl-media{--yoo-sl-welcome-bg-image:url(\''
            . esc_url($bundled_welcome_bg_url, ['http', 'https'])
            . '\');}</style>' . "\n";
    }

    $sl_turnstile_enabled = function_exists('yooadmin_login_turnstile_should_render') && yooadmin_login_turnstile_should_render();
    $sl_turnstile_site_key = $sl_turnstile_enabled && function_exists('yooadmin_login_turnstile_site_key')
        ? yooadmin_login_turnstile_site_key()
        : '';
    if ($sl_turnstile_enabled && $sl_turnstile_site_key !== '') {
        if (function_exists('yooadmin_enqueue_cloudflare_turnstile_script')) {
            yooadmin_enqueue_cloudflare_turnstile_script();
        }
        if (function_exists('wp_print_scripts')) {
            wp_print_scripts(['cloudflare-turnstile']);
        }
    }
    ?>
    <script>
        window.yooadminSlAjax = <?php echo wp_json_encode(
            [
                'ajaxUrl' => function_exists('yooadmin_admin_ajax_url')
                    ? yooadmin_admin_ajax_url()
                    : admin_url('admin-ajax.php'),
                'nonce'   => wp_create_nonce('yooadmin_sl_ajax'),
                'actions' => [
                    'login'                => 'yooadmin_sl_login',
                    'lostpassword'         => 'yooadmin_sl_lostpassword',
                    'resetpass'            => 'yooadmin_sl_resetpass',
                    'validate_2fa'         => 'yooadmin_sl_validate_2fa',
                    'two_factor_challenge' => 'yooadmin_sl_two_factor_challenge',
                ],
                'turnstile' => [
                    'enabled'             => $sl_turnstile_enabled && $sl_turnstile_site_key !== '',
                    'siteKey'             => $sl_turnstile_site_key,
                    'protectLostPassword' => function_exists('yooadmin_login_turnstile_protect_lostpassword') && yooadmin_login_turnstile_protect_lostpassword(),
                    'language'            => function_exists('yooadmin_login_turnstile_client_language')
                        ? yooadmin_login_turnstile_client_language()
                        : 'en',
                    'render'              => function_exists('yooadmin_login_turnstile_client_render_config')
                        ? yooadmin_login_turnstile_client_render_config()
                        : [
                            'theme'      => 'light',
                            'size'       => 'normal',
                            'appearance' => 'interaction-only',
                            'language'   => 'en',
                        ],
                    'displayMode'         => function_exists('yooadmin_login_turnstile_display_mode')
                        ? yooadmin_login_turnstile_display_mode()
                        : 'minimal',
                ],
                'i18n'    => [
                    'captchaRequired'   => __('Please complete the security check.', 'yooadmin'),
                    'securityChecking'  => __('Security verification in progress…', 'yooadmin'),
                    'securityVerified'  => __('Security verification complete', 'yooadmin'),
                    'securityFailed'    => __('Security verification failed. Please try again.', 'yooadmin'),
                    'securityChallenge' => __('Please complete the security check below.', 'yooadmin'),
                    'securityTimeout'   => __('Security check timed out. Try again or disable VPN/proxy.', 'yooadmin'),
                    'securityBlocked'   => __('Security service could not load. Check your connection or VPN.', 'yooadmin'),
                    'securityRetry'     => __('Try again', 'yooadmin'),
                    'network'        => __('Network error. Please try again.', 'yooadmin'),
                    'badResponse'    => __('Unexpected response. Please refresh the page.', 'yooadmin'),
                    'dismiss'        => __('Dismiss', 'yooadmin'),
                    'sessionExpired' => __('Your session has expired. Please refresh the page and try again.', 'yooadmin'),
                    'emptyUsername'  => __('The username field is empty.', 'yooadmin'),
                    'emptyPassword'  => __('The password field is empty.', 'yooadmin'),
                    'emptyResetUser' => __('Enter a username or email address.', 'yooadmin'),
                    'showPassword'      => __('Show password', 'yooadmin'),
                    'hidePassword'      => __('Hide password', 'yooadmin'),
                    'twoFactorRequired'  => __('Two-factor authentication required.', 'yooadmin'),
                    'twoFactorVerify'    => __('Verify', 'yooadmin'),
                    'twoFactorBack'      => __('Back to sign in', 'yooadmin'),
                    'twoFactorExpired'   => __('Your verification session expired. Please sign in again.', 'yooadmin'),
                    'twoFactorResent'    => __('A new verification code has been sent.', 'yooadmin'),
                    'twoFactorResend'    => __('Resend code', 'yooadmin'),
                    /* translators: %d: number of seconds to wait before the code can be resent. */
                    'twoFactorResendWait'=> __('Resend code (%ds)', 'yooadmin'),
                    'twoFactorCodeLabel' => __('Authentication code', 'yooadmin'),
                    /* translators: 1: position of the current digit, 2: total number of digits. */
                    'twoFactorDigit'     => __('Digit %1$d of %2$d', 'yooadmin'),
                    'twoFactorIncomplete'=> __('Enter the full 6-digit code.', 'yooadmin'),
                    'twoFactorLeadDefault' => __('Enter your verification code to continue.', 'yooadmin'),
                    'twoFactorLeadTotp'    => __('Enter the code from your authenticator app.', 'yooadmin'),
                    'twoFactorLeadEmail'   => __('A verification code has been sent to your email address.', 'yooadmin'),
                    'twoFactorLeadBackup'  => __('Enter one of your recovery codes.', 'yooadmin'),
                    'invalidResetLink'     => __('Your password reset link appears to be invalid.', 'yooadmin'),
                    'expiredResetLink'     => __('Your password reset link has expired.', 'yooadmin'),
                    'passwordMismatch'     => __('The passwords do not match.', 'yooadmin'),
                    'passwordResetEmpty'   => __('Please enter a password.', 'yooadmin'),
                    'passwordResetSuccess' => __('Your password has been reset.', 'yooadmin'),
                    'resetEmailSent'       => __('Check your email for a link to reset your password.', 'yooadmin'),
                    'loginFailed'          => __('Login failed. Please try again.', 'yooadmin'),
                    'incorrectPassword'    => __('The password you entered is incorrect.', 'yooadmin'),
                ],
            ],
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        ); ?>;
    </script>
    <?php if (is_array($sl_revalidate_session)) : ?>
    <script>
        window.yooadminSlBootstrapTwoFactor = <?php echo wp_json_encode(
            $sl_revalidate_session,
            JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        ); ?>;
    </script>
    <?php endif; ?>
</head>
<body class="yooadmin-login-standalone yoo-standalone-login<?php echo esc_attr($sl_dark_class); ?> <?php echo esc_attr($side_class); ?><?php echo $no_logo ? ' yoo-sl--no-logo' : ''; ?><?php echo $bundled_welcome_bg_url !== '' ? ' yoo-sl--has-welcome-bg' : ''; ?><?php echo esc_attr($sl_ar_class); ?><?php echo ($sl_is_revalidate && is_array($sl_revalidate_session)) ? ' yoo-sl--revalidate' : ''; ?>" data-yoo-sl-initial="<?php echo esc_attr($sl_initial_view); ?>" data-yoo-login-color-mode="<?php echo esc_attr($sl_color_mode); ?>" data-yoo-login-color-mode-effective="<?php echo esc_attr($sl_color_effective); ?>"<?php echo ($sl_is_revalidate && is_array($sl_revalidate_session)) ? ' data-yoo-sl-revalidate="1"' : ''; ?><?php echo $sl_forgot_password_inline ? ' data-yoo-sl-forgot-inline="1"' : ''; ?>>
    <?php
    if (function_exists('yooadmin_standalone_login_get_notices_html')) {
        echo yooadmin_standalone_login_get_notices_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from esc_html in helper.
    }
    if (function_exists('yooadmin_login_toolbar_render')) {
        yooadmin_login_toolbar_render();
    }
    ?>
    <div class="yoo-sl-wrap">
        <div class="yoo-sl-media<?php echo $has_visual_media_bg ? '' : ' yoo-sl-media--no-image'; ?>" role="presentation">
            <?php if ($img_url !== '') : ?>
                <div class="yoo-sl-media__img-wrap"><img class="yoo-sl-media__img" src="<?php echo esc_url($img_url); ?>" alt="" /></div>
            <?php endif; ?>
            <div class="yoo-sl-welcome<?php echo $has_visual_media_bg ? ' yoo-sl-welcome--over-image' : ''; ?>">
                <div class="yoo-sl-welcome__glass">
                    <p class="yoo-sl-welcome__text">
                        <?php
                        echo esc_html(
                            apply_filters(
                                'yooadmin_standalone_login_welcome_text',
                                sprintf(
                                    /* translators: %s: site name */
                                    __('Welcome back. Sign in to %s to continue.', 'yooadmin'),
                                    $site_name !== '' ? $site_name : __('this site', 'yooadmin')
                                )
                            )
                        );
                        ?>
                    </p>
                </div>
            </div>
        </div>
        <div class="yoo-sl-panel">
            <div class="yoo-sl-form-card">
                <h1 class="yoo-sl-title">
                    <a class="yoo-sl-logo-link" href="<?php echo esc_url(home_url('/')); ?>">
                        <?php if ($no_logo) : ?>
                            <span class="yoo-sl-logo-text"><?php echo esc_html($site_name); ?></span>
                        <?php elseif ($use_dual_logos) : ?>
                            <img
                                class="yoo-sl-logo-img yoo-sl-logo-img--light"
                                src="<?php echo esc_url($logo_url); ?>"
                                alt="<?php echo esc_attr($site_name); ?>"
                                loading="eager"
                                decoding="async"
                            />
                            <img
                                class="yoo-sl-logo-img yoo-sl-logo-img--dark"
                                src="<?php echo esc_url($logo_dark_url); ?>"
                                alt="<?php echo esc_attr($site_name); ?>"
                                loading="eager"
                                decoding="async"
                            />
                        <?php else : ?>
                            <img
                                class="yoo-sl-logo-img"
                                src="<?php echo esc_url($logo_url !== '' ? $logo_url : $logo_dark_url); ?>"
                                alt="<?php echo esc_attr($site_name); ?>"
                                loading="eager"
                                decoding="async"
                            />
                        <?php endif; ?>
                    </a>
                </h1>

                <div class="yoo-sl-views">
                    <div id="yoo-sl-view-login" class="yoo-sl-view yoo-sl-view--login<?php echo ($sl_initial_view === 'login') ? ' is-active' : ''; ?>"<?php echo ($sl_initial_view === 'login') ? '' : ' hidden'; ?>>
                        <form class="yoo-sl-form" name="loginform" id="loginform" method="post" action="<?php echo esc_url($form_action); ?>" novalidate data-yoo-sl-ajax-form="login">
                            <p class="yoo-sl-field yoo-sl-field--with-icon">
                                <label class="screen-reader-text" for="user_login"><?php esc_html_e('Username or Email Address', 'yooadmin'); ?></label>
                                <span class="yoo-sl-field__icon dashicons dashicons-admin-users" aria-hidden="true"></span>
                                <input
                                    type="text"
                                    name="log"
                                    id="user_login"
                                    class="yoo-sl-input yoo-sl-input--with-icon"
                                    value=""
                                    autocapitalize="off"
                                    autocomplete="username"
                                    required="required"
                                    placeholder="<?php esc_attr_e('Username or Email Address', 'yooadmin'); ?>"
                                />
                            </p>
                            <p class="yoo-sl-field yoo-sl-field--with-icon yoo-sl-field--password">
                                <label class="screen-reader-text" for="user_pass"><?php esc_html_e('Password', 'yooadmin'); ?></label>
                                <span class="yoo-sl-field__icon dashicons dashicons-lock" aria-hidden="true"></span>
                                <input
                                    type="password"
                                    name="pwd"
                                    id="user_pass"
                                    class="yoo-sl-input yoo-sl-input--with-icon"
                                    value=""
                                    autocomplete="current-password"
                                    spellcheck="false"
                                    required="required"
                                    placeholder="<?php esc_attr_e('Password', 'yooadmin'); ?>"
                                />
                                <button type="button" class="yoo-sl-pw-toggle" aria-pressed="false" aria-label="<?php esc_attr_e('Show password', 'yooadmin'); ?>"></button>
                            </p>
                            <p class="yoo-sl-remember">
                                <label class="yoo-sl-check">
                                    <input class="yoo-sl-check__input" name="rememberme" type="checkbox" id="rememberme" value="forever" />
                                    <span class="yoo-sl-check__label"><?php esc_html_e('Remember me', 'yooadmin'); ?></span>
                                </label>
                            </p>
                            <?php if ($sl_turnstile_enabled && $sl_turnstile_site_key !== '') : ?>
                            <div class="yoo-sl-turnstile-wrap is-pending" data-yoo-turnstile-wrap="login" data-yoo-turnstile-state="pending">
                                <p class="yoo-sl-turnstile-status" role="status" aria-live="polite">
                                    <span class="yoo-sl-turnstile-status__icon dashicons dashicons-shield-alt" aria-hidden="true"></span>
                                    <span class="yoo-sl-turnstile-status__spinner" aria-hidden="true"></span>
                                    <span class="yoo-sl-turnstile-status__text" dir="auto"><?php esc_html_e('Security verification in progress…', 'yooadmin'); ?></span>
                                </p>
                                <div class="yoo-sl-turnstile-host">
                                    <span class="yoo-sl-turnstile" data-yoo-turnstile-context="login" aria-hidden="false"></span>
                                </div>
                                <button type="button" class="yoo-sl-turnstile-retry" hidden>
                                    <?php esc_html_e('Try again', 'yooadmin'); ?>
                                </button>
                            </div>
                            <?php endif; ?>
                            <p class="yoo-sl-submit">
                                <input type="submit" name="wp-submit" id="wp-submit" class="yoo-sl-btn yoo-sl-btn--primary yp-yoo-btn yp-yoo-btn--primary" value="<?php esc_attr_e('Sign in', 'yooadmin'); ?>" />
                            </p>
                            <input type="hidden" name="testcookie" value="1" />
                            <?php if ($redirect_to !== '') : ?>
                                <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>" />
                            <?php endif; ?>
                        </form>
                        <nav class="yoo-sl-footer-links" aria-label="<?php esc_attr_e('Login footer', 'yooadmin'); ?>">
                            <div class="yoo-sl-footer-links__main">
                                <a class="yoo-sl-footer-item yoo-sl-footer-item--link" href="<?php echo esc_url(home_url('/')); ?>" title="<?php echo esc_attr(sprintf(/* translators: %s: site name */ __('Home — %s', 'yooadmin'), $site_name !== '' ? $site_name : get_bloginfo('name', 'display'))); ?>">
                                    <span class="yoo-sl-footer-ic dashicons dashicons-admin-site" aria-hidden="true"></span>
                                    <span class="yoo-sl-footer-txt"><?php echo esc_html($site_name !== '' ? $site_name : get_bloginfo('name', 'display')); ?></span>
                                </a>
                                <span class="yoo-sl-footer-sep" aria-hidden="true"></span>
                                <a class="yoo-sl-text-btn yoo-sl-footer-item" id="yoo-sl-toggle-reset" href="<?php echo esc_url($sl_lostpassword_url); ?>">
                                    <span class="yoo-sl-footer-ic dashicons dashicons-email-alt" aria-hidden="true"></span>
                                    <span class="yoo-sl-footer-txt"><?php esc_html_e('Forgot password?', 'yooadmin'); ?></span>
                                </a>
                            </div>
                            <?php if (function_exists('yooadmin_login_toolbar_render_cf_attribution')) : ?>
                                <div class="yoo-sl-footer-links__meta">
                                    <?php yooadmin_login_toolbar_render_cf_attribution(); ?>
                                </div>
                            <?php endif; ?>
                        </nav>
                    </div>

                    <div id="yoo-sl-view-2fa" class="yoo-sl-view yoo-sl-view--2fa<?php echo ($sl_initial_view === '2fa') ? ' is-active is-loading' : ''; ?>"<?php echo ($sl_initial_view === '2fa') ? '' : ' hidden'; ?>>
                        <div class="yoo-sl-2fa-header">
                            <span class="yoo-sl-2fa-header__icon dashicons dashicons-shield-alt" aria-hidden="true"></span>
                            <p class="yoo-sl-2fa-lead" id="yoo-sl-2fa-lead"><?php esc_html_e('Enter your verification code to continue.', 'yooadmin'); ?></p>
                        </div>
                        <p class="yoo-sl-2fa-provider" id="yoo-sl-2fa-provider" hidden></p>
                        <div class="yoo-sl-2fa-fragment" id="yoo-sl-2fa-fragment" hidden></div>
                        <form class="yoo-sl-form" name="twofactorform" id="twofactorform" method="post" action="#" novalidate data-yoo-sl-ajax-form="validate_2fa"<?php echo ($sl_initial_view === '2fa') ? ' hidden' : ''; ?>>
                            <div class="yoo-sl-2fa-fields" id="yoo-sl-2fa-fields"></div>
                            <p class="yoo-sl-submit yoo-sl-submit--2fa">
                                <input
                                    type="submit"
                                    name="wp-submit-2fa"
                                    id="wp-submit-2fa"
                                    class="yoo-sl-btn yoo-sl-btn--primary yp-yoo-btn yp-yoo-btn--primary"
                                    value="<?php esc_attr_e('Verify', 'yooadmin'); ?>"
                                    disabled="disabled"
                                    aria-label="<?php esc_attr_e('Verify authentication code', 'yooadmin'); ?>"
                                />
                            </p>
                        </form>
                        <?php if ($sl_initial_view === '2fa') : ?>
                        <div class="yoo-sl-2fa-loading" id="yoo-sl-2fa-loading" role="status" aria-live="polite" aria-busy="true">
                            <span class="yoo-sl-2fa-loading__spinner" aria-hidden="true"></span>
                            <span class="yoo-sl-2fa-loading__text"><?php esc_html_e('Loading verification…', 'yooadmin'); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="yoo-sl-2fa-actions" id="yoo-sl-2fa-actions"<?php echo ($sl_initial_view === '2fa') ? ' hidden' : ''; ?>></div>
                        <nav class="yoo-sl-2fa-alternates" id="yoo-sl-2fa-alternates" aria-label="<?php esc_attr_e('Other verification methods', 'yooadmin'); ?>"<?php echo ($sl_initial_view === '2fa') ? ' hidden' : ''; ?>></nav>
                        <nav class="yoo-sl-footer-links" aria-label="<?php esc_attr_e('Two-factor footer', 'yooadmin'); ?>">
                            <div class="yoo-sl-footer-links__main">
                                <button type="button" class="yoo-sl-text-btn yoo-sl-footer-item" id="yoo-sl-toggle-login-from-2fa">
                                    <span class="yoo-sl-footer-ic dashicons dashicons-arrow-left-alt" aria-hidden="true"></span>
                                    <span class="yoo-sl-footer-txt"><?php esc_html_e('Back to sign in', 'yooadmin'); ?></span>
                                </button>
                            </div>
                        </nav>
                    </div>

                    <div id="yoo-sl-view-reset" class="yoo-sl-view yoo-sl-view--reset<?php echo ($sl_initial_view === 'reset') ? ' is-active' : ''; ?>"<?php echo ($sl_initial_view === 'reset') ? '' : ' hidden'; ?>>
                        <p class="yoo-sl-reset-lead"><?php esc_html_e('Enter your username or email address. We will send you a link to set a new password.', 'yooadmin'); ?></p>
                        <form class="yoo-sl-form" name="lostpasswordform" id="lostpasswordform" method="post" action="<?php echo esc_url($lostpassword_action); ?>" novalidate data-yoo-sl-ajax-form="lostpassword">
                            <p class="yoo-sl-field yoo-sl-field--with-icon">
                                <label class="screen-reader-text" for="yoo_sl_user_login_reset"><?php esc_html_e('Username or Email Address', 'yooadmin'); ?></label>
                                <span class="yoo-sl-field__icon dashicons dashicons-admin-users" aria-hidden="true"></span>
                                <input
                                    type="text"
                                    name="user_login"
                                    id="yoo_sl_user_login_reset"
                                    class="yoo-sl-input yoo-sl-input--with-icon"
                                    value=""
                                    autocapitalize="off"
                                    autocomplete="username"
                                    required="required"
                                    placeholder="<?php esc_attr_e('Username or Email Address', 'yooadmin'); ?>"
                                />
                            </p>
                            <?php
                            $sl_turnstile_reset = $sl_turnstile_enabled && $sl_turnstile_site_key !== ''
                                && function_exists('yooadmin_login_turnstile_protect_lostpassword')
                                && yooadmin_login_turnstile_protect_lostpassword();
                            ?>
                            <?php if ($sl_turnstile_reset) : ?>
                            <div class="yoo-sl-turnstile-wrap is-pending" data-yoo-turnstile-wrap="lostpassword" data-yoo-turnstile-state="pending">
                                <p class="yoo-sl-turnstile-status" role="status" aria-live="polite">
                                    <span class="yoo-sl-turnstile-status__icon dashicons dashicons-shield-alt" aria-hidden="true"></span>
                                    <span class="yoo-sl-turnstile-status__spinner" aria-hidden="true"></span>
                                    <span class="yoo-sl-turnstile-status__text" dir="auto"><?php esc_html_e('Security verification in progress…', 'yooadmin'); ?></span>
                                </p>
                                <div class="yoo-sl-turnstile-host">
                                    <span class="yoo-sl-turnstile" data-yoo-turnstile-context="lostpassword" aria-hidden="false"></span>
                                </div>
                                <button type="button" class="yoo-sl-turnstile-retry" hidden>
                                    <?php esc_html_e('Try again', 'yooadmin'); ?>
                                </button>
                            </div>
                            <?php endif; ?>
                            <p class="yoo-sl-submit">
                                <input type="submit" name="wp-submit" id="yoo-sl-submit-reset" class="yoo-sl-btn yoo-sl-btn--primary yp-yoo-btn yp-yoo-btn--primary" value="<?php esc_attr_e('Send reset link', 'yooadmin'); ?>" />
                            </p>
                            <?php if ($redirect_to !== '') : ?>
                                <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>" />
                            <?php endif; ?>
                        </form>
                        <nav class="yoo-sl-footer-links" aria-label="<?php esc_attr_e('Password reset footer', 'yooadmin'); ?>">
                            <div class="yoo-sl-footer-links__main">
                                <a class="yoo-sl-footer-item yoo-sl-footer-item--link" href="<?php echo esc_url(home_url('/')); ?>" title="<?php echo esc_attr(sprintf(/* translators: %s: site name */ __('Home — %s', 'yooadmin'), $site_name !== '' ? $site_name : get_bloginfo('name', 'display'))); ?>">
                                    <span class="yoo-sl-footer-ic dashicons dashicons-admin-site" aria-hidden="true"></span>
                                    <span class="yoo-sl-footer-txt"><?php echo esc_html($site_name !== '' ? $site_name : get_bloginfo('name', 'display')); ?></span>
                                </a>
                                <span class="yoo-sl-footer-sep" aria-hidden="true"></span>
                                <button type="button" class="yoo-sl-text-btn yoo-sl-footer-item" id="yoo-sl-toggle-login">
                                    <span class="yoo-sl-footer-ic dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span>
                                    <span class="yoo-sl-footer-txt"><?php esc_html_e('Back to sign in', 'yooadmin'); ?></span>
                                </button>
                            </div>
                            <?php if (function_exists('yooadmin_login_toolbar_render_cf_attribution')) : ?>
                                <div class="yoo-sl-footer-links__meta">
                                    <?php yooadmin_login_toolbar_render_cf_attribution(); ?>
                                </div>
                            <?php endif; ?>
                        </nav>
                    </div>

                    <div id="yoo-sl-view-rp" class="yoo-sl-view yoo-sl-view--rp<?php echo ($sl_initial_view === 'rp') ? ' is-active' : ''; ?>"<?php echo ($sl_initial_view === 'rp') ? '' : ' hidden'; ?>>
                        <?php if ($show_rp_form) : ?>
                            <p class="yoo-sl-reset-lead"><?php esc_html_e('Enter your new password below.', 'yooadmin'); ?></p>
                            <form class="yoo-sl-form" name="resetpassform" id="resetpassform" method="post" action="<?php echo esc_url($resetpass_action); ?>" autocomplete="off" novalidate data-yoo-sl-ajax-form="resetpass">
                                <p class="yoo-sl-field yoo-sl-field--with-icon yoo-sl-field--password">
                                    <label class="screen-reader-text" for="pass1"><?php esc_html_e('New password', 'yooadmin'); ?></label>
                                    <span class="yoo-sl-field__icon dashicons dashicons-lock" aria-hidden="true"></span>
                                    <input
                                        type="password"
                                        name="pass1"
                                        id="pass1"
                                        class="yoo-sl-input yoo-sl-input--with-icon"
                                        value=""
                                        autocomplete="new-password"
                                        spellcheck="false"
                                        required="required"
                                        placeholder="<?php esc_attr_e('New password', 'yooadmin'); ?>"
                                    />
                                    <button type="button" class="yoo-sl-pw-toggle" aria-pressed="false" aria-label="<?php esc_attr_e('Show password', 'yooadmin'); ?>"></button>
                                </p>
                                <p class="yoo-sl-field yoo-sl-field--with-icon yoo-sl-field--password">
                                    <label class="screen-reader-text" for="pass2"><?php esc_html_e('Confirm new password', 'yooadmin'); ?></label>
                                    <span class="yoo-sl-field__icon dashicons dashicons-lock" aria-hidden="true"></span>
                                    <input
                                        type="password"
                                        name="pass2"
                                        id="pass2"
                                        class="yoo-sl-input yoo-sl-input--with-icon"
                                        value=""
                                        autocomplete="new-password"
                                        spellcheck="false"
                                        required="required"
                                        placeholder="<?php esc_attr_e('Confirm new password', 'yooadmin'); ?>"
                                    />
                                    <button type="button" class="yoo-sl-pw-toggle" aria-pressed="false" aria-label="<?php esc_attr_e('Show password', 'yooadmin'); ?>"></button>
                                </p>
                                <p class="yoo-sl-hint"><?php echo wp_kses_post(wp_get_password_hint()); ?></p>
                                <input type="hidden" name="rp_key" value="<?php echo esc_attr($rp_key); ?>" />
                                <input type="hidden" name="rp_login" value="<?php echo esc_attr($rp_login); ?>" />
                                <?php if ($sl_turnstile_enabled && $sl_turnstile_site_key !== '') : ?>
                                <div class="yoo-sl-turnstile-wrap is-pending" data-yoo-turnstile-wrap="resetpass" data-yoo-turnstile-state="pending">
                                    <p class="yoo-sl-turnstile-status" role="status" aria-live="polite">
                                        <span class="yoo-sl-turnstile-status__icon dashicons dashicons-shield-alt" aria-hidden="true"></span>
                                        <span class="yoo-sl-turnstile-status__spinner" aria-hidden="true"></span>
                                        <span class="yoo-sl-turnstile-status__text" dir="auto"><?php esc_html_e('Security verification in progress…', 'yooadmin'); ?></span>
                                    </p>
                                    <div class="yoo-sl-turnstile-host">
                                        <span class="yoo-sl-turnstile" data-yoo-turnstile-context="resetpass" aria-hidden="false"></span>
                                    </div>
                                    <button type="button" class="yoo-sl-turnstile-retry" hidden>
                                        <?php esc_html_e('Try again', 'yooadmin'); ?>
                                    </button>
                                </div>
                                <?php endif; ?>
                                <p class="yoo-sl-submit">
                                    <input type="submit" name="wp-submit" id="yoo-sl-submit-rp" class="yoo-sl-btn yoo-sl-btn--primary yp-yoo-btn yp-yoo-btn--primary" value="<?php esc_attr_e('Save Password', 'yooadmin'); ?>" />
                                </p>
                            </form>
                        <?php endif; ?>
                        <nav class="yoo-sl-footer-links" aria-label="<?php esc_attr_e('Reset password footer', 'yooadmin'); ?>">
                            <div class="yoo-sl-footer-links__main">
                                <a class="yoo-sl-footer-item yoo-sl-footer-item--link" href="<?php echo esc_url(home_url('/')); ?>" title="<?php echo esc_attr(sprintf(/* translators: %s: site name */ __('Home — %s', 'yooadmin'), $site_name !== '' ? $site_name : get_bloginfo('name', 'display'))); ?>">
                                    <span class="yoo-sl-footer-ic dashicons dashicons-admin-site" aria-hidden="true"></span>
                                    <span class="yoo-sl-footer-txt"><?php echo esc_html($site_name !== '' ? $site_name : get_bloginfo('name', 'display')); ?></span>
                                </a>
                                <span class="yoo-sl-footer-sep" aria-hidden="true"></span>
                                <a class="yoo-sl-text-btn yoo-sl-footer-item" href="<?php echo esc_url(function_exists('yooadmin_standalone_login_public_url') ? yooadmin_standalone_login_public_url() : yooadmin_standalone_login_url()); ?>">
                                    <span class="yoo-sl-footer-ic dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span>
                                    <span class="yoo-sl-footer-txt"><?php esc_html_e('Back to sign in', 'yooadmin'); ?></span>
                                </a>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
            <?php
            $yooadmin_footer_link = apply_filters(
                'yooadmin_standalone_login_footer_plugin_url',
                defined('YOOADMIN_SITE_URL') ? YOOADMIN_SITE_URL : 'https://www.yooadmin.io'
            );
            $yooadmin_footer_ver = defined('YOOADMIN_VERSION') ? (string) YOOADMIN_VERSION : '';
            if ($yooadmin_footer_ver !== '') :
                ?>
                <p class="yoo-sl-version">
                    <a class="yoo-sl-version__link" href="<?php echo esc_url($yooadmin_footer_link); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(sprintf(/* translators: %s: plugin version */ __('YOOAdmin %s', 'yooadmin'), $yooadmin_footer_ver)); ?></a>
                </p>
            <?php endif; ?>
        </div>
    </div>
    <?php if ($js_url !== '') : ?>
        <script src="<?php echo esc_url($js_url) . '?ver=' . esc_attr($js_ver); ?>" defer></script>
    <?php endif; ?>
<?php
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals
// phpcs:enable WordPress.WP.EnqueuedResources
// phpcs:enable WordPress.Security.NonceVerification.Recommended -- End standalone template PHPCS exceptions.
?>
</body>
</html>
