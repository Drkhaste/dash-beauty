<?php
/**
 * YOOAdmin - Popup container (dynamic submenu markup)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;
?>
<div id="yp-popup" class="yp-popup ysh-adapt-skip" aria-hidden="true" style="display:none;">
  <div class="yp-popup-box-wrapper">
    <div class="yp-popup-box" role="dialog" aria-modal="true" aria-labelledby="yp-popup-title">
      <button class="yp-modal-close yp-popup-close" type="button" onclick="ypClosePopup()" aria-label="<?php echo esc_attr__('Close', 'yooadmin'); ?>">
        <span class="dashicons dashicons-no-alt"></span>
      </button>
      <div class="yp-popup-header">
        <div class="yp-popup-header-content">
          <span class="yp-popup-icon" id="yp-popup-icon"></span>
          <h2 id="yp-popup-title"></h2>
        </div>
      </div>
      <div id="yp-popup-content" class="yoopixel-popup-grid"></div>
    </div>
  </div>
</div>
