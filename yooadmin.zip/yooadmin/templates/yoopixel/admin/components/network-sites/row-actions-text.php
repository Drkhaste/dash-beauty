<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

if (empty($site_actions) || !is_array($site_actions)) {
    return;
}

?>
<div class="yoo-network-sites-row-actions" role="group" aria-label="<?php esc_attr_e('Site actions', 'yooadmin'); ?>">
  <?php
  $rendered = 0;
  foreach ($site_actions as $action) :
      $label  = isset($action['label']) ? (string) $action['label'] : '';
      $url    = isset($action['url']) ? (string) $action['url'] : '';
      $target = isset($action['target']) ? (string) $action['target'] : '';
      if ($label === '' || $url === '') {
          continue;
      }
      if ($rendered > 0) :
          ?>
      <span class="yoo-network-sites-row-actions__sep" aria-hidden="true">|</span>
          <?php
      endif;
      $classes = 'yoo-network-sites-row-actions__link';
      if (!empty($action['danger'])) {
          $classes .= ' yoo-network-sites-row-actions__link--danger';
      }
      ++$rendered;
      ?>
    <a class="<?php echo esc_attr($classes); ?>"
       href="<?php echo esc_url($url); ?>"
        <?php if ($target !== '') : ?>
       target="<?php echo esc_attr($target); ?>" rel="noopener noreferrer"
        <?php endif; ?>>
      <?php echo esc_html($label); ?>
    </a>
  <?php endforeach; ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
