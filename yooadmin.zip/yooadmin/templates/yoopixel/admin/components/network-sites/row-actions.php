<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

if (empty($site_actions) || !is_array($site_actions)) {
    return;
}

$visible_count = isset($visible_count) ? (int) $visible_count : 2;

if (count($site_actions) > $visible_count) {
    $primary_actions  = array_slice($site_actions, -$visible_count);
    $overflow_actions = array_slice($site_actions, 0, count($site_actions) - $visible_count);
    $has_overflow     = true;
} else {
    $primary_actions  = $site_actions;
    $overflow_actions = [];
    $has_overflow     = false;
}

$render_action = static function (array $action): void {
    $action_classes = function_exists('yooadmin_network_sites_row_action_class')
        ? yooadmin_network_sites_row_action_class($action)
        : 'yp-network-sites-card__action-btn';
    $action_target  = isset($action['target']) ? (string) $action['target'] : '';
    $confirm        = !empty($action['confirm']) && is_array($action['confirm']) ? $action['confirm'] : null;
    $href           = isset($action['url']) ? (string) $action['url'] : '';
    if ($confirm) {
        $href = '#';
    }
    ?>
  <a class="<?php echo esc_attr($action_classes); ?>"
     href="<?php echo esc_url($href); ?>"
     aria-label="<?php echo esc_attr((string) $action['label']); ?>"
     title="<?php echo esc_attr((string) $action['label']); ?>"
      <?php if ($confirm) : ?>
     role="button"
     data-yoo-site-confirm-action="<?php echo esc_attr((string) ($confirm['action'] ?? '')); ?>"
     data-yoo-site-confirm-id="<?php echo esc_attr((string) ($confirm['id'] ?? '')); ?>"
     data-yoo-site-confirm-nonce="<?php echo esc_attr((string) ($confirm['nonce'] ?? '')); ?>"
     data-yoo-site-confirm-message="<?php echo esc_attr((string) ($confirm['message'] ?? '')); ?>"
     data-yoo-site-confirm-notice="<?php echo esc_attr((string) ($confirm['notice'] ?? '')); ?>"
     data-yoo-site-confirm-label="<?php echo esc_attr((string) ($confirm['confirm_label'] ?? '')); ?>"
      <?php endif; ?>
      <?php if ($action_target !== '') : ?>
     target="<?php echo esc_attr($action_target); ?>" rel="noopener noreferrer"
      <?php endif; ?>>
    <span class="dashicons <?php echo esc_attr((string) $action['icon']); ?>" aria-hidden="true"></span>
  </a>
    <?php
};
?>
<div class="yp-network-sites-card__actions">
  <?php if ($has_overflow) : ?>
    <div class="yp-network-sites-card__actions-more">
      <div class="yp-network-sites-card__actions-overflow">
        <?php foreach ($overflow_actions as $action) {
            $render_action($action);
        } ?>
      </div>
      <button type="button"
              class="yp-network-sites-card__action-btn yp-network-sites-card__actions-toggle"
              aria-expanded="false"
              aria-label="<?php esc_attr_e('More actions', 'yooadmin'); ?>"
              title="<?php esc_attr_e('More actions', 'yooadmin'); ?>">
        <span class="dashicons dashicons-ellipsis" aria-hidden="true"></span>
      </button>
    </div>
  <?php endif; ?>

  <?php foreach ($primary_actions as $action) {
      $render_action($action);
  } ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
