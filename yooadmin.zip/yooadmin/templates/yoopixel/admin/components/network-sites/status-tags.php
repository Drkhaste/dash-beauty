<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

$status_tags = [];
if (!empty($site) && is_array($site)) {
    if (!empty($site['status_tags']) && is_array($site['status_tags'])) {
        $status_tags = $site['status_tags'];
    } elseif (!empty($site['status']) && is_array($site['status'])) {
        foreach ($site['status'] as $label) {
            $label = (string) $label;
            if ($label === '') {
                continue;
            }
            $status_tags[] = [
                'slug'  => sanitize_title($label),
                'label' => $label,
            ];
        }
    }
}

if (!$status_tags) {
    return;
}
?>
<span class="yoo-network-sites-status-wrap" data-yoo-site-status>
<span class="yoo-network-sites-status-list">
  <?php foreach ($status_tags as $tag) :
      $slug  = isset($tag['slug']) ? sanitize_html_class((string) $tag['slug']) : '';
      $label = isset($tag['label']) ? (string) $tag['label'] : '';
      if ($label === '') {
          continue;
      }
      $class = 'yoo-network-sites-status';
      if ($slug !== '') {
          $class .= ' yoo-network-sites-status--' . $slug;
      }
      ?>
    <span class="<?php echo esc_attr($class); ?>"><?php echo esc_html($label); ?></span>
  <?php endforeach; ?>
</span>
</span>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
