<?php
/**
 * YOOAdmin — read-only license status modal (non-admin shell users).
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

if (
    !function_exists('yooadmin_should_show_shell_license_status')
    || !yooadmin_should_show_shell_license_status()
    || (
        function_exists('yooadmin_user_can_manage_site_settings')
        && yooadmin_user_can_manage_site_settings()
    )
) {
    return;
}

$yooadmin_license_shell = function_exists('yooadmin_get_shell_license_status')
    ? yooadmin_get_shell_license_status()
    : [];
?>
<div id="yp-license-status-info-modal" class="yp-modal" style="display:none;" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="yp-license-status-info-title">
    <div class="yp-modal-overlay"></div>
    <div class="yp-modal-content">
        <button type="button" class="yp-modal-close" aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
            <span class="dashicons dashicons-no-alt"></span>
        </button>
        <div class="yp-modal-header">
            <span class="dashicons <?php echo esc_attr((string) ($yooadmin_license_shell['modal_icon'] ?? 'dashicons-info')); ?> yp-modal-icon yp-modal-icon--<?php echo esc_attr((string) ($yooadmin_license_shell['modal_type'] ?? 'info')); ?>"></span>
            <h2 id="yp-license-status-info-title" class="yp-modal-title"><?php echo esc_html((string) ($yooadmin_license_shell['modal_title'] ?? __('YOOAdmin License', 'yooadmin'))); ?></h2>
        </div>
        <div class="yp-modal-body">
            <p class="yp-modal-details"><?php echo esc_html((string) ($yooadmin_license_shell['modal_message'] ?? '')); ?></p>
        </div>
        <div class="yp-modal-footer">
            <button type="button" class="yp-yoo-btn yp-yoo-btn--primary yp-modal-close-info"><?php esc_html_e('Close', 'yooadmin'); ?></button>
        </div>
    </div>
</div>
