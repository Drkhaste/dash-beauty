<?php
/**
 * YOOAdmin - Section: Top grid (Welcome + Quick Actions)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

$base = dirname(__DIR__); // points to .../components
?>
<div class="yp-dashboard-grid" data-yooadmin-top-section="true" data-yoocustom-protected="true">
    <?php
    // Welcome card
    $welcome = $base . '/cards/card-welcome.php';
    if (file_exists($welcome)) {
        include $welcome;
    }

    // Quick Actions card
    $actions = $base . '/cards/card-actions.php';
    if (file_exists($actions)) {
        include $actions;
    }
    ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
