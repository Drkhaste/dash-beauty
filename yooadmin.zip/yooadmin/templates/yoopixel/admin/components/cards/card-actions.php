<?php
/**
 * YOOAdmin - Card: Quick Actions
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

/** 1) Defaults (single-site; not Network Admin) */
$defaults = function_exists('yooadmin_dashboard_quick_actions_defaults')
    ? yooadmin_dashboard_quick_actions_defaults()
    : [
        [
            'label'  => __('Add Post', 'yooadmin'),
            'url'    => admin_url('post-new.php'),
            'icon'   => 'dashicons-welcome-write-blog',
            'target' => '_self',
        ],
        [
            'label'  => __('Add Page', 'yooadmin'),
            'url'    => admin_url('post-new.php?post_type=page'),
            'icon'   => 'dashicons-admin-page',
            'target' => '_self',
        ],
        [
            'label'  => __('Media', 'yooadmin'),
            'url'    => admin_url('upload.php'),
            'icon'   => 'dashicons-admin-media',
            'target' => '_self',
        ],
        [
            'label'  => __('Users', 'yooadmin'),
            'url'    => admin_url('admin.php?page=yooadmin-users'),
            'icon'   => 'dashicons-groups',
            'target' => '_self',
        ],
        [
            'label'  => __('Comments', 'yooadmin'),
            'url'    => admin_url('edit-comments.php'),
            'icon'   => 'dashicons-admin-comments',
            'target' => '_self',
        ],
        [
            'label'  => __('Settings', 'yooadmin'),
            'url'    => admin_url('admin.php?page=yooadmin-settings'),
            'icon'   => 'dashicons-admin-settings',
            'target' => '_self',
        ],
    ];
$base_defaults = $defaults;

/** 2) Load personal / site quick actions for the current user */
$items = function_exists('yooadmin_get_quick_actions_for_current_user')
    ? yooadmin_get_quick_actions_for_current_user()
    : $defaults;

if (function_exists('yooadmin_filter_items_by_admin_href_capability')) {
    $display_defaults = yooadmin_filter_items_by_admin_href_capability($defaults, 'url');
} else {
    $display_defaults = $defaults;
}

$yooadmin_can_edit_quick_actions = function_exists('yooadmin_user_can_edit_quick_actions')
    && yooadmin_user_can_edit_quick_actions();
?>
<div class="yp-card yp-card-full"
     data-quick-actions-card
     data-default-actions="<?php echo esc_attr(wp_json_encode($display_defaults)); ?>">
    <div class="yp-card-header">
        <h2 class="yp-card-title">
            <span class="dashicons dashicons-admin-tools" aria-hidden="true"></span>
            <?php echo esc_html__('Quick Actions', 'yooadmin'); ?>
        </h2>
        <?php if ($yooadmin_can_edit_quick_actions) : ?>
        <div class="yp-card-toolbar qa-toolbar">
            <button type="button"
                    class="qa-reset"
                    data-icon-edit-reset="quick-actions"
                    hidden>
                <?php esc_html_e('Reset', 'yooadmin'); ?>
            </button>
            <button type="button"
                    class="qa-toggle"
                    data-qa-toggle
                    data-label-edit="<?php echo esc_attr__('Edit', 'yooadmin'); ?>"
                    data-label-done="<?php echo esc_attr__('Done', 'yooadmin'); ?>"
                    aria-pressed="false"
                    aria-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>">
                <span class="dashicons dashicons-edit" aria-hidden="true"></span>
            </button>
        </div>
        <?php endif; ?>
    </div>

    <div class="yp-quick-actions-loading">
        <div class="yp-loading-spinner">
            <div class="yp-spinner-circle"></div>
        </div>
    </div>

    <div class="yp-action-grid yp-quick-actions" data-quick-actions-grid data-max-items="5" style="display: none;">
        <?php
        $rendered = 0;
        foreach ($items as $it):
            if ($rendered >= 5) {
                break;
            }
            $rendered++;
            $label       = isset($it['label']) ? (string) $it['label'] : '';
            $url         = isset($it['url']) ? (string) $it['url'] : '';
            $icon        = isset($it['icon']) ? (string) $it['icon'] : 'dashicons-admin-links';
            $target      = isset($it['target']) ? (string) $it['target'] : '_blank';
            $aria_label  = isset($it['aria_label']) ? (string) $it['aria_label'] : '';
            if ($label === '' || $url === '') {
                continue;
            }
        ?>
        <div class="qa-tile"
             data-qa-label="<?php echo esc_attr($label); ?>"
             data-qa-url="<?php echo esc_url($url); ?>"
             data-qa-icon="<?php echo esc_attr($icon); ?>"
             data-qa-target="<?php echo esc_attr($target === '_self' ? '_self' : '_blank'); ?>"
             <?php if ($aria_label !== '') : ?>
             data-qa-aria-label="<?php echo esc_attr($aria_label); ?>"
             <?php endif; ?>>
            <a href="<?php echo esc_url($url); ?>"
               class="yp-icon-tile qa-tile-link"
               target="<?php echo ($target === '_self') ? '_self' : '_blank'; ?>"
               rel="<?php echo ($target === '_blank') ? 'noopener noreferrer' : 'nofollow'; ?>"
               <?php if ($aria_label !== '') : ?>
               aria-label="<?php echo esc_attr($aria_label); ?>"
               <?php endif; ?>>
                <span class="dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
                <span class="yp-icon-label"><?php echo esc_html($label); ?></span>
            </a>
            <div class="qa-tile-actions" aria-hidden="true">
                <button type="button" class="qa-tile-edit" aria-label="<?php esc_attr_e('Edit quick action', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-edit"></span>
                </button>
                <button type="button" class="qa-tile-delete" aria-label="<?php esc_attr_e('Delete quick action', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-trash"></span>
                </button>
            </div>
        </div>
        <?php endforeach; ?>

        <?php if ($yooadmin_can_edit_quick_actions) : ?>
        <button type="button"
                class="yp-icon-tile qa-add-tile"
                data-qa-add
                aria-label="<?php esc_attr_e('Add quick action', 'yooadmin'); ?>">
            <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
            <span class="yp-icon-label"><?php esc_html_e('Add', 'yooadmin'); ?></span>
        </button>
        <?php endif; ?>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
