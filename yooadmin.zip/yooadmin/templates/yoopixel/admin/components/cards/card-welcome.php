<?php
/**
 * YOOAdmin - Card: Welcome
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

/** 1) Defaults */
$defaults = [
    'title' => __('Welcome to YOOAdmin — The Clean Admin Experience', 'yooadmin'),
    'p1'    => __('Your dashboard is now faster, smarter, and fully branded for your business.', 'yooadmin'),
    'p2'    => __('Access tools, manage your services, and keep your website running smoothly — all from one clean interface. If you need help, support is just a click away.', 'yooadmin'),
];

/** 2) Option overrides (if present) */
$opt  = (array) get_option('yooadmin_welcome', []);
$data = array_merge($defaults, array_intersect_key($opt, $defaults));

/** 3) External filter (company/master plugin) */
$data = apply_filters('yooadmin_card_welcome_content', $data);

$welcome_links = [
    [
        'icon'  => 'dashicons-admin-generic',
        'label' => __('Customize', 'yooadmin'),
        'url'   => admin_url('admin.php?page=yooadmin-settings'),
    ],
    [
        'icon'  => 'dashicons-admin-appearance',
        'label' => __('Theme Colors', 'yooadmin'),
        'url'   => admin_url('admin.php?page=yooadmin-admin-theme-settings'),
    ],
    [
        'icon'   => 'dashicons-warning',
        'label'  => __('Report Bug', 'yooadmin'),
        'url'    => 'https://www.yooadmin.io/report-bug',
        'target' => '_blank',
    ],
];

/**
 * Filter: allow overriding / extending welcome links.
 *
 * Each item: ['icon' => dashicon-class, 'label' => string, 'url' => string]
 */
$welcome_links = apply_filters('yooadmin_card_welcome_links', $welcome_links);
?>
<div class="yp-card yp-card-full yp-card-welcome-wrapper"
     data-welcome-card
     data-default-welcome="<?php echo esc_attr(wp_json_encode($defaults)); ?>">
    <div class="yp-card-header yp-welcome-header">
        <h2 class="yp-card-welcome">
            <span class="dashicons dashicons-welcome-view-site" aria-hidden="true"></span>
            <?php echo esc_html($data['title']); ?>
        </h2>
        <?php if (current_user_can('manage_options')): ?>
            <div class="yp-card-toolbar qa-toolbar yp-welcome-toolbar">
                <button type="button"
                        class="qa-toggle yp-welcome-toggle"
                        data-welcome-toggle
                        data-label-edit="<?php echo esc_attr__('Edit', 'yooadmin'); ?>"
                        data-label-done="<?php echo esc_attr__('Done', 'yooadmin'); ?>"
                        aria-pressed="false"
                        aria-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-edit" aria-hidden="true"></span>
                </button>
            </div>
        <?php endif; ?>
    </div>
    <p class="yp-card-text"><strong><?php echo esc_html($data['p1']); ?></strong></p>
    <p class="yp-card-text"><?php echo esc_html($data['p2']); ?></p>

    <?php
    if (function_exists('yooadmin_render_welcome_site_context')) {
        yooadmin_render_welcome_site_context();
    }
    ?>

    <?php if (!empty($welcome_links) && is_array($welcome_links)) : ?>
        <div class="yp-welcome-links">
            <?php foreach ($welcome_links as $link) :
                $label = isset($link['label']) ? (string) $link['label'] : '';
                $url   = isset($link['url'])   ? (string) $link['url']   : '';
                $icon  = isset($link['icon'])  ? (string) $link['icon']  : 'dashicons-admin-links';
                $class = isset($link['class']) ? (string) $link['class'] : '';
                $target = isset($link['target']) ? (string) $link['target'] : '';
                $attrs = isset($link['attrs']) && is_array($link['attrs']) ? $link['attrs'] : [];
                if ($label === '' || $url === '') {
                    continue;
                }
                ?>
                <a href="<?php echo esc_url($url); ?>" 
                   class="yp-welcome-link<?php echo $class !== '' ? ' ' . esc_attr($class) : ''; ?>"
                   <?php if ($target): ?>target="<?php echo esc_attr($target); ?>" rel="noopener noreferrer"<?php endif; ?>
                   <?php foreach ($attrs as $attr_name => $attr_value) : ?>
                       <?php echo esc_attr((string) $attr_name); ?>="<?php echo esc_attr((string) $attr_value); ?>"
                   <?php endforeach; ?>>
                    <span class="dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
                    <span class="yp-welcome-link-label"><?php echo esc_html($label); ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
