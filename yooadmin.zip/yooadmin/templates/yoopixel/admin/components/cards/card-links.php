<?php
/**
 * YOOAdmin - Card: Website Management
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

/** Get menu tree (data-only) */
$menu_tree = [];
if (function_exists('yooadmin_build_admin_menu_tree')) {
    $menu_tree = (array) yooadmin_build_admin_menu_tree();
}

/** Small inline sanitizer for data attributes (no global helpers here) */
$slug_key = static function ($slug) {
    $k = strtolower(preg_replace('~[^a-zA-Z0-9_\-\.]~', '_', (string) $slug));
    return $k ?: 'menu';
};

$extract_badge = static function (string $title): array {
    $clean = trim($title);
    $badge = '';

    if ($clean === '') {
        return ['title' => $clean, 'badge' => $badge];
    }

    if (preg_match('/^(.*?)[(（]\s*(\d+)\s*[)）]\s*$/u', $clean, $m)) {
        $clean = trim($m[1]);
        $badge = $m[2];
    } elseif (preg_match('/^(.*?\D)(\d+)\s*$/u', $clean, $m)) {
        $clean = trim($m[1]);
        $badge = $m[2];
    } elseif (preg_match('/^\s*(\d+)\s+(.+)$/u', $clean, $m)) {
        $rest = strtolower(trim($m[2]));
        if (preg_match('/(?:update|updates|pending|comment|comments|order|orders|plugin|plugins|review|reviews|message|messages|draft|drafts)\b/', $rest)) {
            $badge = $m[1];
            $clean = trim($m[2]);
        }
    }

    return ['title' => $clean, 'badge' => $badge];
};

$map_group = static function (string $slug, string $url): string {
    $slug_l = strtolower($slug);
    $url_l  = strtolower($url);

    if (strpos($slug_l, 'plugins.php') !== false || strpos($url_l, 'plugins.php') !== false) {
        return 'wp-plugin-updates';
    }
    if (strpos($slug_l, 'yooadmin-plugins') !== false || strpos($url_l, 'yooadmin-plugins') !== false) {
        return 'wp-plugin-updates';
    }
    if (strpos($slug_l, 'themes.php') !== false || strpos($url_l, 'themes.php') !== false) {
        return 'wp-theme-updates';
    }
    if (strpos($slug_l, 'update-core') !== false || strpos($url_l, 'update-core') !== false) {
        if (strpos($url_l, 'tab=translations') !== false) {
            return 'wp-translation-updates';
        }
        return 'wp-core-update';
    }
    if (strpos($slug_l, 'edit-comments.php') !== false || strpos($url_l, 'edit-comments.php') !== false) {
        return 'wp-comments-pending';
    }
    if (strpos($slug_l, 'edit.php') !== false && strpos($slug_l, 'post_type=shop_order') !== false) {
        return 'wp-order-updates';
    }

    return '';
};
?>
<div class="yp-card yp-card-full yp-dashboard-section" 
     data-section-id="website-management"
     data-collapsible="true"
     data-sortable="true"
     data-collapsed="false">
  <div class="yp-card-header yp-section-header">
    <h2 class="yp-card-title yp-section-title">
      <span class="dashicons dashicons-admin-site" aria-hidden="true"></span>
      <?php echo esc_html__('Website Management', 'yooadmin'); ?>
    </h2>
    <div class="yp-card-header-actions">
      <button type="button"
              class="yp-card-edit-reset"
              data-icon-edit-reset="main-grid">
        <?php esc_html_e('Reset', 'yooadmin'); ?>
      </button>
      <button type="button"
              class="yp-card-edit-toggle"
              data-icon-edit-toggle="main-grid"
              data-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>"
              data-active-label="<?php echo esc_attr__('Done', 'yooadmin'); ?>"
              aria-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>">
        <span class="dashicons dashicons-edit" aria-hidden="true"></span>
      </button>
    </div>
  </div>

  <div class="yp-website-management-loading">
    <div class="yp-loading-spinner">
      <div class="yp-spinner-circle"></div>
    </div>
  </div>

  <div class="yp-icon-grid-boxes yp-cards-grid" 
       data-layout="grid" 
       data-columns="auto"
       data-sortable="true"
       style="display: none;">
    <?php foreach ($menu_tree as $item): ?>
      <?php
        $title   = isset($item['title']) ? (string) $item['title'] : '';
        $url     = isset($item['url'])   ? (string) $item['url']   : '';
        $icon    = isset($item['icon'])  ? (string) $item['icon']  : '';
        $slug    = isset($item['slug'])  ? (string) $item['slug']  : '';
        $has_sub = !empty($item['has_sub']);

        if ($title === '' || $url === '') {
            continue;
        }

        $parsed = $extract_badge($title);
        $clean_title = $parsed['title'];
        $badge_value = $parsed['badge'];
        $group_key = $map_group($slug, $url);
        // Show badge only when there are updates (count > 0), never show "0" on dashboard
        $has_badge = $badge_value !== '' && (int) $badge_value > 0;
        $key_seed = $slug !== '' ? $slug : $url;
        $card_key = 'main-' . $slug_key($key_seed);
        $is_external = (strpos($url, 'http://') === 0 || strpos($url, 'https://') === 0) && strpos($url, admin_url()) !== 0;
      ?>
      <a
        href="<?php echo esc_url($url); ?>"
        <?php if ($is_external): ?>target="_blank" rel="noopener noreferrer"<?php endif; ?>
        class="yp-icon-tile<?php echo $has_badge ? ' has-badge' : ''; ?>"
        data-card-key="<?php echo esc_attr($card_key); ?>"
        data-card-id="<?php echo esc_attr($card_key); ?>"
        data-draggable="true"
        data-resizable="true"
        data-size="normal"
        <?php if ($has_badge): ?>
          data-badge="<?php echo esc_attr($badge_value); ?>"
        <?php endif; ?>
        <?php if ($group_key !== ''): ?>
          data-feed-group="<?php echo esc_attr($group_key); ?>"
        <?php endif; ?>
        <?php if ($has_sub): ?>
          data-menu-slug="<?php echo esc_attr($slug_key($slug)); ?>"
          data-card-title="<?php echo esc_attr($clean_title); ?>"
        <?php endif; ?>
        title="<?php echo esc_attr($clean_title); ?>"
        data-default-icon="<?php echo esc_attr($icon); ?>"
      >
        <span class="yp-icon">
          <?php if (strpos($icon, 'dashicons-') === 0): ?>
            <span class="dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
          <?php elseif (strpos($icon, 'data:image/svg+xml') === 0): ?>
            <?php
              // Extract SVG from data URI and render inline for instant display (no loading delay)
              $svg_content = '';
              if (preg_match('/data:image\/svg\+xml(?:;base64)?,(.+)/', $icon, $matches)) {
                $encoded = $matches[1];
                if (strpos($icon, 'base64') !== false) {
                  $svg_content = @base64_decode($encoded, true);
                } else {
                  $svg_content = @urldecode($encoded);
                }
                // Only output if valid SVG content
                if ($svg_content && strpos(trim($svg_content), '<svg') === 0) {
                  // Force width and height to prevent size changes - match dashicons size (46px)
                  // First, remove existing width/height if present
                  $svg_content = preg_replace('/\s+(width|height)=["\'][^"\']*["\']/i', '', $svg_content);
                  // Add width and height attributes + inline style to prevent any CSS from shrinking it
                  // Add class to prevent card-icons-fix.js from converting to mask-image
                  $svg_content = preg_replace(
                    '/<svg([^>]*)>/i',
                    '<svg$1 width="46" height="46" class="ypi-skip-mask" style="width:46px !important;height:46px !important;max-width:46px !important;max-height:46px !important;min-width:46px !important;min-height:46px !important;display:block;margin:0;padding:0;flex-shrink:0;box-sizing:border-box;">',
                    $svg_content
                  );
                  // Sanitize SVG output (WordPress security)
                  echo wp_kses($svg_content, [
                    'svg' => [
                      'xmlns' => true,
                      'viewbox' => true,
                      'viewBox' => true,
                      'width' => true,
                      'height' => true,
                      'class' => true,
                      'style' => true,
                    ],
                    'path' => [
                      'd' => true,
                      'fill' => true,
                      'stroke' => true,
                      'stroke-width' => true,
                      'class' => true,
                    ],
                    'circle' => ['cx' => true, 'cy' => true, 'r' => true, 'fill' => true],
                    'rect' => ['x' => true, 'y' => true, 'width' => true, 'height' => true, 'fill' => true],
                    'g' => ['fill' => true, 'class' => true],
                  ]);
                } else {
                  // Fallback to img if decode fails
                  echo '<img src="' . esc_url($icon) . '" alt="" loading="eager" decoding="async" />';
                }
              } else {
                echo '<img src="' . esc_url($icon) . '" alt="" loading="eager" decoding="async" />';
              }
            ?>
          <?php elseif (strpos($icon, 'http') === 0 || strpos($icon, 'data:') === 0): ?>
            <img src="<?php echo esc_url($icon); ?>" alt="" loading="eager" decoding="async" />
          <?php else: ?>
            <span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
          <?php endif; ?>
        </span>
        <span class="yp-icon-label"><?php echo esc_html($clean_title); ?></span>
        <?php if ($group_key !== ''): ?>
          <span class="yp-card-badge" data-feed-group="<?php echo esc_attr($group_key); ?>"
                <?php if (!$has_badge) : ?>hidden<?php endif; ?>>
            <?php echo $has_badge ? esc_html($badge_value) : ''; ?>
          </span>
        <?php elseif ($has_badge): ?>
          <span class="yp-card-badge"
                <?php if (!$has_badge) : ?>hidden<?php endif; ?>>
            <?php echo esc_html($badge_value); ?>
          </span>
        <?php endif; ?>
        <span class="yp-card-icon-edit"
              role="button"
              tabindex="0"
              aria-label="<?php esc_attr_e('Change icon', 'yooadmin'); ?>"
              data-card-key="<?php echo esc_attr($card_key); ?>">
          <span class="dashicons dashicons-edit" aria-hidden="true"></span>
        </span>
      </a>
    <?php endforeach; ?>
  </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
