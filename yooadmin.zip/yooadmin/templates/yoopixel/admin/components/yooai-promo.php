<?php
/**
 * YOOAi promotional FAB + modal markup.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

$yooadmin_fab_hidden = class_exists('YOOAdmin_YOOAi_Promo') && YOOAdmin_YOOAi_Promo::is_fab_hidden_for_user();
?>
<div
    id="yooai-fab"
    class="yooai-fab<?php echo esc_attr($yooadmin_fab_hidden ? ' is-hidden' : ''); ?>"
    role="complementary"
    aria-label="<?php esc_attr_e('YOOAi assistant', 'yooadmin'); ?>"
    <?php if ($yooadmin_fab_hidden) : ?> hidden<?php endif; ?>
>
    <button type="button" class="yooai-fab__dismiss" data-yooai-fab-dismiss aria-label="<?php esc_attr_e('Hide YOOAi button', 'yooadmin'); ?>">
        <span aria-hidden="true">&times;</span>
    </button>
    <button type="button" class="yooai-fab__trigger" data-yooai-open aria-label="<?php esc_attr_e('Open YOOAi', 'yooadmin'); ?>">
        <span class="yooai-fab__pulse" aria-hidden="true"></span>
        <span class="yooai-fab__label">YOOAi</span>
    </button>
</div>

<div id="yooai-modal" class="yooai-modal" hidden aria-hidden="true">
    <div class="yooai-modal__backdrop" data-yooai-close tabindex="-1"></div>
    <div class="yooai-modal__panel" role="dialog" aria-modal="true" aria-labelledby="yooai-modal-title">
        <header class="yooai-modal__header">
            <div class="yooai-modal__brand">
                <span class="yooai-modal__logo" aria-hidden="true">AI</span>
                <span class="yooai-modal__title-wrap">
                    <h2 id="yooai-modal-title" class="yooai-modal__title"><?php esc_html_e('YOOAi', 'yooadmin'); ?></h2>
                    <span class="yooai-modal__badge"><?php esc_html_e('Coming soon', 'yooadmin'); ?></span>
                </span>
            </div>
            <button type="button" class="yooai-modal__close" data-yooai-close aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
                <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
            </button>
        </header>

        <div class="yooai-modal__messages" data-yooai-messages role="log" aria-live="polite" aria-relevant="additions"></div>

    </div>
</div>
