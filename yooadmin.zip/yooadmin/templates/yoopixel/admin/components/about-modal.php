<?php
/**
 * YOOAdmin - About modal (shown on dashboard)
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

$yooadmin_support_links = [
    ['label' => __('Official Website', 'yooadmin'), 'url' => 'https://www.yooadmin.io', 'icon' => 'dashicons-admin-site'],
    ['label' => __('Documentation', 'yooadmin'), 'url' => 'https://www.yooadmin.io/docs', 'icon' => 'dashicons-book'],
    ['label' => __('Support', 'yooadmin'), 'url' => 'https://www.yooadmin.io/contact', 'icon' => 'dashicons-sos'],
    ['label' => __('Privacy Policy', 'yooadmin'), 'url' => 'https://www.yooadmin.io/privacy-policy', 'icon' => 'dashicons-shield'],
];
?>
<div id="yp-about-modal" class="yp-about-overlay" style="display:none;" aria-hidden="true" data-yp-about-close>
    <div class="yp-about-content" onclick="event.stopPropagation()">
        <button type="button" class="yp-modal-close yp-about-close" aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
            <span class="dashicons dashicons-no-alt"></span>
        </button>
        <div class="yp-about-body">
            <h1 class="yp-about-title"><?php esc_html_e('YOOAdmin', 'yooadmin'); ?></h1>
            <h2 class="yp-about-subtitle"><?php esc_html_e('About YOOAdmin', 'yooadmin'); ?></h2>
            <p class="yp-about-intro"><?php esc_html_e('YOOAdmin enhances the WordPress admin experience with a cleaner interface, better organization, and a more focused workflow.', 'yooadmin'); ?></p>

            <div class="yp-about-resources">
                <h4 class="yp-about-resources-title"><?php esc_html_e('Support & Resources', 'yooadmin'); ?></h4>
                <div class="yp-about-resources-list">
                    <?php foreach ($yooadmin_support_links as $link) : ?>
                        <a href="<?php echo esc_url($link['url']); ?>" target="_blank" rel="noopener noreferrer" class="yp-about-resource-link">
                            <span class="dashicons <?php echo esc_attr($link['icon']); ?>" aria-hidden="true"></span>
                            <span class="yp-about-resource-label"><?php echo esc_html($link['label']); ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <p class="yp-about-credit">
                <?php echo esc_html__('Developed with', 'yooadmin'); ?>
                <span class="yp-heart" aria-hidden="true">♥</span>
                <?php echo esc_html__('by', 'yooadmin'); ?>
                <a href="<?php echo esc_url('https://www.yoopixel.com'); ?>" target="_blank" rel="noopener noreferrer">YOOPixel</a>
            </p>
        </div>
    </div>
</div>
