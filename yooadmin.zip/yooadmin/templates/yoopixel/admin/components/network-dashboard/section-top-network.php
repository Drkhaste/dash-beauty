<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$user    = wp_get_current_user();
$display = ($user && $user->exists()) ? $user->display_name : __('Admin', 'yooadmin');
$welcome_ts   = current_time('timestamp');
$welcome_date = wp_date((string) get_option('date_format', 'M j, Y'), $welcome_ts);
$welcome_time = wp_date('h:i:s A', $welcome_ts);

$welcome_links = function_exists('yooadmin_network_dashboard_welcome_links')
    ? yooadmin_network_dashboard_welcome_links()
    : [];

$cards_dir = function_exists('yooadmin_network_dashboard_template_path')
    ? yooadmin_network_dashboard_template_path('components/network-dashboard')
    : '';
?>
<div class="yp-dashboard-grid" data-yooadmin-top-section="true" data-yoocustom-protected="true" data-layout-locked="true">
  <div class="yp-card yp-card-full yp-card-welcome-wrapper yp-card-welcome-studio yp-studio-welcome-mock">
    <div class="yp-studio-welcome-mock__inner">
      <div class="yp-card-header yp-welcome-header yp-section-header yp-studio-welcome-mock__header">
        <h2 class="yp-card-welcome"><?php esc_html_e('Network Dashboard', 'yooadmin'); ?></h2>
      </div>
      <p class="yp-card-text yp-studio-welcome-mock__line1">
        <?php
        /* translators: %s: user display name. */
        echo esc_html(sprintf(__('Hi %s! 👋', 'yooadmin'), $display));
        ?>
      </p>
      <div class="yp-studio-welcome-mock__meta-row">
        <p class="yp-card-text yp-studio-welcome-mock__line2">
          <?php esc_html_e('Manage your multisite network from one focused workspace.', 'yooadmin'); ?>
        </p>
        <div class="yp-studio-welcome-mock__datetime">
          <time class="yp-studio-welcome-mock__datetime-inner">
            <span class="yp-studio-welcome-mock__datetime-date"><?php echo esc_html($welcome_date); ?></span>
            <span class="yp-studio-welcome-mock__datetime-time"><?php echo esc_html($welcome_time); ?></span>
          </time>
        </div>
      </div>

      <?php if (!empty($welcome_links) && is_array($welcome_links)) : ?>
        <div class="yp-studio-welcome-mock__footer-spacer" aria-hidden="true"></div>
        <div class="yp-welcome-links yp-studio-welcome-mock__links">
          <?php foreach ($welcome_links as $link) :
              $w_label  = isset($link['label']) ? (string) $link['label'] : '';
              $w_url    = isset($link['url']) ? (string) $link['url'] : '';
              $w_icon   = isset($link['icon']) ? (string) $link['icon'] : 'dashicons-admin-links';
              $w_target = isset($link['target']) ? (string) $link['target'] : '';
              if ($w_label === '' || $w_url === '') {
                  continue;
              }
              ?>
            <a href="<?php echo esc_url($w_url); ?>"
               class="yp-welcome-link"
                <?php if ($w_target !== '') : ?>
               target="<?php echo esc_attr($w_target); ?>" rel="noopener noreferrer"
                <?php endif; ?>>
              <span class="dashicons <?php echo esc_attr($w_icon); ?>" aria-hidden="true"></span>
              <span class="yp-welcome-link-label"><?php echo esc_html($w_label); ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <?php
  $actions = $cards_dir ? $cards_dir . '/card-actions-network.php' : '';
  if ($actions && is_readable($actions)) {
      include $actions;
  }
  ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
