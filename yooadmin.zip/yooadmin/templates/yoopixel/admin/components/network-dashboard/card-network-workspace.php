<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$menu_tree = isset($menu_tree) && is_array($menu_tree) ? $menu_tree : [];
if (!$menu_tree && function_exists('yooadmin_network_dashboard_resolve_menu_tree')) {
    $menu_tree = yooadmin_network_dashboard_resolve_menu_tree();
}
$hidden_attr = function_exists('yooadmin_network_dashboard_section_hidden_attrs')
    ? yooadmin_network_dashboard_section_hidden_attrs('network-workspace', $layout ?? null)
    : '';

$slug_key = static function ($slug) {
    $k = strtolower(preg_replace('~[^a-zA-Z0-9_\-\.]~', '_', (string) $slug));
    return $k ?: 'menu';
};

$extract_badge = static function (string $title): array {
    $clean = trim($title);
    $badge = '';
    if ($clean !== '' && preg_match('/^(.*?)[(（]\s*(\d+)\s*[)）]\s*$/u', $clean, $m)) {
        $clean = trim($m[1]);
        $badge = $m[2];
    } elseif ($clean !== '' && preg_match('/^(.*?\D)(\d+)\s*$/u', $clean, $m)) {
        $clean = trim($m[1]);
        $badge = $m[2];
    }
    if ($badge !== '' && (int) $badge <= 0) {
        $badge = '';
    }
    if ($badge === '') {
        $clean = trim((string) preg_replace('/\s+0\s*$/u', '', $clean));
    }
    return ['title' => $clean, 'badge' => $badge];
};

$map_group = static function (string $slug, string $url): string {
    $slug_l = strtolower($slug);
    $url_l  = strtolower($url);
    if (strpos($slug_l, 'plugins.php') !== false || strpos($url_l, 'plugins.php') !== false || strpos($slug_l, 'yooadmin-plugins') !== false) {
        return 'wp-plugin-updates';
    }
    if (strpos($slug_l, 'themes.php') !== false || strpos($url_l, 'themes.php') !== false) {
        return 'wp-theme-updates';
    }
    if (strpos($slug_l, 'sites.php') !== false || strpos($url_l, 'sites.php') !== false) {
        return '';
    }
    return '';
};

$row_partial = '';
if (defined('YOOADMIN_PLUGIN_FILE')) {
    $candidate = plugin_dir_path(YOOADMIN_PLUGIN_FILE) . 'themes/yooadmin-studio-hub/templates/components/partials/studio-hub-workspace-row.php';
    if (is_readable($candidate)) {
        $row_partial = $candidate;
    }
}

$tile_prefix = 'network';
?>
<div class="yp-card yp-card-full yp-dashboard-section yp-studio-surface-card"
     data-section-id="network-workspace"
     data-layout-section="true"
     data-collapsible="true"
     data-sortable="true"
     data-collapsed="false"
     data-default-section-icon="dashicons-admin-multisite"<?php echo $hidden_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
  <div class="yp-card-header yp-section-header yp-layout-section-handle">
    <span class="yp-layout-section-drag-handle" aria-hidden="true">
      <span class="dashicons dashicons-move" aria-hidden="true"></span>
    </span>
    <h2 class="yp-card-title yp-section-title">
      <span class="dashicons dashicons-admin-multisite" aria-hidden="true"></span>
      <?php esc_html_e('Network Workspace', 'yooadmin'); ?>
    </h2>
    <div class="yp-card-header-actions">
      <button type="button" class="yp-section-visibility-toggle" data-network-section-visibility="network-workspace" aria-pressed="false" hidden>
        <span class="dashicons dashicons-hidden" aria-hidden="true"></span>
      </button>
      <button type="button"
              class="yp-card-edit-reset"
              data-icon-edit-reset="main-grid">
        <?php esc_html_e('Reset', 'yooadmin'); ?>
      </button>
      <button type="button"
              class="yp-card-edit-toggle"
              data-icon-edit-toggle="network-layout"
              data-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>"
              data-active-label="<?php echo esc_attr__('Done', 'yooadmin'); ?>"
              aria-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>">
        <span class="dashicons dashicons-edit" aria-hidden="true"></span>
      </button>
    </div>
  </div>

  <div class="yp-studio-section-body">
    <div class="yp-website-management-loading yp-studio-section-loading" aria-hidden="false">
      <div class="yp-loading-spinner">
        <div class="yp-spinner-circle"></div>
      </div>
    </div>

    <div class="yp-icon-grid-boxes yp-cards-grid yp-studio-workspace-grid yp-studio-workspace-rows"
         data-layout="grid"
         data-columns="auto"
         data-sortable="true">
      <?php
      if ($menu_tree && $row_partial) {
          foreach ($menu_tree as $item) {
              if (!is_array($item)) {
                  continue;
              }
              include $row_partial;
          }
      } elseif ($menu_tree) {
          foreach ($menu_tree as $item) {
              if (!is_array($item) || empty($item['url']) || empty($item['title'])) {
                  continue;
              }
              $icon = isset($item['icon']) ? (string) $item['icon'] : 'dashicons-admin-generic';
              $slug = isset($item['slug']) ? (string) $item['slug'] : '';
              $has_sub = !empty($item['has_sub']) || !empty($item['subs']);
              $parsed = $extract_badge((string) $item['title']);
              ?>
              <a class="yp-icon-tile yp-studio-ws-row" href="<?php echo esc_url((string) $item['url']); ?>"
                <?php if ($has_sub && $slug !== '') : ?>
                  data-menu-slug="<?php echo esc_attr($slug_key($slug)); ?>"
                  data-card-title="<?php echo esc_attr($parsed['title']); ?>"
                <?php endif; ?>>
                <span class="yp-icon yp-studio-ws-row__icon-well">
                  <span class="dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
                </span>
                <span class="yp-studio-ws-row__copy">
                  <span class="yp-icon-label"><?php echo esc_html((string) $parsed['title']); ?></span>
                </span>
              </a>
              <?php
          }
      } else {
          ?>
          <p class="yp-card-text"><?php esc_html_e('No network menu items are available for your account.', 'yooadmin'); ?></p>
          <?php
      }
      ?>
    </div>
  </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
