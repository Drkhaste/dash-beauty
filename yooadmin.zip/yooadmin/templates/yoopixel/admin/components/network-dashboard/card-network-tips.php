<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$hidden_attr = function_exists('yooadmin_network_dashboard_section_hidden_attrs')
    ? yooadmin_network_dashboard_section_hidden_attrs('network-tips', $layout ?? null)
    : '';

$tips = function_exists('yooadmin_network_dashboard_get_tips')
    ? yooadmin_network_dashboard_get_tips()
    : [];

if (!$tips && function_exists('yooadmin_studio_hub_get_network_tips')) {
    $tips = yooadmin_studio_hub_get_network_tips();
}
?>
<div class="yp-studio-aside-card yp-studio-aside-card--tips yp-dashboard-section yp-studio-aside-layout-section"
     data-section-id="network-tips"
     data-layout-section="true"
     data-collapsible="false"
     data-sortable="true"
     data-collapsed="false"
     data-custom-placement="aside"<?php echo $hidden_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
  <div class="yp-card-header yp-section-header yp-layout-section-handle yp-studio-tips-section__header">
    <span class="yp-layout-section-drag-handle" aria-hidden="true">
      <span class="dashicons dashicons-move" aria-hidden="true"></span>
    </span>
    <h2 class="yp-card-title yp-section-title yp-studio-aside-section__title yp-studio-tips-section__title">
      <span class="dashicons dashicons-lightbulb" aria-hidden="true"></span>
      <span class="yp-studio-tips-section__title-text"><?php esc_html_e('Tips', 'yooadmin'); ?></span>
    </h2>
    <div class="yp-card-header-actions">
      <button type="button" class="yp-section-visibility-toggle" data-network-section-visibility="network-tips" aria-pressed="false" hidden>
        <span class="dashicons dashicons-hidden" aria-hidden="true"></span>
      </button>
    </div>
  </div>
  <div class="yp-studio-aside-section__body yp-studio-tips-section__body">
    <?php if ($tips) : ?>
      <div
        class="yp-studio-tips-carousel"
        data-studio-tips-carousel="true"
        data-autoplay-ms="6500"
        aria-live="polite"
      >
        <div class="yp-studio-tips-carousel__track">
          <?php foreach ($tips as $index => $tip) : ?>
            <?php
            $theme = isset($tip['theme']) ? (string) $tip['theme'] : 'brand';
            $icon  = isset($tip['icon']) ? (string) $tip['icon'] : 'dashicons-lightbulb';
            $image = isset($tip['image']) ? (string) $tip['image'] : '';
            ?>
            <article
              class="yp-studio-tip-slide<?php echo $index === 0 ? ' is-active' : ''; ?>"
              data-tip-index="<?php echo esc_attr((string) $index); ?>"
              data-tip-theme="<?php echo esc_attr($theme); ?>"
              <?php echo $index === 0 ? '' : ' hidden'; ?>
            >
              <div class="yp-studio-tip-slide__media yp-studio-tip-slide__media--<?php echo esc_attr($theme); ?>">
                <?php if ($image !== '') : ?>
                  <img
                    class="yp-studio-tip-slide__img"
                    src="<?php echo esc_url($image); ?>"
                    alt=""
                    loading="lazy"
                    decoding="async"
                  />
                <?php endif; ?>
                <span class="yp-studio-tip-slide__icon dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
              </div>
              <div class="yp-studio-tip-slide__body">
                <h3 class="yp-studio-tip-slide__title"><?php echo esc_html($tip['title'] ?? ''); ?></h3>
                <p class="yp-studio-tip-slide__text"><?php echo esc_html($tip['text'] ?? ''); ?></p>
              </div>
            </article>
          <?php endforeach; ?>
        </div>

        <div class="yp-studio-tips-carousel__footer">
          <div
            class="yp-studio-tip-dots"
            role="tablist"
            aria-label="<?php esc_attr_e('Tips', 'yooadmin'); ?>"
          >
            <?php foreach ($tips as $index => $tip) : ?>
              <button
                type="button"
                class="yp-studio-tip-dot<?php echo $index === 0 ? ' is-active' : ''; ?>"
                role="tab"
                data-tip-index="<?php echo esc_attr((string) $index); ?>"
                aria-selected="<?php echo $index === 0 ? 'true' : 'false'; ?>"
                aria-label="<?php echo esc_attr(sprintf(
                    /* translators: %1$d current tip, %2$d total shown */
                    __('Tip %1$d of %2$d', 'yooadmin'),
                    $index + 1,
                    count($tips)
                )); ?>"
              ></button>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    <?php else : ?>
      <p class="yp-studio-tip yp-studio-tips-section__empty"><?php esc_html_e('Tips will appear here soon.', 'yooadmin'); ?></p>
    <?php endif; ?>
  </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
