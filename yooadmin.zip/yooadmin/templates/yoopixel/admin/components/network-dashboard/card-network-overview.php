<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$network_stats = isset($network_stats) && is_array($network_stats) ? $network_stats : ['sites' => 0, 'users' => 0];
$hidden_attr   = function_exists('yooadmin_network_dashboard_section_hidden_attrs')
    ? yooadmin_network_dashboard_section_hidden_attrs('network-overview', $layout ?? null)
    : '';

$plugins_url = network_admin_url('plugins.php');

$settings_url = network_admin_url('settings.php');
if (function_exists('yooadmin_network_settings_manager_url')) {
    $settings_url = yooadmin_network_settings_manager_url();
}

$sites_url = network_admin_url('sites.php');
if (function_exists('yooadmin_network_sites_manager_url')) {
    $sites_url = yooadmin_network_sites_manager_url();
}

$updates_url = network_admin_url('update-core.php');
if (
    function_exists('yooadmin_network_update_center_should_use')
    && yooadmin_network_update_center_should_use()
    && function_exists('yooadmin_network_update_center_url')
) {
    $updates_url = yooadmin_network_update_center_url();
}

$upgrade_network_url = network_admin_url('upgrade.php');
if (
    function_exists('yooadmin_network_upgrade_should_use')
    && yooadmin_network_upgrade_should_use()
    && function_exists('yooadmin_network_upgrade_url')
) {
    $upgrade_network_url = yooadmin_network_upgrade_url();
}

$overview_links = [
    [
        'label' => __('Manage sites', 'yooadmin'),
        'url'   => $sites_url,
        'icon'  => 'dashicons-admin-multisite',
    ],
    [
        'label' => __('Manage users', 'yooadmin'),
        'url'   => network_admin_url('users.php'),
        'icon'  => 'dashicons-admin-users',
    ],
    [
        'label' => __('Network plugins', 'yooadmin'),
        'url'   => $plugins_url,
        'icon'  => 'dashicons-admin-plugins',
    ],
    [
        'label' => __('Network settings', 'yooadmin'),
        'url'   => $settings_url,
        'icon'  => 'dashicons-admin-settings',
    ],
];

if (current_user_can('update_core')) {
    $overview_links[] = [
        'label' => __('Updates', 'yooadmin'),
        'url'   => $updates_url,
        'icon'  => 'dashicons-update',
    ];
}

if (current_user_can('upgrade_network')) {
    $overview_links[] = [
        'label' => __('Upgrade Network', 'yooadmin'),
        'url'   => $upgrade_network_url,
        'icon'  => 'dashicons-update',
    ];
}

$overview_links = apply_filters('yooadmin_network_dashboard_overview_links', $overview_links);
?>
<div class="yp-studio-aside-card yp-dashboard-section yp-studio-aside-layout-section yp-network-overview-card"
     data-section-id="network-overview"
     data-layout-section="true"
     data-collapsible="false"
     data-sortable="true"
     data-collapsed="false"
     data-custom-placement="aside"<?php echo $hidden_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
  <div class="yp-card-header yp-section-header yp-layout-section-handle">
    <span class="yp-layout-section-drag-handle" aria-hidden="true">
      <span class="dashicons dashicons-move" aria-hidden="true"></span>
    </span>
    <h2 class="yp-card-title yp-section-title yp-studio-aside-section__title">
      <span class="dashicons dashicons-chart-bar" aria-hidden="true"></span>
      <?php esc_html_e('Overview', 'yooadmin'); ?>
    </h2>
    <div class="yp-card-header-actions">
      <button type="button" class="yp-section-visibility-toggle" data-network-section-visibility="network-overview" aria-pressed="false" hidden>
        <span class="dashicons dashicons-hidden" aria-hidden="true"></span>
      </button>
    </div>
  </div>

  <div class="yp-studio-aside-section__body yp-network-overview-body">
    <div class="yp-network-overview-stats">
      <div class="yp-network-overview-stats__item">
        <span class="yp-network-overview-stats__icon" aria-hidden="true">
          <span class="dashicons dashicons-admin-multisite"></span>
        </span>
        <span class="yp-network-overview-stats__content">
          <span class="yp-network-overview-stats__value"><?php echo esc_html((string) (int) ($network_stats['sites'] ?? 0)); ?></span>
          <span class="yp-network-overview-stats__label"><?php esc_html_e('Sites', 'yooadmin'); ?></span>
        </span>
      </div>
      <div class="yp-network-overview-stats__item">
        <span class="yp-network-overview-stats__icon" aria-hidden="true">
          <span class="dashicons dashicons-groups"></span>
        </span>
        <span class="yp-network-overview-stats__content">
          <span class="yp-network-overview-stats__value"><?php echo esc_html((string) (int) ($network_stats['users'] ?? 0)); ?></span>
          <span class="yp-network-overview-stats__label"><?php esc_html_e('Users', 'yooadmin'); ?></span>
        </span>
      </div>
    </div>

    <?php if (!empty($overview_links) && is_array($overview_links)) : ?>
      <nav class="yp-network-overview-links" aria-label="<?php esc_attr_e('Network shortcuts', 'yooadmin'); ?>">
        <?php foreach ($overview_links as $link) :
            $label = isset($link['label']) ? (string) $link['label'] : '';
            $url   = isset($link['url']) ? (string) $link['url'] : '';
            $icon  = isset($link['icon']) ? (string) $link['icon'] : 'dashicons-admin-links';
            if ($label === '' || $url === '') {
                continue;
            }
            ?>
          <a href="<?php echo esc_url($url); ?>" class="yp-network-overview-link">
            <span class="yp-network-overview-link__icon" aria-hidden="true">
              <span class="dashicons <?php echo esc_attr($icon); ?>"></span>
            </span>
            <span class="yp-network-overview-link__label"><?php echo esc_html($label); ?></span>
          </a>
        <?php endforeach; ?>
      </nav>
    <?php endif; ?>
  </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
