<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$recent_sites = isset($recent_sites) && is_array($recent_sites) ? $recent_sites : [];
$hidden_attr  = function_exists('yooadmin_network_dashboard_section_hidden_attrs')
    ? yooadmin_network_dashboard_section_hidden_attrs('network-sites', $layout ?? null)
    : '';

$all_sites_url = function_exists('yooadmin_network_sites_manager_url')
    ? yooadmin_network_sites_manager_url()
    : network_admin_url('sites.php');
$create_site_url = function_exists('yooadmin_network_site_new_url')
    ? yooadmin_network_site_new_url()
    : network_admin_url('site-new.php');

$format_site_url = static function (string $url): string {
    $url = trim($url);
    if ($url === '') {
        return '';
    }
    $display = preg_replace('#^https?://#i', '', $url);
    return untrailingslashit((string) $display);
};

?>
<div class="yp-card yp-card-full yp-dashboard-section yp-studio-surface-card"
     data-section-id="network-sites"
     data-layout-section="true"
     data-collapsible="true"
     data-sortable="true"
     data-collapsed="false"<?php echo $hidden_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
  <div class="yp-card-header yp-section-header yp-layout-section-handle">
    <span class="yp-layout-section-drag-handle" aria-hidden="true">
      <span class="dashicons dashicons-move" aria-hidden="true"></span>
    </span>
    <h2 class="yp-card-title yp-section-title">
      <span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
      <?php esc_html_e('Sites', 'yooadmin'); ?>
    </h2>
    <div class="yp-card-header-actions">
      <div class="yp-network-sites-card__header-actions">
        <a class="yp-yoo-btn yp-yoo-btn--soft" href="<?php echo esc_url($all_sites_url); ?>">
          <span class="dashicons dashicons-admin-multisite" aria-hidden="true"></span>
          <?php esc_html_e('All Sites', 'yooadmin'); ?>
        </a>
        <a class="yp-yoo-btn yp-yoo-btn--primary" href="<?php echo esc_url($create_site_url); ?>">
          <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
          <?php esc_html_e('Add Site', 'yooadmin'); ?>
        </a>
      </div>
      <button type="button" class="yp-section-visibility-toggle" data-network-section-visibility="network-sites" aria-pressed="false" hidden>
        <span class="dashicons dashicons-hidden" aria-hidden="true"></span>
      </button>
    </div>
  </div>

  <div class="yp-studio-section-body yp-network-sites-card">
    <div class="yp-network-sites-loading yp-studio-section-loading is-hidden" aria-hidden="true">
      <div class="yp-loading-spinner">
        <div class="yp-spinner-circle"></div>
      </div>
    </div>

    <?php if ($recent_sites) : ?>
      <ul class="yp-network-sites-card__list is-hydrated">
        <?php foreach ($recent_sites as $site) :
            if (!is_array($site) || empty($site['admin'])) {
                continue;
            }
            $name         = (string) ($site['name'] ?? '');
            $home_url     = isset($site['home']) ? (string) $site['home'] : '';
            $url_label    = isset($site['url_label']) ? (string) $site['url_label'] : $format_site_url($home_url);
            $is_main      = !empty($site['id']) && (int) $site['id'] === 1;
            $site_id      = isset($site['id']) ? (int) $site['id'] : 0;
            $card_id      = $site_id > 0 ? 'network-site-' . $site_id : '';
            ?>
          <li class="yp-network-sites-card__item"<?php echo $site_id > 0 ? ' data-yoo-site-id="' . esc_attr((string) $site_id) . '"' : ''; ?><?php echo $card_id !== '' ? ' data-card-id="' . esc_attr($card_id) . '"' : ''; ?>>
            <span class="yp-network-sites-card__icon" aria-hidden="true">
              <span class="dashicons <?php echo $is_main ? 'dashicons-admin-home' : 'dashicons-admin-site-alt3'; ?>"></span>
            </span>
            <div class="yp-network-sites-card__content">
              <p class="yp-network-sites-card__title">
                <?php echo esc_html($name); ?>
                <?php
                if (function_exists('yooadmin_network_sites_render_status_tags')) {
                    yooadmin_network_sites_render_status_tags($site);
                }
                ?>
              </p>
              <?php if ($home_url !== '' && $url_label !== '') : ?>
                <a class="yp-network-sites-card__url" href="<?php echo esc_url($home_url); ?>" target="_blank" rel="noopener noreferrer">
                  <span class="dashicons dashicons-admin-links" aria-hidden="true"></span>
                  <span class="yp-network-sites-card__url-label"><?php echo esc_html($url_label); ?></span>
                </a>
              <?php endif; ?>
            </div>
            <?php
            if (function_exists('yooadmin_network_sites_render_row_actions')) {
                yooadmin_network_sites_render_row_actions($site, 'yooadmin');
            }
            ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else : ?>
      <div class="yp-network-sites-card__empty is-hydrated">
        <span class="yp-network-sites-card__icon" aria-hidden="true">
          <span class="dashicons dashicons-admin-multisite"></span>
        </span>
        <p class="yp-card-text"><?php esc_html_e('No sites found.', 'yooadmin'); ?></p>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
