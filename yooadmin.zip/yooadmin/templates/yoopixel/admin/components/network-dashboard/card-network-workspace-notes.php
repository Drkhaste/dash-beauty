<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$hidden_attr = function_exists('yooadmin_network_dashboard_section_hidden_attrs')
    ? yooadmin_network_dashboard_section_hidden_attrs('network-workspace-notes', $layout ?? null)
    : '';

if (!apply_filters('yooadmin_workspace_notes_enabled', true) || !function_exists('yooadmin_workspace_notes_types')) {
    return;
}

add_filter(
    'yooadmin_workspace_notes_scope',
    static function (): string {
        return 'network';
    },
    99
);

$ws_note_types    = yooadmin_workspace_notes_types();
$ws_active_type   = function_exists('yooadmin_workspace_notes_get_active_type')
    ? yooadmin_workspace_notes_get_active_type()
    : 'todos';
$ws_active_def    = $ws_note_types[ $ws_active_type ] ?? reset($ws_note_types);
$ws_page_size = function_exists('yooadmin_workspace_notes_page_size')
    ? yooadmin_workspace_notes_page_size()
    : 3;
$ws_notes_page = function_exists('yooadmin_workspace_notes_list_page')
    ? yooadmin_workspace_notes_list_page(get_current_user_id(), $ws_active_type, 0, $ws_page_size)
    : ['notes' => [], 'has_more' => false];
$ws_initial_notes  = isset($ws_notes_page['notes']) && is_array($ws_notes_page['notes']) ? $ws_notes_page['notes'] : [];
$ws_notes_has_more = !empty($ws_notes_page['has_more']);
$ws_show_check     = in_array($ws_active_type, ['todos', 'reminders'], true);
$ws_notes_scope    = 'network';

remove_all_filters('yooadmin_workspace_notes_scope', 99);

$ws_partial_vars = [
    'ws_note_types'     => $ws_note_types,
    'ws_active_type'    => $ws_active_type,
    'ws_active_def'     => $ws_active_def,
    'ws_initial_notes'  => $ws_initial_notes,
    'ws_notes_has_more' => $ws_notes_has_more,
    'ws_show_check'     => $ws_show_check,
    'ws_notes_scope'    => $ws_notes_scope,
];

$partial = '';
if (function_exists('yooadmin_studio_hub_render_dashboard_card_partial')) {
    $partial = yooadmin_studio_hub_render_dashboard_card_partial(
        'dashboard-card-workspace-notes-body.php',
        $ws_partial_vars
    );
} else {
    $partial_path = dirname(__DIR__, 5) . '/themes/yooadmin-studio-hub/templates/components/cards/partials/dashboard-card-workspace-notes-body.php';
    if (is_readable($partial_path)) {
        ob_start();
        // phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- Template partial expects local variables.
        extract($ws_partial_vars, EXTR_SKIP);
        include $partial_path;
        $partial = (string) ob_get_clean();
    }
}

if ($partial === '') {
    return;
}
?>
<div class="yp-studio-aside-card yp-dashboard-section yp-studio-aside-layout-section yp-studio-workspace-notes-card yp-network-workspace-notes-card"
     data-section-id="network-workspace-notes"
     data-layout-section="true"
     data-collapsible="false"
     data-sortable="true"
     data-collapsed="false"
     data-custom-placement="aside"
     data-workspace-notes="true"<?php echo $hidden_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
  <div class="yp-card-header yp-section-header yp-layout-section-handle">
    <span class="yp-layout-section-drag-handle" aria-hidden="true">
      <span class="dashicons dashicons-move" aria-hidden="true"></span>
    </span>
    <h2 class="yp-card-title yp-section-title yp-studio-aside-section__title">
      <span class="dashicons dashicons-book-alt" aria-hidden="true"></span>
      <?php esc_html_e('Workspace Notes', 'yooadmin'); ?>
    </h2>
    <div class="yp-card-header-actions">
      <button type="button" class="yp-section-visibility-toggle" data-network-section-visibility="network-workspace-notes" aria-pressed="false" hidden>
        <span class="dashicons dashicons-hidden" aria-hidden="true"></span>
      </button>
    </div>
  </div>

  <?php
  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Partial escapes output.
  echo $partial;
  ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
