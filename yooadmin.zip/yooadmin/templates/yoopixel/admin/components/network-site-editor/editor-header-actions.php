<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

if (empty($site_actions) || !is_array($site_actions)) {
    return;
}

?>
<div class="yoo-network-site-editor-manage-actions">
  <?php foreach ($site_actions as $action) :
      $label   = isset($action['label']) ? (string) $action['label'] : '';
      $url     = isset($action['url']) ? (string) $action['url'] : '';
      $icon    = isset($action['icon']) ? (string) $action['icon'] : 'dashicons-admin-generic';
      $confirm = !empty($action['confirm']) && is_array($action['confirm']) ? $action['confirm'] : null;
      $target  = isset($action['target']) ? (string) $action['target'] : '';
      if ($label === '') {
          continue;
      }

      $href = $confirm ? '#' : $url;
      $button_class = function_exists('yooadmin_network_sites_editor_header_button_class')
          ? yooadmin_network_sites_editor_header_button_class($action)
          : 'yp-yoo-btn yp-yoo-btn--secondary';
      ?>
    <a
      class="<?php echo esc_attr($button_class); ?>"
      href="<?php echo esc_url($href); ?>"
      aria-label="<?php echo esc_attr($label); ?>"
      title="<?php echo esc_attr($label); ?>"
      <?php if ($confirm) : ?>
      role="button"
      data-yoo-site-confirm-action="<?php echo esc_attr((string) ($confirm['action'] ?? '')); ?>"
      data-yoo-site-confirm-id="<?php echo esc_attr((string) ($confirm['id'] ?? '')); ?>"
      data-yoo-site-confirm-nonce="<?php echo esc_attr((string) ($confirm['nonce'] ?? '')); ?>"
      data-yoo-site-confirm-message="<?php echo esc_attr((string) ($confirm['message'] ?? '')); ?>"
      data-yoo-site-confirm-notice="<?php echo esc_attr((string) ($confirm['notice'] ?? '')); ?>"
      data-yoo-site-confirm-label="<?php echo esc_attr((string) ($confirm['confirm_label'] ?? '')); ?>"
      <?php endif; ?>
      <?php if ($target !== '') : ?>
      target="<?php echo esc_attr($target); ?>" rel="noopener noreferrer"
      <?php endif; ?>
    >
      <span class="dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
      <span><?php echo esc_html($label); ?></span>
    </a>
  <?php endforeach; ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
