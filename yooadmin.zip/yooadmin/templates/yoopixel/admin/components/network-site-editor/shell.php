<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$blog_id     = isset($blog_id) ? (int) $blog_id : 0;
$selected    = isset($selected_tab) ? (string) $selected_tab : 'site-info';
$tabs        = function_exists('yooadmin_network_site_editor_nav_tabs') ? yooadmin_network_site_editor_nav_tabs($blog_id, $selected) : [];
$site_name   = isset($site_name) && is_string($site_name) && $site_name !== '' && $site_name !== (string) $blog_id
    ? (string) $site_name
    : (function_exists('yooadmin_network_site_editor_site_name') ? yooadmin_network_site_editor_site_name($blog_id) : (string) $blog_id);
$home_url    = isset($home_url) ? (string) $home_url : get_home_url($blog_id, '/');
$dashboard_url = isset($dashboard_url) ? (string) $dashboard_url : get_admin_url($blog_id);
$form_action = isset($form_action) ? (string) $form_action : '';
$form_id     = isset($form_id) ? (string) $form_id : '';
$wrap_form   = !empty($wrap_form);
$flash_keys  = isset($flash_keys) && is_array($flash_keys) ? $flash_keys : ['update'];
$page_slug   = isset($page_slug) ? (string) $page_slug : 'network-site-info';

$active_tab = null;
foreach ($tabs as $tab_item) {
    if (!empty($tab_item['selected'])) {
        $active_tab = $tab_item;
        break;
    }
}
if (!$active_tab && $tabs) {
    $active_tab = $tabs[0];
}

$flash_message = isset($flash_message) ? (string) $flash_message : '';
$flash_type    = isset($flash_type) ? (string) $flash_type : '';

if ($flash_message === '' && function_exists('yooadmin_network_site_editor_flash_message')) {
    [$flash_message, $flash_type] = yooadmin_network_site_editor_flash_message($selected);
}

$flash_attr = '';
if ($flash_message !== '') {
    $flash_attr = sprintf(
        ' data-flash-message="%s" data-flash-type="%s"',
        esc_attr($flash_message),
        esc_attr($flash_type === 'error' ? 'error' : 'success')
    );
}
?>
<?php if ($wrap_form) : ?>
<form method="post" action="<?php echo esc_url($form_action); ?>" class="yoo-network-site-info-form yoo-network-site-editor-form" id="<?php echo esc_attr($form_id); ?>" novalidate>
  <?php
  if (!empty($form_nonce)) {
      wp_nonce_field((string) $form_nonce);
  }
  if (!empty($form_hidden_action)) {
      echo '<input type="hidden" name="action" value="' . esc_attr((string) $form_hidden_action) . '" />';
  }
  if ($blog_id > 0) {
      echo '<input type="hidden" name="id" value="' . esc_attr((string) $blog_id) . '" />';
  }
  ?>
<?php else : ?>
<div class="yoo-network-site-editor-form yoo-network-site-editor-form--shell">
<?php endif; ?>

<div class="wrap yoo-upload-wrap yoo-network-site-info-wrap yoo-network-site-editor-wrap yooadmin-settings-wrap yoo-network-site-editor-shell" data-page="<?php echo esc_attr($page_slug); ?>"<?php echo $flash_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
  <div class="yoo-upload-header yoo-network-site-info-header yoo-network-site-editor-shell__header">
      <div class="yoo-upload-header-content">
        <h1 class="yoo-upload-title">
          <span class="dashicons dashicons-admin-site-alt3 yoo-upload-title-dashicon" aria-hidden="true"></span>
          <?php
          echo esc_html(
              sprintf(
                  /* translators: %s: site title. */
                  __('Edit Site: %s', 'yooadmin'),
                  $site_name
              )
          );
          ?>
        </h1>
        <p class="yoo-upload-subtitle"><?php esc_html_e('Manage site info, users, themes, and settings in a focused YOOAdmin workspace.', 'yooadmin'); ?></p>
        <?php
        if ($blog_id > 0 && function_exists('yooadmin_network_sites_map_row') && function_exists('yooadmin_network_sites_render_editor_header_actions')) {
            $site_obj = get_site($blog_id);
            if ($site_obj) {
                $site_row = yooadmin_network_sites_map_row($site_obj);
                if (is_array($site_row)) {
                    yooadmin_network_sites_render_editor_header_actions($site_row, 'yooadmin', $selected);
                }
            }
        }
        ?>
      </div>
      <div class="yoo-upload-header-actions yoo-network-site-info-header-actions">
        <a class="yp-yoo-btn yp-yoo-btn--soft" href="<?php echo esc_url($home_url); ?>" target="_blank" rel="noopener noreferrer">
          <span class="dashicons dashicons-external" aria-hidden="true"></span>
          <?php esc_html_e('Visit', 'yooadmin'); ?>
        </a>
        <a class="yp-yoo-btn yp-yoo-btn--primary" href="<?php echo esc_url($dashboard_url); ?>">
          <span class="dashicons dashicons-dashboard" aria-hidden="true"></span>
          <?php esc_html_e('Dashboard', 'yooadmin'); ?>
        </a>
      </div>
    </div>

    <div class="yp-tabs" data-yp-tabs>
      <div class="yp-tab-nav" role="tablist" aria-label="<?php esc_attr_e('Site sections', 'yooadmin'); ?>">
        <?php foreach ($tabs as $tab_item) :
            $tab_id    = isset($tab_item['id']) ? (string) $tab_item['id'] : '';
            $tab_label = isset($tab_item['label']) ? (string) $tab_item['label'] : '';
            $tab_url   = isset($tab_item['url']) ? (string) $tab_item['url'] : '';
            $is_active = !empty($tab_item['selected']);
            if ($tab_id === '' || $tab_label === '') {
                continue;
            }
            ?>
          <a
            class="yp-tab yp-tab--link<?php echo $is_active ? ' is-active' : ''; ?>"
            role="tab"
            aria-selected="<?php echo $is_active ? 'true' : 'false'; ?>"
            href="<?php echo esc_url($tab_url); ?>"
            id="yoo-network-site-editor-tab-<?php echo esc_attr($tab_id); ?>"
          >
            <?php echo esc_html($tab_label); ?>
          </a>
        <?php endforeach; ?>
      </div>

      <div class="yp-tab-panels">
        <div
          class="yp-tab-panel is-active"
          id="yoo-network-site-editor-panel-<?php echo esc_attr($selected); ?>"
          data-panel="<?php echo esc_attr($selected); ?>"
          role="tabpanel"
          aria-labelledby="yoo-network-site-editor-tab-<?php echo esc_attr($selected); ?>"
        >
          <?php if ($active_tab) : ?>
            <div class="yp-tab-intro">
              <span class="dashicons <?php echo esc_attr((string) ($active_tab['icon'] ?? 'dashicons-info-outline')); ?> yp-tab-intro-icon" aria-hidden="true"></span>
              <div class="yp-tab-intro__stack">
                <p class="yp-tab-intro__text"><?php echo esc_html((string) ($active_tab['desc'] ?? '')); ?></p>
              </div>
            </div>
          <?php endif; ?>

          <?php
          if (!empty($panel_partial) && is_readable($panel_partial)) {
              include $panel_partial;
          }
          ?>
        </div>
      </div>
    </div>

    <?php if ($wrap_form && !empty($form_actions_partial) && is_readable($form_actions_partial)) {
        include $form_actions_partial;
    } ?>
</div>

<?php if ($wrap_form) : ?>
</form>
<?php else : ?>
</div>
<?php endif; ?>
