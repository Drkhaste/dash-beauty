<?php
/**
 * YOOAdmin - Admin layout header template
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

$dash_url = function_exists('yooadmin_shell_home_url')
    ? yooadmin_shell_home_url()
    : (function_exists('yooadmin_dashboard_url')
        ? yooadmin_dashboard_url()
        : admin_url('admin.php?page=yooadmin-dashboard'));

$logo_url = function_exists('yooadmin_logo_url') ? yooadmin_logo_url() : '';
$logo_default_url = function_exists('yooadmin_logo_default_url')
    ? yooadmin_logo_default_url()
    : ( defined('YOOADMIN_PLUGIN_FILE')
        // Fallback to bundled logo.png in assets/images
        ? plugin_dir_url(YOOADMIN_PLUGIN_FILE) . 'assets/images/logo.png'
        : '' );

/** When no custom logo is saved, show the default image (same as sidebar), not plain text. */
$header_logo_display = $logo_url !== '' ? $logo_url : $logo_default_url;

$user = function_exists('yooadmin_current_user_meta')
    ? yooadmin_current_user_meta()
    : [
        'display' => esc_html(wp_get_current_user()->display_name ?? __('User', 'yooadmin')),
        'avatar'  => esc_url(get_avatar_url(get_current_user_id()))
      ];

$toolbar_shortcuts = function_exists('yooadmin_collect_toolbar_shortcuts')
    ? yooadmin_collect_toolbar_shortcuts()
    : [];

if (function_exists('yooadmin_should_mirror_admin_bar_in_breadcrumbs') && !yooadmin_should_mirror_admin_bar_in_breadcrumbs()) {
    $toolbar_shortcuts = [];
}

$plugins_submenu = [
    [
        'label'      => __('Installed Plugins', 'yooadmin'),
        'href'       => admin_url('plugins.php'),
        'icon_class' => 'dashicons dashicons-admin-plugins',
        'target'     => '',
    ],
    [
        'label'      => __('Add Plugin', 'yooadmin'),
        'href'       => admin_url('plugin-install.php'),
        'icon_class' => 'dashicons dashicons-plus-alt',
        'target'     => '',
    ],
];

$custom_shortcuts = apply_filters(
    'yooadmin_toolbar_custom_shortcuts',
    [
        [
            'id'         => 'yooadmin-plugins',
            'label'      => '',
            'href'       => admin_url('plugins.php'),
            'tooltip'    => __('Plugins', 'yooadmin'),
            'icon_class' => 'dashicons dashicons-admin-plugins',
            'badge'      => '',
            'target'     => '',
            'children'   => $plugins_submenu,
        ],
        [
            'id'         => function_exists('yooadmin_user_can_manage_site_settings') && yooadmin_user_can_manage_site_settings()
                ? 'yooadmin-settings'
                : 'yooadmin-my-preferences',
            'label'      => '',
            'href'       => function_exists('yooadmin_settings_admin_url')
                ? yooadmin_settings_admin_url()
                : admin_url('admin.php?page=yooadmin-settings'),
            'tooltip'    => function_exists('yooadmin_user_can_manage_site_settings') && yooadmin_user_can_manage_site_settings()
                ? __('Settings', 'yooadmin')
                : __('My Preferences', 'yooadmin'),
            // Use the circular "generic" dashicon instead of the gear/teeth one.
            'icon_class' => 'dashicons dashicons-admin-generic',
            'badge'      => '',
            'target'     => '',
            'children'   => [],
        ],
        [
            'id'         => 'yooadmin-preview-site',
            'label'      => __('Preview Site', 'yooadmin'),
            'href'       => home_url('/'),
            'tooltip'    => __('Preview Site', 'yooadmin'),
            'icon_class' => 'dashicons dashicons-desktop',
            'badge'      => '',
            'target'     => '_blank',
            'children'   => [],
        ],
        class_exists('WooCommerce')
            ? [
                'id'         => 'yooadmin-preview-store',
                'label'      => __('Preview Store', 'yooadmin'),
                'href'       => get_permalink(wc_get_page_id('shop')),
                'tooltip'    => __('Preview WooCommerce Store', 'yooadmin'),
                'icon_class' => 'dashicons dashicons-store',
                'badge'      => '',
                'target'     => '_blank',
                'children'   => [],
            ]
            : null,
    ]
);

if (is_array($custom_shortcuts)) {
    $custom_shortcuts = array_filter($custom_shortcuts);
} else {
    $custom_shortcuts = [];
}

$toolbar_shortcuts_mirrored = $toolbar_shortcuts;
$toolbar_shortcuts          = array_merge($toolbar_shortcuts_mirrored, $custom_shortcuts);

if (function_exists('yooadmin_multisite_filter_breadcrumbs_toolbar_shortcut_sets')) {
    [$toolbar_shortcuts_mirrored, $custom_shortcuts] = yooadmin_multisite_filter_breadcrumbs_toolbar_shortcut_sets(
        $toolbar_shortcuts_mirrored,
        $custom_shortcuts
    );
    $toolbar_shortcuts = array_merge($toolbar_shortcuts_mirrored, $custom_shortcuts);
}

if (function_exists('yooadmin_filter_toolbar_shortcuts_by_capability')) {
    $toolbar_shortcuts_mirrored = yooadmin_filter_toolbar_shortcuts_by_capability($toolbar_shortcuts_mirrored);
    $custom_shortcuts             = yooadmin_filter_toolbar_shortcuts_by_capability($custom_shortcuts);
    $toolbar_shortcuts            = array_merge($toolbar_shortcuts_mirrored, $custom_shortcuts);
}

if (empty($toolbar_shortcuts)) {
    $toolbar_shortcuts_mirrored = function_exists('yooadmin_get_default_toolbar_shortcuts')
        ? yooadmin_get_default_toolbar_shortcuts()
        : [];
    $toolbar_shortcuts = array_merge($toolbar_shortcuts_mirrored, $custom_shortcuts);
    if (function_exists('yooadmin_multisite_filter_breadcrumbs_toolbar_shortcut_sets')) {
        [$toolbar_shortcuts_mirrored, $custom_shortcuts] = yooadmin_multisite_filter_breadcrumbs_toolbar_shortcut_sets(
            $toolbar_shortcuts_mirrored,
            $custom_shortcuts
        );
        $toolbar_shortcuts = array_merge($toolbar_shortcuts_mirrored, $custom_shortcuts);
    }
    if (function_exists('yooadmin_filter_toolbar_shortcuts_by_capability')) {
        $toolbar_shortcuts_mirrored = yooadmin_filter_toolbar_shortcuts_by_capability($toolbar_shortcuts_mirrored);
        $custom_shortcuts             = yooadmin_filter_toolbar_shortcuts_by_capability($custom_shortcuts);
        $toolbar_shortcuts            = array_merge($toolbar_shortcuts_mirrored, $custom_shortcuts);
    }
}

$yp_show_subsite_context_bar = function_exists('yooadmin_show_subsite_context_bar') && yooadmin_show_subsite_context_bar();
$yooadmin_can_manage_focus_policy = function_exists('yooadmin_user_can_manage_focus_policy')
    && yooadmin_user_can_manage_focus_policy();
?>
<?php if ($yp_show_subsite_context_bar) : ?><div class="yp-subsite-chrome"><?php endif; ?>
<?php
if ($yp_show_subsite_context_bar && function_exists('yooadmin_render_subsite_context_bar')) {
    yooadmin_render_subsite_context_bar();
}
?>
<div id="yoo-admin-header-wrapper" class="yp-header-wrapper<?php echo $yp_show_subsite_context_bar ? ' yp-header-wrapper--subsite-context' : ''; ?>">
<header id="yoo-admin-header" class="yp-header">
    <div class="yps-overlay" data-yps-close hidden></div>

    <div class="yp-header-left">
        <button id="yps-toggle-btn" class="yps-toggle" type="button"
                aria-controls="yps-sidebar"
                aria-expanded="false"
                aria-label="<?php echo esc_attr__('Open menu', 'yooadmin'); ?>">
            <span class="dashicons dashicons-menu" aria-hidden="true"></span>
        </button>
        <span class="yooadmin-plus-shell-logo-wrap yooadmin-shell-logo-wrap">
        <a href="<?php echo esc_url($dash_url); ?>" class="yp-logo-link" aria-label="<?php echo esc_attr__('YOOAdmin Home', 'yooadmin'); ?>">
            <?php if ($header_logo_display) : ?>
                <img src="<?php echo esc_url($header_logo_display); ?>"
                     alt="<?php esc_attr_e('YOOAdmin Logo', 'yooadmin'); ?>"
                     class="yp-logo"
                     data-default-src="<?php echo esc_url($logo_default_url); ?>">
            <?php else : ?>
                <span class="yp-logo-text">YOOAdmin</span>
            <?php endif; ?>
        </a>
        <?php
        $yooadmin_show_license_status = function_exists('yooadmin_should_show_shell_license_status')
            && yooadmin_should_show_shell_license_status();
        $yooadmin_can_manage_license = function_exists('yooadmin_user_can_manage_site_settings')
            && yooadmin_user_can_manage_site_settings();
        $yooadmin_license_shell = ($yooadmin_show_license_status && function_exists('yooadmin_get_shell_license_status'))
            ? yooadmin_get_shell_license_status()
            : null;

        if ($yooadmin_license_shell) {
            $status_class = (string) $yooadmin_license_shell['status_class'];
            $status_text  = (string) $yooadmin_license_shell['status_text'];
            $status_icon  = (string) $yooadmin_license_shell['status_icon'];
            ?>
        <div class="yp-license-status yp-license-status--logo-badge">
            <?php if ($yooadmin_can_manage_license) : ?>
            <a href="<?php echo esc_url(function_exists('yooadmin_license_admin_url') ? yooadmin_license_admin_url() : admin_url('admin.php?page=yooadmin-license')); ?>"
               class="yp-license-status-button yooadmin-shell-license-badge yp-license-status-<?php echo esc_attr($status_class); ?>"
               aria-label="<?php echo esc_attr($status_text); ?>"
               title="<?php echo esc_attr($status_text); ?>">
                <span class="dashicons <?php echo esc_attr($status_icon); ?>" aria-hidden="true"></span>
                <span class="screen-reader-text"><?php echo esc_html($status_text); ?></span>
            </a>
            <?php else : ?>
            <button type="button"
                    class="yp-license-status-button yooadmin-shell-license-badge yp-license-status-<?php echo esc_attr($status_class); ?>"
                    data-yooadmin-license-status-modal="1"
                    data-modal-title="<?php echo esc_attr((string) $yooadmin_license_shell['modal_title']); ?>"
                    data-modal-message="<?php echo esc_attr((string) $yooadmin_license_shell['modal_message']); ?>"
                    data-modal-icon="<?php echo esc_attr((string) $yooadmin_license_shell['modal_icon']); ?>"
                    data-modal-type="<?php echo esc_attr((string) $yooadmin_license_shell['modal_type']); ?>"
                    aria-label="<?php echo esc_attr($status_text); ?>"
                    title="<?php echo esc_attr($status_text); ?>">
                <span class="dashicons <?php echo esc_attr($status_icon); ?>" aria-hidden="true"></span>
                <span class="screen-reader-text"><?php echo esc_html($status_text); ?></span>
            </button>
            <?php endif; ?>
        </div>
            <?php
        }
        ?>
        </span>
        <?php
        if (!isset($yooadmin_license_shell)) {
            $yooadmin_license_shell = null;
        }
        ?>
        <?php if (function_exists('yooadmin_network_admin_shell_active') && yooadmin_network_admin_shell_active()) : ?>
            <span class="yp-network-admin-badge yp-network-admin-badge--header" role="status" aria-label="<?php esc_attr_e('Network Admin', 'yooadmin'); ?>">
                <span class="dashicons dashicons-admin-multisite" aria-hidden="true"></span>
                <span class="yp-network-admin-badge__label"><?php esc_html_e('Network Admin', 'yooadmin'); ?></span>
            </span>
        <?php endif; ?>
    </div>

    <div class="yp-header-center">
    </div>

    <?php
    $yooadmin_show_notifications_ui = function_exists('yooadmin_user_can_view_notifications_ui')
        && yooadmin_user_can_view_notifications_ui();

    if (!isset($yooadmin_license_shell)) {
        $yooadmin_license_shell = null;
    }

    $license_active = $yooadmin_license_shell['is_active'] ?? false;
    $license_status = $yooadmin_license_shell['license_status'] ?? 'inactive';

    if ($yooadmin_show_notifications_ui && !$yooadmin_license_shell && class_exists('YOOAdmin_License_Manager')) {
        $license_manager = YOOAdmin_License_Manager::get_instance();
        $license_active  = $license_manager->is_license_active();
        $license_data    = $license_manager->get_license_data();
        $license_status  = $license_data['status'] ?? 'inactive';
    }
    ?>
    <div class="yp-header-right">
        <?php if ($yooadmin_show_notifications_ui) : ?>
        <?php
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }
        ?>
        <div class="yp-notifications" aria-label="<?php echo esc_attr__('Notifications', 'yooadmin'); ?>">
            <span class="dashicons dashicons-bell" aria-hidden="true"></span>
            <?php
            // Check if convert_banners_to_notifications is enabled — no license gate
            $opts = (array) get_option('yooadmin_options', []);
            $convert_banners_enabled = !empty($opts['convert_banners_to_notifications']);
            
            // Use new notification system if available
            $total_count = 0;
            
            if (function_exists('yooadmin_get_integration')) {
                $integration = yooadmin_get_integration();
                if ($integration) {
                    $user_id = get_current_user_id();
                    
                    // If banner conversion is disabled, count only non-banner notifications
                    if (!$convert_banners_enabled) {
                        // Get all notifications and filter out banners
                        $all_notifications = $integration->get_notifications($user_id, [
                            'status' => 'new'
                        ]);
                        
                        // Count only non-banner notifications
                        foreach ($all_notifications as $item) {
                            if (isset($item['type']) && $item['type'] === 'group' && isset($item['items'])) {
                                // Count non-banner items in groups
                                foreach ($item['items'] as $group_item) {
                                    $source_type = $group_item['source_type'] ?? '';
                                    if ($source_type !== 'banner' && $source_type !== 'banner-conversion' && $source_type !== 'wp_admin_banner') {
                                        $total_count++;
                                    }
                                }
                            } else {
                                // Count non-banner individual notifications
                                $source_type = $item['source_type'] ?? '';
                                if ($source_type !== 'banner' && $source_type !== 'banner-conversion' && $source_type !== 'wp_admin_banner') {
                                    $total_count++;
                                }
                            }
                        }
                    } else {
                        // Banner conversion enabled - use normal count
                        $total_count = $integration->get_notification_count($user_id, 'new');
                    }
                }
            }
            
            // Fallback to old system if new system not available
            if ($total_count === 0 && !function_exists('yooadmin_get_integration')) {
                $updates = wp_get_update_data();
                $update_counts = isset($updates['counts']) && is_array($updates['counts']) ? $updates['counts'] : [];

                // Collect detailed meta for WordPress updates.
                $core_meta        = yooadmin_notifications_collect_core_updates();
                $plugin_meta      = yooadmin_notifications_collect_plugin_updates();
                $theme_meta       = yooadmin_notifications_collect_theme_updates();
                $translation_meta = yooadmin_notifications_collect_translation_updates();

                $core_count        = !empty($core_meta['count']) ? (int) $core_meta['count'] : (int) ($update_counts['wordpress'] ?? 0);
                $plugin_count      = !empty($plugin_meta['count']) ? (int) $plugin_meta['count'] : (int) ($update_counts['plugins'] ?? 0);
                $theme_count       = !empty($theme_meta['count']) ? (int) $theme_meta['count'] : (int) ($update_counts['themes'] ?? 0);
                $translation_count = !empty($translation_meta['count']) ? (int) $translation_meta['count'] : (int) ($update_counts['translations'] ?? 0);

                // Comments waiting moderation.
                $comments_count   = wp_count_comments();
                $pending_comments = isset($comments_count->moderated) ? (int) $comments_count->moderated : 0;

                // Draft posts (optional entry).
                $drafts_count = wp_count_posts('post');
                $draft_posts  = isset($drafts_count->draft) ? (int) $drafts_count->draft : 0;

                $total_count = $core_count + $plugin_count + $theme_count + $translation_count + $pending_comments + $draft_posts;
            }
            
            $user_prefs_badge = get_user_meta(get_current_user_id(), 'yooadmin_notification_preferences', true);
            $show_count_badge = true;
            if (is_array($user_prefs_badge) && isset($user_prefs_badge['show_count_badge'])) {
                $show_count_badge = !empty($user_prefs_badge['show_count_badge']);
            }
            
            // Display badge with class for JavaScript to update
            if ($total_count > 0): ?>
                <span class="notification-count yp-notification-count" data-count="<?php echo esc_attr($total_count); ?>"<?php echo $show_count_badge ? '' : ' style="display: none;"'; ?>><?php echo esc_html($total_count); ?></span>
            <?php else: ?>
                <span class="notification-count yp-notification-count" data-count="0" style="display: none;"></span>
            <?php endif; ?>
            
            <div class="yp-notifications-dropdown">
                <div class="yp-notifications-header">
                    <h3><?php esc_html_e('Notifications', 'yooadmin'); ?></h3>
                    <button type="button" class="yp-notifications-mark-read"><?php esc_html_e('Mark all read', 'yooadmin'); ?></button>
                </div>
                <?php
                // Fallback enqueue when admin_enqueue_scripts did not load notifications UI yet.
                if (function_exists('wp_enqueue_script') && !function_exists('yooadmin_notifications_ui_is_enqueued')) {
                    require_once dirname(__DIR__, 4) . '/includes/notifications/ui.php';
                }
                if (function_exists('wp_enqueue_script') && function_exists('yooadmin_notifications_ui_is_enqueued') && !yooadmin_notifications_ui_is_enqueued()) {
                    $base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : dirname(__DIR__, 4) . '/yooadmin.php';
                    $url = plugin_dir_url($base_file);
                    $dir = plugin_dir_path($base_file);
                    $js_path = $dir . 'assets/js/admin/notifications-ui.js';

                    if (file_exists($js_path)) {
                        wp_enqueue_script('yooadmin-notifications-ui', $url . 'assets/js/admin/notifications-ui.js', ['jquery'], (string) filemtime($js_path), true);

                        if (function_exists('yooadmin_get_notifications_ui_localize_data')) {
                            wp_localize_script(
                                'yooadmin-notifications-ui',
                                'yooadmNotifications',
                                yooadmin_get_notifications_ui_localize_data([
                                    'convert_banners_enabled' => $convert_banners_enabled,
                                    'license_active' => $license_active,
                                ])
                            );
                        }
                    }
                }
                ?>
                
                <!-- Filter Tabs -->
                <div class="yp-filter-tabs"
                     data-tab-all="<?php echo esc_attr__('ALL', 'yooadmin'); ?>"
                     data-tab-plugins="<?php echo esc_attr__('Plugins', 'yooadmin'); ?>"
                     data-tab-theme="<?php echo esc_attr__('Theme', 'yooadmin'); ?>"
                     data-tab-extensions="<?php echo esc_attr__('Extensions', 'yooadmin'); ?>"
                     data-tab-banners="<?php echo esc_attr__('Banners', 'yooadmin'); ?>"
                     data-tab-license="<?php echo esc_attr__('License', 'yooadmin'); ?>"
                     data-tab-comments="<?php echo esc_attr__('Comments', 'yooadmin'); ?>">
                    <button class="yp-filter-tab active" data-filter="all" data-type="all">
                        <?php esc_html_e('ALL', 'yooadmin'); ?> <span class="yp-tab-count">0</span>
                    </button>
                    <button class="yp-filter-tab" data-filter="plugins" data-type="wp-plugin-updates">
                        <?php esc_html_e('Plugins', 'yooadmin'); ?> <span class="yp-tab-count">0</span>
                    </button>
                    <button class="yp-filter-tab" data-filter="theme" data-type="wp-theme-updates">
                        <?php esc_html_e('Theme', 'yooadmin'); ?> <span class="yp-tab-count">0</span>
                    </button>
                    <button class="yp-filter-tab" data-filter="banners" data-type="wp-admin-banner">
                        <?php esc_html_e('Banners', 'yooadmin'); ?> <span class="yp-tab-count">0</span>
                    </button>
                </div>
                
                <div class="yp-notifications-list" data-empty-text="<?php esc_attr_e('No new notifications', 'yooadmin'); ?>">
                    <?php 
                    /* 
                     * All notifications are now rendered via JavaScript from new notification system
                     * See: yooadmin-extended/assets/js/admin/notifications-ui.js
                     * Notifications will be populated dynamically via JavaScript when loaded.
                     */
                    ?>
                </div>
                <?php
                if (!function_exists('yooadmin_render_notifications_dropdown_footer')) {
                    require_once dirname(__DIR__, 4) . '/includes/notifications/ui.php';
                }
                if (function_exists('yooadmin_render_notifications_dropdown_footer')) {
                    echo yooadmin_render_notifications_dropdown_footer(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in renderer.
                }
                ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="yp-user-info" aria-label="<?php echo esc_attr($user['display']); ?>">
            <?php if (!empty($user['avatar'])): ?>
                <img src="<?php echo esc_url($user['avatar']); ?>" alt="<?php echo esc_attr($user['display']); ?>" class="yp-user-photo<?php echo !empty($user['avatar_is_placeholder']) ? ' yp-user-photo--placeholder' : ''; ?>">
            <?php endif; ?>

            <div class="yp-user-dropdown">
                <span class="yp-user-name-dropdown"><?php echo esc_html($user['display']); ?></span>
                <?php
                if (function_exists('yooadmin_render_shell_user_menu_links')) {
                    yooadmin_render_shell_user_menu_links();
                }
                ?>
                <a href="<?php echo esc_url(function_exists('yooadmin_shell_user_menu_profile_url') ? yooadmin_shell_user_menu_profile_url() : get_edit_profile_url(get_current_user_id())); ?>">
                    <span class="dashicons dashicons-admin-users" aria-hidden="true"></span> <?php esc_html_e('Edit Profile', 'yooadmin'); ?>
                </a>
                <?php if (function_exists('yooadmin_user_can_view_my_preferences') && yooadmin_user_can_view_my_preferences() && !(function_exists('yooadmin_user_can_manage_site_settings') && yooadmin_user_can_manage_site_settings())) : ?>
                <a href="<?php echo esc_url(function_exists('yooadmin_my_preferences_admin_url') ? yooadmin_my_preferences_admin_url() : admin_url('admin.php?page=yooadmin-my-preferences')); ?>">
                    <span class="dashicons dashicons-admin-generic" aria-hidden="true"></span> <?php esc_html_e('My Preferences', 'yooadmin'); ?>
                </a>
                <?php endif; ?>
                <?php if (function_exists('yooadmin_render_shell_admin_bar_user_action_links')) : ?>
                    <?php yooadmin_render_shell_admin_bar_user_action_links(); ?>
                <?php endif; ?>
                <a href="<?php echo esc_url(wp_logout_url(function_exists('yooadmin_login_post_logout_redirect_url') ? yooadmin_login_post_logout_redirect_url() : home_url('/'))); ?>">
                    <span class="dashicons dashicons-migrate" aria-hidden="true"></span> <?php esc_html_e('Log Out', 'yooadmin'); ?>
                </a>
            </div>
        </div>
    </div>

    <?php if ($yooadmin_show_notifications_ui) : ?>
    <!-- Notification Popup Modal (includes delete confirm view) -->
    <div id="yp-notification-modal" class="yp-modal" style="display:none;">
        <div class="yp-modal-overlay"></div>
        <div class="yp-modal-content">
            <button class="yp-modal-close" aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
            <!-- Notification view (default) -->
            <div class="yp-modal-notification-view">
                <div class="yp-modal-header">
                    <span class="yp-modal-icon dashicons"></span>
                    <h2 class="yp-modal-title"></h2>
                </div>
                <div class="yp-modal-body">
                    <p class="yp-modal-text"></p>
                    <div class="yp-modal-details"></div>
                </div>
                <div class="yp-modal-footer">
                    <a href="#" class="yp-modal-action-btn button button-primary"></a>
                    <button type="button"
                            class="yp-modal-delete-btn button"
                            title="<?php esc_attr_e('Delete permanently', 'yooadmin'); ?>"
                            aria-label="<?php esc_attr_e('Delete permanently', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-trash" aria-hidden="true"></span>
                        <span class="yp-delete-text"><?php esc_html_e('Delete', 'yooadmin'); ?></span>
                    </button>
                    <button type="button"
                            class="yp-modal-snooze-btn button"
                            title="<?php esc_attr_e('Hide for 30 days', 'yooadmin'); ?>"
                            aria-label="<?php esc_attr_e('Hide for 30 days', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-clock" aria-hidden="true"></span>
                        <span class="yp-snooze-text"><?php esc_html_e('Hide 30 days', 'yooadmin'); ?></span>
                    </button>
                </div>
            </div>
            <!-- Snooze confirm view (shown when Hide 30 days clicked) -->
            <div class="yp-modal-snooze-confirm-view" style="display:none;">
                <div class="yp-modal-header">
                    <span class="yp-modal-icon dashicons dashicons-clock"></span>
                    <h2 class="yp-modal-title"><?php esc_html_e('Hide notification for 30 days?', 'yooadmin'); ?></h2>
                </div>
                <div class="yp-modal-body">
                    <p class="yp-modal-text" style="font-weight:400;color:var(--yp-text-secondary,#666);"><?php esc_html_e('To restore all snoozed banners later, go to Settings → Notifications tab → Database Cleanup → Clear Banner Notifications.', 'yooadmin'); ?></p>
                </div>
                <div class="yp-modal-footer">
                    <button type="button" class="button button-secondary yp-snooze-confirm-cancel"><?php esc_html_e('Cancel', 'yooadmin'); ?></button>
                    <button type="button" class="button button-primary yp-snooze-confirm-ok"><?php esc_html_e('OK', 'yooadmin'); ?></button>
                </div>
            </div>
            <!-- Delete confirm view (shown when Delete clicked) -->
            <div class="yp-modal-delete-confirm-view" style="display:none;">
                <div class="yp-modal-header">
                    <span class="yp-modal-icon dashicons dashicons-warning"></span>
                    <h2 class="yp-modal-title"><?php esc_html_e('Remove from notification center?', 'yooadmin'); ?></h2>
                </div>
                <div class="yp-modal-body">
                    <p class="yp-modal-text" style="font-weight:400;color:var(--yp-text-secondary,#666);"><?php
                    printf(
                        /* translators: %s: link to settings notifications tab */
                        esc_html__('The notification is not deleted. If the source is not addressed, it will reappear. To hide it, use "Hide 30 days" or check the %s Advanced Notifications.', 'yooadmin'),
                        '<a href="' . esc_url(function_exists('yooadmin_settings_admin_url') ? yooadmin_settings_admin_url('tab-notifications') : admin_url('admin.php?page=yooadmin-settings#tab-notifications')) . '" class="yp-modal-settings-link">' . esc_html__('settings', 'yooadmin') . '</a>'
                    );
                    ?></p>
                </div>
                <div class="yp-modal-footer">
                    <button type="button" class="button button-secondary yp-delete-confirm-cancel"><?php esc_html_e('Cancel', 'yooadmin'); ?></button>
                    <button type="button" class="button button-primary yp-delete-confirm-ok"><?php esc_html_e('OK', 'yooadmin'); ?></button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php
    $yooadmin_license_status_modal = dirname(__DIR__) . '/components/license-status-info-modal.php';
    if (file_exists($yooadmin_license_status_modal)) {
        include $yooadmin_license_status_modal;
    }
    ?>

    <!-- About modal (in header for correct overlay stacking, like notification modal) -->
    <?php
    $yooadmin_about_modal = dirname(__DIR__) . '/components/about-modal.php';
    if (file_exists($yooadmin_about_modal)) {
        include $yooadmin_about_modal;
    }
    ?>
</header>

<?php
// Breadcrumbs + quick shortcuts row
$breadcrumbs_html = '';
if (function_exists('yooadmin_render_breadcrumbs')) {
    if (is_multisite() && is_network_admin() && function_exists('yooadmin_network_dashboard_slug')) {
        $dash_slug = (string) yooadmin_network_dashboard_slug();
    } else {
        $dash_slug = function_exists('yooadmin_dashboard_slug') ? (string) yooadmin_dashboard_slug() : 'yooadmin-dashboard';
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page routing for breadcrumbs, no state change.
    $is_dashboard = (isset($_GET['page']) && sanitize_text_field(wp_unslash($_GET['page'])) === $dash_slug);

    ob_start();
    yooadmin_render_breadcrumbs($dash_url);
    $bc_html = (string) ob_get_clean();

    if ($is_dashboard && $bc_html !== '') {
        $processed = false;
        if (class_exists('DOMDocument')) {
            $doc = new DOMDocument();
            libxml_use_internal_errors(true);
            $ok = $doc->loadHTML('<?xml encoding="utf-8" ?>' . $bc_html);
            libxml_clear_errors();
            if ($ok) {
                $xp  = new DOMXPath($doc);
                $nav = $xp->query("//nav[contains(concat(' ', normalize-space(@class), ' '), ' yp-breadcrumbs ')]")->item(0);
                if ($nav) {
                    $lis = $xp->query(".//li", $nav);
                    if ($lis && $lis->length > 1) {
                        for ($i = 1; $i < $lis->length; $i++) {
                            $li = $lis->item($i);
                            if ($li && $li->parentNode) {
                                $li->parentNode->removeChild($li);
                            }
                        }
                    }
                    $breadcrumbs_html = $doc->saveHTML($nav);
                    $processed = true;
                }
            }
        }
        if (!$processed) {
            $breadcrumbs_html = $bc_html;
        }
    } else {
        $breadcrumbs_html = $bc_html;
    }
}

if (
    function_exists('yooadmin_should_use_desktop_surface_breadcrumbs')
    && yooadmin_should_use_desktop_surface_breadcrumbs()
    && function_exists('yooadmin_strip_breadcrumb_home_item')
    && $breadcrumbs_html !== ''
) {
    $breadcrumbs_html = yooadmin_strip_breadcrumb_home_item($breadcrumbs_html);
}

$ysh_show_appearance = false;
$ysh_color_mode      = 'auto';
if (class_exists('YOOAdmin_Admin_Theme_Manager')) {
    $ysh_tm = YOOAdmin_Admin_Theme_Manager::get_instance();
    if (
        $ysh_tm
        && $ysh_tm->theme_has_feature('appearance_mode')
    ) {
        $ysh_show_appearance = true;
        $ysh_color_mode      = function_exists('yooadmin_studio_hub_get_color_mode')
            ? yooadmin_studio_hub_get_color_mode()
            : 'auto';
    }
}
$ysh_show_width_control = function_exists('yooadmin_studio_hub_can_show_width_control') && yooadmin_studio_hub_can_show_width_control();
$yooadmin_command_palette_available = function_exists('yooadmin_is_command_palette_available') && yooadmin_is_command_palette_available();
$yooadmin_toolbar_overflow_extras    = $yooadmin_command_palette_available || $ysh_show_width_control;

$yooadmin_network_admin_shell = function_exists('yooadmin_network_admin_shell_active') && yooadmin_network_admin_shell_active();
$yooadmin_subsite_network_breadcrumbs = function_exists('yooadmin_show_subsite_network_admin_breadcrumbs_link')
    && yooadmin_show_subsite_network_admin_breadcrumbs_link();
$yooadmin_show_lang_switcher = function_exists('yooadmin_should_show_admin_language_switcher')
    && yooadmin_should_show_admin_language_switcher();

$yooadmin_desktop_surface_breadcrumbs = function_exists('yooadmin_should_use_desktop_surface_breadcrumbs')
    && yooadmin_should_use_desktop_surface_breadcrumbs();
$yooadmin_show_maintenance_shell = function_exists('yooadmin_should_render_maintenance_mode_control')
    && yooadmin_should_render_maintenance_mode_control('shell');

if ($yooadmin_desktop_surface_breadcrumbs
    || $breadcrumbs_html !== ''
    || !empty($toolbar_shortcuts)
    || $ysh_show_appearance
    || $ysh_show_width_control
    || $yooadmin_network_admin_shell
    || $yooadmin_subsite_network_breadcrumbs
    || $yooadmin_command_palette_available
    || $yooadmin_show_lang_switcher
    || $yooadmin_show_maintenance_shell) :
?>
    <div class="yp-breadcrumbs-bar">
        <div class="yp-breadcrumbs-inner">
            <?php
            if ($yooadmin_desktop_surface_breadcrumbs) {
                echo '<div class="yp-breadcrumbs-brand-cluster">';
                if (function_exists('yooadmin_render_desktop_surface_breadcrumbs_brand')) {
                    yooadmin_render_desktop_surface_breadcrumbs_brand();
                }
                echo '</div>';
            }
            if ($breadcrumbs_html !== '') {
                echo wp_kses_post($breadcrumbs_html);
            }
            ?>

            <?php if (
                $yooadmin_show_maintenance_shell
                || $ysh_show_appearance
                || $ysh_show_width_control
                || !empty($toolbar_shortcuts)
                || $yooadmin_network_admin_shell
                || $yooadmin_subsite_network_breadcrumbs
                || $yooadmin_command_palette_available
                || $yooadmin_show_lang_switcher
            ) : ?>
            <div class="yp-breadcrumbs-tools">
                <?php if ($yooadmin_network_admin_shell) : ?>
                    <span class="yp-network-admin-badge yp-network-admin-badge--breadcrumbs" role="status" aria-label="<?php esc_attr_e('Network Admin', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-admin-multisite" aria-hidden="true"></span>
                        <span class="yp-network-admin-badge__label"><?php esc_html_e('Network Admin', 'yooadmin'); ?></span>
                    </span>
                <?php elseif ($yooadmin_subsite_network_breadcrumbs) : ?>
                    <a
                        href="<?php echo esc_url(network_admin_url()); ?>"
                        class="yp-network-admin-badge yp-network-admin-badge--breadcrumbs yp-network-admin-badge--link"
                        aria-label="<?php esc_attr_e('Network Admin', 'yooadmin'); ?>"
                        title="<?php esc_attr_e('Network Admin', 'yooadmin'); ?>"
                    >
                        <span class="dashicons dashicons-admin-multisite" aria-hidden="true"></span>
                        <span class="yp-network-admin-badge__label"><?php esc_html_e('Network Admin', 'yooadmin'); ?></span>
                    </a>
                <?php endif; ?>

                <?php if ($yooadmin_show_maintenance_shell && function_exists('yooadmin_render_maintenance_mode_control')) : ?>
                    <div class="yp-breadcrumbs-maintenance">
                        <?php yooadmin_render_maintenance_mode_control('shell'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($ysh_show_appearance && function_exists('yooadmin_studio_hub_render_appearance_control')) : ?>
                    <?php
                    yooadmin_studio_hub_render_appearance_control([
                        'toggle_id' => 'ysh-appearance-toggle',
                        'menu_id'   => 'ysh-appearance-menu',
                    ]);
                    ?>
                <?php endif; ?>

                <?php if ($yooadmin_show_lang_switcher && function_exists('yooadmin_render_breadcrumbs_language_switcher')) {
                    yooadmin_render_breadcrumbs_language_switcher();
                } ?>

            <?php if (!empty($toolbar_shortcuts) || $yooadmin_toolbar_overflow_extras) : ?>
                <?php
                $toolbar_shortcuts_visible  = [];
                $toolbar_shortcuts_overflow = [];
                if (!empty($toolbar_shortcuts)) {
                    $toolbar_visible_max = max(1, (int) apply_filters('yooadmin_toolbar_shortcuts_visible_max', 4));
                    if (function_exists('yooadmin_split_toolbar_shortcuts_for_display')) {
                        [$toolbar_shortcuts_visible, $toolbar_shortcuts_overflow] = yooadmin_split_toolbar_shortcuts_for_display(
                            $toolbar_shortcuts_mirrored,
                            $custom_shortcuts,
                            $toolbar_visible_max
                        );
                    } else {
                        $toolbar_shortcuts_visible  = array_values(array_slice($toolbar_shortcuts, 0, $toolbar_visible_max));
                        $toolbar_shortcuts_overflow = array_values(array_slice($toolbar_shortcuts, -max(0, count($toolbar_shortcuts) - $toolbar_visible_max)));
                    }
                }
                ?>
                <nav class="yp-toolbar-shortcuts" aria-label="<?php esc_attr_e('Quick actions', 'yooadmin'); ?>">
                    <?php
                    if (function_exists('yooadmin_render_toolbar_shortcut_item')) {
                        foreach ($toolbar_shortcuts_visible as $shortcut) {
                            if (is_array($shortcut)) {
                                yooadmin_render_toolbar_shortcut_item($shortcut);
                            }
                        }
                    }
                    ?>
                    <?php if (!empty($toolbar_shortcuts_overflow) || $yooadmin_toolbar_overflow_extras) : ?>
                        <div class="yp-toolbar-item has-children yp-toolbar-item--overflow" data-toolbar-id="toolbar-overflow">
                            <button type="button"
                                    class="yp-toolbar-trigger yp-toolbar-more-trigger"
                                    aria-haspopup="true"
                                    aria-expanded="false"
                                    data-label-more="<?php esc_attr_e('More shortcuts', 'yooadmin'); ?>"
                                    data-label-close="<?php esc_attr_e('Back to shortcuts', 'yooadmin'); ?>"
                                    title="<?php esc_attr_e('More shortcuts', 'yooadmin'); ?>"
                                    aria-label="<?php esc_attr_e('More shortcuts', 'yooadmin'); ?>">
                                <span class="yp-toolbar-content">
                                    <span class="yp-toolbar-icon" aria-hidden="true">
                                        <span class="dashicons dashicons-ellipsis yp-toolbar-more-icon yp-toolbar-more-icon--closed" aria-hidden="true"></span>
                                        <span class="dashicons dashicons-no-alt yp-toolbar-more-icon yp-toolbar-more-icon--open" aria-hidden="true"></span>
                                    </span>
                                </span>
                            </button>
                            <div class="yp-toolbar-menu yp-toolbar-menu--overflow" role="menu">
                                <div class="yp-toolbar-overflow-strip" role="group" aria-label="<?php esc_attr_e('More shortcuts', 'yooadmin'); ?>">
                                    <?php
                                    if ($yooadmin_command_palette_available && function_exists('yooadmin_render_command_palette_trigger')) {
                                        yooadmin_render_command_palette_trigger(
                                            [
                                                'id'    => '',
                                                'class' => 'yp-command-palette-trigger--overflow-menu',
                                                'role'  => 'menuitem',
                                            ]
                                        );
                                    }
                                    if ($ysh_show_width_control && function_exists('yooadmin_studio_hub_render_width_control')) {
                                        yooadmin_studio_hub_render_width_control(
                                            [
                                                'context'   => 'overflow',
                                                'id_prefix' => 'ysh-overflow',
                                                'toggle_id' => 'ysh-overflow-width-toggle',
                                                'menu_id'   => 'ysh-overflow-width-menu',
                                            ]
                                        );
                                    }
                                    ?>
                                    <?php
                                    if (function_exists('yooadmin_render_toolbar_shortcut_item')) {
                                        foreach ($toolbar_shortcuts_overflow as $shortcut) {
                                            if (is_array($shortcut)) {
                                                yooadmin_render_toolbar_shortcut_item($shortcut);
                                            }
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<aside id="yps-sidebar" class="yps-sidebar" aria-hidden="true">
    <div class="yps-side-header">
        <span class="yps-side-logo">
            <?php if ($logo_url || $logo_default_url): ?>
                <img src="<?php echo esc_url($logo_url ?: $logo_default_url); ?>"
                     alt="<?php esc_attr_e('YOOAdmin Logo', 'yooadmin'); ?>">
            <?php else: ?>
                <span class="yps-side-title">YOOAdmin</span>
            <?php endif; ?>
        </span>
        <button class="yps-close" type="button" aria-label="<?php echo esc_attr__('Close menu', 'yooadmin'); ?>" data-yps-close>
            <span class="dashicons dashicons-no" aria-hidden="true"></span>
        </button>
    </div>

    <nav class="yps-nav" role="navigation" aria-label="<?php echo esc_attr__('Main admin menu', 'yooadmin'); ?>"></nav>
    
    <!-- Focus Mode Toggle -->
    <div class="yps-focus-toggle">
        <label for="yp-toggle-clean-view" class="yps-focus-label">
            <span class="yps-focus-icon dashicons dashicons-visibility"></span>
            <span class="yps-focus-text"><?php esc_html_e('Focus Mode', 'yooadmin'); ?></span>
            <input type="checkbox" id="yp-toggle-clean-view" class="yps-focus-input" data-can-manage-policy="<?php echo $yooadmin_can_manage_focus_policy ? '1' : '0'; ?>">
            <span class="yps-focus-switch">
                <span class="yps-focus-slider"></span>
            </span>
        </label>
    </div>
</aside>
</div><!-- /.yp-header-wrapper -->
<?php if ($yp_show_subsite_context_bar) : ?></div><!-- /.yp-subsite-chrome --><?php endif; ?>


<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
