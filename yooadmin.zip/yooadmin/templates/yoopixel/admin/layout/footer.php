<?php
/**
 * YOOAdmin - Admin layout footer
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_detect_plugin_version')) {
    function yooadmin_detect_plugin_version(): string {
        // 1) Constant (optional)
        if (defined('YOOADMIN_VERSION') && YOOADMIN_VERSION) {
            return (string) YOOADMIN_VERSION;
        }

        // 2) Read plugin header from the known root file
        $main = defined('YOOADMIN_PLUGIN_FILE')
            ? YOOADMIN_PLUGIN_FILE
            : dirname(__DIR__, 2) . '/yooadmin.php';

        if (file_exists($main)) {
            if (!function_exists('get_plugin_data')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $data = get_plugin_data($main, false, false);
            if (!empty($data['Version'])) {
                return (string) $data['Version'];
            }
        }

        // 3) Fallback to option if you ever store it
        $opt = get_option('yooadmin_version');
        return $opt ? (string) $opt : '—';
    }
}

$yooadmin_plugin_version = yooadmin_detect_plugin_version();
$yooadmin_wp_version     = get_bloginfo('version');
?>
<div class="yp-dashboard-footer">
  <div class="yp-footer">
    <div class="yp-footer-right">
      <span class="yp-meta"><a href="#" class="yp-open-about-modal" data-yp-about-trigger><?php esc_html_e('About', 'yooadmin'); ?></a></span>
      <span class="yp-bullet">•</span>
      <span class="yp-meta"><a href="<?php echo esc_url('https://www.yooadmin.io'); ?>" target="_blank" rel="noopener noreferrer">YOOAdmin</a> v<?php echo esc_html($yooadmin_plugin_version); ?></span>
      <span class="yp-bullet">•</span>
      <span class="yp-meta"><a href="<?php echo esc_url('https://www.wordpress.org/'); ?>" target="_blank" rel="noopener noreferrer">WordPress</a> v<?php echo esc_html($yooadmin_wp_version); ?></span>
    </div>
  </div>
</div>

<?php
// Include popup template for Website Management functionality
$yooadmin_popup_template = dirname(__DIR__) . '/popup.php';
if (file_exists($yooadmin_popup_template)) {
    include $yooadmin_popup_template;
}
?>