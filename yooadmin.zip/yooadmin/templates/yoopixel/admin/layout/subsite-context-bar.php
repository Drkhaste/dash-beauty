<?php
/**
 * Subsite context strip (network admin viewing a site dashboard).
 *
 * @package YOOAdmin
 * @var array{site_name:string,site_url:string,site_url_label:string,back_url:string,back_label:string,message:string} $bar
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

if (empty($bar) || ! is_array($bar)) {
    return;
}

$site_name      = isset($bar['site_name']) ? (string) $bar['site_name'] : '';
$site_url       = isset($bar['site_url']) ? (string) $bar['site_url'] : '';
$site_url_label = isset($bar['site_url_label']) ? (string) $bar['site_url_label'] : '';
$back_url       = isset($bar['back_url']) ? (string) $bar['back_url'] : '';
$back_label     = isset($bar['back_label']) ? (string) $bar['back_label'] : '';
$message        = isset($bar['message']) ? (string) $bar['message'] : '';

if ($site_name === '' || $site_url === '' || $back_url === '') {
    return;
}

if ($site_url_label === '') {
    $site_url_label = $site_url;
}

?>
<script>
(function(){try{if(localStorage.getItem('yooadmin_subsite_context_bar_collapsed')==='1'){document.documentElement.classList.add('yp-subsite-context-bar-is-collapsed');}}catch(e){}})();
</script>
<style id="yp-subsite-context-bar-critical">
html.yp-subsite-context-bar-is-collapsing #yp-subsite-context-bar{background:transparent!important;border-bottom:0!important;pointer-events:none!important}
html.yp-subsite-context-bar-is-collapsed #yp-subsite-context-bar{max-height:0!important;opacity:0!important;overflow:hidden!important;pointer-events:none!important;background:transparent!important;border-bottom:0!important}
html.yp-subsite-context-bar-is-collapsed,body.yp-subsite-context-bar-is-collapsed{--yp-subsite-context-bar-h:0px}
html.yp-subsite-context-bar-is-collapsed #yp-subsite-context-bar .yp-subsite-context-bar__row,html.yp-subsite-context-bar-is-collapsing #yp-subsite-context-bar .yp-subsite-context-bar__row{min-height:0!important;padding:0!important}
.yp-subsite-context-bar__expand-rail{display:none!important;background:transparent!important}
html.yp-subsite-context-bar-is-collapsed .yp-subsite-context-bar__expand-rail{display:block!important;position:absolute;top:0;inset-inline:0;height:0;overflow:visible;z-index:100002;background:transparent!important;pointer-events:none}
html.yp-subsite-context-bar-is-collapsed .yp-subsite-context-bar__expand-rail .yp-subsite-context-bar__expand-row{height:0!important;min-height:0!important;align-items:flex-start!important;padding:0!important;margin-block:0!important;margin-inline:auto!important;max-width:var(--ysh-layout-max,none)!important;width:100%!important;box-sizing:border-box!important}
html.yp-subsite-context-bar-is-collapsed .yp-subsite-context-bar__expand{align-self:flex-start!important}
html.yp-subsite-context-bar-is-collapsed .yp-subsite-context-bar__expand-rail .yp-header-left,html.yp-subsite-context-bar-is-collapsed .yp-subsite-context-bar__expand-rail .yp-header-center{display:none!important}
html.yp-subsite-context-bar-is-collapsed .yp-subsite-context-bar__expand{pointer-events:auto}
</style>
<div
    id="yp-subsite-context-bar"
    class="yp-subsite-context-bar"
    role="region"
    aria-label="<?php esc_attr_e('Site context', 'yooadmin'); ?>"
>
    <div class="yp-header yp-subsite-context-bar__row">
        <div class="yp-header-left">
            <a
                href="<?php echo esc_url($back_url); ?>"
                class="yp-subsite-context-bar__back"
                aria-label="<?php echo esc_attr($back_label); ?>"
            >
                <span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span>
            </a>
            <div class="yp-subsite-context-bar__text" role="status">
                <span class="yp-subsite-context-bar__message"><?php echo esc_html($message); ?></span>
                <span class="yp-subsite-context-bar__site-meta">
                    <strong class="yp-subsite-context-bar__site"><?php echo esc_html($site_name); ?></strong>
                    <span class="yp-subsite-context-bar__sep" aria-hidden="true">·</span>
                    <a
                        class="yp-subsite-context-bar__url"
                        href="<?php echo esc_url($site_url); ?>"
                        target="_blank"
                        rel="noopener noreferrer"
                    ><?php echo esc_html($site_url_label); ?></a>
                </span>
            </div>
        </div>
        <div class="yp-header-center" aria-hidden="true"></div>
        <div class="yp-header-right">
            <button
                type="button"
                class="yp-subsite-context-bar__dismiss"
                aria-label="<?php esc_attr_e('Hide site context', 'yooadmin'); ?>"
            >
                <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
            </button>
        </div>
    </div>
</div>
<div class="yp-subsite-context-bar__expand-rail" id="yp-subsite-context-expand-rail">
    <div class="yp-header yp-subsite-context-bar__expand-row">
        <div class="yp-header-left" aria-hidden="true"></div>
        <div class="yp-header-center" aria-hidden="true"></div>
        <div class="yp-header-right">
            <button
                type="button"
                id="yp-subsite-context-expand"
                class="yp-subsite-context-bar__expand"
                aria-label="<?php esc_attr_e('Show site context', 'yooadmin'); ?>"
            >
                <span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
            </button>
        </div>
    </div>
</div>
