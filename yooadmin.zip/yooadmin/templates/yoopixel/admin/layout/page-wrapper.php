<?php
/**
 * YOOAdmin - Page wrapper layout
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

include __DIR__ . '/../dashboard-header.php';
?>

<div class="yp-page-wrapper">
  <?php
  if (isset($yooadmin_inner_page)) {
      include $yooadmin_inner_page;
  }
  ?>
</div>

<?php include __DIR__ . '/../dashboard-footer.php'; ?>
