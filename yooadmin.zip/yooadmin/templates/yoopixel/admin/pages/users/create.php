<?php
/**
 * YOOAdmin - Create user template
 *
 * @package YOOAdmin
 * @since 1.0.0
 *
 * @var WP_Error  $errors
 * @var array     $roles
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

$list_url = admin_url('admin.php?page=yooadmin-users');
// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in controller
$send_notification_checked = !empty($_POST['send_notification']);
?>

<div class="wrap yooadmin-user-create">
    <div class="yoo-user-create-layout">
        <section class="yoo-user-form-panel">
            <div class="yoo-user-form-header">
                <span class="yoo-users-hero__eyebrow"><?php esc_html_e('Workspace · Invite', 'yooadmin'); ?></span>
                <h1><?php esc_html_e('Add user', 'yooadmin'); ?></h1>
                <p><?php esc_html_e('Craft a welcome-ready account with rich details, strong security, and the correct privileges from day one.', 'yooadmin'); ?></p>
            </div>

            <?php if ($errors instanceof WP_Error && $errors->has_errors()): ?>
                <div class="notice notice-error yoo-user-form-notice">
                    <ul>
                        <?php foreach ($errors->get_error_messages() as $message): ?>
                            <li><?php echo esc_html($message); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="post" class="yoo-user-form" novalidate>
                <?php wp_nonce_field('yooadmin_create_user'); ?>
                <input type="hidden" name="page" value="yooadmin-users-new">

                <?php // phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verified in controller before template inclusion. ?>
                <div class="yoo-form-grid">
                    <div class="yoo-form-field">
                        <label for="yooadmin-user-login">
                            <?php esc_html_e('Username', 'yooadmin'); ?> <span class="required">*</span>
                            <?php echo yooadmin_user_field_help_tooltip(__('Visible across the admin. Letters, numbers, underscores only.', 'yooadmin')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </label>
                        <input type="text" id="yooadmin-user-login" name="user_login" autocomplete="off" value="<?php echo isset($_POST['user_login']) ? esc_attr(sanitize_text_field(wp_unslash($_POST['user_login']))) : ''; ?>" required>
                        <div class="yoo-field-feedback" data-for="user_login"></div>
                    </div>

                    <div class="yoo-form-field">
                        <label for="yooadmin-user-email">
                            <?php esc_html_e('Email address', 'yooadmin'); ?> <span class="required">*</span>
                            <?php echo yooadmin_user_field_help_tooltip(__('Used for notifications and password resets.', 'yooadmin')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </label>
                        <input type="email" id="yooadmin-user-email" name="user_email" autocomplete="off" value="<?php echo isset($_POST['user_email']) ? esc_attr(sanitize_email(wp_unslash($_POST['user_email']))) : ''; ?>" required>
                        <div class="yoo-field-feedback" data-for="user_email"></div>
                    </div>

                    <div class="yoo-form-field">
                        <label for="yooadmin-first-name"><?php esc_html_e('First name', 'yooadmin'); ?></label>
                        <input type="text" id="yooadmin-first-name" name="first_name" value="<?php echo isset($_POST['first_name']) ? esc_attr(sanitize_text_field(wp_unslash($_POST['first_name']))) : ''; ?>">
                    </div>

                    <div class="yoo-form-field">
                        <label for="yooadmin-last-name"><?php esc_html_e('Last name', 'yooadmin'); ?></label>
                        <input type="text" id="yooadmin-last-name" name="last_name" value="<?php echo isset($_POST['last_name']) ? esc_attr(sanitize_text_field(wp_unslash($_POST['last_name']))) : ''; ?>">
                    </div>

                    <div class="yoo-form-field">
                        <label for="yooadmin-display-name"><?php esc_html_e('Display name', 'yooadmin'); ?></label>
                        <input type="text" id="yoo-display-name" name="display_name" value="<?php echo isset($_POST['display_name']) ? esc_attr(sanitize_text_field(wp_unslash($_POST['display_name']))) : ''; ?>" placeholder="<?php esc_attr_e('Auto-generated from first & last name', 'yooadmin'); ?>">
                    </div>

                    <div class="yoo-form-field yoo-form-field--has-select">
                        <label for="yooadmin-role">
                            <?php esc_html_e('Role', 'yooadmin'); ?>
                            <?php echo yooadmin_user_field_help_tooltip(__('Assign the minimum level needed for this user’s responsibilities.', 'yooadmin')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </label>
                        <select id="yooadmin-role" name="role" class="yoo-user-form-select" data-yoo-user-role-select="1">
                            <?php foreach ($roles as $role_key => $role_data): ?>
                                <option value="<?php echo esc_attr($role_key); ?>" <?php selected(isset($_POST['role']) ? sanitize_text_field(wp_unslash($_POST['role'])) : 'subscriber', $role_key); ?>>
                                    <?php echo esc_html(yooadmin_translate_role_label($role_key, $role_data)); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <?php // phpcs:enable WordPress.Security.NonceVerification.Missing ?>

                <div class="yoo-form-divider"></div>

                <div class="yoo-password-field">
                    <div class="yoo-password-field__header">
                        <label for="yooadmin-user-pass">
                            <?php esc_html_e('Password', 'yooadmin'); ?>
                            <?php echo yooadmin_user_field_help_tooltip(__('Use at least 10 characters with letters, numbers, and symbols for best results.', 'yooadmin')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </label>
                        <button type="button" class="yp-yoo-btn yp-yoo-btn--secondary yoo-generate-password">
                            <span class="dashicons dashicons-update" aria-hidden="true"></span>
                            <?php esc_html_e('Generate secure password', 'yooadmin'); ?>
                        </button>
                    </div>
                    <div class="yoo-password-control">
                        <input type="password" id="yooadmin-user-pass" name="user_pass" autocomplete="new-password" placeholder="<?php esc_attr_e('Leave blank to auto-generate', 'yooadmin'); ?>">
                        <button type="button" class="yoo-password-toggle" aria-pressed="false">
                            <span class="dashicons dashicons-visibility"></span>
                            <span class="screen-reader-text"><?php esc_html_e('Toggle password visibility', 'yooadmin'); ?></span>
                        </button>
                    </div>
                    <div class="yoo-password-meter" data-strength="empty">
                        <span class="yoo-password-meter__bar"></span>
                        <span class="yoo-password-meter__label"><?php esc_html_e('Strength: Empty', 'yooadmin'); ?></span>
                    </div>
                </div>

                <label class="yoo-user-form-checkbox">
                    <input type="checkbox" name="send_notification" value="1" <?php checked($send_notification_checked); ?>>
                    <span class="yoo-user-form-checkbox__text"><?php esc_html_e('Email the user a welcome note with access instructions.', 'yooadmin'); ?></span>
                </label>

                <div class="yoo-form-actions">
                    <a class="yp-yoo-btn yp-yoo-btn--secondary" href="<?php echo esc_url($list_url); ?>">
                        <?php esc_html_e('Cancel', 'yooadmin'); ?>
                    </a>
                    <button type="submit" class="yp-yoo-btn yp-yoo-btn--primary">
                        <?php esc_html_e('Create user', 'yooadmin'); ?>
                    </button>
                </div>
            </form>
        </section>

        <aside class="yoo-user-side-panel">
            <div class="yoo-side-card">
                <h3><?php esc_html_e('Role highlights', 'yooadmin'); ?></h3>
                <ul>
                    <?php foreach ($roles as $role_key => $role_data): ?>
                        <li>
                            <strong><?php echo esc_html(yooadmin_translate_role_label($role_key, $role_data)); ?></strong>
                            <span><?php echo esc_html(yooadmin_user_role_highlight_description($role_key)); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="yoo-side-card">
                <h3><?php esc_html_e('Security checklist', 'yooadmin'); ?></h3>
                <ul class="yoo-side-checklist">
                    <li><?php esc_html_e('Use unique emails for each account', 'yooadmin'); ?></li>
                    <li><?php esc_html_e('Empower 2FA for administrators', 'yooadmin'); ?></li>
                    <li><?php esc_html_e('Rotate temporary passwords after first login', 'yooadmin'); ?></li>
                </ul>
            </div>
        </aside>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
