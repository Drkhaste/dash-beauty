<?php
/**
 * YOOAdmin - User profile template
 *
 * @package YOOAdmin
 * @since 1.0.0
 *
 * @var WP_User   $user
 * @var array     $roles
 * @var WP_Error  $errors
 * @var bool      $updated
 * @var bool      $show_role_field
 * @var bool      $is_own_profile
 * @var bool      $can_list_users
 * @var bool      $can_send_password_reset
 * @var string    $profile_back_url
 * @var string    $profile_back_label
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound, WordPress.Security.NonceVerification.Recommended
// Template file. Variables are scoped to the loading function and not global. GET params are read-only display flags.

$is_own_profile = !empty($is_own_profile);
$can_list_users = !empty($can_list_users);
$can_send_password_reset = !empty($can_send_password_reset);
$profile_back_url = isset($profile_back_url) ? (string) $profile_back_url : admin_url('admin.php?page=yooadmin-users');
$profile_back_label = isset($profile_back_label) ? (string) $profile_back_label : __('Back to Users', 'yooadmin');
$can_view_post_count = $is_own_profile ? current_user_can('edit_posts') : current_user_can('edit_others_posts');
$list_url = admin_url('admin.php?page=yooadmin-users');
$edit_link = get_edit_user_link($user->ID);
$created = !empty($_GET['created']);
$registration = strtotime($user->user_registered);
$post_count = count_user_posts($user->ID);
$last_activity = get_user_meta($user->ID, 'yooadmin_last_activity', true);
$days_since = max(0, floor((time() - $registration) / DAY_IN_SECONDS));
$profile_avatar_source = function_exists('yooadmin_profile_get_avatar_source')
    ? yooadmin_profile_get_avatar_source((int) $user->ID)
    : 'yooadmin';
$profile_avatar_native_ui = function_exists('yooadmin_profile_avatar_native_ui_enabled')
    && yooadmin_profile_avatar_native_ui_enabled((int) $user->ID);
$profile_avatar_plugin_panel = function_exists('yooadmin_profile_avatar_uses_plugin_panel')
    && yooadmin_profile_avatar_uses_plugin_panel((int) $user->ID);
$can_edit_profile_avatar = current_user_can('edit_user', $user->ID);
$profile_has_photo_plugins = function_exists('yooadmin_profile_photo_plugins_available')
    && yooadmin_profile_photo_plugins_available($user);
$profile_avatar_choices = function_exists('yooadmin_profile_avatar_source_choices')
    ? yooadmin_profile_avatar_source_choices()
    : [];
$profile_avatar_descriptions = function_exists('yooadmin_profile_avatar_source_descriptions')
    ? yooadmin_profile_avatar_source_descriptions()
    : [];
$profile_has_yooadmin_photo = function_exists('yooadmin_user_has_custom_avatar')
    && yooadmin_user_has_custom_avatar((int) $user->ID);
$profile_row_actions = (!$is_own_profile && function_exists('yooadmin_users_build_profile_actions'))
    ? yooadmin_users_build_profile_actions($user)
    : [];
?>

<div class="wrap yooadmin-user-profile<?php echo $is_own_profile ? ' is-own-profile' : ''; ?>">
    <header class="yoo-profile-hero">
        <a class="yoo-breadcrumb" href="<?php echo esc_url($profile_back_url); ?>">
            <span class="dashicons dashicons-arrow-left-alt2"></span>
            <?php echo esc_html($profile_back_label); ?>
        </a>

        <div class="yoo-profile-card yoo-profile-card--hero">
        <div class="yoo-profile-hero__row yoo-profile-hero__row--top">
            <div class="yoo-profile-identity">
                <div class="yoo-profile-avatar-block">
                <div class="yoo-profile-avatar-wrap">
                <div
                    class="yoo-profile-avatar yoo-profile-avatar--source-<?php echo esc_attr($profile_avatar_source); ?>"
                    data-avatar-source="<?php echo esc_attr($profile_avatar_source); ?>"
                    id="yoo-profile-avatar"
                >
                    <?php
// get_avatar() respects the selected profile photo source.
add_filter('yooadmin_avatar_use_blank_placeholder', '__return_true');
echo wp_kses_post(get_avatar($user->ID, 110));
remove_filter('yooadmin_avatar_use_blank_placeholder', '__return_true');

$is_online = false;
if ($last_activity) {
    $activity_time = (int) $last_activity;
    $minutes_ago   = floor((time() - $activity_time) / 60);
    $is_online     = $minutes_ago < 15;
}

if ($can_edit_profile_avatar) :
    ?>
                    <div class="yoo-avatar-upload-overlay" id="yoo-avatar-upload-overlay"<?php echo $profile_avatar_native_ui ? '' : ' hidden'; ?>>
                        <label for="yoo-avatar-upload-input" aria-label="<?php esc_attr_e('Upload Photo', 'yooadmin'); ?>">
                            <span class="dashicons dashicons-camera" aria-hidden="true"></span>
                        </label>
                        <input type="file" id="yoo-avatar-upload-input" accept="image/*" style="display: none;"
                            data-user-id="<?php echo esc_attr($user->ID); ?>"
                            data-nonce="<?php echo esc_attr(wp_create_nonce('yooadmin_upload_avatar')); ?>">
                    </div>
                    <button type="button" id="yoo-avatar-delete-btn"
                        class="yoo-avatar-delete-btn"
                        data-user-id="<?php echo esc_attr($user->ID); ?>"
                        data-nonce="<?php echo esc_attr(wp_create_nonce('yooadmin_upload_avatar')); ?>"
                        data-has-yooadmin-photo="<?php echo $profile_has_yooadmin_photo ? '1' : '0'; ?>"
                        title="<?php esc_attr_e('Remove Photo', 'yooadmin'); ?>"
                        aria-label="<?php esc_attr_e('Remove Photo', 'yooadmin'); ?>"
                        <?php echo $profile_avatar_native_ui ? '' : ' hidden'; ?>>
                        <span class="dashicons dashicons-trash" aria-hidden="true"></span>
                    </button>
                    <?php endif; ?>
                    <span class="yoo-profile-online-badge <?php echo $is_online ? 'is-online' : 'is-offline'; ?>" aria-hidden="true"></span>
                </div>
                </div>
                <?php if ($can_edit_profile_avatar) : ?>
                <span
                    class="yoo-profile-avatar__source-label"
                    id="yoo-profile-avatar-source-hint"
                    <?php echo $profile_avatar_native_ui ? ' hidden' : ''; ?>
                >
                    <?php
                    if ($profile_avatar_source === 'gravatar') {
                        esc_html_e('Gravatar', 'yooadmin');
                    } elseif ($profile_avatar_source === 'plugins') {
                        esc_html_e('Plugin photo', 'yooadmin');
                    }
                    ?>
                </span>
                <?php endif; ?>
                </div>
                <div class="yoo-profile-info">
                    <div class="yoo-profile-header">
                        <h1 class="yoo-profile-name"><?php echo esc_html($user->display_name ?: $user->user_login); ?></h1>
                        <div class="yoo-profile-tags">
                            <?php foreach ($user->roles as $role_key): ?>
                                <span class="yoo-role-tag"><?php echo esc_html(yooadmin_translate_role_label($role_key)); ?></span>
                            <?php
endforeach; ?>
                        </div>
                    </div>
                    <div class="yoo-profile-meta-strip" aria-label="<?php esc_attr_e('Account details', 'yooadmin'); ?>">
                        <span class="yoo-profile-meta-item yoo-profile-meta-item--email">
                            <span class="dashicons dashicons-email" aria-hidden="true"></span>
                            <a href="mailto:<?php echo esc_attr($user->user_email); ?>"><?php echo esc_html($user->user_email); ?></a>
                        </span>
                        <span class="yoo-profile-meta-sep" aria-hidden="true">·</span>
                        <span class="yoo-profile-meta-item yoo-profile-meta-item--login">
                            <span class="dashicons dashicons-admin-users" aria-hidden="true"></span>
                            <span><?php echo esc_html($user->user_login); ?></span>
                        </span>
                        <span class="yoo-profile-meta-sep" aria-hidden="true">·</span>
                        <span class="yoo-profile-meta-item yoo-profile-meta-item--posts">
                            <span class="dashicons dashicons-admin-post" aria-hidden="true"></span>
                            <?php if ($can_view_post_count) : ?>
                            <a href="<?php echo esc_url(admin_url('edit.php?author=' . $user->ID)); ?>">
                                <?php /* translators: %d: number of posts */ echo esc_html(sprintf(_n('%d post', '%d posts', $post_count, 'yooadmin'), $post_count)); ?>
                            </a>
                            <?php else : ?>
                            <span><?php /* translators: %d: number of posts */ echo esc_html(sprintf(_n('%d post', '%d posts', $post_count, 'yooadmin'), $post_count)); ?></span>
                            <?php endif; ?>
                        </span>
                        <span class="yoo-profile-meta-sep" aria-hidden="true">·</span>
                        <span class="yoo-profile-meta-item yoo-profile-meta-item--joined">
                            <span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span>
                            <span>
                                <?php /* translators: %d: number of days */ echo esc_html(sprintf(_n('%d day', '%d days', $days_since, 'yooadmin'), $days_since)); ?>
                                <span class="yoo-profile-meta-muted"><?php echo esc_html(date_i18n(get_option('date_format'), $registration)); ?></span>
                            </span>
                        </span>
                        <?php if ($can_list_users) : ?>
                        <span class="yoo-profile-meta-sep" aria-hidden="true">·</span>
                        <span class="yoo-profile-meta-item yoo-profile-meta-item--id">
                            <span class="dashicons dashicons-id" aria-hidden="true"></span>
                            <span>#<?php echo esc_html((string) $user->ID); ?></span>
                        </span>
                        <?php endif; ?>
                        <?php if (!$is_own_profile) : ?>
                        <span class="yoo-profile-meta-sep" aria-hidden="true">·</span>
                        <span class="yoo-profile-meta-item yoo-profile-meta-item--activity">
                            <span class="dashicons dashicons-clock" aria-hidden="true"></span>
                            <?php if ($last_activity) :
                                $activity_time = (int) $last_activity;
                                $minutes_ago = floor((time() - $activity_time) / 60);
                                ?>
                            <span>
                                <?php
                                if ($minutes_ago < 15) {
                                    esc_html_e('Online now', 'yooadmin');
                                } else {
                                    echo esc_html(human_time_diff($activity_time, current_time('timestamp')) . ' ' . __('ago', 'yooadmin'));
                                }
                                ?>
                            </span>
                            <?php else : ?>
                            <span class="yoo-profile-meta-muted"><?php esc_html_e('No activity tracked', 'yooadmin'); ?></span>
                            <?php endif; ?>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if (!$is_own_profile && ($can_send_password_reset || $can_list_users || $profile_row_actions !== [])) : ?>
                <div class="yoo-profile-hero__actions">
                    <?php if ($can_list_users) : ?>
                    <a class="yoo-button yoo-button--ghost" href="mailto:<?php echo esc_attr($user->user_email); ?>">
                        <span class="dashicons dashicons-email-alt"></span>
                        <?php esc_html_e('Send email', 'yooadmin'); ?>
                    </a>
                    <?php endif; ?>
                    <?php if ($can_send_password_reset) : ?>
                    <button type="button" class="yoo-button yoo-button--ghost yoo-send-password-reset" data-user-id="<?php echo esc_attr($user->ID); ?>">
                        <span class="dashicons dashicons-admin-links"></span>
                        <?php esc_html_e('Send password reset link', 'yooadmin'); ?>
                    </button>
                    <?php endif; ?>
                    <?php if ($profile_row_actions !== [] && function_exists('yooadmin_users_render_profile_actions')) : ?>
                        <?php yooadmin_users_render_profile_actions($user); ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        </div>
    </header>

    <?php if ($created): ?>
        <div class="notice notice-success is-inline">
            <p><?php esc_html_e('User created successfully.', 'yooadmin'); ?></p>
        </div>
    <?php
endif; ?>

    <?php if ($updated): ?>
        <?php
    $new_app_pass = get_transient('yooadmin_new_app_password_' . $user->ID);
    if ($new_app_pass):
        delete_transient('yooadmin_new_app_password_' . $user->ID);
?>
            <div class="notice notice-success is-inline">
                <p><strong><?php esc_html_e('New application password created:', 'yooadmin'); ?></strong></p>
                <p style="font-family: monospace; background: #f0f0f1; padding: 12px; border-radius: 4px; word-break: break-all;">
                    <?php echo esc_html($new_app_pass['password']); ?>
                </p>
                <p><em><?php esc_html_e('Make sure to copy this password now. You won\'t be able to see it again!', 'yooadmin'); ?></em></p>
            </div>
        <?php
    else: ?>
            <div class="notice notice-success is-inline">
                <p><?php esc_html_e('User details updated.', 'yooadmin'); ?></p>
            </div>
        <?php
    endif; ?>
    <?php
endif; ?>

    <?php if ($errors instanceof WP_Error && $errors->has_errors()): ?>
        <div class="notice notice-error is-inline">
            <ul>
                <?php foreach ($errors->get_error_messages() as $message): ?>
                    <li><?php echo esc_html($message); ?></li>
                <?php
    endforeach; ?>
            </ul>
        </div>
    <?php
endif; ?>

    <div class="yoo-profile-layout">
        <?php if (!$is_own_profile) : ?>
        <!-- Sidebar: Account Details (Read-only) -->
        <aside class="yoo-profile-sidebar">
            <div class="yoo-profile-panel">
                <h2><?php esc_html_e('Account details', 'yooadmin'); ?></h2>
                <div class="yoo-profile-details-grid">
                    <div class="yoo-profile-detail-row">
                        <span class="yoo-profile-detail-label">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php esc_html_e('Username', 'yooadmin'); ?>
                        </span>
                        <span class="yoo-profile-detail-value"><?php echo esc_html($user->user_login); ?></span>
                    </div>
                    <div class="yoo-profile-detail-row">
                        <span class="yoo-profile-detail-label">
                            <span class="dashicons dashicons-email"></span>
                            <?php esc_html_e('Email', 'yooadmin'); ?>
                        </span>
                        <span class="yoo-profile-detail-value">
                            <a href="mailto:<?php echo esc_attr($user->user_email); ?>"><?php echo esc_html($user->user_email); ?></a>
                        </span>
                    </div>
                    <div class="yoo-profile-detail-row">
                        <span class="yoo-profile-detail-label">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php esc_html_e('Display name', 'yooadmin'); ?>
                        </span>
                        <span class="yoo-profile-detail-value"><?php echo esc_html($user->display_name); ?></span>
                    </div>
                    <div class="yoo-profile-detail-row">
                        <span class="yoo-profile-detail-label">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php esc_html_e('First name', 'yooadmin'); ?>
                        </span>
                        <span class="yoo-profile-detail-value"><?php echo esc_html($user->first_name ?: __('Not provided', 'yooadmin')); ?></span>
                    </div>
                    <div class="yoo-profile-detail-row">
                        <span class="yoo-profile-detail-label">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php esc_html_e('Last name', 'yooadmin'); ?>
                        </span>
                        <span class="yoo-profile-detail-value"><?php echo esc_html($user->last_name ?: __('Not provided', 'yooadmin')); ?></span>
                    </div>
                    <div class="yoo-profile-detail-row">
                        <span class="yoo-profile-detail-label">
                            <span class="dashicons dashicons-groups"></span>
                            <?php esc_html_e('Roles', 'yooadmin'); ?>
                        </span>
                        <span class="yoo-profile-detail-value"><?php echo esc_html($user->roles ? yooadmin_translate_user_role_list($user->roles) : __('None assigned', 'yooadmin')); ?></span>
                    </div>
                    <div class="yoo-profile-detail-row">
                        <span class="yoo-profile-detail-label">
                            <span class="dashicons dashicons-admin-links"></span>
                            <?php esc_html_e('Website', 'yooadmin'); ?>
                        </span>
                        <span class="yoo-profile-detail-value">
                            <?php echo $user->user_url ? wp_kses_post('<a href="' . esc_url($user->user_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html($user->user_url) . '</a>') : esc_html__('Not provided', 'yooadmin'); ?>
                        </span>
                    </div>
                    <div class="yoo-profile-detail-row">
                        <span class="yoo-profile-detail-label">
                            <span class="dashicons dashicons-text-page"></span>
                            <?php esc_html_e('Biographical info', 'yooadmin'); ?>
                        </span>
                        <span class="yoo-profile-detail-value"><?php echo $user->description ? esc_html($user->description) : esc_html__('Not provided', 'yooadmin'); ?></span>
                    </div>
                </div>
            </div>
        </aside>
        <?php endif; ?>

        <?php
        $profile_has_security = function_exists('yooadmin_profile_has_plugin_sections') && yooadmin_profile_has_plugin_sections($user);
        $profile_has_sessions = function_exists('wp_get_all_sessions') && ($is_own_profile || $can_list_users);
        $profile_tabs         = [
            'account'  => __('Profile', 'yooadmin'),
            'password' => __('Password', 'yooadmin'),
        ];
        if ($profile_has_security) {
            $profile_tabs['security'] = __('Security', 'yooadmin');
        }
        if ($profile_has_sessions) {
            $profile_tabs['sessions'] = __('Sessions', 'yooadmin');
        }
        $profile_active_tab = 'account';
        if (isset($_GET['profile_tab'])) {
            $tab_candidate = sanitize_key(wp_unslash((string) $_GET['profile_tab']));
            if (isset($profile_tabs[ $tab_candidate ])) {
                $profile_active_tab = $tab_candidate;
            }
        }
        $show_locale_field = current_user_can('edit_user', $user->ID)
            && function_exists('wp_dropdown_languages')
            && function_exists('yooadmin_get_site_admin_language_locales')
            && count(yooadmin_get_site_admin_language_locales()) > 1;
        if ($show_locale_field) {
            $locale_selected = (string) $user->locale;
        }
        ?>

        <!-- Main Content: tabbed settings (YOOAdmin settings chrome) -->
        <main class="yoo-profile-main">
            <div class="yp-tabs yp-tabs--profile" data-yoo-profile-tabs>
                <div class="yp-tab-nav" role="tablist" aria-label="<?php esc_attr_e('Profile settings', 'yooadmin'); ?>">
                    <?php foreach ($profile_tabs as $tab_key => $tab_label) :
                        $profile_tab_href = function_exists('yooadmin_profile_tab_url')
                            ? yooadmin_profile_tab_url((int) $user->ID, $tab_key)
                            : add_query_arg('profile_tab', $tab_key, admin_url('admin.php?page=yooadmin-user'));
                        ?>
                        <a
                            href="<?php echo esc_url($profile_tab_href); ?>"
                            class="yp-tab<?php echo $profile_active_tab === $tab_key ? ' is-active' : ''; ?>"
                            role="tab"
                            aria-selected="<?php echo $profile_active_tab === $tab_key ? 'true' : 'false'; ?>"
                            id="yoo-profile-tab-<?php echo esc_attr($tab_key); ?>"
                            aria-controls="yoo-profile-panel-<?php echo esc_attr($tab_key); ?>"
                            data-profile-tab="<?php echo esc_attr($tab_key); ?>"
                        ><?php echo esc_html($tab_label); ?></a>
                    <?php endforeach; ?>
                </div>

                <div class="yp-tab-panels">
                    <div
                        class="yp-tab-panel yoo-profile-tab-panel<?php echo $profile_active_tab === 'account' ? ' is-active' : ''; ?>"
                        role="tabpanel"
                        id="yoo-profile-panel-account"
                        aria-labelledby="yoo-profile-tab-account"
                        data-profile-panel="account"
                        <?php echo $profile_active_tab === 'account' ? '' : ' hidden'; ?>
                    >
                        <p class="yp-help yoo-profile-tab-panel__lead">
                            <?php echo $is_own_profile ? esc_html__('Update your account details and how you appear in the admin.', 'yooadmin') : esc_html__('Edit this user’s profile details and permissions.', 'yooadmin'); ?>
                        </p>
                        <?php
                        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only status flags.
                        $profile_email_flash = isset($_GET['email_updated']) ? 'updated'
                            : (isset($_GET['email_error']) ? 'error'
                            : (isset($_GET['email_dismissed']) ? 'dismissed' : ''));
                        ?>
                        <?php if ($profile_email_flash === 'updated') : ?>
                            <div class="notice notice-success is-dismissible yoo-profile-inline-notice"><p><?php esc_html_e('Your email address has been updated.', 'yooadmin'); ?></p></div>
                        <?php elseif ($profile_email_flash === 'error') : ?>
                            <div class="notice notice-error is-dismissible yoo-profile-inline-notice"><p><?php esc_html_e('That email confirmation link is invalid or has expired.', 'yooadmin'); ?></p></div>
                        <?php elseif ($profile_email_flash === 'dismissed') : ?>
                            <div class="notice notice-info is-dismissible yoo-profile-inline-notice"><p><?php esc_html_e('Pending email change cancelled.', 'yooadmin'); ?></p></div>
                        <?php elseif (!empty($email_pending_notice)) : ?>
                            <div class="notice notice-info is-dismissible yoo-profile-inline-notice"><p><?php echo esc_html($email_pending_notice); ?></p></div>
                        <?php endif; ?>
                        <form
                            method="post"
                            class="yoo-profile-form"
                            id="yoo-profile-edit-form"
                            data-user-id="<?php echo esc_attr($user->ID); ?>"
                            data-current-email="<?php echo esc_attr($user->user_email); ?>"
                            data-initial-avatar-source="<?php echo esc_attr($profile_avatar_source); ?>"
                            data-requires-2fa-email="<?php echo !empty($profile_email_requires_2fa) ? '1' : '0'; ?>"
                            data-email-password-fallback="<?php echo !empty($profile_email_password_fallback) ? '1' : '0'; ?>"
                        >
                            <?php wp_nonce_field('yooadmin_update_user_' . $user->ID, 'yooadmin_profile_nonce'); ?>
                            <table class="form-table yoo-profile-settings-table"><tbody>
                                <?php if ($can_edit_profile_avatar && $profile_avatar_choices !== []) : ?>
                                <tr class="yoo-profile-avatar-source-row">
                                    <th scope="row">
                                        <div class="yp-th-content">
                                            <span class="dashicons dashicons-format-image yp-th-icon" aria-hidden="true"></span>
                                            <span><?php esc_html_e('Profile photo source', 'yooadmin'); ?></span>
                                        </div>
                                    </th>
                                    <td class="yoo-profile-settings-table__select-cell">
                                        <select
                                            class="ylp-input ylp-input--settings yoo-user-form-select"
                                            name="yooadmin_avatar_source"
                                            id="yooadmin-avatar-source"
                                            data-yoo-user-form-select="1"
                                        >
                                            <?php foreach ($profile_avatar_choices as $source_key => $source_label) : ?>
                                                <option
                                                    value="<?php echo esc_attr($source_key); ?>"
                                                    <?php selected($profile_avatar_source, $source_key); ?>
                                                    data-description="<?php echo esc_attr($profile_avatar_descriptions[ $source_key ] ?? ''); ?>"
                                                ><?php echo esc_html($source_label); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <p class="description yoo-profile-settings-table__note" id="yooadmin-avatar-source-description">
                                            <?php
                                            echo esc_html(
                                                $profile_avatar_descriptions[ $profile_avatar_source ] ?? ''
                                            );
                                            ?>
                                        </p>
                                    </td>
                                </tr>
                                <?php if ($profile_has_photo_plugins) : ?>
                                <tr
                                    class="yoo-profile-photo-plugins-row"
                                    id="yoo-profile-photo-plugins-row"
                                    <?php echo $profile_avatar_plugin_panel ? '' : ' hidden'; ?>
                                >
                                    <th scope="row">
                                        <div class="yp-th-content">
                                            <span class="dashicons dashicons-admin-plugins yp-th-icon" aria-hidden="true"></span>
                                            <span><?php esc_html_e('Plugin photo options', 'yooadmin'); ?></span>
                                        </div>
                                    </th>
                                    <td id="yoo-profile-photo-plugins-cell">
                                        <?php if ($profile_avatar_plugin_panel && function_exists('yooadmin_profile_render_photo_plugin_sections')) : ?>
                                            <?php yooadmin_profile_render_photo_plugin_sections($user, $is_own_profile); ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php endif; ?>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-admin-users yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('First name', 'yooadmin'); ?></span></div></th>
                                    <td><p class="ylp-field ylp-field--with-icon ylp-field--settings"><span class="ylp-field__icon dashicons dashicons-admin-users" aria-hidden="true"></span><input type="text" class="ylp-input ylp-input--with-icon ylp-input--settings" id="yoo-first-name" name="first_name" value="<?php echo esc_attr($user->first_name); ?>"></p></td>
                                </tr>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-admin-users yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('Last name', 'yooadmin'); ?></span></div></th>
                                    <td><p class="ylp-field ylp-field--with-icon ylp-field--settings"><span class="ylp-field__icon dashicons dashicons-admin-users" aria-hidden="true"></span><input type="text" class="ylp-input ylp-input--with-icon ylp-input--settings" id="yoo-last-name" name="last_name" value="<?php echo esc_attr($user->last_name); ?>"></p></td>
                                </tr>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-edit yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('Display name', 'yooadmin'); ?></span></div></th>
                                    <td><p class="ylp-field ylp-field--with-icon ylp-field--settings"><span class="ylp-field__icon dashicons dashicons-edit" aria-hidden="true"></span><input type="text" class="ylp-input ylp-input--with-icon ylp-input--settings" id="yoo-display-name" name="display_name" value="<?php echo esc_attr($user->display_name); ?>"></p></td>
                                </tr>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-email yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('Email address', 'yooadmin'); ?></span></div></th>
                                    <td>
                                        <p class="ylp-field ylp-field--with-icon ylp-field--settings">
                                            <span class="ylp-field__icon dashicons dashicons-email" aria-hidden="true"></span>
                                            <input
                                                type="email"
                                                class="ylp-input ylp-input--with-icon ylp-input--settings"
                                                id="yoo-email"
                                                name="user_email"
                                                value="<?php echo esc_attr($user->user_email); ?>"
                                                autocomplete="email"
                                                required
                                            >
                                        </p>
                                        <?php if ($is_own_profile) : ?>
                                            <p class="description yoo-profile-settings-table__note"><?php esc_html_e('If you change this, a confirmation link will be sent to the new address. It will not become active until you confirm it.', 'yooadmin'); ?></p>
                                            <?php if (!empty($profile_pending_email['newemail']) && strcasecmp((string) $profile_pending_email['newemail'], $user->user_email) !== 0) : ?>
                                                <p class="yoo-profile-email-pending">
                                                    <?php
                                                    printf(
                                                        /* translators: %s: pending email address */
                                                        esc_html__('Pending change to %s.', 'yooadmin'),
                                                        esc_html((string) $profile_pending_email['newemail'])
                                                    );
                                                    ?>
                                                    <?php if (!empty($profile_email_dismiss_url)) : ?>
                                                        <a href="<?php echo esc_url($profile_email_dismiss_url); ?>"><?php esc_html_e('Cancel', 'yooadmin'); ?></a>
                                                    <?php endif; ?>
                                                </p>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php if ($is_own_profile && !empty($profile_email_requires_2fa)) : ?>
                                <tr class="yoo-profile-email-2fa-row" id="yoo-profile-email-2fa-row" hidden>
                                    <th scope="row">
                                        <div class="yp-th-content">
                                            <span class="dashicons dashicons-shield yp-th-icon" aria-hidden="true"></span>
                                            <span><?php esc_html_e('Confirm email change', 'yooadmin'); ?></span>
                                        </div>
                                    </th>
                                    <td>
                                        <div class="yoo-profile-email-2fa" id="yoo-profile-email-2fa">
                                            <?php if (!empty($profile_email_password_fallback)) : ?>
                                                <p class="description yoo-profile-settings-table__note"><?php esc_html_e('Two-factor authentication is enabled. Enter your current account password to confirm this email change.', 'yooadmin'); ?></p>
                                                <p class="ylp-field ylp-field--settings">
                                                    <input type="password" class="ylp-input ylp-input--settings" id="yoo-email-change-pass" name="current_pass" autocomplete="current-password" placeholder="<?php esc_attr_e('Current password', 'yooadmin'); ?>">
                                                </p>
                                            <?php else : ?>
                                                <p class="description yoo-profile-settings-table__note"><?php esc_html_e('Two-factor authentication is enabled. Enter a verification code to confirm this email change.', 'yooadmin'); ?></p>
                                                <?php if (count($profile_email_2fa_providers) > 1) : ?>
                                                    <div class="yoo-profile-settings-table__select-cell">
                                                        <label class="screen-reader-text" for="yoo-email-change-2fa-provider"><?php esc_html_e('Verification method', 'yooadmin'); ?></label>
                                                        <select class="yoo-user-form-select" id="yoo-email-change-2fa-provider" name="email_change_2fa_provider" data-yoo-user-form-select="1">
                                                            <?php foreach ($profile_email_2fa_providers as $provider_row) : ?>
                                                                <option value="<?php echo esc_attr($provider_row['key']); ?>"><?php echo esc_html($provider_row['label']); ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                <?php elseif (!empty($profile_email_2fa_providers[0]['key'])) : ?>
                                                    <input type="hidden" name="email_change_2fa_provider" value="<?php echo esc_attr($profile_email_2fa_providers[0]['key']); ?>">
                                                <?php endif; ?>
                                                <div class="ylp-field ylp-field--settings yoo-profile-email-2fa-field yoo-profile-email-2fa-field--totp" data-2fa-field="totp" data-2fa-providers="totp,Two_Factor_Totp">
                                                    <div class="yoo-profile-email-2fa-pin" id="yoo-email-change-authcode-pin" dir="ltr" role="group" aria-label="<?php esc_attr_e('Authentication code', 'yooadmin'); ?>">
                                                        <?php for ($digit = 0; $digit < 6; $digit++) : ?>
                                                            <input
                                                                type="text"
                                                                class="ylp-input ylp-input--settings yoo-profile-email-2fa-pin__digit"
                                                                inputmode="numeric"
                                                                pattern="[0-9]*"
                                                                maxlength="1"
                                                                dir="ltr"
                                                                autocomplete="<?php echo $digit === 0 ? 'one-time-code' : 'off'; ?>"
                                                                aria-label="<?php echo esc_attr(sprintf(/* translators: 1: current digit, 2: total digits */ __('Digit %1$d of %2$d', 'yooadmin'), $digit + 1, 6)); ?>"
                                                                data-digit-index="<?php echo esc_attr((string) $digit); ?>"
                                                            />
                                                        <?php endfor; ?>
                                                    </div>
                                                    <input type="hidden" id="yoo-email-change-authcode" name="authcode" value="">
                                                </div>
                                                <p class="ylp-field ylp-field--settings yoo-profile-email-2fa-field yoo-profile-email-2fa-field--backup_codes" data-2fa-field="backup_codes" data-2fa-providers="backup_codes,Two_Factor_Backup_Codes" hidden>
                                                    <input type="text" class="ylp-input ylp-input--settings" id="yoo-email-change-backup" name="backup_code" inputmode="text" autocomplete="one-time-code" placeholder="<?php esc_attr_e('Recovery code', 'yooadmin'); ?>">
                                                </p>
                                            <?php endif; ?>
                                            <input type="hidden" name="email_change_2fa_token" id="yoo-email-change-2fa-token" value="">
                                            <p class="yoo-profile-email-2fa-status" id="yoo-profile-email-2fa-status" hidden>
                                                <span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
                                                <span class="yoo-profile-email-2fa-status__text"><?php esc_html_e('Identity verified for this email change.', 'yooadmin'); ?></span>
                                            </p>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php if ($show_locale_field) : ?>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-translation yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('Language', 'yooadmin'); ?></span></div></th>
                                    <td class="yoo-profile-settings-table__select-cell">
                                        <?php
                                        wp_dropdown_languages(
                                            [
                                                'name'                        => 'locale',
                                                'id'                          => 'yoo-locale',
                                                'selected'                    => $locale_selected,
                                                'show_available_translations' => false,
                                                'explicit_option_en_us'       => true,
                                                'languages'                   => yooadmin_get_site_admin_language_locales(),
                                            ]
                                        );
                                        ?>
                                        <p class="description yoo-profile-settings-table__note"><?php esc_html_e('Sets the admin interface language for this user.', 'yooadmin'); ?></p>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php if (!empty($show_role_field)) : ?>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-groups yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('Primary role', 'yooadmin'); ?></span></div></th>
                                    <td class="yoo-profile-settings-table__select-cell">
                                        <select id="yoo-role" name="role" class="ylp-input ylp-input--settings yoo-user-form-select" data-yoo-user-role-select="1">
                                            <?php
                                            $primary_role = reset($user->roles);
                                            foreach ($roles as $role_key => $role_data) :
                                                ?>
                                            <option value="<?php echo esc_attr($role_key); ?>" <?php selected($primary_role, $role_key); ?>>
                                                <?php echo esc_html(yooadmin_translate_role_label($role_key, $role_data)); ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <p class="description yoo-profile-settings-table__note"><?php esc_html_e('Choose the user role, then click Save changes to apply permissions.', 'yooadmin'); ?></p>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-admin-links yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('Website', 'yooadmin'); ?></span></div></th>
                                    <td><p class="ylp-field ylp-field--with-icon ylp-field--settings"><span class="ylp-field__icon dashicons dashicons-admin-links" aria-hidden="true"></span><input type="url" class="ylp-input ylp-input--with-icon ylp-input--settings" id="yoo-user-url" name="user_url" value="<?php echo esc_attr($user->user_url); ?>" placeholder="https://example.com"></p></td>
                                </tr>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-text-page yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('Biographical info', 'yooadmin'); ?></span></div></th>
                                    <td><p class="ylp-field ylp-field--settings ylp-field--textarea"><textarea class="ylp-input ylp-input--settings" id="yoo-description" name="description" rows="4" placeholder="<?php esc_attr_e('A short biographical description of the user.', 'yooadmin'); ?>"><?php echo esc_textarea($user->description); ?></textarea></p></td>
                                </tr>
                            </tbody></table>
                            <div class="yoo-form-actions yoo-profile-tab-panel__actions">
                                <button type="submit" class="button yp-yoo-btn yp-yoo-btn--primary"><?php esc_html_e('Save changes', 'yooadmin'); ?></button>
                            </div>
                        </form>
                    </div>

                    <div
                        class="yp-tab-panel yoo-profile-tab-panel<?php echo $profile_active_tab === 'password' ? ' is-active' : ''; ?>"
                        role="tabpanel"
                        id="yoo-profile-panel-password"
                        aria-labelledby="yoo-profile-tab-password"
                        data-profile-panel="password"
                        <?php echo $profile_active_tab === 'password' ? '' : ' hidden'; ?>
                    >
                        <p class="yp-help yoo-profile-tab-panel__lead"><?php esc_html_e('Set a new password or manage application passwords for API access.', 'yooadmin'); ?></p>
                        <form method="post" class="yoo-profile-form" id="yoo-profile-password-form" data-user-id="<?php echo esc_attr($user->ID); ?>">
                            <?php wp_nonce_field('yooadmin_update_user_' . $user->ID, 'yooadmin_password_nonce'); ?>
                            <table class="form-table yoo-profile-settings-table"><tbody>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-lock yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('New password', 'yooadmin'); ?></span></div></th>
                                    <td><p class="ylp-field ylp-field--with-icon ylp-field--settings"><span class="ylp-field__icon dashicons dashicons-lock" aria-hidden="true"></span><input type="password" class="ylp-input ylp-input--with-icon ylp-input--settings" id="yoo-pass1" name="pass1" autocomplete="new-password"></p></td>
                                </tr>
                                <tr>
                                    <th scope="row"><div class="yp-th-content"><span class="dashicons dashicons-lock yp-th-icon" aria-hidden="true"></span><span><?php esc_html_e('Confirm new password', 'yooadmin'); ?></span></div></th>
                                    <td><p class="ylp-field ylp-field--with-icon ylp-field--settings"><span class="ylp-field__icon dashicons dashicons-lock" aria-hidden="true"></span><input type="password" class="ylp-input ylp-input--with-icon ylp-input--settings" id="yoo-pass2" name="pass2" autocomplete="new-password"></p></td>
                                </tr>
                            </tbody></table>
                            <p class="description yoo-profile-settings-table__note"><?php esc_html_e('Leave blank to keep current password.', 'yooadmin'); ?></p>
                            <div class="yoo-form-actions yoo-profile-tab-panel__actions">
                                <button type="submit" class="button yp-yoo-btn yp-yoo-btn--primary" name="update_password"><?php esc_html_e('Update password', 'yooadmin'); ?></button>
                            </div>
                        </form>

                <?php if (function_exists('wp_is_application_passwords_available_for_user') && wp_is_application_passwords_available_for_user($user->ID)) : ?>
                <div class="yoo-app-passwords-section">
                    <?php
    $app_passwords = WP_Application_Passwords::get_user_application_passwords($user->ID);
?>
                    <div class="yoo-app-passwords">
                        <?php if (empty($app_passwords)): ?>
                            <p class="description"><?php esc_html_e('No application passwords have been configured.', 'yooadmin'); ?></p>
                        <?php
    else: ?>
                            <table class="wp-list-table widefat fixed striped">
                                <thead>
                                    <tr>
                                        <th><?php esc_html_e('Name', 'yooadmin'); ?></th>
                                        <th><?php esc_html_e('Created', 'yooadmin'); ?></th>
                                        <th><?php esc_html_e('Last used', 'yooadmin'); ?></th>
                                        <th><?php esc_html_e('Last IP', 'yooadmin'); ?></th>
                                        <th><?php esc_html_e('Actions', 'yooadmin'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($app_passwords as $app_password): ?>
                                        <tr>
                                            <td><strong><?php echo esc_html($app_password['name']); ?></strong></td>
                                            <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $app_password['created'])); ?></td>
                                            <td><?php echo $app_password['last_used'] ? esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $app_password['last_used'])) : esc_html__('Never', 'yooadmin'); ?></td>
                                            <td><?php echo $app_password['last_ip'] ? esc_html($app_password['last_ip']) : '—'; ?></td>
                                            <td>
                                                <form method="post" style="display: inline;">
                                                    <?php wp_nonce_field('delete_app_pass_' . $app_password['uuid'], '_wpnonce'); ?>
                                                    <input type="hidden" name="action" value="delete_app_password">
                                                    <input type="hidden" name="app_password_uuid" value="<?php echo esc_attr($app_password['uuid']); ?>">
                                                    <button type="submit" class="button-link delete" onclick="return confirm('<?php esc_attr_e('Are you sure you want to revoke this application password?', 'yooadmin'); ?>');">
                                                        <?php esc_html_e('Revoke', 'yooadmin'); ?>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php
        endforeach; ?>
                                </tbody>
                            </table>
                        <?php
    endif; ?>
                        <div style="margin-top: 16px;">
                            <form method="post" class="yoo-app-password-form">
                                <?php wp_nonce_field('create_app_pass_' . $user->ID, '_wpnonce'); ?>
                                <input type="hidden" name="action" value="create_app_password">
                                <div class="yoo-form-field" style="margin-bottom: 0;">
                                    <label for="app_name"><?php esc_html_e('New application password name', 'yooadmin'); ?></label>
                                    <div class="yoo-form-inline-wrapper">
                                        <input type="text" id="app_name" name="app_name" placeholder="<?php esc_attr_e('Enter password name', 'yooadmin'); ?>" required style="flex: 1; min-width: 200px;">
                                        <button type="submit" class="button yp-yoo-btn yp-yoo-btn--primary">
                                            <?php esc_html_e('Add new', 'yooadmin'); ?>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                    </div>

                    <?php if ($profile_has_security) : ?>
                    <div
                        class="yp-tab-panel yoo-profile-tab-panel yoo-profile-panel--security<?php echo $profile_active_tab === 'security' ? ' is-active' : ''; ?>"
                        role="tabpanel"
                        id="yoo-profile-panel-security"
                        aria-labelledby="yoo-profile-tab-security"
                        data-profile-panel="security"
                        <?php echo $profile_active_tab === 'security' ? '' : ' hidden'; ?>
                    >
                        <p class="yp-help yoo-profile-tab-panel__lead"><?php esc_html_e('Manage two-factor authentication and other security options for this account.', 'yooadmin'); ?></p>
                        <?php
                        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash flags after redirect.
                        if (isset($_GET['security_saved'])) :
                            ?>
                            <div class="notice notice-success is-inline yoo-profile-inline-notice">
                                <p><?php esc_html_e('Security settings saved.', 'yooadmin'); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php
                        $native_2fa_profile_errors = get_transient('yooadmin_native_2fa_profile_errors_' . (int) $user->ID);
                        if (is_array($native_2fa_profile_errors) && $native_2fa_profile_errors !== []) :
                            delete_transient('yooadmin_native_2fa_profile_errors_' . (int) $user->ID);
                            ?>
                            <div class="notice notice-warning is-inline yoo-profile-inline-notice">
                                <ul>
                                    <?php foreach ($native_2fa_profile_errors as $native_2fa_error) : ?>
                                        <li><?php echo esc_html((string) $native_2fa_error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form method="post" class="yoo-profile-form yoo-profile-form--plugin-sections" id="yoo-profile-security-form">
                            <?php wp_nonce_field('yooadmin_profile_plugin_sections_' . $user->ID, 'yooadmin_profile_plugin_sections_nonce'); ?>
                            <input type="hidden" name="action" value="save_profile_plugin_sections">
                            <input type="hidden" name="user_id" value="<?php echo esc_attr((string) $user->ID); ?>">
                            <div class="yoo-profile-plugin-sections">
                                <?php
                                if (function_exists('yooadmin_profile_render_plugin_sections')) {
                                    yooadmin_profile_render_plugin_sections($user, $is_own_profile);
                                }
                                ?>
                            </div>
                            <div class="yoo-form-actions yoo-profile-tab-panel__actions">
                                <button type="submit" class="button yp-yoo-btn yp-yoo-btn--primary"><?php esc_html_e('Save security settings', 'yooadmin'); ?></button>
                            </div>
                        </form>
                    </div>
                    <?php endif; ?>

                    <?php if ($profile_has_sessions) : ?>
                    <div
                        class="yp-tab-panel yoo-profile-tab-panel<?php echo $profile_active_tab === 'sessions' ? ' is-active' : ''; ?>"
                        role="tabpanel"
                        id="yoo-profile-panel-sessions"
                        aria-labelledby="yoo-profile-tab-sessions"
                        data-profile-panel="sessions"
                        <?php echo $profile_active_tab === 'sessions' ? '' : ' hidden'; ?>
                    >
                        <p class="yp-help yoo-profile-tab-panel__lead"><?php esc_html_e('Review active sign-in sessions and revoke access from other devices.', 'yooadmin'); ?></p>
                <?php
    $sessions = WP_Session_Tokens::get_instance($user->ID)->get_all();
?>
                <div class="yoo-sessions">
                    <?php if (empty($sessions)): ?>
                        <p class="description"><?php esc_html_e('No active sessions.', 'yooadmin'); ?></p>
                    <?php
    else: ?>
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Device', 'yooadmin'); ?></th>
                                    <th><?php esc_html_e('Location', 'yooadmin'); ?></th>
                                    <th><?php esc_html_e('Last activity', 'yooadmin'); ?></th>
                                    <th><?php esc_html_e('Actions', 'yooadmin'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sessions as $token => $session): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo esc_html($session['login']); ?></strong>
                                            <?php if ($token === wp_get_session_token()): ?>
                                                <span class="description"><?php esc_html_e('(Current session)', 'yooadmin'); ?></span>
                                            <?php
            endif; ?>
                                        </td>
                                        <td>
                                            <?php
            $location = '';
            if (isset($session['ip'])) {
                $location = $session['ip'];
            }
            if (isset($session['ua'])) {
                $location .= ' - ' . $session['ua'];
            }
            echo esc_html($location ?: __('Unknown', 'yooadmin'));
?>
                                        </td>
                                        <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $session['expiration'])); ?></td>
                                        <td>
                                            <?php if ($token !== wp_get_session_token()): ?>
                                                <form method="post" style="display: inline;">
                                                    <?php wp_nonce_field('revoke_session_' . $token, '_wpnonce'); ?>
                                                    <input type="hidden" name="action" value="revoke_session">
                                                    <input type="hidden" name="session_token" value="<?php echo esc_attr($token); ?>">
                                                    <button type="submit" class="button-link delete" onclick="return confirm('<?php esc_attr_e('Are you sure you want to revoke this session?', 'yooadmin'); ?>');">
                                                        <?php esc_html_e('Revoke', 'yooadmin'); ?>
                                                    </button>
                                                </form>
                                            <?php
            else: ?>
                                                <span class="description"><?php esc_html_e('Current session', 'yooadmin'); ?></span>
                                            <?php
            endif; ?>
                                        </td>
                                    </tr>
                                <?php
        endforeach; ?>
                            </tbody>
                        </table>
                    <?php
    endif; ?>
                </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<?php if ($can_edit_profile_avatar) : ?>
<!-- Remove photo confirmation (same overlay pattern as cropper) -->
<div id="yoo-avatar-delete-modal" class="yoo-avatar-dialog yoo-avatar-delete-modal" role="dialog" aria-modal="true" aria-labelledby="yoo-avatar-delete-title" aria-hidden="true" hidden>
    <div class="yoo-avatar-dialog__panel yoo-avatar-dialog__panel--compact">
        <h3 id="yoo-avatar-delete-title" class="yoo-avatar-dialog__title"><?php esc_html_e('Remove profile photo?', 'yooadmin'); ?></h3>
        <p class="yoo-avatar-dialog__message"><?php esc_html_e('Your custom photo will be removed and the default avatar will be shown.', 'yooadmin'); ?></p>
        <div class="yoo-avatar-dialog__footer">
            <button type="button" id="yoo-avatar-delete-cancel" class="button"><?php esc_html_e('Cancel', 'yooadmin'); ?></button>
            <button type="button" id="yoo-avatar-delete-confirm" class="button button-primary"><?php esc_html_e('Remove photo', 'yooadmin'); ?></button>
        </div>
    </div>
</div>

<!-- Cropper Modal -->
<div id="yoo-avatar-cropper-modal" class="yoo-avatar-dialog" role="dialog" aria-modal="true" aria-labelledby="yoo-cropper-title" aria-hidden="true" hidden>
    <div class="yoo-avatar-dialog__panel">
        <div class="yoo-avatar-dialog__header">
            <h3 id="yoo-cropper-title" class="yoo-avatar-dialog__title"><?php esc_html_e('Crop Profile Picture', 'yooadmin'); ?></h3>
            <button type="button" id="yoo-cropper-close" class="yoo-avatar-dialog__close" aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">&times;</button>
        </div>
        <div class="yoo-cropper-stage">
            <img id="yoo-cropper-image" src="" alt="">
        </div>
        <div class="yoo-avatar-dialog__footer">
            <button type="button" id="yoo-cropper-cancel" class="button"><?php esc_html_e('Cancel', 'yooadmin'); ?></button>
            <button type="button" id="yoo-cropper-save" class="button button-primary" data-yoo-label-save="<?php echo esc_attr__('Save', 'yooadmin'); ?>" data-yoo-label-saving="<?php echo esc_attr__('Saving…', 'yooadmin'); ?>"><?php esc_html_e('Save', 'yooadmin'); ?></button>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
// Cropper.js is enqueued in includes/admin/users-page.php as yooadmin-cropperjs (dependency of user-avatar-upload).
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
?>

