<?php
/**
 * YOOAdmin - Users hub index template
 *
 * @package YOOAdmin
 * @since 1.0.0
 *
 * @var array          $users
 * @var array          $roles
 * @var string         $search
 * @var string         $role
 * @var int            $paged
 * @var int            $total_pages
 * @var int            $total
 * @var WP_User_Query  $user_query
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

$list_url = admin_url('admin.php?page=yooadmin-users');
$new_url = admin_url('admin.php?page=yooadmin-users-new');
$has_search = ($search !== '');
$has_role = ($role !== '');
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only sort from URL.
$sort = isset($_GET['sort']) ? sanitize_key(wp_unslash($_GET['sort'])) : 'recent';
if (!in_array($sort, ['recent', 'name', 'role'], true)) {
    $sort = 'recent';
}
?>

<div class="wrap yooadmin-users-page">
    <section class="yoo-users-hero">
        <div class="yoo-users-hero__body">
            <div class="yoo-users-hero__header">
                <div class="yoo-users-hero__title-section">
                    <div class="yoo-users-hero__top-row">
                        <span class="yoo-users-hero__eyebrow"><?php esc_html_e('Workspace · Directory', 'yooadmin'); ?></span>
                        <div class="yoo-users-hero__actions">
                            <div class="yoo-users-search-wrapper">
                                <span class="dashicons dashicons-search"></span>
                                <input type="search" id="yoo-users-search-input" class="yoo-users-search-input" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search by name, email, or username…', 'yooadmin'); ?>">
                            </div>
                            <a class="yp-yoo-btn yp-yoo-btn--primary yoo-users-add-btn" href="<?php echo esc_url($new_url); ?>">
                                <span class="dashicons dashicons-plus-alt"></span>
                                <?php esc_html_e('Add User', 'yooadmin'); ?>
                            </a>
                        </div>
                    </div>
                    <div class="yoo-users-hero__title-row">
                        <h1>
                            <span class="dashicons dashicons-groups"></span>
                            <?php esc_html_e('Users', 'yooadmin'); ?>
                        </h1>
                        <div class="yoo-users-hero__description-section">
                            <p><?php echo wp_kses_post(__('All members, collaborators, and admins in one curated dashboard. Search, filter, and deep-dive into each profile without leaving <strong>YOOAdmin</strong>.', 'yooadmin')); ?></p>
                        </div>
                    </div>
                    <button type="button" class="yoo-users-metrics-toggle" aria-expanded="false">
                        <span class="dashicons dashicons-arrow-down-alt"></span>
                        <span><?php esc_html_e('Show Statistics', 'yooadmin'); ?></span>
                    </button>
                </div>
            </div>
        </div>

        <div class="yoo-users-hero__metrics">
            <article class="yoo-users-metric">
                <div class="yoo-users-metric__icon-wrapper">
                    <div class="yoo-users-metric__icon">
                        <span class="dashicons dashicons-groups"></span>
                    </div>
                </div>
                <div class="yoo-users-metric__content">
                    <strong class="yoo-users-metric__value"><?php echo esc_html(number_format_i18n($stats['total'] ?? $total)); ?></strong>
                    <span class="yoo-users-metric__label"><?php esc_html_e('Total users', 'yooadmin'); ?></span>
                    <small class="yoo-users-metric__subtext"><?php
// translators: %s: number of active roles
printf(esc_html__('%s active roles', 'yooadmin'), esc_html(number_format_i18n($stats['active_roles'] ?? 0))); ?></small>
                </div>
            </article>
            <article class="yoo-users-metric">
                <div class="yoo-users-metric__icon-wrapper">
                    <div class="yoo-users-metric__icon">
                        <span class="dashicons dashicons-calendar-alt"></span>
                    </div>
                </div>
                <div class="yoo-users-metric__content">
                    <strong class="yoo-users-metric__value"><?php echo esc_html(number_format_i18n($stats['new_week'] ?? 0)); ?></strong>
                    <span class="yoo-users-metric__label"><?php esc_html_e('Joined this week', 'yooadmin'); ?></span>
                    <small class="yoo-users-metric__subtext"><?php esc_html_e('Past 7 days', 'yooadmin'); ?></small>
                </div>
            </article>
            <article class="yoo-users-metric">
                <div class="yoo-users-metric__icon-wrapper">
                    <div class="yoo-users-metric__icon">
                        <span class="dashicons dashicons-shield"></span>
                    </div>
                </div>
                <div class="yoo-users-metric__content">
                    <strong class="yoo-users-metric__value"><?php echo esc_html(number_format_i18n($stats['administrators'] ?? 0)); ?></strong>
                    <span class="yoo-users-metric__label"><?php esc_html_e('Administrators', 'yooadmin'); ?></span>
                    <small class="yoo-users-metric__subtext"><?php esc_html_e('With elevated privileges', 'yooadmin'); ?></small>
                </div>
            </article>
            <article class="yoo-users-metric">
                <div class="yoo-users-metric__icon-wrapper">
                    <div class="yoo-users-metric__icon">
                        <span class="dashicons dashicons-yes-alt"></span>
                    </div>
                </div>
                <div class="yoo-users-metric__content">
                    <strong class="yoo-users-metric__value"><?php echo esc_html(number_format_i18n($stats['online'] ?? 0)); ?></strong>
                    <span class="yoo-users-metric__label"><?php esc_html_e('Online now', 'yooadmin'); ?></span>
                    <small class="yoo-users-metric__subtext"><?php esc_html_e('Active in last 15 min', 'yooadmin'); ?></small>
                </div>
            </article>
        </div>
    </section>

    <section class="yoo-users-content-section">
        <div class="yoo-users-toolbar">
            <div class="yoo-users-filters">
                <a class="yoo-filter-chip <?php echo $has_role ? '' : 'is-active'; ?>" href="<?php echo esc_url($list_url); ?>" data-role="" data-filter="all">
                    <?php esc_html_e('All roles', 'yooadmin'); ?>
                    <?php if (!empty($stats['total'])): ?>
                        <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($stats['total'])); ?></span>
                    <?php
endif; ?>
                </a>
                <?php foreach ($roles as $role_key => $role_data): ?>
                    <?php
    $role_args = [
        'page' => 'yooadmin-users',
        'role' => $role_key,
        'paged' => 1,
        's' => $search,
    ];
    if ($sort !== '' && $sort !== 'recent') {
        $role_args['sort'] = $sort;
    }
    $role_link = add_query_arg($role_args, admin_url('admin.php'));
    $count_for_role = isset($role_counts[$role_key]) ? (int)$role_counts[$role_key] : 0;
?>
                    <a class="yoo-filter-chip <?php echo $role === $role_key ? 'is-active' : ''; ?>" href="<?php echo esc_url($role_link); ?>" data-role="<?php echo esc_attr($role_key); ?>" data-filter="role">
                        <?php echo esc_html(yooadmin_translate_role_label($role_key, $role_data)); ?>
                        <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($count_for_role)); ?></span>
                    </a>
                <?php
endforeach; ?>
            </div>

            <div class="yoo-users-sorts">
                <?php if ($has_search || $has_role): ?>
                    <a class="yoo-clear-filters" href="<?php echo esc_url($list_url); ?>">
                        <span class="dashicons dashicons-no"></span>
                        <?php esc_html_e('Reset', 'yooadmin'); ?>
                    </a>
                <?php
endif; ?>
                <label for="yoo-users-sort" class="screen-reader-text"><?php esc_html_e('Sort users', 'yooadmin'); ?></label>
                <select id="yoo-users-sort" name="yooadmin-users-sort" class="yoo-sort-select" data-yoo-users-sort="1">
                    <option value="recent" <?php selected($sort, 'recent'); ?>><?php esc_html_e('Sort: Most recent', 'yooadmin'); ?></option>
                    <option value="name" <?php selected($sort, 'name'); ?>><?php esc_html_e('Alphabetical', 'yooadmin'); ?></option>
                    <option value="role" <?php selected($sort, 'role'); ?>><?php esc_html_e('Role hierarchy', 'yooadmin'); ?></option>
                </select>
            </div>
        </div>

        <div class="yoo-bulk-actions-bar" style="display: none;">
            <div class="yoo-bulk-actions-left">
                <input type="checkbox" id="yoo-select-all-users" class="yoo-checkbox">
                <label for="yoo-select-all-users"><?php esc_html_e('Select All', 'yooadmin'); ?></label>
                <span class="yoo-selected-count">0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
            </div>
            <div class="yoo-bulk-actions-right">
                <select id="yoo-bulk-action-select" class="yoo-bulk-select">
                    <option value=""><?php esc_html_e('Bulk Actions', 'yooadmin'); ?></option>
                    <option value="delete"><?php esc_html_e('Delete', 'yooadmin'); ?></option>
                    <option value="change_role"><?php esc_html_e('Change Role', 'yooadmin'); ?></option>
                </select>
                <button type="button" id="yoo-bulk-apply" class="yoo-button yoo-button--primary" disabled>
                    <?php esc_html_e('Apply', 'yooadmin'); ?>
                </button>
            </div>
        </div>

        <div id="yoo-users-content">
    <?php if ($users): ?>
        <div class="yoo-users-grid">
            <?php foreach ($users as $user): ?>
                <?php
        $roles_display = yooadmin_translate_user_role_list($user->roles);
        $primary_role = $user->roles ? reset($user->roles) : '';
        $status_badge = in_array('administrator', $user->roles, true) ? 'administrator' : ($primary_role ?: 'standard');
        $profile_url = add_query_arg([
            'page' => 'yooadmin-user',
            'user_id' => $user->ID,
        ], admin_url('admin.php'));
        $registered = strtotime($user->user_registered);
        $posts_count = count_user_posts($user->ID, 'post', true);
        $posts_url = add_query_arg([
            'post_type' => 'post',
            'author' => $user->ID,
        ], admin_url('edit.php'));
?>
                <article class="yoo-user-card">
                    <input type="checkbox" class="yoo-user-checkbox" value="<?php echo esc_attr($user->ID); ?>" id="user-<?php echo esc_attr($user->ID); ?>" data-is-admin="<?php echo in_array('administrator', (array) $user->roles, true) ? '1' : '0'; ?>">
                    <label for="user-<?php echo esc_attr($user->ID); ?>" class="yoo-user-checkbox-label"></label>
                    <?php
                    if (function_exists('yooadmin_users_render_row_actions')) {
                        yooadmin_users_render_row_actions($user);
                    }
                    ?>
                    <header class="yoo-user-card__header">
                        <div class="yoo-user-avatar">
                            <?php echo wp_kses_post( get_avatar($user->ID, 72) ); ?>
                            <span class="yoo-user-online-badge" aria-hidden="true"></span>
                        </div>
                        <div class="yoo-user-heading">
                            <h2>
                                <a href="<?php echo esc_url($profile_url); ?>">
                                    <?php echo esc_html($user->display_name ?: $user->user_login); ?>
                                </a>
                            </h2>
                            <span class="yoo-user-role yoo-user-role--<?php echo esc_attr(sanitize_html_class($status_badge)); ?>">
                                <?php echo esc_html($roles_display ?: __('User', 'yooadmin')); ?>
                            </span>
                        </div>
                    </header>

                    <dl class="yoo-user-meta">
                        <div>
                            <dt>
                                <span class="dashicons dashicons-email"></span>
                                <?php esc_html_e('Email', 'yooadmin'); ?>
                            </dt>
                            <dd>
                                <a href="mailto:<?php echo esc_attr($user->user_email); ?>">
                                    <?php echo esc_html($user->user_email); ?>
                                </a>
                            </dd>
                        </div>
                        <div>
                            <dt>
                                <span class="dashicons dashicons-calendar-alt"></span>
                                <?php esc_html_e('Registered', 'yooadmin'); ?>
                            </dt>
                            <dd><?php echo esc_html(date_i18n(get_option('date_format'), $registered)); ?></dd>
                        </div>
                        <div>
                            <dt>
                                <span class="dashicons dashicons-admin-users"></span>
                                <?php esc_html_e('Username', 'yooadmin'); ?>
                            </dt>
                            <dd><?php echo esc_html($user->user_login); ?></dd>
                        </div>
                        <div>
                            <dt>
                                <span class="dashicons dashicons-admin-post"></span>
                                <?php esc_html_e('Posts', 'yooadmin'); ?>
                            </dt>
                            <dd>
                                <a href="<?php echo esc_url($posts_url); ?>">
                                    <?php echo esc_html(number_format_i18n($posts_count)); ?>
                                </a>
                            </dd>
                        </div>
                    </dl>
                </article>
            <?php
    endforeach; ?>
        </div>

        <?php if ($total_pages > 1): ?>
            <nav class="yoo-users-pagination" aria-label="<?php esc_attr_e('Users pagination', 'yooadmin'); ?>">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <?php
            $page_link = add_query_arg([
                'page' => 'yooadmin-users',
                'paged' => $i,
                'role' => $role,
                's' => $search,
            ], admin_url('admin.php'));
?>
                    <a class="<?php echo $i === $paged ? 'is-active' : ''; ?>" href="<?php echo esc_url($page_link); ?>">
                        <?php echo esc_html($i); ?>
                    </a>
                <?php
        endfor; ?>
            </nav>
        <?php
    endif; ?>
    <?php
else: ?>
        <div class="yoo-users-empty">
            <div class="yoo-empty-illustration" aria-hidden="true"></div>
            <h2><?php esc_html_e('No users match your filters', 'yooadmin'); ?></h2>
            <p><?php esc_html_e('Try adjusting your filters or invite a new teammate to get started.', 'yooadmin'); ?></p>
            <a class="yoo-button yoo-button--primary" href="<?php echo esc_url($new_url); ?>">
                <?php esc_html_e('Create first user', 'yooadmin'); ?>
            </a>
        </div>
    <?php
endif; ?>
        </div>
    </section>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
