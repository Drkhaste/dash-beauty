<?php
/**
 * YOOAdmin native two-factor profile options.
 *
 * @package YOOAdmin
 *
 * @var WP_User  $user
 * @var bool     $is_own_profile
 * @var string[] $enabled_providers
 * @var string[] $providers
 * @var bool     $totp_configured
 * @var int      $backup_remaining
 * @var string   $revalidate_url
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.Security.NonceVerification.Missing -- Parent form handles nonce.
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- This is a view partial; it is always include()d within a render function scope (see yooadmin_native_2fa_profile_render_section()), so these variables are function-local, not global.

$locked       = $revalidate_url !== '';
$method_icons = [
    YOOAdmin_2FA_Core::PROVIDER_TOTP         => 'smartphone',
    YOOAdmin_2FA_Core::PROVIDER_EMAIL        => 'email',
    YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES => 'backup',
];
$method_hints = [
    YOOAdmin_2FA_Core::PROVIDER_TOTP         => __('Use an authenticator app to generate sign-in codes. Scan a QR code to set it up.', 'yooadmin'),
    YOOAdmin_2FA_Core::PROVIDER_EMAIL        => __('Receive a one-time code by email when you sign in.', 'yooadmin'),
    YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES => __('Keep single-use codes for backup access if other methods are unavailable.', 'yooadmin'),
];

?>
<div id="yooadmin-native-two-factor" class="yoo-native-2fa" data-user-id="<?php echo esc_attr((string) $user->ID); ?>">
    <input type="hidden" name="yooadmin_native_2fa_present" value="1" />
    <?php if ($locked) : ?>
        <div class="yoo-native-2fa__notice yoo-native-2fa__notice--warn">
            <span class="dashicons dashicons-warning" aria-hidden="true"></span>
            <div class="yoo-native-2fa__notice-text">
                <p><?php esc_html_e('Confirm your identity before changing two-factor settings.', 'yooadmin'); ?></p>
                <a class="button yp-yoo-btn yp-yoo-btn--soft" href="<?php echo esc_url($revalidate_url); ?>">
                    <?php esc_html_e('Revalidate now', 'yooadmin'); ?>
                </a>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($providers !== []) : ?>
    <div class="yoo-native-2fa__methods">
        <table class="form-table yoo-native-2fa__table">
            <tbody>
                <?php foreach ($providers as $provider_key) :
                    $checked     = in_array($provider_key, $enabled_providers, true);
                    $label       = YOOAdmin_2FA_Core::provider_label($provider_key);
                    $icon        = $method_icons[ $provider_key ] ?? 'shield';
                    $hint        = $method_hints[ $provider_key ] ?? '';
                    $field_id    = 'yooadmin-native-2fa-' . $provider_key;
                    $status_bits = yooadmin_native_2fa_profile_status_bits($provider_key, $checked, $totp_configured, $backup_remaining);
                    $status_meta = count($status_bits) > 1 ? implode(' · ', array_slice($status_bits, 1)) : '';
                    ?>
                <tr class="yoo-native-2fa__method-row" data-yoo-2fa-method="<?php echo esc_attr($provider_key); ?>">
                    <th scope="row">
                        <div class="yp-th-content">
                            <span class="dashicons dashicons-<?php echo esc_attr($icon); ?> yp-th-icon" aria-hidden="true"></span>
                            <span><?php echo esc_html($label); ?></span>
                            <?php if ($hint !== '') : ?>
                            <span class="yp-help-icon">
                                <span class="dashicons dashicons-editor-help" aria-hidden="true"></span>
                                <span class="yp-tooltip"><?php echo esc_html($hint); ?></span>
                            </span>
                            <?php endif; ?>
                        </div>
                    </th>
                    <td>
                        <div class="yp-toggle-container yoo-native-2fa__toggle-row" data-yoo-2fa-status-meta="<?php echo esc_attr($status_meta); ?>">
                            <?php
                            yooadmin_native_2fa_profile_render_toggle(
                                $field_id,
                                'yooadmin_native_2fa_providers[]',
                                $provider_key,
                                $checked,
                                $locked
                            );
                            ?>
                            <div class="yp-toggle-label-wrapper">
                                <label for="<?php echo esc_attr($field_id); ?>" class="yp-toggle-label yoo-native-2fa__toggle-label">
                                    <span class="yoo-native-2fa__state" data-yoo-2fa-state><?php echo esc_html($status_bits[0]); ?></span>
                                    <?php if ($status_meta !== '') : ?>
                                        <span class="yoo-native-2fa__state-sep" aria-hidden="true">·</span>
                                        <span class="yoo-native-2fa__state-meta" data-yoo-2fa-meta><?php echo esc_html($status_meta); ?></span>
                                    <?php endif; ?>
                                </label>
                            </div>
                        </div>

                        <?php if ($provider_key === YOOAdmin_2FA_Core::PROVIDER_TOTP && $is_own_profile && !$locked) : ?>
                            <div class="yoo-native-2fa__method-body">
                                <?php if (!$totp_configured) : ?>
                                <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" id="yooadmin-2fa-setup-totp">
                                    <span class="dashicons dashicons-smartphone" aria-hidden="true"></span>
                                    <?php esc_html_e('Set up authenticator', 'yooadmin'); ?>
                                </button>
                                <?php else : ?>
                                <div class="yoo-native-2fa__reset" id="yooadmin-2fa-reset-intro">
                                    <p class="yoo-profile-settings-table__note yoo-native-2fa__reset-hint">
                                        <?php esc_html_e('If your QR code or secret key was exposed, generate a new one. Your old authenticator codes stop working after you verify the new device. Existing recovery codes are revoked for security — generate new ones afterward if needed.', 'yooadmin'); ?>
                                    </p>
                                    <div class="yoo-native-2fa__action-row">
                                        <p class="ylp-field ylp-field--with-icon ylp-field--settings yoo-native-2fa__action-field yoo-native-2fa__action-field--otp">
                                            <label class="screen-reader-text" for="yooadmin-2fa-reset-current-code"><?php esc_html_e('Current authenticator code', 'yooadmin'); ?></label>
                                            <span class="ylp-field__icon dashicons dashicons-smartphone" aria-hidden="true"></span>
                                            <input
                                                type="text"
                                                class="ylp-input ylp-input--with-icon ylp-input--settings yoo-native-2fa__otp-input"
                                                id="yooadmin-2fa-reset-current-code"
                                                inputmode="numeric"
                                                autocomplete="one-time-code"
                                                placeholder="<?php esc_attr_e('000000', 'yooadmin'); ?>"
                                                maxlength="6"
                                                dir="ltr"
                                            />
                                        </p>
                                        <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" id="yooadmin-2fa-reset-totp">
                                            <span class="dashicons dashicons-update" aria-hidden="true"></span>
                                            <?php esc_html_e('Reset authenticator', 'yooadmin'); ?>
                                        </button>
                                    </div>
                                    <p class="yoo-native-2fa__status" id="yooadmin-2fa-reset-status" aria-live="polite"></p>
                                </div>
                                <?php endif; ?>
                                <div id="yooadmin-2fa-totp-panel" class="yoo-native-2fa__totp-panel" hidden>
                                    <div class="yoo-native-2fa__totp-layout">
                                        <div class="yoo-native-2fa__totp-qr-wrap">
                                            <div id="yooadmin-2fa-totp-qrcode" class="yoo-native-2fa__totp-qr" aria-hidden="true"></div>
                                        </div>
                                        <div class="yoo-native-2fa__totp-details">
                                            <p class="yoo-native-2fa__totp-step"><?php esc_html_e('1. Scan the QR code with your authenticator app', 'yooadmin'); ?></p>
                                            <p class="yoo-native-2fa__totp-step"><?php esc_html_e('2. Or enter this key manually', 'yooadmin'); ?></p>
                                            <div class="yoo-native-2fa__secret-row">
                                                <code id="yooadmin-2fa-totp-secret" class="yoo-native-2fa__secret" dir="ltr"></code>
                                                <button type="button" class="button yp-yoo-btn yp-yoo-btn--ghost yoo-native-2fa__copy-secret" id="yooadmin-2fa-copy-secret" title="<?php esc_attr_e('Copy key', 'yooadmin'); ?>">
                                                    <span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
                                                </button>
                                            </div>
                                            <p class="yoo-native-2fa__totp-step"><?php esc_html_e('3. Enter the 6-digit code to verify', 'yooadmin'); ?></p>
                                            <div class="yoo-native-2fa__action-row">
                                                <p class="ylp-field ylp-field--settings yoo-native-2fa__action-field yoo-native-2fa__action-field--otp">
                                                    <label class="screen-reader-text" for="yooadmin-2fa-totp-code"><?php esc_html_e('Verification code', 'yooadmin'); ?></label>
                                                    <input type="text" class="ylp-input ylp-input--settings yoo-native-2fa__otp-input" id="yooadmin-2fa-totp-code" inputmode="numeric" autocomplete="one-time-code" placeholder="<?php esc_attr_e('000000', 'yooadmin'); ?>" maxlength="6" dir="ltr" />
                                                </p>
                                                <button type="button" class="button yp-yoo-btn yp-yoo-btn--primary" id="yooadmin-2fa-verify-totp"><?php esc_html_e('Verify', 'yooadmin'); ?></button>
                                            </div>
                                            <p class="yoo-native-2fa__status" id="yooadmin-2fa-totp-status" aria-live="polite"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($provider_key === YOOAdmin_2FA_Core::PROVIDER_BACKUP_CODES && $is_own_profile && !$locked) : ?>
                            <div class="yoo-native-2fa__method-body yoo-native-2fa__method-body--backup">
                                <div class="yoo-native-2fa__backup-toolbar">
                                    <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" id="yooadmin-2fa-generate-backup">
                                        <span class="dashicons dashicons-update" aria-hidden="true"></span>
                                        <?php esc_html_e('Generate recovery codes', 'yooadmin'); ?>
                                    </button>
                                    <div id="yooadmin-2fa-backup-actions" class="yoo-native-2fa__backup-actions" hidden>
                                        <button type="button" class="button yp-yoo-btn yp-yoo-btn--ghost yoo-native-2fa__backup-download" id="yooadmin-2fa-download-backup">
                                            <span class="dashicons dashicons-download" aria-hidden="true"></span>
                                            <?php esc_html_e('Download', 'yooadmin'); ?>
                                        </button>
                                        <button type="button" class="button yp-yoo-btn yp-yoo-btn--ghost yoo-native-2fa__backup-copy" id="yooadmin-2fa-copy-backup">
                                            <span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
                                            <?php esc_html_e('Copy all', 'yooadmin'); ?>
                                        </button>
                                    </div>
                                </div>
                                <p class="yoo-native-2fa__backup-hint description">
                                    <?php esc_html_e('Each code is 8 characters (letters and numbers) and works once. Store them offline.', 'yooadmin'); ?>
                                </p>
                                <p id="yooadmin-2fa-backup-once-notice" class="yoo-native-2fa__backup-once-notice description" hidden>
                                    <?php esc_html_e('These recovery codes are shown only once. Download or copy them before you leave this page.', 'yooadmin'); ?>
                                </p>
                                <ul id="yooadmin-2fa-backup-codes" class="yoo-native-2fa__backup-list" hidden></ul>
                            </div>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
