<?php
defined('ABSPATH') || exit;
?>
<div class="yoo-network-site-info-form__actions">
  <button type="submit" class="yp-yoo-btn yp-yoo-btn--primary">
    <span class="dashicons dashicons-saved" aria-hidden="true"></span>
    <?php esc_html_e('Save Site Info', 'yooadmin'); ?>
  </button>
  <a class="yp-yoo-btn yp-yoo-btn--soft" href="<?php echo esc_url(function_exists('yooadmin_network_sites_url') ? yooadmin_network_sites_url() : network_admin_url('sites.php')); ?>">
    <?php esc_html_e('Back to Sites', 'yooadmin'); ?>
  </a>
</div>
