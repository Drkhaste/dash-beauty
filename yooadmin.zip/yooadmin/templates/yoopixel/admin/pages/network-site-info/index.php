<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$blog_id = function_exists('yooadmin_network_site_info_current_id') ? yooadmin_network_site_info_current_id() : 0;
$details = function_exists('yooadmin_network_site_info_get_site') ? yooadmin_network_site_info_get_site($blog_id) : null;

if (!$details) {
    return;
}

$site_name     = function_exists('yooadmin_network_site_editor_site_name') ? yooadmin_network_site_editor_site_name($blog_id) : (string) $blog_id;
$parsed_scheme = wp_parse_url($details->siteurl, PHP_URL_SCHEME);
$is_main_site  = is_main_site($blog_id);
$form_url      = function_exists('yooadmin_network_site_info_url') ? yooadmin_network_site_info_url($blog_id) : network_admin_url('site-info.php?id=' . $blog_id);

$selected_tab = 'site-info';
$page_slug    = 'network-site-info';
$wrap_form    = true;
$form_action  = $form_url;
$form_id      = 'yoo-network-site-info-form';
$form_nonce   = 'edit-site';
$form_hidden_action = 'update-site';
$flash_keys   = ['update'];
$panel_partial = __DIR__ . '/tab-info.php';
$form_actions_partial = __DIR__ . '/form-actions.php';

$shell = function_exists('yooadmin_network_site_editor_shell_template') ? yooadmin_network_site_editor_shell_template() : '';
if ($shell) {
    include $shell;
}
