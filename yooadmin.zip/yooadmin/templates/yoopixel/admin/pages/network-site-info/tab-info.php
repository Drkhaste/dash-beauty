<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

if (!isset($details, $blog_id, $parsed_scheme, $is_main_site)) {
    return;
}

$attribute_fields = [
    'public' => _x('Public', 'site', 'yooadmin'),
];
if (!$is_main_site) {
    $attribute_fields['archived'] = __('Archived', 'yooadmin');
    $attribute_fields['spam']     = _x('Spam', 'site', 'yooadmin');
    $attribute_fields['deleted']  = __('Flagged for Deletion', 'yooadmin');
}
$attribute_fields['mature'] = __('Mature', 'yooadmin');
?>
<div class="yoo-network-settings-columns">
    <div class="yoo-network-settings-column">
      <div class="yoo-network-settings-card">
        <div class="yoo-network-settings-card__head">
          <span class="dashicons dashicons-admin-links" aria-hidden="true"></span>
          <h3><?php esc_html_e('Site Address', 'yooadmin'); ?></h3>
        </div>

        <?php if ($is_main_site) : ?>
          <div class="yoo-network-settings-field yoo-network-settings-field--row">
            <label><?php esc_html_e('Site Address (URL)', 'yooadmin'); ?></label>
            <div class="yoo-network-settings-field__control">
              <code class="yoo-network-site-info-url-code"><?php echo esc_html((string) $parsed_scheme . '://' . $details->domain . $details->path); ?></code>
              <p class="description"><?php esc_html_e('The main site address cannot be changed from this screen.', 'yooadmin'); ?></p>
            </div>
          </div>
        <?php else : ?>
          <div class="yoo-network-settings-field yoo-network-settings-field--row">
            <label for="yoo-site-info-url"><?php esc_html_e('Site Address (URL)', 'yooadmin'); ?></label>
            <div class="yoo-network-settings-field__control">
              <input
                name="blog[url]"
                type="url"
                id="yoo-site-info-url"
                class="regular-text"
                value="<?php echo esc_attr((string) $parsed_scheme . '://' . $details->domain . $details->path); ?>"
                required
              />
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="yoo-network-settings-column">
      <div class="yoo-network-settings-card">
        <div class="yoo-network-settings-card__head">
          <span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span>
          <h3><?php esc_html_e('Registration', 'yooadmin'); ?></h3>
        </div>

        <div class="yoo-network-settings-field yoo-network-settings-field--row">
          <label for="blog_registered"><?php echo esc_html_x('Registered', 'site', 'yooadmin'); ?></label>
          <div class="yoo-network-settings-field__control">
            <input name="blog[registered]" type="text" id="blog_registered" class="regular-text" value="<?php echo esc_attr((string) $details->registered); ?>" />
          </div>
        </div>

        <div class="yoo-network-settings-field yoo-network-settings-field--row">
          <label for="blog_last_updated"><?php esc_html_e('Last Updated', 'yooadmin'); ?></label>
          <div class="yoo-network-settings-field__control">
            <input name="blog[last_updated]" type="text" id="blog_last_updated" class="regular-text" value="<?php echo esc_attr((string) $details->last_updated); ?>" />
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="yoo-network-settings-card">
    <div class="yoo-network-settings-card__head">
      <span class="dashicons dashicons-flag" aria-hidden="true"></span>
      <h3><?php esc_html_e('Attributes', 'yooadmin'); ?></h3>
    </div>

    <div class="yoo-network-site-info-attributes">
      <?php foreach ($attribute_fields as $field_key => $field_label) : ?>
        <label class="yoo-network-site-info-attribute">
          <input
            type="checkbox"
            name="blog[<?php echo esc_attr($field_key); ?>]"
            value="1"
            <?php checked((bool) $details->$field_key, true); ?>
            <?php disabled(!in_array((int) $details->$field_key, [0, 1], true)); ?>
          />
          <span><?php echo esc_html($field_label); ?></span>
        </label>
      <?php endforeach; ?>
    </div>
  </div>

  <?php
  /**
   * Fires at the end of the site info form in network admin.
   *
   * @param int $blog_id Site ID.
   */
  do_action('network_site_info_form', (int) $blog_id); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
  ?>
