<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

?>
<div class="yoo-network-site-editor-themes yoo-theme-manager-wrap">
  <p class="yoo-network-site-editor-note"><?php esc_html_e('Network enabled themes are not shown on this screen.', 'yooadmin'); ?></p>

  <div class="yoo-filters-bar yoo-network-site-themes-toolbar">
        <div class="yoo-filters-left">
          <div class="yoo-users-filters yoo-network-site-themes-filters">
          <?php
          $views = [
              'all'      => ['label' => __('All', 'yooadmin'), 'icon' => 'admin-appearance'],
              'enabled'  => ['label' => __('Enabled', 'yooadmin'), 'icon' => 'yes-alt'],
              'disabled' => ['label' => __('Disabled', 'yooadmin'), 'icon' => 'dismiss'],
          ];
          foreach ($views as $view_key => $view_meta) :
              $view_link = add_query_arg(['theme-status' => $view_key, 's' => $search], $list_url);
              ?>
            <a class="yoo-filter-chip<?php echo $view === $view_key ? ' is-active' : ''; ?>" href="<?php echo esc_url($view_link); ?>">
              <span class="dashicons dashicons-<?php echo esc_attr((string) $view_meta['icon']); ?>" aria-hidden="true"></span>
              <?php echo esc_html((string) $view_meta['label']); ?>
            </a>
          <?php endforeach; ?>
          </div>
        </div>
        <div class="yoo-filters-right">
          <form method="get" action="<?php echo esc_url($list_url); ?>" class="yoo-search-box">
            <input type="hidden" name="page" value="<?php echo esc_attr(yooadmin_network_site_themes_page_slug()); ?>" />
            <input type="hidden" name="id" value="<?php echo esc_attr((string) $blog_id); ?>" />
            <input type="hidden" name="theme-status" value="<?php echo esc_attr($view); ?>" />
            <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search themes…', 'yooadmin'); ?>" autocomplete="off" />
            <span class="dashicons dashicons-search" aria-hidden="true"></span>
          </form>
        </div>
      </div>

      <form method="post" action="<?php echo esc_url($list_url); ?>" id="yoo-network-site-themes-form">
        <input type="hidden" name="id" value="<?php echo esc_attr((string) $blog_id); ?>" />
        <?php wp_nonce_field('bulk-themes'); ?>

        <div class="yoo-bulk-actions-bar" id="yoo-network-site-themes-bulk-bar" style="display: none;">
          <div class="yoo-bulk-actions-left">
            <span class="yoo-selected-count" data-yoo-network-site-themes-count>0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
            <button type="button" class="yoo-bulk-action-link" data-yoo-network-site-themes-deselect hidden><?php esc_html_e('Deselect all', 'yooadmin'); ?></button>
            <button type="button" class="yoo-bulk-action-link" data-yoo-network-site-themes-select-all hidden><?php esc_html_e('Select all', 'yooadmin'); ?></button>
          </div>
          <div class="yoo-bulk-actions-right">
            <select name="action" id="yoo-network-site-themes-bulk-action" class="yoo-bulk-select">
              <option value="-1"><?php esc_html_e('Bulk actions', 'yooadmin'); ?></option>
              <option value="enable-selected"><?php esc_html_e('Enable', 'yooadmin'); ?></option>
              <option value="disable-selected"><?php esc_html_e('Disable', 'yooadmin'); ?></option>
            </select>
            <button type="submit" class="yp-yoo-btn yp-yoo-btn--primary yoo-bulk-apply-btn" id="yoo-network-site-themes-bulk-apply" disabled><?php esc_html_e('Apply', 'yooadmin'); ?></button>
          </div>
        </div>

        <?php if ($themes) : ?>
          <div class="yoo-wordpress-results yoo-plugins-grid" id="wp-results">
            <?php foreach ($themes as $theme) :
                $stylesheet = (string) $theme['stylesheet'];
                $enabled    = !empty($theme['enabled']);
                $name       = (string) $theme['name'];
                $version    = (string) ($theme['version'] ?? '');
                $author     = wp_strip_all_tags((string) ($theme['author'] ?? ''));
                $description = (string) ($theme['description'] ?? '');
                $screenshot = (string) ($theme['screenshot'] ?? '');
                $toggle_url = $enabled
                    ? wp_nonce_url(add_query_arg(['action' => 'disable', 'theme' => $stylesheet, 'id' => $blog_id], $list_url), 'disable-theme_' . $stylesheet)
                    : wp_nonce_url(add_query_arg(['action' => 'enable', 'theme' => $stylesheet, 'id' => $blog_id], $list_url), 'enable-theme_' . $stylesheet);
                $cb_id = 'yoo-network-site-theme-' . sanitize_html_class($stylesheet);
                ?>
              <div class="yoo-plugin-card yoo-theme-card<?php echo $enabled ? ' active' : ''; ?>" data-stylesheet="<?php echo esc_attr($stylesheet); ?>" data-theme-name="<?php echo esc_attr($name); ?>">
                <div class="yoo-theme-card-media-wrap">
                  <label class="yoo-media-card__select yoo-theme-card__select" for="<?php echo esc_attr($cb_id); ?>">
                    <input type="checkbox" id="<?php echo esc_attr($cb_id); ?>" class="yoo-media-card__cb" name="checked[]" value="<?php echo esc_attr($stylesheet); ?>" data-yoo-network-site-theme-cb />
                  </label>

                  <?php if ($screenshot !== '') : ?>
                    <div class="yoo-theme-card-media" style="background-image:url('<?php echo esc_url($screenshot); ?>');" role="img" aria-label="<?php echo esc_attr($name); ?>"></div>
                  <?php else : ?>
                    <div class="yoo-theme-card-media yoo-theme-card-media--placeholder" aria-hidden="true">
                      <span class="dashicons dashicons-admin-appearance"></span>
                    </div>
                  <?php endif; ?>

                  <div class="yoo-theme-card-hover-glass" aria-hidden="true"></div>
                  <div class="yoo-theme-card-hover-text">
                    <span class="yoo-theme-card-hover-title"><?php echo esc_html($name); ?></span>
                    <?php if ($author !== '') : ?>
                      <span class="yoo-theme-card-hover-author"><?php echo esc_html($author); ?></span>
                    <?php endif; ?>
                    <?php if ($description !== '') : ?>
                      <span class="yoo-theme-card-hover-desc"><?php echo esc_html(wp_trim_words($description, 18)); ?></span>
                    <?php endif; ?>
                  </div>

                  <div class="yoo-theme-card-top-tags<?php echo $enabled ? '' : ' yoo-theme-card-top-tags--inactive-hover-only'; ?>">
                    <?php if ($version !== '') : ?>
                      <span class="yoo-theme-version-tag"><?php echo esc_html('v' . $version); ?></span>
                    <?php endif; ?>
                    <div class="yoo-theme-status-tag" role="status">
                      <span class="yoo-theme-status-tag__pill <?php echo $enabled ? 'yoo-theme-status-tag__pill--active' : 'yoo-theme-status-tag__pill--inactive'; ?>">
                        <?php echo esc_html($enabled ? __('Enabled', 'yooadmin') : __('Disabled', 'yooadmin')); ?>
                      </span>
                    </div>
                  </div>

                  <div class="yoo-theme-card__actions-overlay">
                    <div class="yoo-theme-card__actions-bar">
                      <?php if ($enabled) : ?>
                        <a class="yoo-media-float-btn yoo-network-site-theme-toggle" href="<?php echo esc_url($toggle_url); ?>" title="<?php esc_attr_e('Disable', 'yooadmin'); ?>" aria-label="<?php esc_attr_e('Disable', 'yooadmin'); ?>">
                          <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                        </a>
                      <?php else : ?>
                        <a class="yoo-media-float-btn yoo-network-site-theme-toggle" href="<?php echo esc_url($toggle_url); ?>" title="<?php esc_attr_e('Enable', 'yooadmin'); ?>" aria-label="<?php esc_attr_e('Enable', 'yooadmin'); ?>">
                          <span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
                        </a>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else : ?>
          <div class="yoo-users-empty yoo-network-site-themes-empty">
            <div class="yoo-empty-illustration yoo-empty-illustration--themes" aria-hidden="true"></div>
            <h2><?php esc_html_e('No themes match your filters.', 'yooadmin'); ?></h2>
            <p><?php esc_html_e('Try adjusting your filters or search terms.', 'yooadmin'); ?></p>
          </div>
        <?php endif; ?>
      </form>
</div>
