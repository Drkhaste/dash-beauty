<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$blog_id = function_exists('yooadmin_network_site_editor_current_id') ? yooadmin_network_site_editor_current_id() : 0;
if ($blog_id <= 0 || !function_exists('yooadmin_network_site_editor_get_site') || !yooadmin_network_site_editor_get_site($blog_id)) {
    return;
}

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$view   = isset($_GET['theme-status']) ? sanitize_key(wp_unslash((string) $_GET['theme-status'])) : 'all';
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$search = isset($_GET['s']) ? sanitize_text_field(wp_unslash((string) $_GET['s'])) : '';

if (!in_array($view, ['all', 'enabled', 'disabled'], true)) {
    $view = 'all';
}

$list_url     = yooadmin_network_site_themes_url($blog_id);
$themes       = yooadmin_network_site_themes_get_items($blog_id, $view, $search);
$selected_tab = 'site-themes';
$page_slug    = 'network-site-themes';
$wrap_form    = false;
$flash_keys   = ['enabled', 'disabled', 'error'];
$panel_partial = __DIR__ . '/tab-themes.php';

$shell = function_exists('yooadmin_network_site_editor_shell_template') ? yooadmin_network_site_editor_shell_template() : '';
if ($shell) {
    include $shell;
}
