<?php
/**
 * YOOAdmin - Pages index template
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

$list_url = admin_url('admin.php?page=yooadmin-pages');
$new_url = admin_url('post-new.php?post_type=page');
$has_search = ($search !== '');
$has_status = ($status !== '');
?>

<div class="wrap yooadmin-pages-page">
    <section class="yoo-pages-hero">
        <div class="yoo-pages-hero__body">
            <div class="yoo-pages-hero__top-row">
                <span class="yoo-pages-hero__eyebrow"><?php esc_html_e('Content · Pages', 'yooadmin'); ?></span>
                <div class="yoo-pages-hero__actions">
                    <div class="yoo-pages-search-wrapper">
                        <span class="dashicons dashicons-search"></span>
                        <input type="search" id="yoo-pages-search-input" class="yoo-pages-search-input" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search pages...', 'yooadmin'); ?>">
                    </div>
                    <a class="yp-yoo-btn yp-yoo-btn--primary" href="<?php echo esc_url($new_url); ?>">
                        <span class="dashicons dashicons-plus-alt"></span>
                        <?php esc_html_e('Add New', 'yooadmin'); ?>
                    </a>
                </div>
            </div>
            <h1>
                <span class="dashicons dashicons-admin-page"></span>
                <?php esc_html_e('Pages', 'yooadmin'); ?>
            </h1>
            <button type="button" class="yoo-pages-metrics-toggle" aria-expanded="false">
                <span class="dashicons dashicons-arrow-down-alt"></span>
                <span><?php esc_html_e('Show Statistics', 'yooadmin'); ?></span>
            </button>
        </div>

        <div class="yoo-pages-hero__metrics">
            <article class="yoo-pages-metric">
                <div class="yoo-pages-metric__icon">
                    <span class="dashicons dashicons-admin-page"></span>
                </div>
                <div class="yoo-pages-metric__content">
                    <strong class="yoo-pages-metric__value"><?php echo esc_html(number_format_i18n($total_count)); ?></strong>
                    <span class="yoo-pages-metric__label"><?php esc_html_e('Total Pages', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-pages-metric">
                <div class="yoo-pages-metric__icon">
                    <span class="dashicons dashicons-yes"></span>
                </div>
                <div class="yoo-pages-metric__content">
                    <strong class="yoo-pages-metric__value"><?php echo esc_html(number_format_i18n($publish_count)); ?></strong>
                    <span class="yoo-pages-metric__label"><?php esc_html_e('Published', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-pages-metric">
                <div class="yoo-pages-metric__icon">
                    <span class="dashicons dashicons-edit"></span>
                </div>
                <div class="yoo-pages-metric__content">
                    <strong class="yoo-pages-metric__value"><?php echo esc_html(number_format_i18n($draft_count)); ?></strong>
                    <span class="yoo-pages-metric__label"><?php esc_html_e('Drafts', 'yooadmin'); ?></span>
                </div>
            </article>
        </div>
    </section>

    <section class="yoo-pages-content-section">
        <div class="yoo-pages-toolbar">
            <div class="yoo-pages-filters">
                <a class="yoo-filter-chip <?php echo !$has_status ? 'is-active' : ''; ?>" href="<?php echo esc_url($list_url); ?>" data-status="">
                    <?php esc_html_e('All', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($total_count)); ?></span>
                </a>
                <a class="yoo-filter-chip <?php echo $status === 'publish' ? 'is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('post_status', 'publish', $list_url)); ?>" data-status="publish">
                    <?php esc_html_e('Published', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($publish_count)); ?></span>
                </a>
                <a class="yoo-filter-chip <?php echo $status === 'draft' ? 'is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('post_status', 'draft', $list_url)); ?>" data-status="draft">
                    <?php esc_html_e('Draft', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($draft_count)); ?></span>
                </a>
                <a class="yoo-filter-chip <?php echo $status === 'trash' ? 'is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('post_status', 'trash', $list_url)); ?>" data-status="trash">
                    <?php esc_html_e('Trash', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($trash_count)); ?></span>
                </a>
            </div>
            
            <div class="yoo-view-toggle">
                <button type="button" class="yoo-view-btn yoo-view-btn--cards is-active" data-view="cards" title="<?php esc_attr_e('Cards View', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-grid-view"></span>
                </button>
                <button type="button" class="yoo-view-btn yoo-view-btn--table" data-view="table" title="<?php esc_attr_e('Table View', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-list-view"></span>
                </button>
            </div>
        </div>

        <div class="yoo-bulk-actions-bar">
            <div class="yoo-bulk-actions-left">
                <input type="checkbox" id="yoo-select-all-pages" class="yoo-checkbox">
                <label for="yoo-select-all-pages"><?php esc_html_e('Select All', 'yooadmin'); ?></label>
                <span class="yoo-selected-count">0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
            </div>
            <div class="yoo-bulk-actions-right">
                <select id="yoo-bulk-action-select" class="yoo-bulk-select">
                    <option value=""><?php esc_html_e('Bulk Actions', 'yooadmin'); ?></option>
                    <option value="trash"><?php esc_html_e('Move to Trash', 'yooadmin'); ?></option>
                    <option value="restore"><?php esc_html_e('Restore', 'yooadmin'); ?></option>
                    <option value="delete"><?php esc_html_e('Delete Permanently', 'yooadmin'); ?></option>
                </select>
                <button type="button" id="yoo-bulk-apply" class="yp-yoo-btn yp-yoo-btn--primary" disabled>
                    <?php esc_html_e('Apply', 'yooadmin'); ?>
                </button>
            </div>
        </div>

        <div id="yoo-pages-content" class="yoo-view-cards" data-max-pages="<?php echo esc_attr($query->max_num_pages); ?>"
             data-current-status="<?php echo esc_attr($status); ?>"
             data-current-search="<?php echo esc_attr($search); ?>">
            <script>
            !function(){try{var k='yooadmin_pages_view';if(localStorage.getItem(k)!=='table')return;var r=document.getElementById('yoo-pages-content');if(!r)return;r.classList.remove('yoo-view-cards');r.classList.add('yoo-view-table');var c=document.querySelector('.yoo-view-btn--cards'),t=document.querySelector('.yoo-view-btn--table');if(c)c.classList.remove('is-active');if(t)t.classList.add('is-active')}catch(e){}}();
            </script>
            <?php if ($query->have_posts()): ?>
                <!-- Cards View -->
                <div class="yoo-pages-grid yoo-view-cards">
                    <?php while ($query->have_posts()):
        $query->the_post();
        $page = get_post();
        $edit_url = get_edit_post_link($page->ID);
        $view_url = get_permalink($page->ID);
        $page_status = $page->post_status;
        $page_author = get_userdata($page->post_author);
        $featured_image = get_the_post_thumbnail_url($page->ID, 'medium');
        $parent = $page->post_parent ? get_post($page->post_parent) : null;
?>
                    <article class="yoo-page-card <?php echo esc_attr($page_status); ?>" data-page-id="<?php echo esc_attr($page->ID); ?>">
                        <input type="checkbox" class="yoo-page-checkbox" value="<?php echo esc_attr($page->ID); ?>" id="page-<?php echo esc_attr($page->ID); ?>">
                        <label for="page-<?php echo esc_attr($page->ID); ?>" class="yoo-page-checkbox-label"></label>
                        
                        <div class="yoo-page-image">
                            <span class="yoo-page-status yoo-page-status--<?php echo esc_attr($page_status); ?>">
                                <?php echo esc_html(ucfirst($page_status)); ?>
                            </span>
                            <?php $this->render_page_role_badges_html($page->ID); ?>
                            <?php if ($featured_image):
            $full_image = get_the_post_thumbnail_url($page->ID, 'full');
?>
                            <img src="<?php echo esc_url($featured_image); ?>" 
                                 alt="<?php echo esc_attr(get_the_title($page->ID)); ?>"
                                 class="yoo-image-lightbox-trigger"
                                 data-image-url="<?php echo esc_url($full_image); ?>"
                                 data-image-title="<?php echo esc_attr(get_the_title($page->ID)); ?>"
                                 style="cursor: pointer;">
                            <?php
        else: ?>
                            <div class="yoo-page-image-placeholder">
                                <span class="dashicons dashicons-format-image"></span>
                                <span class="yoo-placeholder-text"><?php esc_html_e('No Image', 'yooadmin'); ?></span>
                            </div>
                            <?php
        endif; ?>
                        </div>
                        
                        <div class="yoo-page-content">
                            <header class="yoo-page-header">
                                <h2 class="yoo-page-title">
                                    <a href="<?php echo esc_url($edit_url); ?>" title="<?php echo esc_attr(get_the_title($page->ID) ?: __('(No title)', 'yooadmin')); ?>">
                                        <?php echo esc_html(get_the_title($page->ID) ?: __('(No title)', 'yooadmin')); ?>
                                    </a>
                                </h2>
                            </header>
                            
                            <div class="yoo-page-meta">
                                <div class="yoo-page-meta-item">
                                    <span class="dashicons dashicons-admin-users"></span>
                                    <span><?php echo esc_html($page_author ? $page_author->display_name : __('Unknown', 'yooadmin')); ?></span>
                                </div>
                                <div class="yoo-page-meta-item">
                                    <span class="dashicons dashicons-calendar-alt"></span>
                                    <span><?php echo esc_html(get_the_date('', $page->ID)); ?></span>
                                </div>
                                <?php if ($parent): ?>
                                <div class="yoo-page-meta-item">
                                    <span class="dashicons dashicons-networking"></span>
                                    <span><?php echo esc_html($parent->post_title); ?></span>
                                </div>
                                <?php
        endif; ?>
                            </div>
                            
                            <?php if (!empty($page->post_excerpt)): ?>
                            <p class="yoo-page-excerpt"><?php echo esc_html(wp_trim_words($page->post_excerpt, 20)); ?></p>
                            <?php
        endif; ?>
                            
                            <div class="yoo-page-actions">
                                <?php if ($page_status === 'publish'): ?>
                                <a href="<?php echo esc_url($view_url); ?>" target="_blank" class="yoo-action-btn">
                                    <span class="dashicons dashicons-visibility"></span>
                                    <?php esc_html_e('View', 'yooadmin'); ?>
                                </a>
                                <?php
        endif; ?>
                                <a href="<?php echo esc_url($edit_url); ?>" class="yoo-action-btn">
                                    <span class="dashicons dashicons-edit"></span>
                                    <?php esc_html_e('Edit', 'yooadmin'); ?>
                                </a>
                                <?php if ($page_status === 'publish' && current_user_can('edit_page', $page->ID)): ?>
                                <button type="button" class="yoo-action-btn to-draft" data-page-id="<?php echo esc_attr($page->ID); ?>">
                                    <span class="dashicons dashicons-hidden"></span>
                                    <?php esc_html_e('Draft', 'yooadmin'); ?>
                                </button>
                                <?php
        elseif (in_array($page_status, ['draft', 'pending', 'private'], true) && current_user_can('publish_post', $page->ID)): ?>
                                <button type="button" class="yoo-action-btn to-publish" data-page-id="<?php echo esc_attr($page->ID); ?>">
                                    <span class="dashicons dashicons-yes-alt"></span>
                                    <?php esc_html_e('Publish', 'yooadmin'); ?>
                                </button>
                                <?php
        endif; ?>
                                <?php if ($page_status === 'trash'): ?>
                                <button class="yoo-action-btn restore" data-page-id="<?php echo esc_attr($page->ID); ?>">
                                    <span class="dashicons dashicons-undo"></span>
                                    <?php esc_html_e('Restore', 'yooadmin'); ?>
                                </button>
                                <button class="yoo-action-btn danger delete" data-page-id="<?php echo esc_attr($page->ID); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php esc_html_e('Delete', 'yooadmin'); ?>
                                </button>
                                <?php
        else: ?>
                                <button class="yoo-action-btn trash" data-page-id="<?php echo esc_attr($page->ID); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php esc_html_e('Trash', 'yooadmin'); ?>
                                </button>
                                <?php
        endif; ?>
                            </div>
                            <?php yooadmin_render_yoast_summary($page->ID, 'page'); ?>
                        </div>
                    </article>
                    <?php
    endwhile;
    wp_reset_postdata(); ?>
                </div>
                
                <!-- Table View -->
                <div class="yoo-pages-table yoo-view-table">
                    <table class="wp-list-table widefat fixed striped table-view-list" style="width: 100%;">
                        <thead>
                            <tr>
                                <td class="manage-column column-cb check-column">
                                    <input type="checkbox" id="yoo-select-all-pages-table" class="yoo-checkbox">
                                </td>
                                <th scope="col" class="manage-column column-thumbnail">
                                    <?php esc_html_e('Image', 'yooadmin'); ?>
                                </th>
                                <th scope="col" class="manage-column column-title column-primary sortable sort-desc" data-sort="title">
                                    <a href="#" class="yoo-sort-link">
                                        <span><?php esc_html_e('Title', 'yooadmin'); ?></span>
                                        <span class="sorting-indicator"></span>
                                    </a>
                                </th>
                                <th scope="col" class="manage-column column-author">
                                    <?php esc_html_e('Author', 'yooadmin'); ?>
                                </th>
                                <th scope="col" class="manage-column column-parent">
                                    <?php esc_html_e('Parent', 'yooadmin'); ?>
                                </th>
                                <th scope="col" class="manage-column column-date sortable" data-sort="date">
                                    <a href="#" class="yoo-sort-link">
                                        <span><?php esc_html_e('Date', 'yooadmin'); ?></span>
                                        <span class="sorting-indicator"></span>
                                    </a>
                                </th>
                                <th scope="col" class="manage-column column-status">
                                    <?php esc_html_e('Status', 'yooadmin'); ?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
    $query->rewind_posts();
    while ($query->have_posts()):
        $query->the_post();
        $page = get_post();
        $edit_url = get_edit_post_link($page->ID);
        $view_url = get_permalink($page->ID);
        $page_status = $page->post_status;
        $page_author = get_userdata($page->post_author);
        $parent = $page->post_parent ? get_post($page->post_parent) : null;
?>
                            <tr class="yoo-page-row <?php echo esc_attr($page_status); ?>" data-page-id="<?php echo esc_attr($page->ID); ?>" data-title="<?php echo esc_attr(strtolower(get_the_title($page->ID) ?: '')); ?>" data-date="<?php echo esc_attr(get_the_date('U', $page->ID)); ?>">
                                <th scope="row" class="check-column">
                                    <input type="checkbox" class="yoo-page-checkbox" value="<?php echo esc_attr($page->ID); ?>" id="page-table-<?php echo esc_attr($page->ID); ?>">
                                    <label for="page-table-<?php echo esc_attr($page->ID); ?>" class="screen-reader-text"><?php esc_html_e('Select', 'yooadmin'); ?></label>
                                </th>
                                <td class="thumbnail column-thumbnail" data-colname="<?php esc_attr_e('Image', 'yooadmin'); ?>">
                                    <div class="yoo-table-thumb-wrap">
                                    <?php
        $featured_image = get_the_post_thumbnail_url($page->ID, 'thumbnail');
        if ($featured_image):
?>
                                    <?php
            $full_image = get_the_post_thumbnail_url($page->ID, 'full');
?>
                                    <div class="yoo-table-thumbnail">
                                        <img src="<?php echo esc_url($featured_image); ?>" 
                                             alt="<?php echo esc_attr(get_the_title($page->ID)); ?>"
                                             class="yoo-image-lightbox-trigger"
                                             data-image-url="<?php echo esc_url($full_image); ?>"
                                             data-image-title="<?php echo esc_attr(get_the_title($page->ID)); ?>"
                                             style="cursor: pointer;">
                                    </div>
                                    <?php
        else: ?>
                                    <div class="yoo-table-thumbnail yoo-table-thumbnail--placeholder">
                                        <span class="dashicons dashicons-format-image"></span>
                                    </div>
                                    <?php
        endif; ?>
                                    </div>
                                </td>
                                <td class="title column-title column-primary" data-colname="<?php esc_attr_e('Title', 'yooadmin'); ?>">
                                    <strong>
                                        <a class="row-title" href="<?php echo esc_url($edit_url); ?>" title="<?php echo esc_attr(get_the_title($page->ID) ?: __('(No title)', 'yooadmin')); ?>">
                                            <?php echo esc_html(get_the_title($page->ID) ?: __('(No title)', 'yooadmin')); ?>
                                        </a>
                                    </strong>
                                    <?php $this->render_page_role_badges_html($page->ID); ?>
                                    <div class="row-actions">
                                        <?php if ($page_status === 'publish'): ?>
                                        <span class="view">
                                            <a href="<?php echo esc_url($view_url); ?>" target="_blank"><?php esc_html_e('View', 'yooadmin'); ?></a> |
                                        </span>
                                        <?php
        endif; ?>
                                        <span class="edit">
                                            <a href="<?php echo esc_url($edit_url); ?>"><?php esc_html_e('Edit', 'yooadmin'); ?></a> |
                                        </span>
                                        <?php if ($page_status === 'publish' && current_user_can('edit_page', $page->ID)): ?>
                                        <span class="to-draft">
                                            <a href="#" class="yoo-action-link to-draft" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Draft', 'yooadmin'); ?></a> |
                                        </span>
                                        <?php
        elseif (in_array($page_status, ['draft', 'pending', 'private'], true) && current_user_can('publish_post', $page->ID)): ?>
                                        <span class="to-publish">
                                            <a href="#" class="yoo-action-link to-publish" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Publish', 'yooadmin'); ?></a> |
                                        </span>
                                        <?php
        endif; ?>
                                        <?php if ($page_status === 'trash'): ?>
                                        <span class="restore">
                                            <a href="#" class="yoo-action-link restore" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Restore', 'yooadmin'); ?></a> |
                                        </span>
                                        <span class="trash">
                                            <a href="#" class="yoo-action-link delete" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Delete Permanently', 'yooadmin'); ?></a>
                                        </span>
                                        <?php
        else: ?>
                                        <span class="trash">
                                            <a href="#" class="yoo-action-link trash" data-page-id="<?php echo esc_attr($page->ID); ?>"><?php esc_html_e('Trash', 'yooadmin'); ?></a>
                                        </span>
                                        <?php
        endif; ?>
                                    </div>
                                    <?php yooadmin_render_yoast_summary($page->ID, 'page'); ?>
                                </td>
                                <td class="author column-author" data-colname="<?php esc_attr_e('Author', 'yooadmin'); ?>">
                                    <?php echo esc_html($page_author ? $page_author->display_name : __('Unknown', 'yooadmin')); ?>
                                </td>
                                <td class="parent column-parent" data-colname="<?php esc_attr_e('Parent', 'yooadmin'); ?>">
                                    <?php echo $parent ? esc_html($parent->post_title) : '<span aria-hidden="true">—</span>'; ?>
                                </td>
                                <td class="date column-date" data-colname="<?php esc_attr_e('Date', 'yooadmin'); ?>">
                                    <?php echo esc_html(get_the_date('', $page->ID)); ?>
                                </td>
                                <td class="status column-status" data-colname="<?php esc_attr_e('Status', 'yooadmin'); ?>">
                                    <span class="yoo-page-status yoo-page-status--<?php echo esc_attr($page_status); ?>">
                                        <?php echo esc_html(ucfirst($page_status)); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php
    endwhile;
    wp_reset_postdata(); ?>
                        </tbody>
                    </table>
                </div>
            <?php
else: ?>
                <div class="yoo-pages-empty">
                    <div class="yoo-empty-illustration">
                        <span class="dashicons dashicons-admin-page"></span>
                    </div>
                    <h2><?php esc_html_e('No pages found', 'yooadmin'); ?></h2>
                    <p><?php esc_html_e('Try adjusting your search or filter criteria.', 'yooadmin'); ?></p>
                    <a class="yp-yoo-btn yp-yoo-btn--primary" href="<?php echo esc_url($new_url); ?>">
                        <?php esc_html_e('Create first page', 'yooadmin'); ?>
                    </a>
                </div>
            <?php
endif; ?>
        </div>
    </section>
</div>

<!-- Image Lightbox Modal -->
<div id="yoo-image-lightbox" class="yoo-image-lightbox" style="display: none;">
    <div class="yoo-lightbox-overlay"></div>
    <div class="yoo-lightbox-container">
        <button class="yoo-lightbox-close" aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
            <span class="dashicons dashicons-no-alt"></span>
        </button>
        <div class="yoo-lightbox-content">
            <img src="" alt="" class="yoo-lightbox-image">
            <div class="yoo-lightbox-title"></div>
        </div>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
