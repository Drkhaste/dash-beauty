<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$blog_id = function_exists('yooadmin_network_site_editor_current_id') ? yooadmin_network_site_editor_current_id() : 0;
$form_action = function_exists('yooadmin_network_site_yooadmin_url') ? yooadmin_network_site_yooadmin_url($blog_id) : '';
$defaults = function_exists('yooadmin_network_site_yooadmin_default_form_values')
    ? yooadmin_network_site_yooadmin_default_form_values()
    : (function_exists('yooadmin_network_site_yooadmin_default_provision_flags') ? yooadmin_network_site_yooadmin_default_provision_flags() : []);
$site_prefs = function_exists('yooadmin_network_site_yooadmin_get_site_prefs')
    ? yooadmin_network_site_yooadmin_get_site_prefs($blog_id)
    : ['show_admin_tour' => true];
$apply_defaults         = $defaults;
$apply_defaults['show_admin_tour'] = !empty($site_prefs['show_admin_tour']);
?>
<div class="yoo-network-site-yooadmin-tab">
  <form method="post" action="<?php echo esc_url($form_action); ?>" class="yoo-network-site-yooadmin-form">
    <?php wp_nonce_field('yooadmin-network-site-yooadmin'); ?>
    <input type="hidden" name="id" value="<?php echo esc_attr((string) $blog_id); ?>" />
    <input type="hidden" name="yooadmin_network_site_yooadmin_action" value="apply-to-site" />

    <div class="yoo-network-settings-card yp-settings-card yoo-network-site-yooadmin-tab__apply-card">
      <div class="yoo-network-settings-card__head">
        <span class="dashicons dashicons-update" aria-hidden="true"></span>
        <h3><?php esc_html_e('Copy from network', 'yooadmin'); ?></h3>
      </div>

      <p class="description yoo-network-site-yooadmin-tab__intro">
        <?php esc_html_e('Push the saved network template into this site. Choose what to apply — branding from the main site, guided tour for the site admin, or both. Logo images are copied into this site’s media library.', 'yooadmin'); ?>
      </p>

      <?php
      yooadmin_network_site_yooadmin_render_settings_table_open();
      if (function_exists('yooadmin_network_site_yooadmin_render_provision_toggle_rows')) {
          yooadmin_network_site_yooadmin_render_provision_toggle_rows('yooadmin_apply_', $apply_defaults, 'yooadmin');
      }
      yooadmin_network_site_yooadmin_render_settings_table_close();
      ?>

      <div class="yoo-network-site-yooadmin-tab__actions submit">
        <button type="submit" class="yp-yoo-btn yp-yoo-btn--primary">
          <?php esc_html_e('Apply to this site', 'yooadmin'); ?>
        </button>
      </div>
    </div>
  </form>
</div>
