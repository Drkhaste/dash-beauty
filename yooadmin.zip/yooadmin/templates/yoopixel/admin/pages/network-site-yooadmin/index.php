<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$blog_id = function_exists('yooadmin_network_site_editor_current_id') ? yooadmin_network_site_editor_current_id() : 0;
if ($blog_id <= 0 || !function_exists('yooadmin_network_site_editor_get_site') || !yooadmin_network_site_editor_get_site($blog_id)) {
    return;
}

$selected_tab = 'site-yooadmin';
$page_slug    = 'network-site-yooadmin';
$wrap_form    = false;
$form_action  = yooadmin_network_site_yooadmin_url($blog_id);
$form_id      = 'yoo-network-site-yooadmin-form';
$form_nonce   = 'yooadmin-network-site-yooadmin';
$form_hidden_action = '';
$flash_keys   = ['update'];
$panel_partial = __DIR__ . '/tab-yooadmin.php';

$shell = function_exists('yooadmin_network_site_editor_shell_template') ? yooadmin_network_site_editor_shell_template() : '';
if ($shell) {
    include $shell;
}
