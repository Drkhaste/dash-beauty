<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$query = function_exists('yooadmin_network_sites_query') ? yooadmin_network_sites_query() : [
    'items'    => [],
    'total'    => 0,
    'pages'    => 1,
    'page'     => 1,
    'per_page' => 20,
    'search'   => '',
];

$items    = isset($query['items']) && is_array($query['items']) ? $query['items'] : [];
$total    = (int) ($query['total'] ?? 0);
$pages    = max(1, (int) ($query['pages'] ?? 1));
$page     = max(1, (int) ($query['page'] ?? 1));
$search   = isset($query['search']) ? (string) $query['search'] : '';
$add_url  = function_exists('yooadmin_network_site_new_url') ? yooadmin_network_site_new_url() : network_admin_url('site-new.php');
$list_url = function_exists('yooadmin_network_sites_url') ? yooadmin_network_sites_url() : network_admin_url('sites.php');
$flash       = isset($flash) && is_array($flash) ? $flash : ['', ''];
$bulk_action = isset($bulk_action) ? (string) $bulk_action : network_admin_url('sites.php?action=allblogs');
$bulk_actions = isset($bulk_actions) && is_array($bulk_actions) ? $bulk_actions : [];
$flash_msg   = !empty($flash[0]) ? (string) $flash[0] : '';
$flash_type  = !empty($flash[1]) ? (string) $flash[1] : 'success';
$can_bulk    = current_user_can('manage_sites');
?>
<div class="wrap yoo-upload-wrap yoo-network-sites-wrap" data-page="network-sites">
  <?php if ($flash_msg !== '') : ?>
    <div class="notice notice-<?php echo esc_attr($flash_type); ?> is-dismissible">
      <p><?php echo esc_html($flash_msg); ?></p>
    </div>
  <?php endif; ?>
  <div class="yoo-upload-header yoo-network-sites-header">
    <div class="yoo-upload-header-content">
      <h1 class="yoo-upload-title">
        <span class="dashicons dashicons-admin-multisite yoo-upload-title-dashicon" aria-hidden="true"></span>
        <?php esc_html_e('Sites', 'yooadmin'); ?>
      </h1>
      <p class="yoo-upload-subtitle">
        <?php
        if ($search !== '') {
            echo esc_html(
                sprintf(
                    /* translators: 1: number of sites, 2: search term. */
                    _n('%1$s site found for “%2$s”.', '%1$s sites found for “%2$s”.', $total, 'yooadmin'),
                    number_format_i18n($total),
                    $search
                )
            );
        } else {
            echo esc_html(
                sprintf(
                    /* translators: %s: number of sites. */
                    _n('%s site in your network.', '%s sites in your network.', $total, 'yooadmin'),
                    number_format_i18n($total)
                )
            );
        }
        ?>
      </p>
    </div>
    <div class="yoo-upload-header-actions yoo-network-sites-header-actions yp-network-sites-card__header-actions">
      <a class="yp-yoo-btn yp-yoo-btn--primary" href="<?php echo esc_url($add_url); ?>">
        <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
        <?php esc_html_e('Add Site', 'yooadmin'); ?>
      </a>
    </div>
  </div>

  <div class="yoo-network-sites-toolbar">
    <form method="get" action="<?php echo esc_url($list_url); ?>" class="yoo-network-sites-search" role="search">
      <input type="hidden" name="page" value="<?php echo esc_attr(function_exists('yooadmin_network_sites_page_slug') ? yooadmin_network_sites_page_slug() : 'yooadmin-network-sites'); ?>" />
      <label class="screen-reader-text" for="yoo-network-sites-search-input"><?php esc_html_e('Search sites', 'yooadmin'); ?></label>
      <span class="yoo-network-sites-search__field">
        <span class="dashicons dashicons-search" aria-hidden="true"></span>
        <input
          type="search"
          id="yoo-network-sites-search-input"
          name="s"
          value="<?php echo esc_attr($search); ?>"
          placeholder="<?php esc_attr_e('Search sites…', 'yooadmin'); ?>"
          autocomplete="off"
        />
      </span>
      <button type="submit" class="yp-yoo-btn yp-yoo-btn--soft"><?php esc_html_e('Search', 'yooadmin'); ?></button>
      <?php if ($search !== '') : ?>
        <a class="yp-yoo-btn yp-yoo-btn--soft" href="<?php echo esc_url($list_url); ?>"><?php esc_html_e('Clear', 'yooadmin'); ?></a>
      <?php endif; ?>
    </form>
  </div>

  <form id="yoo-network-sites-bulk-form" method="post" action="<?php echo esc_url($bulk_action); ?>">
    <?php wp_nonce_field('bulk-sites'); ?>
    <input type="hidden" name="wp_http_referer" value="<?php echo esc_url($list_url); ?>">

    <?php if ($can_bulk && $items) : ?>
      <div class="yoo-bulk-actions-bar">
        <div class="yoo-bulk-actions-left">
          <label class="yoo-bulk-select-all" for="yoo-select-all-sites">
            <input type="checkbox" id="yoo-select-all-sites" class="yoo-bulk-select-all__input" />
            <span class="yoo-bulk-select-all__box" aria-hidden="true"></span>
            <span class="yoo-bulk-select-all__text"><?php esc_html_e('Select All', 'yooadmin'); ?></span>
          </label>
          <span class="yoo-selected-count">0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
        </div>
        <div class="yoo-bulk-actions-right">
          <select name="action" id="yoo-network-sites-bulk-action" class="yoo-bulk-select" data-yp-enhance-select="1">
            <option value="-1"><?php esc_html_e('Bulk Actions', 'yooadmin'); ?></option>
            <?php foreach ($bulk_actions as $value => $label) : ?>
              <option value="<?php echo esc_attr((string) $value); ?>"><?php echo esc_html((string) $label); ?></option>
            <?php endforeach; ?>
          </select>
          <button type="button" class="yp-yoo-btn yp-yoo-btn--primary yoo-bulk-apply" id="yoo-network-sites-bulk-apply" disabled>
            <?php esc_html_e('Apply', 'yooadmin'); ?>
          </button>
        </div>
      </div>
    <?php endif; ?>

  <div class="yoo-network-sites-shell yp-network-sites-card">
    <?php if ($items) : ?>
      <ul class="yp-network-sites-card__list yoo-network-sites-list">
        <?php foreach ($items as $site) :
            if (!is_array($site) || empty($site['admin'])) {
                continue;
            }
            $name      = (string) ($site['name'] ?? '');
            $home_url  = isset($site['home']) ? (string) $site['home'] : '';
            $url_label = (string) ($site['url_label'] ?? '');
            $is_main   = !empty($site['is_main']);
            $site_id   = isset($site['id']) ? (int) $site['id'] : 0;
            ?>
          <li class="yp-network-sites-card__item yoo-network-sites-list__item<?php echo $is_main ? ' yoo-network-sites-list__item--main' : ''; ?>"<?php echo $site_id > 0 ? ' data-yoo-site-id="' . esc_attr((string) $site_id) . '"' : ''; ?>>
            <span class="yp-network-sites-card__icon" aria-hidden="true">
              <span class="dashicons <?php echo $is_main ? 'dashicons-admin-home' : 'dashicons-admin-site-alt3'; ?>"></span>
            </span>
            <div class="yp-network-sites-card__content">
              <p class="yp-network-sites-card__title">
                <?php echo esc_html($name); ?>
                <?php
                if (function_exists('yooadmin_network_sites_render_status_tags')) {
                    yooadmin_network_sites_render_status_tags($site);
                }
                ?>
              </p>
              <?php if ($home_url !== '' && $url_label !== '') : ?>
                <a class="yp-network-sites-card__url" href="<?php echo esc_url($home_url); ?>" target="_blank" rel="noopener noreferrer">
                  <span class="dashicons dashicons-admin-links" aria-hidden="true"></span>
                  <span class="yp-network-sites-card__url-label"><?php echo esc_html($url_label); ?></span>
                </a>
              <?php endif; ?>
            </div>
            <div class="yp-network-sites-card__actions-wrap">
              <?php
              if (function_exists('yooadmin_network_sites_render_row_actions')) {
                  yooadmin_network_sites_render_row_actions($site, 'yooadmin');
              }
              ?>
              <?php if ($can_bulk && !$is_main && $site_id > 0) : ?>
                <span class="yoo-network-sites-row-select">
                  <input
                    type="checkbox"
                    class="yoo-site-checkbox"
                    name="allblogs[]"
                    value="<?php echo esc_attr((string) $site_id); ?>"
                    id="site-<?php echo esc_attr((string) $site_id); ?>"
                  />
                  <label
                    for="site-<?php echo esc_attr((string) $site_id); ?>"
                    class="yoo-site-checkbox-label"
                    aria-label="<?php echo esc_attr(sprintf(/* translators: %s: site name */ __('Select %s', 'yooadmin'), $name)); ?>"
                  ></label>
                </span>
              <?php endif; ?>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else : ?>
      <div class="yp-network-sites-card__empty yoo-network-sites-empty">
        <span class="yp-network-sites-card__icon" aria-hidden="true">
          <span class="dashicons dashicons-admin-multisite"></span>
        </span>
        <p class="yp-card-text">
          <?php echo $search !== '' ? esc_html__('No sites match your search.', 'yooadmin') : esc_html__('No sites found.', 'yooadmin'); ?>
        </p>
      </div>
    <?php endif; ?>
  </div>
  </form>

  <?php if ($pages > 1) : ?>
    <nav class="yoo-network-sites-pagination" aria-label="<?php esc_attr_e('Sites pagination', 'yooadmin'); ?>">
      <?php
      echo wp_kses_post(
          paginate_links(
              [
                  'base'      => add_query_arg('paged', '%#%', $list_url),
                  'format'    => '',
                  'current'   => $page,
                  'total'     => $pages,
                  'prev_text' => '&laquo; ' . esc_html__('Previous', 'yooadmin'),
                  'next_text' => esc_html__('Next', 'yooadmin') . ' &raquo;',
                  'add_args'  => $search !== '' ? ['s' => $search] : false,
              ]
          ) ?: ''
      );
      ?>
    </nav>
  <?php endif; ?>
</div>
