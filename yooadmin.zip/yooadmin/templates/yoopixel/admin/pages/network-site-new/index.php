<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.
$messages = function_exists('yooadmin_network_site_new_success_messages') ? yooadmin_network_site_new_success_messages() : [];
$form_url = function_exists('yooadmin_network_site_new_url') ? yooadmin_network_site_new_url(['action' => 'add-site']) : network_admin_url('site-new.php?action=add-site');
$list_url = function_exists('yooadmin_network_sites_url') ? yooadmin_network_sites_url() : network_admin_url('sites.php');
$provision_defaults = function_exists('yooadmin_network_site_yooadmin_default_form_values')
    ? yooadmin_network_site_yooadmin_default_form_values()
    : [
        'copy_settings'   => true,
        'copy_login_logo' => true,
        'show_admin_tour' => true,
    ];
$network_settings_url = function_exists('yooadmin_network_site_yooadmin_network_settings_url')
    ? yooadmin_network_site_yooadmin_network_settings_url()
    : '';

$languages    = get_available_languages();
$translations = wp_get_available_translations();
$lang         = get_site_option('WPLANG');
if (!in_array($lang, $languages, true)) {
    $lang = '';
}
?>
<div class="wrap yoo-upload-wrap yoo-network-site-new-wrap" data-page="network-add-site">
  <div class="yoo-upload-header yoo-network-site-new-header">
    <div class="yoo-upload-header-content">
      <h1 class="yoo-upload-title">
        <span class="dashicons dashicons-plus-alt2 yoo-upload-title-dashicon" aria-hidden="true"></span>
        <?php esc_html_e('Add Site', 'yooadmin'); ?>
      </h1>
      <p class="yoo-upload-subtitle"><?php esc_html_e('Create a new site in your network with a focused YOOAdmin workspace.', 'yooadmin'); ?></p>
    </div>
    <div class="yoo-upload-header-actions yoo-network-site-new-header-actions">
      <a class="yp-yoo-btn yp-yoo-btn--soft" href="<?php echo esc_url($list_url); ?>">
        <span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span>
        <?php esc_html_e('All Sites', 'yooadmin'); ?>
      </a>
    </div>
  </div>

  <?php if ($messages) : ?>
    <?php foreach ($messages as $message) : ?>
      <div class="yoo-network-settings-notice yoo-network-settings-notice--success">
        <span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
        <span><?php echo wp_kses_post($message); ?></span>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>

  <form method="post" action="<?php echo esc_url($form_url); ?>" class="yoo-network-site-new-form" id="yoo-network-site-new-form" enctype="multipart/form-data" novalidate>
    <?php wp_nonce_field('add-blog', '_wpnonce_add-blog'); ?>
    <input type="hidden" name="action" value="add-site" />

    <div class="yoo-network-site-new-shell">
      <div class="yoo-network-settings-card">
        <div class="yoo-network-settings-card__head">
          <span class="dashicons dashicons-admin-multisite" aria-hidden="true"></span>
          <h3><?php esc_html_e('Site Details', 'yooadmin'); ?></h3>
        </div>

        <p class="yoo-network-site-new-required-note"><?php echo wp_kses_post(yooadmin_required_field_message()); ?></p>

        <div class="yoo-network-settings-field yoo-network-settings-field--row form-required">
          <label for="site-address">
            <?php
            esc_html_e('Site Address (URL)', 'yooadmin');
            echo ' ' . yooadmin_required_field_indicator(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            ?>
          </label>
          <div class="yoo-network-settings-field__control">
            <div class="yoo-network-site-new-address">
              <?php if (is_subdomain_install()) : ?>
                <input name="blog[domain]" type="text" class="regular-text code" id="site-address" aria-describedby="site-address-desc" autocapitalize="none" autocorrect="off" required />
                <code class="yoo-network-site-new-address__suffix"><?php echo esc_html('.' . preg_replace('|^www\.|', '', get_network()->domain)); ?></code>
              <?php else : ?>
                <code class="yoo-network-site-new-address__prefix"><?php echo esc_html(get_network()->domain . get_network()->path); ?></code>
                <input name="blog[domain]" type="text" class="regular-text code" id="site-address" aria-describedby="site-address-desc" autocapitalize="none" autocorrect="off" required />
              <?php endif; ?>
            </div>
            <p class="description" id="site-address-desc"><?php esc_html_e('Only lowercase letters (a-z), numbers, and hyphens are allowed.', 'yooadmin'); ?></p>
          </div>
        </div>

        <div class="yoo-network-settings-field yoo-network-settings-field--row form-required">
          <label for="site-title">
            <?php
            esc_html_e('Site Title', 'yooadmin');
            echo ' ' . yooadmin_required_field_indicator(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            ?>
          </label>
          <div class="yoo-network-settings-field__control">
            <input name="blog[title]" type="text" class="regular-text" id="site-title" required />
          </div>
        </div>

        <?php if (!empty($languages) || !empty($translations)) : ?>
          <div class="yoo-network-settings-field yoo-network-settings-field--row">
            <label for="site-language"><?php esc_html_e('Site Language', 'yooadmin'); ?></label>
            <div class="yoo-network-settings-field__control">
              <?php
              wp_dropdown_languages(
                  [
                      'name'                        => 'WPLANG',
                      'id'                          => 'site-language',
                      'selected'                    => $lang,
                      'languages'                   => $languages,
                      'translations'                => $translations,
                      'show_available_translations' => current_user_can('install_languages') && wp_can_install_language_pack(),
                  ]
              );
              ?>
            </div>
          </div>
        <?php endif; ?>

        <div class="yoo-network-settings-field yoo-network-settings-field--row form-required">
          <label for="admin-email">
            <?php
            esc_html_e('Admin Email', 'yooadmin');
            echo ' ' . yooadmin_required_field_indicator(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            ?>
          </label>
          <div class="yoo-network-settings-field__control">
            <input name="blog[email]" type="email" class="regular-text wp-suggest-user" id="admin-email" data-autocomplete-type="search" data-autocomplete-field="user_email" aria-describedby="site-admin-email" required />
            <p class="description" id="site-admin-email">
              <?php esc_html_e('A new user will be created if the above email address is not in the database.', 'yooadmin'); ?>
              <?php esc_html_e('The username and a link to set the password will be mailed to this email address.', 'yooadmin'); ?>
            </p>
          </div>
        </div>

        <?php
        /** This action is documented in wp-admin/network/site-new.php */
        do_action('network_site_new_form'); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
        ?>
      </div>

      <?php if (function_exists('yooadmin_network_site_yooadmin_render_toggle')) : ?>
        <div class="yoo-network-settings-card yp-settings-card yooadmin-settings-wrap">
          <div class="yoo-network-settings-card__head">
            <span class="dashicons dashicons-admin-customizer" aria-hidden="true"></span>
            <h3><?php esc_html_e('YOOAdmin Setup', 'yooadmin'); ?></h3>
          </div>

          <?php if ($network_settings_url !== '') : ?>
            <p class="description yoo-network-site-yooadmin-defaults-link">
              <?php
              printf(
                  /* translators: %s: Network Settings YOOAdmin tab URL. */
                  wp_kses_post(__('Configure network defaults in <a href="%s">Network Settings → YOOAdmin</a>. The toggles below choose what is applied when this site is created.', 'yooadmin')),
                  esc_url($network_settings_url)
              );
              ?>
            </p>
          <?php endif; ?>

          <?php
          yooadmin_network_site_yooadmin_render_settings_table_open();
          if (function_exists('yooadmin_network_site_yooadmin_render_provision_toggle_rows')) {
              yooadmin_network_site_yooadmin_render_provision_toggle_rows('yooadmin_provision_', $provision_defaults, 'yooadmin');
          }
          yooadmin_network_site_yooadmin_render_settings_table_close();
          ?>
        </div>
      <?php endif; ?>

      <div class="yoo-network-site-new-form__actions">
        <button type="submit" class="yp-yoo-btn yp-yoo-btn--primary" name="add-site" value="1">
          <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
          <?php esc_html_e('Add Site', 'yooadmin'); ?>
        </button>
      </div>
    </div>
  </form>
</div>
