<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$layout = function_exists('yooadmin_network_dashboard_get_user_layout')
    ? yooadmin_network_dashboard_get_user_layout(get_current_user_id())
    : null;
if (!$layout && function_exists('yooadmin_network_dashboard_layout_defaults')) {
    $layout = yooadmin_network_dashboard_layout_defaults();
}

$main_order  = function_exists('yooadmin_network_dashboard_resolve_main_order')
    ? yooadmin_network_dashboard_resolve_main_order($layout)
    : ['network-workspace', 'network-sites'];
$aside_order = function_exists('yooadmin_network_dashboard_resolve_aside_order')
    ? yooadmin_network_dashboard_resolve_aside_order($layout)
    : ['network-overview', 'network-workspace-notes', 'network-tips'];

$collapse_aside = function_exists('yooadmin_network_dashboard_should_collapse_aside')
    && yooadmin_network_dashboard_should_collapse_aside($layout);
$layout_class   = 'yp-studio-hub__layout' . ($collapse_aside ? ' yp-studio-hub__layout--aside-empty' : '');
$aside_class    = 'yp-studio-hub__aside' . ($collapse_aside ? ' yp-studio-hub__aside--empty' : '');

$cards_dir = function_exists('yooadmin_network_dashboard_template_path')
    ? yooadmin_network_dashboard_template_path('components/network-dashboard')
    : '';

$menu_tree = function_exists('yooadmin_network_dashboard_resolve_menu_tree')
    ? yooadmin_network_dashboard_resolve_menu_tree()
    : (function_exists('yooadmin_build_network_admin_menu_tree')
        ? yooadmin_build_network_admin_menu_tree()
        : []);

$network_stats = function_exists('yooadmin_network_dashboard_network_stats')
    ? yooadmin_network_dashboard_network_stats()
    : ['sites' => 0, 'users' => 0];

$sites_card_limit = (int) apply_filters('yooadmin_network_dashboard_sites_card_limit', 5);
$sites_card_limit = max(1, min(20, $sites_card_limit));
$recent_sites     = function_exists('yooadmin_network_dashboard_recent_sites')
    ? yooadmin_network_dashboard_recent_sites($sites_card_limit)
    : [];

$section_context = [
    'menu_tree'     => $menu_tree,
    'recent_sites'  => $recent_sites,
    'network_stats' => $network_stats,
];
?>
<style id="yooadmin-network-dashboard-layout-critical">
body:not(.yp-icon-edit-mode):not(.yp-layout-edit-mode).yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-aside-layout-section[data-section-hidden="true"],
body:not(.yp-icon-edit-mode):not(.yp-layout-edit-mode).yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-widget-section[data-section-hidden="true"],
body:not(.yp-icon-edit-mode):not(.yp-layout-edit-mode).yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-dashboard-section[data-section-hidden="true"] {
  display: none !important;
}
body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-hub__layout.yp-studio-hub__layout--aside-empty {
  grid-template-columns: minmax(0, 1fr) !important;
}
body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-hub__layout.yp-studio-hub__layout--aside-empty > .yp-studio-hub__aside {
  display: none !important;
}
body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-hub__layout--aside-empty .yp-studio-hub__primary {
  width: 100% !important;
  max-width: 100% !important;
}
body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard[data-layout-ssr-pending="1"] .yp-studio-hub__layout {
  visibility: hidden;
}
</style>
<div
  class="yp-studio-hub yp-studio-hub--dashboard"
  data-layout-ssr-pending="1"
  data-layout-nonce="<?php echo esc_attr(wp_create_nonce('yooadmin_network_dashboard_layout')); ?>"
  data-layout-ajax="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"
  <?php if (is_array($layout)) : ?>
    data-initial-layout="<?php echo esc_attr(wp_json_encode($layout)); ?>"
  <?php endif; ?>
>
  <div class="<?php echo esc_attr($layout_class); ?>">
    <div class="yp-studio-hub__primary">
      <?php
      $section_top = $cards_dir . '/section-top-network.php';
      if ($cards_dir && is_readable($section_top)) {
          include $section_top;
      }
      ?>
      <div class="yp-studio-hub__main" data-network-layout-column="main">
        <?php
        foreach ($main_order as $section_id) {
            if ($cards_dir && function_exists('yooadmin_network_dashboard_render_section')) {
                yooadmin_network_dashboard_render_section((string) $section_id, $layout, $cards_dir, $section_context);
            }
        }
        ?>
      </div>
    </div>

    <div
      class="<?php echo esc_attr($aside_class); ?>"
      data-network-layout-column="aside"
      data-default-aside-order="<?php echo esc_attr(implode(',', $aside_order)); ?>"
      aria-label="<?php esc_attr_e('Sidebar', 'yooadmin'); ?>"
      <?php echo $collapse_aside ? ' aria-hidden="true"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    >
      <?php
      foreach ($aside_order as $section_id) {
          if ($cards_dir && function_exists('yooadmin_network_dashboard_render_section')) {
              yooadmin_network_dashboard_render_section((string) $section_id, $layout, $cards_dir, $section_context);
          }
      }
      ?>
    </div>
  </div>
</div>
<script id="yooadmin-network-dashboard-layout-ssr-apply">
(function () {
  'use strict';
  var root = document.querySelector('.yp-studio-hub--dashboard[data-layout-nonce]');
  if (!root) {
    return;
  }

  function captureFactoryCards() {
    var cards = {};
    root.querySelectorAll('.yp-dashboard-section[data-section-id]').forEach(function (section) {
      var sectionId = section.getAttribute('data-section-id');
      if (!sectionId) {
        return;
      }
      var grid =
        section.querySelector('.yp-cards-grid[data-sortable="true"]') ||
        section.querySelector('.yp-cards-grid');
      if (!grid) {
        return;
      }
      cards[sectionId] = Array.prototype.map
        .call(grid.querySelectorAll('[data-card-id]'), function (card) {
          return card.getAttribute('data-card-id') || '';
        })
        .filter(Boolean);
    });
    try {
      root.setAttribute('data-factory-cards', JSON.stringify(cards));
    } catch (e) {
      /* ignore */
    }
  }

  function reorderSections(container, orderIds) {
    if (!container || !orderIds || !orderIds.length) {
      return;
    }
    var map = Object.create(null);
    Array.prototype.slice
      .call(container.querySelectorAll(':scope > .yp-dashboard-section[data-layout-section="true"]'))
      .forEach(function (section) {
        var id = section.getAttribute('data-section-id');
        if (id) {
          map[id] = section;
        }
      });
    orderIds.forEach(function (id) {
      if (map[id]) {
        container.appendChild(map[id]);
      }
    });
  }

  function reorderCards(sectionId, cardIds) {
    if (!cardIds || !cardIds.length) {
      return;
    }
    var section = root.querySelector('[data-section-id="' + sectionId + '"]');
    if (!section) {
      return;
    }
    var grid =
      section.querySelector('.yp-cards-grid[data-sortable="true"]') ||
      section.querySelector('.yp-cards-grid');
    if (!grid) {
      return;
    }
    var map = Object.create(null);
    grid.querySelectorAll('[data-card-id]').forEach(function (card) {
      var id = card.getAttribute('data-card-id');
      if (id) {
        map[id] = card;
      }
    });
    cardIds.forEach(function (id) {
      if (map[id]) {
        var card = map[id];
        var hint = grid.querySelector('[data-layout-empty-hint]');
        var loader = grid.querySelector('[data-layout-loading]');
        if (hint && hint.parentNode === grid) {
          grid.insertBefore(card, hint);
        } else if (loader && loader.parentNode === grid) {
          grid.insertBefore(card, loader.nextSibling);
        } else {
          grid.appendChild(card);
        }
      }
    });
  }

  function finalizeCustomSectionBooting(section) {
    if (!section || !section.classList.contains('yp-studio-custom-section')) {
      return;
    }
    var grid =
      section.querySelector('.yp-cards-grid[data-sortable="true"]') ||
      section.querySelector('.yp-cards-grid');
    if (grid) {
      grid.classList.add('is-hydrated');
    }
    section.querySelectorAll('[data-layout-loading]').forEach(function (el) {
      if (el.parentNode) {
        el.parentNode.removeChild(el);
      }
    });
    section.classList.remove('yp-studio-layout-section--booting');
    section.removeAttribute('data-layout-booting');
  }

  function finalizeAllCustomSectionBooting() {
    root
      .querySelectorAll(
        '.yp-studio-custom-section.yp-studio-layout-section--booting, .yp-studio-custom-section[data-layout-booting]'
      )
      .forEach(finalizeCustomSectionBooting);
  }

  captureFactoryCards();

  var raw = root.getAttribute('data-initial-layout');
  if (raw) {
    try {
      var layout = JSON.parse(raw);
      var layoutEl = root.querySelector('.yp-studio-hub__layout');
      var mainCol = root.querySelector('.yp-studio-hub__main');
      var asideCol = root.querySelector('.yp-studio-hub__aside');
      if (mainCol && Array.isArray(layout.mainOrder) && layout.mainOrder.length) {
        reorderSections(mainCol, layout.mainOrder);
      }
      if (asideCol && Array.isArray(layout.asideOrder) && layout.asideOrder.length) {
        reorderSections(asideCol, layout.asideOrder);
      }
      if (layout && layout.cards && typeof layout.cards === 'object') {
        Object.keys(layout.cards).forEach(function (sectionId) {
          var ids = layout.cards[sectionId];
          if (Array.isArray(ids)) {
            reorderCards(sectionId, ids);
          }
        });
      }
      if (layoutEl && layout && Array.isArray(layout.hiddenSections) && layout.hiddenSections.length) {
        layout.hiddenSections.forEach(function (id) {
          if (id === 'network-workspace') {
            return;
          }
          var section = root.querySelector('[data-section-id="' + id + '"]');
          if (section) {
            section.setAttribute('data-section-hidden', 'true');
            section.classList.add('is-dashboard-section-hidden');
          }
        });
        var asideVisible = (layout.asideOrder || []).some(function (id) {
          return layout.hiddenSections.indexOf(id) === -1;
        });
        if (!asideVisible && layoutEl) {
          layoutEl.classList.add('yp-studio-hub__layout--aside-empty');
        }
      }
    } catch (e) {
      /* ignore */
    }
  }
  finalizeAllCustomSectionBooting();
  root.removeAttribute('data-layout-ssr-pending');
  root.setAttribute('data-layout-ssr-applied', '1');
})();
</script>
<?php
$popup_tpl = defined('YOOADMIN_PLUGIN_FILE')
    ? plugin_dir_path(YOOADMIN_PLUGIN_FILE) . 'templates/yoopixel/admin/popup.php'
    : '';
if ($popup_tpl && is_readable($popup_tpl) && empty($GLOBALS['yooadmin_popup_printed'])) {
    $GLOBALS['yooadmin_popup_printed'] = true;
    include $popup_tpl;
}
?>
<script id="yooadmin-network-dashboard-popup-boot">
(function () {
  'use strict';
  function boot() {
    var popup = document.getElementById('yp-popup');
    if (!popup) {
      return;
    }
    popup.classList.add('yp-popup--studio-hub');
    if (popup.parentNode !== document.body) {
      document.body.appendChild(popup);
    }
    popup.classList.add('yp-popup--portaled');
  }
  if (document.body) {
    boot();
  } else {
    document.addEventListener('DOMContentLoaded', boot);
  }
})();
</script>
<?php
