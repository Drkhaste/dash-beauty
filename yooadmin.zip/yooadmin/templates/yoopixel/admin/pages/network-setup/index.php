<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$context = yooadmin_network_setup_get_context();
$tabs    = yooadmin_network_setup_tabs();
$tab     = 'overview';
// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only tab routing (display/UI only).
if (isset($_GET['tab'])) {
    $maybe = sanitize_key(wp_unslash((string) $_GET['tab']));
    if (isset($tabs[ $maybe ])) {
        $tab = $maybe;
    }
}
// phpcs:enable WordPress.Security.NonceVerification.Recommended

$allow_line = "define( 'WP_ALLOW_MULTISITE', true );";
?>
<div class="wrap yoo-upload-wrap yoo-network-classic-wrap yoo-network-setup-wrap" data-page="network-setup">
  <div class="yoo-upload-header yoo-network-classic-header">
    <div class="yoo-upload-header-content">
      <h1 class="yoo-upload-title">
        <span class="dashicons dashicons-admin-multisite yoo-upload-title-dashicon" aria-hidden="true"></span>
        <?php esc_html_e('Network Setup', 'yooadmin'); ?>
      </h1>
      <p class="yoo-upload-subtitle"><?php esc_html_e('Enable multisite with guided snippets, copy buttons, and YOOAdmin focus.', 'yooadmin'); ?></p>
    </div>
  </div>

  <div class="yooadmin-settings-wrap yoo-network-classic-tabs-shell">
    <div class="yp-tabs" data-yoo-network-classic-tabs>
      <div class="yp-tab-nav" role="tablist" aria-label="<?php esc_attr_e('Network setup sections', 'yooadmin'); ?>">
        <?php foreach ($tabs as $tab_id => $tab_meta) :
            $active = $tab === $tab_id;
            ?>
          <button
            type="button"
            class="yp-tab<?php echo $active ? ' is-active' : ''; ?>"
            role="tab"
            aria-selected="<?php echo $active ? 'true' : 'false'; ?>"
            data-tab="<?php echo esc_attr($tab_id); ?>"
          ><?php echo esc_html((string) $tab_meta['label']); ?></button>
        <?php endforeach; ?>
      </div>

      <div class="yp-tab-panels">
        <section class="yp-tab-panel<?php echo $tab === 'overview' ? ' is-active' : ''; ?>" data-panel="overview" role="tabpanel">
          <div class="yp-tab-intro">
            <span class="dashicons dashicons-info-outline yp-tab-intro-icon" aria-hidden="true"></span>
            <p class="yp-tab-intro__text"><?php echo esc_html($tabs['overview']['desc']); ?></p>
          </div>

          <ol class="yoo-network-classic-steps">
            <li>
              <strong><?php esc_html_e('Step 1 — Allow multisite', 'yooadmin'); ?></strong>
              <span class="yoo-network-classic-tip" tabindex="0" data-yoo-tip="<?php esc_attr_e('Add this line to wp-config.php before the stop-editing comment, then reload this page.', 'yooadmin'); ?>">?</span>
              <div class="yoo-network-classic-code-block">
                <pre class="yoo-network-classic-code" id="yoo-network-setup-allow"><?php echo esc_html($allow_line); ?></pre>
                <button type="button" class="yoo-network-classic-copy" data-copy-target="yoo-network-setup-allow" aria-label="<?php esc_attr_e('Copy WP_ALLOW_MULTISITE line', 'yooadmin'); ?>">
                  <span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
                </button>
              </div>
            </li>
            <li>
              <strong><?php esc_html_e('Step 2 — Run the network installer', 'yooadmin'); ?></strong>
              <p><?php esc_html_e('After saving wp-config.php, open Tools → Network Setup on the main site to run the WordPress network installer.', 'yooadmin'); ?></p>
            </li>
            <li>
              <strong><?php esc_html_e('Step 3 — Paste generated rules', 'yooadmin'); ?></strong>
              <p><?php esc_html_e('Use the wp-config.php and .htaccess tabs here to copy the final snippets once WordPress generates them.', 'yooadmin'); ?></p>
            </li>
          </ol>

          <?php if (!$context['allow_multisite']) : ?>
            <div class="yoo-network-classic-notice yoo-network-classic-notice--warning">
              <?php esc_html_e('WP_ALLOW_MULTISITE is not enabled yet. Complete step 1 first.', 'yooadmin'); ?>
            </div>
          <?php elseif ($context['multisite_enabled']) : ?>
            <div class="yoo-network-classic-notice yoo-network-classic-notice--success">
              <?php esc_html_e('Multisite constants are active. Keep these snippets for future reference.', 'yooadmin'); ?>
            </div>
          <?php endif; ?>
        </section>

        <section class="yp-tab-panel<?php echo $tab === 'wp-config' ? ' is-active' : ''; ?>" data-panel="wp-config" role="tabpanel">
          <div class="yp-tab-intro">
            <span class="dashicons dashicons-editor-code yp-tab-intro-icon" aria-hidden="true"></span>
            <p class="yp-tab-intro__text"><?php echo esc_html($tabs['wp-config']['desc']); ?></p>
          </div>
          <p class="yoo-network-classic-path">
            <?php
            printf(
                /* translators: %s: wp-config.php directory path. */
                esc_html__('Target file: %s', 'yooadmin'),
                '<code>' . esc_html((string) $context['wp_config_path']) . 'wp-config.php</code>'
            );
            ?>
          </p>
          <div class="yoo-network-classic-code-block">
            <pre class="yoo-network-classic-code" id="yoo-network-setup-wpconfig"><?php echo esc_html((string) $context['wp_config_rules']); ?></pre>
            <button type="button" class="yoo-network-classic-copy" data-copy-target="yoo-network-setup-wpconfig" aria-label="<?php esc_attr_e('Copy wp-config.php rules', 'yooadmin'); ?>">
              <span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
            </button>
          </div>
        </section>

        <section class="yp-tab-panel<?php echo $tab === 'htaccess' ? ' is-active' : ''; ?>" data-panel="htaccess" role="tabpanel">
          <div class="yp-tab-intro">
            <span class="dashicons dashicons-media-code yp-tab-intro-icon" aria-hidden="true"></span>
            <p class="yp-tab-intro__text"><?php echo esc_html($tabs['htaccess']['desc']); ?></p>
          </div>
          <div class="yoo-network-classic-code-block">
            <pre class="yoo-network-classic-code" id="yoo-network-setup-htaccess"><?php echo esc_html((string) $context['htaccess_rules']); ?></pre>
            <button type="button" class="yoo-network-classic-copy" data-copy-target="yoo-network-setup-htaccess" aria-label="<?php esc_attr_e('Copy .htaccess rules', 'yooadmin'); ?>">
              <span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
            </button>
          </div>
        </section>

        <section class="yp-tab-panel<?php echo $tab === 'help' ? ' is-active' : ''; ?>" data-panel="help" role="tabpanel">
          <div class="yp-tab-intro">
            <span class="dashicons dashicons-sos yp-tab-intro-icon" aria-hidden="true"></span>
            <p class="yp-tab-intro__text"><?php echo esc_html($tabs['help']['desc']); ?></p>
          </div>
          <ul class="yoo-network-classic-help-list">
            <li><?php esc_html_e('Back up wp-config.php and .htaccess before pasting anything.', 'yooadmin'); ?></li>
            <li><?php esc_html_e('Turn off Focus Mode in YOOAdmin settings to use the default WordPress Network Setup screen.', 'yooadmin'); ?></li>
            <li>
              <a href="<?php echo esc_url('https://developer.wordpress.org/advanced-administration/multisite/create-network/'); ?>" target="_blank" rel="noopener noreferrer">
                <?php esc_html_e('WordPress multisite documentation', 'yooadmin'); ?>
              </a>
            </li>
          </ul>
        </section>
      </div>
    </div>
  </div>
</div>
