<?php
/**
 * YOOAdmin - Comments index template
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

$list_url   = admin_url('admin.php?page=yooadmin-comments');
$has_status = ($url_status !== '');
$has_search = ($search !== '');
?>

<div class="wrap yooadmin-comments-page yooadmin-posts-page">
    <section class="yoo-posts-hero">
        <div class="yoo-posts-hero__body">
            <div class="yoo-posts-hero__top-row">
                <span class="yoo-posts-hero__eyebrow"><?php esc_html_e('Discussion · Comments', 'yooadmin'); ?></span>
                <div class="yoo-posts-hero__actions">
                    <?php if ($can_manage_options) : ?>
                    <label
                        class="yoo-comments-hero-status yp-yoo-btn yp-yoo-btn--soft<?php echo $comments_enabled ? ' is-on' : ' is-off'; ?>"
                        id="yoo-comments-hero-status"
                        for="yoo-comments-hero-enabled"
                        data-enabled="<?php echo $comments_enabled ? '1' : '0'; ?>"
                    >
                        <span class="dashicons dashicons-admin-comments" aria-hidden="true"></span>
                        <span class="yoo-comments-hero-status__label"><?php esc_html_e('Site comments', 'yooadmin'); ?></span>
                        <span class="yoo-comments-hero-status__state" data-status-label>
                            <?php echo $comments_enabled ? esc_html__('Enabled', 'yooadmin') : esc_html__('Disabled', 'yooadmin'); ?>
                        </span>
                        <input
                            type="checkbox"
                            id="yoo-comments-hero-enabled"
                            class="yoo-comments-hero-toggle__input"
                            role="switch"
                            <?php checked($comments_enabled); ?>
                            aria-label="<?php esc_attr_e('Allow comments on the site', 'yooadmin'); ?>"
                        >
                        <span class="yoo-comments-hero-toggle__track" aria-hidden="true"></span>
                    </label>
                    <?php endif; ?>
                    <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft" id="yoo-comments-screen-options-btn">
                        <span class="dashicons dashicons-screenoptions" aria-hidden="true"></span>
                        <span><?php esc_html_e('Screen Options', 'yooadmin'); ?></span>
                    </button>
                    <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft yoo-comments-delete-all-btn" id="yoo-comments-delete-all" <?php disabled($counts['all'] === 0); ?>>
                        <span class="dashicons dashicons-trash" aria-hidden="true"></span>
                        <span><?php esc_html_e('Delete all comments', 'yooadmin'); ?></span>
                    </button>
                </div>
            </div>
            <div class="yoo-posts-hero__title-row">
                <h1>
                    <span class="dashicons dashicons-admin-comments"></span>
                    <?php esc_html_e('Comments', 'yooadmin'); ?>
                </h1>
            </div>
            <button type="button" class="yoo-posts-metrics-toggle" aria-expanded="false">
                <span class="dashicons dashicons-arrow-down-alt"></span>
                <span><?php esc_html_e('Show Statistics', 'yooadmin'); ?></span>
            </button>
        </div>

        <div class="yoo-posts-hero__metrics">
            <article class="yoo-posts-metric">
                <div class="yoo-posts-metric__icon"><span class="dashicons dashicons-admin-comments"></span></div>
                <div class="yoo-posts-metric__content">
                    <strong class="yoo-posts-metric__value" data-count="all"><?php echo esc_html(number_format_i18n($counts['all'])); ?></strong>
                    <span class="yoo-posts-metric__label"><?php esc_html_e('Total Comments', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-posts-metric">
                <div class="yoo-posts-metric__icon"><span class="dashicons dashicons-warning"></span></div>
                <div class="yoo-posts-metric__content">
                    <strong class="yoo-posts-metric__value" data-count="moderated"><?php echo esc_html(number_format_i18n($counts['moderated'])); ?></strong>
                    <span class="yoo-posts-metric__label"><?php esc_html_e('Pending', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-posts-metric">
                <div class="yoo-posts-metric__icon"><span class="dashicons dashicons-yes"></span></div>
                <div class="yoo-posts-metric__content">
                    <strong class="yoo-posts-metric__value" data-count="approved"><?php echo esc_html(number_format_i18n($counts['approved'])); ?></strong>
                    <span class="yoo-posts-metric__label"><?php esc_html_e('Approved', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-posts-metric">
                <div class="yoo-posts-metric__icon"><span class="dashicons dashicons-flag"></span></div>
                <div class="yoo-posts-metric__content">
                    <strong class="yoo-posts-metric__value" data-count="spam"><?php echo esc_html(number_format_i18n($counts['spam'])); ?></strong>
                    <span class="yoo-posts-metric__label"><?php esc_html_e('Spam', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-posts-metric">
                <div class="yoo-posts-metric__icon"><span class="dashicons dashicons-trash"></span></div>
                <div class="yoo-posts-metric__content">
                    <strong class="yoo-posts-metric__value" data-count="trash"><?php echo esc_html(number_format_i18n($counts['trash'])); ?></strong>
                    <span class="yoo-posts-metric__label"><?php esc_html_e('Trash', 'yooadmin'); ?></span>
                </div>
            </article>
        </div>
    </section>

    <section class="yoo-posts-content-section">
        <div class="yoo-posts-toolbar">
            <div class="yoo-posts-filters">
                <button type="button" class="yoo-filter-chip <?php echo !$has_status ? 'is-active' : ''; ?>" data-status="">
                    <?php esc_html_e('All', 'yooadmin'); ?>
                    <span class="yoo-filter-count" data-count="all"><?php echo esc_html(number_format_i18n($counts['all'])); ?></span>
                </button>
                <button type="button" class="yoo-filter-chip <?php echo $url_status === 'moderated' ? 'is-active' : ''; ?>" data-status="moderated">
                    <?php esc_html_e('Pending', 'yooadmin'); ?>
                    <span class="yoo-filter-count" data-count="moderated"><?php echo esc_html(number_format_i18n($counts['moderated'])); ?></span>
                </button>
                <button type="button" class="yoo-filter-chip <?php echo $url_status === 'approved' ? 'is-active' : ''; ?>" data-status="approved">
                    <?php esc_html_e('Approved', 'yooadmin'); ?>
                    <span class="yoo-filter-count" data-count="approved"><?php echo esc_html(number_format_i18n($counts['approved'])); ?></span>
                </button>
                <button type="button" class="yoo-filter-chip <?php echo $url_status === 'spam' ? 'is-active' : ''; ?>" data-status="spam">
                    <?php esc_html_e('Spam', 'yooadmin'); ?>
                    <span class="yoo-filter-count" data-count="spam"><?php echo esc_html(number_format_i18n($counts['spam'])); ?></span>
                </button>
                <button type="button" class="yoo-filter-chip <?php echo $url_status === 'trash' ? 'is-active' : ''; ?>" data-status="trash">
                    <?php esc_html_e('Trash', 'yooadmin'); ?>
                    <span class="yoo-filter-count" data-count="trash"><?php echo esc_html(number_format_i18n($counts['trash'])); ?></span>
                </button>
            </div>
            <div class="yoo-posts-search-wrapper yoo-comments-toolbar-search">
                <span class="dashicons dashicons-search"></span>
                <input type="search" id="yoo-comments-search-input" class="yoo-posts-search-input" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search comments...', 'yooadmin'); ?>">
            </div>
        </div>

        <div class="yoo-bulk-actions-bar">
            <div class="yoo-bulk-actions-left">
                <input type="checkbox" id="yoo-comments-select-all" class="yoo-checkbox">
                <label for="yoo-comments-select-all"><?php esc_html_e('Select All', 'yooadmin'); ?></label>
                <span class="yoo-selected-count">0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
            </div>
            <div class="yoo-bulk-actions-right">
                <select id="yoo-comments-bulk-select" class="yoo-bulk-select">
                    <option value=""><?php esc_html_e('Bulk Actions', 'yooadmin'); ?></option>
                    <option value="approve"><?php esc_html_e('Approve', 'yooadmin'); ?></option>
                    <option value="unapprove"><?php esc_html_e('Unapprove', 'yooadmin'); ?></option>
                    <option value="spam"><?php esc_html_e('Mark as spam', 'yooadmin'); ?></option>
                    <option value="unspam"><?php esc_html_e('Not spam', 'yooadmin'); ?></option>
                    <option value="trash"><?php esc_html_e('Move to Trash', 'yooadmin'); ?></option>
                    <option value="untrash"><?php esc_html_e('Restore', 'yooadmin'); ?></option>
                    <option value="delete"><?php esc_html_e('Delete Permanently', 'yooadmin'); ?></option>
                </select>
                <button type="button" id="yoo-comments-bulk-apply" class="yp-yoo-btn yp-yoo-btn--primary" disabled>
                    <?php esc_html_e('Apply', 'yooadmin'); ?>
                </button>
            </div>
        </div>

        <form id="comments-form" class="screen-reader-text" aria-hidden="true">
            <input type="hidden" name="comment_status" id="yoo-comments-listing-status" value="<?php echo esc_attr($url_status); ?>">
        </form>

        <div id="yoo-comments-content" class="yoo-view-feed">
            <div class="yoo-comments-feed<?php echo ($view_mode === 'excerpt') ? ' yoo-comments-view-excerpt' : ' yoo-comments-view-list'; ?>">
                <div id="the-comment-list" class="yoo-comments-feed__list" role="list">
                    <?php $this->render_table_body($result['comments'], $url_status); ?>
                </div>
            </div>

            <div id="yoo-comments-pagination-wrap">
                <?php $this->render_pagination($paged, $result['total_pages'], $url_status, $search); ?>
            </div>
        </div>

        <div id="ajax-response"></div>
        <?php
        if (function_exists('wp_comment_reply')) {
            wp_comment_reply('-1', true, 'detail', false);
        }
        ?>
    </section>
</div>
