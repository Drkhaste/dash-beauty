<?php
/**
 * Network YOOUpdate Center — reuses the single-site update center UI.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$uc_template = defined('YOOADMIN_PANEL_DIR')
    ? YOOADMIN_PANEL_DIR . 'templates/yoopixel/admin/pages/update-center/index.php'
    : '';

if ($uc_template && is_readable($uc_template)) {
    include $uc_template;
    return;
}

echo '<div class="wrap"><h1>' . esc_html__('YOOUpdate Center', 'yooadmin') . '</h1><p>' . esc_html__('Template missing.', 'yooadmin') . '</p></div>';
