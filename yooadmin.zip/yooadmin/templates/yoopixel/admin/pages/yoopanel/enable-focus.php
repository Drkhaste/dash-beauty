<?php
/**
 * YOOAdmin - Enable Focus Mode page template
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
// Template file. Variables are scoped to the loading function and not global.

// Enqueue assets (fonts loaded from menu.php admin_enqueue_scripts)
$can_manage_focus_policy = function_exists('yooadmin_user_can_manage_focus_policy')
    && yooadmin_user_can_manage_focus_policy();

$base_url = plugin_dir_url(yooadmin_base_file());
$base_dir = plugin_dir_path(yooadmin_base_file());

wp_enqueue_style('yooadmin-focus-alerts', plugin_dir_url(yooadmin_base_file()) . 'assets/css/admin/focus-mode-alerts.css', [], YOOADMIN_VERSION);
wp_enqueue_script('yooadmin-enable-focus', plugin_dir_url(yooadmin_base_file()) . 'assets/js/admin/enable-focus.js', [], YOOADMIN_VERSION, false);
wp_enqueue_script('yooadmin-focus-alerts', plugin_dir_url(yooadmin_base_file()) . 'assets/js/admin/focus-mode-alerts.js', [], YOOADMIN_VERSION, true);
wp_localize_script('yooadmin-focus-alerts', 'yooadmFocusAlerts', [
    'focusModeDisabled'        => __('Focus Mode Disabled', 'yooadmin'),
    'focusDisabledMessage'     => __('Focus Mode is disabled by the administrator. To enable it for yourself only, the policy must be set to "Auto" to allow users to choose their preference.', 'yooadmin'),
    'focusDisabledMessageUser' => __('Focus Mode is turned off for all users by your site administrator. You cannot enable it yourself. Please contact your administrator if you need access.', 'yooadmin'),
    'cancel'                   => __('Cancel', 'yooadmin'),
    'enableAutoMode'           => __('Enable Auto Mode', 'yooadmin'),
    'focusModePolicy'          => __('Focus Mode Policy', 'yooadmin'),
    'focusModePolicyUser'      => __('Focus Mode Is Locked', 'yooadmin'),
    'policyOnMessage'          => __('Focus Mode policy is currently set to <strong>"Force On"</strong>. To allow users to control Focus Mode, change the policy to <strong>"Auto"</strong> in settings.', 'yooadmin'),
    'policyOnMessageUser'      => __('Your site administrator requires Focus Mode for all users. You cannot turn it off while this policy is active. Please contact your administrator if you need the classic WordPress admin.', 'yooadmin'),
    'policyOffMessage'         => __('Focus Mode policy is currently set to <strong>"Force Off"</strong>. To enable Focus Mode, change the policy to <strong>"Auto"</strong> in settings.', 'yooadmin'),
    'policyOffMessageUser'     => __('Focus Mode is turned off for all users by your site administrator. You cannot enable it yourself. Please contact your administrator if you need access.', 'yooadmin'),
    'close'                    => __('Close', 'yooadmin'),
    'focusModeSettings'        => __('Focus Mode Settings', 'yooadmin'),
    'canManagePolicy'          => $can_manage_focus_policy,
]);
wp_enqueue_script('yooadmin-enable-focus-modal', plugin_dir_url(yooadmin_base_file()) . 'assets/js/admin/enable-focus-modal.js', ['jquery'], YOOADMIN_VERSION, true);

// Handle form submission
$form_submitted = false;
$show_policy_error = false;

if (isset($_POST['enable_focus']) && check_admin_referer('yooadmin_enable_focus', 'yooadmin_focus_nonce')) {
    $enable_scope = isset($_POST['enable_scope']) ? sanitize_text_field(wp_unslash($_POST['enable_scope'])) : 'user';
    $current_policy = get_option('yooadmin_focus_policy', 'auto');

    if (!$can_manage_focus_policy) {
        $enable_scope = 'user';
    }

    // Check if trying to enable for user only when policy is "off"
    if ($enable_scope === 'user' && $current_policy === 'off') {
        $show_policy_error = true;
    }
    else {
        if ($can_manage_focus_policy && $enable_scope === 'all') {
            update_option('yooadmin_focus_policy', 'on');
        }
        elseif ($can_manage_focus_policy && $enable_scope === 'auto') {
            update_option('yooadmin_focus_policy', 'auto');
        }

        if (function_exists('yooadmin_save_user_focus_preference')) {
            yooadmin_save_user_focus_preference('on');
        } elseif (!headers_sent()) {
            setcookie('yoo_focus', 'on', time() + (365 * DAY_IN_SECONDS), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        }

        $form_submitted = true;
    }
}

// Pass redirect URL to JS
if ($form_submitted) {
    $redirect_url = function_exists('yooadmin_focus_home_url')
        ? yooadmin_focus_home_url()
        : admin_url('admin.php?page=yooadmin-dashboard&yoo=on');
    wp_localize_script('yooadmin-enable-focus', 'yooadmFocusRedirect', [
        'url' => $redirect_url,
    ]);

    wp_add_inline_script(
        'yooadmin-enable-focus',
        "(function(){function boot(){if(!document.body){return;}document.body.classList.add('yoo-focus-page-transitioning');var o=document.getElementById('yoo-focus-page-transition');if(o){o.classList.add('is-visible');o.removeAttribute('hidden');}}if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',boot);}else{boot();}})();",
        'before'
    );
}

// Promo image for page card + modals (welcome modal artwork).
$welcome_modal_image = function_exists('yooadmin_focus_modal_promo_image_url')
    ? yooadmin_focus_modal_promo_image_url()
    : $base_url . 'assets/images/welcome-popup-promo.svg';
?>


<div class="wrap yooadmin-enable-focus-page">

    <div class="yoo-focus-card yoo-focus-split-card">
        <div class="ywp-layout">
            <div class="ywp-copy">
                <p class="ywp-eyebrow"><?php esc_html_e('YOOAdmin', 'yooadmin'); ?></p>
                <h1 class="ywp-title yoo-focus-page-title"><?php esc_html_e('Return to YOOAdmin Workspace', 'yooadmin'); ?></h1>
                <p class="ywp-lead"><?php esc_html_e('Restore the streamlined admin experience.', 'yooadmin'); ?></p>
                <p class="ywp-lead yoo-focus-page-sublead"><?php esc_html_e('Switch back to your modern workspace and productivity tools.', 'yooadmin'); ?></p>

                <div class="ywp-actions yoo-focus-actions">
                    <button type="button" class="yp-yoo-btn yp-yoo-btn--primary" id="yoo-show-enable-modal">
                        <?php esc_html_e('Return to YOOAdmin Workspace', 'yooadmin'); ?>
                    </button>
                    <a href="#" id="yoo-why-focus-link" class="yoo-focus-why-link">
                        <span class="yoo-focus-why-link__icon dashicons dashicons-info-outline" aria-hidden="true"></span>
                        <?php esc_html_e('Why Focus Mode?', 'yooadmin'); ?>
                    </a>
                </div>
            </div>

            <div class="ywp-visual" aria-hidden="true">
                <img
                    class="ywp-image"
                    src="<?php echo esc_url($welcome_modal_image); ?>"
                    alt=""
                    width="320"
                    height="280"
                    loading="lazy"
                    decoding="async"
                />
            </div>
        </div>
    </div>
</div>

<!-- Why Focus Mode Popup -->
<div id="yoo-why-focus-modal" class="ywp-overlay yoo-focus-split-modal" hidden aria-hidden="true">
    <div class="ywp-dialog" role="dialog" aria-modal="true" aria-labelledby="yoo-why-focus-title">
        <div class="ywp-layout">
            <div class="ywp-copy">
                <p class="ywp-eyebrow"><?php esc_html_e('YOOAdmin', 'yooadmin'); ?></p>
                <h2 id="yoo-why-focus-title" class="ywp-title"><?php esc_html_e('Why Focus Mode?', 'yooadmin'); ?></h2>
                <p class="ywp-lead"><?php esc_html_e('Your admin is your workspace, not a billboard. We don\'t believe in ads or upgrade nags, even our own. If you decide to upgrade, it should be because you genuinely want more features, not because we kept bugging you. That\'s why our free version is built to deliver a complete, five-star experience.', 'yooadmin'); ?></p>
                <div class="ywp-actions">
                    <button type="button" class="yp-yoo-btn yp-yoo-btn--primary yoo-focus-modal-dismiss">
                        <?php esc_html_e('Close', 'yooadmin'); ?>
                    </button>
                </div>
            </div>
            <div class="ywp-visual" aria-hidden="true">
                <div class="ywp-visual-controls">
                    <button type="button" class="ywp-close yoo-focus-modal-close" aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                    </button>
                </div>
                <img
                    class="ywp-image"
                    src="<?php echo esc_url($welcome_modal_image); ?>"
                    alt=""
                    width="320"
                    height="280"
                    loading="lazy"
                    decoding="async"
                />
            </div>
        </div>
    </div>
</div>

<!-- Enable Focus Mode Modal -->
<?php
if (function_exists('yooadmin_render_focus_split_modal')) {
    yooadmin_render_focus_split_modal([
        'modal_id'   => 'yoo-enable-focus-modal',
        'intent'     => 'enable',
        'context'    => 'page',
        'can_manage' => $can_manage_focus_policy,
        'promo_url'  => $welcome_modal_image,
    ]);
}
?>

<div id="yoo-focus-page-transition" class="yoo-focus-page-transition" hidden aria-hidden="true">
    <span class="yp-loading-spinner" role="status" aria-live="polite">
        <span class="yp-spinner-circle"></span>
    </span>
</div>


<?php if ($show_policy_error): ?>
<?php
    $policy_js = 'document.addEventListener("DOMContentLoaded",function(){if(window.yooadmAlerts){window.yooadmAlerts.showPolicyDisabledAlert(function(){var f=document.createElement("form");f.method="POST";f.action="";var n=document.createElement("input");n.type="hidden";n.name="yooadmin_focus_nonce";n.value="' . esc_js(wp_create_nonce('yooadmin_enable_focus')) . '";var a=document.createElement("input");a.type="hidden";a.name="enable_focus";a.value="1";var s=document.createElement("input");s.type="hidden";s.name="enable_scope";s.value="auto";f.appendChild(n);f.appendChild(a);f.appendChild(s);document.body.appendChild(f);f.submit()});}});';
    wp_add_inline_script('yooadmin-enable-focus-modal', $policy_js);
?>
<?php
endif;
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
?>
