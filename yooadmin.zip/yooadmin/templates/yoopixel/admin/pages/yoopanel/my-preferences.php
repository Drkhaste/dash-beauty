<?php
/**
 * My YOOAdmin Preferences (per-user settings)
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; foreach loop keys scoped to this view.

/** @var YOOAdmin_User_Preferences $this */
/** @var array $preferences */
/** @var string $focus_policy */
/** @var bool $focus_active */
/** @var string $dashboard_url */
/** @var array<string, string> $pref_notification_types */
/** @var array<string, string> $pref_notification_sources */
/** @var array<string, string> $pref_email_triggers */
/** @var bool $pref_show_email_section */
/** @var bool $yp_is_regular_user */
/** @var bool $yp_show_notifications_tab */
/** @var bool $yp_show_guided_tour_reset */
?>
<div class="wrap yooadmin-settings-wrap yp-my-preferences">
    <div class="yp-titlebar">
        <h1>
            <span class="dashicons dashicons-admin-users"></span>
            <?php esc_html_e('My YOOAdmin Preferences', 'yooadmin'); ?>
        </h1>
        <div class="yp-titlebar__actions">
            <button type="submit" form="yp-preferences-form" class="button button-primary yp-yoo-btn yp-yoo-btn--primary">
                <span class="dashicons dashicons-database"></span>
                <?php esc_html_e('Save Preferences', 'yooadmin'); ?>
            </button>
        </div>
    </div>

    <form id="yp-preferences-form" class="yp-preferences-form">
        <div class="yp-tabs" data-yp-tabs>
            <div class="yp-tab-nav" role="tablist">
                <button type="button" class="yp-tab is-active" role="tab" aria-selected="true" data-tab="general"><?php esc_html_e('General', 'yooadmin'); ?></button>
                <button type="button" class="yp-tab" role="tab" aria-selected="false" data-tab="focus"><?php esc_html_e('Focus Mode', 'yooadmin'); ?></button>
                <?php if ($yp_show_notifications_tab) : ?>
                <button type="button" class="yp-tab" role="tab" aria-selected="false" data-tab="notifications"><?php esc_html_e('Notifications', 'yooadmin'); ?></button>
                <?php endif; ?>
            </div>

            <div class="yp-tab-panels">
                <section class="yp-tab-panel is-active" id="tab-general" data-panel="general">
                    <div class="yp-tab-intro">
                        <span class="dashicons dashicons-media-text yp-tab-intro-icon" aria-hidden="true"></span>
                        <div class="yp-tab-intro__stack">
                            <p class="yp-tab-intro__text">
                                <?php
                                if (!empty($yp_is_regular_user)) {
                                    esc_html_e('Personal settings for your account. Open the dashboard to adjust appearance; use Focus Mode to control the YOOAdmin overlay.', 'yooadmin');
                                } else {
                                    esc_html_e('Personal settings for your account. Site-wide options remain under YOOAdmin Settings (administrators only).', 'yooadmin');
                                }
                                ?>
                            </p>
                        </div>
                    </div>

                    <div class="yp-settings-card">
                        <table class="form-table"><tbody>
                            <?php if (empty($yp_is_regular_user)) : ?>
                            <tr>
                                <th scope="row">
                                    <div class="yp-th-content">
                                        <span class="dashicons dashicons-layout yp-th-icon"></span>
                                        <span><?php esc_html_e('Dashboard layout', 'yooadmin'); ?></span>
                                    </div>
                                </th>
                                <td>
                                    <p class="description"><?php esc_html_e('Use Edit layout on your dashboard home.', 'yooadmin'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <div class="yp-th-content">
                                        <span class="dashicons dashicons-admin-links yp-th-icon"></span>
                                        <span><?php esc_html_e('Quick Actions', 'yooadmin'); ?></span>
                                    </div>
                                </th>
                                <td>
                                    <p class="description"><?php esc_html_e('Open Edit on the Quick Actions card to add your own links.', 'yooadmin'); ?></p>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <th scope="row">
                                    <div class="yp-th-content">
                                        <span class="dashicons dashicons-art yp-th-icon"></span>
                                        <span><?php esc_html_e('Appearance', 'yooadmin'); ?></span>
                                    </div>
                                </th>
                                <td>
                                    <p class="description"><?php esc_html_e('Use the appearance control in the top bar when Studio Hub is active.', 'yooadmin'); ?></p>
                                    <p class="yp-my-preferences-actions-inline">
                                        <a class="button button-secondary yp-yoo-btn" href="<?php echo esc_url($dashboard_url); ?>"><?php esc_html_e('Open dashboard', 'yooadmin'); ?></a>
                                    </p>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>

                    <?php if ($yp_show_guided_tour_reset) : ?>
                    <div class="yp-settings-card">
                        <table class="form-table"><tbody>
                            <tr>
                                <th scope="row">
                                    <div class="yp-th-content">
                                        <span class="dashicons dashicons-welcome-learn-more yp-th-icon"></span>
                                        <span><?php esc_html_e('Guided tour', 'yooadmin'); ?></span>
                                    </div>
                                </th>
                                <td>
                                    <p class="description"><?php esc_html_e('Reset your onboarding tour progress so the welcome prompt can appear again on the dashboard.', 'yooadmin'); ?></p>
                                    <p class="yp-my-preferences-actions-inline">
                                        <button
                                            type="button"
                                            class="button button-secondary yp-yoo-btn"
                                            id="yooadmin-guided-tour-reset"
                                            data-nonce="<?php echo esc_attr(wp_create_nonce('yooadmin_guided_tour')); ?>"
                                            data-toast-success="<?php echo esc_attr__('Guided tour reset. The welcome prompt can show again on your dashboard.', 'yooadmin'); ?>"
                                            data-toast-error="<?php echo esc_attr__('Could not reset the guided tour. Please try again.', 'yooadmin'); ?>"
                                        ><?php esc_html_e('Reset guided tour for my account', 'yooadmin'); ?></button>
                                    </p>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                    <?php endif; ?>
                </section>

                <section class="yp-tab-panel" id="tab-focus" data-panel="focus">
                    <div class="yp-tab-intro">
                        <span class="dashicons dashicons-visibility yp-tab-intro-icon" aria-hidden="true"></span>
                        <div class="yp-tab-intro__stack">
                            <p class="yp-tab-intro__text"><?php esc_html_e('Choose whether you want the YOOAdmin interface overlay on admin pages.', 'yooadmin'); ?></p>
                        </div>
                    </div>

                    <div class="yp-settings-card">
                        <table class="form-table"><tbody>
                            <tr>
                                <th scope="row">
                                    <div class="yp-th-content">
                                        <span class="dashicons dashicons-visibility yp-th-icon"></span>
                                        <span><?php esc_html_e('Focus Mode', 'yooadmin'); ?></span>
                                    </div>
                                </th>
                                <td>
                                    <?php if ($focus_policy === 'auto') : ?>
                                        <div class="yp-toggle-container">
                                            <label class="yp-toggle-switch">
                                                <input type="checkbox" id="yp-toggle-clean-view" class="yps-focus-input" <?php checked($focus_active); ?>>
                                                <span class="yp-toggle-slider"></span>
                                            </label>
                                            <div class="yp-toggle-label-wrapper">
                                                <label for="yp-toggle-clean-view" class="yp-toggle-label"><?php esc_html_e('Enable YOOAdmin overlay on admin pages', 'yooadmin'); ?></label>
                                            </div>
                                        </div>
                                    <?php elseif ($focus_policy === 'on') : ?>
                                        <p class="description"><?php esc_html_e('Focus Mode is enabled for all users by the site administrator. Your personal toggle is not available while this policy is active.', 'yooadmin'); ?></p>
                                    <?php else : ?>
                                        <p class="description"><?php esc_html_e('Focus Mode is disabled for all users by the site administrator.', 'yooadmin'); ?></p>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </section>

                <?php if ($yp_show_notifications_tab) : ?>
                <section class="yp-tab-panel" id="tab-notifications" data-panel="notifications">
                    <div class="yp-tab-intro">
                        <span class="dashicons dashicons-bell yp-tab-intro-icon" aria-hidden="true"></span>
                        <div class="yp-tab-intro__stack">
                            <p class="yp-tab-intro__text"><?php esc_html_e('Choose which notifications you receive and how they appear.', 'yooadmin'); ?></p>
                        </div>
                    </div>

                    <div class="yp-notifications-split">
                        <div class="yp-notifications-col">
                            <?php if ($pref_notification_types !== []) : ?>
                            <h3><?php esc_html_e('Notification Types', 'yooadmin'); ?></h3>
                            <p class="description"><?php esc_html_e('Choose which types of notifications you want to receive.', 'yooadmin'); ?></p>
                            <div class="yp-settings-card">
                                <table class="form-table"><tbody>
                                    <?php foreach ($pref_notification_types as $type => $label) : ?>
                                        <tr>
                                            <th scope="row">
                                                <div class="yp-th-content">
                                                    <span class="dashicons dashicons-bell yp-th-icon"></span>
                                                    <span><?php echo esc_html($label); ?></span>
                                                </div>
                                            </th>
                                            <td>
                                                <?php
                                                yooadmin_my_preferences_toggle(
                                                    'notification_types[' . $type . ']',
                                                    $label,
                                                    isset($preferences['notification_types'][$type]) && $preferences['notification_types'][$type],
                                                    'pref-notif-type-' . sanitize_key($type)
                                                );
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody></table>
                            </div>
                            <?php endif; ?>

                            <?php if ($pref_notification_sources !== []) : ?>
                            <h3><?php esc_html_e('Notification Sources', 'yooadmin'); ?></h3>
                            <p class="description"><?php esc_html_e('Choose which sources can send you notifications.', 'yooadmin'); ?></p>
                            <div class="yp-settings-card">
                                <table class="form-table"><tbody>
                                    <?php foreach ($pref_notification_sources as $source => $label) : ?>
                                        <tr>
                                            <th scope="row">
                                                <div class="yp-th-content">
                                                    <span class="dashicons dashicons-admin-plugins yp-th-icon"></span>
                                                    <span><?php echo esc_html($label); ?></span>
                                                </div>
                                            </th>
                                            <td>
                                                <?php
                                                yooadmin_my_preferences_toggle(
                                                    'notification_sources[' . $source . ']',
                                                    $label,
                                                    isset($preferences['notification_sources'][$source]) && $preferences['notification_sources'][$source],
                                                    'pref-notif-source-' . sanitize_key($source)
                                                );
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody></table>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="yp-notifications-col">
                            <h3><?php esc_html_e('Priority Filter', 'yooadmin'); ?></h3>
                            <p class="description"><?php esc_html_e('Filter notifications by priority level.', 'yooadmin'); ?></p>
                            <div class="yp-settings-card">
                                <table class="form-table"><tbody>
                                    <tr>
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-filter yp-th-icon"></span>
                                                <span><?php esc_html_e('Priority Filter', 'yooadmin'); ?></span>
                                            </div>
                                        </th>
                                        <td>
                                            <fieldset style="margin: 0; padding: 0; border: 0;">
                                                <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px; padding: 8px 0;">
                                                    <input type="radio" name="priority_filter" id="pref-priority-all" value="all"
                                                           <?php checked($preferences['priority_filter'] ?? 'all', 'all'); ?> style="margin: 0;" />
                                                    <span><?php esc_html_e('Show all notifications', 'yooadmin'); ?></span>
                                                </label>
                                                <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px; padding: 8px 0;">
                                                    <input type="radio" name="priority_filter" id="pref-priority-high" value="high_only"
                                                           <?php checked($preferences['priority_filter'] ?? 'all', 'high_only'); ?> style="margin: 0;" />
                                                    <span><?php esc_html_e('Show high and critical priority only', 'yooadmin'); ?></span>
                                                </label>
                                                <label style="display: flex; align-items: center; gap: 8px; padding: 8px 0;">
                                                    <input type="radio" name="priority_filter" id="pref-priority-critical" value="critical_only"
                                                           <?php checked($preferences['priority_filter'] ?? 'all', 'critical_only'); ?> style="margin: 0;" />
                                                    <span><?php esc_html_e('Show critical priority only', 'yooadmin'); ?></span>
                                                </label>
                                            </fieldset>
                                        </td>
                                    </tr>
                                </tbody></table>
                            </div>

                            <h3><?php esc_html_e('Display Options', 'yooadmin'); ?></h3>
                            <p class="description"><?php esc_html_e('Customize how notifications are displayed.', 'yooadmin'); ?></p>
                            <div class="yp-settings-card">
                                <table class="form-table"><tbody>
                                    <tr>
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-awards yp-th-icon"></span>
                                                <span><?php esc_html_e('Show notification badge', 'yooadmin'); ?></span>
                                            </div>
                                        </th>
                                        <td>
                                            <?php
                                            yooadmin_my_preferences_toggle(
                                                'display_options[show_badge]',
                                                __('Show notification badge', 'yooadmin'),
                                                isset($preferences['display_options']['show_badge']) && $preferences['display_options']['show_badge'],
                                                'pref-display-show-badge'
                                            );
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-desktop yp-th-icon"></span>
                                                <span><?php esc_html_e('Show desktop notifications', 'yooadmin'); ?></span>
                                            </div>
                                        </th>
                                        <td>
                                            <?php
                                            yooadmin_my_preferences_toggle(
                                                'display_options[show_desktop]',
                                                __('Show desktop notifications', 'yooadmin'),
                                                isset($preferences['display_options']['show_desktop']) && $preferences['display_options']['show_desktop'],
                                                'pref-display-show-desktop'
                                            );
                                            ?>
                                            <p class="description"><?php esc_html_e('Show a browser notification when new alerts arrive while this admin tab is in the background.', 'yooadmin'); ?></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-bell yp-th-icon"></span>
                                                <span><?php esc_html_e('Play notification sounds', 'yooadmin'); ?></span>
                                            </div>
                                        </th>
                                        <td>
                                            <?php
                                            yooadmin_my_preferences_toggle(
                                                'display_options[show_sounds]',
                                                __('Play notification sounds', 'yooadmin'),
                                                isset($preferences['display_options']['show_sounds']) && $preferences['display_options']['show_sounds'],
                                                'pref-display-show-sounds'
                                            );
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-update yp-th-icon"></span>
                                                <span><?php esc_html_e('Auto-refresh notifications', 'yooadmin'); ?></span>
                                            </div>
                                        </th>
                                        <td>
                                            <?php
                                            yooadmin_my_preferences_toggle(
                                                'display_options[auto_refresh]',
                                                __('Auto-refresh notifications', 'yooadmin'),
                                                isset($preferences['display_options']['auto_refresh']) && $preferences['display_options']['auto_refresh'],
                                                'pref-display-auto-refresh'
                                            );
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-clock yp-th-icon"></span>
                                                <label for="refresh_interval"><?php esc_html_e('Refresh interval', 'yooadmin'); ?></label>
                                            </div>
                                        </th>
                                        <td>
                                            <input type="number" id="refresh_interval" name="display_options[refresh_interval]"
                                                   value="<?php echo esc_attr($preferences['display_options']['refresh_interval'] ?? 30); ?>"
                                                   min="10" max="300" step="10" class="small-text">
                                            <span class="description"><?php esc_html_e('seconds', 'yooadmin'); ?></span>
                                        </td>
                                    </tr>
                                </tbody></table>
                            </div>

                            <?php if ($pref_show_email_section) : ?>
                            <h3><?php esc_html_e('Email Notifications', 'yooadmin'); ?></h3>
                            <p class="description"><?php esc_html_e('Configure email notification settings.', 'yooadmin'); ?></p>
                            <div class="yp-settings-card">
                                <table class="form-table"><tbody>
                                    <tr>
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-email yp-th-icon"></span>
                                                <span><?php esc_html_e('Enable email notifications', 'yooadmin'); ?></span>
                                            </div>
                                        </th>
                                        <td>
                                            <?php
                                            yooadmin_my_preferences_toggle(
                                                'email_options[enabled]',
                                                __('Enable email notifications', 'yooadmin'),
                                                isset($preferences['email_options']['enabled']) && $preferences['email_options']['enabled'],
                                                'pref-email-enabled'
                                            );
                                            ?>
                                        </td>
                                    </tr>
                                    <?php if ($pref_email_triggers !== []) : ?>
                                        <?php foreach ($pref_email_triggers as $trigger => $label) : ?>
                                            <tr>
                                                <th scope="row">
                                                    <div class="yp-th-content">
                                                        <span class="dashicons dashicons-flag yp-th-icon"></span>
                                                        <span><?php echo esc_html($label); ?></span>
                                                    </div>
                                                </th>
                                                <td>
                                                    <?php
                                                    yooadmin_my_preferences_toggle(
                                                        'email_options[triggers][' . $trigger . ']',
                                                        $label,
                                                        isset($preferences['email_options']['triggers'][$trigger]) && $preferences['email_options']['triggers'][$trigger],
                                                        'pref-email-trigger-' . sanitize_key($trigger)
                                                    );
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                    <tr>
                                        <th scope="row">
                                            <div class="yp-th-content">
                                                <span class="dashicons dashicons-calendar-alt yp-th-icon"></span>
                                                <label for="email_frequency"><?php esc_html_e('Email frequency', 'yooadmin'); ?></label>
                                            </div>
                                        </th>
                                        <td>
                                            <select id="email_frequency" name="email_options[frequency]">
                                                <option value="immediate" <?php selected($preferences['email_options']['frequency'] ?? 'immediate', 'immediate'); ?>>
                                                    <?php esc_html_e('Immediately', 'yooadmin'); ?>
                                                </option>
                                                <option value="hourly" <?php selected($preferences['email_options']['frequency'] ?? 'immediate', 'hourly'); ?>>
                                                    <?php esc_html_e('Hourly digest', 'yooadmin'); ?>
                                                </option>
                                                <option value="daily" <?php selected($preferences['email_options']['frequency'] ?? 'immediate', 'daily'); ?>>
                                                    <?php esc_html_e('Daily digest', 'yooadmin'); ?>
                                                </option>
                                                <option value="weekly" <?php selected($preferences['email_options']['frequency'] ?? 'immediate', 'weekly'); ?>>
                                                    <?php esc_html_e('Weekly digest', 'yooadmin'); ?>
                                                </option>
                                            </select>
                                        </td>
                                    </tr>
                                </tbody></table>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="yp-preferences-actions">
                        <button type="button" class="button yp-yoo-btn" id="reset-preferences">
                            <?php esc_html_e('Reset to Defaults', 'yooadmin'); ?>
                        </button>
                    </div>
                </section>
                <?php endif; ?>
            </div>
        </div>
    </form>
</div>
<?php
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
?>
