<?php
/**
 * YOOAdmin - Posts index template
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound, WordPress.Security.NonceVerification.Recommended
// Template file. Variables are scoped to the loading function and not global. GET params are read-only filters.

$list_url = admin_url('admin.php?page=yooadmin-posts');
$new_url = admin_url('post-new.php');
$has_search = ($search !== '');
$has_status = ($status !== '');
$has_category = ($category !== 0);
$orderby = isset($_GET['orderby']) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : 'date';
$order = isset($_GET['order']) ? strtoupper( sanitize_key( wp_unslash( $_GET['order'] ) ) ) : 'DESC';
?>

<div class="wrap yooadmin-posts-page">
    <section class="yoo-posts-hero">
        <div class="yoo-posts-hero__body">
            <div class="yoo-posts-hero__top-row">
                <span class="yoo-posts-hero__eyebrow"><?php esc_html_e('Content · Posts', 'yooadmin'); ?></span>
                <div class="yoo-posts-hero__actions">
                    <div class="yoo-posts-search-wrapper">
                        <span class="dashicons dashicons-search"></span>
                        <input type="search" id="yoo-posts-search-input" class="yoo-posts-search-input" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search posts...', 'yooadmin'); ?>">
                    </div>
                    <a class="yp-yoo-btn yp-yoo-btn--primary" href="<?php echo esc_url($new_url); ?>">
                        <span class="dashicons dashicons-plus-alt"></span>
                        <?php esc_html_e('Add New', 'yooadmin'); ?>
                    </a>
                </div>
            </div>
            <h1>
                <span class="dashicons dashicons-admin-post"></span>
                <?php esc_html_e('Posts', 'yooadmin'); ?>
            </h1>
            <button type="button" class="yoo-posts-metrics-toggle" aria-expanded="false">
                <span class="dashicons dashicons-arrow-down-alt"></span>
                <span><?php esc_html_e('Show Statistics', 'yooadmin'); ?></span>
            </button>
        </div>

        <div class="yoo-posts-hero__metrics">
            <article class="yoo-posts-metric">
                <div class="yoo-posts-metric__icon">
                    <span class="dashicons dashicons-admin-post"></span>
                </div>
                <div class="yoo-posts-metric__content">
                    <strong class="yoo-posts-metric__value"><?php echo esc_html(number_format_i18n($total_count)); ?></strong>
                    <span class="yoo-posts-metric__label"><?php esc_html_e('Total Posts', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-posts-metric">
                <div class="yoo-posts-metric__icon">
                    <span class="dashicons dashicons-yes"></span>
                </div>
                <div class="yoo-posts-metric__content">
                    <strong class="yoo-posts-metric__value"><?php echo esc_html(number_format_i18n($publish_count)); ?></strong>
                    <span class="yoo-posts-metric__label"><?php esc_html_e('Published', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-posts-metric">
                <div class="yoo-posts-metric__icon">
                    <span class="dashicons dashicons-edit"></span>
                </div>
                <div class="yoo-posts-metric__content">
                    <strong class="yoo-posts-metric__value"><?php echo esc_html(number_format_i18n($draft_count)); ?></strong>
                    <span class="yoo-posts-metric__label"><?php esc_html_e('Drafts', 'yooadmin'); ?></span>
                </div>
            </article>
        </div>
    </section>

    <section class="yoo-posts-content-section">
        <div class="yoo-posts-toolbar">
            <div class="yoo-posts-filters">
                <a class="yoo-filter-chip <?php echo !$has_status ? 'is-active' : ''; ?>" href="<?php echo esc_url($list_url); ?>" data-status="">
                    <?php esc_html_e('All', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($total_count)); ?></span>
                </a>
                <a class="yoo-filter-chip <?php echo $status === 'publish' ? 'is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('post_status', 'publish', $list_url)); ?>" data-status="publish">
                    <?php esc_html_e('Published', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($publish_count)); ?></span>
                </a>
                <a class="yoo-filter-chip <?php echo $status === 'draft' ? 'is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('post_status', 'draft', $list_url)); ?>" data-status="draft">
                    <?php esc_html_e('Draft', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($draft_count)); ?></span>
                </a>
                <a class="yoo-filter-chip <?php echo $status === 'trash' ? 'is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('post_status', 'trash', $list_url)); ?>" data-status="trash">
                    <?php esc_html_e('Trash', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($trash_count)); ?></span>
                </a>
                
                <!-- Status Filter Button -->
                <?php
$orderby = isset($_GET['orderby']) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : 'date';
$order = isset($_GET['order']) ? strtoupper( sanitize_key( wp_unslash( $_GET['order'] ) ) ) : 'DESC';
$status_sort = ($orderby === 'status') ? strtolower($order) : '';
$status_filter_value = isset($_GET['post_status']) ? sanitize_key(wp_unslash($_GET['post_status'])) : '';
$status_label = __('Status', 'yooadmin');
if ($status_filter_value) {
    $allowed_statuses = ['publish', 'draft', 'pending', 'private', 'future', 'trash'];
    $all_statuses = get_post_stati(['show_in_admin_status_list' => true], 'objects');
    if (in_array($status_filter_value, $allowed_statuses, true) && isset($all_statuses[$status_filter_value])) {
        $status_label = $all_statuses[$status_filter_value]->label;
    }
}
?>
                <div class="yoo-filter-dropdown-wrapper">
                    <button type="button" class="yoo-filter-btn yoo-filter-btn--status yp-yoo-btn yp-yoo-btn--secondary <?php echo !empty($status_filter_value) ? 'is-active' : ''; ?>" data-filter="status" <?php echo $status_sort ? 'data-sort="' . esc_attr($status_sort) . '"' : ''; ?> data-value="<?php echo esc_attr($status_filter_value); ?>">
                        <span class="yoo-filter-label"><?php echo esc_html($status_label); ?></span>
                        <?php if (!empty($status_filter_value)): ?>
                        <span class="yoo-filter-remove" data-filter="status" title="<?php esc_attr_e('Clear filter', 'yooadmin'); ?>">
                            <span class="dashicons dashicons-no-alt"></span>
                        </span>
                        <?php
endif; ?>
                        <span class="yoo-filter-dropdown-arrow dashicons dashicons-arrow-down-alt"></span>
                    </button>
                    <div class="yoo-filter-dropdown" data-dropdown="status">
                        <?php
// Get only post/page relevant statuses in order
$allowed_statuses_order = ['publish', 'draft', 'pending', 'private', 'future', 'trash'];
$all_statuses = get_post_stati(['show_in_admin_status_list' => true], 'objects');
$statuses = [];

// Add statuses in the desired order
foreach ($allowed_statuses_order as $status_key) {
    if (isset($all_statuses[$status_key])) {
        $statuses[$status_key] = $all_statuses[$status_key];
    }
}

$current_status = isset($_GET['post_status']) ? sanitize_key(wp_unslash($_GET['post_status'])) : '';
foreach ($statuses as $status_key => $status_obj):
    $is_selected = $current_status === $status_key;
?>
                        <a href="#" 
                           class="yoo-filter-option <?php echo $is_selected ? 'is-selected' : ''; ?>"
                           data-filter="status"
                           data-value="<?php echo esc_attr($status_key); ?>">
                            <?php echo esc_html($status_obj->label); ?>
                        </a>
                        <?php
endforeach; ?>
                    </div>
                </div>
                
                <!-- Author Filter Button -->
                <?php
$author_sort = ($orderby === 'author') ? strtolower($order) : '';
$author_filter_value = isset($_GET['author']) ? absint($_GET['author']) : 0;
$author_label = __('Author', 'yooadmin');
if ($author_filter_value && isset($authors) && is_array($authors)) {
    foreach ($authors as $author) {
        if ($author->ID == $author_filter_value) {
            $author_label = $author->display_name;
            break;
        }
    }
}
?>
                <div class="yoo-filter-dropdown-wrapper">
                    <button type="button" class="yoo-filter-btn yoo-filter-btn--author yp-yoo-btn yp-yoo-btn--secondary <?php echo !empty($author_filter_value) ? 'is-active' : ''; ?>" data-filter="author" <?php echo $author_sort ? 'data-sort="' . esc_attr($author_sort) . '"' : ''; ?> data-value="<?php echo esc_attr($author_filter_value); ?>">
                        <span class="yoo-filter-label"><?php echo esc_html($author_label); ?></span>
                        <?php if (!empty($author_filter_value)): ?>
                        <span class="yoo-filter-remove" data-filter="author" title="<?php esc_attr_e('Clear filter', 'yooadmin'); ?>">
                            <span class="dashicons dashicons-no-alt"></span>
                        </span>
                        <?php
endif; ?>
                        <span class="yoo-filter-dropdown-arrow dashicons dashicons-arrow-down-alt"></span>
                    </button>
                    <div class="yoo-filter-dropdown" data-dropdown="author">
                        <a href="#" 
                           class="yoo-filter-option <?php echo empty($author_filter_value) ? 'is-selected' : ''; ?>"
                           data-filter="author"
                           data-value="">
                            <?php esc_html_e('All Authors', 'yooadmin'); ?>
                        </a>
                        <?php
if (isset($authors) && is_array($authors)):
    foreach ($authors as $author):
        $is_selected = $author_filter_value == $author->ID;
?>
                        <a href="#" 
                           class="yoo-filter-option <?php echo $is_selected ? 'is-selected' : ''; ?>"
                           data-filter="author"
                           data-value="<?php echo esc_attr($author->ID); ?>">
                            <?php echo esc_html($author->display_name); ?>
                        </a>
                        <?php
    endforeach;
endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="yoo-view-toggle">
                <button type="button" class="yoo-view-btn yoo-view-btn--cards is-active" data-view="cards" title="<?php esc_attr_e('Cards View', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-grid-view"></span>
                </button>
                <button type="button" class="yoo-view-btn yoo-view-btn--table" data-view="table" title="<?php esc_attr_e('Table View', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-list-view"></span>
                </button>
            </div>
        </div>

        <div class="yoo-bulk-actions-bar">
            <div class="yoo-bulk-actions-left">
                <input type="checkbox" id="yoo-select-all-posts" class="yoo-checkbox">
                <label for="yoo-select-all-posts"><?php esc_html_e('Select All', 'yooadmin'); ?></label>
                <span class="yoo-selected-count">0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
            </div>
            <div class="yoo-bulk-actions-right">
                <select id="yoo-bulk-action-select" class="yoo-bulk-select">
                    <option value=""><?php esc_html_e('Bulk Actions', 'yooadmin'); ?></option>
                    <option value="trash"><?php esc_html_e('Move to Trash', 'yooadmin'); ?></option>
                    <option value="restore"><?php esc_html_e('Restore', 'yooadmin'); ?></option>
                    <option value="delete"><?php esc_html_e('Delete Permanently', 'yooadmin'); ?></option>
                </select>
                <button type="button" id="yoo-bulk-apply" class="yp-yoo-btn yp-yoo-btn--primary" disabled>
                    <?php esc_html_e('Apply', 'yooadmin'); ?>
                </button>
            </div>
        </div>

        <div id="yoo-posts-content" class="yoo-view-cards">
            <script>
            !function(){try{var k='yooadmin_posts_view';if(localStorage.getItem(k)!=='table')return;var r=document.getElementById('yoo-posts-content');if(!r)return;r.classList.remove('yoo-view-cards');r.classList.add('yoo-view-table');var c=document.querySelector('.yoo-view-btn--cards'),t=document.querySelector('.yoo-view-btn--table');if(c)c.classList.remove('is-active');if(t)t.classList.add('is-active')}catch(e){}}();
            </script>
            <?php if ($query->have_posts()): ?>
                <!-- Cards View -->
                <div class="yoo-posts-grid yoo-view-cards">
                    <?php while ($query->have_posts()):
        $query->the_post();
        $post = get_post();
        $edit_url = get_edit_post_link($post->ID);
        $view_url = get_permalink($post->ID);
        $post_status = $post->post_status;
        $post_categories = get_the_category($post->ID);
        $post_author = get_userdata($post->post_author);
        $featured_image = get_the_post_thumbnail_url($post->ID, 'medium');
?>
                    <article class="yoo-post-card <?php echo esc_attr($post_status); ?>" data-post-id="<?php echo esc_attr($post->ID); ?>">
                        <input type="checkbox" class="yoo-post-checkbox" value="<?php echo esc_attr($post->ID); ?>" id="post-<?php echo esc_attr($post->ID); ?>">
                        <label for="post-<?php echo esc_attr($post->ID); ?>" class="yoo-post-checkbox-label"></label>
                        
                        <div class="yoo-post-image">
                            <span class="yoo-post-status yoo-post-status--<?php echo esc_attr($post_status); ?>">
                                <?php
                                $status_obj = get_post_status_object($post_status);
                                echo esc_html($status_obj && isset($status_obj->label) ? $status_obj->label : ucfirst($post_status)); ?>
                            </span>
                            <?php if ($featured_image):
            $full_image = get_the_post_thumbnail_url($post->ID, 'full');
?>
                            <img src="<?php echo esc_url($featured_image); ?>" 
                                 alt="<?php echo esc_attr(get_the_title($post->ID)); ?>"
                                 class="yoo-image-lightbox-trigger"
                                 data-image-url="<?php echo esc_url($full_image); ?>"
                                 data-image-title="<?php echo esc_attr(get_the_title($post->ID)); ?>"
                                 style="cursor: pointer;">
                            <?php
        else: ?>
                            <div class="yoo-post-image-placeholder">
                                <span class="dashicons dashicons-format-image"></span>
                                <span class="yoo-placeholder-text"><?php esc_html_e('No Image', 'yooadmin'); ?></span>
                            </div>
                            <?php
        endif; ?>
                        </div>
                        
                        <div class="yoo-post-content">
                            <header class="yoo-post-header">
                                <h2 class="yoo-post-title">
                                    <a href="<?php echo esc_url($edit_url); ?>">
                                        <?php echo esc_html(get_the_title($post->ID) ?: __('(No title)', 'yooadmin')); ?>
                                    </a>
                                </h2>
                            </header>
                            
                            <div class="yoo-post-meta">
                                <div class="yoo-post-meta-item">
                                    <span class="dashicons dashicons-admin-users"></span>
                                    <span><?php echo esc_html($post_author ? $post_author->display_name : __('Unknown', 'yooadmin')); ?></span>
                                </div>
                                <div class="yoo-post-meta-item">
                                    <span class="dashicons dashicons-calendar-alt"></span>
                                    <span><?php echo esc_html(get_the_date('', $post->ID)); ?></span>
                                </div>
                                <?php if (!empty($post_categories)): ?>
                                <div class="yoo-post-meta-item">
                                    <span class="dashicons dashicons-category"></span>
                                    <span><?php echo esc_html($post_categories[0]->name); ?></span>
                                </div>
                                <?php
        endif; ?>
                            </div>
                            
                            <?php
        $excerpt = '';
        if (!empty($post->post_excerpt)) {
            $excerpt = $post->post_excerpt;
        }
        else if (!empty($post->post_content)) {
            $excerpt = $post->post_content;
        }
        if (!empty($excerpt)):
?>
                            <p class="yoo-post-excerpt"><?php echo esc_html(wp_trim_words(strip_shortcodes($excerpt), 20)); ?></p>
                            <?php
        endif; ?>
                            
                            <div class="yoo-post-actions">
                                <?php if ($post_status === 'publish'): ?>
                                <a href="<?php echo esc_url($view_url); ?>" target="_blank" class="yoo-action-btn">
                                    <span class="dashicons dashicons-visibility"></span>
                                    <?php esc_html_e('View', 'yooadmin'); ?>
                                </a>
                                <?php
        endif; ?>
                                <a href="<?php echo esc_url($edit_url); ?>" class="yoo-action-btn">
                                    <span class="dashicons dashicons-edit"></span>
                                    <?php esc_html_e('Edit', 'yooadmin'); ?>
                                </a>
                                <?php if ($post_status === 'publish' && current_user_can('edit_post', $post->ID)): ?>
                                <button type="button" class="yoo-action-btn to-draft" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                    <span class="dashicons dashicons-hidden"></span>
                                    <?php esc_html_e('Draft', 'yooadmin'); ?>
                                </button>
                                <?php
        elseif (in_array($post_status, ['draft', 'pending', 'private'], true) && current_user_can('publish_post', $post->ID)): ?>
                                <button type="button" class="yoo-action-btn to-publish" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                    <span class="dashicons dashicons-yes-alt"></span>
                                    <?php esc_html_e('Publish', 'yooadmin'); ?>
                                </button>
                                <?php
        endif; ?>
                                <?php if ($post_status === 'trash'): ?>
                                <button class="yoo-action-btn restore" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                    <span class="dashicons dashicons-undo"></span>
                                    <?php esc_html_e('Restore', 'yooadmin'); ?>
                                </button>
                                <button class="yoo-action-btn danger delete" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php esc_html_e('Delete', 'yooadmin'); ?>
                                </button>
                                <?php
        else: ?>
                                <button class="yoo-action-btn trash" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php esc_html_e('Trash', 'yooadmin'); ?>
                                </button>
                                <?php
        endif; ?>
                            </div>
                            <?php yooadmin_render_yoast_summary($post->ID, 'post'); ?>
                        </div>
                    </article>
                    <?php
    endwhile;
    wp_reset_postdata(); ?>
                </div>
                
                <!-- Table View -->
                <div class="yoo-posts-table yoo-view-table">
                    <table class="wp-list-table widefat fixed striped table-view-list" style="width: 100%;">
                        <thead>
                            <tr>
                                <th scope="col" class="manage-column column-cb check-column">
                                    <input type="checkbox" id="yoo-select-all-posts-table" class="yoo-checkbox">
                                </th>
                                <th scope="col" class="manage-column column-thumbnail">
                                    <?php esc_html_e('Image', 'yooadmin'); ?>
                                </th>
                                <th scope="col" class="manage-column column-title column-primary sortable sort-desc" data-sort="title">
                                    <a href="#" class="yoo-sort-link">
                                        <span><?php esc_html_e('Title', 'yooadmin'); ?></span>
                                        <span class="sorting-indicator"></span>
                                    </a>
                                </th>
                                <th scope="col" class="manage-column column-author">
                                    <?php esc_html_e('Author', 'yooadmin'); ?>
                                </th>
                                <th scope="col" class="manage-column column-categories">
                                    <?php esc_html_e('Categories', 'yooadmin'); ?>
                                </th>
                                <th scope="col" class="manage-column column-tags">
                                    <?php esc_html_e('Tags', 'yooadmin'); ?>
                                </th>
                                <th scope="col" class="manage-column column-date sortable" data-sort="date">
                                    <a href="#" class="yoo-sort-link">
                                        <span><?php esc_html_e('Date', 'yooadmin'); ?></span>
                                        <span class="sorting-indicator"></span>
                                    </a>
                                </th>
                                <th scope="col" class="manage-column column-comments">
                                    <?php esc_html_e('Comments', 'yooadmin'); ?>
                                </th>
                                <th scope="col" class="manage-column column-status">
                                    <?php esc_html_e('Status', 'yooadmin'); ?>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
    $query->rewind_posts();
    while ($query->have_posts()):
        $query->the_post();
        $post = get_post();
        $edit_url = get_edit_post_link($post->ID);
        $view_url = get_permalink($post->ID);
        $post_status = $post->post_status;
        $post_categories = get_the_category($post->ID);
        $post_tags       = get_the_tags($post->ID);
        if (! is_array($post_tags)) {
            $post_tags = [];
        }
        $post_author = get_userdata($post->post_author);
?>
                            <tr class="yoo-post-row <?php echo esc_attr($post_status); ?>" data-post-id="<?php echo esc_attr($post->ID); ?>" data-title="<?php echo esc_attr(strtolower(get_the_title($post->ID) ?: '')); ?>" data-date="<?php echo esc_attr(get_the_date('U', $post->ID)); ?>">
                                <th scope="row" class="check-column">
                                    <input type="checkbox" class="yoo-post-checkbox" value="<?php echo esc_attr($post->ID); ?>" id="post-table-<?php echo esc_attr($post->ID); ?>">
                                    <label for="post-table-<?php echo esc_attr($post->ID); ?>" class="screen-reader-text"><?php esc_html_e('Select', 'yooadmin'); ?></label>
                                </th>
                                <td class="thumbnail column-thumbnail" data-colname="<?php esc_attr_e('Image', 'yooadmin'); ?>">
                                    <?php
        $featured_image = get_the_post_thumbnail_url($post->ID, 'thumbnail');
        if ($featured_image):
?>
                                    <?php
            $full_image = get_the_post_thumbnail_url($post->ID, 'full');
?>
                                    <div class="yoo-table-thumbnail">
                                        <img src="<?php echo esc_url($featured_image); ?>" 
                                             alt="<?php echo esc_attr(get_the_title($post->ID)); ?>"
                                             class="yoo-image-lightbox-trigger"
                                             data-image-url="<?php echo esc_url($full_image); ?>"
                                             data-image-title="<?php echo esc_attr(get_the_title($post->ID)); ?>"
                                             style="cursor: pointer;">
                                    </div>
                                    <?php
        else: ?>
                                    <div class="yoo-table-thumbnail yoo-table-thumbnail--placeholder">
                                        <span class="dashicons dashicons-format-image"></span>
                                    </div>
                                    <?php
        endif; ?>
                                </td>
                                <td class="title column-title column-primary" data-colname="<?php esc_attr_e('Title', 'yooadmin'); ?>">
                                    <strong>
                                        <a class="row-title" href="<?php echo esc_url($edit_url); ?>">
                                            <?php echo esc_html(get_the_title($post->ID) ?: __('(No title)', 'yooadmin')); ?>
                                        </a>
                                    </strong>
                                    <div class="row-actions">
                                        <?php if ($post_status === 'publish'): ?>
                                        <span class="view">
                                            <a href="<?php echo esc_url($view_url); ?>" target="_blank">
                                                <span class="dashicons dashicons-visibility" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                                                <?php esc_html_e('View', 'yooadmin'); ?>
                                            </a> |
                                        </span>
                                        <?php
        endif; ?>
                                        <span class="edit">
                                            <a href="<?php echo esc_url($edit_url); ?>">
                                                <span class="dashicons dashicons-edit" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                                                <?php esc_html_e('Edit', 'yooadmin'); ?>
                                            </a> |
                                        </span>
                                        <?php if ($post_status === 'publish' && current_user_can('edit_post', $post->ID)): ?>
                                        <span class="to-draft">
                                            <a href="#" class="yoo-action-link to-draft" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                                <span class="dashicons dashicons-hidden" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                                                <?php esc_html_e('Draft', 'yooadmin'); ?>
                                            </a> |
                                        </span>
                                        <?php
        elseif (in_array($post_status, ['draft', 'pending', 'private'], true) && current_user_can('publish_post', $post->ID)): ?>
                                        <span class="to-publish">
                                            <a href="#" class="yoo-action-link to-publish" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                                <span class="dashicons dashicons-yes-alt" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                                                <?php esc_html_e('Publish', 'yooadmin'); ?>
                                            </a> |
                                        </span>
                                        <?php
        endif; ?>
                                        <?php if ($post_status === 'trash'): ?>
                                        <span class="restore">
                                            <a href="#" class="yoo-action-link restore" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                                <span class="dashicons dashicons-undo" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                                                <?php esc_html_e('Restore', 'yooadmin'); ?>
                                            </a> |
                                        </span>
                                        <span class="trash">
                                            <a href="#" class="yoo-action-link delete" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                                <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                                                <?php esc_html_e('Delete Permanently', 'yooadmin'); ?>
                                            </a>
                                        </span>
                                        <?php
        else: ?>
                                        <span class="trash">
                                            <a href="#" class="yoo-action-link trash" data-post-id="<?php echo esc_attr($post->ID); ?>">
                                                <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                                                <?php esc_html_e('Trash', 'yooadmin'); ?>
                                            </a>
                                        </span>
                                        <?php
        endif; ?>
                                    </div>
                                    <?php yooadmin_render_yoast_summary($post->ID, 'post'); ?>
                                </td>
                                <td class="author column-author" data-colname="<?php esc_attr_e('Author', 'yooadmin'); ?>">
                                    <?php echo esc_html($post_author ? $post_author->display_name : __('Unknown', 'yooadmin')); ?>
                                </td>
                                <td class="categories column-categories" data-colname="<?php esc_attr_e('Categories', 'yooadmin'); ?>">
                                    <?php
        if (!empty($post_categories)) {
            $cat_names = array_map(function ($cat) {
                return '<a href="' . esc_url(get_edit_term_link($cat->term_id, 'category')) . '">' . esc_html($cat->name) . '</a>';
            }, $post_categories);
            echo wp_kses_post(implode(', ', $cat_names));
        }
        else {
            echo '<span aria-hidden="true">—</span>';
        }
?>
                                </td>
                                <td class="tags column-tags" data-colname="<?php esc_attr_e('Tags', 'yooadmin'); ?>">
                                    <?php
        if (!empty($post_tags)) {
            $tag_links = array_map(function ($tag) {
                return '<a href="' . esc_url(get_edit_term_link($tag->term_id, 'post_tag')) . '">' . esc_html($tag->name) . '</a>';
            }, $post_tags);
            echo wp_kses_post(implode(', ', $tag_links));
        }
        else {
            echo '<span aria-hidden="true">—</span>';
        }
?>
                                </td>
                                <td class="date column-date" data-colname="<?php esc_attr_e('Date', 'yooadmin'); ?>">
                                    <?php echo esc_html(get_the_date('', $post->ID)); ?>
                                </td>
                                <td class="comments column-comments" data-colname="<?php esc_attr_e('Comments', 'yooadmin'); ?>">
                                    <?php
        $comments_count = get_comments_number($post->ID);
        $comments_url = admin_url('edit-comments.php?p=' . $post->ID);
        if ($comments_count > 0):
?>
                                    <a href="<?php echo esc_url($comments_url); ?>" class="post-com-count post-com-count-approved">
                                        <span class="comment-count-approved" aria-hidden="true">
                                            <span class="dashicons dashicons-admin-comments" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px;"></span>
                                            <?php echo esc_html(number_format_i18n($comments_count)); ?>
                                        </span>
                                    </a>
                                    <?php
        else: ?>
                                    <span class="post-com-count post-com-count-no-comments">
                                        <span class="dashicons dashicons-admin-comments" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; opacity: 0.4;"></span>
                                        <span class="screen-reader-text"><?php esc_html_e('No comments', 'yooadmin'); ?></span>
                                        <span aria-hidden="true">—</span>
                                    </span>
                                    <?php
        endif; ?>
                                </td>
                                <td class="status column-status" data-colname="<?php esc_attr_e('Status', 'yooadmin'); ?>">
                                    <span class="yoo-post-status yoo-post-status--<?php echo esc_attr($post_status); ?>">
                                        <?php
                                        $status_obj = get_post_status_object($post_status);
                                        echo esc_html($status_obj && isset($status_obj->label) ? $status_obj->label : ucfirst($post_status)); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php
    endwhile;
    wp_reset_postdata(); ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($query->max_num_pages > 1):
        $base_url = admin_url('admin.php?page=yooadmin-posts');
        if ($status) {
            $base_url = add_query_arg('post_status', urlencode($status), $base_url);
        }
        if ($category) {
            $base_url = add_query_arg('category', urlencode($category), $base_url);
        }
        if ($search) {
            $base_url = add_query_arg('s', urlencode($search), $base_url);
        }
?>
                <nav class="yoo-posts-pagination">
                    <?php if ($paged > 1):
            $prev_url = add_query_arg('paged', $paged - 1, $base_url);
?>
                        <a href="<?php echo esc_url($prev_url); ?>" class="yoo-pagination-prev">
                            <?php esc_html_e('Previous', 'yooadmin'); ?>
                        </a>
                    <?php
        endif; ?>
                    
                    <?php for ($i = 1; $i <= $query->max_num_pages; $i++): ?>
                        <?php if ($i === $paged): ?>
                            <span class="yoo-pagination-current"><?php echo esc_html($i); ?></span>
                        <?php
            else:
                $page_url = add_query_arg('paged', $i, $base_url);
?>
                            <a href="<?php echo esc_url($page_url); ?>" class="yoo-pagination-link"><?php echo esc_html($i); ?></a>
                        <?php
            endif; ?>
                    <?php
        endfor; ?>
                    
                    <?php if ($paged < $query->max_num_pages):
            $next_url = add_query_arg('paged', $paged + 1, $base_url);
?>
                        <a href="<?php echo esc_url($next_url); ?>" class="yoo-pagination-next">
                            <?php esc_html_e('Next', 'yooadmin'); ?>
                        </a>
                    <?php
        endif; ?>
                </nav>
                <?php
    endif; ?>
            <?php
else: ?>
                <div class="yoo-posts-empty">
                    <div class="yoo-empty-illustration">
                        <span class="dashicons dashicons-edit-page"></span>
                    </div>
                    <h2><?php esc_html_e('No posts found', 'yooadmin'); ?></h2>
                    <p><?php esc_html_e('Try adjusting your search or filter criteria.', 'yooadmin'); ?></p>
                </div>
            <?php
endif; ?>
        </div>
    </section>
</div>

<!-- Image Lightbox Modal -->
<div id="yoo-image-lightbox" class="yoo-image-lightbox" style="display: none;">
    <div class="yoo-lightbox-overlay"></div>
    <div class="yoo-lightbox-container">
        <button class="yoo-lightbox-close" aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
            <span class="dashicons dashicons-no-alt"></span>
        </button>
        <div class="yoo-lightbox-content">
            <img src="" alt="" class="yoo-lightbox-image">
            <div class="yoo-lightbox-title"></div>
        </div>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
