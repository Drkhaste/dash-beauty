<?php
/**
 * YOOUpdate Center template — WordPress hero + tabbed plugins / themes / translations.
 *
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template scope variables.

$subtitle = __('Check for updates and apply them in one place.', 'yooadmin');

$uc_counts = function_exists('yooadmin_uc_get_tab_counts') ? yooadmin_uc_get_tab_counts() : ['core' => 0, 'plugins' => 0, 'themes' => 0, 'translations' => 0];

$cap_plugins = current_user_can('update_plugins');
$cap_themes  = current_user_can('update_themes');
$cap_trans   = current_user_can('update_languages');
$has_tabs    = $cap_plugins || $cap_themes || $cap_trans;

$default_tab = 'plugins';
if ($cap_plugins && $uc_counts['plugins'] > 0) {
    $default_tab = 'plugins';
} elseif ($cap_themes && $uc_counts['themes'] > 0) {
    $default_tab = 'themes';
} elseif ($cap_trans && $uc_counts['translations'] > 0) {
    $default_tab = 'translations';
} elseif (! $cap_plugins && $cap_themes) {
    $default_tab = 'themes';
} elseif (! $cap_plugins && ! $cap_themes && $cap_trans) {
    $default_tab = 'translations';
}

unset($GLOBALS['yooadmin_uc_suppress_core_primary']);
?>
<div class="wrap yoo-upload-wrap yoo-theme-manager-wrap yoo-update-center-wrap" data-page="update-center" data-uc-default-tab="<?php echo esc_attr($default_tab); ?>">
    <div class="yoo-upload-header yoo-update-center-header">
        <div class="yoo-upload-header-content">
            <h1 class="yoo-upload-title">
                <span class="dashicons dashicons-update yoo-update-center-title-icon" aria-hidden="true"></span>
                <?php esc_html_e('YOOUpdate Center', 'yooadmin'); ?>
            </h1>
            <p class="yoo-upload-subtitle"><?php echo esc_html($subtitle); ?></p>
        </div>
        <?php if (current_user_can('update_core')) : ?>
        <div class="yoo-upload-header-actions">
            <?php yooadmin_uc_render_header_actions(); ?>
        </div>
        <?php endif; ?>
    </div>

    <?php yooadmin_uc_core_auto_redirect_notices(); ?>

    <?php if (current_user_can('update_core')) : ?>
        <div id="yoo-uc-preface-slot">
            <?php yooadmin_uc_render_preface_notices(); ?>
        </div>
    <?php endif; ?>

    <section class="yoo-uc-hero" aria-labelledby="yoo-uc-hero-title">
        <div class="yoo-uc-hero__top">
            <div class="yoo-uc-hero__brand">
                <span class="yoo-uc-wp-logo" aria-hidden="true"><span class="dashicons dashicons-wordpress"></span></span>
                <div class="yoo-uc-hero__brand-text">
                    <p id="yoo-uc-hero-title" class="yoo-uc-hero__kicker"><?php esc_html_e('WordPress', 'yooadmin'); ?></p>
                    <p class="yoo-uc-hero__version-line">
                        <?php esc_html_e('Current version', 'yooadmin'); ?>
                        <span class="yoo-uc-hero__version-group">
                            <strong id="yoo-uc-wp-version-num"><?php echo esc_html(get_bloginfo('version')); ?></strong>
                            <?php if (function_exists('yooadmin_uc_should_show_latest_version_badge') && yooadmin_uc_should_show_latest_version_badge()) : ?>
                                <span class="yoo-uc-latest-version-tag"><?php esc_html_e('Latest Version', 'yooadmin'); ?></span>
                            <?php endif; ?>
                        </span>
                    </p>
                    <div id="yoo-uc-hero-maintenance-slot" class="yoo-uc-hero-maintenance-slot"><?php
                    if (current_user_can('update_core') && function_exists('yooadmin_uc_print_hero_maintenance_note')) {
                        yooadmin_uc_print_hero_maintenance_note();
                    }
                    ?></div>
                </div>
            </div>
            <?php if (current_user_can('update_core')) : ?>
            <div id="yoo-uc-hero-aside" class="yoo-uc-hero__aside">
                <?php
                if (function_exists('yooadmin_uc_render_hero_aside')) {
                    yooadmin_uc_render_hero_aside();
                }
                ?>
            </div>
            <?php endif; ?>
        </div>
        <div id="yoo-uc-core-dynamic" class="yoo-uc-hero__core">
            <?php
            if (current_user_can('update_core')) {
                yooadmin_uc_core_upgrade_preamble();
            } else {
                echo '<p class="yoo-update-center-empty">' . esc_html__('You do not have permission to update WordPress core.', 'yooadmin') . '</p>';
            }
            ?>
        </div>
    </section>

    <?php if ($has_tabs) : ?>
    <div class="yp-tabs" id="yoo-uc-tabs-root" role="region" aria-label="<?php esc_attr_e('Plugin, theme, and translation updates', 'yooadmin'); ?>">
        <div class="yp-tab-nav" role="tablist" aria-label="<?php esc_attr_e('Update categories', 'yooadmin'); ?>">
            <?php if ($cap_plugins) : ?>
                <button type="button" class="yp-tab yoo-uc-tab<?php echo 'plugins' === $default_tab ? ' is-active' : ''; ?>" role="tab" id="yoo-uc-tab-plugins" aria-selected="<?php echo 'plugins' === $default_tab ? 'true' : 'false'; ?>" aria-controls="yoo-uc-panel-plugins" data-yoo-uc-tab="plugins">
                    <?php esc_html_e('Plugins', 'yooadmin'); ?>
                    <?php if ($uc_counts['plugins'] > 0) : ?>
                        <span class="yoo-uc-tab__badge"><?php echo esc_html((string) (int) $uc_counts['plugins']); ?></span>
                    <?php endif; ?>
                </button>
            <?php endif; ?>
            <?php if ($cap_themes) : ?>
                <button type="button" class="yp-tab yoo-uc-tab<?php echo 'themes' === $default_tab ? ' is-active' : ''; ?>" role="tab" id="yoo-uc-tab-themes" aria-selected="<?php echo 'themes' === $default_tab ? 'true' : 'false'; ?>" aria-controls="yoo-uc-panel-themes" data-yoo-uc-tab="themes">
                    <?php esc_html_e('Themes', 'yooadmin'); ?>
                    <?php if ($uc_counts['themes'] > 0) : ?>
                        <span class="yoo-uc-tab__badge"><?php echo esc_html((string) (int) $uc_counts['themes']); ?></span>
                    <?php endif; ?>
                </button>
            <?php endif; ?>
            <?php if ($cap_trans) : ?>
                <button type="button" class="yp-tab yoo-uc-tab<?php echo 'translations' === $default_tab ? ' is-active' : ''; ?>" role="tab" id="yoo-uc-tab-translations" aria-selected="<?php echo 'translations' === $default_tab ? 'true' : 'false'; ?>" aria-controls="yoo-uc-panel-translations" data-yoo-uc-tab="translations">
                    <?php esc_html_e('Translations', 'yooadmin'); ?>
                    <?php if ($uc_counts['translations'] > 0) : ?>
                        <span class="yoo-uc-tab__badge"><?php echo esc_html((string) (int) $uc_counts['translations']); ?></span>
                    <?php endif; ?>
                </button>
            <?php endif; ?>
        </div>

        <div class="yp-tab-panels">
        <?php if ($cap_plugins) : ?>
        <div id="yoo-uc-panel-plugins" class="yp-tab-panel yoo-uc-tab-panel<?php echo 'plugins' === $default_tab ? ' is-active' : ''; ?>" role="tabpanel" aria-labelledby="yoo-uc-tab-plugins" <?php echo 'plugins' !== $default_tab ? 'hidden' : ''; ?> data-yoo-uc-panel="plugins">
            <div id="yoo-uc-plugins-wrap">
                <?php yooadmin_uc_list_plugin_updates(true); ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($cap_themes) : ?>
        <div id="yoo-uc-panel-themes" class="yp-tab-panel yoo-uc-tab-panel<?php echo 'themes' === $default_tab ? ' is-active' : ''; ?>" role="tabpanel" aria-labelledby="yoo-uc-tab-themes" <?php echo 'themes' !== $default_tab ? 'hidden' : ''; ?> data-yoo-uc-panel="themes">
            <div id="yoo-uc-themes-wrap">
                <?php yooadmin_uc_list_theme_updates(true); ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($cap_trans) : ?>
        <div id="yoo-uc-panel-translations" class="yp-tab-panel yoo-uc-tab-panel<?php echo 'translations' === $default_tab ? ' is-active' : ''; ?>" role="tabpanel" aria-labelledby="yoo-uc-tab-translations" <?php echo 'translations' !== $default_tab ? 'hidden' : ''; ?> data-yoo-uc-panel="translations">
            <div id="yoo-uc-translations-wrap">
                <?php yooadmin_uc_list_translation_updates(true); ?>
            </div>
        </div>
        <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
