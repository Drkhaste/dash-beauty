<?php
/**
 * YOOAdmin - Categories index template
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

$list_url = admin_url('admin.php?page=yooadmin-categories');
$has_search = ($search !== '');
$default_cat = get_option('default_category');
?>

<div class="wrap yooadmin-categories-page">
    <section class="yoo-categories-hero">
        <div class="yoo-categories-hero__body">
            <div class="yoo-categories-hero__top-row">
                <span class="yoo-categories-hero__eyebrow"><?php esc_html_e('Content · Categories', 'yooadmin'); ?></span>
                <div class="yoo-categories-hero__actions">
                    <div class="yoo-categories-search-wrapper">
                        <span class="dashicons dashicons-search"></span>
                        <input type="search" id="yoo-categories-search-input" class="yoo-categories-search-input" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search categories...', 'yooadmin'); ?>">
                    </div>
                    <button type="button" class="yoo-button yoo-button--primary" id="yoo-add-category-btn">
                        <span class="dashicons dashicons-plus-alt"></span>
                        <?php esc_html_e('Add New', 'yooadmin'); ?>
                    </button>
                </div>
            </div>
            <h1>
                <span class="dashicons dashicons-category"></span>
                <?php esc_html_e('Categories', 'yooadmin'); ?>
            </h1>
            <button type="button" class="yoo-categories-metrics-toggle" aria-expanded="false">
                <span class="dashicons dashicons-arrow-down-alt"></span>
                <span><?php esc_html_e('Show Statistics', 'yooadmin'); ?></span>
            </button>
        </div>

        <div class="yoo-categories-hero__metrics" style="display: none;">
            <article class="yoo-categories-metric">
                <div class="yoo-categories-metric__icon">
                    <span class="dashicons dashicons-category"></span>
                </div>
                <div class="yoo-categories-metric__content">
                    <strong class="yoo-categories-metric__value"><?php echo esc_html(number_format_i18n($total_count)); ?></strong>
                    <span class="yoo-categories-metric__label"><?php esc_html_e('Total Categories', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-categories-metric">
                <div class="yoo-categories-metric__icon">
                    <span class="dashicons dashicons-admin-post"></span>
                </div>
                <div class="yoo-categories-metric__content">
                    <strong class="yoo-categories-metric__value"><?php echo esc_html(number_format_i18n($total_count - $empty_count)); ?></strong>
                    <span class="yoo-categories-metric__label"><?php esc_html_e('With Posts', 'yooadmin'); ?></span>
                </div>
            </article>
        </div>
    </section>

    <section class="yoo-categories-content-section">
        <div class="yoo-categories-toolbar">
            <div class="yoo-categories-filters">
                <a class="yoo-filter-chip is-active" href="<?php echo esc_url($list_url); ?>">
                    <?php esc_html_e('All', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($total_count)); ?></span>
                </a>
                <a class="yoo-filter-chip" href="<?php echo esc_url(add_query_arg('show', 'with-posts', $list_url)); ?>">
                    <?php esc_html_e('With Posts', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($total_count - $empty_count)); ?></span>
                </a>
                <a class="yoo-filter-chip" href="<?php echo esc_url(add_query_arg('show', 'empty', $list_url)); ?>">
                    <?php esc_html_e('Empty', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($empty_count)); ?></span>
                </a>
            </div>
        </div>

        <div class="yoo-bulk-actions-bar">
            <div class="yoo-bulk-actions-left">
                <input type="checkbox" id="yoo-select-all-categories" class="yoo-checkbox">
                <label for="yoo-select-all-categories"><?php esc_html_e('Select All', 'yooadmin'); ?></label>
                <span class="yoo-selected-count">0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
            </div>
            <div class="yoo-bulk-actions-right">
                <select id="yoo-bulk-action-select" class="yoo-bulk-select">
                    <option value=""><?php esc_html_e('Bulk Actions', 'yooadmin'); ?></option>
                    <option value="delete"><?php esc_html_e('Delete', 'yooadmin'); ?></option>
                </select>
                <button type="button" id="yoo-bulk-apply" class="yoo-button yoo-button--primary" disabled>
                    <?php esc_html_e('Apply', 'yooadmin'); ?>
                </button>
            </div>
        </div>

        <div id="yoo-categories-content">
            <?php if (!empty($categories)): ?>
                <div class="yoo-categories-grid">
                    <?php foreach ($categories as $category):
        $edit_url = get_edit_term_link($category->term_id, 'category');
        $view_url = get_category_link($category->term_id);
        $posts_count = (int)$category->count;
        $is_default = ((int)$category->term_id === (int)$default_cat);
        $parent = $category->parent ? get_category($category->parent) : null;
?>
                    <article class="yoo-category-card" data-category-id="<?php echo esc_attr($category->term_id); ?>" data-posts-count="<?php echo esc_attr($posts_count); ?>">
                        <input type="checkbox" class="yoo-category-checkbox" value="<?php echo esc_attr($category->term_id); ?>" id="category-<?php echo esc_attr($category->term_id); ?>" <?php echo $is_default ? 'disabled' : ''; ?>>
                        <label for="category-<?php echo esc_attr($category->term_id); ?>" class="yoo-category-checkbox-label"></label>
                        
                        <div class="yoo-category-content">
                            <header class="yoo-category-header">
                                <h2 class="yoo-category-name">
                                    <a href="<?php echo esc_url($edit_url); ?>">
                                        <?php echo esc_html($category->name); ?>
                                    </a>
                                </h2>
                                <?php if ($is_default): ?>
                                <span class="yoo-category-badge yoo-category-badge--default">
                                    <?php esc_html_e('Default', 'yooadmin'); ?>
                                </span>
                                <?php
        endif; ?>
                            </header>
                            
                            <?php if (!empty($category->description)): ?>
                            <p class="yoo-category-description">
                                <?php echo esc_html(wp_trim_words($category->description, 20)); ?>
                            </p>
                            <?php
        endif; ?>
                            
                            <div class="yoo-category-meta">
                                <div class="yoo-category-meta-item">
                                    <span class="dashicons dashicons-admin-post"></span>
                                    <span><?php /* translators: %d: number of posts */ echo esc_html(sprintf(_n('%d post', '%d posts', $posts_count, 'yooadmin'), $posts_count)); ?></span>
                                </div>
                                <?php if ($parent): ?>
                                <div class="yoo-category-meta-item">
                                    <span class="dashicons dashicons-networking"></span>
                                    <span><?php echo esc_html($parent->name); ?></span>
                                </div>
                                <?php
        endif; ?>
                                <div class="yoo-category-meta-item">
                                    <span class="dashicons dashicons-tag"></span>
                                    <span><?php echo esc_html($category->slug); ?></span>
                                </div>
                            </div>
                            
                            <div class="yoo-category-actions">
                                <a href="<?php echo esc_url($view_url); ?>" target="_blank" class="yoo-action-btn">
                                    <span class="dashicons dashicons-visibility"></span>
                                    <?php esc_html_e('View', 'yooadmin'); ?>
                                </a>
                                <a href="<?php echo esc_url($edit_url); ?>" class="yoo-action-btn">
                                    <span class="dashicons dashicons-edit"></span>
                                    <?php esc_html_e('Edit', 'yooadmin'); ?>
                                </a>
                                <?php if (!$is_default): ?>
                                <button class="yoo-action-btn danger delete" data-category-id="<?php echo esc_attr($category->term_id); ?>" data-category-name="<?php echo esc_attr($category->name); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php esc_html_e('Delete', 'yooadmin'); ?>
                                </button>
                                <?php
        endif; ?>
                            </div>
                        </div>
                    </article>
                    <?php
    endforeach; ?>
                </div>
            <?php
else: ?>
                <div class="yoo-categories-empty">
                    <div class="yoo-empty-illustration">
                        <span class="dashicons dashicons-category"></span>
                    </div>
                    <h2><?php esc_html_e('No categories found', 'yooadmin'); ?></h2>
                    <p><?php esc_html_e('Try adjusting your search criteria.', 'yooadmin'); ?></p>
                    <button type="button" class="yoo-button yoo-button--primary" id="yoo-add-first-category-btn">
                        <?php esc_html_e('Create first category', 'yooadmin'); ?>
                    </button>
                </div>
            <?php
endif; ?>
        </div>
    </section>
</div>

<!-- Add Category Modal -->
<div id="yoo-add-category-modal">
    <div class="yoo-category-modal-content">
        <div class="yoo-category-modal-header">
            <h2><?php esc_html_e('Add New Category', 'yooadmin'); ?></h2>
            <button type="button" id="yoo-category-modal-close">&times;</button>
        </div>
        <form id="yoo-add-category-form">
            <div class="yoo-category-modal-body">
                <div class="yoo-category-form-group">
                    <label>
                        <?php esc_html_e('Name', 'yooadmin'); ?>
                        <span class="required">*</span>
                    </label>
                    <input type="text" name="cat_name" id="yoo-cat-name" required>
                </div>
                <div class="yoo-category-form-group">
                    <label><?php esc_html_e('Slug', 'yooadmin'); ?></label>
                    <input type="text" name="cat_slug" id="yoo-cat-slug">
                    <small><?php esc_html_e('Leave empty to auto-generate', 'yooadmin'); ?></small>
                </div>
                <div class="yoo-category-form-group">
                    <label><?php esc_html_e('Parent Category', 'yooadmin'); ?></label>
                    <select name="cat_parent" id="yoo-cat-parent">
                        <option value="0"><?php esc_html_e('None', 'yooadmin'); ?></option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo esc_attr($cat->term_id); ?>"><?php echo esc_html($cat->name); ?></option>
                        <?php
endforeach; ?>
                    </select>
                </div>
                <div class="yoo-category-form-group">
                    <label><?php esc_html_e('Description', 'yooadmin'); ?></label>
                    <textarea name="cat_description" id="yoo-cat-description" rows="4"></textarea>
                </div>
            </div>
            <div class="yoo-category-modal-footer">
                <button type="button" id="yoo-category-modal-cancel" class="button"><?php esc_html_e('Cancel', 'yooadmin'); ?></button>
                <button type="submit" class="button button-primary"><?php esc_html_e('Add Category', 'yooadmin'); ?></button>
            </div>
        </form>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>



















