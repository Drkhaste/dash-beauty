<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$tabs    = yooadmin_network_upgrade_tabs();
$tab     = 'overview';
$action  = yooadmin_network_upgrade_current_action();
$batch   = null;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only tab routing (display/UI only).
if (isset($_GET['tab'])) {
    $maybe = sanitize_key(wp_unslash((string) $_GET['tab']));
    if (isset($tabs[ $maybe ])) {
        $tab = $maybe;
    }
}
// phpcs:enable WordPress.Security.NonceVerification.Recommended

if ($action === 'upgrade') {
    $tab   = 'upgrade';
    $batch = yooadmin_network_upgrade_process_batch(yooadmin_network_upgrade_batch_index());
}

$upgrade_url = yooadmin_network_upgrade_url(['action' => 'upgrade']);
?>
<div class="wrap yoo-upload-wrap yoo-network-classic-wrap yoo-network-upgrade-wrap" data-page="network-upgrade">
  <div class="yoo-upload-header yoo-network-classic-header">
    <div class="yoo-upload-header-content">
      <h1 class="yoo-upload-title">
        <span class="dashicons dashicons-update yoo-upload-title-dashicon" aria-hidden="true"></span>
        <?php esc_html_e('Upgrade Network', 'yooadmin'); ?>
      </h1>
      <p class="yoo-upload-subtitle"><?php esc_html_e('Upgrade every site database after a core update — five sites per batch.', 'yooadmin'); ?></p>
    </div>
  </div>

  <div class="yooadmin-settings-wrap yoo-network-classic-tabs-shell">
    <div class="yp-tabs" data-yoo-network-classic-tabs>
      <div class="yp-tab-nav" role="tablist" aria-label="<?php esc_attr_e('Network upgrade sections', 'yooadmin'); ?>">
        <?php foreach ($tabs as $tab_id => $tab_meta) :
            $active = $tab === $tab_id;
            ?>
          <button type="button" class="yp-tab<?php echo $active ? ' is-active' : ''; ?>" role="tab" aria-selected="<?php echo $active ? 'true' : 'false'; ?>" data-tab="<?php echo esc_attr($tab_id); ?>">
            <?php echo esc_html((string) $tab_meta['label']); ?>
          </button>
        <?php endforeach; ?>
      </div>

      <div class="yp-tab-panels">
        <section class="yp-tab-panel<?php echo $tab === 'overview' ? ' is-active' : ''; ?>" data-panel="overview" role="tabpanel">
          <div class="yp-tab-intro">
            <span class="dashicons dashicons-info-outline yp-tab-intro-icon" aria-hidden="true"></span>
            <p class="yp-tab-intro__text"><?php echo esc_html($tabs['overview']['desc']); ?></p>
          </div>
          <?php if (yooadmin_network_upgrade_db_version_mismatch()) : ?>
            <div class="yoo-network-classic-notice yoo-network-classic-notice--warning">
              <?php esc_html_e('WordPress core was updated. Run the network upgrade to sync every site database.', 'yooadmin'); ?>
            </div>
          <?php else : ?>
            <div class="yoo-network-classic-notice yoo-network-classic-notice--success">
              <?php esc_html_e('Network database version matches core. You can still run the upgrade safely.', 'yooadmin'); ?>
            </div>
          <?php endif; ?>
          <p class="yoo-network-classic-tip-line">
            <span class="yoo-network-classic-tip" tabindex="0" data-yoo-tip="<?php esc_attr_e('Use this after updating WordPress from Dashboard → Updates.', 'yooadmin'); ?>">?</span>
            <?php esc_html_e('Only run this after core files were updated through the Updates screen.', 'yooadmin'); ?>
          </p>
        </section>

        <section class="yp-tab-panel<?php echo $tab === 'upgrade' ? ' is-active' : ''; ?>" data-panel="upgrade" role="tabpanel">
          <div class="yp-tab-intro">
            <span class="dashicons dashicons-update yp-tab-intro-icon" aria-hidden="true"></span>
            <p class="yp-tab-intro__text"><?php echo esc_html($tabs['upgrade']['desc']); ?></p>
          </div>

          <?php if ($action === 'upgrade' && is_array($batch)) : ?>
            <?php if (!empty($batch['done'])) : ?>
              <div class="yoo-network-classic-notice yoo-network-classic-notice--success">
                <?php esc_html_e('All done! Every site in this batch finished upgrading.', 'yooadmin'); ?>
              </div>
            <?php else : ?>
              <p><?php esc_html_e('Upgraded sites in this batch:', 'yooadmin'); ?></p>
              <ul class="yoo-network-classic-site-list">
                <?php foreach ($batch['sites'] as $site_url) : ?>
                  <li><?php echo esc_html((string) $site_url); ?></li>
                <?php endforeach; ?>
              </ul>
              <p>
                <?php esc_html_e('Continuing automatically…', 'yooadmin'); ?>
                <a class="yp-yoo-btn yp-yoo-btn--primary" href="<?php echo esc_url(yooadmin_network_upgrade_url(['action' => 'upgrade', 'n' => (int) $batch['next']])); ?>">
                  <?php esc_html_e('Next sites', 'yooadmin'); ?>
                </a>
              </p>
              <script>
                window.setTimeout(function () {
                  window.location.href = <?php echo wp_json_encode(yooadmin_network_upgrade_url(['action' => 'upgrade', 'n' => (int) $batch['next']])); ?>;
                }, 350);
              </script>
            <?php endif; ?>
          <?php else : ?>
            <p><?php esc_html_e('The process may take a while on large networks. Please keep this tab open.', 'yooadmin'); ?></p>
            <a class="yp-yoo-btn yp-yoo-btn--primary" href="<?php echo esc_url($upgrade_url); ?>">
              <?php esc_html_e('Upgrade Network', 'yooadmin'); ?>
            </a>
          <?php endif; ?>
        </section>

        <section class="yp-tab-panel<?php echo $tab === 'help' ? ' is-active' : ''; ?>" data-panel="help" role="tabpanel">
          <div class="yp-tab-intro">
            <span class="dashicons dashicons-sos yp-tab-intro-icon" aria-hidden="true"></span>
            <p class="yp-tab-intro__text"><?php echo esc_html($tabs['help']['desc']); ?></p>
          </div>
          <ul class="yoo-network-classic-help-list">
            <li><?php esc_html_e('If a site fails, users logging in there will trigger the same database upgrade.', 'yooadmin'); ?></li>
            <li><?php esc_html_e('Turn off Focus Mode in YOOAdmin settings to use the default WordPress Upgrade Network screen.', 'yooadmin'); ?></li>
            <li>
              <a href="<?php echo esc_url('https://developer.wordpress.org/advanced-administration/multisite/admin/#network-admin-updates-screen'); ?>" target="_blank" rel="noopener noreferrer">
                <?php esc_html_e('Upgrade Network documentation', 'yooadmin'); ?>
              </a>
            </li>
          </ul>
        </section>
      </div>
    </div>
  </div>
</div>
