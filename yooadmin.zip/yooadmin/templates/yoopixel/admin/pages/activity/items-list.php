<?php
/**
 * Activity log — list items partial.
 *
 * @package YOOAdmin
 * @var array<int, array<string, mixed>> $activity_items
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

$activity_items = isset($activity_items) && is_array($activity_items) ? $activity_items : [];

if (!$activity_items) : ?>
    <li class="yoo-activity-empty">
        <span class="dashicons dashicons-backup" aria-hidden="true"></span>
        <p><?php esc_html_e('No activity found for these filters.', 'yooadmin'); ?></p>
    </li>
<?php
    return;
endif;

foreach ($activity_items as $item) :
    if (!is_array($item)) {
        continue;
    }
    $url = isset($item['url']) ? (string) $item['url'] : '';
    $action_label = isset($item['action_label']) ? (string) $item['action_label'] : (string) ($item['title'] ?? '');
    $subject = isset($item['subject']) ? (string) $item['subject'] : '';
    $icon = isset($item['icon']) ? (string) $item['icon'] : 'dashicons-marker';
    $user_name = isset($item['user_name']) ? (string) $item['user_name'] : '';
    $time_label = isset($item['time_label']) ? (string) $item['time_label'] : '';
    $category_label = isset($item['category_label']) ? (string) $item['category_label'] : '';
    ?>
    <li class="yoo-activity-item">
        <span class="yoo-activity-item__icon-wrap" aria-hidden="true">
            <span class="dashicons <?php echo esc_attr($icon); ?>"></span>
        </span>
        <div class="yoo-activity-item__body">
            <p class="yoo-activity-item__line">
                <span class="yoo-activity-item__action"><?php echo esc_html($action_label); ?></span>
                <?php if ($subject !== '' && $url !== '') : ?>
                    <a class="yoo-activity-item__subject" href="<?php echo esc_url($url); ?>"><?php echo esc_html($subject); ?></a>
                <?php elseif ($subject !== '') : ?>
                    <span class="yoo-activity-item__subject"><?php echo esc_html($subject); ?></span>
                <?php endif; ?>
            </p>
            <div class="yoo-activity-item__meta">
                <?php if ($category_label !== '') : ?>
                    <span class="yoo-activity-item__badge"><?php echo esc_html($category_label); ?></span>
                <?php endif; ?>
                <?php if ($user_name !== '') : ?>
                    <span class="yoo-activity-item__user"><?php echo esc_html($user_name); ?></span>
                <?php endif; ?>
                <?php if ($time_label !== '') : ?>
                    <span class="yoo-activity-item__time"><?php echo esc_html($time_label); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </li>
<?php endforeach; ?>
