<?php
/**
 * YOOAdmin - Activity page template.
 *
 * @package YOOAdmin
 *
 * @var array<int, array<string, mixed>> $activity_items
 * @var array<string, string>           $categories
 * @var array<string, string>           $time_ranges
 * @var array<int, array{id:int,label:string}> $filter_users
 * @var string                          $list_url
 * @var string                          $category
 * @var string                          $range
 * @var string                          $search
 * @var int                             $user_id
 * @var int                             $paged
 * @var int                             $total
 * @var int                             $total_pages
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$search = isset($search) ? (string) $search : '';
$can_filter_admins = function_exists('yooadmin_activity_user_can_view_all') && yooadmin_activity_user_can_view_all();
$selected_user_label = __('All admins', 'yooadmin');
if ($user_id > 0) {
    foreach ($filter_users as $filter_user) {
        if ((int) ($filter_user['id'] ?? 0) === $user_id) {
            $selected_user_label = (string) ($filter_user['label'] ?? $selected_user_label);
            break;
        }
    }
}
$has_more = $paged < $total_pages;
?>

<div class="wrap yooadmin-activity-page" data-yooadmin-activity-page="true">
    <section class="yoo-activity-hero">
        <div class="yoo-activity-hero__top-row">
            <span class="yoo-activity-hero__eyebrow"><?php esc_html_e('Workspace · Activity', 'yooadmin'); ?></span>
            <div class="yoo-activity-hero__actions">
                <div class="yoo-activity-search-wrapper">
                    <span class="dashicons dashicons-search" aria-hidden="true"></span>
                    <input
                        type="search"
                        id="yoo-activity-search"
                        class="yoo-activity-search-input"
                        value="<?php echo esc_attr($search); ?>"
                        placeholder="<?php esc_attr_e('Search activity…', 'yooadmin'); ?>"
                        autocomplete="off"
                    />
                </div>

                <?php if ($can_filter_admins) : ?>
                    <div class="yoo-filter-dropdown-wrapper">
                        <button
                            type="button"
                            class="yoo-filter-btn yoo-filter-btn--author<?php echo $user_id > 0 ? ' is-active' : ''; ?>"
                            data-filter="user"
                            data-value="<?php echo esc_attr((string) $user_id); ?>"
                            aria-haspopup="listbox"
                            aria-expanded="false"
                        >
                            <span class="dashicons dashicons-admin-users" aria-hidden="true"></span>
                            <span class="yoo-filter-label"><?php echo esc_html($selected_user_label); ?></span>
                            <?php if ($user_id > 0) : ?>
                                <span class="yoo-filter-remove" data-filter="user" title="<?php esc_attr_e('Clear filter', 'yooadmin'); ?>">
                                    <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
                                </span>
                            <?php endif; ?>
                            <span class="yoo-filter-dropdown-arrow dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
                        </button>
                        <div class="yoo-filter-dropdown" role="listbox" hidden>
                            <button type="button" class="yoo-filter-option<?php echo $user_id === 0 ? ' is-selected' : ''; ?>" data-user-id="0">
                                <?php esc_html_e('All admins', 'yooadmin'); ?>
                            </button>
                            <?php foreach ($filter_users as $filter_user) : ?>
                                <button
                                    type="button"
                                    class="yoo-filter-option<?php echo (int) $filter_user['id'] === $user_id ? ' is-selected' : ''; ?>"
                                    data-user-id="<?php echo esc_attr((string) $filter_user['id']); ?>"
                                >
                                    <?php echo esc_html((string) $filter_user['label']); ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <h1>
            <span class="dashicons dashicons-backup" aria-hidden="true"></span>
            <?php esc_html_e('Activity', 'yooadmin'); ?>
            <span class="yoo-activity-hero__count">
                <?php
                /* translators: %s: number of activity events */
                echo esc_html(sprintf(__('%s events', 'yooadmin'), number_format_i18n($total)));
                ?>
            </span>
        </h1>
    </section>

    <section class="yoo-activity-content-section">
        <div class="yoo-activity-toolbar">
            <div class="yoo-activity-filters" role="toolbar" aria-label="<?php esc_attr_e('Activity category filters', 'yooadmin'); ?>">
                <?php foreach ($categories as $cat_key => $cat_label) : ?>
                    <button
                        type="button"
                        class="yoo-filter-chip<?php echo $category === $cat_key ? ' is-active' : ''; ?>"
                        data-activity-category="<?php echo esc_attr($cat_key); ?>"
                    >
                        <?php echo esc_html($cat_label); ?>
                    </button>
                <?php endforeach; ?>
            </div>

            <div class="yoo-activity-range-filters" role="toolbar" aria-label="<?php esc_attr_e('Activity time filters', 'yooadmin'); ?>">
                <?php foreach ($time_ranges as $range_key => $range_label) : ?>
                    <button
                        type="button"
                        class="yoo-filter-chip yoo-filter-chip--subtle<?php echo $range === $range_key ? ' is-active' : ''; ?>"
                        data-activity-range="<?php echo esc_attr($range_key); ?>"
                    >
                        <?php echo esc_html($range_label); ?>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="yoo-activity-list-panel">
            <ul class="yoo-activity-list" id="yoo-activity-list" aria-live="polite">
                <?php include __DIR__ . '/items-list.php'; ?>
            </ul>

            <div class="yoo-activity-infinite-status" id="yoo-activity-infinite-status" aria-live="polite">
                <div
                    class="yoo-activity-scroll-sentinel"
                    id="yoo-activity-scroll-sentinel"
                    <?php echo $has_more ? '' : 'hidden'; ?>
                ></div>
                <div class="yoo-activity-loading-more" id="yoo-activity-loading-more" hidden aria-hidden="true">
                    <div class="yp-loading-spinner" aria-hidden="true">
                        <div class="yp-spinner-circle"></div>
                    </div>
                </div>
                <p class="yoo-activity-end" id="yoo-activity-end" <?php echo (!$has_more && $total > 0) ? '' : 'hidden'; ?>>
                    <?php esc_html_e('All activity loaded.', 'yooadmin'); ?>
                </p>
            </div>
        </div>
    </section>
</div>
