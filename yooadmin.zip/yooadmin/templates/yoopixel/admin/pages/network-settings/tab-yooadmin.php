<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$defaults = function_exists('yooadmin_network_site_yooadmin_default_form_values')
    ? yooadmin_network_site_yooadmin_default_form_values()
    : (function_exists('yooadmin_network_site_yooadmin_default_provision_flags') ? yooadmin_network_site_yooadmin_default_provision_flags() : []);
$branding_settings_url = function_exists('yooadmin_network_site_yooadmin_branding_settings_url')
    ? yooadmin_network_site_yooadmin_branding_settings_url()
    : '';
$template = function_exists('yooadmin_network_site_yooadmin_get_template')
    ? yooadmin_network_site_yooadmin_get_template()
    : [];
$template_saved_at = !empty($template['saved_at']) ? (int) $template['saved_at'] : 0;
?>
<div class="yoo-network-settings-columns yoo-network-settings-yooadmin-tab">
  <div class="yoo-network-settings-column">
    <div class="yoo-network-settings-card yp-settings-card">
      <div class="yoo-network-settings-card__head">
        <span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
        <h3><?php esc_html_e('Network YOOAdmin defaults', 'yooadmin'); ?></h3>
      </div>

      <p class="description yoo-network-settings-yooadmin-tab__intro">
        <?php esc_html_e('Choose what is copied from the main site when provisioning new sites or applying defaults from a site’s YOOAdmin tab.', 'yooadmin'); ?>
        <?php if ($branding_settings_url !== '') : ?>
          <?php
          printf(
              /* translators: %s: YOOAdmin branding settings URL. */
              wp_kses_post(__('Configure branding in <a href="%s">YOOAdmin settings</a> on the main site, then save here.', 'yooadmin')),
              esc_url($branding_settings_url)
          );
          ?>
        <?php endif; ?>
      </p>

      <?php if ($template_saved_at > 0) : ?>
        <p class="description yoo-network-settings-yooadmin-tab__meta">
          <?php
          echo esc_html(
              sprintf(
                  /* translators: %s: formatted date/time. */
                  __('Template last saved: %s', 'yooadmin'),
                  wp_date(get_option('date_format') . ' ' . get_option('time_format'), $template_saved_at)
              )
          );
          ?>
        </p>
      <?php endif; ?>

      <?php
      if (function_exists('yooadmin_network_site_yooadmin_render_settings_table_open')) {
          yooadmin_network_site_yooadmin_render_settings_table_open();
          if (function_exists('yooadmin_network_site_yooadmin_render_provision_toggle_rows')) {
              yooadmin_network_site_yooadmin_render_provision_toggle_rows('yooadmin_default_', $defaults, 'yooadmin');
          }
          yooadmin_network_site_yooadmin_render_settings_table_close();
      }
      ?>
    </div>
  </div>
</div>
