<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.


if (!get_site_option('registration')) {
    update_site_option('registration', 'none');
}
$reg = (string) get_site_option('registration');

$illegal_names = get_site_option('illegal_names');
if (empty($illegal_names)) {
    $illegal_names = '';
} elseif (is_array($illegal_names)) {
    $illegal_names = implode(' ', $illegal_names);
}

$limited_email_domains = get_site_option('limited_email_domains');
if (empty($limited_email_domains)) {
    $limited_email_domains = '';
} else {
    $limited_email_domains = str_replace(' ', "\n", (string) $limited_email_domains);
    if (is_array($limited_email_domains)) {
        $limited_email_domains = implode("\n", $limited_email_domains);
    }
}

$banned_email_domains = get_site_option('banned_email_domains');
if (empty($banned_email_domains)) {
    $banned_email_domains = '';
} elseif (is_array($banned_email_domains)) {
    $banned_email_domains = implode("\n", $banned_email_domains);
}

$new_admin_email = get_site_option('new_admin_email');
?>
<div class="yoo-network-settings-columns">
  <div class="yoo-network-settings-column">
    <div class="yoo-network-settings-card">
      <div class="yoo-network-settings-card__head">
        <span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
        <h3><?php esc_html_e('Operational Settings', 'yooadmin'); ?></h3>
      </div>
      <div class="yoo-network-settings-field yoo-network-settings-field--row">
        <label for="site_name"><?php esc_html_e('Network Title', 'yooadmin'); ?></label>
        <div class="yoo-network-settings-field__control">
          <input name="site_name" type="text" id="site_name" class="regular-text" value="<?php echo esc_attr(get_network()->site_name); ?>" />
        </div>
      </div>
      <div class="yoo-network-settings-field yoo-network-settings-field--row">
        <label for="admin_email"><?php esc_html_e('Network Admin Email', 'yooadmin'); ?></label>
        <div class="yoo-network-settings-field__control">
          <input name="new_admin_email" type="email" id="admin_email" class="regular-text" value="<?php echo esc_attr((string) get_site_option('admin_email')); ?>" />
          <p class="description"><?php esc_html_e('Changing this sends a confirmation email. The new address becomes active only after confirmation.', 'yooadmin'); ?></p>
          <?php if ($new_admin_email && get_site_option('admin_email') !== $new_admin_email) : ?>
            <div class="yoo-network-settings-inline-notice">
              <?php
              echo esc_html(
                  sprintf(
                      /* translators: %s: pending admin email. */
                      __('Pending change to %s.', 'yooadmin'),
                      (string) $new_admin_email
                  )
              );
              ?>
              <a href="<?php echo esc_url(wp_nonce_url(add_query_arg('dismiss', 'new_network_admin_email', yooadmin_network_settings_url()), 'dismiss_new_network_admin_email')); ?>">
                <?php esc_html_e('Cancel', 'yooadmin'); ?>
              </a>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="yoo-network-settings-card">
      <div class="yoo-network-settings-card__head">
        <span class="dashicons dashicons-shield" aria-hidden="true"></span>
        <h3><?php esc_html_e('Registration Restrictions', 'yooadmin'); ?></h3>
      </div>
      <div class="yoo-network-settings-field">
        <label for="illegal_names"><?php esc_html_e('Banned Names', 'yooadmin'); ?></label>
        <input name="illegal_names" type="text" id="illegal_names" class="large-text" value="<?php echo esc_attr((string) $illegal_names); ?>" />
        <p class="description"><?php esc_html_e('Users cannot register these site names. Separate names with spaces.', 'yooadmin'); ?></p>
      </div>
      <div class="yoo-network-settings-field">
        <label for="limited_email_domains"><?php esc_html_e('Limited Email Registrations', 'yooadmin'); ?></label>
        <textarea name="limited_email_domains" id="limited_email_domains" rows="4" class="large-text"><?php echo esc_textarea((string) $limited_email_domains); ?></textarea>
        <p class="description"><?php esc_html_e('Limit registrations to certain domains. One domain per line.', 'yooadmin'); ?></p>
      </div>
    </div>
  </div>

  <div class="yoo-network-settings-column">
    <div class="yoo-network-settings-card">
      <div class="yoo-network-settings-card__head">
        <span class="dashicons dashicons-groups" aria-hidden="true"></span>
        <h3><?php esc_html_e('Registration Policy', 'yooadmin'); ?></h3>
      </div>

      <fieldset class="yoo-network-settings-field">
        <legend><?php esc_html_e('Allow new registrations', 'yooadmin'); ?></legend>
        <label class="yoo-network-settings-choice"><input name="registration" type="radio" value="none" <?php checked($reg, 'none'); ?> /> <?php esc_html_e('Registration is disabled', 'yooadmin'); ?></label>
        <label class="yoo-network-settings-choice"><input name="registration" type="radio" value="user" <?php checked($reg, 'user'); ?> /> <?php esc_html_e('User accounts may be registered', 'yooadmin'); ?></label>
        <label class="yoo-network-settings-choice"><input name="registration" type="radio" value="blog" <?php checked($reg, 'blog'); ?> /> <?php esc_html_e('Logged in users may register new sites', 'yooadmin'); ?></label>
        <label class="yoo-network-settings-choice"><input name="registration" type="radio" value="all" <?php checked($reg, 'all'); ?> /> <?php esc_html_e('Both sites and user accounts can be registered', 'yooadmin'); ?></label>
      </fieldset>

      <div class="yoo-network-settings-field yoo-network-settings-field--toggles">
        <label class="yoo-network-settings-choice">
          <input name="registrationnotification" type="checkbox" value="yes" <?php checked(get_site_option('registrationnotification'), 'yes'); ?> />
          <?php esc_html_e('Send the network admin an email notification when someone registers a site or user account', 'yooadmin'); ?>
        </label>
        <label class="yoo-network-settings-choice">
          <input name="add_new_users" type="checkbox" value="1" <?php checked((bool) get_site_option('add_new_users')); ?> />
          <?php esc_html_e('Allow site administrators to add new users via Users → Add User', 'yooadmin'); ?>
        </label>
      </div>
    </div>

    <div class="yoo-network-settings-card">
      <div class="yoo-network-settings-card__head">
        <span class="dashicons dashicons-email-alt" aria-hidden="true"></span>
        <h3><?php esc_html_e('Banned Email Domains', 'yooadmin'); ?></h3>
      </div>
      <div class="yoo-network-settings-field">
        <label for="banned_email_domains"><?php esc_html_e('Banned domains list', 'yooadmin'); ?></label>
        <textarea name="banned_email_domains" id="banned_email_domains" rows="6" class="large-text"><?php echo esc_textarea((string) $banned_email_domains); ?></textarea>
        <p class="description"><?php esc_html_e('Ban domains from registrations. One domain per line.', 'yooadmin'); ?></p>
      </div>
    </div>
  </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
