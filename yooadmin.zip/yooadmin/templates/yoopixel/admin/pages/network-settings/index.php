<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$tab = function_exists('yooadmin_network_settings_current_tab') ? yooadmin_network_settings_current_tab() : 'general';

// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flash message flag.
$updated = isset($_GET['updated']) && sanitize_key(wp_unslash((string) $_GET['updated'])) === 'true';

$tabs = function_exists('yooadmin_network_settings_tabs')
    ? yooadmin_network_settings_tabs('yooadmin')
    : [
        'general' => [
            'label' => __('General', 'yooadmin'),
            'icon'  => 'dashicons-admin-settings',
            'desc'  => __('Network title, admin email, and registration rules.', 'yooadmin'),
        ],
        'sites'   => [
            'label' => __('Sites & Uploads', 'yooadmin'),
            'icon'  => 'dashicons-admin-multisite',
            'desc'  => __('New site defaults, uploads, language, and menus.', 'yooadmin'),
        ],
    ];

$partials_dir = __DIR__;
?>
<div class="wrap yoo-upload-wrap yoo-network-settings-wrap" data-page="network-settings"<?php echo $updated ? ' data-flash-saved="1"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
  <div class="yoo-upload-header yoo-network-settings-header">
    <div class="yoo-upload-header-content">
      <h1 class="yoo-upload-title">
        <span class="dashicons dashicons-admin-settings yoo-upload-title-dashicon" aria-hidden="true"></span>
        <?php esc_html_e('Network Settings', 'yooadmin'); ?>
      </h1>
      <p class="yoo-upload-subtitle"><?php esc_html_e('Manage your multisite network options in a focused YOOAdmin workspace.', 'yooadmin'); ?></p>
    </div>
    <div class="yoo-upload-header-actions yoo-network-settings-header-actions">
      <button type="button" class="yp-yoo-btn yp-yoo-btn--primary" id="yoo-network-settings-save" data-save-label="<?php esc_attr_e('Save Settings', 'yooadmin'); ?>" data-saving-label="<?php esc_attr_e('Saving…', 'yooadmin'); ?>">
        <span class="dashicons dashicons-saved" aria-hidden="true"></span>
        <?php esc_html_e('Save Settings', 'yooadmin'); ?>
      </button>
    </div>
  </div>

  <form method="post" action="<?php echo esc_url(yooadmin_network_settings_url()); ?>" class="yoo-network-settings-form" id="yoo-network-settings-form" novalidate>
    <?php wp_nonce_field('yooadmin_network_settings'); ?>
    <input type="hidden" name="yooadmin_network_settings_save" value="1" />
    <input type="hidden" name="yooadmin_network_settings_tab" value="<?php echo esc_attr($tab); ?>" id="yoo-network-settings-tab-input" />

    <div class="yooadmin-settings-wrap yoo-network-settings-tabs-shell">
      <div class="yp-tabs" data-yp-tabs>
        <div class="yp-tab-nav" role="tablist" aria-label="<?php esc_attr_e('Network settings sections', 'yooadmin'); ?>">
          <?php foreach ($tabs as $tab_id => $tab_meta) :
              $active = $tab === $tab_id;
              ?>
            <button
              type="button"
              class="yp-tab<?php echo $active ? ' is-active' : ''; ?>"
              role="tab"
              aria-selected="<?php echo $active ? 'true' : 'false'; ?>"
              data-tab="<?php echo esc_attr($tab_id); ?>"
              id="yoo-network-settings-tab-<?php echo esc_attr($tab_id); ?>"
            >
              <?php echo esc_html((string) $tab_meta['label']); ?>
            </button>
          <?php endforeach; ?>
        </div>

        <div class="yp-tab-panels">
          <?php foreach ($tabs as $tab_id => $tab_meta) :
              $partial = $partials_dir . '/tab-' . $tab_id . '.php';
              $active  = $tab === $tab_id;
              ?>
            <section
              class="yp-tab-panel<?php echo $active ? ' is-active' : ''; ?>"
              id="yoo-network-settings-panel-<?php echo esc_attr($tab_id); ?>"
              data-panel="<?php echo esc_attr($tab_id); ?>"
              role="tabpanel"
              aria-labelledby="yoo-network-settings-tab-<?php echo esc_attr($tab_id); ?>"
            >
              <div class="yp-tab-intro">
                <span class="dashicons <?php echo esc_attr((string) $tab_meta['icon']); ?> yp-tab-intro-icon" aria-hidden="true"></span>
                <div class="yp-tab-intro__stack">
                  <p class="yp-tab-intro__text"><?php echo esc_html((string) $tab_meta['desc']); ?></p>
                </div>
              </div>
              <?php
              if (is_readable($partial)) {
                  include $partial;
              }
              ?>
            </section>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </form>

  <div class="yoo-network-settings-form__actions yoo-network-settings-form__actions--mobile">
    <button type="button" class="yp-yoo-btn yp-yoo-btn--primary" id="yoo-network-settings-save-mobile" data-save-label="<?php esc_attr_e('Save Settings', 'yooadmin'); ?>" data-saving-label="<?php esc_attr_e('Saving…', 'yooadmin'); ?>">
      <span class="dashicons dashicons-saved" aria-hidden="true"></span>
      <?php esc_html_e('Save Settings', 'yooadmin'); ?>
    </button>
  </div>
</div>
