<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.


$menu_perms = get_site_option('menu_items');
/** This filter is documented in wp-admin/network/settings.php */
$menu_items = apply_filters('mu_menu_items', ['plugins' => __('Plugins', 'yooadmin')]); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.

$languages    = function_exists('get_available_languages') ? get_available_languages() : [];
$translations = function_exists('wp_get_available_translations') ? wp_get_available_translations() : [];
?>
<div class="yoo-network-settings-columns">
  <div class="yoo-network-settings-column">
    <div class="yoo-network-settings-card">
      <div class="yoo-network-settings-card__head">
        <span class="dashicons dashicons-welcome-write-blog" aria-hidden="true"></span>
        <h3><?php esc_html_e('New Site Settings', 'yooadmin'); ?></h3>
      </div>

      <div class="yoo-network-settings-field">
        <label for="welcome_email"><?php esc_html_e('Welcome Email', 'yooadmin'); ?></label>
        <textarea name="welcome_email" id="welcome_email" rows="4" class="large-text"><?php echo esc_textarea((string) get_site_option('welcome_email')); ?></textarea>
      </div>
      <div class="yoo-network-settings-field">
        <label for="welcome_user_email"><?php esc_html_e('Welcome User Email', 'yooadmin'); ?></label>
        <textarea name="welcome_user_email" id="welcome_user_email" rows="4" class="large-text"><?php echo esc_textarea((string) get_site_option('welcome_user_email')); ?></textarea>
      </div>

      <div class="yoo-network-settings-field-grid">
        <div class="yoo-network-settings-field">
          <label for="first_post"><?php esc_html_e('First Post', 'yooadmin'); ?></label>
          <textarea name="first_post" id="first_post" rows="3" class="large-text"><?php echo esc_textarea((string) get_site_option('first_post')); ?></textarea>
        </div>
        <div class="yoo-network-settings-field">
          <label for="first_page"><?php esc_html_e('First Page', 'yooadmin'); ?></label>
          <textarea name="first_page" id="first_page" rows="3" class="large-text"><?php echo esc_textarea((string) get_site_option('first_page')); ?></textarea>
        </div>
      </div>

      <div class="yoo-network-settings-field">
        <label for="first_comment"><?php esc_html_e('First Comment', 'yooadmin'); ?></label>
        <textarea name="first_comment" id="first_comment" rows="3" class="large-text"><?php echo esc_textarea((string) get_site_option('first_comment')); ?></textarea>
      </div>

      <div class="yoo-network-settings-field-grid yoo-network-settings-field-grid--compact">
        <div class="yoo-network-settings-field">
          <label for="first_comment_author"><?php esc_html_e('First Comment Author', 'yooadmin'); ?></label>
          <input type="text" name="first_comment_author" id="first_comment_author" class="regular-text" value="<?php echo esc_attr((string) get_site_option('first_comment_author')); ?>" />
        </div>
        <div class="yoo-network-settings-field">
          <label for="first_comment_email"><?php esc_html_e('First Comment Email', 'yooadmin'); ?></label>
          <input type="email" name="first_comment_email" id="first_comment_email" class="regular-text" value="<?php echo esc_attr((string) get_site_option('first_comment_email')); ?>" />
        </div>
      </div>
      <div class="yoo-network-settings-field">
        <label for="first_comment_url"><?php esc_html_e('First Comment URL', 'yooadmin'); ?></label>
        <input type="url" name="first_comment_url" id="first_comment_url" class="regular-text" value="<?php echo esc_attr((string) get_site_option('first_comment_url')); ?>" />
      </div>
    </div>
  </div>

  <div class="yoo-network-settings-column">
    <div class="yoo-network-settings-card">
      <div class="yoo-network-settings-card__head">
        <span class="dashicons dashicons-upload" aria-hidden="true"></span>
        <h3><?php esc_html_e('Upload Settings', 'yooadmin'); ?></h3>
      </div>
      <div class="yoo-network-settings-field yoo-network-settings-field--inline">
        <label class="yoo-network-settings-choice">
          <input type="checkbox" id="upload_space_check_disabled" name="upload_space_check_disabled" value="0" <?php checked((bool) get_site_option('upload_space_check_disabled'), false); ?> />
          <?php esc_html_e('Limit total size of files uploaded to', 'yooadmin'); ?>
        </label>
        <div class="yoo-network-settings-inline-inputs">
          <input name="blog_upload_space" type="number" min="0" id="blog_upload_space" class="small-text" value="<?php echo esc_attr((string) get_site_option('blog_upload_space', 100)); ?>" />
          <span class="yoo-network-settings-inline-suffix"><?php esc_html_e('MB', 'yooadmin'); ?></span>
        </div>
      </div>
      <div class="yoo-network-settings-field">
        <label for="upload_filetypes"><?php esc_html_e('Upload file types', 'yooadmin'); ?></label>
        <input name="upload_filetypes" type="text" id="upload_filetypes" class="large-text" value="<?php echo esc_attr((string) get_site_option('upload_filetypes', 'jpg jpeg png gif')); ?>" />
        <p class="description"><?php esc_html_e('Allowed file types. Separate types with spaces.', 'yooadmin'); ?></p>
      </div>
      <div class="yoo-network-settings-field yoo-network-settings-field--row">
        <label for="fileupload_maxk"><?php esc_html_e('Max upload file size', 'yooadmin'); ?></label>
        <div class="yoo-network-settings-field__control">
          <div class="yoo-network-settings-inline-inputs">
            <input name="fileupload_maxk" type="number" min="0" id="fileupload_maxk" class="small-text" value="<?php echo esc_attr((string) get_site_option('fileupload_maxk', 300)); ?>" />
            <span class="yoo-network-settings-inline-suffix"><?php esc_html_e('KB', 'yooadmin'); ?></span>
          </div>
        </div>
      </div>
    </div>

    <?php if ($languages || $translations) : ?>
      <div class="yoo-network-settings-card">
        <div class="yoo-network-settings-card__head">
          <span class="dashicons dashicons-translation" aria-hidden="true"></span>
          <h3><?php esc_html_e('Language Settings', 'yooadmin'); ?></h3>
        </div>
        <div class="yoo-network-settings-field yoo-network-settings-field--row">
          <label for="WPLANG"><?php esc_html_e('Default Language', 'yooadmin'); ?></label>
          <div class="yoo-network-settings-field__control">
            <?php
            $lang = get_site_option('WPLANG');
            if (!in_array($lang, $languages, true)) {
                $lang = '';
            }
            wp_dropdown_languages(
                [
                    'name'                        => 'WPLANG',
                    'id'                          => 'WPLANG',
                    'selected'                    => $lang,
                    'languages'                   => $languages,
                    'translations'                => $translations,
                    'show_available_translations' => current_user_can('install_languages') && wp_can_install_language_pack(),
                ]
            );
            ?>
          </div>
        </div>
      </div>
    <?php endif; ?>

    <?php if ($menu_items) : ?>
      <div class="yoo-network-settings-card">
        <div class="yoo-network-settings-card__head">
          <span class="dashicons dashicons-menu" aria-hidden="true"></span>
          <h3><?php esc_html_e('Menu Settings', 'yooadmin'); ?></h3>
        </div>
        <fieldset class="yoo-network-settings-field">
          <legend><?php esc_html_e('Enable administration menus', 'yooadmin'); ?></legend>
          <?php foreach ((array) $menu_items as $key => $val) : ?>
            <label class="yoo-network-settings-choice">
              <input type="checkbox" name="menu_items[<?php echo esc_attr((string) $key); ?>]" value="1" <?php checked(isset($menu_perms[$key]) ? $menu_perms[$key] : '', '1'); ?> />
              <?php echo esc_html((string) $val); ?>
            </label>
          <?php endforeach; ?>
        </fieldset>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php
/** This action is documented in wp-admin/network/settings.php */
do_action('wpmu_options'); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
?>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
