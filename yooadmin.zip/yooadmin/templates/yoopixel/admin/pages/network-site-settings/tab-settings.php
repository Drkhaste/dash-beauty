<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.
$groups = yooadmin_network_site_settings_prepare_groups($blog_id);
?>
<div class="yoo-network-site-editor-settings">
  <div class="yoo-network-settings-columns">
    <div class="yoo-network-settings-column">
      <?php foreach ($groups['left'] as $group) : ?>
        <div class="yoo-network-settings-card">
          <div class="yoo-network-settings-card__head">
            <span class="dashicons <?php echo esc_attr((string) ($group['icon'] ?? 'dashicons-admin-settings')); ?>" aria-hidden="true"></span>
            <h3><?php echo esc_html((string) ($group['title'] ?? '')); ?></h3>
          </div>
          <?php foreach ((array) ($group['fields'] ?? []) as $option) :
              yooadmin_network_site_settings_render_field($option, $blog_id, $is_main_site);
          endforeach; ?>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="yoo-network-settings-column">
      <?php foreach ($groups['right'] as $group) : ?>
        <div class="yoo-network-settings-card">
          <div class="yoo-network-settings-card__head">
            <span class="dashicons <?php echo esc_attr((string) ($group['icon'] ?? 'dashicons-admin-settings')); ?>" aria-hidden="true"></span>
            <h3><?php echo esc_html((string) ($group['title'] ?? '')); ?></h3>
          </div>
          <?php foreach ((array) ($group['fields'] ?? []) as $option) :
              yooadmin_network_site_settings_render_field($option, $blog_id, $is_main_site);
          endforeach; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <?php if (!empty($groups['advanced'])) : ?>
    <div class="yoo-network-settings-card yoo-network-site-editor-settings-advanced">
      <div class="yoo-network-settings-card__head">
        <span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
        <h3><?php esc_html_e('Additional Options', 'yooadmin'); ?></h3>
      </div>
      <div class="yoo-network-settings-columns yoo-network-settings-columns--compact">
        <div class="yoo-network-settings-column">
          <?php
          $half = (int) ceil(count($groups['advanced']) / 2);
          foreach (array_slice($groups['advanced'], 0, $half) as $option) :
              yooadmin_network_site_settings_render_field($option, $blog_id, $is_main_site);
          endforeach;
          ?>
        </div>
        <div class="yoo-network-settings-column">
          <?php foreach (array_slice($groups['advanced'], $half) as $option) :
              yooadmin_network_site_settings_render_field($option, $blog_id, $is_main_site);
          endforeach; ?>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php do_action('wpmueditblogaction', $blog_id); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook. ?>
</div>
