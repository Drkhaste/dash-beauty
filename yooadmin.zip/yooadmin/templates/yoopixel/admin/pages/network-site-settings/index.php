<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$blog_id = function_exists('yooadmin_network_site_editor_current_id') ? yooadmin_network_site_editor_current_id() : 0;
if ($blog_id <= 0 || !function_exists('yooadmin_network_site_editor_get_site') || !yooadmin_network_site_editor_get_site($blog_id)) {
    return;
}

$details      = yooadmin_network_site_editor_get_site($blog_id);
$is_main_site = is_main_site($blog_id);
$form_url     = yooadmin_network_site_settings_url($blog_id);
$selected_tab = 'site-settings';
$page_slug    = 'network-site-settings';
$wrap_form    = true;
$form_action  = $form_url;
$form_id      = 'yoo-network-site-settings-form';
$form_nonce   = 'edit-site';
$form_hidden_action = 'update-site';
$flash_keys   = ['update'];
$panel_partial = __DIR__ . '/tab-settings.php';
$form_actions_partial = __DIR__ . '/form-actions.php';

$shell = function_exists('yooadmin_network_site_editor_shell_template') ? yooadmin_network_site_editor_shell_template() : '';
if ($shell) {
    include $shell;
}
