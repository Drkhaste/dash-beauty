<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

if ($users) : ?>
  <div class="yoo-users-grid">
    <?php foreach ($users as $user) :
        switch_to_blog($blog_id);
        $member = new WP_User($user->ID);
        $roles_display = yooadmin_translate_user_role_list($member->roles);
        restore_current_blog();
        $primary_role  = $member->roles ? reset($member->roles) : '';
        $status_badge  = in_array('administrator', $member->roles, true) ? 'administrator' : ($primary_role ?: 'standard');
        $registered    = strtotime($user->user_registered);
        $can_edit_user = function_exists('yooadmin_network_site_users_can_edit_user')
            ? yooadmin_network_site_users_can_edit_user($blog_id, (int) $user->ID)
            : false;
        $profile_url   = function_exists('yooadmin_network_site_users_edit_user_url')
            ? yooadmin_network_site_users_edit_user_url($blog_id, (int) $user->ID)
            : '';
        $is_protected  = function_exists('yooadmin_network_site_users_is_removal_protected')
            ? yooadmin_network_site_users_is_removal_protected((int) $user->ID)
            : is_super_admin((int) $user->ID);
        ?>
      <article class="yoo-user-card<?php echo $is_protected ? ' yoo-user-card--removal-protected' : ''; ?>">
        <input type="checkbox"
               class="yoo-user-checkbox"
               name="users[]"
               value="<?php echo esc_attr((string) $user->ID); ?>"
               id="yoo-network-site-user-<?php echo esc_attr((string) $user->ID); ?>"
               <?php echo $is_protected ? ' disabled data-removal-protected="1"' : ''; ?> />
        <label for="yoo-network-site-user-<?php echo esc_attr((string) $user->ID); ?>" class="yoo-user-checkbox-label"></label>
        <?php if ($can_edit_user && $profile_url !== '') : ?>
          <a href="<?php echo esc_url($profile_url); ?>" class="yoo-user-edit-icon" title="<?php esc_attr_e('Edit user', 'yooadmin'); ?>">
            <span class="dashicons dashicons-edit" aria-hidden="true"></span>
          </a>
        <?php endif; ?>

        <header class="yoo-user-card__header">
          <div class="yoo-user-avatar">
            <?php echo wp_kses_post(get_avatar($user->ID, 72)); ?>
          </div>
          <div class="yoo-user-heading">
            <h2><?php echo esc_html($user->display_name ?: $user->user_login); ?></h2>
            <span class="yoo-user-role yoo-user-role--<?php echo esc_attr(sanitize_html_class($status_badge)); ?>">
              <?php echo esc_html($roles_display ?: __('No role', 'yooadmin')); ?>
            </span>
          </div>
        </header>

        <dl class="yoo-user-meta">
          <div>
            <dt>
              <span class="dashicons dashicons-email" aria-hidden="true"></span>
              <?php esc_html_e('Email', 'yooadmin'); ?>
            </dt>
            <dd>
              <a href="mailto:<?php echo esc_attr($user->user_email); ?>">
                <?php echo esc_html($user->user_email); ?>
              </a>
            </dd>
          </div>
          <div>
            <dt>
              <span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span>
              <?php esc_html_e('Registered', 'yooadmin'); ?>
            </dt>
            <dd><?php echo esc_html(date_i18n(get_option('date_format'), $registered)); ?></dd>
          </div>
          <div>
            <dt>
              <span class="dashicons dashicons-admin-users" aria-hidden="true"></span>
              <?php esc_html_e('Username', 'yooadmin'); ?>
            </dt>
            <dd><?php echo esc_html($user->user_login); ?></dd>
          </div>
        </dl>
      </article>
    <?php endforeach; ?>
  </div>

  <?php if ($total_pages > 1) : ?>
    <nav class="yoo-users-pagination" aria-label="<?php esc_attr_e('Users pagination', 'yooadmin'); ?>">
      <?php for ($i = 1; $i <= $total_pages; $i++) :
          $page_link = add_query_arg(['paged' => $i, 'role' => $role, 's' => $search], $list_url);
          ?>
        <a class="<?php echo $i === $paged ? 'is-active' : ''; ?>" href="<?php echo esc_url($page_link); ?>"><?php echo esc_html((string) $i); ?></a>
      <?php endfor; ?>
    </nav>
  <?php endif; ?>
<?php else : ?>
  <div class="yoo-users-empty">
    <div class="yoo-empty-illustration" aria-hidden="true"></div>
    <h2><?php esc_html_e('No users match your filters', 'yooadmin'); ?></h2>
    <p><?php esc_html_e('Try adjusting your filters or add a user to this site.', 'yooadmin'); ?></p>
    <?php if ($can_add_new) : ?>
      <button type="button" class="yp-yoo-btn yp-yoo-btn--primary" data-yoo-network-site-open-modal="add-new">
        <span class="dashicons dashicons-plus-alt" aria-hidden="true"></span>
        <?php esc_html_e('Add User', 'yooadmin'); ?>
      </button>
    <?php endif; ?>
  </div>
<?php endif; ?>
