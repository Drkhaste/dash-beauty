<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$td = yooadmin_network_site_editor_text_domain();

switch_to_blog($blog_id);
$default_role = get_option('default_role');
restore_current_blog();

$has_search = ($search !== '');
$has_role   = ($role !== '');
$can_add_existing = current_user_can('promote_users') && apply_filters('show_network_site_users_add_existing_form', true); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
$can_add_new      = current_user_can('create_users') && apply_filters('show_network_site_users_add_new_form', true); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core filter.
?>
<div class="yoo-network-site-editor-users yooadmin-users-page" data-blog-id="<?php echo esc_attr((string) $blog_id); ?>">
  <div class="yoo-network-site-users-head">
      <div class="yoo-network-site-users-head__intro">
        <h2 class="yoo-network-site-users-head__title">
          <span class="dashicons dashicons-groups" aria-hidden="true"></span>
          <?php esc_html_e('Site Members', 'yooadmin'); ?>
        </h2>
        <p class="yoo-network-site-users-head__meta">
          <span id="yoo-network-site-users-total-label"><?php echo esc_html(yooadmin_network_site_users_total_label($total)); ?></span>
          <a class="yoo-clear-filters yoo-network-site-users-head__reset" id="yoo-network-site-users-reset" href="<?php echo esc_url($list_url); ?>"<?php echo ($has_search || $has_role) ? '' : ' hidden'; ?>>
            <span class="dashicons dashicons-no" aria-hidden="true"></span>
            <?php esc_html_e('Reset filters', 'yooadmin'); ?>
          </a>
        </p>
      </div>

      <div class="yoo-network-site-users-head__actions">
        <div class="yoo-users-search-wrapper">
          <span class="dashicons dashicons-search" aria-hidden="true"></span>
          <input
            type="search"
            id="yoo-network-site-users-search"
            class="yoo-users-search-input"
            value="<?php echo esc_attr($search); ?>"
            placeholder="<?php esc_attr_e('Search by name, email, or username…', 'yooadmin'); ?>"
            autocomplete="off"
          />
        </div>

        <?php if ($can_add_existing) : ?>
          <button type="button" class="yp-yoo-btn yp-yoo-btn--soft yoo-network-site-users-head__btn" data-yoo-network-site-open-modal="add-existing">
            <span class="dashicons dashicons-admin-users" aria-hidden="true"></span>
            <?php esc_html_e('Add Existing', 'yooadmin'); ?>
          </button>
        <?php endif; ?>

        <?php if ($can_add_new) : ?>
          <button type="button" class="yp-yoo-btn yp-yoo-btn--primary yoo-network-site-users-head__btn" data-yoo-network-site-open-modal="add-new">
            <span class="dashicons dashicons-plus-alt" aria-hidden="true"></span>
            <?php esc_html_e('Add User', 'yooadmin'); ?>
          </button>
        <?php endif; ?>
      </div>
    </div>

    <div class="yoo-users-toolbar yoo-network-site-users-toolbar">
      <div class="yoo-users-filters" id="yoo-network-site-users-role-filters">
        <button type="button" class="yoo-filter-chip<?php echo $has_role ? '' : ' is-active'; ?>" data-role="" data-filter="all">
          <?php esc_html_e('All roles', 'yooadmin'); ?>
        </button>
        <?php foreach ($roles as $role_key => $role_data) : ?>
          <button type="button" class="yoo-filter-chip<?php echo $role === $role_key ? ' is-active' : ''; ?>" data-role="<?php echo esc_attr($role_key); ?>" data-filter="role">
            <?php echo esc_html(yooadmin_translate_role_label((string) $role_key, $role_data)); ?>
          </button>
        <?php endforeach; ?>
      </div>
    </div>

    <form method="post" action="<?php echo esc_url($form_url); ?>" id="yoo-network-site-users-form" class="yoo-network-site-editor-users-list-form">
      <input type="hidden" name="id" value="<?php echo esc_attr((string) $blog_id); ?>" />
      <?php wp_nonce_field('bulk-users'); ?>

      <div class="yoo-bulk-actions-bar" id="yoo-network-site-users-bulk-bar" style="display: none;">
        <div class="yoo-bulk-actions-left">
          <input type="checkbox" id="yoo-network-site-select-all-users" class="yoo-network-site-users-select-all" />
          <label for="yoo-network-site-select-all-users"><?php esc_html_e('Select All', 'yooadmin'); ?></label>
          <span class="yoo-selected-count">0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
        </div>
        <div class="yoo-bulk-actions-right">
          <select id="yoo-network-site-users-bulk-action" class="yoo-bulk-select" name="action" data-yp-select-native="1">
            <option value="-1"><?php esc_html_e('Bulk Actions', 'yooadmin'); ?></option>
            <?php if (current_user_can('remove_users')) : ?>
              <option value="remove"><?php esc_html_e('Remove from site', 'yooadmin'); ?></option>
            <?php endif; ?>
            <?php if (current_user_can('promote_users')) : ?>
              <option value="promote"><?php esc_html_e('Change role', 'yooadmin'); ?></option>
            <?php endif; ?>
          </select>
          <?php if (current_user_can('promote_users')) : ?>
            <select name="new_role" id="yoo-network-site-users-new-role" class="yoo-bulk-select yoo-network-site-users-role-select" data-yp-select-native="1" style="display: none;">
              <?php
              switch_to_blog($blog_id);
              wp_dropdown_roles($default_role);
              echo '<option value="none">' . esc_html__('&mdash; No role for this site &mdash;', 'yooadmin') . '</option>';
              restore_current_blog();
              ?>
            </select>
          <?php endif; ?>
          <button type="button" id="yoo-network-site-users-bulk-apply" class="yp-yoo-btn yp-yoo-btn--primary" disabled>
            <?php esc_html_e('Apply', 'yooadmin'); ?>
          </button>
        </div>
      </div>

      <div class="yoo-network-site-users-body">
        <div class="yoo-network-site-users-loading" id="yoo-network-site-users-loading" hidden>
          <div class="yoo-loading">
            <div class="yoo-spinner-circle" aria-hidden="true"></div>
            <span class="yoo-loading-text"><?php esc_html_e('Loading…', 'yooadmin'); ?></span>
          </div>
        </div>
        <div id="yoo-network-site-users-content">
          <?php
          $partial = yooadmin_network_site_users_list_partial();
          if ($partial) {
              include $partial;
          }
          ?>
        </div>
      </div>
    </form>
</div>

<?php if ($can_add_existing) : ?>
  <div class="yoo-network-site-users-modal" id="yoo-network-site-add-existing-modal" hidden>
    <div class="yoo-network-site-users-modal__overlay">
      <div class="yoo-network-site-users-modal__content" role="dialog" aria-modal="true" aria-labelledby="yoo-network-site-add-existing-title">
        <button type="button" class="yp-modal-close" data-yoo-network-site-close-modal aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
          <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
        </button>
        <div class="yp-modal-header yoo-network-site-users-modal__header">
          <span class="yp-modal-icon dashicons dashicons-admin-users" aria-hidden="true"></span>
          <h2 class="yp-modal-title" id="yoo-network-site-add-existing-title"><?php esc_html_e('Add Existing User', 'yooadmin'); ?></h2>
        </div>
        <form action="<?php echo esc_url(add_query_arg('action', 'adduser', $form_url)); ?>" method="post">
          <input type="hidden" name="id" value="<?php echo esc_attr((string) $blog_id); ?>" />
          <div class="yp-modal-body yoo-network-site-users-modal__body">
            <div class="yoo-network-settings-field yoo-network-settings-field--row">
              <label for="yoo-network-add-existing-user"><?php esc_html_e('Username', 'yooadmin'); ?></label>
              <div class="yoo-network-settings-field__control">
                <input type="text" class="regular-text wp-suggest-user" name="newuser" id="yoo-network-add-existing-user" autocomplete="off" required />
              </div>
            </div>
            <div class="yoo-network-settings-field yoo-network-settings-field--row">
              <label for="yoo-network-add-existing-role"><?php esc_html_e('Role', 'yooadmin'); ?></label>
              <div class="yoo-network-settings-field__control">
                <select name="new_role" id="yoo-network-add-existing-role">
                  <?php
                  switch_to_blog($blog_id);
                  wp_dropdown_roles($default_role);
                  restore_current_blog();
                  ?>
                </select>
              </div>
            </div>
          </div>
          <div class="yp-modal-footer yoo-network-site-users-modal__footer">
            <button type="button" class="yp-yoo-btn yp-yoo-btn--secondary" data-yoo-network-site-close-modal><?php esc_html_e('Cancel', 'yooadmin'); ?></button>
            <?php wp_nonce_field('add-user', '_wpnonce_add-user'); ?>
            <button type="submit" name="add-user" class="yp-yoo-btn yp-yoo-btn--primary">
              <span class="dashicons dashicons-admin-users" aria-hidden="true"></span>
              <?php esc_html_e('Add Existing User', 'yooadmin'); ?>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php if ($can_add_new) : ?>
  <div class="yoo-network-site-users-modal" id="yoo-network-site-add-new-modal" hidden>
    <div class="yoo-network-site-users-modal__overlay">
      <div class="yoo-network-site-users-modal__content" role="dialog" aria-modal="true" aria-labelledby="yoo-network-site-add-new-title">
        <button type="button" class="yp-modal-close" data-yoo-network-site-close-modal aria-label="<?php esc_attr_e('Close', 'yooadmin'); ?>">
          <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
        </button>
        <div class="yp-modal-header yoo-network-site-users-modal__header">
          <span class="yp-modal-icon dashicons dashicons-plus-alt" aria-hidden="true"></span>
          <h2 class="yp-modal-title" id="yoo-network-site-add-new-title"><?php esc_html_e('Add New User', 'yooadmin'); ?></h2>
        </div>
        <form action="<?php echo esc_url(add_query_arg('action', 'newuser', $form_url)); ?>" method="post">
          <input type="hidden" name="id" value="<?php echo esc_attr((string) $blog_id); ?>" />
          <div class="yp-modal-body yoo-network-site-users-modal__body">
            <div class="yoo-network-settings-field yoo-network-settings-field--row">
              <label for="yoo-network-new-user-login"><?php esc_html_e('Username', 'yooadmin'); ?></label>
              <div class="yoo-network-settings-field__control">
                <input type="text" class="regular-text ltr" name="user[username]" id="yoo-network-new-user-login" required />
              </div>
            </div>
            <div class="yoo-network-settings-field yoo-network-settings-field--row">
              <label for="yoo-network-new-user-email"><?php esc_html_e('Email', 'yooadmin'); ?></label>
              <div class="yoo-network-settings-field__control">
                <input type="email" class="regular-text ltr" name="user[email]" id="yoo-network-new-user-email" required />
              </div>
            </div>
            <div class="yoo-network-settings-field yoo-network-settings-field--row">
              <label for="yoo-network-new-user-role"><?php esc_html_e('Role', 'yooadmin'); ?></label>
              <div class="yoo-network-settings-field__control">
                <select name="new_role" id="yoo-network-new-user-role">
                  <?php
                  switch_to_blog($blog_id);
                  wp_dropdown_roles($default_role);
                  restore_current_blog();
                  ?>
                </select>
              </div>
            </div>
            <div class="yoo-network-site-users-modal__note yoo-network-site-users-modal__note--soft" role="note">
              <span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
              <span class="yoo-network-site-users-modal__note-text"><?php esc_html_e('A password reset link will be sent to the user via email.', 'yooadmin'); ?></span>
            </div>
          </div>
          <div class="yp-modal-footer yoo-network-site-users-modal__footer">
            <button type="button" class="yp-yoo-btn yp-yoo-btn--secondary" data-yoo-network-site-close-modal><?php esc_html_e('Cancel', 'yooadmin'); ?></button>
            <?php wp_nonce_field('add-user', '_wpnonce_add-new-user'); ?>
            <button type="submit" name="add-user" class="yp-yoo-btn yp-yoo-btn--primary">
              <span class="dashicons dashicons-plus-alt" aria-hidden="true"></span>
              <?php esc_html_e('Add User', 'yooadmin'); ?>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php endif; ?>
