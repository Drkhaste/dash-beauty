<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

$blog_id = function_exists('yooadmin_network_site_editor_current_id') ? yooadmin_network_site_editor_current_id() : 0;
if ($blog_id <= 0 || !function_exists('yooadmin_network_site_editor_get_site') || !yooadmin_network_site_editor_get_site($blog_id)) {
    return;
}

$query        = yooadmin_network_site_users_query_args($blog_id);
$user_query   = new WP_User_Query($query['query_args']);
$users        = $user_query->get_results();
$total        = (int) $user_query->get_total();
$total_pages  = (int) ceil($total / max(1, (int) $query['per_page']));
$roles        = yooadmin_network_site_users_get_roles($blog_id);
$search       = (string) $query['search'];
$role         = (string) $query['role'];
$paged        = (int) $query['paged'];
$list_url     = yooadmin_network_site_users_url($blog_id);
$form_url     = $list_url;
$selected_tab = 'site-users';
$page_slug    = 'network-site-users';
$wrap_form    = false;
$flash_keys   = ['update'];
$panel_partial = __DIR__ . '/tab-users.php';

$shell = function_exists('yooadmin_network_site_editor_shell_template') ? yooadmin_network_site_editor_shell_template() : '';
if ($shell) {
    include $shell;
}
