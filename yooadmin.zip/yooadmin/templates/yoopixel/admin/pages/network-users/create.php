<?php
/**
 * YOOAdmin — Network Add User template.
 *
 * @package YOOAdmin
 *
 * @var WP_Error|null $errors
 * @var string        $message
 * @var string        $list_url
 * @var string        $form_url
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template scope.

$td = function_exists('yooadmin_network_users_text_domain') ? yooadmin_network_users_text_domain() : 'yooadmin';

// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Display-only repopulation after failed submit.
$post_user = isset($_POST['user']) && is_array($_POST['user']) ? wp_unslash($_POST['user']) : [];
$username  = isset($post_user['username']) ? sanitize_user((string) $post_user['username'], true) : '';
$email     = isset($post_user['email']) ? sanitize_email((string) $post_user['email']) : '';
?>
<div class="wrap yooadmin-user-create yooadmin-network-user-create">
    <div class="yoo-user-create-layout">
        <section class="yoo-user-form-panel">
            <div class="yoo-user-form-header">
                <span class="yoo-users-hero__eyebrow"><?php esc_html_e('Network · Invite', 'yooadmin'); ?></span>
                <h1><?php esc_html_e('Add user', 'yooadmin'); ?></h1>
                <p><?php esc_html_e('Create a new account on the network. A password reset link will be emailed to the user.', 'yooadmin'); ?></p>
            </div>

            <?php if ($message !== '') : ?>
                <div class="notice notice-success yoo-user-form-notice">
                    <p><?php echo wp_kses_post($message); ?></p>
                </div>
            <?php endif; ?>

            <?php if ($errors instanceof WP_Error && $errors->has_errors()) : ?>
                <div class="notice notice-error yoo-user-form-notice">
                    <ul>
                        <?php foreach ($errors->get_error_messages() as $err_message) : ?>
                            <li><?php echo esc_html($err_message); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url($form_url); ?>" class="yoo-user-form" id="adduser" novalidate>
                <input type="hidden" name="action" value="add-user">
                <?php wp_nonce_field('add-user', '_wpnonce_add-user'); ?>

                <div class="yoo-form-grid">
                    <div class="yoo-form-field">
                        <label for="username">
                            <?php esc_html_e('Username', 'yooadmin'); ?>
                            <span class="required">*</span>
                            <?php
                            if (function_exists('yooadmin_user_field_help_tooltip')) {
                                echo yooadmin_user_field_help_tooltip(__('Letters, numbers, and underscores only.', 'yooadmin')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                            }
                            ?>
                        </label>
                        <input
                            type="text"
                            class="regular-text"
                            name="user[username]"
                            id="username"
                            autocapitalize="none"
                            autocorrect="off"
                            maxlength="60"
                            value="<?php echo esc_attr($username); ?>"
                            required
                        >
                    </div>

                    <div class="yoo-form-field">
                        <label for="email">
                            <?php esc_html_e('Email', 'yooadmin'); ?>
                            <span class="required">*</span>
                            <?php
                            if (function_exists('yooadmin_user_field_help_tooltip')) {
                                echo yooadmin_user_field_help_tooltip(__('Used for login and password reset.', 'yooadmin')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                            }
                            ?>
                        </label>
                        <input
                            type="email"
                            class="regular-text"
                            name="user[email]"
                            id="email"
                            value="<?php echo esc_attr($email); ?>"
                            required
                        >
                    </div>
                </div>

                <p class="yoo-network-user-create__email-note">
                    <?php esc_html_e('A password reset link will be sent to the user via email.', 'yooadmin'); ?>
                </p>

                <?php
                /**
                 * Fires at the end of the new user form in network admin.
                 *
                 * @since 4.5.0
                 */
                do_action('network_user_new_form'); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
                ?>

                <div class="yoo-form-actions">
                    <a class="yp-yoo-btn yp-yoo-btn--secondary" href="<?php echo esc_url($list_url); ?>">
                        <?php esc_html_e('Cancel', 'yooadmin'); ?>
                    </a>
                    <button type="submit" name="add-user" class="yp-yoo-btn yp-yoo-btn--primary">
                        <?php esc_html_e('Add user', 'yooadmin'); ?>
                    </button>
                </div>
            </form>
        </section>

        <aside class="yoo-user-side-panel">
            <div class="yoo-side-card">
                <h3><?php esc_html_e('Network membership', 'yooadmin'); ?></h3>
                <p><?php esc_html_e('Users added without a site are subscribed to the primary site so they can manage their profile until a site is created for them.', 'yooadmin'); ?></p>
            </div>
            <div class="yoo-side-card">
                <h3><?php esc_html_e('Security checklist', 'yooadmin'); ?></h3>
                <ul class="yoo-side-checklist">
                    <li><?php esc_html_e('Use unique emails for each account', 'yooadmin'); ?></li>
                    <li><?php esc_html_e('Grant super admin only when required', 'yooadmin'); ?></li>
                    <li><?php esc_html_e('Review new accounts from the Users screen', 'yooadmin'); ?></li>
                </ul>
            </div>
        </aside>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
