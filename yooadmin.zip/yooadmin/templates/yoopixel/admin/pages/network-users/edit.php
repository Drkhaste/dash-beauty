<?php
/**
 * YOOAdmin — Network User edit.
 *
 * @package YOOAdmin
 *
 * @var WP_User   $user
 * @var WP_Error  $errors
 * @var bool      $updated
 * @var string    $list_url
 * @var string    $form_url
 * @var bool      $show_super_admin
 * @var bool      $is_super_admin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

$registration = strtotime($user->user_registered);
$sites        = yooadmin_network_users_user_sites_summary($user->ID);
?>

<div class="wrap yooadmin-user-profile yooadmin-network-user-profile">
    <header class="yoo-profile-hero">
        <a class="yoo-breadcrumb" href="<?php echo esc_url($list_url); ?>">
            <span class="dashicons dashicons-arrow-left-alt2"></span>
            <?php esc_html_e('Back to Users', 'yooadmin'); ?>
        </a>
        <div class="yoo-profile-hero__row yoo-profile-hero__row--top">
            <div class="yoo-profile-card yoo-profile-card--identity">
                <div class="yoo-profile-identity">
                    <div class="yoo-profile-avatar">
                        <?php
                        add_filter('yooadmin_avatar_use_blank_placeholder', '__return_true');
                        echo wp_kses_post(get_avatar($user->ID, 110));
                        remove_filter('yooadmin_avatar_use_blank_placeholder', '__return_true');
                        ?>
                    </div>
                    <div class="yoo-profile-info">
                        <h1 class="yoo-profile-name"><?php echo esc_html($user->display_name ?: $user->user_login); ?></h1>
                        <div class="yoo-profile-tags">
                            <span class="yoo-role-tag"><?php echo esc_html(yooadmin_network_users_user_badge($user)); ?></span>
                        </div>
                        <?php if ($sites !== '') : ?>
                        <p class="description"><?php echo esc_html($sites); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <?php if ($updated) : ?>
        <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e('User updated.', 'yooadmin'); ?></p>
        </div>
    <?php endif; ?>

    <?php if ($errors instanceof WP_Error && $errors->has_errors()) : ?>
        <div class="notice notice-error is-dismissible">
            <ul>
                <?php foreach ($errors->get_error_messages() as $message) : ?>
                    <li><?php echo esc_html($message); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($is_super_admin && $show_super_admin) : ?>
        <div class="notice notice-info">
            <p><strong><?php esc_html_e('Important:', 'yooadmin'); ?></strong> <?php esc_html_e('This user has super admin privileges.', 'yooadmin'); ?></p>
        </div>
    <?php endif; ?>

    <div class="yoo-profile-layout">
        <aside class="yoo-profile-sidebar">
            <div class="yoo-profile-panel">
                <h2><span class="dashicons dashicons-calendar-alt"></span><?php esc_html_e('Account info', 'yooadmin'); ?></h2>
                <p><?php
                printf(
                    /* translators: %s: registration date */
                    esc_html__('Registered on %s.', 'yooadmin'),
                    esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $registration))
                );
                ?></p>
                <p><?php
                printf(
                    /* translators: %d: user ID. */
                    esc_html__('User ID: #%d', 'yooadmin'),
                    (int) $user->ID
                );
                ?></p>
            </div>
        </aside>

        <main class="yoo-profile-main">
            <div class="yoo-profile-panel">
                <h2><span class="dashicons dashicons-admin-users"></span><?php esc_html_e('Edit profile', 'yooadmin'); ?></h2>
                <form method="post" action="<?php echo esc_url($form_url); ?>" class="yoo-profile-form">
                    <?php wp_nonce_field('update-user_' . $user->ID); ?>
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>">

                    <div class="yoo-form-sections">
                        <div class="yoo-form-section yoo-form-section--left">
                            <div class="yoo-form-grid">
                                <div class="yoo-form-field">
                                    <label for="yoo-first-name"><?php esc_html_e('First name', 'yooadmin'); ?></label>
                                    <input type="text" id="yoo-first-name" name="first_name" value="<?php echo esc_attr($user->first_name); ?>">
                                </div>
                                <div class="yoo-form-field">
                                    <label for="yoo-last-name"><?php esc_html_e('Last name', 'yooadmin'); ?></label>
                                    <input type="text" id="yoo-last-name" name="last_name" value="<?php echo esc_attr($user->last_name); ?>">
                                </div>
                                <div class="yoo-form-field">
                                    <label for="yoo-display-name"><?php esc_html_e('Display name', 'yooadmin'); ?></label>
                                    <input type="text" id="yoo-display-name" name="display_name" value="<?php echo esc_attr($user->display_name); ?>">
                                </div>
                                <div class="yoo-form-field">
                                    <label for="yoo-email"><?php esc_html_e('Email address', 'yooadmin'); ?> <span class="required">*</span></label>
                                    <input type="email" id="yoo-email" name="email" value="<?php echo esc_attr($user->user_email); ?>" required>
                                </div>
                                <div class="yoo-form-field">
                                    <label><?php esc_html_e('Username', 'yooadmin'); ?></label>
                                    <input type="text" value="<?php echo esc_attr($user->user_login); ?>" disabled>
                                </div>
                                <?php if ($show_super_admin) : ?>
                                <div class="yoo-form-field">
                                    <label for="super_admin">
                                        <input type="checkbox" id="super_admin" name="super_admin" value="1" <?php checked($is_super_admin); ?>>
                                        <?php esc_html_e('Grant this user super admin privileges for the Network.', 'yooadmin'); ?>
                                    </label>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="yoo-form-section yoo-form-section--right">
                            <div class="yoo-form-grid">
                                <div class="yoo-form-field">
                                    <label for="yoo-user-url"><?php esc_html_e('Website', 'yooadmin'); ?></label>
                                    <input type="url" id="yoo-user-url" name="url" value="<?php echo esc_attr($user->user_url); ?>">
                                </div>
                                <div class="yoo-form-field yoo-form-field--full">
                                    <label for="yoo-description"><?php esc_html_e('Biographical info', 'yooadmin'); ?></label>
                                    <textarea id="yoo-description" name="description" rows="4"><?php echo esc_textarea($user->description); ?></textarea>
                                </div>
                                <div class="yoo-form-field">
                                    <label for="yoo-pass1"><?php esc_html_e('New password', 'yooadmin'); ?></label>
                                    <input type="password" id="yoo-pass1" name="pass1" autocomplete="new-password">
                                </div>
                                <div class="yoo-form-field">
                                    <label for="yoo-pass2"><?php esc_html_e('Confirm new password', 'yooadmin'); ?></label>
                                    <input type="password" id="yoo-pass2" name="pass2" autocomplete="new-password">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="yoo-form-actions">
                        <button type="submit" class="yoo-button yoo-button--primary">
                            <?php esc_html_e('Update User', 'yooadmin'); ?>
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
