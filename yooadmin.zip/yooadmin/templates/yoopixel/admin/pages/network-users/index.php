<?php
/**
 * YOOAdmin — Network Users list.
 *
 * @package YOOAdmin
 *
 * @var array<int, WP_User> $users
 * @var int                 $total
 * @var int                 $total_pages
 * @var int                 $paged
 * @var string              $search
 * @var string              $role
 * @var array               $stats
 * @var array               $flash
 * @var string              $list_url
 * @var string              $new_url
 * @var string              $bulk_action
 * @var bool                $can_add
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

$has_search  = ($search !== '');
$has_role    = ($role !== '');
$flash_msg   = !empty($flash[0]) ? (string) $flash[0] : '';
$flash_type  = !empty($flash[1]) ? (string) $flash[1] : 'success';
?>

<div class="wrap yooadmin-users-page yooadmin-network-users-page">
    <?php if ($flash_msg !== '') : ?>
        <div class="notice notice-<?php echo esc_attr($flash_type); ?> is-dismissible">
            <p><?php echo esc_html($flash_msg); ?></p>
        </div>
    <?php endif; ?>

    <section class="yoo-users-hero">
        <div class="yoo-users-hero__body">
            <div class="yoo-users-hero__header">
                <div class="yoo-users-hero__title-section">
                    <div class="yoo-users-hero__top-row">
                        <span class="yoo-users-hero__eyebrow"><?php esc_html_e('Network · Directory', 'yooadmin'); ?></span>
                        <div class="yoo-users-hero__actions">
                            <form method="get" action="<?php echo esc_url($list_url); ?>" class="yoo-users-search-wrapper">
                                <input type="hidden" name="page" value="<?php echo esc_attr(yooadmin_network_users_list_page_slug()); ?>">
                                <span class="dashicons dashicons-search"></span>
                                <input type="search" name="s" class="yoo-users-search-input" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search by name, email, or username…', 'yooadmin'); ?>">
                            </form>
                            <?php if ($can_add) : ?>
                            <a class="yoo-button yoo-button--primary yoo-users-add-btn" href="<?php echo esc_url($new_url); ?>">
                                <span class="dashicons dashicons-plus-alt"></span>
                                <?php esc_html_e('Add User', 'yooadmin'); ?>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="yoo-users-hero__title-row">
                        <h1>
                            <span class="dashicons dashicons-groups"></span>
                            <?php esc_html_e('Users', 'yooadmin'); ?>
                        </h1>
                        <div class="yoo-users-hero__description-section">
                            <p><?php echo wp_kses_post(__('Manage network members, super admins, and spam status from one curated dashboard in <strong>YOOAdmin</strong>.', 'yooadmin')); ?></p>
                        </div>
                    </div>
                    <button type="button" class="yoo-users-metrics-toggle" aria-expanded="false">
                        <span class="dashicons dashicons-arrow-down-alt"></span>
                        <span><?php esc_html_e('Show Statistics', 'yooadmin'); ?></span>
                    </button>
                </div>
            </div>
        </div>

        <div class="yoo-users-hero__metrics">
            <article class="yoo-users-metric">
                <div class="yoo-users-metric__icon-wrapper">
                    <div class="yoo-users-metric__icon"><span class="dashicons dashicons-groups"></span></div>
                </div>
                <div class="yoo-users-metric__content">
                    <strong class="yoo-users-metric__value"><?php echo esc_html(number_format_i18n($stats['total'] ?? $total)); ?></strong>
                    <span class="yoo-users-metric__label"><?php esc_html_e('Total users', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-users-metric">
                <div class="yoo-users-metric__icon-wrapper">
                    <div class="yoo-users-metric__icon"><span class="dashicons dashicons-shield"></span></div>
                </div>
                <div class="yoo-users-metric__content">
                    <strong class="yoo-users-metric__value"><?php echo esc_html(number_format_i18n($stats['super_admins'] ?? 0)); ?></strong>
                    <span class="yoo-users-metric__label"><?php esc_html_e('Super Admins', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-users-metric">
                <div class="yoo-users-metric__icon-wrapper">
                    <div class="yoo-users-metric__icon"><span class="dashicons dashicons-calendar-alt"></span></div>
                </div>
                <div class="yoo-users-metric__content">
                    <strong class="yoo-users-metric__value"><?php echo esc_html(number_format_i18n($stats['new_week'] ?? 0)); ?></strong>
                    <span class="yoo-users-metric__label"><?php esc_html_e('Joined this week', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-users-metric">
                <div class="yoo-users-metric__icon-wrapper">
                    <div class="yoo-users-metric__icon"><span class="dashicons dashicons-warning"></span></div>
                </div>
                <div class="yoo-users-metric__content">
                    <strong class="yoo-users-metric__value"><?php echo esc_html(number_format_i18n($stats['spam'] ?? 0)); ?></strong>
                    <span class="yoo-users-metric__label"><?php esc_html_e('Marked as spam', 'yooadmin'); ?></span>
                </div>
            </article>
        </div>
    </section>

    <section class="yoo-users-content-section">
        <div class="yoo-users-toolbar">
            <div class="yoo-users-filters">
                <a class="yoo-filter-chip <?php echo $has_role ? '' : 'is-active'; ?>" href="<?php echo esc_url($list_url); ?>">
                    <?php esc_html_e('All users', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($stats['total'] ?? 0)); ?></span>
                </a>
                <a class="yoo-filter-chip <?php echo $role === 'super' ? 'is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('role', 'super', $list_url)); ?>">
                    <?php esc_html_e('Super Admins', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($stats['super_admins'] ?? 0)); ?></span>
                </a>
            </div>
            <?php if ($has_search || $has_role) : ?>
            <div class="yoo-users-sorts">
                <a class="yoo-clear-filters" href="<?php echo esc_url($list_url); ?>">
                    <span class="dashicons dashicons-no"></span>
                    <?php esc_html_e('Reset', 'yooadmin'); ?>
                </a>
            </div>
            <?php endif; ?>
        </div>

        <form id="yoo-network-users-bulk-form" method="post" action="<?php echo esc_url($bulk_action); ?>">
            <?php wp_nonce_field('bulk-users-network'); ?>
            <input type="hidden" name="wp_http_referer" value="<?php echo esc_url(yooadmin_network_users_list_url()); ?>">

            <div class="yoo-bulk-actions-bar" style="display: none;">
                <div class="yoo-bulk-actions-left">
                    <input type="checkbox" id="yoo-select-all-users" class="yoo-checkbox">
                    <label for="yoo-select-all-users"><?php esc_html_e('Select All', 'yooadmin'); ?></label>
                    <span class="yoo-selected-count">0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
                </div>
                <div class="yoo-bulk-actions-right">
                    <select name="action" id="yoo-network-bulk-action" class="yoo-bulk-select">
                        <option value="-1"><?php esc_html_e('Bulk Actions', 'yooadmin'); ?></option>
                        <?php if (current_user_can('delete_users')) : ?>
                        <option value="delete"><?php esc_html_e('Delete', 'yooadmin'); ?></option>
                        <?php endif; ?>
                        <option value="spam"><?php echo esc_html_x('Mark as spam', 'user', 'yooadmin'); ?></option>
                        <option value="notspam"><?php echo esc_html_x('Not spam', 'user', 'yooadmin'); ?></option>
                    </select>
                    <button type="submit" class="yoo-button yoo-button--primary" id="yoo-network-bulk-apply" disabled>
                        <?php esc_html_e('Apply', 'yooadmin'); ?>
                    </button>
                </div>
            </div>

            <div id="yoo-users-content">
                <?php if ($users) : ?>
                <div class="yoo-users-grid">
                    <?php foreach ($users as $user) : ?>
                        <?php
                        $badge       = yooadmin_network_users_user_badge($user);
                        $sites       = yooadmin_network_users_user_sites_summary($user->ID);
                        $profile_url = yooadmin_network_user_edit_url($user->ID);
                        $registered  = strtotime($user->user_registered);
                        $status_cls  = is_super_admin($user->ID) ? 'administrator' : (!empty($user->spam) ? 'spam' : 'standard');
                        ?>
                    <article class="yoo-user-card">
                        <input type="checkbox" class="yoo-user-checkbox" name="allusers[]" value="<?php echo esc_attr($user->ID); ?>" id="user-<?php echo esc_attr($user->ID); ?>">
                        <label for="user-<?php echo esc_attr($user->ID); ?>" class="yoo-user-checkbox-label"></label>
                        <a href="<?php echo esc_url($profile_url); ?>" class="yoo-user-edit-icon" title="<?php esc_attr_e('Edit user', 'yooadmin'); ?>">
                            <span class="dashicons dashicons-edit"></span>
                        </a>
                        <header class="yoo-user-card__header">
                            <div class="yoo-user-avatar">
                                <?php echo wp_kses_post(get_avatar($user->ID, 72)); ?>
                            </div>
                            <div class="yoo-user-heading">
                                <h2>
                                    <a href="<?php echo esc_url($profile_url); ?>">
                                        <?php echo esc_html($user->display_name ?: $user->user_login); ?>
                                    </a>
                                </h2>
                                <span class="yoo-user-role yoo-user-role--<?php echo esc_attr(sanitize_html_class($status_cls)); ?>">
                                    <?php echo esc_html($badge); ?>
                                </span>
                            </div>
                        </header>
                        <dl class="yoo-user-meta">
                            <div>
                                <dt><span class="dashicons dashicons-email"></span><?php esc_html_e('Email', 'yooadmin'); ?></dt>
                                <dd><a href="mailto:<?php echo esc_attr($user->user_email); ?>"><?php echo esc_html($user->user_email); ?></a></dd>
                            </div>
                            <div>
                                <dt><span class="dashicons dashicons-calendar-alt"></span><?php esc_html_e('Registered', 'yooadmin'); ?></dt>
                                <dd><?php echo esc_html(date_i18n(get_option('date_format'), $registered)); ?></dd>
                            </div>
                            <div>
                                <dt><span class="dashicons dashicons-admin-users"></span><?php esc_html_e('Username', 'yooadmin'); ?></dt>
                                <dd><?php echo esc_html($user->user_login); ?></dd>
                            </div>
                            <?php if ($sites !== '') : ?>
                            <div>
                                <dt><span class="dashicons dashicons-admin-multisite"></span><?php esc_html_e('Sites', 'yooadmin'); ?></dt>
                                <dd><?php echo esc_html($sites); ?></dd>
                            </div>
                            <?php endif; ?>
                        </dl>
                    </article>
                    <?php endforeach; ?>
                </div>

                <?php if ($total_pages > 1) : ?>
                <nav class="yoo-users-pagination" aria-label="<?php esc_attr_e('Users pagination', 'yooadmin'); ?>">
                    <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                        <?php
                        $page_link = add_query_arg(
                            [
                                'paged' => $i,
                                'role'  => $role,
                                's'     => $search,
                            ],
                            $list_url
                        );
                        ?>
                    <a class="<?php echo $i === $paged ? 'is-active' : ''; ?>" href="<?php echo esc_url($page_link); ?>">
                        <?php echo esc_html((string) $i); ?>
                    </a>
                    <?php endfor; ?>
                </nav>
                <?php endif; ?>

                <?php else : ?>
                <div class="yoo-users-empty">
                    <h2><?php esc_html_e('No users match your filters', 'yooadmin'); ?></h2>
                    <p><?php esc_html_e('Try adjusting your search or add a new network user.', 'yooadmin'); ?></p>
                    <?php if ($can_add) : ?>
                    <a class="yoo-button yoo-button--primary" href="<?php echo esc_url($new_url); ?>">
                        <?php esc_html_e('Add User', 'yooadmin'); ?>
                    </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </form>
    </section>
</div>
<script>
(function($){
  var $form = $('#yoo-network-users-bulk-form');
  if (!$form.length) return;
  var $bar = $form.find('.yoo-bulk-actions-bar');
  var $checkboxes = $form.find('.yoo-user-checkbox');
  var $selectAll = $('#yoo-select-all-users');
  var $apply = $('#yoo-network-bulk-apply');
  var $count = $form.find('.yoo-selected-count');
  function updateBar(){
    var n = $checkboxes.filter(':checked').length;
    $bar.toggle(n > 0);
    $count.text(n + ' <?php echo esc_js(__('selected', 'yooadmin')); ?>');
    $apply.prop('disabled', n === 0);
  }
  $checkboxes.on('change', updateBar);
  $selectAll.on('change', function(){ $checkboxes.prop('checked', this.checked); updateBar(); });
  $apply.on('click', function(e){
    if ($('#yoo-network-bulk-action').val() === '-1') { e.preventDefault(); }
  });
})(jQuery);
</script>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
