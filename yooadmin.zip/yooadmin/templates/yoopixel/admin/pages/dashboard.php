<?php
/**
 * YOOAdmin - Dashboard page template
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

if (!defined('YOOADMIN_PLUGIN_FILE')) {
    return;
}
$plugin_base = plugin_dir_path(YOOADMIN_PLUGIN_FILE);

$BASE   = rtrim($plugin_base, '/\\') . '/templates/yoopixel/admin';
$LAYOUT = $BASE . '/layout';
$CARDS  = $BASE . '/components/cards';


// 1) Top section (wraps Welcome + Quick Actions)
include $CARDS  . '/section-top.php';

// 2) Website Management (bottom grid)
echo '<div class="yp-dashboard-grid">';
include $CARDS . '/card-links.php';
echo '</div>';

// 3) Popup container
include $BASE . '/popup.php';
// phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound