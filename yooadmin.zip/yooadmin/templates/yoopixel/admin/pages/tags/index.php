<?php
/**
 * YOOAdmin - Tags index template
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound, WordPress.Security.NonceVerification.Recommended
// Template file. Variables are scoped to the loading function and not global. GET params are read-only filters.

$list_url = admin_url('admin.php?page=yooadmin-tags');
$search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
?>

<div class="wrap yooadmin-tags-page">
    <section class="yoo-tags-hero">
        <div class="yoo-tags-hero__body">
            <div class="yoo-tags-hero__top-row">
                <span class="yoo-tags-hero__eyebrow"><?php esc_html_e('Content · Tags', 'yooadmin'); ?></span>
                <div class="yoo-tags-hero__actions">
                    <div class="yoo-tags-search-wrapper">
                        <span class="dashicons dashicons-search"></span>
                        <input type="search" id="yoo-tags-search-input" class="yoo-tags-search-input" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search tags...', 'yooadmin'); ?>">
                    </div>
                    <button type="button" class="yoo-button yoo-button--primary" id="yoo-add-tag-btn">
                        <span class="dashicons dashicons-plus-alt"></span>
                        <?php esc_html_e('Add New', 'yooadmin'); ?>
                    </button>
                </div>
            </div>
            <h1>
                <span class="dashicons dashicons-tag"></span>
                <?php esc_html_e('Tags', 'yooadmin'); ?>
            </h1>
            <button type="button" class="yoo-tags-metrics-toggle" aria-expanded="false">
                <span class="dashicons dashicons-arrow-down-alt"></span>
                <span><?php esc_html_e('Show Statistics', 'yooadmin'); ?></span>
            </button>
        </div>

        <div class="yoo-tags-hero__metrics" style="display: none;">
            <article class="yoo-tags-metric">
                <div class="yoo-tags-metric__icon">
                    <span class="dashicons dashicons-tag"></span>
                </div>
                <div class="yoo-tags-metric__content">
                    <strong class="yoo-tags-metric__value"><?php echo esc_html(number_format_i18n($total_count)); ?></strong>
                    <span class="yoo-tags-metric__label"><?php esc_html_e('Total Tags', 'yooadmin'); ?></span>
                </div>
            </article>
            <article class="yoo-tags-metric">
                <div class="yoo-tags-metric__icon">
                    <span class="dashicons dashicons-admin-post"></span>
                </div>
                <div class="yoo-tags-metric__content">
                    <strong class="yoo-tags-metric__value"><?php echo esc_html(number_format_i18n($total_count - $empty_count)); ?></strong>
                    <span class="yoo-tags-metric__label"><?php esc_html_e('With Posts', 'yooadmin'); ?></span>
                </div>
            </article>
        </div>
    </section>

    <section class="yoo-tags-content-section">
        <div class="yoo-tags-toolbar">
            <div class="yoo-tags-filters">
                <a class="yoo-filter-chip is-active" href="<?php echo esc_url($list_url); ?>">
                    <?php esc_html_e('All', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($total_count)); ?></span>
                </a>
                <a class="yoo-filter-chip" href="<?php echo esc_url(add_query_arg('show', 'with-posts', $list_url)); ?>">
                    <?php esc_html_e('With Posts', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($total_count - $empty_count)); ?></span>
                </a>
                <a class="yoo-filter-chip" href="<?php echo esc_url(add_query_arg('show', 'empty', $list_url)); ?>">
                    <?php esc_html_e('Empty', 'yooadmin'); ?>
                    <span class="yoo-filter-count"><?php echo esc_html(number_format_i18n($empty_count)); ?></span>
                </a>
            </div>
        </div>

        <div class="yoo-bulk-actions-bar">
            <div class="yoo-bulk-actions-left">
                <input type="checkbox" id="yoo-select-all-tags" class="yoo-checkbox">
                <label for="yoo-select-all-tags"><?php esc_html_e('Select All', 'yooadmin'); ?></label>
                <span class="yoo-selected-count">0 <?php esc_html_e('selected', 'yooadmin'); ?></span>
            </div>
            <div class="yoo-bulk-actions-right">
                <select id="yoo-bulk-action-select" class="yoo-bulk-select">
                    <option value=""><?php esc_html_e('Bulk Actions', 'yooadmin'); ?></option>
                    <option value="delete"><?php esc_html_e('Delete', 'yooadmin'); ?></option>
                </select>
                <button type="button" id="yoo-bulk-apply" class="yoo-button yoo-button--primary" disabled>
                    <?php esc_html_e('Apply', 'yooadmin'); ?>
                </button>
            </div>
        </div>

        <div id="yoo-tags-content">
            <?php if (!empty($tags)): ?>
                <div class="yoo-tags-grid">
                    <?php foreach ($tags as $tag):
        $edit_url = get_edit_term_link($tag->term_id, 'post_tag');
        $view_url = get_tag_link($tag->term_id);
        $posts_count = (int)$tag->count;
?>
                    <article class="yoo-tag-card" data-tag-id="<?php echo esc_attr($tag->term_id); ?>" data-posts-count="<?php echo esc_attr($posts_count); ?>">
                        <input type="checkbox" class="yoo-tag-checkbox" value="<?php echo esc_attr($tag->term_id); ?>" id="tag-<?php echo esc_attr($tag->term_id); ?>">
                        <label for="tag-<?php echo esc_attr($tag->term_id); ?>" class="yoo-tag-checkbox-label"></label>
                        
                        <div class="yoo-tag-content">
                            <header class="yoo-tag-header">
                                <h2 class="yoo-tag-name">
                                    <a href="<?php echo esc_url($edit_url); ?>">
                                        <?php echo esc_html($tag->name); ?>
                                    </a>
                                </h2>
                            </header>
                            
                            <?php if (!empty($tag->description)): ?>
                            <p class="yoo-tag-description">
                                <?php echo esc_html(wp_trim_words($tag->description, 20)); ?>
                            </p>
                            <?php
        endif; ?>
                            
                            <div class="yoo-tag-meta">
                                <div class="yoo-tag-meta-item">
                                    <span class="dashicons dashicons-admin-post"></span>
                                    <span><?php /* translators: %d: number of posts */ echo esc_html(sprintf(_n('%d post', '%d posts', $posts_count, 'yooadmin'), $posts_count)); ?></span>
                                </div>
                                <div class="yoo-tag-meta-item">
                                    <span class="dashicons dashicons-tag"></span>
                                    <span><?php echo esc_html($tag->slug); ?></span>
                                </div>
                            </div>
                            
                            <div class="yoo-tag-actions">
                                <a href="<?php echo esc_url($view_url); ?>" target="_blank" class="yoo-action-btn">
                                    <span class="dashicons dashicons-visibility"></span>
                                    <?php esc_html_e('View', 'yooadmin'); ?>
                                </a>
                                <a href="<?php echo esc_url($edit_url); ?>" class="yoo-action-btn">
                                    <span class="dashicons dashicons-edit"></span>
                                    <?php esc_html_e('Edit', 'yooadmin'); ?>
                                </a>
                                <button class="yoo-action-btn danger delete" data-tag-id="<?php echo esc_attr($tag->term_id); ?>" data-tag-name="<?php echo esc_attr($tag->name); ?>">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php esc_html_e('Delete', 'yooadmin'); ?>
                                </button>
                            </div>
                        </div>
                    </article>
                    <?php
    endforeach; ?>
                </div>
            <?php
else: ?>
                <div class="yoo-tags-empty">
                    <div class="yoo-empty-illustration">
                        <span class="dashicons dashicons-tag"></span>
                    </div>
                    <h2><?php esc_html_e('No tags found', 'yooadmin'); ?></h2>
                    <p><?php esc_html_e('Try adjusting your search criteria.', 'yooadmin'); ?></p>
                    <button type="button" class="yoo-button yoo-button--primary" id="yoo-add-first-tag-btn">
                        <?php esc_html_e('Create first tag', 'yooadmin'); ?>
                    </button>
                </div>
            <?php
endif; ?>
        </div>
    </section>
</div>

<!-- Add Tag Modal -->
<div id="yoo-add-tag-modal">
    <div class="yoo-tag-modal-content">
        <div class="yoo-tag-modal-header">
            <h2><?php esc_html_e('Add New Tag', 'yooadmin'); ?></h2>
            <button type="button" id="yoo-tag-modal-close">&times;</button>
        </div>
        <form id="yoo-add-tag-form">
            <div class="yoo-tag-modal-body">
                <div class="yoo-tag-form-group">
                    <label>
                        <?php esc_html_e('Name', 'yooadmin'); ?>
                        <span class="required">*</span>
                    </label>
                    <input type="text" name="tag_name" id="yoo-tag-name" required>
                </div>
                <div class="yoo-tag-form-group">
                    <label><?php esc_html_e('Slug', 'yooadmin'); ?></label>
                    <input type="text" name="tag_slug" id="yoo-tag-slug">
                    <small><?php esc_html_e('Leave empty to auto-generate', 'yooadmin'); ?></small>
                </div>
                <div class="yoo-tag-form-group">
                    <label><?php esc_html_e('Description', 'yooadmin'); ?></label>
                    <textarea name="tag_description" id="yoo-tag-description" rows="4"></textarea>
                </div>
            </div>
            <div class="yoo-tag-modal-footer">
                <button type="button" id="yoo-tag-modal-cancel" class="button"><?php esc_html_e('Cancel', 'yooadmin'); ?></button>
                <button type="submit" class="button button-primary"><?php esc_html_e('Add Tag', 'yooadmin'); ?></button>
            </div>
        </form>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>








