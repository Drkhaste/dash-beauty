<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
// phpcs:disable WordPress.WP.EnqueuedResources

$page = is_array($GLOBALS['yooadmin_security_action_page'] ?? null)
    ? $GLOBALS['yooadmin_security_action_page']
    : [];

$title         = (string) ($page['title'] ?? '');
$message       = (string) ($page['message'] ?? '');
$restore_email = sanitize_email((string) ($page['restore_email'] ?? ''));
if (!is_email($restore_email)) {
    $restore_email = '';
}
$email_label   = (string) ($page['email_label'] ?? __('Email to restore', 'yooadmin'));
$error         = (string) ($page['error'] ?? '');
$action_url   = (string) ($page['action_url'] ?? '');
$hidden       = is_array($page['hidden_fields'] ?? null) ? $page['hidden_fields'] : [];
$nonce_action = (string) ($page['nonce_action'] ?? '');
$nonce_name   = (string) ($page['nonce_name'] ?? '');
$submit_label = (string) ($page['submit_label'] ?? __('Continue', 'yooadmin'));

$opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];

$logo_pack = function_exists('yooadmin_branded_public_security_page_resolve_logo_pack')
    ? yooadmin_branded_public_security_page_resolve_logo_pack()
    : [
        'url'       => '',
        'max_w'     => 150,
        'light_url' => '',
        'dark_url'  => '',
        'use_dual'  => false,
    ];

$logo_url       = (string) ($logo_pack['url'] ?? '');
$logo_light_url = (string) ($logo_pack['light_url'] ?? '');
$logo_dark_url  = (string) ($logo_pack['dark_url'] ?? '');
$logo_w         = max(60, (int) ($logo_pack['max_w'] ?? 150));
$logo_box_style = sprintf('width:%dpx;max-width:100%%;', $logo_w);
$use_dual       = !empty($logo_pack['use_dual']);
$no_logo        = ($logo_url === '' && $logo_light_url === '' && $logo_dark_url === '');

$img_bg    = ['url' => '', 'id' => 0];
$login_img = isset($opts['login_page_image_url']) ? trim((string) $opts['login_page_image_url']) : '';
if ($login_img !== '' && function_exists('yooadmin_maintenance_resolve_image_attachment')) {
    $img_bg = yooadmin_maintenance_resolve_image_attachment($login_img);
}
$img_url = $img_bg['url'] !== '' ? esc_url($img_bg['url']) : '';

$bundled_bg_url = '';
if (defined('YOOADMIN_DIR') && defined('YOOADMIN_PLUGIN_FILE')
    && is_readable(YOOADMIN_DIR . 'assets/images/login-background.jpg')) {
    $bundled_bg_url = plugins_url('assets/images/login-background.jpg', YOOADMIN_PLUGIN_FILE);
}
$has_bg = ($img_url !== '') || ($bundled_bg_url !== '');

$ar_class = (function_exists('yooadmin_custom_login_is_arabic_locale') && yooadmin_custom_login_is_arabic_locale())
    ? ' yoo-maintenance--ar'
    : '';

$color_mode = function_exists('yooadmin_custom_login_get_color_mode')
    ? yooadmin_custom_login_get_color_mode()
    : 'auto';
$color_effective = function_exists('yooadmin_custom_login_resolve_effective_color_mode')
    ? yooadmin_custom_login_resolve_effective_color_mode()
    : 'light';

$base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
$css_url   = $base_file ? plugin_dir_url($base_file) . 'assets/css/maintenance/yoo-maintenance.css' : '';
$css_path  = $base_file ? plugin_dir_path($base_file) . 'assets/css/maintenance/yoo-maintenance.css' : '';
$css_ver   = ($css_path && is_readable($css_path)) ? (string) filemtime($css_path) : '1';

$site_name = get_bloginfo('name', 'display');
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noindex, nofollow" />
    <title><?php echo esc_html($title); ?><?php echo $site_name !== '' ? ' — ' . esc_html($site_name) : ''; ?></title>
    <?php
    if (function_exists('yooadmin_branded_public_security_page_print_color_bootstrap')) {
        yooadmin_branded_public_security_page_print_color_bootstrap();
    }
    if ($img_url !== '') {
        echo '<link rel="preload" as="image" href="' . esc_url($img_url) . '" fetchpriority="high" />' . "\n";
    } elseif ($bundled_bg_url !== '') {
        echo '<link rel="preload" as="image" href="' . esc_url($bundled_bg_url) . '" fetchpriority="high" />' . "\n";
    }
    if ($css_url !== '') {
        echo '<link rel="stylesheet" href="' . esc_url($css_url) . '?ver=' . esc_attr($css_ver) . '" />' . "\n";
    }
    if (function_exists('yooadmin_public_branded_page_print_head_assets')) {
        yooadmin_public_branded_page_print_head_assets();
    }
    if (function_exists('yooadmin_branded_public_security_page_print_inline_vars')) {
        yooadmin_branded_public_security_page_print_inline_vars();
    }
    if (function_exists('yooadmin_branded_public_security_page_print_scripts')) {
        yooadmin_branded_public_security_page_print_scripts();
    }
    if ($bundled_bg_url !== '' && $has_bg && $img_url === '') {
        echo '<style id="yooadmin-public-security-welcome-fallback">body.yooadmin-public-security-page .yoo-maintenance__media{--yoo-sl-welcome-bg-image:url(\''
            . esc_url($bundled_bg_url, ['http', 'https'])
            . '\');}</style>' . "\n";
    }
    ?>
</head>
<body class="yooadmin-public-security-page yoo-maintenance<?php echo $no_logo ? ' yoo-maintenance--no-logo' : ''; ?><?php echo $has_bg ? ' yoo-maintenance--has-bg' : ''; ?><?php echo esc_attr($ar_class); ?>" data-yoo-login-color-mode="<?php echo esc_attr($color_mode); ?>" data-yoo-login-color-mode-effective="<?php echo esc_attr($color_effective); ?>">
    <div class="yoo-maintenance__shell">
        <?php if ($has_bg) : ?>
            <div class="yoo-maintenance__media" aria-hidden="true">
                <?php
                if ($img_bg['url'] !== '' && function_exists('yooadmin_maintenance_echo_fullsize_background_img')) {
                    yooadmin_maintenance_echo_fullsize_background_img($img_bg);
                } elseif (function_exists('yooadmin_maintenance_render_background_media')) {
                    yooadmin_maintenance_render_background_media();
                }
                ?>
            </div>
        <?php endif; ?>
        <div class="yoo-maintenance__panel">
            <div class="yoo-maintenance__card">
                <?php if (!$no_logo) : ?>
                    <div class="yoo-maintenance__logo" style="<?php echo esc_attr($logo_box_style); ?>">
                        <?php if ($use_dual) : ?>
                            <img class="yoo-maintenance__logo-img yoo-maintenance__logo-img--light" src="<?php echo esc_url($logo_light_url); ?>" alt="" width="<?php echo (int) $logo_w; ?>" />
                            <img class="yoo-maintenance__logo-img yoo-maintenance__logo-img--dark" src="<?php echo esc_url($logo_dark_url); ?>" alt="" width="<?php echo (int) $logo_w; ?>" />
                        <?php else : ?>
                            <img class="yoo-maintenance__logo-img" src="<?php echo esc_url($logo_url !== '' ? $logo_url : ($logo_dark_url !== '' ? $logo_dark_url : $logo_light_url)); ?>" alt="" width="<?php echo (int) $logo_w; ?>" />
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <h1 class="yoo-maintenance__title"><?php echo esc_html($title); ?></h1>

                <?php if ($error !== '') : ?>
                    <p class="yoo-security-action__error" role="alert"><?php echo esc_html($error); ?></p>
                <?php else : ?>
                    <?php if ($message !== '') : ?>
                        <p class="yoo-maintenance__message yoo-security-action__message"><?php echo esc_html($message); ?></p>
                    <?php endif; ?>
                    <?php if ($restore_email !== '') : ?>
                        <p class="yoo-security-action__email-label"><?php echo esc_html($email_label); ?></p>
                        <p class="yoo-security-action__email" dir="ltr"><?php echo esc_html($restore_email); ?></p>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if ($error === '' && $action_url !== '' && $submit_label !== '') : ?>
                    <form class="yoo-security-action__form" method="post" action="<?php echo esc_url($action_url); ?>">
                        <?php foreach ($hidden as $name => $value) : ?>
                            <input type="hidden" name="<?php echo esc_attr((string) $name); ?>" value="<?php echo esc_attr((string) $value); ?>" />
                        <?php endforeach; ?>
                        <?php
                        if ($nonce_action !== '' && $nonce_name !== '') {
                            wp_nonce_field($nonce_action, $nonce_name);
                        }
                        ?>
                        <p class="yoo-security-action__submit-row">
                            <span class="yoo-security-action__submit-wrap">
                                <button type="submit" class="yoo-security-action__submit"><?php echo esc_html($submit_label); ?></button>
                                <span class="yoo-security-action__spinner" aria-hidden="true"></span>
                            </span>
                        </p>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
