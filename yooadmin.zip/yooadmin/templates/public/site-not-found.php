<?php
/**
 * @package YOOAdmin
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
// phpcs:disable WordPress.WP.EnqueuedResources

$title   = isset($GLOBALS['yooadmin_public_site_error_title'])
    ? (string) $GLOBALS['yooadmin_public_site_error_title']
    : __('Page not found', 'yooadmin');
$message = isset($GLOBALS['yooadmin_public_site_error_message'])
    ? (string) $GLOBALS['yooadmin_public_site_error_message']
    : __('The page you requested could not be found.', 'yooadmin');

$opts = function_exists('yooadmin_get_options') ? yooadmin_get_options() : [];

$logo_pack = function_exists('yooadmin_maintenance_resolve_page_logo')
    ? yooadmin_maintenance_resolve_page_logo()
    : [
        'url'       => '',
        'max_w'     => 220,
        'light_url' => '',
        'dark_url'  => '',
        'use_dual'  => false,
    ];
$logo_url       = (string) ($logo_pack['url'] ?? '');
$logo_light_url = (string) ($logo_pack['light_url'] ?? '');
$logo_dark_url  = (string) ($logo_pack['dark_url'] ?? '');
$logo_w = function_exists('yooadmin_maintenance_get_page_logo_max_width')
    ? yooadmin_maintenance_get_page_logo_max_width()
    : max(60, (int) ($logo_pack['max_w'] ?? 150));
$logo_box_style = sprintf('width:%dpx;max-width:100%%;', (int) $logo_w);
$use_dual       = !empty($logo_pack['use_dual']);
$no_logo        = ($logo_url === '');

$img_bg = ['url' => '', 'id' => 0];
$login_img = isset($opts['login_page_image_url']) ? trim((string) $opts['login_page_image_url']) : '';
if ($login_img !== '' && function_exists('yooadmin_maintenance_resolve_image_attachment')) {
    $img_bg = yooadmin_maintenance_resolve_image_attachment($login_img);
} elseif (function_exists('yooadmin_maintenance_get_background_image')) {
    $img_bg = yooadmin_maintenance_get_background_image();
}
$img_url = $img_bg['url'] !== '' ? esc_url($img_bg['url']) : '';

$bundled_bg_url = '';
if (defined('YOOADMIN_DIR') && defined('YOOADMIN_PLUGIN_FILE')
    && is_readable(YOOADMIN_DIR . 'assets/images/login-background.jpg')) {
    $bundled_bg_url = plugins_url('assets/images/login-background.jpg', YOOADMIN_PLUGIN_FILE);
}
$has_bg = ($img_url !== '') || ($bundled_bg_url !== '');

$ar_class = (function_exists('yooadmin_custom_login_is_arabic_locale') && yooadmin_custom_login_is_arabic_locale())
    ? ' yoo-maintenance--ar'
    : '';

$base_file = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
$css_url   = $base_file ? plugin_dir_url($base_file) . 'assets/css/maintenance/yoo-maintenance.css' : '';
$css_path  = $base_file ? plugin_dir_path($base_file) . 'assets/css/maintenance/yoo-maintenance.css' : '';
$css_ver   = ($css_path && is_readable($css_path)) ? (string) filemtime($css_path) : '1';

$site_name = get_bloginfo('name', 'display');
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noindex, nofollow" />
    <title><?php echo esc_html($title); ?><?php echo $site_name !== '' ? ' — ' . esc_html($site_name) : ''; ?></title>
    <?php
    if ($css_url !== '') {
        echo '<link rel="stylesheet" href="' . esc_url($css_url) . '?ver=' . esc_attr($css_ver) . '" />' . "\n";
    }
    if (function_exists('yooadmin_public_branded_page_print_head_assets')) {
        yooadmin_public_branded_page_print_head_assets();
    }
    if (function_exists('yooadmin_public_site_error_print_inline_vars')) {
        yooadmin_public_site_error_print_inline_vars();
    }
    if ($bundled_bg_url !== '' && $has_bg && $img_url === '') {
        echo '<style id="yooadmin-public-error-welcome-fallback">body.yooadmin-public-error-page .yoo-maintenance__media{--yoo-sl-welcome-bg-image:url(\''
            . esc_url($bundled_bg_url, ['http', 'https'])
            . '\');}</style>' . "\n";
    }
    ?>
</head>
<body class="yooadmin-public-error-page yoo-maintenance<?php echo $no_logo ? ' yoo-maintenance--no-logo' : ''; ?><?php echo $has_bg ? ' yoo-maintenance--has-bg' : ''; ?><?php echo esc_attr($ar_class); ?>" data-yoo-login-color-mode="dark" data-yoo-login-color-mode-effective="dark">
    <div class="yoo-maintenance__shell">
        <?php if ($has_bg) : ?>
            <div class="yoo-maintenance__media" aria-hidden="true">
                <?php
                if ($img_bg['url'] !== '' && function_exists('yooadmin_maintenance_echo_fullsize_background_img')) {
                    yooadmin_maintenance_echo_fullsize_background_img($img_bg);
                } elseif (function_exists('yooadmin_maintenance_render_background_media')) {
                    yooadmin_maintenance_render_background_media();
                }
                ?>
            </div>
        <?php endif; ?>
        <div class="yoo-maintenance__panel">
            <div class="yoo-maintenance__card">
                <?php if (!$no_logo) : ?>
                    <div class="yoo-maintenance__logo" style="<?php echo esc_attr($logo_box_style); ?>">
                        <?php if ($use_dual) : ?>
                            <img class="yoo-maintenance__logo-img yoo-maintenance__logo-img--light" src="<?php echo esc_url($logo_light_url); ?>" alt="" width="<?php echo (int) $logo_w; ?>" style="width:100%;height:auto;display:block;" />
                            <img class="yoo-maintenance__logo-img yoo-maintenance__logo-img--dark" src="<?php echo esc_url($logo_dark_url); ?>" alt="" width="<?php echo (int) $logo_w; ?>" style="width:100%;height:auto;display:block;" />
                        <?php else : ?>
                            <img class="yoo-maintenance__logo-img" src="<?php echo esc_url($logo_url); ?>" alt="" width="<?php echo (int) $logo_w; ?>" style="width:100%;height:auto;display:block;" />
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <h1 class="yoo-maintenance__title"><?php echo esc_html($title); ?></h1>
                <p class="yoo-maintenance__message"><?php echo esc_html($message); ?></p>
            </div>
            <?php
            $footer_link = defined('YOOADMIN_SITE_URL') ? YOOADMIN_SITE_URL : 'https://www.yooadmin.io';
            $footer_ver  = defined('YOOADMIN_VERSION') ? (string) YOOADMIN_VERSION : '';
            if ($footer_ver !== '') :
                ?>
                <p class="yoo-maintenance__version">
                    <a class="yoo-maintenance__version-link" href="<?php echo esc_url($footer_link); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(sprintf(/* translators: %s: plugin version */ __('YOOAdmin %s', 'yooadmin'), $footer_ver)); ?></a>
                </p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
