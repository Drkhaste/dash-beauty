<?php
/**
 * YOOAdmin - Connect Account page template
 *
 * Assets: yooadmin_enqueue_license_page_assets() on admin_enqueue_scripts (menu.php).
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

$license_manager = YOOAdmin_License_Manager::get_instance();
$license_context = $license_manager->get_license_view_context();

$license_data = $license_context['license_data'];
$is_active = $license_context['is_active'];
$license_type_labels = $license_context['license_type_labels'];
$license_type_colors = $license_context['license_type_colors'];
$current_license_type = $license_context['current_license_type'];
$all_license_types = $license_context['all_license_types'];
?>

<div class="wrap yooadmin-license-page">
    <?php
    // Do not use wp_kses_post() here: it strips <form>, <input>, <button> (not in post HTML allowlist) and removes the activation field. Markup is from our partial; dynamic values are escaped there.
    echo $license_manager->render_license_status_markup($license_context); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    ?>

    <div id="license-notification" class="notice" style="display: none;">
        <p id="license-notification-message"></p>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
