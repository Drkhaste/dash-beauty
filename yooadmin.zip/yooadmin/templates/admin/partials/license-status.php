<?php
/**
 * YOOAdmin - Partial: Account connection status card
 *
 * @package YOOAdmin
 * @since 1.0.0
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file; variables scoped to the loading function, not global.

$_raw_status    = $license_data['status'] ?? 'inactive';
$_susp_source   = $license_data['suspension_source'] ?? '';
// Resolve: billing suspensions (non-admin source) displayed as 'expired'
$current_status = ( $_raw_status === 'suspended' && $_susp_source !== 'admin' ) ? 'expired' : $_raw_status;
$has_license    = !empty($license_data['activation_code']);
$portal_profile = (isset($portal_profile) && is_array($portal_profile) && (!empty($portal_profile['display_name']) || !empty($portal_profile['email']))) ? $portal_profile : null;
$site_domain    = isset($site_domain) ? $site_domain : '';
$has_portal_profile = !empty($portal_profile);
$is_suspended_or_revoked = in_array($current_status, ['suspended', 'revoked', 'expired'], true);
?>

<div class="yooadmin-license-status-card" data-has-portal="<?php echo esc_attr($has_portal_profile ? '1' : '0'); ?>">
    <div class="license-status-header">
        <h2><?php esc_html_e('Account Connection', 'yooadmin'); ?></h2>
        <?php if ($current_status === 'expired'): ?>
            <span class="status-badge expired">
                <span class="dashicons dashicons-calendar-alt"></span>
                <?php esc_html_e('Expired', 'yooadmin'); ?>
            </span>
        <?php elseif ($current_status === 'suspended'): ?>
            <span class="status-badge suspended">
                <span class="dashicons dashicons-warning"></span>
                <?php esc_html_e('Suspended', 'yooadmin'); ?>
            </span>
        <?php elseif ($current_status === 'revoked'): ?>
            <span class="status-badge revoked">
                <span class="dashicons dashicons-no"></span>
                <?php esc_html_e('Revoked', 'yooadmin'); ?>
            </span>
        <?php elseif ($is_active): ?>
            <span class="status-badge active">
                <span class="dashicons dashicons-yes-alt"></span>
                <?php esc_html_e('Active', 'yooadmin'); ?>
            </span>
        <?php else: ?>
            <div class="license-header-actions">
                <span class="status-badge inactive">
                    <span class="dashicons dashicons-admin-users"></span>
                    <?php esc_html_e('Not Connected', 'yooadmin'); ?>
                </span>
                <?php
                $panel_connect_url = isset($portal_connect_url) && !empty($portal_connect_url) ? $portal_connect_url : 'https://www.yooadmin.io/portal/panel-connect/';
                $origin = esc_attr(wp_parse_url(admin_url(), PHP_URL_SCHEME) . '://' . wp_parse_url(admin_url(), PHP_URL_HOST));
                $domain = isset($site_domain) ? esc_attr($site_domain) : esc_attr(wp_parse_url(get_site_url(), PHP_URL_HOST));
                $panel_connect_url = add_query_arg(['origin' => $origin, 'domain' => $domain], $panel_connect_url);
                ?>
                <a href="<?php echo esc_url($panel_connect_url); ?>" class="button button-primary yooadmin-license-action yooadmin-panel-connect-trigger" data-panel-url="<?php echo esc_attr($panel_connect_url); ?>">
                    <span class="dashicons dashicons-admin-users"></span>
                    <span><?php esc_html_e('Connect Your Account', 'yooadmin'); ?></span>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <div class="license-status-body">
        <?php if ($is_active || ($has_license && $is_suspended_or_revoked)): ?>
            <div class="license-details-container <?php echo $is_suspended_or_revoked ? 'has-overlay' : ''; ?>">
                <div class="license-details <?php echo $is_suspended_or_revoked ? 'license-suspended' : ''; ?>">
                    <div class="license-detail-item">
                        <span class="detail-label"><?php esc_html_e('Account Type:', 'yooadmin'); ?></span>
                        <span class="detail-value">
                            <span class="license-type-badge" style="background-color: <?php echo esc_attr($license_type_colors[$current_license_type] ?? '#95a5a6'); ?>">
                                <?php 
                                // Try to get label from license_type_labels (should be updated by get_license_view_context)
                                $display_name = $license_type_labels[$current_license_type] ?? null;
                                
                                // If not found, try to find in all_license_types (for custom types)
                                if (empty($display_name) && isset($all_license_types[$current_license_type])) {
                                    $display_name = $all_license_types[$current_license_type]['name'] ?? null;
                                }
                                
                                // No fuzzy matching - license_type should always be exact
                                // If not found in all_license_types, it means API sent invalid data
                                
                                // Final fallback - format the key nicely
                                if (empty($display_name)) {
                                    $display_name = ucfirst(str_replace(['-', '_'], ' ', $current_license_type));
                                }
                                
                                echo esc_html($display_name);
                                ?>
                            </span>
                        </span>
                    </div>

                    <div class="license-detail-item">
                        <span class="detail-label"><?php esc_html_e('Account Key:', 'yooadmin'); ?></span>
                        <span class="detail-value">
                            <code class="activation-code">
                                <?php
                                $activation_code = $license_data['activation_code'] ?? '';
                                if (!empty($activation_code)) {
                                    $code_parts = explode('-', $activation_code);
                                    if (count($code_parts) >= 2) {
                                        $first = $code_parts[0];
                                        $last  = $code_parts[count($code_parts) - 1];
                                        echo esc_html($first) . '-****-****-****-' . esc_html($last);
                                    } else {
                                        echo esc_html($activation_code);
                                    }
                                }
                                ?>
                            </code>
                        </span>
                    </div>

                    <div class="license-detail-item">
                        <span class="detail-label"><?php esc_html_e('Site URL:', 'yooadmin'); ?></span>
                        <span class="detail-value"><?php echo esc_html(get_site_url()); ?></span>
                    </div>

                    <?php if (!empty($license_data['usage_count'])): ?>
                        <div class="license-detail-item">
                            <span class="detail-label"><?php esc_html_e('Usage Count:', 'yooadmin'); ?></span>
                            <span class="detail-value">
                                <?php
                                echo esc_html($license_data['usage_count']);
                                if (!empty($license_data['max_usage'])) {
                                    echo ' / ' . esc_html($license_data['max_usage']);
                                }
                                ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($license_data['expires_at'])): ?>
                        <div class="license-detail-item">
                            <span class="detail-label"><?php esc_html_e('Expires:', 'yooadmin'); ?></span>
                            <span class="detail-value"><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($license_data['expires_at']))); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="license-detail-item">
                        <span class="detail-label"><?php esc_html_e('Connected:', 'yooadmin'); ?></span>
                        <span class="detail-value">
                            <?php
                            if (!empty($license_data['activated_at'])) {
                                echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($license_data['activated_at'])));
                            }
                            ?>
                        </span>
                    </div>

                    <div class="license-detail-item">
                        <span class="detail-label"><?php esc_html_e('Last Checked:', 'yooadmin'); ?></span>
                        <span class="detail-value">
                            <?php
                            if (!empty($license_data['last_checked'])) {
                                echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($license_data['last_checked'])));
                            }
                            ?>
                        </span>
                    </div>
                    
                    <?php if (!empty($portal_profile)): ?>
                        <div class="license-detail-item license-detail-portal">
                            <span class="detail-label"><?php esc_html_e('Connected Account:', 'yooadmin'); ?></span>
                            <span class="detail-value portal-account-summary">
                                <?php if (!empty($portal_profile['avatar_url'])): ?>
                                    <img class="portal-account-avatar" src="<?php echo esc_url($portal_profile['avatar_url']); ?>" alt="<?php echo esc_attr($portal_profile['display_name'] ?? $portal_profile['email'] ?? ''); ?>">
                                <?php endif; ?>
                                <span class="portal-account-meta">
                                    <strong class="portal-account-name">
                                        <?php echo esc_html($portal_profile['display_name'] ?: ($portal_profile['email'] ?? __('YOOPixel Account', 'yooadmin'))); ?>
                                    </strong>
                                    <?php if (!empty($portal_profile['email'])): ?>
                                        <span class="portal-account-email"><?php echo esc_html($portal_profile['email']); ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($portal_profile['synced_at'])): ?>
                                        <span class="portal-account-synced">
                                            <?php
                                            printf(
                                                '%s',
                                                esc_html(
                                                    sprintf(
                                                        /* translators: %s: date and time */
                                                        __('Linked on %s', 'yooadmin'),
                                                        date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($portal_profile['synced_at']))
                                                    )
                                                )
                                            );
                                            ?>
                                        </span>
                                    <?php endif; ?>
                                </span>
                            </span>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($is_suspended_or_revoked): ?>
                    <?php
                    $overlay_status = $license_data['status'] ?? 'suspended';
                    $is_expired_overlay = $overlay_status === 'expired';
                    ?>
                    <div class="license-overlay">
                        <div class="overlay-content">
                            <span class="dashicons <?php echo $is_expired_overlay ? 'dashicons-calendar-alt' : 'dashicons-warning'; ?>" <?php echo $is_expired_overlay ? 'style="color:#eda934"' : ''; ?>></span>
                            <h3>
                                <?php
                                if ($overlay_status === 'expired') {
                                    esc_html_e('Connection Expired', 'yooadmin');
                                } elseif ($overlay_status === 'suspended') {
                                    esc_html_e('Connection Suspended', 'yooadmin');
                                } else {
                                    esc_html_e('Connection Revoked', 'yooadmin');
                                }
                                ?>
                            </h3>

                            <?php if ($is_expired_overlay): ?>
                                <p class="overlay-reason"><?php esc_html_e('Your account connection has expired. Please renew your subscription to continue receiving updates and Extended features.', 'yooadmin'); ?></p>
                                <a href="https://www.yooadmin.io/portal/billing/" target="_blank" class="button button-primary overlay-support-btn" style="background:#eda934;border-color:#eda934;">
                                    <?php esc_html_e('Renew Now', 'yooadmin'); ?>
                                </a>
                            <?php else: ?>
                                <?php if (!empty($license_data['status_reason'])): ?>
                                    <p class="overlay-reason"><?php echo esc_html($license_data['status_reason']); ?></p>
                                <?php endif; ?>
                                <a href="https://www.yooadmin.io/support/" target="_blank" class="button button-primary overlay-support-btn">
                                    <?php esc_html_e('Contact Support', 'yooadmin'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="yooadmin-extended-notice">
                <p class="yooadmin-extended-notice__text">
                    <?php esc_html_e('Your account is connected. Visit your account page to see what\'s available.', 'yooadmin'); ?>
                    <a href="https://www.yooadmin.io/#account" target="_blank" rel="noopener noreferrer" class="yooadmin-extended-notice__link">yooadmin.io</a>
                </p>
            </div>

            <div class="license-actions">
                <a href="https://www.yooadmin.io/portal" target="_blank" rel="noopener noreferrer" class="button button-primary">
                    <span class="dashicons dashicons-external"></span>
                    <span><?php esc_html_e('Visit Account Page', 'yooadmin'); ?></span>
                </a>

                <button type="button" class="button button-secondary" id="check-license-btn">
                    <span class="dashicons dashicons-update"></span>
                    <?php esc_html_e('Refresh Connection', 'yooadmin'); ?>
                </button>

                <button type="button" class="button button-link-delete" id="deactivate-license-btn">
                    <span class="dashicons dashicons-no"></span>
                    <?php esc_html_e('Disconnect Account', 'yooadmin'); ?>
                </button>
            </div>

        <?php else: ?>
            <div class="license-activation-wrapper">
                <div class="license-activation-form">
                    <div class="form-card">
                        <p class="description">
                            <?php esc_html_e('Enter the account key from your YOOAdmin account to link this site.', 'yooadmin'); ?>
                        </p>

                        <form id="license-activation-form">
                    <div class="form-group">
                        <label for="activation-code-input">
                            <?php esc_html_e('Account Key', 'yooadmin'); ?>
                        </label>
                        <input
                            type="text"
                            id="activation-code-input"
                            name="activation_code"
                            class="regular-text code"
                            placeholder="XXXX-XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
                            required
                        >
                        <p class="description">
                            <?php esc_html_e('Format: XXXX-XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX', 'yooadmin'); ?>
                        </p>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="button button-primary button-hero" id="activate-license-btn">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php esc_html_e('Connect Account', 'yooadmin'); ?>
                        </button>
                    </div>
                        </form>
                    </div>

                <div class="license-help">
                    <h3><?php esc_html_e('Need Help?', 'yooadmin'); ?></h3>
                    <ul>
                        <li>
                            <span class="dashicons dashicons-admin-links"></span>
                            <?php
                            $panel_connect_url_help = isset($portal_connect_url) && !empty($portal_connect_url) ? $portal_connect_url : 'https://www.yooadmin.io/portal/panel-connect/';
                            $origin_help = esc_attr(wp_parse_url(admin_url(), PHP_URL_SCHEME) . '://' . wp_parse_url(admin_url(), PHP_URL_HOST));
                            $domain_help = isset($site_domain) ? esc_attr($site_domain) : esc_attr(wp_parse_url(get_site_url(), PHP_URL_HOST));
                            $panel_connect_url_help = add_query_arg(['origin' => $origin_help, 'domain' => $domain_help], $panel_connect_url_help);
                            ?>
                            <a href="<?php echo esc_url($panel_connect_url_help); ?>" class="yooadmin-panel-connect-trigger" data-panel-url="<?php echo esc_attr($panel_connect_url_help); ?>">
                                <?php esc_html_e('Create Free Account', 'yooadmin'); ?>
                            </a>
                        </li>
                        <li>
                            <span class="dashicons dashicons-sos"></span>
                            <a href="https://www.yooadmin.io/support/" target="_blank">
                                <?php esc_html_e('Contact Support', 'yooadmin'); ?>
                            </a>
                        </li>
                        <li>
                            <span class="dashicons dashicons-book"></span>
                            <a href="https://yooadmin.io/docs/" target="_blank">
                                <?php esc_html_e('Documentation', 'yooadmin'); ?>
                            </a>
                        </li>
                    </ul>
                </div>
                </div>

                <div class="license-benefits-sidebar">
                    <div class="benefits-card">
                        <div class="benefits-header">
                            <span class="dashicons dashicons-admin-users"></span>
                            <h3><?php esc_html_e('Why Connect?', 'yooadmin'); ?></h3>
                        </div>
                        <p class="benefits-card__lead">
                            <?php esc_html_e('Linking your YOOAdmin account gives you access to account features.', 'yooadmin'); ?>
                        </p>
                        <a href="https://www.yooadmin.io/portal" target="_blank" rel="noopener noreferrer" class="benefits-card__link">
                            <?php esc_html_e('Learn more →', 'yooadmin'); ?>
                        </a>
                        <p class="benefits-card__note">
                            <?php esc_html_e('YOOAdmin works fully without an account. Connecting is optional and free.', 'yooadmin'); ?>
                        </p>
                    </div>

                    <div class="benefits-card benefits-card-secondary">
                        <div class="benefits-header">
                            <span class="dashicons dashicons-info"></span>
                            <h3><?php esc_html_e('Free Account', 'yooadmin'); ?></h3>
                        </div>
                        <p class="benefits-text">
                            <?php esc_html_e('Create a free YOOAdmin account to get your account key. No credit card required.', 'yooadmin'); ?>
                        </p>
                        <?php
                        $panel_connect_url_free = isset($portal_connect_url) && !empty($portal_connect_url) ? $portal_connect_url : 'https://www.yooadmin.io/portal/panel-connect/';
                        $origin_free = esc_attr(wp_parse_url(admin_url(), PHP_URL_SCHEME) . '://' . wp_parse_url(admin_url(), PHP_URL_HOST));
                        $domain_free = isset($site_domain) ? esc_attr($site_domain) : esc_attr(wp_parse_url(get_site_url(), PHP_URL_HOST));
                        $panel_connect_url_free = add_query_arg(['origin' => $origin_free, 'domain' => $domain_free], $panel_connect_url_free);
                        ?>
                        <a href="<?php echo esc_url($panel_connect_url_free); ?>" class="button button-secondary benefits-cta yooadmin-panel-connect-trigger" data-panel-url="<?php echo esc_attr($panel_connect_url_free); ?>">
                            <span class="dashicons dashicons-external"></span>
                            <span><?php esc_html_e('Create Free Account', 'yooadmin'); ?></span>
                        </a>
                    </div>
                </div>
            </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
