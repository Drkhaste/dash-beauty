<?php
/**
 * Studio Hub — theme bootstrap (loaded by YOOAdmin theme manager from manifest.json).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

require_once __DIR__ . '/includes/bootstrap/loaders.php';
require_once __DIR__ . '/includes/studio-hub-menu-split.php';
require_once __DIR__ . '/includes/studio-hub-tips.php';
if (!function_exists('yooadmin_studio_hub_register_dashboard_widget_hooks')) {
    require_once __DIR__ . '/includes/studio-hub-dashboard-widgets.php';
}
require_once __DIR__ . '/includes/studio-hub-builtin-dashboard-cards.php';
require_once __DIR__ . '/includes/bootstrap/hooks.php';
