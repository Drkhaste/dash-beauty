<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

/**
 * Studio Hub — compact workspace shortcuts for non-administrator users (top row).
 */

$split = isset($studio_hub_split) && is_array($studio_hub_split)
    ? $studio_hub_split
    : (function_exists('yooadmin_build_admin_menu_tree') && function_exists('yooadmin_studio_hub_split_menu_tree')
        ? yooadmin_studio_hub_split_menu_tree((array) yooadmin_build_admin_menu_tree())
        : ['core' => [], 'extensions' => []]);

$core_items = function_exists('yooadmin_get_regular_user_shortcut_items')
    ? yooadmin_get_regular_user_shortcut_items()
    : (isset($split['core']) && is_array($split['core']) ? $split['core'] : []);
$title      = function_exists('yooadmin_regular_user_shortcuts_title')
    ? yooadmin_regular_user_shortcuts_title()
    : __('Shortcuts', 'yooadmin');
?>
<div class="yp-card yp-card-full yp-studio-quick-actions yp-studio-surface-card yp-studio-workspace-shortcuts"
     data-layout-locked="true">
    <div class="yp-card-header yp-section-header yp-studio-qa-header">
        <h2 class="yp-card-title yp-section-title">
            <span class="dashicons dashicons-layout" aria-hidden="true"></span>
            <?php echo esc_html($title); ?>
        </h2>
    </div>

    <div class="yp-studio-qa-body yp-studio-section-body">
        <div class="yp-action-grid yp-quick-actions" data-quick-actions-grid>
            <?php
            $rendered = 0;
            foreach ($core_items as $item) :
                if ($rendered >= 12 || !is_array($item)) {
                    break;
                }
                $label = isset($item['title']) ? (string) $item['title'] : '';
                $url   = isset($item['url']) ? (string) $item['url'] : '';
                $icon  = isset($item['icon']) ? trim((string) $item['icon']) : '';
                if ($label === '' || $url === '' || $icon === '') {
                    continue;
                }
                if (function_exists('yooadmin_user_can_access_admin_href') && !yooadmin_user_can_access_admin_href($url)) {
                    continue;
                }
                $rendered++;
                ?>
                <div class="qa-tile">
                    <a href="<?php echo esc_url($url); ?>"
                       class="yp-icon-tile qa-tile-link yp-studio-qa-tile"
                       target="_self"
                       rel="nofollow">
                        <span class="yp-studio-qa-tile__icon-well" aria-hidden="true">
                            <span class="dashicons <?php echo esc_attr(strpos($icon, 'dashicons') === 0 ? $icon : 'dashicons-' . ltrim($icon, 'dashicons-')); ?>"></span>
                        </span>
                        <span class="yp-icon-label"><?php echo esc_html(wp_strip_all_tags($label)); ?></span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
