<?php
/**
 * Studio Hub — Workspace Notes aside section.
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

if (!apply_filters('yooadmin_workspace_notes_enabled', true)) {
    return;
}

if (!function_exists('yooadmin_workspace_notes_types')) {
    return;
}

$ws_note_types    = yooadmin_workspace_notes_types();
$ws_active_type   = function_exists('yooadmin_workspace_notes_get_active_type')
    ? yooadmin_workspace_notes_get_active_type()
    : 'todos';
$ws_active_def    = $ws_note_types[ $ws_active_type ] ?? reset($ws_note_types);
$ws_page_size = function_exists('yooadmin_workspace_notes_page_size')
    ? yooadmin_workspace_notes_page_size()
    : 3;
$ws_notes_page = function_exists('yooadmin_workspace_notes_list_page')
    ? yooadmin_workspace_notes_list_page(get_current_user_id(), $ws_active_type, 0, $ws_page_size)
    : ['notes' => [], 'has_more' => false];
$ws_initial_notes  = isset($ws_notes_page['notes']) && is_array($ws_notes_page['notes']) ? $ws_notes_page['notes'] : [];
$ws_notes_has_more = !empty($ws_notes_page['has_more']);
$ws_show_check     = in_array($ws_active_type, ['todos', 'reminders'], true);
?>
<div class="yp-studio-aside-card yp-dashboard-section yp-studio-aside-layout-section yp-studio-workspace-notes-card"
     data-section-id="studio-workspace-notes"
     data-layout-section="true"
     data-collapsible="false"
     data-sortable="true"
     data-collapsed="false"
     data-custom-placement="aside"
     data-workspace-notes="true"<?php echo function_exists('yooadmin_studio_hub_section_hidden_attrs') ? yooadmin_studio_hub_section_hidden_attrs('studio-workspace-notes') : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
  <div class="yp-card-header yp-section-header yp-layout-section-handle">
    <span class="yp-layout-section-drag-handle" aria-hidden="true">
      <span class="dashicons dashicons-move" aria-hidden="true"></span>
    </span>
    <h2 class="yp-card-title yp-section-title yp-studio-aside-section__title">
      <span class="dashicons dashicons-book-alt" aria-hidden="true"></span>
      <span class="yp-studio-aside-section__title-label"><?php echo esc_html(function_exists('yooadmin_workspace_notes_section_title') ? yooadmin_workspace_notes_section_title() : __('Workspace Notes', 'yooadmin')); ?></span>
    </h2>
    <div class="yp-card-header-actions">
      <button type="button"
              class="yp-layout-section-remove"
              aria-label="<?php esc_attr_e('Remove section', 'yooadmin'); ?>"
              aria-hidden="true">
        <span class="dashicons dashicons-trash" aria-hidden="true"></span>
      </button>
    </div>
  </div>

  <?php include __DIR__ . '/partials/dashboard-card-workspace-notes-body.php'; ?>
</div>
