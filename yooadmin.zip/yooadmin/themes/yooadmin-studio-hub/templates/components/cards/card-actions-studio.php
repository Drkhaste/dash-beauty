<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

/**
 * Studio Hub — Quick Actions (single-site dashboard; network uses card-actions-network.php).
 */

$defaults = function_exists('yooadmin_dashboard_quick_actions_defaults')
    ? yooadmin_dashboard_quick_actions_defaults()
    : [
        [
            'label'  => __('Add Post', 'yooadmin'),
            'url'    => admin_url('post-new.php'),
            'icon'   => 'dashicons-welcome-write-blog',
            'target' => '_self',
        ],
        [
            'label'  => __('Add Page', 'yooadmin'),
            'url'    => admin_url('post-new.php?post_type=page'),
            'icon'   => 'dashicons-admin-page',
            'target' => '_self',
        ],
        [
            'label'  => __('Media', 'yooadmin'),
            'url'    => admin_url('upload.php'),
            'icon'   => 'dashicons-admin-media',
            'target' => '_self',
        ],
        [
            'label'  => __('Users', 'yooadmin'),
            'url'    => admin_url('admin.php?page=yooadmin-users'),
            'icon'   => 'dashicons-groups',
            'target' => '_self',
        ],
        [
            'label'  => __('Comments', 'yooadmin'),
            'url'    => admin_url('edit-comments.php'),
            'icon'   => 'dashicons-admin-comments',
            'target' => '_self',
        ],
        [
            'label'  => __('Settings', 'yooadmin'),
            'url'    => admin_url('admin.php?page=yooadmin-settings'),
            'icon'   => 'dashicons-admin-settings',
            'target' => '_self',
        ],
    ];
$base_defaults = $defaults;

$items = function_exists('yooadmin_get_quick_actions_for_current_user')
    ? yooadmin_get_quick_actions_for_current_user()
    : $defaults;

if (function_exists('yooadmin_filter_items_by_admin_href_capability')) {
    $display_defaults = yooadmin_filter_items_by_admin_href_capability($defaults, 'url');
} else {
    $display_defaults = $defaults;
}

$yooadmin_can_edit_quick_actions = function_exists('yooadmin_user_can_edit_quick_actions')
    && yooadmin_user_can_edit_quick_actions();
?>
<div class="yp-card yp-card-full yp-studio-quick-actions yp-studio-surface-card"
     data-quick-actions-card
     data-default-actions="<?php echo esc_attr(wp_json_encode($display_defaults)); ?>">
    <div class="yp-card-header yp-section-header yp-studio-qa-header">
        <h2 class="yp-card-title yp-section-title">
            <span class="dashicons dashicons-admin-tools" aria-hidden="true"></span>
            <?php esc_html_e('Quick Actions', 'yooadmin'); ?>
        </h2>
        <?php if ($yooadmin_can_edit_quick_actions) : ?>
        <div class="yp-card-toolbar qa-toolbar">
            <button type="button"
                    class="qa-reset"
                    data-icon-edit-reset="quick-actions"
                    hidden>
                <?php esc_html_e('Reset', 'yooadmin'); ?>
            </button>
            <button type="button"
                    class="qa-toggle"
                    data-qa-toggle
                    data-label-edit="<?php echo esc_attr__('Edit', 'yooadmin'); ?>"
                    data-label-done="<?php echo esc_attr__('Done', 'yooadmin'); ?>"
                    aria-pressed="false"
                    aria-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>">
                <span class="dashicons dashicons-edit" aria-hidden="true"></span>
            </button>
        </div>
        <?php endif; ?>
    </div>

    <div class="yp-studio-qa-body yp-studio-section-body">
        <div class="yp-quick-actions-loading yp-studio-section-loading" aria-hidden="false">
            <div class="yp-loading-spinner">
                <div class="yp-spinner-circle"></div>
            </div>
        </div>

        <div class="yp-action-grid yp-quick-actions" data-quick-actions-grid data-max-items="24">
        <?php
        $rendered = 0;
        foreach ($items as $it) :
            if ($rendered >= 24) {
                break;
            }
            $label      = isset($it['label']) ? (string) $it['label'] : '';
            $url        = isset($it['url']) ? (string) $it['url'] : '';
            $icon       = isset($it['icon']) ? (string) $it['icon'] : 'dashicons-admin-links';
            $target     = isset($it['target']) ? (string) $it['target'] : '_self';
            $aria_label = isset($it['aria_label']) ? (string) $it['aria_label'] : '';
            if ($label === '' || $url === '') {
                continue;
            }
            $rendered++;
            ?>
        <div class="qa-tile"
             data-qa-label="<?php echo esc_attr($label); ?>"
             data-qa-url="<?php echo esc_url($url); ?>"
             data-qa-icon="<?php echo esc_attr($icon); ?>"
             data-qa-target="<?php echo esc_attr($target === '_self' ? '_self' : '_blank'); ?>"
            <?php if ($aria_label !== '') : ?>
             data-qa-aria-label="<?php echo esc_attr($aria_label); ?>"
            <?php endif; ?>>
            <span class="qa-tile-drag-handle" aria-hidden="true">
                <span class="dashicons dashicons-move" aria-hidden="true"></span>
            </span>
            <a href="<?php echo esc_url($url); ?>"
               class="yp-icon-tile qa-tile-link yp-studio-qa-tile"
               target="<?php echo ($target === '_self') ? '_self' : '_blank'; ?>"
               rel="<?php echo ($target === '_blank') ? 'noopener noreferrer' : 'nofollow'; ?>"
                <?php if ($aria_label !== '') : ?>
               aria-label="<?php echo esc_attr($aria_label); ?>"
                <?php endif; ?>>
                <span class="yp-studio-qa-tile__icon-well" aria-hidden="true">
                    <span class="dashicons <?php echo esc_attr($icon); ?>"></span>
                </span>
                <span class="yp-icon-label"><?php echo esc_html($label); ?></span>
            </a>
            <div class="qa-tile-actions yp-studio-card-edit-actions" aria-hidden="true">
                <button type="button" class="qa-tile-edit yp-card-icon-edit" aria-label="<?php esc_attr_e('Edit quick action', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-edit" aria-hidden="true"></span>
                </button>
                <button type="button" class="qa-tile-delete yp-card-icon-edit yp-qa-tile-delete" aria-label="<?php esc_attr_e('Delete quick action', 'yooadmin'); ?>">
                    <span class="dashicons dashicons-trash" aria-hidden="true"></span>
                </button>
            </div>
        </div>
            <?php
        endforeach;
        ?>

        <?php if ($yooadmin_can_edit_quick_actions) : ?>
        <div class="qa-tile qa-tile--add-slot">
            <button type="button"
                    class="yp-icon-tile qa-add-tile yp-studio-qa-tile"
                    data-qa-add
                    aria-label="<?php esc_attr_e('Add quick action', 'yooadmin'); ?>">
                <span class="yp-studio-qa-tile__icon-well" aria-hidden="true">
                    <span class="dashicons dashicons-plus-alt2"></span>
                </span>
                <span class="yp-icon-label"><?php esc_html_e('Add', 'yooadmin'); ?></span>
            </button>
        </div>
        <?php endif; ?>
        </div>

        <nav class="yp-studio-qa-nav" data-qa-nav hidden aria-label="<?php esc_attr_e('Quick actions pages', 'yooadmin'); ?>">
            <button type="button" class="yp-studio-qa-nav__btn" data-qa-prev aria-label="<?php esc_attr_e('Previous page', 'yooadmin'); ?>">
                <span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span>
            </button>
            <span class="yp-studio-qa-nav__label" data-qa-nav-label aria-live="polite"></span>
            <button type="button" class="yp-studio-qa-nav__btn" data-qa-next aria-label="<?php esc_attr_e('Next page', 'yooadmin'); ?>">
                <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
            </button>
        </nav>
        <div class="yp-studio-qa-dots" data-qa-dots hidden aria-hidden="true"></div>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
