<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

/**
 * Studio Hub — welcome block (headline, greeting, intro + date/time; no Visit Site CTA).
 */

$defaults = [
    'title' => __('Welcome', 'yooadmin'),
    'p1'    => function_exists('yooadmin_welcome_card_user_greeting')
        ? yooadmin_welcome_card_user_greeting()
        : __('Hi! 👋', 'yooadmin'),
    'p2'    => __('Welcome to Studio Hub by YOOAdmin, designed to help you manage WordPress with more focus, clarity, and control.', 'yooadmin'),
];

$data = function_exists('yooadmin_welcome_studio_card_content')
    ? yooadmin_welcome_studio_card_content($defaults)
    : $defaults;
$data = apply_filters('yooadmin_studio_hub_card_welcome_content', $data);

$welcome_ts   = current_time('timestamp');
$welcome_date = wp_date((string) get_option('date_format', 'M j, Y'), $welcome_ts);
$welcome_time = wp_date('h:i:s A', $welcome_ts);
$welcome_iso = wp_date('c', $welcome_ts);

$welcome_links = [
    [
        'icon'   => 'dashicons-admin-generic',
        'label'  => __('Customize', 'yooadmin'),
        'url'    => admin_url('admin.php?page=yooadmin-settings'),
    ],
    [
        'icon'   => 'dashicons-admin-appearance',
        'label'  => __('Theme Colors', 'yooadmin'),
        'url'    => admin_url('admin.php?page=yooadmin-admin-theme-settings'),
    ],
    [
        'icon'    => 'dashicons-warning',
        'label'   => __('Report Bug', 'yooadmin'),
        'url'     => 'https://www.yooadmin.io/report-bug',
        'target'  => '_blank',
    ],
];
$welcome_links = apply_filters('yooadmin_card_welcome_links', $welcome_links);
$welcome_links = apply_filters('yooadmin_studio_hub_card_welcome_links', $welcome_links);
if (function_exists('yooadmin_filter_welcome_links_by_capability')) {
    $welcome_links = yooadmin_filter_welcome_links_by_capability($welcome_links);
}
?>
<div class="yp-card yp-card-full yp-card-welcome-wrapper yp-card-welcome-studio yp-studio-welcome-mock"
     data-welcome-card
     data-default-welcome="<?php echo esc_attr(wp_json_encode($defaults)); ?>">
    <div class="yp-studio-welcome-mock__inner">
        <div class="yp-card-header yp-welcome-header yp-section-header yp-studio-welcome-mock__header">
            <h2 class="yp-card-welcome"><?php echo esc_html($data['title']); ?></h2>
            <?php if (function_exists('yooadmin_user_can_manage_site_settings') && yooadmin_user_can_manage_site_settings()) : ?>
                <div class="yp-card-toolbar qa-toolbar yp-welcome-toolbar">
                    <button type="button"
                            class="qa-toggle yp-welcome-toggle"
                            data-welcome-toggle
                            data-label-edit="<?php echo esc_attr__('Edit', 'yooadmin'); ?>"
                            data-label-done="<?php echo esc_attr__('Done', 'yooadmin'); ?>"
                            aria-pressed="false"
                            aria-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>">
                        <span class="dashicons dashicons-edit" aria-hidden="true"></span>
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <p class="yp-card-text yp-studio-welcome-mock__line1"><?php echo esc_html($data['p1']); ?></p>

        <div class="yp-studio-welcome-mock__meta-row">
            <p class="yp-card-text yp-studio-welcome-mock__line2"><?php echo esc_html($data['p2']); ?></p>
            <div class="yp-studio-welcome-mock__datetime">
                <time
                    class="yp-studio-welcome-mock__datetime-inner"
                    datetime="<?php echo esc_attr($welcome_iso); ?>"
                    data-locale="<?php echo esc_attr(function_exists('get_user_locale') ? get_user_locale() : get_locale()); ?>"
                    data-wp-date-format="<?php echo esc_attr((string) get_option('date_format', 'M j, Y')); ?>">
                    <span class="yp-studio-welcome-mock__datetime-date"><?php echo esc_html($welcome_date); ?></span>
                    <span class="yp-studio-welcome-mock__datetime-time"><?php echo esc_html($welcome_time); ?></span>
                </time>
            </div>
        </div>

        <?php
        if (function_exists('yooadmin_render_welcome_site_context')) {
            yooadmin_render_welcome_site_context();
        }
        ?>

        <?php if (!empty($welcome_links) && is_array($welcome_links)) : ?>
            <div class="yp-studio-welcome-mock__footer-spacer" aria-hidden="true"></div>
            <div class="yp-welcome-links yp-studio-welcome-mock__links">
                <?php foreach ($welcome_links as $link) :
                    $w_label = isset($link['label']) ? (string) $link['label'] : '';
                    $w_url   = isset($link['url']) ? (string) $link['url'] : '';
                    $w_icon  = isset($link['icon']) ? (string) $link['icon'] : 'dashicons-admin-links';
                    $w_class = isset($link['class']) ? (string) $link['class'] : '';
                    $w_target = isset($link['target']) ? (string) $link['target'] : '';
                    $w_attrs = isset($link['attrs']) && is_array($link['attrs']) ? $link['attrs'] : [];
                    if ($w_label === '' || $w_url === '') {
                        continue;
                    }
                    ?>
                <a href="<?php echo esc_url($w_url); ?>"
                   class="yp-welcome-link<?php echo $w_class !== '' ? ' ' . esc_attr($w_class) : ''; ?>"
                    <?php if ($w_target !== '') : ?>
                   target="<?php echo esc_attr($w_target); ?>" rel="noopener noreferrer"
                    <?php endif; ?>
                    <?php foreach ($w_attrs as $attr_name => $attr_value) : ?>
                        <?php echo esc_attr((string) $attr_name); ?>="<?php echo esc_attr((string) $attr_value); ?>"
                    <?php endforeach; ?>>
                    <span class="dashicons <?php echo esc_attr($w_icon); ?>" aria-hidden="true"></span>
                    <span class="yp-welcome-link-label"><?php echo esc_html($w_label); ?></span>
                </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
