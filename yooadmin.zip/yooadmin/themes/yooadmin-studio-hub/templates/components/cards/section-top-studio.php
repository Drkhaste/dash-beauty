<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

/**
 * Studio Hub — top row: Welcome + Quick Actions (six tiles).
 */

$base = dirname(__DIR__);
?>
<div class="yp-dashboard-grid" data-yooadmin-top-section="true" data-yoocustom-protected="true" data-layout-locked="true">
    <?php
    $welcome = $base . '/cards/card-welcome-studio.php';
    if (file_exists($welcome)) {
        include $welcome;
    }

    $actions = $base . '/cards/card-actions-studio.php';
    if (function_exists('yooadmin_is_site_regular_user') && yooadmin_is_site_regular_user()) {
        $shortcuts = $base . '/cards/card-workspace-shortcuts-studio.php';
        if (file_exists($shortcuts)) {
            include $shortcuts;
        }
    } elseif (file_exists($actions)) {
        include $actions;
    }
    ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
