<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

/**
 * Studio Hub — third-party menus + extension slots (mockup-style dashed placeholders).
 *
 * @package YOOAdmin Extended
 */

$split = isset($studio_hub_split) && is_array($studio_hub_split)
    ? $studio_hub_split
    : (function_exists('yooadmin_build_admin_menu_tree') && function_exists('yooadmin_studio_hub_split_menu_tree')
        ? yooadmin_studio_hub_split_menu_tree((array) yooadmin_build_admin_menu_tree())
        : ['core' => [], 'extensions' => []]);

$extension_items = isset($split['extensions']) && is_array($split['extensions']) ? $split['extensions'] : [];

$slug_key = static function ($slug) {
    $k = strtolower(preg_replace('~[^a-zA-Z0-9_\-\.]~', '_', (string) $slug));
    return $k ?: 'menu';
};

$extract_badge = static function (string $title): array {
    $clean = trim($title);
    $badge = '';

    if ($clean === '') {
        return ['title' => $clean, 'badge' => $badge];
    }

    if (preg_match('/^(.*?)[(（]\s*(\d+)\s*[)）]\s*$/u', $clean, $m)) {
        $clean = trim($m[1]);
        $badge = $m[2];
    } elseif (preg_match('/^(.*?\D)(\d+)\s*$/u', $clean, $m)) {
        $clean = trim($m[1]);
        $badge = $m[2];
    } elseif (preg_match('/^\s*(\d+)\s+(.+)$/u', $clean, $m)) {
        $rest = strtolower(trim($m[2]));
        if (preg_match('/(?:update|updates|pending|comment|comments|order|orders|plugin|plugins|review|reviews|message|messages|draft|drafts)\b/', $rest)) {
            $badge = $m[1];
            $clean = trim($m[2]);
        }
    }
    if ($badge !== '' && (int) $badge <= 0) {
        $badge = '';
    }
    if ($badge === '') {
        $clean = trim((string) preg_replace('/\s+0\s*$/u', '', $clean));
    }

    return ['title' => $clean, 'badge' => $badge];
};

$map_group = static function (string $slug, string $url): string {
    $slug_l = strtolower($slug);
    $url_l  = strtolower($url);

    if (strpos($slug_l, 'plugins.php') !== false || strpos($url_l, 'plugins.php') !== false) {
        return 'wp-plugin-updates';
    }
    if (strpos($slug_l, 'yooadmin-plugins') !== false || strpos($url_l, 'yooadmin-plugins') !== false) {
        return 'wp-plugin-updates';
    }
    if (strpos($slug_l, 'themes.php') !== false || strpos($url_l, 'themes.php') !== false) {
        return 'wp-theme-updates';
    }
    if (strpos($slug_l, 'yooadmin-update-center') !== false || strpos($url_l, 'yooadmin-update-center') !== false) {
        return 'wp-core-update';
    }
    if (strpos($slug_l, 'update-core') !== false || strpos($url_l, 'update-core') !== false) {
        if (strpos($url_l, 'tab=translations') !== false) {
            return 'wp-translation-updates';
        }
        return 'wp-core-update';
    }
    if (strpos($slug_l, 'edit-comments.php') !== false || strpos($url_l, 'edit-comments.php') !== false) {
        return 'wp-comments-pending';
    }
    if (strpos($slug_l, 'yooadmin-extensions') !== false || strpos($url_l, 'yooadmin-extensions') !== false) {
        return 'yooadmin-extensions-update';
    }
    if (strpos($slug_l, 'edit.php') !== false && strpos($slug_l, 'post_type=shop_order') !== false) {
        return 'wp-order-updates';
    }

    return '';
};

$row_partial = dirname(__DIR__) . '/partials/studio-hub-workspace-row.php';
$tile_prefix = 'ext';
$has_rows      = $extension_items !== [] && file_exists($row_partial);

ob_start();
do_action('yooadmin_studio_hub_extensions');
$hooked = trim((string) ob_get_clean());
?>
<?php
$yooadmin_studio_hub_extensions_placement = 'main';
if (isset($GLOBALS['yooadmin_studio_hub_extensions_placement'])) {
    $yooadmin_studio_hub_extensions_placement = (string) $GLOBALS['yooadmin_studio_hub_extensions_placement'];
} elseif (isset($yooadmin_studio_hub_extensions_placement)) {
    $yooadmin_studio_hub_extensions_placement = (string) $yooadmin_studio_hub_extensions_placement;
}
if ($yooadmin_studio_hub_extensions_placement !== 'aside') {
    $yooadmin_studio_hub_extensions_placement = 'main';
}
$extensions_layout_empty = function_exists('yooadmin_studio_hub_extensions_section_empty_for_layout')
    && yooadmin_studio_hub_extensions_section_empty_for_layout();
$extensions_layout_all_hidden = false;
if ($has_rows && function_exists('yooadmin_studio_hub_get_user_layout')) {
    $extensions_layout = yooadmin_studio_hub_get_user_layout();
    $hidden_cards      = [];
    if (!empty($extensions_layout['hidden']) && is_array($extensions_layout['hidden'])) {
        foreach ($extensions_layout['hidden'] as $hidden_card_id) {
            $hidden_card_id = sanitize_text_field((string) $hidden_card_id);
            if ($hidden_card_id !== '') {
                $hidden_cards[$hidden_card_id] = true;
            }
        }
    }

    if ($hidden_cards !== []) {
        $section_card_ids = [];
        if (
            !empty($extensions_layout['cards'])
            && is_array($extensions_layout['cards'])
            && array_key_exists('from-extensions', $extensions_layout['cards'])
            && is_array($extensions_layout['cards']['from-extensions'])
        ) {
            foreach ($extensions_layout['cards']['from-extensions'] as $card_id) {
                $card_id = sanitize_text_field((string) $card_id);
                if ($card_id !== '') {
                    $section_card_ids[] = $card_id;
                }
            }
        } else {
            foreach ($extension_items as $extension_item) {
                if (!is_array($extension_item) || empty($extension_item['url'])) {
                    continue;
                }
                $slug     = isset($extension_item['slug']) ? (string) $extension_item['slug'] : '';
                $url      = (string) $extension_item['url'];
                $key_seed = $slug !== '' ? $slug : $url;
                $section_card_ids[] = $tile_prefix . '-' . $slug_key($key_seed);
            }
        }

        $section_card_ids = array_values(array_filter(array_unique($section_card_ids)));
        $visible_card_ids = array_filter(
            $section_card_ids,
            static function ($card_id) use ($hidden_cards) {
                return empty($hidden_cards[$card_id]);
            }
        );
        $extensions_layout_all_hidden = $section_card_ids !== [] && $visible_card_ids === [];
    }
}
$yooadmin_studio_extensions_section_empty = (!$has_rows && $hooked === '') || $extensions_layout_empty || ($extensions_layout_all_hidden && $hooked === '');
$extensions_pending = $has_rows && !$extensions_layout_empty && !$extensions_layout_all_hidden;
$extensions_section_hidden = function_exists('yooadmin_studio_hub_is_section_hidden_for_user')
    && yooadmin_studio_hub_is_section_hidden_for_user('from-extensions');
?>
<div class="yp-card yp-card-full yp-dashboard-section yp-studio-surface-card yp-studio-extensions-card<?php echo $yooadmin_studio_extensions_section_empty ? ' yp-layout-section--empty yp-layout-section--hidden' : ''; ?><?php echo $extensions_section_hidden ? ' is-dashboard-section-hidden' : ''; ?>"
     data-section-id="from-extensions"
     data-layout-section="true"
     data-collapsible="true"
     data-sortable="true"
     data-collapsed="false"
     data-custom-placement="<?php echo esc_attr($yooadmin_studio_hub_extensions_placement); ?>"
     data-default-section-icon="dashicons-admin-plugins"
     <?php echo $extensions_section_hidden ? ' data-section-hidden="true"' : ''; ?>
     <?php echo $yooadmin_studio_extensions_section_empty ? ' hidden' : ''; ?>
     <?php echo $extensions_pending ? ' data-extensions-pending="true"' : ''; ?>>
  <div class="yp-card-header yp-section-header">
    <h2 class="yp-card-title yp-section-title">
      <span class="dashicons dashicons-admin-plugins" aria-hidden="true"></span>
      <?php echo esc_html__('Your plugins', 'yooadmin'); ?>
    </h2>
  </div>
  <div class="yp-card-body yp-studio-extensions-body">
    <?php if ($has_rows) : ?>
      <p class="yp-studio-extensions-lead">
        <span class="yp-studio-extensions-lead__icon dashicons dashicons-info-outline" aria-hidden="true"></span>
        <span class="yp-studio-extensions-lead__text"><?php esc_html_e('Plugin screens with top-level menus appear here automatically.', 'yooadmin'); ?></span>
      </p>
      <div class="yp-studio-section-body">
        <div class="yp-studio-section-loading yp-extensions-grid-loading" aria-hidden="false">
          <div class="yp-loading-spinner">
            <div class="yp-spinner-circle"></div>
          </div>
        </div>
        <div class="yp-icon-grid-boxes yp-cards-grid yp-studio-extensions-grid yp-studio-workspace-rows"
             data-layout="grid"
             data-columns="auto"
             data-sortable="true"
             >
    <?php else : ?>
    <div class="yp-icon-grid-boxes yp-cards-grid yp-studio-extensions-grid yp-studio-workspace-rows is-grid-empty"
         data-layout="grid"
         data-columns="auto"
         data-sortable="true"
         hidden>
    <?php endif; ?>
      <?php
      if ($has_rows) :
          foreach ($extension_items as $item) :
              if (!is_array($item)) {
                  continue;
              }
              include $row_partial;
          endforeach;
      endif;
      ?>
    </div>
    <?php if ($has_rows) : ?>
      </div>
    <?php endif; ?>

    <?php if ($hooked !== '') : ?>
      <div class="yp-studio-extensions-widgets" data-studio-extensions-widgets="true">
        <h3 class="yp-studio-extensions-widgets__title"><?php esc_html_e('Extension widgets', 'yooadmin'); ?></h3>
        <?php echo $hooked; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
