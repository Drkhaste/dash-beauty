<?php
/**
 * Updates — compact card body (aside section + dashboard card API).
 *
 * Expects: $studio_hub_updates
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

$studio_hub_updates = isset($studio_hub_updates) && is_array($studio_hub_updates)
    ? $studio_hub_updates
    : (function_exists('yooadmin_studio_hub_get_updates_card_data') ? yooadmin_studio_hub_get_updates_card_data() : []);

$groups        = isset($studio_hub_updates['groups']) && is_array($studio_hub_updates['groups']) ? $studio_hub_updates['groups'] : [];
$visible_items = isset($studio_hub_updates['visibleItems']) && is_array($studio_hub_updates['visibleItems']) ? $studio_hub_updates['visibleItems'] : [];
$total         = isset($studio_hub_updates['total']) ? (int) $studio_hub_updates['total'] : 0;
$hidden_count  = isset($studio_hub_updates['hiddenCount']) ? (int) $studio_hub_updates['hiddenCount'] : 0;
$updates_url   = isset($studio_hub_updates['updatesUrl']) ? (string) $studio_hub_updates['updatesUrl'] : self_admin_url('update-core.php');
$product_notice = isset($studio_hub_updates['productNotice']) && is_array($studio_hub_updates['productNotice'])
    ? $studio_hub_updates['productNotice']
    : (function_exists('yooadmin_studio_hub_get_updates_product_notice') ? yooadmin_studio_hub_get_updates_product_notice() : []);
$product_rows   = isset($product_notice['rows']) && is_array($product_notice['rows']) ? $product_notice['rows'] : [];
$groups_id     = function_exists('wp_unique_id') ? wp_unique_id('yp-studio-updates-groups-') : uniqid('yp-studio-updates-groups-', false);

$render_update_item = static function (array $item, array $group = []) use ($updates_url): string {
    $group_id    = isset($item['group']) ? (string) $item['group'] : (string) ($group['id'] ?? '');
    $group_label = isset($item['groupLabel']) ? (string) $item['groupLabel'] : (string) ($group['label'] ?? '');
    $icon        = isset($item['icon']) ? (string) $item['icon'] : (string) ($group['icon'] ?? 'dashicons-update');
    $item_url    = isset($item['url']) ? (string) $item['url'] : $updates_url;
    $title       = (string) ($item['title'] ?? __('Update available', 'yooadmin'));
    $meta        = (string) ($item['meta'] ?? '');
    $version     = (string) ($item['version'] ?? '');
    $key         = (string) ($item['key'] ?? md5($group_id . '|' . $title . '|' . $meta));
    $action_type = (string) ($item['actionType'] ?? '');
    $can_update  = !empty($item['canUpdate']);
    $action_url  = isset($item['actionUrl']) ? (string) $item['actionUrl'] : $item_url;
    $action_label = (string) ($item['actionLabel'] ?? __('Update', 'yooadmin'));
    $action_aria  = (string) ($item['actionAriaLabel'] ?? $action_label);

    ob_start();
    ?>
    <li class="yp-studio-updates-item"
        data-update-key="<?php echo esc_attr($key); ?>"
        data-update-group="<?php echo esc_attr($group_id); ?>"
        data-update-type="<?php echo esc_attr((string) ($item['type'] ?? $action_type)); ?>"
        data-update-name="<?php echo esc_attr($title); ?>"
        data-update-version="<?php echo esc_attr($version); ?>">
      <span class="yp-studio-updates-item__icon" aria-hidden="true">
        <span class="dashicons <?php echo esc_attr($icon); ?>"></span>
      </span>
      <div class="yp-studio-updates-item__content">
        <a class="yp-studio-updates-item__title" href="<?php echo esc_url($item_url); ?>">
          <?php echo esc_html($title); ?>
        </a>
        <span class="yp-studio-updates-item__meta">
          <?php echo esc_html($meta !== '' ? $meta : $group_label); ?>
        </span>
        <span class="yp-studio-updates-item__status" data-update-status aria-live="polite"></span>
      </div>
      <div class="yp-studio-updates-item__actions">
        <?php if ($action_type === 'update-plugin' && $can_update) : ?>
          <button type="button"
                  class="yp-studio-updates-action"
                  data-update-action="update-plugin"
                  data-update-key="<?php echo esc_attr($key); ?>"
                  data-update-group="<?php echo esc_attr($group_id); ?>"
                  data-update-name="<?php echo esc_attr($title); ?>"
                  data-update-version="<?php echo esc_attr($version); ?>"
                  data-plugin="<?php echo esc_attr((string) ($item['plugin'] ?? '')); ?>"
                  data-slug="<?php echo esc_attr((string) ($item['slug'] ?? '')); ?>"
                  aria-label="<?php echo esc_attr($action_aria); ?>">
            <?php echo esc_html($action_label); ?>
          </button>
        <?php elseif ($action_type === 'update-theme' && $can_update) : ?>
          <button type="button"
                  class="yp-studio-updates-action"
                  data-update-action="update-theme"
                  data-update-key="<?php echo esc_attr($key); ?>"
                  data-update-group="<?php echo esc_attr($group_id); ?>"
                  data-update-name="<?php echo esc_attr($title); ?>"
                  data-update-version="<?php echo esc_attr($version); ?>"
                  data-slug="<?php echo esc_attr((string) ($item['slug'] ?? $item['stylesheet'] ?? '')); ?>"
                  aria-label="<?php echo esc_attr($action_aria); ?>">
            <?php echo esc_html($action_label); ?>
          </button>
        <?php elseif ($action_type === 'update-translation' && $can_update) : ?>
          <button type="button"
                  class="yp-studio-updates-action"
                  data-update-action="update-translation"
                  data-update-key="<?php echo esc_attr($key); ?>"
                  data-update-group="<?php echo esc_attr($group_id); ?>"
                  data-update-name="<?php echo esc_attr($title); ?>"
                  data-update-version="<?php echo esc_attr($version); ?>"
                  data-translation-type="<?php echo esc_attr((string) ($item['translationType'] ?? '')); ?>"
                  data-slug="<?php echo esc_attr((string) ($item['slug'] ?? '')); ?>"
                  data-language="<?php echo esc_attr((string) ($item['language'] ?? '')); ?>"
                  aria-label="<?php echo esc_attr($action_aria); ?>">
            <?php echo esc_html($action_label); ?>
          </button>
        <?php elseif ($action_url !== '') : ?>
          <a class="yp-studio-updates-action yp-studio-updates-action--link"
             href="<?php echo esc_url($action_url); ?>"
             aria-label="<?php echo esc_attr($action_aria); ?>">
            <?php echo esc_html($action_label); ?>
          </a>
        <?php endif; ?>
      </div>
    </li>
    <?php
    return (string) ob_get_clean();
};
?>
<div class="yp-studio-aside-section__body yp-studio-updates-card-body"
     data-studio-updates-widget="true"
     data-total="<?php echo esc_attr((string) $total); ?>"
     data-updates-url="<?php echo esc_url($updates_url); ?>">
  <div class="yp-studio-updates-summary<?php echo $total > 0 ? ' has-updates' : ' is-clear'; ?>">
    <span class="yp-studio-updates-summary__icon" aria-hidden="true">
      <span class="dashicons <?php echo $total > 0 ? 'dashicons-update' : 'dashicons-yes-alt'; ?>"></span>
    </span>
    <div class="yp-studio-updates-summary__copy">
      <p class="yp-studio-updates-summary__title" data-updates-summary-title>
        <?php
        echo esc_html(
            $total > 0
                ? (
                    $total === 1
                        ? __('1 update needs attention', 'yooadmin')
                        : sprintf(
                            /* translators: %s: update count. */
                            _n('%s update needs attention', '%s updates need attention', $total, 'yooadmin'),
                            number_format_i18n($total)
                        )
                )
                : __('Everything is up to date', 'yooadmin')
        );
        ?>
      </p>
      <p class="yp-studio-updates-summary__text" data-updates-summary-text>
        <?php
        echo esc_html(
            $total > 0
                ? __('Core, plugins, themes, and language packs are grouped below.', 'yooadmin')
                : __('No core, plugin, theme, or language updates are waiting right now.', 'yooadmin')
        );
        ?>
      </p>
    </div>
  </div>

  <div class="yp-studio-updates-tabs" role="list" aria-label="<?php esc_attr_e('Update groups', 'yooadmin'); ?>">
    <?php foreach ($groups as $group) : ?>
      <?php
      if (!is_array($group)) {
          continue;
      }
      $group_id    = isset($group['id']) ? (string) $group['id'] : '';
      $group_count = isset($group['count']) ? (int) $group['count'] : 0;
      $group_icon  = isset($group['icon']) ? (string) $group['icon'] : 'dashicons-update';
      ?>
      <span class="yp-studio-updates-tab<?php echo $group_count > 0 ? ' has-updates' : ''; ?>"
            role="listitem"
            data-update-group="<?php echo esc_attr($group_id); ?>">
        <span class="dashicons <?php echo esc_attr($group_icon); ?>" aria-hidden="true"></span>
        <span class="yp-studio-updates-tab__label"><?php echo esc_html($group['label'] ?? ''); ?></span>
        <span class="yp-studio-updates-tab__count" data-update-group-count="<?php echo esc_attr($group_id); ?>"><?php echo esc_html(number_format_i18n($group_count)); ?></span>
      </span>
    <?php endforeach; ?>
  </div>

  <?php if ($visible_items) : ?>
    <ul class="yp-studio-updates-list" data-updates-compact>
      <?php foreach ($visible_items as $item) : ?>
        <?php
        if (!is_array($item)) {
            continue;
        }
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Renderer escapes item fields.
        echo $render_update_item($item);
        ?>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

  <?php if ($hidden_count > 0) : ?>
    <div id="<?php echo esc_attr($groups_id); ?>" class="yp-studio-updates-groups" data-updates-groups hidden>
      <?php foreach ($groups as $group) : ?>
        <?php
        if (!is_array($group) || empty($group['items']) || !is_array($group['items'])) {
            continue;
        }
        $group_id = isset($group['id']) ? (string) $group['id'] : '';
        ?>
        <section class="yp-studio-updates-group" data-update-group-section="<?php echo esc_attr($group_id); ?>">
          <ul class="yp-studio-updates-list yp-studio-updates-list--grouped">
            <?php foreach ($group['items'] as $item) : ?>
              <?php
              if (!is_array($item)) {
                  continue;
              }
              // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Renderer escapes item fields.
              echo $render_update_item($item, $group);
              ?>
            <?php endforeach; ?>
          </ul>
        </section>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php if ($product_rows) : ?>
    <div class="yp-studio-updates-product-notice yp-studio-updates-product-notice--after-list" aria-label="<?php esc_attr_e('YOOAdmin product versions', 'yooadmin'); ?>">
      <?php foreach ($product_rows as $product_row) : ?>
        <?php
        if (!is_array($product_row)) {
            continue;
        }
        $row_state   = isset($product_row['state']) ? (string) $product_row['state'] : '';
        $row_product = isset($product_row['product']) ? (string) $product_row['product'] : '';
        $row_icon    = isset($product_row['icon']) ? (string) $product_row['icon'] : 'dashicons-info';
        $row_version = isset($product_row['version']) ? (string) $product_row['version'] : '';
        $row_detail  = isset($product_row['detail']) ? (string) $product_row['detail'] : '';
        $row_cta_url    = isset($product_row['ctaUrl']) ? (string) $product_row['ctaUrl'] : '';
        $row_cta_lbl    = isset($product_row['ctaLabel']) ? (string) $product_row['ctaLabel'] : '';
        $row_cta_action = isset($product_row['ctaAction']) ? sanitize_key((string) $product_row['ctaAction']) : '';
        $row_cta_plugin = isset($product_row['ctaPlugin']) ? (string) $product_row['ctaPlugin'] : '';
        $row_cta_slug   = isset($product_row['ctaSlug']) ? (string) $product_row['ctaSlug'] : '';
        if ($row_state === 'update' && $row_cta_lbl === '' && $row_cta_url !== '') {
            $row_cta_lbl = __('Update', 'yooadmin');
        }
        ?>
        <div class="yp-studio-updates-product-row yp-studio-updates-product-row--<?php echo esc_attr($row_state); ?>">
          <span class="yp-studio-updates-product-row__icon" aria-hidden="true">
            <span class="dashicons <?php echo esc_attr($row_icon); ?>"></span>
          </span>
          <div class="yp-studio-updates-product-row__copy">
            <p class="yp-studio-updates-product-row__title">
              <?php
              if ($row_version !== '') {
                  echo esc_html($row_product . ' ' . $row_version);
              } else {
                  echo esc_html($row_product);
              }
              ?>
            </p>
            <?php if ($row_detail !== '') : ?>
              <p class="yp-studio-updates-product-row__detail"><?php echo esc_html($row_detail); ?></p>
            <?php endif; ?>
          </div>
          <?php if ($row_cta_lbl !== '' && ($row_cta_url !== '' || $row_cta_action !== '')) : ?>
            <?php if ($row_cta_action === 'activate-plugin') : ?>
              <button type="button"
                      class="yp-studio-updates-product-row__cta"
                      data-cta-action="activate-plugin"
                      data-product-id="<?php echo esc_attr(isset($product_row['id']) ? (string) $product_row['id'] : ''); ?>"
                      data-name="<?php echo esc_attr(isset($product_row['ctaName']) ? (string) $product_row['ctaName'] : $row_product); ?>"
                      data-plugin="<?php echo esc_attr($row_cta_plugin !== '' ? $row_cta_plugin : 'yooadmin-plus/yooadmin-plus.php'); ?>"
                      data-slug="<?php echo esc_attr($row_cta_slug !== '' ? $row_cta_slug : 'yooadmin-plus'); ?>">
                <?php echo esc_html($row_cta_lbl); ?>
              </button>
            <?php elseif ($row_cta_action === 'license-connect' && $row_cta_url !== '') : ?>
              <button type="button"
                      class="yp-studio-updates-product-row__cta yooadmin-panel-connect-trigger"
                      data-panel-url="<?php echo esc_url($row_cta_url); ?>">
                <?php echo esc_html($row_cta_lbl); ?>
              </button>
            <?php else : ?>
              <a class="yp-studio-updates-product-row__cta"
                 href="<?php echo esc_url($row_cta_url); ?>"
                 <?php echo $row_cta_action === 'portal-login' ? '' : 'target="_blank" rel="noopener noreferrer"'; ?>>
                <?php echo esc_html($row_cta_lbl); ?>
              </a>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php if ($hidden_count > 0 || $total > 0) : ?>
    <div class="yp-studio-aside-footer yp-studio-updates-footer">
      <?php if ($hidden_count > 0) : ?>
        <?php
        $collapsed_label = sprintf(
            /* translators: %s: hidden update count. */
            __('View all updates (+%s more)', 'yooadmin'),
            number_format_i18n($hidden_count)
        );
        $expanded_label = __('Show fewer updates', 'yooadmin');
        ?>
        <button type="button"
                class="yp-studio-updates-view-all"
                data-updates-toggle
                data-label-collapsed="<?php echo esc_attr($collapsed_label); ?>"
                data-label-expanded="<?php echo esc_attr($expanded_label); ?>"
                aria-expanded="false"
                aria-controls="<?php echo esc_attr($groups_id); ?>">
          <span data-updates-toggle-label><?php echo esc_html($collapsed_label); ?></span>
        </button>
        <noscript>
          <a class="yp-studio-updates-fallback-link" href="<?php echo esc_url($updates_url); ?>">
            <?php esc_html_e('Open WordPress Updates', 'yooadmin'); ?>
          </a>
        </noscript>
      <?php else : ?>
        <a class="yp-studio-updates-view-all yp-studio-updates-view-all--link" href="<?php echo esc_url($updates_url); ?>">
          <?php esc_html_e('Open WordPress Updates', 'yooadmin'); ?>
          <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
        </a>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
