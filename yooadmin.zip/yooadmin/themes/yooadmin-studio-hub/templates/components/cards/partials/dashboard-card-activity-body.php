<?php
/**
 * Activity — card body (aside section + dashboard card API).
 *
 * @package YOOAdmin_Studio_Hub
 * @var array<int, array<string, mixed>> $studio_hub_activity_items
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

$studio_hub_activity_items = isset($studio_hub_activity_items) && is_array($studio_hub_activity_items)
    ? $studio_hub_activity_items
    : (function_exists('yooadmin_activity_get_recent') ? yooadmin_activity_get_recent(5) : []);

$activity_url = admin_url('admin.php?page=yooadmin-activity');

?>
<div class="yp-studio-aside-section__body yp-studio-activity-card-body">
  <ul class="yp-studio-activity-list">
    <?php if ($studio_hub_activity_items) : ?>
      <?php foreach ($studio_hub_activity_items as $item) : ?>
        <?php
        if (!is_array($item)) {
            continue;
        }
        $url = isset($item['url']) ? (string) $item['url'] : '';
        $action_label = isset($item['action_label']) ? (string) $item['action_label'] : (string) ($item['title'] ?? '');
        $subject = isset($item['subject']) ? (string) $item['subject'] : '';
        $icon = isset($item['icon']) ? (string) $item['icon'] : 'dashicons-marker';
        $time_label = isset($item['time_label']) ? (string) $item['time_label'] : '';
        ?>
        <li class="yp-studio-activity-item">
          <span class="yp-studio-activity-item__icon" aria-hidden="true">
            <span class="dashicons <?php echo esc_attr($icon); ?>"></span>
          </span>
          <div class="yp-studio-activity-item__content">
            <p class="yp-studio-activity-item__line">
              <span class="yp-studio-activity-item__action"><?php echo esc_html($action_label); ?><?php echo $subject !== '' ? ':' : ''; ?></span>
              <?php if ($subject !== '' && $url !== '') : ?>
                <a class="yp-studio-activity-item__subject" href="<?php echo esc_url($url); ?>"><?php echo esc_html($subject); ?></a>
              <?php elseif ($subject !== '') : ?>
                <span class="yp-studio-activity-item__subject"><?php echo esc_html($subject); ?></span>
              <?php endif; ?>
            </p>
            <?php if ($time_label !== '') : ?>
              <p class="yp-studio-activity-item__meta"><?php echo esc_html($time_label); ?></p>
            <?php endif; ?>
          </div>
        </li>
      <?php endforeach; ?>
    <?php else : ?>
      <li class="yp-studio-activity-item yp-studio-activity-item--empty">
        <span class="yp-studio-activity-item__icon" aria-hidden="true">
          <span class="dashicons dashicons-backup"></span>
        </span>
        <div class="yp-studio-activity-item__content">
          <p class="yp-studio-activity-item__line">
            <span class="yp-studio-activity-item__action"><?php esc_html_e('No recent activity yet.', 'yooadmin'); ?></span>
          </p>
          <p class="yp-studio-activity-item__meta"><?php esc_html_e('Changes to content, comments, and settings will appear here.', 'yooadmin'); ?></p>
        </div>
      </li>
    <?php endif; ?>
  </ul>
  <div class="yp-studio-aside-footer yp-studio-activity-footer">
    <a class="yp-studio-activity-view-all" href="<?php echo esc_url($activity_url); ?>">
      <?php esc_html_e('View all activity', 'yooadmin'); ?>
      <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
    </a>
  </div>
</div>
