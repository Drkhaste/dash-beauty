<?php
/**
 * Workspace Notes — card body (aside section + dashboard card API).
 *
 * Expects: $ws_active_type, $ws_active_def, $ws_note_types, $ws_initial_notes, $ws_show_check
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

$ws_active_type   = isset($ws_active_type) ? (string) $ws_active_type : 'todos';
$ws_note_types    = (isset($ws_note_types) && is_array($ws_note_types)) ? $ws_note_types : [];
$ws_active_def    = (isset($ws_active_def) && is_array($ws_active_def)) ? $ws_active_def : [];
$ws_initial_notes = (isset($ws_initial_notes) && is_array($ws_initial_notes)) ? $ws_initial_notes : [];
$ws_show_check    = ! empty($ws_show_check);
$ws_notes_scope   = isset($ws_notes_scope) ? (string) $ws_notes_scope : 'site';
$ws_notes_has_more = !empty($ws_notes_has_more);

?>
<div class="yp-studio-workspace-notes yp-studio-aside-section__body"
     data-active-type="<?php echo esc_attr($ws_active_type); ?>"
     data-ws-ajax-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"
     data-ws-nonce="<?php echo esc_attr(wp_create_nonce('yooadmin_workspace_notes')); ?>"
     data-ws-notes-scope="<?php echo esc_attr($ws_notes_scope); ?>">

    <div class="yp-studio-workspace-notes__toolbar">
      <div class="yp-studio-workspace-notes__type-picker">
        <button type="button"
                class="yp-studio-workspace-notes__type-trigger"
                aria-haspopup="listbox"
                aria-expanded="false">
          <span class="dashicons <?php echo esc_attr($ws_active_def['icon'] ?? 'dashicons-admin-generic'); ?>" aria-hidden="true"></span>
          <span class="yp-studio-workspace-notes__type-trigger-label"><?php echo esc_html($ws_active_def['label'] ?? ''); ?></span>
          <span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
        </button>
        <ul class="yp-studio-workspace-notes__type-menu" role="listbox" hidden>
          <?php foreach ($ws_note_types as $type_key => $type_def) : ?>
            <li role="presentation">
              <button type="button"
                      class="yp-studio-workspace-notes__type-option<?php echo $type_key === $ws_active_type ? ' is-active' : ''; ?>"
                      role="option"
                      data-note-type="<?php echo esc_attr($type_key); ?>"
                      aria-selected="<?php echo $type_key === $ws_active_type ? 'true' : 'false'; ?>">
                <span class="dashicons <?php echo esc_attr($type_def['icon'] ?? 'dashicons-admin-generic'); ?>" aria-hidden="true"></span>
                <span><?php echo esc_html($type_def['label'] ?? $type_key); ?></span>
              </button>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <button type="button"
              class="button yp-yoo-btn yp-yoo-btn--soft yp-studio-workspace-notes__add-btn"
              aria-expanded="false"
              aria-label="<?php esc_attr_e('Add note', 'yooadmin'); ?>">
        <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
      </button>
    </div>

    <div class="yp-studio-workspace-notes__list-wrap">
      <ul class="yp-studio-workspace-notes__list" aria-live="polite">
        <?php if ($ws_initial_notes) : ?>
          <?php foreach ($ws_initial_notes as $note) : ?>
            <?php
            $nid  = (int) ( $note['id'] ?? 0 );
            $done = ! empty( $note['is_done'] );
            ?>
            <li class="yp-studio-workspace-notes__item<?php echo $done ? ' is-done' : ''; ?>"
                data-note-id="<?php echo esc_attr((string) $nid); ?>">
              <?php if ($ws_show_check) : ?>
                <button type="button"
                        class="yp-studio-workspace-notes__check"
                        aria-label="<?php esc_attr_e('Mark done', 'yooadmin'); ?>"
                        aria-pressed="<?php echo $done ? 'true' : 'false'; ?>"></button>
              <?php endif; ?>
              <div class="yp-studio-workspace-notes__item-body">
                <span class="yp-studio-workspace-notes__item-title"><?php echo esc_html($note['title'] ?? ''); ?></span>
                <?php if (!empty($note['body'])) : ?>
                  <span class="yp-studio-workspace-notes__item-desc"><?php echo esc_html(wp_strip_all_tags($note['body'])); ?></span>
                <?php endif; ?>
                <?php if ($ws_active_type === 'todos' && !empty($note['due_at_label']) && !$done) : ?>
                  <span class="yp-studio-workspace-notes__item-meta yp-studio-workspace-notes__item-meta--due">
                    <?php
                    echo esc_html(sprintf(
                        /* translators: %s: due date/time */
                        /* translators: %s: due date. */                        __('Due: %s', 'yooadmin'),
                        $note['due_at_label']
                    ));
                    ?>
                  </span>
                <?php endif; ?>
                <?php if ($ws_active_type === 'todos' && !empty($note['completed_at_label']) && $done) : ?>
                  <span class="yp-studio-workspace-notes__item-meta yp-studio-workspace-notes__item-meta--done">
                    <?php
                    echo esc_html(sprintf(
                        /* translators: %s: Completion date/time label. */
                        /* translators: %s: completion date. */                        __('Completed: %s', 'yooadmin'),
                        $note['completed_at_label']
                    ));
                    ?>
                  </span>
                <?php endif; ?>
                <?php if ($ws_active_type === 'reminders' && !empty($note['remind_at_label'])) : ?>
                  <span class="yp-studio-workspace-notes__item-meta yp-studio-workspace-notes__item-meta--remind">
                    <?php
                    echo esc_html(sprintf(
                        /* translators: %s: Reminder date/time label. */
                        /* translators: %s: reminder date. */                        __('Remind: %s', 'yooadmin'),
                        $note['remind_at_label']
                    ));
                    ?>
                  </span>
                <?php endif; ?>
                <?php if (!empty($note['created_at_label'])) : ?>
                  <span class="yp-studio-workspace-notes__item-meta yp-studio-workspace-notes__item-meta--added">
                    <?php
                    echo esc_html(sprintf(
                        /* translators: %s: Note creation date label. */
                        /* translators: %s: date added. */                        __('Added: %s', 'yooadmin'),
                        $note['created_at_label']
                    ));
                    ?>
                  </span>
                <?php endif; ?>
              </div>
              <button type="button"
                      class="yp-studio-workspace-notes__delete"
                      aria-label="<?php esc_attr_e('Delete note', 'yooadmin'); ?>">
                <span class="dashicons dashicons-trash" aria-hidden="true"></span>
              </button>
            </li>
          <?php endforeach; ?>
        <?php else : ?>
          <li class="yp-studio-workspace-notes__empty"><?php esc_html_e('No notes yet.', 'yooadmin'); ?></li>
        <?php endif; ?>
      </ul>
      <?php if ($ws_notes_has_more) : ?>
        <button type="button" class="yp-studio-workspace-notes__load-more">
          <span class="yp-studio-workspace-notes__load-more-label"><?php esc_html_e('Load more', 'yooadmin'); ?></span>
          <span class="yp-studio-workspace-notes__load-more-spinner" aria-hidden="true" hidden>
            <span class="yp-spinner-circle"></span>
          </span>
        </button>
      <?php endif; ?>
    </div>

    <div class="yp-studio-workspace-notes__form-wrap" hidden>
      <form class="yp-studio-workspace-notes__form" autocomplete="off" novalidate>
        <label class="screen-reader-text" for="yp-studio-ws-note-title"><?php esc_html_e('Title', 'yooadmin'); ?></label>
        <input type="text"
               id="yp-studio-ws-note-title"
               class="yp-studio-workspace-notes__input"
               name="title"
               placeholder="<?php esc_attr_e('Title…', 'yooadmin'); ?>"
               required />

        <label class="screen-reader-text" for="yp-studio-ws-note-body"><?php esc_html_e('Details', 'yooadmin'); ?></label>
        <textarea id="yp-studio-ws-note-body"
                  class="yp-studio-workspace-notes__textarea"
                  name="body"
                  rows="2"
                  placeholder="<?php esc_attr_e('Details (optional)', 'yooadmin'); ?>"></textarea>

        <?php
        $ws_tz_label = function_exists('yooadmin_workspace_notes_timezone_label')
            ? yooadmin_workspace_notes_timezone_label()
            : '';
        ?>
        <div class="yp-studio-workspace-notes__due-row" hidden>
          <label class="yp-studio-workspace-notes__field-label" for="yp-studio-ws-note-due">
            <?php esc_html_e('Due by', 'yooadmin'); ?>
          </label>
          <div class="yp-studio-workspace-notes__datetime-wrap">
            <span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span>
            <input type="datetime-local"
                   id="yp-studio-ws-note-due"
                   class="yp-studio-workspace-notes__datetime"
                   name="due_at"
                   autocomplete="off" />
          </div>
          <?php if ($ws_tz_label !== '') : ?>
            <p class="yp-studio-workspace-notes__datetime-hint" data-ws-datetime-hint hidden>
              <?php
              /* translators: %s: Site timezone label. */
              echo esc_html(sprintf(__('Site time: %s', 'yooadmin'), $ws_tz_label));
              ?>
            </p>
          <?php endif; ?>
        </div>

        <div class="yp-studio-workspace-notes__remind-row" hidden>
          <label class="yp-studio-workspace-notes__field-label" for="yp-studio-ws-note-remind">
            <?php esc_html_e('Remind at', 'yooadmin'); ?>
          </label>
          <div class="yp-studio-workspace-notes__datetime-wrap">
            <span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span>
            <input type="datetime-local"
                   id="yp-studio-ws-note-remind"
                   class="yp-studio-workspace-notes__datetime"
                   name="remind_at"
                   autocomplete="off" />
          </div>
          <?php if (!empty($ws_tz_label)) : ?>
            <p class="yp-studio-workspace-notes__datetime-hint" data-ws-datetime-hint hidden>
              <?php
              /* translators: %s: Site timezone label. */
              echo esc_html(sprintf(__('Site time: %s', 'yooadmin'), $ws_tz_label));
              ?>
            </p>
          <?php endif; ?>
        </div>

        <div class="yp-studio-workspace-notes__form-actions">
          <button type="button" class="button yp-yoo-btn yp-yoo-btn--soft yp-studio-workspace-notes__cancel">
            <?php esc_html_e('Cancel', 'yooadmin'); ?>
          </button>
          <button type="submit" class="button button-primary yp-yoo-btn yp-yoo-btn--primary yp-studio-workspace-notes__submit">
            <?php esc_html_e('Save', 'yooadmin'); ?>
          </button>
        </div>
      </form>
    </div>
</div>
