<?php
/**
 * Tips — card body (aside section + dashboard card API).
 *
 * Expects: $studio_hub_tips (array)
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

$studio_hub_tips = isset($studio_hub_tips) && is_array($studio_hub_tips)
    ? $studio_hub_tips
    : (function_exists('yooadmin_studio_hub_get_tips') ? yooadmin_studio_hub_get_tips() : []);

?>
<div class="yp-studio-aside-section__body yp-studio-tips-section__body">
  <?php if ($studio_hub_tips) : ?>
    <div
      class="yp-studio-tips-carousel"
      data-studio-tips-carousel="true"
      data-autoplay-ms="6500"
      aria-live="polite"
    >
      <div class="yp-studio-tips-carousel__track">
        <?php foreach ($studio_hub_tips as $index => $tip) : ?>
          <?php
          $theme = isset($tip['theme']) ? (string) $tip['theme'] : 'brand';
          $icon  = isset($tip['icon']) ? (string) $tip['icon'] : 'dashicons-lightbulb';
          $image = isset($tip['image']) ? (string) $tip['image'] : '';
          ?>
          <article
            class="yp-studio-tip-slide<?php echo $index === 0 ? ' is-active' : ''; ?>"
            data-tip-index="<?php echo esc_attr((string) $index); ?>"
            data-tip-theme="<?php echo esc_attr($theme); ?>"
            <?php echo $index === 0 ? '' : ' hidden'; ?>
          >
            <div class="yp-studio-tip-slide__media yp-studio-tip-slide__media--<?php echo esc_attr($theme); ?>">
              <?php if ($image !== '') : ?>
                <img
                  class="yp-studio-tip-slide__img"
                  src="<?php echo esc_url($image); ?>"
                  alt=""
                  loading="lazy"
                  decoding="async"
                />
              <?php endif; ?>
              <span class="yp-studio-tip-slide__icon dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
            </div>
            <div class="yp-studio-tip-slide__body">
              <h3 class="yp-studio-tip-slide__title"><?php echo esc_html($tip['title'] ?? ''); ?></h3>
              <p class="yp-studio-tip-slide__text"><?php echo esc_html($tip['text'] ?? ''); ?></p>
            </div>
          </article>
        <?php endforeach; ?>
      </div>

      <div class="yp-studio-tips-carousel__footer">
        <div
          class="yp-studio-tip-dots"
          role="tablist"
          aria-label="<?php esc_attr_e('Tips', 'yooadmin'); ?>"
        >
          <?php foreach ($studio_hub_tips as $index => $tip) : ?>
            <button
              type="button"
              class="yp-studio-tip-dot<?php echo $index === 0 ? ' is-active' : ''; ?>"
              role="tab"
              data-tip-index="<?php echo esc_attr((string) $index); ?>"
              aria-selected="<?php echo $index === 0 ? 'true' : 'false'; ?>"
              aria-label="<?php echo esc_attr(sprintf(
                  /* translators: %1$d current tip, %2$d total shown */
                  __('Tip %1$d of %2$d', 'yooadmin'),
                  $index + 1,
                  count($studio_hub_tips)
              )); ?>"
            ></button>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  <?php else : ?>
    <p class="yp-studio-tip yp-studio-tips-section__empty"><?php esc_html_e('Tips will appear here soon.', 'yooadmin'); ?></p>
  <?php endif; ?>
</div>
