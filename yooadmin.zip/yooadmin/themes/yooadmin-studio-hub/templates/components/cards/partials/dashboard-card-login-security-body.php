<?php
/**
 * Login security score — dashboard card body.
 *
 * Expects: $studio_hub_login_security (array)
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial.

$studio_hub_login_security = isset($studio_hub_login_security) && is_array($studio_hub_login_security)
    ? $studio_hub_login_security
    : (function_exists('yooadmin_login_security_dashboard_score_get') ? yooadmin_login_security_dashboard_score_get() : []);

$percent      = isset($studio_hub_login_security['percent']) ? (int) $studio_hub_login_security['percent'] : 0;
$percent      = max(0, min(100, $percent));
$status_label = isset($studio_hub_login_security['status_label']) ? (string) $studio_hub_login_security['status_label'] : '';
$status_key   = isset($studio_hub_login_security['status_key']) ? sanitize_html_class((string) $studio_hub_login_security['status_key']) : 'low';
$tips         = isset($studio_hub_login_security['tips']) && is_array($studio_hub_login_security['tips']) ? $studio_hub_login_security['tips'] : [];
$settings_url = isset($studio_hub_login_security['settings_url']) ? (string) $studio_hub_login_security['settings_url'] : admin_url('admin.php?page=yooadmin-settings#tab-login-security');
$active       = isset($studio_hub_login_security['active']) ? (int) $studio_hub_login_security['active'] : 0;
$total        = isset($studio_hub_login_security['total']) ? (int) $studio_hub_login_security['total'] : 0;

$ring_radius         = 42;
$circumference       = (int) round(2 * M_PI * $ring_radius);
$ring_offset_initial = $circumference;

$bar_strokes = [
    'off'     => '#94a3b8',
    'low'     => '#e57373',
    'partial' => '#f0ad4e',
    'good'    => '#eda934',
    'full'    => '#eda934',
];
$bar_stroke   = $bar_strokes[ $status_key ] ?? '#eda934';
$track_stroke = '#dcdcde';

?>
<div
  class="yp-studio-login-security-card-body"
  data-studio-login-security-widget="true"
  data-score-percent="<?php echo esc_attr((string) $percent); ?>"
  data-ring-c="<?php echo esc_attr((string) $circumference); ?>"
>
  <div class="yp-studio-login-security-card-body__row">
    <div
      class="yp-studio-security-score yp-studio-security-score--<?php echo esc_attr($status_key); ?>"
      data-security-score-ring
      role="img"
      aria-label="<?php echo esc_attr(sprintf(
          /* translators: 1: percent, 2: status label */
          __('%1$d%% — %2$s', 'yooadmin'),
          $percent,
          $status_label
      )); ?>"
    >
      <svg class="yp-studio-security-score__svg" viewBox="0 0 100 100" aria-hidden="true" focusable="false">
        <circle
          class="yp-studio-security-score__track"
          cx="50"
          cy="50"
          r="<?php echo esc_attr((string) $ring_radius); ?>"
          fill="none"
          stroke="<?php echo esc_attr($track_stroke); ?>"
          stroke-width="8"
        />
        <circle
          class="yp-studio-security-score__bar"
          cx="50"
          cy="50"
          r="<?php echo esc_attr((string) $ring_radius); ?>"
          fill="none"
          stroke="<?php echo esc_attr($bar_stroke); ?>"
          stroke-width="8"
          stroke-linecap="round"
          stroke-dasharray="<?php echo esc_attr((string) $circumference); ?>"
          stroke-dashoffset="<?php echo esc_attr((string) $ring_offset_initial); ?>"
          data-ring-bar
        />
      </svg>
      <div class="yp-studio-security-score__label">
        <span class="yp-studio-security-score__value" data-score-value>0</span>
        <span class="yp-studio-security-score__suffix">%</span>
      </div>
    </div>

    <div class="yp-studio-login-security-card-body__copy">
      <p class="yp-studio-login-security-card-body__status"><?php echo esc_html($status_label); ?></p>
      <?php if ($total > 0) : ?>
        <p class="yp-studio-login-security-card-body__meta">
          <?php
          echo esc_html(
              sprintf(
                  /* translators: 1: active protections, 2: total protections */
                  _n('%1$d of %2$d protection active', '%1$d of %2$d protections active', $total, 'yooadmin'),
                  $active,
                  $total
              )
          );
          ?>
        </p>
      <?php endif; ?>
      <?php if ($tips !== []) : ?>
        <ul class="yp-studio-login-security-card-body__tips">
          <?php foreach (array_slice($tips, 0, 2) as $tip) : ?>
            <li><?php echo esc_html((string) $tip); ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>

  <div class="yp-studio-aside-footer yp-studio-updates-footer">
    <a class="yp-studio-updates-view-all yp-studio-updates-view-all--link" href="<?php echo esc_url($settings_url); ?>">
      <?php esc_html_e('Security settings', 'yooadmin'); ?>
      <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
    </a>
  </div>
</div>
