<?php
defined('ABSPATH') || exit;
?>
  <div class="yp-studio-aside-card yp-studio-aside-card--updates yp-dashboard-section yp-studio-aside-layout-section"
       data-section-id="studio-updates"
       data-layout-section="true"
       data-collapsible="false"
       data-sortable="true"
       data-collapsed="false"
       data-custom-placement="aside"<?php echo function_exists('yooadmin_studio_hub_section_hidden_attrs') ? yooadmin_studio_hub_section_hidden_attrs('studio-updates') : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
    <div class="yp-card-header yp-section-header yp-layout-section-handle">
      <span class="yp-layout-section-drag-handle" aria-hidden="true">
        <span class="dashicons dashicons-move" aria-hidden="true"></span>
      </span>
      <h2 class="yp-card-title yp-section-title yp-studio-aside-section__title">
        <span class="dashicons dashicons-update" aria-hidden="true"></span>
        <span class="yp-studio-aside-section__title-label"><?php esc_html_e('Updates', 'yooadmin'); ?></span>
      </h2>
      <div class="yp-card-header-actions">
        <button type="button"
                class="yp-layout-section-remove"
                aria-label="<?php esc_attr_e('Remove section', 'yooadmin'); ?>"
                aria-hidden="true">
          <span class="dashicons dashicons-trash" aria-hidden="true"></span>
        </button>
      </div>
    </div>
    <?php include __DIR__ . '/dashboard-card-updates-body.php'; ?>
  </div>
