<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

/**
 * YOOAdmin — Studio Hub: core workspace (mockup rows: icon + title + description).
 *
 * @package YOOAdmin Extended
 */

$split = isset($studio_hub_split) && is_array($studio_hub_split)
    ? $studio_hub_split
    : (function_exists('yooadmin_build_admin_menu_tree') && function_exists('yooadmin_studio_hub_split_menu_tree')
        ? yooadmin_studio_hub_split_menu_tree((array) yooadmin_build_admin_menu_tree())
        : ['core' => [], 'extensions' => []]);

$core_items = isset($split['core']) && is_array($split['core']) ? $split['core'] : [];

$slug_key = static function ($slug) {
    $k = strtolower(preg_replace('~[^a-zA-Z0-9_\-\.]~', '_', (string) $slug));
    return $k ?: 'menu';
};

$extract_badge = static function (string $title): array {
    $clean = trim($title);
    $badge = '';

    if ($clean === '') {
        return ['title' => $clean, 'badge' => $badge];
    }

    if (preg_match('/^(.*?)[(（]\s*(\d+)\s*[)）]\s*$/u', $clean, $m)) {
        $clean = trim($m[1]);
        $badge = $m[2];
    } elseif (preg_match('/^(.*?\D)(\d+)\s*$/u', $clean, $m)) {
        $clean = trim($m[1]);
        $badge = $m[2];
    } elseif (preg_match('/^\s*(\d+)\s+(.+)$/u', $clean, $m)) {
        $rest = strtolower(trim($m[2]));
        if (preg_match('/(?:update|updates|pending|comment|comments|order|orders|plugin|plugins|review|reviews|message|messages|draft|drafts)\b/', $rest)) {
            $badge = $m[1];
            $clean = trim($m[2]);
        }
    }
    if ($badge !== '' && (int) $badge <= 0) {
        $badge = '';
    }
    if ($badge === '') {
        $clean = trim((string) preg_replace('/\s+0\s*$/u', '', $clean));
    }

    return ['title' => $clean, 'badge' => $badge];
};

$map_group = static function (string $slug, string $url): string {
    $slug_l = strtolower($slug);
    $url_l  = strtolower($url);

    if (strpos($slug_l, 'plugins.php') !== false || strpos($url_l, 'plugins.php') !== false) {
        return 'wp-plugin-updates';
    }
    if (strpos($slug_l, 'yooadmin-plugins') !== false || strpos($url_l, 'yooadmin-plugins') !== false) {
        return 'wp-plugin-updates';
    }
    if (strpos($slug_l, 'themes.php') !== false || strpos($url_l, 'themes.php') !== false) {
        return 'wp-theme-updates';
    }
    if (strpos($slug_l, 'yooadmin-update-center') !== false || strpos($url_l, 'yooadmin-update-center') !== false) {
        return 'wp-core-update';
    }
    if (strpos($slug_l, 'update-core') !== false || strpos($url_l, 'update-core') !== false) {
        if (strpos($url_l, 'tab=translations') !== false) {
            return 'wp-translation-updates';
        }
        return 'wp-core-update';
    }
    if (strpos($slug_l, 'edit-comments.php') !== false || strpos($url_l, 'edit-comments.php') !== false) {
        return 'wp-comments-pending';
    }
    if (strpos($slug_l, 'yooadmin-extensions') !== false || strpos($url_l, 'yooadmin-extensions') !== false) {
        return 'yooadmin-extensions-update';
    }
    if (strpos($slug_l, 'edit.php') !== false && strpos($slug_l, 'post_type=shop_order') !== false) {
        return 'wp-order-updates';
    }

    return '';
};

$row_partial = dirname(__DIR__) . '/partials/studio-hub-workspace-row.php';
$tile_prefix = 'main';
?>
<div class="yp-card yp-card-full yp-dashboard-section yp-studio-surface-card"
     data-section-id="your-workspace"
     data-layout-section="true"
     data-collapsible="true"
     data-sortable="true"
     data-collapsed="false"
     data-default-section-icon="dashicons-layout">
  <div class="yp-card-header yp-section-header yp-layout-section-handle">
    <h2 class="yp-card-title yp-section-title">
      <span class="dashicons dashicons-layout" aria-hidden="true"></span>
      <?php echo esc_html__('Your workspace', 'yooadmin'); ?>
    </h2>
    <div class="yp-card-header-actions">
      <?php if (function_exists('yooadmin_user_can_manage_site_settings') && yooadmin_user_can_manage_site_settings()) : ?>
      <button type="button"
              class="yp-card-edit-reset"
              data-icon-edit-reset="main-grid">
        <?php esc_html_e('Reset', 'yooadmin'); ?>
      </button>
      <button type="button"
              class="yp-card-edit-toggle"
              data-icon-edit-toggle="main-grid"
              data-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>"
              data-active-label="<?php echo esc_attr__('Done', 'yooadmin'); ?>"
              aria-label="<?php echo esc_attr__('Edit', 'yooadmin'); ?>">
        <span class="dashicons dashicons-edit" aria-hidden="true"></span>
      </button>
      <?php endif; ?>
    </div>
  </div>

  <div class="yp-studio-section-body">
    <div class="yp-website-management-loading yp-studio-section-loading" aria-hidden="false">
      <div class="yp-loading-spinner">
        <div class="yp-spinner-circle"></div>
      </div>
    </div>

    <div class="yp-icon-grid-boxes yp-cards-grid yp-studio-workspace-grid yp-studio-workspace-rows"
         data-layout="grid"
         data-columns="auto"
         data-sortable="true"
         >
    <?php
    if (file_exists($row_partial)) :
        foreach ($core_items as $item) :
            if (!is_array($item)) {
                continue;
            }
            include $row_partial;
        endforeach;
    endif;
    ?>
    </div>
  </div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
