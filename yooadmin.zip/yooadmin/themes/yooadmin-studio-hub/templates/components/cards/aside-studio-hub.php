<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

/**
 * Studio Hub — sidebar sections in saved order (server layout).
 */

$studio_hub_layout_for_aside = null;
if (isset($studio_hub_user_layout) && is_array($studio_hub_user_layout)) {
    $studio_hub_layout_for_aside = $studio_hub_user_layout;
} elseif (function_exists('yooadmin_studio_hub_get_user_layout')) {
    $studio_hub_layout_for_aside = yooadmin_studio_hub_get_user_layout();
}
if (
    !$studio_hub_layout_for_aside
    && function_exists('yooadmin_studio_hub_layout_defaults_for_display')
) {
    $studio_hub_layout_for_aside = yooadmin_studio_hub_layout_defaults_for_display();
}

if (!isset($studio_hub_extensions_in_aside)) {
    $studio_hub_extensions_in_aside = function_exists('yooadmin_studio_hub_section_in_aside')
        && yooadmin_studio_hub_section_in_aside('from-extensions', $studio_hub_layout_for_aside);
}

$studio_hub_aside_empty = function_exists('yooadmin_studio_hub_should_collapse_aside_for_user')
    && yooadmin_studio_hub_should_collapse_aside_for_user();
$studio_hub_aside_class  = 'yp-studio-hub__aside' . ($studio_hub_aside_empty ? ' yp-studio-hub__aside--empty' : '');
$studio_hub_aside_order  = function_exists('yooadmin_studio_hub_resolve_aside_order')
    ? yooadmin_studio_hub_resolve_aside_order($studio_hub_layout_for_aside)
    : ['studio-workspace-notes', 'studio-updates', 'studio-tips', 'studio-activity'];
$studio_hub_aside_order_attr = implode(',', $studio_hub_aside_order);
$studio_hub_cards_dir      = __DIR__;

?>
<div
  class="<?php echo esc_attr($studio_hub_aside_class); ?>"
  data-default-aside-order="<?php echo esc_attr($studio_hub_aside_order_attr); ?>"
  aria-label="<?php esc_attr_e('Sidebar', 'yooadmin'); ?>"
  <?php echo $studio_hub_aside_empty ? ' aria-hidden="true"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
>
  <?php
  foreach ($studio_hub_aside_order as $studio_hub_aside_section_id) {
      if (function_exists('yooadmin_studio_hub_render_aside_section')) {
          yooadmin_studio_hub_render_aside_section(
              (string) $studio_hub_aside_section_id,
              $studio_hub_layout_for_aside,
              $studio_hub_cards_dir
          );
      }
  }
  ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
