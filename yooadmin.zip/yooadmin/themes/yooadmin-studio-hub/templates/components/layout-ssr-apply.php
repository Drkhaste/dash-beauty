<?php
defined('ABSPATH') || exit;

/**
 * Apply saved layout (sections + cross-section cards) before first paint.
 */
?>
<script id="yooadmin-studio-hub-layout-ssr-apply">
(function () {
  'use strict';

  var root = document.querySelector('.yp-studio-hub--dashboard');
  if (!root) {
    return;
  }
  var hiddenCardIds = Object.create(null);

  function getSectionGrid(section) {
    if (!section) {
      return null;
    }
    return (
      section.querySelector('.yp-cards-grid[data-sortable="true"]') ||
      section.querySelector('.yp-cards-grid')
    );
  }

  function captureFactoryCards() {
    var cards = {};
    root.querySelectorAll('.yp-dashboard-section[data-section-id]').forEach(function (section) {
      var sectionId = section.getAttribute('data-section-id');
      if (!sectionId) {
        return;
      }
      var grid = getSectionGrid(section);
      if (!grid) {
        return;
      }
      cards[sectionId] = Array.prototype.map
        .call(grid.querySelectorAll('[data-card-id]'), function (card) {
          return card.getAttribute('data-card-id') || '';
        })
        .filter(Boolean);
    });
    try {
      root.setAttribute('data-factory-cards', JSON.stringify(cards));
    } catch (e) {
      /* ignore */
    }
  }

  function reorderSections(container, orderIds) {
    if (!container || !orderIds || !orderIds.length) {
      return;
    }
    var map = Object.create(null);
    Array.prototype.slice
      .call(container.querySelectorAll(':scope > .yp-dashboard-section[data-layout-section="true"]'))
      .forEach(function (section) {
        var id = section.getAttribute('data-section-id');
        if (id) {
          map[id] = section;
        }
      });
    orderIds.forEach(function (id) {
      if (map[id]) {
        container.appendChild(map[id]);
      }
    });
  }

  /** Move cards between sections and restore per-section order from storage. */
  function applyCardsLayout(cardsBySection) {
    if (!cardsBySection || typeof cardsBySection !== 'object') {
      return;
    }

    var cardNodes = Object.create(null);
    root.querySelectorAll('[data-card-id]').forEach(function (card) {
      var id = card.getAttribute('data-card-id');
      if (id) {
        cardNodes[id] = card;
      }
    });

    Object.keys(cardsBySection).forEach(function (sectionId) {
      var section = root.querySelector('[data-section-id="' + sectionId + '"]');
      if (!section) {
        return;
      }
      var grid = getSectionGrid(section);
      if (!grid) {
        return;
      }
      var ids = cardsBySection[sectionId];
      if (!Array.isArray(ids)) {
        return;
      }
      ids.forEach(function (cid) {
        if (cardNodes[cid]) {
          var card = cardNodes[cid];
          var hint = grid.querySelector('[data-layout-empty-hint]');
          var loader = grid.querySelector('[data-layout-loading]');
          if (hint && hint.parentNode === grid) {
            grid.insertBefore(card, hint);
          } else if (loader && loader.parentNode === grid) {
            grid.insertBefore(card, loader.nextSibling);
          } else {
            grid.appendChild(card);
          }
        }
      });
    });
  }

  function finalizeCustomSectionBooting(section) {
    if (!section || !section.classList.contains('yp-studio-custom-section')) {
      return;
    }
    var grid = getSectionGrid(section);
    if (grid) {
      grid.classList.add('is-hydrated');
    }
    section.querySelectorAll('[data-layout-loading]').forEach(function (el) {
      if (el.parentNode) {
        el.parentNode.removeChild(el);
      }
    });
    section.classList.remove('yp-studio-layout-section--booting');
    section.removeAttribute('data-layout-booting');
  }

  function finalizeAllCustomSectionBooting() {
    root
      .querySelectorAll(
        '.yp-studio-custom-section.yp-studio-layout-section--booting, .yp-studio-custom-section[data-layout-booting]'
      )
      .forEach(finalizeCustomSectionBooting);
  }

  function sectionHasWidgets(section) {
    var widgets = section.querySelector('.yp-studio-extensions-widgets');
    if (!widgets) {
      return false;
    }
    return widgets.children.length > 0 || (widgets.textContent || '').trim() !== '';
  }

  function sectionIsEmpty(section) {
    if (!section) {
      return true;
    }
    var grid = getSectionGrid(section);
    if (grid) {
      var hasVisibleCard = Array.prototype.some.call(grid.querySelectorAll('[data-card-id]'), function (card) {
        var cardId = card.getAttribute('data-card-id') || '';
        return !!(cardId && !hiddenCardIds[cardId] && card.getAttribute('data-hidden') !== 'true');
      });
      if (hasVisibleCard) {
        return false;
      }
    }
    return !sectionHasWidgets(section);
  }

  function finalizeExtensionsSection(section) {
    if (!section || section.getAttribute('data-section-id') !== 'from-extensions') {
      return;
    }
    var grid = getSectionGrid(section);
    var loading = section.querySelector('.yp-extensions-grid-loading');
    if (loading) {
      loading.classList.add('is-hidden');
      loading.setAttribute('aria-hidden', 'true');
    }
    section.removeAttribute('data-extensions-pending');
    section.classList.add('yp-layout-section--hydrated');
    if (grid) {
      grid.classList.add('is-hydrated');
    }
  }

  function hideEmptySection(section) {
    if (!section || !sectionIsEmpty(section)) {
      return;
    }

    var sectionId = section.getAttribute('data-section-id') || '';
    section.classList.add('yp-layout-section--empty');

    if (sectionId === 'from-extensions' || section.classList.contains('yp-studio-custom-section')) {
      section.classList.add('yp-layout-section--hidden');
      section.setAttribute('hidden', 'hidden');
    }

    if (sectionId === 'from-extensions') {
      finalizeExtensionsSection(section);
      var grid = getSectionGrid(section);
      if (grid) {
        grid.classList.add('is-grid-empty');
        grid.hidden = true;
        grid.setAttribute('hidden', 'hidden');
      }
      var lead = section.querySelector('.yp-studio-extensions-lead');
      if (lead) {
        lead.hidden = true;
      }
    }
  }

  function applyHiddenSections(layout) {
    if (!layout || !Array.isArray(layout.hiddenSections) || !layout.hiddenSections.length) {
      return;
    }
    layout.hiddenSections.forEach(function (id) {
      if (!id) {
        return;
      }
      var section = root.querySelector('[data-section-id="' + id + '"]');
      if (section) {
        section.setAttribute('data-section-hidden', 'true');
        section.classList.add('is-dashboard-section-hidden');
      }
    });
  }

  function applyRemovedSections(layout) {
    var removed = [];
    if (layout && Array.isArray(layout.removedBuiltInSections)) {
      removed = layout.removedBuiltInSections.slice();
    } else if (!layout || (!layout.hiddenSectionsExplicit && !layout.asideVisibilityTouched)) {
      removed = ['studio-activity'];
    }
    removed.forEach(function (id) {
      if (!id) {
        return;
      }
      var section = root.querySelector('[data-section-id="' + id + '"]');
      if (section && section.parentNode) {
        section.parentNode.removeChild(section);
      }
    });
  }

  function applyHiddenCards(layout) {
    hiddenCardIds = Object.create(null);
    if (!layout || !Array.isArray(layout.hidden) || !layout.hidden.length) {
      return;
    }
    layout.hidden.forEach(function (id) {
      if (!id) {
        return;
      }
      hiddenCardIds[id] = true;
      root.querySelectorAll('[data-card-id="' + id + '"]').forEach(function (card) {
        card.setAttribute('data-hidden', 'true');
        card.setAttribute('aria-disabled', 'true');
        card.classList.add('is-dashboard-card-hidden');
      });
    });
  }

  function syncAsideCollapse() {
    var layoutEl = root.querySelector('.yp-studio-hub__layout');
    var asideEl = root.querySelector('.yp-studio-hub__aside');
    if (!layoutEl || !asideEl) {
      return;
    }

    var hasVisible = false;
    asideEl.querySelectorAll('.yp-dashboard-section[data-layout-section="true"]').forEach(function (section) {
      if (section.getAttribute('data-section-hidden') === 'true') {
        return;
      }
      if (section.classList.contains('yp-layout-section--hidden') || section.hasAttribute('hidden')) {
        return;
      }
      hasVisible = true;
    });

    layoutEl.classList.toggle('yp-studio-hub__layout--aside-empty', !hasVisible);
    asideEl.classList.toggle('yp-studio-hub__aside--empty', !hasVisible);
    if (!hasVisible) {
      asideEl.setAttribute('aria-hidden', 'true');
    } else {
      asideEl.removeAttribute('aria-hidden');
    }
  }

  function finalizeEmptySections() {
    root.querySelectorAll('.yp-dashboard-section[data-layout-section="true"]').forEach(function (section) {
      hideEmptySection(section);
    });
    syncAsideCollapse();
  }

  function finishSsrApply() {
    root.removeAttribute('data-layout-ssr-pending');
    root.setAttribute('data-layout-ssr-applied', '1');
  }

  captureFactoryCards();

  var raw = root.getAttribute('data-initial-layout');
  if (!raw) {
    finalizeEmptySections();
    finishSsrApply();
    return;
  }

  var layout;
  try {
    layout = JSON.parse(raw);
  } catch (e) {
    finalizeEmptySections();
    finishSsrApply();
    return;
  }

  if (!layout || layout.version !== 1) {
    finalizeEmptySections();
    finishSsrApply();
    return;
  }

  var mainCol = root.querySelector('.yp-studio-hub__main');
  var asideCol = root.querySelector('.yp-studio-hub__aside');
  if (mainCol && Array.isArray(layout.mainOrder) && layout.mainOrder.length) {
    reorderSections(mainCol, layout.mainOrder);
  }
  if (asideCol && Array.isArray(layout.asideOrder) && layout.asideOrder.length) {
    reorderSections(asideCol, layout.asideOrder);
  }

  if (layout.cards && typeof layout.cards === 'object') {
    applyCardsLayout(layout.cards);
  }

  applyHiddenCards(layout);
  applyRemovedSections(layout);
  applyHiddenSections(layout);
  finalizeEmptySections();
  finishSsrApply();
})();
</script>
