<?php
/**
 * Single dashboard menu tile (Studio Hub workspace or extensions grid).
 *
 * Expects in scope: $item (array), $slug_key (callable), $extract_badge (callable),
 * $map_group (callable), $tile_prefix (string).
 *
 * @package YOOAdmin Extended
 */

defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Partial; variables from parent template.

if (!isset($item) || !is_array($item)) {
    return;
}
if (!is_callable($slug_key) || !is_callable($extract_badge) || !is_callable($map_group)) {
    return;
}

$prefix = isset($tile_prefix) ? (string) $tile_prefix : 'main';

$title   = isset($item['title']) ? (string) $item['title'] : '';
$url     = isset($item['url']) ? (string) $item['url'] : '';
$icon    = isset($item['icon']) ? (string) $item['icon'] : '';
$slug    = isset($item['slug']) ? (string) $item['slug'] : '';
$has_sub = !empty($item['has_sub']);

if ($title === '' || $url === '') {
    return;
}

$parsed        = $extract_badge($title);
$clean_title   = $parsed['title'];
$badge_value   = $parsed['badge'];
$group_key     = $map_group($slug, $url);
$has_badge     = $badge_value !== '' && (int) $badge_value > 0;
$key_seed      = $slug !== '' ? $slug : $url;
$card_key      = $prefix . '-' . $slug_key($key_seed);
$is_external   = (strpos($url, 'http://') === 0 || strpos($url, 'https://') === 0) && strpos($url, admin_url()) !== 0;
?>
<a
  href="<?php echo esc_url($url); ?>"
  <?php if ($is_external) : ?>target="_blank" rel="noopener noreferrer"<?php endif; ?>
  class="yp-icon-tile<?php echo $has_badge ? ' has-badge' : ''; ?>"
  data-card-key="<?php echo esc_attr($card_key); ?>"
  data-card-id="<?php echo esc_attr($card_key); ?>"
  data-draggable="true"
  data-resizable="true"
  data-size="normal"
  <?php if ($has_badge) : ?>
    data-badge="<?php echo esc_attr($badge_value); ?>"
  <?php endif; ?>
  <?php if ($group_key !== '') : ?>
    data-feed-group="<?php echo esc_attr($group_key); ?>"
  <?php endif; ?>
  <?php if ($has_sub) : ?>
    data-menu-slug="<?php echo esc_attr($slug_key($slug)); ?>"
    data-card-title="<?php echo esc_attr($clean_title); ?>"
  <?php endif; ?>
  title="<?php echo esc_attr($clean_title); ?>"
  data-default-icon="<?php echo esc_attr($icon); ?>"
>
  <span class="yp-icon">
    <?php if (strpos($icon, 'dashicons-') === 0) : ?>
      <span class="dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
    <?php elseif (strpos($icon, 'data:image/svg+xml') === 0) : ?>
      <?php
      $svg_content = '';
      if (preg_match('/data:image\/svg\+xml(?:;base64)?,(.+)/', $icon, $matches)) {
          $encoded = $matches[1];
          if (strpos($icon, 'base64') !== false) {
              $svg_content = @base64_decode($encoded, true);
          } else {
              $svg_content = @urldecode($encoded);
          }
          if ($svg_content && strpos(trim($svg_content), '<svg') === 0) {
              $svg_content = preg_replace('/\s+(width|height)=["\'][^"\']*["\']/i', '', $svg_content);
              $svg_content = preg_replace(
                  '/<svg([^>]*)>/i',
                  '<svg$1 width="46" height="46" class="ypi-skip-mask" style="width:46px !important;height:46px !important;max-width:46px !important;max-height:46px !important;min-width:46px !important;min-height:46px !important;display:block;margin:0;padding:0;flex-shrink:0;box-sizing:border-box;">',
                  $svg_content
              );
              echo wp_kses(
                  $svg_content,
                  [
                      'svg'    => [
                          'xmlns'   => true,
                          'viewbox' => true,
                          'viewBox' => true,
                          'width'   => true,
                          'height'  => true,
                          'class'   => true,
                          'style'   => true,
                      ],
                      'path'   => [
                          'd'            => true,
                          'fill'         => true,
                          'stroke'       => true,
                          'stroke-width' => true,
                          'class'        => true,
                      ],
                      'circle' => ['cx' => true, 'cy' => true, 'r' => true, 'fill' => true],
                      'rect'   => ['x' => true, 'y' => true, 'width' => true, 'height' => true, 'fill' => true],
                      'g'      => ['fill' => true, 'class' => true],
                  ]
              );
          } else {
              echo '<img src="' . esc_url($icon) . '" alt="" loading="eager" decoding="async" />';
          }
      } else {
          echo '<img src="' . esc_url($icon) . '" alt="" loading="eager" decoding="async" />';
      }
      ?>
    <?php elseif (strpos($icon, 'http') === 0 || strpos($icon, 'data:') === 0) : ?>
      <img src="<?php echo esc_url($icon); ?>" alt="" loading="eager" decoding="async" />
    <?php else : ?>
      <span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
    <?php endif; ?>
  </span>
  <span class="yp-icon-label"><?php echo esc_html($clean_title); ?></span>
  <?php if ($group_key !== '') : ?>
    <span class="yp-card-badge" data-feed-group="<?php echo esc_attr($group_key); ?>"
          <?php if (!$has_badge) : ?>hidden<?php endif; ?>>
      <?php echo $has_badge ? esc_html($badge_value) : ''; ?>
    </span>
  <?php elseif ($has_badge) : ?>
    <span class="yp-card-badge"
          <?php if (!$has_badge) : ?>hidden<?php endif; ?>>
      <?php echo esc_html($badge_value); ?>
    </span>
  <?php endif; ?>
  <span class="yp-card-icon-edit"
        role="button"
        tabindex="0"
        aria-label="<?php esc_attr_e('Change icon', 'yooadmin'); ?>"
        data-card-key="<?php echo esc_attr($card_key); ?>">
    <span class="dashicons dashicons-edit" aria-hidden="true"></span>
  </span>
</a>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
