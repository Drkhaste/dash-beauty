<?php
defined('ABSPATH') || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template file.

/**
 * Studio Hub — dashboard home (theme template).
 */

if (!defined('YOOADMIN_PLUGIN_FILE')) {
    return;
}

$theme_base = defined('YOOADMIN_ACTIVE_ADMIN_THEME_DIR')
    ? trailingslashit((string) YOOADMIN_ACTIVE_ADMIN_THEME_DIR)
    : trailingslashit(dirname(__DIR__, 2));

if (!defined('YOOADMIN_ACTIVE_ADMIN_THEME_DIR')) {
    define('YOOADMIN_ACTIVE_ADMIN_THEME_DIR', $theme_base);
}

$BASE  = $theme_base . 'templates';
$CARDS = $BASE . '/components/cards';

$studio_hub_split = ['core' => [], 'extensions' => []];
if (function_exists('yooadmin_build_admin_menu_tree')) {
    $full_tree = (array) yooadmin_build_admin_menu_tree();
    $studio_hub_split = function_exists('yooadmin_studio_hub_split_menu_tree')
        ? yooadmin_studio_hub_split_menu_tree($full_tree)
        : ['core' => $full_tree, 'extensions' => []];
}

$plugin_tpl = plugin_dir_path(YOOADMIN_PLUGIN_FILE) . 'templates/yoopixel/admin';

$studio_hub_user_layout = null;
if (function_exists('yooadmin_studio_hub_get_user_layout')) {
    $studio_hub_user_layout = yooadmin_studio_hub_get_user_layout(get_current_user_id());
}
if (
    !$studio_hub_user_layout
    && function_exists('yooadmin_studio_hub_layout_defaults_for_display')
) {
    $studio_hub_user_layout = yooadmin_studio_hub_layout_defaults_for_display();
}

$studio_hub_collapse_aside = function_exists('yooadmin_studio_hub_should_collapse_aside_for_user')
    && yooadmin_studio_hub_should_collapse_aside_for_user();
$studio_hub_layout_class   = 'yp-studio-hub__layout' . ($studio_hub_collapse_aside ? ' yp-studio-hub__layout--aside-empty' : '');
$studio_hub_factory_layout = function_exists('yooadmin_studio_hub_layout_defaults_for_display')
    ? yooadmin_studio_hub_layout_defaults_for_display()
    : null;
$studio_hub_factory_widget_sections = is_array($studio_hub_factory_layout)
    && isset($studio_hub_factory_layout['widgetSections'])
    && is_array($studio_hub_factory_layout['widgetSections'])
    ? $studio_hub_factory_layout['widgetSections']
    : [];
$studio_hub_factory_aside_order = is_array($studio_hub_factory_layout)
    && isset($studio_hub_factory_layout['asideOrder'])
    && is_array($studio_hub_factory_layout['asideOrder'])
    ? $studio_hub_factory_layout['asideOrder']
    : [];
$studio_hub_extensions_in_aside = function_exists('yooadmin_studio_hub_section_in_aside')
    && yooadmin_studio_hub_section_in_aside('from-extensions', $studio_hub_user_layout);
$yooadmin_studio_hub_extensions_placement = $studio_hub_extensions_in_aside ? 'aside' : 'main';
$studio_hub_main_order = function_exists('yooadmin_studio_hub_resolve_main_order')
    ? yooadmin_studio_hub_resolve_main_order($studio_hub_user_layout)
    : ['your-workspace', 'from-extensions'];
?>
<style id="yooadmin-studio-hub-layout-hidden-critical">
body:not(.yp-icon-edit-mode):not(.yp-layout-edit-mode).yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-aside-layout-section[data-section-hidden="true"],
body:not(.yp-icon-edit-mode):not(.yp-layout-edit-mode).yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-widget-section[data-section-hidden="true"],
body:not(.yp-icon-edit-mode):not(.yp-layout-edit-mode).yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-extensions-card[data-section-hidden="true"],
body:not(.yp-icon-edit-mode):not(.yp-layout-edit-mode).yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-extensions-card.yp-layout-section--hidden,
body:not(.yp-icon-edit-mode):not(.yp-layout-edit-mode).yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-extensions-card.yp-layout-section--empty {
  display: none !important;
}
body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-hub__layout.yp-studio-hub__layout--aside-empty {
  grid-template-columns: minmax(0, 1fr) !important;
}
body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-hub__layout.yp-studio-hub__layout--aside-empty > .yp-studio-hub__aside {
  display: none !important;
}
body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-hub__layout--aside-empty .yp-studio-hub__primary {
  width: 100% !important;
  max-width: 100% !important;
}
body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard[data-layout-ssr-pending="1"] .yp-studio-hub__layout {
  visibility: hidden;
}
@media (max-width: 1100px) {
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-hub__layout {
    display: flex;
    flex-direction: column;
  }
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-hub__primary {
    display: contents;
  }
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-dashboard-grid[data-yooadmin-top-section="true"] {
    order: -1;
  }
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-hub__aside {
    order: 0;
  }
}
@media (max-width: 782px) {
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-workspace-rows.yp-cards-grid,
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-custom-section .yp-studio-custom-grid.yp-cards-grid,
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-extensions-card .yp-studio-extensions-grid.yp-cards-grid {
    display: grid !important;
    grid-template-columns: 1fr !important;
    gap: 10px !important;
  }
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-extensions-card .yp-studio-extensions-body {
    padding-left: 0 !important;
    padding-right: 0 !important;
  }
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-extensions-card .yp-studio-section-body,
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-extensions-card .yp-studio-extensions-grid.yp-cards-grid {
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
  }
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-icon-tile.yp-studio-ws-row {
    width: 100% !important;
    min-height: 68px;
    padding: 10px 12px;
    gap: 10px;
    flex-direction: row !important;
    align-items: center;
  }
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-ws-row .yp-icon-label {
    overflow-wrap: anywhere;
  }
  body.yooadmin-theme-yooadmin-studio-hub .yp-studio-hub--dashboard .yp-studio-ws-row .yp-studio-ws-row__desc {
    font-size: 12px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    overflow: hidden;
  }
}
</style>
<div
  class="yp-studio-hub yp-studio-hub--dashboard"
  data-layout-ssr-pending="1"
  data-layout-nonce="<?php echo esc_attr(wp_create_nonce('yooadmin_studio_hub_layout')); ?>"
  data-layout-ajax="<?php echo esc_url(function_exists('yooadmin_admin_ajax_url') ? yooadmin_admin_ajax_url() : admin_url('admin-ajax.php')); ?>"
  data-factory-widget-sections="<?php echo esc_attr(wp_json_encode($studio_hub_factory_widget_sections)); ?>"
  data-factory-aside-order="<?php echo esc_attr(wp_json_encode($studio_hub_factory_aside_order)); ?>"
  <?php if (is_array($studio_hub_user_layout)) : ?>
    data-initial-layout="<?php echo esc_attr(wp_json_encode($studio_hub_user_layout)); ?>"
  <?php endif; ?>
>
  <div class="<?php echo esc_attr($studio_hub_layout_class); ?>">
    <div class="yp-studio-hub__primary">
        <?php
        $section_top = $CARDS . '/section-top-studio.php';
        if (file_exists($section_top)) {
            include $section_top;
        }
        ?>
      <div class="yp-studio-hub__main">
        <?php
        foreach ($studio_hub_main_order as $studio_hub_main_section_id) {
            if (function_exists('yooadmin_studio_hub_render_main_section')) {
                yooadmin_studio_hub_render_main_section(
                    (string) $studio_hub_main_section_id,
                    $studio_hub_user_layout,
                    $CARDS
                );
            }
        }
        ?>
      </div>
    </div>
    <?php
    $aside = $CARDS . '/aside-studio-hub.php';
    if (file_exists($aside)) {
        include $aside;
    }
    ?>
  </div>

    <?php
    $layout_ssr_apply = $BASE . '/components/layout-ssr-apply.php';
    if (is_readable($layout_ssr_apply)) {
        include $layout_ssr_apply;
    }

    $popup = $plugin_tpl . '/popup.php';
    if (is_readable($popup)) {
        include $popup;
    }

    ?>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
