<?php
/**
 * Studio Hub dashboard — Tips carousel data (large pool; random subset per page load).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_studio_hub_tips_asset_url')) {
    /**
     * Public URL for a theme asset under assets/.
     */
    function yooadmin_studio_hub_tips_asset_url(string $relative): string {
        $base = defined('YOOADMIN_ACTIVE_ADMIN_THEME_DIR')
            ? trailingslashit((string) YOOADMIN_ACTIVE_ADMIN_THEME_DIR)
            : trailingslashit(dirname(__DIR__));

        return plugins_url('assets/' . ltrim($relative, '/'), $base . 'theme.php');
    }
}

if (!function_exists('yooadmin_studio_hub_tip_entry')) {
    /**
     * @param array<string, string> $args
     * @return array<string, string>
     */
    function yooadmin_studio_hub_tip_entry(array $args): array {
        static $images = [
            'organize'   => 'tip-organize.svg',
            'revisions'  => 'tip-revisions.svg',
            'keyboard'   => 'tip-keyboard.svg',
            'media'      => 'tip-media.svg',
            'updates'    => 'tip-updates.svg',
            'roles'      => 'tip-roles.svg',
            'permalinks' => 'tip-permalinks.svg',
            'preview'    => 'tip-preview.svg',
            'health'     => 'tip-health.svg',
            'focus'      => 'tip-focus.svg',
            'quick'      => 'tip-quick.svg',
            'workspace'  => 'tip-workspace.svg',
            'comments'   => 'tip-comments.svg',
            'privacy'    => 'tip-privacy.svg',
            'theme'      => 'tip-theme.svg',
            'autosave'   => 'tip-autosave.svg',
            'search'     => 'tip-search.svg',
            'backup'     => 'tip-backup.svg',
        ];

        $art = isset($args['art']) ? (string) $args['art'] : 'organize';
        $file = $images[$art] ?? $images['organize'];

        return [
            'id'    => (string) ($args['id'] ?? 'tip'),
            'title' => (string) ($args['title'] ?? ''),
            'text'  => (string) ($args['text'] ?? ''),
            'theme' => (string) ($args['theme'] ?? 'brand'),
            'icon'  => (string) ($args['icon'] ?? 'dashicons-lightbulb'),
            'image' => yooadmin_studio_hub_tips_asset_url('images/tips/' . $file),
        ];
    }
}

if (!function_exists('yooadmin_studio_hub_get_all_tips')) {
    /**
     * Full tips pool (WordPress + YOOAdmin).
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_studio_hub_get_all_tips(): array {
        // phpcs:disable WordPress.WP.I18n.TextDomainMismatch
        $t = static function (array $a): array {
            return yooadmin_studio_hub_tip_entry($a);
        };

        $wp = [
            $t([
                'id' => 'wp-categories-tags', 'art' => 'organize', 'theme' => 'amber',
                'icon' => 'dashicons-category',
                'title' => __('Organize with categories & tags', 'yooadmin'),
                'text'  => __('Use categories and tags consistently to keep content easier to browse, manage, and discover.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-revisions', 'art' => 'revisions', 'theme' => 'violet',
                'icon' => 'dashicons-backup',
                'title' => __('Post revisions save you', 'yooadmin'),
                'text'  => __('Restore or compare previous versions directly from the editor when you need to recover changes.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-keyboard', 'art' => 'keyboard', 'theme' => 'teal',
                'icon' => 'dashicons-editor-kitchensink',
                'title' => __('Block editor shortcuts', 'yooadmin'),
                'text'  => __('Open the shortcut guide inside the editor to speed up writing, formatting, and navigation.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-media-alt', 'art' => 'media', 'theme' => 'green',
                'icon' => 'dashicons-format-image',
                'title' => __('Always add alt text', 'yooadmin'),
                'text'  => __('Alt text improves accessibility and helps search engines better understand your images.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-updates', 'art' => 'updates', 'theme' => 'orange',
                'icon' => 'dashicons-update',
                'title' => __('Keep core & plugins updated', 'yooadmin'),
                'text'  => __('Manage WordPress, themes, and plugin updates from one streamlined update center. Back up your site before major upgrades.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-roles', 'art' => 'roles', 'theme' => 'blue',
                'icon' => 'dashicons-groups',
                'title' => __('Use the right user role', 'yooadmin'),
                'text'  => __('Assign only the permissions each user needs to keep your WordPress site secure and organized.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-permalinks', 'art' => 'permalinks', 'theme' => 'indigo',
                'icon' => 'dashicons-admin-links',
                'title' => __('Pretty permalinks', 'yooadmin'),
                'text'  => __('Use readable post-name URLs for cleaner links and better search engine visibility.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-preview', 'art' => 'preview', 'theme' => 'rose',
                'icon' => 'dashicons-visibility',
                'title' => __('Preview before publish', 'yooadmin'),
                'text'  => __('Preview pages and posts before they go live, then schedule publishing for the perfect time.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-site-health', 'art' => 'health', 'theme' => 'cyan',
                'icon' => 'dashicons-heart',
                'title' => __('Check Site Health', 'yooadmin'),
                'text'  => __('Site Health helps monitor performance, security, and recommended WordPress configuration improvements.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-comments', 'art' => 'comments', 'theme' => 'teal',
                'icon' => 'dashicons-admin-comments',
                'title' => __('Moderate comments quickly', 'yooadmin'),
                'text'  => __('Approve, reply, or manage spam directly from the Comments screen without opening each post.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-privacy', 'art' => 'privacy', 'theme' => 'green',
                'icon' => 'dashicons-privacy',
                'title' => __('Privacy & export tools', 'yooadmin'),
                'text'  => __('Built-in privacy tools help manage personal data requests and support modern privacy requirements.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-child-theme', 'art' => 'theme', 'theme' => 'orange',
                'icon' => 'dashicons-admin-appearance',
                'title' => __('Use a child theme', 'yooadmin'),
                'text'  => __('Child themes protect your customizations when the main theme receives updates.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-autosave', 'art' => 'autosave', 'theme' => 'blue',
                'icon' => 'dashicons-saved',
                'title' => __('Autosave drafts', 'yooadmin'),
                'text'  => __('WordPress automatically saves your progress while you work so drafts can be restored if something interrupts your session.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-search', 'art' => 'search', 'theme' => 'indigo',
                'icon' => 'dashicons-search',
                'title' => __('Search & list filters', 'yooadmin'),
                'text'  => __('Use search tools and filters across admin tables to quickly locate posts, users, products, and orders.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-backup', 'art' => 'backup', 'theme' => 'rose',
                'icon' => 'dashicons-cloud-upload',
                'title' => __('Back up before big changes', 'yooadmin'),
                'text'  => __('Before migrations, theme switches, or bulk edits, create a backup to protect your content and settings.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-featured-image', 'art' => 'media', 'theme' => 'amber',
                'icon' => 'dashicons-format-image',
                'title' => __('Set a featured image', 'yooadmin'),
                'text'  => __('Featured images improve archive layouts, social previews, and visual consistency across your site.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-excerpt', 'art' => 'organize', 'theme' => 'violet',
                'icon' => 'dashicons-text',
                'title' => __('Write custom excerpts', 'yooadmin'),
                'text'  => __('Custom excerpts give you better control over preview text across archives and blog pages.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-trash', 'art' => 'revisions', 'theme' => 'teal',
                'icon' => 'dashicons-trash',
                'title' => __('Empty trash periodically', 'yooadmin'),
                'text'  => __('Deleted content stays in Trash until removed permanently. Review items carefully before emptying it.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-bulk-edit', 'art' => 'keyboard', 'theme' => 'green',
                'icon' => 'dashicons-editor-table',
                'title' => __('Bulk edit posts', 'yooadmin'),
                'text'  => __('Update categories, tags, authors, or post status for multiple posts in just a few clicks.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-screen-options', 'art' => 'preview', 'theme' => 'cyan',
                'icon' => 'dashicons-admin-settings',
                'title' => __('Screen Options tab', 'yooadmin'),
                'text'  => __('Customize admin screens by showing or hiding columns, boxes, and table information you use most.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-sticky', 'art' => 'permalinks', 'theme' => 'blue',
                'icon' => 'dashicons-admin-post',
                'title' => __('Sticky posts', 'yooadmin'),
                'text'  => __('Keep important posts pinned at the top of your blog until you choose to remove them.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-patterns', 'art' => 'theme', 'theme' => 'indigo',
                'icon' => 'dashicons-layout',
                'title' => __('Reuse block patterns', 'yooadmin'),
                'text'  => __('Save and reuse layouts to build pages faster and keep designs consistent across your site.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-cron', 'art' => 'updates', 'theme' => 'orange',
                'icon' => 'dashicons-clock',
                'title' => __('Scheduled tasks', 'yooadmin'),
                'text'  => __('WordPress automatically handles scheduled publishing and background tasks behind the scenes.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-passwords', 'art' => 'roles', 'theme' => 'rose',
                'icon' => 'dashicons-lock',
                'title' => __('Strong passwords', 'yooadmin'),
                'text'  => __('Protect administrator accounts with strong passwords and enable two-factor authentication when supported.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-menus', 'art' => 'organize', 'theme' => 'brand',
                'icon' => 'dashicons-menu',
                'title' => __('Manage menus', 'yooadmin'),
                'text'  => __('Build navigation menus and assign them to different theme locations from one central screen.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-widgets', 'art' => 'workspace', 'theme' => 'amber',
                'icon' => 'dashicons-welcome-widgets-menus',
                'title' => __('Widgets & sidebars', 'yooadmin'),
                'text'  => __('Add widgets, content blocks, and tools to sidebars, footers, and widget-ready areas.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-rest-api', 'art' => 'health', 'theme' => 'violet',
                'icon' => 'dashicons-rest-api',
                'title' => __('REST API basics', 'yooadmin'),
                'text'  => __('Modern plugins and editor features rely on the REST API to communicate securely with WordPress.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-database', 'art' => 'backup', 'theme' => 'teal',
                'icon' => 'dashicons-database',
                'title' => __('Database size', 'yooadmin'),
                'text'  => __('Large databases can slow down admin performance. Periodic cleanup helps keep WordPress responsive.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-gutenberg', 'art' => 'keyboard', 'theme' => 'brand',
                'icon' => 'dashicons-block-default',
                'title' => __('Blocks vs classic', 'yooadmin'),
                'text'  => __('Use the block editor for flexible modern layouts, or keep the Classic Editor workflow if your team prefers it.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-customizer', 'art' => 'theme', 'theme' => 'violet',
                'icon' => 'dashicons-admin-customizer',
                'title' => __('Customizer & site editor', 'yooadmin'),
                'text'  => __('Classic themes use the Customizer while block themes use the Site Editor for templates and styles.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-duplicate', 'art' => 'revisions', 'theme' => 'green',
                'icon' => 'dashicons-admin-page',
                'title' => __('Duplicate a post', 'yooadmin'),
                'text'  => __('Reuse existing layouts and content structures without rebuilding pages from scratch.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-sitemaps', 'art' => 'permalinks', 'theme' => 'teal',
                'icon' => 'dashicons-networking',
                'title' => __('Core XML sitemaps', 'yooadmin'),
                'text'  => __('WordPress automatically generates XML sitemaps to help search engines index your content.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-heartbeat', 'art' => 'autosave', 'theme' => 'orange',
                'icon' => 'dashicons-heart',
                'title' => __('Editor autosync', 'yooadmin'),
                'text'  => __('Heartbeat keeps sessions active and syncs changes while you work inside the admin.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-upload-limit', 'art' => 'media', 'theme' => 'blue',
                'icon' => 'dashicons-upload',
                'title' => __('Upload size limits', 'yooadmin'),
                'text'  => __('Large uploads may fail if server upload limits are too low. Hosting settings control the maximum size.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-debug', 'art' => 'health', 'theme' => 'rose',
                'icon' => 'dashicons-warning',
                'title' => __('Debug with care', 'yooadmin'),
                'text'  => __('Use debugging tools only on staging environments to avoid exposing sensitive errors on live sites.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-transients', 'art' => 'backup', 'theme' => 'indigo',
                'icon' => 'dashicons-database-remove',
                'title' => __('Clear expired transients', 'yooadmin'),
                'text'  => __('Expired transient data can accumulate over time. Cleanup helps reduce unnecessary database overhead.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-ssl', 'art' => 'privacy', 'theme' => 'cyan',
                'icon' => 'dashicons-lock',
                'title' => __('HTTPS everywhere', 'yooadmin'),
                'text'  => __('Secure your WordPress site with HTTPS to improve trust, privacy, and browser compatibility.', 'yooadmin'),
            ]),
            $t([
                'id' => 'wp-caching', 'art' => 'updates', 'theme' => 'amber',
                'icon' => 'dashicons-performance',
                'title' => __('Page caching', 'yooadmin'),
                'text'  => __('Caching improves front-end speed and responsiveness. Clear cache after publishing updates or changing menus.', 'yooadmin'),
            ]),
        ];

        $yoo = [
            $t([
                'id' => 'yoo-focus', 'art' => 'focus', 'theme' => 'brand',
                'icon' => 'dashicons-visibility',
                'title' => __('Focus Mode', 'yooadmin'),
                'text'  => __('Enable Focus Mode for a cleaner, distraction-free workspace built around productivity.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-quick-actions', 'art' => 'quick', 'theme' => 'amber',
                'icon' => 'dashicons-performance',
                'title' => __('Quick Actions', 'yooadmin'),
                'text'  => __('Customize Quick Actions for faster access to the screens, tools, and workflows you use most.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-workspace', 'art' => 'workspace', 'theme' => 'violet',
                'icon' => 'dashicons-layout',
                'title' => __('Your workspace layout', 'yooadmin'),
                'text'  => __('Drag and arrange workspace cards in edit mode to build a layout that matches your workflow.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-color-mode', 'art' => 'focus', 'theme' => 'brand',
                'icon' => 'dashicons-art',
                'title' => __('Light, dark, or auto', 'yooadmin'),
                'text'  => __('Switch between light, dark, or automatic appearance modes directly from the header controls.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-plugins-hub', 'art' => 'quick', 'theme' => 'orange',
                'icon' => 'dashicons-admin-plugins',
                'title' => __('YOOAdmin Plugins hub', 'yooadmin'),
                'text'  => __('Manage plugins from a cleaner, card-based experience designed to fit naturally into Studio Hub.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-extensions', 'art' => 'updates', 'theme' => 'teal',
                'icon' => 'dashicons-admin-tools',
                'title' => __('Extensions screen', 'yooadmin'),
                'text'  => __('Discover extensions that expand YOOAdmin with workflow tools, themes, and additional admin experiences.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-settings', 'art' => 'permalinks', 'theme' => 'blue',
                'icon' => 'dashicons-admin-generic',
                'title' => __('YOOAdmin Settings', 'yooadmin'),
                'text'  => __('Control branding, workspace behavior, integrations, and interface preferences from one place.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-icon-edit', 'art' => 'workspace', 'theme' => 'indigo',
                'icon' => 'dashicons-edit',
                'title' => __('Edit dashboard icons', 'yooadmin'),
                'text'  => __('Personalize workspace cards with custom icons or hide sections you rarely use.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-sections-drag', 'art' => 'organize', 'theme' => 'cyan',
                'icon' => 'dashicons-move',
                'title' => __('Reorder sections', 'yooadmin'),
                'text'  => __('Move dashboard sections freely in edit mode to create a layout that feels natural to your workflow.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-notifications', 'art' => 'health', 'theme' => 'green',
                'icon' => 'dashicons-bell',
                'title' => __('Notification center', 'yooadmin'),
                'text'  => __('Review WordPress notices from a centralized notification center instead of scattered admin banners.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-banner-convert', 'art' => 'comments', 'theme' => 'rose',
                'icon' => 'dashicons-megaphone',
                'title' => __('Convert banners to notices', 'yooadmin'),
                'text'  => __('Reduce dashboard clutter by moving traditional admin banners into the YOOAdmin notification center.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-studio-hub', 'art' => 'theme', 'theme' => 'brand',
                'icon' => 'dashicons-admin-home',
                'title' => __('Studio Hub home', 'yooadmin'),
                'text'  => __('Studio Hub organizes shortcuts, tools, and insights into a modern workspace built for daily admin work.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-submenu-popup', 'art' => 'keyboard', 'theme' => 'violet',
                'icon' => 'dashicons-external',
                'title' => __('Submenu popup', 'yooadmin'),
                'text'  => __('Navigate faster with instant submenu popups that reduce page loads and keep your workflow moving.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-hide-cards', 'art' => 'preview', 'theme' => 'amber',
                'icon' => 'dashicons-hidden',
                'title' => __('Hide unused cards', 'yooadmin'),
                'text'  => __('Hide cards you rarely use to keep your workspace organized and distraction free.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-custom-sections', 'art' => 'workspace', 'theme' => 'teal',
                'icon' => 'dashicons-plus-alt2',
                'title' => __('Add custom sections', 'yooadmin'),
                'text'  => __('Create additional dashboard sections for custom tools, workflows, or extension content.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-reset-layout', 'art' => 'revisions', 'theme' => 'orange',
                'icon' => 'dashicons-image-rotate',
                'title' => __('Reset layout', 'yooadmin'),
                'text'  => __('Restore the default layout and card arrangement for any workspace section at any time.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-welcome', 'art' => 'focus', 'theme' => 'blue',
                'icon' => 'dashicons-welcome-learn-more',
                'title' => __('Welcome checklist', 'yooadmin'),
                'text'  => __('The welcome experience introduces key workspace features so new admins can get started faster.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-brand-colors', 'art' => 'theme', 'theme' => 'indigo',
                'icon' => 'dashicons-admin-customizer',
                'title' => __('Brand colors', 'yooadmin'),
                'text'  => __('Customize headers, sidebars, and accent colors to match your brand identity across the workspace.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-woocommerce', 'art' => 'updates', 'theme' => 'green',
                'icon' => 'dashicons-cart',
                'title' => __('WooCommerce in Studio Hub', 'yooadmin'),
                'text'  => __('WooCommerce screens automatically inherit Studio Hub styling for a more consistent store workflow.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-media-library', 'art' => 'media', 'theme' => 'cyan',
                'icon' => 'dashicons-admin-media',
                'title' => __('Media library styling', 'yooadmin'),
                'text'  => __('Enjoy a cleaner media experience with styled grids, modals, and uploads that match the workspace.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-update-center', 'art' => 'backup', 'theme' => 'rose',
                'icon' => 'dashicons-update-alt',
                'title' => __('YOOUpdate Center', 'yooadmin'),
                'text'  => __('YOOUpdate Center is part of YOOAdmin Extended and brings WordPress, theme, and plugin updates into one streamlined workspace.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-theme-manager', 'art' => 'theme', 'theme' => 'violet',
                'icon' => 'dashicons-admin-appearance',
                'title' => __('Admin theme manager', 'yooadmin'),
                'text'  => __('Switch between YOOAdmin admin themes and workspace styles directly from Theme Manager.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-speed-booster', 'art' => 'quick', 'theme' => 'green',
                'icon' => 'dashicons-performance',
                'title' => __('Speed Booster', 'yooadmin'),
                'text'  => __('Speed Booster optimizes admin assets and interactions for a faster workspace experience.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-license', 'art' => 'privacy', 'theme' => 'blue',
                'icon' => 'dashicons-admin-network',
                'title' => __('Activate your license', 'yooadmin'),
                'text'  => __('Activate your license to unlock premium extensions, updates, and advanced workspace features.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-focus-policy', 'art' => 'focus', 'theme' => 'indigo',
                'icon' => 'dashicons-shield',
                'title' => __('Focus Mode policy', 'yooadmin'),
                'text'  => __('Control whether Focus Mode is managed globally or personalized for individual users.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-posts-screen', 'art' => 'organize', 'theme' => 'amber',
                'icon' => 'dashicons-admin-post',
                'title' => __('Styled list tables', 'yooadmin'),
                'text'  => __('Posts, pages, and custom content tables use improved spacing and cleaner scanning tools.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-users-screen', 'art' => 'roles', 'theme' => 'teal',
                'icon' => 'dashicons-admin-users',
                'title' => __('Users screen', 'yooadmin'),
                'text'  => __('Manage users and permissions from a more organized and distraction-free admin workspace.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-toolbar', 'art' => 'keyboard', 'theme' => 'cyan',
                'icon' => 'dashicons-admin-bar',
                'title' => __('Admin bar integration', 'yooadmin'),
                'text'  => __('Quick front-end links and profile tools stay accessible while working inside Focus Mode.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-pin-sections', 'art' => 'workspace', 'theme' => 'orange',
                'icon' => 'dashicons-sticky',
                'title' => __('Collapse sections', 'yooadmin'),
                'text'  => __('Collapse workspace sections you do not need often and expand them again whenever needed.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-wc-orders', 'art' => 'updates', 'theme' => 'rose',
                'icon' => 'dashicons-list-view',
                'title' => __('WooCommerce orders list', 'yooadmin'),
                'text'  => __('Orders and product tables adopt Studio Hub styling for a smoother WooCommerce workflow.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-media-screen', 'art' => 'media', 'theme' => 'cyan',
                'icon' => 'dashicons-admin-media',
                'title' => __('YOOMedia System', 'yooadmin'),
                'text'  => __('Available in YOOAdmin Extended, YOOMedia System adds a modern media workspace with improved uploads, browsing, and media management tools.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-plugin-manager', 'art' => 'quick', 'theme' => 'orange',
                'icon' => 'dashicons-admin-plugins',
                'title' => __('YOOAdmin Plugin Manager', 'yooadmin'),
                'text'  => __('Included with YOOAdmin Extended, the Plugin Manager introduces a cleaner card-based workflow for managing plugins and updates.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-logo-branding', 'art' => 'theme', 'theme' => 'brand',
                'icon' => 'dashicons-format-image',
                'title' => __('Your logo & branding', 'yooadmin'),
                'text'  => __('Apply your own logo, colors, and identity across the admin workspace and login screen.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-extended-free', 'art' => 'privacy', 'theme' => 'green',
                'icon' => 'dashicons-admin-plugins',
                'title' => __('YOOAdmin Extended', 'yooadmin'),
                'text'  => __('Looking for more tools? YOOAdmin Extended expands the workspace with additional integrations, utilities, and admin features.', 'yooadmin'),
            ]),
            $t([
                'id' => 'yoo-yooai', 'art' => 'focus', 'theme' => 'violet',
                'icon' => 'dashicons-superhero',
                'title' => __('YOOAi — coming soon', 'yooadmin'),
                'text'  => __('YOOAi is an upcoming assistant designed to help manage WordPress sites directly from the workspace.', 'yooadmin'),
            ]),
        ];

        $wp_ai = [];
        if (defined('WPAI_VERSION')) {
            $wp_ai = [
                $t([
                    'id' => 'wp-ai-get-started', 'art' => 'focus', 'theme' => 'violet',
                    'icon' => 'dashicons-superhero-alt',
                    'title' => __('WordPress AI is here', 'yooadmin'),
                    'text'  => __('Go to Settings → Connectors to add an AI provider, then Settings → AI to enable the features you want to use.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-connectors', 'art' => 'health', 'theme' => 'cyan',
                    'icon' => 'dashicons-admin-plugins',
                    'title' => __('Set up AI Connectors first', 'yooadmin'),
                    'text'  => __('Connect OpenAI, Google Gemini, or Anthropic in Settings → Connectors before turning on WordPress AI experiments.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-opt-in', 'art' => 'privacy', 'theme' => 'green',
                    'icon' => 'dashicons-shield',
                    'title' => __('Opt in to AI experiments', 'yooadmin'),
                    'text'  => __('WordPress AI is experiment-based: enable only the tools you need from Settings → AI instead of turning everything on at once.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-title', 'art' => 'keyboard', 'theme' => 'brand',
                    'icon' => 'dashicons-edit',
                    'title' => __('Generate post titles', 'yooadmin'),
                    'text'  => __('Enable Title Generation, edit a post, click the title field, and use Generate to brainstorm headline options in one click.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-alt-text', 'art' => 'media', 'theme' => 'green',
                    'icon' => 'dashicons-format-image',
                    'title' => __('AI alt text for images', 'yooadmin'),
                    'text'  => __('Turn on Alt Text Generation to draft descriptive alt text for media uploads and improve accessibility faster.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-excerpt', 'art' => 'organize', 'theme' => 'amber',
                    'icon' => 'dashicons-text',
                    'title' => __('Auto-generate excerpts', 'yooadmin'),
                    'text'  => __('Excerpt Generation creates concise post summaries so archives, cards, and previews stay consistent with less manual writing.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-content-resize', 'art' => 'revisions', 'theme' => 'teal',
                    'icon' => 'dashicons-editor-expand',
                    'title' => __('Resize block content', 'yooadmin'),
                    'text'  => __('Content Resizing can shorten, expand, or rephrase selected block content without rebuilding the layout from scratch.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-editorial-notes', 'art' => 'preview', 'theme' => 'indigo',
                    'icon' => 'dashicons-welcome-write-blog',
                    'title' => __('Editorial Notes review', 'yooadmin'),
                    'text'  => __('Editorial Notes scans blocks and adds suggestions for accessibility, readability, grammar, and SEO before you publish.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-classification', 'art' => 'organize', 'theme' => 'blue',
                    'icon' => 'dashicons-category',
                    'title' => __('Smarter tags & categories', 'yooadmin'),
                    'text'  => __('Content Classification suggests relevant tags and categories to keep posts organized and easier to discover.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-image-gen', 'art' => 'media', 'theme' => 'rose',
                    'icon' => 'dashicons-art',
                    'title' => __('Generate & edit images', 'yooadmin'),
                    'text'  => __('Image Generation lets you create or edit visuals from the block editor and Media Library when you need custom artwork quickly.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-comment-moderation', 'art' => 'comments', 'theme' => 'orange',
                    'icon' => 'dashicons-admin-comments',
                    'title' => __('AI comment moderation', 'yooadmin'),
                    'text'  => __('Comment Moderation uses toxicity and sentiment signals to help you review comments faster while staying in control of approvals.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-meta-description', 'art' => 'permalinks', 'theme' => 'violet',
                    'icon' => 'dashicons-search',
                    'title' => __('Meta description suggestions', 'yooadmin'),
                    'text'  => __('Meta Description Generation drafts SEO snippets and can integrate with popular SEO plugins when enabled.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-summarization', 'art' => 'quick', 'theme' => 'cyan',
                    'icon' => 'dashicons-list-view',
                    'title' => __('Summarize long content', 'yooadmin'),
                    'text'  => __('Content Summarization turns long posts into shorter overviews when you need a quick digest for editors or internal review.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-connector-approval', 'art' => 'privacy', 'theme' => 'rose',
                    'icon' => 'dashicons-lock',
                    'title' => __('Approve AI connector access', 'yooadmin'),
                    'text'  => __('Connector Approvals require admin consent before other plugins or themes can use the AI connectors configured on your site.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-request-log', 'art' => 'health', 'theme' => 'teal',
                    'icon' => 'dashicons-chart-bar',
                    'title' => __('Review AI request logs', 'yooadmin'),
                    'text'  => __('AI Request Logging records requests for debugging and observability so you can troubleshoot provider or experiment issues.', 'yooadmin'),
                ]),
                $t([
                    'id' => 'wp-ai-abilities-explorer', 'art' => 'workspace', 'theme' => 'brand',
                    'icon' => 'dashicons-admin-tools',
                    'title' => __('Explore AI abilities', 'yooadmin'),
                    'text'  => __('Abilities Explorer lists registered AI abilities so developers and power users can browse and test what WordPress AI exposes.', 'yooadmin'),
                ]),
            ];
        }

        return array_merge($wp, $yoo, $wp_ai);
        // phpcs:enable WordPress.WP.I18n.TextDomainMismatch
    }
}

if (!function_exists('yooadmin_studio_hub_tips_index_by_id')) {
    /**
     * @param array<int, array<string, string>> $tips
     * @return array<string, array<string, string>>
     */
    function yooadmin_studio_hub_tips_index_by_id(array $tips): array {
        $indexed = [];
        foreach ($tips as $tip) {
            $id = isset($tip['id']) ? (string) $tip['id'] : '';
            if ($id === '') {
                continue;
            }
            $indexed[$id] = $tip;
        }

        return $indexed;
    }
}

if (!function_exists('yooadmin_studio_hub_tips_pool_signature')) {
    /**
     * Changes when tips are added/removed so per-user decks reset.
     *
     * @param array<string, array<string, string>> $indexed
     */
    function yooadmin_studio_hub_tips_pool_signature(array $indexed): string {
        $ids = array_keys($indexed);
        sort($ids, SORT_STRING);

        return md5(implode("\n", $ids));
    }
}

if (!function_exists('yooadmin_studio_hub_shuffle_tip_deck')) {
    /**
     * @param array<string> $ids
     * @return array<string>
     */
    function yooadmin_studio_hub_shuffle_tip_deck(array $ids): array {
        $deck = array_values($ids);
        shuffle($deck);

        return $deck;
    }
}

if (!function_exists('yooadmin_studio_hub_pick_rotating_tips')) {
    /**
     * Fair rotation: each tip appears once per cycle before any repeat (per user).
     *
     * @param array<int, array<string, string>> $tips
     * @return array<int, array<string, string>>
     */
    function yooadmin_studio_hub_pick_rotating_tips(array $tips, int $min = 5, int $max = 6): array {
        $indexed = yooadmin_studio_hub_tips_index_by_id($tips);
        $total   = count($indexed);
        if ($total <= 0) {
            return [];
        }
        if ($total <= $min) {
            return array_values($indexed);
        }

        $max  = min($max, $total);
        $min  = min($min, $max);
        $want = wp_rand($min, $max);

        $user_id = function_exists('get_current_user_id') ? (int) get_current_user_id() : 0;
        if ($user_id <= 0) {
            $deck = yooadmin_studio_hub_shuffle_tip_deck(array_keys($indexed));

            return array_values(array_intersect_key($indexed, array_flip(array_slice($deck, 0, $want))));
        }

        $meta_deck = 'yooadmin_studio_hub_tips_deck';
        $meta_sig  = 'yooadmin_studio_hub_tips_deck_sig';
        $sig       = yooadmin_studio_hub_tips_pool_signature($indexed);
        $stored_sig = (string) get_user_meta($user_id, $meta_sig, true);

        if ($stored_sig !== $sig) {
            delete_user_meta($user_id, $meta_deck);
            update_user_meta($user_id, $meta_sig, $sig);
        }

        $deck = get_user_meta($user_id, $meta_deck, true);
        if (!is_array($deck)) {
            $deck = [];
        }

        $valid = array_flip(array_keys($indexed));
        $deck  = array_values(array_filter(
            array_map('strval', $deck),
            static function (string $id) use ($valid): bool {
                return isset($valid[$id]);
            }
        ));

        if (count($deck) < $want) {
            $in_deck = array_flip($deck);
            $remaining = [];
            foreach (array_keys($indexed) as $id) {
                if (!isset($in_deck[$id])) {
                    $remaining[] = $id;
                }
            }
            if ($remaining === []) {
                $remaining = array_keys($indexed);
                $deck      = [];
            }
            $deck = array_merge($deck, yooadmin_studio_hub_shuffle_tip_deck($remaining));
        }

        $picked_ids = array_slice($deck, 0, $want);
        $deck       = array_slice($deck, $want);

        update_user_meta($user_id, $meta_deck, $deck);

        $picked = [];
        foreach ($picked_ids as $id) {
            if (isset($indexed[$id])) {
                $picked[] = $indexed[$id];
            }
        }

        if (count($picked) < $want) {
            $fallback = yooadmin_studio_hub_shuffle_tip_deck(array_keys($indexed));
            foreach ($fallback as $id) {
                if (isset($indexed[$id]) && !in_array($id, $picked_ids, true)) {
                    $picked[] = $indexed[$id];
                }
                if (count($picked) >= $want) {
                    break;
                }
            }
        }

        shuffle($picked);

        return array_slice($picked, 0, $want);
    }
}

if (!function_exists('yooadmin_studio_hub_get_tips')) {
    /**
     * Rotating subset for the current page load (5–6 tips, fair deck per user).
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_studio_hub_get_tips(): array {
        $all = yooadmin_studio_hub_get_all_tips();

        /**
         * Filter the full tips pool before the rotating subset is chosen.
         *
         * @param array<int, array<string, string>> $all
         */
        $all = apply_filters('yooadmin_studio_hub_tips', $all);

        return yooadmin_studio_hub_pick_rotating_tips($all, 5, 6);
    }
}

if (!function_exists('yooadmin_studio_hub_get_network_tips')) {
    /**
     * Network dashboard tips (carousel format).
     *
     * @return array<int, array<string, string>>
     */
    function yooadmin_studio_hub_get_network_tips(): array {
        if (function_exists('yooadmin_network_dashboard_get_tips')) {
            return yooadmin_network_dashboard_get_tips();
        }

        return [];
    }
}
