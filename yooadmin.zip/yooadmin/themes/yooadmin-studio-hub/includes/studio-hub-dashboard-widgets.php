<?php
/**
 * Studio Hub — WordPress dashboard widgets as layout sections.
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Register AJAX handlers once (theme bootstrap may load this file).
 */
function yooadmin_studio_hub_register_dashboard_widget_hooks(): void {
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;

    add_action('wp_ajax_yooadmin_studio_hub_dashboard_widgets_catalog', 'yooadmin_studio_hub_ajax_dashboard_widgets_catalog');
    add_action('wp_ajax_yooadmin_studio_hub_render_dashboard_widget', 'yooadmin_studio_hub_ajax_render_dashboard_widget');
}

yooadmin_studio_hub_register_dashboard_widget_hooks();
add_action('rest_api_init', 'yooadmin_studio_hub_register_dashboard_widget_rest_routes');

/**
 * Whether the current admin screen is the YOOAdmin dashboard (Studio Hub template).
 */
function yooadmin_studio_hub_is_dashboard_screen(): bool {
    if (!is_admin()) {
        return false;
    }
    if (!function_exists('yooadmin_studio_hub_is_active') || !yooadmin_studio_hub_is_active()) {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    $slug = function_exists('yooadmin_dashboard_slug')
        ? (string) yooadmin_dashboard_slug()
        : 'yooadmin-dashboard';

    return $page === $slug;
}

/**
 * Bootstrap dashboard meta boxes on a non-index admin screen.
 */
function yooadmin_studio_hub_prepare_dashboard_widget_context(): void {
    global $pagenow, $current_screen, $typenow;

    if (!function_exists('wp_dashboard_setup')) {
        require_once ABSPATH . 'wp-admin/includes/dashboard.php';
    }

    if (!function_exists('_wp_dashboard_control_callback')) {
        require_once ABSPATH . 'wp-admin/includes/meta-boxes.php';
    }

    if (!class_exists('WP_Screen')) {
        require_once ABSPATH . 'wp-admin/includes/class-wp-screen.php';
    }

    $pagenow = 'index.php';
    $typenow = '';

    if (!$current_screen || 'dashboard' !== $current_screen->id) {
        $current_screen = WP_Screen::get('dashboard');
    }

    set_current_screen('dashboard');

    if (!isset($_SERVER['REQUEST_METHOD'])) {
        $_SERVER['REQUEST_METHOD'] = 'GET';
    }
}

function yooadmin_studio_hub_bootstrap_dashboard_meta_boxes(): void {
    global $wp_meta_boxes;

    static $bootstrapped = false;

    if ($bootstrapped) {
        return;
    }

    $bootstrapped = true;

    yooadmin_studio_hub_prepare_dashboard_widget_context();

    // Rebuild once per request — admin-ajax may start with a partial registry (e.g. WooCommerce Setup only).
    $wp_meta_boxes['dashboard'] = [];

    if (class_exists('WooCommerce', false)) {
        $wc_setup = WP_PLUGIN_DIR . '/woocommerce/includes/admin/class-wc-admin-dashboard-setup.php';
        if (is_readable($wc_setup)) {
            include_once $wc_setup;
        }
    }

    wp_dashboard_setup();
}

/**
 * @param string $widget_id Raw widget id.
 */
function yooadmin_studio_hub_sanitize_widget_id(string $widget_id): string {
    $widget_id = sanitize_text_field($widget_id);
    if ($widget_id === '' || !preg_match('/^[a-zA-Z0-9_-]+$/', $widget_id)) {
        return '';
    }

    return $widget_id;
}

/**
 * Read layout AJAX nonce from POST (supports alternate field names).
 */
function yooadmin_studio_hub_get_layout_ajax_nonce(): string {
    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified by caller.
    if (!empty($_POST['nonce'])) {
        return sanitize_text_field(wp_unslash($_POST['nonce']));
    }
    if (!empty($_POST['_ajax_nonce'])) {
        return sanitize_text_field(wp_unslash($_POST['_ajax_nonce']));
    }
    // phpcs:enable WordPress.Security.NonceVerification.Missing

    return '';
}

/**
 * Verify widget/catalog AJAX (JSON body always HTTP 200 so admin JS can read messages).
 */
function yooadmin_studio_hub_verify_layout_ajax_request(): void {
    if (!is_user_logged_in()) {
        wp_send_json_error(
            [
                'message' => __('You must be logged in.', 'yooadmin'),
                'code'    => 'not_logged_in',
            ],
            200
        );
    }

    if (!current_user_can(yooadmin_studio_hub_layout_capability())) {
        wp_send_json_error(
            [
                'message' => __('Sorry, you are not allowed to view widgets.', 'yooadmin'),
                'code'    => 'forbidden',
            ],
            200
        );
    }

    $nonce = yooadmin_studio_hub_get_layout_ajax_nonce();
    if (!wp_verify_nonce($nonce, 'yooadmin_studio_hub_layout')) {
        wp_send_json_error(
            [
                'message' => __('Invalid security token. Please reload the page.', 'yooadmin'),
                'code'    => 'invalid_nonce',
            ],
            200
        );
    }
}

/**
 * Catalog for Studio Hub section picker (YOOAdmin dashboard cards API only).
 *
 * @return array<int, array<string, mixed>>
 */
function yooadmin_studio_hub_get_dashboard_widgets_catalog(): array {
    if (!function_exists('yooadmin_get_dashboard_cards_catalog_for_context')) {
        if (!function_exists('yooadmin_get_dashboard_cards_catalog')) {
            return [];
        }
        $catalog = yooadmin_get_dashboard_cards_catalog();
    } else {
        $context = function_exists('yooadmin_dashboard_card_active_context')
            ? yooadmin_dashboard_card_active_context()
            : 'site';
        $catalog = yooadmin_get_dashboard_cards_catalog_for_context($context);
    }

    /**
     * @param array<int, array<string, mixed>> $catalog
     */
    return apply_filters('yooadmin_studio_hub_dashboard_widgets_catalog', $catalog);
}

/**
 * Light info notice (Studio Hub) — same visual language as YOOAdmin About modal resource blocks.
 *
 * @param string $title   Notice heading.
 * @param string $message Body copy.
 * @param string $link_url Optional link URL.
 * @param string $link_text Optional link label.
 */
function yooadmin_studio_hub_info_notice_html(
    string $title,
    string $message,
    string $link_url = '',
    string $link_text = ''
): string {
    ob_start();
    ?>
    <div class="yp-studio-hub-info-notice" role="note">
        <div class="yp-studio-hub-info-notice__inner">
            <span class="yp-studio-hub-info-notice__icon dashicons dashicons-info-outline" aria-hidden="true"></span>
            <div class="yp-studio-hub-info-notice__content">
                <?php if ($title !== '') : ?>
                    <p class="yp-studio-hub-info-notice__title"><?php echo esc_html($title); ?></p>
                <?php endif; ?>
                <?php if ($message !== '') : ?>
                    <p class="yp-studio-hub-info-notice__text"><?php echo esc_html($message); ?></p>
                <?php endif; ?>
                <?php if ($link_url !== '' && $link_text !== '') : ?>
                    <p class="yp-studio-hub-info-notice__link">
                        <a href="<?php echo esc_url($link_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($link_text); ?></a>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
    return (string) ob_get_clean();
}

/**
 * HTML shown for legacy WordPress dashboard widget ids saved in older layouts.
 */
function yooadmin_studio_hub_legacy_wp_widget_notice_html(): string {
    $docs = apply_filters(
        'yooadmin_studio_hub_dashboard_cards_docs_url',
        'https://www.yooadmin.io/kb-category/for-developers/'
    );

    return yooadmin_studio_hub_info_notice_html(
        __('Classic WordPress dashboard widgets are not available in Studio Hub.', 'yooadmin'),
        __(
            'YOOAdmin dashboard cards provide a cleaner, more modern workspace experience built for Studio Hub.',
            'yooadmin'
        ),
        is_string($docs) ? $docs : '',
        __('Developer guide on yooadmin.io', 'yooadmin')
    );
}

/**
 * @param string $id Widget id.
 * @param string $title Widget title.
 */
function yooadmin_studio_hub_guess_widget_icon(string $id, string $title): string {
    $hay = strtolower($id . ' ' . $title);

    if (strpos($hay, 'woo') !== false || strpos($hay, 'commerce') !== false) {
        return 'dashicons-cart';
    }
    if (strpos($hay, 'health') !== false || strpos($hay, 'security') !== false) {
        return 'dashicons-shield';
    }
    if (strpos($hay, 'news') !== false || strpos($hay, 'event') !== false) {
        return 'dashicons-megaphone';
    }
    if (strpos($hay, 'activity') !== false || strpos($hay, 'log') !== false) {
        return 'dashicons-backup';
    }
    if (strpos($hay, 'comment') !== false) {
        return 'dashicons-admin-comments';
    }
    if (strpos($hay, 'post') !== false || strpos($hay, 'blog') !== false) {
        return 'dashicons-admin-post';
    }
    if (strpos($hay, 'plugin') !== false) {
        return 'dashicons-admin-plugins';
    }
    if (strpos($hay, 'user') !== false) {
        return 'dashicons-groups';
    }

    return 'dashicons-admin-generic';
}

/**
 * Find a dashboard widget box by id.
 *
 * @return array<string, mixed>|null
 */
function yooadmin_studio_hub_find_dashboard_widget_box(string $widget_id): ?array {
    yooadmin_studio_hub_bootstrap_dashboard_meta_boxes();

    return yooadmin_studio_hub_lookup_dashboard_widget_box($widget_id);
}

/**
 * @return array<string, mixed>|null
 */
function yooadmin_studio_hub_lookup_dashboard_widget_box(string $widget_id): ?array {
    global $wp_meta_boxes;

    if ($widget_id === '' || empty($wp_meta_boxes['dashboard']) || !is_array($wp_meta_boxes['dashboard'])) {
        return null;
    }

    foreach ($wp_meta_boxes['dashboard'] as $priorities) {
        if (!is_array($priorities)) {
            continue;
        }
        foreach ($priorities as $boxes) {
            if (!is_array($boxes) || empty($boxes[ $widget_id ]) || !is_array($boxes[ $widget_id ])) {
                continue;
            }
            return $boxes[ $widget_id ];
        }
    }

    return null;
}

/**
 * Enqueue styles/scripts needed for a dashboard widget outside index.php.
 *
 * @param string $widget_id Dashboard widget id.
 */
function yooadmin_studio_hub_enqueue_widget_assets(string $widget_id): void {
    if (!is_admin()) {
        return;
    }

    yooadmin_studio_hub_prepare_dashboard_widget_context();

    switch ($widget_id) {
        case 'dashboard_site_health':
            if (!class_exists('WP_Site_Health')) {
                require_once ABSPATH . 'wp-admin/includes/class-wp-site-health.php';
            }
            wp_enqueue_style('site-health');
            if (class_exists('WP_Site_Health')) {
                WP_Site_Health::get_instance()->enqueue_scripts();
            }
            break;

        case 'wc_admin_dashboard_setup':
            if (defined('WC_PLUGIN_FILE')) {
                wp_enqueue_style(
                    'wc-dashboard-setup',
                    plugins_url('assets/css/dashboard-setup.css', WC_PLUGIN_FILE),
                    [],
                    defined('WC_VERSION') ? WC_VERSION : '1.0'
                );
            }
            break;
    }

    /**
     * Plugins may register extra handles for a widget id.
     *
     * @param string $widget_id Dashboard widget id.
     */
    do_action('yooadmin_studio_hub_enqueue_dashboard_widget_assets', $widget_id);
}

/**
 * Print enqueued widget asset tags (for REST/AJAX injection when not on the main dashboard load).
 *
 * @param string $widget_id Dashboard widget id.
 * @return array{styles: string, scripts: string}
 */
function yooadmin_studio_hub_capture_widget_assets_markup(string $widget_id): array {
    $style_handles  = [];
    $script_handles = [];

    switch ($widget_id) {
        case 'dashboard_site_health':
            $style_handles  = [ 'site-health' ];
            $script_handles = [ 'site-health' ];
            break;
        case 'wc_admin_dashboard_setup':
            $style_handles = [ 'wc-dashboard-setup' ];
            break;
    }

    yooadmin_studio_hub_enqueue_widget_assets($widget_id);

    ob_start();
    foreach ($style_handles as $handle) {
        if (wp_style_is($handle, 'registered')) {
            wp_enqueue_style($handle);
            wp_print_styles($handle);
        }
    }
    $styles = (string) ob_get_clean();

    ob_start();
    foreach ($script_handles as $handle) {
        if (wp_script_is($handle, 'registered')) {
            wp_enqueue_script($handle);
            wp_print_scripts($handle);
        }
    }
    $scripts = (string) ob_get_clean();

    return [
        'styles'  => $styles,
        'scripts' => $scripts,
    ];
}

/**
 * Apply Site Health score UI server-side (widget AJAX does not run dashboard site-health.js).
 *
 * @param string $html Widget markup.
 * @return string
 */
function yooadmin_studio_hub_postprocess_site_health_widget(string $html): string {
    $html = '<div id="dashboard_site_health" class="yp-studio-wp-widget-root">' . $html . '</div>';

    $get_issues = get_transient('health-check-site-status-result');
    if (false === $get_issues) {
        return $html;
    }

    $issue_counts = json_decode((string) $get_issues, true);
    if (!is_array($issue_counts)) {
        return $html;
    }

    $good        = (int) ($issue_counts['good'] ?? 0);
    $recommended = (int) ($issue_counts['recommended'] ?? 0);
    $critical    = (int) ($issue_counts['critical'] ?? 0);

    $total_tests  = $good + $recommended + (int) ($critical * 1.5);
    $failed_tests = ($recommended * 0.5) + ($critical * 1.5);

    $wrapper_classes = 'health-check-widget-title-section site-health-progress-wrapper hide-if-no-js';
    $label           = __('Should be improved', 'yooadmin');
    $state_class     = 'orange';
    $bar_style       = '';

    if ($total_tests > 0) {
        $val = 100 - (int) ceil(($failed_tests / $total_tests) * 100);
        if ($val < 0) {
            $val = 0;
        }
        if ($val > 100) {
            $val = 100;
        }

        $circumference = M_PI * 180;
        $offset        = (100 - $val) / 100 * $circumference;
        $bar_style     = ' style="stroke-dashoffset:' . esc_attr((string) $offset) . 'px"';

        if ($val >= 80 && 0 === $critical) {
            $state_class = 'green';
            $label       = __('Good', 'yooadmin');
        }

        $wrapper_classes .= ' ' . $state_class;
    } else {
        $wrapper_classes .= ' hidden';
        $label = __('No information yet&hellip;', 'yooadmin');
    }

    $html = str_replace(
        'health-check-widget-title-section site-health-progress-wrapper loading hide-if-no-js',
        $wrapper_classes,
        $html
    );

    $html = preg_replace(
        '#<div class="site-health-progress-label">\s*.*?\s*</div>#s',
        '<div class="site-health-progress-label">' . esc_html($label) . '</div>',
        $html,
        1
    );

    if ($bar_style !== '') {
        $html = preg_replace(
            '#(<circle id="bar"[^>]*)(/?>)#',
            '$1' . $bar_style . '$2',
            $html,
            1
        );
    }

    return $html;
}

/**
 * Wrap widget HTML and fix known rendering gaps on Studio Hub.
 *
 * @param string $widget_id Widget id.
 * @param string $html      Raw widget HTML.
 * @return string
 */
function yooadmin_studio_hub_postprocess_widget_html(string $widget_id, string $html): string {
    if ($widget_id === 'dashboard_site_health') {
        return yooadmin_studio_hub_postprocess_site_health_widget($html);
    }

    if ($widget_id === 'wc_admin_dashboard_setup') {
        return '<div class="yp-studio-wp-widget-root yp-studio-wp-widget-root--wc-setup">' . $html . '</div>';
    }

    return $html;
}

/**
 * HTML + optional asset tags for widget section body.
 *
 * @return array{html: string, assets: array{styles: string, scripts: string}}
 */
function yooadmin_studio_hub_get_widget_render_payload(string $widget_id): array {
    if (function_exists('yooadmin_studio_hub_ensure_builtin_dashboard_cards_registered')) {
        yooadmin_studio_hub_ensure_builtin_dashboard_cards_registered();
    }

    $render = static function () use ($widget_id): array {
        $html   = yooadmin_studio_hub_render_dashboard_widget_html($widget_id);
        $assets = [ 'styles' => '', 'scripts' => '' ];

        if (function_exists('yooadmin_is_dashboard_card') && yooadmin_is_dashboard_card($widget_id)) {
            $assets = yooadmin_capture_dashboard_card_assets($widget_id);
        }

        return [
            'html'   => $html,
            'assets' => $assets,
        ];
    };

    if (function_exists('yooadmin_with_admin_ui_locale')) {
        return yooadmin_with_admin_ui_locale($render);
    }

    if (function_exists('yooadmin_load_admin_ui_textdomain')) {
        yooadmin_load_admin_ui_textdomain();
    }

    return $render();
}

/**
 * Render dashboard widget markup for Studio Hub section body.
 */
function yooadmin_studio_hub_render_dashboard_widget_html(string $widget_id): string {
    if (function_exists('yooadmin_is_dashboard_card') && yooadmin_is_dashboard_card($widget_id)) {
        return '<div class="yp-studio-widget-section__inner">' . yooadmin_render_dashboard_card($widget_id) . '</div>';
    }

    return '<div class="yp-studio-widget-section__inner">' . yooadmin_studio_hub_legacy_wp_widget_notice_html() . '</div>';
}

/**
 * AJAX: widget catalog for add-section modal.
 */
function yooadmin_studio_hub_ajax_dashboard_widgets_catalog(): void {
    yooadmin_studio_hub_verify_layout_ajax_request();

    wp_send_json_success(
        [
            'widgets' => yooadmin_studio_hub_get_dashboard_widgets_catalog(),
        ]
    );
}

/**
 * AJAX: render one dashboard widget body.
 */
function yooadmin_studio_hub_ajax_render_dashboard_widget(): void {
    yooadmin_studio_hub_verify_layout_ajax_request();

    // phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified by yooadmin_studio_hub_verify_layout_ajax_request().
    $widget_id = isset($_POST['widget_id'])
        ? yooadmin_studio_hub_sanitize_widget_id(sanitize_text_field(wp_unslash($_POST['widget_id'])))
        : '';
    // phpcs:enable WordPress.Security.NonceVerification.Missing
    if ($widget_id === '') {
        wp_send_json_error(['message' => __('Invalid widget.', 'yooadmin')], 400);
    }

    wp_send_json_success(yooadmin_studio_hub_get_widget_render_payload($widget_id));
}

/**
 * REST routes (preferred over admin-ajax when WAF blocks POST render requests).
 */
function yooadmin_studio_hub_register_dashboard_widget_rest_routes(): void {
    register_rest_route(
        'yooadmin/v1',
        '/studio-hub/widgets',
        [
            'methods'             => 'GET',
            'permission_callback' => static function (): bool {
                return is_user_logged_in() && current_user_can('read');
            },
            'callback'            => static function (): WP_REST_Response {
                return new WP_REST_Response(
                    [
                        'widgets' => yooadmin_studio_hub_get_dashboard_widgets_catalog(),
                    ],
                    200
                );
            },
        ]
    );

    register_rest_route(
        'yooadmin/v1',
        '/studio-hub/widgets/(?P<widget_id>[a-zA-Z0-9_-]+)/render',
        [
            'methods'             => 'GET',
            'permission_callback' => static function (): bool {
                return is_user_logged_in() && current_user_can('read');
            },
            'callback'            => static function (WP_REST_Request $request) {
                $widget_id = yooadmin_studio_hub_sanitize_widget_id((string) $request->get_param('widget_id'));
                if ($widget_id === '') {
                    return new WP_Error(
                        'invalid_widget',
                        __('Invalid widget.', 'yooadmin'),
                        ['status' => 400]
                    );
                }

                return new WP_REST_Response(
                    yooadmin_studio_hub_get_widget_render_payload($widget_id),
                    200
                );
            },
        ]
    );
}

/**
 * Minimal script registration for widgets that need dashboard assets in AJAX context.
 * Avoids firing admin_enqueue_scripts (can fatal or trigger WAF on admin-ajax).
 *
 * @param string $widget_id Dashboard widget id being rendered.
 */
function yooadmin_studio_hub_enqueue_dashboard_widget_deps(string $widget_id = ''): void {
    if (!is_admin()) {
        return;
    }

    yooadmin_studio_hub_enqueue_widget_assets($widget_id);

    if (wp_script_is('dashboard', 'registered')) {
        wp_enqueue_script('dashboard');
    }
    if (wp_script_is('postbox', 'registered')) {
        wp_enqueue_script('postbox');
    }

    /**
     * Targeted hook for plugins that need widget-specific assets without full admin_enqueue_scripts.
     *
     * @param string $widget_id Dashboard widget id.
     */
    do_action('yooadmin_studio_hub_dashboard_widget_scripts', $widget_id);
}
