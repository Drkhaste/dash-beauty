<?php
/**
 * Studio Hub — plugin details Thickbox (plugins.php + plugin-install.php iframe).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * plugin-install.php iframe: tab=plugin-information.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_plugin_information_iframe(): bool {
    if (!is_admin()) {
        return false;
    }

    global $pagenow;

    if (!isset($pagenow) || $pagenow !== 'plugin-install.php') {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen detection.
    $tab = isset($_GET['tab']) ? sanitize_key((string) wp_unslash($_GET['tab'])) : '';

    return $tab === 'plugin-information';
}

/**
 * plugins.php (Thickbox shell) or plugin-information iframe.
 *
 * @return bool
 */
function yooadmin_studio_hub_needs_plugin_information_styles(): bool {
    return yooadmin_studio_hub_is_plugin_information_parent_page() || yooadmin_studio_hub_is_plugin_information_iframe();
}

/**
 * Parent pages that can open the plugin-information Thickbox.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_plugin_information_parent_page(): bool {
    if (function_exists('yooadmin_studio_hub_should_style_plugins_php_experience')
        && yooadmin_studio_hub_should_style_plugins_php_experience()) {
        return true;
    }

    return function_exists('yooadmin_studio_hub_should_style_plugin_install_layout')
        && yooadmin_studio_hub_should_style_plugin_install_layout();
}

/**
 * Effective color mode for plugin-information iframe (GET override from parent Thickbox).
 *
 * @return string dark|light|auto
 */
function yooadmin_studio_hub_get_plugin_information_effective_color_mode(): string {
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Parent passes read-only appearance hint.
    if (isset($_GET['ysh_effective'])) {
        $raw = sanitize_key((string) wp_unslash($_GET['ysh_effective']));
        if (in_array($raw, ['dark', 'light'], true)) {
            return $raw;
        }
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    return yooadmin_studio_hub_get_color_mode();
}

/**
 * @return bool
 */
function yooadmin_studio_hub_is_plugin_information_dark_context(): bool {
    if (!yooadmin_studio_hub_is_active()) {
        return false;
    }

    $effective = yooadmin_studio_hub_get_plugin_information_effective_color_mode();

    return $effective !== 'light';
}

/**
 * Load dark assets when Studio Hub dark/auto is active (iframe does not require Focus shell).
 *
 * @return bool
 */
function yooadmin_studio_hub_should_load_plugin_information_dark(): bool {
    if (!yooadmin_studio_hub_needs_plugin_information_styles()) {
        return false;
    }
    if (!yooadmin_studio_hub_plugin_install_basic_active()) {
        return false;
    }
    if (yooadmin_studio_hub_is_plugin_information_iframe()) {
        return yooadmin_studio_hub_is_plugin_information_dark_context();
    }

    return yooadmin_studio_hub_is_active() && yooadmin_studio_hub_is_plugin_information_dark_context();
}

/**
 * @return string
 */
function yooadmin_studio_hub_plugin_information_stylesheet_path(): string {
    return yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugin-information-dark.css');
}

/**
 * @return string
 */
function yooadmin_studio_hub_plugin_information_stylesheet_url(): string {
    $file = yooadmin_studio_hub_plugin_information_stylesheet_path();
    $url  = yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugin-information-dark.css');

    if (is_readable($file)) {
        return add_query_arg('ver', (string) filemtime($file), $url);
    }

    return $url;
}

/**
 * Ensure iframe has common.css + color-mode bootstrap before iframe_header prints styles.
 */
function yooadmin_studio_hub_prepare_plugin_information_iframe(): void {
    if (!yooadmin_studio_hub_is_plugin_information_iframe() || !yooadmin_studio_hub_is_plugin_information_dark_context()) {
        return;
    }

    if (!wp_style_is('common', 'registered')) {
        wp_register_style('common', admin_url('css/common.css'), [], get_bloginfo('version'));
    }
    wp_enqueue_style('common');
}

/**
 * Blocking anti-flash rules (iframe first paint + parent TB shell while loading).
 *
 * @return string
 */
function yooadmin_studio_hub_plugin_information_antiflash_css(): string {
    return 'html.ysh-plugin-info-pending{background:#1a1d23!important;}'
        . 'body#plugin-information.ysh-plugin-info-dark,body#plugin-information.ysh-plugin-info-auto{'
        . 'background:#1a1d23!important;color:#cfd6e0!important;}'
        . yooadmin_studio_hub_plugin_information_scrollbar_css()
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-scrollable,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-scrollable,'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-content,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-content{'
        . 'background:#1a1d23!important;color:#cfd6e0!important;}'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-title:not(.with-banner),'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-title:not(.with-banner),'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-tabs,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-tabs,'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-footer,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-footer,'
        . 'body#plugin-information.ysh-plugin-info-dark .fyi,'
        . 'body#plugin-information.ysh-plugin-info-auto .fyi{background:#121418!important;}'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-title.with-banner,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-title.with-banner{'
        . 'background-color:transparent!important;}';
}

/**
 * @return string
 */
function yooadmin_studio_hub_plugin_information_scrollbar_css(): string {
    return 'body#plugin-information,body#plugin-information #plugin-information-scrollable{'
        . 'scrollbar-width:thin;scrollbar-color:rgba(15,23,42,.28) transparent;}'
        . 'body#plugin-information #plugin-information-scrollable{'
        . 'scrollbar-gutter:stable;}'
        . 'body#plugin-information::-webkit-scrollbar,'
        . 'body#plugin-information #plugin-information-scrollable::-webkit-scrollbar{'
        . 'width:8px;height:8px;}'
        . 'body#plugin-information::-webkit-scrollbar-track,'
        . 'body#plugin-information #plugin-information-scrollable::-webkit-scrollbar-track{'
        . 'background:transparent;}'
        . 'body#plugin-information::-webkit-scrollbar-thumb,'
        . 'body#plugin-information #plugin-information-scrollable::-webkit-scrollbar-thumb{'
        . 'background-color:rgba(15,23,42,.26);border:2px solid transparent;border-radius:999px;background-clip:padding-box;}'
        . 'body#plugin-information::-webkit-scrollbar-thumb:hover,'
        . 'body#plugin-information #plugin-information-scrollable::-webkit-scrollbar-thumb:hover{'
        . 'background-color:rgba(15,23,42,.4);}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"],'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information,'
        . 'body#plugin-information.ysh-plugin-info-dark,'
        . 'body#plugin-information.ysh-plugin-info-auto,'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-scrollable,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-scrollable{'
        . 'scrollbar-color:rgba(255,255,255,.2) transparent;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information::-webkit-scrollbar-thumb,'
        . 'body#plugin-information.ysh-plugin-info-dark::-webkit-scrollbar-thumb,'
        . 'body#plugin-information.ysh-plugin-info-auto::-webkit-scrollbar-thumb,'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-scrollable::-webkit-scrollbar-thumb,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-scrollable::-webkit-scrollbar-thumb{'
        . 'background-color:rgba(255,255,255,.2);}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information::-webkit-scrollbar-thumb:hover,'
        . 'body#plugin-information.ysh-plugin-info-dark::-webkit-scrollbar-thumb:hover,'
        . 'body#plugin-information.ysh-plugin-info-auto::-webkit-scrollbar-thumb:hover,'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-scrollable::-webkit-scrollbar-thumb:hover,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-scrollable::-webkit-scrollbar-thumb:hover{'
        . 'background-color:rgba(255,255,255,.32);}';
}

/**
 * Print plugin details scrollbar in both light and dark mode.
 */
function yooadmin_studio_hub_print_plugin_information_scrollbar(): void {
    if (!yooadmin_studio_hub_is_plugin_information_iframe() || !yooadmin_studio_hub_plugin_install_basic_active()) {
        return;
    }

    $css = yooadmin_studio_hub_plugin_information_scrollbar_css();

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Raw trusted theme CSS.
    echo '<style id="yooadmin-studio-hub-plugin-information-scrollbar">' . $css . '</style>' . "\n";
}

/**
 * Print anti-flash CSS after wp-admin styles in iframe (beats common.css white flash).
 */
function yooadmin_studio_hub_print_plugin_information_iframe_antiflash(): void {
    if (!yooadmin_studio_hub_is_plugin_information_iframe() || !yooadmin_studio_hub_is_plugin_information_dark_context()) {
        return;
    }

    $mode = yooadmin_studio_hub_get_plugin_information_effective_color_mode();

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static critical CSS fragments.
    echo '<style id="yooadmin-studio-hub-plugin-information-antiflash">'
        . yooadmin_studio_hub_plugin_information_antiflash_css()
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information{'
        . 'background:#1a1d23!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information #plugin-information-scrollable,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information #plugin-information-content{'
        . 'background:#1a1d23!important;color:#cfd6e0!important;}';

    if ($mode === 'auto') {
        echo '@media (prefers-color-scheme:dark){'
            . 'body#plugin-information.ysh-plugin-info-auto{background:#1a1d23!important;color:#cfd6e0!important;}'
            . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-scrollable,'
            . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-content{'
            . 'background:#1a1d23!important;color:#cfd6e0!important;}'
            . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-title:not(.with-banner),'
            . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-tabs,'
            . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-footer,'
            . 'body#plugin-information.ysh-plugin-info-auto .fyi{background:#121418!important;}'
            . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-title.with-banner{'
            . 'background-color:transparent!important;}'
            . '}';
    }

    echo '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Color-mode bootstrap in iframe (no Focus gate — parent shell is already dark).
 */
function yooadmin_studio_hub_print_plugin_information_iframe_appearance(): void {
    if (!yooadmin_studio_hub_is_plugin_information_iframe() || !yooadmin_studio_hub_is_plugin_information_dark_context()) {
        return;
    }

    $mode = yooadmin_studio_hub_get_plugin_information_effective_color_mode();

    // Blocking paint before body renders (html class picked up immediately).
    echo '<style id="yooadmin-studio-hub-plugin-info-preflash">'
        . 'html.ysh-plugin-info-pending{background:#1a1d23!important;}'
        . '</style>' . "\n";

    printf(
        '<script id="yooadmin-studio-hub-plugin-info-color-mode">(function(){var m=%1$s;var eff="light";'
        . 'if(m==="dark"){eff="dark";}else if(m==="auto"){try{eff=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(e){eff="light";}}'
        . 'var root=document.documentElement;'
        . 'root.setAttribute("data-yooadmin-studio-color-mode",m);'
        . 'root.setAttribute("data-yooadmin-studio-color-mode-effective",eff);'
        . 'root.classList.add("yooadmin-studio-hub-html");'
        . 'if(eff==="dark"){root.classList.add("ysh-plugin-info-pending");'
        . 'var mark=function(){if(document.body){document.body.classList.add("ysh-plugin-info-dark");'
        . 'root.classList.remove("ysh-plugin-info-pending");}else{requestAnimationFrame(mark);}};'
        . 'mark();}'
        . '})();</script>' . "\n",
        wp_json_encode($mode)
    );
}

/**
 * @param string $classes
 * @return string
 */
function yooadmin_studio_hub_filter_plugin_information_body_class(string $classes): string {
    if (!yooadmin_studio_hub_is_plugin_information_iframe() || !yooadmin_studio_hub_is_plugin_information_dark_context()) {
        return $classes;
    }

    $mode = yooadmin_studio_hub_get_plugin_information_effective_color_mode();
    if ($mode === 'dark') {
        return trim($classes . ' ysh-plugin-info-dark');
    }
    if ($mode === 'auto') {
        return trim($classes . ' ysh-plugin-info-auto');
    }

    return $classes;
}

/**
 * Dark cascade tail after wp-admin common.css.
 */
function yooadmin_studio_hub_enqueue_plugin_information_dark_tail(): void {
    if (!yooadmin_studio_hub_should_load_plugin_information_dark()) {
        return;
    }

    $file = yooadmin_studio_hub_plugin_information_stylesheet_path();
    if (!is_readable($file)) {
        return;
    }

    $deps = [];
    foreach (['common', 'list-tables', 'yooadmin-core', 'yooadmin-studio-hub-late'] as $handle) {
        if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
            $deps[] = $handle;
        }
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-plugin-information-dark',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugin-information-dark.css'),
        $deps,
        (string) filemtime($file)
    );
}

/**
 * Inline the full dark stylesheet in iframe (guaranteed load; no html-attribute dependency).
 */
function yooadmin_studio_hub_print_plugin_information_iframe_inline_css(): void {
    if (!yooadmin_studio_hub_is_plugin_information_iframe() || !yooadmin_studio_hub_is_plugin_information_dark_context()) {
        return;
    }

    $file = yooadmin_studio_hub_plugin_information_stylesheet_path();
    if (!is_readable($file)) {
        return;
    }

    $css = file_get_contents($file);
    if (!is_string($css) || $css === '') {
        return;
    }

  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Raw trusted theme CSS.
    echo '<style id="yooadmin-studio-hub-plugin-information-inline">' . $css . '</style>' . "\n";
}

/**
 * Critical dark rules — body#plugin-information (iframe first paint).
 */
function yooadmin_studio_hub_print_plugin_information_critical(): void {
    if (!yooadmin_studio_hub_should_load_plugin_information_dark()) {
        return;
    }

    $css = 'body#plugin-information.ysh-plugin-info-dark,body#plugin-information.ysh-plugin-info-auto,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information{'
        . 'background:#1a1d23!important;color:#cfd6e0!important;}'
        . yooadmin_studio_hub_plugin_information_scrollbar_css()
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-scrollable,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-scrollable,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information #plugin-information-scrollable{'
        . 'background:#1a1d23!important;}'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-content,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-content,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information #plugin-information-content{'
        . 'background:#1a1d23!important;color:#cfd6e0!important;}'
        . 'body#plugin-information.ysh-plugin-info-dark .fyi,body#plugin-information.ysh-plugin-info-auto .fyi,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information .fyi{'
        . 'background:#121418!important;border-left-color:rgba(255,255,255,.12)!important;color:#9aa3b2!important;}'
        . 'body#plugin-information.ysh-plugin-info-dark #plugin-information-footer,'
        . 'body#plugin-information.ysh-plugin-info-auto #plugin-information-footer,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body#plugin-information #plugin-information-footer{'
        . 'background:#121418!important;border-top-color:rgba(255,255,255,.12)!important;}';

    if (yooadmin_studio_hub_get_plugin_information_effective_color_mode() === 'auto') {
        $css .= '@media (prefers-color-scheme:dark){'
            . 'body#plugin-information{background:#1a1d23!important;color:#cfd6e0!important;}'
            . 'body#plugin-information #plugin-information-scrollable{background:#1a1d23!important;}'
            . 'body#plugin-information #plugin-information-content{background:#1a1d23!important;color:#cfd6e0!important;}'
            . 'body#plugin-information .fyi{background:#121418!important;border-left-color:rgba(255,255,255,.12)!important;color:#9aa3b2!important;}'
            . 'body#plugin-information #plugin-information-footer{background:#121418!important;border-top-color:rgba(255,255,255,.12)!important;}'
            . 'body#plugin-information #plugin-information-tabs{background:#121418!important;}'
            . 'body#plugin-information #plugin-information-title:not(.with-banner){background:#121418!important;}'
            . '}';
    }

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Raw trusted theme CSS.
    echo '<style id="yooadmin-studio-hub-plugin-information-critical">' . $css . '</style>' . "\n";
}

/**
 * Re-link cascade tail late in <head>.
 */
function yooadmin_studio_hub_print_plugin_information_cascade_tail(): void {
    if (!yooadmin_studio_hub_should_load_plugin_information_dark()) {
        return;
    }

    $file = yooadmin_studio_hub_plugin_information_stylesheet_path();
    if (!is_readable($file)) {
        return;
    }

    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Late cascade tail must load after wp-admin CSS in iframe <head>.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-plugin-information-cascade-tail" href="%s" />' . "\n",
        esc_url(yooadmin_studio_hub_plugin_information_stylesheet_url())
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

/**
 * Footer rules — beats late wp-admin styles in iframe.
 */
function yooadmin_studio_hub_print_plugin_information_footer_dark(): void {
    if (!yooadmin_studio_hub_should_load_plugin_information_dark()) {
        return;
    }

    $rules =
        'body#plugin-information #plugin-information-tabs{background:#121418!important;border-bottom-color:rgba(255,255,255,.12)!important;}'
        . 'body#plugin-information #plugin-information-tabs a{color:#9aa3b2!important;}'
        . 'body#plugin-information #plugin-information-tabs a.current{'
        . 'background:#1a1d23!important;border-color:rgba(255,255,255,.12)!important;'
        . 'border-bottom-color:#1a1d23!important;color:#e8ecf1!important;}'
        . 'body#plugin-information #plugin-information-title:not(.with-banner){background:#121418!important;}'
        . 'body#plugin-information .section,body#plugin-information .section p{color:#cfd6e0!important;}'
        . 'body#plugin-information :is(.notice,.notice-warning,.notice-alt){background:rgba(255,255,255,.06)!important;'
        . 'border-color:rgba(255,255,255,.14)!important;color:#cfd6e0!important;}'
        . 'body#plugin-information .notice-warning{background:rgba(219,166,23,.14)!important;border-left-color:#dba617!important;}'
        . 'body#plugin-information :is(.notice,.notice-warning) :is(p,strong,span){color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . 'body#plugin-information :is(.notice,.notice-warning) strong{color:#e8ecf1!important;}'
        . 'body#plugin-information #plugin-information-footer .button{'
        . 'background:rgba(255,255,255,.08)!important;border-color:rgba(255,255,255,.16)!important;color:#e8ecf1!important;}'
        . 'body#plugin-information #plugin-information-footer .button.disabled,'
        . 'body#plugin-information #plugin-information-footer .button[disabled]{'
        . 'background:rgba(255,255,255,.06)!important;color:#9aa3b2!important;opacity:1!important;}';

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static footer CSS fragments.
    echo '<style id="yooadmin-studio-hub-plugin-information-footer">' . $rules
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] ' . $rules;

    if (yooadmin_studio_hub_get_plugin_information_effective_color_mode() === 'auto') {
        echo '@media (prefers-color-scheme:dark){' . $rules . '}';
    }

    echo '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Minimal dark rules injected into iframe from parent (sync paint, no network wait).
 *
 * @return string
 */
function yooadmin_studio_hub_plugin_information_parent_paint_css(): string {
    return yooadmin_studio_hub_plugin_information_antiflash_css()
        . 'body#plugin-information #plugin-information-tabs{border-bottom-color:rgba(255,255,255,.12)!important;}'
        . 'body#plugin-information #plugin-information-tabs a{color:#9aa3b2!important;}'
        . 'body#plugin-information #plugin-information-tabs a.current{background:#1a1d23!important;'
        . 'border-color:rgba(255,255,255,.12)!important;border-bottom-color:#1a1d23!important;color:#e8ecf1!important;}'
        . 'body#plugin-information .fyi{border-left-color:rgba(255,255,255,.12)!important;color:#9aa3b2!important;}'
        . 'body#plugin-information .section,body#plugin-information .section p{color:#cfd6e0!important;}'
        . 'body#plugin-information :is(.notice,.notice-warning,.notice-alt){background:rgba(255,255,255,.06)!important;'
        . 'border-color:rgba(255,255,255,.14)!important;color:#cfd6e0!important;}'
        . 'body#plugin-information .notice-warning{background:rgba(219,166,23,.14)!important;border-left-color:#dba617!important;}'
        . 'body#plugin-information :is(.notice,.notice-warning) :is(p,strong,span){color:#cfd6e0!important;}'
        . 'body#plugin-information :is(.notice,.notice-warning) strong{color:#e8ecf1!important;}'
        . 'body#plugin-information #plugin-information-footer .button{background:rgba(255,255,255,.08)!important;'
        . 'border-color:rgba(255,255,255,.16)!important;color:#e8ecf1!important;}'
        . 'body#plugin-information #plugin-information-footer .button.disabled,'
        . 'body#plugin-information #plugin-information-footer .button[disabled]{'
        . 'background:rgba(255,255,255,.06)!important;color:#9aa3b2!important;opacity:1!important;}';
}

/**
 * YOOAdmin spinner overlay while plugin details iframe loads (dark mode).
 */
function yooadmin_studio_hub_print_plugin_information_loader_markup(): void {
    if (!yooadmin_studio_hub_is_plugin_information_parent_page()) {
        return;
    }

    echo '<style id="ysh-plugin-details-loader-critical">'
        . '.ysh-plugin-details-loader{position:fixed;inset:0;z-index:110003;display:none;align-items:center;justify-content:center;background:rgba(10,12,16,.42);backdrop-filter:blur(10px) saturate(120%);-webkit-backdrop-filter:blur(10px) saturate(120%);}'
        . '.ysh-plugin-details-loader.is-visible{display:flex;}'
        . '.ysh-plugin-details-loader__panel{display:flex;flex-direction:column;align-items:center;gap:14px;padding:0;border-radius:0;background:transparent;border:0;box-shadow:none;}'
        . '.ysh-plugin-details-loader__text{margin:0;font-size:14px;font-weight:600;color:#f8fafc;text-shadow:0 1px 3px rgba(0,0,0,.62);}'
        . '.ysh-plugin-details-loader__ring{display:block;box-sizing:border-box;width:40px;height:40px;border:3px solid rgba(0,0,0,.12);border-top-color:var(--yp-primary,#eda934);border-radius:50%;animation:ysh-plugin-details-spin .8s linear infinite;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body:is(.plugins-php,.plugin-install-php) .ysh-plugin-details-loader,html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body:is(.plugins-php,.plugin-install-php) .ysh-plugin-details-loader{background:rgba(10,12,16,.58);}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body:is(.plugins-php,.plugin-install-php) .ysh-plugin-details-loader__text,html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body:is(.plugins-php,.plugin-install-php) .ysh-plugin-details-loader__text{color:#f8fafc;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body:is(.plugins-php,.plugin-install-php) .ysh-plugin-details-loader__ring,html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body:is(.plugins-php,.plugin-install-php) .ysh-plugin-details-loader__ring{border-color:rgba(255,255,255,.12);border-top-color:var(--yp-primary,#eda934);}'
        . '@keyframes ysh-plugin-details-spin{to{transform:rotate(360deg);}}'
        . '#TB_window.ysh-plugin-details-pending{visibility:hidden!important;}'
        . '#TB_window.ysh-plugin-details-pending #TB_iframeContent{opacity:0!important;}'
        . '</style>' . "\n";
    echo '<div id="ysh-plugin-details-loader" class="ysh-plugin-details-loader" hidden aria-hidden="true">'
        . '<div class="ysh-plugin-details-loader__panel" role="status" aria-live="polite">'
        . '<span class="ysh-plugin-details-loader__ring" aria-hidden="true"></span>'
        . '<p class="ysh-plugin-details-loader__text">' . esc_html__('Loading plugin details…', 'yooadmin') . '</p>'
        . '</div></div>' . "\n";
}

/**
 * Parent Thickbox shell polish shared by light/dark modes.
 */
function yooadmin_studio_hub_print_plugin_information_parent_shell_css(): void {
    if (!yooadmin_studio_hub_is_plugin_information_parent_page()) {
        return;
    }

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static CSS.
    echo '<style id="yooadmin-studio-hub-plugin-information-parent-shell">'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php).ysh-plugin-details-open #TB_overlay{'
        . 'opacity:1!important;background:rgba(10,12,16,.42)!important;backdrop-filter:blur(10px) saturate(120%)!important;-webkit-backdrop-filter:blur(10px) saturate(120%)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php).ysh-plugin-details-open #TB_overlay,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php).ysh-plugin-details-open #TB_overlay{'
        . 'background:rgba(10,12,16,.58)!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton{'
        . 'position:absolute!important;top:10px!important;right:10px!important;z-index:110004!important;'
        . 'display:flex!important;align-items:center!important;justify-content:center!important;'
        . 'width:30px!important;height:30px!important;min-width:30px!important;min-height:30px!important;'
        . 'margin:0!important;padding:0!important;border:0!important;border-radius:999px!important;'
        . 'outline:0!important;background:rgba(18,20,24,.72)!important;color:#fff!important;'
        . 'text-decoration:none!important;box-shadow:none!important;'
        . '-webkit-appearance:none!important;appearance:none!important;overflow:hidden!important;'
        . 'transition:background .18s ease,color .18s ease!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:hover,'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:focus,'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:focus-visible{'
        . 'outline:0!important;border:0!important;background:rgba(237,169,52,.95)!important;color:#fff!important;box-shadow:none!important;transform:none!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:focus,'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:focus-visible{'
        . 'outline:0!important;box-shadow:none!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton .tb-close-icon{'
        . 'display:flex!important;align-items:center!important;justify-content:center!important;width:100%!important;height:100%!important;'
        . 'margin:0!important;padding:0!important;border:0!important;outline:0!important;background:transparent!important;color:#fff!important;'
        . 'box-shadow:none!important;text-shadow:none!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton .tb-close-icon:before,'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:after{'
        . 'display:block!important;width:auto!important;height:auto!important;margin:0!important;padding:0!important;'
        . 'border:0!important;outline:0!important;box-shadow:none!important;color:#fff!important;font-size:18px!important;line-height:1!important;text-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton{'
        . 'background:rgba(255,255,255,.08)!important;color:var(--ysh-heading,#e8ecf1)!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:hover,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:focus-visible,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:hover,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.plugins-php,.plugin-install-php) #TB_window.plugin-details-modal #TB_closeWindowButton:focus-visible{'
        . 'background:color-mix(in srgb,var(--ysh-brand,#eda934) 32%,rgba(255,255,255,.08))!important;color:#fff!important;}'
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Parent plugins.php — defer modal reveal until iframe is dark-ready; show YOOAdmin spinner.
 */
function yooadmin_studio_hub_print_plugin_information_parent_inject_script(): void {
    if (!yooadmin_studio_hub_is_plugin_information_parent_page()) {
        return;
    }

    $css_url   = wp_json_encode(yooadmin_studio_hub_plugin_information_stylesheet_url());
    $paint_css = wp_json_encode(yooadmin_studio_hub_plugin_information_parent_paint_css());

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Inline script; JSON values from wp_json_encode().
    echo '<script id="yooadmin-studio-hub-plugin-info-parent-inject">'
        . 'jQuery(function($){'
        . 'var cssUrl=' . $css_url . ',paintCss=' . $paint_css . ',pending=false,pendingDark=false;'
        . 'var loader=document.getElementById("ysh-plugin-details-loader");'
        . 'function parentEffectiveDark(){var h=document.documentElement;'
        . 'var eff=h.getAttribute("data-yooadmin-studio-color-mode-effective");'
        . 'if(eff==="dark"||h.classList.contains("is-dark-theme")){return true;}'
        . 'var mode=h.getAttribute("data-yooadmin-studio-color-mode");'
        . 'if(mode==="auto"){try{return window.matchMedia("(prefers-color-scheme: dark)").matches;}catch(e){}}'
        . 'return false;}'
        . 'function appendEffectiveToUrl(url){if(!url||!parentEffectiveDark()){return url;}'
        . 'if(url.indexOf("ysh_effective=")>=0){return url;}'
        . 'return url+(url.indexOf("?")>=0?"&":"?")+"ysh_effective=dark";}'
        . 'function showLoader(){if(document.body){document.body.classList.add("ysh-plugin-details-open","ysh-plugin-details-loading");}if(!loader){return;}'
        . 'loader.hidden=false;loader.setAttribute("aria-hidden","false");loader.classList.add("is-visible");}'
        . 'function hideLoader(){if(!loader){return;}'
        . 'loader.hidden=true;loader.setAttribute("aria-hidden","true");loader.classList.remove("is-visible");}'
        . 'function paintIframe(doc){if(!doc||!doc.documentElement){return;}'
        . 'doc.documentElement.setAttribute("data-yooadmin-studio-color-mode-effective","dark");'
        . 'doc.documentElement.classList.add("yooadmin-studio-hub-html");'
        . 'if(doc.body){doc.body.classList.add("ysh-plugin-info-dark");}'
        . 'var st=doc.getElementById("ysh-plugin-info-paint");'
        . 'if(!st){st=doc.createElement("style");st.id="ysh-plugin-info-paint";doc.head.appendChild(st);}'
        . 'st.textContent=paintCss;'
        . 'if(!doc.getElementById("ysh-plugin-info-dark-link")){'
        . 'var link=doc.createElement("link");link.id="ysh-plugin-info-dark-link";link.rel="stylesheet";'
        . 'link.href=cssUrl;doc.head.appendChild(link);}}'
        . 'function revealPluginDetailsModal(){'
        . 'var frame=document.getElementById("TB_iframeContent");'
        . 'var win=document.getElementById("TB_window");'
        . 'var dark=pendingDark;hideLoader();pending=false;pendingDark=false;'
        . 'if(frame){frame.style.opacity="1";}'
        . 'if(win){win.style.background=dark?"#1a1d23":"#fff";win.style.visibility="visible";win.classList.remove("ysh-plugin-details-pending");}'
        . 'jQuery("#TB_load").remove();'
        . 'jQuery("#TB_window").trigger("thickbox:iframe:loaded");}'
        . 'function finishPendingIframe(){'
        . 'var frame=document.getElementById("TB_iframeContent");'
        . 'if(!frame){hideLoader();pending=false;return;}'
        . 'if(pendingDark){try{paintIframe(frame.contentDocument||frame.contentWindow.document);}catch(e){}}'
        . 'requestAnimationFrame(function(){requestAnimationFrame(revealPluginDetailsModal);});}'
        . 'function patchPluginDetailLinks(){$(".thickbox.open-plugin-details-modal").each(function(){'
        . 'var href=$(this).attr("href");if(href){$(this).attr("href",appendEffectiveToUrl(href));}});}'
        . 'if(typeof window.tb_show==="function"&&!window.tb_show.yshPatched){'
        . 'var coreShow=window.tb_show;'
        . 'window.tb_show=function(caption,url,imageGroup){'
        . 'var defer=url&&url.indexOf("plugin-information")!==-1;pendingDark=defer&&parentEffectiveDark();'
        . 'if(defer){url=pendingDark?appendEffectiveToUrl(url):url;pending=true;showLoader();}'
        . 'var out=coreShow.call(this,caption,url,imageGroup);'
        . 'if(defer){jQuery("#TB_load").remove();'
        . 'jQuery("#TB_window").css({visibility:"hidden",background:pendingDark?"#1a1d23":"#fff"})'
        . '.addClass("plugin-details-modal ysh-plugin-details-pending");'
        . 'var frame=document.getElementById("TB_iframeContent");if(frame){frame.style.opacity="0";}}'
        . 'return out;};'
        . 'window.tb_show.yshPatched=true;}'
        . 'if(typeof window.tb_showIframe==="function"&&!window.tb_showIframe.yshPatched){'
        . 'var coreIframe=window.tb_showIframe;'
        . 'window.tb_showIframe=function(){'
        . 'if(!pending){return coreIframe.apply(this,arguments);}'
        . 'finishPendingIframe();};'
        . 'window.tb_showIframe.yshPatched=true;}'
        . 'patchPluginDetailLinks();'
        . '$(document.body).on("thickbox:removed",function(){hideLoader();pending=false;pendingDark=false;if(document.body){document.body.classList.remove("ysh-plugin-details-open","ysh-plugin-details-loading");}});'
        . '});'
        . '</script>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Offset Thickbox below YOOAdmin header without overriding WP width/height math.
 */
function yooadmin_studio_hub_print_plugin_information_tb_position_script(): void {
    if (!yooadmin_studio_hub_is_plugin_information_parent_page()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-plugin-details-tb-position">'
        . 'jQuery(function(){'
        . 'if(typeof window.tb_position!=="function"){return;}'
        . 'var core=window.tb_position;'
        . 'window.tb_position=function(){'
        . 'core.apply(this,arguments);'
        . 'var win=document.getElementById("TB_window");'
        . 'if(!win||!win.classList.contains("plugin-details-modal")){return;}'
        . 'var frame=document.getElementById("TB_iframeContent");'
        . 'var root=document.documentElement;'
        . 'var header=parseInt(getComputedStyle(root).getPropertyValue("--yp-header-h"),10)||64;'
        . 'var bc=parseInt(getComputedStyle(root).getPropertyValue("--yp-bc-h"),10)||48;'
        . 'var offset=header+bc+12;'
        . 'var maxH=Math.max(320,window.innerHeight-offset-24);'
        . 'var w=win.offsetWidth;'
        . 'var h=Math.min(win.offsetHeight||maxH,maxH);'
        . 'win.style.top=offset+"px";'
        . 'win.style.marginTop="0";'
        . 'win.style.height=h+"px";'
        . 'if(frame){frame.style.height=h+"px";if(w){frame.style.width=w+"px";}}'
        . 'if(w){win.style.left="50%";win.style.marginLeft="-"+Math.round(w/2)+"px";}'
        . '};'
        . '});'
        . '</script>' . "\n";
}
