<?php
/**
 * Studio Hub — server-side layout rendering (section order, custom/widget shells).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * @param array<string, mixed>|null $layout Layout payload.
 * @return string[]
 */
function yooadmin_studio_hub_default_aside_order(?array $layout = null): array {
    $overview_widget_section = function_exists('yooadmin_studio_hub_default_overview_widget_section_id')
        ? yooadmin_studio_hub_default_overview_widget_section_id()
        : 'widget-aside-yooadmin-overview';
    $order = ['studio-workspace-notes', 'studio-updates', 'studio-tips', 'studio-activity', $overview_widget_section];
    if (
        $layout
        && function_exists('yooadmin_studio_hub_section_in_aside')
        && yooadmin_studio_hub_section_in_aside('from-extensions', $layout)
    ) {
        $aside = isset($layout['asideOrder']) && is_array($layout['asideOrder']) ? $layout['asideOrder'] : [];
        if (in_array('from-extensions', $aside, true)) {
            $pos = array_search('studio-workspace-notes', $order, true);
            if ($pos === false) {
                array_unshift($order, 'from-extensions');
            } else {
                array_splice($order, (int) $pos + 1, 0, ['from-extensions']);
            }
        }
    }

    return $order;
}

/**
 * @param array<string, mixed>|null $layout Layout payload.
 * @return string[]
 */
function yooadmin_studio_hub_resolve_aside_order(?array $layout): array {
    if (!$layout || !is_array($layout)) {
        return array_values(
            array_filter(
                yooadmin_studio_hub_default_aside_order(null),
                static function ($id) {
                    return yooadmin_studio_hub_user_can_view_layout_section((string) $id, null);
                }
            )
        );
    }

    $layout = yooadmin_studio_hub_migrate_layout_orders($layout);
    $removed_builtins = !empty($layout['removedBuiltInSections']) && is_array($layout['removedBuiltInSections'])
        ? array_fill_keys($layout['removedBuiltInSections'], true)
        : [];
    $has_aside_order  = array_key_exists('asideOrder', $layout) && is_array($layout['asideOrder']);
    $aside            = $has_aside_order ? $layout['asideOrder'] : [];
    if (!$has_aside_order) {
        return array_values(
            array_filter(
                array_values(
                    array_filter(
                        yooadmin_studio_hub_default_aside_order($layout),
                        static function ($id) use ($removed_builtins) {
                            return !isset($removed_builtins[ $id ]);
                        }
                    )
                ),
                static function ($id) use ($layout) {
                    return yooadmin_studio_hub_user_can_view_layout_section((string) $id, $layout);
                }
            )
        );
    }

    $known = [
        'studio-workspace-notes' => true,
        'studio-updates'         => true,
        'studio-tips'            => true,
        'studio-activity'        => true,
        'from-extensions'        => true,
    ];

    $removed_widgets = function_exists('yooadmin_studio_hub_removed_widget_ids')
        ? array_fill_keys(yooadmin_studio_hub_removed_widget_ids($layout), true)
        : [];

    $out = [];
    foreach ($aside as $id) {
        $id = sanitize_key((string) $id);
        if ($id === '') {
            continue;
        }
        if (
            !empty($layout['widgetSections'][ $id ]['widgetId'])
            && isset($removed_widgets[ (string) $layout['widgetSections'][ $id ]['widgetId'] ])
        ) {
            continue;
        }
        if ($id !== '' && isset($known[ $id ]) && !isset($removed_builtins[ $id ])) {
            $out[] = $id;
        }
    }

    foreach (array_keys($known) as $id) {
        if (!in_array($id, $out, true)) {
            if (isset($removed_builtins[ $id ])) {
                continue;
            }
            if ($id === 'from-extensions') {
                if (yooadmin_studio_hub_section_in_aside('from-extensions', $layout)) {
                    $out[] = $id;
                }
                continue;
            }
            $out[] = $id;
        }
    }

    if (!empty($layout['customSections']) && is_array($layout['customSections'])) {
        foreach ($layout['customSections'] as $section_id => $meta) {
            if (!is_array($meta) || ($meta['placement'] ?? 'main') !== 'aside') {
                continue;
            }
            $section_id = sanitize_key((string) $section_id);
            if ($section_id !== '' && !in_array($section_id, $out, true)) {
                $out[] = $section_id;
            }
        }
    }

    if (!empty($layout['widgetSections']) && is_array($layout['widgetSections'])) {
        foreach ($layout['widgetSections'] as $section_id => $meta) {
            if (!is_array($meta) || ($meta['placement'] ?? 'main') !== 'aside') {
                continue;
            }
            $widget_id = sanitize_key((string) ( $meta['widgetId'] ?? '' ));
            if ($widget_id !== '' && isset($removed_widgets[ $widget_id ])) {
                continue;
            }
            $section_id = sanitize_key((string) $section_id);
            if ($section_id !== '' && !in_array($section_id, $out, true)) {
                $out[] = $section_id;
            }
        }
    }

    return array_values(
        array_filter(
            $out,
            static function ($id) use ($layout) {
                return yooadmin_studio_hub_user_can_view_layout_section((string) $id, $layout);
            }
        )
    );
}

/**
 * @param array<string, mixed>|null $layout Layout payload.
 * @return string[]
 */
function yooadmin_studio_hub_resolve_main_order(?array $layout): array {
    $defaults = ['your-workspace', 'from-extensions'];

    if (!$layout || !is_array($layout)) {
        return $defaults;
    }

    $layout = yooadmin_studio_hub_migrate_layout_orders($layout);
    $main   = isset($layout['mainOrder']) && is_array($layout['mainOrder']) ? $layout['mainOrder'] : [];
    $aside  = isset($layout['asideOrder']) && is_array($layout['asideOrder']) ? $layout['asideOrder'] : [];
    $aside_set = array_fill_keys($aside, true);

    $out = [];
    foreach ($main as $id) {
        $id = sanitize_key((string) $id);
        if ($id !== '' && !isset($aside_set[ $id ])) {
            $out[] = $id;
        }
    }

    foreach ($defaults as $id) {
        if (!in_array($id, $out, true) && !isset($aside_set[ $id ])) {
            if ($id === 'from-extensions' && yooadmin_studio_hub_section_in_aside('from-extensions', $layout)) {
                continue;
            }
            $out[] = $id;
        }
    }

    if (!empty($layout['customSections']) && is_array($layout['customSections'])) {
        foreach ($layout['customSections'] as $section_id => $meta) {
            if (!is_array($meta) || ($meta['placement'] ?? 'main') !== 'main') {
                continue;
            }
            $section_id = sanitize_key((string) $section_id);
            if ($section_id !== '' && !in_array($section_id, $out, true)) {
                $out[] = $section_id;
            }
        }
    }

    if (!empty($layout['widgetSections']) && is_array($layout['widgetSections'])) {
        foreach ($layout['widgetSections'] as $section_id => $meta) {
            if (!is_array($meta) || ($meta['placement'] ?? 'main') !== 'main') {
                continue;
            }
            $section_id = sanitize_key((string) $section_id);
            if ($section_id !== '' && !in_array($section_id, $out, true)) {
                $out[] = $section_id;
            }
        }
    }

    return apply_filters('yooadmin_studio_hub_resolved_main_order', $out, $layout);
}

/**
 * @param string               $icon Raw icon class.
 * @param string               $fallback Fallback class.
 */
function yooadmin_studio_hub_normalize_section_icon(string $icon, string $fallback = 'dashicons-screenoptions'): string {
    $icon = sanitize_text_field($icon);
    if ($icon === '') {
        return $fallback;
    }
    if (strpos($icon, 'dashicons-') === 0) {
        return $icon;
    }
    if (strpos($icon, 'dashicons ') === 0) {
        return trim($icon);
    }

    return 'dashicons-' . preg_replace('/^dashicons-/', '', $icon);
}

/**
 * Render an empty custom section shell (cards reordered by layout-ssr-apply.js).
 *
 * @param string               $section_id Section id.
 * @param array<string, mixed> $meta       Section meta.
 * @param array<string, mixed> $layout     Full layout (for aside pagination attrs).
 */
function yooadmin_studio_hub_render_custom_section_shell(string $section_id, array $meta, ?array $layout = null): void {
    $placement = isset($meta['placement']) && $meta['placement'] === 'aside' ? 'aside' : 'main';
    $title     = isset($meta['title']) ? (string) $meta['title'] : '';
    $title     = $title !== '' ? $title : __('Custom section', 'yooadmin');
    $icon      = yooadmin_studio_hub_normalize_section_icon((string) ( $meta['icon'] ?? '' ));

    $aside_class = $placement === 'aside' ? ' yp-studio-custom-section--aside' : '';
    $grid_class  = $placement === 'aside'
        ? 'yp-icon-grid-boxes yp-cards-grid yp-studio-workspace-rows yp-studio-custom-grid yp-studio-aside-grid'
        : 'yp-icon-grid-boxes yp-cards-grid yp-studio-workspace-rows yp-studio-custom-grid';

    $paginate = '';
    $pager    = '';
    $use_pagination = $placement === 'aside';
    if ($use_pagination) {
        $per_page = 4;
        $paginate = ' data-workspace-paginate="true" data-items-per-page="' . esc_attr((string) $per_page) . '"';
        $pager    =
            '<div class="yp-studio-ws-pager-footer" data-ws-pager-footer hidden>'
            . '<nav class="yp-studio-ws-nav" data-ws-nav hidden aria-label="' . esc_attr__('Section pages', 'yooadmin') . '">'
            . '<button type="button" class="yp-studio-ws-nav__btn" data-ws-prev aria-label="' . esc_attr__('Previous page', 'yooadmin') . '">'
            . '<span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span></button>'
            . '<span class="yp-studio-ws-nav__label" data-ws-nav-label aria-live="polite"></span>'
            . '<button type="button" class="yp-studio-ws-nav__btn" data-ws-next aria-label="' . esc_attr__('Next page', 'yooadmin') . '">'
            . '<span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span></button>'
            . '</nav>'
            . '<div class="yp-studio-ws-dots" data-ws-dots hidden aria-hidden="true"></div>'
            . '</div>';
    }

    $hint = esc_html__(
        'Drag tiles here from another section (use the move handle on each tile).',
        'yooadmin'
    );

    printf(
        '<div class="yp-card yp-card-full yp-dashboard-section yp-studio-surface-card yp-studio-custom-section yp-studio-layout-section--booting%s"'
        . ' data-section-id="%s" data-layout-section="true" data-collapsible="true" data-sortable="true"'
        . ' data-collapsed="false" data-custom-placement="%s" data-section-title="%s"'
        . ' data-default-section-icon="dashicons-screenoptions" data-layout-booting="true">',
        esc_attr($aside_class),
        esc_attr($section_id),
        esc_attr($placement),
        esc_attr($title)
    );
    ?>
    <div class="yp-card-header yp-section-header yp-layout-section-handle">
      <span class="yp-section-header__edit-controls">
        <span class="yp-layout-section-drag-handle" aria-hidden="true">
          <span class="dashicons dashicons-move" aria-hidden="true"></span>
        </span>
        <span class="yp-section-icon-edit" role="button" tabindex="0" hidden>
          <span class="dashicons dashicons-edit" aria-hidden="true"></span>
        </span>
      </span>
      <h2 class="yp-card-title yp-section-title">
        <span class="yp-section-title-icon-wrap">
          <span class="yp-section-title-icon dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
        </span>
        <span class="yp-section-title-label"><?php echo esc_html($title); ?></span>
        <input type="text" class="yp-section-title-input" maxlength="80" autocomplete="off" spellcheck="false" hidden
               value="<?php echo esc_attr($title); ?>" />
      </h2>
      <div class="yp-card-header-actions">
        <button type="button" class="yp-layout-section-remove" aria-label="<?php esc_attr_e('Remove section', 'yooadmin'); ?>">
          <span class="dashicons dashicons-trash" aria-hidden="true"></span>
        </button>
      </div>
    </div>
    <div class="<?php echo esc_attr($grid_class); ?>" data-layout="grid" data-columns="auto" data-sortable="true"<?php
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built above with esc_attr.
        echo $paginate;
    ?>>
      <div class="yp-studio-section-grid-loading yp-studio-section-loading" data-layout-loading aria-hidden="false">
        <div class="yp-loading-spinner">
          <div class="yp-spinner-circle"></div>
        </div>
      </div>
      <p class="yp-layout-empty-drop-hint" data-layout-empty-hint hidden><?php echo esc_html($hint); ?></p>
    </div>
    <?php
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* above.
    echo $pager;
    ?>
    </div>
    <?php
}

/**
 * @param string               $section_id Section id.
 * @param array<string, mixed> $meta       Section meta.
 */
function yooadmin_studio_hub_render_widget_section_shell(string $section_id, array $meta): void {
    $layout = [
        'widgetSections' => [
            $section_id => $meta,
        ],
    ];
    if (!yooadmin_studio_hub_user_can_view_layout_section($section_id, $layout)) {
        return;
    }

    $placement = isset($meta['placement']) && $meta['placement'] === 'aside' ? 'aside' : 'main';
    $widget_id = isset($meta['widgetId']) ? sanitize_key((string) $meta['widgetId']) : '';
    if ($widget_id === '') {
        return;
    }
    $title = isset($meta['title']) ? (string) $meta['title'] : '';
    $title = function_exists('yooadmin_studio_hub_localized_widget_section_title')
        ? yooadmin_studio_hub_localized_widget_section_title($widget_id, $title)
        : ($title !== '' ? $title : __('Dashboard card', 'yooadmin'));
    $icon  = yooadmin_studio_hub_normalize_section_icon((string) ( $meta['icon'] ?? '' ), 'dashicons-admin-generic');

    printf(
        '<div class="yp-card yp-card-full yp-dashboard-section yp-studio-surface-card yp-studio-widget-section"'
        . ' data-section-id="%s" data-layout-section="true" data-section-type="widget" data-widget-id="%s"'
        . ' data-collapsible="false" data-sortable="true" data-collapsed="false" data-custom-placement="%s"'
        . ' data-section-title="%s" data-default-section-icon="%s" data-widget-ssr-pending="1">',
        esc_attr($section_id),
        esc_attr($widget_id),
        esc_attr($placement),
        esc_attr($title),
        esc_attr($icon)
    );
    ?>
    <div class="yp-card-header yp-section-header yp-layout-section-handle">
      <span class="yp-section-header__edit-controls">
        <span class="yp-layout-section-drag-handle" aria-hidden="true">
          <span class="dashicons dashicons-move" aria-hidden="true"></span>
        </span>
      </span>
      <h2 class="yp-card-title yp-section-title">
        <span class="yp-section-title-icon-wrap">
          <span class="yp-section-title-icon dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span>
        </span>
        <span class="yp-section-title-label"><?php echo esc_html($title); ?></span>
      </h2>
      <div class="yp-card-header-actions">
        <button type="button" class="yp-layout-section-remove" aria-label="<?php esc_attr_e('Remove section', 'yooadmin'); ?>">
          <span class="dashicons dashicons-trash" aria-hidden="true"></span>
        </button>
      </div>
    </div>
    <div class="yp-studio-widget-section__body" data-widget-body="true">
      <div class="yp-studio-widget-section__loading" role="status" aria-live="polite">
        <div class="yp-loading-spinner" aria-hidden="true">
          <div class="yp-spinner-circle"></div>
        </div>
        <span class="screen-reader-text"><?php esc_html_e('Loading widget…', 'yooadmin'); ?></span>
      </div>
    </div>
    </div>
    <?php
}

/**
 * Render one aside section by id.
 *
 * @param string               $section_id Section id.
 * @param array<string, mixed> $layout     Layout payload.
 * @param string               $cards_dir  Cards templates directory.
 */
function yooadmin_studio_hub_render_aside_section(string $section_id, ?array $layout, string $cards_dir): void {
    if (!yooadmin_studio_hub_user_can_view_layout_section($section_id, $layout)) {
        return;
    }

    switch ($section_id) {
        case 'studio-workspace-notes':
            $file = $cards_dir . '/card-workspace-notes.php';
            if (is_readable($file)) {
                include $file;
            }
            return;
        case 'from-extensions':
            if (
                !function_exists('yooadmin_studio_hub_section_in_aside')
                || !yooadmin_studio_hub_section_in_aside('from-extensions', $layout)
            ) {
                return;
            }
            $GLOBALS['yooadmin_studio_hub_extensions_placement'] = 'aside';
            $file = $cards_dir . '/card-extensions-studio.php';
            if (is_readable($file)) {
                include $file;
            }
            return;
        case 'studio-tips':
            $partial = $cards_dir . '/partials/aside-section-tips.php';
            if (is_readable($partial)) {
                include $partial;
            }
            return;
        case 'studio-updates':
            $partial = $cards_dir . '/partials/aside-section-updates.php';
            if (is_readable($partial)) {
                include $partial;
            }
            return;
        case 'studio-activity':
            $partial = $cards_dir . '/partials/aside-section-activity.php';
            if (is_readable($partial)) {
                include $partial;
            }
            return;
    }

    if ($layout && !empty($layout['customSections'][ $section_id ]) && is_array($layout['customSections'][ $section_id ])) {
        yooadmin_studio_hub_render_custom_section_shell($section_id, $layout['customSections'][ $section_id ], $layout);
        return;
    }

    if ($layout && !empty($layout['widgetSections'][ $section_id ]) && is_array($layout['widgetSections'][ $section_id ])) {
        yooadmin_studio_hub_render_widget_section_shell($section_id, $layout['widgetSections'][ $section_id ]);
    }
}

/**
 * Render one main column section by id.
 *
 * @param string               $section_id Section id.
 * @param array<string, mixed> $layout     Layout payload.
 * @param string               $cards_dir  Cards templates directory.
 */
function yooadmin_studio_hub_render_main_section(string $section_id, ?array $layout, string $cards_dir): void {
    if (!yooadmin_studio_hub_user_can_view_layout_section($section_id, $layout)) {
        return;
    }

    switch ($section_id) {
        case 'your-workspace':
            $file = $cards_dir . '/card-workspace-studio.php';
            if (is_readable($file)) {
                include $file;
            }
            return;
        case 'from-extensions':
            if (
                function_exists('yooadmin_studio_hub_section_in_aside')
                && yooadmin_studio_hub_section_in_aside('from-extensions', $layout)
            ) {
                return;
            }
            $GLOBALS['yooadmin_studio_hub_extensions_placement'] = 'main';
            $file = $cards_dir . '/card-extensions-studio.php';
            if (is_readable($file)) {
                include $file;
            }
            return;
    }

    if ($layout && !empty($layout['customSections'][ $section_id ]) && is_array($layout['customSections'][ $section_id ])) {
        yooadmin_studio_hub_render_custom_section_shell($section_id, $layout['customSections'][ $section_id ], $layout);
        return;
    }

    if ($layout && !empty($layout['widgetSections'][ $section_id ]) && is_array($layout['widgetSections'][ $section_id ])) {
        yooadmin_studio_hub_render_widget_section_shell($section_id, $layout['widgetSections'][ $section_id ]);
    }
}
