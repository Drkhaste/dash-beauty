<?php
/**
 * Studio Hub — split top-level admin menu into core WordPress / YOOAdmin vs third-party screens.
 *
 * @package YOOAdmin Extended
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_studio_hub_menu_item_bucket')) {
    /**
     * Classify a single top-level menu item.
     *
     * @param array<string, mixed> $item Menu tree item from yooadmin_build_admin_menu_tree().
     * @return string 'core'|'extensions'
     */
    function yooadmin_studio_hub_menu_item_bucket(array $item): string {
        $url = isset($item['url']) ? (string) $item['url'] : '';

        if ($url === '') {
            return 'core';
        }

        $path = (string) wp_parse_url($url, PHP_URL_PATH);
        $basename = strtolower((string) basename(strtok($path, '?')));
        $query = (string) wp_parse_url($url, PHP_URL_QUERY);
        $q = [];
        if ($query !== '') {
            parse_str($query, $q);
        }

        $admin_base = trailingslashit(strtolower((string) wp_parse_url(admin_url(), PHP_URL_PATH)));
        $path_norm = strtolower($path);
        if ($admin_base !== '/' && $path_norm !== '' && strpos($path_norm, $admin_base) === 0) {
            $rel = substr($path_norm, strlen(rtrim($admin_base, '/')));
            $basename = strtolower((string) basename($rel !== '' ? $rel : $path_norm));
        }

        if (strpos($url, 'http://') === 0 || strpos($url, 'https://') === 0) {
            $admin_host = (string) wp_parse_url(admin_url(), PHP_URL_HOST);
            $item_host = (string) wp_parse_url($url, PHP_URL_HOST);
            if ($item_host !== '' && $admin_host !== '' && strtolower($item_host) !== strtolower($admin_host)) {
                return 'extensions';
            }
        }

        if ($basename === 'edit.php') {
            $pt = isset($q['post_type']) ? (string) $q['post_type'] : '';
            if ($pt === '' || $pt === 'post') {
                return 'core';
            }
            if ($pt === 'page') {
                return 'core';
            }
            return 'extensions';
        }

        if ($basename === 'admin.php' && isset($q['page'])) {
            $page = (string) $q['page'];
            if ($page === 'site-health' || strpos($page, 'site-health') === 0) {
                return 'core';
            }
            if (strpos($page, 'yooadmin-') === 0) {
                return 'core';
            }
            return 'extensions';
        }

        $core_scripts = [
            'index.php',
            'upload.php',
            'edit-comments.php',
            'themes.php',
            'plugins.php',
            'plugin-install.php',
            'update-core.php',
            'users.php',
            'profile.php',
            'tools.php',
            'options-general.php',
            'import.php',
            'export.php',
            'site-health.php',
            'customize.php',
            'nav-menus.php',
            'widgets.php',
        ];

        if (in_array($basename, $core_scripts, true)) {
            return 'core';
        }

        return 'extensions';
    }
}

if (!function_exists('yooadmin_studio_hub_split_menu_tree')) {
    /**
     * @param array<int, array<string, mixed>> $menu_tree
     * @return array{core: array<int, array<string, mixed>>, extensions: array<int, array<string, mixed>>}
     */
    function yooadmin_studio_hub_split_menu_tree(array $menu_tree): array {
        $core = [];
        $extensions = [];
        foreach ($menu_tree as $item) {
            if (!is_array($item)) {
                continue;
            }
            if (yooadmin_studio_hub_menu_item_bucket($item) === 'extensions') {
                $extensions[] = $item;
            } else {
                $core[] = $item;
            }
        }

        return [
            'core'        => $core,
            'extensions'  => $extensions,
        ];
    }
}

if (!function_exists('yooadmin_studio_hub_core_group_key')) {
    /**
     * Sub-group label key for core items only.
     *
     * @param array<string, mixed> $item
     * @return string home|content|look|site|other
     */
    function yooadmin_studio_hub_core_group_key(array $item): string {
        $url = strtolower((string) ($item['url'] ?? ''));

        if (strpos($url, 'upload.php') !== false) {
            return 'content';
        }
        if (strpos($url, 'edit-comments.php') !== false) {
            return 'content';
        }
        if (strpos($url, 'edit.php') !== false) {
            if (strpos($url, 'post_type=page') !== false) {
                return 'content';
            }
            if (strpos($url, 'post_type=') === false) {
                return 'content';
            }
        }

        if (strpos($url, 'themes.php') !== false
            || strpos($url, 'customize.php') !== false
            || strpos($url, 'plugins.php') !== false
            || strpos($url, 'plugin-install.php') !== false) {
            return 'look';
        }

        if (strpos($url, 'users.php') !== false
            || strpos($url, 'profile.php') !== false
            || strpos($url, 'tools.php') !== false
            || strpos($url, 'options-general.php') !== false
            || strpos($url, 'site-health') !== false) {
            return 'site';
        }

        if (strpos($url, 'index.php') !== false && strpos($url, 'page=') === false) {
            return 'home';
        }
        if (strpos($url, 'page=yooadmin-dashboard') !== false) {
            return 'home';
        }

        if (strpos($url, 'page=yooadmin-') !== false) {
            return 'site';
        }

        if (strpos($url, 'update-core.php') !== false) {
            return 'site';
        }

        return 'other';
    }
}

if (!function_exists('yooadmin_studio_hub_group_core_menu')) {
    /**
     * @param array<int, array<string, mixed>> $core_items
     * @return array<int, array{key: string, label: string, items: array<int, array<string, mixed>>}>
     */
    function yooadmin_studio_hub_group_core_menu(array $core_items): array {
        $order = ['home', 'content', 'look', 'site', 'other'];
        $labels = [
            'home'    => __('Home & overview', 'yooadmin'),
            'content' => __('Content & media', 'yooadmin'),
            'look'    => __('Look & plugins', 'yooadmin'),
            'site'    => __('People, tools & settings', 'yooadmin'),
            'other'   => __('More', 'yooadmin'),
        ];

        $buckets = array_fill_keys($order, []);
        foreach ($core_items as $item) {
            if (!is_array($item)) {
                continue;
            }
            $k = yooadmin_studio_hub_core_group_key($item);
            if (!isset($buckets[$k])) {
                $k = 'other';
            }
            $buckets[$k][] = $item;
        }

        $out = [];
        foreach ($order as $key) {
            if (empty($buckets[$key])) {
                continue;
            }
            $out[] = [
                'key'    => $key,
                'label'  => $labels[$key],
                'items'  => $buckets[$key],
            ];
        }

        return apply_filters('yooadmin_studio_hub_core_menu_groups', $out, $core_items);
    }
}

if (!function_exists('yooadmin_studio_hub_url_item_description')) {
    /**
     * Short subtitle for admin menu links (popup tiles, workspace rows), keyed by URL + label.
     *
     * @param string $url   Admin menu URL.
     * @param string $title Clean menu label (optional).
     */
    function yooadmin_studio_hub_url_item_description(string $url, string $title = ''): string {
        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $url_l = strtolower($url);
        $title = function_exists('yooadmin_clean_menu_label_noise')
            ? yooadmin_clean_menu_label_noise($title)
            : trim((string) $title);

        $map = [
            'index.php'              => __('Overview of your site status and at-a-glance widgets.', 'yooadmin'),
            'upload.php'             => __('Upload and manage your media files.', 'yooadmin'),
            'media-new.php'          => __('Upload new images, documents, and other files.', 'yooadmin'),
            'edit-comments.php'      => __('View and moderate comments.', 'yooadmin'),
            'themes.php'             => __('Browse, activate, and update your site themes.', 'yooadmin'),
            'theme-install.php'      => __('Find and install themes from the directory.', 'yooadmin'),
            'theme-editor.php'       => __('Edit theme template files (use with care).', 'yooadmin'),
            'plugins.php'            => __('Install, activate, and manage plugins.', 'yooadmin'),
            'plugin-install.php'     => __('Browse and install plugins from the directory.', 'yooadmin'),
            'plugin-editor.php'      => __('Edit plugin files (use with care).', 'yooadmin'),
            'users.php'              => __('Manage users and their roles.', 'yooadmin'),
            'user-new.php'           => __('Add a new user account and assign a role.', 'yooadmin'),
            'profile.php'            => __('Manage your profile and account details.', 'yooadmin'),
            'tools.php'              => __('Site utilities: import, export, health, and privacy tools.', 'yooadmin'),
            'import.php'             => __('Bring content in from another system.', 'yooadmin'),
            'export.php'             => __('Download an export of your content.', 'yooadmin'),
            'site-health.php'        => __('Check and improve your site health.', 'yooadmin'),
            'export-personal-data.php' => __('Export personal data for privacy requests.', 'yooadmin'),
            'erase-personal-data.php'  => __('Erase personal data for privacy requests.', 'yooadmin'),
            'network.php'            => __('Configure multisite network settings.', 'yooadmin'),
            'customize.php'          => __('Live preview theme colors, layout, and widgets.', 'yooadmin'),
            'nav-menus.php'          => __('Build and assign navigation menus.', 'yooadmin'),
            'widgets.php'            => __('Manage sidebar and footer widget areas.', 'yooadmin'),
            'site-editor.php'        => __('Edit block templates and global styles.', 'yooadmin'),
            'options-general.php'    => __('Site title, URL, timezone, language, and membership.', 'yooadmin'),
            'options-writing.php'    => __('Default post category, format, email posting, and ping services.', 'yooadmin'),
            'options-reading.php'    => __('Homepage display, blog pages, and feed settings.', 'yooadmin'),
            'options-discussion.php' => __('Comment defaults, avatars, and moderation rules.', 'yooadmin'),
            'options-media.php'      => __('Image sizes and how uploads are organized.', 'yooadmin'),
            'options-permalink.php'  => __('Custom URL structures for posts, categories, and tags.', 'yooadmin'),
            'options-privacy.php'    => __('Privacy policy page and personal data settings.', 'yooadmin'),
            'options-connectors.php'   => __('Connect AI and third-party services for WordPress features.', 'yooadmin'),
            'page=ai-wp-admin'         => __('Configure WordPress AI features and experiments.', 'yooadmin'),
            'privacy.php'            => __('Privacy policy page and personal data tools.', 'yooadmin'),
            'update-core.php'        => __('Update WordPress core, themes, and translations.', 'yooadmin'),
            'action-scheduler'       => __('View and manage background tasks scheduled by plugins.', 'yooadmin'),
            'wpseo_redirects_tools'  => __('Manage SEO redirects for changed URLs (Yoast SEO).', 'yooadmin'),
            'ms-delete-site.php'     => __('Permanently delete this site from the network.', 'yooadmin'),
            'yooadmin.io'            => __('Download the Extended version for free.', 'yooadmin'),
        ];

        foreach ($map as $needle => $text) {
            if (strpos($url_l, $needle) !== false) {
                return (string) apply_filters('yooadmin_studio_hub_item_description', $text, $url, $title, $needle);
            }
        }

        if (strpos($url_l, 'action-scheduler') !== false) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('View and manage background tasks scheduled by plugins.', 'yooadmin'),
                $url,
                $title,
                'action-scheduler'
            );
        }

        if (strpos($url_l, 'wpseo_redirects_tools') !== false) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('Manage SEO redirects for changed URLs (Yoast SEO).', 'yooadmin'),
                $url,
                $title,
                'yoast-redirects'
            );
        }

        if (strpos($url_l, 'edit.php') !== false) {
            if (strpos($url_l, 'post_type=page') !== false) {
                return (string) apply_filters(
                    'yooadmin_studio_hub_item_description',
                    __('View, edit, and organize pages.', 'yooadmin'),
                    $url,
                    $title,
                    'pages'
                );
            }
            if (strpos($url_l, 'post_type=') === false) {
                return (string) apply_filters(
                    'yooadmin_studio_hub_item_description',
                    __('View, edit, and organize blog posts.', 'yooadmin'),
                    $url,
                    $title,
                    'posts'
                );
            }
        }

        if (strpos($url_l, 'post-new.php') !== false) {
            if (strpos($url_l, 'post_type=page') !== false) {
                return (string) apply_filters(
                    'yooadmin_studio_hub_item_description',
                    __('Create a new page.', 'yooadmin'),
                    $url,
                    $title,
                    'add-page'
                );
            }
            if (strpos($url_l, 'post_type=') === false) {
                return (string) apply_filters(
                    'yooadmin_studio_hub_item_description',
                    __('Create a new blog post.', 'yooadmin'),
                    $url,
                    $title,
                    'add-post'
                );
            }
        }

        if (strpos($url_l, 'edit-tags.php') !== false) {
            if (strpos($url_l, 'taxonomy=category') !== false) {
                return (string) apply_filters(
                    'yooadmin_studio_hub_item_description',
                    __('Organize and edit post categories.', 'yooadmin'),
                    $url,
                    $title,
                    'categories'
                );
            }
            if (strpos($url_l, 'taxonomy=post_tag') !== false) {
                return (string) apply_filters(
                    'yooadmin_studio_hub_item_description',
                    __('Manage post tags.', 'yooadmin'),
                    $url,
                    $title,
                    'tags'
                );
            }
        }

        if (strpos($url_l, 'page=yooadmin-dashboard') !== false) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('YOOAdmin home — shortcuts and overview for your site admin.', 'yooadmin'),
                $url,
                $title,
                'yooadmin-dashboard'
            );
        }

        if (strpos($url_l, 'page=yooadmin-settings') !== false) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('Tune YOOAdmin behavior, appearance, notifications, and integrations.', 'yooadmin'),
                $url,
                $title,
                'yooadmin-settings'
            );
        }

        if (strpos($url_l, 'page=yooadmin-themes') !== false) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('Browse and adjust YOOAdmin admin themes.', 'yooadmin'),
                $url,
                $title,
                'yooadmin-themes'
            );
        }

        if (strpos($url_l, 'page=yooadmin-license') !== false) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('Activate or review your YOOAdmin license and plan features.', 'yooadmin'),
                $url,
                $title,
                'yooadmin-license'
            );
        }

        if (strpos($url_l, 'page=yooadmin-activity') !== false) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('View recent workspace and site activity.', 'yooadmin'),
                $url,
                $title,
                'yooadmin-activity'
            );
        }

        if (strpos($url_l, 'page=yooadmin-admin-theme-settings') !== false) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('Configure the active admin theme colors and appearance options.', 'yooadmin'),
                $url,
                $title,
                'yooadmin-admin-theme-settings'
            );
        }

        if (strpos($url_l, 'page=yooadmin-') !== false) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('YOOAdmin tools and configuration for this section.', 'yooadmin'),
                $url,
                $title,
                'yooadmin'
            );
        }

        if (preg_match('/page=[^&]*(yoast|aioseo|seopress|squirrely|rank-math|wpseo|seo)[^&]*/i', $url_l)) {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                __('Optimize your site for search engines.', 'yooadmin'),
                $url,
                $title,
                'seo'
            );
        }

        if ($title !== '') {
            return (string) apply_filters(
                'yooadmin_studio_hub_item_description',
                sprintf(
                    /* translators: %s: admin menu item label. */
                    __('Open %s in the admin.', 'yooadmin'),
                    $title
                ),
                $url,
                $title,
                'title-fallback'
            );
        }

        $fallback = __('Open this section in the admin.', 'yooadmin');
        return (string) apply_filters('yooadmin_studio_hub_item_description', $fallback, $url, $title, 'default');
    }
}

if (!function_exists('yooadmin_studio_hub_workspace_item_description')) {
    /**
     * @param array<string, mixed> $item Menu tree item.
     */
    function yooadmin_studio_hub_workspace_item_description(array $item): string {
        $url   = (string) ($item['url'] ?? '');
        $title = (string) ($item['title'] ?? '');
        $text  = yooadmin_studio_hub_url_item_description($url, $title);

        return (string) apply_filters('yooadmin_studio_hub_workspace_description', $text, $item, 'url');
    }
}

if (!function_exists('yooadmin_studio_hub_build_popup_item_descriptions')) {
    /**
     * URL => description map for dashboard card submenu popup (from live admin menu).
     *
     * @return array<string, string>
     */
    function yooadmin_studio_hub_build_popup_item_descriptions(): array {
        if (!function_exists('yooadmin_build_admin_menu_tree')) {
            return [];
        }

        if (function_exists('yooadmin_load_admin_ui_textdomain')) {
            yooadmin_load_admin_ui_textdomain();
        }

        $map  = [];
        $tree = yooadmin_build_admin_menu_tree();
        foreach ($tree as $menu) {
            if (!is_array($menu)) {
                continue;
            }
            $subs = isset($menu['subs']) && is_array($menu['subs']) ? $menu['subs'] : [];
            foreach ($subs as $sub) {
                if (!is_array($sub)) {
                    continue;
                }
                $url = isset($sub['url']) ? (string) $sub['url'] : '';
                if ($url === '') {
                    continue;
                }
                $title       = isset($sub['title']) ? (string) $sub['title'] : '';
                $map[ $url ] = yooadmin_studio_hub_url_item_description($url, $title);
            }
        }

        return apply_filters('yooadmin_studio_hub_popup_item_descriptions', $map);
    }
}
