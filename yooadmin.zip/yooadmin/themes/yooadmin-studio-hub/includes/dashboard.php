<?php
/**
 * Studio Hub — dashboard
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Ensure layout AJAX nonce/url exist even if wp_localize_script did not attach them.
 */

function yooadmin_studio_hub_dashboard_redirect_enabled(): bool {
    if (function_exists('yooadmin_get_option')) {
        return (bool) yooadmin_get_option('redirect_dashboard', true);
    }

    $opts = (array) get_option('yooadmin_options', []);
    return array_key_exists('redirect_dashboard', $opts) ? !empty($opts['redirect_dashboard']) : true;
}

function yooadmin_studio_hub_wordpress_dashboard_url(): string {
    return add_query_arg('yooadmin_no_redirect', '1', admin_url('index.php'));
}

function yooadmin_studio_hub_dashboard_home_url(): string {
    return function_exists('yooadmin_dashboard_url')
        ? yooadmin_dashboard_url()
        : admin_url('admin.php?page=yooadmin-dashboard');
}

function yooadmin_studio_hub_ajax_set_dashboard_redirect(): void {
    check_ajax_referer('yooadmin_studio_hub_layout', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Forbidden', 'yooadmin')], 403);
    }

    $enabled = !empty($_POST['enabled']) && sanitize_text_field(wp_unslash($_POST['enabled'])) === '1';
    $opts    = (array) get_option('yooadmin_options', []);
    $opts['redirect_dashboard'] = $enabled ? 1 : 0;

    update_option('yooadmin_options', $opts, false);
    wp_cache_delete('yooadmin_options_' . get_current_user_id(), 'yooadmin_settings');

    wp_send_json_success([
        'enabled' => $enabled,
        'homeUrl' => $enabled
            ? yooadmin_studio_hub_dashboard_home_url()
            : yooadmin_studio_hub_wordpress_dashboard_url(),
    ]);
}

/**
 * Preload dashboard widget CSS/JS on the YOOAdmin dashboard (Site Health, WooCommerce setup, etc.).
 */
function yooadmin_studio_hub_enqueue_dashboard_widget_vendor_assets(): void {
    if (!function_exists('yooadmin_studio_hub_is_dashboard_screen') || !yooadmin_studio_hub_is_dashboard_screen()) {
        return;
    }
    if (!function_exists('yooadmin_studio_hub_enqueue_widget_assets')) {
        return;
    }

    yooadmin_studio_hub_enqueue_widget_assets('dashboard_site_health');
    if (class_exists('WooCommerce', false)) {
        yooadmin_studio_hub_enqueue_widget_assets('wc_admin_dashboard_setup');
    }

    if (
        function_exists('yooadmin_studio_hub_should_show_login_security_widget')
        && yooadmin_studio_hub_should_show_login_security_widget()
        && function_exists('yooadmin_studio_hub_enqueue_builtin_dashboard_card_assets')
    ) {
        yooadmin_studio_hub_enqueue_builtin_dashboard_card_assets('studio-login-security');
    }
}

function yooadmin_studio_hub_print_layout_script_config(): void {
    if (!function_exists('yooadmin_studio_hub_is_dashboard_screen') || !yooadmin_studio_hub_is_dashboard_screen()) {
        return;
    }

    $nonce = wp_create_nonce('yooadmin_studio_hub_layout');
    $ajax  = admin_url('admin-ajax.php');

    printf(
        '<script>window.yooadminStudioHubLayout=window.yooadminStudioHubLayout||{};window.yooadminStudioHubLayout.nonce=%1$s;window.yooadminStudioHubLayout.ajaxUrl=%2$s;window.yooadminStudioHubLayout.restUrl=%3$s;window.yooadminStudioHubLayout.restNonce=%4$s;window.yooadminStudioHubLayout.dashboardRedirectEnabled=%5$s;window.yooadminStudioHubLayout.wpDashboardUrl=%6$s;window.yooadminStudioHubLayout.yooadminDashboardUrl=%7$s;window.yooadminStudioHubLayout.canManageSiteSettings=%8$s;</script>' . "\n",
        wp_json_encode($nonce),
        wp_json_encode($ajax),
        wp_json_encode(rest_url('yooadmin/v1/')),
        wp_json_encode(wp_create_nonce('wp_rest')),
        wp_json_encode(yooadmin_studio_hub_dashboard_redirect_enabled()),
        wp_json_encode(yooadmin_studio_hub_wordpress_dashboard_url()),
        wp_json_encode(yooadmin_studio_hub_dashboard_home_url()),
        wp_json_encode(
            function_exists('yooadmin_user_can_manage_site_settings') && yooadmin_user_can_manage_site_settings()
        )
    );
}

/**
 * Script config for workspace-notes.js (site + network dashboard).
 *
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_workspace_notes_script_data(): array {
    if (!function_exists('yooadmin_studio_hub_filter_script_localize')) {
        return [];
    }

    $localized = yooadmin_studio_hub_filter_script_localize(
        null,
        'yooadmin-studio-hub-workspace-notes',
        'yooadmin-studio-hub',
        ['file' => 'assets/js/dashboard/workspace-notes.js']
    );

    return (is_array($localized) && !empty($localized['data']) && is_array($localized['data']))
        ? $localized['data']
        : [];
}

/**
 * @param array|null $data
 * @param string     $handle
 * @param string     $theme_slug
 * @param array      $asset
 * @return array|null
 */
function yooadmin_studio_hub_filter_script_localize($data, $handle, $theme_slug, $asset) {
    if ($theme_slug !== 'yooadmin-studio-hub' || empty($asset['file'])) {
        return $data;
    }

    $file = (string) $asset['file'];

    if (substr($file, -strlen('studio-hub.js')) === 'studio-hub.js') {
        $popup = [
            'defaultSectionDesc' => __('Open this section in the admin.', 'yooadmin'),
            'itemDescriptions'   => function_exists('yooadmin_studio_hub_build_popup_item_descriptions')
                ? yooadmin_studio_hub_build_popup_item_descriptions()
                : [],
        ];

        return [
            'object' => 'yooadminStudioHubAppearance',
            'data'   => [
                'ajaxUrl'   => admin_url('admin-ajax.php'),
                'nonce'     => wp_create_nonce('yooadmin_studio_hub_color_mode'),
                'colorMode' => yooadmin_studio_hub_get_color_mode(),
                'widthMode' => function_exists('yooadmin_studio_hub_get_width_mode') ? yooadmin_studio_hub_get_width_mode() : 'normal',
                'i18n'      => function_exists('yooadmin_studio_hub_appearance_script_i18n') ? yooadmin_studio_hub_appearance_script_i18n() : [],
                'popup'     => $popup,
            ],
        ];
    }

    if (substr($file, -strlen('studio-tips-carousel.js')) === 'studio-tips-carousel.js') {
        return [
            'object' => 'yooadminStudioHubTips',
            'data'   => [
                'autoplayMs' => 6500,
                'perPage'    => 5,
            ],
        ];
    }

    if (substr($file, -strlen('workspace-notes.js')) === 'workspace-notes.js') {
        $ws_types = function_exists('yooadmin_workspace_notes_types')
            ? yooadmin_workspace_notes_types()
            : [];

        $ws_dt = function_exists('yooadmin_workspace_notes_datetime_config')
            ? yooadmin_workspace_notes_datetime_config()
            : [];

        return [
            'object' => 'yooadminWorkspaceNotes',
            'data'   => array_merge(
                [
                    'ajaxUrl'  => admin_url('admin-ajax.php'),
                    'nonce'    => wp_create_nonce('yooadmin_workspace_notes'),
                    'types'    => $ws_types,
                    'pageSize' => function_exists('yooadmin_workspace_notes_page_size')
                        ? yooadmin_workspace_notes_page_size()
                        : 3,
                ],
                $ws_dt,
                [
                'i18n'    => [
                    'empty'          => __('No notes yet.', 'yooadmin'),
                    'markDone'       => __('Mark done', 'yooadmin'),
                    'deleteNote'     => __('Delete note', 'yooadmin'),
                    'confirmDelete'  => __('Delete this note?', 'yooadmin'),
                    'addNote'        => __('Add note', 'yooadmin'),
                    /* translators: %s: Due date label. */
                    /* translators: %s: due date. */                    'due'            => __('Due: %s', 'yooadmin'),
                    /* translators: %s: Completion date label. */
                    /* translators: %s: completion date. */                    'completed'      => __('Completed: %s', 'yooadmin'),
                    /* translators: %s: Reminder date/time label. */
                    /* translators: %s: reminder date. */                    'remind'         => __('Remind: %s', 'yooadmin'),
                    /* translators: %s: Note creation date label. */
                    /* translators: %s: date added. */                    'added'            => __('Added: %s', 'yooadmin'),
                    'dueRequired'      => __('Due date is required.', 'yooadmin'),
                    'remindRequired'   => __('Reminder time is required.', 'yooadmin'),
                    'deleteModalTitle' => __('Delete note?', 'yooadmin'),
                    'deleteModalMessage' => __('This note will be removed permanently.', 'yooadmin'),
                    'cancel'           => __('Cancel', 'yooadmin'),
                    'deleteConfirm'    => __('Delete', 'yooadmin'),
                    'titleRequired'  => __('Title is required.', 'yooadmin'),
                    'saved'          => __('Note saved.', 'yooadmin'),
                    'deleted'        => __('Note deleted.', 'yooadmin'),
                    'markedDone'     => __('Marked as done.', 'yooadmin'),
                    'markedActive'   => __('Marked as active.', 'yooadmin'),
                    'saveFailed'     => __('Could not save note.', 'yooadmin'),
                    'deleteFailed'   => __('Could not delete note.', 'yooadmin'),
                    'errorGeneric'   => __('Something went wrong. Please try again.', 'yooadmin'),
                    'loadMore'       => __('Load more', 'yooadmin'),
                    /* translators: %s: Site timezone label. */
                    'siteTime'       => __('Site time: %s', 'yooadmin'),
                ],
                ]
            ),
        ];
    }

    if (substr($file, -strlen('studio-updates-widget.js')) === 'studio-updates-widget.js') {
        return [
            'object' => 'yooadminStudioHubUpdates',
            'data'   => function_exists('yooadmin_studio_hub_updates_widget_script_data')
                ? yooadmin_studio_hub_updates_widget_script_data()
                : [
                    'ajaxUrl'    => admin_url('admin-ajax.php'),
                    'updatesUrl' => self_admin_url('update-core.php'),
                    'nonce'      => wp_create_nonce('updates'),
                    'i18n'       => [],
                ],
        ];
    }

    if (substr($file, -strlen('studio-hub-dashboard-layout.js')) === 'studio-hub-dashboard-layout.js') {
        return [
            'object' => 'yooadminStudioHubLayout',
            'data'   => [
                'ajaxUrl'    => admin_url('admin-ajax.php'),
                'nonce'      => wp_create_nonce('yooadmin_studio_hub_layout'),
                'restUrl'    => rest_url('yooadmin/v1/'),
                'restNonce'  => wp_create_nonce('wp_rest'),
                'dashboardRedirectEnabled' => yooadmin_studio_hub_dashboard_redirect_enabled(),
                'canManageSiteSettings'    => function_exists('yooadmin_user_can_manage_site_settings')
                    && yooadmin_user_can_manage_site_settings(),
                'wpDashboardUrl'           => yooadmin_studio_hub_wordpress_dashboard_url(),
                'yooadminDashboardUrl'     => yooadmin_studio_hub_dashboard_home_url(),
                'i18n'    => apply_filters('yooadmin_studio_hub_dashboard_layout_i18n', [
                    'yooadminOverview'            => __('YOOAdmin Overview', 'yooadmin'),
                    'loginSecurity'               => __('Login security', 'yooadmin'),
                    'workspaceNotes'              => function_exists('yooadmin_workspace_notes_section_title')
                        ? yooadmin_workspace_notes_section_title()
                        : __('Workspace Notes', 'yooadmin'),
                    'tips'                        => __('Tips', 'yooadmin'),
                    'updates'                     => __('Updates', 'yooadmin'),
                    'activity'                    => __('Activity', 'yooadmin'),
                    'slotTitle'      => __('Extension slot', 'yooadmin'),
                    'slotHint'       => __('Extension widgets can register here.', 'yooadmin'),
                    'customSection'  => __('Custom section', 'yooadmin'),
                    'sectionTitle'      => __('Section title', 'yooadmin'),
                    'changeSectionIcon' => __('Change section icon', 'yooadmin'),
                    'removeSection'     => __('Remove section', 'yooadmin'),
                    'layoutToolbar'  => __('Layout', 'yooadmin'),
                    'layoutHint'     => __('Drag sections and cards. Empty sections stay visible while editing.', 'yooadmin'),
                    'dropTilesHere'  => __('Drag tiles here from another section (use the move handle on each tile).', 'yooadmin'),
                    'addBelow'       => __('Add section below', 'yooadmin'),
                    'addAside'       => __('Add section on the right', 'yooadmin'),
                    'hideCard'       => __('Hide card', 'yooadmin'),
                    'showCard'       => __('Show card', 'yooadmin'),
                    'hideSection'    => __('Hide section', 'yooadmin'),
                    'showSection'    => __('Show section', 'yooadmin'),
                    'layoutSaved'    => __('Layout saved.', 'yooadmin'),
                    'layoutSaveFailed' => __('Could not save layout. Please try again.', 'yooadmin'),
                    'ok'                        => __('OK', 'yooadmin'),
                    'workspaceMinItemsToast'      => __(
                        'This section requires at least 3 items.',
                        'yooadmin'
                    ),
                    'workspaceAsideBlockedTitle'   => __('Cannot move this section', 'yooadmin'),
                    'workspaceAsideBlockedMessage' => __(
                        'Your workspace must stay in the main column. You can reorder it with other sections on the left, but it cannot be placed in the right sidebar.',
                        'yooadmin'
                    ),
                    'addSectionTitle'             => __('Add to dashboard', 'yooadmin'),
                    'addWorkspaceSection'         => __('Add section or widget', 'yooadmin'),
                    'addSectionCustom'            => __('Custom section', 'yooadmin'),
                    'addSectionCustomHint'        => __('Empty section for your tiles. Drag cards from other sections.', 'yooadmin'),
                    'addSectionCards'             => __('Dashboard card', 'yooadmin'),
                    'addSectionCardsHint'         => __(
                        'Cards registered by plugins for YOOAdmin Studio Hub.',
                        'yooadmin'
                    ),
                    'addSectionWidgets'           => __('WordPress widget', 'yooadmin'),
                    'addSectionWidgetsHint'       => __(
                        'Classic WordPress dashboard widgets are not available in Studio Hub.',
                        'yooadmin'
                    ),
                    'legacyWidgetTitle'           => __('Classic WordPress dashboard widgets are not available in Studio Hub.', 'yooadmin'),
                    'legacyWidgetBody'            => __('YOOAdmin dashboard cards provide a cleaner, more modern workspace experience built for Studio Hub.', 'yooadmin'),
                    'legacyWidgetDocLink'         => __('Developer guide on yooadmin.io', 'yooadmin'),
                    'dashboardRedirectLabel'      => __('Dashboard Redirect', 'yooadmin'),
                    'dashboardRedirectHint'       => __('Turn this off if you want the Home button to open the classic WordPress Dashboard.', 'yooadmin'),
                    'dashboardRedirectSaving'     => __('Saving dashboard redirect…', 'yooadmin'),
                    'dashboardRedirectSaved'      => __('Dashboard redirect updated.', 'yooadmin'),
                    'dashboardRedirectSaveFailed' => __('Could not update dashboard redirect. Please try again.', 'yooadmin'),
                    'developerDocsUrl'            => 'https://www.yooadmin.io/kb-category/for-developers/',
                    'widgetsLoading'              => __('Loading cards…', 'yooadmin'),
                    'widgetsEmpty'                => __(
                        'No dashboard cards are registered yet. Plugins must call yooadmin_register_dashboard_card() on the yooadmin_dashboard_cards_init action.',
                        'yooadmin'
                    ),
                    'widgetsSearch'               => __('Search cards…', 'yooadmin'),
                    'cardBuiltinIncluded'         => __('Included', 'yooadmin'),
                    'cardAlreadyAdded'            => __('Added', 'yooadmin'),
                    'cardInSidebar'               => __('In sidebar', 'yooadmin'),
                    'cardHide'                    => __('Hide', 'yooadmin'),
                    'cardHideFromDashboard'       => __('Hide from dashboard', 'yooadmin'),
                    'cardShow'                    => __('Show', 'yooadmin'),
                    'cardShowOnDashboard'         => __('Show on dashboard', 'yooadmin'),
                    'cardHiddenFromDashboard'     => __('Hidden', 'yooadmin'),
                    'cardRemove'                  => __('Remove', 'yooadmin'),
                    'cardRemoveFromDashboard'     => __('Remove from dashboard', 'yooadmin'),
                    'cardAlreadyOnDashboard'      => __('This card is already on your dashboard.', 'yooadmin'),
                    'cardBuiltinAlreadyInSidebar' => __(
                        'This card is already included in your sidebar. Use layout edit to hide or show it.',
                        'yooadmin'
                    ),
                    'placeWidgetTitle'            => __('Place widget', 'yooadmin'),
                    'placeWidgetHint'             => __('Choose a column. The widget will use the full width of that column.', 'yooadmin'),
                    'placeMain'                   => __('Main column', 'yooadmin'),
                    'placeAside'                  => __('Side column', 'yooadmin'),
                    'widgetLoading'               => __('Loading widget…', 'yooadmin'),
                    'widgetLoadFailed'            => __('Could not load widget.', 'yooadmin'),
                    'widgetNonceFailed'           => __('Session expired. Reload the page and try again.', 'yooadmin'),
                    'widgetNetworkFailed'         => __('Network error while loading the widget.', 'yooadmin'),
                    'cancel'                      => __('Cancel', 'yooadmin'),
                    'close'                       => __('Close', 'yooadmin'),
                ]),
            ],
        ];
    }

    return $data;
}

