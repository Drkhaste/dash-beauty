<?php
/**
 * Studio Hub — register built-in YOOAdmin dashboard cards (Notes, Activity, Tips).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Theme templates path for card partials.
 *
 * Built-in card bodies live under Studio Hub. During admin-ajax the active theme
 * constant may point at another shell; resolve the first readable partial path.
 */
function yooadmin_studio_hub_dashboard_card_partial_path(string $filename): string {
    $relative = 'templates/components/cards/partials/' . ltrim($filename, '/');
    $paths    = [];

    if (defined('YOOADMIN_ACTIVE_ADMIN_THEME_DIR')) {
        $paths[] = trailingslashit((string) YOOADMIN_ACTIVE_ADMIN_THEME_DIR) . $relative;
    }

    if (function_exists('yooadmin_bundled_admin_theme_path')) {
        $paths[] = yooadmin_bundled_admin_theme_path('yooadmin-studio-hub', $relative);
    }

    $paths[] = trailingslashit(dirname(__DIR__)) . $relative;

    foreach ($paths as $path) {
        if (is_readable($path)) {
            return $path;
        }
    }

    return $paths[0] ?? '';
}

/**
 * Load built-in dashboard card registration when theme bootstrap did not run yet.
 */
function yooadmin_studio_hub_ensure_builtin_dashboard_cards_loaded(): void {
    if (function_exists('yooadmin_studio_hub_register_builtin_dashboard_cards')) {
        return;
    }

    $file = function_exists('yooadmin_bundled_admin_theme_path')
        ? yooadmin_bundled_admin_theme_path('yooadmin-studio-hub', 'includes/studio-hub-builtin-dashboard-cards.php')
        : '';

    if ($file !== '' && is_readable($file)) {
        require_once $file;
    }
}

/**
 * Register built-in cards if yooadmin_dashboard_cards_init already fired (e.g. admin-ajax).
 */
function yooadmin_studio_hub_ensure_builtin_dashboard_cards_registered(): void {
    yooadmin_studio_hub_ensure_builtin_dashboard_cards_loaded();

    if (!function_exists('yooadmin_studio_hub_register_builtin_dashboard_cards')) {
        return;
    }

    if (function_exists('yooadmin_is_dashboard_card') && yooadmin_is_dashboard_card('studio-updates')) {
        return;
    }

    yooadmin_studio_hub_register_builtin_dashboard_cards();
}

/**
 * Build template variables for the workspace notes card partial.
 *
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_workspace_notes_partial_vars(string $notes_scope = 'site'): array {
    if (!function_exists('yooadmin_workspace_notes_types')) {
        return [];
    }

    $ws_note_types = yooadmin_workspace_notes_types();
    $ws_active_type = function_exists('yooadmin_workspace_notes_get_active_type')
        ? yooadmin_workspace_notes_get_active_type()
        : 'todos';

    $scope_filter = null;
    if ($notes_scope === 'network') {
        $scope_filter = static function (): string {
            return 'network';
        };
        add_filter('yooadmin_workspace_notes_scope', $scope_filter, 99);
    }

    $ws_page_size = function_exists('yooadmin_workspace_notes_page_size')
        ? yooadmin_workspace_notes_page_size()
        : 3;
    $ws_notes_page = function_exists('yooadmin_workspace_notes_list_page')
        ? yooadmin_workspace_notes_list_page(get_current_user_id(), $ws_active_type, 0, $ws_page_size)
        : ['notes' => [], 'has_more' => false, 'total' => 0];

    if ($scope_filter !== null) {
        remove_filter('yooadmin_workspace_notes_scope', $scope_filter, 99);
    }

    return [
        'ws_note_types'     => $ws_note_types,
        'ws_active_type'    => $ws_active_type,
        'ws_active_def'     => $ws_note_types[ $ws_active_type ] ?? reset($ws_note_types),
        'ws_initial_notes'  => isset($ws_notes_page['notes']) && is_array($ws_notes_page['notes']) ? $ws_notes_page['notes'] : [],
        'ws_notes_has_more' => !empty($ws_notes_page['has_more']),
        'ws_show_check'     => in_array($ws_active_type, ['todos', 'reminders'], true),
        'ws_notes_scope'    => $notes_scope === 'network' ? 'network' : 'site',
    ];
}

/**
 * Include a card body partial and return HTML.
 *
 * @param array<string, mixed> $context Variables extracted into the partial scope.
 */
function yooadmin_studio_hub_render_dashboard_card_partial(string $filename, array $context = []): string {
    $path = yooadmin_studio_hub_dashboard_card_partial_path($filename);
    if (!is_readable($path)) {
        return '';
    }

    if ($context) {
        // phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- Template partial expects local variables.
        extract($context, EXTR_SKIP);
    }

    ob_start();
    include $path;

    return (string) ob_get_clean();
}

/**
 * Workspace Notes context variables for partials.
 *
 * @return bool Whether notes are available.
 */
function yooadmin_studio_hub_prime_workspace_notes_context(): bool {
    if (!apply_filters('yooadmin_workspace_notes_enabled', true)) {
        return false;
    }
    if (!function_exists('yooadmin_workspace_notes_types')) {
        return false;
    }

    return true;
}

/**
 * Read a scalar value from a WordPress update object/array.
 *
 * @param mixed $source Update payload.
 * @param mixed $default Default value.
 * @return mixed
 */
function yooadmin_studio_hub_update_value($source, string $key, $default = '') {
    if (is_array($source) && array_key_exists($key, $source)) {
        return $source[ $key ];
    }
    if (is_object($source) && isset($source->{$key})) {
        return $source->{$key};
    }

    return $default;
}

/**
 * Resolve the slug expected by WordPress' plugin update AJAX endpoint.
 *
 * @param mixed $plugin_update Update payload.
 */
function yooadmin_studio_hub_update_plugin_slug(string $plugin_file, $plugin_update): string {
    $slug = (string) yooadmin_studio_hub_update_value($plugin_update, 'slug', '');
    if ($slug !== '') {
        return sanitize_key($slug);
    }

    $dir = dirname($plugin_file);
    if ($dir !== '' && $dir !== '.') {
        return sanitize_key($dir);
    }

    return sanitize_key(basename($plugin_file, '.php'));
}

/**
 * Human-readable title for a pending translation (language pack) update.
 *
 * @param mixed $update Translation update object from wp_get_translation_updates().
 */
function yooadmin_studio_hub_translation_update_title($update): string {
    $type = (string) yooadmin_studio_hub_update_value($update, 'type', '');
    $lang = (string) yooadmin_studio_hub_update_value($update, 'language', '');
    $slug = (string) yooadmin_studio_hub_update_value($update, 'slug', '');

    $lang_label = $lang;
    if ($lang !== '' && function_exists('format_code_lang')) {
        $formatted = format_code_lang($lang);
        if (is_string($formatted) && $formatted !== '') {
            $lang_label = $formatted;
        }
    }

    if ($type === 'core') {
        return $lang_label !== ''
            ? sprintf(
                /* translators: %s: language name. */
                __('WordPress — %s', 'yooadmin'),
                $lang_label
            )
            : __('WordPress language pack', 'yooadmin');
    }

    if ($type === 'plugin' && $slug !== '') {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $plugin_names   = function_exists('get_plugins') ? get_plugins() : [];
        $sanitized_slug = sanitize_key($slug);
        foreach ($plugin_names as $plugin_file => $data) {
            $plugin_file = (string) $plugin_file;
            $dir         = dirname($plugin_file);
            $matches     = $sanitized_slug === sanitize_key($dir !== '.' ? $dir : basename($plugin_file, '.php'))
                || $sanitized_slug === sanitize_key(basename($plugin_file, '.php'));
            if (!$matches) {
                continue;
            }
            $name = isset($data['Name']) ? (string) $data['Name'] : $slug;
            return $lang_label !== ''
                ? sprintf(
                    /* translators: 1: plugin name, 2: language name. */
                    __('%1$s — %2$s', 'yooadmin'),
                    $name,
                    $lang_label
                )
                : $name;
        }
    }

    if ($type === 'theme' && $slug !== '') {
        $theme = wp_get_theme($slug);
        if ($theme->exists()) {
            $name = (string) $theme->get('Name');
            return $lang_label !== ''
                ? sprintf(
                    /* translators: 1: theme name, 2: language name. */
                    __('%1$s — %2$s', 'yooadmin'),
                    $name,
                    $lang_label
                )
                : $name;
        }
    }

    if ($lang_label !== '') {
        return sprintf(
            /* translators: %s: language name. */
            __('Language pack — %s', 'yooadmin'),
            $lang_label
        );
    }

    return __('Language pack update', 'yooadmin');
}

/**
 * YOOAdmin customer portal URL (register vs dashboard) from license state.
 */
function yooadmin_studio_hub_portal_url(): string {
    if (yooadmin_studio_hub_is_license_active()) {
        return 'https://www.yooadmin.io/portal/';
    }

    return 'https://www.yooadmin.io/portal/register/';
}

/**
 * Whether the YOOAdmin license is active on this site.
 */
function yooadmin_studio_hub_is_license_active(): bool {
    if (!class_exists('YOOAdmin_License_Manager')) {
        return false;
    }

    return YOOAdmin_License_Manager::get_instance()->is_license_active();
}

/**
 * Whether the YOOAdmin Plus package exists on disk (may be inactive).
 */
function yooadmin_studio_hub_is_plus_present(): bool {
    return yooadmin_studio_hub_plugin_installed_version('yooadmin-plus/yooadmin-plus.php') !== '';
}

/**
 * Portal login URL (for downloading Plus when license is active).
 */
function yooadmin_studio_hub_portal_login_url(): string {
    if (class_exists('YOOAdmin_License_Manager')) {
        $context = YOOAdmin_License_Manager::get_instance()->get_license_view_context();
        if (!empty($context['portal_login_url'])) {
            return (string) $context['portal_login_url'];
        }
    }

    $license_page_url = function_exists('yooadmin_license_admin_url')
        ? yooadmin_license_admin_url()
        : admin_url('admin.php?page=yooadmin-license');
    $portal_base      = function_exists('yooadmin_filter_portal_base_url')
        ? yooadmin_filter_portal_base_url('https://www.yooadmin.io/')
        : trailingslashit('https://www.yooadmin.io/');

    return add_query_arg(
        [
            'redirect_to' => rawurlencode($license_page_url),
            'source'      => 'yooadmin',
        ],
        $portal_base . 'portal/login/'
    );
}

/**
 * Panel-connect URL for YOOAdmin Plus inactive CTA.
 */
function yooadmin_studio_hub_license_panel_connect_url(): string {
    if (!class_exists('YOOAdmin_License_Manager')) {
        return '';
    }

    $portal_connect_url = YOOAdmin_License_Manager::get_license_portal_connect_url();
    $origin             = wp_parse_url(admin_url(), PHP_URL_SCHEME) . '://' . wp_parse_url(admin_url(), PHP_URL_HOST);
    $domain             = wp_parse_url(get_site_url(), PHP_URL_HOST);

    return add_query_arg(
        [
            'origin' => $origin,
            'domain' => $domain,
        ],
        $portal_connect_url
    );
}

/**
 * CTA metadata for inactive YOOAdmin Plus (action + URL).
 *
 * @return array{action: string, url: string, plugin: string, slug: string}
 */
function yooadmin_studio_hub_get_plus_inactive_cta(bool $plus_active, bool $plus_present, bool $license_active): array {
    $plus_file = 'yooadmin-plus/yooadmin-plus.php';
    $defaults  = [
        'action' => '',
        'url'    => '',
        'plugin' => $plus_file,
        'slug'   => 'yooadmin-plus',
    ];

    if (!$license_active) {
        return array_merge(
            $defaults,
            [
                'action' => 'license-connect',
                'url'    => yooadmin_studio_hub_license_panel_connect_url(),
            ]
        );
    }

    if ($plus_present && !$plus_active) {
        return array_merge(
            $defaults,
            [
                'action' => 'activate-plugin',
                'url'    => '',
            ]
        );
    }

    return array_merge(
        $defaults,
        [
            'action' => 'portal-login',
            'url'    => yooadmin_studio_hub_portal_login_url(),
        ]
    );
}

/**
 * Whether YOOAdmin Plus is installed and active.
 */
function yooadmin_studio_hub_is_plus_installed(): bool {
    if (defined('YOOADMIN_PLUS_LOADED')) {
        return true;
    }

    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    return is_plugin_active('yooadmin-plus/yooadmin-plus.php');
}

/**
 * Installed plugin version from plugin header.
 */
function yooadmin_studio_hub_plugin_installed_version(string $plugin_file): string {
    if (!function_exists('get_plugins')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $all = get_plugins();

    return isset($all[ $plugin_file ]['Version']) ? (string) $all[ $plugin_file ]['Version'] : '';
}

/**
 * Pending update version from the plugins update transient, if any.
 */
function yooadmin_studio_hub_plugin_pending_version(string $plugin_file): string {
    $updates = get_site_transient('update_plugins');
    if (!is_object($updates) || empty($updates->response[ $plugin_file ]->new_version)) {
        return '';
    }

    return (string) $updates->response[ $plugin_file ]->new_version;
}

/**
 * Latest product version from YOOAdmin API (cached).
 */
function yooadmin_studio_hub_product_remote_version(string $slug): string {
    $slug = sanitize_key($slug);
    if ($slug === '') {
        return '';
    }

    $cache_key = 'yooadmin_sh_prod_' . md5($slug);
    $cached    = get_site_transient($cache_key);
    if (is_array($cached) && isset($cached['until'], $cached['version']) && (int) $cached['until'] > time()) {
        return (string) $cached['version'];
    }

    $remote = '';
    if (function_exists('yooadmin_plus_get_public_product_api_data')) {
        $api = yooadmin_plus_get_public_product_api_data($slug);
        if (is_array($api) && !empty($api['version'])) {
            $remote = (string) $api['version'];
        }
    } elseif (function_exists('yooadmin_extended_get_public_product_api_data')) {
        $api = yooadmin_extended_get_public_product_api_data($slug);
        if (is_array($api) && !empty($api['version'])) {
            $remote = (string) $api['version'];
        }
    } elseif (function_exists('yooadmin_can_use_external_api') && yooadmin_can_use_external_api()) {
        $base = apply_filters('yooadmin_yoopixel_api_url', 'https://www.yooadmin.io/wp-json/yoopixel-api/v1/');
        $base = rtrim((string) $base, '/');
        $url  = $base . '/products/' . rawurlencode($slug) . '/info';
        $response = wp_remote_get(
            $url,
            [
                'timeout'   => 12,
                'sslverify' => true,
                'headers'   => ['Accept' => 'application/json'],
            ]
        );
        if (!is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) === 200) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (is_array($body) && !empty($body['ok']) && !empty($body['product']['version'])) {
                $remote = (string) $body['product']['version'];
            }
        }
    }

    $ttl = $remote !== '' ? 5 * MINUTE_IN_SECONDS : MINUTE_IN_SECONDS;
    set_site_transient(
        $cache_key,
        [
            'until'   => time() + $ttl,
            'version' => $remote,
        ],
        $ttl + MINUTE_IN_SECONDS
    );

    return $remote;
}

/**
 * Soft product status rows for the Updates widget (YOOAdmin + Plus).
 *
 * @return array{rows: array<int, array<string, mixed>>, portalUrl: string}
 */
function yooadmin_studio_hub_get_updates_product_notice(): array {
    $portal_url  = yooadmin_studio_hub_portal_url();
    $plugins_url = admin_url('plugins.php');
    $rows        = [];

    $lite_file = defined('YOOADMIN_PANEL_BASENAME') ? YOOADMIN_PANEL_BASENAME : 'yooadmin/yooadmin.php';
    $lite_slug = (string) apply_filters('yooadmin_studio_hub_lite_product_slug', 'yooadmin');
    $lite_ver  = yooadmin_studio_hub_plugin_installed_version($lite_file);

    if ($lite_ver !== '') {
        $lite_pending = yooadmin_studio_hub_plugin_pending_version($lite_file);
        $lite_remote  = yooadmin_studio_hub_product_remote_version($lite_slug);
        $lite_new     = $lite_pending !== ''
            ? $lite_pending
            : ($lite_remote !== '' && version_compare($lite_remote, $lite_ver, '>') ? $lite_remote : '');

        $rows[] = [
            'id'      => 'yooadmin',
            'product' => 'YOOAdmin',
            'icon'    => 'dashicons-admin-generic',
            'version' => $lite_ver,
            'state'   => $lite_new !== '' ? 'update' : 'latest',
            'detail'  => $lite_new !== ''
                ? sprintf(
                    /* translators: %s: available version. */
                    __('Update available (%s)', 'yooadmin'),
                    $lite_new
                )
                : __('Latest version', 'yooadmin'),
            'ctaUrl'  => $lite_new !== '' ? $plugins_url : '',
        ];
    }

    $plus_active   = yooadmin_studio_hub_is_plus_installed();
    $plus_present  = yooadmin_studio_hub_is_plus_present();
    $license_active = yooadmin_studio_hub_is_license_active();
    $plus_file     = 'yooadmin-plus/yooadmin-plus.php';
    $plus_ver      = '';

    if ($plus_present) {
        $plus_ver = defined('YOOADMIN_PLUS_VERSION')
            ? (string) YOOADMIN_PLUS_VERSION
            : yooadmin_studio_hub_plugin_installed_version($plus_file);
    }

    if (!$plus_active || !$license_active) {
        if (!$license_active) {
            $plus_detail = __('YOOAdmin Plus license is not active.', 'yooadmin');
        } elseif ($plus_present && !$plus_active) {
            $plus_detail = __('YOOAdmin Plus is installed but not activated.', 'yooadmin');
        } else {
            $plus_detail = __('YOOAdmin Plus is not installed on this site.', 'yooadmin');
        }

        $plus_cta = yooadmin_studio_hub_get_plus_inactive_cta($plus_active, $plus_present, $license_active);

        $rows[] = [
            'id'        => 'yooadmin-plus',
            'product'   => 'YOOAdmin Plus',
            'icon'      => 'dashicons-star-filled',
            'version'   => $plus_ver,
            'state'     => 'inactive',
            'detail'    => $plus_detail,
            'ctaLabel'  => __('Activate', 'yooadmin'),
            'ctaAction' => $plus_cta['action'],
            'ctaUrl'    => $plus_cta['url'],
            'ctaPlugin' => $plus_cta['plugin'],
            'ctaSlug'   => $plus_cta['slug'],
            'ctaName'   => 'YOOAdmin Plus',
        ];
    } else {
        $plus_slug    = function_exists('yooadmin_plus_product_update_slug')
            ? yooadmin_plus_product_update_slug()
            : 'yooadmin-plus';
        $plus_pending = yooadmin_studio_hub_plugin_pending_version($plus_file);
        $plus_remote  = yooadmin_studio_hub_product_remote_version($plus_slug);
        $plus_new     = $plus_pending !== ''
            ? $plus_pending
            : ($plus_remote !== '' && version_compare($plus_remote, $plus_ver, '>') ? $plus_remote : '');

        $rows[] = [
            'id'       => 'yooadmin-plus',
            'product'  => 'YOOAdmin Plus',
            'icon'     => 'dashicons-star-filled',
            'version'  => $plus_ver,
            'state'    => $plus_new !== '' ? 'update' : 'latest',
            'detail'   => $plus_new !== ''
                ? sprintf(
                    /* translators: %s: available version. */
                    __('Update available (%s)', 'yooadmin'),
                    $plus_new
                )
                : __('Latest version', 'yooadmin'),
            'ctaUrl'   => $plus_new !== '' ? $plugins_url : '',
            'ctaLabel' => $plus_new !== '' ? __('Update', 'yooadmin') : '',
        ];
    }

    return [
        'rows'      => $rows,
        'portalUrl' => $portal_url,
    ];
}

/**
 * Build compact update data for the Studio Hub Updates card.
 *
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_get_updates_card_data(): array {
    $updates_url = self_admin_url('update-core.php');
    $groups      = [
        'core'    => [
            'id'    => 'core',
            'label' => __('Core', 'yooadmin'),
            'icon'  => 'dashicons-wordpress',
            'count' => 0,
            'items' => [],
            'url'   => $updates_url,
        ],
        'plugins' => [
            'id'    => 'plugins',
            'label' => __('Plugins', 'yooadmin'),
            'icon'  => 'dashicons-admin-plugins',
            'count' => 0,
            'items' => [],
            'url'   => $updates_url,
        ],
        'themes'  => [
            'id'    => 'themes',
            'label' => __('Themes', 'yooadmin'),
            'icon'  => 'dashicons-admin-appearance',
            'count' => 0,
            'items' => [],
            'url'   => $updates_url,
        ],
        'translations' => [
            'id'    => 'translations',
            'label' => __('Languages', 'yooadmin'),
            'icon'  => 'dashicons-translation',
            'count' => 0,
            'items' => [],
            'url'   => $updates_url,
        ],
    ];

    if (current_user_can('update_core')) {
        $core_transient = get_site_transient('update_core');
        $core_updates   = (is_object($core_transient) && !empty($core_transient->updates) && is_array($core_transient->updates))
            ? $core_transient->updates
            : [];

        foreach ($core_updates as $core_update) {
            if (yooadmin_studio_hub_update_value($core_update, 'response') !== 'upgrade') {
                continue;
            }

            $version = (string) yooadmin_studio_hub_update_value($core_update, 'current', '');
            $groups['core']['items'][] = [
                'key'             => 'core:wordpress',
                'type'            => 'core',
                'version'         => $version,
                'actionType'      => 'core',
                'actionUrl'       => $updates_url,
                'actionLabel'     => __('Open updater', 'yooadmin'),
                'actionAriaLabel' => __('Open the WordPress core updater', 'yooadmin'),
                'canUpdate'       => current_user_can('update_core'),
                'title'           => __('WordPress core', 'yooadmin'),
                'meta'            => $version !== ''
                    ? sprintf(
                        /* translators: %s: WordPress version. */
                        __('Version %s is available', 'yooadmin'),
                        $version
                    )
                    : __('Update available', 'yooadmin'),
                'url'             => $updates_url,
            ];
            break;
        }

        $groups['core']['count'] = count($groups['core']['items']);
    }

    if (current_user_can('update_plugins')) {
        $plugin_transient = get_site_transient('update_plugins');
        $plugin_updates   = (is_object($plugin_transient) && !empty($plugin_transient->response) && is_array($plugin_transient->response))
            ? $plugin_transient->response
            : [];

        $plugin_names = [];
        if ($plugin_updates) {
            if (!function_exists('get_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $plugin_names = function_exists('get_plugins') ? get_plugins() : [];
        }

        foreach ($plugin_updates as $plugin_file => $plugin_update) {
            $plugin_file = (string) $plugin_file;
            $slug        = yooadmin_studio_hub_update_plugin_slug($plugin_file, $plugin_update);
            $name        = isset($plugin_names[ $plugin_file ]['Name'])
                ? (string) $plugin_names[ $plugin_file ]['Name']
                : ($slug !== '' ? $slug : (string) yooadmin_studio_hub_update_value($plugin_update, 'slug', $plugin_file));
            $version     = (string) yooadmin_studio_hub_update_value($plugin_update, 'new_version', '');

            $groups['plugins']['items'][] = [
                'key'             => 'plugin:' . $plugin_file,
                'type'            => 'plugin',
                'actionType'      => 'update-plugin',
                'plugin'          => $plugin_file,
                'slug'            => $slug,
                'version'         => $version,
                'actionLabel'     => __('Update', 'yooadmin'),
                'actionAriaLabel' => sprintf(
                    /* translators: %s: plugin name. */
                    __('Update %s', 'yooadmin'),
                    $name !== '' ? $name : __('plugin', 'yooadmin')
                ),
                'canUpdate'       => current_user_can('update_plugins') && $slug !== '',
                'title'           => $name !== '' ? $name : __('Plugin update', 'yooadmin'),
                'meta'            => $version !== ''
                    ? sprintf(
                        /* translators: %s: plugin version. */
                        __('Update to %s', 'yooadmin'),
                        $version
                    )
                    : __('Update available', 'yooadmin'),
                'url'             => $updates_url,
            ];
        }

        $groups['plugins']['count'] = count($groups['plugins']['items']);
    }

    if (current_user_can('update_themes')) {
        $theme_transient = get_site_transient('update_themes');
        $theme_updates   = (is_object($theme_transient) && !empty($theme_transient->response) && is_array($theme_transient->response))
            ? $theme_transient->response
            : [];
        $theme_names     = $theme_updates ? wp_get_themes() : [];

        foreach ($theme_updates as $theme_slug => $theme_update) {
            $theme_slug = (string) $theme_slug;
            $theme      = isset($theme_names[ $theme_slug ]) ? $theme_names[ $theme_slug ] : null;
            $name       = $theme instanceof WP_Theme ? (string) $theme->get('Name') : $theme_slug;
            $version    = (string) yooadmin_studio_hub_update_value($theme_update, 'new_version', '');

            $groups['themes']['items'][] = [
                'key'             => 'theme:' . $theme_slug,
                'type'            => 'theme',
                'actionType'      => 'update-theme',
                'stylesheet'      => $theme_slug,
                'slug'            => $theme_slug,
                'version'         => $version,
                'actionLabel'     => __('Update', 'yooadmin'),
                'actionAriaLabel' => sprintf(
                    /* translators: %s: theme name. */
                    __('Update %s', 'yooadmin'),
                    $name !== '' ? $name : __('theme', 'yooadmin')
                ),
                'canUpdate'       => current_user_can('update_themes'),
                'title'           => $name !== '' ? $name : __('Theme update', 'yooadmin'),
                'meta'            => $version !== ''
                    ? sprintf(
                        /* translators: %s: theme version. */
                        __('Update to %s', 'yooadmin'),
                        $version
                    )
                    : __('Update available', 'yooadmin'),
                'url'             => $updates_url,
            ];
        }

        $groups['themes']['count'] = count($groups['themes']['items']);
    }

    if (current_user_can('update_languages')) {
        if (!function_exists('yooadmin_uc_get_translation_updates_with_type')) {
            $render_path = defined('YOOADMIN_DIR')
                ? YOOADMIN_DIR . 'includes/admin/update-center-render.php'
                : '';
            if ($render_path !== '' && is_readable($render_path)) {
                require_once $render_path;
            }
        }

        $translation_updates = function_exists('yooadmin_uc_get_translation_updates_with_type')
            ? yooadmin_uc_get_translation_updates_with_type()
            : wp_get_translation_updates();
        $translation_url     = self_admin_url('update-core.php');

        if (is_array($translation_updates)) {
            usort(
                $translation_updates,
                static function ($a, $b): int {
                    $ta = (string) yooadmin_studio_hub_update_value($a, 'type', '');
                    $tb = (string) yooadmin_studio_hub_update_value($b, 'type', '');
                    $c  = strcmp($ta, $tb);
                    if ($c !== 0) {
                        return $c;
                    }
                    $la = (string) yooadmin_studio_hub_update_value($a, 'language', '');
                    $lb = (string) yooadmin_studio_hub_update_value($b, 'language', '');
                    return strcmp($la, $lb);
                }
            );

            foreach ($translation_updates as $translation_update) {
                $type     = (string) yooadmin_studio_hub_update_value($translation_update, 'type', '');
                $language = (string) yooadmin_studio_hub_update_value($translation_update, 'language', '');
                $slug     = (string) yooadmin_studio_hub_update_value($translation_update, 'slug', '');
                $version  = (string) yooadmin_studio_hub_update_value($translation_update, 'version', '');
                $title    = yooadmin_studio_hub_translation_update_title($translation_update);

                $groups['translations']['items'][] = [
                    'key'             => 'translation:' . $type . ':' . $slug . ':' . $language,
                    'type'            => 'translation',
                    'actionType'      => 'update-translation',
                    'translationType' => $type,
                    'slug'            => $slug,
                    'language'        => $language,
                    'version'         => $version,
                    'actionLabel'     => __('Update', 'yooadmin'),
                    'actionAriaLabel' => sprintf(
                        /* translators: %s: language pack label. */
                        __('Update language pack for %s', 'yooadmin'),
                        $title
                    ),
                    'canUpdate'       => current_user_can('update_languages'),
                    'title'           => $title,
                    'meta'            => $version !== ''
                        ? sprintf(
                            /* translators: %s: language pack version. */
                            __('Version %s', 'yooadmin'),
                            $version
                        )
                        : __('Language update available', 'yooadmin'),
                    'url'             => $translation_url,
                ];
            }
        }

        $groups['translations']['count'] = count($groups['translations']['items']);
    } else {
        unset($groups['translations']);
    }

    $items = [];
    foreach ($groups as $group_id => $group) {
        foreach ($group['items'] as $item) {
            $item['group']      = $group_id;
            $item['groupLabel'] = $group['label'];
            $item['icon']       = $group['icon'];
            $items[]            = $item;
        }
    }

    $visible_items = array_slice($items, 0, 4);

    return [
        'groups'        => $groups,
        'items'         => $items,
        'total'         => count($items),
        'visibleItems'  => $visible_items,
        'hiddenCount'   => max(0, count($items) - 4),
        'updatesUrl'    => $updates_url,
        'nonce'         => wp_create_nonce('updates'),
        'productNotice' => yooadmin_studio_hub_get_updates_product_notice(),
    ];
}

/**
 * Localized settings for the Studio Hub Updates widget script.
 *
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_updates_product_notice_needs_license_script(): bool {
    $notice = yooadmin_studio_hub_get_updates_product_notice();

    foreach ($notice['rows'] as $row) {
        if (!is_array($row)) {
            continue;
        }
        if (($row['ctaAction'] ?? '') === 'license-connect') {
            return true;
        }
    }

    return false;
}

/**
 * Enqueue license connect assets for dashboard Plus CTA.
 */
function yooadmin_studio_hub_enqueue_license_connect_script(): void {
    if (!class_exists('YOOAdmin_License_Manager') || !current_user_can('activate_plugins')) {
        return;
    }

    if (wp_script_is('yooadmin-license', 'enqueued')) {
        return;
    }

    $portal_connect_url = YOOAdmin_License_Manager::get_license_portal_connect_url();
    $portal_origin      = '';

    if ($portal_connect_url && strpos($portal_connect_url, 'http') === 0) {
        $parsed = wp_parse_url($portal_connect_url);
        if (!empty($parsed['scheme']) && !empty($parsed['host'])) {
            $portal_origin = $parsed['scheme'] . '://' . $parsed['host'];
            if (!empty($parsed['port'])) {
                $portal_origin .= ':' . $parsed['port'];
            }
        }
    }

    $license_admin_url = function_exists('yooadmin_license_admin_url')
        ? yooadmin_license_admin_url()
        : admin_url('admin.php?page=yooadmin-license');

    wp_enqueue_style(
        'yooadmin-license',
        YOOADMIN_URL . 'assets/css/admin/license.css',
        [],
        defined('YOOADMIN_VERSION') ? YOOADMIN_VERSION : '1.0.0'
    );
    wp_enqueue_script(
        'yooadmin-license',
        YOOADMIN_URL . 'assets/js/admin/license.js',
        [ 'jquery' ],
        defined('YOOADMIN_VERSION') ? YOOADMIN_VERSION : '1.0.0',
        true
    );
    wp_localize_script(
        'yooadmin-license',
        'yooadmLicense',
        [
            'nonce'            => wp_create_nonce('yooadmin_license_nonce'),
            'ajaxUrl'          => admin_url('admin-ajax.php'),
            'portalMessages'   => [
                'close' => __('Close', 'yooadmin'),
            ],
            'portalConnectUrl' => $portal_connect_url,
            'portalOrigin'     => $portal_origin,
            'licensePageUrl'   => $license_admin_url,
        ]
    );
}

function yooadmin_studio_hub_boot_update_center_ajax(): void {
    static $booted = false;

    if ($booted) {
        return;
    }

    if (class_exists('YOOAdmin_Update_Center_Ajax', false)) {
        YOOAdmin_Update_Center_Ajax::get_instance();
        $booted = true;
        return;
    }

    $paths = [];

    if (defined('YOOADMIN_PANEL_DIR')) {
        $paths[] = YOOADMIN_PANEL_DIR . 'includes/admin/update-center-ajax.php';
    }

    if (defined('YOOADMIN_FILE')) {
        $paths[] = dirname(YOOADMIN_FILE) . '/includes/admin/update-center-ajax.php';
    }

    foreach ($paths as $path) {
        if (!is_readable($path)) {
            continue;
        }

        require_once $path;
        break;
    }

    if (class_exists('YOOAdmin_Update_Center_Ajax', false)) {
        YOOAdmin_Update_Center_Ajax::get_instance();
        $booted = true;
    }
}

/**
 * Ensure Update Center AJAX handlers are available for dashboard widget updates.
 */
function yooadmin_studio_hub_maybe_boot_update_center_ajax(): void {
    if (!wp_doing_ajax()) {
        return;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : '';
    $widget_update_actions = [
        'yooadmin_uc_update_translation',
        'yooadmin_uc_update_translations',
        'yooadmin_uc_update_plugin',
        'yooadmin_uc_update_theme',
    ];

    if (in_array($action, $widget_update_actions, true)) {
        yooadmin_studio_hub_boot_update_center_ajax();
    }
}

add_action('init', 'yooadmin_studio_hub_maybe_boot_update_center_ajax', 5);

function yooadmin_studio_hub_updates_widget_script_data(): array {
    return [
        'ajaxUrl'     => function_exists('yooadmin_admin_ajax_url') ? yooadmin_admin_ajax_url() : admin_url('admin-ajax.php'),
        'updatesUrl'  => self_admin_url('update-core.php'),
        'nonce'       => wp_create_nonce('updates'),
        'ucNonce'     => wp_create_nonce('yooadmin_update_center'),
        'layoutNonce' => wp_create_nonce('yooadmin_studio_hub_layout'),
        'widgetId'    => 'studio-updates',
        'restUrl'     => rest_url('yooadmin/v1'),
        'restNonce'   => wp_create_nonce('wp_rest'),
        'i18n'        => [
            'updateNow'          => __('Update', 'yooadmin'),
            'updating'           => __('Updating...', 'yooadmin'),
            'updated'            => __('Updated', 'yooadmin'),
            'updateFailed'       => __('Update failed.', 'yooadmin'),
            'updateHandlerMissing' => __('Update handler is unavailable. Refresh the page and try again.', 'yooadmin'),
            'filesystemRequired' => __('WordPress needs filesystem credentials. Open the updater to continue.', 'yooadmin'),
            'errorGeneric'       => __('Could not update this item. Please try again.', 'yooadmin'),
            'thirdPartyDownloadFailed' => __('The update package could not be downloaded from the vendor server (service unavailable). Open Updates in WordPress or update from the plugin or theme author site.', 'yooadmin'),
            'noUpdates'          => __('Everything is up to date', 'yooadmin'),
            'noUpdatesText'      => __('No core, plugin, theme, or language updates are waiting right now.', 'yooadmin'),
            'summaryOne'         => __('1 update needs attention', 'yooadmin'),
            /* translators: %s: number of available updates. */
            'summaryMany'        => __('%s updates need attention', 'yooadmin'),
            'summaryGroupedBelow' => __('Core, plugins, themes, and language packs are grouped below.', 'yooadmin'),
            /* translators: %s: number of available updates. */
            'summarySingular'    => _n('%s update needs attention', '%s updates need attention', 1, 'yooadmin'),
            /* translators: %s: number of available updates. */
            'summaryPlural'      => _n('%s update needs attention', '%s updates need attention', 2, 'yooadmin'),
            /* translators: 1: item name, 2: updated version number. */
            'updatedWithVersion' => __('%1$s updated to %2$s.', 'yooadmin'),
            /* translators: %s: item name. */
            'updatedWithoutVersion' => __('%s updated.', 'yooadmin'),
            'updatesHidden'      => __('Updates are clear. The Updates widget is hidden until a new update appears.', 'yooadmin'),
            'loadingUpdates'     => __('Loading updates...', 'yooadmin'),
            /* translators: %s: number of additional available updates. */
            'viewAllSingular'    => __('View all updates (+%s more)', 'yooadmin'),
            /* translators: %s: number of additional available updates. */
            'viewAllPlural'      => __('View all updates (+%s more)', 'yooadmin'),
            'updateAll'          => __('Update all', 'yooadmin'),
            'updatingAll'        => __('Updating all...', 'yooadmin'),
            'allUpdatesCompleted' => __('All available updates completed.', 'yooadmin'),
            'allDirectUpdatesCompleted' => __('Plugin, theme, and language updates completed. Open the updater for remaining core updates.', 'yooadmin'),
            /* translators: %s: number of updates that failed. */
            'updateAllFailedSingular' => __('%s update could not be completed.', 'yooadmin'),
            /* translators: %s: number of updates that failed. */
            'updateAllFailedPlural' => __('%s updates could not be completed.', 'yooadmin'),
            'activate'             => __('Activate', 'yooadmin'),
            'activating'           => __('Activating...', 'yooadmin'),
            'latestVersion'        => __('Latest version', 'yooadmin'),
            'plusActivated'        => __('YOOAdmin Plus activated.', 'yooadmin'),
            'activateFailed'       => __('Could not activate YOOAdmin Plus. Please try again.', 'yooadmin'),
        ],
    ];
}

/**
 * Enqueue the Studio Hub Updates widget behavior.
 */
function yooadmin_studio_hub_enqueue_updates_widget_script(): void {
    $handle = 'yooadmin-studio-hub-updates-widget';
    $file   = function_exists('yooadmin_studio_hub_asset_path')
        ? yooadmin_studio_hub_asset_path('js/dashboard/studio-updates-widget.js')
        : '';

    if ($file === '' || !is_readable($file)) {
        return;
    }

    if (!wp_script_is($handle, 'registered')) {
        wp_register_script(
            $handle,
            yooadmin_studio_hub_asset_url('js/dashboard/studio-updates-widget.js'),
            [ 'jquery', 'updates' ],
            (string) filemtime($file),
            true
        );
    }

    wp_enqueue_script($handle);
    wp_localize_script($handle, 'yooadminStudioHubUpdates', yooadmin_studio_hub_updates_widget_script_data());

    if (yooadmin_studio_hub_updates_product_notice_needs_license_script()) {
        yooadmin_studio_hub_enqueue_license_connect_script();
    }
}

/**
 * Allow built-in card assets during widget AJAX render (admin-ajax.php).
 */
function yooadmin_studio_hub_force_builtin_card_asset_enqueue(): bool {
    if (!wp_doing_ajax()) {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only action name for enqueue routing.
    $action = isset($_POST['action']) ? sanitize_key(wp_unslash($_POST['action'])) : '';

    return $action === 'yooadmin_studio_hub_render_dashboard_widget';
}

/**
 * Enqueue theme assets for a built-in dashboard card.
 */
function yooadmin_studio_hub_enqueue_builtin_dashboard_card_assets(string $card_id, bool $force = false): void {
    if (
        !$force
        && (
            !function_exists('yooadmin_studio_hub_is_dashboard_screen')
            || !yooadmin_studio_hub_is_dashboard_screen()
        )
    ) {
        return;
    }

    $theme_url = defined('YOOADMIN_ACTIVE_ADMIN_THEME_URL')
        ? trailingslashit((string) YOOADMIN_ACTIVE_ADMIN_THEME_URL)
        : '';

    if ($theme_url === '') {
        return;
    }

    switch ($card_id) {
        case 'studio-workspace-notes':
        case 'studio-network-workspace-notes':
            $ws_handle = 'yooadmin-studio-hub-workspace-notes';
            $ws_file   = function_exists('yooadmin_studio_hub_asset_path')
                ? yooadmin_studio_hub_asset_path('js/dashboard/workspace-notes.js')
                : '';

            if ($ws_file === '' || !is_readable($ws_file)) {
                break;
            }

            if (!wp_script_is($ws_handle, 'registered')) {
                wp_register_script(
                    $ws_handle,
                    yooadmin_studio_hub_asset_url('js/dashboard/workspace-notes.js'),
                    [ 'jquery' ],
                    (string) filemtime($ws_file),
                    true
                );
            }

            wp_enqueue_script($ws_handle);

            $ws_data = function_exists('yooadmin_studio_hub_workspace_notes_script_data')
                ? yooadmin_studio_hub_workspace_notes_script_data()
                : [];

            if ($ws_data) {
                wp_localize_script($ws_handle, 'yooadminWorkspaceNotes', $ws_data);
            }
            break;

        case 'studio-tips':
        case 'studio-network-tips':
            if (!wp_script_is('yooadmin-studio-hub-tips-carousel', 'enqueued')) {
                wp_enqueue_script(
                    'yooadmin-studio-hub-tips-carousel',
                    yooadmin_studio_hub_asset_url('js/dashboard/studio-tips-carousel.js'),
                    [],
                    '1.0.0',
                    true
                );
            }
            break;

        case 'studio-updates':
            yooadmin_studio_hub_enqueue_updates_widget_script();
            break;

        case 'studio-login-security':
            $sec_css = yooadmin_studio_hub_asset_path('css/dashboard/login-security-widget.css');
            if ($sec_css !== '' && is_readable($sec_css)) {
                wp_enqueue_style(
                    'yooadmin-studio-hub-login-security-widget',
                    yooadmin_studio_hub_asset_url('css/dashboard/login-security-widget.css'),
                    [],
                    (string) filemtime($sec_css)
                );
            }

            $sec_js = yooadmin_studio_hub_asset_path('js/dashboard/studio-login-security-widget.js');
            if ($sec_js !== '' && is_readable($sec_js)) {
                wp_enqueue_script(
                    'yooadmin-studio-hub-login-security-widget',
                    yooadmin_studio_hub_asset_url('js/dashboard/studio-login-security-widget.js'),
                    [],
                    (string) filemtime($sec_js),
                    true
                );
            }
            break;
    }
}

/**
 * Register Workspace Notes, Updates, Activity, and Tips as dashboard cards.
 */
function yooadmin_studio_hub_register_builtin_dashboard_cards(): void {
    if (!function_exists('yooadmin_register_dashboard_card')) {
        return;
    }

    $category = __('YOOAdmin', 'yooadmin');

    if (yooadmin_studio_hub_prime_workspace_notes_context()) {
        yooadmin_register_dashboard_card(
            'studio-workspace-notes',
            [
                'title'       => __('Workspace Notes', 'yooadmin'),
                'description' => __('Todos, reminders, and quick notes in your sidebar.', 'yooadmin'),
                'icon'        => 'dashicons-book-alt',
                'capability'  => 'read',
                'priority'    => 1,
                'placements'  => [ 'aside' ],
                'scopes'      => [ 'site' ],
                'builtin'     => true,
                'category'    => $category,
                'render'      => static function (): void {
                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Partial escapes output.
                    echo yooadmin_studio_hub_render_dashboard_card_partial(
                        'dashboard-card-workspace-notes-body.php',
                        yooadmin_studio_hub_workspace_notes_partial_vars('site')
                    );
                },
                'enqueue'     => static function (string $card_id): void {
                    yooadmin_studio_hub_enqueue_builtin_dashboard_card_assets($card_id);
                },
            ]
        );

        yooadmin_register_dashboard_card(
            'studio-network-workspace-notes',
            [
                'title'       => __('Network Notes', 'yooadmin'),
                'description' => __('Network-only todos, reminders, and notes — separate from site notes.', 'yooadmin'),
                'icon'        => 'dashicons-book-alt',
                'capability'  => 'read',
                'priority'    => 1,
                'placements'  => [ 'aside' ],
                'scopes'      => [ 'network' ],
                'builtin'     => true,
                'category'    => $category,
                'render'      => static function (): void {
                    add_filter(
                        'yooadmin_workspace_notes_scope',
                        static function (): string {
                            return 'network';
                        },
                        99
                    );

                    $partial_vars = yooadmin_studio_hub_workspace_notes_partial_vars('network');

                    remove_all_filters('yooadmin_workspace_notes_scope', 99);

                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Partial escapes output.
                    echo yooadmin_studio_hub_render_dashboard_card_partial(
                        'dashboard-card-workspace-notes-body.php',
                        $partial_vars
                    );
                },
                'enqueue'     => static function (string $card_id): void {
                    yooadmin_studio_hub_enqueue_builtin_dashboard_card_assets($card_id);
                },
            ]
        );
    }

    yooadmin_register_dashboard_card(
        'studio-activity',
        [
            'title'       => __('Activity', 'yooadmin'),
            'description' => __('Recent site activity at a glance.', 'yooadmin'),
            'icon'        => 'dashicons-megaphone',
            'capability'  => 'read',
            'priority'    => 2,
            'placements'  => [ 'aside' ],
            'scopes'      => [ 'site' ],
            'builtin'     => true,
            'category'    => $category,
            'render'      => static function (): void {
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                echo yooadmin_studio_hub_render_dashboard_card_partial('dashboard-card-activity-body.php');
            },
        ]
    );

    yooadmin_register_dashboard_card(
        'studio-updates',
        [
            'title'       => __('Updates', 'yooadmin'),
            'description' => __('A compact view of core, plugin, and theme updates.', 'yooadmin'),
            'icon'        => 'dashicons-update',
            'capability'  => 'update_core',
            'priority'    => 2,
            'placements'  => [ 'aside' ],
            'scopes'      => [ 'site' ],
            'builtin'     => true,
            'category'    => $category,
            'render'      => static function (): void {
                $studio_hub_updates = yooadmin_studio_hub_get_updates_card_data();
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Partial escapes output.
                echo yooadmin_studio_hub_render_dashboard_card_partial(
                    'dashboard-card-updates-body.php',
                    [ 'studio_hub_updates' => $studio_hub_updates ]
                );
            },
            'enqueue'     => static function (string $card_id): void {
                yooadmin_studio_hub_enqueue_builtin_dashboard_card_assets($card_id);
            },
        ]
    );

    if (function_exists('yooadmin_has_feature') && yooadmin_has_feature('login_customizer')) {
        yooadmin_register_dashboard_card(
            'studio-login-security',
            [
                'title'       => __('Login security', 'yooadmin'),
                'description' => __('Protection score from Turnstile, rate limits, and username shields.', 'yooadmin'),
                'icon'        => 'dashicons-shield',
                'capability'  => 'manage_options',
                'priority'    => 4,
                'placements'  => [ 'main', 'aside' ],
                'scopes'      => [ 'site' ],
                'builtin'     => true,
                'category'    => $category,
                'render'      => static function (): void {
                    $studio_hub_login_security = function_exists('yooadmin_login_security_dashboard_score_get')
                        ? yooadmin_login_security_dashboard_score_get()
                        : [];
                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Partial escapes output.
                    echo yooadmin_studio_hub_render_dashboard_card_partial(
                        'dashboard-card-login-security-body.php',
                        ['studio_hub_login_security' => $studio_hub_login_security]
                    );
                },
                'enqueue'     => static function (string $card_id): void {
                    $force = function_exists('yooadmin_studio_hub_force_builtin_card_asset_enqueue')
                        && yooadmin_studio_hub_force_builtin_card_asset_enqueue();
                    yooadmin_studio_hub_enqueue_builtin_dashboard_card_assets($card_id, $force);
                },
            ]
        );
    }

    yooadmin_register_dashboard_card(
        'studio-tips',
        [
            'title'       => __('Tips', 'yooadmin'),
            'description' => __('Helpful tips and product highlights.', 'yooadmin'),
            'icon'        => 'dashicons-lightbulb',
            'capability'  => 'read',
            'priority'    => 3,
            'placements'  => [ 'aside' ],
            'scopes'      => [ 'site' ],
            'builtin'     => true,
            'category'    => $category,
            'render'      => static function (): void {
                $studio_hub_tips = function_exists('yooadmin_studio_hub_get_tips')
                    ? yooadmin_studio_hub_get_tips()
                    : [];
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                echo yooadmin_studio_hub_render_dashboard_card_partial('dashboard-card-tips-body.php');
            },
            'enqueue'     => static function (string $card_id): void {
                yooadmin_studio_hub_enqueue_builtin_dashboard_card_assets($card_id);
            },
        ]
    );

    yooadmin_register_dashboard_card(
        'studio-network-tips',
        [
            'title'       => __('Network Tips', 'yooadmin'),
            'description' => __('Multisite tips for your network dashboard.', 'yooadmin'),
            'icon'        => 'dashicons-lightbulb',
            'capability'  => 'read',
            'priority'    => 3,
            'placements'  => [ 'aside' ],
            'scopes'      => [ 'network' ],
            'builtin'     => true,
            'category'    => $category,
            'render'      => static function (): void {
                $studio_hub_tips = function_exists('yooadmin_studio_hub_get_network_tips')
                    ? yooadmin_studio_hub_get_network_tips()
                    : [];
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                echo yooadmin_studio_hub_render_dashboard_card_partial('dashboard-card-tips-body.php');
            },
            'enqueue'     => static function (string $card_id): void {
                yooadmin_studio_hub_enqueue_builtin_dashboard_card_assets($card_id);
            },
        ]
    );
}

add_action('yooadmin_dashboard_cards_init', 'yooadmin_studio_hub_register_builtin_dashboard_cards', 5);
