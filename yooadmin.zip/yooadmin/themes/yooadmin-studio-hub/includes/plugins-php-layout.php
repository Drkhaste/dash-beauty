<?php
/**
 * Studio Hub — native plugins.php layout (YOOAdmin list view like yooadmin-pages).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * @return bool
 */
function yooadmin_studio_hub_should_style_plugins_php_layout(): bool {
    return yooadmin_studio_hub_should_style_plugins_php_experience();
}

/**
 * @param string $classes
 * @return string
 */
function yooadmin_studio_hub_filter_plugins_php_body_class(string $classes): string {
    if (!yooadmin_studio_hub_should_style_plugins_php_layout()) {
        return $classes;
    }

    return trim($classes . ' yooadmin-plugins-page yoo-list-screen');
}

/**
 * Critical CSS + first-paint guard — hide native plugins.php until JS reshapes the layout.
 */
function yooadmin_studio_hub_print_plugins_php_layout_critical(): void {
    if (!yooadmin_studio_hub_should_style_plugins_php_layout()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-plugins-php-layout-pending">'
        . 'document.documentElement.classList.add("yoo-plugins-layout-pending");'
        . '</script>' . "\n";

    $dark =
        'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.plugins-php.yooadmin-plugins-page ';
    $light =
        'html:not([data-yooadmin-studio-color-mode-effective="dark"]):not(.is-dark-theme) body.plugins-php.yooadmin-plugins-page ';
    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS; selector prefixes are constants.
    echo '<style id="yooadmin-studio-hub-plugins-php-layout-critical">'
        . $light . '.yoo-pages-search-input,.yoo-pages-search-wrapper .yoo-pages-search-input{background:#fff!important;border-color:#dcdcde!important;color:#2c3338!important;}'
        . $light . '.yoo-pages-search-wrapper .dashicons{color:#8c8f94!important;}'
        . $dark . '.yoo-pages-toolbar a.yoo-filter-chip:not(.is-active){color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $dark . '.yoo-pages-toolbar a.yoo-filter-chip.is-active{color:#fff!important;-webkit-text-fill-color:#fff!important;}'
        . $dark . '.yoo-pages-toolbar a.yoo-filter-chip.is-active :is(*,.yoo-filter-count){color:#fff!important;-webkit-text-fill-color:#fff!important;}'
        . $dark . '.yoo-pages-hero__actions .yp-yoo-btn--primary,.yoo-pages-hero__actions .yp-yoo-btn--primary :is(*,.dashicons){color:#fff!important;-webkit-text-fill-color:#fff!important;}'
        . $dark . '.yoo-pages-hero__actions .yoo-plugins-search-submit{color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $dark . '.yoo-pages-search-input,.yoo-pages-search-wrapper .yoo-pages-search-input{background:#22262e!important;border-color:rgba(255,255,255,.14)!important;color:#cfd6e0!important;}'
        . $dark . '.yoo-pages-search-wrapper .dashicons{color:#9aa5b1!important;}'
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Enqueue pages list styles + plugins layout assets.
 */
function yooadmin_studio_hub_enqueue_plugins_php_layout_assets(): void {
    if (!yooadmin_studio_hub_should_style_plugins_php_layout()) {
        return;
    }

    if (!defined('YOOADMIN_DIR') || !defined('YOOADMIN_PLUGIN_FILE')) {
        return;
    }

    if (function_exists('yooadmin_enqueue_list_screen_ui_assets')) {
        yooadmin_enqueue_list_screen_ui_assets();
    }

    $pages_css = YOOADMIN_DIR . 'assets/css/admin/pages-page.css';
    if (is_readable($pages_css)) {
        $pages_deps = ['yooadmin-shell', 'yooadmin-core'];
        if (wp_style_is('yooadmin-list-screens-ui', 'registered') || wp_style_is('yooadmin-list-screens-ui', 'enqueued')) {
            $pages_deps[] = 'yooadmin-list-screens-ui';
        } elseif (wp_style_is('yooadmin-yoo-buttons', 'registered') || wp_style_is('yooadmin-yoo-buttons', 'enqueued')) {
            $pages_deps[] = 'yooadmin-yoo-buttons';
        }
        wp_enqueue_style(
            'yooadmin-pages',
            plugins_url('assets/css/admin/pages-page.css', YOOADMIN_PLUGIN_FILE),
            $pages_deps,
            (string) filemtime($pages_css)
        );
    }

    $layout_css = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugins-php-layout.css');
    if (is_readable($layout_css)) {
        $deps = ['yooadmin-studio-hub-late'];
        if (wp_style_is('yooadmin-pages', 'registered') || wp_style_is('yooadmin-pages', 'enqueued')) {
            $deps[] = 'yooadmin-pages';
        }
        if (wp_style_is('yooadmin-list-screens-ui', 'registered') || wp_style_is('yooadmin-list-screens-ui', 'enqueued')) {
            $deps[] = 'yooadmin-list-screens-ui';
        }
        if (wp_style_is('yooadmin-yp-ui-select', 'registered') || wp_style_is('yooadmin-yp-ui-select', 'enqueued')) {
            $deps[] = 'yooadmin-yp-ui-select';
        }
        wp_enqueue_style(
            'yooadmin-studio-hub-plugins-php-layout',
            yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugins-php-layout.css'),
            $deps,
            (string) filemtime($layout_css)
        );
    }

    $layout_js = yooadmin_studio_hub_asset_path('js/admin/plugins-php-layout.js');
    if (!is_readable($layout_js)) {
        return;
    }

    $layout_deps = [];
    if (wp_script_is('yooadmin-yp-ui-select', 'registered') || wp_script_is('yooadmin-yp-ui-select', 'enqueued')) {
        $layout_deps[] = 'yooadmin-yp-ui-select';
    }

    wp_enqueue_script(
        'yooadmin-studio-hub-plugins-php-layout',
        yooadmin_studio_hub_asset_url('js/admin/plugins-php-layout.js'),
        $layout_deps,
        (string) filemtime($layout_js),
        true
    );

    $can_install_plugins = current_user_can('install_plugins');
    if (is_multisite() && !is_network_admin()) {
        $can_install_plugins = false;
    }

    wp_localize_script(
        'yooadmin-studio-hub-plugins-php-layout',
        'yooadminPluginsLayout',
        [
            'canInstallPlugins' => $can_install_plugins,
            'addPluginUrl'      => $can_install_plugins ? self_admin_url('plugin-install.php') : '',
            'i18n' => [
                'eyebrow'       => __('Extensions · Plugins', 'yooadmin'),
                'searchPlaceholder' => __('Search plugins…', 'yooadmin'),
                'showStats'     => __('Show Statistics', 'yooadmin'),
                'hideStats'     => __('Hide Statistics', 'yooadmin'),
                'totalPlugins'  => __('Total Plugins', 'yooadmin'),
                'activePlugins' => __('Active', 'yooadmin'),
                'inactivePlugins' => __('Inactive', 'yooadmin'),
                'addPlugin'     => __('Add Plugin', 'yooadmin'),
                'activeBadge'   => __('Active', 'yooadmin'),
                'screenOptions' => __('Screen Options', 'yooadmin'),
            ],
        ]
    );
}
