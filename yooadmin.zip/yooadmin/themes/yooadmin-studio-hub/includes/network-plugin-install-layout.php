<?php
/**
 * Studio Hub — plugin-install.php layout (site + network admin, YOOAdmin hero + cards).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Add Plugins screen (excludes plugin-information iframe). Site admin + Network Admin.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_plugin_install_layout_php_page(): bool {
    if (!is_admin()) {
        return false;
    }

    global $pagenow;

    if (!isset($pagenow) || $pagenow !== 'plugin-install.php') {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen detection.
    $tab = isset($_GET['tab']) ? sanitize_key((string) wp_unslash($_GET['tab'])) : '';

    return $tab !== 'plugin-information';
}

/**
 * @deprecated 1.1.0 Use yooadmin_studio_hub_is_plugin_install_layout_php_page().
 * @return bool
 */
function yooadmin_studio_hub_is_network_plugin_install_php_page(): bool {
    return yooadmin_studio_hub_is_plugin_install_layout_php_page();
}

/**
 * @return bool
 */
function yooadmin_studio_hub_should_style_plugin_install_layout(): bool {
    return yooadmin_studio_hub_is_active()
        && yooadmin_studio_hub_plugin_install_basic_active()
        && yooadmin_studio_hub_is_plugin_install_layout_php_page();
}

/**
 * @deprecated 1.1.0 Use yooadmin_studio_hub_should_style_plugin_install_layout().
 * @return bool
 */
function yooadmin_studio_hub_should_style_network_plugin_install_layout(): bool {
    return yooadmin_studio_hub_should_style_plugin_install_layout();
}

/**
 * @param string $classes
 * @return string
 */
function yooadmin_studio_hub_filter_plugin_install_body_class(string $classes): string {
    if (!yooadmin_studio_hub_should_style_plugin_install_layout()) {
        return $classes;
    }

    return trim($classes . ' yooadmin-plugin-install-page yoo-list-screen');
}

/**
 * @deprecated 1.1.0 Use yooadmin_studio_hub_filter_plugin_install_body_class().
 * @param string $classes
 * @return string
 */
function yooadmin_studio_hub_filter_network_plugin_install_body_class(string $classes): string {
    return yooadmin_studio_hub_filter_plugin_install_body_class($classes);
}

/**
 * Critical CSS + first-paint guard — hide native plugin-install until JS reshapes layout.
 */
function yooadmin_studio_hub_print_plugin_install_layout_critical(): void {
    if (!yooadmin_studio_hub_should_style_plugin_install_layout()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-plugin-install-layout-pending">'
        . 'document.documentElement.classList.add("yoo-plugin-install-layout-pending");'
        . '</script>' . "\n";

    $dark =
        'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.plugin-install-php.yooadmin-plugin-install-page ';
    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS; $dark is a constant selector prefix.
    echo '<style id="yooadmin-studio-hub-plugin-install-layout-critical">'
        . 'html:not(.yoo-plugin-install-ui-ready) body.plugin-install-php'
        . ' #typeselector:not(.yp-custom-select__native),'
        . 'html:not(.yoo-plugin-install-ui-ready) body.plugin-install-php'
        . ' .search-form.search-plugins select[name="type"]:not(.yp-custom-select__native){'
        . 'position:absolute!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important;}'
        . $dark . '.yoo-pages-search-input,.yoo-pages-search-wrapper .yoo-pages-search-input{background:#22262e!important;border-color:rgba(255,255,255,.14)!important;color:#cfd6e0!important;}'
        . $dark . '.yoo-pages-search-wrapper .dashicons{color:#9aa5b1!important;}'
        . $dark . '.yoo-plugin-install-search .yp-custom-select__trigger{background:#22262e!important;border-color:rgba(255,255,255,.2)!important;color:#cfd6e0!important;}'
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * @deprecated 1.1.0 Use yooadmin_studio_hub_print_plugin_install_layout_critical().
 */
function yooadmin_studio_hub_print_network_plugin_install_layout_critical(): void {
    yooadmin_studio_hub_print_plugin_install_layout_critical();
}

/**
 * Enqueue pages hero styles + plugin-install layout assets.
 */
function yooadmin_studio_hub_enqueue_plugin_install_layout_assets(): void {
    if (!yooadmin_studio_hub_should_style_plugin_install_layout()) {
        return;
    }

    if (!defined('YOOADMIN_DIR') || !defined('YOOADMIN_PLUGIN_FILE')) {
        return;
    }

    if (function_exists('yooadmin_enqueue_list_screen_ui_assets')) {
        yooadmin_enqueue_list_screen_ui_assets();
    }

    $pages_css = YOOADMIN_DIR . 'assets/css/admin/pages-page.css';
    if (is_readable($pages_css)) {
        $pages_deps = ['yooadmin-shell', 'yooadmin-core'];
        if (wp_style_is('yooadmin-list-screens-ui', 'registered') || wp_style_is('yooadmin-list-screens-ui', 'enqueued')) {
            $pages_deps[] = 'yooadmin-list-screens-ui';
        } elseif (wp_style_is('yooadmin-yoo-buttons', 'registered') || wp_style_is('yooadmin-yoo-buttons', 'enqueued')) {
            $pages_deps[] = 'yooadmin-yoo-buttons';
        }
        wp_enqueue_style(
            'yooadmin-pages',
            plugins_url('assets/css/admin/pages-page.css', YOOADMIN_PLUGIN_FILE),
            $pages_deps,
            (string) filemtime($pages_css)
        );
    }

    $layout_css = yooadmin_studio_hub_asset_path('css/compat/studio-hub-network-plugin-install-layout.css');
    if (is_readable($layout_css)) {
        $deps = ['yooadmin-studio-hub-late'];
        if (wp_style_is('yooadmin-pages', 'registered') || wp_style_is('yooadmin-pages', 'enqueued')) {
            $deps[] = 'yooadmin-pages';
        }
        if (wp_style_is('yooadmin-list-screens-ui', 'registered') || wp_style_is('yooadmin-list-screens-ui', 'enqueued')) {
            $deps[] = 'yooadmin-list-screens-ui';
        }
        wp_enqueue_style(
            'yooadmin-studio-hub-network-plugin-install-layout',
            yooadmin_studio_hub_asset_url('css/compat/studio-hub-network-plugin-install-layout.css'),
            $deps,
            (string) filemtime($layout_css)
        );
    }

    $yp_sel_css = YOOADMIN_DIR . 'assets/css/admin/yp-archive-delay-select.css';
    if (is_readable($yp_sel_css)) {
        wp_enqueue_style(
            'yooadmin-yp-ui-select',
            plugins_url('assets/css/admin/yp-archive-delay-select.css', YOOADMIN_PLUGIN_FILE),
            ['yooadmin-core'],
            (string) filemtime($yp_sel_css)
        );
    }

    $yp_sel_js = YOOADMIN_DIR . 'assets/js/admin/yp-archive-delay-select.js';
    if (is_readable($yp_sel_js)) {
        wp_enqueue_script(
            'yooadmin-yp-ui-select',
            plugins_url('assets/js/admin/yp-archive-delay-select.js', YOOADMIN_PLUGIN_FILE),
            [],
            (string) filemtime($yp_sel_js),
            true
        );
    }

    $search_fields_css = YOOADMIN_DIR . 'assets/css/admin/yp-admin-search-fields.css';
    if (is_readable($search_fields_css)) {
        wp_enqueue_style(
            'yooadmin-admin-search-fields',
            plugins_url('assets/css/admin/yp-admin-search-fields.css', YOOADMIN_PLUGIN_FILE),
            ['yooadmin-core'],
            (string) filemtime($search_fields_css)
        );
    }

    $layout_js = yooadmin_studio_hub_asset_path('js/admin/network-plugin-install-layout.js');
    if (!is_readable($layout_js)) {
        return;
    }

    $layout_deps = [];
    if (wp_script_is('yooadmin-yp-ui-select', 'registered') || wp_script_is('yooadmin-yp-ui-select', 'enqueued')) {
        $layout_deps[] = 'yooadmin-yp-ui-select';
    }

    wp_enqueue_script(
        'yooadmin-studio-hub-network-plugin-install-layout',
        yooadmin_studio_hub_asset_url('js/admin/network-plugin-install-layout.js'),
        $layout_deps,
        (string) filemtime($layout_js),
        true
    );

    wp_localize_script(
        'yooadmin-studio-hub-network-plugin-install-layout',
        'yooadminPluginInstallLayout',
        [
            'isUploadTab' => isset($_GET['tab']) && sanitize_key((string) wp_unslash($_GET['tab'])) === 'upload', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            'i18n'        => [
                'eyebrow'           => __('Extensions · Add Plugin', 'yooadmin'),
                'searchPlaceholder' => __('Search plugins…', 'yooadmin'),
                'uploadPlugin'      => __('Upload Plugin', 'yooadmin'),
                'browsePlugins'     => __('Browse Plugins', 'yooadmin'),
            ],
        ]
    );
}

/**
 * @deprecated 1.1.0 Use yooadmin_studio_hub_enqueue_plugin_install_layout_assets().
 */
function yooadmin_studio_hub_enqueue_network_plugin_install_layout_assets(): void {
    yooadmin_studio_hub_enqueue_plugin_install_layout_assets();
}
