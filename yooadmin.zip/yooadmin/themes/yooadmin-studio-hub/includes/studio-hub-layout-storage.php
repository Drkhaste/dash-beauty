<?php
/**
 * Studio Hub — per-user dashboard layout persistence (user meta).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

const YOOADMIN_STUDIO_HUB_LAYOUT_META_KEY = 'yooadmin_studio_hub_layout_v1';
const YOOADMIN_STUDIO_HUB_LAYOUT_VERSION  = 1;

if (!function_exists('yooadmin_studio_hub_layout_capability')) {
    /**
     * Capability for per-user dashboard layout AJAX/REST (load, save, visibility).
     *
     * Defaults to `read` so Authors, Editors, and other workspace users can persist
     * their own layout in user meta. Stricter sites may filter this (e.g. edit_posts).
     *
     * @return string
     */
    function yooadmin_studio_hub_layout_capability(): string
    {
        return (string) apply_filters('yooadmin_studio_hub_layout_capability', 'read');
    }
}

/**
 * Aside sections hidden until the user shows them (no saved layout yet).
 *
 * @return string[]
 */
function yooadmin_studio_hub_default_hidden_sections(): array {
    return [];
}

/**
 * Built-in aside sections removed until the user adds them back.
 *
 * @return string[]
 */
function yooadmin_studio_hub_default_removed_sections(): array {
    return ['studio-activity'];
}

/**
 * Resolved hidden aside sections (defaults until user customizes visibility).
 *
 * @param array<string, mixed>|null $layout Stored layout or null.
 * @return string[]
 */
function yooadmin_studio_hub_resolve_hidden_sections(?array $layout): array {
    $defaults = yooadmin_studio_hub_default_hidden_sections();
    if (!$layout) {
        return $defaults;
    }
    if (!empty($layout['hiddenSectionsExplicit']) && !empty($layout['asideVisibilityTouched'])) {
        $hidden = isset($layout['hiddenSections']) && is_array($layout['hiddenSections'])
            ? $layout['hiddenSections']
            : [];
        return array_values(array_unique(array_map('sanitize_key', $hidden)));
    }
    if (!isset($layout['hiddenSections']) || !is_array($layout['hiddenSections']) || $layout['hiddenSections'] === []) {
        return $defaults;
    }
    return array_values(array_unique(array_map('sanitize_key', $layout['hiddenSections'])));
}

/**
 * Keep main/aside placement consistent (e.g. from-extensions only in one column).
 *
 * @param array<string, mixed> $layout Normalized layout.
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_migrate_layout_orders(array $layout): array {
    $aside = [];
    if (!empty($layout['asideOrder']) && is_array($layout['asideOrder'])) {
        foreach ($layout['asideOrder'] as $id) {
            $id = sanitize_key((string) $id);
            if ($id !== '') {
                $aside[ $id ] = true;
            }
        }
    }
    if ($aside && !empty($layout['mainOrder']) && is_array($layout['mainOrder'])) {
        $layout['mainOrder'] = array_values(
            array_filter(
                $layout['mainOrder'],
                static function ($id) use ($aside) {
                    $id = sanitize_key((string) $id);
                    return $id !== '' && !isset($aside[ $id ]);
                }
            )
        );
    }
    return $layout;
}

/**
 * Register layout AJAX + REST.
 */
function yooadmin_studio_hub_register_layout_storage_hooks(): void {
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;

    add_action('wp_ajax_yooadmin_studio_hub_get_layout', 'yooadmin_studio_hub_ajax_get_layout');
    add_action('wp_ajax_yooadmin_studio_hub_save_layout', 'yooadmin_studio_hub_ajax_save_layout');
}

yooadmin_studio_hub_register_layout_storage_hooks();
add_action('rest_api_init', 'yooadmin_studio_hub_register_layout_rest_routes');

/**
 * @return int
 */
function yooadmin_studio_hub_layout_user_id(): int {
    return (int) get_current_user_id();
}

/**
 * Built-in dashboard sections mapped to registered dashboard card ids.
 *
 * @return array<string, string>
 */
function yooadmin_studio_hub_layout_section_card_map(): array {
    return [
        'studio-workspace-notes' => 'studio-workspace-notes',
        'studio-updates'         => 'studio-updates',
        'studio-tips'            => 'studio-tips',
        'studio-activity'        => 'studio-activity',
    ];
}

/**
 * Whether the current user may see a layout section on the dashboard.
 *
 * @param array<string, mixed>|null $layout Layout payload.
 */
function yooadmin_studio_hub_user_can_view_layout_section(string $section_id, ?array $layout = null): bool {
    if (!is_user_logged_in() || !current_user_can('read')) {
        return false;
    }

    $section_id = sanitize_key($section_id);
    if ($section_id === '') {
        return false;
    }

    $card_map = yooadmin_studio_hub_layout_section_card_map();
    if (isset($card_map[ $section_id ])) {
        return function_exists('yooadmin_user_can_view_dashboard_card')
            ? yooadmin_user_can_view_dashboard_card($card_map[ $section_id ])
            : current_user_can('read');
    }

    if (
        function_exists('yooadmin_studio_hub_default_overview_widget_section_id')
        && $section_id === yooadmin_studio_hub_default_overview_widget_section_id()
    ) {
        $widget_id = 'yooadmin_overview';
        if ($layout && !empty($layout['widgetSections'][ $section_id ]['widgetId'])) {
            $widget_id = sanitize_key((string) $layout['widgetSections'][ $section_id ]['widgetId']);
        }

        return function_exists('yooadmin_user_can_view_dashboard_card')
            ? yooadmin_user_can_view_dashboard_card($widget_id)
            : current_user_can('manage_options');
    }

    if ($layout && !empty($layout['widgetSections'][ $section_id ]) && is_array($layout['widgetSections'][ $section_id ])) {
        $widget_id = sanitize_key((string) ( $layout['widgetSections'][ $section_id ]['widgetId'] ?? '' ));
        if ($widget_id === '') {
            return false;
        }

        return function_exists('yooadmin_user_can_view_dashboard_card')
            ? yooadmin_user_can_view_dashboard_card($widget_id)
            : current_user_can('read');
    }

    return true;
}

/**
 * Remove dashboard sections/widgets the current user cannot access.
 *
 * @param array<string, mixed> $layout Layout payload.
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_filter_layout_sections_for_user(array $layout): array {
    if (!is_user_logged_in()) {
        return $layout;
    }

    foreach (['mainOrder', 'asideOrder'] as $order_key) {
        if (empty($layout[ $order_key ]) || !is_array($layout[ $order_key ])) {
            continue;
        }

        $layout[ $order_key ] = array_values(
            array_filter(
                $layout[ $order_key ],
                static function ($section_id) use ($layout) {
                    return yooadmin_studio_hub_user_can_view_layout_section((string) $section_id, $layout);
                }
            )
        );
    }

    if (!empty($layout['widgetSections']) && is_array($layout['widgetSections'])) {
        foreach (array_keys($layout['widgetSections']) as $section_id) {
            if (!yooadmin_studio_hub_user_can_view_layout_section((string) $section_id, $layout)) {
                unset($layout['widgetSections'][ $section_id ]);
            }
        }
    }

    return $layout;
}

/**
 * @param int $user_id
 * @return array<string, mixed>|null
 */
function yooadmin_studio_hub_get_user_layout(int $user_id = 0): ?array {
    if ($user_id <= 0) {
        $user_id = yooadmin_studio_hub_layout_user_id();
    }
    if ($user_id <= 0) {
        return null;
    }

    $stored = get_user_meta($user_id, YOOADMIN_STUDIO_HUB_LAYOUT_META_KEY, true);
    if (!is_array($stored)) {
        return null;
    }

    $layout = yooadmin_studio_hub_normalize_layout_payload($stored);
    if (!$layout) {
        return null;
    }

    $migrated = yooadmin_studio_hub_migrate_layout_orders($layout);
    $before   = isset($layout['mainOrder']) && is_array($layout['mainOrder']) ? $layout['mainOrder'] : [];
    $after    = isset($migrated['mainOrder']) && is_array($migrated['mainOrder']) ? $migrated['mainOrder'] : [];
    if (wp_json_encode($before) !== wp_json_encode($after)) {
        yooadmin_studio_hub_save_user_layout($migrated, $user_id);
    }

    $migrated = yooadmin_studio_hub_migrate_layout_removed_defaults($migrated);
    $migrated = yooadmin_studio_hub_migrate_default_overview_widget($migrated);
    $migrated = yooadmin_studio_hub_migrate_default_dashboard_widgets($migrated);
    if (function_exists('yooadmin_studio_hub_migrate_default_login_security_widget')) {
        $migrated = yooadmin_studio_hub_migrate_default_login_security_widget($migrated);
    }
    if (!empty($migrated['__layout_migrated'])) {
        unset($migrated['__layout_migrated']);
        yooadmin_studio_hub_save_user_layout($migrated, $user_id);
    }

    return yooadmin_studio_hub_filter_layout_sections_for_user(
        apply_filters('yooadmin_studio_hub_user_layout', $migrated, $user_id)
    );
}

/**
 * Whether a hideable aside section is stored as hidden for the user (SSR / no flash on refresh).
 *
 * @param string $section_id Section id (e.g. studio-activity).
 * @param int    $user_id    User ID (0 = current).
 */
function yooadmin_studio_hub_is_section_hidden_for_user(string $section_id, int $user_id = 0): bool {
    $section_id = sanitize_key($section_id);
    if ($section_id === '') {
        return false;
    }

    $hideable = [
        'studio-workspace-notes' => true,
        'studio-activity'        => true,
        'studio-tips'            => true,
        'studio-updates'         => true,
        'from-extensions'        => true,
    ];
    if (!isset($hideable[ $section_id ])) {
        return false;
    }

    $layout = yooadmin_studio_hub_get_user_layout($user_id);
    $hidden = yooadmin_studio_hub_resolve_hidden_sections($layout);

    return in_array($section_id, $hidden, true);
}

/**
 * @return string
 */
function yooadmin_studio_hub_default_overview_widget_section_id(): string {
    return 'widget-aside-yooadmin-overview';
}

/**
 * @return array<string, string>
 */
function yooadmin_studio_hub_default_overview_widget_meta(): array {
    return [
        'placement' => 'aside',
        'widgetId'  => 'yooadmin_overview',
        'title'     => yooadmin_studio_hub_localized_widget_section_title('yooadmin_overview'),
        'icon'      => 'dashicons-dashboard',
    ];
}

/**
 * Localized title for built-in widget sections (ignores stale saved English titles).
 *
 * @param string $widget_id    Widget id.
 * @param string $stored_title Optional title from saved layout.
 */
function yooadmin_studio_hub_localized_widget_section_title(string $widget_id, string $stored_title = ''): string {
    $canonical = [
        'yooadmin_overview'         => __('YOOAdmin Overview', 'yooadmin'),
        'yooadmin_account_overview' => __('Account overview', 'yooadmin'),
        'studio-login-security'     => __('Login security', 'yooadmin'),
    ];

    if (isset($canonical[ $widget_id ])) {
        return $canonical[ $widget_id ];
    }

    if ($stored_title !== '') {
        return $stored_title;
    }

    return __('Dashboard card', 'yooadmin');
}

/**
 * Mark legacy overview auto-migration as complete (overview is opt-in, not default).
 *
 * @param array<string, mixed> $layout Layout payload.
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_migrate_default_overview_widget(array $layout): array {
    if (!empty($layout['overviewDefaultWidgetAdded'])) {
        return $layout;
    }

    $layout['overviewDefaultWidgetAdded'] = true;
    $layout['__layout_migrated']          = true;

    return $layout;
}

/**
 * Insert section ids from the default aside order into a saved aside order.
 *
 * @param string[] $current  Current aside order.
 * @param string[] $defaults Factory/default aside order.
 * @return string[]
 */
function yooadmin_studio_hub_merge_aside_order_with_defaults(array $current, array $defaults): array {
    $merged = array_values($current);

    foreach ($defaults as $section_id) {
        $section_id = sanitize_key((string) $section_id);
        if ($section_id === '' || in_array($section_id, $merged, true)) {
            continue;
        }

        $insert_at = count($merged);
        $default_index = array_search($section_id, $defaults, true);
        if ($default_index !== false) {
            for ($i = $default_index - 1; $i >= 0; $i--) {
                $anchor = sanitize_key((string) $defaults[ $i ]);
                if ($anchor === '') {
                    continue;
                }
                $anchor_pos = array_search($anchor, $merged, true);
                if ($anchor_pos !== false) {
                    $insert_at = $anchor_pos + 1;
                    break;
                }
            }
        }

        array_splice($merged, $insert_at, 0, [ $section_id ]);
    }

    return array_values($merged);
}

/**
 * Widget ids the user removed from the dashboard (persisted in layout).
 *
 * @param array<string, mixed>|null $layout Layout payload.
 * @return string[]
 */
function yooadmin_studio_hub_removed_widget_ids(?array $layout): array {
    if (!$layout || !isset($layout['removedWidgetIds']) || !is_array($layout['removedWidgetIds'])) {
        return [];
    }

    return array_values(
        array_filter(
            array_map(
                static function ($id): string {
                    return sanitize_key((string) $id);
                },
                $layout['removedWidgetIds']
            )
        )
    );
}

/**
 * @param string                    $widget_id Widget id (e.g. studio-login-security).
 * @param array<string, mixed>|null $layout    Layout payload.
 */
function yooadmin_studio_hub_is_widget_id_removed(string $widget_id, ?array $layout): bool {
    $widget_id = sanitize_key($widget_id);

    return $widget_id !== '' && in_array($widget_id, yooadmin_studio_hub_removed_widget_ids($layout), true);
}

/**
 * Add default dashboard widgets from layout defaults (extensions + core cards).
 *
 * @param array<string, mixed> $layout Layout payload.
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_migrate_default_dashboard_widgets(array $layout): array {
    if (!function_exists('yooadmin_studio_hub_layout_defaults_for_display')) {
        return $layout;
    }

    $defaults        = yooadmin_studio_hub_layout_defaults_for_display();
    $default_widgets = isset($defaults['widgetSections']) && is_array($defaults['widgetSections'])
        ? $defaults['widgetSections']
        : [];
    $default_aside   = isset($defaults['asideOrder']) && is_array($defaults['asideOrder'])
        ? $defaults['asideOrder']
        : [];

    if ($default_widgets === []) {
        return $layout;
    }

    $widgets = isset($layout['widgetSections']) && is_array($layout['widgetSections'])
        ? $layout['widgetSections']
        : [];
    $removed = isset($layout['removedWidgetIds']) && is_array($layout['removedWidgetIds'])
        ? array_map('strval', $layout['removedWidgetIds'])
        : [];
    $changed = false;

    foreach ($default_widgets as $section_id => $meta) {
        $section_id = sanitize_key((string) $section_id);
        if ($section_id === '' || !is_array($meta)) {
            continue;
        }

        $widget_id = sanitize_key((string) ( $meta['widgetId'] ?? '' ));
        if ($widget_id === '' || $widget_id === 'yooadmin_overview') {
            continue;
        }

        if (in_array($widget_id, $removed, true)) {
            continue;
        }

        $has_widget = false;
        foreach ($widgets as $stored_meta) {
            if (is_array($stored_meta) && (string) ( $stored_meta['widgetId'] ?? '' ) === $widget_id) {
                $has_widget = true;
                break;
            }
        }

        if ($has_widget) {
            continue;
        }

        if (
            function_exists('yooadmin_user_can_view_dashboard_card')
            && !yooadmin_user_can_view_dashboard_card($widget_id)
        ) {
            continue;
        }

        $widgets[ $section_id ] = [
            'placement' => isset($meta['placement']) && $meta['placement'] === 'aside' ? 'aside' : 'main',
            'widgetId'  => $widget_id,
            'title'     => isset($meta['title']) ? sanitize_text_field((string) $meta['title']) : '',
            'icon'      => isset($meta['icon']) ? sanitize_text_field((string) $meta['icon']) : '',
        ];
        $changed = true;
    }

    if (!$changed) {
        return $layout;
    }

    $layout['widgetSections'] = $widgets;

    $aside_order = isset($layout['asideOrder']) && is_array($layout['asideOrder'])
        ? $layout['asideOrder']
        : [];
    $layout['asideOrder']       = yooadmin_studio_hub_merge_aside_order_with_defaults($aside_order, $default_aside);
    $layout['__layout_migrated'] = true;

    return $layout;
}

/**
 * Layout payload for SSR/early scripts when the user has no saved layout yet.
 *
 * @return array<string, mixed>
 */
/**
 * Whether a layout section is stored in the right sidebar column.
 *
 * @param string               $section_id Section id.
 * @param array<string, mixed>|null $layout    Layout payload or null (load from user).
 */
function yooadmin_studio_hub_section_in_aside(string $section_id, ?array $layout = null): bool {
    $section_id = sanitize_key($section_id);
    if ($section_id === '') {
        return false;
    }

    if ($layout === null) {
        $layout = yooadmin_studio_hub_get_user_layout();
        if (!$layout && function_exists('yooadmin_studio_hub_layout_defaults_for_display')) {
            $layout = yooadmin_studio_hub_layout_defaults_for_display();
        }
    }

    if (!$layout || !is_array($layout)) {
        return false;
    }

    $layout   = yooadmin_studio_hub_migrate_layout_orders($layout);
    $aside    = isset($layout['asideOrder']) && is_array($layout['asideOrder']) ? $layout['asideOrder'] : [];
    $in_aside = in_array($section_id, $aside, true);

    return $in_aside;
}

/**
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_layout_defaults_for_display(): array {
    $aside_order = ['studio-workspace-notes', 'studio-updates', 'studio-tips', 'studio-activity'];
    $widget_sections = [];

    if (
        function_exists('yooadmin_user_can_view_dashboard_card')
        && !yooadmin_user_can_view_dashboard_card('studio-updates')
    ) {
        $aside_order = array_values(
            array_filter(
                $aside_order,
                static function ($id) {
                    return $id !== 'studio-updates';
                }
            )
        );
    }

    return apply_filters('yooadmin_studio_hub_layout_defaults', [
        'version'                => YOOADMIN_STUDIO_HUB_LAYOUT_VERSION,
        'mainOrder'              => ['your-workspace', 'from-extensions'],
        'asideOrder'             => $aside_order,
        'hidden'                 => [],
        'hiddenSections'         => yooadmin_studio_hub_default_hidden_sections(),
        'hiddenSectionsExplicit' => false,
        'removedBuiltInSections' => yooadmin_studio_hub_default_removed_sections(),
        'widgetSections'         => $widget_sections,
        'overviewDefaultWidgetAdded' => true,
    ]);
}

/**
 * Migrate legacy hidden Activity to removed-by-default layout.
 *
 * @param array<string, mixed> $layout Layout payload.
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_migrate_layout_removed_defaults(array $layout): array {
    $changed = false;
    $hidden  = isset($layout['hiddenSections']) && is_array($layout['hiddenSections'])
        ? $layout['hiddenSections']
        : [];
    $removed = isset($layout['removedBuiltInSections']) && is_array($layout['removedBuiltInSections'])
        ? $layout['removedBuiltInSections']
        : [];

    if (in_array('studio-activity', $hidden, true)) {
        if (!in_array('studio-activity', $removed, true)) {
            $removed[] = 'studio-activity';
        }
        $hidden = array_values(
            array_filter(
                $hidden,
                static function ($id) {
                    return $id !== 'studio-activity';
                }
            )
        );
        $layout['hiddenSections'] = $hidden;
        $changed                  = true;
    }

    if (
        !array_key_exists('removedBuiltInSections', $layout)
        && empty($layout['asideVisibilityTouched'])
        && empty($layout['hiddenSectionsExplicit'])
    ) {
        $removed = yooadmin_studio_hub_default_removed_sections();
        $changed = true;
    }

    if ($changed) {
        $layout['removedBuiltInSections'] = array_values(array_unique($removed));
        $layout['__layout_migrated']    = true;
    }

    return $layout;
}

/**
 * Markup attributes for a hidden dashboard section (empty when visible).
 *
 * @param string $section_id Section id.
 * @param int    $user_id    User ID (0 = current).
 */
function yooadmin_studio_hub_section_hidden_attrs(string $section_id, int $user_id = 0): string {
    if (!yooadmin_studio_hub_is_section_hidden_for_user($section_id, $user_id)) {
        return '';
    }

    return ' data-section-hidden="true" class="is-dashboard-section-hidden"';
}

/**
 * Whether the saved layout keeps no tiles in Your plugins (all moved elsewhere).
 *
 * @param array<string, mixed>|null $layout Layout payload or null (load from user).
 */
function yooadmin_studio_hub_extensions_section_empty_for_layout(?array $layout = null): bool {
    if ($layout === null) {
        $layout = yooadmin_studio_hub_get_user_layout();
    }
    if (!$layout || empty($layout['cards']) || !is_array($layout['cards'])) {
        return false;
    }
    if (!array_key_exists('from-extensions', $layout['cards'])) {
        return false;
    }
    $ext_cards = $layout['cards']['from-extensions'];
    if (!is_array($ext_cards)) {
        return false;
    }

    return $ext_cards === [];
}

/**
 * Whether the sidebar column should collapse (primary uses full width) for this user.
 *
 * @param int $user_id User ID (0 = current).
 */
function yooadmin_studio_hub_should_collapse_aside_for_user(int $user_id = 0): bool {
    $layout = yooadmin_studio_hub_get_user_layout($user_id);
    if (!$layout) {
        return false;
    }

    $hidden = yooadmin_studio_hub_resolve_hidden_sections($layout);

    $main_order = [];
    if (!empty($layout['mainOrder']) && is_array($layout['mainOrder'])) {
        $main_order = $layout['mainOrder'];
    }

    $aside_candidates = [];

    $removed_builtins = !empty($layout['removedBuiltInSections']) && is_array($layout['removedBuiltInSections'])
        ? array_fill_keys($layout['removedBuiltInSections'], true)
        : [];

    if (array_key_exists('asideOrder', $layout) && is_array($layout['asideOrder'])) {
        foreach ($layout['asideOrder'] as $id) {
            $id = sanitize_key((string) $id);
            if ($id !== '' && !isset($removed_builtins[ $id ])) {
                $aside_candidates[ $id ] = true;
            }
        }
    } else {
        foreach (['studio-workspace-notes', 'studio-updates', 'studio-tips', 'studio-activity'] as $id) {
            if (!isset($removed_builtins[ $id ])) {
                $aside_candidates[ $id ] = true;
            }
        }
    }

    if (!empty($layout['customSections']) && is_array($layout['customSections'])) {
        foreach ($layout['customSections'] as $id => $meta) {
            if (!is_array($meta) || ($meta['placement'] ?? 'main') !== 'aside') {
                continue;
            }
            $id = sanitize_key((string) $id);
            if ($id !== '') {
                $aside_candidates[ $id ] = true;
            }
        }
    }

    if (!empty($layout['widgetSections']) && is_array($layout['widgetSections'])) {
        foreach ($layout['widgetSections'] as $id => $meta) {
            if (!is_array($meta) || ($meta['placement'] ?? '') !== 'aside') {
                continue;
            }
            $id = sanitize_key((string) $id);
            if ($id !== '') {
                $aside_candidates[ $id ] = true;
            }
        }
    }

    foreach (array_keys($aside_candidates) as $id) {
        if (in_array($id, $main_order, true)) {
            continue;
        }
        if (!in_array($id, $hidden, true)) {
            return false;
        }
    }

    return true;
}

/**
 * @param array<string, mixed> $data
 * @param int                  $user_id
 * @return bool
 */
function yooadmin_studio_hub_save_user_layout(array $data, int $user_id = 0): bool {
    if ($user_id <= 0) {
        $user_id = yooadmin_studio_hub_layout_user_id();
    }
    if ($user_id <= 0) {
        return false;
    }

    $layout = yooadmin_studio_hub_normalize_layout_payload($data);
    if ($layout === null) {
        return false;
    }

    $layout = yooadmin_studio_hub_migrate_layout_orders($layout);

    $stored      = get_user_meta($user_id, YOOADMIN_STUDIO_HUB_LAYOUT_META_KEY, true);
    $existing    = is_array($stored) ? yooadmin_studio_hub_normalize_layout_payload($stored) : null;
    $incoming_ts = isset($layout['savedAt']) ? (int) $layout['savedAt'] : 0;
    $existing_ts = is_array($existing) && isset($existing['savedAt']) ? (int) $existing['savedAt'] : 0;
    if ($existing && $incoming_ts > 0 && $existing_ts > 0 && $incoming_ts < $existing_ts) {
        return true;
    }

    if (!isset($layout['savedAt']) || (int) $layout['savedAt'] <= 0) {
        $layout['savedAt'] = (int) round(microtime(true) * 1000);
    }

    $encoded = wp_json_encode($layout);
    if (!is_string($encoded) || strlen($encoded) > 512000) {
        return false;
    }

    return (bool) update_user_meta($user_id, YOOADMIN_STUDIO_HUB_LAYOUT_META_KEY, $layout);
}

/**
 * Fast path: update only hidden aside sections (merge into stored layout).
 *
 * @param string[] $hidden_sections Section IDs to hide.
 * @param int      $saved_at        Client timestamp (ms).
 * @param int      $user_id         User ID (0 = current).
 */
function yooadmin_studio_hub_patch_layout_visibility(array $hidden_sections, int $saved_at = 0, int $user_id = 0): bool {
    if ($user_id <= 0) {
        $user_id = yooadmin_studio_hub_layout_user_id();
    }
    if ($user_id <= 0) {
        return false;
    }

    $hideable = [
        'studio-workspace-notes' => true,
        'studio-activity'        => true,
        'studio-tips'            => true,
        'studio-updates'         => true,
    ];

    $hidden = [];
    foreach ($hidden_sections as $id) {
        $id = sanitize_key((string) $id);
        if ($id !== '' && isset($hideable[ $id ])) {
            $hidden[] = $id;
        }
    }

    $layout = yooadmin_studio_hub_get_user_layout($user_id);
    if (!is_array($layout)) {
        $layout = [
            'version'        => YOOADMIN_STUDIO_HUB_LAYOUT_VERSION,
            'mainOrder'      => [],
            'asideOrder'     => [],
            'hidden'         => [],
            'hiddenSections' => [],
        ];
    }

    $incoming_ts = $saved_at > 0 ? $saved_at : (int) round(microtime(true) * 1000);
    $existing_ts = isset($layout['savedAt']) ? (int) $layout['savedAt'] : 0;
    if ($existing_ts > 0 && $incoming_ts > 0 && $incoming_ts < $existing_ts) {
        return true;
    }

    $layout['version']                 = YOOADMIN_STUDIO_HUB_LAYOUT_VERSION;
    $layout['hiddenSections']          = $hidden;
    $layout['hiddenSectionsExplicit']  = true;
    $layout['asideVisibilityTouched']  = true;
    $layout['savedAt']                 = $incoming_ts;

    return yooadmin_studio_hub_save_user_layout($layout, $user_id);
}

/**
 * @param int $user_id
 * @return bool
 */
function yooadmin_studio_hub_delete_user_layout(int $user_id = 0): bool {
    if ($user_id <= 0) {
        $user_id = yooadmin_studio_hub_layout_user_id();
    }
    if ($user_id <= 0) {
        return false;
    }

    return (bool) delete_user_meta($user_id, YOOADMIN_STUDIO_HUB_LAYOUT_META_KEY);
}

/**
 * @param mixed $raw
 * @return array<string, mixed>|null
 */
function yooadmin_studio_hub_normalize_layout_payload($raw): ?array {
    if (!is_array($raw)) {
        return null;
    }

    $version = isset($raw['version']) ? (int) $raw['version'] : 0;
    if ($version !== YOOADMIN_STUDIO_HUB_LAYOUT_VERSION) {
        return null;
    }

    $layout = [
        'version' => YOOADMIN_STUDIO_HUB_LAYOUT_VERSION,
    ];

    if (isset($raw['savedAt'])) {
        $layout['savedAt'] = max(0, (int) $raw['savedAt']);
    }

    if (!empty($raw['asideVisibilityTouched'])) {
        $layout['asideVisibilityTouched'] = true;
    }

    if (!empty($raw['overviewDefaultWidgetAdded'])) {
        $layout['overviewDefaultWidgetAdded'] = true;
    }

    if (isset($raw['removedWidgetIds']) && is_array($raw['removedWidgetIds'])) {
        $layout['removedWidgetIds'] = array_values(
            array_filter(
                array_map(
                    static function ($id) {
                        $id = sanitize_text_field((string) $id);
                        return $id !== '' ? $id : null;
                    },
                    $raw['removedWidgetIds']
                )
            )
        );
    }

    if (!empty($raw['hiddenSectionsExplicit']) && !empty($layout['asideVisibilityTouched'])) {
        $layout['hiddenSectionsExplicit'] = true;
    }

    $string_list_keys = ['mainOrder', 'asideOrder', 'hiddenSections', 'removedBuiltInSections'];
    foreach ($string_list_keys as $key) {
        if (!isset($raw[ $key ]) || !is_array($raw[ $key ])) {
            continue;
        }
        $layout[ $key ] = array_values(
            array_filter(
                array_map(
                    static function ($id) {
                        return sanitize_key((string) $id);
                    },
                    $raw[ $key ]
                )
            )
        );
    }

    if (isset($raw['hidden']) && is_array($raw['hidden'])) {
        $layout['hidden'] = array_values(
            array_filter(
                array_map(
                    static function ($id) {
                        $id = sanitize_text_field((string) $id);
                        return $id !== '' ? $id : null;
                    },
                    $raw['hidden']
                )
            )
        );
    }

    if (isset($raw['cards']) && is_array($raw['cards'])) {
        $cards = [];
        foreach ($raw['cards'] as $section_id => $card_ids) {
            $section_id = sanitize_key((string) $section_id);
            if ($section_id === '' || !is_array($card_ids)) {
                continue;
            }
            $cards[ $section_id ] = array_values(
                array_filter(
                    array_map(
                        static function ($card_id) {
                            $card_id = sanitize_text_field((string) $card_id);
                            return $card_id !== '' ? $card_id : null;
                        },
                        $card_ids
                    )
                )
            );
        }
        if ($cards) {
            $layout['cards'] = $cards;
        }
    }

    if (isset($raw['cardPages']) && is_array($raw['cardPages'])) {
        $pages = [];
        foreach ($raw['cardPages'] as $section_id => $page) {
            $section_id = sanitize_key((string) $section_id);
            if ($section_id === '') {
                continue;
            }
            $pages[ $section_id ] = max(0, (int) $page);
        }
        if ($pages) {
            $layout['cardPages'] = $pages;
        }
    }

    if (isset($raw['sectionIcons']) && is_array($raw['sectionIcons'])) {
        $icons = [];
        foreach ($raw['sectionIcons'] as $section_id => $icon) {
            $section_id = sanitize_key((string) $section_id);
            $icon       = sanitize_text_field((string) $icon);
            if ($section_id !== '' && $icon !== '') {
                $icons[ $section_id ] = $icon;
            }
        }
        if ($icons) {
            $layout['sectionIcons'] = $icons;
        }
    }

    if (isset($raw['customSections']) && is_array($raw['customSections'])) {
        $sections = [];
        foreach ($raw['customSections'] as $section_id => $meta) {
            $section_id = sanitize_key((string) $section_id);
            if ($section_id === '' || !is_array($meta)) {
                continue;
            }
            $placement = isset($meta['placement']) && $meta['placement'] === 'aside' ? 'aside' : 'main';
            $title     = isset($meta['title']) ? sanitize_text_field((string) $meta['title']) : '';
            $icon      = isset($meta['icon']) ? sanitize_text_field((string) $meta['icon']) : '';
            $sections[ $section_id ] = [
                'placement' => $placement,
                'title'     => $title,
                'icon'      => $icon,
            ];
        }
        if ($sections) {
            $layout['customSections'] = $sections;
        }
    }

    if (isset($raw['widgetSections']) && is_array($raw['widgetSections'])) {
        $widgets = [];
        foreach ($raw['widgetSections'] as $section_id => $meta) {
            $section_id = sanitize_key((string) $section_id);
            if ($section_id === '' || !is_array($meta)) {
                continue;
            }
            $widget_id = isset($meta['widgetId']) ? sanitize_key((string) $meta['widgetId']) : '';
            if ($widget_id === '') {
                continue;
            }
            $placement = isset($meta['placement']) && $meta['placement'] === 'aside' ? 'aside' : 'main';
            $title     = isset($meta['title']) ? sanitize_text_field((string) $meta['title']) : '';
            $icon      = isset($meta['icon']) ? sanitize_text_field((string) $meta['icon']) : '';
            $widgets[ $section_id ] = [
                'placement' => $placement,
                'widgetId'  => $widget_id,
                'title'     => $title,
                'icon'      => $icon,
            ];
        }
        if ($widgets) {
            $layout['widgetSections'] = $widgets;
        }
    }

    if (!empty($layout['removedBuiltInSections']) && is_array($layout['removedBuiltInSections'])) {
        $removable_builtins = [
            'studio-workspace-notes'         => true,
            'studio-activity'                => true,
            'studio-tips'                    => true,
            'studio-updates'                 => true,
            'studio-network-workspace-notes' => true,
            'studio-network-tips'            => true,
            'network-workspace-notes'        => true,
            'network-overview'               => true,
            'network-tips'                   => true,
            'yooadmin_overview'              => true,
        ];
        $layout['removedBuiltInSections'] = array_values(
            array_filter(
                array_unique($layout['removedBuiltInSections']),
                static function ($id) use ($removable_builtins) {
                    return isset($removable_builtins[ $id ]);
                }
            )
        );
    }

    if (empty($layout['hiddenSectionsExplicit'])) {
        $layout['hiddenSections'] = array_values(
            array_unique(
                array_merge(
                    yooadmin_studio_hub_default_hidden_sections(),
                    isset($layout['hiddenSections']) && is_array($layout['hiddenSections']) ? $layout['hiddenSections'] : []
                )
            )
        );
    }

    if (!empty($layout['removedBuiltInSections']) && !empty($layout['hiddenSections']) && is_array($layout['hiddenSections'])) {
        $removed = array_fill_keys($layout['removedBuiltInSections'], true);
        $layout['hiddenSections'] = array_values(
            array_filter(
                $layout['hiddenSections'],
                static function ($id) use ($removed) {
                    return !isset($removed[ $id ]);
                }
            )
        );
    }

    return yooadmin_studio_hub_migrate_layout_orders($layout);
}

/**
 * Whether the current layout AJAX request passed auth and nonce checks.
 *
 * @return bool
 */
function yooadmin_studio_hub_layout_request_is_verified(): bool {
    if (!is_user_logged_in() || !current_user_can(yooadmin_studio_hub_layout_capability())) {
        return false;
    }

    $nonce = function_exists('yooadmin_studio_hub_get_layout_ajax_nonce')
        ? yooadmin_studio_hub_get_layout_ajax_nonce()
        : '';

    if (!wp_verify_nonce($nonce, 'yooadmin_studio_hub_layout')) {
        return false;
    }

    return true;
}

/**
 * Decode layout JSON from POST/REST body (AJAX only; requires verified nonce).
 *
 * @return array<string, mixed>|null
 */
function yooadmin_studio_hub_read_layout_from_request(): ?array {
    if (!is_user_logged_in() || !current_user_can(yooadmin_studio_hub_layout_capability())) {
        return null;
    }

    $nonce = function_exists('yooadmin_studio_hub_get_layout_ajax_nonce')
        ? yooadmin_studio_hub_get_layout_ajax_nonce()
        : '';

    if (!wp_verify_nonce($nonce, 'yooadmin_studio_hub_layout')) {
        return null;
    }

    if (!isset($_POST['layout'])) {
        return null;
    }

    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce-verified layout blob; normalized after json_decode.
    $raw = wp_unslash($_POST['layout']);

    if (is_array($raw)) {
        return yooadmin_studio_hub_normalize_layout_payload($raw);
    }

    if (!is_string($raw) || $raw === '') {
        return null;
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        return null;
    }

    return yooadmin_studio_hub_normalize_layout_payload($decoded);
}

/**
 * AJAX: load saved layout for current user.
 */
function yooadmin_studio_hub_ajax_get_layout(): void {
    yooadmin_studio_hub_verify_layout_ajax_request();

    wp_send_json_success(
        [
            'layout' => yooadmin_studio_hub_get_user_layout(),
        ]
    );
}

/**
 * AJAX: persist layout for current user.
 */
function yooadmin_studio_hub_ajax_save_layout(): void {
    yooadmin_studio_hub_verify_layout_ajax_request();

    $layout = yooadmin_studio_hub_read_layout_from_request();
    if ($layout === null) {
        wp_send_json_error(
            [
                'message' => __('Invalid layout data.', 'yooadmin'),
                'code'    => 'invalid_layout',
            ],
            400
        );
    }

    if (!yooadmin_studio_hub_save_user_layout($layout)) {
        wp_send_json_error(
            [
                'message' => __('Could not save layout.', 'yooadmin'),
                'code'    => 'save_failed',
            ],
            500
        );
    }

    wp_send_json_success(
        [
            'saved' => true,
        ]
    );
}

/**
 * REST routes for layout load/save.
 */
function yooadmin_studio_hub_register_layout_rest_routes(): void {
    register_rest_route(
        'yooadmin/v1',
        '/studio-hub/layout',
        [
            [
                'methods'             => 'GET',
                'permission_callback' => static function (): bool {
                    return is_user_logged_in() && current_user_can(yooadmin_studio_hub_layout_capability());
                },
                'callback'            => static function (): WP_REST_Response {
                    return new WP_REST_Response(
                        [
                            'layout' => yooadmin_studio_hub_get_user_layout(),
                        ],
                        200
                    );
                },
            ],
            [
                'methods'             => 'DELETE',
                'permission_callback' => static function (): bool {
                    return is_user_logged_in() && current_user_can(yooadmin_studio_hub_layout_capability());
                },
                'callback'            => static function (): WP_REST_Response {
                    yooadmin_studio_hub_delete_user_layout();

                    return new WP_REST_Response(['deleted' => true], 200);
                },
            ],
            [
                'methods'             => 'POST',
                'permission_callback' => static function (): bool {
                    return is_user_logged_in() && current_user_can(yooadmin_studio_hub_layout_capability());
                },
                'callback'            => static function (WP_REST_Request $request) {
                    $params = $request->get_json_params();
                    $raw    = is_array($params) && isset($params['layout']) ? $params['layout'] : $params;
                    $layout = yooadmin_studio_hub_normalize_layout_payload(is_array($raw) ? $raw : null);
                    if ($layout === null) {
                        return new WP_Error(
                            'invalid_layout',
                            __('Invalid layout data.', 'yooadmin'),
                            ['status' => 400]
                        );
                    }
                    if (!yooadmin_studio_hub_save_user_layout($layout)) {
                        return new WP_Error(
                            'save_failed',
                            __('Could not save layout.', 'yooadmin'),
                            ['status' => 500]
                        );
                    }

                    return new WP_REST_Response(['saved' => true], 200);
                },
            ],
        ]
    );

    register_rest_route(
        'yooadmin/v1',
        '/studio-hub/layout/visibility',
        [
            [
                'methods'             => 'POST',
                'permission_callback' => static function (): bool {
                    return is_user_logged_in() && current_user_can(yooadmin_studio_hub_layout_capability());
                },
                'callback'            => static function (WP_REST_Request $request) {
                    $params = $request->get_json_params();
                    if (!is_array($params)) {
                        $params = [];
                    }
                    $hidden = isset($params['hiddenSections']) && is_array($params['hiddenSections'])
                        ? $params['hiddenSections']
                        : [];
                    $saved_at = isset($params['savedAt']) ? (int) $params['savedAt'] : 0;

                    if (!yooadmin_studio_hub_patch_layout_visibility($hidden, $saved_at)) {
                        return new WP_Error(
                            'save_failed',
                            __('Could not save layout visibility.', 'yooadmin'),
                            ['status' => 500]
                        );
                    }

                    return new WP_REST_Response(['saved' => true], 200);
                },
            ],
        ]
    );
}
