<?php
/**
 * Studio Hub — native themes.php / theme-install.php cascade.
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Native WordPress themes list / install screens.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_themes_php_page(): bool {
    if (!is_admin()) {
        return false;
    }

    global $pagenow;

    return isset($pagenow) && in_array($pagenow, ['themes.php', 'theme-install.php'], true);
}

/**
 * Dark + layout cascade tail after yp-admin-core + wp-admin themes.css.
 */
function yooadmin_studio_hub_enqueue_themes_php_dark_tail(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_themes_php_page()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-themes-php-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $deps = ['yooadmin-studio-hub-late'];
    foreach (['yooadmin-core', 'themes'] as $handle) {
        if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
            $deps[] = $handle;
        }
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-themes-php-dark',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-themes-php-dark.css'),
        array_values(array_unique($deps)),
        (string) filemtime($file)
    );
}

/**
 * Critical overlay stacking (first paint when opening theme details).
 */
function yooadmin_studio_hub_print_themes_php_critical(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_themes_php_page()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-themes-php-critical">'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open .theme-overlay,'
        . 'body.yooadmin-network-admin-shell.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open .theme-overlay{'
        . 'position:fixed!important;inset:0!important;z-index:110000!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open .theme-overlay .theme-wrap,'
        . 'body.yooadmin-network-admin-shell.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open'
        . ' .theme-overlay .theme-wrap{'
        . 'z-index:110001!important;'
        . 'top:calc(var(--yp-header-h,64px) + var(--yp-bc-h,48px) + 12px)!important;'
        . 'bottom:max(72px,calc(40px + env(safe-area-inset-bottom,0px)))!important;'
        . 'left:50%!important;right:auto!important;transform:translateX(-50%)!important;'
        . 'width:min(calc(100vw - 32px),var(--ysh-layout-max,1400px))!important;'
        . 'max-width:var(--ysh-layout-max,1400px)!important;margin:0!important;box-sizing:border-box!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php) #wpbody-content>.wrap{'
        . 'overflow:visible!important;}'
        . '</style>' . "\n";
}

/**
 * Re-link themes.php tail late in <head>.
 */
function yooadmin_studio_hub_print_themes_php_cascade_tail(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_themes_php_page()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-themes-php-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-themes-php-dark.css');
    $ver = (string) filemtime($file);
    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Late cascade tail must load after wp-admin themes.css in <head>.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-themes-php-cascade-tail" href="%s" />' . "\n",
        esc_url(add_query_arg('ver', $ver, $url))
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

/**
 * Footer rules — beats late wp-admin styles in <head>.
 */
function yooadmin_studio_hub_print_themes_php_footer_dark(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_themes_php_page()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-themes-php-footer">'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php) #wpbody-content>.wrap:last-child{'
        . 'margin-bottom:56px!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php) #wpbody-content{'
        . 'padding-bottom:72px!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open .theme-overlay .theme-wrap,'
        . 'body.yooadmin-network-admin-shell.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open'
        . ' .theme-overlay .theme-wrap{'
        . 'left:50%!important;right:auto!important;transform:translateX(-50%)!important;'
        . 'width:min(calc(100vw - 32px),var(--ysh-layout-max,1400px))!important;'
        . 'max-width:var(--ysh-layout-max,1400px)!important;'
        . 'top:calc(var(--yp-header-h,64px) + var(--yp-bc-h,48px) + 12px)!important;'
        . 'bottom:max(72px,calc(40px + env(safe-area-inset-bottom,0px)))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open'
        . ' .theme-overlay .theme-wrap,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]'
        . ' body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open .theme-overlay .theme-wrap{'
        . 'background:var(--ysh-card,#1a1d23)!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open'
        . ' .theme-overlay .theme-header,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]'
        . ' body.yooadmin-theme-yooadmin-studio-hub:is(.themes-php,.theme-install-php).modal-open .theme-overlay .theme-header{'
        . 'background:#343b44!important;border-bottom-color:rgba(255,255,255,.12)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.theme-install-php'
        . ' .theme-install-overlay :is(.wp-full-overlay-sidebar,.wp-full-overlay-main,.wp-full-overlay-header,.wp-full-overlay-footer),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]'
        . ' body.yooadmin-theme-yooadmin-studio-hub.theme-install-php'
        . ' .theme-install-overlay :is(.wp-full-overlay-sidebar,.wp-full-overlay-main,.wp-full-overlay-header,.wp-full-overlay-footer){'
        . 'background:#1a1d23!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.theme-install-php'
        . ' .theme-install-overlay :is(.close-full-overlay,.previous-theme,.next-theme),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]'
        . ' body.yooadmin-theme-yooadmin-studio-hub.theme-install-php'
        . ' .theme-install-overlay :is(.close-full-overlay,.previous-theme,.next-theme){'
        . 'background:#343b44!important;border-color:rgba(255,255,255,.12)!important;color:#9aa5b1!important;}'
        . '</style>' . "\n";
}
