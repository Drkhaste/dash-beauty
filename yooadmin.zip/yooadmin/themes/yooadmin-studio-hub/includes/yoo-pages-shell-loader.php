<?php
/**
 * Studio Hub — YOOAdmin-styled page shell loader (plugins.php, plugin-install.php).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * @return bool
 */
function yooadmin_studio_hub_should_show_yoo_pages_shell_loader(): bool {
    if (!is_admin() || !function_exists('yooadmin_studio_hub_is_focus_enabled') || !yooadmin_studio_hub_is_focus_enabled()) {
        return false;
    }

    if (function_exists('yooadmin_studio_hub_should_style_plugins_php_experience')
        && yooadmin_studio_hub_should_style_plugins_php_experience()) {
        return true;
    }

    if (function_exists('yooadmin_studio_hub_should_style_plugin_install_layout')
        && yooadmin_studio_hub_should_style_plugin_install_layout()) {
        return true;
    }

    return false;
}

/**
 * Critical CSS — show loader while layout JS reshapes the page.
 */
function yooadmin_studio_hub_print_yoo_pages_shell_loader_critical(): void {
    if (!yooadmin_studio_hub_should_show_yoo_pages_shell_loader()) {
        return;
    }

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static critical CSS.
    echo '<style id="yooadmin-studio-hub-yoo-pages-shell-loader-critical">'
        . '.ysh-yoo-pages-shell-loader{position:fixed;top:0;right:0;bottom:0;left:0;width:100vw;height:100vh;z-index:100150;box-sizing:border-box;display:none;flex-direction:row;align-items:center;justify-content:center;background:transparent;pointer-events:none;}'
        . '.ysh-yoo-pages-shell-loader.is-visible{display:flex!important;}'
        . 'html.yoo-plugins-layout-pending #ysh-yoo-pages-shell-loader,'
        . 'html.yoo-plugin-install-layout-pending #ysh-yoo-pages-shell-loader{'
        . 'display:flex!important;}'
        . '.ysh-yoo-pages-shell-loader__panel{box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;min-width:220px;max-width:min(92vw,360px);padding:28px 36px;pointer-events:auto;border-radius:12px;background:var(--ysh-card,#1a1d23);border:1px solid rgba(255,255,255,.12);box-shadow:0 24px 64px rgba(0,0,0,.45);}'
        . '.ysh-yoo-pages-shell-loader__text{margin:0;font-size:14px;line-height:1.45;text-align:center;white-space:normal;color:var(--ysh-muted,#9aa3b2);}'
        . '.ysh-yoo-pages-shell-loader__ring{flex:0 0 auto;width:40px;height:40px;border:3px solid rgba(255,255,255,.12);border-top-color:var(--yp-primary,#eda934);border-radius:50%;animation:ysh-yoo-pages-shell-spin .8s linear infinite;}'
        . '.ysh-yoo-pages-shell-loader .yp-loading-spinner{display:flex!important;flex:0 0 auto;align-items:center;justify-content:center;padding:0!important;min-height:0!important;margin:0!important;}'
        . '.ysh-yoo-pages-shell-loader .yp-spinner-circle{width:40px;height:40px;margin:0!important;border:3px solid rgba(255,255,255,.12);border-top-color:var(--yp-primary,#eda934);border-radius:50%;animation:ysh-yoo-pages-shell-spin .8s linear infinite;}'
        . '@keyframes ysh-yoo-pages-shell-spin{to{transform:rotate(360deg);}}'
        . 'html.yoo-plugins-layout-pending body.plugins-php.yooadmin-plugins-page #wpbody-content>.wrap:not(.yoo-plugins-layout-ready)>:not(#ysh-yoo-pages-shell-loader){display:none!important;}'
        . 'html.yoo-plugins-layout-pending body.plugins-php.yooadmin-plugins-page #wpbody-content>.wrap:not(.yoo-plugins-layout-ready){visibility:visible!important;min-height:260px;}'
        . 'html.yoo-plugin-install-layout-pending:not(.yoo-plugin-install-ui-ready) body.plugin-install-php #wpbody-content>.wrap:not(.yoo-plugin-install-layout-ready)>:not(#ysh-yoo-pages-shell-loader){display:none!important;}'
        . 'html.yoo-plugin-install-layout-pending:not(.yoo-plugin-install-ui-ready) body.plugin-install-php #wpbody-content>.wrap:not(.yoo-plugin-install-layout-ready){visibility:visible!important;min-height:260px;}'
        . 'html.yoo-plugins-layout-pending body.plugins-php.yooadmin-plugins-page #ysh-yoo-pages-shell-loader,'
        . 'html.yoo-plugin-install-layout-pending:not(.yoo-plugin-install-ui-ready) body.plugin-install-php #ysh-yoo-pages-shell-loader{position:static!important;width:100%!important;height:auto!important;min-height:220px!important;margin:16px 0!important;z-index:auto!important;background:transparent!important;pointer-events:none!important;}'
        . 'html.yoo-plugin-install-layout-pending:not(.yoo-plugin-install-ui-ready):is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.plugin-install-php #ysh-yoo-pages-shell-loader,'
        . 'html.yoo-plugin-install-layout-pending:not(.yoo-plugin-install-ui-ready).yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.plugin-install-php #ysh-yoo-pages-shell-loader{background:rgba(10,12,16,.58)!important;backdrop-filter:blur(10px) saturate(120%)!important;-webkit-backdrop-filter:blur(10px) saturate(120%)!important;border-radius:12px!important;}'
        . 'html.yoo-plugins-layout-pending body.plugins-php.yooadmin-plugins-page #ysh-yoo-pages-shell-loader .ysh-yoo-pages-shell-loader__panel,'
        . 'html.yoo-plugin-install-layout-pending:not(.yoo-plugin-install-ui-ready) body.plugin-install-php #ysh-yoo-pages-shell-loader .ysh-yoo-pages-shell-loader__panel{min-width:0!important;max-width:none!important;padding:0!important;background:transparent!important;border:0!important;box-shadow:none!important;pointer-events:none!important;}'
        . 'html.yoo-plugin-install-layout-pending:not(.yoo-plugin-install-ui-ready):is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.plugin-install-php #ysh-yoo-pages-shell-loader .ysh-yoo-pages-shell-loader__text,'
        . 'html.yoo-plugin-install-layout-pending:not(.yoo-plugin-install-ui-ready).yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.plugin-install-php #ysh-yoo-pages-shell-loader .ysh-yoo-pages-shell-loader__text{color:#f8fafc!important;font-weight:600!important;text-shadow:0 1px 3px rgba(0,0,0,.62)!important;}'
        . 'html.yoo-plugins-layout-pending body.plugins-php.yooadmin-plugins-page #ysh-yoo-pages-shell-loader .ysh-yoo-pages-shell-loader__ring,'
        . 'html.yoo-plugin-install-layout-pending:not(.yoo-plugin-install-ui-ready) body.plugin-install-php #ysh-yoo-pages-shell-loader .ysh-yoo-pages-shell-loader__ring{width:28px!important;height:28px!important;}'
        . 'html.yoo-plugins-layout-pending body.plugins-php.yooadmin-plugins-page #wpbody-content>.wrap.yoo-plugins-layout-ready,'
        . 'html.yoo-plugin-install-ui-ready body.plugin-install-php #wpbody-content>.wrap.yoo-plugin-install-layout-ready{'
        . 'visibility:visible!important;}'
        . 'body.yoo-plugins-page.is-yoo-plugins-page-loading .yoo-pages-content-section{pointer-events:none;}'
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Loader markup + tiny API for JS (show/hide during AJAX).
 */
function yooadmin_studio_hub_print_yoo_pages_shell_loader_markup(): void {
    if (!yooadmin_studio_hub_should_show_yoo_pages_shell_loader()) {
        return;
    }

    $label = __('Loading…', 'yooadmin');
    if (function_exists('yooadmin_studio_hub_should_style_plugins_php_experience')
        && yooadmin_studio_hub_should_style_plugins_php_experience()
        && function_exists('yooadmin_studio_hub_should_style_plugin_install_layout')
        && !yooadmin_studio_hub_should_style_plugin_install_layout()) {
        $label = __('Loading plugins…', 'yooadmin');
    } elseif (function_exists('yooadmin_studio_hub_should_style_plugin_install_layout')
        && yooadmin_studio_hub_should_style_plugin_install_layout()) {
        $label = __('Loading plugin directory…', 'yooadmin');
    }

    echo '<div id="ysh-yoo-pages-shell-loader" class="ysh-yoo-pages-shell-loader" hidden aria-hidden="true">'
        . '<div class="ysh-yoo-pages-shell-loader__panel" role="status" aria-live="polite">'
        . '<span class="ysh-yoo-pages-shell-loader__ring" aria-hidden="true"></span>'
        . '<p class="ysh-yoo-pages-shell-loader__text" data-yoo-pages-shell-loader-text>'
        . esc_html($label)
        . '</p></div></div>';

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Inline loader API; label from wp_json_encode().
    echo '<script id="yooadmin-studio-hub-yoo-pages-shell-loader-api">'
        . '(function(){'
        . 'var el=document.getElementById("ysh-yoo-pages-shell-loader");'
        . 'function mountLoader(){if(!el){return;}var wrap=document.querySelector("body.plugins-php #wpbody-content>.wrap,body.plugin-install-php #wpbody-content>.wrap");var target=wrap||document.body;if(target&&el.parentNode!==target){target.appendChild(el);}}'
        . 'var textEl=el&&el.querySelector("[data-yoo-pages-shell-loader-text]");'
        . 'function show(msg){'
        . 'if(!el){return;}'
        . 'if(msg&&textEl){textEl.textContent=msg;}'
        . 'el.removeAttribute("hidden");el.setAttribute("aria-hidden","false");el.classList.add("is-visible");'
        . 'document.documentElement.classList.add("yoo-yoo-pages-shell-loading");}'
        . 'function hide(){'
        . 'if(!el){return;}'
        . 'el.setAttribute("hidden","");el.setAttribute("aria-hidden","true");el.classList.remove("is-visible");'
        . 'document.documentElement.classList.remove("yoo-yoo-pages-shell-loading");}'
        . 'function pending(){var h=document.documentElement;return h.classList.contains("yoo-plugins-layout-pending")||h.classList.contains("yoo-plugin-install-layout-pending");}'
        . 'function boot(){mountLoader();if(pending()){show();}}'
        . 'if(document.body){boot();}else{document.addEventListener("DOMContentLoaded",boot,{once:true});}'
        . 'document.addEventListener("DOMContentLoaded",boot,{once:true});'
        . 'setTimeout(boot,50);'
        . 'window.yooadminYooPagesShellLoader={show:show,hide:hide,el:el};'
        . '})();</script>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}
