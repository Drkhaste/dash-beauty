<?php
/**
 * Studio Hub — woocommerce / wc-settings
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * WooCommerce Settings — critical CSS + pending flag in <head> (first paint = new design).
 */
function yooadmin_studio_hub_print_wc_settings_chrome(): void {
    if (!yooadmin_studio_hub_wc_settings_studio_active()) {
        return;
    }

    if (yooadmin_studio_hub_wc_settings_uses_classic_pending()) {
        echo '<script id="yooadmin-studio-hub-wc-settings-pending">document.documentElement.classList.add("ysh-wc-settings-pending");</script>' . "\n";
    }

    $critical = yooadmin_studio_hub_asset_path('css/compat/wc-settings-critical.css');
    if (is_readable($critical)) {
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS, no user input.
        echo '<style id="yooadmin-studio-hub-wc-settings-critical">' . file_get_contents($critical) . '</style>' . "\n";
    }
}

/**
 * Classic layout DOM wrap before visible settings body (pairs with critical pending CSS).
 */
function yooadmin_studio_hub_print_wc_settings_boot(): void {
    if (!yooadmin_studio_hub_wc_settings_studio_active()) {
        return;
    }

    $boot = yooadmin_studio_hub_asset_path('js/compat/wc-settings-boot.js');
    if (!is_readable($boot)) {
        return;
    }

    $js = file_get_contents($boot);
    if ($js === false || $js === '') {
        return;
    }

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme JS.
    echo '<script id="yooadmin-studio-hub-wc-settings-boot">' . $js . '</script>' . "\n";

    yooadmin_studio_hub_print_wc_settings_guard();
}

/**
 * Unsaved-changes modal (replaces Woo native beforeunload dialog).
 */
function yooadmin_studio_hub_print_wc_settings_guard(): void {
    $guard = yooadmin_studio_hub_asset_path('js/compat/wc-settings-guard.js');
    if (!is_readable($guard)) {
        return;
    }

    $l10n = [
        'title'   => __('Unsaved changes', 'yooadmin'),
        'message' => __(
            'The changes you made may not be saved if you leave this page.',
            'yooadmin'
        ),
        'stay'    => __('Stay on this page', 'yooadmin'),
        'leave'   => __('Leave without saving', 'yooadmin'),
    ];

    echo '<script>window.yshWcSettingsGuard=' . wp_json_encode($l10n) . ';</script>' . "\n";

    $js = file_get_contents($guard);
    if ($js === false || $js === '') {
        return;
    }

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme JS.
    echo '<script id="yooadmin-studio-hub-wc-settings-guard">' . $js . '</script>' . "\n";
}

/**
 * React mount node for Site visibility when Woo skips classic field output.
 */
function yooadmin_studio_hub_ensure_site_visibility_slotfill(): void {
    if (!yooadmin_studio_hub_wc_settings_studio_active()) {
        return;
    }

    if (
        class_exists('\Automattic\WooCommerce\Admin\Features\Features')
        && \Automattic\WooCommerce\Admin\Features\Features::is_enabled('settings')
    ) {
        echo '<div id="wc_settings_site_visibility_slotfill"></div>';
    }
}

function yooadmin_studio_hub_guard_site_visibility_slotfill(): void {
    if (!yooadmin_studio_hub_wc_settings_studio_active()) {
        return;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : '';
    if ('site-visibility' !== $tab) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-site-visibility-slotfill-guard">(function(){var id="wc_settings_site_visibility_slotfill";if(document.getElementById(id)){return;}var f=document.getElementById("mainform");if(!f){return;}var d=document.createElement("div");d.id=id;var submit=f.querySelector("p.submit");if(submit){f.insertBefore(d,submit);}else{f.appendChild(d);}})();</script>' . "\n";
}

