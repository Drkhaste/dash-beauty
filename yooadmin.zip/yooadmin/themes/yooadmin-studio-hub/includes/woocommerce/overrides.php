<?php
/**
 * Studio Hub — woocommerce / overrides
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Enqueue Woo overrides in <head> (manifest + footer tail load too late for wc-admin first paint).
 */
function yooadmin_studio_hub_enqueue_woo_overrides_early(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_wc_settings_studio_active() && !yooadmin_studio_hub_is_wc_admin_screen()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/woocommerce-studio-overrides.css');
    if (!is_readable($file)) {
        return;
    }

    $url  = yooadmin_studio_hub_asset_url('css/compat/woocommerce-studio-overrides.css');
    $deps = ['yooadmin-studio-hub-late'];
    if (wp_style_is('yooadmin-studio-hub-dashboard', 'registered')) {
        $deps[] = 'yooadmin-studio-hub-dashboard';
    }
    if (wp_style_is('wc-admin-app', 'registered')) {
        $deps[] = 'wc-admin-app';
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-woo-early',
        $url,
        $deps,
        (string) filemtime($file)
    );
}

/**
 * Re-link Woo overrides last in <head> after wc-admin chunk CSS injects (studio-hub.js may move again).
 */
function yooadmin_studio_hub_print_woo_overrides_cascade_tail(): void {
    if (!is_admin() || !yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!function_exists('yooadmin_is_wc_screen') || !yooadmin_is_wc_screen()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/woocommerce-studio-overrides.css');
    if (!is_readable($file)) {
        return;
    }

    $url = yooadmin_studio_hub_asset_url('css/compat/woocommerce-studio-overrides.css');
    $ver = (string) filemtime($file);
    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Late cascade tail must load after WooCommerce in <head>.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-woo-cascade-tail" href="%s" />' . "\n",
        esc_url(add_query_arg('ver', $ver, $url))
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

