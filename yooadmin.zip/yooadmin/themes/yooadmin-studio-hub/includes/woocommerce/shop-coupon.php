<?php
/**
 * Studio Hub — woocommerce / shop-coupon
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Coupons list (edit.php?post_type=shop_coupon) — critical layout + dark shell in <head>.
 */
function yooadmin_studio_hub_print_shop_coupon_list_critical(): void {
    if (!yooadmin_studio_hub_shop_coupon_list_studio_active()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-shop-coupon-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-shop_coupon.edit-php){background:#0b0d11!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php #wpwrap,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php #wpcontent,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php #wpbody,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php #wpbody-content,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php .yoo-shell-content{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;padding-left:0!important;padding-right:0!important;overflow-x:clip!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php .yoo-shell-content{'
        . 'max-width:var(--ysh-layout-max,1400px)!important;margin-inline:auto!important;}'
        . 'body.yoo-focus.wp-admin.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php #wpbody-content>.wrap{'
        . 'width:100%!important;max-width:min(var(--ysh-layout-max,1400px),100%)!important;margin-left:auto!important;margin-right:auto!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php'
        . ' :is(#wpwrap,#wpcontent,#wpbody,#wpbody-content,.yoo-shell-content){background:#0b0d11!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.wp-admin.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php'
        . ' #wpbody-content>.wrap{background:transparent!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php'
        . ' .yp-breadcrumbs-bar{background:#0b0d11!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php #wpbody-content>.wrap>hr.wp-header-end{'
        . 'display:none!important;height:0!important;margin:0!important;border:none!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php .yp-breadcrumbs-bar{'
        . 'border-top:none!important;border-bottom:none!important;box-shadow:none!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php #wpbody-content{'
        . 'padding-top:0!important;margin-top:0!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-shop_coupon.edit-php #wpbody-content>.wrap{'
        . 'margin-top:0!important;padding-top:16px!important;box-shadow:none!important;border-top:none!important;'
        . 'display:block!important;padding-block-start:16px!important;}'
        . '</style>' . "\n";
}

/**
 * Coupons list — last cascade in <head>.
 */
function yooadmin_studio_hub_print_shop_coupon_list_cascade_tail(): void {
    if (!yooadmin_studio_hub_shop_coupon_list_studio_active()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-shop-coupon-tail">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-shop_coupon.edit-php),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-shop_coupon.edit-php) body,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-shop_coupon.edit-php) #wpwrap,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-shop_coupon.edit-php) #wpcontent{'
        . 'background:#0b0d11!important;background-color:#0b0d11!important;'
        . 'scrollbar-color:rgba(255,255,255,.2) #0b0d11!important;}'
        . 'html:has(body.post-type-shop_coupon.edit-php),html:has(body.post-type-shop_coupon.edit-php) body{'
        . 'overflow-x:hidden!important;max-width:100%!important;}'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php #wpwrap{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;overflow-x:hidden!important;}'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php #wpcontent,'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php.folded #wpcontent,'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php.auto-fold #wpcontent,'
        . 'body.yp-clean-view.post-type-shop_coupon.edit-php #wpcontent{'
        . 'width:100%!important;max-width:none!important;min-width:0!important;'
        . 'margin:0!important;margin-left:0!important;margin-right:0!important;'
        . 'padding-left:0!important;padding-right:0!important;float:none!important;}'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php #wpbody,'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php #wpbody-content,'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php .yoo-shell-content{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;margin-inline:0!important;'
        . 'margin-top:0!important;padding-top:0!important;padding-inline:0!important;'
        . 'overflow-x:clip!important;box-sizing:border-box!important;}'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php #wpcontent #wpbody-content>.wrap{'
        . 'display:block!important;margin-top:0!important;padding-block-start:16px!important;box-shadow:none!important;}'
        . 'html[dir=rtl] body.yoo-focus.post-type-shop_coupon.edit-php #wpcontent{'
        . 'margin-right:0!important;margin-left:0!important;float:none!important;}'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php #adminmenuback,'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php #adminmenuwrap,'
        . 'body.yoo-focus.post-type-shop_coupon.edit-php #adminmenumain{display:none!important;}'
        . '</style>' . "\n";
}

/**
 * Coupons list — force full-width shell.
 */
function yooadmin_studio_hub_print_shop_coupon_list_layout_fix_script(): void {
    if (!yooadmin_studio_hub_shop_coupon_list_studio_active()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-shop-coupon-layout-fix">'
        . '(function(){'
        . 'function yshShopCouponLayout(){'
        . 'var w=document.getElementById("wpwrap"),c=document.getElementById("wpcontent"),b=document.getElementById("wpbody"),'
        . 'bc=document.getElementById("wpbody-content"),s=document.querySelector(".yoo-shell-content"),'
        . 'ab=document.getElementById("adminmenuback"),aw=document.getElementById("adminmenuwrap"),am=document.getElementById("adminmenumain");'
        . 'var dark=document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";'
        . '[w,c,b,bc,s].forEach(function(el){if(!el)return;el.style.setProperty("width","100%","important");'
        . 'el.style.setProperty("max-width","100%","important");el.style.setProperty("margin-left","0","important");'
        . 'el.style.setProperty("margin-right","0","important");el.style.setProperty("padding-left","0","important");'
        . 'el.style.setProperty("padding-right","0","important");'
        . 'if(dark){el.style.setProperty("background","#0b0d11","important");el.style.setProperty("background-color","#0b0d11","important");}});'
        . 'document.documentElement.style.setProperty("overflow-x","hidden","important");'
        . 'document.body.style.setProperty("overflow-x","hidden","important");'
        . 'if(dark){document.documentElement.style.setProperty("background","#0b0d11","important");'
        . 'document.body.style.setProperty("background","#0b0d11","important");}'
        . 'if(s){s.style.setProperty("max-width","min(1400px, 100%)","important");s.style.setProperty("margin-inline","auto","important");}'
        . '[ab,aw,am].forEach(function(el){if(el)el.style.setProperty("display","none","important");});'
        . 'var wrap=bc&&bc.querySelector(":scope > .wrap");'
        . 'if(wrap){wrap.style.setProperty("width","100%","important");wrap.style.setProperty("max-width","min(1400px, 100%)","important");'
        . 'wrap.style.setProperty("margin-left","auto","important");wrap.style.setProperty("margin-right","auto","important");'
        . 'wrap.style.setProperty("margin-top","0","important");wrap.style.setProperty("display","block","important");'
        . 'wrap.style.setProperty("padding-block-start","16px","important");wrap.style.setProperty("border","none","important");wrap.style.setProperty("box-shadow","none","important");'
        . 'if(dark){wrap.style.setProperty("background","transparent","important");wrap.style.setProperty("background-color","transparent","important");}}'
        . 'var hrEnd=wrap&&wrap.querySelector("hr.wp-header-end");'
        . 'if(hrEnd){hrEnd.style.setProperty("display","none","important");hrEnd.style.setProperty("border","none","important");}'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",yshShopCouponLayout);}else{yshShopCouponLayout();}'
        . 'window.addEventListener("load",yshShopCouponLayout);'
        . '})();'
        . '</script>' . "\n";
}

