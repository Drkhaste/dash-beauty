<?php
/**
 * Studio Hub — woocommerce / wc-reports
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * WooCommerce legacy reports — dedicated assets.
 */
function yooadmin_studio_hub_enqueue_wc_reports_assets(): void {
    if (!yooadmin_studio_hub_wc_reports_studio_active()) {
        return;
    }

    $css = yooadmin_studio_hub_asset_path('css/compat/wc-reports.css');
    $js  = yooadmin_studio_hub_asset_path('js/compat/wc-reports.js');

    $deps = ['yooadmin-studio-hub-late'];
    if (wp_style_is('yooadmin-studio-hub-dashboard', 'registered')) {
        $deps[] = 'yooadmin-studio-hub-dashboard';
    }

    if (is_readable($css)) {
        wp_enqueue_style(
            'yooadmin-studio-hub-wc-reports',
            yooadmin_studio_hub_asset_url('css/compat/wc-reports.css'),
            $deps,
            (string) filemtime($css)
        );
    }

    if (is_readable($js)) {
        wp_enqueue_script(
            'yooadmin-studio-hub-wc-reports',
            yooadmin_studio_hub_asset_url('js/compat/wc-reports.js'),
            ['jquery'],
            (string) filemtime($js),
            true
        );
    }
}

/**
 * @param string $classes
 * @return string
 */
function yooadmin_studio_hub_filter_wc_reports_body_class(string $classes): string {
    if (yooadmin_studio_hub_wc_reports_studio_active()) {
        $classes .= ' ysh-wc-reports-active';
    }

    return $classes;
}

/**
 * Patch jQuery.plot before inline report scripts run (prevents width=0 Flot error).
 */
function yooadmin_studio_hub_print_wc_reports_flot_patch(): void {
    if (!yooadmin_studio_hub_wc_reports_studio_active()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-wc-reports-flot-patch">'
        . '(function(){function patch(){if(!window.jQuery||!jQuery.plot||jQuery.plot.__yshWcReportsPatched){return false;}'
        . 'var o=jQuery.plot;jQuery.plot=function(p,d,opt){var el=jQuery(p);if(el.length&&el.width()<10){'
        . 'el.css({width:"100%",minWidth:"280px",display:"block"});'
        . 'var m=el.closest(".main");if(m.length){m.css({flex:"1 1 auto",minWidth:0,width:"100%"});}}'
        . 'return o.apply(this,arguments);};jQuery.plot.__yshWcReportsPatched=true;return true;}'
        . 'if(!patch()){var n=0,t=setInterval(function(){if(patch()||++n>40){clearInterval(t);}},50);}})();'
        . '</script>' . "\n";
}

/**
 * Reports (admin.php?page=wc-reports) — critical layout + dark shell in <head>.
 */
function yooadmin_studio_hub_print_wc_reports_critical(): void {
    if (!yooadmin_studio_hub_wc_reports_studio_active()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-wc-reports-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)){background:#0b0d11!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpwrap,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpcontent,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpbody,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpbody-content,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) .yoo-shell-content{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;padding-left:0!important;padding-right:0!important;overflow-x:clip!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) .yoo-shell-content{'
        . 'max-width:var(--ysh-layout-max,1400px)!important;margin-inline:auto!important;}'
        . 'body.yoo-focus.wp-admin.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpbody-content>.wrap{'
        . 'width:100%!important;max-width:min(var(--ysh-layout-max,1400px),100%)!important;margin-left:auto!important;margin-right:auto!important;}'
        . 'body.ysh-wc-reports-active .chart-placeholder.main{width:100%!important;min-width:300px!important;height:400px!important;display:block!important;}'
        . 'body.ysh-wc-reports-active .inside.chart-with-sidebar{display:flex!important;width:100%!important;}'
        . 'body.ysh-wc-reports-active .chart-with-sidebar .main{flex:1 1 auto!important;min-width:0!important;width:100%!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)'
        . ' :is(#wpwrap,#wpcontent,#wpbody,#wpbody-content,.yoo-shell-content){background:#0b0d11!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.wp-admin.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)'
        . ' #wpbody-content>.wrap{background:transparent!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)'
        . ' .yp-breadcrumbs-bar{background:#0b0d11!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpbody-content>.wrap>hr.wp-header-end{'
        . 'display:none!important;height:0!important;margin:0!important;border:none!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) .yp-breadcrumbs-bar{'
        . 'border-top:none!important;border-bottom:none!important;box-shadow:none!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpbody-content{'
        . 'padding-top:0!important;margin-top:0!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpbody-content>.wrap{'
        . 'margin-top:0!important;padding-top:16px!important;box-shadow:none!important;border-top:none!important;'
        . 'display:block!important;padding-block-start:16px!important;}'
        . '</style>' . "\n";
}

/**
 * Reports — last cascade in <head> (beats core RTL admin-menu margins on #wpcontent).
 */
function yooadmin_studio_hub_print_wc_reports_cascade_tail(): void {
    if (!yooadmin_studio_hub_wc_reports_studio_active()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-wc-reports-tail">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)) body,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)) #wpwrap,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)) #wpcontent{'
        . 'background:#0b0d11!important;background-color:#0b0d11!important;'
        . 'scrollbar-color:rgba(255,255,255,.2) #0b0d11!important;}'
        . 'html:has(body:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)),html:has(body:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports)) body{'
        . 'overflow-x:hidden!important;max-width:100%!important;}'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpwrap{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;overflow-x:hidden!important;}'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpcontent,'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports).folded #wpcontent,'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports).auto-fold #wpcontent,'
        . 'body.yp-clean-view:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpcontent{'
        . 'width:100%!important;max-width:none!important;min-width:0!important;'
        . 'margin:0!important;margin-left:0!important;margin-right:0!important;'
        . 'padding-left:0!important;padding-right:0!important;float:none!important;}'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpbody,'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpbody-content,'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) .yoo-shell-content{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;margin-inline:0!important;'
        . 'margin-top:0!important;padding-top:0!important;padding-inline:0!important;'
        . 'overflow-x:clip!important;box-sizing:border-box!important;}'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) .woocommerce-reports-wrap,'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) .woocommerce-reports-wide{'
        . 'margin-left:0!important;width:100%!important;max-width:100%!important;}'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpcontent #wpbody-content>.wrap{'
        . 'display:block!important;margin-top:0!important;padding-block-start:16px!important;box-shadow:none!important;}'
        . 'html[dir=rtl] body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #wpcontent{'
        . 'margin-right:0!important;margin-left:0!important;float:none!important;}'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #adminmenuback,'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #adminmenuwrap,'
        . 'body.yoo-focus:is(.woocommerce_page_wc-reports,.toplevel_page_wc-reports) #adminmenumain{display:none!important;}'
        . '</style>' . "\n";
}

/**
 * Reports — force full-width shell (beats late WP / plugin margin-left on #wpcontent).
 */
function yooadmin_studio_hub_print_wc_reports_layout_fix_script(): void {
    if (!yooadmin_studio_hub_wc_reports_studio_active()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-wc-reports-layout-fix">'
        . '(function(){'
        . 'function yshWcReportsLayout(){'
        . 'var w=document.getElementById("wpwrap"),c=document.getElementById("wpcontent"),b=document.getElementById("wpbody"),'
        . 'bc=document.getElementById("wpbody-content"),s=document.querySelector(".yoo-shell-content"),'
        . 'ab=document.getElementById("adminmenuback"),aw=document.getElementById("adminmenuwrap"),am=document.getElementById("adminmenumain");'
        . 'var dark=document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";'
        . '[w,c,b,bc,s].forEach(function(el){if(!el)return;el.style.setProperty("width","100%","important");'
        . 'el.style.setProperty("max-width","100%","important");el.style.setProperty("margin-left","0","important");'
        . 'el.style.setProperty("margin-right","0","important");el.style.setProperty("padding-left","0","important");'
        . 'el.style.setProperty("padding-right","0","important");'
        . 'if(dark){el.style.setProperty("background","#0b0d11","important");el.style.setProperty("background-color","#0b0d11","important");}});'
        . 'document.documentElement.style.setProperty("overflow-x","hidden","important");'
        . 'document.body.style.setProperty("overflow-x","hidden","important");'
        . 'if(dark){document.documentElement.style.setProperty("background","#0b0d11","important");'
        . 'document.body.style.setProperty("background","#0b0d11","important");}'
        . 'if(s){s.style.setProperty("max-width","min(1400px, 100%)","important");s.style.setProperty("margin-inline","auto","important");}'
        . '[ab,aw,am].forEach(function(el){if(el)el.style.setProperty("display","none","important");});'
        . 'var wrap=bc&&bc.querySelector(":scope > .wrap");'
        . 'if(wrap){wrap.style.setProperty("width","100%","important");wrap.style.setProperty("max-width","min(1400px, 100%)","important");'
        . 'wrap.style.setProperty("margin-left","auto","important");wrap.style.setProperty("margin-right","auto","important");'
        . 'wrap.style.setProperty("margin-top","0","important");wrap.style.setProperty("display","block","important");'
        . 'wrap.style.setProperty("padding-block-start","16px","important");wrap.style.setProperty("border","none","important");wrap.style.setProperty("box-shadow","none","important");'
        . 'if(dark){wrap.style.setProperty("background","transparent","important");wrap.style.setProperty("background-color","transparent","important");}}'
        . 'document.querySelectorAll(".woocommerce-reports-wide,.woocommerce-reports-wrap").forEach(function(el){'
        . 'el.style.setProperty("margin-left","0","important");el.style.setProperty("width","100%","important");el.style.setProperty("max-width","100%","important");el.style.setProperty("float","none","important");});'
        . 'var ph=document.querySelector(".chart-placeholder.main");if(ph){ph.style.setProperty("width","100%","important");ph.style.setProperty("min-width","280px","important");}'
        . 'var main=document.querySelector(".chart-with-sidebar .main");if(main){main.style.setProperty("flex","1 1 auto","important");main.style.setProperty("min-width","0","important");main.style.setProperty("width","100%","important");}'
        . 'var hrEnd=wrap&&wrap.querySelector("hr.wp-header-end");'
        . 'if(hrEnd){hrEnd.style.setProperty("display","none","important");hrEnd.style.setProperty("border","none","important");}'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",yshWcReportsLayout);}else{yshWcReportsLayout();}'
        . 'window.addEventListener("load",yshWcReportsLayout);'
        . '})();'
        . '</script>' . "\n";
}

