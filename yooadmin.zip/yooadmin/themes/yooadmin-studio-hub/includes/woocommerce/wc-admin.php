<?php
/**
 * Studio Hub — woocommerce / wc-admin
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Mark wc-admin dashboard (no path) so CSS can hide duplicate "Home" tab strip.
 *
 * @param string $classes
 * @return string
 */
function yooadmin_studio_hub_filter_wc_admin_body_class(string $classes): string {
    if (!yooadmin_studio_hub_is_active()) {
        return $classes;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (!isset($_GET['page']) || 'wc-admin' !== sanitize_key(wp_unslash($_GET['page']))) {
        return $classes;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $path = isset($_GET['path']) ? trim(sanitize_text_field(wp_unslash($_GET['path'])), " \t\n\r\0\x0B/") : '';
    if ($path === '') {
        $classes .= ' ysh-wc-admin-is-home';
    } elseif (
        'analytics' === $path
        || 0 === strpos($path, 'analytics/')
    ) {
        $classes .= ' ysh-wc-admin-is-analytics';
    } elseif (
        'extensions' === $path
        || 0 === strpos($path, 'extensions/')
    ) {
        $classes .= ' ysh-wc-admin-is-extensions';
    }

    return $classes;
}

/**
 * wc-admin — one-shot paint fix after React mount (no MutationObserver — it breaks Woo Home).
 *
 * Only clears background-color on chrome strips; never touches layout width/height.
 */
function yooadmin_studio_hub_print_wc_admin_header_fix_script(): void {
    if (!is_admin() || !yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (!isset($_GET['page']) || 'wc-admin' !== sanitize_key(wp_unslash($_GET['page']))) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-wc-admin-header-fix">'
        . '(function(){'
        . 'var bgSel=[".woocommerce-layout__header-heading",'
        . '".woocommerce-layout__header-heading .components-tab-panel__tabs",'
        . '".woocommerce-layout__header-heading [role=tablist]",'
        . '".woocommerce-layout__header .components-card",'
        . '".woocommerce-layout__header .components-card__body",'
        . '".woocommerce-layout__activity-panel-tabs .woocommerce-layout__activity-panel-tab"];'
        . 'function clearBg(){bgSel.forEach(function(s){document.querySelectorAll(s).forEach(function(el){'
        . 'el.style.setProperty("background-color","transparent","important");'
        . 'el.style.setProperty("background","transparent","important");'
        . 'el.style.setProperty("box-shadow","none","important");'
        . '});});}'
        . 'clearBg();'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",clearBg);}'
        . 'window.addEventListener("load",clearBg);'
        . 'setTimeout(clearBg,800);'
        . 'setTimeout(clearBg,2500);'
        . '})();</script>' . "\n";
}

/**
 * wc-admin — strip #fff behind header tablist (.woocommerce-layout__header-heading).
 */
function yooadmin_studio_hub_print_wc_admin_header_chrome(): void {
    if (!is_admin() || !yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (!isset($_GET['page']) || 'wc-admin' !== sanitize_key(wp_unslash($_GET['page']))) {
        return;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $path = isset($_GET['path']) ? trim(sanitize_text_field(wp_unslash($_GET['path'])), " \t\n\r\0\x0B/") : '';
    $hide_home_tab = ($path === '') ? 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin.ysh-wc-admin-is-home .woocommerce-layout__header-heading{display:none!important;visibility:hidden!important;height:0!important;min-height:0!important;padding:0!important;margin:0!important;overflow:hidden!important;border:0!important;}' : '';

    echo '<style id="yooadmin-studio-hub-wc-admin-header">'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__header,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__header-heading,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__header-heading .components-tab-panel__tabs,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__header-heading [role="tablist"],'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__header .components-card,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__header .components-card__body,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__activity-panel,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__activity-panel-tabs,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__activity-panel-tab'
        . '{background:transparent!important;background-color:transparent!important;box-shadow:none!important;border:none!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__activity-panel-tab:not(.has-icon){color:var(--ysh-brand,#eda934)!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-layout__activity-panel-tab.has-icon{color:var(--ysh-muted,#5d5d5d)!important;}'
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static CSS selector fragment.
        . $hide_home_tab
        . '</style>' . "\n";
}

/**
 * wc-admin core profiler (setup-wizard) — critical dark rules before vendor chunk paints.
 */
function yooadmin_studio_hub_print_wc_profiler_critical(): void {
    if (!yooadmin_studio_hub_is_wc_admin_screen() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-wc-profiler-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-profile-wizard__body,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-profile-wizard__body{background:#121418!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' :is(.woocommerce-profiler-heading__title,.woocommerce-profiler-heading__subtitle,.woocommerce-profiler-question-label),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' :is(.woocommerce-profiler-heading__title,.woocommerce-profiler-heading__subtitle,.woocommerce-profiler-question-label){'
        . 'color:#e8ecf1!important;-webkit-text-fill-color:#e8ecf1!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-profiler-choice-container,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-profiler-choice-container{background:#1a1d23!important;border-color:rgba(255,255,255,.14)!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-profiler-choice :is(label,span,p,strong),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-profiler-choice :is(label,span,p,strong){color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-onboarding-loader,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-onboarding-loader{background:#121418!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-onboarding-loader__title,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-onboarding-loader__title{color:#e8ecf1!important;-webkit-text-fill-color:#e8ecf1!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-onboarding-loader__subtext,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin .woocommerce-onboarding-loader__subtext{color:#9aa3b2!important;-webkit-text-fill-color:#9aa3b2!important;}'
        . '</style>' . "\n";
}

/**
 * wc-admin SPA — sync route body class before React paint (PHP only runs on full load).
 */
function yooadmin_studio_hub_print_wc_admin_route_bootstrap(): void {
    if (!yooadmin_studio_hub_is_wc_admin_screen() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-wc-route-bootstrap">'
        . '(function(){'
        . 'function path(){try{var p=new URLSearchParams(location.search).get("path")||"";return p.replace(/^\\/+|\\/+$/g,"");}catch(e){return"";}}'
        . 'function sync(){var p=path();document.documentElement.setAttribute("data-ysh-wc-path",p);'
        . 'var b=document.body;if(!b||!b.classList.contains("woocommerce_page_wc-admin")){return;}'
        . '["ysh-wc-admin-is-home","ysh-wc-admin-is-analytics","ysh-wc-admin-is-extensions","ysh-wc-admin-is-profiler"].forEach(function(c){b.classList.remove(c);});'
        . 'if(p===""){b.classList.add("ysh-wc-admin-is-home");}'
        . 'else if(p==="analytics"||p.indexOf("analytics/")===0||p==="customers"){b.classList.add("ysh-wc-admin-is-analytics");}'
        . 'else if(p==="extensions"||p.indexOf("extensions/")===0){b.classList.add("ysh-wc-admin-is-extensions");}'
        . 'else if(p==="setup-wizard"||p.indexOf("setup-wizard/")===0){b.classList.add("ysh-wc-admin-is-profiler");}}'
        . 'sync();'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",sync);}'
        . 'window.addEventListener("locationchange",sync);'
        . 'window.addEventListener("popstate",sync);'
        . '})();</script>' . "\n";
}

/**
 * wc-admin analytics — clear Emotion inline fills (Performance, leaderboards, chart interval).
 */
function yooadmin_studio_hub_print_wc_admin_analytics_fix_script(): void {
    if (!yooadmin_studio_hub_is_wc_admin_screen() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-wc-analytics-fix">'
        . '(function(){'
        . 'var sel=[".woocommerce-dashboard__store-performance .woocommerce-summary",'
        . '".woocommerce-dashboard__store-performance .woocommerce-summary__item",'
        . '".woocommerce-stats-overview__stats .woocommerce-summary__item",'
        . '".woocommerce-summary__item",'
        . '".woocommerce-leaderboard",'
        . '".woocommerce-leaderboard > div",'
        . '".woocommerce-leaderboard .components-card__body",'
        . '".woocommerce-leaderboard .components-card__header",'
        . '".woocommerce-leaderboard .woocommerce-table.is-empty",'
        . '".woocommerce-leaderboard .woocommerce-card",'
        . '".woocommerce-leaderboard .woocommerce-card__body",'
        . '".woocommerce-dashboard__dashboard-leaderboards .components-card",'
        . '".woocommerce-dashboard__dashboard-leaderboards .components-card__body",'
        . '".woocommerce-dashboard__dashboard-leaderboards .woocommerce-card",'
        . '".woocommerce-dashboard__dashboard-leaderboards .woocommerce-card__body",'
        . '".woocommerce-leaderboard.woocommerce-empty-content",'
        . '".woocommerce-empty-content",'
        . '".woocommerce-chart",'
        . '".woocommerce-chart .woocommerce-chart__header"];'
        . 'function isAnalytics(){try{var p=(new URLSearchParams(location.search).get("path")||"").replace(/^\\/+|\\/+$/g,"");return p==="analytics"||p.indexOf("analytics/")===0;}catch(e){return false;}}'
        . 'function clearSurfaces(){if(!isAnalytics()){return;}'
        . 'sel.forEach(function(s){document.querySelectorAll(s).forEach(function(el){'
        . 'el.style.removeProperty("background");el.style.removeProperty("background-color");'
        . '});});'
        . 'function lbPaint(el,c){el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");el.style.setProperty("color",c,"important");el.style.setProperty("-webkit-text-fill-color",c,"important");}'
        . 'function lbText(){'
        . 'document.querySelectorAll(".woocommerce-dashboard__dashboard-leaderboards .woocommerce-leaderboard :is(h2,h3),.woocommerce-dashboard__dashboard-leaderboards .woocommerce-section-header__title,.woocommerce-stats-overview__leaderboards .woocommerce-section-header__title,.woocommerce-dashboard__dashboard-leaderboards .woocommerce-dashboard-section__title,.woocommerce-dashboard__dashboard-leaderboards .woocommerce-ellipsis-menu__title,.woocommerce-leaderboard .woocommerce-card__title,.woocommerce-leaderboard .woocommerce-card__header :is(h2,h3,.components-text),.woocommerce-leaderboard .components-card__header :is(h2,h3,.components-text),.woocommerce-leaderboard.woocommerce-table .components-card__header :is(h2,h3,.components-text),.woocommerce-dashboard__dashboard-leaderboards .components-card__header :is(h2,h3,.components-text)").forEach(function(el){lbPaint(el,"#d8d3ce");});'
        . 'document.querySelectorAll(".woocommerce-leaderboard .woocommerce-table.is-empty,.woocommerce-leaderboard .woocommerce-empty-content__message,.woocommerce-leaderboard .woocommerce-table__empty-table,.woocommerce-leaderboard .woocommerce-table__empty-item,.woocommerce-leaderboard .woocommerce-table__head th,.woocommerce-leaderboard .woocommerce-table__cell,.woocommerce-leaderboard .woocommerce-table__cell a,.woocommerce-dashboard__dashboard-leaderboards .woocommerce-empty-content__message,.woocommerce-empty-content__message").forEach(function(el){lbPaint(el,"#9aa5b1");});'
        . '}'
        . 'var d=document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";'
        . 'if(d){document.querySelectorAll(".woocommerce-leaderboard,.woocommerce-leaderboard>div,.woocommerce-leaderboard.components-card,.woocommerce-leaderboard .components-card__body,.woocommerce-leaderboard .components-card__header,.woocommerce-leaderboard .woocommerce-table.is-empty,.woocommerce-leaderboard .woocommerce-card,.woocommerce-leaderboard .woocommerce-card__header,.woocommerce-leaderboard .woocommerce-card__body,.woocommerce-dashboard__dashboard-leaderboards .components-card,.woocommerce-dashboard__dashboard-leaderboards .components-card__header,.woocommerce-dashboard__dashboard-leaderboards .components-card__body,.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card,.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card__header,.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card__body,.woocommerce-leaderboard.woocommerce-empty-content").forEach(function(el){'
        . 'el.style.setProperty("background","#1a1d23","important");el.style.setProperty("background-color","#1a1d23","important");'
        . 'el.style.setProperty("border-color","rgba(255,255,255,0.1)","important");});'
        . 'lbText();}'
        . 'document.querySelectorAll(".woocommerce-summary__item-label,.woocommerce-summary__item-prev-label").forEach(function(el){'
        . 'el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");'
        . 'if(d){el.style.setProperty("color","#9aa5b1","important");el.style.setProperty("-webkit-text-fill-color","#9aa5b1","important");}});'
        . 'document.querySelectorAll(".woocommerce-summary__item-value").forEach(function(el){'
        . 'el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");'
        . 'if(d){el.style.setProperty("color","#d8d3ce","important");el.style.setProperty("-webkit-text-fill-color","#d8d3ce","important");}});'
        . 'document.querySelectorAll(".woocommerce-summary__item-delta,.woocommerce-empty-content__message").forEach(function(el){'
        . 'el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");'
        . 'if(d){el.style.setProperty("color","#cfd6e0","important");el.style.setProperty("-webkit-text-fill-color","#cfd6e0","important");}});'
        . 'document.querySelectorAll(".woocommerce-chart .components-select-control__input,.woocommerce-chart .components-input-control__container,.woocommerce-chart .components-input-control__input").forEach(function(el){'
        . 'el.style.removeProperty("background");el.style.removeProperty("background-color");el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");el.style.removeProperty("box-shadow");});}'
        . 'function run(){clearSurfaces();if(window.yshSyncWooAnalyticsChrome){window.yshSyncWooAnalyticsChrome();}}'
        . 'run();'
        . '[0,50,150,400,800,1500,2500].forEach(function(ms){setTimeout(run,ms);});'
        . 'window.addEventListener("load",run);'
        . 'window.addEventListener("locationchange",run);'
        . 'document.addEventListener("ysh-studio-color-mode-changed",run);'
        . '})();</script>' . "\n";
}

/**
 * wc-admin marketplace — clear Emotion inline fills after mount / color-mode toggle.
 */
function yooadmin_studio_hub_print_wc_admin_marketplace_fix_script(): void {
    if (!yooadmin_studio_hub_is_wc_admin_screen() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-wc-marketplace-fix">'
        . '(function(){'
        . 'var sel=[".woocommerce-marketplace__header-container",'
        . '".woocommerce-marketplace__header",'
        . '".woocommerce-marketplace__content",'
        . '".woocommerce-marketplace__product-list",'
        . '".woocommerce-marketplace__extension-card",'
        . '".woocommerce-marketplace__product-card.components-card",'
        . '".woocommerce-marketplace__product-card__details",'
        . '".woocommerce-marketplace__product-card__content",'
        . '".woocommerce-marketplace__product-card--theme .components-card__body",'
        . '".woocommerce-marketplace__banner",'
        . '".woocommerce-marketplace__footer"];'
        . 'function clearMp(){if(!document.querySelector(".woocommerce-marketplace")){return;}'
        . 'sel.forEach(function(s){document.querySelectorAll(s).forEach(function(el){'
        . 'el.style.removeProperty("background");'
        . 'el.style.removeProperty("background-color");'
        . '});});}'
        . 'function fixSearch(){var s=document.querySelector(".woocommerce-marketplace__search");'
        . 'if(!s){return;}'
        . 'var d=document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";'
        . 's.querySelectorAll(".components-input-control__container").forEach(function(el){'
        . 'el.style.removeProperty("background");el.style.removeProperty("background-color");el.style.removeProperty("box-shadow");});'
        . 's.querySelectorAll(".components-input-control__input,input").forEach(function(el){'
        . 'el.style.removeProperty("background");el.style.removeProperty("background-color");el.style.removeProperty("color");'
        . 'el.style.removeProperty("-webkit-text-fill-color");el.style.removeProperty("box-shadow");'
        . 'if(d){el.style.setProperty("color","#cfd6e0","important");el.style.setProperty("-webkit-text-fill-color","#cfd6e0","important");}});}'
        . 'function fixNotices(){document.querySelectorAll(".woocommerce-marketplace__connect-notice,.woocommerce-marketplace__connect-notice .woocommerce-marketplace__notice,.woocommerce-marketplace__connect-notice .woocommerce-marketplace__notice-description,.woocommerce-marketplace__connect-notice .components-text").forEach(function(el){'
        . 'el.style.removeProperty("background");el.style.removeProperty("background-color");el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");});}'
        . 'function fixMySubscriptions(){document.querySelectorAll(".woocommerce-marketplace__my-subscriptions__account,.woocommerce-marketplace__my-subscriptions__account-header,.woocommerce-marketplace__my-subscriptions__account-content,.woocommerce-marketplace__my-subscriptions .woocommerce-table__header,.woocommerce-marketplace__my-subscriptions .woocommerce-table__item,.woocommerce-marketplace__my-subscriptions__heading,.woocommerce-marketplace__my-subscriptions__table").forEach(function(el){'
        . 'el.style.removeProperty("background");el.style.removeProperty("background-color");el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");});}'
        . 'function fixCategories(){var d=document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";'
        . 'document.querySelectorAll(".woocommerce-marketplace__category-item-button,.woocommerce-marketplace__category-dropdown-button,.woocommerce-marketplace__category-navigation-button").forEach(function(el){'
        . 'el.style.removeProperty("background");el.style.removeProperty("background-color");el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");});'
        . 'document.querySelectorAll(".woocommerce-marketplace__category-dropdown-button .components-icon,.woocommerce-marketplace__category-dropdown-button svg,.woocommerce-marketplace__category-dropdown-button svg path").forEach(function(el){'
        . 'el.style.removeProperty("fill");el.style.removeProperty("color");el.style.removeProperty("stroke");'
        . 'if(d){el.style.setProperty("fill","currentColor","important");el.style.setProperty("color","#cfd6e0","important");}});}'
        . 'function fixTabs(){var h=document.querySelector(".woocommerce-marketplace__header");'
        . 'if(!h){return;}'
        . 'h.querySelectorAll(".woocommerce-marketplace__header-title,.woocommerce-marketplace__tab-button,.woocommerce-marketplace__tab-button .components-text,.woocommerce-marketplace__tab-button span").forEach(function(el){'
        . 'el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");});}'
        . 'function run(){clearMp();fixSearch();fixTabs();fixNotices();fixMySubscriptions();fixCategories();if(window.yshSyncWooMarketplaceChrome){window.yshSyncWooMarketplaceChrome();}}'
        . 'run();'
        . '[0,50,150,400,800,1500,2500].forEach(function(ms){setTimeout(run,ms);});'
        . 'window.addEventListener("load",run);'
        . 'document.addEventListener("ysh-studio-color-mode-changed",run);'
        . '})();</script>' . "\n";
}

/**
 * Marketplace — critical dark shell in <head> (before React/Emotion first paint).
 */
function yooadmin_studio_hub_print_wc_marketplace_critical(): void {
    if (!yooadmin_studio_hub_is_wc_admin_screen() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-wc-marketplace-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__header-container,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__content,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__header-container,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__content{'
        . 'background:var(--ysh-card,#1a1d23)!important;background-color:var(--ysh-card,#1a1d23)!important;color:var(--ysh-text,#cfd6e0)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__header,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__header{background:transparent!important;background-color:transparent!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' :is(.woocommerce-marketplace__product-card.components-card,.woocommerce-marketplace__product-card__details,.woocommerce-marketplace__product-card__content),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' :is(.woocommerce-marketplace__product-card.components-card,.woocommerce-marketplace__product-card__details,.woocommerce-marketplace__product-card__content){'
        . 'background:transparent!important;background-color:transparent!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__product-card.components-card,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__product-card.components-card{border:1px solid rgba(255,255,255,.14)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__search .components-input-control__container{'
        . 'background:#22262e!important;background-color:#22262e!important;border:1px solid rgba(255,255,255,.14)!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__search :is(.components-input-control__input,input){'
        . 'background:transparent!important;color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__search :is(.components-input-control__input,input)::placeholder{color:#9aa5b1!important;opacity:1!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' :is(.woocommerce-marketplace__header-title,.woocommerce-marketplace__tab-button){'
        . 'color:#d8d3ce!important;-webkit-text-fill-color:#d8d3ce!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__tab-button.is-active{color:#eda934!important;-webkit-text-fill-color:#eda934!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' :is(.woocommerce-marketplace__header-title,.woocommerce-marketplace__tab-button){'
        . 'color:#1f2933!important;-webkit-text-fill-color:#1f2933!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__connect-notice{'
        . 'background:color-mix(in srgb,#eda934 18%,#1a1d23)!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__connect-notice :is(.woocommerce-marketplace__notice-description,.components-text,span,p){'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__my-subscriptions__account{'
        . 'background:color-mix(in srgb,#eda934 18%,#1a1d23)!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__my-subscriptions__account :is(.woocommerce-marketplace__my-subscriptions__account-header,.woocommerce-marketplace__my-subscriptions__account-content){'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__my-subscriptions .woocommerce-table__header{'
        . 'background:#22262e!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__my-subscriptions .woocommerce-table__item{'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__category-navigation-button--next{'
        . 'background:linear-gradient(to left,#1a1d23 0%,color-mix(in srgb,#1a1d23 72%,transparent) 55%,transparent 100%)!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__category-navigation-button--prev{'
        . 'background:linear-gradient(to right,#1a1d23 0%,color-mix(in srgb,#1a1d23 72%,transparent) 55%,transparent 100%)!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__category-dropdown-button :is(.components-icon,svg,svg path){'
        . 'fill:currentColor!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__my-subscriptions .woocommerce-table__table::after{'
        . 'background:linear-gradient(90deg,rgba(26,29,35,0),#1a1d23)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__my-subscriptions .woocommerce-table__table::before{'
        . 'background:linear-gradient(90deg,#1a1d23,rgba(26,29,35,0))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__product-card.is-loading.components-card{'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;border:1px solid rgba(255,255,255,.1)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__product-card.is-loading :is('
        . '.woocommerce-marketplace__product-card__image,'
        . '.woocommerce-marketplace__product-card__vendor,'
        . '.woocommerce-marketplace__product-card__description,'
        . '.woocommerce-marketplace__product-card__price,'
        . '.woocommerce-marketplace__product-card__icon,'
        . '.woocommerce-marketplace__product-card__title,'
        . '.woocommerce-marketplace__product-card__footer),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' :is(.woocommerce-marketplace__product-list-title.is-loading,.woocommerce-marketplace__category-item-button.is-loading){'
        . 'background:rgba(255,255,255,.1)!important;background-color:rgba(255,255,255,.1)!important;color:transparent!important;}'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__product-card.is-loading.components-card{'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;border:1px solid rgba(255,255,255,.1)!important;}'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__product-card.is-loading :is('
        . '.woocommerce-marketplace__product-card__image,'
        . '.woocommerce-marketplace__product-card__vendor,'
        . '.woocommerce-marketplace__product-card__description,'
        . '.woocommerce-marketplace__product-card__price,'
        . '.woocommerce-marketplace__product-card__icon,'
        . '.woocommerce-marketplace__product-card__title,'
        . '.woocommerce-marketplace__product-card__footer),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' :is(.woocommerce-marketplace__product-list-title.is-loading,.woocommerce-marketplace__category-item-button.is-loading){'
        . 'background:rgba(255,255,255,.1)!important;background-color:rgba(255,255,255,.1)!important;color:transparent!important;}'
        . '@media screen and (max-width:1024px){'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__header-container,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__header-tabs{max-width:100%!important;overflow-x:hidden!important;min-width:0!important;padding:0!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__tabs{max-width:100%!important;width:100%!important;min-width:0!important;overflow-x:auto!important;overflow-y:hidden!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ':is(.ysh-wc-admin-is-extensions,.woocommerce-admin-page__extensions)'
        . ' .woocommerce-marketplace__tabs::after{display:none!important;content:none!important;}'
        . '}'
        . '</style>' . "\n";
}

/**
 * Analytics leaderboards — critical dark shell in <head> (empty state uses components-card__body #f0f0f0).
 */
function yooadmin_studio_hub_print_wc_analytics_critical(): void {
    if (!yooadmin_studio_hub_is_wc_admin_screen() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-wc-analytics-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard>div,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .components-card__header,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .components-card__body,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .woocommerce-table.is-empty,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard>div,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .components-card__header,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .components-card__body,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .woocommerce-table.is-empty{'
        . 'background:var(--ysh-card,#1a1d23)!important;background-color:var(--ysh-card,#1a1d23)!important;'
        . 'border-color:rgba(255,255,255,.1)!important;color:var(--ysh-text,#cfd6e0)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-dashboard__dashboard-leaderboards .woocommerce-section-header__title,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-dashboard__dashboard-leaderboards .woocommerce-section-header__title,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-dashboard__dashboard-leaderboards .woocommerce-leaderboard :is(h2,h3),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-dashboard__dashboard-leaderboards .woocommerce-leaderboard :is(h2,h3),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .components-card__header :is(h2,h3,.components-text),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .components-card__header :is(h2,h3,.components-text){'
        . 'color:#d8d3ce!important;-webkit-text-fill-color:#d8d3ce!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .woocommerce-table.is-empty,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .woocommerce-table.is-empty,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .woocommerce-table__empty-item,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-admin'
        . ' .woocommerce-leaderboard .woocommerce-table__empty-item{'
        . 'color:#9aa5b1!important;-webkit-text-fill-color:#9aa5b1!important;}'
        . '</style>' . "\n";
}

