<?php
/**
 * Studio Hub — woocommerce / wc-orders
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Orders list (HPOS) — critical layout + marketplace CTA contrast in <head>.
 */
function yooadmin_studio_hub_print_wc_orders_critical(): void {
    if (!yooadmin_studio_hub_wc_orders_studio_active()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-wc-orders-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.woocommerce_page_wc-orders){background:#0b0d11!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders #wpwrap,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders #wpcontent,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders #wpbody,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders #wpbody-content,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders .yoo-shell-content{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;padding-left:0!important;padding-right:0!important;overflow-x:clip!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders .yoo-shell-content{'
        . 'max-width:var(--ysh-layout-max,1400px)!important;margin-inline:auto!important;}'
        . 'body.yoo-focus.wp-admin.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders #wpbody-content>.wrap{'
        . 'width:100%!important;max-width:min(var(--ysh-layout-max,1400px),100%)!important;margin-left:auto!important;margin-right:auto!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders'
        . ' :is(#wpwrap,#wpcontent,#wpbody,#wpbody-content,.yoo-shell-content){background:#0b0d11!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.wp-admin.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders'
        . ' #wpbody-content>.wrap{background:transparent!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders'
        . ' .yp-breadcrumbs-bar{background:#0b0d11!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders'
        . ' .woocommerce-layout__activity-panel-wrapper{background:#1a1d23!important;scrollbar-color:rgba(255,255,255,.24) #1a1d23!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders'
        . ' .marketplace-suggestion-container-cta :is(a.button,a.button-primary){'
        . 'background:var(--ysh-brand,#eda934)!important;color:#1a1a1a!important;border-color:transparent!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders #wpbody-content>.wrap>hr.wp-header-end{'
        . 'display:none!important;height:0!important;margin:0!important;border:none!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders .yp-breadcrumbs-bar{'
        . 'border-top:none!important;border-bottom:none!important;box-shadow:none!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders #wpbody-content{'
        . 'padding-top:0!important;margin-top:0!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders #wpbody-content>.wrap{'
        . 'margin-top:0!important;padding-top:16px!important;box-shadow:none!important;border-top:none!important;'
        . 'display:block!important;padding-block-start:16px!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders .yoo-shell-content,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.woocommerce_page_wc-orders #wpbody{'
        . 'margin-top:0!important;padding-top:0!important;}'
        . '</style>' . "\n";
}

/**
 * Orders — last cascade in <head> (beats core RTL admin-menu margins on #wpcontent).
 */
function yooadmin_studio_hub_print_wc_orders_cascade_tail(): void {
    if (!yooadmin_studio_hub_wc_orders_studio_active()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-wc-orders-tail">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.woocommerce_page_wc-orders),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.woocommerce_page_wc-orders) body,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.woocommerce_page_wc-orders) #wpwrap,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.woocommerce_page_wc-orders) #wpcontent{'
        . 'background:#0b0d11!important;background-color:#0b0d11!important;'
        . 'scrollbar-color:rgba(255,255,255,.2) #0b0d11!important;}'
        . 'html:has(body.woocommerce_page_wc-orders),html:has(body.woocommerce_page_wc-orders) body{'
        . 'overflow-x:hidden!important;max-width:100%!important;}'
        . 'body.yoo-focus.woocommerce_page_wc-orders #wpwrap{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;overflow-x:hidden!important;}'
        . 'body.yoo-focus.woocommerce_page_wc-orders #wpcontent,'
        . 'body.yoo-focus.woocommerce_page_wc-orders.folded #wpcontent,'
        . 'body.yoo-focus.woocommerce_page_wc-orders.auto-fold #wpcontent,'
        . 'body.yp-clean-view.woocommerce_page_wc-orders #wpcontent,'
        . 'body.yp-clean-view.woocommerce_page_wc-orders.folded #wpcontent{'
        . 'width:100%!important;max-width:none!important;min-width:0!important;'
        . 'margin:0!important;margin-left:0!important;margin-right:0!important;'
        . 'padding-left:0!important;padding-right:0!important;float:none!important;}'
        . 'body.yoo-focus.woocommerce_page_wc-orders #wpbody,'
        . 'body.yoo-focus.woocommerce_page_wc-orders #wpbody-content,'
        . 'body.yoo-focus.woocommerce_page_wc-orders .yoo-shell-content{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;margin-inline:0!important;'
        . 'margin-top:0!important;padding-top:0!important;padding-inline:0!important;'
        . 'overflow-x:clip!important;box-sizing:border-box!important;}'
        . 'body.yoo-focus.woocommerce_page_wc-orders #wpcontent #wpbody-content>.wrap{'
        . 'display:block!important;margin-top:0!important;padding-block-start:16px!important;box-shadow:none!important;}'
        . 'html[dir=rtl] body.yoo-focus.woocommerce_page_wc-orders #wpcontent{'
        . 'margin-right:0!important;margin-left:0!important;float:none!important;}'
        . 'body.yoo-focus.woocommerce_page_wc-orders #adminmenuback,'
        . 'body.yoo-focus.woocommerce_page_wc-orders #adminmenuwrap,'
        . 'body.yoo-focus.woocommerce_page_wc-orders #adminmenumain{display:none!important;}'
        . '</style>' . "\n";
}

/**
 * Orders — force full-width shell (beats late WP / plugin margin-left on #wpcontent).
 */
function yooadmin_studio_hub_print_wc_orders_layout_fix_script(): void {
    if (!yooadmin_studio_hub_wc_orders_studio_active()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-wc-orders-layout-fix">'
        . '(function(){'
        . 'function yshWcOrdersLayout(){'
        . 'var w=document.getElementById("wpwrap"),c=document.getElementById("wpcontent"),b=document.getElementById("wpbody"),'
        . 'if(w){w.style.setProperty("width","100%","important");w.style.setProperty("max-width","100%","important");w.style.setProperty("overflow-x","hidden","important");}'
        . 'bc=document.getElementById("wpbody-content"),s=document.querySelector(".yoo-shell-content"),'
        . 'ab=document.getElementById("adminmenuback"),aw=document.getElementById("adminmenuwrap"),am=document.getElementById("adminmenumain");'
        . 'var dark=document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";'
        . '[w,c,b,bc,s].forEach(function(el){if(!el)return;el.style.setProperty("width","100%","important");'
        . 'el.style.setProperty("max-width","100%","important");el.style.setProperty("margin-left","0","important");'
        . 'el.style.setProperty("margin-right","0","important");el.style.setProperty("padding-left","0","important");'
        . 'el.style.setProperty("padding-right","0","important");'
        . 'if(dark){el.style.setProperty("background","#0b0d11","important");el.style.setProperty("background-color","#0b0d11","important");}});'
        . 'document.documentElement.style.setProperty("overflow-x","hidden","important");'
        . 'document.body.style.setProperty("overflow-x","hidden","important");'
        . 'if(dark){document.documentElement.style.setProperty("background","#0b0d11","important");'
        . 'document.body.style.setProperty("background","#0b0d11","important");}'
        . 'if(s){s.style.setProperty("max-width","min(1400px, 100%)","important");s.style.setProperty("margin-inline","auto","important");}'
        . '[ab,aw,am].forEach(function(el){if(el)el.style.setProperty("display","none","important");});'
        . 'var wrap=bc&&bc.querySelector(":scope > .wrap");'
        . 'if(wrap){wrap.style.setProperty("width","100%","important");wrap.style.setProperty("max-width","min(1400px, 100%)","important");'
        . 'wrap.style.setProperty("margin-left","auto","important");wrap.style.setProperty("margin-right","auto","important");'
        . 'wrap.style.setProperty("margin-top","0","important");wrap.style.setProperty("display","block","important");'
        . 'wrap.style.setProperty("padding-block-start","16px","important");wrap.style.setProperty("border","none","important");wrap.style.setProperty("box-shadow","none","important");'
        . 'if(dark){wrap.style.setProperty("background","transparent","important");wrap.style.setProperty("background-color","transparent","important");}}'
        . 'var hrEnd=wrap&&wrap.querySelector("hr.wp-header-end");'
        . 'if(hrEnd){hrEnd.style.setProperty("display","none","important");hrEnd.style.setProperty("border","none","important");}'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",yshWcOrdersLayout);}else{yshWcOrdersLayout();}'
        . 'window.addEventListener("load",yshWcOrdersLayout);'
        . '})();'
        . '</script>' . "\n";
}

