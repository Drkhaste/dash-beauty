<?php
/**
 * Studio Hub — WooCommerce product catalog screens (list, taxonomies, attributes, reviews).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * CSS body scope — native WP classes (like shop_coupon) plus ysh-wc-product-catalog marker.
 *
 * @return string
 */
function yooadmin_studio_hub_product_catalog_css_scope(): string {
    return ':is(.ysh-wc-product-catalog,.post-type-product.edit-php,.taxonomy-product_cat,.taxonomy-product_tag,.taxonomy-product_brand,.product_page_product_attributes,.product_page_product-reviews,.product_page_product_reviews)';
}

/**
 * @param string $classes
 * @return string
 */
function yooadmin_studio_hub_filter_product_catalog_body_class($classes): string {
    if (yooadmin_studio_hub_is_product_catalog_screen() && yooadmin_studio_hub_is_focus_enabled()) {
        $classes .= ' ysh-wc-product-catalog';
    }

    return $classes;
}

/**
 * Critical layout — column cap + overflow (prevents wide/cut-off table).
 */
function yooadmin_studio_hub_print_product_catalog_critical(): void {
    if (!yooadmin_studio_hub_product_catalog_studio_active()) {
        return;
    }

    // $scope is a fixed CSS selector list (no user input) from yooadmin_studio_hub_product_catalog_css_scope().
    $scope = yooadmin_studio_hub_product_catalog_css_scope();

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Critical inline CSS; $scope is a constant selector fragment.
    echo '<style id="yooadmin-studio-hub-product-catalog-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body' . $scope . '){background:#0b0d11!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' #wpwrap,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' #wpcontent,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' #wpbody,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' #wpbody-content,'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' .yoo-shell-content{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;padding-left:0!important;padding-right:0!important;overflow-x:clip!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' .yoo-shell-content{'
        . 'max-width:var(--ysh-layout-max,1400px)!important;margin-inline:auto!important;}'
        . 'body.yoo-focus.wp-admin.yooadmin-theme-yooadmin-studio-hub' . $scope . ' #wpbody-content>.wrap{'
        . 'width:100%!important;max-width:min(var(--ysh-layout-max,1400px),100%)!important;margin-left:auto!important;margin-right:auto!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope
        . ' :is(#wpwrap,#wpcontent,#wpbody,#wpbody-content,.yoo-shell-content){background:#0b0d11!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.wp-admin.yooadmin-theme-yooadmin-studio-hub' . $scope
        . ' #wpbody-content>.wrap{background:transparent!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope
        . ' .yp-breadcrumbs-bar{background:#0b0d11!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' #wpbody-content>.wrap>hr.wp-header-end{'
        . 'display:none!important;height:0!important;margin:0!important;border:none!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' .yp-breadcrumbs-bar{'
        . 'border-top:none!important;border-bottom:none!important;box-shadow:none!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' #wpbody-content{'
        . 'padding-top:0!important;margin-top:0!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub' . $scope . ' #wpbody-content>.wrap{'
        . 'margin-top:0!important;padding-top:16px!important;box-shadow:none!important;border-top:none!important;'
        . 'display:block!important;padding-block-start:16px!important;overflow-x:auto!important;overflow-y:visible!important;-webkit-overflow-scrolling:touch;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-product.edit-php table.wp-list-table tr.type-product :is(td.thumb,td.column-thumb){'
        . 'width:52px!important;max-width:72px!important;overflow:hidden!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-product.edit-php table.wp-list-table tr.type-product :is(td.thumb,td.column-thumb) a{'
        . 'display:inline-block!important;width:40px!important;height:40px!important;overflow:hidden!important;}'
        . 'body.yoo-focus.yooadmin-theme-yooadmin-studio-hub.post-type-product.edit-php table.wp-list-table tr.type-product :is(td.thumb,td.column-thumb) img{'
        . 'width:40px!important;height:40px!important;max-width:40px!important;max-height:40px!important;object-fit:cover!important;}'
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Tail cascade — reinforce shell width on late-loaded styles.
 */
function yooadmin_studio_hub_print_product_catalog_cascade_tail(): void {
    if (!yooadmin_studio_hub_product_catalog_studio_active()) {
        return;
    }

    // $scope is a fixed CSS selector list (no user input) from yooadmin_studio_hub_product_catalog_css_scope().
    $scope = yooadmin_studio_hub_product_catalog_css_scope();

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Tail inline CSS; $scope is a constant selector fragment.
    echo '<style id="yooadmin-studio-hub-product-catalog-tail">'
        . 'html:has(body' . $scope . '),html:has(body' . $scope . ') body{'
        . 'overflow-x:hidden!important;max-width:100%!important;}'
        . 'body.yoo-focus' . $scope . ' #wpwrap{width:100%!important;max-width:100%!important;margin:0!important;overflow-x:hidden!important;}'
        . 'body.yoo-focus' . $scope . ' #wpcontent,'
        . 'body.yoo-focus' . $scope . '.folded #wpcontent,'
        . 'body.yoo-focus' . $scope . '.auto-fold #wpcontent,'
        . 'body.yp-clean-view' . $scope . ' #wpcontent{'
        . 'width:100%!important;max-width:none!important;min-width:0!important;'
        . 'margin:0!important;margin-left:0!important;margin-right:0!important;'
        . 'padding-left:0!important;padding-right:0!important;float:none!important;}'
        . 'body.yoo-focus' . $scope . ' #wpbody,'
        . 'body.yoo-focus' . $scope . ' #wpbody-content,'
        . 'body.yoo-focus' . $scope . ' .yoo-shell-content{'
        . 'width:100%!important;max-width:100%!important;margin:0!important;margin-inline:0!important;'
        . 'margin-top:0!important;padding-top:0!important;padding-inline:0!important;'
        . 'overflow-x:clip!important;box-sizing:border-box!important;}'
        . 'body.yoo-focus' . $scope . ' #wpcontent #wpbody-content>.wrap{'
        . 'display:block!important;margin-top:0!important;padding-block-start:16px!important;'
        . 'box-shadow:none!important;width:100%!important;max-width:min(var(--ysh-layout-max,1400px),100%)!important;'
        . 'margin-left:auto!important;margin-right:auto!important;overflow-x:auto!important;overflow-y:visible!important;}'
        . 'html[dir=rtl] body.yoo-focus' . $scope . ' #wpcontent{'
        . 'margin-right:0!important;margin-left:0!important;float:none!important;}'
        . 'body.yoo-focus' . $scope . ' :is(#adminmenuback,#adminmenuwrap,#adminmenumain){display:none!important;}'
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Footer script — enforce layout after WP/Woo inline styles.
 */
function yooadmin_studio_hub_print_product_catalog_layout_fix_script(): void {
    if (!yooadmin_studio_hub_product_catalog_studio_active()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-product-catalog-layout-fix">'
        . '(function(){'
        . 'function yshProductCatalogLayout(){'
        . 'var w=document.getElementById("wpwrap"),c=document.getElementById("wpcontent"),b=document.getElementById("wpbody"),'
        . 'bc=document.getElementById("wpbody-content"),s=document.querySelector(".yoo-shell-content"),'
        . 'ab=document.getElementById("adminmenuback"),aw=document.getElementById("adminmenuwrap"),am=document.getElementById("adminmenumain");'
        . 'var dark=document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";'
        . '[w,c,b,bc,s].forEach(function(el){if(!el)return;el.style.setProperty("width","100%","important");'
        . 'el.style.setProperty("max-width","100%","important");el.style.setProperty("margin-left","0","important");'
        . 'el.style.setProperty("margin-right","0","important");el.style.setProperty("padding-left","0","important");'
        . 'el.style.setProperty("padding-right","0","important");'
        . 'if(dark){el.style.setProperty("background","#0b0d11","important");el.style.setProperty("background-color","#0b0d11","important");}});'
        . '[ab,aw,am].forEach(function(el){if(el)el.style.setProperty("display","none","important");});'
        . 'document.documentElement.style.setProperty("overflow-x","hidden","important");'
        . 'document.body.style.setProperty("overflow-x","hidden","important");'
        . 'if(dark){document.documentElement.style.setProperty("background","#0b0d11","important");'
        . 'document.body.style.setProperty("background","#0b0d11","important");}'
        . 'if(s){s.style.setProperty("max-width","min(1400px, 100%)","important");s.style.setProperty("margin-inline","auto","important");}'
        . 'var wrap=bc&&bc.querySelector(":scope > .wrap");'
        . 'if(wrap){wrap.style.setProperty("width","100%","important");wrap.style.setProperty("max-width","min(1400px, 100%)","important");'
        . 'wrap.style.setProperty("margin-left","auto","important");wrap.style.setProperty("margin-right","auto","important");'
        . 'wrap.style.setProperty("margin-top","0","important");wrap.style.setProperty("display","block","important");'
        . 'wrap.style.setProperty("padding-block-start","16px","important");wrap.style.setProperty("overflow-x","auto","important");'
        . 'wrap.style.setProperty("overflow-y","visible","important");wrap.style.setProperty("border","none","important");wrap.style.setProperty("box-shadow","none","important");'
        . 'if(dark){wrap.style.setProperty("background","transparent","important");wrap.style.setProperty("background-color","transparent","important");}}'
        . 'var hrEnd=wrap&&wrap.querySelector("hr.wp-header-end");'
        . 'if(hrEnd){hrEnd.style.setProperty("display","none","important");hrEnd.style.setProperty("border","none","important");}'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",yshProductCatalogLayout);}else{yshProductCatalogLayout();}'
        . 'window.addEventListener("load",yshProductCatalogLayout);'
        . '})();'
        . '</script>' . "\n";
}
