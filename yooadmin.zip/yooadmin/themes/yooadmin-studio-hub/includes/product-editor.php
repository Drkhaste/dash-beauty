<?php
/**
 * Studio Hub — product-editor
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Product editor — dedicated tabbed layout assets.
 */
function yooadmin_studio_hub_enqueue_product_editor_assets(): void {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    $css = yooadmin_studio_hub_asset_path('css/compat/product-editor.css');
    $js  = yooadmin_studio_hub_asset_path('js/compat/product-editor.js');

    $deps = ['yooadmin-studio-hub-late'];
    if (wp_style_is('yooadmin-studio-hub-dashboard', 'registered')) {
        $deps[] = 'yooadmin-studio-hub-dashboard';
    }

    if (is_readable($css)) {
        wp_enqueue_style(
            'yooadmin-studio-hub-product-editor',
            yooadmin_studio_hub_asset_url('css/compat/product-editor.css'),
            $deps,
            (string) filemtime($css)
        );
    }

    if (is_readable($js)) {
        wp_enqueue_script(
            'yooadmin-studio-hub-product-editor',
            yooadmin_studio_hub_asset_url('js/compat/product-editor.js'),
            ['jquery'],
            (string) filemtime($js),
            false
        );

        wp_localize_script(
            'yooadmin-studio-hub-product-editor',
            'yshProductEditor',
            [
                'tabs' => [
                    [
                        'id'    => 'content',
                        'label' => __('Title & description', 'yooadmin'),
                    ],
                    [
                        'id'    => 'product-data',
                        'label' => __('Product data', 'yooadmin'),
                    ],
                    [
                        'id'    => 'short-description',
                        'label' => __('Short description', 'yooadmin'),
                    ],
                    [
                        'id'    => 'yoast',
                        'label' => __('Yoast SEO', 'yooadmin'),
                    ],
                ],
                'sidebarTabs' => [
                    [
                        'id'    => 'publish',
                        'label' => __('Publish', 'yooadmin'),
                    ],
                    [
                        'id'    => 'organize',
                        'label' => __('Organize', 'yooadmin'),
                    ],
                    [
                        'id'    => 'media',
                        'label' => __('Media', 'yooadmin'),
                    ],
                    [
                        'id'    => 'more',
                        'label' => __('More', 'yooadmin'),
                    ],
                ],
                'publishIcons' => [
                    'saveDraft'   => __('Save draft', 'yooadmin'),
                    'preview'     => __('Preview', 'yooadmin'),
                    'previewChanges' => __('Preview changes', 'yooadmin'),
                    'publish'     => __('Publish', 'yooadmin'),
                    'update'      => __('Update', 'yooadmin'),
                    'schedule'    => __('Schedule', 'yooadmin'),
                    'submitReview'=> __('Submit for review', 'yooadmin'),
                    'copyDraft'   => __('Copy to a new draft', 'yooadmin'),
                    'moreActions' => __('More publish actions', 'yooadmin'),
                    'moveTrash'   => __('Move to trash', 'yooadmin'),
                    'delete'      => __('Delete permanently', 'yooadmin'),
                    'editStatus'  => __('Edit status', 'yooadmin'),
                    'editVisibility' => __('Edit visibility', 'yooadmin'),
                    'editDate'    => __('Edit publish date', 'yooadmin'),
                    'edit'        => __('Edit', 'yooadmin'),
                ],
            ]
        );
    }

}

/**
 * Product editor — stop the WooCommerce product tour (tour-kit).
 *
 * The custom tabbed layout moves the tour's anchor elements, so the tour renders
 * in the wrong place and its focus-lock/interactivity overlay blocks clicks on the
 * tabs. Dequeue the tour scripts entirely on this screen.
 */
function yooadmin_studio_hub_disable_woo_product_tour(): void {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    foreach (['wc-admin-product-tour', 'wc-admin-variable-product-tour'] as $handle) {
        wp_dequeue_script($handle);
        wp_deregister_script($handle);
    }
}

/**
 * @param string $classes
 * @return string
 */
function yooadmin_studio_hub_filter_product_editor_body_class(string $classes): string {
    if (yooadmin_studio_hub_is_product_editor_screen() && yooadmin_studio_hub_is_active()) {
        $classes .= ' ysh-product-editor-ready';
    }

    return $classes;
}

/**
 * Product editor (post.php / post-new.php?post_type=product) — layout + dark shell.
 */
function yooadmin_studio_hub_print_product_editor_critical(): void {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-product-editor-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-php),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-new-php),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-php) body,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-new-php) body{'
        . 'background:#0b0d11!important;background-color:#0b0d11!important;}'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) #poststuff,'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) .wrap>h1,'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) .wrap>a.page-title-action,'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) #woocommerce-embedded-root,'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) .wrap>hr{'
        . 'display:none!important;visibility:hidden!important;height:0!important;overflow:hidden!important;margin:0!important;padding:0!important;}'
        . 'body.ysh-product-editor-ready #woocommerce-embedded-root,'
        . 'body.post-type-product:is(.post-php,.post-new-php) :is(#woocommerce-embedded-root,.woocommerce-layout,.woocommerce-layout__header){'
        . 'display:none!important;visibility:hidden!important;height:0!important;overflow:hidden!important;}'
        . 'body.ysh-product-editor-active .wrap>a.page-title-action{display:none!important;}'
        . 'body.ysh-product-editor-active #ysh-product-editor-page-head .page-title-action{display:inline-block!important;}'
        . '#ysh-product-editor{display:none!important;}'
        . 'body.ysh-product-editor-active #ysh-product-editor{display:block!important;}'
        . 'body.ysh-product-editor-active #poststuff{'
        . 'visibility:visible!important;height:auto!important;overflow:visible!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php) .yoo-shell-content{'
        . 'max-width:var(--ysh-layout-max,1400px)!important;margin-inline:auto!important;}'
        . 'body.ysh-product-editor-active .yoo-shell-content{padding-top:20px!important;}'
        . 'body.ysh-product-editor-active #wpbody-content>.wrap{background:transparent!important;border:none!important;box-shadow:none!important;}'
        . 'body.ysh-product-editor-active .ysh-product-editor-page{width:100%;margin:0 auto;padding:24px 20px 32px;'
        . 'border-radius:var(--ysh-radius,14px);border:1px solid rgba(0,0,0,.08);background:#fff;box-sizing:border-box;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.ysh-product-editor-active .ysh-product-editor-page{'
        . 'background:#1a1d23;border-color:rgba(255,255,255,.1);}'
        . '.ysh-product-editor__page-head{border-bottom:1px solid rgba(0,0,0,.08);padding-bottom:16px;margin-bottom:20px;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] .ysh-product-editor__page-head{border-bottom-color:rgba(255,255,255,.08);}'
        . 'body.ysh-product-editor-ready #local-storage-notice.hidden,'
        . 'body.ysh-product-editor-active #local-storage-notice.hidden,'
        . 'body.ysh-product-editor-active #ysh-product-editor-page-head #local-storage-notice{'
        . 'display:none!important;margin:0!important;padding:0!important;border:none!important;height:0!important;}'
        . '.ysh-product-editor-notices:empty{display:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php)'
        . ' :is(#wpwrap,#wpcontent,#wpbody,#wpbody-content,.yoo-shell-content){background:#0b0d11!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.ysh-product-editor-active.post-type-product:is(.post-php,.post-new-php)'
        . ' :is(#post,#poststuff,#post-body,#post-body-content){background:transparent!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php)'
        . ' .yp-breadcrumbs-bar{background:#0b0d11!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php) .yp-breadcrumbs-bar{'
        . 'border-top:none!important;border-bottom:none!important;box-shadow:none!important;}'
        . 'body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php) #wpbody-content{'
        . 'padding-top:0!important;margin-top:0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php) #title{'
        . 'background:#22262e!important;border-color:rgba(255,255,255,.14)!important;color:#d8d3ce!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php)'
        . ' :is(.mce-toolbar-grp,.mce-panel,.mce-statusbar,.wp-editor-wrap,.wp-editor-container){'
        . 'background:#22262e!important;border-color:rgba(255,255,255,.1)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php)'
        . ' .mce-edit-area{background:#1a1d23!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php)'
        . ' textarea.wp-editor-area{background:#1a1d23!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.post-type-product.post-php'
        . ' :is(.woocommerce-tour-kit,.woocommerce-tour-kit-step,.tour-kit-frame__container),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.post-type-product.post-php'
        . ' .woocommerce-tour-kit :is(.components-card,.components-card__body){'
        . 'background:#1a1d23!important;color:#cfd6e0!important;border-color:rgba(255,255,255,.12)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.post-type-product.post-php'
        . ' .woocommerce-tour-kit-step__heading{color:#d8d3ce!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.post-type-product.post-php'
        . ' .woocommerce-tour-kit-step__description{color:#9aa3b2!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.post-type-product:is(.post-php,.post-new-php)'
        . ' #wpseo_meta :is(.inside,.wpseo-metabox-content,.wpseo-meta-section-react.active){'
        . 'background:#22262e!important;color:#cfd6e0!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.post-type-product:is(.post-php,.post-new-php)'
        . ' .woocommerce-tour-kit :is(.components-card__footer,.woocommerce-tour-kit-step-navigation){'
        . 'background:#1a1d23!important;border:none!important;border-top:none!important;color:#9aa3b2!important;}'
        . '.ysh-product-editor__page-head{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;width:100%;}'
        . '.ysh-product-editor__page-head :is(h1,.wp-heading-inline){margin:0!important;float:none!important;flex:1 1 auto;min-width:0;}'
        . '.ysh-product-editor__page-head .page-title-action{margin:0!important;float:none!important;flex:0 0 auto;white-space:nowrap;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.post-type-product:is(.post-php,.post-new-php) #submitdiv #major-publishing-actions{'
        . 'background:rgba(255,255,255,.04)!important;border-top-color:rgba(255,255,255,.1)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.post-type-product:is(.post-php,.post-new-php)'
        . ' :is(#poststuff,.ysh-product-editor__sidebar) :is(.categorydiv,.tagsdiv,.taxonomydiv) .tabs-panel,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.post-type-product:is(.post-php,.post-new-php)'
        . ' :is(#poststuff,.ysh-product-editor__sidebar) :is(.categorydiv,.tagsdiv,.taxonomydiv) .wp-tab-panel{'
        . 'background:rgba(255,255,255,.04)!important;border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;}'
        . 'body.ysh-product-editor-ready #woocommerce-embedded-root,'
        . 'body.post-type-product:is(.post-php,.post-new-php) :is(#woocommerce-embedded-root,.woocommerce-layout,.woocommerce-layout__header){display:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.ysh-product-editor-active'
        . ' :is(.tour-kit-frame__container,.components-elevation){background:transparent!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.ysh-product-editor-active'
        . ' .woocommerce-tour-kit :is(.components-card__divider,.components-hr){display:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.ysh-product-editor-active'
        . ' .woocommerce-tour-kit :is(.components-card__footer,.woocommerce-tour-kit-step-navigation){border:none!important;border-top:none!important;}'
        // The product editor has a custom tabbed layout, so any guided tour (YOOAdmin
        // or WooCommerce tour-kit) anchors to moved/hidden targets and renders in the
        // wrong place. Suppress every tour overlay on this screen.
        . 'body.post-type-product:is(.post-php,.post-new-php) :is(.ygt-tour-root,.ygt-overlay,.woocommerce-tour-kit,.tour-kit-frame,.tour-kit-frame__container,[class*="tour-kit"]){'
        . 'display:none!important;visibility:hidden!important;pointer-events:none!important;}'
        // Product-data box: use the YOOAdmin admin font + Studio Hub controls.
        . 'body.ysh-product-editor-active #woocommerce-product-data,'
        . 'body.ysh-product-editor-active #woocommerce-product-data *{'
        . 'font-family:var(--yooadmin-latin-font-family,"Montserrat"),"Tajawal",sans-serif!important;}'
        . 'body.ysh-product-editor-active #woocommerce-product-data .hndle{'
        . 'font-size:14px!important;font-weight:600!important;line-height:1.4!important;}'
        . 'body.ysh-product-editor-active #woocommerce-product-data select{'
        . 'font-size:13px!important;font-weight:500!important;min-height:32px!important;'
        . 'padding:5px 28px 5px 10px!important;border:1px solid rgba(0,0,0,.14)!important;border-radius:8px!important;'
        . 'background-color:#fff!important;color:#1d2327!important;line-height:1.4!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.ysh-product-editor-active #woocommerce-product-data select{'
        . 'background-color:#22262e!important;border-color:rgba(255,255,255,.14)!important;color:#d8d3ce!important;}'
        . 'body.ysh-product-editor-active #woocommerce-product-data label{font-size:13px!important;font-weight:500!important;}'
        . 'body.ysh-product-editor-active #woocommerce-product-data input[type="checkbox"],'
        . 'body.ysh-product-editor-active #woocommerce-product-data input[type="radio"]{'
        . 'accent-color:var(--ysh-brand,#eda934)!important;}'
        . '</style>' . "\n";
}

/**
 * Product editor — loader overlay (in <head>, before paint).
 */
function yooadmin_studio_hub_print_product_editor_loader_critical(): void {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-product-editor-loader">'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) #poststuff,'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) .wrap>h1,'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) .wrap>a.page-title-action,'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) #woocommerce-embedded-root{'
        . 'display:none!important;visibility:hidden!important;height:0!important;overflow:hidden!important;}'
        . 'body.ysh-product-editor-ready #woocommerce-embedded-root,'
        . 'body.post-type-product:is(.post-php,.post-new-php) :is(#woocommerce-embedded-root,.woocommerce-layout,.woocommerce-layout__header){'
        . 'display:none!important;visibility:hidden!important;height:0!important;overflow:hidden!important;margin:0!important;padding:0!important;}'
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) :is(#yoo-shell-content,#wpbody-content){position:relative!important;}'
        // While loading, only the spinner card shows — collapse the (hidden) content
        // wrap so no empty placeholder box appears beneath it.
        . 'body.ysh-product-editor-ready:not(.ysh-product-editor-active) #wpbody-content .wrap{display:none!important;}'
        . '.ysh-pe-loader{position:relative;z-index:100;display:flex;align-items:center;justify-content:center;'
        . 'min-height:60vh;margin:20px auto;max-width:var(--ysh-layout-max,1400px);box-sizing:border-box;'
        . 'border:1px solid rgba(0,0,0,.08);border-radius:14px;background:#fff;pointer-events:auto;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] .ysh-pe-loader{background:#1a1d23;border-color:rgba(255,255,255,.1);}'
        . 'body.ysh-product-editor-active .ysh-pe-loader{display:none!important;visibility:hidden!important;}'
        . '.ysh-pe-loader__spinner{display:block;width:24px;height:24px;border:2px solid rgba(0,0,0,.1);'
        . 'border-top-color:var(--ysh-brand,#eda934);border-radius:50%;animation:ysh-pe-spin .65s linear infinite;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] .ysh-pe-loader__spinner{border-color:rgba(255,255,255,.14);border-top-color:var(--ysh-brand,#eda934);}'
        . '@keyframes ysh-pe-spin{to{transform:rotate(360deg);}}'
        . '</style>' . "\n";
}

/**
 * Product editor — stop WooCommerce embed header placeholder on classic product screens.
 */
function yooadmin_studio_hub_disable_woo_embed_header_on_product_editor(): void {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    if (!class_exists(\Automattic\WooCommerce\Internal\Admin\Loader::class)) {
        return;
    }

    remove_action('in_admin_header', [\Automattic\WooCommerce\Internal\Admin\Loader::class, 'embed_page_header']);
}

/**
 * Product editor — loader markup (inside yoo-shell-content, not over header/footer).
 */
function yooadmin_studio_hub_print_product_editor_loader_markup(): void {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    echo '<div id="ysh-pe-loader" class="ysh-pe-loader" role="status" aria-live="polite" aria-busy="true">'
        . '<span class="ysh-pe-loader__spinner" aria-hidden="true"></span>'
        . '</div>' . "\n";
}

/**
 * Product editor — cascade tail in <head>.
 */
function yooadmin_studio_hub_print_product_editor_cascade_tail(): void {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-product-editor-tail">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-php),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-new-php),'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-php) body,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-new-php) body,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-php) #wpwrap,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]:has(body.post-type-product.post-new-php) #wpcontent{'
        . 'background:#0b0d11!important;scrollbar-color:rgba(255,255,255,.2) #0b0d11!important;}'
        . 'body.yoo-focus.post-type-product:is(.post-php,.post-new-php) #adminmenuback,'
        . 'body.yoo-focus.post-type-product:is(.post-php,.post-new-php) #adminmenuwrap,'
        . 'body.yoo-focus.post-type-product:is(.post-php,.post-new-php) #adminmenumain{display:none!important;}'
        . '</style>' . "\n";
}

/**
 * TinyMCE — dark content area for product editor.
 *
 * @param array<string, mixed> $init Editor init.
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_filter_tinymce_dark(array $init): array {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return $init;
    }

    if (!yooadmin_studio_hub_is_effective_dark_mode()) {
        return $init;
    }

    $content_style = 'body.mce-content-body{background-color:#1a1d23;color:#cfd6e0;}'
        . 'body.mce-content-body a{color:#eda934;}'
        . 'body.mce-content-body p,body.mce-content-body li{color:#cfd6e0;}';

    if (!empty($init['content_style'])) {
        $init['content_style'] .= ' ' . $content_style;
    } else {
        $init['content_style'] = $content_style;
    }

    $init['body_class'] = trim(($init['body_class'] ?? '') . ' ysh-dark-editor');

    return $init;
}

/**
 * Product editor — patch TinyMCE iframe + text mode when dark (incl. auto mode).
 */
function yooadmin_studio_hub_print_product_editor_dark_script(): void {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-product-editor-dark">'
        . '(function(){'
        . 'function yshDarkEditorApply(){'
        . 'var dark=document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";'
        . 'document.querySelectorAll("iframe[id$=\'_ifr\']").forEach(function(frame){'
        . 'try{var doc=frame.contentDocument||frame.contentWindow.document;if(!doc||!doc.body){return;}'
        . 'if(dark){doc.body.classList.add("ysh-dark-editor");doc.body.style.backgroundColor="#1a1d23";doc.body.style.color="#cfd6e0";}'
        . 'else{doc.body.classList.remove("ysh-dark-editor");doc.body.style.backgroundColor="#ffffff";doc.body.style.color="#1f2937";}'
        . '}catch(e){}});'
        . 'document.querySelectorAll("textarea.wp-editor-area").forEach(function(ta){'
        . 'if(dark){ta.style.setProperty("background","#1a1d23","important");ta.style.setProperty("color","#cfd6e0","important");}'
        . 'else{ta.style.removeProperty("background");ta.style.removeProperty("color");}});'
        . '}'
        . 'function yshDarkEditorWatch(){yshDarkEditorApply();'
        . 'if(window.tinymce){tinymce.on("AddEditor",function(){setTimeout(yshDarkEditorApply,50);});}'
        . 'new MutationObserver(function(muts){'
        . 'muts.forEach(function(m){if(m.attributeName==="data-yooadmin-studio-color-mode-effective"){yshDarkEditorApply();}});'
        . '}).observe(document.documentElement,{attributes:true,attributeFilter:["data-yooadmin-studio-color-mode-effective"]});'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",yshDarkEditorWatch);}'
        . 'else{yshDarkEditorWatch();}'
        . 'window.addEventListener("load",yshDarkEditorWatch);'
        . '})();'
        . '</script>' . "\n";
}

/**
 * Product editor — re-apply Yoast width + tour dark surfaces when React mounts late.
 */
function yooadmin_studio_hub_print_product_editor_yoast_tour_watch_script(): void {
    if (!yooadmin_studio_hub_is_product_editor_screen() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-product-editor-yoast-tour-watch">'
        . '(function(){'
        . 'function yshProductYoastTourFix(){'
        . 'var yo=document.getElementById("wpseo_meta");'
        . 'if(yo){yo.style.setProperty("width","100%","important");yo.style.setProperty("max-width","100%","important");'
        . 'yo.querySelectorAll(".wpseo-metabox-content,.wpseo-meta-section-react,#wpseo-metabox-root,.wpseo-metabox-root")'
        . '.forEach(function(el){el.style.setProperty("max-width","none","important");el.style.setProperty("width","100%","important");});}'
        . 'if(document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")!=="dark"){return;}'
        . 'document.querySelectorAll(".tour-kit-frame__container,.tour-kit-frame,.components-elevation")'
        . '.forEach(function(el){el.style.setProperty("background","transparent","important");'
        . 'el.style.setProperty("box-shadow","none","important");});'
        . 'document.querySelectorAll(".woocommerce-tour-kit-step").forEach(function(el){'
        . 'el.style.setProperty("background","#1a1d23","important");el.style.setProperty("color","#cfd6e0","important");'
        . 'el.style.setProperty("box-shadow","0 6px 28px rgba(0,0,0,.4)","important");});'
        . 'document.querySelectorAll(".woocommerce-tour-kit-step__heading").forEach(function(el){'
        . 'el.style.setProperty("color","#d8d3ce","important");});'
        . 'document.querySelectorAll(".woocommerce-tour-kit-step__description,.woocommerce-tour-kit-step-navigation__step,.woocommerce-tour-kit-step-navigation__step-count")'
        . '.forEach(function(el){el.style.setProperty("color","#9aa3b2","important");});'
        . 'document.querySelectorAll(".woocommerce-tour-kit .components-card__footer,.woocommerce-tour-kit-step-navigation,.woocommerce-tour-kit-step-controls")'
        . '.forEach(function(el){el.style.setProperty("background","#1a1d23","important");'
        . 'el.style.setProperty("background-color","#1a1d23","important");'
        . 'el.style.setProperty("border-top","1px solid rgba(255,255,255,.1)","important");'
        . 'el.style.setProperty("opacity","1","important");el.style.setProperty("visibility","visible","important");});'
        . '}'
        . 'function yshProductYoastTourWatch(){yshProductYoastTourFix();'
        . 'var obs=new MutationObserver(function(){yshProductYoastTourFix();});'
        . 'obs.observe(document.body,{childList:true,subtree:true});'
        . 'setInterval(yshProductYoastTourFix,1500);'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",yshProductYoastTourWatch);}'
        . 'else{yshProductYoastTourWatch();}'
        . 'window.addEventListener("load",yshProductYoastTourWatch);'
        . '})();'
        . '</script>' . "\n";
}

