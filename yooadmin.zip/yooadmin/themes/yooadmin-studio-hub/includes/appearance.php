<?php
/**
 * Studio Hub — appearance
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

const YOOADMIN_STUDIO_HUB_WIDTH_META_KEY = 'yooadmin_studio_hub_width_mode';
const YOOADMIN_STUDIO_HUB_COLOR_MODE_META_KEY = 'yooadmin_studio_hub_color_mode';

/**
 * @param string $mode
 */
function yooadmin_studio_hub_normalize_width_mode(string $mode): string {
    $mode = sanitize_key($mode);

    return in_array($mode, ['normal', 'wide', 'full'], true) ? $mode : 'normal';
}

/**
 * @param int $user_id User ID (0 = current).
 */
function yooadmin_studio_hub_get_width_mode(int $user_id = 0): string {
    if ($user_id <= 0) {
        $user_id = (int) get_current_user_id();
    }
    if ($user_id <= 0) {
        return 'normal';
    }

    return yooadmin_studio_hub_normalize_width_mode((string) get_user_meta($user_id, YOOADMIN_STUDIO_HUB_WIDTH_META_KEY, true));
}

/**
 * @param string $mode
 */
function yooadmin_studio_hub_width_css_value(string $mode): string {
    $mode = yooadmin_studio_hub_normalize_width_mode($mode);
    if ($mode === 'full') {
        return 'calc(100% - clamp(24px, 4vw, 64px))';
    }
    if ($mode === 'wide') {
        return '1720px';
    }

    return '1400px';
}

/**
 * Localized strings consumed by the Studio Hub appearance/width controls.
 *
 * @return array<string, string>
 */
function yooadmin_studio_hub_appearance_script_i18n(): array {
    return [
        'widthNormal'     => __('Normal', 'yooadmin'),
        'widthWide'       => __('Wide', 'yooadmin'),
        'widthFull'       => __('Full', 'yooadmin'),
        /* translators: %s: selected page width label. */
        'widthSaved'      => __('Page width saved: %s.', 'yooadmin'),
        'widthSaveFailed' => __('Could not save page width. Please try again.', 'yooadmin'),
    ];
}

/**
 * @return bool
 */
function yooadmin_studio_hub_can_show_width_control(): bool {
    return yooadmin_studio_hub_is_active() && yooadmin_studio_hub_is_focus_enabled();
}

/**
 * Early color-mode attributes (avoid flash before studio-hub.css).
 */
function yooadmin_studio_hub_print_appearance_bootstrap(): void {
    if (!is_admin() || !yooadmin_studio_hub_is_active()) {
        return;
    }

    $is_customizer = function_exists('yooadmin_is_customizer_request') && yooadmin_is_customizer_request();
    if ($is_customizer) {
        if (!function_exists('yooadmin_resolve_focus_preference') || !yooadmin_resolve_focus_preference()) {
            return;
        }
    } elseif (!yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    $mode = yooadmin_studio_hub_get_color_mode();
    $width_mode = yooadmin_studio_hub_get_width_mode();
    $width_css  = yooadmin_studio_hub_width_css_value($width_mode);
    printf(
        '<script id="yooadmin-studio-hub-color-mode">(function(){var m=%1$s;var w=%2$s;var eff="light";if(m==="dark"){eff="dark";}else if(m==="auto"){try{eff=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(e){eff="light";}}var html=document.documentElement;html.classList.remove("ysh-customizer-pane-hidden","ysh-customizer-exiting");function syncBody(){if(!document.body){return;}var isDark=eff==="dark";document.body.classList.toggle("is-dark-theme",isDark);document.body.classList.toggle("ysh-customizer-dark",isDark);}html.setAttribute("data-yooadmin-studio-color-mode",m);html.setAttribute("data-yooadmin-studio-color-mode-effective",eff);html.setAttribute("data-ysh-layout-width",w);html.classList.add("yooadmin-studio-hub-html");html.classList.toggle("is-dark-theme",eff==="dark");if(eff==="dark"){html.style.setProperty("--ysh-card","#1a1d23");html.style.setProperty("--ysh-surface","#121418");html.style.colorScheme="dark";}else{html.style.removeProperty("--ysh-card");html.style.removeProperty("--ysh-surface");html.style.removeProperty("color-scheme");html.style.colorScheme="light";}syncBody();if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",syncBody);}else{syncBody();}})();</script>' . "\n",
        wp_json_encode($mode),
        wp_json_encode($width_mode)
    );

    $colors  = (array) get_option('yooadmin_colors', []);
    $primary = isset($colors['primary']) ? sanitize_hex_color((string) $colors['primary']) : '';
    $header  = isset($colors['header_bg']) ? sanitize_hex_color((string) $colors['header_bg']) : '';
    $sidebar = isset($colors['sidebar_bg']) ? sanitize_hex_color((string) $colors['sidebar_bg']) : '';
    if (!$primary) {
        $primary = '#eda934';
    }
    if (!$header) {
        $header = '#4B4B4B';
    }
    if (!$sidebar) {
        $sidebar = '#4B4B4B';
    }
    $primary_rgb_parts = sscanf($primary, '#%02x%02x%02x');
    $primary_rgb       = is_array($primary_rgb_parts) && count($primary_rgb_parts) === 3
        ? implode(',', array_map('intval', $primary_rgb_parts))
        : '237,169,52';
    $primary_600 = function_exists('yooadmin_get_brand_primary_600_hex')
        ? yooadmin_get_brand_primary_600_hex()
        : $primary;
    printf(
        '<style id="yooadmin-studio-hub-brand-vars">:root,:root.yooadmin-studio-hub-html{--ysh-brand:%1$s;--ysh-brand-rgb:%4$s;--yp-primary-rgb:%4$s;--yooadmin-brand-source:%1$s;--yooadmin-primary:%1$s;--yooadmin-primary-600:%6$s;--yooadmin-primary-hover:%6$s;--yp-primary:%1$s;--yp-primary-600:%6$s;--yooadmin-header-bg-source:%2$s;--yooadmin-sidebar-bg-source:%3$s;--ysh-card:#ffffff;--ysh-surface:#f6f7f8;}'
        . 'html.yooadmin-studio-hub-html body.yooadmin-theme-yooadmin-studio-hub{--ysh-layout-max:%5$s!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"]{--ysh-card:#1a1d23;--ysh-surface:#121418;--yp-plugins-active-row-bg:rgba(255,255,255,0.07);}</style>' . "\n",
        esc_html($primary),
        esc_html($header),
        esc_html($sidebar),
        esc_html($primary_rgb),
        esc_html($width_css),
        esc_html($primary_600)
    );
}

/**
 * Whether Studio Hub may style the native Customizer controls pane.
 * Requires Focus Mode preference ON; vanilla WP customizer when focus is off.
 */
function yooadmin_studio_hub_customizer_dark_applies(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active()) {
        return false;
    }

    if (!function_exists('yooadmin_is_customizer_request') || !yooadmin_is_customizer_request()) {
        return false;
    }

    return function_exists('yooadmin_resolve_focus_preference') && yooadmin_resolve_focus_preference();
}

/**
 * Full Customizer dark stylesheet (controls pane only).
 *
 * Embed preview (Theme Manager iframe) loads the same sheet; layout is guarded
 * by yooadmin-plus customize-embed.php rules at customize_controls_print_styles:1001.
 */
function yooadmin_studio_hub_customizer_full_dark_sheet_applies(): bool {
    return yooadmin_studio_hub_customizer_dark_applies();
}

/**
 * Theme Manager iframe embed inside the live preview modal.
 */
function yooadmin_studio_hub_customizer_embed_preview(): bool {
    if (!function_exists('yooadmin_is_customizer_request') || !yooadmin_is_customizer_request()) {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only routing flag.
    return !empty($_GET['yooadmin_tm_preview']);
}

/**
 * Tiny anti-flash layer for customize.php before the enqueued stylesheet loads.
 */
function yooadmin_studio_hub_print_customizer_dark_critical(): void {
    if (!yooadmin_studio_hub_customizer_dark_applies()) {
        return;
    }

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static critical CSS.
    echo '<style id="yooadmin-studio-hub-customizer-dark-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] .wp-full-overlay-sidebar{background:#121418;color:#d7dde7;color-scheme:dark;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] #customize-controls{background:#121418;color:#d7dde7;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] #customize-controls :is(.wp-full-overlay-sidebar-content,.customize-pane-parent,.customize-pane-child,#customize-theme-controls){background:#121418;color:#d7dde7;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] #customize-controls :is(.accordion-section,.control-section,.accordion-section-title,#customize-info,#customize-header-actions){background:#1a1d23;border-color:rgba(255,255,255,.1);color:#f3f6fb;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer.ysh-customizer-dark #customize-header-actions,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer.ysh-customizer-dark .wp-full-overlay-sidebar .wp-full-overlay-header,'
        . 'body.wp-customizer.ysh-customizer-dark #customize-header-actions,'
        . 'body.wp-customizer.ysh-customizer-dark .wp-full-overlay-sidebar .wp-full-overlay-header{background:#1a1d23!important;border-color:rgba(255,255,255,.075)!important;color:#d7dde7!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer.ysh-customizer-dark .customize-controls-close,'
        . 'body.wp-customizer.ysh-customizer-dark .customize-controls-close{background:#1a1d23!important;border-color:rgba(255,255,255,.075)!important;color:#d7dde7!important;}'
        . '</style>' . "\n";
}

/**
 * Final Customizer dark override, printed after WordPress customize-controls.css.
 */
function yooadmin_studio_hub_print_customizer_dark_tail(): void {
    if (!yooadmin_studio_hub_customizer_dark_applies()) {
        return;
    }

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static Customizer CSS scoped away from the preview iframe.
    echo '<style id="yooadmin-studio-hub-customizer-dark-tail">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-sidebar{background:#121418!important;color:#d7dde7!important;color-scheme:dark;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-header-actions,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-header-actions.wp-full-overlay-header,'
        . 'body.wp-customizer.ysh-customizer-dark #customize-header-actions,'
        . 'body.wp-customizer.ysh-customizer-dark #customize-header-actions.wp-full-overlay-header{background:#1a1d23!important;border-color:rgba(255,255,255,.075)!important;color:#d7dde7!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .customize-controls-close,'
        . 'body.wp-customizer.ysh-customizer-dark .customize-controls-close{background:#1a1d23!important;border-top-color:#1a1d23!important;border-color:rgba(255,255,255,.075)!important;color:#d7dde7!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .customize-controls-close:hover,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .customize-controls-close:focus,'
        . 'body.wp-customizer.ysh-customizer-dark .customize-controls-close:hover,'
        . 'body.wp-customizer.ysh-customizer-dark .customize-controls-close:focus{background:#20242d!important;color:#f3f6fb!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .customize-controls-close:before,'
        . 'body.wp-customizer.ysh-customizer-dark .customize-controls-close:before{color:inherit!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(.wp-full-overlay-sidebar-content,.customize-pane-parent,.customize-pane-child,#customize-theme-controls,#customize-outer-theme-controls,#widgets-right,.accordion-container,.control-panel-content){background:#121418!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(#customize-header-actions,#customize-info,.accordion-section,.control-section,.accordion-section-title,.customize-section-title,.customize-panel-back,.customize-section-back,.customize-panel-description,.customize-section-description,.customize-control,.customize-control-content,.customize-inside-control-row,.menu-item-bar,.menu-item-handle,.widget,.widget-top,.widget-inside){background:#1a1d23!important;border-color:rgba(255,255,255,.075)!important;color:#d7dde7!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(h1,h2,h3,h4,h5,h6,.preview-notice,.panel-title,.accordion-section-title,.customize-control-title,.theme-name,.widget-title,.menu-item-title){color:#f3f6fb!important;-webkit-text-fill-color:#f3f6fb!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(p,li,label,span:not(.dashicons),small,.description,.customize-control-description,.customize-action){color:#d7dde7!important;-webkit-text-fill-color:#d7dde7!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(.accordion-section-title:after,.customize-panel-back:before,.customize-section-back:before,.customize-help-toggle:before,.toggle-indicator:before){color:#9aa4b2!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(a:not(.button),.dashicons){color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(input[type="text"],input[type="search"],input[type="url"],input[type="email"],input[type="number"],input[type="password"],textarea,select){background:#11141a!important;border-color:rgba(255,255,255,.14)!important;color:#d7dde7!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(.button:not(.button-primary):not(.ysh-customizer-mode-toggle):not(.collapse-sidebar):not(.preview-desktop):not(.preview-tablet):not(.preview-mobile),button:not(.button-primary):not(.ysh-customizer-mode-toggle):not(.collapse-sidebar):not(.preview-desktop):not(.preview-tablet):not(.preview-mobile)){background:#20242d!important;border-color:rgba(255,255,255,.14)!important;color:#d7dde7!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(.button-primary,#save){background:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;border-color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;color:#fff!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-theme-controls,html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-theme-controls>ul{background:#1a1d23!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(.accordion-section,.control-section,.accordion-section-title,.control-section .accordion-section-title){border-left:0!important;border-right:0!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer :where(.control-panel-themes .customize-themes-full-container,.control-panel-themes .customize-themes-section,.control-panel-themes .theme-section,.customize-preview-header.themes-filter-bar,.themes-filter-bar,.filter-drawer){background:#121418!important;border-color:rgba(255,255,255,.075)!important;color:#d7dde7!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer :where(.control-panel-themes .customize-themes-section-title,.control-panel-themes .customize-themes-section-title:hover,.control-panel-themes .customize-themes-section-title:focus){background:#1a1d23!important;border-color:rgba(255,255,255,.075)!important;color:#f3f6fb!important;-webkit-text-fill-color:#f3f6fb!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .control-panel-themes .customize-themes-section-title:not(.selected):after{background:transparent!important;border:1px solid rgba(255,255,255,.28)!important;border-radius:50%!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .control-panel-themes .theme-section .customize-themes-section-title.selected{color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;-webkit-text-fill-color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .control-panel-themes .theme-section .customize-themes-section-title.selected:after{background:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;border-color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;color:#fff!important;-webkit-text-fill-color:#fff!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-sidebar{border-right-color:rgba(255,255,255,.08)!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-main{background:#0b0d11!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-main iframe{background:#fff!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer :where(#customize-footer-actions,.wp-full-overlay-footer,.wp-full-overlay-footer .devices-wrapper,.wp-full-overlay-footer .devices,.collapse-sidebar,.collapse-sidebar-label){background:#1a1d23!important;border-color:rgba(255,255,255,.075)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-footer-actions{border-top:1px solid rgba(255,255,255,.075)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices button{background:transparent!important;border-top-color:transparent!important;border-bottom-color:transparent!important;color:#9aa4b2!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices button.active{border-bottom-color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices button:is(:hover,:focus){background:transparent!important;background-color:transparent!important;color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .collapse-sidebar:is(:hover,:focus){color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices button:before{color:currentColor!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .collapse-sidebar-label{background:transparent!important;color:inherit!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .collapse-sidebar-arrow{background:#2a303a!important;background-image:none!important;border:1px solid rgba(255,255,255,.12)!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .collapse-sidebar-arrow:before{color:#d7dde7!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer{--ysh-customizer-flat:#1a1d23;--ysh-customizer-flat-soft:#1d222a;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls,html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(#customize-theme-controls,#customize-theme-controls>ul,#customize-theme-controls .customize-pane-parent,#customize-theme-controls .customize-pane-child,#customize-theme-controls .accordion-section-content,#customize-outer-theme-controls,#customize-outer-theme-controls>ul,.customize-pane-parent,.customize-pane-child,.wp-full-overlay-sidebar-content,.accordion-container,.accordion-section,.control-section,.control-panel,.accordion-section-title,.control-section .accordion-section-title,.control-panel-content,.customize-section-title){background:var(--ysh-customizer-flat)!important;background-color:var(--ysh-customizer-flat)!important;border-left-color:transparent!important;border-right-color:transparent!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(.accordion-section-title:hover,.accordion-section-title:focus,.accordion-section.open .accordion-section-title,.control-section.open .accordion-section-title,.control-section:hover>.accordion-section-title,.customize-panel-back:hover,.customize-section-back:hover){background:var(--ysh-customizer-flat-soft)!important;background-color:var(--ysh-customizer-flat-soft)!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer #customize-controls :where(.accordion-section-title,.control-section .accordion-section-title){border-bottom:1px solid rgba(255,255,255,.075)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer :where(#customize-footer-actions,#customize-footer-actions *:not(.devices),.wp-full-overlay-footer,.wp-full-overlay-footer *:not(.devices)){box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer :where(#customize-footer-actions,.wp-full-overlay-footer,.wp-full-overlay-footer .devices-wrapper,.wp-full-overlay-footer .devices,.collapse-sidebar,.collapse-sidebar-label){background:var(--ysh-customizer-flat)!important;background-color:var(--ysh-customizer-flat)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices{box-shadow:20px 0 10px -5px var(--ysh-customizer-flat,#1a1d23)!important;}'
        . 'html[dir="ltr"][data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices,body.wp-customizer:not(.rtl).ysh-customizer-dark .wp-full-overlay-footer .devices{box-shadow:-20px 0 10px -5px var(--ysh-customizer-flat,#1a1d23)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .collapse-sidebar{background:var(--ysh-customizer-flat,#1a1d23)!important;background-color:var(--ysh-customizer-flat,#1a1d23)!important;border:0!important;color:#9aa4b2!important;box-shadow:none!important;}'
        . 'body.wp-customizer.wp-core-ui .wp-full-overlay .collapse-sidebar:hover,body.wp-customizer.wp-core-ui .wp-full-overlay .collapse-sidebar:focus{color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;}'
        . 'body.wp-customizer .wp-full-overlay .collapse-sidebar:hover .collapse-sidebar-arrow,body.wp-customizer .wp-full-overlay .collapse-sidebar:focus .collapse-sidebar-arrow{box-shadow:0 0 0 1.5px var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;outline:2px solid transparent!important;}'
        . 'body.wp-customizer .collapse-sidebar-arrow:before{background:transparent!important;}'
        . 'body.wp-customizer .collapse-sidebar-label{background:transparent!important;background-color:transparent!important;}'
        . 'body.wp-customizer .wp-full-overlay-footer .devices button:hover,body.wp-customizer .wp-full-overlay-footer .devices button:focus,body.wp-customizer .wp-full-overlay-footer .devices button.active:hover{border-bottom-color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;background-color:transparent!important;}'
        . 'body.wp-customizer .wp-full-overlay-footer .devices button:hover:before,body.wp-customizer .wp-full-overlay-footer .devices button:focus:before,body.wp-customizer .wp-full-overlay-footer .devices button.active:hover:before{color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices button,html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices button.active,html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices button:hover,html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices button:focus{background:transparent!important;background-color:transparent!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-customizer .wp-full-overlay-footer .devices button.active{border-bottom-color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;}'
        . 'body.wp-customizer .ysh-customizer-mode-toggle{background:linear-gradient(180deg,color-mix(in srgb,var(--ysh-brand,var(--yoo-brand-accent,#eda934)) 88%,#fff 12%),var(--ysh-brand,var(--yoo-brand-accent,#eda934)))!important;border:none!important;color:#fff!important;box-shadow:0 1px 2px rgba(15,23,42,.12)!important;}'
        . 'body.wp-customizer .ysh-customizer-mode-toggle:hover,body.wp-customizer .ysh-customizer-mode-toggle:focus{background:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;color:#fff!important;filter:brightness(1.04);}'
        . 'body.wp-customizer .ysh-customizer-mode-toggle.is-dark{background:#20242d!important;border:1px solid color-mix(in srgb,var(--ysh-brand,var(--yoo-brand-accent,#eda934)) 42%,rgba(255,255,255,.14))!important;color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;box-shadow:none!important;filter:none!important;}'
        . 'body.wp-customizer .ysh-customizer-mode-toggle.is-dark:hover,body.wp-customizer .ysh-customizer-mode-toggle.is-dark:focus{background:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;border-color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;color:#fff!important;}'
        . 'body.wp-customizer #customize-save-button-wrapper{display:inline-flex!important;align-items:center!important;gap:8px!important;vertical-align:middle!important;}'
        . 'body.wp-customizer #customize-save-button-wrapper > .ysh-customizer-mode-toggle{float:none!important;margin:0!important;flex-shrink:0!important;}'
        . 'body.wp-customizer #customize-header-actions .button.ysh-customizer-mode-toggle,body.wp-customizer #customize-save-button-wrapper .button.ysh-customizer-mode-toggle{background:linear-gradient(180deg,color-mix(in srgb,var(--ysh-brand,var(--yoo-brand-accent,#eda934)) 88%,#fff 12%),var(--ysh-brand,var(--yoo-brand-accent,#eda934)))!important;border:1px solid color-mix(in srgb,var(--ysh-brand,var(--yoo-brand-accent,#eda934)) 72%,#fff 28%)!important;color:#fff!important;box-shadow:0 1px 2px rgba(15,23,42,.12)!important;}'
        . 'body.wp-customizer #customize-header-actions .button.ysh-customizer-mode-toggle.is-dark,body.wp-customizer #customize-save-button-wrapper .button.ysh-customizer-mode-toggle.is-dark{background:#20242d!important;border:1px solid color-mix(in srgb,var(--ysh-brand,var(--yoo-brand-accent,#eda934)) 42%,rgba(255,255,255,.14))!important;color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;box-shadow:none!important;}'
        . 'html.yooadmin-studio-hub-html body.wp-customizer{--wp-admin-theme-color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;--wp-admin-theme-color-darker-10:color-mix(in srgb,var(--ysh-brand,var(--yoo-brand-accent,#eda934)) 86%,#000 14%)!important;--wp-admin-theme-color-darker-20:color-mix(in srgb,var(--ysh-brand,var(--yoo-brand-accent,#eda934)) 72%,#000 28%)!important;--yoo-brand-accent:var(--ysh-brand,var(--yoo-brand-accent,#eda934));--ysh-customizer-brand:var(--ysh-brand,var(--yoo-brand-accent,#eda934));}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-controls,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer .wp-full-overlay-sidebar-content{background:#f6f7f8!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-theme-controls,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-theme-controls>ul{background:#f6f7f8!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-info,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-info .customize-info{background:#fff!important;border-color:#e5e5e5!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-theme-controls .accordion-section-title,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-info .accordion-section-title{background:#fff!important;border-color:#e5e5e5!important;color:#3c434a!important;border-bottom:1px solid #e5e5e5!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-theme-controls .accordion-section-title:hover,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-theme-controls .accordion-section-title:focus{color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;background:#fff!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-theme-controls .accordion-section-title:after{color:#9aa4b2!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-header-actions,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-footer-actions{background:#f0f0f1!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-controls :where(a:not(.button):not(.button-primary), .button-link, .button.button-link){color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-controls :where(.button-secondary, .change-theme, button.switch-to-editor){color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;border-color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;background:#fff!important;box-shadow:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-controls :where(.button-secondary:hover,.button-secondary:focus,.change-theme:hover,.change-theme:focus,button.switch-to-editor:hover,button.switch-to-editor:focus){color:#fff!important;background:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;border-color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-notifications-area .notice{background:#fff!important;border-inline-start:4px solid var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;border-top-color:#e5e5e5!important;border-bottom-color:#e5e5e5!important;border-right-color:#e5e5e5!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer #customize-notifications-area .notice a{color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer .customize-section-title,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer .customize-section-title h3,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer h3.customize-section-title{background:#fff!important;border-bottom:1px solid #e5e5e5!important;color:#3c434a!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer .customize-section-title span.customize-action{color:#646970!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer .customize-panel-back,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer .customize-section-back{background:#fff!important;border-top:none!important;border-bottom:none!important;border-inline-end:1px solid #e5e5e5!important;border-inline-start:4px solid #fff!important;color:#50575e!important;}'
        . 'html.yooadmin-studio-hub-html body.wp-customizer.wp-core-ui #customize-controls .control-section:hover>.accordion-section-title,html.yooadmin-studio-hub-html body.wp-customizer.wp-core-ui #customize-controls .control-section .accordion-section-title:hover,html.yooadmin-studio-hub-html body.wp-customizer.wp-core-ui #customize-controls .control-section.open .accordion-section-title,html.yooadmin-studio-hub-html body.wp-customizer.wp-core-ui #customize-controls .control-section .accordion-section-title:focus,html.yooadmin-studio-hub-html body.wp-customizer.wp-core-ui .customize-panel-back:hover,html.yooadmin-studio-hub-html body.wp-customizer.wp-core-ui .customize-panel-back:focus,html.yooadmin-studio-hub-html body.wp-customizer.wp-core-ui .customize-section-back:hover,html.yooadmin-studio-hub-html body.wp-customizer.wp-core-ui .customize-section-back:focus{color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;border-inline-start-color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer.wp-core-ui .customize-panel-back:hover,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer.wp-core-ui .customize-panel-back:focus,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer.wp-core-ui .customize-section-back:hover,html[data-yooadmin-studio-color-mode-effective="light"] body.wp-customizer.wp-core-ui .customize-section-back:focus{background:#f6f7f8!important;}'
        . 'body.wp-customizer.ysh-customizer-dark #customize-controls,body.wp-customizer.ysh-customizer-dark .wp-full-overlay-sidebar-content,body.wp-customizer.ysh-customizer-dark #customize-theme-controls,body.wp-customizer.ysh-customizer-dark #customize-theme-controls>ul,body.wp-customizer.ysh-customizer-dark #customize-theme-controls .control-section .accordion-section-title{background:#1a1d23!important;color:#d7dde7!important;border-color:rgba(255,255,255,.075)!important;}'
        . 'body.wp-customizer.ysh-customizer-dark #customize-theme-controls .accordion-section-title:hover,body.wp-customizer.ysh-customizer-dark #customize-theme-controls .accordion-section-title:focus{background:#1d222a!important;color:var(--ysh-brand,var(--yoo-brand-accent,#eda934))!important;}'
        . 'body.wp-customizer .button-primary,body.wp-customizer #save{background:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;border-color:var(--yoo-brand-accent,var(--ysh-brand,#eda934))!important;color:#fff!important;}'
        . '</style>' . "\n";
}

/**
 * Dark mode for the Customizer controls pane only; the site preview iframe is untouched.
 */
function yooadmin_studio_hub_enqueue_customizer_dark_assets(): void {
    if (!yooadmin_studio_hub_customizer_full_dark_sheet_applies()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-customizer-dark.css');
    if (!is_readable($file)) {
        return;
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-customizer-dark',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-customizer-dark.css'),
        ['customize-controls'],
        (string) filemtime($file)
    );
}

/**
 * Compact Light/Dark toggle beside the Customizer publish button (header).
 *
 * Inline script + mount in #customize-save-button-wrapper — same approach as the
 * stable build; avoids wp.customize pane hooks that empty the sections list.
 */
function yooadmin_studio_hub_print_customizer_mode_toggle_script(): void {
    if (!yooadmin_studio_hub_customizer_dark_applies()) {
        return;
    }

    $config = [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('yooadmin_studio_hub_color_mode'),
        'mode'    => yooadmin_studio_hub_get_color_mode(),
        'i18n'    => [
            'dark'  => __('Dark mode', 'yooadmin'),
            'light' => __('Light mode', 'yooadmin'),
        ],
    ];

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON-encoded config and static Customizer JS.
    printf(
        '<script id="yooadmin-studio-hub-customizer-mode-toggle">'
        . '(function(cfg){'
        . 'if(!cfg||!cfg.ajaxUrl||!cfg.nonce){return;}'
        . 'var html=document.documentElement;'
        . 'function eff(mode){if(mode==="auto"){try{return window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";}catch(e){return "light";}}return mode==="dark"?"dark":"light";}'
        . 'function apply(mode){var effective=eff(mode);var isDark=effective==="dark";html.setAttribute("data-yooadmin-studio-color-mode",mode);html.setAttribute("data-yooadmin-studio-color-mode-effective",effective);html.classList.add("yooadmin-studio-hub-html");html.classList.toggle("is-dark-theme",isDark);if(document.body){document.body.classList.toggle("is-dark-theme",isDark);document.body.classList.toggle("ysh-customizer-dark",isDark);}if(isDark){html.style.setProperty("--ysh-card","#1a1d23");html.style.setProperty("--ysh-surface","#121418");html.style.colorScheme="dark";}else{html.style.removeProperty("--ysh-card");html.style.removeProperty("--ysh-surface");html.style.colorScheme="light";}syncButton();notifyParent(mode,effective);try{document.dispatchEvent(new CustomEvent("ysh-studio-color-mode-changed",{detail:{mode:mode,effective:effective}}));}catch(e){}}'
        . 'function notifyParent(mode,effective){try{if(window.parent&&window.parent!==window){window.parent.postMessage(JSON.stringify({id:"yooadmin-studio-color-mode",channel:"yooadmin-tm-customizer",data:{mode:mode,effective:effective}}),window.location.origin);}}catch(e){}}'
        . 'function icon(dark){return dark?\'<svg class="ysh-customizer-mode-toggle__svg" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.8 1.42-1.42zm10.48 0l1.79-1.8 1.41 1.41-1.8 1.79-1.4-1.4zM12 4V1h-1v3h1zm0 19v-3h-1v3h1zM4 11H1v1h3v-1zm19 0h-3v1h3v-1zm-2.76 7.16l1.8 1.79 1.41-1.41-1.79-1.8-1.42 1.42zM4.84 17.24l-1.79 1.8 1.41 1.41 1.8-1.79-1.42-1.42zM12 6.5a5.5 5.5 0 1 1 0 11 5.5 5.5 0 0 1 0-11z"/></svg>\':\'<svg class="ysh-customizer-mode-toggle__svg" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>\';}'
        . 'function syncButton(){var btn=document.getElementById("ysh-customizer-mode-toggle");if(!btn){return;}var dark=html.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";btn.classList.toggle("is-dark",dark);btn.setAttribute("aria-pressed",dark?"true":"false");btn.title=dark?cfg.i18n.light:cfg.i18n.dark;btn.setAttribute("aria-label",btn.title);btn.innerHTML=icon(dark);}'
        . 'function save(next){apply(next);var fd=new FormData();fd.append("action","yooadmin_save_studio_hub_color_mode");fd.append("nonce",cfg.nonce);fd.append("color_mode",next);fetch(cfg.ajaxUrl,{method:"POST",body:fd,credentials:"same-origin"}).then(function(r){return r.json();}).then(function(json){if(json&&json.success&&json.data&&json.data.color_mode){apply(json.data.color_mode);}}).catch(function(){});}'
        . 'function mount(){var host=document.getElementById("customize-save-button-wrapper");if(!host){syncButton();return;}var btn=document.getElementById("ysh-customizer-mode-toggle");if(!btn){btn=document.createElement("button");btn.type="button";btn.id="ysh-customizer-mode-toggle";btn.className="button ysh-customizer-mode-toggle";btn.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();var dark=html.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";save(dark?"light":"dark");});}if(btn.parentNode!==host){host.insertBefore(btn,host.firstChild);}syncButton();}'
        . 'apply(cfg.mode==="dark"||cfg.mode==="light"||cfg.mode==="auto"?cfg.mode:"auto");'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",mount);}else{mount();}'
        . 'window.addEventListener("load",mount);'
        . '})(%s);'
        . '</script>' . "\n",
        wp_json_encode($config)
    );
}

/**
 * Light shell: map Studio tokens to YOOAdmin brand colors.
 */
function yooadmin_studio_hub_print_shell_color_bridge(): void {
    if (!is_admin() || !yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    printf(
        '<style id="yooadmin-studio-hub-shell-bridge">html[data-yooadmin-studio-color-mode-effective="light"] body.yooadmin-theme-yooadmin-studio-hub{'
        . '--yp-header-bg:var(--yooadmin-header-bg, #4B4B4B);'
        . '--ysh-breadcrumbs-bg:var(--yooadmin-breadcrumbs-bg, #ffffff);'
        . '--ysh-breadcrumb-fg:var(--yooadmin-breadcrumbs-fg, var(--yooadmin-text-600, #5d5d5d));'
        . '--ysh-header-fg:var(--yp-text-contrast, var(--yooadmin-text-contrast, #fff));'
        . '--ysh-menu-popover-fg:var(--yooadmin-text-600, #5d5d5d);'
        . '--ysh-heading:var(--yooadmin-text-600, #5d5d5d);'
        . '--ysh-muted:var(--yooadmin-text-500, #555555);'
        . '}</style>' . "\n"
    );
}

/**
 * @param string $url
 * @param array|null $theme
 */
function yooadmin_studio_hub_filter_sidebar_logo_url(string $url, $theme): string {
    if (!yooadmin_studio_hub_is_active()) {
        return $url;
    }

    $options = get_option('yooadmin_options', []);
    if (is_array($options) && !empty($options['logo_url'])) {
        return $url;
    }

    if (!defined('YOOADMIN_PLUGIN_FILE')) {
        return $url;
    }

    $path = wp_normalize_path(plugin_dir_path(YOOADMIN_PLUGIN_FILE) . 'assets/images/logo.png');
    if (!file_exists($path)) {
        return $url;
    }

    return esc_url(plugins_url('assets/images/logo.png', YOOADMIN_PLUGIN_FILE));
}

/**
 * @return bool
 */
function yooadmin_studio_hub_can_show_appearance_control(): bool {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return false;
    }
    if (!class_exists('YOOAdmin_Admin_Theme_Manager')) {
        return false;
    }

    $tm = YOOAdmin_Admin_Theme_Manager::get_instance();

    return $tm && $tm->theme_has_feature('appearance_mode');
}

/**
 * Studio Hub appearance toggle (light / dark / auto) — same markup as breadcrumbs bar.
 *
 * @param array<string, string> $args id_prefix, toggle_id, menu_id.
 */
function yooadmin_studio_hub_render_appearance_control(array $args = []): void {
    if (!yooadmin_studio_hub_can_show_appearance_control()) {
        return;
    }

    $id_prefix = isset($args['id_prefix']) ? sanitize_key((string) $args['id_prefix']) : 'ysh';
    $toggle_id = isset($args['toggle_id']) ? sanitize_html_class((string) $args['toggle_id']) : $id_prefix . '-appearance-toggle';
    $menu_id   = isset($args['menu_id']) ? sanitize_html_class((string) $args['menu_id']) : $id_prefix . '-appearance-menu';

    $color_mode = yooadmin_studio_hub_get_color_mode();

    $svg_light = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('light', 18) : '';
    $svg_dark  = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('dark', 18) : '';
    $icon_auto = function_exists('yooadmin_appearance_mode_icon_svg') ? yooadmin_appearance_mode_icon_svg('auto', 18) : '';
    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG / icon markup.
    ?>
    <div class="ysh-appearance" data-ysh-appearance-root>
        <button type="button"
                class="ysh-appearance__toggle"
                id="<?php echo esc_attr($toggle_id); ?>"
                aria-expanded="false"
                aria-haspopup="true"
                aria-controls="<?php echo esc_attr($menu_id); ?>"
                title="<?php esc_attr_e('Color mode', 'yooadmin'); ?>"
                aria-label="<?php esc_attr_e('Color mode', 'yooadmin'); ?>">
            <span class="ysh-appearance__toggle-icons" aria-hidden="true">
                <span class="ysh-appearance__ti ysh-appearance__ti--light<?php echo $color_mode === 'light' ? ' is-current' : ''; ?>"><?php echo $svg_light; ?></span>
                <span class="ysh-appearance__ti ysh-appearance__ti--dark<?php echo $color_mode === 'dark' ? ' is-current' : ''; ?>"><?php echo $svg_dark; ?></span>
                <span class="ysh-appearance__ti ysh-appearance__ti--auto<?php echo $color_mode === 'auto' ? ' is-current' : ''; ?>"><?php echo $icon_auto; ?></span>
            </span>
        </button>
        <div class="ysh-appearance__menu" id="<?php echo esc_attr($menu_id); ?>" role="group" aria-label="<?php esc_attr_e('Choose color mode', 'yooadmin'); ?>" hidden>
            <button type="button" class="ysh-appearance__option<?php echo $color_mode === 'light' ? ' is-active' : ''; ?>" data-ysh-appearance="light" title="<?php esc_attr_e('Light', 'yooadmin'); ?>">
                <?php echo $svg_light; ?>
                <span class="screen-reader-text"><?php esc_html_e('Light', 'yooadmin'); ?></span>
            </button>
            <button type="button" class="ysh-appearance__option<?php echo $color_mode === 'dark' ? ' is-active' : ''; ?>" data-ysh-appearance="dark" title="<?php esc_attr_e('Dark', 'yooadmin'); ?>">
                <?php echo $svg_dark; ?>
                <span class="screen-reader-text"><?php esc_html_e('Dark', 'yooadmin'); ?></span>
            </button>
            <button type="button" class="ysh-appearance__option<?php echo $color_mode === 'auto' ? ' is-active' : ''; ?>" data-ysh-appearance="auto" title="<?php esc_attr_e('Auto', 'yooadmin'); ?>">
                <?php echo $icon_auto; ?>
                <span class="screen-reader-text"><?php esc_html_e('Auto', 'yooadmin'); ?></span>
            </button>
        </div>
    </div>
    <?php
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Studio Hub page width control (normal / wide / full), saved per user.
 *
 * @param array<string, string> $args id_prefix, toggle_id, menu_id.
 */
function yooadmin_studio_hub_render_width_control(array $args = []): void {
    if (!yooadmin_studio_hub_can_show_width_control()) {
        return;
    }

    $id_prefix = isset($args['id_prefix']) ? sanitize_key((string) $args['id_prefix']) : 'ysh';
    $toggle_id = isset($args['toggle_id']) ? sanitize_html_class((string) $args['toggle_id']) : $id_prefix . '-width-toggle';
    $menu_id   = isset($args['menu_id']) ? sanitize_html_class((string) $args['menu_id']) : $id_prefix . '-width-menu';
    $context   = isset($args['context']) ? sanitize_key((string) $args['context']) : 'bar';
    $mode      = yooadmin_studio_hub_get_width_mode();

    $icon_normal = '<svg class="ysh-width__svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><rect x="5.5" y="4.5" width="13" height="15" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9 9h6M9 12h6M9 15h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    $icon_wide   = '<svg class="ysh-width__svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><rect x="3" y="5.5" width="18" height="13" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M7 10h10M7 14h7" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    $icon_full   = '<svg class="ysh-width__svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 8H4v3M16 8h4v3M8 16H4v-3M16 16h4v-3" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    $icons       = [
        'normal' => $icon_normal,
        'wide'   => $icon_wide,
        'full'   => $icon_full,
    ];

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup.
    ?>
    <div class="ysh-width<?php echo $context === 'overflow' ? ' ysh-width--overflow' : ''; ?>" data-ysh-width-root data-ysh-width-current="<?php echo esc_attr($mode); ?>" aria-busy="false">
        <button type="button"
                class="ysh-width__toggle ysh-width__toggle--<?php echo esc_attr($mode); ?>"
                id="<?php echo esc_attr($toggle_id); ?>"
                aria-expanded="false"
                aria-haspopup="true"
                aria-controls="<?php echo esc_attr($menu_id); ?>"
                title="<?php esc_attr_e('Page width', 'yooadmin'); ?>"
                aria-label="<?php esc_attr_e('Page width', 'yooadmin'); ?>">
            <span class="ysh-width__toggle-icon" aria-hidden="true"><?php echo $icons[ $mode ]; ?></span>
        </button>
        <div class="ysh-width__menu" id="<?php echo esc_attr($menu_id); ?>" role="group" aria-label="<?php esc_attr_e('Choose page width', 'yooadmin'); ?>" hidden>
            <button type="button" class="ysh-width__option<?php echo $mode === 'normal' ? ' is-active' : ''; ?>" data-ysh-width="normal" title="<?php esc_attr_e('Normal width', 'yooadmin'); ?>" aria-pressed="<?php echo $mode === 'normal' ? 'true' : 'false'; ?>">
                <?php echo $icon_normal; ?>
                <span class="screen-reader-text"><?php esc_html_e('Normal width', 'yooadmin'); ?></span>
            </button>
            <button type="button" class="ysh-width__option<?php echo $mode === 'wide' ? ' is-active' : ''; ?>" data-ysh-width="wide" title="<?php esc_attr_e('Wide width', 'yooadmin'); ?>" aria-pressed="<?php echo $mode === 'wide' ? 'true' : 'false'; ?>">
                <?php echo $icon_wide; ?>
                <span class="screen-reader-text"><?php esc_html_e('Wide width', 'yooadmin'); ?></span>
            </button>
            <button type="button" class="ysh-width__option<?php echo $mode === 'full' ? ' is-active' : ''; ?>" data-ysh-width="full" title="<?php esc_attr_e('Full width', 'yooadmin'); ?>" aria-pressed="<?php echo $mode === 'full' ? 'true' : 'false'; ?>">
                <?php echo $icon_full; ?>
                <span class="screen-reader-text"><?php esc_html_e('Full width', 'yooadmin'); ?></span>
            </button>
        </div>
    </div>
    <?php
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * AJAX: persist appearance color mode from breadcrumbs control.
 */
/**
 * Persist light / dark / auto for the current user and active theme defaults.
 *
 * @param string $mode light|dark|auto
 */
function yooadmin_studio_hub_persist_color_mode_preference(string $mode): void {
    if (!in_array($mode, ['light', 'dark', 'auto'], true)) {
        return;
    }

    if (class_exists('YOOAdmin_Admin_Theme_Manager') && yooadmin_studio_hub_is_active()) {
        YOOAdmin_Admin_Theme_Manager::get_instance()->save_appearance_color_mode('yooadmin-studio-hub', $mode);
        return;
    }

    if (is_user_logged_in()) {
        update_user_meta((int) get_current_user_id(), YOOADMIN_STUDIO_HUB_COLOR_MODE_META_KEY, $mode);
    }
}

/**
 * AJAX: persist appearance color mode from breadcrumbs control.
 */
function yooadmin_studio_hub_ajax_save_color_mode(): void {
    check_ajax_referer('yooadmin_studio_hub_color_mode', 'nonce');

    if (!is_user_logged_in() || !current_user_can('read')) {
        wp_send_json_error(['message' => __('Sorry, you are not allowed to modify this preference.', 'yooadmin')], 403);
    }

    if (!yooadmin_studio_hub_is_active()) {
        wp_send_json_error(['message' => __('Studio Hub is not the active theme.', 'yooadmin')], 400);
    }

    $raw = isset($_POST['color_mode']) ? sanitize_key((string) wp_unslash($_POST['color_mode'])) : '';
    if (!in_array($raw, ['light', 'dark', 'auto'], true)) {
        wp_send_json_error(['message' => __('Invalid appearance mode.', 'yooadmin')], 400);
    }

    yooadmin_studio_hub_persist_color_mode_preference($raw);

    wp_send_json_success(['color_mode' => $raw]);
}

/**
 * AJAX: persist page width preference per user.
 */
function yooadmin_studio_hub_ajax_save_width_mode(): void {
    check_ajax_referer('yooadmin_studio_hub_color_mode', 'nonce');

    if (!is_user_logged_in() || !current_user_can('read')) {
        wp_send_json_error(['message' => __('Sorry, you are not allowed to modify this preference.', 'yooadmin')], 403);
    }

    if (!yooadmin_studio_hub_is_active()) {
        wp_send_json_error(['message' => __('Studio Hub is not the active theme.', 'yooadmin')], 400);
    }

    $raw = isset($_POST['width_mode'])
        ? yooadmin_studio_hub_normalize_width_mode(sanitize_key(wp_unslash($_POST['width_mode'])))
        : 'normal';
    update_user_meta((int) get_current_user_id(), YOOADMIN_STUDIO_HUB_WIDTH_META_KEY, $raw);

    wp_send_json_success(
        [
            'width_mode' => $raw,
            'layout_max' => yooadmin_studio_hub_width_css_value($raw),
        ]
    );
}

/**
 * Safety belt: core theme manager should skip shell assets when Focus is off; dequeue if anything slipped through.
 */
function yooadmin_studio_hub_dequeue_shell_when_focus_off(): void {
    if (!yooadmin_studio_hub_is_active() || yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    foreach (
        [
            'yooadmin-studio-hub-dashboard',
            'yooadmin-studio-hub-late',
            'yooadmin-studio-hub-plugins-php-dark',
            'yooadmin-studio-hub-plugins-php-layout',
            'yooadmin-studio-hub-plugin-information-dark',
            'yooadmin-studio-hub-themes-php-dark',
            'yooadmin-studio-hub-block-editor-dark',
            'yooadmin-studio-hub-block-editor-layout',
            'yooadmin-studio-hub-woo',
            'yooadmin-studio-hub-woo-early',
            'yooadmin-admin-theme-compat-woo',
            'yooadmin-studio-hub-wc-reports',
        ] as $handle
    ) {
        wp_dequeue_style($handle);
        wp_deregister_style($handle);
        wp_dequeue_script($handle);
        wp_deregister_script($handle);
    }
}

