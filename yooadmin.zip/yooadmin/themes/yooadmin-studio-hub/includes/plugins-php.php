<?php
/**
 * Studio Hub — native plugins.php dark mode cascade.
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Native WordPress plugins list screen.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_plugins_php_page(): bool {
    if (!is_admin()) {
        return false;
    }

    global $pagenow;

    return isset($pagenow) && $pagenow === 'plugins.php';
}

/**
 * Plugin Install Basic toggle + Focus Mode (plugins.php + plugin-install.php styling).
 *
 * @return bool
 */
function yooadmin_studio_hub_plugin_install_basic_active(): bool {
    if (!function_exists('yooadmin_plugin_install_basic_option_enabled') || !yooadmin_plugin_install_basic_option_enabled()) {
        return false;
    }

    return yooadmin_studio_hub_is_focus_enabled();
}

/**
 * Diagnostic native mode for plugins.php.
 *
 * Keeps the WordPress plugins list/actions on their native flow while we verify
 * whether the YOOAdmin JS layout/SPA layer is causing the page issues.
 *
 * @return bool
 */
function yooadmin_studio_hub_plugins_php_native_mode_enabled(): bool {
    return false;
}

/**
 * Native plugins.php YOOAdmin layout / dark styling.
 *
 * @return bool
 */
function yooadmin_studio_hub_should_style_plugins_php_experience(): bool {
    if (yooadmin_studio_hub_plugins_php_native_mode_enabled()) {
        return false;
    }

    return yooadmin_studio_hub_is_active()
        && yooadmin_studio_hub_plugin_install_basic_active()
        && yooadmin_studio_hub_is_plugins_php_page();
}

/**
 * Dark cascade tail after yp-admin-core + wp-admin list-tables.css.
 */
function yooadmin_studio_hub_enqueue_plugins_php_dark_tail(): void {
    if (!yooadmin_studio_hub_should_style_plugins_php_experience()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugins-php-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $deps = ['yooadmin-studio-hub-late'];
    if (wp_style_is('yooadmin-studio-hub-plugins-php-layout', 'registered') || wp_style_is('yooadmin-studio-hub-plugins-php-layout', 'enqueued')) {
        $deps[] = 'yooadmin-studio-hub-plugins-php-layout';
    }
    foreach (['yooadmin-core', 'list-tables'] as $handle) {
        if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
            $deps[] = $handle;
        }
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-plugins-php-dark',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugins-php-dark.css'),
        array_values(array_unique($deps)),
        (string) filemtime($file)
    );
}

/**
 * Critical dark rules for plugins table (first paint).
 */
function yooadmin_studio_hub_print_plugins_php_critical(): void {
    if (!yooadmin_studio_hub_should_style_plugins_php_experience()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-plugins-php-critical">'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table .wp-list-table.plugins :is(thead,tfoot) tr,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table .wp-list-table.plugins :is(thead,tfoot) tr{background:transparent!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table .wp-list-table.plugins :is(thead,tfoot) :is(th,td),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table .wp-list-table.plugins :is(thead,tfoot) :is(th,td){'
        . 'background:#22262e!important;background-color:#22262e!important;color:#c2ccd6!important;-webkit-text-fill-color:#c2ccd6!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table{background:#1a1d23!important;border-color:rgba(255,255,255,.1)!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table .wp-list-table.plugins tbody tr:not(.plugin-update-tr) :is(th,td),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table .wp-list-table.plugins tbody tr:not(.plugin-update-tr) :is(th,td){background:rgba(255,255,255,.02)!important;color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table .wp-list-table.plugins tbody tr.active:not(.plugin-update-tr) :is(th,td),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub.plugins-php'
        . ' #wpbody-content .yoo-plugins-table .wp-list-table.plugins tbody tr.active:not(.plugin-update-tr) :is(th,td){background:rgba(237,169,52,.1)!important;color:#cfd6e0!important;}'
        . '</style>' . "\n";
}

/**
 * Re-link plugins.php dark tail late in <head>.
 */
function yooadmin_studio_hub_print_plugins_php_cascade_tail(): void {
    if (!yooadmin_studio_hub_should_style_plugins_php_experience()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugins-php-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugins-php-dark.css');
    $ver = (string) filemtime($file);
    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Late cascade tail must load after wp-admin in <head>.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-plugins-php-cascade-tail" href="%s" />' . "\n",
        esc_url(add_query_arg('ver', $ver, $url))
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

/**
 * Footer dark rules — beats late wp-admin styles in <head>.
 */
function yooadmin_studio_hub_print_plugins_php_footer_dark(): void {
    if (!yooadmin_studio_hub_should_style_plugins_php_experience()) {
        return;
    }

    $dark = ':is(html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"])';
    $body = 'body.plugins-php #wpbody-content';
    $table = $body . ' .wp-list-table.plugins';
    $yoo = $body . ' .yoo-plugins-table .wp-list-table.plugins';

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static critical CSS.
    echo '<style id="yooadmin-studio-hub-plugins-php-footer">'
        . $dark . ' ' . $body . ' .yoo-plugins-table{background:#1a1d23!important;border-color:rgba(255,255,255,.1)!important;}'
        . $dark . ' ' . $table . ' tbody tr{background:transparent!important;}'
        . $dark . ' ' . $yoo . ' tbody tr:not(.plugin-update-tr)> :is(td,th),'
        . $dark . ' ' . $table . ' tbody tr:not(.plugin-update-tr)> :is(td,th){'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $dark . ' ' . $yoo . ' tbody tr.active:not(.plugin-update-tr)> :is(td,th),'
        . $dark . ' ' . $table . ' tbody tr.active:not(.plugin-update-tr)> :is(td,th),'
        . $dark . ' ' . $table . ' .active> :is(td,th){background:rgba(237,169,52,.12)!important;color:#cfd6e0!important;}'
        . $dark . ' ' . $table . ' tr.no-items> :is(td,th),'
        . $dark . ' ' . $table . ' td.colspanchange{'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $dark . ' ' . $table . ' tr.no-items a{color:#eda934!important;}'
        . $dark . ' ' . $table . ' :is(.plugin-title,.plugin-title strong,.column-description,.column-description p,.desc){color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $dark . ' ' . $table . ' .plugin-title strong{color:#e8ecf1!important;-webkit-text-fill-color:#e8ecf1!important;}'
        . $dark . ' ' . $table . ' .row-actions a{color:#eda934!important;}'
        . $dark . ' body.plugins-php.yooadmin-plugins-page .yp-breadcrumbs-bar .yp-bc-link,'
        . $dark . ' body.plugins-php.yooadmin-plugins-page .yp-breadcrumbs-bar .yp-bc-link .dashicons,'
        . $dark . ' body.plugins-php.yooadmin-plugins-page .yp-breadcrumbs-bar .yp-bc-home-icon{'
        . 'color:#eda934!important;-webkit-text-fill-color:#eda934!important;}'
        . $dark . ' body.plugins-php.yooadmin-plugins-page .yp-breadcrumbs-bar .yp-command-palette-trigger,'
        . $dark . ' body.plugins-php.yooadmin-plugins-page .yp-breadcrumbs-bar .yp-command-palette-trigger'
        . ' :is(.yp-command-palette-trigger__icon,.yp-command-palette-trigger__kbd,.dashicons){'
        . 'color:#eda934!important;-webkit-text-fill-color:#eda934!important;}'
        . $dark . ' body.plugins-php.yooadmin-plugins-page .yp-breadcrumbs-bar .yp-bc-current,'
        . $dark . ' body.plugins-php.yooadmin-plugins-page .yp-breadcrumbs-bar .yp-breadcrumbs-inner{'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $dark . ' body.plugins-php.yooadmin-plugins-page #wpbody-content>.wrap.yooadmin-plugins-page'
        . ' .yoo-pages-toolbar a.yoo-filter-chip.is-active,'
        . $dark . ' body.plugins-php.yooadmin-plugins-page #wpbody-content>.wrap.yooadmin-plugins-page'
        . ' .yoo-pages-toolbar a.yoo-filter-chip.is-active :is(*,.yoo-filter-count){'
        . 'color:#fff!important;-webkit-text-fill-color:#fff!important;}'
        . $dark . ' body.plugins-php.yooadmin-plugins-page #wpbody-content>.wrap.yooadmin-plugins-page'
        . ' .yoo-pages-hero__actions .yp-yoo-btn--primary,'
        . $dark . ' body.plugins-php.yooadmin-plugins-page #wpbody-content>.wrap.yooadmin-plugins-page'
        . ' .yoo-pages-hero__actions .yp-yoo-btn--primary :is(*,.dashicons){'
        . 'color:#fff!important;-webkit-text-fill-color:#fff!important;}'
        . $dark . ' #wf-onboarding-banner{background:#22262e!important;border:1px solid rgba(237,169,52,.45)!important;border-left:4px solid #eda934!important;color:#e8ecf1!important;}'
        . $dark . ' #wf-onboarding-plugin-header-content,'
        . $dark . ' .wf-onboarding-modal-content{background:#1a1d23!important;color:#cfd6e0!important;}'
        . '@media (max-width:782px){'
        . $dark . ' ' . $body . ' .yoo-plugins-table{background:transparent!important;border:0!important;box-shadow:none!important;}'
        . $dark . ' ' . $yoo . ' tbody tr:not(.plugin-update-tr),'
        . $dark . ' ' . $table . ' tbody tr:not(.plugin-update-tr){'
        . 'background:#22262e!important;background-color:#22262e!important;border:1px solid rgba(255,255,255,.1)!important;border-radius:12px!important;box-shadow:none!important;}'
        . $dark . ' ' . $yoo . ' tbody tr.active:not(.plugin-update-tr),'
        . $dark . ' ' . $table . ' tbody tr.active:not(.plugin-update-tr){'
        . 'background:#22262e!important;background-color:#22262e!important;}'
        . $dark . ' ' . $yoo . ' tbody tr:not(.plugin-update-tr)> :is(td,th),'
        . $dark . ' ' . $table . ' tbody tr:not(.plugin-update-tr)> :is(td,th),'
        . $dark . ' ' . $yoo . ' tbody tr.active:not(.plugin-update-tr)> :is(td,th),'
        . $dark . ' ' . $table . ' tbody tr.active:not(.plugin-update-tr)> :is(td,th),'
        . $dark . ' ' . $table . ' .active> :is(td,th){'
        . 'background:transparent!important;background-color:transparent!important;border:0!important;box-shadow:none!important;}'
        . $dark . ' ' . $table . ' :is(.column-description,.column-auto-updates){margin-top:0!important;padding-top:14px!important;border-top:1px solid rgba(255,255,255,.1)!important;}'
        . $dark . ' ' . $table . ' .row-actions span{flex:0 0 auto!important;width:auto!important;margin:0!important;}'
        . '}'
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}
