<?php
/**
 * Studio Hub — helpers
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Absolute path to the Studio Hub theme root directory.
 */
function yooadmin_studio_hub_theme_dir(): string {
    return dirname(__DIR__);
}

/**
 * Absolute path under assets/ (e.g. css/core/tokens.css).
 */
function yooadmin_studio_hub_asset_path(string $relative): string {
    return yooadmin_studio_hub_theme_dir() . '/assets/' . ltrim(str_replace('\\', '/', $relative), '/');
}

/**
 * Public URL for an asset under assets/.
 */
function yooadmin_studio_hub_asset_url(string $relative): string {
    return plugins_url(
        'assets/' . ltrim(str_replace('\\', '/', $relative), '/'),
        yooadmin_studio_hub_theme_dir() . '/theme.php'
    );
}

/**
 * @return bool
 */
function yooadmin_studio_hub_is_active(): bool {
    return get_option('yooadmin_active_admin_theme', '') === 'yooadmin-studio-hub';
}

/**
 * @return string light|dark|auto
 */
function yooadmin_studio_hub_get_color_mode(int $user_id = 0): string {
    if ($user_id <= 0) {
        $user_id = (int) get_current_user_id();
    }

    if ($user_id > 0) {
        $user_mode = sanitize_key((string) get_user_meta($user_id, 'yooadmin_studio_hub_color_mode', true));
        if (in_array($user_mode, ['light', 'dark', 'auto'], true)) {
            return $user_mode;
        }
    }

    $opt = get_option('yooadmin_admin_theme_settings_yooadmin-studio-hub', []);
    if (!is_array($opt)) {
        return 'auto';
    }
    $mode = isset($opt['color_mode']) ? sanitize_key((string) $opt['color_mode']) : 'auto';
    if (!in_array($mode, ['light', 'dark', 'auto'], true)) {
        return 'auto';
    }

    return $mode;
}

/**
 * Studio Hub chrome applies only when YOOAdmin Focus Mode is on (body.yoo-focus).
 *
 * @return bool
 */
function yooadmin_studio_hub_is_focus_enabled(): bool {
    return function_exists('yooadmin_is_focus_enabled') && yooadmin_is_focus_enabled();
}

/**
 * @return bool
 */
function yooadmin_studio_hub_is_effective_dark_mode(): bool {
    $mode = yooadmin_studio_hub_get_color_mode();

    return 'dark' === $mode;
}

/**
 * @return bool
 */
function yooadmin_studio_hub_is_wc_settings_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active()) {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (!isset($_GET['page']) || 'wc-settings' !== sanitize_key(wp_unslash($_GET['page']))) {
        return false;
    }

    return true;
}

/**
 * WooCommerce Settings Studio overrides (CSS/JS layout) — Focus Mode only.
 *
 * @return bool
 */
function yooadmin_studio_hub_wc_settings_studio_active(): bool {
    return yooadmin_studio_hub_is_wc_settings_screen() && yooadmin_studio_hub_is_focus_enabled();
}

/**
 * WooCommerce legacy Reports — Studio chrome (Focus Mode only).
 *
 * @return bool
 */
function yooadmin_studio_hub_wc_reports_studio_active(): bool {
    return yooadmin_studio_hub_is_wc_reports_screen() && yooadmin_studio_hub_is_focus_enabled();
}

/**
 * Coupons list — Studio chrome (Focus Mode only).
 *
 * @return bool
 */
function yooadmin_studio_hub_shop_coupon_list_studio_active(): bool {
    return yooadmin_studio_hub_is_shop_coupon_list_screen() && yooadmin_studio_hub_is_focus_enabled();
}

/**
 * Product catalog screens (list, taxonomies, attributes, reviews) — Studio chrome.
 *
 * @return bool
 */
function yooadmin_studio_hub_product_catalog_studio_active(): bool {
    return yooadmin_studio_hub_is_product_catalog_screen() && yooadmin_studio_hub_is_focus_enabled();
}

/**
 * WooCommerce product list / taxonomies / attributes / reviews (classic WP screens).
 *
 * @return bool
 */
function yooadmin_studio_hub_is_product_catalog_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active()) {
        return false;
    }

    $catalog_taxonomies = ['product_cat', 'product_tag', 'product_brand'];
    $catalog_subpages   = ['product_attributes', 'product-reviews', 'product_reviews'];

    if (function_exists('get_current_screen')) {
        $screen = get_current_screen();
        if ($screen) {
            if ('edit-product' === $screen->id) {
                return true;
            }
            if ('edit-tags' === $screen->base && in_array($screen->taxonomy, $catalog_taxonomies, true)) {
                return true;
            }
            if (in_array($screen->id, ['product_page_product_attributes', 'product_page_product-reviews', 'product_page_product_reviews'], true)) {
                return true;
            }
            if (str_contains((string) $screen->id, 'product_attributes') || str_contains((string) $screen->id, 'product-reviews') || str_contains((string) $screen->id, 'product_reviews')) {
                return true;
            }
        }
    }

    global $pagenow;

    if ('edit-tags.php' === $pagenow) {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $taxonomy  = isset($_GET['taxonomy']) ? sanitize_key(wp_unslash($_GET['taxonomy'])) : '';
        $post_type = isset($_GET['post_type']) ? sanitize_key(wp_unslash($_GET['post_type'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return 'product' === $post_type && in_array($taxonomy, $catalog_taxonomies, true);
    }

    if ('edit.php' !== $pagenow) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (!isset($_GET['post_type']) || 'product' !== sanitize_key(wp_unslash($_GET['post_type']))) {
        return false;
    }

    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

    if ('' === $page) {
        return true;
    }

    return in_array($page, $catalog_subpages, true);
    // phpcs:enable WordPress.Security.NonceVerification.Recommended
}

/**
 * Orders list (HPOS) — Studio chrome (Focus Mode only).
 *
 * @return bool
 */
function yooadmin_studio_hub_wc_orders_studio_active(): bool {
    return yooadmin_studio_hub_is_wc_orders_screen() && yooadmin_studio_hub_is_focus_enabled();
}

/**
 * Tabs that use React / special chrome — skip classic layout pending state.
 *
 * @return bool
 */
function yooadmin_studio_hub_wc_settings_uses_classic_pending(): bool {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'general';

    return !in_array($tab, ['shipping', 'checkout', 'email', 'site-visibility', 'point-of-sale'], true);
}

/**
 * @return bool
 */
function yooadmin_studio_hub_is_wc_admin_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active()) {
        return false;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    return isset($_GET['page']) && 'wc-admin' === sanitize_key(wp_unslash($_GET['page']));
}

/**
 * @return bool
 */
function yooadmin_studio_hub_is_wc_orders_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active()) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (!isset($_GET['page'])) {
        return false;
    }

    $page = sanitize_key(wp_unslash($_GET['page']));
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    return 'wc-orders' === $page || 0 === strpos($page, 'wc-orders--');
}

/**
 * @return bool
 */
function yooadmin_studio_hub_is_wc_reports_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active()) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (!isset($_GET['page'])) {
        return false;
    }

    return 'wc-reports' === sanitize_key(wp_unslash($_GET['page']));
    // phpcs:enable WordPress.Security.NonceVerification.Recommended
}

/**
 * @return bool
 */
function yooadmin_studio_hub_is_shop_coupon_list_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active()) {
        return false;
    }

    if (function_exists('get_current_screen')) {
        $screen = get_current_screen();
        if ($screen && 'edit-shop_coupon' === $screen->id) {
            return true;
        }
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (!isset($_GET['post_type'])) {
        return false;
    }

    return 'shop_coupon' === sanitize_key(wp_unslash($_GET['post_type']));
    // phpcs:enable WordPress.Security.NonceVerification.Recommended
}

/**
 * @return bool
 */
function yooadmin_studio_hub_is_product_editor_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active()) {
        return false;
    }

    global $pagenow, $typenow;

    if (function_exists('get_current_screen')) {
        $screen = get_current_screen();
        // Single product add/edit only — not list, taxonomy, or attribute screens.
        if ($screen && 'product' === $screen->post_type && in_array($screen->base, ['post', 'add'], true)) {
            return true;
        }
    }

    if ('post-new.php' === $pagenow) {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $post_type = isset($_GET['post_type']) ? sanitize_key(wp_unslash($_GET['post_type'])) : (string) $typenow;
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return 'product' === $post_type;
    }

    if ('post.php' === $pagenow && 'product' === $typenow) {
        return true;
    }

    if ('post.php' !== $pagenow) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (isset($_GET['post'])) {
        $post = get_post(absint(wp_unslash($_GET['post'])));
        if ($post instanceof WP_Post && 'product' === $post->post_type) {
            return true;
        }
    }
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    if (isset($GLOBALS['post']) && $GLOBALS['post'] instanceof WP_Post && 'product' === $GLOBALS['post']->post_type) {
        return true;
    }

    return false;
}

/**
 * Plugins Manager or Extensions Store admin screen.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_plugins_extensions_page(): bool {
    if (!is_admin()) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only page routing.
    if (!isset($_GET['page'])) {
        return false;
    }

    $page = sanitize_key(wp_unslash($_GET['page']));
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    return in_array($page, ['yooadmin-plugins', 'yooadmin-extensions'], true);
}

/**
 * Drop style handles that are not registered (e.g. late tail deregistered when Focus is off).
 *
 * @param string[] $deps
 * @return string[]
 */
function yooadmin_studio_hub_prune_unregistered_style_deps(array $deps): array {
    $pruned = [];

    foreach ($deps as $handle) {
        if (!is_string($handle) || '' === $handle) {
            continue;
        }
        if (wp_style_is($handle, 'registered')) {
            $pruned[] = $handle;
        }
    }

    return array_values(array_unique($pruned));
}

/**
 * Core admin styles when studio-hub-late is unavailable.
 *
 * @return string[]
 */
function yooadmin_studio_hub_fallback_admin_style_deps(): array {
    $fallback = [];

    foreach (['wp-admin', 'common', 'dashicons', 'forms', 'list-tables'] as $handle) {
        if (wp_style_is($handle, 'registered')) {
            $fallback[] = $handle;
        }
    }

    return $fallback;
}

/**
 * Resolve enqueue dependencies: registered handles only, with WP admin fallbacks.
 *
 * @param string[] $preferred
 * @return string[]
 */
function yooadmin_studio_hub_resolve_style_deps(array $preferred): array {
    $deps = yooadmin_studio_hub_prune_unregistered_style_deps($preferred);

    if ([] !== $deps) {
        return $deps;
    }

    return yooadmin_studio_hub_fallback_admin_style_deps();
}
