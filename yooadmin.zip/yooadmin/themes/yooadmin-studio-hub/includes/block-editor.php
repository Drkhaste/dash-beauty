<?php
/**
 * Studio Hub — native block editor (Gutenberg) dark mode + layout.
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Post / CPT block editor screens (not Site Editor).
 *
 * @return bool
 */
function yooadmin_studio_hub_is_block_editor_page(): bool {
    if (!is_admin() || !function_exists('get_current_screen')) {
        return false;
    }

    $screen = get_current_screen();
    if (!$screen || !$screen->is_block_editor()) {
        return false;
    }

    // Extended integrated composer ships its own editor chrome.
    if (function_exists('yooadmin_post_editor_is_composer_page') && yooadmin_post_editor_is_composer_page()) {
        return false;
    }

    return true;
}

/**
 * Post type for post.php / post-new.php (empty when not applicable).
 *
 * @return string
 */
function yooadmin_studio_hub_resolve_editor_post_type(): string {
    global $pagenow;

    if (!isset($pagenow)) {
        return '';
    }

    if ('post-new.php' === $pagenow) {
        if (isset($_GET['post_type'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            return sanitize_key(wp_unslash($_GET['post_type'])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        }

        return 'post';
    }

    if ('post.php' === $pagenow && isset($_GET['post'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $post_id = absint(wp_unslash($_GET['post'])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ($post_id > 0) {
            $post_type = get_post_type($post_id);
            return is_string($post_type) ? $post_type : '';
        }
    }

    return '';
}

/**
 * Block editor for post.php / post-new.php when the screen object is not ready yet.
 *
 * @return bool
 */
function yooadmin_studio_hub_post_screen_uses_block_editor(): bool {
    $post_type = yooadmin_studio_hub_resolve_editor_post_type();
    if ('' === $post_type || !function_exists('use_block_editor_for_post_type')) {
        return false;
    }

    return (bool) use_block_editor_for_post_type($post_type);
}

/**
 * Gutenberg admin routes — block editor screen check; site-editor.php always true.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_gutenberg_admin_request(): bool {
    if (!is_admin()) {
        return false;
    }

    if (function_exists('yooadmin_post_editor_is_composer_page') && yooadmin_post_editor_is_composer_page()) {
        return false;
    }

    global $pagenow;
    if (!isset($pagenow)) {
        return yooadmin_studio_hub_is_block_editor_page();
    }

    if ('site-editor.php' === $pagenow) {
        return true;
    }

    if (in_array($pagenow, ['post.php', 'post-new.php'], true)) {
        if (function_exists('get_current_screen')) {
            $screen = get_current_screen();
            if ($screen) {
                return $screen->is_block_editor();
            }
        }

        return yooadmin_studio_hub_post_screen_uses_block_editor();
    }

    return yooadmin_studio_hub_is_block_editor_page();
}

/**
 * Block editor layout — body selectors (theme class may be absent on network admin).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_layout_body_selector(): string {
    return 'body.block-editor-page,'
        . 'body.site-editor-php,'
        . 'body.yooadmin-theme-yooadmin-studio-hub.block-editor-page,'
        . 'body.yoo-focus.block-editor-page,'
        . 'body.yooadmin-network-admin-shell.block-editor-page,'
        . 'body.yooadmin-theme-yooadmin-studio-hub.site-editor-php,'
        . 'body.yoo-focus.site-editor-php,'
        . 'body.yooadmin-network-admin-shell.site-editor-php';
}

/**
 * Studio Hub block editor assets (Focus Mode + active theme + Gutenberg screen).
 *
 * @return bool
 */
function yooadmin_studio_hub_block_editor_assets_applies(): bool {
    return yooadmin_studio_hub_is_active()
        && yooadmin_studio_hub_is_focus_enabled()
        && yooadmin_studio_hub_is_gutenberg_admin_request();
}

/**
 * Ensure Studio Hub body classes on Gutenberg (appearance toggle CSS + JS guard).
 *
 * @param string $classes Space-separated admin body classes.
 * @return string
 */
function yooadmin_studio_hub_filter_block_editor_body_class(string $classes): string {
    if (!yooadmin_studio_hub_block_editor_assets_applies()) {
        return $classes;
    }

    if (strpos($classes, 'yooadmin-theme-yooadmin-studio-hub') === false) {
        $classes .= ' yooadmin-theme-yooadmin-studio-hub';
    }
    if (strpos($classes, 'yooadmin-theme-studio-hub') === false) {
        $classes .= ' yooadmin-theme-studio-hub';
    }

    return $classes;
}

/**
 * Antiflash scope — block editor body classes only (never bare html/body).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_antiflash_body_selector(): string {
    return 'body.block-editor-page,body.site-editor-php';
}

/**
 * Prefix comma-separated selectors with another comma-separated prefix list.
 *
 * @param string $prefix    CSS selector list used as parent scope.
 * @param string $selectors CSS selector list to nest under each prefix.
 * @return string
 */
function yooadmin_studio_hub_block_editor_prefix_selectors(string $prefix, string $selectors): string {
    $prefixed = [];

    foreach (array_filter(array_map('trim', explode(',', $prefix))) as $scope) {
        foreach (array_filter(array_map('trim', explode(',', $selectors))) as $selector) {
            $prefixed[] = $scope . ' ' . $selector;
        }
    }

    return implode(',', $prefixed);
}

/**
 * Full-bleed shell reset + hide native admin menu chrome on block editor.
 *
 * @return string
 */
/**
 * First-paint loading shell — one canvas color; hide skeleton sidebar column (WP gray/white split).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_loading_shell_css(): string {
    $body = yooadmin_studio_hub_block_editor_layout_body_selector();

    $parts = '.interface-interface-skeleton,'
        . '.interface-interface-skeleton__header,'
        . '.interface-interface-skeleton__body,'
        . '.interface-interface-skeleton__content,'
        . '.interface-interface-skeleton__editor,'
        . '.interface-interface-skeleton__sidebar,'
        . '.interface-interface-skeleton__secondary-sidebar,'
        . '.interface-interface-skeleton__footer,'
        . '.interface-interface-skeleton__actions';

    $scoped_parts = yooadmin_studio_hub_block_editor_prefix_selectors($body, $parts);
    // Collapse empty document settings column only — block inserter uses secondary-sidebar.
    $scoped_sidebar_empty = yooadmin_studio_hub_block_editor_prefix_selectors(
        $body,
        '.interface-interface-skeleton__sidebar:empty'
    );

    $mode   = yooadmin_studio_hub_get_color_mode();
    $dark_h = 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)';
    $light_rules =
        $body . ' #wpbody-content{background:#fff!important;}'
        . $scoped_parts . '{background:#fff!important;background-color:#fff!important;}'
        . $scoped_sidebar_empty . '{width:0!important;min-width:0!important;max-width:0!important;'
        . 'flex:0 0 0!important;overflow:hidden!important;padding:0!important;border:0!important;}';
    $dark_rules  = '';
    $dark_scoped = [];

    foreach (array_filter(array_map('trim', explode(',', $body))) as $body_sel) {
        $dark_scoped[] = $dark_h . ' ' . $body_sel . ' #wpbody-content';
        foreach (array_filter(array_map('trim', explode(',', $parts))) as $part_sel) {
            $dark_scoped[] = $dark_h . ' ' . $body_sel . ' ' . $part_sel;
        }
    }

    $dark_rules = implode(',', $dark_scoped)
        . '{background:#1a1d23!important;background-color:#1a1d23!important;}'
        . $dark_h . ' ' . $body . ' #wpbody-content{background:#121418!important;}';

    if ('light' === $mode) {
        return $light_rules;
    }
    if ('dark' === $mode) {
        return $dark_rules . $scoped_sidebar_empty . '{width:0!important;min-width:0!important;max-width:0!important;'
            . 'flex:0 0 0!important;overflow:hidden!important;padding:0!important;border:0!important;}';
    }

    return $light_rules . '@media (prefers-color-scheme:dark){' . $dark_rules . '}' . $scoped_sidebar_empty
        . '{width:0!important;min-width:0!important;max-width:0!important;'
        . 'flex:0 0 0!important;overflow:hidden!important;padding:0!important;border:0!important;}';
}

function yooadmin_studio_hub_block_editor_layout_shell_css(): string {
    $body = yooadmin_studio_hub_block_editor_layout_body_selector();

    $css = yooadmin_studio_hub_block_editor_loading_shell_css();

    $css .= $body . ' #wpwrap,'
        . $body . ' #wpcontent,'
        . $body . ' #wpbody,'
        . $body . ' #wpbody-content{'
        . 'padding:0!important;margin:0!important;margin-left:0!important;margin-top:0!important;'
        . 'padding-left:0!important;padding-top:0!important;max-width:none!important;width:100%!important;'
        . 'box-sizing:border-box!important;}'
        . $body . ' #wpbody-content>#editor,'
        . $body . ' #wpbody-content>.block-editor,'
        . $body . ' #wpbody-content>.edit-post-layout{'
        . 'margin:0!important;max-width:none!important;width:100%!important;min-height:100vh!important;}'
        . $body . ' .interface-interface-skeleton,'
        . $body . ' #editor .interface-interface-skeleton{'
        . 'top:0!important;left:0!important;right:0!important;min-height:100vh!important;'
        . 'visibility:visible!important;opacity:1!important;}'
        . $body . ' #adminmenuback,'
        . $body . ' #adminmenumain,'
        . $body . ' #adminmenuwrap{display:none!important;width:0!important;}'
        . 'html.wp-toolbar:has(body.yoo-focus.block-editor-page),'
        . 'html.wp-toolbar:has(body.yoo-focus.site-editor-php),'
        . 'html.wp-toolbar:has(body.yooadmin-network-admin-shell.block-editor-page),'
        . 'html.wp-toolbar:has(body.yooadmin-network-admin-shell.site-editor-php){padding-top:0!important;}'
        . 'body.yoo-focus.block-editor-page.admin-bar,'
        . 'body.yoo-focus.site-editor-php.admin-bar,'
        . 'body.yooadmin-network-admin-shell.block-editor-page.admin-bar,'
        . 'body.yooadmin-network-admin-shell.site-editor-php.admin-bar{margin-top:0!important;}'
        . 'body.yoo-focus.block-editor-page.auto-fold .interface-interface-skeleton,'
        . 'body.yoo-focus.block-editor-page.folded .interface-interface-skeleton,'
        . 'body.yoo-focus.site-editor-php.auto-fold .interface-interface-skeleton,'
        . 'body.yoo-focus.site-editor-php.folded .interface-interface-skeleton,'
        . 'body.yooadmin-network-admin-shell.block-editor-page.auto-fold .interface-interface-skeleton,'
        . 'body.yooadmin-network-admin-shell.block-editor-page.folded .interface-interface-skeleton,'
        . 'body.yooadmin-network-admin-shell.site-editor-php.auto-fold .interface-interface-skeleton,'
        . 'body.yooadmin-network-admin-shell.site-editor-php.folded .interface-interface-skeleton{left:0!important;}'
        . $body . ' .editor-header__back-button,'
        . $body . ' .edit-post-fullscreen-mode-close{display:flex!important;visibility:visible!important;}'
        . $body . ' .editor-header__back-button[hidden],'
        . $body . ' .edit-post-fullscreen-mode-close[hidden]{display:flex!important;}'
        . $body . ' .edit-post-fullscreen-mode-close-site-icon{'
        . 'width:56px!important;height:56px!important;max-width:56px!important;'
        . 'max-height:56px!important;flex-shrink:0!important;overflow:hidden!important;}'
        . $body . ' img.edit-post-fullscreen-mode-close-site-icon__image{'
        . 'display:block!important;opacity:1!important;visibility:visible!important;'
        . 'width:100%!important;height:100%!important;max-width:56px!important;'
        . 'max-height:56px!important;object-fit:contain!important;'
        . 'background:transparent!important;box-shadow:none!important;}';

    return $css;
}

/**
 * Real site_icon attachment ID from the database (bypasses pre_option filters).
 *
 * YOOAdmin may mask get_option( 'site_icon' ) with __yooadmin_virtual_site_icon__
 * when no native icon exists; Gutenberg must read the stored attachment ID only.
 *
 * @param int $blog_id Blog ID.
 * @return int Attachment ID, or 0 when unset / invalid.
 */
function yooadmin_studio_hub_get_db_site_icon_attachment_id(int $blog_id = 0): int {
    global $wpdb;

    $switched = false;
    if ($blog_id > 0 && is_multisite() && get_current_blog_id() !== $blog_id) {
        switch_to_blog($blog_id);
        $switched = true;
    }

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Must bypass pre_option_site_icon.
    $raw = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1",
            'site_icon'
        )
    );

    if ($switched) {
        restore_current_blog();
    }

    if (!is_numeric($raw)) {
        return 0;
    }

    $id = (int) $raw;
    return $id > 0 ? $id : 0;
}

/**
 * Block editor routes where Gutenberg header must use native Site Icon only.
 *
 * Includes admin screens and REST requests issued from the block editor (referer).
 *
 * @return bool
 */
function yooadmin_studio_hub_is_block_editor_site_icon_context(): bool {
    if (yooadmin_studio_hub_is_gutenberg_admin_request()) {
        return true;
    }

    if (!defined('REST_REQUEST') || ! REST_REQUEST) {
        return false;
    }

    $referer = wp_get_referer();
    if (is_string($referer) && '' !== $referer) {
        $path = wp_parse_url($referer, PHP_URL_PATH);
        if (is_string($path) && '' !== $path
            && preg_match('#/(wp-admin/)?(post\.php|post-new\.php|site-editor\.php)([?]|$)#', $path)) {
            return true;
        }
    }

    return yooadmin_studio_hub_is_block_editor_site_icon_rest_request();
}

/**
 * REST requests that load Gutenberg site metadata (site_icon_url), including preload.
 *
 * Referer is often omitted on same-origin fetches; match the root index fields Gutenberg uses.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_block_editor_site_icon_rest_request(): bool {
    if (!defined('REST_REQUEST') || ! REST_REQUEST || !is_user_logged_in()) {
        return false;
    }

    if (!current_user_can('edit_posts')) {
        return false;
    }

    $route = '';
    if (isset($GLOBALS['wp']) && isset($GLOBALS['wp']->query_vars['rest_route'])) {
        $route = (string) $GLOBALS['wp']->query_vars['rest_route'];
    }

    if ('' !== $route && '/' !== $route) {
        return false;
    }

    return yooadmin_studio_hub_rest_request_includes_site_icon_fields();
}

/**
 * Whether a REST request loads Gutenberg __unstableBase (site_icon_url) fields.
 *
 * @param WP_REST_Request|null $request Optional request (preferred over $_GET).
 * @return bool
 */
function yooadmin_studio_hub_rest_request_includes_site_icon_fields(?WP_REST_Request $request = null): bool {
    $fields = '';
    if ($request instanceof WP_REST_Request) {
        $fields = (string) $request->get_param('_fields');
    } elseif (isset($_GET['_fields'])) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- REST field list probe.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only REST field list probe.
        $fields = sanitize_text_field((string) wp_unslash($_GET['_fields']));
    }

    return '' !== $fields && false !== strpos($fields, 'site_icon');
}

/**
 * Native WordPress Site Icon URL without re-entering get_site_icon_url filters.
 *
 * Reads the site_icon attachment directly so Gutenberg never triggers
 * yooadmin_collect_admin_favicons() → has_site_icon() recursion.
 *
 * @param int $size    Requested size.
 * @param int $blog_id Blog ID.
 * @return string
 */
function yooadmin_studio_hub_resolve_native_site_icon_url(int $size = 512, int $blog_id = 0): string {
    if ($size < 1) {
        $size = 512;
    }

    $site_icon_id = yooadmin_studio_hub_get_db_site_icon_attachment_id($blog_id);
    if ($site_icon_id <= 0) {
        return '';
    }

    $switched = false;
    if ($blog_id > 0 && is_multisite() && get_current_blog_id() !== $blog_id) {
        switch_to_blog($blog_id);
        $switched = true;
    }

    if ($size >= 512) {
        $size_data = 'full';
    } else {
        $size_data = [$size, $size];
    }

    $url = wp_get_attachment_image_url($site_icon_id, $size_data);
    if (!is_string($url) || '' === $url) {
        $url = wp_get_attachment_image_url($site_icon_id, 'full');
    }

    if ($switched) {
        restore_current_blog();
    }

    return is_string($url) ? $url : '';
}

/**
 * Gutenberg header icon — same favicon as YOOAdmin admin (not logo.png).
 *
 * @param int $size Requested size in pixels.
 * @return string
 */
function yooadmin_studio_hub_block_editor_gutenberg_site_icon_url(int $size = 512): string {
    $favicon = yooadmin_studio_hub_get_admin_favicon_fallback_url();
    if ('' !== $favicon) {
        return yooadmin_studio_hub_block_editor_asset_url($favicon);
    }

    return yooadmin_studio_hub_block_editor_asset_url(
        yooadmin_studio_hub_resolve_native_site_icon_url($size, 0)
    );
}

/**
 * Gutenberg Site Icon slot — YOOAdmin favicon first, then native WP Site Icon.
 *
 * @param string $url     Site icon URL.
 * @param int    $size    Requested size.
 * @param int    $blog_id Blog ID.
 * @return string
 */
function yooadmin_studio_hub_filter_block_editor_site_icon_url($url, $size, $blog_id): string {
    $url = is_string($url) ? $url : '';

    if (!yooadmin_studio_hub_is_block_editor_site_icon_context()) {
        return $url;
    }

    $resolved = yooadmin_studio_hub_block_editor_gutenberg_site_icon_url((int) $size);
    if ('' !== $resolved) {
        return $resolved;
    }

    return '' !== $url ? yooadmin_studio_hub_block_editor_asset_url($url) : $url;
}

/**
 * @param int $size Requested size in pixels.
 * @return string
 */
function yooadmin_studio_hub_block_editor_site_logo_url(int $size = 512): string {
    return yooadmin_studio_hub_block_editor_gutenberg_site_icon_url($size);
}

/**
 * Match site/home URL scheme so Gutenberg does not block mixed-content images.
 *
 * @param string $url Asset URL.
 * @return string
 */
function yooadmin_studio_hub_block_editor_asset_url(string $url): string {
    if ('' === $url) {
        return '';
    }

    $scheme = wp_parse_url(home_url(), PHP_URL_SCHEME);
    if (!is_string($scheme) || '' === $scheme) {
        $scheme = is_ssl() ? 'https' : 'http';
    }

    return set_url_scheme($url, $scheme);
}

/**
 * Ensure preloaded REST index includes a Site Icon URL for the block editor header.
 *
 * @param WP_REST_Response $response REST index response.
 * @param WP_REST_Request  $request  REST request.
 * @return WP_REST_Response
 */
function yooadmin_studio_hub_filter_rest_index_site_icon_url($response, $request) {
    if (!($response instanceof WP_REST_Response) || !is_array($response->data)) {
        return $response;
    }

    if (!$request instanceof WP_REST_Request) {
        return $response;
    }

    if (!yooadmin_studio_hub_rest_request_includes_site_icon_fields($request)) {
        return $response;
    }

    if (!is_user_logged_in() || !current_user_can('edit_posts')) {
        return $response;
    }

    $resolved = yooadmin_studio_hub_block_editor_gutenberg_site_icon_url(512);
    if ('' !== $resolved) {
        $response->data['site_icon_url'] = $resolved;
    }

    return $response;
}

/**
 * YOOAdmin admin favicon URL used as Gutenberg site-icon fallback (option → bundled asset).
 */
function yooadmin_studio_hub_get_admin_favicon_fallback_url(): string {
    $opts = (array) get_option('yooadmin_options', []);
    $opt  = isset($opts['admin_favicon_url']) ? (string) $opts['admin_favicon_url'] : '';
    if ('' !== $opt) {
        return yooadmin_studio_hub_block_editor_asset_url(esc_url_raw($opt));
    }

    $base = defined('YOOADMIN_PLUGIN_FILE') ? YOOADMIN_PLUGIN_FILE : '';
    if ('' === $base) {
        return '';
    }

    $dir = plugin_dir_path($base);
    $url = plugin_dir_url($base);

    foreach (['assets/images/favicon.svg', 'assets/images/favicon.ico'] as $rel) {
        $abs = $dir . $rel;
        if (file_exists($abs)) {
            $ver  = @filemtime($abs);
            $href = $url . $rel;
            $href = $ver ? $href . '?ver=' . $ver : $href;
            return yooadmin_studio_hub_block_editor_asset_url($href);
        }
    }

    return '';
}

/**
 * Ensure Studio tokens (--yp-header-bg, etc.) load on the block editor.
 *
 * Dark editor CSS depends on yooadmin-studio-hub-late; the manifest chains it to dashboard.css.
 * On post.php that chain is sometimes registered but not enqueued, so dark rules never apply.
 */
function yooadmin_studio_hub_enqueue_block_editor_theme_tokens(): void {
    if (!yooadmin_studio_hub_block_editor_assets_applies()) {
        return;
    }

    if (wp_style_is('yooadmin-studio-hub-dashboard', 'registered') && !wp_style_is('yooadmin-studio-hub-dashboard', 'enqueued')) {
        wp_enqueue_style('yooadmin-studio-hub-dashboard');
    }

    if (wp_style_is('yooadmin-studio-hub-late', 'registered') && !wp_style_is('yooadmin-studio-hub-late', 'enqueued')) {
        wp_enqueue_style('yooadmin-studio-hub-late');
        return;
    }

    if (wp_style_is('yooadmin-studio-hub-late', 'enqueued')) {
        return;
    }

    $tokens = yooadmin_studio_hub_asset_path('css/core/tokens.css');
    if (!is_readable($tokens)) {
        return;
    }

    if (!wp_style_is('yooadmin-studio-hub-tokens', 'registered')) {
        wp_register_style(
            'yooadmin-studio-hub-tokens',
            yooadmin_studio_hub_asset_url('css/core/tokens.css'),
            ['yooadmin-shell'],
            (string) filemtime($tokens)
        );
    }

    wp_enqueue_style('yooadmin-studio-hub-tokens');
}

/**
 * Appearance toggle in Gutenberg header needs studio-hub.js + AJAX config (not loaded with shell on block editor).
 */
function yooadmin_studio_hub_enqueue_block_editor_appearance_script(): void {
    if (!yooadmin_studio_hub_block_editor_assets_applies() || !yooadmin_studio_hub_can_show_appearance_control()) {
        return;
    }

    $handle = 'yooadmin-studio-hub-dashboard';
    $script = yooadmin_studio_hub_asset_path('js/core/studio-hub.js');
    if (!wp_script_is($handle, 'registered') && is_readable($script)) {
        wp_register_script(
            $handle,
            yooadmin_studio_hub_asset_url('js/core/studio-hub.js'),
            [],
            (string) filemtime($script),
            true
        );
    }
    if (!wp_script_is($handle, 'registered')) {
        return;
    }

    if (!wp_script_is($handle, 'enqueued')) {
        wp_enqueue_script($handle);
    }

    wp_localize_script(
        $handle,
        'yooadminStudioHubAppearance',
        [
            'ajaxUrl'   => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('yooadmin_studio_hub_color_mode'),
            'colorMode' => yooadmin_studio_hub_get_color_mode(),
            'widthMode' => function_exists('yooadmin_studio_hub_get_width_mode') ? yooadmin_studio_hub_get_width_mode() : 'normal',
            'i18n'      => function_exists('yooadmin_studio_hub_appearance_script_i18n') ? yooadmin_studio_hub_appearance_script_i18n() : [],
        ]
    );
}

/**
 * Reserved — header chrome is handled by core Gutenberg + studio-hub-block-editor-dark.css only.
 */
function yooadmin_studio_hub_print_block_editor_header_branding(): void {
    // Intentionally empty: inline header backgrounds broke the editor canvas layout.
}

/**
 * Early external layout stylesheet (before dark tail at priority 9999).
 */
function yooadmin_studio_hub_enqueue_block_editor_layout_early(): void {
    if (!yooadmin_studio_hub_block_editor_assets_applies()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-block-editor-layout.css');
    if (!is_readable($file)) {
        return;
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-block-editor-layout',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-block-editor-layout.css'),
        ['yooadmin-shell'],
        (string) filemtime($file)
    );
}

/**
 * Resolved logo URL for Gutenberg header (sidebar filter + bundled fallback).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_logo_url(): string {
    if (!yooadmin_studio_hub_is_active()) {
        return '';
    }

    $url = function_exists('yooadmin_logo_url') ? (string) yooadmin_logo_url() : '';
    $url = (string) apply_filters('yooadmin_admin_theme_sidebar_logo_url', $url, null);

    if ('' !== $url) {
        return yooadmin_studio_hub_block_editor_asset_url($url);
    }

    if (!defined('YOOADMIN_PLUGIN_FILE')) {
        return '';
    }

    $path = wp_normalize_path(plugin_dir_path(YOOADMIN_PLUGIN_FILE) . 'assets/images/logo.png');
    if (!is_readable($path)) {
        return '';
    }

    return yooadmin_studio_hub_block_editor_asset_url(
        esc_url(plugins_url('assets/images/logo.png', YOOADMIN_PLUGIN_FILE))
    );
}

/**
 * @return string
 */
function yooadmin_studio_hub_block_editor_dark_selector(): string {
    $html_modes = [
        'html[data-yooadmin-studio-color-mode-effective="dark"]',
        'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]',
    ];
    $bodies = [
        'body.yooadmin-theme-yooadmin-studio-hub.block-editor-page',
        'body.yoo-focus.block-editor-page',
        'body.yooadmin-network-admin-shell.block-editor-page',
        'body.yooadmin-theme-yooadmin-studio-hub.site-editor-php',
        'body.yoo-focus.site-editor-php',
        'body.yooadmin-network-admin-shell.site-editor-php',
    ];
    $selectors = [];

    foreach ($html_modes as $html) {
        foreach ($bodies as $body) {
            $selectors[] = $html . ' ' . $body;
        }
    }

    return implode(',', $selectors);
}

/**
 * Critical rules — first paint (avoid dark wpbody + white editor flash/gaps).
 */
function yooadmin_studio_hub_print_block_editor_critical(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_gutenberg_admin_request()) {
        return;
    }

    $dark = yooadmin_studio_hub_block_editor_dark_selector();

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Critical inline CSS; selector fragments are static.
    // Layout is in print_block_editor_layout_critical() — dark-only here (never enable with layout; breaks WP 6.7+ iframe).
    echo '<style id="yooadmin-studio-hub-block-editor-critical">'
        . $dark . ' #wpbody-content{background:var(--ysh-surface,#121418)!important;}'
        . $dark . ' .interface-interface-skeleton,'
        . $dark . ' .interface-interface-skeleton__header,'
        . $dark . ' .interface-interface-skeleton__body,'
        . $dark . ' .interface-interface-skeleton__content,'
        . $dark . ' .interface-interface-skeleton__editor,'
        . $dark . ' .interface-interface-skeleton__footer,'
        . $dark . ' .interface-complementary-area,'
        . $dark . ' .editor-visual-editor,'
        . $dark . ' .edit-post-header,'
        . $dark . ' .editor-header,'
        . $dark . ' .interface-interface-skeleton__header{background:var(--yp-header-bg,color-mix(in srgb,#4b4b4b 22%,#0c0e12 78%))!important;color:var(--ysh-heading,#d8d3ce)!important;box-shadow:0 12px 40px rgba(0,0,0,.45);border-bottom:1px solid rgba(255,255,255,.1)!important;}'
        . $dark . ' .editor-header__toolbar,'
        . $dark . ' .editor-header__settings,'
        . $dark . ' .components-button,'
        . $dark . ' .components-button.has-icon{color:var(--ysh-text,#cfd6e0)!important;}'
        . $dark . ' .block-editor-iframe__container,'
        . $dark . ' .block-editor-iframe__scale-container,'
        . $dark . ' .block-editor-iframe__html,'
        . $dark . ' iframe[name="editor-canvas"]{background:var(--ysh-card,#1a1d23)!important;background-color:var(--ysh-card,#1a1d23)!important;}'
        . $dark . ' .editor-document-bar{background:#22262e!important;color:var(--ysh-text,#cfd6e0)!important;}'
        . $dark . ' .components-panel__header.editor-sidebar__panel-tabs [role="tab"],'
        . $dark . ' .interface-complementary-area [role="tablist"] [role="tab"]{color:var(--ysh-muted,#b4bdc9)!important;}'
        . $dark . ' .components-panel__header.editor-sidebar__panel-tabs [role="tab"][aria-selected="true"]{color:var(--ysh-heading,#e8ecf1)!important;}'
        . $dark . ' .interface-complementary-area .components-panel__body>.components-panel__body-title,'
        . $dark . ' .interface-complementary-area .components-panel__body.is-opened>.components-panel__body-title{background:var(--ysh-card,#1a1d23)!important;}'
        . $dark . ' .interface-complementary-area .components-panel__body-toggle.components-button,'
        . $dark . ' .interface-complementary-area .components-panel__body-toggle.components-button:hover{color:var(--ysh-heading,#e8ecf1)!important;background:transparent!important;}'
        . $dark . ' .block-editor-tabbed-sidebar,'
        . $dark . ' .block-editor-tabbed-sidebar__tablist-and-close-button,'
        . $dark . ' .block-editor-inserter__panel-header{background:var(--ysh-card,#1a1d23)!important;color:var(--ysh-text,#cfd6e0)!important;}'
        . $dark . ' .block-editor-inserter__panel-title{color:var(--ysh-muted,#b4bdc9)!important;}'
        . $dark . ' .block-editor-tabbed-sidebar .components-tab-panel__tabs-item{color:var(--ysh-muted,#b4bdc9)!important;}'
        . $dark . ' .interface-interface-skeleton__footer{background:var(--ysh-card,#1a1d23)!important;border-top-color:rgba(255,255,255,0.08)!important;}'
        . $dark . ' .edit-post-meta-boxes-main,'
        . $dark . ' .edit-post-meta-boxes-main__presenter,'
        . $dark . ' .edit-post-meta-boxes-main__liner{background:var(--ysh-card,#1a1d23)!important;color:var(--ysh-text,#cfd6e0)!important;}'
        . $dark . ' .edit-post-meta-boxes-main__presenter{box-shadow:inset 0 1px rgba(255,255,255,0.08)!important;}'
        . $dark . ' .edit-post-meta-boxes-main__presenter>button[aria-expanded]{color:var(--ysh-muted,#b4bdc9)!important;}'
        . $dark . ' .edit-post-meta-boxes-main__presenter>button[role=separator]::before{background-color:rgba(255,255,255,.28)!important;}'
        . $dark . ' .block-editor-block-breadcrumb__button,'
        . $dark . ' .block-editor-block-breadcrumb__current{color:var(--ysh-muted,#b4bdc9)!important;}'
        . $dark . ' .components-button.is-secondary,'
        . $dark . ' .editor-post-trash.components-button{background:#22262e!important;color:var(--ysh-text,#cfd6e0)!important;box-shadow:inset 0 0 0 1px rgba(255,255,255,0.1)!important;}'
        . $dark . ' .editor-post-trash.components-button{background:rgba(204,24,24,0.14)!important;color:#ff8a8a!important;}'
        . $dark . ' .components-notice.is-warning{background:rgba(240,184,73,0.12)!important;border-left-color:#f0b849!important;color:var(--ysh-text,#e8ecf1)!important;}'
        . $dark . ' .components-notice__content,'
        . $dark . ' .components-notice__dismiss{color:var(--ysh-text,#cfd6e0)!important;}'
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Layout-only first paint — fixes left/top gaps; safe to keep separate from dark critical.
 */
function yooadmin_studio_hub_print_block_editor_layout_critical(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_gutenberg_admin_request()) {
        return;
    }

    $layout = yooadmin_studio_hub_block_editor_layout_shell_css();

    $appearance = '';
    if (yooadmin_studio_hub_can_show_appearance_control()) {
        $appearance = 'body.block-editor-page .ysh-appearance,body.site-editor-php .ysh-appearance{'
            . 'position:relative;display:inline-flex!important;align-items:center;flex-shrink:0;visibility:visible!important;}'
            . 'body.block-editor-page .ysh-appearance__toggle,body.site-editor-php .ysh-appearance__toggle{'
            . 'display:inline-flex!important;align-items:center;justify-content:center;gap:2px;padding:5px 7px;'
            . 'border:none;border-radius:8px;background:transparent;cursor:pointer;'
            . 'color:var(--yooadmin-primary,var(--ysh-brand,#eda934));}'
            . 'body.block-editor-page .ysh-appearance__menu,body.site-editor-php .ysh-appearance__menu{'
            . 'position:absolute;inset-inline-end:0;top:calc(100% + 6px);z-index:100100;display:flex;gap:6px;'
            . 'padding:8px;border-radius:10px;border:1px solid rgba(255,255,255,.12);'
            . 'background:var(--ysh-card,#1a1d23);box-shadow:0 10px 28px rgba(0,0,0,.35);}'
            . 'body.block-editor-page .ysh-appearance__menu[hidden],body.site-editor-php .ysh-appearance__menu[hidden]{display:none!important;}';
    }

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Layout-only critical CSS; static selectors.
    echo '<style id="yooadmin-studio-hub-block-editor-layout">'
        . $layout
        . $appearance
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * First-paint anti-flash — dark shell before Gutenberg/React mount (Site Editor templates too).
 */
function yooadmin_studio_hub_print_block_editor_antiflash_critical(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_gutenberg_admin_request()) {
        return;
    }

    $mode = yooadmin_studio_hub_get_color_mode();
    if ('light' === $mode) {
        return;
    }

    $be_body      = yooadmin_studio_hub_block_editor_antiflash_body_selector();
    $shell        = '#editor,.edit-site,.interface-interface-skeleton,.interface-interface-skeleton__body,'
        . '.interface-interface-skeleton__content,.interface-interface-skeleton__editor,'
        . '.interface-interface-skeleton__header,.editor-header,'
        . '.editor-visual-editor,.block-editor-iframe__container,.block-editor-iframe__scale-container,'
        . 'iframe[name="editor-canvas"],iframe[name="style-book-canvas"]';
    $scoped_shell = yooadmin_studio_hub_block_editor_prefix_selectors($be_body, $shell);
    $dark         = yooadmin_studio_hub_block_editor_dark_selector();
    $dark_shell   = yooadmin_studio_hub_block_editor_prefix_selectors($dark, $shell);
    $auto_body    = yooadmin_studio_hub_block_editor_prefix_selectors(
        'html:not([data-yooadmin-studio-color-mode-effective="light"])',
        $be_body
    );
    $auto_shell   = yooadmin_studio_hub_block_editor_prefix_selectors(
        'html:not([data-yooadmin-studio-color-mode-effective="light"])',
        yooadmin_studio_hub_block_editor_prefix_selectors($be_body, $shell)
    );

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Critical inline CSS; selector fragments are static.
    echo '<style id="yooadmin-studio-hub-block-editor-antiflash">';

    if ('dark' === $mode) {
        echo $be_body . '{background:#121418!important;color:#cfd6e0!important;color-scheme:dark;}'
            . $scoped_shell . '{background:#1a1d23!important;background-color:#1a1d23!important;}';
    } else {
        echo '@media (prefers-color-scheme:dark){'
            . $be_body . '{background:#121418!important;color:#cfd6e0!important;color-scheme:dark;}'
            . $scoped_shell . '{background:#1a1d23!important;background-color:#1a1d23!important;}'
            . '}';
    }

    echo $dark . '{background:#121418!important;color:#cfd6e0!important;color-scheme:dark;}'
        . $dark_shell . '{background:#1a1d23!important;background-color:#1a1d23!important;}'
        . '@media (prefers-color-scheme:dark){'
        . $auto_body . '{background:#121418!important;color:#cfd6e0!important;color-scheme:dark;}'
        . $auto_shell . '{background:#1a1d23!important;background-color:#1a1d23!important;}'
        . '}'
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Block placeholder / variation picker / canvas links (iframe canvas only).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_block_ui_dark_css(): string {
    return '.components-placeholder,.components-placeholder.components-placeholder,.wp-block-placeholder{'
        . 'background-color:#22262e!important;color:#cfd6e0!important;'
        . 'box-shadow:inset 0 0 0 1px rgba(255,255,255,.14)!important;}'
        . '.components-placeholder__label,.components-placeholder__instructions,'
        . '.components-placeholder__fieldset,.components-placeholder__error{color:#cfd6e0!important;}'
        . '.components-placeholder__label .block-editor-block-icon,'
        . '.components-placeholder__label>svg,.components-placeholder__label .dashicon{'
        . 'color:#cfd6e0!important;fill:currentColor!important;}'
        . '.components-placeholder__input[type=url]{background:#1a1d23!important;color:#cfd6e0!important;'
        . 'border-color:rgba(255,255,255,.14)!important;}'
        . '.components-placeholder__input[type=url]::placeholder{color:#9aa5b1!important;}'
        . '.block-editor-block-variation-picker__variations,.block-editor-block-variation-picker__skip,'
        . '.wp-block-group-placeholder__variations{color:#b4bdc9!important;}'
        . '.block-editor-block-variation-picker__variations .components-button,'
        . '.block-editor-block-variation-picker__skip .components-button,'
        . '.wp-block-group-placeholder__variations .components-button{color:#b4bdc9!important;}'
        . '.block-editor-block-variation-picker__variations svg,'
        . '.block-editor-block-variation-picker__skip svg,'
        . '.wp-block-group-placeholder__variations svg{fill:#b4bdc9!important;}'
        . '.block-editor-block-variation-picker__variations .components-button:hover,'
        . '.block-editor-block-variation-picker__skip .components-button:hover,'
        . '.wp-block-group-placeholder__variations .components-button:hover{color:#eda934!important;}'
        . '.block-editor-block-variation-picker__variations .components-button:hover svg,'
        . '.block-editor-block-variation-picker__skip .components-button:hover svg,'
        . '.wp-block-group-placeholder__variations .components-button:hover svg{fill:#eda934!important;}'
        . '.components-button.is-link{color:#eda934!important;}'
        . '.components-button.is-link:hover{color:#f5c66a!important;}'
        . '.components-placeholder .components-button.is-primary,'
        . '.editor-styles-wrapper .components-button.is-primary:not(.is-link){'
        . 'background:var(--ysh-brand,#eda934)!important;background-color:var(--ysh-brand,#eda934)!important;'
        . 'color:#1a1d23!important;border-color:var(--ysh-brand,#eda934)!important;}'
        . '.components-placeholder .components-button.is-primary:hover:not(:disabled),'
        . '.editor-styles-wrapper .components-button.is-primary:hover:not(:disabled):not(.is-link){'
        . 'background:color-mix(in srgb,var(--ysh-brand,#eda934) 88%,#000)!important;'
        . 'border-color:color-mix(in srgb,var(--ysh-brand,#eda934) 88%,#000)!important;'
        . 'color:#1a1d23!important;}'
        . '.components-placeholder .components-button.is-secondary,'
        . '.editor-styles-wrapper .components-button.is-secondary{'
        . 'background:transparent!important;color:var(--ysh-brand,#eda934)!important;'
        . 'box-shadow:inset 0 0 0 1px var(--ysh-brand,#eda934)!important;border-color:var(--ysh-brand,#eda934)!important;}'
        . '.components-placeholder .components-button.is-secondary:hover:not(:disabled),'
        . '.editor-styles-wrapper .components-button.is-secondary:hover:not(:disabled){'
        . 'background:color-mix(in srgb,var(--ysh-brand,#eda934) 14%,#1a1d23)!important;'
        . 'color:var(--ysh-brand,#eda934)!important;}'
        . '.editor-styles-wrapper a,.block-editor-block-list__block a,.rich-text a,'
        . '.wp-block-post-terms a,.wp-block-term-name a,.wp-block-post-title a{'
        . 'color:#eda934!important;}'
        . '.editor-styles-wrapper a:hover,.block-editor-block-list__block a:hover,'
        . '.rich-text a:hover,.wp-block-post-terms a:hover{color:#f5c66a!important;}'
        . '.block-editor-button-block-appender{color:rgba(255,255,255,.65)!important;'
        . 'box-shadow:inset 0 0 0 1px rgba(255,255,255,.22)!important;}'
        . '.block-editor-button-block-appender:hover{color:#eda934!important;'
        . 'box-shadow:inset 0 0 0 1px #eda934!important;}'
        . yooadmin_studio_hub_block_editor_canvas_block_selection_dark_css();
}

/**
 * Canvas block focus/selection overlays — remove WP white inset glow on dark backgrounds.
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_block_selection_dark_css(): string {
    return '.block-editor-block-list__layout .block-editor-block-list__block.is-highlighted::after,'
        . '.block-editor-block-list__layout .block-editor-block-list__block.is-highlighted ~ .is-multi-selected::after,'
        . '.block-editor-block-list__layout .block-editor-block-list__block:not([contenteditable=true]):focus::after,'
        . '.is-outline-mode .block-editor-block-list__block:not(.remove-outline).is-hovered:not(.is-selected)::after,'
        . '.is-outline-mode .block-editor-block-list__block:not(.remove-outline):not(.rich-text):not([contenteditable=true]).is-selected::after{'
        . 'box-shadow:none!important;outline-color:var(--wp-admin-theme-color,#eda934)!important;}'
        . '.block-editor-block-list__layout .block-editor-block-list__block.is-multi-selected:not(.is-partially-selected)::after{'
        . 'background:var(--wp-admin-theme-color,#eda934)!important;opacity:.22!important;}'
        . '.block-list-appender:only-child.is-drag-over .block-editor-button-block-appender{'
        . 'box-shadow:inset 0 0 0 1px rgba(255,255,255,.18)!important;}';
}

/**
 * Template / FSE content blocks in the canvas (headings, comments, forms, theme presets).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_template_content_dark_css(): string {
    return '.editor-styles-wrapper :where(h1,h2,h3,h4,h5,h6,.wp-block-heading,.wp-block-post-title,.wp-block-query-title){'
        . 'color:#d8d3ce!important;}'
        . '.wp-block-comments-title,.wp-block-post-comments-count,.comment-reply-title{color:#d8d3ce!important;}'
        . '.wp-block-comment-content,.wp-block-post-comments .commentlist .comment p{color:#cfd6e0!important;}'
        . '.has-white-background-color,'
        . '.wp-block-group.has-background.has-base-background-color,'
        . '.wp-block-group.has-background.has-base-2-background-color,'
        . '.wp-block-cover.has-base-background-color,'
        . '.wp-block-cover.has-base-2-background-color,'
        . '.wp-block-template-part .has-base-background-color,'
        . '.wp-block-template-part .has-base-2-background-color,'
        . '.is-root-container>.wp-block-group.has-base-2-background-color{'
        . 'background-color:#282d36!important;color:#cfd6e0!important;}'
        . '.wp-block-post-terms.has-background{background-color:#22262e!important;color:#cfd6e0!important;}'
        . '.wp-block-post-comments-form textarea,.wp-block-post-comments-form input:not([type=submit]):not([type=checkbox]),'
        . '.wp-block-post-comments textarea,.wp-block-post-comments input:not([type=submit]):not([type=checkbox]){'
        . 'background:#22262e!important;color:#cfd6e0!important;border-color:rgba(255,255,255,.14)!important;}'
        . '.wp-block-post-comments-form label,.wp-block-post-comments .comment-form label{color:#cfd6e0!important;}'
        . ':where(.wp-block-post-comments-form input[type=submit],.wp-block-post-comments input[type=submit]){'
        . 'background:#eda934!important;color:#1a1d23!important;border:none!important;}'
        . ':where(.wp-block-post-comments-form input[type=submit]:hover,.wp-block-post-comments input[type=submit]:hover){'
        . 'background:#f5c66a!important;}'
        . '.wp-block-post-navigation-link,.wp-block-comments-pagination{color:#cfd6e0!important;}'
        . '.wp-block-post-navigation-link a,.wp-block-comments-pagination a{color:#eda934!important;}';
}

/**
 * Style Book iframe — typography/color previews on dark canvas.
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_style_book_dark_css(): string {
    return 'body{background:#1a1d23!important;color:#cfd6e0!important;}'
        . '.is-root-container{'
        . '--wp--preset--color--contrast:#d8d3ce;'
        . '--wp--preset--color--contrast-2:#b4bdc9;'
        . '--wp--preset--color--contrast-3:#9aa5b1;'
        . '--wp--preset--color--base:#1a1d23;'
        . '--wp--preset--color--base-2:#282d36;'
        . '--wp--style--color--link:#eda934;color:#cfd6e0!important;}'
        . '.is-root-container :where(h1,h2,h3,h4,h5,h6,.wp-block-heading){color:#d8d3ce!important;}'
        . '.is-root-container a{color:#eda934!important;}'
        . '.editor-style-book__subcategory-title,.editor-style-book__example-title{'
        . 'color:#b4bdc9!important;border-top-color:rgba(255,255,255,.14)!important;}'
        . '.editor-style-book__example{border:1px solid rgba(255,255,255,.12)!important;'
        . 'background:rgba(255,255,255,.03)!important;}'
        . '.wp-block-search__input,input[type=search]{background:#22262e!important;'
        . 'color:#cfd6e0!important;border-color:rgba(255,255,255,.14)!important;}';
}

/**
 * Canvas structure — header/footer bands, section frames, elevated surfaces.
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_structure_dark_css(): string {
    return '.wp-block-template-part[data-area=header],'
        . '.wp-block-template-part[data-area=header]>.wp-block-group,'
        . '.wp-block-template-part[data-area=header] .has-base-2-background-color{'
        . 'background-color:#282d36!important;'
        . 'border-bottom:1px solid rgba(255,255,255,.14)!important;}'
        . '.wp-block-template-part[data-area=footer],'
        . '.wp-block-template-part[data-area=footer]>.wp-block-group,'
        . '.wp-block-template-part[data-area=footer] .has-base-2-background-color{'
        . 'background-color:#282d36!important;'
        . 'border-top:1px solid rgba(255,255,255,.14)!important;}'
        . '.is-root-container>.wp-block-group.has-base-2-background-color:first-child{'
        . 'background-color:#282d36!important;'
        . 'border-bottom:1px solid rgba(255,255,255,.14)!important;}'
        . '.wp-block-template-part[data-area=header],'
        . '.wp-block-template-part[data-area=footer]{'
        . 'box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)!important;}'
        . '.editor-style-book__example{border:1px solid rgba(255,255,255,.12)!important;'
        . 'background:rgba(255,255,255,.03)!important;}';
}

/**
 * Iframe names that receive injected canvas dark/light CSS.
 *
 * @return string JS selector list for querySelectorAll.
 */
function yooadmin_studio_hub_block_editor_canvas_iframe_selector(): string {
    return 'iframe[name="editor-canvas"],iframe[name="style-book-canvas"]';
}

/**
 * Canvas block surfaces — keep wrappers transparent so theme base colors do not stripe rows.
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_block_surface_dark_css(): string {
    return '.block-editor-block-list__layout.is-root-container,'
        . '.is-root-container.block-editor-block-list__layout{'
        . 'background:transparent!important;background-color:transparent!important;}'
        . '.block-editor-block-list__layout .block-editor-block-list__block,'
        . '.block-editor-block-list__layout > .block-list-appender.wp-block,'
        . '.block-editor-block-list__layout .block-list-appender.wp-block{'
        . 'background:transparent!important;background-color:transparent!important;}'
        . '.block-editor-block-list__layout .block-editor-block-list__block > .wp-block:not(.has-background):not([class*="has-"][class*="-background-color"]),'
        . '.block-editor-block-list__layout .block-editor-block-list__block .wp-block-paragraph:not(.has-background),'
        . '.block-editor-block-list__layout .block-editor-block-list__block .wp-block-heading:not(.has-background){'
        . 'background:transparent!important;background-color:transparent!important;}'
        . '.block-editor-block-list__layout .has-base-background-color:not(.wp-block-group):not(.wp-block-cover):not(.wp-block-template-part),'
        . '.block-editor-block-list__layout .has-base-2-background-color:not(.wp-block-group):not(.wp-block-cover):not(.wp-block-template-part){'
        . 'background:transparent!important;background-color:transparent!important;}';
}

/**
 * Block inserter preview iframe — scaled block examples (Preformatted, etc.).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_inserter_preview_dark_css(): string {
    return '.is-root-container{'
        . '--wp--preset--color--contrast:#d8d3ce;'
        . '--wp--preset--color--contrast-2:#b4bdc9;'
        . '--wp--preset--color--base:#22262e;'
        . '--wp--preset--color--base-2:#282d36;'
        . 'color:#cfd6e0!important;background:#22262e!important;}'
        . '.is-root-container :where(h1,h2,h3,h4,h5,h6,.wp-block-heading){color:#d8d3ce!important;}'
        . '.is-root-container .block-editor-block-icon,'
        . '.is-root-container .block-editor-block-icon svg,'
        . '.is-root-container .components-placeholder,'
        . '.is-root-container .components-placeholder__label{color:#cfd6e0!important;fill:currentColor!important;}'
        . '.is-root-container pre,.is-root-container code{color:#cfd6e0!important;'
        . 'background:#1a1d23!important;}';
}

/**
 * Canvas iframe scrollbars — parent doc rules do not reach editor-canvas iframe.
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_scrollbar_dark_css(): string {
    return 'html,body{color-scheme:dark;scrollbar-color:rgba(255,255,255,.22) #1a1d23;scrollbar-width:thin;}'
        . 'html::-webkit-scrollbar,body::-webkit-scrollbar,*::-webkit-scrollbar{width:10px;height:10px;}'
        . 'html::-webkit-scrollbar-track,body::-webkit-scrollbar-track,*::-webkit-scrollbar-track{background:#1a1d23;}'
        . 'html::-webkit-scrollbar-thumb,body::-webkit-scrollbar-thumb,*::-webkit-scrollbar-thumb{'
        . 'background:rgba(255,255,255,.22);border-radius:5px;}'
        . 'html::-webkit-scrollbar-thumb:hover,body::-webkit-scrollbar-thumb:hover,*::-webkit-scrollbar-thumb:hover{'
        . 'background:rgba(255,255,255,.34);}'
        . 'html::-webkit-scrollbar-corner,body::-webkit-scrollbar-corner,*::-webkit-scrollbar-corner{background:#1a1d23;}';
}

/**
 * Inline CSS injected into the Gutenberg iframe canvas (reset forces #fff on .editor-styles-wrapper).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_dark_css(): string {
    return ':root{--wp-editor-canvas-background:#1a1d23;'
        . '--wp-admin-theme-color:#eda934!important;'
        . '--wp-admin-theme-color--rgb:237,169,52;'
        . '--wp-components-color-accent:#eda934!important;'
        . '--wp-components-color-accent-darker-10:#d4922a!important;'
        . '--wp-components-color-accent-darker-20:#b87a1f!important;}'
        . 'html{background:#1a1d23!important;color:#cfd6e0!important;}'
        . 'html :where(.editor-styles-wrapper){background:#1a1d23!important;color:#cfd6e0!important;'
        . '--wp--preset--color--contrast:#d8d3ce;'
        . '--wp--preset--color--contrast-2:#b4bdc9;'
        . '--wp--preset--color--contrast-3:#9aa5b1;'
        . '--wp--preset--color--base:#1a1d23;'
        . '--wp--preset--color--base-2:#282d36;'
        . '--wp--style--color--link:#eda934;'
        . '--wp-admin-theme-color:#eda934;'
        . '--wp-components-color-accent:#eda934;}'
        . 'body{background:#1a1d23!important;color:#cfd6e0!important;}'
        . '.editor-post-title__input,.editor-post-title__input::placeholder{color:#d8d3ce!important;}'
        . '.block-editor-default-block-appender__content{color:#9aa5b1!important;}'
        . yooadmin_studio_hub_block_editor_canvas_scrollbar_dark_css()
        . yooadmin_studio_hub_block_editor_canvas_block_surface_dark_css()
        . yooadmin_studio_hub_block_editor_canvas_structure_dark_css()
        . yooadmin_studio_hub_block_editor_canvas_block_ui_dark_css()
        . yooadmin_studio_hub_block_editor_canvas_template_content_dark_css()
        . yooadmin_studio_hub_block_editor_canvas_style_book_dark_css();
}

/**
 * Preview iframe bundle — main canvas dark rules plus inserter preview surface.
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_preview_iframe_dark_css(): string {
    return yooadmin_studio_hub_block_editor_canvas_dark_css()
        . yooadmin_studio_hub_block_editor_canvas_inserter_preview_dark_css();
}

/**
 * Light canvas reset — overrides dark iframe styles without a page reload.
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_light_css(): string {
    return ':root{--wp-editor-canvas-background:#fff;}'
        . 'html{background:#fff!important;color:#1e1e1e!important;color-scheme:light!important;}'
        . 'html :where(.editor-styles-wrapper){background:#fff!important;color:#1e1e1e!important;}'
        . 'body{background:#fff!important;color:#1e1e1e!important;}'
        . '.editor-post-title__input,.editor-post-title__input::placeholder{color:#1e1e1e!important;}'
        . '.editor-post-title__input::placeholder{color:#757575!important;}'
        . '.block-editor-default-block-appender__content{color:#757575!important;}'
        . 'html,body{scrollbar-color:rgba(0,0,0,.25) #f0f0f0;scrollbar-width:thin;}';
}

/**
 * Minimal canvas paint — first style in iframe head before theme/global styles.
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_preflash_css(): string {
    $light = ':root{--wp-editor-canvas-background:#fff;}'
        . 'html{background:#fff!important;color:#1e1e1e!important;color-scheme:light;}'
        . 'body{background:#fff!important;color:#1e1e1e!important;}'
        . 'html :where(.editor-styles-wrapper){background:#fff!important;color:#1e1e1e!important;}';
    $dark  = ':root{--wp-editor-canvas-background:#1a1d23;}'
        . 'html{background:#1a1d23!important;color:#cfd6e0!important;color-scheme:dark;}'
        . 'body{background:#1a1d23!important;color:#cfd6e0!important;}'
        . 'html :where(.editor-styles-wrapper){background:#1a1d23!important;color:#cfd6e0!important;}';

    $mode = yooadmin_studio_hub_get_color_mode();
    if ('light' === $mode) {
        return $light;
    }
    if ('dark' === $mode) {
        return $dark;
    }

    return $light . '@media (prefers-color-scheme:dark){' . $dark . '}';
}

/**
 * Canvas CSS for block_editor_settings (first iframe paint — before JS runs).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_canvas_settings_css(): string {
    $mode = yooadmin_studio_hub_get_color_mode();
    if ('light' === $mode) {
        return '';
    }

    $dark = yooadmin_studio_hub_block_editor_canvas_dark_css();
    if ('dark' === $mode) {
        return $dark;
    }

    return '@media (prefers-color-scheme: dark){' . $dark . '}';
}

/**
 * Seed iframe canvas styles at editor bootstrap (no white flash on refresh).
 *
 * @param array                   $editor_settings      Block editor settings.
 * @param WP_Block_Editor_Context $block_editor_context Editor context.
 * @return array
 */
function yooadmin_studio_hub_filter_block_editor_settings_canvas_theme(array $editor_settings, $block_editor_context): array {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return $editor_settings;
    }
    if (!yooadmin_studio_hub_is_gutenberg_admin_request()) {
        return $editor_settings;
    }

    $css = yooadmin_studio_hub_block_editor_canvas_settings_css();
    if ('' === $css) {
        return $editor_settings;
    }

    if (!isset($editor_settings['styles']) || !is_array($editor_settings['styles'])) {
        $editor_settings['styles'] = [];
    }

    array_unshift(
        $editor_settings['styles'],
        [
            'css'            => yooadmin_studio_hub_block_editor_canvas_preflash_css(),
            '__unstableType' => 'yooadmin-studio-hub-canvas-preflash',
            'isGlobalStyles' => false,
        ]
    );

    $editor_settings['styles'][] = [
        'css'            => $css,
        '__unstableType' => 'yooadmin-studio-hub-canvas-theme',
        'isGlobalStyles' => false,
    ];

    return $editor_settings;
}

/**
 * Early head script — sync canvas iframe before React footer scripts (anti-flash).
 */
function yooadmin_studio_hub_print_block_editor_canvas_early_script(): void {
    if (defined('YOOADMIN_STUDIO_HUB_BLOCK_EDITOR_THEME_SYNC_PRINTED')) {
        return;
    }
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_gutenberg_admin_request()) {
        return;
    }

    define('YOOADMIN_STUDIO_HUB_BLOCK_EDITOR_THEME_SYNC_PRINTED', true);

    $dark_css         = yooadmin_studio_hub_block_editor_canvas_dark_css();
    $preview_dark_css = yooadmin_studio_hub_block_editor_canvas_preview_iframe_dark_css();
    $light_css        = yooadmin_studio_hub_block_editor_canvas_light_css();
    $canvas_sig       = '#1a1d23';

    $iframe_selector = yooadmin_studio_hub_block_editor_canvas_iframe_selector();

    echo '<script id="yooadmin-studio-hub-block-editor-canvas-early">'
        . '(function(){'
        . 'var darkCss=' . wp_json_encode($dark_css) . ';'
        . 'var previewDarkCss=' . wp_json_encode($preview_dark_css) . ';'
        . 'var lightCss=' . wp_json_encode($light_css) . ';'
        . 'var canvasSig=' . wp_json_encode($canvas_sig) . ';'
        . 'var iframeSelector=' . wp_json_encode($iframe_selector) . ';'
        . 'function yshIsDark(){return document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";}'
        . 'function yshEnsureHead(doc){'
        . 'if(!doc||!doc.documentElement){return null;}'
        . 'var head=doc.head||doc.getElementsByTagName("head")[0];'
        . 'if(!head){head=doc.createElement("head");if(doc.documentElement.firstChild){doc.documentElement.insertBefore(head,doc.documentElement.firstChild);}else{doc.documentElement.appendChild(head);}}'
        . 'return head;'
        . '}'
        . 'function yshSyncDoc(doc,isPreview){'
        . 'if(!doc||!doc.documentElement){return;}'
        . 'var dark=yshIsDark();'
        . 'if(doc.body){doc.body.classList.toggle("is-dark-theme",dark);}'
        . 'doc.documentElement.classList.toggle("is-dark-theme",dark);'
        . 'var head=yshEnsureHead(doc);'
        . 'if(!head){return;}'
        . 'var el=doc.getElementById("yooadmin-studio-hub-canvas-theme");'
        . 'if(!el){el=doc.createElement("style");el.id="yooadmin-studio-hub-canvas-theme";head.appendChild(el);}'
        . 'el.textContent=dark?(isPreview?previewDarkCss:darkCss):lightCss;'
        . 'if(dark){'
        . 'if(doc.documentElement){doc.documentElement.style.backgroundColor=canvasSig;}'
        . 'if(doc.body){doc.body.style.backgroundColor=canvasSig;}'
        . '}else{'
        . 'if(doc.documentElement){doc.documentElement.style.removeProperty("background-color");}'
        . 'if(doc.body){doc.body.style.removeProperty("background-color");}'
        . 'doc.querySelectorAll("style").forEach(function(st){'
        . 'if(!st||st.id==="yooadmin-studio-hub-canvas-theme"){return;}'
        . 'var t=st.textContent||"";'
        . 'if(t.indexOf("editor-styles-wrapper")>-1&&t.indexOf(canvasSig)>-1){st.remove();}'
        . '});'
        . '}'
        . '}'
        . 'function yshPrimeFrame(frame,isPreview){'
        . 'if(!frame){return;}'
        . 'if(yshIsDark()){frame.style.setProperty("background-color",canvasSig,"important");}'
        . 'else{frame.style.removeProperty("background-color");}'
        . 'function sync(){try{yshSyncDoc(frame.contentDocument||frame.contentWindow.document,isPreview);}catch(e){}}'
        . 'sync();'
        . 'if(!frame.__yshCanvasBound){frame.__yshCanvasBound=true;frame.addEventListener("load",sync);}'
        . 'if(!frame.__yshCanvasPoll){frame.__yshCanvasPoll=true;var n=0,t=setInterval(function(){'
        . 'try{var d=frame.contentDocument||frame.contentWindow.document;if(d&&d.body){sync();clearInterval(t);return;}}catch(e){}'
        . 'sync();if(++n>15){clearInterval(t);}'
        . '},200);}'
        . '}'
        . 'var yshCanvasSyncPending=false;'
        . 'function yshScheduleCanvasSync(){'
        . 'if(yshCanvasSyncPending){return;}'
        . 'yshCanvasSyncPending=true;'
        . 'requestAnimationFrame(function(){yshCanvasSyncPending=false;yshSyncFrames();});'
        . '}'
        . 'function yshSyncFrames(){'
        . 'var dark=yshIsDark();'
        . 'if(document.body&&document.body.classList.contains("block-editor-page")){'
        . 'document.body.classList.toggle("is-dark-theme",dark);'
        . 'document.documentElement.classList.toggle("is-dark-theme",dark);'
        . '}'
        . 'document.querySelectorAll(iframeSelector).forEach(function(f){yshPrimeFrame(f,false);});'
        . 'document.querySelectorAll("iframe").forEach(function(f){'
        . 'try{var d=f.contentDocument||f.contentWindow.document;'
        . 'if(!d||!d.documentElement||!d.documentElement.classList.contains("block-editor-block-preview__content-iframe")){return;}'
        . 'yshPrimeFrame(f,true);'
        . '}catch(e){}'
        . '});'
        . '}'
        . 'function yshCanvasMutationsNeedSync(muts){'
        . 'for(var i=0;i<muts.length;i++){'
        . 'var m=muts[i];if(m.type!=="childList"){continue;}'
        . 'var nodes=m.addedNodes;'
        . 'for(var j=0;j<nodes.length;j++){'
        . 'var node=nodes[j];'
        . 'if(node.nodeType!==1){continue;}'
        . 'if(node.tagName==="IFRAME"||(node.querySelector&&node.querySelector("iframe"))){return true;}'
        . '}'
        . '}'
        . 'return false;'
        . '}'
        . 'function yshWatchCanvasFrames(){'
        . 'if(window.__yshCanvasFrameObs){return;}'
        . 'window.__yshCanvasFrameObs=new MutationObserver(function(muts){'
        . 'if(yshCanvasMutationsNeedSync(muts)){yshScheduleCanvasSync();}'
        . '});'
        . 'function yshBindCanvasObs(){'
        . 'var root=document.getElementById("editor")||document.querySelector(".interface-interface-skeleton");'
        . 'if(root){window.__yshCanvasFrameObs.observe(root,{childList:true,subtree:true});return true;}'
        . 'return false;'
        . '}'
        . 'if(!yshBindCanvasObs()&&document.readyState==="loading"){'
        . 'document.addEventListener("DOMContentLoaded",function(){yshBindCanvasObs();yshScheduleCanvasSync();},{once:true});'
        . '}'
        . '}'
        . 'window.yshBlockEditorThemeSync=window.yshBlockEditorThemeSync||yshSyncFrames;'
        . 'yshSyncFrames();'
        . 'yshWatchCanvasFrames();'
        . 'window.addEventListener("load",yshSyncFrames,{once:true});'
        . 'document.addEventListener("ysh-studio-color-mode-changed",yshSyncFrames);'
        . '})();'
        . '</script>' . "\n";
}

/**
 * Runtime theme sync — alias for canvas early script (footer fallback if head missed).
 */
function yooadmin_studio_hub_print_block_editor_dark_script(): void {
    if (defined('YOOADMIN_STUDIO_HUB_BLOCK_EDITOR_THEME_SYNC_PRINTED')) {
        return;
    }
    yooadmin_studio_hub_print_block_editor_canvas_early_script();
}

/**
 * Dark cascade tail after wp-admin block editor styles.
 */
function yooadmin_studio_hub_enqueue_block_editor_dark_tail(): void {
    if (!yooadmin_studio_hub_block_editor_assets_applies()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-block-editor-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $deps = [];
    foreach (['yooadmin-studio-hub-late', 'yooadmin-studio-hub-tokens', 'yooadmin-shell'] as $handle) {
        if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
            $deps[] = $handle;
        }
    }
    foreach (
        ['wp-edit-blocks', 'wp-block-editor', 'wp-block-library', 'wp-components', 'wp-edit-site', 'wp-edit-site-rtl'] as $handle
    ) {
        if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
            $deps[] = $handle;
        }
    }
    if ([] === $deps) {
        $deps[] = 'wp-components';
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-block-editor-dark',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-block-editor-dark.css'),
        array_values(array_unique($deps)),
        (string) filemtime($file)
    );

    $engine = yooadmin_studio_hub_asset_path('css/compat/studio-hub-block-editor-engine-dark.css');
    if (is_readable($engine)) {
        wp_enqueue_style(
            'yooadmin-studio-hub-block-editor-engine-dark',
            yooadmin_studio_hub_asset_url('css/compat/studio-hub-block-editor-engine-dark.css'),
            ['yooadmin-studio-hub-block-editor-dark'],
            (string) filemtime($engine)
        );
    }

    yooadmin_studio_hub_enqueue_block_editor_adaptive_assets();
}

/**
 * First-paint rules for portaled template libraries (before vendor CSS + adaptive JS).
 *
 * @return string
 */
function yooadmin_studio_hub_block_editor_adaptive_antiflash_css(): string {
    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return '';
    }

    $d  = 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)';
    $dh = 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]';
    $b  = 'body:is(.block-editor-page,.site-editor-php)';
    $host = $d . ' ' . $b . ' :is(.react-responsive-modal-root,[class*="gutenkit-library"],[class*="gkit-template"],[class*="gutenkit-template"])';
    $panel = $host . ' :is([class*="library"],.react-responsive-modal-modal,[class*="library-header"],[class*="library-body"],[class*="library-filter"],[class*="library-menu"],[class*="library-list"])';
    $chip = $host . ' [class*="filter-category"],' . $host . ' [class*="menu-item"],' . $host . ' [class*="list-item"]';

    return $host . '{background:#1a1d23!important;background-color:#1a1d23!important;color:#cfd6e0!important;}'
        . $panel . ',' . $dh . ' ' . $b . ' :is(.react-responsive-modal-root,[class*="gutenkit-library"]) :is([class*="library"],.react-responsive-modal-modal){'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;color:#cfd6e0!important;}'
        . $chip . ',' . $dh . ' ' . $b . ' [class*="gutenkit-library"] [class*="filter-category"]{'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;}'
        . $host . ' :is(h1,h2,h3,h4,h5,h6,p,span,label,strong,li,small):not(.components-button):not(.dashicons),'
        . $dh . ' ' . $b . ' [class*="gutenkit-library"] :is(h1,h2,h3,h4,h5,h6,p,span,label,strong,li,small){'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $host . ' :is(input[type="search"],input[type="text"],input:not([type]),textarea,.components-text-control__input),'
        . $dh . ' ' . $b . ' [class*="gutenkit-library"] input{'
        . 'background:#121418!important;color:#cfd6e0!important;border-color:rgba(255,255,255,.14)!important;}';
}

/**
 * Critical CSS + early adaptive stylesheet (anti-flash before GutenKit modal paint).
 */
function yooadmin_studio_hub_print_block_editor_adaptive_critical(): void {
    if (!yooadmin_studio_hub_block_editor_assets_applies()) {
        return;
    }
    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return;
    }

    $antiflash = yooadmin_studio_hub_block_editor_adaptive_antiflash_css();
    if ('' !== $antiflash) {
        // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static critical CSS fragments.
        echo '<style id="yooadmin-studio-hub-block-editor-adaptive-critical">' . $antiflash . '</style>' . "\n";
        // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-block-editor-adaptive.css');
    if (is_readable($file)) {
        $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-block-editor-adaptive.css');
        $ver = (string) filemtime($file);
        // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Early paint before vendor modal CSS.
        printf(
            '<link rel="stylesheet" id="yooadmin-studio-hub-block-editor-adaptive-early" href="%s" />' . "\n",
            esc_url(add_query_arg('ver', $ver, $url))
        );
        // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
    }

}

/**
 * Late cascade — adaptive CSS after GutenKit template-library bundle.
 */
function yooadmin_studio_hub_print_block_editor_adaptive_cascade_tail(): void {
    if (!yooadmin_studio_hub_block_editor_assets_applies()) {
        return;
    }
    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-block-editor-adaptive.css');
    if (!is_readable($file)) {
        return;
    }

    $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-block-editor-adaptive.css');
    $ver = (string) filemtime($file);
    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Late cascade after vendor CSS.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-block-editor-adaptive-cascade-tail" href="%s" />' . "\n",
        esc_url(add_query_arg('ver', $ver, $url))
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

/**
 * Adaptive engine — GutenKit, modals, portaled React (no per-vendor CSS).
 */
function yooadmin_studio_hub_enqueue_block_editor_adaptive_assets(): void {
    if (!yooadmin_studio_hub_block_editor_assets_applies()) {
        return;
    }

    $css_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-block-editor-adaptive.css');
    $js_file  = yooadmin_studio_hub_asset_path('js/compat/studio-hub-block-editor-adaptive.js');
    if (!is_readable($css_file) || !is_readable($js_file)) {
        return;
    }

    $style_deps = ['yooadmin-studio-hub-block-editor-engine-dark'];
    if (!wp_style_is('yooadmin-studio-hub-block-editor-engine-dark', 'registered')) {
        $style_deps = ['yooadmin-studio-hub-block-editor-dark'];
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-block-editor-adaptive',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-block-editor-adaptive.css'),
        $style_deps,
        (string) filemtime($css_file)
    );

    if (!wp_script_is('yooadmin-studio-hub-block-editor-adaptive', 'enqueued')) {
        wp_enqueue_script(
            'yooadmin-studio-hub-block-editor-adaptive',
            yooadmin_studio_hub_asset_url('js/compat/studio-hub-block-editor-adaptive.js'),
            [],
            (string) filemtime($js_file),
            false
        );
    }
}

/**
 * @deprecated Alias — use yooadmin_studio_hub_enqueue_block_editor_adaptive_assets().
 */
function yooadmin_studio_hub_enqueue_block_editor_adaptive(): void {
    yooadmin_studio_hub_enqueue_block_editor_adaptive_assets();
}

/**
 * Re-link block editor dark tail late in <head>.
 */
function yooadmin_studio_hub_print_block_editor_cascade_tail(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_gutenberg_admin_request()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-block-editor-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-block-editor-dark.css');
    $ver = (string) filemtime($file);
    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Late cascade tail must load after wp-admin in <head>.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-block-editor-cascade-tail" href="%s" />' . "\n",
        esc_url(add_query_arg('ver', $ver, $url))
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

/**
 * Hidden template — appearance toggle cloned into Gutenberg header.
 */
function yooadmin_studio_hub_print_block_editor_appearance_template(): void {
    if (!yooadmin_studio_hub_is_gutenberg_admin_request() || !yooadmin_studio_hub_can_show_appearance_control()) {
        return;
    }

    echo '<div id="yooadmin-studio-hub-block-editor-appearance-source" hidden aria-hidden="true">';
    yooadmin_studio_hub_render_appearance_control(
        [
            'id_prefix' => 'ysh-be',
            'toggle_id' => 'ysh-be-appearance-toggle',
            'menu_id'   => 'ysh-be-appearance-menu',
        ]
    );
    echo '</div>' . "\n";
}

/**
 * Mount appearance toggle in Gutenberg header (same control as breadcrumbs bar).
 */
function yooadmin_studio_hub_print_block_editor_appearance_mount_script(): void {
    if (!yooadmin_studio_hub_is_gutenberg_admin_request() || !yooadmin_studio_hub_can_show_appearance_control()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-block-editor-appearance-mount">'
        . '(function(){'
        . 'function yshMountBlockEditorAppearance(){'
        . 'if(document.querySelector(".ysh-appearance--block-editor")){return true;}'
        . 'var host=document.querySelector(".editor-header__settings")'
        . '||document.querySelector(".edit-post-header__settings")'
        . '||document.querySelector(".editor-header__toolbar")'
        . '||document.querySelector(".edit-post-header__toolbar");'
        . 'if(!host){return;}'
        . 'var src=document.getElementById("yooadmin-studio-hub-block-editor-appearance-source");'
        . 'if(!src){return;}'
        . 'var wrap=src.querySelector(".ysh-appearance");'
        . 'if(!wrap){return;}'
        . 'wrap=wrap.cloneNode(true);'
        . 'wrap.classList.add("ysh-appearance--block-editor");'
        . 'host.insertBefore(wrap,host.firstChild);'
        . 'function yshInitMountedAppearance(el){'
        . 'function run(){if(window.yshInitStudioAppearanceToggle){window.yshInitStudioAppearanceToggle(el);return true;}return false;}'
        . 'if(run()){return;}'
        . 'var n=0,t=setInterval(function(){if(run()||++n>40){clearInterval(t);}},250);'
        . 'window.addEventListener("load",function(){run();});'
        . '}'
        . 'yshInitMountedAppearance(wrap);'
        . 'if(window.__yshBeAppearanceObs){window.__yshBeAppearanceObs.disconnect();window.__yshBeAppearanceObs=null;}'
        . 'return true;'
        . '}'
        . 'function yshWatchBlockEditorAppearance(){'
        . 'if(yshMountBlockEditorAppearance()){return;}'
        . 'if(window.__yshBeAppearanceObs){return;}'
        . 'window.__yshBeAppearanceObs=new MutationObserver(function(){yshMountBlockEditorAppearance();});'
        . 'var host=document.querySelector(".editor-header")||document.querySelector(".edit-post-header");'
        . 'if(host){window.__yshBeAppearanceObs.observe(host,{childList:true,subtree:true});}'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",yshWatchBlockEditorAppearance);}'
        . 'else{yshWatchBlockEditorAppearance();}'
        . 'window.addEventListener("load",yshMountBlockEditorAppearance);'
        . 'var yshBeMountTries=0;'
        . 'var yshBeMountIv=setInterval(function(){'
        . 'if(yshMountBlockEditorAppearance()||++yshBeMountTries>80){clearInterval(yshBeMountIv);}'
        . '},400);'
        . '})();'
        . '</script>' . "\n";
}

/**
 * Reserved — Gutenberg reads site_icon_url from core; do not inject YOOAdmin logo here.
 */
function yooadmin_studio_hub_print_block_editor_logo_mount_script(): void {
    // Intentionally empty: JS logo override replaced Site Icon with logo.png.
}
