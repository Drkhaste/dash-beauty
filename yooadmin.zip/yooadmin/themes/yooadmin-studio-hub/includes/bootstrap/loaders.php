<?php
/**
 * Studio Hub — load theme modules in dependency order.
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

require_once dirname(__DIR__, 2) . '/includes/helpers.php';
require_once dirname(__DIR__, 2) . '/includes/appearance.php';
require_once dirname(__DIR__, 2) . '/includes/dashboard.php';
require_once dirname(__DIR__, 2) . '/includes/studio-hub-layout-storage.php';
require_once dirname(__DIR__, 2) . '/includes/studio-hub-layout-ssr.php';
require_once dirname(__DIR__, 2) . '/includes/product-editor.php';
require_once dirname(__DIR__, 2) . '/includes/plugins-extensions.php';
require_once dirname(__DIR__, 2) . '/includes/plugins-php.php';
require_once dirname(__DIR__, 2) . '/includes/yoo-pages-shell-loader.php';
require_once dirname(__DIR__, 2) . '/includes/plugins-php-layout.php';
require_once dirname(__DIR__, 2) . '/includes/network-plugin-install-layout.php';
require_once dirname(__DIR__, 2) . '/includes/plugin-install-information.php';
require_once dirname(__DIR__, 2) . '/includes/plugin-admin-compat.php';
require_once dirname(__DIR__, 2) . '/includes/dark-engine.php';
require_once dirname(__DIR__, 2) . '/includes/themes-php.php';
require_once dirname(__DIR__, 2) . '/includes/block-editor.php';
require_once dirname(__DIR__, 2) . '/includes/woocommerce/overrides.php';
require_once dirname(__DIR__, 2) . '/includes/woocommerce/wc-admin.php';
require_once dirname(__DIR__, 2) . '/includes/woocommerce/wc-settings.php';
require_once dirname(__DIR__, 2) . '/includes/woocommerce/wc-orders.php';
require_once dirname(__DIR__, 2) . '/includes/woocommerce/wc-reports.php';
require_once dirname(__DIR__, 2) . '/includes/woocommerce/shop-coupon.php';
require_once dirname(__DIR__, 2) . '/includes/woocommerce/product-catalog.php';
