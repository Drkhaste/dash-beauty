<?php
/**
 * Studio Hub — plugins-extensions
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * Dark cascade tail after yooadmin-upload-page / extensions-store (loads last).
 */
function yooadmin_studio_hub_enqueue_plugins_extensions_dark_tail(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_plugins_extensions_page()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugins-ext-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $deps = ['yooadmin-studio-hub-late'];
    $after = [
        'yooadmin-upload-page',
        'yooadmin-upload-modal',
        'yooadmin-addons-store',
        'yooadmin-addons-store-header',
        'yooadmin-addons-store-enhancements',
        'yooadmin-addons-store-variants',
    ];
    foreach ($after as $handle) {
        if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
            $deps[] = $handle;
        }
    }

    $ver = (string) filemtime($file);

    wp_enqueue_style(
        'yooadmin-studio-hub-plugins-ext-dark',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugins-ext-dark.css'),
        $deps,
        $ver
    );

    $inline = yooadmin_studio_hub_plugins_extensions_filter_dark_css();
    if ($inline !== '') {
        wp_add_inline_style('yooadmin-studio-hub-plugins-ext-dark', $inline);
    }
}

/**
 * Inline dark rules for extension/plugin filters (same specificity as extensions-store-header.css).
 *
 * @return string
 */
function yooadmin_studio_hub_plugins_extensions_filter_dark_css(): string {
    return 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin select.yp-store-filter,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin select#yp-extensions-filter,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin select.yoo-status-filter,'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin select#yoo-status-filter,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin select.yp-store-filter,'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin select#yp-extensions-filter'
        . '{color-scheme:dark!important;-webkit-appearance:none!important;appearance:none!important;'
        . 'background:#22262e!important;background-color:#22262e!important;'
        . 'background-image:url("data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'10\' height=\'5\' viewBox=\'0 0 10 5\'><path fill=\'%239aa5b1\' d=\'M0 0l5 5 5-5z\'/></svg>")!important;'
        . 'background-repeat:no-repeat!important;background-position:right 12px center!important;'
        . 'background-size:10px 5px!important;color:#cfd6e0!important;'
        . 'border:1px solid rgba(255,255,255,.14)!important;border-color:rgba(255,255,255,.14)!important;'
        . 'box-shadow:none!important;outline:none!important;}';
}

/**
 * Critical dark rules for filters (first paint before full CSS).
 */
function yooadmin_studio_hub_print_plugins_extensions_critical(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_plugins_extensions_page()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-plugins-ext-critical">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin'
        . ' :is(select#yoo-status-filter,select#yp-extensions-filter,select.yp-store-filter,select.yoo-status-filter){'
        . 'color-scheme:dark!important;background:#22262e!important;background-color:#22262e!important;'
        . 'color:#cfd6e0!important;border:1px solid rgba(255,255,255,.14)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin'
        . ' :is(select#yp-extensions-filter,select.yp-store-filter):is(:hover,:focus,:focus-visible,:active){'
        . 'background:#22262e!important;background-color:#22262e!important;'
        . 'color:#cfd6e0!important;border-color:rgba(255,255,255,.14)!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.yooadmin-theme-yooadmin-studio-hub'
        . ' .yp-ext-actions :is(.button-activate,.button-danger){background-color:rgba(255,255,255,.06)!important;}'
        . '</style>' . "\n";
}

/**
 * Re-link plugins/extensions dark tail last in <head> (studio-hub.js may move again after late plugin CSS).
 */
function yooadmin_studio_hub_print_plugins_extensions_cascade_tail(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_plugins_extensions_page()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugins-ext-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugins-ext-dark.css');
    $ver = (string) filemtime($file);
    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Late cascade tail must load after wp-admin in <head>.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-plugins-ext-cascade-tail" href="%s" />' . "\n",
        esc_url(add_query_arg('ver', $ver, $url))
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

/**
 * Footer dark rules for filters (beats extensions-store-header + late plugin CSS in <head>).
 */
function yooadmin_studio_hub_print_plugins_extensions_footer_dark(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_plugins_extensions_page()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-plugins-ext-footer">'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin'
        . ' :is(select#yoo-status-filter,select#yp-extensions-filter,select.yp-store-filter,select.yoo-status-filter),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin'
        . ' :is(select#yoo-status-filter,select#yp-extensions-filter,select.yp-store-filter,select.yoo-status-filter){'
        . 'color-scheme:dark!important;-webkit-appearance:none!important;appearance:none!important;'
        . 'background:#22262e!important;background-color:#22262e!important;'
        . 'background-image:url("data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'10\' height=\'5\' viewBox=\'0 0 10 5\'><path fill=\'%239aa5b1\' d=\'M0 0l5 5 5-5z\'/></svg>")!important;'
        . 'background-repeat:no-repeat!important;background-position:right 12px center!important;'
        . 'background-size:10px 5px!important;'
        . 'color:#cfd6e0!important;border:1px solid rgba(255,255,255,.14)!important;'
        . 'box-shadow:none!important;outline:none!important;}'
        . 'html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin'
        . ' :is(select#yp-extensions-filter,select.yp-store-filter):is(:hover,:focus,:focus-visible,:active),'
        . 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"] body.wp-admin'
        . ' :is(select#yp-extensions-filter,select.yp-store-filter):is(:hover,:focus,:focus-visible,:active){'
        . 'background:#22262e!important;background-color:#22262e!important;'
        . 'color:#cfd6e0!important;border-color:rgba(255,255,255,.2)!important;}'
        . '</style>' . "\n";
}

/**
 * Footer script: enforce dark filter chrome after extensions-store.js (no MutationObserver).
 */
function yooadmin_studio_hub_print_plugins_extensions_filter_fix_script(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!yooadmin_studio_hub_is_plugins_extensions_page()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-plugins-ext-filter-fix">'
        . '(function(){'
        . 'var arrow=\'url("data:image/svg+xml;utf8,<svg xmlns=\\\'http://www.w3.org/2000/svg\\\' width=\\\'10\\\' height=\\\'5\\\' viewBox=\\\'0 0 10 5\\\'><path fill=\\\'%239aa5b1\\\' d=\\\'M0 0l5 5 5-5z\\\'/></svg>")\';'
        . 'function fix(){'
        . 'if(document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")!=="dark"){return;}'
        . 'document.querySelectorAll("select#yp-extensions-filter,select.yp-store-filter,select#yoo-status-filter,select.yoo-status-filter").forEach(function(el){'
        . 'el.style.setProperty("background","#22262e","important");'
        . 'el.style.setProperty("background-color","#22262e","important");'
        . 'el.style.setProperty("background-image",arrow,"important");'
        . 'el.style.setProperty("background-repeat","no-repeat","important");'
        . 'el.style.setProperty("background-position","right 12px center","important");'
        . 'el.style.setProperty("background-size","10px 5px","important");'
        . 'el.style.setProperty("color","#cfd6e0","important");'
        . 'el.style.setProperty("border","1px solid rgba(255,255,255,0.14)","important");'
        . 'el.style.setProperty("color-scheme","dark","important");'
        . '});}'
        . 'fix();'
        . '[0,50,150,400,800,1500,2500].forEach(function(ms){setTimeout(fix,ms);});'
        . 'window.addEventListener("load",fix);'
        . 'document.addEventListener("ysh-studio-color-mode-changed",fix);'
        . '})();</script>' . "\n";
}

