<?php
/**
 * Studio Hub — generic third-party plugin admin dark compat (late cascade).
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

/**
 * WP core settings/tools screens using the YOOAdmin wp-settings-experience layer.
 *
 * These are still WordPress pages — not YOOAdmin-custom UI. Used only to avoid
 * treating ?page= routes on options-general.php as third-party plugin settings.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_wp_native_settings_experience_screen(): bool {
    if (!function_exists('yooadmin_wp_settings_experience_active')
        || !function_exists('yooadmin_wp_settings_experience_is_screen')) {
        return false;
    }

    return yooadmin_wp_settings_experience_active() && yooadmin_wp_settings_experience_is_screen();
}

/**
 * Third-party plugin settings registered under a core parent menu (?page=slug).
 *
 * Examples: options-general.php?page=my-plugin, settings.php?page=my-plugin.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_third_party_plugin_settings_route(): bool {
    if (yooadmin_studio_hub_is_wp_native_settings_experience_screen()) {
        return false;
    }

    global $pagenow;
    if (!isset($pagenow)) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    if ('' === $page || 0 === strpos($page, 'yooadmin')) {
        return false;
    }

    $plugin_parent_scripts = [
        'options-general.php',
        'settings.php',
        'tools.php',
        'upload.php',
        'edit.php',
        'edit-comments.php',
        'themes.php',
        'plugins.php',
        'users.php',
        'index.php',
    ];

    return in_array($pagenow, $plugin_parent_scripts, true);
}

/**
 * Native plugin catalog screens (YOOAdmin layout CSS — not adaptive compat).
 *
 * plugins.php without ?page= and plugin-install.php are excluded from the adaptive engine.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_native_plugin_catalog_screen(): bool {
    global $pagenow;

    if (!isset($pagenow)) {
        return false;
    }

    if ('plugin-install.php' === $pagenow) {
        return true;
    }

    if ('plugins.php' !== $pagenow) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    return '' === $page;
}

/**
 * Core WP list/tools screens with plugin banners or health-check accordions.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_wp_core_admin_compat_screen(): bool {
    global $pagenow;

    if (!isset($pagenow)) {
        return false;
    }

    return in_array(
        $pagenow,
        [
            'about.php',
            'credits.php',
            'freedoms.php',
            'privacy.php',
            'contribute.php',
            'site-health.php',
            'edit-comments.php',
            'import.php',
            'export.php',
            'update-core.php',
            'plugin-editor.php',
            'theme-editor.php',
        ],
        true
    );
}

/**
 * YOOAdmin-built admin UI (custom templates / Studio layouts).
 *
 * Excludes the generic plugin compat engine. Does NOT include bare WordPress core
 * screens (Import, Settings, Site Health, etc.) even when Focus Mode adds yoo-list-screen.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_yooadmin_native_experience_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return false;
    }

    if (yooadmin_studio_hub_is_wp_core_admin_compat_screen()) {
        return false;
    }

    if (yooadmin_studio_hub_is_yooadmin_native_admin_screen()) {
        return true;
    }

    if (yooadmin_studio_hub_is_native_plugin_catalog_screen()) {
        return true;
    }

    if (yooadmin_studio_hub_is_yooadmin_studio_custom_screen()) {
        return true;
    }

    if (function_exists('yooadmin_studio_hub_is_block_editor_page') && yooadmin_studio_hub_is_block_editor_page()) {
        return true;
    }

    if (function_exists('yooadmin_studio_hub_is_product_editor_screen') && yooadmin_studio_hub_is_product_editor_screen()) {
        return true;
    }

    if (function_exists('yooadmin_studio_hub_product_catalog_studio_active') && yooadmin_studio_hub_product_catalog_studio_active()) {
        return true;
    }

    if (function_exists('yooadmin_studio_hub_wc_settings_studio_active') && yooadmin_studio_hub_wc_settings_studio_active()) {
        return true;
    }

    if (function_exists('yooadmin_studio_hub_wc_orders_studio_active') && yooadmin_studio_hub_wc_orders_studio_active()) {
        return true;
    }

    if (function_exists('yooadmin_studio_hub_wc_reports_studio_active') && yooadmin_studio_hub_wc_reports_studio_active()) {
        return true;
    }

    if (function_exists('yooadmin_studio_hub_shop_coupon_list_studio_active') && yooadmin_studio_hub_shop_coupon_list_studio_active()) {
        return true;
    }

    if (function_exists('yooadmin_studio_hub_is_wc_admin_screen') && yooadmin_studio_hub_is_wc_admin_screen()) {
        return true;
    }

    return false;
}

/**
 * Screens with a YOOAdmin-custom layout (detectable before/at body class).
 *
 * @return bool
 */
function yooadmin_studio_hub_is_yooadmin_studio_custom_screen(): bool {
    global $pagenow;

    if (!isset($pagenow)) {
        return false;
    }

    if ('plugins.php' === $pagenow
        && function_exists('yooadmin_studio_hub_should_style_plugins_php_experience')
        && yooadmin_studio_hub_should_style_plugins_php_experience()) {
        return true;
    }

    if ('plugin-install.php' === $pagenow
        && function_exists('yooadmin_studio_hub_should_style_plugin_install_layout')
        && yooadmin_studio_hub_should_style_plugin_install_layout()) {
        return true;
    }

    if ('admin.php' !== $pagenow) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    $studio_custom_pages = apply_filters(
        'yooadmin_studio_hub_custom_admin_pages',
        [
            'yooadmin-posts',
            'yooadmin-pages',
            'yooadmin-users',
            'yooadmin-categories',
        ]
    );

    return in_array($page, $studio_custom_pages, true);
}

/**
 * WP Settings boot-layout screens (Connectors, AI, …) — React apps inside wp-settings-experience.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_wp_settings_boot_adaptive_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return false;
    }

    if (!function_exists('yooadmin_wp_settings_experience_active')
        || !function_exists('yooadmin_wp_settings_experience_is_boot_layout_screen')
        || !yooadmin_wp_settings_experience_active()) {
        return false;
    }

    if (!function_exists('get_current_screen')) {
        return false;
    }

    $screen = get_current_screen();
    if (!$screen || empty($screen->id)) {
        return false;
    }

    return yooadmin_wp_settings_experience_is_boot_layout_screen((string) $screen->id);
}

/**
 * Adaptive contrast engine scope (third-party compat + WP settings boot React surfaces).
 *
 * @return bool
 */
function yooadmin_studio_hub_should_run_plugin_admin_adaptive(): bool {
    // Bare plugin settings / classic editor: CSS-only — adaptive JS competes with TinyMCE + Yoast.
    if (yooadmin_studio_hub_should_skip_plugin_admin_adaptive()) {
        return false;
    }

    if (!yooadmin_studio_hub_is_plugin_admin_compat_screen()) {
        return false;
    }

    return !yooadmin_studio_hub_is_wp_core_admin_compat_screen();
}

/**
 * Body class scope for plugin-admin compat + boot-layout adaptive hosts.
 *
 * @return bool
 */
function yooadmin_studio_hub_applies_plugin_admin_compat_body_class(): bool {
    return yooadmin_studio_hub_is_plugin_admin_compat_screen()
        || yooadmin_studio_hub_is_wp_native_settings_experience_screen()
        || yooadmin_studio_hub_is_plugin_check_admin_screen();
}

/**
 * Admin screens that receive generic plugin compat dark CSS.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_plugin_admin_compat_screen(): bool {
    if (!is_admin() || !yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return false;
    }

    if (function_exists('get_current_screen')) {
        $screen = get_current_screen();
        if ($screen && $screen->is_block_editor()) {
            return false;
        }
    }

    global $pagenow;
    if (!isset($pagenow)) {
        return false;
    }

    if ('site-editor.php' === $pagenow) {
        return false;
    }

    if (function_exists('yooadmin_dark_engine_context')
        && in_array(yooadmin_dark_engine_context(), ['media', 'files'], true)
    ) {
        return false;
    }

    if (yooadmin_studio_hub_is_wp_core_admin_compat_screen()) {
        return true;
    }

    if (yooadmin_studio_hub_is_yooadmin_native_experience_screen()) {
        return false;
    }

    if (in_array($pagenow, ['post.php', 'post-new.php'], true)) {
        return true;
    }

    // Third-party plugin top-level/submenu (admin.php?page=…).
    if ('admin.php' === $pagenow) {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        $page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return '' !== $page;
    }

    // Plugin settings hung off core menus (options-general.php, tools.php, etc.).
    if (yooadmin_studio_hub_is_third_party_plugin_settings_route()) {
        return true;
    }

    return false;
}

/**
 * admin.php?page=…/settings.php — plugin UI mounted without a WordPress .wrap (TrustIndex, etc.).
 *
 * @return bool
 */
function yooadmin_studio_hub_get_admin_page_query_slug(): string {
    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    if (!isset($_GET['page'])) {
        return '';
    }
    $page = sanitize_text_field(wp_unslash((string) $_GET['page']));
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    return $page;
}

/**
 * Bare plugin settings canvas (no .wrap) — skip heavy compat stack; vendor CSS owns the UI.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_bare_plugin_settings_admin_screen(): bool {
    global $pagenow;

    if (!isset($pagenow) || 'admin.php' !== $pagenow) {
        return false;
    }

    $page = yooadmin_studio_hub_get_admin_page_query_slug();
    if ('' === $page || str_starts_with($page, 'yooadmin')) {
        return false;
    }

    if (false !== strpos($page, 'settings.php')) {
        return true;
    }

    return (bool) preg_match('/(?:^|[\\/])settings(?:\\.php)?$/i', $page);
}

/**
 * Yoast SEO active (classic or block editor metabox).
 *
 * @return bool
 */
function yooadmin_studio_hub_is_yoast_seo_active(): bool {
    return defined('WPSEO_VERSION')
        || class_exists('WPSEO_Admin', false)
        || class_exists('Yoast\WP\SEO\Main', false);
}

/**
 * SiteOrigin Page Builder active.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_siteorigin_panels_active(): bool {
    if (defined('SITEORIGIN_PANELS_VERSION') || class_exists('SiteOrigin_Panels', false)) {
        return true;
    }

    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    return is_plugin_active('siteorigin-panels/siteorigin-panels.php');
}

/**
 * Front-end page builder plugins that embed in post.php (Brizy, Breezy, SiteOrigin, etc.).
 *
 * @return bool
 */
function yooadmin_studio_hub_is_page_builder_editor_plugin_active(): bool {
    if (yooadmin_studio_hub_is_siteorigin_panels_active()) {
        return true;
    }

    if (defined('BRZY_VERSION') || class_exists('Brizy_Editor', false) || class_exists('Brizy_Admin', false)) {
        return true;
    }

    if (defined('BREEZY_VERSION') || defined('BREEZY_WP_VERSION')) {
        return true;
    }

    foreach (['Breezy_Page_Builder', 'Breezy_Admin', 'BreezyWP'] as $class_name) {
        if (class_exists($class_name, false)) {
            return true;
        }
    }

    if (!function_exists('is_plugin_active')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    $plugin_files = apply_filters(
        'yooadmin_studio_hub_page_builder_editor_plugin_files',
        [
            'brizy/brizy.php',
            'brizy-pro/brizy.php',
            'breezy-page-builder/breezy.php',
            'breezy-page-builder/main.php',
            'breezy/breezy.php',
            'breezy-page-builder/breezy-page-builder.php',
            'siteorigin-panels/siteorigin-panels.php',
        ]
    );

    foreach ((array) $plugin_files as $plugin_file) {
        if (is_string($plugin_file) && $plugin_file !== '' && is_plugin_active($plugin_file)) {
            return true;
        }
    }

    return false;
}

/**
 * Classic post editor with heavy third-party UIs (Yoast, page builders, TinyMCE).
 *
 * Uses CSS-only compat and skips the adaptive MutationObserver engine so editor
 * screens stay responsive.
 *
 * @return bool
 */
function yooadmin_studio_hub_classic_editor_has_plugin_editor_conflict(): bool {
    if (!yooadmin_studio_hub_is_classic_editor_compat_screen()) {
        return false;
    }

    $yoast   = yooadmin_studio_hub_is_yoast_seo_active();
    $builder = yooadmin_studio_hub_is_page_builder_editor_plugin_active();

    if ($yoast || $builder) {
        return true;
    }

    /**
     * Allow sites to extend conflict detection (e.g. other builder slugs).
     *
     * @param bool $conflict  Whether to use light compat only.
     * @param bool $yoast     Yoast SEO active.
     * @param bool $builder   Page builder plugin active.
     */
    return (bool) apply_filters(
        'yooadmin_studio_hub_classic_editor_has_plugin_editor_conflict',
        true,
        $yoast,
        $builder
    );
}

/**
 * Whether to skip studio-hub-plugin-admin-adaptive.js (DOM scan) on this request.
 *
 * @return bool
 */
function yooadmin_studio_hub_should_skip_plugin_admin_adaptive(): bool {
    if (yooadmin_studio_hub_should_skip_heavy_plugin_admin_compat()) {
        return true;
    }

    return yooadmin_studio_hub_is_classic_editor_compat_screen();
}

/**
 * Skip the full plugin-admin-dark + adaptive stack (TrustIndex-style bare settings only).
 *
 * Classic editor uses CSS-only dark + optional invert islands instead.
 *
 * @return bool
 */
function yooadmin_studio_hub_should_skip_heavy_plugin_admin_compat(): bool {
    return yooadmin_studio_hub_is_bare_plugin_settings_admin_screen();
}

/**
 * Body class — classic editor light compat (CSS only, no adaptive JS).
 *
 * @param string $classes Space-separated admin body classes.
 * @return string
 */
function yooadmin_studio_hub_filter_classic_editor_conflict_body_class(string $classes): string {
    if (!yooadmin_studio_hub_is_classic_editor_compat_screen()) {
        return $classes;
    }

    if (strpos($classes, 'ysh-classic-editor-light-compat') === false) {
        $classes .= ' ysh-classic-editor-light-compat';
    }

    if (
        yooadmin_studio_hub_classic_editor_dark_compat_wanted()
        && strpos($classes, 'ysh-classic-editor-static-dark') === false
    ) {
        $classes .= ' ysh-classic-editor-static-dark';
    }

    if (strpos($classes, 'yooadmin-theme-yooadmin-studio-hub') === false) {
        $classes .= ' yooadmin-theme-yooadmin-studio-hub';
    }

    return $classes;
}

/**
 * Whether to load the classic editor dark stack. Loads on every classic editor
 * screen regardless of the saved mode: the head CSS is fully scoped under the
 * dark attribute (inert in light) and the runtime script must be present so the
 * live color-mode toggle applies without a page refresh.
 *
 * @return bool
 */
function yooadmin_studio_hub_classic_editor_dark_compat_wanted(): bool {
    if (!yooadmin_studio_hub_is_classic_editor_compat_screen()) {
        return false;
    }

    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return false;
    }

    return true;
}

/**
 * Cached classic-editor dark CSS (transient keyed by filemtime — one disk read per deploy).
 *
 * @return string Raw CSS (no style tags).
 */
function yooadmin_studio_hub_get_classic_editor_dark_css_cached(): string {
    static $request_cache = null;

    if (is_string($request_cache)) {
        return $request_cache;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-classic-editor-dark.css');
    if (!is_readable($file)) {
        $request_cache = '';

        return '';
    }

    $mtime = (string) filemtime($file);
    $key   = 'ysh_classic_editor_dark_css_v14_' . md5($mtime);

    $cached = get_transient($key);
    if (is_string($cached) && $cached !== '') {
        $request_cache = $cached;

        return $cached;
    }

    // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local theme asset.
    $css = (string) file_get_contents($file);
    if ($css !== '') {
        set_transient($key, $css, WEEK_IN_SECONDS);
    }

    $request_cache = $css;

    return $css;
}

/**
 * First-paint antiflash (tiny; full rules come from cached bundle in admin_head).
 */
function yooadmin_studio_hub_print_classic_editor_dark_antiflash(): void {
    if (!yooadmin_studio_hub_classic_editor_dark_compat_wanted()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-classic-editor-dark-antiflash">'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus):is(.post-php,.post-new-php)'
        . ' :is(#poststuff .postbox,#titlediv,#title,.wp-editor-wrap,#submitdiv,.categorydiv,.tagsdiv,#wpseo_meta)'
        . '{background:#1a1d23!important;color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus):is(.post-php,.post-new-php)'
        . ' :is(#title,.wp-editor-area,.mce-edit-area,iframe[id$="_ifr"],#post-status-info,#post-status-info td,.autosave-info){background:#1a1d23!important;color:#e8ecf1!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus):is(.post-php,.post-new-php)'
        . ' .mce-listbox button{background:#22262e!important;color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus):is(.post-php,.post-new-php)'
        . ' #wpseo_meta :is([role="tab"],[role="tablist"],button[role="tab"]){background:#22262e!important;color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark):is(.post-php,.post-new-php)'
        . ' #wpseo_meta :is(label,[class*="yst-replacevar"] button,[class*="yst-replacevar"] span){color:#cfd6e0!important;background:#2d3340!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark):is(.post-php,.post-new-php)'
        . ' #wpseo_meta [class*="prominent"] :is([class*="bar"],div[style*="width"]){background:#3a4254!important;color:#e8ecf1!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark):is(.post-php,.post-new-php)'
        . ' .siteorigin-panels-builder :is(.so-builder-toolbar,.so-panels-welcome-message,.so-message-wrapper){background:#22262e!important;color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog{transition:none!important;animation:none!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog :is(.so-content,.so-title-bar,.so-toolbar,.so-left-sidebar,.so-right-sidebar,.so-row-preview,.so-cells-preview,.cell,.cell-wrapper){background:#1a1d23!important;background-color:#1a1d23!important;color:#cfd6e0!important;transition:none!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog :is(.so-toolbar,.so-toolbar *){background:#22262e!important;background-color:#22262e!important;color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog :is(.cell,.cell-wrapper,.so-row-preview,.so-cells-preview){background:#2a3040!important;background-color:#2a3040!important;}'
        . '</style>' . "\n";
}

/**
 * Inline cached dark CSS in head (loads once per request from transient; browser caches the file separately).
 */
function yooadmin_studio_hub_print_classic_editor_dark_critical(): void {
    if (!yooadmin_studio_hub_classic_editor_dark_compat_wanted()) {
        return;
    }

    $css = yooadmin_studio_hub_get_classic_editor_dark_css_cached();
    if ($css === '') {
        return;
    }

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS from disk.
    echo '<style id="yooadmin-studio-hub-classic-editor-dark-critical">' . $css . '</style>' . "\n";
}

/**
 * Enqueue classic editor dark compat (static CSS file for browser cache + transient on server).
 */
function yooadmin_studio_hub_enqueue_classic_editor_dark_compat(): void {
    if (!yooadmin_studio_hub_classic_editor_dark_compat_wanted()) {
        return;
    }

    $deps = yooadmin_studio_hub_resolve_style_deps(
        ['common', 'forms', 'editor-buttons', 'wp-admin', 'yooadmin-studio-hub-late']
    );

    $dark_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-classic-editor-dark.css');
    if (is_readable($dark_file)) {
        wp_enqueue_style(
            'yooadmin-studio-hub-classic-editor-dark',
            yooadmin_studio_hub_asset_url('css/compat/studio-hub-classic-editor-dark.css'),
            $deps,
            (string) filemtime($dark_file)
        );
        $deps = ['yooadmin-studio-hub-classic-editor-dark'];
    }

    $conflict_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-classic-editor-conflict-compat.css');
    if (is_readable($conflict_file)) {
        $conflict_deps = wp_style_is('yooadmin-studio-hub-classic-editor-dark', 'enqueued')
            ? ['yooadmin-studio-hub-classic-editor-dark']
            : $deps;
        $conflict_deps = yooadmin_studio_hub_resolve_style_deps($conflict_deps);
        if ([] !== $conflict_deps) {
            wp_enqueue_style(
                'yooadmin-studio-hub-classic-editor-conflict-compat',
                yooadmin_studio_hub_asset_url('css/compat/studio-hub-classic-editor-conflict-compat.css'),
                $conflict_deps,
                (string) filemtime($conflict_file)
            );
        }
    }

    if (yooadmin_studio_hub_is_siteorigin_panels_active()) {
        $so_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-siteorigin-panels-dark.css');
        if (is_readable($so_file)) {
            $so_deps = wp_style_is('yooadmin-studio-hub-classic-editor-dark', 'enqueued')
                ? ['yooadmin-studio-hub-classic-editor-dark']
                : $deps;
            if (wp_style_is('so-panels-admin', 'registered') || wp_style_is('so-panels-admin', 'enqueued')) {
                $so_deps[] = 'so-panels-admin';
            }
            $so_deps = yooadmin_studio_hub_resolve_style_deps($so_deps);
            wp_enqueue_style(
                'yooadmin-studio-hub-siteorigin-panels-dark',
                yooadmin_studio_hub_asset_url('css/compat/studio-hub-siteorigin-panels-dark.css'),
                $so_deps,
                (string) filemtime($so_file)
            );
        }

    }

    $patch_js = yooadmin_studio_hub_asset_path('js/compat/studio-classic-editor-dark-patch.js');
    if (is_readable($patch_js)) {
        wp_enqueue_script(
            'yooadmin-studio-hub-classic-editor-dark-patch',
            yooadmin_studio_hub_asset_url('js/compat/studio-classic-editor-dark-patch.js'),
            [],
            (string) filemtime($patch_js),
            true
        );
    }
}

/**
 * @deprecated 1.5.13 Use yooadmin_studio_hub_enqueue_classic_editor_dark_compat().
 */
function yooadmin_studio_hub_enqueue_classic_editor_conflict_compat(): void {
    yooadmin_studio_hub_enqueue_classic_editor_dark_compat();
}

/**
 * YOOAdmin native screens (dashboard, settings, etc.) — styled by theme CSS, not generic plugin compat.
 *
 * @return bool
 */
function yooadmin_studio_hub_is_yooadmin_native_admin_screen(): bool {
    global $pagenow;

    if (!isset($pagenow) || 'admin.php' !== $pagenow) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';
    // phpcs:enable WordPress.Security.NonceVerification.Recommended
    if ('' === $page) {
        return false;
    }

    return 0 === strpos($page, 'yooadmin');
}

/**
 * Late enqueue — after plugin stylesheets.
 */
function yooadmin_studio_hub_enqueue_plugin_admin_dark_tail(): void {
    $wp_settings_adaptive = yooadmin_studio_hub_is_wp_native_settings_experience_screen();

    if (
        !yooadmin_studio_hub_is_plugin_admin_compat_screen()
        && !yooadmin_studio_hub_is_plugin_check_admin_screen()
        && !$wp_settings_adaptive
    ) {
        return;
    }

    if (
        !$wp_settings_adaptive
        && yooadmin_studio_hub_is_plugin_admin_compat_screen()
        && !yooadmin_studio_hub_is_focus_enabled()
    ) {
        return;
    }

    if ($wp_settings_adaptive && !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }

    if (yooadmin_studio_hub_uses_classic_editor_static_dark_stack()) {
        return;
    }

    if (yooadmin_studio_hub_should_skip_heavy_plugin_admin_compat()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugin-admin-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $deps = ['yooadmin-studio-hub-late'];
    foreach (
        [
            'wp-admin',
            'common',
            'forms',
            'editor-buttons',
        ] as $handle
    ) {
        if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
            $deps[] = $handle;
        }
    }

    $deps = array_merge($deps, yooadmin_studio_hub_collect_plugin_admin_vendor_style_deps());

    foreach (['site-health', 'privacy', 'about'] as $core_handle) {
        if (wp_style_is($core_handle, 'registered') || wp_style_is($core_handle, 'enqueued')) {
            $deps[] = $core_handle;
        }
    }

    if ($wp_settings_adaptive && wp_style_is('yooadmin-wp-settings-experience', 'registered')) {
        $deps[] = 'yooadmin-wp-settings-experience';
    }

    $deps = yooadmin_studio_hub_resolve_style_deps(array_values(array_unique($deps)));
    if ([] === $deps) {
        return;
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-plugin-admin-dark',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugin-admin-dark.css'),
        $deps,
        (string) filemtime($file)
    );

    if (yooadmin_studio_hub_should_run_plugin_admin_adaptive()) {
        yooadmin_studio_hub_enqueue_plugin_admin_adaptive_assets();
    }
}

/**
 * Adaptive contrast / surface detection for third-party plugin admin (dark mode only).
 */
function yooadmin_studio_hub_enqueue_plugin_admin_adaptive_assets(): void {
    if (!yooadmin_studio_hub_should_run_plugin_admin_adaptive()) {
        return;
    }

    $css_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugin-admin-adaptive.css');
    $js_file  = yooadmin_studio_hub_asset_path('js/compat/studio-hub-plugin-admin-adaptive.js');
    if (!is_readable($css_file) || !is_readable($js_file)) {
        return;
    }

    $style_deps = ['yooadmin-studio-hub-plugin-admin-dark'];
    if (!wp_style_is('yooadmin-studio-hub-plugin-admin-dark', 'registered')) {
        $style_deps = ['yooadmin-studio-hub-late'];
        global $wp_styles;
        if ($wp_styles instanceof WP_Styles) {
            foreach ($wp_styles->queue as $handle) {
                if (!is_string($handle)) {
                    continue;
                }
                if (
                    preg_match('/trustindex|reviews-plugin|admin-page-settings/i', $handle)
                    || preg_match('/-(admin|backend)(?:-rtl)?$/i', $handle)
                ) {
                    $style_deps[] = $handle;
                }
            }
        }
        $style_deps = array_values(array_unique($style_deps));
    }

    $style_deps = yooadmin_studio_hub_resolve_style_deps($style_deps);
    if ([] === $style_deps) {
        return;
    }

    wp_enqueue_style(
        'yooadmin-studio-hub-plugin-admin-adaptive',
        yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugin-admin-adaptive.css'),
        $style_deps,
        (string) filemtime($css_file)
    );

    wp_enqueue_script(
        'yooadmin-studio-hub-plugin-admin-adaptive',
        yooadmin_studio_hub_asset_url('js/compat/studio-hub-plugin-admin-adaptive.js'),
        [],
        (string) filemtime($js_file),
        true
    );
}

/**
 * Handles for plugin/vendor admin CSS already enqueued on this screen (compat loads after them).
 *
 * @return string[]
 */
function yooadmin_studio_hub_collect_plugin_admin_vendor_style_deps(): array {
    global $wp_styles;

    if (!$wp_styles instanceof WP_Styles) {
        return [];
    }

    $skip = [
        'yooadmin-studio-hub-plugin-admin-dark' => true,
        'yooadmin-studio-hub-plugin-admin-adaptive' => true,
        'yooadmin-studio-hub-late' => true,
        'wp-admin' => true,
        'common' => true,
        'forms' => true,
        'editor-buttons' => true,
        'dashicons' => true,
    ];

    $deps = [];

    foreach ($wp_styles->queue as $handle) {
        if (!is_string($handle) || isset($skip[$handle])) {
            continue;
        }

        if (preg_match('/-(admin|backend)(?:-rtl)?$/i', $handle) || preg_match('/admin-style/i', $handle)) {
            $deps[] = $handle;
            continue;
        }

        $reg = $wp_styles->registered[$handle] ?? null;
        if ($reg && is_string($reg->src) && preg_match('#/wp-content/plugins/[^/]+/.+\.css#i', $reg->src)) {
            $deps[] = $handle;
        }
    }

    return array_values(array_unique($deps));
}

/**
 * Whether Dark Engine v2 owns plugin-admin dark styling (legacy vendor overrides must stay off).
 *
 * @return bool
 */
function yooadmin_studio_hub_v2_handles_plugin_admin_dark(): bool {
    return function_exists('yooadmin_dark_engine_should_run')
        && function_exists('yooadmin_dark_engine_context')
        && yooadmin_dark_engine_should_run()
        && 'plugin' === yooadmin_dark_engine_context();
}

/**
 * Generic first-paint overrides for plugin admin surfaces that ship light CSS.
 *
 * @return string
 */
function yooadmin_studio_hub_plugin_admin_vendor_surface_overrides_css(): string {
    $d  = 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)';
    $dh = 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]';
    $b  = 'body.yooadmin-theme-yooadmin-studio-hub.ysh-plugin-admin-compat';
    $host = $b . ' #wpbody-content :is([id$="-plugin-container"],[id*="plugin-container"],[class$="-app"],'
        . '[class*="admin-wrap"],[class*="admin-page"],[class*="admin-ui-page"],[class*="-admin-dashboard"],'
        . '[class*="-onboard-dashboard"],[class*="onboard"],[class*="Onboard"],[class*="setup"],[class*="Setup"],'
        . '[class*="wizard"],[class*="Wizard"])';
    $sweep = $b . ' #wpbody-content :is(main,section,article,aside,header,footer,.wrap,[role="main"],[role="region"],'
        . '[role="dialog"],[class*="container"],[class*="Container"],[class*="wrapper"],[class*="Wrapper"],'
        . '[class*="header"],[class*="Header"],[class*="footer"],[class*="Footer"],[class*="onboard"],[class*="Onboard"],'
        . '[class*="setup"],[class*="Setup"],[class*="wizard"],[class*="Wizard"],[class*="panel"],[class*="Panel"],'
        . '[class*="card"],[class*="Card"],[class*="box"],[class*="Box"],[class*="module"],[class*="Module"])'
        . ':not(.button):not(.button-primary):not(.button-secondary):not(.page-title-action):not(.notice-dismiss)'
        . ':not([class^="yp-"]):not([class*=" yp-"]):not([class^="yoo"]):not([class*=" yoo"])'
        . ':not([class*="yooadmin"]):not([id^="yp-"]):not([id^="yoo"])';
    $hard_sweep = $b . ' #wpbody-content :where(h1,h2,h3,h4,h5,h6,p,span,label,strong,small,b,em,i,li,td,th,dt,dd,legend,a,code,pre,kbd)'
        . ':not(svg):not(svg *):not(path):not(circle):not(rect):not(polygon):not(polyline):not(line):not(g)'
        . ':not(img):not(picture):not(video):not(canvas):not(iframe):not(object):not(embed)'
        . ':not(input):not(textarea):not(select):not(option):not(button)'
        . ':not(.button):not(.button-primary):not(.button-secondary):not(.page-title-action):not(.notice-dismiss)'
        . ':not(.dashicons):not(.screen-reader-text)'
        . ':not([class^="yp-"]):not([class*=" yp-"]):not([class^="yoo"]):not([class*=" yoo"])'
        . ':not([class*="yooadmin"]):not([id^="yp-"]):not([id^="yoo"])';
    $panels = ':is(.card,.welcome-panel,.notice:not(.yp-notification-item),.postbox,.stuffbox,fieldset,.inside,'
        . '[class*="panel"],[class*="Panel"],[class*="card"],[class*="Card"],[class*="settings"],[class*="Settings"],'
        . '[class*="section"],[class*="banner"],[class*="callout"],[class*="modal"],[class*="feature"],[class*="row"],[class*="list"],'
        . '[class*="header"],[class*="Header"],[class*="footer"],[class*="Footer"],[class*="container"],[class*="Container"],'
        . '[class*="wrapper"],[class*="Wrapper"],[class*="setup"],[class*="Setup"],[class*="wizard"],[class*="Wizard"],'
        . '.components-card,.components-panel__body)'
        . ':not([class^="yp-"]):not([class*=" yp-"]):not([class^="yoo"]):not([class*=" yoo"]):not([class*="yooadmin"]):not([id^="yp-"]):not([id^="yoo"])';

    return $d . ' ' . $host . ',' . $dh . ' ' . $host
        . '{background:transparent!important;background-color:transparent!important;color:#cfd6e0!important;}'
        . $d . ' ' . $hard_sweep . ',' . $dh . ' ' . $hard_sweep
        . '{border-color:rgba(255,255,255,.12)!important;'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:currentColor!important;}'
        . $d . ' ' . $sweep . ',' . $dh . ' ' . $sweep
        . '{background:#1a1d23!important;background-color:#1a1d23!important;'
        . 'border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;color-scheme:dark!important;}'
        . $d . ' ' . $host . ' ' . $panels . ',' . $dh . ' ' . $host . ' ' . $panels
        . '{background:var(--ysh-card,#1a1d23)!important;background-color:var(--ysh-card,#1a1d23)!important;'
        . 'border-color:rgba(255,255,255,.12)!important;box-shadow:none!important;color:#cfd6e0!important;}'
        . $d . ' ' . $host . ' ' . $panels . ' :is(h1,h2,h3,h4,h5,h6,strong),'
        . $dh . ' ' . $host . ' ' . $panels . ' :is(h1,h2,h3,h4,h5,h6,strong){'
        . 'color:#eef1f5!important;-webkit-text-fill-color:#eef1f5!important;}'
        . $d . ' ' . $host . ' ' . $panels . ' :is(p,span,label,li,small),'
        . $dh . ' ' . $host . ' ' . $panels . ' :is(p,span,label,li,small){'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $d . ' ' . $host . ' ' . $panels . ' a:not(.button),'
        . $dh . ' ' . $host . ' ' . $panels . ' a:not(.button){'
        . 'color:#eda934!important;-webkit-text-fill-color:#eda934!important;}'
        . yooadmin_studio_hub_yoast_portal_dark_css();
}

/**
 * Yoast SEO portaled surfaces (modals, introductions, toasts) — outside #wpbody-content.
 *
 * @return string
 */
function yooadmin_studio_hub_yoast_portal_dark_css(): string {
    $d  = 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)';
    $dh = 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]';
    $b  = 'body.yooadmin-theme-yooadmin-studio-hub.ysh-plugin-admin-compat';
    $yoast_surfaces = ':is('
        . '.yst-root,.yst-modal,.yst-modal__panel,.yst-modal__container,.yst-modal__overlay,'
        . '.yst-modal__close-button,.yst-introduction-modal,.yst-toast,.yst-notification,.yst-paper,'
        . '[class*="yst-modal" i],[class*="yst-toast" i],[class*="yst-notification" i]'
        . ')';
    $yoast_gradients = ':is('
        . '.yst-introduction-gradient,.yst-delayed-introduction-gradient,.yst-woo-introduction-gradient'
        . ')';
    $yoast_text = ':is('
        . '[class*="yst-text-slate" i],[class*="yst-text-gray" i],[class*="yst-text-neutral" i],'
        . '[class*="yst-text-black" i],[class*="text-slate" i],[class*="text-gray" i],'
        . '[class*="text-neutral" i],.yst-text-tiny'
        . ')';

    return $d . ' ' . $b . ' ' . $yoast_surfaces . ','
        . $dh . ' ' . $b . ' ' . $yoast_surfaces
        . '{background:#1a1d23!important;background-color:#1a1d23!important;'
        . 'border-color:rgba(255,255,255,.14)!important;color:#cfd6e0!important;'
        . '-webkit-text-fill-color:#cfd6e0!important;box-shadow:0 18px 48px rgba(0,0,0,.46)!important;color-scheme:dark!important;}'
        . $d . ' ' . $b . ' ' . $yoast_gradients . ','
        . $dh . ' ' . $b . ' ' . $yoast_gradients
        . '{background:#22262e!important;background-color:#22262e!important;background-image:none!important;}'
        . $d . ' ' . $b . ' .yst-modal__overlay,' . $dh . ' ' . $b . ' .yst-modal__overlay'
        . '{background:rgba(5,7,11,.72)!important;background-color:rgba(5,7,11,.72)!important;}'
        . $d . ' ' . $b . ' ' . $yoast_surfaces . ' ' . $yoast_text . ','
        . $dh . ' ' . $b . ' ' . $yoast_surfaces . ' ' . $yoast_text
        . '{color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' ' . $yoast_surfaces . ' :is(h1,h2,h3,h4,h5,h6,strong),'
        . $dh . ' ' . $b . ' ' . $yoast_surfaces . ' :is(h1,h2,h3,h4,h5,h6,strong)'
        . '{color:#eef1f5!important;-webkit-text-fill-color:#eef1f5!important;}';
}

/**
 * Body class for plugin-admin compat (critical CSS + adaptive scope).
 *
 * @param string $classes Space-separated classes.
 * @return string
 */
function yooadmin_studio_hub_filter_plugin_admin_compat_body_class(string $classes): string {
    if (function_exists('yooadmin_studio_hub_is_gutenberg_admin_request') && yooadmin_studio_hub_is_gutenberg_admin_request()) {
        return $classes;
    }
    if (!yooadmin_studio_hub_applies_plugin_admin_compat_body_class()) {
        return $classes;
    }

    $extra = ' ysh-plugin-admin-compat';
    if (yooadmin_studio_hub_is_plugin_check_admin_screen()) {
        $extra .= ' ysh-plugin-check-compat';
    }
    if (yooadmin_studio_hub_is_wp_core_admin_compat_screen()) {
        $extra .= ' ysh-wp-core-tools-compat';
    }
    if (yooadmin_studio_hub_is_bare_plugin_settings_admin_screen()) {
        $extra .= ' ysh-bare-plugin-settings';
    } elseif (function_exists('yooadmin_studio_hub_is_effective_dark_mode') && yooadmin_studio_hub_is_effective_dark_mode()) {
        if (!yooadmin_studio_hub_is_wp_core_admin_compat_screen()) {
            $extra .= ' ysh-adapt-wait';
        }
    }

    return trim($classes . $extra);
}

/**
 * Bare plugin settings (TrustIndex-style) — minimal head fixes; no adaptive stack.
 */
function yooadmin_studio_hub_print_bare_plugin_settings_compat(): void {
    if (!yooadmin_studio_hub_is_bare_plugin_settings_admin_screen()) {
        return;
    }

    $dark = function_exists('yooadmin_studio_hub_is_effective_dark_mode') && yooadmin_studio_hub_is_effective_dark_mode();

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS.
    echo '<style id="ysh-bare-plugin-settings-compat">'
        . 'body.ysh-bare-plugin-settings #wpbody-content > [class*="toggle-opacity"]{opacity:1!important;}'
        . 'body.ysh-bare-plugin-settings #wpbody-content > :is([id*="plugin-settings"],[id$="-settings-page"]){'
        . 'box-sizing:border-box;max-width:100%;width:100%;min-width:0;overflow-x:clip;}'
        . 'body.ysh-bare-plugin-settings #wpbody-content #ti-loading{position:fixed;inset:0;width:auto;height:auto;max-width:100vw;max-height:100vh;}';

    if ($dark) {
        echo 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)'
            . ' body.ysh-bare-plugin-settings.ysh-plugin-admin-compat{background:var(--ysh-surface,#12151a)!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)'
            . ' body.ysh-bare-plugin-settings.ysh-plugin-admin-compat :is(#wpcontent,#wpbody,#wpbody-content){'
            . 'background:var(--ysh-surface,#12151a)!important;background-color:var(--ysh-surface,#12151a)!important;}';
    }

    echo '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Generic dark surfaces for bare plugin-settings hosts (TrustIndex-style, no .wrap).
 * Loaded in footer so it wins vendor CSS; does not require adaptive JS.
 *
 * @return string
 */
function yooadmin_studio_hub_bare_plugin_settings_dark_surface_css(): string {
    $d     = 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)';
    $b     = 'body.ysh-bare-plugin-settings.ysh-plugin-admin-compat';
    $host  = '#wpbody-content > :is([id*="plugin-settings"],[id$="-settings-page"])';
    $hdesc = $host . ',#wpbody-content [id*="plugin-settings"],#wpbody-content [id$="-settings-page"]';
    $line  = 'rgba(255,255,255,.1)';
    $card  = 'var(--ysh-card,#1a1d23)';
    $panels = ':is('
        . '[class*="-box"],[class*="preview-box"],[class*="step-list"],[class*="-source-box"],'
        . '[class*="-rate-us"],[class*="-connect-platform"],[class*="highlight-content"],'
        . '[class*="button-dropdown"],[class*="promobox"],[class*="-modal-content"],'
        . '[class*="-special-offer"],[class*="upgrade-notice"],[class*="-notice"],'
        . '[class*="left-block"],[class*="right-block"],[class*="full-width"],[class*="half-width"]'
        . ')';

    $css  = $d . ' ' . $b . ','
        . $d . ' ' . $b . ' :is(#wpcontent,#wpbody,#wpbody-content){'
        . 'background:var(--ysh-surface,#12151a)!important;background-color:var(--ysh-surface,#12151a)!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . '{'
        . 'background:transparent!important;background-color:transparent!important;color:var(--ysh-text,#cfd6e0)!important;}'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-box,'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-step-list,'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-preview-box,'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-preview-boxes,'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-source-box,'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-connect-platform,'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-highlight-content,'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-button-dropdown,'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-notice,'
        . $d . ' ' . $b . ' #trustindex-plugin-settings-page .ti-rate-us-box{'
        . 'background:' . $card . '!important;background-color:' . $card . '!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' ' . $panels . '{'
        . 'background:' . $card . '!important;background-color:' . $card . '!important;'
        . 'box-shadow:none!important;color:var(--ysh-text,#cfd6e0)!important;color-scheme:dark;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="preview-box"][data-set-id],'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="preview-boxes"][data-set-id]{'
        . 'background:' . $card . '!important;background-color:' . $card . '!important;}'
        /* Subtle separators only on main panels (no heavy frames) */
        . $d . ' ' . $b . ' ' . $hdesc . ' :is([class*="-box"],[class*="step-list"],[class*="-source-box"],[class*="preview-boxes"]){'
        . 'outline:1px solid ' . $line . '!important;outline-offset:-1px;border-color:' . $line . '!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="-box-header"]{'
        . 'border-bottom:1px solid ' . $line . '!important;color:var(--ysh-heading,#eef1f5)!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="-box-footer"]{'
        . 'border-top:1px solid ' . $line . '!important;}'
        /* Tab bar — flat, no boxed tabs */
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="header-nav"]{'
        . 'background:var(--ysh-elevated,#181c22)!important;border-bottom:1px solid ' . $line . '!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="header-nav"] [class*="-nav-item"]{'
        . 'color:var(--ysh-muted,#9aa3b2)!important;background:transparent!important;'
        . 'border:none!important;box-shadow:none!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="header-nav"] [class*="-nav-item"]:hover{'
        . 'color:var(--ysh-heading,#eef1f5)!important;background:rgba(255,255,255,.05)!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="header-nav"] [class*="-nav-item"][class*="active"],'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="header-nav"] [class*="-nav-item"][class*="active"]:first-child{'
        . 'color:var(--ysh-heading,#eef1f5)!important;background:' . $card . '!important;'
        . 'border:none!important;border-radius:8px 8px 0 0!important;margin-left:0!important;}'
        /* Step bar */
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="step-list"]{box-shadow:none!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="step-list"] li{color:var(--ysh-muted,#9aa3b2)!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="step-list"] li:is([class*="active"],[class*="done"],[class*="current"]){'
        . 'color:var(--ysh-heading,#eef1f5)!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="step-list"] li span{background:var(--ysh-muted,#6b7280)!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="step-list"] li[class*="active"] span{background:var(--ysh-heading,#eef1f5)!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' [class*="step-list"] li[class*="done"] span{background:#1a976a!important;}'
        /* Typography */
        . $d . ' ' . $b . ' ' . $hdesc . ' :is([class*="header-title"],[class*="section-title"],h1,h2,h3){'
        . 'color:var(--ysh-heading,#eef1f5)!important;-webkit-text-fill-color:currentColor!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' :is(p,label,li,small,[class*="info-text"],[class*="lead"]){'
        . 'color:var(--ysh-text,#cfd6e0)!important;-webkit-text-fill-color:currentColor!important;}'
        . $d . ' ' . $b . ' ' . $hdesc . ' :is([class*="form-control"],[class*="shortcode"],input:not([type="checkbox"]):not([type="radio"]),textarea,select){'
        . 'background:var(--ysh-field,#22262e)!important;border-color:' . $line . '!important;'
        . 'color:var(--ysh-text,#cfd6e0)!important;}';

    return $css;
}

/**
 * Bare plugin settings + dark — beat vendor body/canvas rules printed after admin_head.
 */
function yooadmin_studio_hub_print_bare_plugin_settings_dark_footer(): void {
    if (!yooadmin_studio_hub_is_bare_plugin_settings_admin_screen()) {
        return;
    }
    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return;
    }

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS.
    echo '<style id="ysh-bare-plugin-settings-dark-footer">'
        . yooadmin_studio_hub_bare_plugin_settings_dark_surface_css()
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Inline sync on theme toggle — runs in <head> before paint (adaptive.js may load later in footer).
 */
function yooadmin_studio_hub_plugin_admin_mode_sync_inline_js(): string {
    return '(function(){'
        . 'function peelLight(){'
        . 'var b=document.body;if(!b||b.className.indexOf("ysh-plugin-admin-compat")<0)return;'
        . 'document.querySelectorAll("[data-ysh-adapt-token-props],#wpbody-content [class$=\'-app\']").forEach(function(el){'
        . '(el.getAttribute("data-ysh-adapt-token-props")||"").split(",").forEach(function(p){p=p.trim();if(p)el.style.removeProperty(p);});'
        . 'el.removeAttribute("data-ysh-adapt-token-props");'
        . 'el.classList.remove("ysh-adapt-token-app","ysh-adaptive-active","ysh-adapt-react-css-only");'
        . 'el.style.removeProperty("background");el.style.removeProperty("background-color");'
        . 'el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");});'
        . 'b.classList.remove("ysh-adapt-wait","ysh-adapt-ready");'
        . 'var w=document.getElementById("wpbody-content");if(w)w.classList.remove("ysh-adaptive-active");}'
        . 'function sync(){'
        . 'if(typeof window.yshPluginAdminAdaptSyncMode==="function"){window.yshPluginAdminAdaptSyncMode();return;}'
        . 'if(document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")!=="dark")peelLight();}'
        . 'if(!window.__yshPluginAdaptModeQuickObs){'
        . 'window.__yshPluginAdaptModeQuickObs=new MutationObserver(sync);'
        . 'window.__yshPluginAdaptModeQuickObs.observe(document.documentElement,{attributes:true,attributeFilter:["data-yooadmin-studio-color-mode-effective"]});}'
        . 'document.addEventListener("ysh-studio-color-mode-changed",sync);'
        . '})();';
}

/**
 * Print mode-sync observer on all plugin-admin compat screens (light + dark).
 */
function yooadmin_studio_hub_print_plugin_admin_mode_sync_inline(): void {
    if (!yooadmin_studio_hub_applies_plugin_admin_compat_body_class()) {
        return;
    }

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme JS, no user input.
    echo '<script id="yooadmin-studio-hub-plugin-admin-mode-sync">'
        . yooadmin_studio_hub_plugin_admin_mode_sync_inline_js()
        . '</script>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Site Health / Privacy tools — first-paint accordion surfaces (beats site-health.css).
 *
 * @return string
 */
function yooadmin_studio_hub_plugin_admin_wp_core_tools_antiflash_css(): string {
    if (!yooadmin_studio_hub_is_wp_core_admin_compat_screen()) {
        return '';
    }

    $d  = 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)';
    $dh = 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]';
    $b  = 'body.yooadmin-theme-yooadmin-studio-hub.ysh-plugin-admin-compat.ysh-wp-core-tools-compat';

    $css = $d . ' ' . $b . ' :is(.health-check-accordion-trigger,.privacy-settings-accordion-trigger,.site-health-view-passed),'
        . $dh . ' ' . $b . ' :is(.health-check-accordion-trigger,.privacy-settings-accordion-trigger,.site-health-view-passed){'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' .health-check-accordion-trigger .title,' . $dh . ' ' . $b . ' .health-check-accordion-trigger .title{'
        . 'color:#e8ecf1!important;-webkit-text-fill-color:#e8ecf1!important;}'
        . $d . ' ' . $b . ' :is(.health-check-accordion-panel,.privacy-settings-accordion-panel),'
        . $dh . ' ' . $b . ' :is(.health-check-accordion-panel,.privacy-settings-accordion-panel){'
        . 'background:#22262e!important;background-color:#22262e!important;color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' .site-health-issue-count-title,' . $dh . ' ' . $b . ' .site-health-issue-count-title{'
        . 'color:#eef1f5!important;-webkit-text-fill-color:#eef1f5!important;}'
        . $d . ' ' . $b . ' .health-check-body,' . $dh . ' ' . $b . ' .health-check-body{'
        . 'color:#cfd6e0!important;}';

    $css .= $d . ' ' . $b . '.import-php .importers.widefat,' . $dh . ' ' . $b . '.import-php .importers.widefat{'
        . 'background:var(--ysh-card,#1a1d23)!important;border-color:rgba(255,255,255,.12)!important;}'
        . $d . ' ' . $b . '.import-php .importers :is(td,th),' . $dh . ' ' . $b . '.import-php .importers :is(td,th){'
        . 'border-color:rgba(255,255,255,.1)!important;color:var(--ysh-text,#cfd6e0)!important;}'
        . $d . ' ' . $b . '.import-php .importers.striped > tbody > :nth-child(odd),' . $dh . ' ' . $b . '.import-php .importers.striped > tbody > :nth-child(odd){'
        . 'background:rgba(255,255,255,.04)!important;}'
        . $d . ' ' . $b . '.import-php .importer-title,' . $dh . ' ' . $b . '.import-php .importer-title{'
        . 'color:var(--ysh-heading,#e8ecf1)!important;-webkit-text-fill-color:var(--ysh-heading,#e8ecf1)!important;}'
        . $d . ' ' . $b . '.import-php .importer-desc,' . $dh . ' ' . $b . '.import-php .importer-desc{'
        . 'color:var(--ysh-text-muted,#9ca3af)!important;-webkit-text-fill-color:var(--ysh-text-muted,#9ca3af)!important;}'
        . $d . ' ' . $b . '.import-php .importer-action a,' . $dh . ' ' . $b . '.import-php .importer-action a{'
        . 'color:var(--ysh-brand,#eda934)!important;-webkit-text-fill-color:var(--ysh-brand,#eda934)!important;}';

    $css .= $d . ' ' . $b . ' :is(.notification-dialog,.file-editor-warning .notification-dialog),'
        . $dh . ' ' . $b . ' :is(.notification-dialog,.file-editor-warning .notification-dialog){'
        . 'background:var(--ysh-card,#1a1d23)!important;background-color:var(--ysh-card,#1a1d23)!important;'
        . 'color:var(--ysh-text,#cfd6e0)!important;border:1px solid rgba(255,255,255,.14)!important;'
        . 'box-shadow:0 24px 64px rgba(0,0,0,.55)!important;}'
        . $d . ' ' . $b . ' .notification-dialog :is(h1,h2,h3,p,li,label),' . $dh . ' ' . $b . ' .notification-dialog :is(h1,h2,h3,p,li,label){'
        . 'color:var(--ysh-text,#cfd6e0)!important;-webkit-text-fill-color:var(--ysh-text,#cfd6e0)!important;}'
        . $d . ' ' . $b . ' .notification-dialog h1,' . $dh . ' ' . $b . ' .notification-dialog h1{'
        . 'color:var(--ysh-heading,#e8ecf1)!important;-webkit-text-fill-color:var(--ysh-heading,#e8ecf1)!important;}'
        . $d . ' ' . $b . ' .notification-dialog-background,' . $dh . ' ' . $b . ' .notification-dialog-background{'
        . 'background:rgba(0,0,0,.72)!important;opacity:1!important;}';

    $ab = $b . ':is(.about-php,.credits-php,.freedoms-php,.privacy-php,.contribute-php)';
    $css .= $d . ' ' . $ab . ','
        . $dh . ' ' . $ab . '{background:#0f1115!important;}'
        . $d . ' ' . $ab . ' #wpcontent,' . $dh . ' ' . $ab . ' #wpcontent{'
        . 'background:#0f1115!important;background-color:#0f1115!important;}'
        . $d . ' ' . $ab . ' .about__container,' . $dh . ' ' . $ab . ' .about__container{'
        . '--background:#1a1d23;--subtle-background:#22262e;--text:#e8ecf1;--text-light:#f8fafc;'
        . '--accent-1:#eda934;--nav-background:#1a1d23;--nav-border:rgba(255,255,255,.12);'
        . '--nav-color:#cfd6e0;--nav-current:#eda934;color:#e8ecf1!important;}'
        . $d . ' ' . $ab . ' .about__header-title h1,' . $dh . ' ' . $ab . ' .about__header-title h1{'
        . 'color:#f8fafc!important;-webkit-text-fill-color:#f8fafc!important;}'
        . $d . ' ' . $ab . ' .about__header-navigation,' . $dh . ' ' . $ab . ' .about__header-navigation{'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;'
        . 'border-bottom-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;}'
        . $d . ' ' . $ab . ' .about__header-navigation .nav-tab,' . $dh . ' ' . $ab . ' .about__header-navigation .nav-tab{'
        . 'background:transparent!important;color:#cfd6e0!important;'
        . '-webkit-text-fill-color:#cfd6e0!important;border-color:transparent!important;}'
        . $d . ' ' . $ab . ' .about__header-navigation .nav-tab-active,'
        . $dh . ' ' . $ab . ' .about__header-navigation .nav-tab-active{'
        . 'color:#f8fafc!important;-webkit-text-fill-color:#f8fafc!important;'
        . 'border-bottom-color:#eda934!important;}';

    global $pagenow;

    if (isset($pagenow) && in_array($pagenow, ['plugin-editor.php', 'theme-editor.php'], true)) {
        $fe = 'body.yooadmin-theme-yooadmin-studio-hub.ysh-plugin-admin-compat.ysh-wp-core-tools-compat:is(.plugin-editor-php,.theme-editor-php)';
        $css .= $d . ' ' . $fe . ' #newcontent,' . $dh . ' ' . $fe . ' #newcontent{'
            . 'background:#1e2228!important;color:#cfd6e0!important;}'
            . $d . ' ' . $fe . ' #templateside,' . $dh . ' ' . $fe . ' #templateside{'
            . 'background:#1a1d23!important;border:1px solid rgba(255,255,255,.12)!important;}'
            . $d . ' ' . $fe . ' #templateside>ul,' . $dh . ' ' . $fe . ' #templateside>ul{'
            . 'background:#1a1d23!important;background-color:#1a1d23!important;'
            . 'border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;}'
            . $d . ' ' . $fe . ' #templateside .folder-label,' . $dh . ' ' . $fe . ' #templateside .folder-label{'
            . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
            . $d . ' ' . $fe . ' #templateside li:not(.howto) a,' . $dh . ' ' . $fe . ' #templateside li:not(.howto) a{'
            . 'color:#9ca3af!important;-webkit-text-fill-color:#9ca3af!important;}'
            . $d . ' ' . $fe . ' #templateside li.current-file>a,' . $dh . ' ' . $fe . ' #templateside li.current-file>a,'
            . $d . ' ' . $fe . ' #templateside .highlight,' . $dh . ' ' . $fe . ' #templateside .highlight{'
            . 'color:#eda934!important;-webkit-text-fill-color:#eda934!important;}';
    }

    return $css;
}

/**
 * First-paint dark rules for third-party plugin admin (before plugin CSS + adaptive JS).
 *
 * @return string
 */
function yooadmin_studio_hub_plugin_admin_adaptive_antiflash_css(): string {
    $d = 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)';
    $dh = 'html.yooadmin-studio-hub-html[data-yooadmin-studio-color-mode-effective="dark"]';
    $b = 'body.yooadmin-theme-yooadmin-studio-hub.ysh-plugin-admin-compat';
    $native_wrap = ':not(.yooadmin-posts-page):not(.yooadmin-pages-page):not(.yooadmin-plugins-page):not(.yooadmin-media-page)'
        . ':not(.yooadmin-users-page):not(.yooadmin-tags-page):not(.yooadmin-categories-page):not(.yooadmin-extensions-page)'
        . ':not(.yooadmin-extensions-manager):not(.yooadmin-plugin-install-page):not(.yooadmin-settings-wrap)';
    $wrap = $b . ' #wpbody-content > .wrap' . $native_wrap;
    $react = $b . ' #wpbody-content [class*="-admin-dashboard"],' . $b . ' #wpbody-content [class*="-onboard-dashboard"]';
    $reactPanels = $b . ' #wpbody-content [class*="-admin-dashboard"] :is('
        . '[class*="__header"],[class*="__welcome"],[class*="__welcome__content"],[class*="__welcome__content-subscribe"],'
        . '[class*="__welcome__content-video"],[class*="__content-subscribe"],[class*="__content-video"],'
        . '[class*="__cards-item"],[class*="__blocks-list__item"],[class*="__settings-list"],[class*="__settings-content"],[class*="__section"],'
        . '.components-card,.components-panel__body'
        . '),'
        . $dh . ' #wpbody-content [class*="-admin-dashboard"] :is('
        . '[class*="__header"],[class*="__welcome"],[class*="__welcome__content"],[class*="__welcome__content-subscribe"],'
        . '[class*="__welcome__content-video"],[class*="__content-subscribe"],[class*="__content-video"],'
        . '[class*="__cards-item"],[class*="__blocks-list__item"],[class*="__settings-list"],[class*="__settings-content"],[class*="__section"],'
        . '.components-card,.components-panel__body'
        . ')';

    $vendor_surfaces = yooadmin_studio_hub_v2_handles_plugin_admin_dark()
        ? ''
        : yooadmin_studio_hub_plugin_admin_vendor_surface_overrides_css();

    return yooadmin_studio_hub_plugin_admin_wp_core_tools_antiflash_css()
        . $vendor_surfaces
        . $d . ' ' . $b . ' :is(#wpcontent,#wpbody){background:#12151a!important;background-color:#12151a!important;}'
        . $d . ' ' . $b . ' #wpbody-content{background:#12151a!important;background-color:#12151a!important;}'
        . $d . ' ' . $b . ' #wpbody-content > :not(.wrap):is([id],[class]){'
        . 'max-width:var(--ysh-layout-max,1400px)!important;width:100%!important;'
        . 'margin:20px auto 40px!important;padding:25px 16px 80px!important;box-sizing:border-box!important;'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;'
        . 'border:none!important;box-shadow:0 12px 40px rgba(0,0,0,.28)!important;color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' #wpbody-content > :not(.wrap) :is('
        . '[class*="masthead"],[class*="header"],[class*="hero"],[class*="setup"],[class*="card"],[class*="panel"],[class*="box"]'
        . '){background-color:transparent!important;}'
        . $d . ' ' . $b . ' #wpbody-content > :not(.wrap) :is('
        . 'input:not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]):not([type="hidden"]),textarea,select'
        . '){background:#22262e!important;border-color:rgba(255,255,255,.14)!important;'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;color-scheme:dark!important;}'
        . $d . ' ' . $react . ',' . $dh . ' ' . $react . '{background:transparent!important;background-color:transparent!important;color:#cfd6e0!important;}'
        . $d . ' ' . $reactPanels . ',' . $dh . ' ' . $reactPanels
        . '{background:#1a1d23!important;background-color:#1a1d23!important;border-color:rgba(255,255,255,.12)!important;}'
        . $d . ' ' . $react . ' a:not(.button):not(.nav-tab),' . $dh . ' ' . $react . ' a:not(.button):not(.nav-tab){'
        . 'color:#eda934!important;-webkit-text-fill-color:#eda934!important;}'
        . $d . ' ' . $wrap . ','
        . $dh . ' ' . $wrap . '{'
        . 'max-width:var(--ysh-layout-max,1400px)!important;width:100%!important;'
        . 'margin:20px auto 40px!important;padding:25px 16px 80px!important;box-sizing:border-box!important;'
        . 'background:#1a1d23!important;background-color:#1a1d23!important;'
        . 'border:none!important;box-shadow:0 12px 40px rgba(0,0,0,.28)!important;'
        . 'color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' #wpbody-content > .wrap :is('
        . '.card,.welcome-panel,'
        . '.notice:not(.yp-notification-item),.postbox,.stuffbox,fieldset,.inside,'
        . '[class*="panel"],[class*="card"],[class*="settings"],[class*="Settings"],'
        . '[class*="__cards-item"],[class*="__blocks-list__item"],[class*="__settings-list"],[class*="__settings-content"]'
        . '),'
        . $dh . ' ' . $b . ' #wpbody-content > .wrap :is('
        . '.card,.welcome-panel,'
        . '.notice:not(.yp-notification-item),.postbox,.stuffbox,fieldset,.inside,'
        . '[class*="panel"],[class*="card"],[class*="settings"],[class*="Settings"],'
        . '[class*="__cards-item"],[class*="__blocks-list__item"],[class*="__settings-list"],[class*="__settings-content"]'
        . '){background:#1a1d23!important;background-color:#1a1d23!important;'
        . 'border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;}'
        . $d . ' ' . $wrap . ' a:not(.button):not(.button-primary):not(.button-secondary):not(.nav-tab):not(.yoo-filter-chip):not(.yoo-filter-btn):not(.yp-yoo-btn),'
        . $dh . ' ' . $wrap . ' a:not(.button):not(.button-primary):not(.button-secondary):not(.nav-tab):not(.yoo-filter-chip):not(.yoo-filter-btn):not(.yp-yoo-btn){'
        . 'color:#eda934!important;-webkit-text-fill-color:#eda934!important;}'
        . $d . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is('
        . 'input[type="text"],input[type="number"],input[type="search"],input[type="email"],input[type="url"],textarea,select,'
        . '[class*="-text-input"],[class*="-number-input"],[class*="-textarea"],'
        . '.wp-picker-container .wp-color-result,.wp-picker-input-wrap input[type="text"]'
        . '),'
        . $dh . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is('
        . 'input[type="text"],input[type="number"],input[type="search"],input[type="email"],input[type="url"],textarea,select,'
        . '[class*="-text-input"],[class*="-number-input"],[class*="-textarea"],'
        . '.wp-picker-container .wp-color-result,.wp-picker-input-wrap input[type="text"]'
        . '){background:#22262e!important;background-color:#22262e!important;'
        . 'border-color:rgba(255,255,255,.14)!important;color:#cfd6e0!important;'
        . '-webkit-text-fill-color:#cfd6e0!important;box-shadow:none!important;color-scheme:dark!important;}'
        . $d . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' .wp-picker-container .wp-color-result-text,'
        . $dh . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' .wp-picker-container .wp-color-result-text{'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is(h1,h2,h3,h4,h5,h6,strong),'
        . $dh . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is(h1,h2,h3,h4,h5,h6,strong){'
        . 'color:#eef1f5!important;-webkit-text-fill-color:#eef1f5!important;}'
        . $d . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is(p,span,label,li,small),'
        . $dh . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is(p,span,label,li,small){'
        . 'color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' [class*="-card-header"],'
        . $dh . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' [class*="-card-header"]{'
        . 'background:rgba(255,255,255,.04)!important;border-bottom-color:rgba(255,255,255,.12)!important;}'
        . $d . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is('
        . '[class*="-page-item"]:hover,[class*="-page-item"].selected,[class*="-page-item"].active,[class*="-page-item"].is-selected,[class*="-radio-item"]:hover'
        . '),'
        . $dh . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is('
        . '[class*="-page-item"]:hover,[class*="-page-item"].selected,[class*="-page-item"].active,[class*="-page-item"].is-selected,[class*="-radio-item"]:hover'
        . '){background:rgba(255,255,255,.07)!important;color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is([class*="-page-item"].selected,[class*="-page-item"].active,[class*="-page-item"].is-selected),'
        . $dh . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is([class*="-page-item"].selected,[class*="-page-item"].active,[class*="-page-item"].is-selected){'
        . 'background:rgba(237,169,52,.14)!important;}'
        . $d . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is('
        . '[class*="-page-item"]:hover,[class*="-page-item"].selected,[class*="-page-item"].active,[class*="-page-item"].is-selected'
        . ') :is(span,[class*="-title"],[class*="-id"]),'
        . $dh . ' ' . $b . ' #wpbody-content > .wrap' . $native_wrap . ' :is('
        . '[class*="-page-item"]:hover,[class*="-page-item"].selected,[class*="-page-item"].active,[class*="-page-item"].is-selected'
        . ') :is(span,[class*="-title"],[class*="-id"]){color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' #wpbody-content [class$="-app"] :is([class*="-settings-section"],[class*="-pro-teaser"]),'
        . $dh . ' ' . $b . ' #wpbody-content [class$="-app"] :is([class*="-settings-section"],[class*="-pro-teaser"]){'
        . 'background:#1a1d23!important;border-color:rgba(255,255,255,.12)!important;color:#cfd6e0!important;}'
        . $d . ' ' . $b . ' #wpbody-content [class$="-app"] :is([class*="-input"],input[type="text"],input[type="number"],textarea,select),'
        . $dh . ' ' . $b . ' #wpbody-content [class$="-app"] :is([class*="-input"],input[type="text"],input[type="number"],textarea,select){'
        . 'background:#22262e!important;border-color:rgba(255,255,255,.14)!important;color:#eef1f5!important;}'
        . $d . ' ' . $b . ' #wpbody-content [class$="-app"] :is(h1,h2,h3,h4,h5,h6),'
        . $dh . ' ' . $b . ' #wpbody-content [class$="-app"] :is(h1,h2,h3,h4,h5,h6){'
        . 'color:#eef1f5!important;-webkit-text-fill-color:#eef1f5!important;}';
}

/**
 * Prime .ysh-adaptive-active on .wrap before adaptive.js (reduces pre-JS paint flash).
 */
function yooadmin_studio_hub_print_plugin_admin_adapt_boot_inline(): void {
    if (!yooadmin_studio_hub_should_run_plugin_admin_adaptive()) {
        return;
    }
    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-plugin-admin-adapt-boot">'
        . '(function(){'
        . 'function yshPrimePluginShell(){'
        . 'var wp=document.getElementById("wpbody-content");if(!wp)return null;'
        . 'var w=wp.querySelector(":scope > .wrap");'
        . 'if(w)return w;'
        . 'return wp.querySelector(":scope > [id*=\'plugin-settings\'],:scope > [id$=\'-settings-page\'],:scope > [id*=\'form-container\'],:scope > [id*=\'page-container\']");}'
        . 'var b=document.body,s=yshPrimePluginShell();'
        . 'if(!b||b.className.indexOf("ysh-plugin-admin-compat")<0)return;'
        . 'if(s)s.classList.add("ysh-adaptive-active");'
        . 'document.querySelectorAll("#wpbody-content [class$=\'-app\'][data-screen]").forEach(function(a){'
        . 'if(!/yooadmin|yp-studio|yp-inbox/i.test(a.className||""))a.classList.add("ysh-adaptive-active");});'
        . '})();'
        . '</script>' . "\n";
}

/**
 * Critical CSS in <head> — Studio Hub column + dark surfaces on first paint.
 */
function yooadmin_studio_hub_print_plugin_admin_adaptive_critical(): void {
    if (!yooadmin_studio_hub_applies_plugin_admin_compat_body_class()) {
        return;
    }

    yooadmin_studio_hub_print_plugin_admin_mode_sync_inline();

    if (
        yooadmin_studio_hub_should_skip_plugin_admin_adaptive()
        || yooadmin_studio_hub_uses_classic_editor_static_dark_stack()
    ) {
        return;
    }

    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return;
    }

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS, no user input.
    echo '<style id="yooadmin-studio-hub-plugin-admin-adaptive-critical">'
        . yooadmin_studio_hub_plugin_admin_adaptive_antiflash_css()
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped

    if (yooadmin_studio_hub_is_wp_core_admin_compat_screen()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-plugin-admin-adapt-prime">'
        . '(function(){'
        . 'function yshPrimePluginShell(){'
        . 'var wp=document.getElementById("wpbody-content");if(!wp)return null;'
        . 'var w=wp.querySelector(":scope > .wrap");'
        . 'if(w)return w;'
        . 'return wp.querySelector(":scope > [id*=\'plugin-settings\'],:scope > [id$=\'-settings-page\'],:scope > [id*=\'form-container\'],:scope > [id*=\'page-container\']");}'
        . 'function prime(){var b=document.body,s=yshPrimePluginShell();'
        . 'if(!b||b.className.indexOf("ysh-plugin-admin-compat")<0)return false;'
        . 'if(s)s.classList.add("ysh-adaptive-active");'
        . 'document.querySelectorAll("#wpbody-content [class$=\'-app\'][data-screen],'
        . '#wpbody-content > .wrap > [class$=\'-app\'],#wpbody-content > .wrap > [class*=\'admin-wrap\']")'
        . '.forEach(function(a){if(!/yooadmin|yp-studio|yp-inbox/i.test(a.className||""))a.classList.add("ysh-adaptive-active");});'
        . 'return !!s;}'
        . 'if(prime())return;'
        . 'var obs=new MutationObserver(function(){if(prime())obs.disconnect();});'
        . 'var wp=document.getElementById("wpbody-content");'
        . 'if(wp){obs.observe(wp,{childList:true,subtree:false});}'
        . 'else{obs.observe(document.documentElement,{childList:true,subtree:false});}'
        . 'setTimeout(function(){obs.disconnect();},8000);'
        . '})();'
        . '</script>' . "\n";

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugin-admin-adaptive.css');
    if (is_readable($file)) {
        $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugin-admin-adaptive.css');
        $ver = (string) filemtime($file);
        // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Early paint before footer vendor CSS.
        printf(
            '<link rel="stylesheet" id="yooadmin-studio-hub-plugin-admin-adaptive-early" href="%s" />' . "\n",
            esc_url(add_query_arg('ver', $ver, $url))
        );
        // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
    }
}

/**
 * Footer inline overrides — beats vendor React CSS printed in head/footer.
 */
function yooadmin_studio_hub_print_plugin_admin_vendor_surface_overrides(): void {
    if (!yooadmin_studio_hub_is_plugin_admin_compat_screen()) {
        return;
    }
    if (yooadmin_studio_hub_v2_handles_plugin_admin_dark()) {
        return;
    }
    if (
        yooadmin_studio_hub_should_skip_heavy_plugin_admin_compat()
        || yooadmin_studio_hub_uses_classic_editor_static_dark_stack()
    ) {
        return;
    }
    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return;
    }

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS, no user input.
    echo '<style id="yooadmin-studio-hub-plugin-admin-vendor-surfaces">'
        . yooadmin_studio_hub_plugin_admin_vendor_surface_overrides_css()
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Footer cascade — adaptive CSS after vendor + compat dark (paired with adaptive JS).
 */
function yooadmin_studio_hub_print_plugin_admin_adaptive_cascade_tail(): void {
    if (!yooadmin_studio_hub_is_plugin_admin_compat_screen()) {
        return;
    }
    if (yooadmin_studio_hub_v2_handles_plugin_admin_dark()) {
        return;
    }
    if (
        yooadmin_studio_hub_should_skip_heavy_plugin_admin_compat()
        || yooadmin_studio_hub_uses_classic_editor_static_dark_stack()
    ) {
        return;
    }
    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugin-admin-adaptive.css');
    if (!is_readable($file)) {
        return;
    }

    $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugin-admin-adaptive.css');
    $ver = (string) filemtime($file);
    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Late cascade after plugin + compat CSS.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-plugin-admin-adaptive-cascade-tail" href="%s" />' . "\n",
        esc_url(add_query_arg('ver', $ver, $url))
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

/**
 * Re-link compat CSS late in <head> (beats plugin styles without !important wars).
 */
function yooadmin_studio_hub_print_plugin_admin_dark_cascade_tail(): void {
    if (!yooadmin_studio_hub_is_plugin_admin_compat_screen() && !yooadmin_studio_hub_is_plugin_check_admin_screen()) {
        return;
    }
    if (yooadmin_studio_hub_v2_handles_plugin_admin_dark()) {
        return;
    }
    if (
        yooadmin_studio_hub_should_skip_heavy_plugin_admin_compat()
        || yooadmin_studio_hub_uses_classic_editor_static_dark_stack()
    ) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugin-admin-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugin-admin-dark.css');
    $ver = (string) filemtime($file);
    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Late cascade tail must load after wp-admin/plugin CSS in <head>.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-plugin-admin-cascade-tail" href="%s" />' . "\n",
        esc_url(add_query_arg('ver', $ver, $url))
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

/**
 * Footer dark rules — beats styles printed late in <head>.
 */
function yooadmin_studio_hub_print_plugin_admin_dark_footer(): void {
    if (!yooadmin_studio_hub_is_plugin_admin_compat_screen() && !yooadmin_studio_hub_is_plugin_check_admin_screen()) {
        return;
    }
    if (yooadmin_studio_hub_v2_handles_plugin_admin_dark()) {
        return;
    }
    if (
        yooadmin_studio_hub_should_skip_heavy_plugin_admin_compat()
        || yooadmin_studio_hub_uses_classic_editor_static_dark_stack()
    ) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-plugin-admin-dark.css');
    if (!is_readable($file)) {
        return;
    }

    $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-plugin-admin-dark.css');
    $ver = (string) filemtime($file);
    // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Footer cascade beats late plugin CSS.
    printf(
        '<link rel="stylesheet" id="yooadmin-studio-hub-plugin-admin-footer-dark" href="%s" />' . "\n",
        esc_url(add_query_arg('ver', $ver, $url))
    );
    // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
}

/**
 * Plugin Check tool (Tools → Plugin Check).
 *
 * @return bool
 */
function yooadmin_studio_hub_is_plugin_check_admin_screen(): bool {
    global $pagenow;

    if (!isset($pagenow) || 'tools.php' !== $pagenow) {
        return false;
    }

    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';
    // phpcs:enable WordPress.Security.NonceVerification.Recommended

    return 'plugin-check' === $page;
}

/**
 * Plugin Check AJAX results table — dark surfaces (no .wrap / theme-class requirement).
 *
 * @return string
 */
function yooadmin_studio_hub_plugin_check_results_dark_css(): string {
    $d = 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)';
    // Tools → Plugin Check uses yoo-wp-settings-experience, not ysh-plugin-admin-compat.
    $b = 'body.wp-admin.yoo-wp-settings-experience';
    $scope = $b . ' #plugin-check__results table.plugin-check__results-table';
    $card = 'var(--ysh-card,#1a1d23)';
    $text = 'var(--ysh-text,#cfd6e0)';
    $line = 'rgba(255,255,255,.1)';

    return $d . ' ' . $scope
        . '{background:' . $card . '!important;background-color:' . $card . '!important;'
        . 'border:1px solid rgba(255,255,255,.12)!important;color:' . $text . '!important;}'
        . $d . ' ' . $scope . ' thead :is(th,td){'
        . 'background:var(--ysh-card-raised,#22262e)!important;background-color:var(--ysh-card-raised,#22262e)!important;'
        . 'color:var(--ysh-muted,#c2ccd6)!important;-webkit-text-fill-color:var(--ysh-muted,#c2ccd6)!important;'
        . 'border-color:' . $line . '!important;}'
        . $d . ' ' . $scope . ' tbody > tr{background:transparent!important;background-color:transparent!important;}'
        . $d . ' ' . $scope . ' tbody > tr > :is(th,td){'
        . 'background:rgba(255,255,255,.03)!important;background-color:rgba(255,255,255,.03)!important;'
        . 'border-color:' . $line . '!important;color:' . $text . '!important;-webkit-text-fill-color:' . $text . '!important;}'
        . $d . ' ' . $scope . '.striped > tbody > :nth-child(odd),'
        . $d . ' ' . $scope . '.striped > tbody > :nth-child(odd) > :is(th,td){'
        . 'background:rgba(255,255,255,.06)!important;background-color:rgba(255,255,255,.06)!important;}'
        . $d . ' ' . $scope . '.striped > tbody > :nth-child(even),'
        . $d . ' ' . $scope . '.striped > tbody > :nth-child(even) > :is(th,td){'
        . 'background:rgba(255,255,255,.02)!important;background-color:rgba(255,255,255,.02)!important;}'
        . $d . ' ' . $scope . ' a:not(.button){'
        . 'color:var(--ysh-brand,#eda934)!important;-webkit-text-fill-color:var(--ysh-brand,#eda934)!important;}';
}

/**
 * Plugin Check — first-paint dark table rules in head.
 */
function yooadmin_studio_hub_print_plugin_check_results_dark_head(): void {
    if (!yooadmin_studio_hub_is_plugin_check_admin_screen()) {
        return;
    }
    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return;
    }

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS.
    echo '<style id="ysh-plugin-check-results-dark-head">'
        . yooadmin_studio_hub_plugin_check_results_dark_css()
        . '</style>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Plugin Check — footer CSS + strip adaptive marks from AJAX-injected results tables.
 */
function yooadmin_studio_hub_print_plugin_check_results_dark_footer(): void {
    if (!yooadmin_studio_hub_is_plugin_check_admin_screen()) {
        return;
    }
    if (!function_exists('yooadmin_studio_hub_is_effective_dark_mode') || !yooadmin_studio_hub_is_effective_dark_mode()) {
        return;
    }

    // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS/JS.
    echo '<style id="ysh-plugin-check-results-dark-footer">'
        . yooadmin_studio_hub_plugin_check_results_dark_css()
        . '</style>' . "\n";
    echo '<script id="ysh-plugin-check-results-dark-watch">'
        . '(function(){'
        . 'function isDark(){return document.documentElement.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark";}'
        . 'function cleanTable(table){'
        . 'if(!table)return;'
        . 'table.querySelectorAll("[data-ysh-adapt],[data-ysh-adapt-text],[data-ysh-adapt-btn],[data-ysh-adapt-icon]").forEach(function(el){'
        . 'el.removeAttribute("data-ysh-adapt");el.removeAttribute("data-ysh-adapt-text");'
        . 'el.removeAttribute("data-ysh-adapt-btn");el.removeAttribute("data-ysh-adapt-icon");'
        . 'el.classList.remove("ysh-adapt-light-bg","ysh-adapt-light-nested","ysh-adapt-hoverable");'
        . 'el.style.removeProperty("background");el.style.removeProperty("background-color");'
        . 'el.style.removeProperty("color");el.style.removeProperty("-webkit-text-fill-color");});'
        . 'table.querySelectorAll("thead :is(th,td),tbody :is(th,td)").forEach(function(cell){'
        . 'cell.removeAttribute("data-ysh-adapt-text");'
        . 'cell.style.removeProperty("background");cell.style.removeProperty("background-color");'
        . 'cell.style.removeProperty("color");cell.style.removeProperty("-webkit-text-fill-color");});'
        . 'table.querySelectorAll("tbody > tr").forEach(function(row){'
        . 'row.style.removeProperty("background");row.style.removeProperty("background-color");});}'
        . 'function clean(){'
        . 'if(!isDark())return;'
        . 'var root=document.getElementById("plugin-check__results");if(!root)return;'
        . 'root.querySelectorAll("table.plugin-check__results-table,table.widefat.striped:not(.wp-list-table)")'
        . '.forEach(cleanTable);}'
        . 'function watch(){'
        . 'var root=document.getElementById("plugin-check__results");if(!root)return;'
        . 'clean();'
        . 'if(root.__yshPluginCheckObs||typeof MutationObserver==="undefined")return;'
        . 'root.__yshPluginCheckObs=new MutationObserver(function(){clean();});'
        . 'root.__yshPluginCheckObs.observe(root,{childList:true,subtree:true});}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",watch);}'
        . 'else{watch();}'
        . 'document.addEventListener("ysh-studio-color-mode-changed",clean);'
        . '})();'
        . '</script>' . "\n";
    // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Classic editor screens (post.php / post-new.php, not block editor).
 *
 * @return bool
 */
function yooadmin_studio_hub_is_classic_editor_compat_screen(): bool {
    if (!yooadmin_studio_hub_is_plugin_admin_compat_screen()) {
        return false;
    }

    global $pagenow;
    if (!isset($pagenow) || !in_array($pagenow, ['post.php', 'post-new.php'], true)) {
        return false;
    }

    if (function_exists('get_current_screen')) {
        $screen = get_current_screen();
        if ($screen && $screen->is_block_editor()) {
            return false;
        }
    }

    return true;
}

/**
 * Classic editor uses a slim static dark stack (no full plugin-admin-dark / adaptive head).
 *
 * @return bool
 */
function yooadmin_studio_hub_uses_classic_editor_static_dark_stack(): bool {
    return yooadmin_studio_hub_is_classic_editor_compat_screen();
}

/**
 * TinyMCE iframe — dark content area on classic post/page editor.
 *
 * @param array<string, mixed> $init Editor init.
 * @return array<string, mixed>
 */
function yooadmin_studio_hub_filter_classic_editor_tinymce_dark(array $init): array {
    if (!yooadmin_studio_hub_classic_editor_dark_compat_wanted()) {
        return $init;
    }

    if (function_exists('yooadmin_studio_hub_is_product_editor_screen') && yooadmin_studio_hub_is_product_editor_screen()) {
        return $init;
    }

    $content_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-tinymce-dark-content.css');
    if (is_readable($content_file)) {
        $content_url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-tinymce-dark-content.css');
        $content_url .= '?ver=' . rawurlencode((string) filemtime($content_file));

        if (!empty($init['content_css'])) {
            $init['content_css'] .= ',' . $content_url;
        } else {
            $init['content_css'] = $content_url;
        }
    }

    $content_style = 'html:has(body.ysh-dark-editor){background-color:#1a1d23 !important;}'
        . 'body.mce-content-body.ysh-dark-editor{background-color:#1a1d23 !important;color:#cfd6e0 !important;}'
        . 'body.mce-content-body.ysh-dark-editor a{color:#eda934;}'
        . 'body.mce-content-body.ysh-dark-editor p,body.mce-content-body.ysh-dark-editor li{color:#cfd6e0 !important;}';

    if (!empty($init['content_style'])) {
        $init['content_style'] .= ' ' . $content_style;
    } else {
        $init['content_style'] = $content_style;
    }

    if (yooadmin_studio_hub_is_effective_dark_mode()) {
        $init['body_class'] = trim(($init['body_class'] ?? '') . ' ysh-dark-editor');
        $init['body_style'] = 'background-color:#1a1d23;color:#cfd6e0;';
    }

    return $init;
}

/**
 * Footer cascade — beats SiteOrigin / late plugin CSS in <head>.
 */
/**
 * SiteOrigin modal overlay — must run on every classic editor load (not only dark mode).
 */
function yooadmin_studio_hub_print_siteorigin_overlay_critical(): void {
    if (!yooadmin_studio_hub_is_classic_editor_compat_screen()) {
        return;
    }

    if (!yooadmin_studio_hub_is_siteorigin_panels_active()) {
        return;
    }

    if (function_exists('yooadmin_studio_hub_is_product_editor_screen') && yooadmin_studio_hub_is_product_editor_screen()) {
        return;
    }

    echo '<style id="yooadmin-studio-hub-siteorigin-overlay-critical">'
        . 'body:has(.so-panels-dialog) .so-overlay{pointer-events:none!important;z-index:100049!important;}'
        . 'body:has(.so-panels-dialog) .so-panels-dialog :is(.so-content,.so-title-bar,.so-left-sidebar,.so-right-sidebar,.so-toolbar){z-index:100052!important;pointer-events:auto!important;}'
        . 'body:has(.so-panels-dialog) #wpseo_meta{pointer-events:none!important;z-index:auto!important;}'
        . 'body:has(.so-panels-dialog) .widget-type-wrapper{pointer-events:auto!important;cursor:pointer!important;}'
        . '</style>' . "\n";

    if (yooadmin_studio_hub_classic_editor_dark_compat_wanted()) {
        echo '<style id="yooadmin-studio-hub-siteorigin-dark-critical">'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog,:is(.so-panels-dialog *){transition:none!important;animation:none!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog :is(.so-content,.so-title-bar,.so-toolbar,.so-left-sidebar,.so-right-sidebar){background:#1a1d23!important;background-color:#1a1d23!important;color:#cfd6e0!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog :is(.so-toolbar,.so-toolbar *){background:#22262e!important;background-color:#22262e!important;color:#cfd6e0!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog :is(.cell,.cell-wrapper,.so-row-preview,.so-cells-preview){background:#2a3040!important;background-color:#2a3040!important;color:#cfd6e0!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog :is(.so-right-sidebar,.so-right-sidebar .so-sidebar,.so-visual-styles){background:#1a1d23!important;background-color:#1a1d23!important;color:#cfd6e0!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog .so-visual-styles :is(h3,.style-section-head,.style-section-head:hover,.style-section-head:focus,.style-section-fields,.style-field-wrapper,.style-field){background:#22262e!important;background-color:#22262e!important;border-color:rgba(255,255,255,.12)!important;box-shadow:none!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog .so-visual-styles :is(h3,h4,label,.style-section-head h4){color:#e8ecf1!important;-webkit-text-fill-color:#e8ecf1!important;text-shadow:none!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog .so-title-bar :is(a,a:hover,a:focus){background:#22262e!important;background-color:#22262e!important;color:#e8ecf1!important;border-color:rgba(255,255,255,.12)!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .siteorigin-panels-builder .widgets-container .so-widget,html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .siteorigin-panels-builder .widgets-container .so-widget:hover{background:#22262e!important;background-color:#22262e!important;color:#cfd6e0!important;box-shadow:none!important;}'
            . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .siteorigin-panels-builder .widgets-container .so-widget:hover{background:#2a3040!important;background-color:#2a3040!important;}'
            . '</style>' . "\n";
    }

    echo '<script id="yooadmin-studio-hub-siteorigin-overlay-critical-js">'
        . '(function(){'
        . 'function yshSoIsDark(){var h=document.documentElement;return h.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark"||h.classList.contains("is-dark-theme");}'
        . 'function yshSoPaint(el,bg,fg){if(!el||el.nodeType!==1)return;el.style.setProperty("background",bg,"important");el.style.setProperty("background-color",bg,"important");el.style.setProperty("color",fg,"important");el.style.setProperty("-webkit-text-fill-color",fg,"important");el.style.setProperty("border-color","rgba(255,255,255,0.12)","important");el.style.setProperty("box-shadow","none","important");}'
        . 'function yshSoDarkPaint(){'
        . 'if(!yshSoIsDark()){return;}'
        . 'document.querySelectorAll(".so-panels-dialog:not([data-ysh-so-dialog-done])").forEach(function(d){'
        . 'd.querySelectorAll(".so-content,.so-title-bar,.so-toolbar,.so-left-sidebar,.so-right-sidebar").forEach(function(el){yshSoPaint(el,"#1a1d23","#cfd6e0");});'
        . 'd.querySelectorAll(".so-toolbar,.so-toolbar *").forEach(function(el){yshSoPaint(el,"#22262e","#cfd6e0");});'
        . 'd.querySelectorAll(".cell,.cell-wrapper,.so-row-preview,.so-cells-preview").forEach(function(el){yshSoPaint(el,"#2a3040","#cfd6e0");});'
        . 'd.querySelectorAll(".so-right-sidebar,.so-visual-styles,.so-visual-styles .style-section-head,.so-visual-styles .style-section-fields").forEach(function(el){yshSoPaint(el,el.classList&&el.classList.contains("so-right-sidebar")?"#1a1d23":"#22262e","#cfd6e0");});'
        . 'd.setAttribute("data-ysh-so-dialog-done","1");'
        . '});'
        . 'document.querySelectorAll(".so-panels-dialog .so-visual-styles :is(h3,h4,label)").forEach(function(el){el.style.setProperty("color","#e8ecf1","important");el.style.setProperty("-webkit-text-fill-color","#e8ecf1","important");});'
        . 'document.querySelectorAll(".so-panels-dialog .so-title-bar a").forEach(function(el){yshSoPaint(el,"#22262e","#e8ecf1");});'
        . 'document.querySelectorAll(".siteorigin-panels-builder .so-widget:not([data-ysh-so-painted])").forEach(function(el){yshSoPaint(el,"#22262e","#cfd6e0");el.setAttribute("data-ysh-so-painted","1");});'
        . '}'
        . 'function yshSoOverlayPassthrough(){'
        . 'if(!document.querySelector(".so-panels-dialog")){return;}'
        . 'document.querySelectorAll(".so-overlay").forEach(function(o){'
        . 'o.style.setProperty("pointer-events","none","important");'
        . 'o.style.setProperty("z-index","100049","important");'
        . '});'
        . 'document.querySelectorAll(".so-panels-dialog .so-content,.so-panels-dialog .so-title-bar,.so-panels-dialog .so-left-sidebar,.so-panels-dialog .so-right-sidebar,.so-panels-dialog .so-toolbar").forEach(function(p){'
        . 'p.style.setProperty("z-index","100052","important");'
        . 'p.style.setProperty("pointer-events","auto","important");'
        . '});'
        . 'var y=document.getElementById("wpseo_meta");'
        . 'if(y){y.style.setProperty("pointer-events","none","important");y.style.setProperty("z-index","auto","important");}'
        . 'yshSoDarkPaint();'
        . '}'
        . 'function yshSoRun(){yshSoOverlayPassthrough();yshSoDarkPaint();}'
        . 'yshSoRun();'
        . 'document.addEventListener("DOMContentLoaded",yshSoRun);'
        . 'if(typeof MutationObserver!=="undefined"){new MutationObserver(function(ms){var hit=false;ms.forEach(function(m){if(!m.addedNodes||!m.addedNodes.length)return;m.addedNodes.forEach(function(n){if(n.nodeType===1&&(n.matches&&n.matches(".so-panels-dialog,.so-overlay")||(n.querySelector&&n.querySelector(".so-panels-dialog"))))hit=true;});});if(hit){yshSoRun();requestAnimationFrame(yshSoRun);}}).observe(document.body,{childList:true,subtree:true});}'
        . '})();'
        . '</script>' . "\n";
}

/**
 * SiteOrigin dialog dark — last cascade in admin_head (beats vendor CSS load order).
 */
function yooadmin_studio_hub_print_siteorigin_dark_cascade_tail(): void {
    if (!yooadmin_studio_hub_classic_editor_dark_compat_wanted()) {
        return;
    }

    if (!yooadmin_studio_hub_is_classic_editor_compat_screen()) {
        return;
    }

    if (!yooadmin_studio_hub_is_siteorigin_panels_active()) {
        return;
    }

    if (function_exists('yooadmin_studio_hub_is_product_editor_screen') && yooadmin_studio_hub_is_product_editor_screen()) {
        return;
    }

    $so_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-siteorigin-panels-dark.css');
    if (!is_readable($so_file)) {
        return;
    }

    // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local theme asset.
    $css = (string) file_get_contents($so_file);
    $marker = 'CASCADE TAIL';
    $pos    = strpos($css, $marker);
    if ($pos === false) {
        return;
    }

    $tail = substr($css, $pos);
    if ($tail === '') {
        return;
    }

    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static theme CSS from disk.
    echo '<style id="yooadmin-studio-hub-siteorigin-dark-cascade-tail">' . $tail . '</style>' . "\n";
}

function yooadmin_studio_hub_print_classic_editor_dark_footer(): void {
    if (!yooadmin_studio_hub_classic_editor_dark_compat_wanted()) {
        return;
    }

    if (function_exists('yooadmin_studio_hub_is_product_editor_screen') && yooadmin_studio_hub_is_product_editor_screen()) {
        return;
    }

    $dark_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-classic-editor-dark.css');
    if (is_readable($dark_file)) {
        $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-classic-editor-dark.css');
        $ver = (string) filemtime($dark_file);
        // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Footer cascade.
        printf(
            '<link rel="stylesheet" id="yooadmin-studio-hub-classic-editor-footer-dark" href="%s" />' . "\n",
            esc_url(add_query_arg('ver', $ver, $url))
        );
        // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
    }

    if (yooadmin_studio_hub_is_siteorigin_panels_active()) {
        $so_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-siteorigin-panels-dark.css');
        if (is_readable($so_file)) {
            $url = yooadmin_studio_hub_asset_url('css/compat/studio-hub-siteorigin-panels-dark.css');
            $ver = (string) filemtime($so_file);
            // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Footer cascade.
            printf(
                '<link rel="stylesheet" id="yooadmin-studio-hub-siteorigin-panels-footer-dark" href="%s" />' . "\n",
                esc_url(add_query_arg('ver', $ver, $url))
            );
            // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
        }
    }

    echo '<style id="yooadmin-studio-hub-classic-editor-footer-cascade">'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)'
        . ' body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus):is(.post-php,.post-new-php)'
        . ' :is(.wp-editor-wrap,.wp-editor-container,#wp-content-editor-container){max-width:100%!important;min-width:0!important;box-sizing:border-box!important;}'
        . '.mce-edit-area{overflow-x:hidden!important;}'
        . 'body:has(.so-panels-dialog) #wpseo_meta{z-index:auto!important;pointer-events:none!important;}'
        . 'body:has(.so-panels-dialog) .so-overlay{z-index:100049!important;pointer-events:none!important;}'
        . 'body:has(.so-panels-dialog) .so-panels-dialog :is(.so-content,.so-title-bar,.so-left-sidebar,.so-right-sidebar,.so-toolbar){z-index:100052!important;pointer-events:auto!important;}'
        . '.so-panels-dialog .widget-type-wrapper,.so-panels-dialog .widget-type-wrapper:hover,.so-panels-dialog .widget-type-wrapper:focus{display:block!important;background:#22262e!important;background-color:#22262e!important;color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;border-color:rgba(255,255,255,.14)!important;box-shadow:none!important;opacity:1!important;pointer-events:auto!important;cursor:pointer!important;}'
        . '.so-panels-dialog .widget-type-wrapper:hover,.so-panels-dialog .widget-type-wrapper:focus{background:#2a3040!important;background-color:#2a3040!important;}'
        . '.so-panels-dialog .widget-type-wrapper :is(h3,small,span,p,.widget-icon){color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;opacity:1!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog :is(.so-right-sidebar,.so-right-sidebar .so-sidebar,.so-visual-styles){background:#1a1d23!important;background-color:#1a1d23!important;color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog .so-visual-styles :is(h3,.style-section-head,.style-section-head:hover,.style-section-fields,.style-field-wrapper,.style-field){background:#22262e!important;background-color:#22262e!important;color:#e8ecf1!important;-webkit-text-fill-color:#e8ecf1!important;border-color:rgba(255,255,255,.12)!important;box-shadow:none!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) .so-panels-dialog .so-visual-styles :is(h3,h4,label){color:#e8ecf1!important;-webkit-text-fill-color:#e8ecf1!important;text-shadow:none!important;}'
        . '.so-panels-dialog .so-title-bar,.so-panels-dialog .so-title-bar a,.so-panels-dialog .so-title-bar a:hover{background:#22262e!important;background-color:#22262e!important;color:#e8ecf1!important;border-color:rgba(255,255,255,.12)!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus) .siteorigin-panels-builder .so-widget,.siteorigin-panels-builder .so-widget:hover,.siteorigin-panels-builder .so-widget:focus{background:#22262e!important;background-color:#22262e!important;color:#cfd6e0!important;box-shadow:none!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus) .siteorigin-panels-builder .so-widget:hover,.siteorigin-panels-builder .so-widget:focus{background:#2a3040!important;background-color:#2a3040!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus) .siteorigin-panels-builder .so-widget :is(h4,small){color:#e8ecf1!important;-webkit-text-fill-color:#e8ecf1!important;text-shadow:none!important;}'
        . '.so-panels-dialog :is(.widget-type-list,.widget-type){pointer-events:auto!important;opacity:1!important;}'
        . '.so-panels-dialog .so-widgets :is(a.so-widget,a[class*="widget"]){display:block!important;background:#22262e!important;color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;opacity:1!important;pointer-events:auto!important;cursor:pointer!important;text-decoration:none!important;}'
        . '.so-panels-dialog .so-widgets :is(a.so-widget,a[class*="widget"]) :is(h3,small,span,p){color:#cfd6e0!important;-webkit-text-fill-color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)'
        . ' body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus):is(.post-php,.post-new-php)'
        . ' :is(.mce-tinymce,.mce-container,.mce-container-body,.mce-edit-area){max-width:100%!important;box-sizing:border-box!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)'
        . ' body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus):is(.post-php,.post-new-php)'
        . ' .mce-edit-area iframe{width:100%!important;max-width:100%!important;display:block!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)'
        . ' body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus):is(.post-php,.post-new-php)'
        . ' .quicktags-toolbar input.button{background:rgba(255,255,255,.07)!important;color:#cfd6e0!important;border-color:rgba(255,255,255,.16)!important;box-shadow:none!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)'
        . ' body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus)'
        . ' .siteorigin-panels-builder :is(.so-builder-toolbar,.so-toolbar,.so-panels-welcome-message,.so-message-wrapper,.so-tool-button){background:#22262e!important;background-color:#22262e!important;color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme)'
        . ' body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus)'
        . ' .so-panels-dialog :is(.so-content,.so-title-bar,.so-left-sidebar,.so-right-sidebar){background:#1a1d23!important;color:#cfd6e0!important;}'
        . 'html:is([data-yooadmin-studio-color-mode-effective="dark"],.is-dark-theme) body:is(.yooadmin-theme-yooadmin-studio-hub,.ysh-classic-editor-static-dark,.yoo-focus):is(.post-php,.post-new-php) #wpseo_meta :is([class*="SnippetPreview"],[class*="snippet-preview"],[class*="yst-snippet"],[class*="bg-white"]){background:#22262e!important;background-color:#22262e!important;overflow-x:hidden!important;max-width:100%!important;}'
        . '</style>' . "\n";

    $so_fix_js = yooadmin_studio_hub_asset_path('js/compat/studio-siteorigin-dialog-fix.js');
    if (is_readable($so_fix_js)) {
        $url = yooadmin_studio_hub_asset_url('js/compat/studio-siteorigin-dialog-fix.js');
        $ver = (string) filemtime($so_fix_js);
        // phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Footer cascade for SiteOrigin modal.
        printf(
            '<script src="%s" id="yooadmin-studio-hub-siteorigin-dialog-fix-footer"></script>' . "\n",
            esc_url(add_query_arg('ver', $ver, $url))
        );
        // phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedScript
    }
}

/**
 * Patch TinyMCE iframe + text mode when dark (classic editor, all post types).
 */
function yooadmin_studio_hub_print_classic_editor_dark_script(): void {
    if (!yooadmin_studio_hub_classic_editor_dark_compat_wanted()) {
        return;
    }

    if (function_exists('yooadmin_studio_hub_is_product_editor_screen') && yooadmin_studio_hub_is_product_editor_screen()) {
        return;
    }

    echo '<script id="yooadmin-studio-hub-classic-editor-dark">'
        . '(function(){'
        . 'var timers=[];'
        . 'function yshIsDark(){var h=document.documentElement;if(h.getAttribute("data-yooadmin-studio-color-mode-effective")==="dark")return true;'
        . 'if(h.classList.contains("is-dark-theme"))return true;if(document.body&&document.body.classList.contains("is-dark-theme"))return true;'
        . 'var m=h.getAttribute("data-yooadmin-studio-color-mode");if(m==="dark")return true;if(m==="auto"){try{return window.matchMedia("(prefers-color-scheme: dark)").matches;}catch(e){}}return false;}'
        . 'function yshClassicEditorDarkApply(){'
        . 'var dark=yshIsDark();'
        . 'document.querySelectorAll(".mce-edit-area,.mce-container-body iframe").forEach(function(el){'
        . 'if(dark){el.style.setProperty("background-color","#1a1d23","important");}'
        . 'else{el.style.removeProperty("background-color");}});'
        . 'document.querySelectorAll("iframe[id$=\'_ifr\']").forEach(function(frame){'
        . 'try{var doc=frame.contentDocument||frame.contentWindow.document;if(!doc||!doc.body){return;}'
        . 'if(dark){doc.documentElement.style.backgroundColor="#1a1d23";doc.body.classList.add("ysh-dark-editor");'
        . 'doc.body.style.backgroundColor="#1a1d23";doc.body.style.color="#cfd6e0";}'
        . 'else{doc.documentElement.style.backgroundColor="";doc.body.classList.remove("ysh-dark-editor");'
        . 'doc.body.style.backgroundColor="#fff";doc.body.style.color="#1f2937";}'
        . '}catch(e){}});'
        . 'document.querySelectorAll("textarea.wp-editor-area").forEach(function(ta){'
        . 'if(dark){ta.style.setProperty("background","#1a1d23","important");ta.style.setProperty("color","#cfd6e0","important");}'
        . 'else{ta.style.removeProperty("background");ta.style.removeProperty("color");}});'
        . 'if(window.tinymce){tinymce.editors.forEach(function(ed){'
        . 'try{if(ed.getBody&&ed.getBody()){var b=ed.getBody();if(dark){b.style.backgroundColor="#1a1d23";b.style.color="#cfd6e0";}'
        . 'else{b.style.backgroundColor="#fff";b.style.color="#1f2937";}}'
        . 'ed.on("init",function(){setTimeout(yshClassicEditorDarkApply,50);});}catch(e){}});'
        . 'var contentEd=tinymce.get("content");if(contentEd){contentEd.on("init",function(){setTimeout(yshClassicEditorDarkApply,50);});}}'
        . '}'
        . 'function yshScheduleApply(){[0,400,1200,2800].forEach(function(ms){'
        . 'timers.push(setTimeout(yshClassicEditorDarkApply,ms));});}'
        . 'function yshClassicEditorDarkWatch(){yshClassicEditorDarkApply();yshScheduleApply();'
        . 'if(window.tinymce){tinymce.on("AddEditor",function(){setTimeout(yshClassicEditorDarkApply,80);});}'
        . 'new MutationObserver(function(muts){'
        . 'muts.forEach(function(m){if(m.attributeName==="data-yooadmin-studio-color-mode-effective"){yshClassicEditorDarkApply();}});'
        . '}).observe(document.documentElement,{attributes:true,attributeFilter:["data-yooadmin-studio-color-mode-effective"]});'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",yshClassicEditorDarkWatch);}'
        . 'else{yshClassicEditorDarkWatch();}'
        . 'window.addEventListener("load",function(){yshClassicEditorDarkApply();yshScheduleApply();});'
        . 'document.addEventListener("ysh-studio-color-mode-changed",yshClassicEditorDarkApply);'
        . '})();'
        . '</script>' . "\n";
}

/**
 * Elementor "Editor One" admin layout fix for the Focus shell.
 *
 * Re-points Editor One's fixed rail + top bar at the Focus shell (no WP admin
 * menu) and stabilises the content column. Loads on Elementor admin pages only;
 * every rule is scoped to the Editor One chrome so it is inert elsewhere.
 */
function yooadmin_studio_hub_enqueue_elementor_admin_layout(): void {
    if (!yooadmin_studio_hub_is_active() || !yooadmin_studio_hub_is_focus_enabled()) {
        return;
    }
    if (!defined('ELEMENTOR_VERSION')) {
        return;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only route check.
    $slug = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    if (strpos($slug, 'elementor') !== 0) {
        return;
    }

    $file = yooadmin_studio_hub_asset_path('css/compat/elementor-home.css');
    if (is_readable($file)) {
        wp_enqueue_style(
            'yooadmin-studio-hub-elementor-admin-layout',
            yooadmin_studio_hub_asset_url('css/compat/elementor-home.css'),
            [],
            (string) filemtime($file)
        );
    }

    $script = yooadmin_studio_hub_asset_path('js/compat/elementor-admin-layout.js');
    if (is_readable($script)) {
        wp_enqueue_script(
            'yooadmin-studio-hub-elementor-admin-layout',
            yooadmin_studio_hub_asset_url('js/compat/elementor-admin-layout.js'),
            [],
            (string) filemtime($script),
            true
        );
    }
}
