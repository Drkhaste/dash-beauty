<?php
/**
 * YOOAdmin Dark Engine v2.
 *
 * @package YOOAdmin_Studio_Hub
 */

defined('ABSPATH') || exit;

if (!function_exists('yooadmin_dark_engine_v2_enabled')) {
    function yooadmin_dark_engine_v2_enabled(): bool {
        return (bool) apply_filters('yooadmin_dark_engine_v2_enabled', true);
    }
}

if (!function_exists('yooadmin_dark_engine_query_page_slug')) {
    /**
     * Current ?page= slug (read-only route check).
     */
    function yooadmin_dark_engine_query_page_slug(): string {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only route check.
        if (!isset($_GET['page'])) {
            return '';
        }
        $page = sanitize_key((string) wp_unslash($_GET['page']));
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        return $page;
    }
}

if (!function_exists('yooadmin_dark_engine_is_wp_core_settings_screen')) {
    /**
     * WordPress core settings/tools screens (no third-party ?page= route).
     *
     * Also covers the core user screens (profile, edit/new user, users list),
     * which share the same core form/list markup and otherwise render unstyled
     * (default dark-on-dark text) under the Focus dark shell.
     */
    function yooadmin_dark_engine_is_wp_core_settings_screen(): bool {
        global $pagenow;

        if (!isset($pagenow)) {
            return false;
        }

        $screens = [
            'options-general.php',
            'options-writing.php',
            'options-reading.php',
            'options-discussion.php',
            'options-media.php',
            'options-permalink.php',
            'options-privacy.php',
            'options.php',
            'privacy.php',
            'tools.php',
            'import.php',
            'export.php',
            'export-personal-data.php',
            'erase-personal-data.php',
            'site-health.php',
            'profile.php',
            'user-edit.php',
            'user-new.php',
            'users.php',
            'update-core.php',
            'update.php',
            'edit-tags.php',
            'term.php',
            'comment.php',
            'nav-menus.php',
            'widgets.php',
            'link-manager.php',
            'link-add.php',
            'link.php',
        ];

        if (!in_array($pagenow, $screens, true)) {
            return false;
        }

        // A ?page= route under these menus belongs to a third-party plugin.
        return '' === yooadmin_dark_engine_query_page_slug();
    }
}

if (!function_exists('yooadmin_dark_engine_is_plugin_admin_screen')) {
    /**
     * Third-party plugin admin screen (top-level or hung under a core menu).
     *
     * Excludes YOOAdmin-native pages, the block/site editor, and bare WP core
     * settings (handled by the wp-core layer).
     */
    function yooadmin_dark_engine_is_plugin_admin_screen(): bool {
        global $pagenow;

        if (!isset($pagenow)) {
            return false;
        }

        if (in_array($pagenow, ['site-editor.php', 'post.php', 'post-new.php'], true)) {
            return false;
        }

        if (function_exists('get_current_screen')) {
            $screen = get_current_screen();
            if ($screen && $screen->is_block_editor()) {
                return false;
            }
        }

        $page = yooadmin_dark_engine_query_page_slug();
        if ('' === $page || 0 === strpos($page, 'yooadmin')) {
            return false;
        }

        // Top-level plugin menus.
        if ('admin.php' === $pagenow) {
            return true;
        }

        // Plugin settings hung under core parent menus (options-general.php?page=, etc.).
        $parent_menus = [
            'options-general.php',
            'settings.php',
            'tools.php',
            'upload.php',
            'edit.php',
            'edit-comments.php',
            'themes.php',
            'plugins.php',
            'users.php',
            'index.php',
        ];

        return in_array($pagenow, $parent_menus, true);
    }
}

if (!function_exists('yooadmin_dark_engine_is_media_library_screen')) {
    function yooadmin_dark_engine_is_media_library_screen(): bool {
        global $pagenow;

        if (!isset($pagenow) || !in_array($pagenow, ['upload.php', 'media-new.php'], true)) {
            return false;
        }

        return '' === yooadmin_dark_engine_query_page_slug();
    }
}

if (!function_exists('yooadmin_dark_engine_is_file_editor_screen')) {
    function yooadmin_dark_engine_is_file_editor_screen(): bool {
        global $pagenow;

        return isset($pagenow)
            && in_array($pagenow, ['plugin-editor.php', 'theme-editor.php'], true);
    }
}

if (!function_exists('yooadmin_dark_engine_context')) {
    function yooadmin_dark_engine_context(): string {
        $ctx = '';

        if (yooadmin_dark_engine_is_wp_core_settings_screen()) {
            $ctx = 'wp';
        } elseif (yooadmin_dark_engine_is_media_library_screen()) {
            $ctx = 'media';
        } elseif (yooadmin_dark_engine_is_file_editor_screen()) {
            $ctx = 'files';
        } elseif (yooadmin_dark_engine_is_plugin_admin_screen()) {
            $ctx = 'plugin';
        } elseif (yooadmin_dark_engine_is_dashboard_screen()) {
            $ctx = 'dashboard';
        }

        if ('' === $ctx) {
            return '';
        }

        return in_array($ctx, yooadmin_dark_engine_active_contexts(), true) ? $ctx : '';
    }
}

if (!function_exists('yooadmin_dark_engine_active_contexts')) {
    /**
     * @return string[]
     */
    function yooadmin_dark_engine_active_contexts(): array {
        return apply_filters(
            'yooadmin_dark_engine_active_contexts',
            ['wp', 'plugin', 'media', 'files', 'dashboard']
        );
    }
}

if (!function_exists('yooadmin_dark_engine_is_dashboard_screen')) {
    function yooadmin_dark_engine_is_dashboard_screen(): bool {
        return function_exists('yooadmin_studio_hub_is_dashboard_screen')
            && yooadmin_studio_hub_is_dashboard_screen();
    }
}

if (!function_exists('yooadmin_dark_engine_should_run')) {
    /**
     * Gate shared by every v2 hook: flag on + Studio Hub active + Focus on.
     */
    function yooadmin_dark_engine_should_run(): bool {
        return yooadmin_dark_engine_v2_enabled()
            && yooadmin_studio_hub_is_active()
            && yooadmin_studio_hub_is_focus_enabled();
    }
}

if (!function_exists('yooadmin_dark_engine_admin_body_class')) {
    /**
     * Add one context class so CSS layers can use a short, stable scope.
     *
     * @param string $classes Space-separated admin body classes.
     * @return string
     */
    function yooadmin_dark_engine_admin_body_class(string $classes): string {
        if (!yooadmin_dark_engine_should_run()) {
            return $classes;
        }

        $ctx = yooadmin_dark_engine_context();
        if ('' === $ctx) {
            return $classes;
        }

        return $classes . ' yp-dark-v2 yp-dark-v2-' . $ctx;
    }
}

if (!function_exists('yooadmin_dark_engine_enqueue_assets')) {
    /**
     * Enqueue the v2 dark layers in cascade order. The dark scope lives in the
     * CSS (html[...effective='dark']) so we can register in any mode and let the
     * runtime toggle apply instantly without a reload.
     */
    function yooadmin_dark_engine_enqueue_assets(): void {
        if (!yooadmin_dark_engine_should_run()) {
            return;
        }

        $ctx = yooadmin_dark_engine_context();
        if ('' === $ctx) {
            return;
        }

        // Core layers (always for any v2 screen).
        $deps = yooadmin_dark_engine_enqueue_layers([
            'yooadmin-dark-core-tokens'  => 'css/dark/core/tokens.css',
            'yooadmin-dark-core-base'    => 'css/dark/core/base.css',
            'yooadmin-dark-core-invert'  => 'css/dark/core/invert-island.css',
        ], []);

        // Opt-in invert islands for impossible light-only UIs (filter-driven).
        yooadmin_dark_engine_attach_invert_islands('yooadmin-dark-core-invert');

        // List tables are shared by screens that render WP_List_Table.
        if (in_array($ctx, ['wp', 'plugin', 'media'], true)) {
            $deps = yooadmin_dark_engine_enqueue_layers([
                'yooadmin-dark-list-tables' => 'css/dark/wp-core/list-tables.css',
            ], yooadmin_dark_engine_with_core_style_deps($deps));
        }

        $core_deps = yooadmin_dark_engine_with_core_style_deps($deps);

        // Screens that may embed a TinyMCE editor (wp_editor) need the iframe
        // bridge so the editor's writing surface follows light/dark live.
        if (in_array($ctx, ['plugin', 'wp'], true)) {
            yooadmin_dark_engine_enqueue_tinymce_bridge();
        }

        switch ($ctx) {
            case 'wp':
                $wp_deps = yooadmin_dark_engine_enqueue_layers([
                    'yooadmin-dark-wp-settings' => 'css/dark/wp-core/settings.css',
                ], $core_deps);

                // Menus + Widgets carry bespoke markup the settings layer cannot
                // reach (menu builder panels, block/classic widgets editor).
                global $pagenow;
                if (isset($pagenow) && in_array($pagenow, ['nav-menus.php', 'widgets.php'], true)) {
                    yooadmin_dark_engine_enqueue_layers([
                        'yooadmin-dark-wp-menus-widgets' => 'css/dark/wp-core/menus-widgets.css',
                    ], yooadmin_dark_engine_with_core_style_deps($wp_deps));
                }
                break;

            case 'plugin':
                $compat_deps = yooadmin_dark_engine_enqueue_layers([
                    'yooadmin-dark-compat-generic' => 'css/dark/compat/generic.css',
                ], $core_deps);
                yooadmin_dark_engine_enqueue_vendor_layers($compat_deps);
                yooadmin_dark_engine_enqueue_adaptive();
                break;

            case 'media':
                $media_deps = $core_deps;
                foreach (['media', 'media-views', 'buttons'] as $mh) {
                    if (wp_style_is($mh, 'registered') || wp_style_is($mh, 'enqueued')) {
                        $media_deps[] = $mh;
                    }
                }
                yooadmin_dark_engine_enqueue_layers([
                    'yooadmin-dark-wp-media' => 'css/dark/wp-core/media.css',
                ], array_values(array_unique($media_deps)));
                break;

            case 'files':
                yooadmin_dark_engine_enqueue_layers([
                    'yooadmin-dark-wp-file-editor' => 'css/dark/wp-core/file-editor.css',
                ], $core_deps);
                break;

            case 'dashboard':
                yooadmin_dark_engine_enqueue_layers([
                    'yooadmin-dark-dashboard-widgets' => 'css/dark/compat/dashboard-widgets.css',
                ], $core_deps);
                break;
        }
    }
}

if (!function_exists('yooadmin_dark_engine_enqueue_tinymce_bridge')) {
    /**
     * Enqueue the TinyMCE iframe bridge on v2 screens that may host wp_editor().
     *
     * The script toggles the in-iframe dark body class (and the Text-mode
     * textarea) live on color-mode changes. Inert when no editor is present.
     */
    function yooadmin_dark_engine_enqueue_tinymce_bridge(): void {
        $rel  = 'js/dark/tinymce.js';
        $path = yooadmin_studio_hub_asset_path($rel);
        if (!is_readable($path)) {
            return;
        }
        wp_enqueue_script(
            'yooadmin-dark-tinymce',
            yooadmin_studio_hub_asset_url($rel),
            [],
            (string) filemtime($path),
            true
        );
    }
}

if (!function_exists('yooadmin_dark_engine_filter_tinymce_dark')) {
    /**
     * Inject the dark writing-surface stylesheet into TinyMCE editors on v2
     * plugin/WP-core screens (e.g. Code Snippets "Description"). The editor body
     * lives in a separate iframe document that page CSS cannot reach, so the dark
     * theme has to ride in through TinyMCE's own content_css/content_style.
     *
     * Scoped to body.ysh-dark-editor; the bridge script toggles that class so the
     * surface follows live light/dark switching. The classic-editor and product
     * editor screens have their own handlers and are not v2 contexts, so they are
     * left untouched.
     *
     * @param array<string, mixed> $init Editor init config.
     * @return array<string, mixed>
     */
    function yooadmin_dark_engine_filter_tinymce_dark(array $init): array {
        if (!yooadmin_dark_engine_should_run()) {
            return $init;
        }

        if (!in_array(yooadmin_dark_engine_context(), ['plugin', 'wp'], true)) {
            return $init;
        }

        $content_file = yooadmin_studio_hub_asset_path('css/compat/studio-hub-tinymce-dark-content.css');
        if (is_readable($content_file)) {
            $content_url  = yooadmin_studio_hub_asset_url('css/compat/studio-hub-tinymce-dark-content.css');
            $content_url .= '?ver=' . rawurlencode((string) filemtime($content_file));

            $init['content_css'] = empty($init['content_css'])
                ? $content_url
                : $init['content_css'] . ',' . $content_url;
        }

        $content_style = 'html:has(body.ysh-dark-editor){background-color:#1a1d23 !important;}'
            . 'body.mce-content-body.ysh-dark-editor{background-color:#1a1d23 !important;color:#cfd6e0 !important;}'
            . 'body.mce-content-body.ysh-dark-editor a{color:#eda934;}'
            . 'body.mce-content-body.ysh-dark-editor p,body.mce-content-body.ysh-dark-editor li{color:#cfd6e0 !important;}';

        $init['content_style'] = empty($init['content_style'])
            ? $content_style
            : $init['content_style'] . ' ' . $content_style;

        if (function_exists('yooadmin_studio_hub_is_effective_dark_mode')
            && yooadmin_studio_hub_is_effective_dark_mode()
        ) {
            $init['body_class'] = trim(($init['body_class'] ?? '') . ' ysh-dark-editor');
        }

        return $init;
    }
}

if (!function_exists('yooadmin_dark_engine_enqueue_adaptive')) {
    /**
     * Enqueue the narrow adaptive JS fallback for plugin admin screens.
     *
     * Pure CSS cannot reach self-contained React/MUI/emotion apps (hashed class
     * names, runtime styles). This small, budgeted script darkens only neutral
     * light stragglers at runtime. It self-gates on the dark attribute + the
     * v2-plugin body class, so it is inert outside dark mode.
     */
    function yooadmin_dark_engine_enqueue_adaptive(): void {
        $rel  = 'js/dark/adaptive.js';
        $path = yooadmin_studio_hub_asset_path($rel);
        if (!is_readable($path)) {
            return;
        }
        wp_enqueue_script(
            'yooadmin-dark-adaptive',
            yooadmin_studio_hub_asset_url($rel),
            [],
            (string) filemtime($path),
            true
        );
    }
}

if (!function_exists('yooadmin_dark_engine_enqueue_vendor_layers')) {
    /**
     * Conditionally load vendor-specific dark overrides for detected plugins.
     *
     * Each vendor file is loaded only when the plugin is active, keeping the
     * payload minimal. Vendor layers override generic tokens with the plugin's
     * own dark palette when available (e.g. Elementor's --e-a-* system).
     *
     * @param string[] $base_deps Handles from the generic compat layer.
     */
    function yooadmin_dark_engine_enqueue_vendor_layers(array $base_deps): void {
        // Load vendor layers AFTER the active plugin's own admin styles so our
        // token overrides win on load order (in addition to specificity).
        $base_deps = array_values(array_unique(array_merge(
            $base_deps,
            yooadmin_dark_engine_collect_plugin_style_deps()
        )));

        $vendors = [
            'elementor' => [
                'detect' => static fn(): bool => defined('ELEMENTOR_VERSION'),
                'file'   => 'css/dark/vendor/elementor.css',
            ],
            // WooCommerce admin (wc-admin React app, settings, status, reports).
            'woocommerce' => [
                'detect' => static function (): bool {
                    if (!class_exists('WooCommerce') && !defined('WC_VERSION')) {
                        return false;
                    }
                    $slug = yooadmin_dark_engine_query_page_slug();
                    return 0 === strpos($slug, 'wc-');
                },
                'file'   => 'css/dark/vendor/woocommerce.css',
            ],
            // Elementor Home (admin.php?page=elementor-home) is a self-contained
            // React/MUI app that ignores all design tokens; theme it directly.
            // The default slug is 'elementor-home' (Config::ADMIN_PAGE); older
            // builds used 'elementor'. Match both.
            'elementor-home' => [
                'detect' => static function (): bool {
                    if (!defined('ELEMENTOR_VERSION')) {
                        return false;
                    }
                    $slug = yooadmin_dark_engine_query_page_slug();
                    return 'elementor-home' === $slug || 'elementor' === $slug;
                },
                'file'   => 'css/dark/vendor/elementor-home.css',
            ],
        ];

        foreach ($vendors as $slug => $cfg) {
            if (!($cfg['detect'])()) {
                continue;
            }
            yooadmin_dark_engine_enqueue_layers([
                'yooadmin-dark-vendor-' . $slug => $cfg['file'],
            ], $base_deps);
        }
    }
}

if (!function_exists('yooadmin_dark_engine_attach_invert_islands')) {
    /**
     * Apply the invert-island treatment to selectors registered via filter.
     *
     * Lets impossible light-only widgets be darkened without adding a class to
     * the DOM. Each selector is inverted + hue-rotated; media inside is
     * counter-inverted so it stays true-colour. No selectors registered = no CSS.
     *
     * @param string $handle Style handle to attach the generated CSS to.
     */
    function yooadmin_dark_engine_attach_invert_islands(string $handle): void {
        if (!wp_style_is($handle, 'enqueued') && !wp_style_is($handle, 'registered')) {
            return;
        }

        $context = [
            'is_wp_core' => yooadmin_dark_engine_is_wp_core_settings_screen(),
            'is_plugin'  => yooadmin_dark_engine_is_plugin_admin_screen(),
            'page'       => yooadmin_dark_engine_query_page_slug(),
        ];

        /**
         * Filter the list of CSS selectors to treat as invert islands.
         *
         * @param string[] $selectors Selectors (relative to the dark v2 body scope).
         * @param array    $context   Current screen context.
         */
        $selectors = apply_filters('yooadmin_dark_engine_invert_island_selectors', [], $context);

        if (!is_array($selectors) || [] === $selectors) {
            return;
        }

        $selectors = array_values(array_unique(array_filter(array_map('trim', $selectors))));
        if ([] === $selectors) {
            return;
        }

        $scope  = "html[data-yooadmin-studio-color-mode-effective='dark'] body.yp-dark-v2 ";
        $island = [];
        $media  = [];
        foreach ($selectors as $sel) {
            $island[] = $scope . $sel;
            // Counter-invert true media only; canvas/iframe are usually the
            // impossible UI being darkened, so they are excluded here.
            $media[]  = $scope . $sel
                . ' :is(img,picture,video,svg,[style*="background-image"],[style*="url("])';
        }

        $css  = implode(',', $island) . '{filter:invert(1) hue-rotate(180deg);background-color:#fff!important;}';
        $css .= implode(',', $media) . '{filter:invert(1) hue-rotate(180deg);}';

        wp_add_inline_style($handle, $css);
    }
}

if (!function_exists('yooadmin_dark_engine_collect_plugin_style_deps')) {
    /**
     * Collect currently-enqueued third-party plugin admin style handles.
     *
     * Used as extra dependencies for vendor layers so they always load after the
     * plugin's own CSS. v2 evolution of the legacy
     * yooadmin_studio_hub_collect_plugin_admin_vendor_style_deps().
     *
     * @return string[]
     */
    function yooadmin_dark_engine_collect_plugin_style_deps(): array {
        global $wp_styles;
        if (!$wp_styles instanceof WP_Styles) {
            return [];
        }

        $skip = [
            'wp-admin' => true, 'common' => true, 'forms' => true,
            'dashicons' => true, 'editor-buttons' => true,
        ];

        $deps = [];
        foreach ($wp_styles->queue as $handle) {
            if (!is_string($handle) || isset($skip[$handle]) || 0 === strpos($handle, 'yooadmin')) {
                continue;
            }
            $reg = $wp_styles->registered[$handle] ?? null;
            if ($reg && is_string($reg->src)
                && preg_match('#/wp-content/plugins/[^/]+/.+\.css#i', $reg->src)
            ) {
                $deps[] = $handle;
            }
        }

        return array_values(array_unique($deps));
    }
}

if (!function_exists('yooadmin_dark_engine_enqueue_layers')) {
    /**
     * Enqueue a set of layer files chained as dependencies, in order.
     *
     * @param array<string,string> $layers handle => relative asset path.
     * @param string[]             $base_deps Dependencies for the first layer.
     * @return string[] Handles enqueued (for chaining as deps).
     */
    function yooadmin_dark_engine_enqueue_layers(array $layers, array $base_deps): array {
        $prev    = $base_deps;
        $handles = [];

        foreach ($layers as $handle => $rel) {
            $path = yooadmin_studio_hub_asset_path($rel);
            if (!is_readable($path)) {
                continue;
            }
            wp_enqueue_style(
                $handle,
                yooadmin_studio_hub_asset_url($rel),
                array_values(array_unique($prev)),
                (string) filemtime($path)
            );
            $prev      = [$handle];
            $handles[] = $handle;
        }

        return $handles;
    }
}

if (!function_exists('yooadmin_dark_engine_dequeue_legacy')) {
    /**
     * Remove legacy dark engines when v2 is active, so only the new engine runs.
     *
     * Targets:
     *  - YOOAdmin v1 plugin-admin dark + adaptive CSS/JS.
     *  - dark-mode-for-wp-dashboard plugin (separate plugin, body class + CSS).
     *
     * Runs at priority 99999 so everything has been enqueued first.
     */
    function yooadmin_dark_engine_dequeue_legacy(): void {
        if (!yooadmin_dark_engine_should_run()) {
            return;
        }

        $is_v2_screen = yooadmin_dark_engine_is_wp_core_settings_screen()
                     || yooadmin_dark_engine_is_plugin_admin_screen();

        if (!$is_v2_screen) {
            return;
        }

        $legacy_styles = [
            'yooadmin-studio-hub-plugin-admin-dark',
            'yooadmin-studio-hub-plugin-admin-adaptive',
            'yooadmin-studio-hub-classic-editor-dark',
            'yooadmin-studio-hub-classic-editor-dark-patch',
            'yooadmin-brand-dark',
            'yooadmin-wp-media-modal-dark',
            'dark-mode-dashboard',
            'dark-mode-dashboard-editor',
        ];

        foreach ($legacy_styles as $handle) {
            wp_dequeue_style($handle);
            wp_deregister_style($handle);
        }

        $legacy_scripts = [
            'yooadmin-studio-hub-plugin-admin-adaptive',
        ];

        foreach ($legacy_scripts as $handle) {
            wp_dequeue_script($handle);
            wp_deregister_script($handle);
        }
    }
}

if (!function_exists('yooadmin_dark_engine_remove_legacy_body_classes')) {
    /**
     * Strip dark-mode-for-wp-dashboard body classes when v2 is active.
     *
     * @param string $classes Admin body class string.
     * @return string
     */
    function yooadmin_dark_engine_remove_legacy_body_classes(string $classes): string {
        if (!yooadmin_dark_engine_should_run()) {
            return $classes;
        }

        $is_v2_screen = yooadmin_dark_engine_is_wp_core_settings_screen()
                     || yooadmin_dark_engine_is_plugin_admin_screen();

        if (!$is_v2_screen) {
            return $classes;
        }

        $classes = preg_replace('/\bdark-mode(?:-auto)?\b/', '', $classes);

        return trim((string) preg_replace('/\s{2,}/', ' ', $classes));
    }
}

if (!function_exists('yooadmin_dark_engine_suppress_legacy_inline')) {
    /**
     * Remove legacy inline anti-flash styles injected via admin_head by both
     * the old engine and dark-mode-for-wp-dashboard.
     */
    function yooadmin_dark_engine_suppress_legacy_inline(): void {
        if (!yooadmin_dark_engine_should_run()) {
            return;
        }

        $is_v2_screen = yooadmin_dark_engine_is_wp_core_settings_screen()
                     || yooadmin_dark_engine_is_plugin_admin_screen();

        if (!$is_v2_screen) {
            return;
        }

        remove_action('admin_head', 'dark_mode_dashboard_anti_flash', 1);
    }
}

if (!function_exists('yooadmin_dark_engine_with_core_style_deps')) {
    /**
     * Append registered WP core admin style handles so v2 loads after them.
     *
     * @param string[] $deps Existing dependency handles.
     * @return string[]
     */
    function yooadmin_dark_engine_with_core_style_deps(array $deps): array {
        foreach (['wp-admin', 'common', 'forms'] as $handle) {
            if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
                $deps[] = $handle;
            }
        }

        return array_values(array_unique($deps));
    }
}
