/**
 * WooCommerce product editor — tabbed main column + YOOAdmin sidebar.
 */
(function ($) {
  'use strict';

  var cfg = window.yshProductEditor || {};
  var STORAGE_KEY = 'ysh_product_editor_tab';
  var SIDEBAR_STORAGE_KEY = 'ysh_product_editor_sidebar_tab';

  var SIDEBAR_TAB_DEFS = [
    { id: 'publish', label: 'Publish' },
    { id: 'organize', label: 'Organize' },
    { id: 'media', label: 'Media' },
    { id: 'more', label: 'More' }
  ];

  var publishUiMutating = false;
  var publishMenuOrder = ['preview-action', 'save-action', 'duplicate-action'];

  function isDark() {
    return (
      document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') ===
      'dark'
    );
  }

  function mountLoader() {
    var loader = document.getElementById('ysh-pe-loader');
    if (!loader) {
      return;
    }

    var target =
      document.getElementById('yoo-shell-content') || document.getElementById('wpbody-content');
    if (target && loader.parentElement !== target) {
      target.insertBefore(loader, target.firstChild);
    }
  }

  function hideWooEmbed() {
    document.querySelectorAll(
      '#woocommerce-embedded-root, .woocommerce-layout, .woocommerce-layout__header'
    ).forEach(function (el) {
      el.style.setProperty('display', 'none', 'important');
      el.style.setProperty('visibility', 'hidden', 'important');
      el.style.setProperty('height', '0', 'important');
      el.style.setProperty('overflow', 'hidden', 'important');
    });
  }

  function hideLoader() {
    document.body.classList.add('ysh-product-editor-active');
    var loader = document.getElementById('ysh-pe-loader');
    if (loader) {
      loader.setAttribute('aria-busy', 'false');
      loader.remove();
    }
    hideWooEmbed();
  }

  var EDITOR_IDS_BY_PANEL = {
    content: ['content'],
    'short-description': ['excerpt']
  };

  function applyEditorTheme() {
    var dark = isDark();
    document.querySelectorAll('iframe[id$="_ifr"]').forEach(function (frame) {
      try {
        var doc = frame.contentDocument || frame.contentWindow.document;
        if (!doc || !doc.body) {
          return;
        }
        if (dark) {
          doc.body.classList.add('ysh-dark-editor');
          doc.body.style.backgroundColor = '#1a1d23';
          doc.body.style.color = '#cfd6e0';
        } else {
          doc.body.classList.remove('ysh-dark-editor');
          doc.body.style.backgroundColor = '#ffffff';
          doc.body.style.color = '#1f2937';
        }
      } catch (e) {}
    });
    document.querySelectorAll('textarea.wp-editor-area').forEach(function (ta) {
      if (dark) {
        ta.style.setProperty('background', '#1a1d23', 'important');
        ta.style.setProperty('color', '#cfd6e0', 'important');
      } else {
        ta.style.removeProperty('background');
        ta.style.removeProperty('color');
      }
    });
  }

  function refreshEditorsInPanel(panelId) {
    var ids = EDITOR_IDS_BY_PANEL[panelId] || [];
    if (!ids.length) {
      return;
    }

    window.setTimeout(function () {
      if (window.tinymce) {
        ids.forEach(function (id) {
          var ed = window.tinymce.get(id);
          if (!ed) {
            return;
          }
          try {
            if (ed.hidden) {
              ed.show();
            }
            ed.fire('Show');
            ed.fire('ResizeEditor');
            var container = ed.getContainer();
            if (container) {
              container.style.visibility = 'visible';
              container.style.height = '';
            }
            if (ed.theme && typeof ed.theme.resizeTo === 'function' && container) {
              ed.theme.resizeTo(container.offsetWidth, Math.max(220, container.offsetHeight || 220));
            }
          } catch (e2) {}
        });
        try {
          window.tinymce.execCommand('mceRepaint');
        } catch (e3) {}
      }

      applyEditorTheme();
      window.dispatchEvent(new Event('resize'));
    }, 60);
  }

  function getActiveTabId() {
    var $active = $('.ysh-product-editor__tab.is-active').first();
    return $active.length ? $active.attr('data-tab') : 'content';
  }

  function enhancePermalinkUi() {
    var $box = $('#edit-slug-box');
    if (!$box.length) {
      return;
    }

    function iconify($el, iconClass, fallbackLabel) {
      if (!$el.length || $el.data('yshPermalinkIcon')) {
        return;
      }
      var label =
        $el.attr('aria-label') || $el.attr('title') || $.trim($el.text()) || fallbackLabel;
      $el
        .addClass('ysh-permalink-icon-btn')
        .attr('aria-label', label)
        .attr('title', label)
        .data('yshPermalinkIcon', 1)
        .html('<span class="dashicons ' + iconClass + '" aria-hidden="true"></span>');
    }

    iconify($('#change-permalinks a.button'), 'dashicons-admin-links', 'Change Permalink Structure');
    iconify($('#edit-slug-buttons .edit-slug'), 'dashicons-edit', 'Edit permalink');
    iconify($('#edit-slug-buttons .cancel'), 'dashicons-no-alt', 'Cancel');
    iconify($('#edit-slug-buttons .save'), 'dashicons-yes', 'OK');
  }

  function watchColorMode() {
    if (typeof MutationObserver === 'undefined') {
      return;
    }
    var obs = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        if (m.attributeName === 'data-yooadmin-studio-color-mode-effective') {
          applyEditorTheme();
          applyTourDark();
          refreshEditorsInPanel(getActiveTabId());
        }
      });
    });
    obs.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['data-yooadmin-studio-color-mode-effective']
    });
  }

  function watchPermalinkBox() {
    var $box = $('#edit-slug-box');
    if (!$box.length || typeof MutationObserver === 'undefined') {
      return;
    }
    var timer = null;
    new MutationObserver(function () {
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(enhancePermalinkUi, 40);
    }).observe($box[0], { childList: true, subtree: true });
  }

  function publishIconLabels() {
    return (cfg && cfg.publishIcons) || {};
  }

  function readControlLabel($el, fallback) {
    if (!$el || !$el.length) {
      return fallback || '';
    }
    var sr = $.trim($el.find('.screen-reader-text').text());
    if (sr) {
      return sr;
    }
    var aria = $.trim($el.attr('aria-label') || '');
    if (aria) {
      return aria;
    }
    if ($el.is('input')) {
      return $.trim($el.val() || $el.attr('value') || '') || fallback || '';
    }
    return $.trim($el.text()) || fallback || '';
  }

  function cleanPublishLabel(label) {
    label = $.trim(String(label || ''));
    label = label.replace(/\s*\(opens in a new tab\)\s*/gi, ' ').trim();
    return label;
  }

  function stylePublishToolbarButton($el, variant, iconClass, label) {
    if (!$el || !$el.length) {
      return;
    }

    if ($el.closest('.ysh-publish-footer-action').length) {
      var $legacy = $el.closest('.ysh-publish-footer-action');
      var $control = $legacy.find('input, a, button').first();
      if ($control.length) {
        $el = $control;
      }
    }

    if ($el.data('yshPublishToolbar')) {
      return;
    }

    label = cleanPublishLabel(label || readControlLabel($el, ''));
    variant = variant || 'default';
    $el.attr('title', label).attr('aria-label', label).data('yshPublishToolbar', 1);

    var iconHtml = iconClass
      ? '<span class="dashicons ' + iconClass + '" aria-hidden="true"></span>'
      : '';
    var textHtml = '<span class="ysh-publish-toolbar-btn__text">' + label + '</span>';

    var $slot = $el.closest(
      '#save-action, #preview-action, #publishing-action, #delete-action, #duplicate-action'
    );
    if ($slot.is('#publishing-action')) {
      var $splitMain = $slot.find('.ysh-publish-split__main').first();
      if ($splitMain.length) {
        $slot = $splitMain;
      }
    }
    var $marker = null;

    if (!$slot.length) {
      $marker = $('<span class="ysh-publish-footer-marker" aria-hidden="true" />');
      $marker.insertBefore($el);
    }

    if ($el.is('input[type="submit"], input[type="button"], input.button')) {
      var $btn = $(
        '<span class="ysh-publish-toolbar-btn ysh-publish-toolbar-btn--' + variant + '" />'
      );
      $btn.attr('title', label).attr('aria-label', label);
      $el.addClass('ysh-publish-toolbar-btn__input').val(label);
      $btn.append(iconHtml).append(textHtml).append($el);
      if ($slot.length) {
        $slot.empty().append($btn);
      } else if ($marker && $marker.length) {
        $marker.replaceWith($btn);
      }
      return;
    }

    $el
      .addClass('ysh-publish-toolbar-btn ysh-publish-toolbar-btn--' + variant)
      .html(iconHtml + textHtml);
  }

  function styleMiscEditLink($el, label) {
    if (!$el || !$el.length || $el.data('yshPublishEdit')) {
      return;
    }

    label = label || readControlLabel($el, 'Edit');
    $el.attr('title', label).attr('aria-label', label).data('yshPublishEdit', 1);
    $el.removeClass('ysh-publish-icon-btn ysh-publish-icon-btn--input ysh-publish-icon-btn--danger');
    $el.addClass('ysh-publish-edit-link');
    $el.html(
      '<span class="dashicons dashicons-edit" aria-hidden="true"></span>' +
        '<span class="screen-reader-text">' +
        label +
        '</span>'
    );
  }

  function styleMiscEditLinks() {
    var labels = publishIconLabels();
    $('.ysh-sidebar-metabox--publish .edit-post-status').each(function () {
      styleMiscEditLink($(this), labels.editStatus || 'Edit status');
    });
    $('.ysh-sidebar-metabox--publish .edit-visibility').each(function () {
      styleMiscEditLink($(this), labels.editVisibility || 'Edit visibility');
    });
    $('.ysh-sidebar-metabox--publish .edit-timestamp').each(function () {
      styleMiscEditLink($(this), labels.editDate || 'Edit publish date');
    });
  }

  function layoutPublishBox() {
    var $submitbox = $('.ysh-sidebar-metabox--publish .submitbox');
    if (!$submitbox.length) {
      return;
    }

    var $major = $('#major-publishing-actions');
    var $misc = $('#misc-publishing-actions');
    var $minor = $('#minor-publishing-actions');
    var $minorPub = $('#minor-publishing');

    var $oldBottom = $submitbox.find('.ysh-publish-bottom-row');
    if ($oldBottom.length) {
      $oldBottom.find('#misc-publishing-actions').each(function () {
        if ($minorPub.length) {
          $minorPub.prepend(this);
        }
      });
      $oldBottom.find('#minor-publishing-actions').each(function () {
        if ($major.length) {
          $major.prepend(this);
        }
      });
      $oldBottom.remove();
    }

    if ($misc.length && !$submitbox.find('.ysh-publish-meta-row').length) {
      var $metaRow = $('<div class="ysh-publish-meta-row" />');
      $metaRow.append($misc);
      if ($minorPub.length) {
        $minorPub.prepend($metaRow);
      } else if ($major.length) {
        $major.before($metaRow);
      }
    }

    if ($minor.length && $major.length && !$minor.closest('#major-publishing-actions').length) {
      $major.prepend($minor);
    }

    if ($major.length && !$major.find('.ysh-publish-footer-toolbar').length) {
      var $toolbar = $('<div class="ysh-publish-footer-toolbar" />');
      $major.children('#delete-action, #publishing-action').appendTo($toolbar);
      if ($toolbar.children().length) {
        $major.append($toolbar);
      }
    }

    $submitbox.data('yshPublishLayout', 1);
  }

  function closePublishMoreMenu() {
    $('.ysh-publish-more-menu').attr('hidden', 'hidden');
    $('.ysh-publish-split__toggle').attr('aria-expanded', 'false');
  }

  function getPublishMoreMenu() {
    return $('#submitdiv .ysh-publish-more-menu').first();
  }

  function ensurePublishMenuOutsideInside($menu) {
    if (!$menu || !$menu.length) {
      return;
    }

    var $submitBox = $('#submitdiv');
    if (!$submitBox.length) {
      return;
    }

    if (!$menu.parent().is($submitBox)) {
      $submitBox.append($menu);
    }

    $menu.addClass('ysh-publish-more-menu--portaled');
  }

  function positionPublishMoreMenu($toggle, $menu) {
    if (!$toggle || !$toggle.length || !$menu || !$menu.length) {
      return;
    }

    var node = $toggle[0];
    var rect = node.getBoundingClientRect();
    var menuWidth = Math.max(200, $menu.outerWidth() || 200);
    var left = rect.right - menuWidth;
    var maxLeft = window.innerWidth - menuWidth - 8;

    if (left > maxLeft) {
      left = maxLeft;
    }
    if (left < 8) {
      left = 8;
    }

    $menu.css({
      position: 'fixed',
      left: left + 'px',
      right: 'auto',
      top: 'auto',
      bottom: window.innerHeight - rect.top + 6 + 'px',
      minWidth: menuWidth + 'px',
      zIndex: 100050
    });
  }

  function reorderPublishMoreMenu($menu) {
    if (!$menu || !$menu.length) {
      return false;
    }

    var desired = [];
    publishMenuOrder.forEach(function (id) {
      if ($menu.children('#' + id).length) {
        desired.push(id);
      }
    });

    var current = [];
    $menu.children().each(function () {
      if (publishMenuOrder.indexOf(this.id) !== -1) {
        current.push(this.id);
      }
    });

    if (current.join('|') === desired.join('|')) {
      return false;
    }

    desired.forEach(function (id) {
      $menu.append($menu.children('#' + id).first());
    });
    return true;
  }

  function setupPublishSplitActions() {
    var $pubAction = $('#publishing-action');
    if (!$pubAction.length) {
      return;
    }

    var labels = publishIconLabels();
    var $saveSlot = $('#save-action');
    var $previewSlot = $('#preview-action');
    var $duplicateSlot = $('#duplicate-action');
    var $save = $('#save-post');
    var $preview = $('#post-preview');
    var $duplicateLink = $('#duplicate-action a');
    var $publish = $('#publish');

    if (!$pubAction.data('yshPublishSplit')) {
      var $split = $('<div class="ysh-publish-split" />');
      var $main = $('<div class="ysh-publish-split__main" />');
      var $toggle = $(
        '<button type="button" class="ysh-publish-split__toggle" aria-haspopup="true" aria-expanded="false" aria-label="' +
          (labels.moreActions || 'More publish actions') +
          '" />'
      );
      $toggle.html('<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>');

      var $menu = $('<div class="ysh-publish-more-menu" hidden />');
      if ($previewSlot.length) {
        $menu.append($previewSlot);
      }
      if ($saveSlot.length) {
        $menu.append($saveSlot);
      }
      if ($duplicateSlot.length) {
        $menu.append($duplicateSlot);
      }

      $split.append($main).append($toggle);
      $pubAction.empty().append($split);
      ensurePublishMenuOutsideInside($menu);
      $pubAction.data('yshPublishSplit', 1);

      if ($publish.length) {
        $main.append($publish);
      }
    }

    var $mainWrap = $pubAction.find('.ysh-publish-split__main').first();
    if ($publish.length && $mainWrap.length && !$publish.closest($mainWrap).length) {
      $mainWrap.append($publish);
    }

    if ($save.length && !$save.data('yshPublishToolbar')) {
      stylePublishToolbarButton(
        $save,
        'draft',
        'dashicons-saved',
        labels.saveDraft || readControlLabel($save, 'Save draft')
      );
    }

    if ($preview.length && !$preview.data('yshPublishToolbar')) {
      stylePublishToolbarButton($preview, 'preview', 'dashicons-visibility', labels.preview || 'Preview');
      $preview.removeClass('button preview');
    }

    if ($duplicateLink.length && !$duplicateLink.data('yshPublishToolbar')) {
      stylePublishToolbarButton(
        $duplicateLink,
        'duplicate',
        'dashicons-admin-page',
        labels.copyDraft || readControlLabel($duplicateLink, 'Copy to a new draft')
      );
    }

    if ($publish.length && !$publish.data('yshPublishToolbar')) {
      var pubLabel = readControlLabel($publish, labels.publish || 'Publish');
      var pubIcon = 'dashicons-yes-alt';
      if (/update/i.test(pubLabel)) {
        pubIcon = 'dashicons-update';
      } else if (/schedule/i.test(pubLabel)) {
        pubIcon = 'dashicons-calendar-alt';
      }
      stylePublishToolbarButton($publish, 'publish', pubIcon, pubLabel);
    }

    var $menu = getPublishMoreMenu();
    if (!$menu.length) {
      $menu = $pubAction.find('.ysh-publish-more-menu').first();
      ensurePublishMenuOutsideInside($menu);
    }
    reorderPublishMoreMenu($menu);
  }

  function enhancePublishUi() {
    if (publishUiMutating) {
      return;
    }

    var $box = $('#submitdiv');
    if (!$box.length) {
      return;
    }

    publishUiMutating = true;
    try {
      $box.addClass('ysh-sidebar-metabox--publish');
      layoutPublishBox();

      var labels = publishIconLabels();
      var $trash = $('#delete-action a');
      if ($trash.length && !$trash.data('yshPublishToolbar')) {
        var trashLabel = readControlLabel($trash, labels.moveTrash || 'Move to trash');
        if (/delete permanently/i.test(trashLabel)) {
          trashLabel = labels.delete || trashLabel;
        }
        stylePublishToolbarButton($trash, 'trash', 'dashicons-trash', trashLabel);
      }

      setupPublishSplitActions();
      styleMiscEditLinks();
    } finally {
      publishUiMutating = false;
    }
  }

  function watchPublishBox() {
    var $box = $('#submitdiv');
    if (!$box.length || typeof MutationObserver === 'undefined' || $box.data('yshPublishObserved')) {
      return;
    }
    $box.data('yshPublishObserved', 1);
    var timer = null;
    new MutationObserver(function () {
      if (publishUiMutating) {
        return;
      }
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(function () {
        if (publishUiMutating) {
          return;
        }
        enhancePublishUi();
      }, 120);
    }).observe($box[0], { childList: true, subtree: true });
  }

  function bindPublishSplitEvents() {
    if (window._yshPublishSplitBound) {
      return;
    }
    window._yshPublishSplitBound = true;

    $(document).on('click', '.ysh-publish-split__toggle', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var $toggle = $(this);
      var $menu = getPublishMoreMenu();
      if (!$menu.length) {
        $menu = $toggle.closest('#publishing-action').find('.ysh-publish-more-menu').first();
        ensurePublishMenuOutsideInside($menu);
      }
      var isOpen = !$menu.is('[hidden]');
      closePublishMoreMenu();
      if (!isOpen && $menu.length) {
        $menu.removeAttr('hidden');
        positionPublishMoreMenu($toggle, $menu);
        $toggle.attr('aria-expanded', 'true');
      }
    });

    $(window).on('resize.yshPublishMenu scroll.yshPublishMenu', function () {
      var $menu = getPublishMoreMenu();
      if ($menu.length && !$menu.is('[hidden]')) {
        var $toggle = $('#publishing-action .ysh-publish-split__toggle').first();
        positionPublishMoreMenu($toggle, $menu);
      }
    });

    $(document).on('click', function (e) {
      if (
        !$(e.target).closest(
          '#publishing-action, .ysh-publish-split__toggle, .ysh-publish-more-menu'
        ).length
      ) {
        closePublishMoreMenu();
      }
    });

    $(document).on('click', '.ysh-publish-more-menu a, .ysh-publish-more-menu .ysh-publish-toolbar-btn__input', function () {
      closePublishMoreMenu();
    });
  }

  function applyTourDark() {
    if (!isDark()) {
      return;
    }
    document
      .querySelectorAll('.tour-kit-frame__container, .tour-kit-frame, .components-elevation')
      .forEach(function (el) {
        el.style.setProperty('background', 'transparent', 'important');
        el.style.setProperty('background-color', 'transparent', 'important');
        el.style.setProperty('box-shadow', 'none', 'important');
        el.style.setProperty('border', 'none', 'important');
      });
    document.querySelectorAll('.woocommerce-tour-kit-step').forEach(function (el) {
      el.style.setProperty('background', '#1a1d23', 'important');
      el.style.setProperty('color', '#cfd6e0', 'important');
      el.style.setProperty('border', '1px solid rgba(255,255,255,0.12)', 'important');
      el.style.setProperty('border-radius', '8px', 'important');
      el.style.setProperty('box-shadow', '0 6px 28px rgba(0,0,0,0.4)', 'important');
    });
    document.querySelectorAll('.woocommerce-tour-kit .components-card').forEach(function (el) {
      el.style.setProperty('box-shadow', 'none', 'important');
      el.style.setProperty('border', 'none', 'important');
    });
    document
      .querySelectorAll(
        '.woocommerce-tour-kit .components-card__footer, .woocommerce-tour-kit-step-navigation, .woocommerce-tour-kit-step-controls'
      )
      .forEach(function (el) {
        el.style.setProperty('background', '#1a1d23', 'important');
        el.style.setProperty('background-color', '#1a1d23', 'important');
        el.style.setProperty('border', 'none', 'important');
        el.style.setProperty('border-top', 'none', 'important');
        el.style.setProperty('opacity', '1', 'important');
        el.style.setProperty('visibility', 'visible', 'important');
      });
    document
      .querySelectorAll('.woocommerce-tour-kit .components-card__divider, .woocommerce-tour-kit hr')
      .forEach(function (el) {
        el.style.setProperty('display', 'none', 'important');
      });
    document.querySelectorAll('.woocommerce-tour-kit-step__heading').forEach(function (el) {
      el.style.setProperty('color', '#d8d3ce', 'important');
    });
    document
      .querySelectorAll(
        '.woocommerce-tour-kit-step__description, .woocommerce-tour-kit-step-navigation__step, .woocommerce-tour-kit-step-navigation__step-count'
      )
      .forEach(function (el) {
        el.style.setProperty('color', '#9aa3b2', 'important');
      });
    document.querySelectorAll('.woocommerce-tour-kit .components-button.is-primary').forEach(function (el) {
      el.style.setProperty('background', '#eda934', 'important');
      el.style.setProperty('color', '#1a1a1a', 'important');
    });
  }

  function $el(id) {
    var node = document.getElementById(id);
    return node ? $(node) : $();
  }

  function moveInto($target, $nodes) {
    $nodes.each(function () {
      var $n = $(this);
      if ($n.length && $n.closest('#ysh-product-editor').length === 0) {
        $target.append($n);
      }
    });
  }

  function ensurePageSection() {
    var $postForm = $('#post');
    var $wrap = $('#wpbody-content > .wrap').first();
    if (!$wrap.length) {
      $wrap = $('.wrap').first();
    }

    var $anchor = $postForm.length ? $postForm : $wrap;
    if (!$anchor.length) {
      return $();
    }

    var $page = $('#ysh-product-editor-page');
    if (!$page.length) {
      $page = $(
        '<section id="ysh-product-editor-page" class="ysh-product-editor-page" aria-label="Product editor" />'
      );
      $anchor.prepend($page);
    } else if ($postForm.length && $page.closest('#post').length === 0) {
      $page.detach();
      $postForm.prepend($page);
    }

    return $page;
  }

  function relocateAutosaveNotice($page) {
    var $notice = $('#local-storage-notice');
    if (!$notice.length) {
      return;
    }

    if (!$page || !$page.length) {
      $page = $('#ysh-product-editor-page');
    }
    if (!$page.length) {
      return;
    }

    $notice.addClass('yp-banner-tooltip-added');

    var $slot = $('#ysh-product-editor-notices');
    if (!$slot.length) {
      $slot = $(
        '<div id="ysh-product-editor-notices" class="ysh-product-editor-notices" aria-live="polite" />'
      );
      $page.prepend($slot);
    } else if ($slot.parent()[0] !== $page[0]) {
      $page.prepend($slot);
    }

    if ($notice.parent()[0] !== $slot[0]) {
      $notice.detach().appendTo($slot);
    }

    if ($notice.hasClass('hidden') || !$notice.is(':visible')) {
      $notice.addClass('hidden').attr('hidden', 'hidden');
    } else {
      $notice.removeAttr('hidden');
    }
  }

  function setupPageHead($page) {
    var $wrap = $('#wpbody-content > .wrap').first();
    if (!$wrap.length) {
      $wrap = $('.wrap').first();
    }
    if (!$page || !$page.length) {
      return;
    }

    var $h1 = $wrap.children('h1').first();
    if (!$h1.length) {
      $h1 = $wrap.find('h1.wp-heading-inline').first();
    }

    var $action = $wrap.children('a.page-title-action').first();
    if (!$action.length) {
      $action = $wrap.find('> a.page-title-action').first();
    }

    if (!$h1.length && !$action.length) {
      return;
    }

    var $head = $('#ysh-product-editor-page-head');
    if (!$head.length) {
      $head = $('<div id="ysh-product-editor-page-head" class="ysh-product-editor__page-head" />');
      $page.prepend($head);
    } else if ($head.parent()[0] !== $page[0]) {
      $page.prepend($head);
    }

    if ($h1.length && !$h1.closest('#ysh-product-editor-page-head').length) {
      $head.append($h1);
    }
    if ($action.length && !$action.closest('#ysh-product-editor-page-head').length) {
      $head.append($action);
    }

    relocateAutosaveNotice($page);
  }

  function tabHasContent(tabId) {
    switch (tabId) {
      case 'content':
        return true;
      case 'product-data':
        return !!document.getElementById('woocommerce-product-data');
      case 'short-description':
        return !!document.getElementById('postexcerpt');
      case 'yoast':
        return !!document.getElementById('wpseo_meta');
      default:
        return true;
    }
  }

  function buildTabs() {
    var tabs = cfg.tabs || [
      { id: 'content', label: 'Title & description' },
      { id: 'product-data', label: 'Product data' },
      { id: 'short-description', label: 'Short description' },
      { id: 'yoast', label: 'Yoast SEO' }
    ];
    // Only show a tab when its metabox is actually present (e.g. hide the Yoast
    // SEO tab when no SEO plugin is installed instead of rendering an empty tab).
    tabs = tabs.filter(function (tab) {
      return tabHasContent(tab.id);
    });
    var $nav = $('<nav class="ysh-product-editor__tabs" role="tablist" />');
    tabs.forEach(function (tab, index) {
      var $btn = $('<button type="button" class="ysh-product-editor__tab" />')
        .attr('data-tab', tab.id)
        .attr('role', 'tab')
        .attr('aria-selected', index === 0 ? 'true' : 'false')
        .text(tab.label || tab.id);
      if (index === 0) {
        $btn.addClass('is-active');
      }
      $nav.append($btn);
    });
    return $nav;
  }

  function activateTab(tabId) {
    $('.ysh-product-editor__tab')
      .removeClass('is-active')
      .attr('aria-selected', 'false')
      .filter('[data-tab="' + tabId + '"]')
      .addClass('is-active')
      .attr('aria-selected', 'true');
    $('.ysh-pe-panel').removeClass('is-active').filter('[data-panel="' + tabId + '"]').addClass('is-active');
    try {
      localStorage.setItem(STORAGE_KEY, tabId);
    } catch (e) {}
    applyEditorTheme();
    refreshEditorsInPanel(tabId);
    if (tabId === 'publish') {
      window.setTimeout(enhancePublishUi, 0);
    }
  }

  function getSidebarTabDefs() {
    var fromCfg = cfg.sidebarTabs || [];
    if (!fromCfg.length) {
      return SIDEBAR_TAB_DEFS.slice();
    }
    return fromCfg.map(function (tab) {
      return {
        id: tab.id,
        label: tab.label || tab.id
      };
    });
  }

  var SKIP_SIDEBAR_BOX_IDS = {
    'woocommerce-product-data': true,
    postexcerpt: true,
    wpseo_meta: true
  };

  function isTopLevelSidebarPostbox($box) {
    return $box.parents('.postbox').length === 0;
  }

  function isMeaningfulSidebarPostbox($box) {
    var id = ($box.attr('id') || '').trim();
    if (!id || SKIP_SIDEBAR_BOX_IDS[id]) {
      return false;
    }
    return isTopLevelSidebarPostbox($box);
  }

  function collectSidebarPostboxes($sidebar) {
    var list = [];
    $sidebar.find('.postbox').each(function () {
      var $box = $(this);
      if (isMeaningfulSidebarPostbox($box)) {
        list.push($box);
      }
    });
    return list;
  }

  function expandSidebarPanelPostboxes($panel) {
    $panel.find('.postbox.closed').removeClass('closed');
    $panel.find('.handlediv').attr('aria-expanded', 'true');
    $panel.find('.postbox > .inside').show();
  }

  function classifySidebarPostbox(id, $box) {
    id = (id || '').toLowerCase();

    if (id === 'submitdiv' || id.indexOf('submit') === 0 || id.indexOf('publish') !== -1) {
      return 'publish';
    }

    if (
      id === 'postimagediv' ||
      id === 'woocommerce-product-images' ||
      /image|gallery|thumbnail|featured/.test(id)
    ) {
      return 'media';
    }

    if (
      id === 'slugdiv' ||
      id === 'postcustom' ||
      /catdiv|tagsdiv|tagsdiv-|taxonomy|brand/.test(id) ||
      /^product_/.test(id) ||
      id.indexOf('product_cat') !== -1 ||
      id.indexOf('product_tag') !== -1
    ) {
      return 'organize';
    }

    if (
      $box.find('.categorydiv, .tagsdiv, .taxonomydiv, .taxonomydiv2').length ||
      $box.find('[class*="categorydiv"], [class*="tagsdiv"], [class*="taxonomydiv"]').length
    ) {
      return 'organize';
    }

    return 'more';
  }

  function setupSidebarTabs($sidebar) {
    if (!$sidebar || !$sidebar.length || $sidebar.data('yshSidebarTabsReady')) {
      return;
    }

    var tabDefs = getSidebarTabDefs();
    var buckets = {};
    tabDefs.forEach(function (tab) {
      buckets[tab.id] = [];
    });

    collectSidebarPostboxes($sidebar).forEach(function ($box) {
      var id = $box.attr('id') || '';
      var group = classifySidebarPostbox(id, $box);
      if (!buckets[group]) {
        group = 'more';
      }
      buckets[group].push($box);
    });

    var activeTabs = tabDefs.filter(function (tab) {
      return buckets[tab.id] && buckets[tab.id].length > 0;
    });

    if (!activeTabs.length) {
      return;
    }

    var $shell = $('<div class="ysh-sidebar-shell" />');
    var $nav = $('<nav class="ysh-sidebar-tabs" role="tablist" aria-label="Product sidebar sections" />');
    var $panels = $('<div class="ysh-sidebar-panels" />');

    activeTabs.forEach(function (tab, index) {
      var $btn = $('<button type="button" class="ysh-sidebar-tab" />')
        .attr('data-sidebar-tab', tab.id)
        .attr('role', 'tab')
        .attr('aria-selected', index === 0 ? 'true' : 'false')
        .text(tab.label || tab.id);
      if (index === 0) {
        $btn.addClass('is-active');
      }
      $nav.append($btn);

      var $panel = $('<div class="ysh-sidebar-panel" />')
        .attr('data-sidebar-panel', tab.id)
        .attr('role', 'tabpanel');
      if (index === 0) {
        $panel.addClass('is-active');
      }

      buckets[tab.id].forEach(function ($box) {
        $panel.append($box);
      });

      $panels.append($panel);
    });

    $sidebar.children().not('.ysh-pe-loader').detach();
    $shell.append($nav, $panels);
    $sidebar.append($shell);

    $nav.on('click', '.ysh-sidebar-tab', function (e) {
      e.preventDefault();
      activateSidebarTab($(this).attr('data-sidebar-tab'));
    });

    var savedSidebar = '';
    try {
      savedSidebar = localStorage.getItem(SIDEBAR_STORAGE_KEY) || '';
    } catch (e3) {}
    expandSidebarPanelPostboxes($panels.find('.ysh-sidebar-panel.is-active').first());

    if (savedSidebar && $nav.find('[data-sidebar-tab="' + savedSidebar + '"]').length) {
      activateSidebarTab(savedSidebar);
    } else {
      activateSidebarTab(activeTabs[0].id);
    }

    $sidebar.data('yshSidebarTabsReady', true);
  }

  function activateSidebarTab(tabId) {
    var $tab = $('.ysh-sidebar-tab').filter('[data-sidebar-tab="' + tabId + '"]');
    var $panel = $('.ysh-sidebar-panel').filter('[data-sidebar-panel="' + tabId + '"]');

    if (!$tab.length || !$panel.length || !$panel.find('.postbox').length) {
      var $first = $('.ysh-sidebar-tab').first();
      if ($first.length) {
        tabId = $first.attr('data-sidebar-tab');
        $tab = $first;
        $panel = $('.ysh-sidebar-panel').filter('[data-sidebar-panel="' + tabId + '"]');
      }
    }

    $('.ysh-sidebar-tab').removeClass('is-active').attr('aria-selected', 'false');
    $tab.addClass('is-active').attr('aria-selected', 'true');
    $('.ysh-sidebar-panel').removeClass('is-active');
    $panel.addClass('is-active');
    expandSidebarPanelPostboxes($panel);

    try {
      localStorage.setItem(SIDEBAR_STORAGE_KEY, tabId);
    } catch (e) {}
  }

  function initLayout() {
    if (!$('body').hasClass('post-type-product')) {
      return false;
    }
    if ($('#ysh-product-editor').length) {
      return true;
    }

    var $post = $('#post');
    var $poststuff = $('#poststuff');
    if (!$post.length || !$poststuff.length) {
      return false;
    }

    var $shell = $('<div id="ysh-product-editor" class="ysh-product-editor"></div>');
    var $workspace = $('<div class="ysh-product-editor__workspace"></div>');
    var $main = $('<div class="ysh-product-editor__main"></div>');
    var $tabs = buildTabs();
    var $panels = $('<div class="ysh-product-editor__panels" />');

    var $panelContent = $('<div class="ysh-pe-panel is-active" data-panel="content" />');
    var $panelData = $('<div class="ysh-pe-panel" data-panel="product-data" />');
    var $panelShort = $('<div class="ysh-pe-panel" data-panel="short-description"></div>');
    var $panelYoast = $('<div class="ysh-pe-panel" data-panel="yoast" />');

    moveInto($panelContent, $('#titlediv'));
    moveInto($panelContent, $('#postdivrich'));

    moveInto($panelData, $el('woocommerce-product-data'));
    moveInto($panelShort, $el('postexcerpt'));
    moveInto($panelYoast, $el('wpseo_meta'));

    if (!$panelContent.children().length) {
      moveInto($panelContent, $('#wp-content-wrap').closest('.postbox, #postdivrich'));
    }

    $panels.append($panelContent, $panelData, $panelShort, $panelYoast);

    $main.append($tabs, $panels);

    var $sidebar = $('<aside class="ysh-product-editor__sidebar" aria-label="Product sidebar" />');
    var $col2 = $('#postbox-container-2');
    if ($col2.length) {
      $sidebar.append($col2);
    }

    var $sideSort = $sidebar.find('.meta-box-sortables').first();
    if (!$sideSort.length) {
      $sideSort = $('<div class="meta-box-sortables" />');
      $sidebar.append($sideSort);
    }
    $('#postbox-container-1 .postbox').each(function () {
      var $box = $(this);
      var id = $box.attr('id') || '';
      if (id === 'woocommerce-product-data' || id === 'postexcerpt' || id === 'wpseo_meta') {
        return;
      }
      $sideSort.append($box);
    });

    setupSidebarTabs($sidebar);

    $workspace.append($main, $sidebar);
    $shell.append($workspace);

    var $page = ensurePageSection();
    if (!$page.length) {
      return false;
    }

    setupPageHead($page);
    $page.append($shell);
    relocateAutosaveNotice($page);
    watchSecondaryPanels();
    fireProductEditorReady();

    var $col1 = $('#postbox-container-1');
    if ($col1.length && $col1.find('.postbox:visible').length === 0) {
      $col1.hide();
    }

    $tabs.on('click', '.ysh-product-editor__tab', function (e) {
      e.preventDefault();
      activateTab($(this).attr('data-tab'));
    });

    var saved = '';
    try {
      saved = localStorage.getItem(STORAGE_KEY) || '';
    } catch (e2) {}
    if (saved && $('.ysh-product-editor__tab[data-tab="' + saved + '"]').length) {
      activateTab(saved);
    }

    enhancePermalinkUi();
    watchPermalinkBox();
    enhancePublishUi();
    bindPublishSplitEvents();
    watchPublishBox();
    watchColorMode();
    applyEditorTheme();
    applyTourDark();
    refreshEditorsInPanel(getActiveTabId());

    if (window.tinymce) {
      window.tinymce.on('AddEditor', function (ed) {
        window.setTimeout(function () {
          applyEditorTheme();
          if (ed && ed.id) {
            Object.keys(EDITOR_IDS_BY_PANEL).forEach(function (panelId) {
              if (EDITOR_IDS_BY_PANEL[panelId].indexOf(ed.id) !== -1) {
                refreshEditorsInPanel(panelId);
              }
            });
          }
        }, 80);
      });
    }

    return true;
  }

  function ensureSecondaryPanels() {
    var pending = false;

    [
      { panel: '.ysh-pe-panel[data-panel="yoast"]', boxId: 'wpseo_meta', tab: 'yoast' },
      { panel: '.ysh-pe-panel[data-panel="short-description"]', boxId: 'postexcerpt', tab: 'short-description' }
    ].forEach(function (pair) {
      var panel = document.querySelector(pair.panel);
      var box = document.getElementById(pair.boxId);
      if (!panel) {
        return;
      }
      if (!box) {
        // Only keep retrying when a tab for this metabox is actually rendered.
        // If the box never existed (e.g. no SEO plugin), its tab was filtered
        // out, so there's nothing to wait for.
        if (document.querySelector('.ysh-product-editor__tab[data-tab="' + pair.tab + '"]')) {
          pending = true;
        }
        return;
      }
      if (box.closest(pair.panel) !== panel) {
        panel.appendChild(box);
      }
    });

    // Postbox chrome (collapse toggle) is hidden in tabs, so force every panel
    // metabox open — a collapsed box would otherwise render an empty tab.
    $('.ysh-pe-panel .postbox.closed').removeClass('closed');
    $('.ysh-pe-panel .postbox > .inside').css('display', '');
    $('.ysh-pe-panel .postbox .handlediv').attr('aria-expanded', 'true');

    return pending;
  }

  function watchSecondaryPanels() {
    if (!ensureSecondaryPanels()) {
      return;
    }
    var attempts = 0;
    var timer = window.setInterval(function () {
      attempts += 1;
      if (!ensureSecondaryPanels() || attempts >= 40) {
        window.clearInterval(timer);
      }
    }, 200);
  }

  function fireProductEditorReady() {
    $(document).trigger('ysh-product-editor-ready');

    if (typeof window.yshSetupProductMediaFields !== 'function') {
      return;
    }

    if (window.yshSetupProductMediaFields()) {
      return;
    }

    var attempts = 0;
    var timer = setInterval(function () {
      attempts += 1;
      if (window.yshSetupProductMediaFields() || attempts >= 40) {
        clearInterval(timer);
      }
    }, 200);
  }

  function watchDom() {
    var noticeTimer = null;

    var obs = new MutationObserver(function () {
      hideWooEmbed();
      applyEditorTheme();
      applyTourDark();
      enhancePermalinkUi();

      if ($('#local-storage-notice').length) {
        if (noticeTimer) {
          clearTimeout(noticeTimer);
        }
        noticeTimer = setTimeout(function () {
          relocateAutosaveNotice($('#ysh-product-editor-page'));
        }, 50);
      }
    });
    obs.observe(document.body, { childList: true, subtree: true });
  }

  function boot() {
    var attempts = 0;
    var maxAttempts = 50;

    mountLoader();
    hideWooEmbed();

    function tryInit() {
      if (initLayout()) {
        hideLoader();
        watchDom();
        return;
      }

      attempts += 1;
      if (attempts < maxAttempts) {
        setTimeout(tryInit, 50);
        return;
      }

      hideLoader();
      watchDom();
    }

    tryInit();
  }

  mountLoader();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(jQuery);
