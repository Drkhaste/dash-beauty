/**
 * WooCommerce Settings — unsaved changes (YOOAdmin-style modal, not browser beforeunload).
 */
(function () {
  'use strict';

  var dirty = false;
  var modalId = 'ysh-wc-settings-leave-modal';
  var pendingHref = null;

  function i18n(key, fallback) {
    var cfg = window.yshWcSettingsGuard || {};
    if (key === 'message' && window.woocommerce_settings_params && window.woocommerce_settings_params.i18n_nav_warning) {
      return window.woocommerce_settings_params.i18n_nav_warning;
    }
    return cfg[key] || fallback;
  }

  function setDirty(next) {
    dirty = !!next;
    if (!dirty) {
      window.onbeforeunload = null;
    }
  }

  function clearNativeUnload() {
    if (dirty) {
      window.onbeforeunload = null;
    }
  }

  function removeModal() {
    var modal = document.getElementById(modalId);
    if (modal && modal.parentNode) {
      modal.parentNode.removeChild(modal);
    }
    document.body.classList.remove('yp-alert-open');
    pendingHref = null;
  }

  function showLeaveModal(href) {
    if (!dirty) {
      if (href) {
        window.location.href = href;
      }
      return;
    }

    pendingHref = href || null;
    removeModal();

    var title = i18n('title', 'Unsaved changes');
    var message = i18n(
      'message',
      'The changes you made may not be saved if you leave this page.'
    );
    var stay = i18n('stay', 'Stay on this page');
    var leave = i18n('leave', 'Leave without saving');

    var html =
      '<div id="' +
      modalId +
      '" class="yp-alert-modal">' +
      '<div class="yp-alert-overlay" data-ysh-wc-leave-close></div>' +
      '<div class="yp-alert-content">' +
      '<div class="yp-alert-header">' +
      '<span class="yp-alert-icon warning dashicons dashicons-warning"></span>' +
      '<h2 class="yp-alert-title">' +
      title +
      '</h2>' +
      '</div>' +
      '<div class="yp-alert-body"><p class="yp-alert-message">' +
      message +
      '</p></div>' +
      '<div class="yp-alert-footer">' +
      '<button type="button" class="yp-alert-btn yp-alert-btn-secondary" data-ysh-wc-leave-close>' +
      stay +
      '</button>' +
      '<button type="button" class="yp-alert-btn yp-alert-btn-primary" data-ysh-wc-leave-confirm>' +
      leave +
      '</button>' +
      '</div>' +
      '</div>' +
      '</div>';

    document.body.insertAdjacentHTML('beforeend', html);
    document.body.classList.add('yp-alert-open');

    var modal = document.getElementById(modalId);
    if (!modal) {
      return;
    }

    modal.querySelectorAll('[data-ysh-wc-leave-close]').forEach(function (el) {
      el.addEventListener('click', removeModal);
    });

    var confirm = modal.querySelector('[data-ysh-wc-leave-confirm]');
    if (confirm) {
      confirm.addEventListener('click', function () {
        var target = pendingHref;
        setDirty(false);
        removeModal();
        if (target) {
          window.location.href = target;
        }
      });
    }
  }

  function shouldInterceptLink(a) {
    if (!a || !a.getAttribute) {
      return false;
    }
    var href = a.getAttribute('href');
    if (!href || href === '#' || href.indexOf('javascript:') === 0) {
      return false;
    }
    if (a.target === '_blank' || a.hasAttribute('download')) {
      return false;
    }
    if (a.closest('.woocommerce-save-button, p.submit, .submit')) {
      return false;
    }
    if (a.classList.contains('woocommerce-save-button')) {
      return false;
    }

    var url;
    try {
      url = new URL(a.href, window.location.href);
    } catch (e) {
      return false;
    }

    var cur = new URL(window.location.href);
    if (url.pathname === cur.pathname && url.search === cur.search) {
      return false;
    }

    return true;
  }

  function bindForm(form) {
    if (!form || form.dataset.yshWcGuardBound) {
      return;
    }
    form.dataset.yshWcGuardBound = '1';

    var prevent = form.querySelector(
      '.wp-list-table .check-column, .wc-settings-prevent-change-event'
    );

    form.addEventListener(
      'change',
      function (e) {
        if (prevent && prevent.contains(e.target)) {
          return;
        }
        setDirty(true);
        clearNativeUnload();
      },
      true
    );

    form.addEventListener(
      'input',
      function (e) {
        if (prevent && prevent.contains(e.target)) {
          return;
        }
        setDirty(true);
        clearNativeUnload();
      },
      true
    );

    form.addEventListener(
      'click',
      function (e) {
        var btn = e.target.closest(
          '.woocommerce-save-button, .submit :input, input#search-submit'
        );
        if (btn) {
          setDirty(false);
        }
      },
      true
    );
  }

  function init() {
    if (!document.body || !document.body.classList.contains('woocommerce_page_wc-settings')) {
      return;
    }
    if (!document.body.classList.contains('yoo-focus')) {
      return;
    }

    var form = document.getElementById('mainform');
    if (form) {
      bindForm(form);
    }

    document.addEventListener(
      'click',
      function (e) {
        if (!dirty) {
          return;
        }
        var a = e.target.closest('a[href]');
        if (!shouldInterceptLink(a)) {
          return;
        }
        e.preventDefault();
        e.stopPropagation();
        clearNativeUnload();
        showLeaveModal(a.href);
      },
      true
    );

    setInterval(clearNativeUnload, 400);

    window.yshWcSettingsClearDirty = function () {
      setDirty(false);
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
