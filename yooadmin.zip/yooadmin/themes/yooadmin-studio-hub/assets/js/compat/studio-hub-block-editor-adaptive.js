/**
 * Studio Hub — adaptive dark mode for Gutenberg + portaled template libraries.
 * Same engine as studio-hub-plugin-admin-adaptive.js (luminance + contrast tiers).
 */
(function () {
  'use strict';

  var ROOT_SELECTORS =
    '#editor, .edit-site, .components-modal__screen, .react-responsive-modal-root';
  var SKIP_TAGS = {
    IMG: 1,
    SVG: 1,
    VIDEO: 1,
    CANVAS: 1,
    IFRAME: 1,
    INPUT: 1,
    TEXTAREA: 1,
    SELECT: 1,
    BUTTON: 1,
    STYLE: 1,
    SCRIPT: 1,
    NOSCRIPT: 1,
    BR: 1,
    HR: 1,
  };
  var TEXT_QUERY =
    'h1,h2,h3,h4,h5,h6,p,span,label,strong,small,b,em,i,li,td,th,dt,dd,figcaption,legend,a,code,pre,kbd';
  var INPUT_QUERY =
    'input[type="search"],input[type="text"],input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]):not([type="submit"]):not([type="button"]),textarea,.components-text-control__input,.components-search-control__input';
  var LIGHT_SURFACE = 0.58;
  var DARK_TEXT_LUM = 0.42;
  var DARK_CANVAS_LUM = 0.52;
  var SURFACE_HINTS =
    '[class*="gutenkit-library"], [class*="gkit-template"], [class*="gutenkit-template"], .react-responsive-modal-modal, ' +
    '.components-modal__content, .components-modal__header, .components-card, ' +
    '.block-editor-inserter__menu, .block-editor-inserter__main-area, .interface-complementary-area, ' +
    '.gutenkit-library-filter, .gutenkit-library-filter__inner, .gutenkit-library-menu, .gutenkit-library-list, ' +
    '.gutenkit-library-body, .gutenkit-library-header, .gutenkit-library-body-content, .search-container, ' +
    '[class*="library-filter"], [class*="library-menu"], [class*="library-list"], [class*="filter-category"], ' +
    '[class*="menu-item"], [class*="list-item-inner"]';
  var debounceTimer = null;
  var fastTimer = null;
  var bodyObserver = null;
  var adaptPass = 0;
  var MAX_PASSES = 12;

  function isDarkMode() {
    var html = document.documentElement;
    return (
      html.getAttribute('data-yooadmin-studio-color-mode-effective') === 'dark' ||
      html.classList.contains('is-dark-theme')
    );
  }

  function isEditorPage() {
    return (
      document.body &&
      (document.body.classList.contains('block-editor-page') ||
        document.body.classList.contains('site-editor-php'))
    );
  }

  function parseRgb(cssColor) {
    if (!cssColor || cssColor === 'transparent') {
      return null;
    }
    var m = cssColor.match(/rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)(?:\s*,\s*([\d.]+))?\s*\)/);
    if (!m) {
      return null;
    }
    return {
      r: parseFloat(m[1]),
      g: parseFloat(m[2]),
      b: parseFloat(m[3]),
      a: m[4] !== undefined ? parseFloat(m[4]) : 1,
    };
  }

  function luminance(r, g, b) {
    function ch(c) {
      c /= 255;
      return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b);
  }

  function getOwnBackgroundLum(el) {
    var rgb = parseRgb(window.getComputedStyle(el).backgroundColor);
    if (!rgb || rgb.a < 0.35) {
      return null;
    }
    return luminance(rgb.r, rgb.g, rgb.b);
  }

  function getTextLum(el) {
    var rgb = parseRgb(window.getComputedStyle(el).color);
    return rgb ? luminance(rgb.r, rgb.g, rgb.b) : 0.5;
  }

  function effectiveBackgroundLum(el, root) {
    var node = el;
    while (node && node !== root && node !== document.documentElement) {
      var lum = getOwnBackgroundLum(node);
      if (lum !== null) {
        return lum;
      }
      node = node.parentElement;
    }
    var rootLum = root ? getOwnBackgroundLum(root) : null;
    return rootLum !== null ? rootLum : 0.1;
  }

  function getAdaptRoots() {
    var roots = [];
    var seen = new Set();
    document.querySelectorAll(ROOT_SELECTORS).forEach(function (el) {
      if (!el || seen.has(el)) {
        return;
      }
      seen.add(el);
      roots.push(el);
    });
    return roots;
  }

  function shouldSkipEl(el) {
    if (!el || el.nodeType !== 1) {
      return true;
    }
    if (SKIP_TAGS[el.tagName]) {
      return true;
    }
    if (el.tagName === 'LABEL') {
      if (el.closest('[class*="gutenkit"], [class*="gkit-"], .react-responsive-modal-root')) {
        return false;
      }
      return true;
    }
    if (el.closest('.ysh-adapt-skip, .editor-header, .edit-post-header, .components-button.is-primary')) {
      return true;
    }
    if (el.classList && el.classList.contains('dashicons')) {
      return true;
    }
    return false;
  }

  function hasMeaningfulText(el) {
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      return false;
    }
    var text = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!text) {
      return false;
    }
    if (el.children.length > 0) {
      var own = '';
      for (var i = 0; i < el.childNodes.length; i++) {
        var n = el.childNodes[i];
        if (n.nodeType === 3) {
          own += n.textContent;
        }
      }
      own = own.replace(/\s+/g, ' ').trim();
      if (!own && el.tagName !== 'A' && !/^H[1-6]$/.test(el.tagName)) {
        return false;
      }
    }
    return true;
  }

  function isSelfTriggeredMutation(mutations) {
    if (!mutations || !mutations.length) {
      return false;
    }
    var i;
    var m;
    var name;
    for (i = 0; i < mutations.length; i++) {
      m = mutations[i];
      if (m.type !== 'attributes') {
        return false;
      }
      name = m.attributeName;
      if (
        name === 'data-ysh-adapt' ||
        name === 'data-ysh-adapt-text' ||
        name === 'data-ysh-adapt-input' ||
        name === 'class'
      ) {
        continue;
      }
      return false;
    }
    return true;
  }

  function clearMarks(root) {
    if (!root) {
      return;
    }
    root.classList.remove('ysh-be-adaptive-active');
    root.querySelectorAll('[data-ysh-adapt], [data-ysh-adapt-text], [data-ysh-adapt-input]').forEach(function (el) {
      el.classList.remove('ysh-adapt-light-bg', 'ysh-adapt-light-nested');
      el.removeAttribute('data-ysh-adapt');
      el.removeAttribute('data-ysh-adapt-text');
      el.removeAttribute('data-ysh-adapt-input');
    });
  }

  function markLightSurfacesFromHints(root) {
    root.querySelectorAll(SURFACE_HINTS).forEach(function (hint) {
      if (shouldSkipEl(hint)) {
        return;
      }
      var lum = getOwnBackgroundLum(hint);
      if (lum === null && hint.closest('[class*="gutenkit"], [class*="gkit-"]')) {
        lum = LIGHT_SURFACE;
      }
      if (lum === null || lum >= LIGHT_SURFACE - 0.14) {
        var r = hint.getBoundingClientRect();
        if (r.width >= 24 && r.height >= 12) {
          hint.classList.add('ysh-adapt-light-bg');
          hint.setAttribute('data-ysh-adapt', 'surface');
        }
      }
    });
  }

  function markLightSurfacesWalk(root) {
    var all = root.querySelectorAll(
      'div, section, aside, ul, ol, li, label, fieldset, button, a, span, [class*="filter"], [class*="menu"], [class*="list-item"]'
    );
    var max = Math.min(all.length, 2800);
    var n;
    for (n = 0; n < max; n++) {
      var el = all[n];
      if (shouldSkipEl(el) || el.classList.contains('ysh-adapt-light-bg')) {
        continue;
      }
      var lum = getOwnBackgroundLum(el);
      if (lum === null || lum < LIGHT_SURFACE) {
        continue;
      }
      var rect = el.getBoundingClientRect();
      if (rect.width < 20 || rect.height < 10) {
        continue;
      }
      el.classList.add('ysh-adapt-light-bg');
      el.setAttribute('data-ysh-adapt', 'surface');
    }
  }

  function classifyTextTier(el) {
    if (el.tagName === 'A') {
      return 'link';
    }
    if (/^H[1-6]$/.test(el.tagName)) {
      return 'heading';
    }
    var cs = window.getComputedStyle(el);
    var fs = parseFloat(cs.fontSize) || 14;
    var fw = parseInt(cs.fontWeight, 10) || 400;
    if (fs <= 11 || cs.fontStyle === 'italic') {
      return 'muted';
    }
    if (fw >= 600) {
      return 'heading';
    }
    return 'body';
  }

  function adaptTypography(root) {
    var nodes = root.querySelectorAll(TEXT_QUERY);
    var i;
    var el;
    var bgLum;
    var textLum;
    var tier;
    var ratio;

    for (i = 0; i < nodes.length; i++) {
      el = nodes[i];
      if (shouldSkipEl(el) || !hasMeaningfulText(el)) {
        continue;
      }

      bgLum = effectiveBackgroundLum(el, root);
      textLum = getTextLum(el);
      tier = null;
      var fsText = parseFloat(window.getComputedStyle(el).fontSize) || 14;

      if (el.closest('.ysh-adapt-light-bg, .ysh-adapt-light-nested')) {
        tier = classifyTextTier(el);
      } else if (bgLum >= LIGHT_SURFACE && textLum >= 0.52) {
        tier = 'on-light';
      } else if (textLum <= DARK_TEXT_LUM && bgLum < DARK_CANVAS_LUM) {
        tier = el.tagName === 'A' ? 'link' : fsText <= 11 ? 'muted' : 'on-dark';
      } else if (bgLum < 0.45 && textLum < 0.45) {
        tier = 'on-dark';
      } else {
        ratio = (Math.max(bgLum, textLum) + 0.05) / (Math.min(bgLum, textLum) + 0.05);
        if (ratio < 4.2) {
          tier = bgLum >= LIGHT_SURFACE ? 'on-light' : 'on-dark';
        }
      }

      if (tier) {
        el.setAttribute('data-ysh-adapt-text', tier);
      }
    }
  }

  function adaptInputs(root) {
    root.querySelectorAll(INPUT_QUERY).forEach(function (el) {
      if (!el || el.closest('.ysh-adapt-skip, .editor-header, .edit-post-header')) {
        return;
      }
      var lum = getOwnBackgroundLum(el);
      if (lum === null || lum >= LIGHT_SURFACE - 0.1) {
        el.setAttribute('data-ysh-adapt-input', 'field');
      } else if (isDarkMode()) {
        el.setAttribute('data-ysh-adapt-input', 'field');
      }
    });
  }

  function adaptRoot(root, fullClear) {
    if (!root) {
      return;
    }
    if (fullClear) {
      clearMarks(root);
    }
    if (!isDarkMode()) {
      return;
    }
    root.classList.add('ysh-be-adaptive-active');
    markLightSurfacesFromHints(root);
    markLightSurfacesWalk(root);
    adaptTypography(root);
    adaptInputs(root);
  }

  function runAdapt(fullClear) {
    if (!isEditorPage()) {
      return;
    }
    var roots = getAdaptRoots();
    if (!isDarkMode()) {
      roots.forEach(clearMarks);
      document.body.classList.remove('ysh-be-adaptive-active');
      adaptPass = 0;
      return;
    }
    document.body.classList.add('ysh-be-adaptive-active');
    roots.forEach(function (root) {
      adaptRoot(root, fullClear);
    });
    adaptPass++;
    if (adaptPass < MAX_PASSES) {
      window.requestAnimationFrame(function () {
        roots.forEach(function (root) {
          adaptRoot(root, false);
        });
      });
    }
  }

  function scheduleAdapt(mutations, fast) {
    if (isSelfTriggeredMutation(mutations)) {
      return;
    }
    if (fast) {
      if (fastTimer) {
        window.clearTimeout(fastTimer);
      }
      fastTimer = window.setTimeout(function () {
        fastTimer = null;
        runAdapt(false);
      }, 40);
      return;
    }
    if (debounceTimer) {
      window.clearTimeout(debounceTimer);
    }
    debounceTimer = window.setTimeout(function () {
      debounceTimer = null;
      runAdapt(true);
    }, 100);
  }

  function watch() {
    if (bodyObserver) {
      return;
    }
    bodyObserver = new MutationObserver(function (mutations) {
      var urgent = false;
      var i;
      for (i = 0; i < mutations.length; i++) {
        var m = mutations[i];
        if (m.type !== 'childList') {
          continue;
        }
        var j;
        for (j = 0; j < m.addedNodes.length; j++) {
          var node = m.addedNodes[j];
          if (node.nodeType !== 1) {
            continue;
          }
          if (
            node.matches &&
            (node.matches('.react-responsive-modal-root, [class*="gutenkit"]') ||
              (node.querySelector &&
                node.querySelector('.react-responsive-modal-root, [class*="gutenkit-library"]')))
          ) {
            urgent = true;
            break;
          }
        }
        if (urgent) {
          break;
        }
      }
      scheduleAdapt(mutations, urgent);
    });
    bodyObserver.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class', 'style', 'hidden', 'aria-hidden'],
    });
    new MutationObserver(function (mutations) {
      adaptPass = 0;
      scheduleAdapt(mutations, true);
    }).observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['data-yooadmin-studio-color-mode-effective', 'class'],
    });
  }

  function boot() {
    if (!isEditorPage()) {
      return;
    }
    runAdapt(true);
    watch();
    document.addEventListener('ysh-studio-color-mode-changed', function () {
      adaptPass = 0;
      runAdapt(true);
    });
    window.addEventListener('load', function () {
      adaptPass = 0;
      runAdapt(true);
    });
  }

  window.yshBlockEditorAdapt = runAdapt;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
