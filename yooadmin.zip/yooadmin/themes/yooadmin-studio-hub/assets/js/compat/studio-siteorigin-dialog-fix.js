/**
 * SiteOrigin Page Builder — overlay click-through + dark surfaces (hover-safe, no flash).
 * CSS owns steady-state paint; JS only patches dynamic nodes once per dialog open.
 */
(function () {
  'use strict';

  var CARD_BG = '#22262e';
  var CARD_HOVER = '#2a3040';
  var CARD_TEXT = '#cfd6e0';
  var CONTENT_BG = '#1a1d23';
  var PAINTED = 'data-ysh-so-painted';
  var PAINT_PROPS = [
    'background',
    'background-color',
    'color',
    '-webkit-text-fill-color',
    'border-color',
    'box-shadow',
    'text-shadow',
    'transition',
    'opacity',
    'pointer-events',
    'cursor',
    'text-decoration',
    'z-index'
  ];

  function isDark() {
    var html = document.documentElement;
    if (html.getAttribute('data-yooadmin-studio-color-mode-effective') === 'dark') {
      return true;
    }
    if (html.classList.contains('is-dark-theme')) {
      return true;
    }
    if (document.body && document.body.classList.contains('is-dark-theme')) {
      return true;
    }
    var mode = html.getAttribute('data-yooadmin-studio-color-mode');
    if (mode === 'dark') {
      return true;
    }
    if (mode === 'auto') {
      try {
        return window.matchMedia('(prefers-color-scheme: dark)').matches;
      } catch (e) {
        return false;
      }
    }
    return false;
  }

  function paintSurface(el, bg, text) {
    if (!el || el.nodeType !== 1 || el.matches('img, svg, iframe, canvas, video')) {
      return;
    }
    if (el.getAttribute(PAINTED) === '1') {
      return;
    }
    el.style.setProperty('background', bg, 'important');
    el.style.setProperty('background-color', bg, 'important');
    el.style.setProperty('color', text, 'important');
    el.style.setProperty('-webkit-text-fill-color', text, 'important');
    el.style.setProperty('border-color', 'rgba(255,255,255,0.12)', 'important');
    el.style.setProperty('box-shadow', 'none', 'important');
    el.style.setProperty('text-shadow', 'none', 'important');
    el.style.setProperty('transition', 'none', 'important');
    el.setAttribute(PAINTED, '1');
  }

  function fixOverlayStacking() {
    document.querySelectorAll('.so-overlay').forEach(function (overlay) {
      overlay.style.setProperty('z-index', '100049', 'important');
      overlay.style.setProperty('pointer-events', 'none', 'important');
    });

    document
      .querySelectorAll(
        '.so-panels-dialog .so-content, .so-panels-dialog .so-title-bar, .so-panels-dialog .so-left-sidebar, .so-panels-dialog .so-right-sidebar, .so-panels-dialog .so-toolbar'
      )
      .forEach(function (pane) {
        pane.style.setProperty('z-index', '100052', 'important');
        pane.style.setProperty('pointer-events', 'auto', 'important');
      });

    var yoast = document.getElementById('wpseo_meta');
    if (yoast) {
      yoast.style.setProperty('z-index', 'auto', 'important');
      yoast.style.setProperty('pointer-events', 'none', 'important');
    }
  }

  function clearPaint(el) {
    if (!el || el.nodeType !== 1) {
      return;
    }

    PAINT_PROPS.forEach(function (prop) {
      el.style.removeProperty(prop);
    });
    el.removeAttribute(PAINTED);
  }

  function unpaintAll() {
    document.querySelectorAll('[' + PAINTED + '="1"]').forEach(clearPaint);

    document.querySelectorAll('[data-ysh-so-dialog-done]').forEach(function (el) {
      el.removeAttribute('data-ysh-so-dialog-done');
    });
    document.querySelectorAll('[data-ysh-so-sidebar-done]').forEach(function (el) {
      el.removeAttribute('data-ysh-so-sidebar-done');
    });

    document.querySelectorAll('.so-overlay').forEach(clearPaint);
    document
      .querySelectorAll(
        '.so-panels-dialog .so-content, .so-panels-dialog .so-title-bar, .so-panels-dialog .so-left-sidebar, .so-panels-dialog .so-right-sidebar, .so-panels-dialog .so-toolbar'
      )
      .forEach(clearPaint);

    restoreYoast();
  }

  function restoreYoast() {
    if (document.querySelector('.so-panels-dialog')) {
      return;
    }
    var yoast = document.getElementById('wpseo_meta');
    if (yoast) {
      yoast.style.removeProperty('pointer-events');
      yoast.style.removeProperty('z-index');
    }
  }

  function styleTextNodes(root, color) {
    root.querySelectorAll('h3, h4, small, span, p, label').forEach(function (el) {
      if (el.matches('img, svg') || el.getAttribute(PAINTED) === '1') {
        return;
      }
      el.style.setProperty('color', color, 'important');
      el.style.setProperty('-webkit-text-fill-color', color, 'important');
      el.style.setProperty('text-shadow', 'none', 'important');
      el.setAttribute(PAINTED, '1');
    });
  }

  function fixClickableCard(card) {
    if (!card || card.nodeType !== 1) {
      return;
    }
    paintSurface(card, CARD_BG, CARD_TEXT);
    card.style.setProperty('opacity', '1', 'important');
    card.style.setProperty('pointer-events', 'auto', 'important');
    card.style.setProperty('cursor', 'pointer', 'important');
    styleTextNodes(card, CARD_TEXT);
    card.querySelectorAll('.widget-icon').forEach(function (icon) {
      icon.style.setProperty('color', CARD_TEXT, 'important');
      icon.style.setProperty('opacity', '1', 'important');
      icon.setAttribute(PAINTED, '1');
    });
  }

  function fixBuilderWidget(widget) {
    if (!widget || widget.nodeType !== 1) {
      return;
    }
    paintSurface(widget, CARD_BG, CARD_TEXT);
    widget.querySelectorAll('.so-widget-wrapper, h4, small, .title').forEach(function (child) {
      if (child.matches('img, svg')) {
        return;
      }
      paintSurface(child, CARD_BG, child.matches('small, h4 span') ? '#9aa5b1' : '#e8ecf1');
    });
  }

  function fixVisualStyles(root) {
    if (!root || root.nodeType !== 1) {
      return;
    }

    paintSurface(root, CONTENT_BG, CARD_TEXT);
    root.querySelectorAll('.style-section-head, .style-section-fields, .style-field-wrapper, .style-field, .style-input-wrapper, .so-wp-slider-wrapper, .so-wp-slider-value, .style-field-measurement').forEach(function (el) {
      paintSurface(el, CARD_BG, CARD_TEXT);
    });
    root.querySelectorAll('h3, h4, label, .style-section-head h4').forEach(function (el) {
      el.style.setProperty('color', '#e8ecf1', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#e8ecf1', 'important');
      el.style.setProperty('text-shadow', 'none', 'important');
      el.setAttribute(PAINTED, '1');
    });
    root.querySelectorAll('p, span, small, .description').forEach(function (el) {
      el.style.setProperty('color', '#9aa5b1', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#9aa5b1', 'important');
      el.setAttribute(PAINTED, '1');
    });
  }

  function fixRightSidebar(sidebar) {
    if (!sidebar || sidebar.nodeType !== 1 || sidebar.getAttribute('data-ysh-so-sidebar-done') === '1') {
      return;
    }

    paintSurface(sidebar, CONTENT_BG, CARD_TEXT);
    sidebar.querySelectorAll('.so-sidebar, .so-visual-styles').forEach(function (el) {
      paintSurface(el, CONTENT_BG, CARD_TEXT);
    });
    sidebar.querySelectorAll('.so-visual-styles').forEach(fixVisualStyles);
    sidebar.setAttribute('data-ysh-so-sidebar-done', '1');
  }

  function fixRowDialog(dialog) {
    dialog.querySelectorAll('.so-toolbar, .so-row-preview, .so-cells-preview, .cell, .cell-wrapper').forEach(function (el) {
      paintSurface(el, el.classList.contains('so-toolbar') ? CARD_BG : '#2a3040', CARD_TEXT);
    });
  }

  function fixDialogDark(dialog) {
    if (!isDark() || !dialog || dialog.getAttribute('data-ysh-so-dialog-done') === '1') {
      return;
    }

    dialog
      .querySelectorAll('.so-content, .so-title-bar, .so-left-sidebar, .so-right-sidebar, .so-toolbar')
      .forEach(function (el) {
        paintSurface(el, CONTENT_BG, CARD_TEXT);
      });

    dialog.querySelectorAll('.so-title-bar, .so-title-bar a, .so-title-bar h3').forEach(function (el) {
      paintSurface(el, CARD_BG, '#e8ecf1');
    });

    dialog.querySelectorAll('.widget-type-wrapper').forEach(fixClickableCard);
    dialog.querySelectorAll('.so-widgets a.so-widget, .so-widgets a[class*="widget"]').forEach(function (anchor) {
      fixClickableCard(anchor);
      anchor.style.setProperty('text-decoration', 'none', 'important');
    });

    dialog.querySelectorAll('.so-right-sidebar').forEach(fixRightSidebar);
    dialog.querySelectorAll('.so-visual-styles').forEach(fixVisualStyles);
    fixRowDialog(dialog);
    dialog.setAttribute('data-ysh-so-dialog-done', '1');
  }

  function fixBuilderDark() {
    if (!isDark()) {
      return;
    }
    var builder = document.querySelector('.siteorigin-panels-builder');
    if (!builder) {
      return;
    }
    builder.querySelectorAll('.so-widget').forEach(fixBuilderWidget);
  }

  function scan() {
    if (!isDark()) {
      unpaintAll();
      return;
    }

    var hasDialog = !!document.querySelector('.so-panels-dialog');
    if (hasDialog) {
      fixOverlayStacking();
      if (isDark()) {
        document.querySelectorAll('.so-panels-dialog').forEach(fixDialogDark);
      }
    } else {
      restoreYoast();
    }
    fixBuilderDark();
  }

  function onDialogAdded() {
    scan();
    if (isDark()) {
      window.requestAnimationFrame(scan);
    }
  }

  function boot() {
    scan();

    if (typeof MutationObserver === 'undefined') {
      return;
    }

    var obs = new MutationObserver(function (mutations) {
      var dialogAdded = false;
      mutations.forEach(function (m) {
        if (!m.addedNodes || !m.addedNodes.length) {
          return;
        }
        m.addedNodes.forEach(function (node) {
          if (node.nodeType !== 1) {
            return;
          }
          if (
            node.matches &&
            (node.matches('.so-panels-dialog') ||
              node.matches('.so-overlay') ||
              (node.querySelector && node.querySelector('.so-panels-dialog')))
          ) {
            dialogAdded = true;
          }
        });
      });
      if (dialogAdded) {
        onDialogAdded();
      }
    });
    obs.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  document.addEventListener('ysh-studio-color-mode-changed', scan);

  document.addEventListener(
    'mouseover',
    function (e) {
      if (!isDark() || !(e.target instanceof Element)) {
        return;
      }
      var widget = e.target.closest('.siteorigin-panels-builder .so-widget');
      if (!widget) {
        return;
      }
      paintSurface(widget, CARD_HOVER, '#e8ecf1');
    },
    true
  );
})();
