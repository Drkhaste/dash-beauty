/**
 * WooCommerce Settings — layout boot, grid mode, YOOAdmin-style tooltips.
 */
(function () {
  'use strict';

  var SKIP = {
    shipping: 1,
    checkout: 1,
    email: 1,
    'site-visibility': 1,
    'point-of-sale': 1,
  };

  function shouldSkipLayoutNode(node) {
    if (!node || !node.matches) {
      return true;
    }
    if (
      node.matches(
        'nav.nav-tab-wrapper, ul.subsubsub, h1.screen-reader-text, .ysh-wc-settings-body, p.submit'
      )
    ) {
      return true;
    }
    if (node.matches('br.clear')) {
      return true;
    }
    if (node.matches('.notice:empty, .woocommerce-message:empty')) {
      return true;
    }
    return false;
  }

  function sectionHasContent(section) {
    if (!section || !section.children.length) {
      return false;
    }
    if (
      section.querySelector(
        '.form-table, table, h2, h3.wc-settings-sub-title, select, input:not([type="hidden"]), textarea, .button, .notice, .woocommerce-message, p.wc-settings-marketplace-link, img, [id$="_slotfill"], [id*="_slotfill"]'
      )
    ) {
      return true;
    }
    return (
      String(section.textContent || '')
        .replace(/\s+/g, ' ')
        .trim().length > 0
    );
  }

  function tabSlug() {
    try {
      return new URLSearchParams(window.location.search).get('tab') || 'general';
    } catch (e) {
      return 'general';
    }
  }

  function shouldLayout() {
    var b = document.body;
    if (!b || b.className.indexOf('yooadmin-theme-yooadmin-studio-hub') === -1) {
      return false;
    }
    if (!b.classList.contains('yoo-focus')) {
      return false;
    }
    if (b.className.indexOf('woocommerce_page_wc-settings') === -1) {
      return false;
    }
    if (b.classList.contains('woocommerce-settings-payments-tab')) {
      return false;
    }
    return !SKIP[tabSlug()];
  }

  function markReady() {
    document.documentElement.classList.remove('ysh-wc-settings-pending');
    document.documentElement.classList.add('ysh-wc-settings-ready');
  }

  function destroyTipTip(el) {
    if (!el || !window.jQuery || !window.jQuery.fn || !window.jQuery.fn.tipTip) {
      return;
    }
    try {
      window.jQuery(el).tipTip('destroy');
    } catch (e) {
      /* noop */
    }
  }

  function stripHtml(html) {
    var tmp = document.createElement('div');
    tmp.innerHTML = html;
    return String(tmp.textContent || tmp.innerText || '').trim();
  }

  function createYooHelpIcon(tipHtml) {
    var wrap = document.createElement('span');
    wrap.className = 'yp-help-icon ysh-wc-help-icon';
    wrap.setAttribute('tabindex', '0');
    wrap.setAttribute('role', 'button');

    var plain = stripHtml(tipHtml);
    if (plain) {
      wrap.setAttribute('aria-label', plain);
    }

    var icon = document.createElement('span');
    icon.className = 'dashicons dashicons-editor-help';
    icon.setAttribute('aria-hidden', 'true');

    var tooltip = document.createElement('span');
    tooltip.className = 'yp-tooltip ysh-wc-settings-tooltip';
    tooltip.innerHTML = tipHtml;

    wrap.appendChild(icon);
    wrap.appendChild(tooltip);
    return wrap;
  }

  function getHelpTipText(el) {
    if (!el) {
      return '';
    }
    return (
      el.getAttribute('data-tip') ||
      el.getAttribute('aria-label') ||
      el.getAttribute('title') ||
      ''
    );
  }

  function upgradeHelpTip(el) {
    if (!el || el.classList.contains('yp-help-icon')) {
      return null;
    }
    if (el.classList.contains('ysh-wc-help-upgraded') || el.closest('.yp-help-icon')) {
      return null;
    }

    var tip = getHelpTipText(el);
    if (!tip) {
      return null;
    }

    destroyTipTip(el);

    var wrap = createYooHelpIcon(tip);
    wrap.classList.add('ysh-wc-help-upgraded');

    var label = el.closest('label');
    var th = el.closest('th');
    var td = el.closest('td');
    var host = el.closest('.help-tooltip');

    if (host && host.parentNode) {
      host.parentNode.removeChild(host);
    } else if (el.parentNode) {
      el.parentNode.removeChild(el);
    }

    if (label) {
      label.appendChild(wrap);
    } else if (th) {
      th.appendChild(wrap);
    } else if (td) {
      td.insertBefore(wrap, td.firstChild);
    }

    bindHelpIcon(wrap);
    return wrap;
  }

  function upgradeWcHelpTips(root) {
    var scope = root || document;
    var tips = scope.querySelectorAll('.woocommerce-help-tip');
    var i;
    var upgraded = 0;
    for (i = 0; i < tips.length; i++) {
      if (upgradeHelpTip(tips[i])) {
        upgraded += 1;
      }
    }
    if (upgraded && document.body) {
      document.body.classList.add('ysh-wc-tips-yoo');
    }
    var icons = scope.querySelectorAll('.yp-help-icon.ysh-wc-help-upgraded');
    var j;
    for (j = 0; j < icons.length; j++) {
      bindHelpIcon(icons[j]);
    }
  }

  function positionYooTooltip(icon, tooltip) {
    if (!icon || !tooltip) {
      return;
    }

    tooltip.style.setProperty('position', 'fixed', 'important');
    tooltip.style.setProperty('transform', 'none', 'important');
    tooltip.style.setProperty('margin', '0', 'important');
    tooltip.style.setProperty('z-index', '9999999', 'important');
    tooltip.style.setProperty('bottom', 'auto', 'important');

    var iconRect = icon.getBoundingClientRect();
    var tooltipWidth = 320;
    var tooltipHeight = tooltip.offsetHeight || 80;
    var left = iconRect.left + iconRect.width / 2 - tooltipWidth / 2;
    var top = iconRect.top - tooltipHeight - 8;

    if (left < 20) {
      left = 20;
    }
    if (left + tooltipWidth > window.innerWidth - 20) {
      left = window.innerWidth - tooltipWidth - 20;
    }
    if (top < 20) {
      top = iconRect.bottom + 8;
    }

    tooltip.style.setProperty('left', left + 'px', 'important');
    tooltip.style.setProperty('top', top + 'px', 'important');
  }

  function showYooTooltip(icon) {
    var tooltip = icon._yshTooltipNode || icon.querySelector('.yp-tooltip');
    if (!tooltip) {
      return;
    }

    icon._yshTooltipNode = tooltip;
    if (tooltip.parentNode !== document.body) {
      document.body.appendChild(tooltip);
    }

    icon.classList.add('ysh-wc-tip-visible');
    tooltip.classList.add('ysh-wc-tip-visible');
    positionYooTooltip(icon, tooltip);
  }

  function hideYooTooltip(icon) {
    var tooltip = icon._yshTooltipNode || icon.querySelector('.yp-tooltip');
    if (!tooltip) {
      return;
    }

    icon.classList.remove('ysh-wc-tip-visible');
    tooltip.classList.remove('ysh-wc-tip-visible');

    if (tooltip.parentNode === document.body) {
      icon.appendChild(tooltip);
    }
  }

  function bindHelpIcon(icon) {
    if (!icon || icon.dataset.yshTipBound === '1') {
      return;
    }
    icon.dataset.yshTipBound = '1';

    icon.addEventListener('mouseenter', function () {
      showYooTooltip(icon);
    });
    icon.addEventListener('mouseleave', function () {
      hideYooTooltip(icon);
    });
    icon.addEventListener('focus', function () {
      showYooTooltip(icon);
    });
    icon.addEventListener('blur', function () {
      hideYooTooltip(icon);
    });
  }

  function applyWcSettingsGridMode(body) {
    if (!body) {
      return;
    }
    var sections = body.querySelectorAll(
      '.ysh-wc-settings-section:not(.ysh-wc-settings-section--misc):not(.ysh-wc-settings-section--wide)'
    );
    var multi = sections.length > 1;
    body.classList.toggle('ysh-wc-settings-body--single', !multi);
    body.classList.toggle('ysh-wc-settings-body--multi', multi);
  }

  function finalizeWcSettingsLayout(form) {
    if (!form) {
      return;
    }
    var body = form.querySelector('.ysh-wc-settings-body');
    if (body) {
      applyWcSettingsGridMode(body);
    }
    upgradeWcHelpTips(form);
  }

  function enhance() {
    if (!shouldLayout()) {
      document.body.classList.remove('ysh-wc-settings-classic-layout');
      markReady();
      return;
    }

    var form = document.getElementById('mainform');
    if (!form) {
      markReady();
      return;
    }

    if (!form.querySelector('.ysh-wc-settings-body')) {
      var contentNodes = [];
      var i;
      var ch;
      for (i = 0; i < form.children.length; i++) {
        ch = form.children[i];
        if (!ch.matches) {
          continue;
        }
        if (shouldSkipLayoutNode(ch)) {
          continue;
        }
        contentNodes.push(ch);
      }

      if (contentNodes.length) {
        var body = document.createElement('div');
        body.className = 'ysh-wc-settings-body';
        var section = null;
        var misc = document.createElement('div');
        misc.className = 'ysh-wc-settings-section ysh-wc-settings-section--misc';
        var n;
        var node;

        for (n = 0; n < contentNodes.length; n++) {
          node = contentNodes[n];
          if (node.matches('h2, h3.wc-settings-sub-title')) {
            if (section) {
              body.appendChild(section);
            }
            section = document.createElement('div');
            section.className = 'ysh-wc-settings-section';
            section.appendChild(node);
          } else if (section) {
            section.appendChild(node);
          } else {
            misc.appendChild(node);
          }
        }

        if (section) {
          body.appendChild(section);
        }
        if (misc.children.length && sectionHasContent(misc)) {
          body.insertBefore(misc, body.firstChild);
        }

        if (body.children.length) {
          var wideSel =
            '.wp-list-table, table.wc-shipping-zones, #webhooks, .wc_webhooks, .wc-shipping-zone-methods, .wc-shipping-classes';
          var sections = body.querySelectorAll('.ysh-wc-settings-section');
          var s;
          for (s = 0; s < sections.length; s++) {
            if (sections[s].querySelector(wideSel)) {
              sections[s].classList.add('ysh-wc-settings-section--wide');
            }
          }

          var anchor = form.querySelector('ul.subsubsub') || form.querySelector('nav.nav-tab-wrapper');
          if (anchor) {
            anchor.parentNode.insertBefore(body, anchor.nextSibling);
          } else {
            form.insertBefore(body, form.firstChild);
          }
          form.dataset.yshWcLayout = '1';
        }
      }
    }

    document.body.classList.add('ysh-wc-settings-classic-layout');
    finalizeWcSettingsLayout(form);
    markReady();

    if (window.jQuery) {
      window.jQuery(function () {
        finalizeWcSettingsLayout(form);
      });
      window.jQuery(document.body).on('init_tooltips', function () {
        upgradeWcHelpTips(form);
        window.jQuery('#tiptip_holder').remove();
      });
    } else {
      document.addEventListener(
        'DOMContentLoaded',
        function () {
          finalizeWcSettingsLayout(form);
        },
        { once: true }
      );
    }
  }

  if (document.body) {
    enhance();
  } else {
    document.addEventListener('DOMContentLoaded', enhance, { once: true });
  }

  window.yshWcSettingsEnhanceLayout = enhance;
})();
