/**
 * WooCommerce legacy reports — ensure Flot charts get a valid width before plot.
 */
(function ($) {
  'use strict';

  function ensureChartLayout() {
    var $inside = $('.woocommerce-reports-wide .inside.chart-with-sidebar, .woocommerce-reports-wrap .inside.chart-with-sidebar');
    if ($inside.length) {
      $inside.css({
        display: 'flex',
        width: '100%'
      });
    }

    var $main = $('.chart-with-sidebar .main');
    if ($main.length) {
      $main.css({
        flex: '1 1 auto',
        minWidth: '0',
        width: '100%',
        float: 'none',
        margin: 0
      });
    }

    $('.chart-with-sidebar .chart-sidebar').css({
      width: '260px',
      minWidth: '260px',
      maxWidth: '260px',
      margin: 0,
      float: 'none'
    });

    $('.chart-container').css({
      width: '100%',
      maxWidth: '100%',
      minWidth: '0',
      float: 'none'
    });

    $('.chart-placeholder.main, .chart-placeholder').each(function () {
      var $ph = $(this);
      if ($ph.hasClass('pie-chart')) {
        return;
      }
      $ph.css({
        width: '100%',
        maxWidth: '100%',
        minWidth: '280px',
        minHeight: '380px',
        height: '400px',
        display: 'block'
      });
    });
  }

  function triggerChartResize() {
    ensureChartLayout();
    if ($.fn && $('.chart-placeholder').length) {
      $('.chart-placeholder').trigger('resize');
    }
  }

  function patchFlotPlot() {
    if (!$.plot || $.plot.__yshWcReportsPatched) {
      return;
    }

    var original = $.plot;
    $.plot = function (placeholder, data, options) {
      var $ph = $(placeholder);
      if ($ph.length && $ph.width() < 10) {
        ensureChartLayout();
        $ph.css('width', '100%');
      }
      return original.apply(this, arguments);
    };
    $.plot.__yshWcReportsPatched = true;
  }

  function init() {
    patchFlotPlot();
    ensureChartLayout();
    $(window).on('load', triggerChartResize);
    $(window).on('resize', function () {
      window.clearTimeout(window.__yshWcReportsResizeTimer);
      window.__yshWcReportsResizeTimer = window.setTimeout(triggerChartResize, 120);
    });
    setTimeout(triggerChartResize, 50);
    setTimeout(triggerChartResize, 300);
    setTimeout(triggerChartResize, 800);
  }

  $(init);
})(jQuery);
