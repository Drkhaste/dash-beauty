/**
 * Studio Hub — adaptive dark mode for third-party plugin admin.
 * Detects surface luminance + text contrast; marks nodes for studio-hub-plugin-admin-adaptive.css.
 */
(function () {
  'use strict';

  var ROOT_WRAP = '#wpbody-content > .wrap';
  var NATIVE_WRAP =
    'yooadmin-posts-page|yooadmin-pages-page|yooadmin-plugins-page|yooadmin-media-page|yooadmin-users-page|yooadmin-enable-focus-page|yooadmin-license-page|yooadmin-user-profile|yooadmin-tags-page|yooadmin-categories-page|yooadmin-user-create|yooadmin-extensions-page|yooadmin-extensions-manager|yooadmin-settings-wrap|yooadmin-plugin-install-page';
  var NATIVE_RE = new RegExp('\\b(' + NATIVE_WRAP.replace(/-/g, '\\-') + ')\\b');
  var SKIP_TAGS = {
    IMG: 1,
    SVG: 1,
    VIDEO: 1,
    CANVAS: 1,
    IFRAME: 1,
    INPUT: 1,
    TEXTAREA: 1,
    SELECT: 1,
    BUTTON: 1,
    /* LABEL handled in shouldSkipEl — interactive labels need typography */
    STYLE: 1,
    SCRIPT: 1,
    NOSCRIPT: 1,
    BR: 1,
    HR: 1,
  };
  var TEXT_QUERY =
    'h1,h2,h3,h4,h5,h6,p,span,label,strong,small,b,em,i,li,td,th,dt,dd,figcaption,legend,a,code,pre,kbd, ' +
    '[class*="title"], [class*="Title"], [class*="heading"], [class*="Heading"], ' +
    '[class*="text"], [class*="Text"], [class*="label"], [class*="Label"], ' +
    '[class*="description"], [class*="Description"], [class*="message"], [class*="Message"], ' +
    '[class*="empty"], [class*="Empty"], [class*="notice"], [class*="Notice"], [class*="content"], [class*="Content"], ' +
    '[data-wp-component="Card"] div, [data-wp-component="Card"] span, .components-card div, .components-card span';
  var BTN_QUERY =
    'button, input[type="button"], input[type="submit"], input[type="reset"], .button, ' +
    '[class*="__dual-button"] button, [class*="button"]:not([class*="button-group"]):not([class*="buttons"])';
  var REACT_BTN_QUERY =
    '[class*="__dual-button"] button, [class*="__settings-api"] button, [class*="__settings-api__"] button, '
    + '[class*="__settings-global-css"] button, [class*="__settings-advanced"] button, '
    + 'button[class*="__settings"], [class*="__settings-api__content-button"]';
  var reactButtonsTimer = null;
  var darkModeSettleTimer = null;
  var darkModeSettleRun = 0;
  var INTERACTIVE_QUERY =
    '[class*="toggle-row"], [class*="category__toggle"], [class*="__blocks-list__item"], ' +
    '[class*="__settings-list"] li, [class*="__welcome__cards-item"], [class*="__cards-item"], ' +
    '[id$="-editor-tabs"] button';
  var DENSE_GRID_QUERY = '[class*="__blocks-list__item"], [class*="__cards-item"]';
  var DENSE_GRID_MIN = 28;
  var TYPOGRAPHY_MAX_NODES = 900;
  var INTERACTIVE_MAX_NODES = 48;
  var PORTAL_OBS_SELECTOR =
    '[role="dialog"], [class*="-modal"], .media-modal, .media-frame, #TB_window, .thickbox-loading';
  var LIGHT_SURFACE = 0.58;
  var DARK_TEXT_LUM = 0.42;
  var DARK_CANVAS_LUM = 0.52;
  var MIN_PANEL_W = 48;
  var MIN_PANEL_H = 20;
  var SURFACE_HINTS =
    '.notice, .update-nag, .updated, .error, .welcome-panel, .card, ' +
    '.postbox, .stuffbox, fieldset, .inside, .metabox-holder, .form-table, ' +
    '[class*="__header"], [class*="-header"], [class*="Header"], [class*="__footer"], [class*="-footer"], [class*="Footer"], ' +
    '[class*="__welcome"], [class*="__welcome__content"], [class*="__welcome__content-subscribe"], ' +
    '[class*="__welcome__content-video"], [class*="__content-subscribe"], [class*="__content-video"], ' +
    '[class*="__cards-item"], [class*="__blocks-list__item"], [class*="__settings-list"], [class*="__settings-content"], [class*="__section"], ' +
    '[class*="panel"], [class*="Panel"], [class*="card"], [class*="Card"], [class*="settings"], [class*="Settings"], ' +
    '.components-card, .components-surface, [data-wp-component="Card"], .components-panel__body, [class*="-admin-dashboard"], ' +
    '' +
    '[id$="-editor"], [id$="-editor-tabs"], [class*="-editor-panel"], #submitdiv, #informationdiv, ' +
    '[class*="-card-header"], [class*="-card-body"], [class*="-page-checkboxes"], [class*="-radio-item"], ' +
    '[class*="-settings-section"], [class*="-pro-teaser"], [class*="-pro-teasers"], ' +
    '[class*="-banner"], [class*="-callout"], [class*="-promo"], [class*="-hero"]:not(.yoo-pages-hero), ' +
    '[class*="-container"], [class*="Container"], [class*="-wrapper"], [class*="Wrapper"], [class*="-wrap"], ' +
    '[class*="-setup"], [class*="Setup"], [class*="-wizard"], [class*="Wizard"], [class*="-onboarding"], [class*="Onboarding"], ' +
    '[class*="-modal-container"], [class*="-modal-inner"], [class*="-modal-header"], [class*="-modal-body"], ' +
    '[class*="-template-card"], [class*="-step-inner"], [class*="step-list"], [class*="header-nav"], [class*="-nav-item"], ' +
    '[class*="-box"], [class*="-boxes"], ' +
    '[role="dialog"], ' +
    '.media-modal, .media-frame, .media-sidebar, .attachment-details, .attachment-info, .compat-item, ' +
    '.attachments-browser, .uploader-inline, #TB_window, .thickbox-loading';
  var FORM_FIELD_QUERY =
    'input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="hidden"]):not([type="file"]), textarea, select';
  var LIGHT_FIELD_BG = 'var(--ysh-field, #22262e)';
  var ICON_QUERY =
    'svg, [class*="icon"], [class*="Icon"], [class*="dashicon"], [class*="Dashicon"], [class*="symbol"], [class*="Symbol"]';
  var TOGGLE_QUERY =
    'input[type="checkbox"], [role="switch"], [aria-checked], [aria-pressed], ' +
    '[class*="switch"], [class*="Switch"], [class*="toggle"], [class*="Toggle"]';
  var CUSTOM_SELECT_QUERY =
    '.code-snippets-select, [class*="select" i], [role="combobox"], [role="listbox"]';
  var CUSTOM_SELECT_VALUE_QUERY =
    '[class*="singleValue" i], [class*="single-value" i], [class*="valueContainer" i], [class*="value-container" i], ' +
    '[class*="placeholder" i], [class*="selectedValue" i], [class*="selected-value" i], [class*="indicator" i], [role="option"]';
  var PLUGIN_DIRECT_ROOT_QUERY =
    ':scope > [id$="-form-container"], :scope > [id*="form-container"], :scope > [id$="-page-container"], :scope > [id*="page-container"], ' +
    ':scope > [id*="plugin-settings"], :scope > [id$="-settings-page"], :scope > [id*="settings-page"], ' +
    ':scope > [class$="-form-container"], :scope > [class*="form-container"], :scope > [class$="-page-container"], :scope > [class*="page-container"]';
  var SURFACE_WALK_QUERY =
    'div, section, aside, article, fieldset, main, header, footer, dialog, button, [role="button"], [role="dialog"], ' +
    '.components-card, .components-surface, [data-wp-component="Card"], ' +
    '[class*="panel"], [class*="card"], [class*="settings"], [class*="banner"], [class*="modal"], [class*="template"], ' +
    '[class*="list"], [class*="row"], [class*="item"], [class*="feature"], [class*="module"], [class*="setting"], ' +
    '[class*="header"], [class*="Header"], [class*="footer"], [class*="Footer"], [class*="container"], [class*="Container"], ' +
    '[class*="wrapper"], [class*="Wrapper"], [class*="setup"], [class*="Setup"], [class*="wizard"], [class*="Wizard"]';
  var YOOADMIN_SKIP_SELECTOR =
    '.ysh-adapt-skip, .yp-notification-item, [id^="yp-"], [id^="yoo"], [class^="yp-"], [class*=" yp-"], [class^="yoo"], [class*=" yoo"], [class*="yooadmin"], [class*="YOOAdmin"]';
  var SURFACE_WALK_MAX = 700;
  var SURFACE_CARD_BG = 'var(--ysh-card, #1a1d23)';
  var debounceTimer = null;
  var heavyAdaptRaf = null;
  var rootObserver = null;
  var reactPollTimer = null;
  var reactPollCount = 0;
  var adaptBootAt = Date.now();
  var ADAPT_READY_MAX_MS = 1400;
  var reactAdaptLocked = false;
  var denseAdaptLocked = false;
  var formAdaptLocked = false;
  var pluginSettingsAdaptLocked = false;
  var cachedGlobalPrefixes = null;
  var cachedTokenRoots = null;
  var cachedTokenRootsKey = '';
  var tokenVarsCache = typeof WeakMap !== 'undefined' ? new WeakMap() : null;
  var rootProfileCache = typeof WeakMap !== 'undefined' ? new WeakMap() : null;
  var adaptPerfEnabled = false;
  var adaptPerfNodes = 0;
  var adaptPassCount = 0;
  var adaptRunning = false;
  var MAX_CLASSIC_ADAPT_PASSES = 1;
  var REACT_POLL_MAX = 6;
  var REACT_POLL_MS = 280;
  var DEBOUNCE_MS = 120;
  var DEBOUNCE_REACT_MS = 450;
  var EDITOR_FRAME_STYLE_ID = 'ysh-plugin-admin-editor-frame-dark';

  function isDarkMode() {
    return (
      document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') === 'dark'
    );
  }

  function shouldApplyYooadminSkip(el) {
    return !!(
      el &&
      el.closest &&
      el.closest(YOOADMIN_SKIP_SELECTOR)
    );
  }

  function initPerfFlag() {
    var qs;
    try {
      qs = new URLSearchParams(window.location.search || '');
      adaptPerfEnabled =
        qs.get('_ysh_adapt_perf') === '1' ||
        window.localStorage.getItem('ysh_adapt_perf') === '1';
    } catch (e) {
      adaptPerfEnabled = false;
    }
  }

  function perfStart(label, root) {
    if (!adaptPerfEnabled || !window.performance) {
      return null;
    }
    adaptPerfNodes = 0;
    return {
      label: label,
      profile: root ? root.getAttribute('data-ysh-adapt-profile') || '' : '',
      start: window.performance.now(),
    };
  }

  function perfCount(nodes) {
    if (!adaptPerfEnabled || !nodes) {
      return;
    }
    adaptPerfNodes += typeof nodes.length === 'number' ? nodes.length : 1;
  }

  function perfEnd(mark) {
    if (!mark || !window.console || !window.performance) {
      return;
    }
    window.console.log('[YSH adaptive]', {
      label: mark.label,
      profile: mark.profile || '',
      elapsedMs: Math.round((window.performance.now() - mark.start) * 10) / 10,
      scannedNodes: adaptPerfNodes,
      pass: adaptPassCount,
    });
  }

  function styleSheetSignature() {
    var parts = [];
    var i;
    var sheet;
    for (i = 0; i < document.styleSheets.length && i < TOKEN_STYLE_SHEET_MAX; i++) {
      sheet = document.styleSheets[i];
      parts.push((sheet.href || 'inline') + ':' + (sheet.ownerNode && sheet.ownerNode.id ? sheet.ownerNode.id : ''));
    }
    return parts.join('|');
  }

  function clonePlainObject(obj) {
    var out = {};
    var key;
    for (key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        out[key] = obj[key];
      }
    }
    return out;
  }

  function classText(node) {
    var cn = node && node.className;
    if (!cn) {
      return '';
    }
    if (typeof cn === 'string') {
      return cn;
    }
    if (typeof cn.baseVal === 'string') {
      return cn.baseVal;
    }
    return String(cn);
  }

  function isYooadminOwnedNode(node) {
    return !!(
      node &&
      node.nodeType === 1 &&
      (/(^|\s)(yp-|yoo)|yooadmin|yp-studio|yp-inbox|yp-notification/i.test(classText(node)) ||
        /^(yp-|yoo)/i.test(node.id || '') ||
        (node.closest && node.closest(YOOADMIN_SKIP_SELECTOR)))
    );
  }

  function parseRgb(cssColor) {
    if (!cssColor || cssColor === 'transparent') {
      return null;
    }
    var m = cssColor.match(/rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)(?:\s*,\s*([\d.]+))?\s*\)/);
    if (!m) {
      return null;
    }
    return {
      r: parseFloat(m[1]),
      g: parseFloat(m[2]),
      b: parseFloat(m[3]),
      a: m[4] !== undefined ? parseFloat(m[4]) : 1,
    };
  }

  /** Luminance from rgb / oklch / hsl (modern plugin CSS vars). */
  function parseColorLum(cssColor) {
    var rgb;
    var m;
    if (!cssColor || cssColor === 'transparent') {
      return null;
    }
    rgb = parseRgb(cssColor);
    if (rgb) {
      if (rgb.a < 0.35) {
        return null;
      }
      return luminance(rgb.r, rgb.g, rgb.b);
    }
    m = cssColor.match(/oklch\(\s*([\d.]+)%/i);
    if (m) {
      return parseFloat(m[1]) / 100;
    }
    m = cssColor.match(/oklch\(\s*([\d.]+)\s+/i);
    if (m) {
      return parseFloat(m[1]);
    }
    m = cssColor.match(/hsla?\([^,]+,\s*[^,]+,\s*([\d.]+)%/i);
    if (m) {
      return parseFloat(m[1]) / 100;
    }
    m = cssColor.match(/^#([0-9a-f]{3,8})$/i);
    if (m) {
      var hex = m[1];
      if (hex.length === 3) {
        hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
      }
      return luminance(
        parseInt(hex.slice(0, 2), 16),
        parseInt(hex.slice(2, 4), 16),
        parseInt(hex.slice(4, 6), 16)
      );
    }
    return null;
  }

  function luminance(r, g, b) {
    function ch(c) {
      c /= 255;
      return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b);
  }

  function getOwnBackgroundLum(el) {
    var cs = window.getComputedStyle(el);
    var lum = parseColorLum(cs.backgroundColor);
    if (lum === null) {
      lum = parseColorLum(cs.getPropertyValue('background-color'));
    }
    return lum;
  }

  function getTextLum(el) {
    var lum = parseColorLum(window.getComputedStyle(el).color);
    return lum !== null ? lum : 0.5;
  }

  function getPaintLum(el) {
    var cs = window.getComputedStyle(el);
    var svgPaint = /^(svg|path|circle|rect|polygon|polyline|line|g)$/i.test(el.tagName || '');
    var props = svgPaint ? ['fill', 'stroke', 'color'] : ['color', 'fill', 'stroke'];
    var i;
    var lum;
    for (i = 0; i < props.length; i++) {
      lum = parseColorLum(cs[props[i]] || cs.getPropertyValue(props[i]));
      if (lum !== null) {
        return lum;
      }
    }
    return 0.5;
  }

  function hasImplicitDarkSvgPaint(svg) {
    if (!svg || svg.tagName !== 'SVG') {
      return false;
    }
    if (/logo|brand|avatar|image|flag/i.test(classText(svg))) {
      return false;
    }
    var shapes = svg.querySelectorAll
      ? svg.querySelectorAll('path, circle, rect, polygon, polyline, line')
      : [];
    if (!shapes.length) {
      return false;
    }
    var dark = 0;
    var colored = 0;
    var max = Math.min(shapes.length, 8);
    for (var i = 0; i < max; i++) {
      var node = shapes[i];
      var fillAttr = (node.getAttribute('fill') || '').trim().toLowerCase();
      var strokeAttr = (node.getAttribute('stroke') || '').trim().toLowerCase();
      var lum = getPaintLum(node);
      if (
        !fillAttr ||
        fillAttr === 'currentcolor' ||
        fillAttr === 'black' ||
        fillAttr === '#000' ||
        fillAttr === '#000000' ||
        (!strokeAttr && lum <= DARK_TEXT_LUM)
      ) {
        dark++;
      } else if (fillAttr !== 'none' || (strokeAttr && strokeAttr !== 'none')) {
        colored++;
      }
    }
    return dark > 0 && colored <= 1;
  }

  var TOKEN_APP_QUERY_DOC =
    '#wpbody-content [class$="-app"][data-screen], #wpbody-content [class$="-app"], ' +
    '#wpbody-content [id$="-plugin-container"], #wpbody-content [id*="plugin-container"], #wpbody-content .admin-ui-page, ' +
    '#wpbody-content > .wrap > [class$="-app"], #wpbody-content > .wrap > [class*="admin-wrap"], ' +
    '#wpbody-content > .wrap > [class$="-app"][data-screen], #wpbody-content > .wrap [class$="-app"][data-screen]';
  var TOKEN_APP_QUERY_SCOPE =
    ':scope > [class$="-app"], :scope > [class*="admin-wrap"], :scope > [id$="-plugin-container"], :scope > [id*="plugin-container"], ' +
    ':scope > .admin-ui-page, :scope > [class$="-app"][data-screen], ' +
    '[class$="-app"][data-screen]';
  var TOKEN_PREFIX_SKIP = {
    wp: 1,
    ui: 1,
    is: 1,
    has: 1,
    wrap: 1,
    app: 1,
    pixonex: 1,
    nav: 1,
    tab: 1,
    active: 1,
    button: 1,
    btn: 1,
    form: 1,
    field: 1,
    page: 1,
    item: 1,
    list: 1,
    grid: 1,
    row: 1,
    col: 1,
    card: 1,
    icon: 1,
    dashicons: 1,
  };
  var TOKEN_DARK_VALUES = {
    bg: '#12151a',
    'bg-sunken': '#12151a',
    'bg-subtle': '#151922',
    'bg-muted': '#181c24',
    'bg-raised': '#1a1d23',
    'bg-surface': '#1a1d23',
    'bg-hover': 'rgba(255, 255, 255, 0.06)',
    'bg-active': 'rgba(255, 255, 255, 0.09)',
    'bg-card': '#1a1d23',
    background: '#1a1d23',
    surface: '#1a1d23',
    card: '#1a1d23',
    white: '#1a1d23',
    'white-off': '#12151a',
    black: '#eef1f5',
    'gray-0': '#22262e',
    'gray-5': '#1a1d23',
    'gray-10': '#1a1d23',
    'gray-20': 'rgba(255, 255, 255, 0.12)',
    'gray-30': 'rgba(255, 255, 255, 0.18)',
    'gray-40': '#9aa5b1',
    'gray-50': '#9aa5b1',
    'gray-60': '#cfd6e0',
    'gray-70': '#cfd6e0',
    'gray-80': '#d8dee8',
    'gray-90': '#eef1f5',
    'gray-100': '#f8fafc',
    fg: '#eef1f5',
    fg1: '#eef1f5',
    'fg-primary': '#eef1f5',
    fg2: '#cfd6e0',
    'fg-secondary': '#cfd6e0',
    fg3: '#9aa5b1',
    'fg-muted': '#9aa5b1',
    text: '#cfd6e0',
    'text-muted': '#9aa5b1',
    border: 'rgba(255, 255, 255, 0.12)',
    'border-strong': 'rgba(255, 255, 255, 0.18)',
    'border-color': 'rgba(255, 255, 255, 0.12)',
    'color-bg-surface-neutral': '#12151a',
    'color-bg-surface-neutral-strong': '#1a1d23',
    'color-bg-surface-neutral-weak': '#151922',
    'color-bg-surface-selected': 'rgba(255, 255, 255, 0.09)',
    'color-bg-surface-hover': 'rgba(255, 255, 255, 0.06)',
    'color-fg-content-neutral': '#cfd6e0',
    'color-fg-content-neutral-strong': '#eef1f5',
    'color-fg-content-neutral-weak': '#9aa5b1',
    'color-stroke-surface-neutral': 'rgba(255, 255, 255, 0.12)',
    'color-stroke-surface-neutral-strong': 'rgba(255, 255, 255, 0.18)',
    'color-stroke-surface-neutral-weak': 'rgba(255, 255, 255, 0.1)',
  };
  var TOKEN_STYLE_SHEET_MAX = 64;
  var TOKEN_RULE_MAX = 2400;

  function isTokenAppShell(el) {
    if (!el || el.nodeType !== 1) {
      return false;
    }
    if (isYooadminOwnedNode(el)) {
      return false;
    }
    var cn = classText(el);
    var id = el.id || '';
    if (
      /\b\w+-app\b/.test(cn) ||
      /admin-wrap\b|admin-ui-page\b|admin-page\b/i.test(cn) ||
      /plugin-container/i.test(id) ||
      el.hasAttribute('data-screen')
    ) {
      return true;
    }
    return false;
  }

  function findTokenAppRoots(root) {
    var cacheKey =
      (root ? (root.id || '') + ':' + classText(root) + ':' + root.childElementCount : 'doc') +
      '|' +
      (document.body ? classText(document.body) : '');
    if (cachedTokenRoots && cachedTokenRootsKey === cacheKey) {
      return cachedTokenRoots.filter(function (el) {
        return el && document.documentElement.contains(el);
      });
    }
    var seen = [];
    var out = [];
    var wrap = document.querySelector(ROOT_WRAP);
    function push(el) {
      if (!el || !isTokenAppShell(el) || seen.indexOf(el) !== -1) {
        return;
      }
      seen.push(el);
      out.push(el);
    }

    document.querySelectorAll(TOKEN_APP_QUERY_DOC).forEach(push);
    if (wrap) {
      wrap.querySelectorAll(TOKEN_APP_QUERY_SCOPE).forEach(push);
    }
    if (root && root !== wrap && root.querySelectorAll) {
      root.querySelectorAll('[class$="-app"], [class*="admin-wrap"], [data-screen][class*="app"]').forEach(push);
    }
    cachedTokenRoots = out.slice();
    cachedTokenRootsKey = cacheKey;
    return out;
  }

  function mergeTokenPrefixes(app, vars) {
    var seen = {};
    var list = guessTokenPrefixes(app);
    var name;
    var m;
    var i;
    var p;
    for (i = 0; i < list.length; i++) {
      seen[list[i]] = 1;
    }
    for (name in vars) {
      if (!Object.prototype.hasOwnProperty.call(vars, name)) {
        continue;
      }
      m = name.match(/^--([a-z][a-z0-9]{1,10})-/i);
      if (!m) {
        continue;
      }
      p = m[1].toLowerCase();
      if (!TOKEN_PREFIX_SKIP[p]) {
        seen[p] = 1;
      }
    }
    return Object.keys(seen);
  }

  function shouldSkipTokenName(name) {
    return /brand|coral|accent|success|warning|danger|primary|ink|pro-/i.test(name);
  }

  function guessTokenPrefixes(app) {
    var counts = {};
    var nodes = [app].concat(Array.prototype.slice.call(app.querySelectorAll('[class]'), 0, 120));
    var i;
    var j;
    var parts;
    var m;
    var p;
    for (i = 0; i < nodes.length; i++) {
      parts = classText(nodes[i]).split(/\s+/);
      for (j = 0; j < parts.length; j++) {
        m = parts[j].match(/^([a-z][a-z0-9]{1,8})-/i);
        if (!m) {
          continue;
        }
        p = m[1].toLowerCase();
        if (TOKEN_PREFIX_SKIP[p]) {
          continue;
        }
        counts[p] = (counts[p] || 0) + 1;
      }
    }
    return Object.keys(counts)
      .sort(function (a, b) {
        return counts[b] - counts[a];
      })
      .slice(0, 4);
  }

  function selectorTouchesApp(selector, classSet) {
    var chunks = selector.split(',');
    var i;
    var c;
    for (i = 0; i < chunks.length; i++) {
      for (c in classSet) {
        if (classSet[c] && chunks[i].indexOf('.' + c) !== -1) {
          return true;
        }
      }
    }
    return false;
  }

  function collectTokenVarsFromPluginSheets(app) {
    var cacheKey = 'plugin:' + styleSheetSignature() + ':' + (app.id || '') + ':' + classText(app);
    var cached;
    if (tokenVarsCache) {
      cached = tokenVarsCache.get(app);
      if (cached && cached.pluginKey === cacheKey) {
        return clonePlainObject(cached.pluginVars);
      }
    }
    var found = {};
    var appClass = (classText(app).split(/\s+/)[0] || '').trim();
    var si;
    var sheet;
    var rules;
    var ri;
    var rule;
    var style;
    var pi;
    var prop;
    var href;

    for (si = 0; si < document.styleSheets.length && si < TOKEN_STYLE_SHEET_MAX; si++) {
      sheet = document.styleSheets[si];
      try {
        href = sheet.href || '';
        if (href.indexOf('/plugins/') === -1 && href.indexOf('/wp-content/') === -1) {
          continue;
        }
        rules = sheet.cssRules || sheet.rules;
      } catch (e) {
        continue;
      }
      if (!rules) {
        continue;
      }
      for (ri = 0; ri < rules.length && ri < TOKEN_RULE_MAX; ri++) {
        rule = rules[ri];
        if (!rule || rule.type !== 1 || !rule.selectorText || !rule.style) {
          continue;
        }
        if (rule.selectorText.indexOf('-app') === -1) {
          continue;
        }
        if (appClass && rule.selectorText.indexOf('.' + appClass) === -1 && rule.selectorText.indexOf('-app') === -1) {
          continue;
        }
        style = rule.style;
        for (pi = 0; pi < style.length; pi++) {
          prop = style[pi];
          if (prop.indexOf('--') === 0) {
            found[prop] = style.getPropertyValue(prop).trim();
          }
        }
      }
    }
    if (tokenVarsCache) {
      cached = tokenVarsCache.get(app) || {};
      cached.pluginKey = cacheKey;
      cached.pluginVars = clonePlainObject(found);
      tokenVarsCache.set(app, cached);
    }
    return found;
  }

  function collectTokenVarsFromStylesheets(app) {
    var cacheKey = 'all:' + styleSheetSignature() + ':' + (app.id || '') + ':' + classText(app);
    var cached;
    if (tokenVarsCache) {
      cached = tokenVarsCache.get(app);
      if (cached && cached.allKey === cacheKey) {
        return clonePlainObject(cached.allVars);
      }
    }
    var found = {};
    var classSet = {};
    var i;
    var si;
    var sheet;
    var rules;
    var ri;
    var rule;
    var style;
    var pi;
    var prop;
    var val;

    classText(app).split(/\s+/).forEach(function (cls) {
      if (cls) {
        classSet[cls] = 1;
      }
    });

    for (si = 0; si < document.styleSheets.length && si < TOKEN_STYLE_SHEET_MAX; si++) {
      sheet = document.styleSheets[si];
      try {
        rules = sheet.cssRules || sheet.rules;
      } catch (e) {
        continue;
      }
      if (!rules) {
        continue;
      }
      for (ri = 0; ri < rules.length && ri < TOKEN_RULE_MAX; ri++) {
        rule = rules[ri];
        if (!rule || rule.type !== 1 || !rule.selectorText || !rule.style) {
          continue;
        }
        if (!selectorTouchesApp(rule.selectorText, classSet)) {
          continue;
        }
        style = rule.style;
        for (pi = 0; pi < style.length; pi++) {
          prop = style[pi];
          if (prop.indexOf('--') !== 0) {
            continue;
          }
          val = style.getPropertyValue(prop);
          if (val) {
            found[prop] = val.trim();
          }
        }
      }
    }
    if (tokenVarsCache) {
      cached = tokenVarsCache.get(app) || {};
      cached.allKey = cacheKey;
      cached.allVars = clonePlainObject(found);
      tokenVarsCache.set(app, cached);
    }
    return found;
  }

  function darkValueForTokenName(propName) {
    var bits = propName.replace(/^--/, '').split('-');
    var suffix;
    if (bits.length < 2) {
      return null;
    }
    suffix = bits.slice(1).join('-');
    if (TOKEN_DARK_VALUES[suffix]) {
      return TOKEN_DARK_VALUES[suffix];
    }
    if (/stroke|border|outline|separator|divider/i.test(suffix)) {
      return /strong|bold|emphasis/i.test(suffix) ? TOKEN_DARK_VALUES['border-strong'] : TOKEN_DARK_VALUES.border;
    }
    if (/fg|text|label|heading|title|content/i.test(suffix)) {
      if (/muted|secondary|hint|weak|subtle|3|dim/i.test(suffix)) {
        return TOKEN_DARK_VALUES['fg3'];
      }
      if (/strong|heading|title|emphasis|bold/i.test(suffix)) {
        return TOKEN_DARK_VALUES.fg;
      }
      return TOKEN_DARK_VALUES.fg2;
    }
    if (/bg|background|surface|raised|sunken|card/i.test(suffix)) {
      if (/strong|raised|card|panel/i.test(suffix)) {
        return TOKEN_DARK_VALUES['bg-raised'];
      }
      if (/weak|subtle|muted/i.test(suffix)) {
        return TOKEN_DARK_VALUES['bg-subtle'];
      }
      return TOKEN_DARK_VALUES.bg;
    }
    return null;
  }

  function probePrefixedTokens(app, prefixes) {
    var found = {};
    var pi;
    var suffix;
    var name;
    var val;
    var cs = window.getComputedStyle(app);
    for (pi = 0; pi < prefixes.length; pi++) {
      for (suffix in TOKEN_DARK_VALUES) {
        if (!Object.prototype.hasOwnProperty.call(TOKEN_DARK_VALUES, suffix)) {
          continue;
        }
        name = '--' + prefixes[pi] + '-' + suffix;
        val = cs.getPropertyValue(name).trim();
        if (val) {
          found[name] = val;
        }
      }
    }
    return found;
  }

  function forceRemapTokensForPrefixes(app, prefixes) {
    var remapped = [];
    var pi;
    var suffix;
    var name;
    var darkVal;

    prefixes.forEach(function (prefix) {
      for (suffix in TOKEN_DARK_VALUES) {
        if (!Object.prototype.hasOwnProperty.call(TOKEN_DARK_VALUES, suffix)) {
          continue;
        }
        name = '--' + prefix + '-' + suffix;
        if (shouldSkipTokenName(name)) {
          continue;
        }
        darkVal = TOKEN_DARK_VALUES[suffix];
        app.style.setProperty(name, darkVal, 'important');
        if (remapped.indexOf(name) === -1) {
          remapped.push(name);
        }
      }
    });
    return remapped;
  }

  function discoverCssVarPrefixesFromStylesheets() {
    if (cachedGlobalPrefixes) {
      return cachedGlobalPrefixes.slice();
    }
    var found = {};
    var re = /--([a-z][a-z0-9]{1,12})-(?:bg(?:-[a-z0-9-]+)?|surface\d*|card|background)\s*:/gi;
    var si;
    var sheet;
    var rules;
    var ri;
    var css;
    var m;
    var p;
    var href;

    for (si = 0; si < document.styleSheets.length && si < TOKEN_STYLE_SHEET_MAX; si++) {
      sheet = document.styleSheets[si];
      try {
        href = (sheet.href || '').toLowerCase();
        if (/yooadmin|studio-hub/i.test(href)) {
          continue;
        }
        rules = sheet.cssRules;
        if (!rules) {
          continue;
        }
        for (ri = 0; ri < rules.length && ri < TOKEN_RULE_MAX; ri++) {
          css = rules[ri].cssText || '';
          re.lastIndex = 0;
          while ((m = re.exec(css))) {
            p = m[1].toLowerCase();
            if (!TOKEN_PREFIX_SKIP[p]) {
              found[p] = 1;
            }
          }
        }
      } catch (e) {
        /* cross-origin stylesheet */
      }
    }
    cachedGlobalPrefixes = Object.keys(found);
    return cachedGlobalPrefixes.slice();
  }

  function remapGlobalDesignTokens() {
    var prefixes = discoverCssVarPrefixesFromStylesheets();
    var el = document.documentElement;
    var remapped = [];
    var existing;

    if (!prefixes.length) {
      return;
    }

    existing = (el.getAttribute('data-ysh-adapt-global-props') || '').split(',').filter(Boolean);
    remapped = forceRemapTokensForPrefixes(el, prefixes);
    remapped.forEach(function (name) {
      if (existing.indexOf(name) === -1) {
        existing.push(name);
      }
    });
    if (existing.length) {
      el.setAttribute('data-ysh-adapt-global-props', existing.join(','));
      el.setAttribute('data-ysh-adapt', 'global-tokens');
    }
  }

  function clearGlobalDesignTokens() {
    var el = document.documentElement;
    if (!el.getAttribute('data-ysh-adapt-global-props')) {
      return;
    }
    clearElementAdaptState(el);
  }

  function isAdaptPerfLocked() {
    return reactAdaptLocked || denseAdaptLocked || formAdaptLocked;
  }

  function rootProfileSignature(root) {
    if (!root) {
      return '';
    }
    return [
      root.id || '',
      classText(root),
      root.childElementCount || 0,
      root.querySelector ? !!root.querySelector('.CodeMirror, .cm-editor, .wp-code-editor') : false,
    ].join('|');
  }

  function classifyAdaptRoot(root) {
    var sig;
    var cached;
    var profile;
    if (!root) {
      return 'none';
    }
    sig = rootProfileSignature(root);
    if (rootProfileCache) {
      cached = rootProfileCache.get(root);
      if (cached && cached.sig === sig) {
        return cached.profile;
      }
    }
    if (isFastPluginFormRoot(root)) {
      profile = 'fast-form';
    } else if (isDirectPluginSettingsRoot(root)) {
      profile = 'plugin-settings';
    } else if (isReactHost(root)) {
      profile = 'react';
    } else if (isDenseGridShell(root)) {
      profile = 'dense';
    } else if (isTokenAppShell(root)) {
      profile = 'token';
    } else {
      profile = 'unknown';
    }
    if (rootProfileCache) {
      rootProfileCache.set(root, { sig: sig, profile: profile });
    }
    return profile;
  }

  function setAdaptProfile(shell, root, profile) {
    [shell, root].forEach(function (el) {
      if (el && el.nodeType === 1) {
        el.setAttribute('data-ysh-adapt-profile', profile);
      }
    });
    if (document.body) {
      document.body.setAttribute('data-ysh-adapt-profile', profile);
    }
  }

  function clearAdaptProfile(root) {
    if (root && root.nodeType === 1) {
      root.removeAttribute('data-ysh-adapt-profile');
    }
    if (document.body) {
      document.body.removeAttribute('data-ysh-adapt-profile');
    }
  }

  function isFastPluginFormRoot(root) {
    var idClass;
    if (!root || root.nodeType !== 1 || !root.querySelector) {
      return false;
    }
    idClass = ((root.id || '') + ' ' + classText(root)).toLowerCase();
    if (!/(?:^|\s|-)form-container\b|(?:^|\s|-)page-container\b/.test(idClass)) {
      return false;
    }
    return !!root.querySelector(
      '.CodeMirror, .cm-editor, .wp-code-editor, [role="combobox"], [class*="select" i], .components-form-token-field__input-container'
    );
  }

  function countDenseGridNodes(root) {
    if (!root || !root.querySelectorAll) {
      return 0;
    }
    return root.querySelectorAll(DENSE_GRID_QUERY).length;
  }

  function isDenseGridShell(root) {
    return countDenseGridNodes(root) >= DENSE_GRID_MIN;
  }

  function nodeMatchesPortal(el) {
    if (!el || el.nodeType !== 1) {
      return false;
    }
    if (el.matches && el.matches(PORTAL_OBS_SELECTOR)) {
      return true;
    }
    return !!(el.querySelector && el.querySelector(PORTAL_OBS_SELECTOR));
  }

  function remapDesignTokenApps(root) {
    findTokenAppRoots(root).forEach(function (app) {
      var vars = collectTokenVarsFromStylesheets(app);
      var pluginVars = collectTokenVarsFromPluginSheets(app);
      var name;
      var prefixes = mergeTokenPrefixes(app, Object.assign({}, pluginVars, vars));
      var remapped = [];
      var lum;
      var darkVal;

      if (prefixes.length) {
        remapped = forceRemapTokensForPrefixes(app, prefixes);
      }

      for (name in pluginVars) {
        if (Object.prototype.hasOwnProperty.call(pluginVars, name)) {
          vars[name] = pluginVars[name];
        }
      }

      var probed = probePrefixedTokens(app, prefixes);
      for (name in probed) {
        if (Object.prototype.hasOwnProperty.call(probed, name) && !vars[name]) {
          vars[name] = probed[name];
        }
      }

      for (name in vars) {
        if (!Object.prototype.hasOwnProperty.call(vars, name) || shouldSkipTokenName(name)) {
          continue;
        }
        lum = parseColorLum(vars[name]);
        if (lum === null) {
          lum = parseColorLum(window.getComputedStyle(app).getPropertyValue(name));
        }
        if (lum === null || lum < LIGHT_SURFACE - 0.12) {
          continue;
        }
        darkVal = darkValueForTokenName(name);
        if (!darkVal) {
          continue;
        }
        app.style.setProperty(name, darkVal, 'important');
        if (remapped.indexOf(name) === -1) {
          remapped.push(name);
        }
      }

      for (name in vars) {
        if (!Object.prototype.hasOwnProperty.call(vars, name) || shouldSkipTokenName(name)) {
          continue;
        }
        if (!/fg|text|label|heading/i.test(name) || /bg|border/i.test(name)) {
          continue;
        }
        lum = parseColorLum(vars[name]);
        if (lum === null) {
          lum = parseColorLum(window.getComputedStyle(app).getPropertyValue(name));
        }
        if (lum === null || lum > DARK_TEXT_LUM + 0.08) {
          continue;
        }
        darkVal = darkValueForTokenName(name);
        if (!darkVal) {
          continue;
        }
        app.style.setProperty(name, darkVal, 'important');
        if (remapped.indexOf(name) === -1) {
          remapped.push(name);
        }
      }

      if (remapped.length) {
        app.classList.add('ysh-adapt-token-app', 'ysh-adaptive-active');
        app.setAttribute('data-ysh-adapt', 'token-app');
        app.setAttribute('data-ysh-adapt-token-props', remapped.join(','));
      }
    });
  }

  function effectiveBackgroundLum(el, root) {
    var node = el;
    while (node && node !== root && node !== document.documentElement) {
      var lum = getOwnBackgroundLum(node);
      if (lum !== null) {
        return lum;
      }
      node = node.parentElement;
    }
    var rootLum = root ? getOwnBackgroundLum(root) : null;
    return rootLum !== null ? rootLum : 0.1;
  }

  function hasPluginAdminCompat() {
    return document.body && classText(document.body).indexOf('ysh-plugin-admin-compat') >= 0;
  }

  function isWpCoreToolsStaticCompatScreen() {
    var b = document.body;
    return b && b.classList.contains('ysh-wp-core-tools-compat');
  }

  function isYooadminNativeExperienceScreen() {
    var b = document.body;
    var wrap = document.querySelector(ROOT_WRAP);
    var page;
    if (!b) {
      return false;
    }
    if (isWpCoreToolsStaticCompatScreen()) {
      return false;
    }
    if (b.classList.contains('block-editor-page') || b.classList.contains('site-editor-php')) {
      return true;
    }
    if (b.classList.contains('plugin-install-php') && b.classList.contains('yooadmin-plugin-install-page')) {
      return true;
    }
    if (b.classList.contains('plugins-php') && b.classList.contains('yooadmin-plugins-page')) {
      return true;
    }
    if (wrap && classText(wrap) && NATIVE_RE.test(classText(wrap))) {
      return true;
    }
    if (classText(b) && NATIVE_RE.test(classText(b))) {
      return true;
    }
    if (
      b.classList.contains('yooadmin-posts-screen') ||
      b.classList.contains('yooadmin-pages-screen') ||
      b.classList.contains('yooadmin-plugins-page') ||
      b.classList.contains('yooadmin-plugin-install-page')
    ) {
      return true;
    }
    try {
      page = new URLSearchParams(window.location.search).get('page');
    } catch (ePage) {
      page = '';
    }
    if (page && /^yooadmin-/i.test(page)) {
      return true;
    }
    if (b.classList.contains('ysh-product-editor-ready') || b.classList.contains('ysh-product-editor-active')) {
      return true;
    }
    return false;
  }

  function hasMeaningfulRootText(el) {
    if (!el || el.nodeType !== 1) {
      return false;
    }
    var text = ((el.innerText || el.textContent || '') + '').replace(/\s+/g, ' ').trim();
    if (text.length >= 16) {
      return true;
    }
    if (el.querySelector) {
      return !!el.querySelector(
        'form, table, input, textarea, select, button, h1, h2, h3, .wrap, [class*="settings"], [class*="nav"]'
      );
    }
    return (el.childElementCount || 0) > 0;
  }

  function isDirectPluginSettingsRoot(root) {
    if (!root || !root.id) {
      return false;
    }
    var id = root.id.toLowerCase();
    return /plugin-settings|settings-page/.test(id);
  }

  function shouldUseHintsOnlySurfacePass(root) {
    if (!root || root.nodeType !== 1) {
      return true;
    }
    if (root.id === 'wpbody-content') {
      return true;
    }
    return isDirectPluginSettingsRoot(root);
  }

  function forceVendorLightCanvas() {
    var surf = 'var(--ysh-surface, #12151a)';
    var targets = [document.body, document.getElementById('wpcontent'), document.getElementById('wpbody-content')];
    var i;
    var el;
    var lum;
    for (i = 0; i < targets.length; i++) {
      el = targets[i];
      if (!el || el.nodeType !== 1) {
        continue;
      }
      lum = getOwnBackgroundLum(el);
      if (lum === null || lum >= LIGHT_SURFACE - 0.12) {
        el.style.setProperty('background', surf, 'important');
        el.style.setProperty('background-color', surf, 'important');
      }
    }
  }

  function getPluginAdminShell() {
    var classicWrap = document.querySelector(ROOT_WRAP);
    var wpbody = document.getElementById('wpbody-content');
    var tokenApp;
    var topLevelTokenApp;
    var directRoot;
    var compat = hasPluginAdminCompat();

    if (isYooadminNativeExperienceScreen()) {
      return null;
    }

    if (!compat) {
      if (classicWrap && !isNativeWrap(classicWrap)) {
        var hostOnly = classicWrap.querySelector(
          ':scope > [class*="-admin-dashboard"], :scope > [class*="-onboard-dashboard"]'
        );
        return { shell: classicWrap, root: hostOnly || classicWrap };
      }
      return null;
    }

    if (wpbody) {
      topLevelTokenApp = wpbody.querySelector(
        ':scope > [id$="-plugin-container"], :scope > [id*="plugin-container"], :scope > [class$="-app"], ' +
          ':scope > [class*="admin-wrap"], :scope > .admin-ui-page, :scope > [class*="admin-page"], ' +
          '[id$="-plugin-container"], [id*="plugin-container"]'
      );
      if (topLevelTokenApp && isTokenAppShell(topLevelTokenApp)) {
        return { shell: wpbody, root: topLevelTokenApp };
      }
    }

    if (classicWrap && !isNativeWrap(classicWrap)) {
      var host = classicWrap.querySelector(
        ':scope > [class*="-admin-dashboard"], :scope > [class*="-onboard-dashboard"]'
      );
      return { shell: classicWrap, root: host || classicWrap };
    }

    if (wpbody) {
      directRoot = wpbody.querySelector(PLUGIN_DIRECT_ROOT_QUERY);
      if (directRoot && !isYooadminOwnedNode(directRoot) && hasMeaningfulRootText(directRoot)) {
        return { shell: wpbody, root: directRoot };
      }

      tokenApp = wpbody.querySelector(
        '[class$="-app"][data-screen], [class$="-app"], [class*="admin-wrap"], ' +
          '[id$="-plugin-container"], [id*="plugin-container"], .admin-ui-page, [class*="admin-page"]'
      );
      if (tokenApp && isTokenAppShell(tokenApp)) {
        return { shell: wpbody, root: tokenApp };
      }
    }

    if (classicWrap) {
      return { shell: classicWrap, root: classicWrap };
    }

    if (wpbody) {
      return { shell: wpbody, root: wpbody };
    }

    return null;
  }

  function getAdaptRoot() {
    var ctx = getPluginAdminShell();
    return ctx ? ctx.root : null;
  }

  function getAdaptShell() {
    var ctx = getPluginAdminShell();
    return ctx ? ctx.shell : null;
  }

  function isNativeWrap(wrap) {
    if (wrap && classText(wrap) && NATIVE_RE.test(classText(wrap))) {
      return true;
    }
    /* plugins.php: body gets yooadmin-plugins-page in PHP before layout JS adds it to .wrap */
    if (document.body && classText(document.body) && NATIVE_RE.test(classText(document.body))) {
      return true;
    }
    return false;
  }

  var WP_REACT_COMPONENTS_SKIP =
    '.components-form-token-field, .components-popover__content, ' +
    '.components-panel, .components-panel__body, .components-base-control, ' +
    '.components-select-control, .components-toggle-control, ' +
    '.components-card, .components-modal__content, ' +
    '[class^="components-"], [data-wp-component]';

  var wpReactPageDetected = -1; // -1 = unchecked, 0 = no, 1 = yes

  /**
   * Detect pages that contain @wordpress/components React elements.
   * On these pages the comprehensive adaptive script must limit itself to
   * CSS-class scaffolding only — no inline styles, no data-attributes on
   * arbitrary DOM nodes — because the entire page form is often a single
   * React app and external DOM modifications cause React reconciliation
   * crashes (NotFoundError: removeChild).
   */
  function pageHasWpReactComponents() {
    if (wpReactPageDetected !== -1) return wpReactPageDetected === 1;
    var wpbody = document.getElementById('wpbody-content');
    if (!wpbody) { wpReactPageDetected = 0; return false; }
    wpReactPageDetected = wpbody.querySelector(
      '[class^="components-"], [class*=" components-"], [data-wp-component]'
    ) ? 1 : 0;
    return wpReactPageDetected === 1;
  }

  function shouldSkipEl(el) {
    if (!el || el.nodeType !== 1) {
      return true;
    }
    if (SKIP_TAGS[el.tagName]) {
      return true;
    }
    if (el.closest && el.closest('.CodeMirror, .cm-editor')) {
      return true;
    }
    if (el.closest && el.closest(WP_REACT_COMPONENTS_SKIP)) {
      return true;
    }
    if (
      el.closest &&
      el.closest(
        'table.widefat thead, table.widefat tfoot, table.wp-list-table thead, table.wp-list-table tfoot, table.plugin-check__results-table thead'
      )
    ) {
      return true;
    }
    if (
      el.closest &&
      el.closest('table.plugin-check__results-table, table.widefat.striped:not(.wp-list-table)')
    ) {
      return true;
    }
    if (el.tagName === 'LABEL' && !/(block-item|toggle-row)/i.test(classText(el))) {
      return true;
    }
    if (
      el.closest(
        '.notice-dismiss, .page-title-action, .nav-tab, [class*="__header-menu"]'
      )
    ) {
      return true;
    }
    if (shouldApplyYooadminSkip(el)) {
      return true;
    }
    if (el.classList && el.classList.contains('dashicons')) {
      return true;
    }
    if (
      el.classList &&
      (el.classList.contains('button') ||
        el.classList.contains('button-primary') ||
        el.classList.contains('button-secondary'))
    ) {
      return true;
    }
    return false;
  }

  function isModalInternalSurface(el) {
    var cls;
    if (!el || el.nodeType !== 1) {
      return false;
    }
    if (el.getAttribute('role') === 'dialog' || el.getAttribute('aria-modal') === 'true') {
      return false;
    }
    cls = classText(el);
    if (!cls) {
      return false;
    }
    return /(?:modal|dialog)(?:[-_]{1,2})(?:body|content|inner|main|header|footer)\b|(?:body|content|inner|main|header|footer)(?:[-_]{1,2})(?:modal|dialog)\b/i.test(
      cls
    );
  }

  function shouldSkipSurface(el) {
    if (!el || el.nodeType !== 1) {
      return true;
    }
    if (
      el.closest &&
      el.closest(
        '#wpseo-metabox-root, #wpseo_meta, .wpseo-metabox-content, [id^="brz-"], [class*="brz-root"], #breezy-editor, .breezy-editor, [class*="breezy-editor"]'
      )
    ) {
      return true;
    }
    if (isModalInternalSurface(el)) {
      return true;
    }
    if (el.closest && el.closest('.CodeMirror, .cm-editor')) {
      return true;
    }
    if (el.closest && el.closest(WP_REACT_COMPONENTS_SKIP)) {
      return true;
    }
    if (
      el.closest(
        'table.plugin-check__results-table, table.widefat.striped:not(.wp-list-table)'
      )
    ) {
      return true;
    }
    if (
      el.closest(
        '.nav-tab-wrapper, .wp-picker-container, .iris-picker, ' +
          '[class*="live-preview"], [class*="color-picker"], [class*="preview-panel"], .wp-color-result, ' +
          '.yoo-pages-hero, .yp-inbox-wrap, .yp-studio-hub'
      )
    ) {
      return true;
    }
    if (shouldApplyYooadminSkip(el)) {
      return true;
    }
    if (
      el.classList &&
      (el.classList.contains('button') ||
        el.classList.contains('button-primary') ||
        el.classList.contains('button-secondary') ||
        el.classList.contains('nav-tab'))
    ) {
      return true;
    }
    return false;
  }

  function shouldSkipBtn(el) {
    if (!el || el.nodeType !== 1) {
      return true;
    }
    if (
      el.closest(
        YOOADMIN_SKIP_SELECTOR +
          ', .notice-dismiss, .nav-tab, .nav-tab-wrapper, [class*="__header-menu"], [id$="-editor-tabs"]'
      )
    ) {
      return true;
    }
    if (el.closest && el.closest(WP_REACT_COMPONENTS_SKIP)) {
      return true;
    }
    if (el.classList && el.classList.contains('dashicons')) {
      return true;
    }
    return false;
  }

  function hasMeaningfulText(el) {
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      return false;
    }
    var text = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!text) {
      return false;
    }
    if (el.children.length > 0) {
      var own = '';
      for (var i = 0; i < el.childNodes.length; i++) {
        var n = el.childNodes[i];
        if (n.nodeType === 3) {
          own += n.textContent;
        }
      }
      own = own.replace(/\s+/g, ' ').trim();
      if (!own && el.tagName !== 'A' && !/^H[1-6]$/.test(el.tagName)) {
        return false;
      }
    }
    return true;
  }

  function isReactHost(root) {
    if (!root || !classText(root)) {
      return false;
    }
    return /-admin-dashboard|-onboard-dashboard/.test(classText(root));
  }

  function hasReactPainted(root) {
    if (!isReactHost(root)) {
      return true;
    }
    if (
      root.querySelector(
        '[class*="__welcome"], [class*="__content-subscribe"], [class*="__header"], [class*="__blocks"], [class*="__settings"]'
      )
    ) {
      return true;
    }
    var text = (root.innerText || '').replace(/\s+/g, ' ').trim();
    return text.length > 24;
  }

  function clearElementAdaptState(el) {
    if (!el || el.nodeType !== 1) {
      return;
    }
    el.classList.remove(
      'ysh-adapt-light-bg',
      'ysh-adapt-light-nested',
      'ysh-adapt-hoverable',
      'ysh-adapt-token-app',
      'ysh-adapt-field',
      'ysh-adaptive-active',
      'ysh-adapt-react-css-only',
      'ysh-adapt-dense-css-only'
    );
    el.removeAttribute('data-ysh-adapt');
    el.removeAttribute('data-ysh-adapt-text');
    el.removeAttribute('data-ysh-adapt-btn');
    el.removeAttribute('data-ysh-adapt-icon');
    el.removeAttribute('data-ysh-adapt-toggle');
    el.removeAttribute('data-ysh-adapt-select-value');
    el.removeAttribute('data-ysh-adapt-profile');
    (el.getAttribute('data-ysh-adapt-token-props') || '').split(',').forEach(function (prop) {
      prop = prop.trim();
      if (prop) {
        el.style.removeProperty(prop);
      }
    });
    el.removeAttribute('data-ysh-adapt-token-props');
    el.style.removeProperty('background');
    el.style.removeProperty('background-color');
    el.style.removeProperty('border');
    el.style.removeProperty('border-color');
    el.style.removeProperty('color');
    el.style.removeProperty('-webkit-text-fill-color');
    el.style.removeProperty('box-shadow');
    el.style.removeProperty('outline');
    el.style.removeProperty('opacity');
    el.style.removeProperty('visibility');
    el.style.removeProperty('z-index');
  }

  function clearLightModeShellState() {
    var shell = getAdaptShell();
    var wrap = document.querySelector(ROOT_WRAP);
    var wpbody = document.getElementById('wpbody-content');

    if (shell) {
      shell.classList.remove('ysh-adaptive-active', 'ysh-adapt-react-css-only');
      shell.querySelectorAll('[class*="-admin-dashboard"].ysh-adaptive-active').forEach(function (host) {
        host.classList.remove('ysh-adaptive-active', 'ysh-adapt-react-css-only');
      });
    }
    if (wrap) {
      wrap.classList.remove('ysh-adaptive-active', 'ysh-adapt-react-css-only');
    }
    if (wpbody) {
      clearAdaptProfile(wpbody);
      wpbody.querySelectorAll('.ysh-adapt-token-app, [data-ysh-adapt-token-props]').forEach(clearElementAdaptState);
      wpbody
        .querySelectorAll('[data-ysh-adapt-select-value], [data-ysh-adapt-select-control]')
        .forEach(clearElementAdaptState);
      clearClassicEditorFrameStyles(wpbody);
    }
    if (wrap && wrap !== wpbody) {
      clearClassicEditorFrameStyles(wrap);
    }
    if (document.body) {
      document.body.classList.remove('ysh-adapt-wait', 'ysh-adapt-ready');
    }
    clearGlobalDesignTokens();
  }

  function markAdaptReady() {
    if (!document.body) {
      return;
    }
    if (!isDarkMode()) {
      clearLightModeShellState();
      return;
    }
    document.body.classList.remove('ysh-adapt-wait');
    document.body.classList.add('ysh-adapt-ready');
    var shell = getAdaptShell();
    if (shell) {
      shell.classList.add('ysh-adaptive-active');
    }
  }

  function primeAdaptShell() {
    var ctx;
    var wrap;
    if (!isDarkMode()) {
      return;
    }
    ctx = getPluginAdminShell();
    wrap = document.querySelector(ROOT_WRAP);
    if (wrap && hasPluginAdminCompat()) {
      wrap.classList.add('ysh-adaptive-active');
    }
    if (!ctx) {
      return;
    }
    ctx.shell.classList.add('ysh-adaptive-active');
    findTokenAppRoots(ctx.root).forEach(function (app) {
      app.classList.add('ysh-adaptive-active');
    });
  }

  function forceAdaptReadySoon() {
    window.setTimeout(function () {
      adaptBootAt = 0;
      markAdaptReady();
    }, ADAPT_READY_MAX_MS + 80);
  }

  function isSelfTriggeredMutation(mutations) {
    if (!mutations || !mutations.length) {
      return false;
    }
    var i;
    var m;
    var name;
    for (i = 0; i < mutations.length; i++) {
      m = mutations[i];
      if (m.type !== 'attributes') {
        return false;
      }
      name = m.attributeName;
      if (
        name === 'data-ysh-adapt' ||
        name === 'data-ysh-adapt-text' ||
        name === 'data-ysh-adapt-btn' ||
        name === 'data-ysh-adapt-icon' ||
        name === 'data-ysh-adapt-toggle' ||
        name === 'data-ysh-adapt-select-value' ||
        name === 'data-ysh-adapt-select-control' ||
        name === 'data-ysh-adapt-profile' ||
        name === 'style' ||
        name === 'class'
      ) {
        continue;
      }
      return false;
    }
    return true;
  }

  function ensureReactButtonObserver() {
    var root = getAdaptRoot();
    if (!root || !isReactHost(root)) {
      return;
    }
    if (window.__yshReactBtnObs) {
      return;
    }
    window.__yshReactBtnObs = new MutationObserver(function () {
      scheduleReactButtonsOnly();
    });
    window.__yshReactBtnObs.observe(root, { childList: true, subtree: true });
  }

  function ensureColorModeObserver() {
    if (window.__yshColorModeObs) {
      return;
    }
    window.__yshColorModeObs = new MutationObserver(onStudioColorModeChanged);
    window.__yshColorModeObs.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['data-yooadmin-studio-color-mode-effective'],
    });
  }

  function ensureBodyPortalObserver() {
    if (window.__yshBodyAdaptObs || !document.body || !isDarkMode()) {
      return;
    }
    window.__yshBodyAdaptObs = new MutationObserver(function (mutations) {
      if (!isDarkMode()) {
        return;
      }
      scheduleAdapt(mutations);
    });
    window.__yshBodyAdaptObs.observe(document.body, { childList: true, subtree: false });
  }

  function stopHeavyObservers() {
    if (rootObserver) {
      rootObserver.disconnect();
      rootObserver = null;
    }
    if (reactPollTimer) {
      window.clearInterval(reactPollTimer);
      reactPollTimer = null;
    }
    if (window.__yshReactBtnObs) {
      window.__yshReactBtnObs.disconnect();
      window.__yshReactBtnObs = null;
    }
    if (window.__yshBodyAdaptObs) {
      window.__yshBodyAdaptObs.disconnect();
      window.__yshBodyAdaptObs = null;
    }
  }

  function pauseHeavyObservers() {
    if (rootObserver) {
      rootObserver.disconnect();
      rootObserver = null;
    }
    if (reactPollTimer) {
      window.clearInterval(reactPollTimer);
      reactPollTimer = null;
    }
    ensureBodyPortalObserver();
    ensureReactButtonObserver();
  }

  function clearMarks(root, full) {
    if (isAdaptPerfLocked() && !full) {
      return;
    }
    if (root) {
      clearElementAdaptState(root);
      root
        .querySelectorAll(
          '[data-ysh-adapt], [data-ysh-adapt-text], [data-ysh-adapt-btn], [data-ysh-adapt-icon], [data-ysh-adapt-toggle], [data-ysh-adapt-select-value], [data-ysh-adapt-select-control], [data-ysh-adapt-token-props], .ysh-adapt-field, .ysh-adapt-light-bg, .ysh-adapt-light-nested'
        )
        .forEach(clearElementAdaptState);
    }
    if (!isDarkMode()) {
      clearLightModeShellState();
    }
  }

  function markLightSurfacesFromHints(root) {
    var hints = root.querySelectorAll(SURFACE_HINTS);
    perfCount(hints);
    hints.forEach(function (hint) {
      if (shouldSkipEl(hint) || isModalInternalSurface(hint)) {
        return;
      }
      var lum = getOwnBackgroundLum(hint);
      if (lum === null) {
        lum = LIGHT_SURFACE;
      }
      if (lum >= LIGHT_SURFACE - 0.12) {
        var r = hint.getBoundingClientRect();
        if (r.width >= 40 && r.height >= 16) {
          hint.classList.add('ysh-adapt-light-bg');
          hint.setAttribute('data-ysh-adapt', 'surface');
        }
      }
    });
  }

  function markLightSurfacesWalk(root) {
    if (!root || root.id === 'wpbody-content') {
      return;
    }
    var all = root.querySelectorAll(SURFACE_WALK_QUERY);
    perfCount(all);
    var max = Math.min(all.length, SURFACE_WALK_MAX);
    var candidates = [];
    var n;
    var el;
    var lum;
    var rect;
    var i;
    var j;
    var outer;
    var inner;

    for (n = 0; n < max; n++) {
      el = all[n];
      if (shouldSkipSurface(el) || el.closest('.ysh-adapt-light-bg, .ysh-adapt-light-nested')) {
        continue;
      }
      lum = getOwnBackgroundLum(el);
      if (lum === null || lum < LIGHT_SURFACE - 0.12) {
        continue;
      }
      rect = el.getBoundingClientRect();
      if (rect.width < MIN_PANEL_W || rect.height < MIN_PANEL_H) {
        continue;
      }
      candidates.push(el);
    }

    for (i = 0; i < candidates.length; i++) {
      outer = candidates[i];
      var hasLighterAncestor = false;
      for (j = 0; j < candidates.length; j++) {
        inner = candidates[j];
        if (outer !== inner && inner.contains(outer)) {
          hasLighterAncestor = true;
          break;
        }
      }
      if (hasLighterAncestor) {
        outer.classList.add('ysh-adapt-light-nested');
        outer.setAttribute('data-ysh-adapt', 'surface-nested');
      } else {
        outer.classList.add('ysh-adapt-light-bg');
        outer.setAttribute('data-ysh-adapt', 'surface');
      }
    }
  }

  function escalateLightSurfaceBackgrounds(root) {
    var nodes = root.querySelectorAll('.ysh-adapt-light-bg');
    perfCount(nodes);
    nodes.forEach(function (el) {
      if (shouldSkipSurface(el)) {
        return;
      }
      var lum = getOwnBackgroundLum(el);
      if (lum !== null && lum >= LIGHT_SURFACE - 0.12) {
        el.style.setProperty('background', SURFACE_CARD_BG, 'important');
        el.style.setProperty('background-color', SURFACE_CARD_BG, 'important');
      }
    });
  }

  function adaptBodyPortals() {
    var nodes;
    if (!hasPluginAdminCompat() || !isDarkMode() || !document.body) {
      return;
    }
    nodes = document.body.querySelectorAll(
      '[role="dialog"], [class*="-modal"], .media-modal, .media-frame, #TB_window'
    );
    nodes.forEach(function (node) {
      if (shouldSkipSurface(node)) {
        return;
      }
      markLightSurfacesFromHints(node);
      markLightSurfacesWalk(node);
      escalateLightSurfaceBackgrounds(node);
      markLightFormFields(node);
      adaptTypography(node);
    });
  }

  function markLightSurfaces(root, lightOnly) {
    remapGlobalDesignTokens();
    if (!lightOnly) {
      remapDesignTokenApps(root);
    }
    markLightSurfacesFromHints(root);
    if (!lightOnly) {
      markLightSurfacesWalk(root);
    }
    escalateLightSurfaceBackgrounds(root);
    adaptBodyPortals();
  }

  function shouldSkipFormField(el) {
    if (!el || el.nodeType !== 1) {
      return true;
    }
    if (
      el.closest(
        '.notice-dismiss, .page-title-action, .nav-tab, ' +
          '.wp-picker-container, .iris-picker, .wp-picker-holder'
      )
    ) {
      return true;
    }
    if (el.closest && el.closest(WP_REACT_COMPONENTS_SKIP)) {
      return true;
    }
    if (shouldApplyYooadminSkip(el)) {
      return true;
    }
    if (
      el.classList &&
      (el.classList.contains('button') ||
        el.classList.contains('button-primary') ||
        el.classList.contains('button-secondary'))
    ) {
      return true;
    }
    return false;
  }

  function markLightFormFields(root) {
    var fields = root.querySelectorAll(FORM_FIELD_QUERY);
    perfCount(fields);
    fields.forEach(function (el) {
      if (shouldSkipFormField(el)) {
        return;
      }
      if (el.classList && el.classList.contains('wp-color-picker')) {
        return;
      }
      var lum = getOwnBackgroundLum(el);
      if (lum === null || lum < LIGHT_SURFACE - 0.12) {
        return;
      }
      var rect = el.getBoundingClientRect();
      if (rect.width < 24 || rect.height < 12) {
        return;
      }
      el.classList.add('ysh-adapt-field');
      el.setAttribute('data-ysh-adapt', 'field');
      el.style.setProperty('background', LIGHT_FIELD_BG, 'important');
      el.style.setProperty('background-color', LIGHT_FIELD_BG, 'important');
      el.style.setProperty('border-color', 'rgba(255, 255, 255, 0.14)', 'important');
      el.style.setProperty('color', 'var(--ysh-text, #cfd6e0)', 'important');
    });
  }

  function isClassicEditorFrame(frame) {
    var text = (
      (frame.id || '') +
      ' ' +
      (frame.name || '') +
      ' ' +
      (frame.title || '') +
      ' ' +
      classText(frame)
    ).toLowerCase();
    if (!text) {
      return false;
    }
    return /(^|[_\s-])mce|tinymce|editor|visual|content_ifr|_ifr\b/.test(text);
  }

  function withEditorFrameDocument(frame, cb) {
    try {
      var doc = frame.contentDocument || (frame.contentWindow && frame.contentWindow.document);
      if (doc && doc.documentElement) {
        cb(doc);
      }
    } catch (e) {
      /* Cross-origin previews are intentionally left alone. */
    }
  }

  function adaptClassicEditorFrames(root) {
    if (!root || !root.querySelectorAll) {
      return;
    }
    root.querySelectorAll('iframe').forEach(function (frame) {
      if (!isClassicEditorFrame(frame)) {
        return;
      }
      withEditorFrameDocument(frame, function (doc) {
        var style = doc.getElementById(EDITOR_FRAME_STYLE_ID);
        if (!style) {
          style = doc.createElement('style');
          style.id = EDITOR_FRAME_STYLE_ID;
          (doc.head || doc.documentElement).appendChild(style);
        }
        style.textContent =
          'html,body{background:#151922!important;background-color:#151922!important;color:#e5e7eb!important;color-scheme:dark!important;}' +
          'body{caret-color:#f8fafc!important;}' +
          'body,body p,body div,body span,body li,body td,body th{color:#e5e7eb!important;}' +
          'a{color:#f0b84d!important;}' +
          '::selection{background:rgba(237,169,52,.45)!important;color:#f8fafc!important;}';
      });
    });
  }

  function clearClassicEditorFrameStyles(root) {
    if (!root || !root.querySelectorAll) {
      return;
    }
    root.querySelectorAll('iframe').forEach(function (frame) {
      withEditorFrameDocument(frame, function (doc) {
        var style = doc.getElementById(EDITOR_FRAME_STYLE_ID);
        if (style && style.parentNode) {
          style.parentNode.removeChild(style);
        }
      });
    });
  }

  function adaptCustomSelectValues(root) {
    if (!root || !root.querySelectorAll) {
      return;
    }
    var controls = root.querySelectorAll(CUSTOM_SELECT_QUERY);
    perfCount(controls);
    var maxControls = Math.min(controls.length, 180);
    var i;
    var j;

    for (i = 0; i < maxControls; i++) {
      var control = controls[i];
      if (control.matches(YOOADMIN_SKIP_SELECTOR)) {
        continue;
      }
      if (control.tagName === 'SELECT') {
        continue;
      }
      if (control.closest && control.closest(
        '.components-form-token-field,.components-panel,.components-base-control,.components-card'
      )) {
        continue;
      }

      control.setAttribute('data-ysh-adapt-select-control', '1');
      control.style.setProperty('color', '#eef1f5', 'important');
      control.style.setProperty('-webkit-text-fill-color', '#eef1f5', 'important');
      if (control.matches('input')) {
        control.style.setProperty('background', 'transparent', 'important');
        control.style.setProperty('background-color', 'transparent', 'important');
        control.style.setProperty('border', '0', 'important');
        control.style.setProperty('box-shadow', 'none', 'important');
        control.style.setProperty('outline', '0', 'important');
      }

      control.querySelectorAll('input').forEach(function (input) {
        input.setAttribute('data-ysh-adapt-select-control', '1');
        input.style.setProperty('background', 'transparent', 'important');
        input.style.setProperty('background-color', 'transparent', 'important');
        input.style.setProperty('border', '0', 'important');
        input.style.setProperty('box-shadow', 'none', 'important');
        input.style.setProperty('outline', '0', 'important');
        if (document.activeElement !== input) {
          input.style.setProperty('opacity', '0', 'important');
        }
      });

      var values = control.querySelectorAll(CUSTOM_SELECT_VALUE_QUERY);
      perfCount(values);
      for (j = 0; j < values.length && j < 80; j++) {
        var value = values[j];
        value.setAttribute('data-ysh-adapt-select-value', '1');
        value.style.setProperty('color', '#eef1f5', 'important');
        value.style.setProperty('-webkit-text-fill-color', '#eef1f5', 'important');
        value.style.setProperty('opacity', '1', 'important');
        value.style.setProperty('visibility', 'visible', 'important');
        value.style.setProperty('z-index', '2', 'important');
        value.querySelectorAll('span, div, svg, path, .dashicons').forEach(function (child) {
          child.style.setProperty('color', '#eef1f5', 'important');
          child.style.setProperty('-webkit-text-fill-color', '#eef1f5', 'important');
          child.style.setProperty('fill', 'currentColor', 'important');
          child.style.setProperty('stroke', 'currentColor', 'important');
          child.style.setProperty('opacity', '1', 'important');
          child.style.setProperty('visibility', 'visible', 'important');
        });
      }
    }
  }

  function classifyTextTier(el, bgLum) {
    if (el.tagName === 'A') {
      return 'link';
    }
    if (/^H[1-6]$/.test(el.tagName)) {
      return 'heading';
    }
    var cs = window.getComputedStyle(el);
    var fs = parseFloat(cs.fontSize) || 14;
    var fw = parseInt(cs.fontWeight, 10) || 400;
    if (fs <= 11 || cs.fontStyle === 'italic') {
      return 'muted';
    }
    if (fw >= 600) {
      return 'heading';
    }
    return 'body';
  }

  function adaptTypography(root) {
    var nodes = root.querySelectorAll(TEXT_QUERY);
    perfCount(nodes);
    var i;
    var el;
    var bgLum;
    var textLum;
    var tier;
    var ratio;
    var limit = nodes.length > TYPOGRAPHY_MAX_NODES ? TYPOGRAPHY_MAX_NODES : nodes.length;
    var processed = 0;

    for (i = 0; i < nodes.length && processed < limit; i++) {
      el = nodes[i];
      if (shouldSkipEl(el) || !hasMeaningfulText(el)) {
        continue;
      }
      processed++;

      bgLum = effectiveBackgroundLum(el, root);
      textLum = getTextLum(el);
      tier = null;
      var csText = window.getComputedStyle(el);
      var fsText = parseFloat(csText.fontSize) || 14;

      if (/^H[1-6]$/.test(el.tagName) && bgLum < 0.55 && !el.closest('.ysh-adapt-light-bg, .ysh-adapt-light-nested')) {
        tier = 'heading';
      } else if (el.closest('.ysh-adapt-light-bg, .ysh-adapt-light-nested')) {
        tier = classifyTextTier(el, bgLum);
      } else if (bgLum >= LIGHT_SURFACE && textLum >= 0.52) {
        tier = 'on-light';
      } else if (textLum <= DARK_TEXT_LUM && bgLum < DARK_CANVAS_LUM) {
        tier = el.tagName === 'A' ? 'link' : fsText <= 11 ? 'muted' : 'on-dark';
      } else if (bgLum < 0.45 && textLum < 0.45) {
        tier = 'on-dark';
      } else {
        ratio = (Math.max(bgLum, textLum) + 0.05) / (Math.min(bgLum, textLum) + 0.05);
        if (ratio < 4.2) {
          tier = bgLum >= LIGHT_SURFACE ? 'on-light' : 'on-dark';
        }
      }

      if (tier) {
        el.setAttribute('data-ysh-adapt-text', tier);
      }
    }
  }

  function classifyButtonTier(el) {
    var cn = classText(el).toLowerCase();
    var txt = ((el.innerText || el.textContent || '') + ' ' + (el.value || '')).toLowerCase();
    if (
      /primary|save|submit|button-primary|license-btn|installer-button/.test(cn) ||
      /save|submit|subscribe|activate|add key|connect/.test(txt)
    ) {
      return 'primary';
    }
    if (/content-button|icon-wrapper/.test(cn) && /add key|edit key|update/.test(txt)) {
      return 'secondary';
    }
    if (/danger|delete|remove|disable all|cat-disable/.test(cn + txt)) {
      return 'danger';
    }
    if (/success|enable|cat-enable|all on/.test(cn + txt)) {
      return 'success';
    }
    return 'secondary';
  }

  function adaptButtons(root) {
    var nodes = root.querySelectorAll(BTN_QUERY);
    perfCount(nodes);
    nodes.forEach(function (el) {
      if (shouldSkipBtn(el)) {
        return;
      }
      if (el.closest('.components-button-group, .wp-core-ui .media-toolbar')) {
        return;
      }
      var rect = el.getBoundingClientRect();
      if (rect.width < 8 || rect.height < 8) {
        return;
      }
      el.setAttribute('data-ysh-adapt-btn', classifyButtonTier(el));
    });
  }

  function adaptInteractives(root) {
    var nodes = root.querySelectorAll(INTERACTIVE_QUERY);
    perfCount(nodes);
    var max = Math.min(nodes.length, INTERACTIVE_MAX_NODES);
    var n;
    var el;
    var cs;
    var rect;
    for (n = 0; n < max; n++) {
      el = nodes[n];
      if (shouldSkipEl(el) || shouldSkipBtn(el)) {
        continue;
      }
      cs = window.getComputedStyle(el);
      if (cs.cursor !== 'pointer' && el.tagName !== 'LABEL' && el.tagName !== 'LI') {
        if (!/item|row|toggle|tab|card/i.test(classText(el))) {
          continue;
        }
      }
      rect = el.getBoundingClientRect();
      if (rect.width < 24 || rect.height < 12) {
        continue;
      }
      el.classList.add('ysh-adapt-hoverable');
    }
  }

  function adaptIcons(root, limit) {
    var nodes = root.querySelectorAll(ICON_QUERY);
    perfCount(nodes);
    var max = limit || nodes.length;
    var n;
    var processed = 0;
    for (n = 0; n < nodes.length && processed < max; n++) {
      var el = nodes[n];
      if (el.closest(YOOADMIN_SKIP_SELECTOR + ', .notice-dismiss, .page-title-action, .nav-tab')) {
        continue;
      }
      if (el.closest && el.closest(WP_REACT_COMPONENTS_SKIP)) {
        continue;
      }
      if (el.tagName !== 'SVG' && hasMeaningfulText(el)) {
        continue;
      }
      var rect = el.getBoundingClientRect();
      if (rect.width > 96 || rect.height > 96 || rect.width < 6 || rect.height < 6) {
        continue;
      }
      processed++;
      var bgLum = effectiveBackgroundLum(el, root);
      var fillLum = getPaintLum(el);
      if (el.tagName === 'SVG' || /icon|symbol|dashicon/i.test(classText(el))) {
        var paths = el.querySelectorAll ? el.querySelectorAll('path, circle, rect, polygon, polyline, line, g') : [];
        if (paths.length) {
          fillLum = getPaintLum(paths[0]);
        }
      }
      if (bgLum < DARK_CANVAS_LUM && (fillLum <= DARK_TEXT_LUM || hasImplicitDarkSvgPaint(el))) {
        el.setAttribute('data-ysh-adapt-text', 'on-dark');
        el.setAttribute('data-ysh-adapt-icon', 'on-dark');
      }
    }
  }

  function classStateMatch(cn, positive) {
    var re = positive
      ? /(?:^|[\s_-])(active|enabled|checked|selected|on)(?:[\s_-]|$)|\bis-active\b|\bis-enabled\b/i
      : /(?:^|[\s_-])(inactive|disabled|unchecked|off)(?:[\s_-]|$)|\bis-inactive\b|\bis-disabled\b/i;
    return re.test(cn || '');
  }

  function getToggleActionState(el) {
    var label = (
      (el.getAttribute('aria-label') || '') +
      ' ' +
      (el.getAttribute('title') || '') +
      ' ' +
      (el.value || '') +
      ' ' +
      (el.innerText || el.textContent || '')
    )
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();

    if (!label) {
      return null;
    }
    if (/\b(deactivate|disable|turn off|switch off|stop|pause)\b/.test(label)) {
      return true;
    }
    if (/\b(activate|enable|turn on|switch on|start|resume)\b/.test(label)) {
      return false;
    }
    return null;
  }

  function getToggleAncestorState(el, root) {
    var host = el.parentElement;
    var depth = 0;
    var cn;

    while (host && host !== root && depth < 7) {
      cn = classText(host);
      if (classStateMatch(cn, false)) {
        return false;
      }
      if (classStateMatch(cn, true)) {
        return true;
      }
      host = host.parentElement;
      depth++;
    }
    return null;
  }

  function getToggleExplicitState(el, isNativeInput, cn) {
    var ariaChecked = el.getAttribute('aria-checked');
    var ariaPressed = el.getAttribute('aria-pressed');

    if (isNativeInput) {
      return !!el.checked;
    }
    if (ariaChecked === 'true' || ariaPressed === 'true') {
      return true;
    }
    if (ariaChecked === 'false' || ariaPressed === 'false') {
      return false;
    }
    if (classStateMatch(cn, false)) {
      return false;
    }
    if (classStateMatch(cn, true)) {
      return true;
    }
    return null;
  }

  function adaptToggles(root, limit) {
    var nodes = root.querySelectorAll(TOGGLE_QUERY);
    perfCount(nodes);
    var max = limit || nodes.length;
    var n;
    for (n = 0; n < nodes.length && n < max; n++) {
      var el = nodes[n];
      if (el.closest(YOOADMIN_SKIP_SELECTOR + ', .notice-dismiss, .nav-tab, .nav-tab-wrapper')) {
        continue;
      }
      if (el.closest && el.closest(WP_REACT_COMPONENTS_SKIP)) {
        continue;
      }
      var cn = classText(el);
      var role = (el.getAttribute('role') || '').toLowerCase();
      var isNativeInput = el.tagName === 'INPUT' && el.type === 'checkbox';
      var hasToggleSemantics =
        isNativeInput ||
        role === 'switch' ||
        el.hasAttribute('aria-checked') ||
        el.hasAttribute('aria-pressed') ||
        /switch|toggle/i.test(cn);
      if (!hasToggleSemantics) {
        continue;
      }
      var rect = el.getBoundingClientRect();
      if (!isNativeInput && role !== 'switch' && (rect.width > 96 || rect.height > 48 || rect.width < 10 || rect.height < 8)) {
        continue;
      }
      var checked = getToggleExplicitState(el, isNativeInput, cn);
      if (checked === null && !isNativeInput) {
        checked = getToggleActionState(el);
      }
      if (checked === null) {
        checked = getToggleAncestorState(el, root);
      }
      el.setAttribute('data-ysh-adapt-toggle', checked ? 'on' : 'off');
    }
  }

  function adaptButtonsReact(root) {
    if (!root) {
      return;
    }
    var nodes = root.querySelectorAll(REACT_BTN_QUERY);
    perfCount(nodes);
    var max = Math.min(nodes.length, 160);
    var n;
    for (n = 0; n < max; n++) {
      var el = nodes[n];
      if (shouldSkipBtn(el)) {
        continue;
      }
      var rect = el.getBoundingClientRect();
      if (rect.width < 8 || rect.height < 8) {
        continue;
      }
      el.setAttribute('data-ysh-adapt-btn', classifyButtonTier(el));
    }
  }

  function scheduleReactButtonsOnly() {
    if (reactButtonsTimer) {
      window.clearTimeout(reactButtonsTimer);
    }
    reactButtonsTimer = window.setTimeout(function () {
      reactButtonsTimer = null;
      if (!isDarkMode()) {
        return;
      }
      var root = getAdaptRoot();
      if (root && isReactHost(root)) {
        adaptButtonsReact(root);
      }
    }, 160);
  }

  function scheduleReactDynamicAdapt() {
    if (reactButtonsTimer) {
      window.clearTimeout(reactButtonsTimer);
    }
    reactButtonsTimer = window.setTimeout(function () {
      var root;
      reactButtonsTimer = null;
      if (!isDarkMode()) {
        return;
      }
      root = getAdaptRoot();
      if (!root || !isReactHost(root)) {
        return;
      }
      var perf = perfStart('react-dynamic', root);
      markLightSurfacesFromHints(root);
      markLightSurfacesWalk(root);
      escalateLightSurfaceBackgrounds(root);
      markLightFormFields(root);
      adaptClassicEditorFrames(root);
      adaptCustomSelectValues(root);
      adaptTypography(root);
      adaptButtonsReact(root);
      adaptToggles(root, 180);
      adaptIcons(root, 220);
      perfEnd(perf);
    }, 180);
  }

  function runReactFastAdapt(wrap, root) {
    var perf = perfStart('react-fast', root);
    wrap.classList.add('ysh-adaptive-active', 'ysh-adapt-react-css-only');
    root.classList.add('ysh-adaptive-active', 'ysh-adapt-react-css-only');
    setAdaptProfile(wrap, root, 'react');

    if (!reactAdaptLocked) {
      markLightSurfaces(root);
      markLightFormFields(root);
      adaptClassicEditorFrames(root);
      adaptCustomSelectValues(root);
    }
    adaptButtonsReact(root);
    adaptToggles(root, 180);
    adaptIcons(root, 220);

    markAdaptReady();

    if (hasReactPainted(root) && !reactAdaptLocked) {
      reactAdaptLocked = true;
      pauseHeavyObservers();
    }
    perfEnd(perf);
  }

  function runFastPluginFormAdapt(wrap, root) {
    var perf = perfStart('fast-form', root);
    wrap.classList.add('ysh-adaptive-active', 'ysh-adapt-react-css-only');
    root.classList.add('ysh-adaptive-active', 'ysh-adapt-react-css-only');
    setAdaptProfile(wrap, root, 'fast-form');

    if (!formAdaptLocked) {
      markLightFormFields(root);
      adaptClassicEditorFrames(root);
      adaptCustomSelectValues(root);
      adaptToggles(root, 100);
    }

    markAdaptReady();
    formAdaptLocked = true;
    pauseHeavyObservers();
    perfEnd(perf);
  }

  function runDenseGridAdapt(wrap, root) {
    var perf = perfStart('dense', root);
    wrap.classList.add('ysh-adaptive-active', 'ysh-adapt-dense-css-only');
    root.classList.add('ysh-adaptive-active', 'ysh-adapt-dense-css-only');
    setAdaptProfile(wrap, root, 'dense');

    if (!denseAdaptLocked) {
      markLightSurfaces(root, true);
      root.querySelectorAll('.postbox, .notice').forEach(function (panel) {
        if (!shouldSkipSurface(panel)) {
          markLightSurfacesFromHints(panel);
          escalateLightSurfaceBackgrounds(panel);
        }
      });
      root.querySelectorAll('.button, .button-primary, .button-secondary').forEach(function (btn) {
        if (!shouldSkipBtn(btn)) {
          btn.setAttribute('data-ysh-adapt-btn', classifyButtonTier(btn));
        }
      });
      adaptToggles(root, 220);
      adaptIcons(root, 260);
      adaptClassicEditorFrames(root);
      adaptCustomSelectValues(root);
    }

    markAdaptReady();
    denseAdaptLocked = true;
    pauseHeavyObservers();
    perfEnd(perf);
  }

  function normalizeWidefatTableHeads(root) {
    if (!root || !root.querySelectorAll) {
      return;
    }
    root.querySelectorAll(
      'table.widefat:not(.wp-list-table) thead :is(th, td), table.plugin-check__results-table thead :is(th, td)'
    ).forEach(function (cell) {
      cell.removeAttribute('data-ysh-adapt-text');
      cell.classList.remove('ysh-adapt-light-bg', 'ysh-adapt-light-nested');
      cell.style.removeProperty('background');
      cell.style.removeProperty('background-color');
      cell.style.removeProperty('color');
      cell.style.removeProperty('-webkit-text-fill-color');
    });
  }

  function runDynamicSurfaceAdapt(root) {
    if (!root || !root.querySelectorAll) {
      return;
    }
    var perf = perfStart('dynamic-surface', root);
    markLightSurfacesFromHints(root);
    markLightSurfacesWalk(root);
    escalateLightSurfaceBackgrounds(root);
    markLightFormFields(root);
    adaptClassicEditorFrames(root);
    adaptCustomSelectValues(root);
    adaptTypography(root);
    normalizeWidefatTableHeads(root);
    adaptButtons(root);
    adaptInteractives(root);
    adaptToggles(root, 180);
    adaptIcons(root, 220);
    perfEnd(perf);
  }

  function runPluginSettingsAdapt(shell, root) {
    var perf = perfStart('plugin-settings', root);
    shell.classList.add('ysh-adaptive-active');
    root.classList.add('ysh-adaptive-active', 'ysh-adapt-plugin-settings');
    setAdaptProfile(shell, root, 'plugin-settings');
    forceVendorLightCanvas();
    markLightSurfaces(root, true);
    markLightFormFields(root);
    markAdaptReady();
    pluginSettingsAdaptLocked = true;
    perfEnd(perf);
  }

  function runClassicAdapt(wrap, root) {
    var perf = perfStart('classic', root);
    var hintsOnly = shouldUseHintsOnlySurfacePass(root);
    setAdaptProfile(wrap, root, 'unknown');
    forceVendorLightCanvas();
    if (adaptPassCount >= MAX_CLASSIC_ADAPT_PASSES) {
      runDynamicSurfaceAdapt(root);
      markAdaptReady();
      perfEnd(perf);
      return;
    }

    if (adaptPassCount > 0) {
      clearMarks(root, true);
    }
    adaptPassCount++;

    wrap.classList.add('ysh-adaptive-active');
    markLightSurfaces(root, hintsOnly);
    markLightFormFields(root);
    adaptClassicEditorFrames(root);
    adaptCustomSelectValues(root);
    adaptTypography(root);
    adaptButtons(root);
    adaptInteractives(root);
    adaptToggles(root, 220);
    adaptIcons(root, 260);
    normalizeWidefatTableHeads(root);
    markAdaptReady();
    perfEnd(perf);
  }

  function forceTokenAppFoundation(root) {
    var wpcontent;
    var wpbody;
    if (!root || !root.querySelectorAll) {
      return;
    }
    wpcontent = document.getElementById('wpcontent');
    wpbody = document.getElementById('wpbody-content');
    [wpcontent, wpbody, root.parentElement].forEach(function (el) {
      if (!el || el.nodeType !== 1) {
        return;
      }
      el.style.setProperty('background', 'var(--ysh-surface, #12151a)', 'important');
      el.style.setProperty('background-color', 'var(--ysh-surface, #12151a)', 'important');
    });
    root.style.setProperty('background', 'var(--ysh-surface, #12151a)', 'important');
    root.style.setProperty('background-color', 'var(--ysh-surface, #12151a)', 'important');
    root.style.setProperty('color', 'var(--ysh-text, #cfd6e0)', 'important');
    root.style.setProperty('color-scheme', 'dark', 'important');
  }

  function runTokenAppAdapt(shell, root) {
    var perf = perfStart('token-app', root);
    shell.classList.add('ysh-adaptive-active');
    root.classList.add('ysh-adaptive-active', 'ysh-adapt-token-app');
    setAdaptProfile(shell, root, 'token');
    remapDesignTokenApps(root);
    forceTokenAppFoundation(root);
    markLightSurfacesFromHints(root);
    markLightSurfacesWalk(root);
    escalateLightSurfaceBackgrounds(root);
    markLightFormFields(root);
    adaptClassicEditorFrames(root);
    adaptCustomSelectValues(root);
    adaptTypography(root);
    adaptButtons(root);
    adaptInteractives(root);
    adaptToggles(root, 220);
    adaptIcons(root, 260);
    markAdaptReady();
    perfEnd(perf);
  }

  function scheduleAdaptHeavy() {
    if (heavyAdaptRaf) {
      window.cancelAnimationFrame(heavyAdaptRaf);
    }
    heavyAdaptRaf = window.requestAnimationFrame(function () {
      heavyAdaptRaf = null;
      var ctx = getPluginAdminShell();
      if (!ctx || !isDarkMode()) {
        return;
      }
      var root = ctx.root;
      var profile = classifyAdaptRoot(root);
      setAdaptProfile(ctx.shell, root, profile);
      if (profile === 'react') {
        adaptButtonsReact(root);
        adaptToggles(root, 180);
        adaptIcons(root, 220);
        return;
      }
      if (profile === 'token') {
        runTokenAppAdapt(ctx.shell, root);
        return;
      }
      runClassicAdapt(ctx.shell, root);
    });
  }

  function runAdaptFastForColorMode() {
    var ctx = getPluginAdminShell();
    var shell;
    var root;

    if (debounceTimer) {
      window.clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    if (heavyAdaptRaf) {
      window.cancelAnimationFrame(heavyAdaptRaf);
      heavyAdaptRaf = null;
    }

    if (!ctx) {
      markAdaptReady();
      return;
    }

    if (pageHasWpReactComponents()) {
      ctx.shell.classList.add('ysh-adaptive-active');
      ctx.root.classList.add('ysh-adaptive-active');
      markAdaptReady();
      stopHeavyObservers();
      return;
    }

    shell = ctx.shell;
    root = ctx.root;
    reactAdaptLocked = false;
    denseAdaptLocked = false;
    formAdaptLocked = false;
    pluginSettingsAdaptLocked = false;
    adaptPassCount = 0;

    if (!isDarkMode()) {
      clearMarks(root, true);
      markAdaptReady();
      return;
    }

    shell.classList.add('ysh-adaptive-active');
    root.classList.add('ysh-adaptive-active');
    var profile = classifyAdaptRoot(root);
    setAdaptProfile(shell, root, profile);
    forceVendorLightCanvas();
    if (document.body) {
      document.body.classList.add('ysh-adapt-wait');
    }

    if (profile === 'plugin-settings') {
      if (document.body) {
        document.body.classList.remove('ysh-adapt-wait');
      }
      runPluginSettingsAdapt(shell, root);
      return;
    }

    if (profile === 'dense') {
      if (document.body) {
        document.body.classList.remove('ysh-adapt-wait');
      }
      runDenseGridAdapt(shell, root);
      return;
    }

    if (profile === 'fast-form') {
      if (document.body) {
        document.body.classList.remove('ysh-adapt-wait');
      }
      runFastPluginFormAdapt(shell, root);
      return;
    }

    if (profile === 'token') {
      runTokenAppAdapt(shell, root);
      return;
    }

    if (profile === 'react') {
      if (document.body) {
        document.body.classList.remove('ysh-adapt-wait');
      }
      runReactFastAdapt(shell, root);
      return;
    }

    markAdaptReady();
    runClassicAdapt(shell, root);
  }

  function scheduleDarkModeSettleAdapt() {
    var delays = [180, 720, 1600];
    var runId;
    var root = getAdaptRoot();
    var profile = root ? root.getAttribute('data-ysh-adapt-profile') || classifyAdaptRoot(root) : 'unknown';
    if (!isDarkMode()) {
      return;
    }
    if (profile !== 'unknown') {
      return;
    }
    if (root && (root.id === 'wpbody-content' || isDirectPluginSettingsRoot(root))) {
      return;
    }
    if (darkModeSettleTimer) {
      window.clearTimeout(darkModeSettleTimer);
    }
    darkModeSettleRun++;
    runId = darkModeSettleRun;
    delays.forEach(function (delay, index) {
      var timer = window.setTimeout(function () {
        root = getAdaptRoot();
        profile = root ? root.getAttribute('data-ysh-adapt-profile') || classifyAdaptRoot(root) : 'unknown';
        if (!isDarkMode() || runId !== darkModeSettleRun || profile !== 'unknown') {
          return;
        }
        if (index === delays.length - 1) {
          darkModeSettleTimer = null;
        }
        reactAdaptLocked = false;
        denseAdaptLocked = false;
        adaptPassCount = 0;
        runAdapt();
      }, delay);
      if (index === delays.length - 1) {
        darkModeSettleTimer = timer;
      }
    });
  }

  function runAdapt() {
    var ctx = getPluginAdminShell();
    var shell;
    var root;
    var profile;

    if (!ctx) {
      markAdaptReady();
      return;
    }

    if (pageHasWpReactComponents()) {
      ctx.shell.classList.add('ysh-adaptive-active');
      ctx.root.classList.add('ysh-adaptive-active');
      markAdaptReady();
      stopHeavyObservers();
      return;
    }

    if (adaptRunning) {
      return;
    }
    adaptRunning = true;

    shell = ctx.shell;
    root = ctx.root;

    if (!isDarkMode()) {
      clearMarks(root, true);
      reactAdaptLocked = false;
      denseAdaptLocked = false;
      formAdaptLocked = false;
      pluginSettingsAdaptLocked = false;
      adaptPassCount = 0;
      markAdaptReady();
      adaptRunning = false;
      return;
    }

    profile = classifyAdaptRoot(root);
    setAdaptProfile(shell, root, profile);

    try {
      if (profile === 'fast-form') {
        runFastPluginFormAdapt(shell, root);
        return;
      }

      if (profile === 'react') {
        runReactFastAdapt(shell, root);
        return;
      }

      if (profile === 'dense') {
        runDenseGridAdapt(shell, root);
        return;
      }

      if (profile === 'token') {
        runTokenAppAdapt(shell, root);
        return;
      }

      if (profile === 'plugin-settings') {
        if (pluginSettingsAdaptLocked) {
          markAdaptReady();
          return;
        }
        runPluginSettingsAdapt(shell, root);
        return;
      }

      runClassicAdapt(shell, root);
    } finally {
      adaptRunning = false;
    }
  }

  function scheduleAdapt(mutations) {
    if (!isDarkMode()) {
      return;
    }
    if (pluginSettingsAdaptLocked) {
      return;
    }
    if (mutations && mutations.length) {
      for (var mi = 0; mi < mutations.length; mi++) {
        var mm = mutations[mi];
        if (mm.type !== 'childList' || !mm.addedNodes) {
          continue;
        }
        for (var ni = 0; ni < mm.addedNodes.length; ni++) {
          if (nodeMatchesPortal(mm.addedNodes[ni])) {
            adaptBodyPortals();
            return;
          }
        }
      }
    }
    var rootForProfile = getAdaptRoot();
    var profileForSchedule = rootForProfile
      ? rootForProfile.getAttribute('data-ysh-adapt-profile') || classifyAdaptRoot(rootForProfile)
      : 'unknown';
    if ((denseAdaptLocked || profileForSchedule === 'dense' || profileForSchedule === 'fast-form') && mutations) {
      if (mutations && mutations.length) {
        var pi;
        var pm;
        var added;
        var ai;
        for (pi = 0; pi < mutations.length; pi++) {
          pm = mutations[pi];
          if (pm.type !== 'childList' || !pm.addedNodes) {
            continue;
          }
          for (ai = 0; ai < pm.addedNodes.length; ai++) {
            added = pm.addedNodes[ai];
            if (nodeMatchesPortal(added)) {
              adaptBodyPortals();
              return;
            }
          }
        }
      }
      return;
    }
    if (reactAdaptLocked && mutations) {
      scheduleReactDynamicAdapt();
      return;
    }
    if (isSelfTriggeredMutation(mutations)) {
      return;
    }
    if (debounceTimer) {
      window.clearTimeout(debounceTimer);
    }
    var root = rootForProfile;
    var delay = profileForSchedule === 'react' ? DEBOUNCE_REACT_MS : DEBOUNCE_MS;
    debounceTimer = window.setTimeout(runAdapt, delay);
  }

  function startReactPoll() {
    var root = getAdaptRoot();
    if (!isDarkMode() || !root || classifyAdaptRoot(root) !== 'react') {
      return;
    }
    if (reactPollTimer) {
      window.clearInterval(reactPollTimer);
    }
    reactPollCount = 0;
    reactPollTimer = window.setInterval(function () {
      if (reactAdaptLocked) {
        adaptButtonsReact(root);
        reactPollCount++;
        if (reactPollCount >= REACT_POLL_MAX) {
          if (reactPollTimer) {
            window.clearInterval(reactPollTimer);
            reactPollTimer = null;
          }
        }
        return;
      }
      runAdapt();
      reactPollCount++;
      if (reactPollCount >= REACT_POLL_MAX) {
        pauseHeavyObservers();
      }
    }, REACT_POLL_MS);
  }

  function reconnectPluginAdminObservers() {
    if (window.__yshReactBtnObs) {
      window.__yshReactBtnObs.disconnect();
      window.__yshReactBtnObs = null;
    }
    if (reactPollTimer) {
      window.clearInterval(reactPollTimer);
      reactPollTimer = null;
    }
    if (isDarkMode()) {
      primeAdaptShell();
      watch();
      startReactPoll();
    } else {
      stopHeavyObservers();
    }
    ensureColorModeObserver();
  }

  function onStudioColorModeChanged() {
    if (!isDarkMode()) {
      if (darkModeSettleTimer) {
        window.clearTimeout(darkModeSettleTimer);
        darkModeSettleTimer = null;
      }
      stopHeavyObservers();
      clearLightModeShellState();
      reactAdaptLocked = false;
      denseAdaptLocked = false;
      formAdaptLocked = false;
      pluginSettingsAdaptLocked = false;
      adaptPassCount = 0;
      return;
    }
    if (window.__yshAdaptModeSyncHandled) {
      window.__yshAdaptModeSyncHandled = false;
      runAdaptFastForColorMode();
      scheduleDarkModeSettleAdapt();
      reconnectPluginAdminObservers();
      return;
    }
    runAdaptFastForColorMode();
    scheduleDarkModeSettleAdapt();
    reconnectPluginAdminObservers();
  }

  function watch() {
    if (rootObserver) {
      rootObserver.disconnect();
    }
    if (!isDarkMode()) {
      rootObserver = null;
      return;
    }
    var shell = getAdaptShell();
    var root = getAdaptRoot();
    var profile = root ? root.getAttribute('data-ysh-adapt-profile') || classifyAdaptRoot(root) : 'unknown';
    var dense = profile === 'dense';
    ensureColorModeObserver();
    ensureBodyPortalObserver();
    if (root && profile === 'plugin-settings' && pluginSettingsAdaptLocked) {
      rootObserver = null;
      return;
    }
    if (root && profile === 'fast-form' && formAdaptLocked) {
      rootObserver = null;
      return;
    }
    if (root && profile === 'react' && reactAdaptLocked) {
      rootObserver = null;
      ensureReactButtonObserver();
      return;
    }
    if (shell) {
      var observeTarget = root && root !== shell ? root : shell;
      var wpbodyWide = observeTarget.id === 'wpbody-content';
      var subtree = !wpbodyWide && !(dense || profile === 'token');
      var attributes = subtree;
      rootObserver = new MutationObserver(scheduleAdapt);
      rootObserver.observe(observeTarget, {
        childList: true,
        subtree: subtree,
        attributes: attributes,
        attributeFilter: attributes ? ['class', 'style', 'hidden', 'aria-hidden'] : undefined,
      });
    }
  }

  function isBarePluginSettingsScreen() {
    return document.body && document.body.classList.contains('ysh-bare-plugin-settings');
  }

  function isClassicEditorPluginConflictScreen() {
    if (!document.body || document.body.classList.contains('block-editor-page')) {
      return false;
    }
    if (
      document.body.classList.contains('ysh-classic-editor-light-compat') ||
      document.body.classList.contains('ysh-classic-editor-static-dark')
    ) {
      return true;
    }
    var isPostEditor =
      document.body.classList.contains('post-php') || document.body.classList.contains('post-new-php');
    if (!isPostEditor) {
      return false;
    }
    var yoast = !!(
      document.getElementById('wpseo-metabox-root') ||
      document.getElementById('wpseo_meta') ||
      document.querySelector('#wpseo-metabox-root, .wpseo-metabox-content')
    );
    var builder = !!(
      document.querySelector(
        '[id^="brz-"], [class*="brz-root"], #breezy-editor, .breezy-editor, [class*="breezy-editor"], iframe[src*="brizy"], iframe[src*="breezy"]'
      )
    );
    return yoast || builder;
  }

  function boot() {
    initPerfFlag();
    if (
      document.body &&
      (document.body.classList.contains('block-editor-page') ||
        document.body.classList.contains('site-editor-php'))
    ) {
      return;
    }
    if (isBarePluginSettingsScreen() || isClassicEditorPluginConflictScreen()) {
      markAdaptReady();
      return;
    }
    if (isYooadminNativeExperienceScreen()) {
      return;
    }
    if (isWpCoreToolsStaticCompatScreen()) {
      return;
    }
    ensureColorModeObserver();
    document.addEventListener('ysh-studio-color-mode-changed', onStudioColorModeChanged);
    window.addEventListener('hashchange', function () {
      if (isDarkMode()) {
        scheduleReactButtonsOnly();
      }
    });
    window.addEventListener('popstate', function () {
      if (isDarkMode()) {
        scheduleReactButtonsOnly();
      }
    });
    if (!isDarkMode()) {
      clearLightModeShellState();
      markAdaptReady();
      return;
    }
    primeAdaptShell();
    forceAdaptReadySoon();
    runAdapt();
    watch();
    startReactPoll();
    document.addEventListener('DOMContentLoaded', function () {
      if (!isDarkMode()) {
        return;
      }
      if (!isAdaptPerfLocked()) {
        runAdapt();
      }
      startReactPoll();
    });
    window.addEventListener('load', function () {
      if (!isDarkMode()) {
        return;
      }
      if (!isAdaptPerfLocked()) {
        runAdapt();
      }
      startReactPoll();
    });
    document.addEventListener('yooadmin-plugins-layout-ready', function () {
      if (!isDarkMode()) {
        return;
      }
      var wrap = document.querySelector(ROOT_WRAP);
      if (wrap) {
        clearMarks(wrap, true);
      }
      reactAdaptLocked = false;
      denseAdaptLocked = false;
      adaptPassCount = 0;
      scheduleAdapt();
    });
  }

  window.yshPluginAdminAdaptSyncMode = function () {
    if (isYooadminNativeExperienceScreen() || isBarePluginSettingsScreen()) {
      return;
    }
    window.__yshAdaptModeSyncHandled = true;
    if (!isDarkMode()) {
      stopHeavyObservers();
      clearLightModeShellState();
      return;
    }
    runAdaptFastForColorMode();
    scheduleDarkModeSettleAdapt();
  };

  boot();
})();
