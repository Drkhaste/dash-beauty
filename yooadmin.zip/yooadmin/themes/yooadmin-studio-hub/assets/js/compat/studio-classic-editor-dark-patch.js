/**
 * Classic editor — one-shot surface patch for React/light inline styles (Yoast, tabs-panel).
 * Scoped + idle-scheduled; not a full DOM adaptive engine.
 */
(function () {
  'use strict';

  var PATCHED = 'data-ysh-dark-patched';
  var MAX_NODES = 320;
  var YOAST_MAX = 220;
  var PATCH_PROPS = [
    'background',
    'background-color',
    'color',
    '-webkit-text-fill-color',
    'border-color',
    'border',
    'box-shadow',
    'accent-color',
    'overflow-x',
    'max-width',
    'box-sizing',
    'width',
    'display',
    'z-index',
    'pointer-events',
    'opacity',
    'cursor',
    'text-decoration',
    'text-shadow',
    'transition'
  ];

  function isDark() {
    var html = document.documentElement;
    if (html.getAttribute('data-yooadmin-studio-color-mode-effective') === 'dark') {
      return true;
    }
    if (html.classList.contains('is-dark-theme')) {
      return true;
    }
    var body = document.body;
    if (body && body.classList.contains('is-dark-theme')) {
      return true;
    }
    var mode = html.getAttribute('data-yooadmin-studio-color-mode');
    if (mode === 'dark') {
      return true;
    }
    if (mode === 'auto') {
      try {
        return window.matchMedia('(prefers-color-scheme: dark)').matches;
      } catch (e) {
        return false;
      }
    }
    return false;
  }

  function isLightRgb(rgb) {
    if (!rgb || rgb === 'transparent' || rgb === 'rgba(0, 0, 0, 0)') {
      return false;
    }
    var m = rgb.match(/\d+/g);
    if (!m || m.length < 3) {
      return false;
    }
    return Number(m[0]) + Number(m[1]) + Number(m[2]) > 600;
  }

  function isDarkText(rgb) {
    if (!rgb || rgb === 'transparent') {
      return false;
    }
    var m = rgb.match(/\d+/g);
    if (!m || m.length < 3) {
      return false;
    }
    return Number(m[0]) + Number(m[1]) + Number(m[2]) < 280;
  }

  function isSiteOriginContext(el) {
    return !!(el && el.closest && el.closest('.so-panels-dialog, .siteorigin-panels-builder'));
  }

  function shouldSkip(el) {
    if (!el || el.nodeType !== 1) {
      return true;
    }
    if (isSiteOriginContext(el)) {
      return el.matches('img, svg, iframe, canvas, video');
    }
    if (el.getAttribute(PATCHED) === '1') {
      return true;
    }
    if (el.matches('img, svg, iframe, canvas, video, .wpseo-score-icon, [class*="traffic-light"]')) {
      return true;
    }
    return false;
  }

  function forceDarkSurface(el) {
    if (!el || el.nodeType !== 1 || el.matches('img, svg, iframe, canvas, video, .wpseo-score-icon, [class*="traffic-light"]')) {
      return;
    }

    el.style.setProperty('background', '#22262e', 'important');
    el.style.setProperty('background-color', '#22262e', 'important');
    el.style.setProperty('color', '#cfd6e0', 'important');
    el.style.setProperty('-webkit-text-fill-color', '#cfd6e0', 'important');
    el.style.setProperty('border-color', 'rgba(255,255,255,0.12)', 'important');
    el.style.setProperty('box-shadow', 'none', 'important');
    el.setAttribute(PATCHED, '1');
  }

  function clearElementPatch(el) {
    if (!el || el.nodeType !== 1) {
      return;
    }

    PATCH_PROPS.forEach(function (prop) {
      el.style.removeProperty(prop);
    });
    el.removeAttribute(PATCHED);
  }

  function unpatchSurfaces() {
    document.querySelectorAll('[' + PATCHED + '="1"]').forEach(clearElementPatch);

    var statusRow = document.getElementById('post-status-info');
    if (statusRow) {
      clearElementPatch(statusRow);
      statusRow.querySelectorAll('td, th').forEach(clearElementPatch);
    }

    document.querySelectorAll('.mce-edit-area, iframe[id$="_ifr"]').forEach(clearElementPatch);
    document
      .querySelectorAll('.wp-editor-wrap, .wp-editor-container, #wp-content-editor-container, .mce-edit-area')
      .forEach(clearElementPatch);
    document.querySelectorAll('.mce-edit-area iframe').forEach(clearElementPatch);

    var yoast = document.getElementById('wpseo_meta');
    if (yoast) {
      yoast.style.removeProperty('z-index');
      yoast.style.removeProperty('pointer-events');
    }

    document.querySelectorAll('.so-overlay').forEach(clearElementPatch);
    document
      .querySelectorAll(
        '.so-panels-dialog .so-content, .so-panels-dialog .so-title-bar, .so-panels-dialog .so-left-sidebar, .so-panels-dialog .so-right-sidebar, .so-panels-dialog .so-toolbar'
      )
      .forEach(clearElementPatch);

    if (siteOriginGuardTimer) {
      window.clearInterval(siteOriginGuardTimer);
      siteOriginGuardTimer = null;
    }
  }

  function applyDarkSurface(el) {
    var cs = window.getComputedStyle(el);
    if (isLightRgb(cs.backgroundColor)) {
      el.style.setProperty('background-color', '#22262e', 'important');
      if (isLightRgb(cs.color) || isDarkText(cs.color)) {
        el.style.setProperty('color', '#cfd6e0', 'important');
        el.style.setProperty('-webkit-text-fill-color', '#cfd6e0', 'important');
      }
    }
    if (isLightRgb(cs.color)) {
      el.style.setProperty('color', '#cfd6e0', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#cfd6e0', 'important');
    }
    if (isLightRgb(cs.borderTopColor) || isLightRgb(cs.borderBottomColor)) {
      el.style.setProperty('border-color', 'rgba(255,255,255,0.12)', 'important');
    }
    el.setAttribute(PATCHED, '1');
  }

  function applyReadableText(el) {
    var cs = window.getComputedStyle(el);
    if (isDarkText(cs.color)) {
      el.style.setProperty('color', '#cfd6e0', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#cfd6e0', 'important');
    }
    el.setAttribute(PATCHED, '1');
  }

  function patchYoastTypography() {
    if (!isDark()) {
      return;
    }

    var meta = document.getElementById('wpseo_meta');
    if (!meta) {
      return;
    }

    meta.querySelectorAll('label, legend, [class*="yst-label"], [class*="field-group__title"]').forEach(function (el) {
      if (shouldSkip(el)) {
        return;
      }
      applyReadableText(el);
    });

    meta.querySelectorAll('[class*="yst-replacevar"] button, [class*="yst-replacevar"] [role="button"], [class*="yst-replacevar"] span').forEach(function (el) {
      if (shouldSkip(el)) {
        return;
      }
      applyDarkSurface(el);
      applyReadableText(el);
    });

    meta.querySelectorAll('[class*="prominent"], [class*="word-form"], [class*="wordform"]').forEach(function (section) {
      section.querySelectorAll('div, span, td, th, li').forEach(function (el) {
        if (shouldSkip(el)) {
          return;
        }
        var cs = window.getComputedStyle(el);
        if (isLightRgb(cs.backgroundColor)) {
          el.style.setProperty('background-color', '#3a4254', 'important');
          el.style.setProperty('color', '#e8ecf1', 'important');
          el.style.setProperty('-webkit-text-fill-color', '#e8ecf1', 'important');
          el.setAttribute(PATCHED, '1');
        } else if (isLightRgb(cs.color)) {
          applyDarkSurface(el);
        } else if (isDarkText(cs.color)) {
          applyReadableText(el);
        }
      });
    });

    meta.querySelectorAll('[class*="snippet"], [class*="preview"], [class*="google"]').forEach(function (section) {
      section.querySelectorAll('p, span, div, a, time').forEach(function (el) {
        if (shouldSkip(el)) {
          return;
        }
        applyReadableText(el);
        if (isDarkText(window.getComputedStyle(el).color)) {
          el.style.setProperty('color', '#9aa5b1', 'important');
          el.style.setProperty('-webkit-text-fill-color', '#9aa5b1', 'important');
        }
      });
    });
  }

  function patchRoot(root, maxNodes) {
    if (!root || !isDark()) {
      return;
    }

    var limit = typeof maxNodes === 'number' ? maxNodes : MAX_NODES;
    var nodes = root.querySelectorAll(
      'div, section, fieldset, article, li, label, input, textarea, select, button, header, [class*="yst-"], .tabs-panel, .wp-tab-panel, [role="tab"], [role="tabpanel"]'
    );
    var patched = 0;

    nodes.forEach(function (el) {
      if (patched >= limit || shouldSkip(el)) {
        return;
      }

      var cs = window.getComputedStyle(el);
      if (!isLightRgb(cs.backgroundColor) && !isLightRgb(cs.color)) {
        return;
      }

      applyDarkSurface(el);
      patched += 1;
    });
  }

  function patchYoastChrome() {
    if (!isDark()) {
      return;
    }

    var meta = document.getElementById('wpseo_meta');
    if (!meta) {
      return;
    }

    meta.querySelectorAll(
      '[role="tablist"], [role="tab"], button[role="tab"], .yoast-aria-tabs, .yoast-aria-tabs > *, [class*="yst-tab"], [class*="yst-accordion"], [class*="yst-box"]'
    ).forEach(function (el) {
      if (shouldSkip(el)) {
        return;
      }
      applyDarkSurface(el);
    });

    patchRoot(document.getElementById('wpseo-metabox-root'), YOAST_MAX);
    patchRoot(meta, YOAST_MAX);
  }

  function patchTinyMceShell() {
    if (!isDark()) {
      return;
    }

    document.querySelectorAll('.mce-edit-area, iframe[id$="_ifr"]').forEach(function (el) {
      el.style.setProperty('background-color', '#1a1d23', 'important');
      el.setAttribute(PATCHED, '1');
    });

    document.querySelectorAll(
      '.mce-statusbar, .mce-statusbar .mce-path, .mce-statusbar .mce-flow-layout-item, .mce-path-item, .mce-listbox button, .mce-btn-has-text, #post-status-info, #post-status-info td'
    ).forEach(function (el) {
      if (shouldSkip(el)) {
        return;
      }
      applyDarkSurface(el);
    });
  }

  function patchQuicktags() {
    if (!isDark()) {
      return;
    }

    document.querySelectorAll('.quicktags-toolbar input.button').forEach(function (btn) {
      if (shouldSkip(btn)) {
        return;
      }
      btn.style.setProperty('background', 'rgba(255,255,255,0.07)', 'important');
      btn.style.setProperty('background-color', 'rgba(255,255,255,0.07)', 'important');
      btn.style.setProperty('border-color', 'rgba(255,255,255,0.16)', 'important');
      btn.style.setProperty('color', '#cfd6e0', 'important');
      btn.style.setProperty('box-shadow', 'none', 'important');
      btn.setAttribute(PATCHED, '1');
    });
  }

  function fixEditorOverflow() {
    if (!isDark()) {
      return;
    }

    document
      .querySelectorAll('.wp-editor-wrap, .wp-editor-container, #wp-content-editor-container, .mce-edit-area')
      .forEach(function (el) {
        el.style.setProperty('max-width', '100%', 'important');
        el.style.setProperty('box-sizing', 'border-box', 'important');
        el.setAttribute(PATCHED, '1');
      });

    document.querySelectorAll('.mce-edit-area').forEach(function (area) {
      area.style.setProperty('overflow-x', 'hidden', 'important');
      area.setAttribute(PATCHED, '1');
    });

    document.querySelectorAll('.mce-edit-area iframe').forEach(function (frame) {
      frame.style.setProperty('width', '100%', 'important');
      frame.style.setProperty('max-width', '100%', 'important');
      frame.style.setProperty('display', 'block', 'important');
      frame.setAttribute(PATCHED, '1');
    });
  }

  function fixSiteOriginModalStacking() {
    if (!isDark()) {
      return;
    }

    document.querySelectorAll('.so-overlay').forEach(function (el) {
      el.style.setProperty('z-index', '100049', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
      el.setAttribute(PATCHED, '1');
    });

    document
      .querySelectorAll(
        '.so-panels-dialog .so-content, .so-panels-dialog .so-title-bar, .so-panels-dialog .so-left-sidebar, .so-panels-dialog .so-right-sidebar, .so-panels-dialog .so-toolbar'
      )
      .forEach(function (el) {
        el.style.setProperty('z-index', '100052', 'important');
        el.style.setProperty('pointer-events', 'auto', 'important');
        el.setAttribute(PATCHED, '1');
      });

    var yoast = document.getElementById('wpseo_meta');
    if (yoast) {
      if (document.querySelector('.so-panels-dialog')) {
        yoast.style.setProperty('z-index', 'auto', 'important');
        yoast.style.setProperty('pointer-events', 'none', 'important');
      } else {
        yoast.style.removeProperty('pointer-events');
      }
    }
  }

  function forceSiteOriginWidgetCard(card) {
    if (!card || card.nodeType !== 1) {
      return;
    }

    card.style.setProperty('display', 'block', 'important');
    card.style.setProperty('background', '#22262e', 'important');
    card.style.setProperty('background-color', '#22262e', 'important');
    card.style.setProperty('color', '#cfd6e0', 'important');
    card.style.setProperty('-webkit-text-fill-color', '#cfd6e0', 'important');
    card.style.setProperty('border-color', 'rgba(255,255,255,0.14)', 'important');
    card.style.setProperty('opacity', '1', 'important');
    card.style.setProperty('pointer-events', 'auto', 'important');
    card.style.setProperty('cursor', 'pointer', 'important');
    card.style.setProperty('text-decoration', 'none', 'important');

    card.querySelectorAll('h3, small, span, p, label, a, .widget-icon').forEach(function (child) {
      if (child.matches('img, svg, iframe')) {
        return;
      }
      child.style.setProperty('color', '#cfd6e0', 'important');
      child.style.setProperty('-webkit-text-fill-color', '#cfd6e0', 'important');
      child.style.setProperty('opacity', '1', 'important');
      child.setAttribute(PATCHED, '1');
    });
    card.setAttribute(PATCHED, '1');
  }

  function forceSiteOriginBuilderWidget(widget) {
    if (!widget || widget.nodeType !== 1) {
      return;
    }

    forceDarkSurface(widget);
    widget.querySelectorAll('.so-widget-wrapper, .title, .widget-title, h3, h4, small, .description, p, span, label').forEach(function (child) {
      if (child.matches('img, svg')) {
        return;
      }
      forceDarkSurface(child);
      child.style.setProperty('color', child.matches('small, h4 span') ? '#9aa5b1' : '#e8ecf1', 'important');
      child.style.setProperty('-webkit-text-fill-color', child.matches('small, h4 span') ? '#9aa5b1' : '#e8ecf1', 'important');
      child.style.setProperty('text-shadow', 'none', 'important');
    });
  }

  function forceSiteOriginVisualStyles(root) {
    if (!root || root.nodeType !== 1) {
      return;
    }

    forceDarkSurface(root);
    root.style.setProperty('background-color', '#1a1d23', 'important');
    root.querySelectorAll('.style-section-head, .style-section-fields, .style-field-wrapper, .style-field, .style-input-wrapper, .so-wp-slider-wrapper, .so-wp-slider-value, .style-field-measurement').forEach(function (el) {
      forceDarkSurface(el);
      applyReadableText(el);
    });
    root.querySelectorAll('h3, h4, label, .style-section-head h4').forEach(function (el) {
      el.style.setProperty('color', '#e8ecf1', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#e8ecf1', 'important');
      el.style.setProperty('text-shadow', 'none', 'important');
      el.setAttribute(PATCHED, '1');
    });
    root.querySelectorAll('p, span, small, .description').forEach(function (el) {
      el.style.setProperty('color', '#9aa5b1', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#9aa5b1', 'important');
      el.setAttribute(PATCHED, '1');
    });
  }

  function forceSiteOriginRightSidebar(sidebar) {
    if (!sidebar || sidebar.nodeType !== 1) {
      return;
    }

    forceDarkSurface(sidebar);
    sidebar.style.setProperty('background-color', '#1a1d23', 'important');
    sidebar.querySelectorAll('.so-sidebar, .so-visual-styles').forEach(function (el) {
      forceDarkSurface(el);
      el.style.setProperty('background-color', '#1a1d23', 'important');
    });
    sidebar.querySelectorAll('.so-visual-styles').forEach(forceSiteOriginVisualStyles);
    sidebar.querySelectorAll('*').forEach(function (el) {
      if (el.matches('img, svg, iframe, canvas, video, input, select, textarea, .iris-picker, .wp-picker-holder')) {
        return;
      }
      if (isLightRgb(window.getComputedStyle(el).backgroundColor)) {
        forceDarkSurface(el);
      }
      if (el.matches('h3, h4, label')) {
        el.style.setProperty('color', '#e8ecf1', 'important');
        el.style.setProperty('-webkit-text-fill-color', '#e8ecf1', 'important');
        el.setAttribute(PATCHED, '1');
      }
    });
  }

  var siteOriginGuardTimer = null;

  function startSiteOriginGuard() {
    if (siteOriginGuardTimer || !isDark()) {
      return;
    }

    siteOriginGuardTimer = window.setInterval(function () {
      if (!isDark()) {
        window.clearInterval(siteOriginGuardTimer);
        siteOriginGuardTimer = null;
        return;
      }
      if (!document.querySelector('.so-panels-dialog') && !document.querySelector('.siteorigin-panels-builder')) {
        window.clearInterval(siteOriginGuardTimer);
        siteOriginGuardTimer = null;
        return;
      }
      patchSiteOriginPanels();
    }, 420);
  }

  function patchYoastGooglePreview() {
    if (!isDark()) {
      return;
    }

    var meta = document.getElementById('wpseo_meta');
    if (!meta) {
      return;
    }

    meta.querySelectorAll('div, section, article, fieldset').forEach(function (el) {
      var cls = typeof el.className === 'string' ? el.className : '';
      var testId = el.getAttribute('data-testid') || '';
      var cs = window.getComputedStyle(el);
      var isPreview =
        /(SnippetPreview|snippet-preview|GooglePreview|google-preview|yst-snippet|bg-white)/i.test(cls) ||
        (testId && testId.indexOf('preview') !== -1) ||
        (el.closest('[class*="preview" i], [class*="snippet" i]') && isLightRgb(cs.backgroundColor));

      if (!isPreview) {
        return;
      }

      forceDarkSurface(el);
      el.style.setProperty('overflow-x', 'hidden', 'important');
      el.style.setProperty('max-width', '100%', 'important');
      el.style.setProperty('box-sizing', 'border-box', 'important');
      el.setAttribute(PATCHED, '1');
      el.querySelectorAll('div, span, p, a, time, h3').forEach(function (child) {
        if (shouldSkip(child)) {
          return;
        }
        if (isLightRgb(window.getComputedStyle(child).backgroundColor)) {
          forceDarkSurface(child);
        }
        applyReadableText(child);
      });
    });
  }

  function patchSidebarInputs() {
    if (!isDark()) {
      return;
    }

    var side = document.getElementById('side-sortables');
    if (!side) {
      return;
    }

    side.querySelectorAll('input, select, textarea, [contenteditable="true"]').forEach(function (el) {
      if (shouldSkip(el) || el.matches('[type="checkbox"], [type="radio"], [type="hidden"], [type="button"], [type="submit"]')) {
        return;
      }
      applyDarkSurface(el);
    });
  }

  function patchYoastFields() {
    if (!isDark()) {
      return;
    }

    var meta = document.getElementById('wpseo_meta');
    if (!meta) {
      return;
    }

    meta.querySelectorAll(
      '[contenteditable="true"], [role="textbox"], [class*="replacevar"], [class*="yst-replacevar"], [class*="yst-textfield"], [class*="yst-chip"], [class*="yst-badge"], [class*="yst-tag"], button[class*="yst-"], progress, meter, [role="progressbar"], [class*="progress"], [class*="indicator"], hr, ul, ol, li'
    ).forEach(function (el) {
      if (shouldSkip(el)) {
        return;
      }
      applyDarkSurface(el);
    });

    var thinBars = 0;
    meta.querySelectorAll('div, span').forEach(function (el) {
      if (thinBars >= 48 || shouldSkip(el)) {
        return;
      }
      var cs = window.getComputedStyle(el);
      var h = parseFloat(cs.height);
      if (h > 0 && h <= 10 && isLightRgb(cs.backgroundColor)) {
        el.style.setProperty('background-color', '#22262e', 'important');
        el.setAttribute(PATCHED, '1');
        thinBars += 1;
      }
    });
  }

  function patchPoststuffChrome() {
    if (!isDark()) {
      return;
    }

    var poststuff = document.getElementById('poststuff');
    if (!poststuff) {
      return;
    }

    poststuff.querySelectorAll('hr, fieldset, .misc-pub-section, .form-table th, .form-table td').forEach(function (el) {
      if (shouldSkip(el)) {
        return;
      }
      applyDarkSurface(el);
    });

    poststuff.querySelectorAll('label, legend, th, .description, .howto').forEach(function (el) {
      if (shouldSkip(el)) {
        return;
      }
      applyReadableText(el);
    });

    poststuff.querySelectorAll('input[type="checkbox"], input[type="radio"]').forEach(function (el) {
      if (shouldSkip(el)) {
        return;
      }
      el.style.setProperty('accent-color', '#eda934', 'important');
      el.style.setProperty('background-color', '#22262e', 'important');
      el.style.setProperty('border', '1px solid rgba(255,255,255,0.28)', 'important');
      el.setAttribute(PATCHED, '1');
    });

    poststuff.querySelectorAll('textarea:not(.wp-editor-area)').forEach(function (el) {
      if (shouldSkip(el)) {
        return;
      }
      applyDarkSurface(el);
    });
  }

  function patchSiteOriginPanels() {
    if (!isDark()) {
      return;
    }

    var builder = document.querySelector('.siteorigin-panels-builder');
    if (builder) {
      builder
        .querySelectorAll(
          '.so-builder-toolbar, .so-panels-welcome-message, .so-message-wrapper, .so-tool-button, .so-toolbar, .panel-grid-cell, .so-panel, .cell, .cell-wrapper, .so-widget, .so-widget-wrapper, .widget, .widget-wrapper, .so-preview, .style-wrapper, .panel-cell'
        )
        .forEach(function (el) {
          if (el.matches('img, svg, iframe')) {
            return;
          }
          forceDarkSurface(el);
          applyReadableText(el);
        });

      builder.querySelectorAll('.so-widget, .widget').forEach(forceSiteOriginBuilderWidget);
    }

    document.querySelectorAll('.so-panels-dialog').forEach(function (dialog) {
      dialog.querySelectorAll('.widget-type-wrapper').forEach(forceSiteOriginWidgetCard);
      dialog.querySelectorAll('.so-widgets a.so-widget, .so-widgets a[class*="widget"]').forEach(forceSiteOriginWidgetCard);
      dialog.querySelectorAll('.so-widgets .so-widget:not(a)').forEach(forceSiteOriginWidgetCard);

      dialog
        .querySelectorAll(
          '.so-title-bar, .so-title-bar *, .so-toolbar, .so-left-sidebar, .so-right-sidebar, .so-right-sidebar ul, .so-right-sidebar li, .so-right-sidebar a, .so-sidebar-tabs a, .so-sidebar-list, .so-sidebar-list li, .so-visual-styles, .so-visual-styles *, .style-section-head, .style-section-fields, .style-field, .so-field, .so-media-field, .so-media-image, .so-input-holder, input, select, textarea'
        )
        .forEach(function (el) {
          if (el.matches('img, svg, iframe') || el.closest('.so-widgets')) {
            return;
          }
          forceDarkSurface(el);
          applyReadableText(el);
        });

      dialog.querySelectorAll('.so-right-sidebar').forEach(forceSiteOriginRightSidebar);
      dialog.querySelectorAll('.so-visual-styles').forEach(forceSiteOriginVisualStyles);

      var content = dialog.querySelector('.so-content');
      if (content) {
        forceDarkSurface(content);
      }
    });

    fixSiteOriginModalStacking();
    startSiteOriginGuard();
  }

  function patchSurfaces() {
    if (!isDark()) {
      unpatchSurfaces();
      return;
    }

    if (document.querySelector('.so-panels-dialog')) {
      patchSiteOriginPanels();
      return;
    }

    patchYoastChrome();
    patchYoastFields();
    patchYoastTypography();
    patchYoastGooglePreview();
    patchTinyMceShell();
    patchQuicktags();
    fixEditorOverflow();
    patchSidebarInputs();
    patchPoststuffChrome();
    patchSiteOriginPanels();

    document.querySelectorAll('.categorydiv .tabs-panel, .tagsdiv .tabs-panel').forEach(function (panel) {
      patchRoot(panel, 80);
    });

    var statusRow = document.getElementById('post-status-info');
    if (statusRow) {
      statusRow.style.setProperty('background-color', '#1a1d23', 'important');
      statusRow.setAttribute(PATCHED, '1');
      statusRow.querySelectorAll('td, th').forEach(function (cell) {
        cell.style.setProperty('background-color', '#1a1d23', 'important');
        cell.style.setProperty('color', '#9aa5b1', 'important');
        cell.setAttribute(PATCHED, '1');
      });
    }
  }

  function schedulePatch() {
    if (typeof window.requestIdleCallback === 'function') {
      window.requestIdleCallback(patchSurfaces, { timeout: 2500 });
    } else {
      window.setTimeout(patchSurfaces, 1800);
    }
  }

  function boot() {
    patchSurfaces();
    schedulePatch();
    window.setTimeout(patchSurfaces, 3200);
    window.setTimeout(patchSurfaces, 5500);

    if (window.tinymce) {
      window.tinymce.on('AddEditor', function () {
        window.setTimeout(function () {
          patchTinyMceShell();
          fixEditorOverflow();
          patchSurfaces();
        }, 120);
      });
    }

    function watchRoot(root) {
      if (!root || typeof MutationObserver === 'undefined') {
        return;
      }
      var debounce = null;
      var obs = new MutationObserver(function () {
        if (debounce) {
          window.clearTimeout(debounce);
        }
        debounce = window.setTimeout(patchSurfaces, 350);
      });
      obs.observe(root, { childList: true, subtree: true });
    }

    watchRoot(document.getElementById('wpseo_meta'));
    watchRoot(document.getElementById('poststuff'));

    if (typeof MutationObserver !== 'undefined') {
      var bodyObs = new MutationObserver(function (muts) {
        var hit = false;
        muts.forEach(function (m) {
          if (m.addedNodes && m.addedNodes.length) {
            m.addedNodes.forEach(function (node) {
              if (node.nodeType === 1 && (node.matches && (node.matches('.so-panels-dialog') || node.querySelector && node.querySelector('.so-panels-dialog')))) {
                hit = true;
              }
            });
          }
        });
        if (hit) {
          window.setTimeout(patchSiteOriginPanels, 80);
          window.setTimeout(patchSiteOriginPanels, 400);
        }
      });
      bodyObs.observe(document.body, { childList: true, subtree: false });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  document.addEventListener('ysh-studio-color-mode-changed', patchSurfaces);

  document.addEventListener(
    'mouseover',
    function (e) {
      if (!isDark() || !(e.target instanceof Element)) {
        return;
      }

      var target = e.target;
      var widget = target.closest('.siteorigin-panels-builder .so-widget, .siteorigin-panels-builder .widget');
      if (widget) {
        forceSiteOriginBuilderWidget(widget);
        window.requestAnimationFrame(function () {
          forceSiteOriginBuilderWidget(widget);
        });
      }

      if (target.closest('.so-panels-dialog')) {
        var patchEl =
          target.closest(
            'li, a, div, span, label, .so-title-bar, .widget-type-wrapper, a.so-widget, .style-section-head, .style-section-fields, .so-visual-styles'
          ) || target;
        if (patchEl && !patchEl.matches('img, svg, iframe')) {
          forceDarkSurface(patchEl);
          applyReadableText(patchEl);
        }
        if (target.closest('.so-visual-styles')) {
          var visualRoot = target.closest('.so-visual-styles');
          if (visualRoot) {
            forceSiteOriginVisualStyles(visualRoot);
          }
        }
        window.requestAnimationFrame(function () {
          patchSiteOriginPanels();
        });
      }

      if (target.closest('#wpseo_meta')) {
        patchYoastGooglePreview();
      }
    },
    true
  );
})();
