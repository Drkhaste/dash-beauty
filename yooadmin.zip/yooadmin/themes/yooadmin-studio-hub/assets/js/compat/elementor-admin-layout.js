/**
 * Studio Hub — Elementor "Editor One" admin layout controller (Focus shell).
 *
 * Keeps Elementor's fixed chrome glued to the Focus shell by measuring the live
 * geometry and publishing it as CSS variables consumed by
 * css/compat/elementor-home.css:
 *   --yp-eone-top      : bottom edge of our fixed header + breadcrumbs bar
 *   --yp-eone-topbar-h : Editor One top bar height
 *   --yp-eone-bottom   : fixed shell footer height (0 when absent)
 *
 * This is what makes the layout immune to Editor One's own JS, which re-measures
 * vanilla wp-admin metrics after load. We never read those metrics; we pin our
 * own, so there is no post-load reflow ("jump").
 */
(function () {
  'use strict';

  var root = document.documentElement;
  var rafId = 0;

  function isEditorOne() {
    return !!document.body &&
      document.body.classList.contains('e-has-sidebar-navigation') &&
      document.body.classList.contains('yoo-focus');
  }

  /*
   * Server-rendered settings pages (Tools, Role Manager, …) are plain documents,
   * unlike the React Home app (#e-home-screen). On those, we want the NATIVE window
   * scroll (see css/compat/elementor-home.css). Editor One, however, locks the
   * document scroll via INLINE !important styles that CSS cannot override, so we
   * clear them here and keep them clear if Editor One re-applies them.
   */
  function isSettingsPage() {
    return isEditorOne() && !document.getElementById('e-home-screen');
  }

  var scrollMo = null;
  var enforcing = false;

  function enforceWindowScroll() {
    if (!isSettingsPage()) {
      return;
    }
    enforcing = true;
    var targets = [
      document.documentElement,
      document.body,
      document.getElementById('wpwrap'),
      document.getElementById('wpcontent')
    ];
    for (var i = 0; i < targets.length; i++) {
      var el = targets[i];
      if (!el) {
        continue;
      }
      el.style.setProperty('overflow', 'visible', 'important');
      el.style.setProperty('height', 'auto', 'important');
      el.style.setProperty('position', 'static', 'important');
    }
    document.documentElement.style.setProperty('overflow-y', 'auto', 'important');
    enforcing = false;
  }

  function watchScrollLock() {
    if (!isSettingsPage() || !window.MutationObserver) {
      return;
    }
    scrollMo = new MutationObserver(function () {
      if (enforcing) {
        return;
      }
      (window.requestAnimationFrame || window.setTimeout)(enforceWindowScroll);
    });
    scrollMo.observe(document.documentElement, { attributes: true, attributeFilter: ['style'] });
    scrollMo.observe(document.body, { attributes: true, attributeFilter: ['style'] });
  }

  /* Lowest bottom edge among the shell header chrome elements pinned to the top. */
  function measureHeaderBottom() {
    var selectors = [
      '#yoo-admin-header-wrapper',
      '.yp-subsite-chrome',
      '#yoo-admin-header',
      '.yp-breadcrumbs-bar'
    ];
    var bottom = 0;
    for (var i = 0; i < selectors.length; i++) {
      var el = document.querySelector(selectors[i]);
      if (!el) {
        continue;
      }
      var rect = el.getBoundingClientRect();
      // Only count chrome anchored to the top of the viewport.
      if (rect.height > 0 && rect.top <= 8 && rect.bottom > bottom) {
        bottom = rect.bottom;
      }
    }
    return bottom;
  }

  function measureHeight(selector) {
    var el = document.querySelector(selector);
    if (!el) {
      return 0;
    }
    var rect = el.getBoundingClientRect();
    return rect.height > 0 ? rect.height : 0;
  }

  function setVar(name, px) {
    if (px > 0) {
      root.style.setProperty(name, Math.round(px) + 'px');
    }
  }

  function apply() {
    rafId = 0;
    if (!isEditorOne()) {
      return;
    }
    enforceWindowScroll();
    setVar('--yp-eone-top', measureHeaderBottom());
    setVar('--yp-eone-topbar-h', measureHeight('#editor-one-top-bar > header') ||
      measureHeight('#editor-one-top-bar > *'));

    // Footer can legitimately be absent → publish 0 rather than skip.
    var footer = measureHeight('.yp-dashboard-footer');
    root.style.setProperty('--yp-eone-bottom', Math.round(footer) + 'px');
  }

  function schedule() {
    if (rafId) {
      return;
    }
    rafId = (window.requestAnimationFrame || window.setTimeout)(apply);
  }

  function init() {
    apply();
    enforceWindowScroll();
    watchScrollLock();
    // Catch late chrome/app mounts.
    window.setTimeout(apply, 120);
    window.setTimeout(apply, 400);
    window.setTimeout(apply, 1000);

    window.addEventListener('load', apply);
    window.addEventListener('resize', schedule);

    if (window.ResizeObserver) {
      var ro = new ResizeObserver(schedule);
      [
        '#yoo-admin-header-wrapper',
        '#yoo-admin-header',
        '.yp-breadcrumbs-bar',
        '#editor-one-top-bar',
        '.yp-dashboard-footer'
      ].forEach(function (sel) {
        var el = document.querySelector(sel);
        if (el) {
          ro.observe(el);
        }
      });
    }

    // Editor One mounts its chrome asynchronously; watch for it once.
    if (window.MutationObserver) {
      var mo = new MutationObserver(function () {
        if (document.getElementById('editor-one-top-bar')) {
          schedule();
        }
      });
      if (document.body) {
        mo.observe(document.body, { childList: true, subtree: true });
        window.setTimeout(function () { mo.disconnect(); }, 5000);
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
