/**
 * Studio Hub — reshape plugin-install.php (site + network) to match yooadmin-pages.
 */
(function () {
    'use strict';

    var cfg = window.yooadminPluginInstallLayout || {};
    var i18n = cfg.i18n || {};

    function buildFilterChips(filterLinks) {
        var filters = document.createElement('div');
        filters.className = 'yoo-pages-filters';

        if (!filterLinks) {
            return filters;
        }

        filterLinks.querySelectorAll('li a').forEach(function (link) {
            var chip = document.createElement('a');
            chip.className = 'yoo-filter-chip';
            if (link.classList.contains('current')) {
                chip.classList.add('is-active');
            }
            chip.href = link.getAttribute('href') || '#';
            chip.textContent = (link.textContent || '').replace(/\s+/g, ' ').trim();
            filters.appendChild(chip);
        });

        return filters;
    }

    function styleYooButton(el, variant) {
        if (!el) {
            return;
        }
        el.classList.remove('page-title-action');
        el.classList.add('yp-yoo-btn', 'yp-yoo-btn--' + variant);
    }

    function initUiSelects(scope) {
        if (window.yooadminUiSelect && typeof window.yooadminUiSelect.initIn === 'function') {
            window.yooadminUiSelect.initIn(scope);
        }
    }

    function enhancePluginInstallTypeSelect() {
        var sel =
            document.querySelector('.yoo-plugin-install-search #typeselector') ||
            document.querySelector('.yoo-plugin-install-search select[name="type"]') ||
            document.getElementById('typeselector');

        if (!sel) {
            return false;
        }

        var api = window.yooadminUiSelect;
        if (!api) {
            return false;
        }

        if (!sel.closest('.yp-ui-select')) {
            if (typeof api.wrap === 'function') {
                api.wrap(sel, { force: true });
            } else if (typeof api.initIn === 'function' && sel.parentNode) {
                api.initIn(sel.parentNode);
            }
        }

        var ui = sel.closest('.yp-ui-select');
        if (!ui) {
            return false;
        }

        ui.classList.add('yp-ui-select--plugin-install-type', 'yoo-plugin-install-type-select');
        sel.classList.remove('yoo-plugin-install-type-select');
        return true;
    }

    function dispatchEnhanceNativeSelects() {
        try {
            document.dispatchEvent(
                new CustomEvent('yooadmin:enhance-native-selects', {
                    detail: { root: document.querySelector('.yooadmin-plugin-install-page') || document },
                })
            );
        } catch (err) {
            /* CustomEvent optional */
        }
    }

    function schedulePluginInstallTypeSelectEnhance(onReady) {
        var attempts = 0;
        var maxAttempts = 40;
        var done = false;

        function finish() {
            if (done) {
                return;
            }
            done = true;
            if (typeof onReady === 'function') {
                onReady();
            }
        }

        function run() {
            attempts += 1;
            if (enhancePluginInstallTypeSelect()) {
                finish();
                return;
            }
            if (attempts === 1) {
                dispatchEnhanceNativeSelects();
            }
            if (attempts >= maxAttempts) {
                finish();
                return;
            }
            window.setTimeout(run, 16);
        }

        run();
        if (typeof window.requestAnimationFrame === 'function') {
            window.requestAnimationFrame(run);
        }
    }

    function releasePluginInstallPaint() {
        document.documentElement.classList.remove('yoo-plugin-install-layout-pending');
        document.documentElement.classList.add('yoo-plugin-install-ui-ready');
        if (window.yooadminYooPagesShellLoader && typeof window.yooadminYooPagesShellLoader.hide === 'function') {
            window.yooadminYooPagesShellLoader.hide();
        }
    }

    function stylePluginCardButtons(root) {
        if (!root) {
            return;
        }

        root.querySelectorAll('.plugin-card .install-now.button, .install-now.button').forEach(function (btn) {
            btn.classList.add('yp-yoo-btn', 'yp-yoo-btn--primary');
        });

        root.querySelectorAll('.plugin-action-buttons .button:not(.install-now):not(.button-primary)').forEach(function (btn) {
            btn.classList.add('yp-yoo-btn', 'yp-yoo-btn--ghost');
        });

        root.querySelectorAll(
            '.plugin-action-buttons a:not(.button):not(.install-now), .plugin-action-buttons a.open-plugin-details-modal, .plugin-action-buttons a.more-details-link'
        ).forEach(function (link) {
            link.classList.add('ysh-plugin-install-details-link');
        });

        root.querySelectorAll('.tablenav .button, .tablenav input[type="submit"].button').forEach(function (btn) {
            if (!btn.classList.contains('yp-yoo-btn')) {
                btn.classList.add('yp-yoo-btn', 'yp-yoo-btn--ghost');
            }
        });

        root.querySelectorAll('#install-plugin-submit, #upload-plugin-submit').forEach(function (btn) {
            btn.classList.add('yp-yoo-btn', 'yp-yoo-btn--primary');
        });
    }

    function buildHero(wrap, ctx) {
        var hero = document.createElement('section');
        hero.className = 'yoo-pages-hero';

        var body = document.createElement('div');
        body.className = 'yoo-pages-hero__body';

        var topRow = document.createElement('div');
        topRow.className = 'yoo-pages-hero__top-row';

        var eyebrow = document.createElement('span');
        eyebrow.className = 'yoo-pages-hero__eyebrow';
        eyebrow.textContent = i18n.eyebrow || 'Extensions · Add Plugin';

        var heroActions = document.createElement('div');
        heroActions.className = 'yoo-pages-hero__actions';

        if (ctx.searchInput) {
            var searchOuter = document.createElement('div');
            searchOuter.className = 'yoo-plugin-install-search';

            var searchWrap = document.createElement('div');
            searchWrap.className = 'yoo-pages-search-wrapper';

            var icon = document.createElement('span');
            icon.className = 'dashicons dashicons-search';

            ctx.searchInput.classList.add('yoo-pages-search-input');
            ctx.searchInput.placeholder =
                i18n.searchPlaceholder || ctx.searchInput.placeholder || 'Search plugins…';

            if (ctx.searchForm) {
                ctx.searchForm.querySelectorAll('label').forEach(function (lab) {
                    lab.classList.add('screen-reader-text');
                });
            }

            searchWrap.appendChild(icon);
            searchWrap.appendChild(ctx.searchInput);
            searchOuter.appendChild(searchWrap);

            if (ctx.searchType) {
                var typeMount = ctx.searchType.closest('.yp-ui-select') || ctx.searchType;
                typeMount.classList.add('yoo-plugin-install-type-select');
                searchOuter.appendChild(typeMount);
            }

            heroActions.appendChild(searchOuter);
        }

        if (ctx.uploadToggle) {
            styleYooButton(ctx.uploadToggle, ctx.isUploadTab ? 'ghost' : 'primary');
            if (!ctx.isUploadTab && !ctx.uploadToggle.querySelector('.dashicons')) {
                var upIcon = document.createElement('span');
                upIcon.className = 'dashicons dashicons-upload';
                ctx.uploadToggle.insertBefore(upIcon, ctx.uploadToggle.firstChild);
            }
            heroActions.appendChild(ctx.uploadToggle);
        }

        topRow.appendChild(eyebrow);
        topRow.appendChild(heroActions);

        var title = document.createElement('h1');
        if (ctx.h1) {
            title.innerHTML = ctx.h1.innerHTML;
            if (!title.querySelector('.dashicons')) {
                var d = document.createElement('span');
                d.className = 'dashicons dashicons-plus-alt';
                title.insertBefore(d, title.firstChild);
            }
        } else {
            title.innerHTML = '<span class="dashicons dashicons-plus-alt"></span> Add Plugins';
        }

        body.appendChild(topRow);
        body.appendChild(title);

        if (ctx.isUploadTab && ctx.uploadPlugin) {
            ctx.uploadPlugin.classList.add('yoo-plugin-install-hero-upload');
            body.appendChild(ctx.uploadPlugin);
        }

        hero.appendChild(body);

        return hero;
    }

    function initLayout() {
        var wrap = document.querySelector('body.plugin-install-php #wpbody-content > .wrap');
        if (!wrap || wrap.classList.contains('yoo-plugin-install-layout-ready')) {
            return;
        }

        var isUploadTab =
            cfg.isUploadTab || wrap.classList.contains('plugin-install-tab-upload');

        var h1 = wrap.querySelector('h1.wp-heading-inline');
        var uploadToggle = wrap.querySelector('.upload-view-toggle.page-title-action');
        var hr = wrap.querySelector('.wp-header-end');
        var wpFilter = wrap.querySelector('.wp-filter');
        var searchForm =
            wrap.querySelector('.search-form.search-plugins') ||
            (wpFilter ? wpFilter.querySelector('.search-form.search-plugins') : null);
        var searchInput = searchForm
            ? searchForm.querySelector('#search-plugins, input[type="search"]')
            : null;
        var searchType = searchForm ? searchForm.querySelector('#typeselector, select[name="type"]') : null;
        var uploadPlugin = wrap.querySelector(':scope > .upload-plugin');

        wrap.classList.add('yooadmin-plugin-install-page', 'yooadmin-pages-page');
        if (isUploadTab) {
            wrap.classList.add('yoo-plugin-install-page--upload-tab');
        }

        var hero = buildHero(wrap, {
            h1: h1,
            uploadToggle: uploadToggle,
            searchInput: searchInput,
            searchType: searchType,
            searchForm: searchForm,
            isUploadTab: isUploadTab,
            uploadPlugin: uploadPlugin,
        });

        var section = document.createElement('section');
        section.className = 'yoo-pages-content-section yoo-plugin-install-content';
        if (isUploadTab) {
            section.classList.add('yoo-plugin-install-content--upload');
        }

        var introP = null;
        if (wpFilter && wpFilter.previousElementSibling && wpFilter.previousElementSibling.tagName === 'P') {
            introP = wpFilter.previousElementSibling;
            introP.classList.add('yoo-plugin-install-intro');
            section.appendChild(introP);
        }

        if (wpFilter) {
            var filterLinks = wpFilter.querySelector('.filter-links');
            var filters = buildFilterChips(filterLinks);

            var toolbar = document.createElement('div');
            toolbar.className = 'yoo-pages-toolbar yoo-plugin-install-toolbar';
            toolbar.appendChild(filters);
            section.appendChild(toolbar);

            wpFilter.style.display = 'none';
            wpFilter.setAttribute('aria-hidden', 'true');
        }

        var skip = new Set([h1, hr, uploadToggle, uploadPlugin]);
        Array.from(wrap.children).forEach(function (child) {
            if (!child || skip.has(child)) {
                return;
            }
            if (child.classList.contains('upload-plugin-wrap') || child.classList.contains('upload-plugin')) {
                return;
            }
            if (child.tagName === 'SPAN' && child.classList.contains('spinner')) {
                return;
            }
            if (introP && child === introP) {
                return;
            }
            section.appendChild(child);
        });

        var listTable = section.querySelector('.wp-list-table');
        if (listTable) {
            var cardsWrap = document.createElement('div');
            cardsWrap.className = 'yoo-plugin-install-cards';
            listTable.parentNode.insertBefore(cardsWrap, listTable);
            cardsWrap.appendChild(listTable);
        }

        var popularTags = section.querySelector('.plugins-popular-tags-wrapper');
        if (popularTags) {
            popularTags.classList.add('yoo-plugin-install-tags');
        }

        wrap.insertBefore(hero, wrap.firstChild);
        wrap.appendChild(section);

        if (isUploadTab) {
            section.classList.add('yoo-plugin-install-content--upload-only');
            var hasBrowseContent = section.querySelector(
                '.yoo-plugin-install-intro, .yoo-plugin-install-toolbar, .wp-list-table, .plugins-popular-tags-wrapper, .tablenav'
            );
            if (!hasBrowseContent) {
                section.setAttribute('aria-hidden', 'true');
                section.hidden = true;
            }
        }

        if (h1) {
            h1.remove();
        }
        if (hr) {
            hr.remove();
        }

        if (searchForm && searchInput && hero.contains(searchInput)) {
            searchForm.style.display = 'none';
            searchForm.setAttribute('aria-hidden', 'true');
            if (!searchForm.parentNode) {
                wrap.appendChild(searchForm);
            }
        }

        stylePluginCardButtons(section);
        stylePluginCardButtons(hero);
        initUiSelects(wrap);
        wrap.classList.add('yoo-plugin-install-layout-ready');

        if (enhancePluginInstallTypeSelect()) {
            releasePluginInstallPaint();
        } else {
            schedulePluginInstallTypeSelectEnhance(releasePluginInstallPaint);
        }

        syncPluginInstallSearchChrome();
    }

    function syncPluginInstallSearchChrome() {
        var isLight =
            document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') === 'light';
        if (!isLight) {
            return;
        }

        document
            .querySelectorAll(
                '.yoo-plugin-install-search :is(.yoo-pages-search-input, #search-plugins, input[type="search"])'
            )
            .forEach(function (input) {
                input.style.removeProperty('background');
                input.style.removeProperty('background-color');
                input.style.removeProperty('border-color');
                input.style.removeProperty('color');
                input.style.removeProperty('color-scheme');
            });
    }

    function bootLayout() {
        window.setTimeout(function () {
            if (!document.documentElement.classList.contains('yoo-plugin-install-ui-ready')) {
                releasePluginInstallPaint();
            }
        }, 4000);

        document.addEventListener('ysh-studio-color-mode-changed', syncPluginInstallSearchChrome);

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initLayout, { once: true });
            return;
        }
        initLayout();
    }

    bootLayout();
})();
