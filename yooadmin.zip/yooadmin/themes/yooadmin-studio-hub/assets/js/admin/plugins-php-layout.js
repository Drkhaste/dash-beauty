/**
 * Studio Hub — reshape native plugins.php to match yooadmin-pages list view.
 */
(function () {
    'use strict';

    var cfg = window.yooadminPluginsLayout || {};
    var i18n = cfg.i18n || {};

    function parseCount(text) {
        var m = String(text || '').match(/\(([\d,]+)\)/);
        if (!m) {
            return '';
        }
        return m[1].replace(/,/g, '');
    }

    function chipLabelFromLink(link) {
        var clone = link.cloneNode(true);
        var count = clone.querySelector('.count');
        if (count) {
            count.remove();
        }
        return (clone.textContent || '').replace(/\s+/g, ' ').trim();
    }

    function buildFilterChips(subsubsub) {
        var filters = document.createElement('div');
        filters.className = 'yoo-pages-filters';

        if (!subsubsub) {
            return filters;
        }

        var links = subsubsub.querySelectorAll('li a');
        if (!links.length) {
            links = subsubsub.querySelectorAll('a');
        }

        links.forEach(function (link) {
            var chip = document.createElement('a');
            chip.className = 'yoo-filter-chip';
            if (link.classList.contains('current')) {
                chip.classList.add('is-active');
            }
            chip.href = link.getAttribute('href') || '#';

            var label = chipLabelFromLink(link);
            var count = parseCount(link.textContent);
            chip.appendChild(document.createTextNode(label + ' '));
            if (count !== '') {
                var span = document.createElement('span');
                span.className = 'yoo-filter-count';
                span.textContent = count;
                chip.appendChild(span);
            }

            filters.appendChild(chip);
        });

        return filters;
    }

    function buildMetricsFromChips(filtersEl) {
        var metrics = {
            total: '0',
            active: '0',
            inactive: '0',
        };

        if (!filtersEl) {
            return metrics;
        }

        filtersEl.querySelectorAll('.yoo-filter-chip').forEach(function (chip) {
            var label = (chip.textContent || '').toLowerCase();
            var countEl = chip.querySelector('.yoo-filter-count');
            var val = countEl ? countEl.textContent : '0';
            if (label.indexOf('all') === 0) {
                metrics.total = val;
            } else if (label.indexOf('active') === 0 && label.indexOf('inactive') === -1) {
                metrics.active = val;
            } else if (label.indexOf('inactive') === 0) {
                metrics.inactive = val;
            }
        });

        return metrics;
    }

    function getPluginsForm(wrap) {
        var tableInForm = wrap.querySelector('form .wp-list-table.plugins');
        return (
            wrap.querySelector('#bulk-action-form') ||
            wrap.querySelector('#plugin-filter') ||
            (tableInForm ? tableInForm.closest('form') : null)
        );
    }

    function getSearchContext(wrap) {
        var searchForm =
            wrap.querySelector('.search-form.search-plugins') ||
            wrap.querySelector('#plugin-filter') ||
            null;
        var searchBox = searchForm
            ? searchForm.querySelector('.search-box') || searchForm
            : wrap.querySelector('.search-box');
        var searchInput = searchBox ? searchBox.querySelector('input[type="search"]') : null;
        return { searchForm: searchForm, searchBox: searchBox, searchInput: searchInput };
    }

    function buildSearchForm(searchContext) {
        var sourceInput = searchContext.searchInput;
        if (!sourceInput) {
            return null;
        }

        var form = document.createElement('form');
        form.className = 'yoo-pages-search-form';
        form.method = 'get';
        form.action = 'plugins.php';

        var sourceForm = searchContext.searchForm;
        if (sourceForm && sourceForm.getAttribute('action')) {
            form.action = sourceForm.getAttribute('action');
        }

        var sourceParams = new URLSearchParams(window.location.search || '');
        ['plugin_status', 'paged', 's'].forEach(function (key) {
            sourceParams.delete(key);
        });
        sourceParams.forEach(function (value, key) {
            var hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = key;
            hidden.value = value;
            form.appendChild(hidden);
        });

        var searchWrap = document.createElement('div');
        searchWrap.className = 'yoo-pages-search-wrapper';

        var icon = document.createElement('span');
        icon.className = 'dashicons dashicons-search';
        searchWrap.appendChild(icon);

        var input = sourceInput.cloneNode(false);
        input.classList.add('yoo-pages-search-input');
        input.placeholder = i18n.searchPlaceholder || input.placeholder || 'Search plugins…';
        input.value = sourceInput.value || '';
        searchWrap.appendChild(input);

        var submit = document.createElement('button');
        submit.type = 'submit';
        submit.className = 'button yoo-plugins-search-submit screen-reader-text';
        submit.textContent = 'Search';
        searchWrap.appendChild(submit);

        form.appendChild(searchWrap);
        return form;
    }

    function buildHero(wrap, searchContext) {
        var h1 = wrap.querySelector('h1.wp-heading-inline');
        var actions = wrap.querySelectorAll('.page-title-action');

        var hero = document.createElement('section');
        hero.className = 'yoo-pages-hero';

        var body = document.createElement('div');
        body.className = 'yoo-pages-hero__body';

        var topRow = document.createElement('div');
        topRow.className = 'yoo-pages-hero__top-row';

        var eyebrow = document.createElement('span');
        eyebrow.className = 'yoo-pages-hero__eyebrow';
        eyebrow.textContent = i18n.eyebrow || 'Extensions · Plugins';

        var heroActions = document.createElement('div');
        heroActions.className = 'yoo-pages-hero__actions';

        var searchForm = buildSearchForm(searchContext);
        if (searchForm) {
            heroActions.appendChild(searchForm);
        }

        var screenOptsBtn = document.createElement('button');
        screenOptsBtn.type = 'button';
        screenOptsBtn.id = 'yoo-plugins-screen-options-btn';
        screenOptsBtn.className = 'button yp-yoo-btn yp-yoo-btn--soft';
        screenOptsBtn.setAttribute('aria-haspopup', 'dialog');
        screenOptsBtn.innerHTML =
            '<span class="dashicons dashicons-screenoptions" aria-hidden="true"></span>' +
            '<span>' +
            (i18n.screenOptions || 'Screen Options') +
            '</span>';
        heroActions.appendChild(screenOptsBtn);

        actions.forEach(function (btn, index) {
            btn.classList.remove('page-title-action');
            btn.classList.add('yp-yoo-btn');
            btn.classList.add(index === 0 ? 'yp-yoo-btn--primary' : 'yp-yoo-btn--ghost');
            if (index === 0 && !btn.querySelector('.dashicons')) {
                var plus = document.createElement('span');
                plus.className = 'dashicons dashicons-plus-alt';
                btn.insertBefore(plus, btn.firstChild);
            }
            heroActions.appendChild(btn);
        });

        if (!actions.length && cfg.canInstallPlugins && cfg.addPluginUrl) {
            var addBtn = document.createElement('a');
            addBtn.href = cfg.addPluginUrl;
            addBtn.className = 'yp-yoo-btn yp-yoo-btn--primary';
            var addIcon = document.createElement('span');
            addIcon.className = 'dashicons dashicons-plus-alt';
            addBtn.appendChild(addIcon);
            addBtn.appendChild(document.createTextNode(' ' + (i18n.addPlugin || 'Add Plugin')));
            heroActions.appendChild(addBtn);
        }

        topRow.appendChild(eyebrow);
        topRow.appendChild(heroActions);

        var title = document.createElement('h1');
        if (h1) {
            title.innerHTML = h1.innerHTML;
            if (!title.querySelector('.dashicons')) {
                var d = document.createElement('span');
                d.className = 'dashicons dashicons-admin-plugins';
                title.insertBefore(d, title.firstChild);
            }
        } else {
            title.innerHTML = '<span class="dashicons dashicons-admin-plugins"></span> Plugins';
        }

        var metricsToggle = document.createElement('button');
        metricsToggle.type = 'button';
        metricsToggle.className = 'yoo-pages-metrics-toggle';
        metricsToggle.setAttribute('aria-expanded', 'false');
        metricsToggle.innerHTML =
            '<span class="dashicons dashicons-arrow-down-alt"></span><span>' +
            (i18n.showStats || 'Show Statistics') +
            '</span>';

        body.appendChild(topRow);
        body.appendChild(title);
        body.appendChild(metricsToggle);
        hero.appendChild(body);

        return hero;
    }

    function enhanceBulkSelects(scope) {
        if (!scope || !scope.querySelectorAll) {
            return;
        }
        scope.querySelectorAll('select[name="action"], select[name="action2"]').forEach(function (sel) {
            sel.classList.add('yoo-bulk-select');
        });
    }

    function initUiSelects(scope) {
        if (window.yooadminUiSelect && typeof window.yooadminUiSelect.initIn === 'function') {
            window.yooadminUiSelect.initIn(scope);
        }
    }

    function syncHeroMetricsFromFilters() {
        var filters = document.querySelector('.yooadmin-plugins-page .yoo-pages-filters');
        var panel = document.querySelector('.yooadmin-plugins-page .yoo-pages-hero__metrics');
        if (!filters || !panel) {
            return;
        }
        var metrics = buildMetricsFromChips(filters);
        var cards = panel.querySelectorAll('.yoo-pages-metric__value');
        var values = [metrics.total, metrics.active, metrics.inactive];
        cards.forEach(function (el, index) {
            if (values[index] !== undefined) {
                el.textContent = values[index];
            }
        });
    }

    function hideShellLoader() {
        if (window.yooadminYooPagesShellLoader && typeof window.yooadminYooPagesShellLoader.hide === 'function') {
            window.yooadminYooPagesShellLoader.hide();
        }
    }

    function addActivePluginBadges(table) {
        if (!table) {
            return;
        }
        table.querySelectorAll('.yoo-plugin-active-badge').forEach(function (badge) {
            badge.remove();
        });
        var label = i18n.activeBadge || 'Active';
        table.querySelectorAll('tbody tr.active:not(.plugin-update-tr)').forEach(function (row) {
            var titleCell = row.querySelector('.plugin-title');
            if (!titleCell || titleCell.querySelector('.yoo-plugin-active-badge')) {
                return;
            }
            var strong = titleCell.querySelector('strong');
            var badge = document.createElement('span');
            badge.className = 'yoo-plugin-active-badge';
            badge.textContent = label;
            if (strong) {
                strong.insertAdjacentElement('afterend', badge);
            } else {
                titleCell.insertBefore(badge, titleCell.firstChild);
            }
        });
    }

    function buildMetricsPanel(metrics) {
        var panel = document.createElement('div');
        panel.className = 'yoo-pages-hero__metrics';

        [
            { icon: 'admin-plugins', label: i18n.totalPlugins || 'Total Plugins', value: metrics.total },
            { icon: 'yes', label: i18n.activePlugins || 'Active', value: metrics.active },
            { icon: 'marker', label: i18n.inactivePlugins || 'Inactive', value: metrics.inactive },
        ].forEach(function (item) {
            var card = document.createElement('article');
            card.className = 'yoo-pages-metric';
            card.innerHTML =
                '<div class="yoo-pages-metric__icon"><span class="dashicons dashicons-' +
                item.icon +
                '"></span></div>' +
                '<div class="yoo-pages-metric__content">' +
                '<strong class="yoo-pages-metric__value">' +
                item.value +
                '</strong>' +
                '<span class="yoo-pages-metric__label">' +
                item.label +
                '</span></div>';
            panel.appendChild(card);
        });

        return panel;
    }

    function initLayout() {
        var wrap = document.querySelector('body.plugins-php #wpbody-content > .wrap');
        if (!wrap || wrap.classList.contains('yoo-plugins-layout-ready')) {
            return;
        }

        var subsubsub = wrap.querySelector('.subsubsub');
        var hr = wrap.querySelector('.wp-header-end');
        var h1 = wrap.querySelector('h1.wp-heading-inline');
        var form = getPluginsForm(wrap);
        var table = wrap.querySelector('.wp-list-table.plugins');
        var searchContext = getSearchContext(wrap);

        if (!form || !table) {
            document.documentElement.classList.remove('yoo-plugins-layout-pending');
            hideShellLoader();
            return;
        }

        wrap.classList.add('yooadmin-plugins-page', 'yooadmin-pages-page');

        var hero = buildHero(wrap, searchContext);
        var filters = buildFilterChips(subsubsub);
        var metrics = buildMetricsFromChips(filters);
        hero.appendChild(buildMetricsPanel(metrics));

        var section = document.createElement('section');
        section.className = 'yoo-pages-content-section';

        var toolbar = document.createElement('div');
        toolbar.className = 'yoo-pages-toolbar';
        toolbar.appendChild(filters);

        var tablenavTop = form.querySelector('.tablenav.top');
        if (tablenavTop) {
            var toolbarExtras = document.createElement('div');
            toolbarExtras.className = 'yoo-plugins-toolbar-extras';
            var alignRight = tablenavTop.querySelector('.tablenav-pages');
            if (alignRight) {
                toolbarExtras.appendChild(alignRight);
            }
            toolbar.appendChild(toolbarExtras);
        }

        var bulkBar = document.createElement('div');
        bulkBar.className = 'yoo-plugins-bulk-bar';
        if (tablenavTop) {
            var bulkLeft = tablenavTop.querySelector('.alignleft.actions');
            if (bulkLeft) {
                bulkBar.appendChild(bulkLeft);
            }
            tablenavTop.classList.add('yoo-plugins-tablenav-top');
        }

        var tableWrap = document.createElement('div');
        tableWrap.className = 'yoo-pages-table yoo-plugins-table';

        var tableParent = table.parentNode;
        if (tableParent && tableParent !== form) {
            tableParent.insertBefore(tableWrap, table);
            tableWrap.appendChild(table);
        } else {
            form.insertBefore(tableWrap, table);
            tableWrap.appendChild(table);
        }

        if (bulkBar.childNodes.length) {
            form.insertBefore(bulkBar, tablenavTop || tableWrap || table);
        }

        section.appendChild(toolbar);
        section.appendChild(form);
        form.querySelectorAll('.tablenav.top').forEach(function (nav) {
            if (!nav.querySelector('.alignleft.actions')) {
                nav.classList.add('yoo-plugins-tablenav-top--compact');
            }
        });

        wrap.insertBefore(hero, wrap.firstChild);
        if (hr) {
            hr.remove();
        }
        if (h1) {
            h1.remove();
        }
        wrap.querySelectorAll('.page-title-action').forEach(function (el) {
            if (!hero.contains(el)) {
                el.remove();
            }
        });
        if (subsubsub && filters.childNodes.length) {
            subsubsub.style.display = 'none';
            subsubsub.setAttribute('aria-hidden', 'true');
        }

        var notices = wrap.querySelectorAll(':scope > .notice, :scope > .updated, :scope > .error');
        notices.forEach(function (n) {
            section.insertBefore(n, section.firstChild);
        });

        wrap.appendChild(section);
        wrap.classList.add('yoo-plugins-layout-ready');
        document.documentElement.classList.remove('yoo-plugins-layout-pending');
        hideShellLoader();
        document.dispatchEvent(
            new CustomEvent('yooadmin-plugins-layout-ready', { detail: { wrap: wrap } })
        );

        enhanceBulkSelects(wrap);
        addActivePluginBadges(table);
        initUiSelects(wrap);

        /* Only bulk/form buttons — not hero, filter chips, or pagination (avoid color/class churn). */
        if (typeof window.yooadminEnhanceGlobalButtons === 'function') {
            wrap.querySelectorAll('.yoo-plugins-bulk-bar, .yoo-pages-content-section form').forEach(function (root) {
                window.yooadminEnhanceGlobalButtons(root);
            });
        }

        if (searchContext.searchBox && searchContext.searchInput) {
            searchContext.searchBox.style.display = 'none';
            searchContext.searchBox.setAttribute('aria-hidden', 'true');
        }

        var toggle = hero.querySelector('.yoo-pages-metrics-toggle');
        var metricsPanel = hero.querySelector('.yoo-pages-hero__metrics');
        if (toggle && metricsPanel) {
            toggle.addEventListener('click', function () {
                var open = metricsPanel.classList.toggle('is-visible');
                toggle.classList.toggle('is-expanded', open);
                toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
                var label = toggle.querySelector('span:last-child');
                if (label) {
                    label.textContent = open
                        ? i18n.hideStats || 'Hide Statistics'
                        : i18n.showStats || 'Show Statistics';
                }
            });
        }
    }

    window.yooadminPluginsLayoutRefresh = function (scope) {
        var root =
            scope ||
            document.querySelector('.yoo-plugins-layout-ready') ||
            document.querySelector('.yooadmin-plugins-page');
        if (!root) {
            return;
        }
        var table = root.querySelector('.wp-list-table.plugins');
        enhanceBulkSelects(root);
        if (table) {
            addActivePluginBadges(table);
        }
        syncHeroMetricsFromFilters();
        initUiSelects(root);
        if (typeof window.yooadminEnhanceGlobalButtons === 'function') {
            root.querySelectorAll('.yoo-plugins-bulk-bar, .yoo-pages-content-section form').forEach(function (formRoot) {
                window.yooadminEnhanceGlobalButtons(formRoot);
            });
        }
    };

    function bootLayout() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initLayout, { once: true });
            return;
        }
        initLayout();
    }

    bootLayout();
})();
