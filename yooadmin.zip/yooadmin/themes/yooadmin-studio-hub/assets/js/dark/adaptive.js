/**
 * YOOAdmin Dark Engine v2 — narrow adaptive fallback.
 *
 * The CSS layers (tokens, wp-core, compat, vendor) handle the vast majority of
 * admin UI. This script is a deliberately *small* runtime safety net for the
 * leftovers CSS cannot reach: self-contained React/MUI/emotion apps (e.g. the
 * Elementor Home "website builder") whose hashed class names and runtime styles
 * dodge selector targeting, leaving light stragglers (banners, inactive tabs,
 * chips) on an otherwise dark page.
 *
 * Design constraints (why this is "narrow", unlike the legacy engine):
 *  - Runs ONLY on v2 plugin screens, in dark mode.
 *  - Darkens ONLY neutral (low-saturation) light surfaces — never saturated
 *    brand colors (pink CTAs, blue banners stay), never images/media.
 *  - Hard node budget + debounced, self-disconnecting observer for React
 *    re-renders. No token discovery, no per-plugin heuristics.
 *  - @wordpress/components subtrees are skipped per-element (WP_REACT_SKIP),
 *    not by shutting down the whole page when components-* is present.
 */
(function () {
  'use strict';

  var DARK_ATTR = 'data-yooadmin-studio-color-mode-effective';
  var SCAN_ROOT_ID = 'wpbody-content';
  var NODE_BUDGET = 1600;
  var DEBOUNCE_MS = 250;
  var SETTLE_DELAYS = [120, 600, 1500];
  var LIGHT_LUM = 0.62; // background lighter than this is a candidate
  var DARK_TEXT_LUM = 0.45; // text darker than this needs lightening
  var NEUTRAL_MAX_CHROMA = 42; // max(rgb)-min(rgb) above this = saturated, skip
  var MIN_W = 24;
  var MIN_H = 14;

  var SURFACE_BG = 'var(--yp-dark-surface, #1a1d23)';
  var FIELD_BG = 'var(--yp-dark-field, #22262e)';
  var FIELD_BORDER = 'var(--yp-dark-field-border, rgba(255,255,255,.18))';
  var TEXT_COLOR = 'var(--yp-dark-text, #cfd6e0)';

  /** react-select v5 / emotion — hashed *-control nodes inside *-select wrappers. */
  var CUSTOM_SELECT_QUERY =
    '[class*="-select"] [class*="-control"],' +
    '[class*="type-container"] [class*="-control"],' +
    '[class*="-select"] [class*="-menu"]';

  var SKIP_TAGS = {
    IMG: 1, SVG: 1, PATH: 1, VIDEO: 1, CANVAS: 1, IFRAME: 1, PICTURE: 1,
    INPUT: 1, TEXTAREA: 1, SELECT: 1, STYLE: 1, SCRIPT: 1, NOSCRIPT: 1,
    BR: 1, HR: 1, OPTION: 1,
  };
  var TEXT_QUERY =
    'h1,h2,h3,h4,h5,h6,p,span,a,li,td,th,dt,dd,label,legend,strong,em,b,small,figcaption,' +
    '[class*="MuiTypography"],[class*="MuiChip"],[class*="MuiTab"],[class*="MuiAlert"],[class*="MuiListItemText"]';
  var YOOADMIN_SKIP =
    '[id^="yp-"],[id^="yoo"],[class^="yp-"],[class*=" yp-"],[class^="yoo"],[class*=" yoo"],' +
    '[class*="yooadmin"],[class*="YOOAdmin"],.yp-studio-hub,.yp-inbox-wrap';
  /**
   * Live code/text editors mutate the DOM on every keystroke and scroll. Scanning
   * (or re-scanning) inside them is both pointless (CSS layers theme them) and the
   * single biggest perf hazard — getComputedStyle/getBoundingClientRect on a
   * CodeMirror viewport forces synchronous reflow per keystroke. Skip entirely.
   */
  var EDITOR_SKIP =
    '.CodeMirror,.CodeMirror-code,.cm-editor,.wp-editor-area,.wp-editor-wrap,' +
    '.ace_editor,.monaco-editor,.mce-content-body,[contenteditable="true"]';

  /**
   * @wordpress/components React subtrees. External DOM modification (adding
   * attributes / inline styles) desynchronises React's virtual DOM from the real
   * DOM; on a subsequent reconciliation React calls removeChild on a node that
   * has already moved → NotFoundError. CSS layers handle their dark mode;
   * the adaptive scan must never touch them.
   */
  var WP_REACT_SKIP =
    '.components-form-token-field,.components-popover__content,' +
    '.components-panel,.components-panel__body,.components-base-control,' +
    '.components-select-control,.components-toggle-control,' +
    '.components-card,.components-modal__content,' +
    '[class^="components-"],[data-wp-component]';

  var scanTimer = null;
  var observer = null;
  var bodyObserver = null;
  var settleTimers = [];
  var booted = false;

  function isDark() {
    return document.documentElement.getAttribute(DARK_ATTR) === 'dark';
  }

  function isPluginScreen() {
    return !!(document.body && document.body.classList.contains('yp-dark-v2-plugin'));
  }

  function active() {
    return isDark() && isPluginScreen();
  }

  function classText(node) {
    var cn = node && node.className;
    if (!cn) return '';
    if (typeof cn === 'string') return cn;
    if (typeof cn.baseVal === 'string') return cn.baseVal;
    return '';
  }

  function parseRgb(str) {
    if (!str) return null;
    var m = str.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,/\s]+([\d.]+))?/i);
    if (!m) return null;
    return {
      r: parseFloat(m[1]),
      g: parseFloat(m[2]),
      b: parseFloat(m[3]),
      a: m[4] !== undefined ? parseFloat(m[4]) : 1,
    };
  }

  function lin(c) {
    c /= 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  }

  function luminance(rgb) {
    return 0.2126 * lin(rgb.r) + 0.7152 * lin(rgb.g) + 0.0722 * lin(rgb.b);
  }

  function chroma(rgb) {
    return Math.max(rgb.r, rgb.g, rgb.b) - Math.min(rgb.r, rgb.g, rgb.b);
  }

  function hasImageOrGradient(cs) {
    var bg = cs.backgroundImage;
    return !!bg && bg !== 'none';
  }

  function isSkippable(el) {
    if (!el || el.nodeType !== 1) return true;
    if (SKIP_TAGS[el.tagName]) return true;
    if (el.closest && el.closest(YOOADMIN_SKIP)) return true;
    if (el.closest && el.closest(EDITOR_SKIP)) return true;
    if (el.closest && el.closest(WP_REACT_SKIP)) return true;
    if (el.closest && el.closest('.yp-dark-invert-island')) return true;
    if (el.closest && el.closest('.MuiButton-containedPrimary, .MuiButton-contained, [class*="primary"]')) {
      return true;
    }
    return false;
  }

  /** Force dark field surfaces on emotion/react-select controls CSS cannot reach. */
  function fixCustomSelectSurface(el) {
    if (isSkippable(el)) return false;
    var cs = window.getComputedStyle(el);
    var rgb = parseRgb(cs.backgroundColor);
    if (rgb && rgb.a >= 0.35 && luminance(rgb) < LIGHT_LUM) return false;
    el.style.setProperty('background-color', FIELD_BG, 'important');
    el.style.setProperty('border-color', FIELD_BORDER, 'important');
    el.style.setProperty('color', TEXT_COLOR, 'important');
    el.setAttribute('data-yp-v2-adapt', 'select');
    return true;
  }

  function fixCustomSelects(root, budget) {
    if (!root || !root.querySelectorAll) return;
    var nodes = root.querySelectorAll(CUSTOM_SELECT_QUERY);
    var len = Math.min(nodes.length, budget);
    for (var i = 0; i < len; i++) {
      fixCustomSelectSurface(nodes[i]);
    }
  }

  /** Darken a neutral light background; returns true if it acted. */
  function darkenSurface(el) {
    if (isSkippable(el)) return false;
    var cs = window.getComputedStyle(el);
    if (hasImageOrGradient(cs)) return false; // keep thumbnails/gradients
    var rgb = parseRgb(cs.backgroundColor);
    if (!rgb || rgb.a < 0.35) return false;
    if (luminance(rgb) < LIGHT_LUM) return false; // already dark enough
    if (chroma(rgb) > NEUTRAL_MAX_CHROMA) return false; // saturated brand color
    var rect = el.getBoundingClientRect();
    if (rect.width < MIN_W || rect.height < MIN_H) return false;
    el.style.setProperty('background-color', SURFACE_BG, 'important');
    el.style.setProperty('border-color', 'var(--yp-dark-border, rgba(255,255,255,.1))', 'important');
    el.setAttribute('data-yp-v2-adapt', 'surface');
    return true;
  }

  /** Lighten dark text that would otherwise vanish on a dark surface. */
  function lightenText(el) {
    if (isSkippable(el)) return;
    var cs = window.getComputedStyle(el);
    var rgb = parseRgb(cs.color);
    if (!rgb) return;
    if (luminance(rgb) > DARK_TEXT_LUM) return; // already light enough
    if (chroma(rgb) > NEUTRAL_MAX_CHROMA) return; // colored link/accent text
    el.style.setProperty('color', TEXT_COLOR, 'important');
    el.setAttribute('data-yp-v2-adapt', 'text');
  }

  var PORTAL_QUERY =
    'body > .MuiModal-root, body > .MuiPopover-root, body > .MuiMenu-root, ' +
    'body > .MuiDialog-root, body > [role="presentation"]';

  function scanScope(root, budget) {
    if (!root || !root.getElementsByTagName) return;
    var i;
    // Pass 1: surfaces (broad element walk, budgeted).
    var all = root.getElementsByTagName('*');
    var len = Math.min(all.length, budget);
    for (i = 0; i < len; i++) {
      darkenSurface(all[i]);
    }
    // Pass 2: text contrast (targeted query, budgeted).
    var texts = root.querySelectorAll(TEXT_QUERY);
    var tlen = Math.min(texts.length, budget);
    for (i = 0; i < tlen; i++) {
      lightenText(texts[i]);
    }
  }

  function scan() {
    scanTimer = null;
    if (!active()) return;

    var main = document.getElementById(SCAN_ROOT_ID);
    if (main) {
      fixCustomSelects(main, NODE_BUDGET);
      scanScope(main, NODE_BUDGET);
    }

    var portals = document.querySelectorAll(PORTAL_QUERY);
    for (var p = 0; p < portals.length; p++) {
      scanScope(portals[p], NODE_BUDGET);
    }
  }

  function scheduleScan() {
    if (scanTimer) window.clearTimeout(scanTimer);
    scanTimer = window.setTimeout(scan, DEBOUNCE_MS);
  }

  function clearObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (bodyObserver) {
      bodyObserver.disconnect();
      bodyObserver = null;
    }
  }

  /** True only for a real structural change OUTSIDE any live editor subtree. */
  function hasChildListChange(mutations) {
    for (var i = 0; i < mutations.length; i++) {
      var m = mutations[i];
      if (m.type !== 'childList' || (!m.addedNodes.length && !m.removedNodes.length)) {
        continue;
      }
      // Ignore mutations whose target sits inside a code/text editor: those fire
      // on every keystroke/scroll and would thrash the scanner (the main cause of
      // typing lag on editor-heavy plugin screens like Code Snippets).
      var t = m.target;
      if (t && t.nodeType === 1 && t.closest &&
          (t.closest(EDITOR_SKIP) || t.closest(WP_REACT_SKIP))) {
        continue;
      }
      return true;
    }
    return false;
  }

  function startObserver() {
    var root = document.getElementById(SCAN_ROOT_ID);
    if (root && !observer) {
      observer = new MutationObserver(function (mutations) {
        if (!active()) return;
        if (hasChildListChange(mutations)) scheduleScan();
      });
      observer.observe(root, { childList: true, subtree: true });
    }
    if (document.body && !bodyObserver) {
      bodyObserver = new MutationObserver(function (mutations) {
        if (!active()) return;
        if (hasChildListChange(mutations)) scheduleScan();
      });
      bodyObserver.observe(document.body, { childList: true, subtree: false });
    }
  }

  function clearSettleTimers() {
    settleTimers.forEach(function (t) {
      window.clearTimeout(t);
    });
    settleTimers = [];
  }

  function run() {
    if (!active()) {
      clearObserver();
      clearSettleTimers();
      return;
    }
    scan();
    // Catch late React paints without a permanent heavy observer.
    clearSettleTimers();
    SETTLE_DELAYS.forEach(function (d) {
      settleTimers.push(
        window.setTimeout(function () {
          if (active()) scan();
        }, d)
      );
    });
    startObserver();
  }

  function onColorModeChange() {
    if (active()) {
      run();
    } else {
      clearObserver();
      clearSettleTimers();
    }
  }

  function watchColorMode() {
    var mo = new MutationObserver(onColorModeChange);
    mo.observe(document.documentElement, {
      attributes: true,
      attributeFilter: [DARK_ATTR],
    });
  }

  function boot() {
    if (booted) return;
    booted = true;
    watchColorMode();
    document.addEventListener('ysh-studio-color-mode-changed', onColorModeChange);
    if (active()) run();
    window.addEventListener('load', function () {
      if (active()) run();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
