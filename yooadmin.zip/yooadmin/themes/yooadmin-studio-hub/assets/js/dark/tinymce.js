/**
 * YOOAdmin Dark Engine v2 — TinyMCE iframe bridge.
 *
 * A TinyMCE editor's writing surface lives in a separate same-origin <iframe>
 * document that page CSS cannot reach. The usual route is to inject a dark
 * stylesheet via the tiny_mce_before_init / teeny_mce_before_init PHP filters —
 * but some plugins (e.g. Code Snippets) build the editor entirely in JavaScript
 * with wp.editor.initialize() and the hardcoded default settings, so those
 * filters never run for them.
 *
 * To cover every case, this bridge injects the dark CSS *directly* into each
 * TinyMCE iframe document (the same technique the block editor canvas uses) and
 * keeps it in sync with the effective color mode. It also darkens the plain
 * "Text/Code" mode textarea. Self-gating and a no-op when no editor is present.
 */
(function () {
  'use strict';

  var ATTR = 'data-yooadmin-studio-color-mode-effective';
  var STYLE_ID = 'yoo-dark-tinymce-style';

  var DARK_CSS =
    'html{background-color:#1a1d23!important;}' +
    'body,body.mce-content-body{background-color:#1a1d23!important;color:#cfd6e0!important;}' +
    'body p,body li,body td,body th,body dl,body dt,body dd,body figcaption{color:#cfd6e0!important;}' +
    'body a{color:#eda934!important;}' +
    'body h1,body h2,body h3,body h4,body h5,body h6{color:#e8ecf1!important;}' +
    'body blockquote{border-left-color:rgba(237,169,52,.5)!important;color:#9aa5b1!important;}' +
    'body code,body pre{background-color:#0f1216!important;color:#cfd6e0!important;}' +
    'body ::selection{background:rgba(237,169,52,.35);}' +
    'body table td,body table th{border-color:rgba(255,255,255,.14)!important;}';

  var booted = false;
  var pollTimer = null;
  var pollCount = 0;
  var tinymceBound = false;

  function isDark() {
    return document.documentElement.getAttribute(ATTR) === 'dark';
  }

  function ensureHead(doc) {
    if (!doc || !doc.documentElement) {
      return null;
    }
    var head = doc.head || doc.getElementsByTagName('head')[0];
    if (!head) {
      head = doc.createElement('head');
      if (doc.documentElement.firstChild) {
        doc.documentElement.insertBefore(head, doc.documentElement.firstChild);
      } else {
        doc.documentElement.appendChild(head);
      }
    }
    return head;
  }

  function syncFrame(frame, dark) {
    var doc;
    try {
      doc = frame.contentDocument || (frame.contentWindow && frame.contentWindow.document);
    } catch (e) {
      return;
    }
    if (!doc || !doc.documentElement) {
      return;
    }

    var styleEl = doc.getElementById(STYLE_ID);

    if (dark) {
      var head = ensureHead(doc);
      if (head) {
        if (!styleEl) {
          styleEl = doc.createElement('style');
          styleEl.id = STYLE_ID;
          head.appendChild(styleEl);
        }
        if (styleEl.textContent !== DARK_CSS) {
          styleEl.textContent = DARK_CSS;
        }
      }
      if (doc.body) {
        doc.body.classList.add('ysh-dark-editor');
      }
    } else {
      if (styleEl && styleEl.parentNode) {
        styleEl.parentNode.removeChild(styleEl);
      }
      if (doc.body) {
        doc.body.classList.remove('ysh-dark-editor');
      }
    }
  }

  function apply() {
    var dark = isDark();

    var frames = document.querySelectorAll("iframe[id$='_ifr']");
    for (var i = 0; i < frames.length; i++) {
      syncFrame(frames[i], dark);
    }

    var areas = document.querySelectorAll('textarea.wp-editor-area');
    for (var j = 0; j < areas.length; j++) {
      if (dark) {
        areas[j].style.setProperty('background-color', 'var(--yp-dark-surface-sunken, #0f1216)', 'important');
        areas[j].style.setProperty('color', 'var(--yp-dark-text, #cfd6e0)', 'important');
      } else {
        areas[j].style.removeProperty('background-color');
        areas[j].style.removeProperty('color');
      }
    }
  }

  // TinyMCE may not be loaded yet when this script runs (it is enqueued before
  // wp-tinymce in the footer). Poll briefly to (a) bind editor lifecycle events
  // once tinymce appears and (b) re-apply while a JS-built editor mounts late.
  function poll() {
    pollCount++;
    apply();

    if (!tinymceBound && window.tinymce && typeof window.tinymce.on === 'function') {
      tinymceBound = true;
      try {
        window.tinymce.on('AddEditor', function (e) {
          var ed = e && e.editor;
          if (ed && typeof ed.on === 'function') {
            ed.on('init SetContent', function () {
              window.setTimeout(apply, 30);
            });
          }
          window.setTimeout(apply, 60);
        });
      } catch (e) {
        /* ignore */
      }
    }

    // Stop after ~20s; the color-mode observer handles changes afterwards.
    if (pollCount < 28) {
      pollTimer = window.setTimeout(poll, 700);
    }
  }

  function watch() {
    apply();
    poll();

    new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        if (muts[i].attributeName === ATTR) {
          apply();
          break;
        }
      }
    }).observe(document.documentElement, { attributes: true, attributeFilter: [ATTR] });

    document.addEventListener('ysh-studio-color-mode-changed', apply);
    window.addEventListener('load', apply);
  }

  function boot() {
    if (booted) {
      return;
    }
    booted = true;
    watch();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
