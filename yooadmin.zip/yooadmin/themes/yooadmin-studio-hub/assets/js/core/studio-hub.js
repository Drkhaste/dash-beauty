/**
 * Studio Hub admin theme — color mode + submenu popup (theme-only; no extended/core edits).
 */
(function () {
  'use strict';

  var studioToastTimer = null;
  var studioToastHideTimer = null;

  function readRawMode() {
    var v = document.documentElement.getAttribute('data-yooadmin-studio-color-mode');
    return v === 'dark' || v === 'auto' || v === 'light' ? v : 'auto';
  }

  function effectiveFromRaw(raw) {
    if (raw === 'auto') {
      try {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      } catch (e) {
        return 'light';
      }
    }
    return raw === 'dark' ? 'dark' : 'light';
  }

  function dispatchStudioColorModeChanged() {
    try {
      document.dispatchEvent(new CustomEvent('ysh-studio-color-mode-changed'));
    } catch (e) {
      /* IE11 — ignore */
    }
  }

  var SHELL_INLINE_BG_PROPS = ['background', 'background-color', 'color-scheme'];

  function clearShellInlineStyles(el) {
    if (!el || !el.style) {
      return;
    }
    for (var i = 0; i < SHELL_INLINE_BG_PROPS.length; i++) {
      el.style.removeProperty(SHELL_INLINE_BG_PROPS[i]);
    }
  }

  function syncStudioShellThemeChrome(eff) {
    var dark = eff === 'dark';
    var html = document.documentElement;
    var body = document.body;

    html.classList.toggle('is-dark-theme', dark);
    if (body) {
      body.classList.toggle('is-dark-theme', dark);
    }

    if (dark) {
      html.style.setProperty('--ysh-card', '#1a1d23');
      html.style.setProperty('--ysh-surface', '#121418');
      html.style.colorScheme = 'dark';
    } else {
      html.style.removeProperty('--ysh-card');
      html.style.removeProperty('--ysh-surface');
      html.style.removeProperty('color-scheme');
      html.style.colorScheme = 'light';
    }

    clearShellInlineStyles(html);
    clearShellInlineStyles(body);

    ['wpwrap', 'wpcontent', 'wpbody', 'wpbody-content'].forEach(function (id) {
      clearShellInlineStyles(document.getElementById(id));
    });

    clearShellInlineStyles(document.querySelector('.yoo-shell-content'));

    if (!dark) {
      document
        .querySelectorAll('iframe[name="editor-canvas"], iframe[name="style-book-canvas"]')
        .forEach(function (frame) {
          clearShellInlineStyles(frame);
          try {
            var doc = frame.contentDocument || frame.contentWindow.document;
            if (doc) {
              clearShellInlineStyles(doc.documentElement);
              clearShellInlineStyles(doc.body);
            }
          } catch (e) {
            /* cross-origin */
          }
        });
    }
  }

  window.yshSyncStudioShellThemeChrome = syncStudioShellThemeChrome;

  function syncBlockEditorThemeChrome(eff) {
    if (!document.body || !document.body.classList.contains('block-editor-page')) {
      return;
    }
    if (typeof window.yshBlockEditorThemeSync === 'function') {
      window.yshBlockEditorThemeSync();
    }
  }

  function appearanceI18n() {
    var cfg = window.yooadminStudioHubAppearance || {};
    return cfg.i18n || {};
  }

  function t(key, fallback) {
    return appearanceI18n()[key] || fallback;
  }

  function sprintfOne(template, value) {
    return String(template || '').replace('%s', value);
  }

  function showStudioHubToast(message, type) {
    if (!message || !document.body) {
      return;
    }
    type = type === 'error' ? 'error' : type === 'info' ? 'info' : 'success';

    document.querySelectorAll('.yp-toast-message.ysh-layout-saved-toast').forEach(function (el) {
      if (el.parentNode) {
        el.parentNode.removeChild(el);
      }
    });

    if (studioToastTimer) {
      clearTimeout(studioToastTimer);
      studioToastTimer = null;
    }
    if (studioToastHideTimer) {
      clearTimeout(studioToastHideTimer);
      studioToastHideTimer = null;
    }

    var iconChar = type === 'error' ? '✕' : type === 'info' ? 'ℹ' : '✓';
    var toast = document.createElement('div');
    toast.className = 'yp-toast-message ysh-layout-saved-toast yp-toast-' + type;
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');

    var icon = document.createElement('span');
    icon.className = 'yp-toast-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = iconChar;

    var text = document.createElement('span');
    text.className = 'yp-toast-text';
    text.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(text);
    document.body.appendChild(toast);

    requestAnimationFrame(function () {
      toast.classList.add('yp-toast-show');
    });

    studioToastHideTimer = setTimeout(function () {
      toast.classList.remove('yp-toast-show');
      studioToastTimer = setTimeout(function () {
        studioToastTimer = null;
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3200);
  }

  window.yshShowStudioHubToast = showStudioHubToast;

  function applyEffective() {
    var raw = readRawMode();
    var eff = effectiveFromRaw(raw);
    document.documentElement.setAttribute('data-yooadmin-studio-color-mode-effective', eff);
    syncStudioShellThemeChrome(eff);
    syncBlockEditorThemeChrome(eff);
    if (typeof window.yshPluginAdminAdaptSyncMode === 'function') {
      window.yshPluginAdminAdaptSyncMode();
    }
    dispatchStudioColorModeChanged();
    if (typeof syncWooMarketplaceChrome === 'function') {
      syncWooMarketplaceChrome();
    }
    if (typeof syncWooAnalyticsChrome === 'function') {
      syncWooAnalyticsChrome();
    }
    if (typeof syncPluginsExtensionsDarkChrome === 'function') {
      syncPluginsExtensionsDarkChrome();
    }
  }

  function setStudioColorModeOnHtml(mode) {
    var m = mode === 'dark' || mode === 'auto' || mode === 'light' ? mode : 'light';
    document.documentElement.setAttribute('data-yooadmin-studio-color-mode', m);
    applyEffective();
  }

  function syncAppearanceUI(activeMode) {
    var mode =
      activeMode === 'dark' || activeMode === 'auto' || activeMode === 'light' ? activeMode : 'light';

    document.querySelectorAll('[data-ysh-appearance-root]').forEach(function (root) {
      var togglers = root.querySelectorAll('.ysh-appearance__ti');
      for (var t = 0; t < togglers.length; t++) {
        togglers[t].classList.remove('is-current');
      }
      var curTi = root.querySelector('.ysh-appearance__ti--' + mode);
      if (curTi) {
        curTi.classList.add('is-current');
      }

      var opts = root.querySelectorAll('.ysh-appearance__menu [data-ysh-appearance]');
      for (var i = 0; i < opts.length; i++) {
        var b = opts[i];
        var k = b.getAttribute('data-ysh-appearance');
        b.classList.toggle('is-active', k === mode);
        b.setAttribute('aria-pressed', k === mode ? 'true' : 'false');
      }
    });
  }

  function normalizeWidthMode(mode) {
    return mode === 'wide' || mode === 'full' || mode === 'normal' ? mode : 'normal';
  }

  function widthCssValue(mode) {
    mode = normalizeWidthMode(mode);
    if (mode === 'full') {
      return 'calc(100% - clamp(24px, 4vw, 64px))';
    }
    if (mode === 'wide') {
      return '1720px';
    }
    return '1400px';
  }

  function readWidthMode() {
    var cfg = window.yooadminStudioHubAppearance || {};
    var attr = document.documentElement.getAttribute('data-ysh-layout-width');
    return normalizeWidthMode(attr || cfg.widthMode || 'normal');
  }

  function widthModeLabel(mode) {
    mode = normalizeWidthMode(mode);
    if (mode === 'full') {
      return t('widthFull', 'Full');
    }
    if (mode === 'wide') {
      return t('widthWide', 'Wide');
    }
    return t('widthNormal', 'Normal');
  }

  function widthSavedMessage(mode) {
    return sprintfOne(t('widthSaved', 'Page width saved: %s.'), widthModeLabel(mode));
  }

  function applyLayoutWidth(mode) {
    var normalized = normalizeWidthMode(mode);
    var cssValue = widthCssValue(normalized);
    document.documentElement.setAttribute('data-ysh-layout-width', normalized);
    document.documentElement.style.setProperty('--ysh-layout-max', cssValue, 'important');
    if (document.body) {
      document.body.setAttribute('data-ysh-layout-width', normalized);
      document.body.style.setProperty('--ysh-layout-max', cssValue, 'important');
    }
    syncWidthUI(normalized);
  }

  function syncWidthUI(activeMode) {
    var mode = normalizeWidthMode(activeMode);
    document.querySelectorAll('[data-ysh-width-root]').forEach(function (root) {
      var toggle = root.querySelector('.ysh-width__toggle');
      var toggleIcon = root.querySelector('.ysh-width__toggle-icon');
      var activeOption = null;
      var opts = root.querySelectorAll('[data-ysh-width]');
      root.setAttribute('data-ysh-width-current', mode);
      if (toggle) {
        toggle.classList.remove('ysh-width__toggle--normal', 'ysh-width__toggle--wide', 'ysh-width__toggle--full');
        toggle.classList.add('ysh-width__toggle--' + mode);
        toggle.title =
          mode === 'full' ? 'Full width' : mode === 'wide' ? 'Wide width' : 'Normal width';
        toggle.setAttribute('aria-label', toggle.title);
      }
      for (var i = 0; i < opts.length; i++) {
        var btn = opts[i];
        var key = normalizeWidthMode(btn.getAttribute('data-ysh-width'));
        var isActive = key === mode;
        btn.classList.toggle('is-active', isActive);
        btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        if (isActive) {
          activeOption = btn;
        }
      }
      if (toggleIcon && activeOption) {
        var svg = activeOption.querySelector('svg');
        if (svg) {
          toggleIcon.innerHTML = svg.outerHTML;
        }
      }
    });
  }

  function setAppearanceMenuOpen(root, open) {
    var toggle = root.querySelector('.ysh-appearance__toggle');
    var menu = root.querySelector('.ysh-appearance__menu');
    if (!toggle || !menu) return;
    if (open) {
      menu.removeAttribute('hidden');
      root.classList.add('is-open');
      toggle.setAttribute('aria-expanded', 'true');
    } else {
      menu.setAttribute('hidden', 'hidden');
      root.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
    }
  }

  function bindAppearanceDocCloseOnce() {
    if (bindAppearanceDocCloseOnce.done) {
      return;
    }
    bindAppearanceDocCloseOnce.done = true;
    document.addEventListener(
      'click',
      function (e) {
        var open = document.querySelector('.ysh-appearance.is-open');
        if (open && !open.contains(e.target)) {
          setAppearanceMenuOpen(open, false);
        }
        var widthOpen = document.querySelector('.ysh-width.is-open');
        if (widthOpen) {
          var widthMenu = widthOpen.querySelector('.ysh-width__menu');
          if (
            !widthOpen.contains(e.target) &&
            !(widthMenu && widthMenu.contains(e.target))
          ) {
            setWidthMenuOpen(widthOpen, false);
          }
        }
      },
      true
    );
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') {
        return;
      }
      var open = document.querySelector('.ysh-appearance.is-open');
      if (open) {
        setAppearanceMenuOpen(open, false);
      }
      var widthOpen = document.querySelector('.ysh-width.is-open');
      if (widthOpen) {
        setWidthMenuOpen(widthOpen, false);
      }
    });
  }

  function bindAppearanceRoot(root) {
    if (!root || root.__yshAppearanceBound) {
      return;
    }
    root.__yshAppearanceBound = true;

    var toggle = root.querySelector('.ysh-appearance__toggle');
    var menu = root.querySelector('.ysh-appearance__menu');
    if (!toggle || !menu) {
      return;
    }

    bindAppearanceDocCloseOnce();

    toggle.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var isOpen = root.classList.contains('is-open');
      setAppearanceMenuOpen(root, !isOpen);
    });

    menu.addEventListener('click', function (e) {
      var cfg = window.yooadminStudioHubAppearance;
      if (!cfg || !cfg.ajaxUrl || !cfg.nonce) {
        return;
      }

      var btn = e.target.closest('[data-ysh-appearance]');
      if (!btn || !menu.contains(btn)) {
        return;
      }
      e.preventDefault();
      var mode = btn.getAttribute('data-ysh-appearance');
      if (mode !== 'light' && mode !== 'dark' && mode !== 'auto') return;
      if (root.getAttribute('aria-busy') === 'true') return;

      root.setAttribute('aria-busy', 'true');
      var fd = new FormData();
      fd.append('action', 'yooadmin_save_studio_hub_color_mode');
      fd.append('nonce', cfg.nonce);
      fd.append('color_mode', mode);

      fetch(cfg.ajaxUrl, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      })
        .then(function (r) {
          return r.json();
        })
        .then(function (json) {
          if (!json || !json.success) {
            throw new Error((json && json.data && json.data.message) || 'save failed');
          }
          var saved = json.data && json.data.color_mode ? json.data.color_mode : mode;
          cfg.colorMode = saved;
          setStudioColorModeOnHtml(saved);
          syncAppearanceUI(saved);
          setAppearanceMenuOpen(root, false);
        })
        .catch(function () {
          /* keep UI unchanged on failure */
        })
        .then(function () {
          root.removeAttribute('aria-busy');
        });
    });
  }

  function setWidthMenuOpen(root, open) {
    var toggle = root.querySelector('.ysh-width__toggle');
    var menu = root.querySelector('.ysh-width__menu');
    if (!toggle || !menu) return;
    if (open) {
      document.querySelectorAll('.ysh-width.is-open').forEach(function (other) {
        if (other !== root) {
          setWidthMenuOpen(other, false);
        }
      });
      menu.removeAttribute('hidden');
      root.classList.add('is-open');
      toggle.setAttribute('aria-expanded', 'true');
    } else {
      menu.setAttribute('hidden', 'hidden');
      root.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
    }
  }

  function bindWidthRoot(root) {
    if (!root || root.__yshWidthBound) {
      return;
    }
    root.__yshWidthBound = true;

    var toggle = root.querySelector('.ysh-width__toggle');
    var menu = root.querySelector('.ysh-width__menu');
    if (!toggle || !menu) {
      return;
    }

    bindAppearanceDocCloseOnce();

    toggle.addEventListener(
      'click',
      function (e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        var isOpen = root.classList.contains('is-open');
        setWidthMenuOpen(root, !isOpen);
      },
      true
    );

    menu.addEventListener('click', function (e) {
      var cfg = window.yooadminStudioHubAppearance;
      var btn = e.target.closest('[data-ysh-width]');
      var mode;
      var previous;
      var fd;
      if (!btn || !menu.contains(btn)) {
        return;
      }
      e.preventDefault();
      mode = normalizeWidthMode(btn.getAttribute('data-ysh-width'));
      if (root.getAttribute('aria-busy') === 'true') return;
      previous = normalizeWidthMode((cfg && cfg.widthMode) || readWidthMode());

      applyLayoutWidth(mode);
      setWidthMenuOpen(root, false);
      if (!cfg || !cfg.ajaxUrl || !cfg.nonce) {
        applyLayoutWidth(previous);
        return;
      }

      root.setAttribute('aria-busy', 'true');
      fd = new URLSearchParams();
      fd.append('action', 'yooadmin_save_studio_hub_width_mode');
      fd.append('nonce', cfg.nonce);
      fd.append('width_mode', mode);

      fetch(cfg.ajaxUrl, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin',
        keepalive: true
      })
        .then(function (r) {
          return r.json();
        })
        .then(function (json) {
          if (!json || !json.success) {
            throw new Error((json && json.data && json.data.message) || 'save failed');
          }
          var saved = json.data && json.data.width_mode ? json.data.width_mode : mode;
          cfg.widthMode = saved;
          applyLayoutWidth(saved);
          showStudioHubToast(widthSavedMessage(saved), 'success');
        })
        .catch(function () {
          applyLayoutWidth(previous);
          showStudioHubToast(
            t('widthSaveFailed', 'Could not save page width. Please try again.'),
            'error'
          );
        })
        .then(function () {
          root.removeAttribute('aria-busy');
        });
    });
  }

  function yshAppearancePageActive() {
    if (!document.body) {
      return false;
    }
    return (
      document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub') ||
      document.body.classList.contains('block-editor-page') ||
      document.body.classList.contains('site-editor-php')
    );
  }

  function initStudioAppearanceToggle(scope) {
    var cfg = window.yooadminStudioHubAppearance;
    if (!yshAppearancePageActive()) return;

    applyLayoutWidth(readWidthMode());

    var roots = scope && scope.matches && scope.matches('[data-ysh-appearance-root]')
      ? [scope]
      : Array.prototype.slice.call(document.querySelectorAll('[data-ysh-appearance-root]'));

    if (cfg && cfg.ajaxUrl && cfg.nonce) {
      for (var i = 0; i < roots.length; i++) {
        bindAppearanceRoot(roots[i]);
      }

      syncAppearanceUI(cfg.colorMode || readRawMode());
    }

    var widthRoots = scope && scope.matches && scope.matches('[data-ysh-width-root]')
      ? [scope]
      : Array.prototype.slice.call(document.querySelectorAll('[data-ysh-width-root]'));
    for (var w = 0; w < widthRoots.length; w++) {
      bindWidthRoot(widthRoots[w]);
    }
    syncWidthUI(readWidthMode());
  }

  window.yshInitStudioAppearanceToggle = initStudioAppearanceToggle;

  if (window.matchMedia) {
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    if (mq.addEventListener) {
      mq.addEventListener('change', function () {
        if (readRawMode() === 'auto') {
          applyEffective();
        }
      });
    } else if (mq.addListener) {
      mq.addListener(function () {
        if (readRawMode() === 'auto') {
          applyEffective();
        }
      });
    }
  }

  function markStudioPopup() {
    var el = document.getElementById('yp-popup');
    if (el) {
      el.classList.add('yp-popup--studio-hub', 'ysh-adapt-skip');
    }
  }

  window.yshMarkStudioPopup = markStudioPopup;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', markStudioPopup);
  } else {
    markStudioPopup();
  }

  /* ---------- Submenu popup: two-column menu + descriptions (theme-only) ---------- */

  function isStudioHubTheme() {
    if (!document.body) {
      return false;
    }
    if (
      document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub') ||
      document.body.classList.contains('yooadmin-theme-studio-hub')
    ) {
      return true;
    }
    return document.documentElement.classList.contains('yooadmin-studio-hub-html');
  }

  var YSH_POPUP_DEFAULT_DESC_LS = 'ysh_studio_hub_popup_default_desc';

  function popupConfig() {
    var w = window.yooadminStudioHubAppearance;
    if (w && w.popup) {
      return w.popup;
    }
    return window.yshStudioHubPopup || null;
  }

  function defaultSectionDesc(S) {
    try {
      var ls = localStorage.getItem(YSH_POPUP_DEFAULT_DESC_LS);
      if (ls && String(ls).trim()) return String(ls).trim();
    } catch (e1) {}
    var cfg = popupConfig();
    if (cfg && typeof cfg.defaultSectionDesc === 'string' && cfg.defaultSectionDesc.trim()) {
      return cfg.defaultSectionDesc.trim();
    }
    return S.DEFAULT;
  }

  function lookupPhpPopupDesc(href) {
    var cfg = popupConfig();
    if (!cfg || !cfg.itemDescriptions) {
      return '';
    }
    var map = cfg.itemDescriptions;
    if (map[href]) {
      return map[href];
    }
    try {
      var abs = new URL(href, window.location.origin).href;
      if (map[abs]) {
        return map[abs];
      }
    } catch (e) {}
    return '';
  }

  function popupDescStrings() {
    return {
      DEFAULT: 'Open this section in the admin.',
      YOO_GENERIC: 'YOOAdmin panel page.',
      ALL_POSTS: 'View, edit, and organize blog posts.',
      ADD_POST: 'Create a new blog post.',
      ALL_PAGES: 'View, edit, and organize pages.',
      ADD_PAGE: 'Create a new page.',
      CATEGORIES: 'Organize and edit post categories.',
      TAGS: 'Manage post tags.',
      MEDIA: 'Upload files and browse the media library.',
      COMMENTS: 'Moderate and reply to comments.',
      USERS: 'Manage users and roles.',
      PLUGINS: 'Activate, update, and organize plugins.',
      THEMES: 'Change site appearance and themes.',
      SETTINGS: 'Adjust general site preferences.',
      SETTINGS_GENERAL: 'Site title, URL, timezone, language, and membership.',
      SETTINGS_WRITING: 'Default post category, format, email posting, and ping services.',
      SETTINGS_READING: 'Homepage display, blog pages, and feed settings.',
      SETTINGS_DISCUSSION: 'Comment defaults, avatars, and moderation rules.',
      SETTINGS_MEDIA: 'Image sizes and how uploads are organized.',
      SETTINGS_PERMALINK: 'Custom URL structures for posts, categories, and tags.',
      SETTINGS_PRIVACY: 'Privacy policy page and personal data settings.',
      TOOLS_HOME: 'Maintenance utilities: import, export, health checks, and more.',
      ACTION_SCHEDULER: 'View and manage background tasks scheduled by plugins.',
      YOAST_REDIRECTS: 'Manage SEO redirects for changed URLs (Yoast SEO).',
      NETWORK_SETUP: 'Configure multisite network settings.',
      CUSTOMIZER: 'Customize widgets and appearance live.',
      YOO_DASHBOARD: 'YOOAdmin home — shortcuts and overview for your site admin.',
      YOO_SETTINGS: 'Tune YOOAdmin behavior, appearance, notifications, and integrations.',
      YOO_EXTENSIONS: 'Browse add-ons, licensing, and updates in the YOOAdmin extensions hub.',
      YOO_PLUGINS: 'Manage installed plugins using the YOOAdmin plugin manager.',
      YOO_LICENSE: 'Activate or review your YOOAdmin license and plan features.',
      YOO_ADMIN_THEME_SETTINGS: 'Configure the admin theme (colors, dark mode, layout options).',
      YOO_THEMES: 'Browse and adjust YOOAdmin admin themes.',
      YOO_THEME_MANAGER: 'Pick which admin theme YOOAdmin uses and manage it.',
      YOO_UPDATE_CENTER: 'Updates and backups workflow tied to YOOAdmin.',
      YOO_MEDIA: 'Media library inside the YOOAdmin experience.',
      YOO_USERS: 'User list and management in YOOAdmin.',
      YOO_USERS_NEW: 'Create a new user and assign a role.',
      YOO_POSTS: 'Posts list inside YOOAdmin.',
      YOO_PAGES: 'Pages list inside YOOAdmin.',
      YOO_CATEGORIES: 'Organize content categories from YOOAdmin.',
      YOO_TAGS: 'Manage content tags from YOOAdmin.',
      YOO_NOTIFICATIONS: 'YOOAdmin notification inbox and alerts.',
      YOO_BLOCKED_SENDERS: 'Manage blocked senders for YOOAdmin notifications.',
      YOO_ENABLE_FOCUS: 'Turn on or adjust Focus mode for a calmer admin UI.',
      YOO_SETUP: 'YOOAdmin first-time setup wizard.'
    };
  }

  function yooadminPageDescription(slug, S) {
    var k = String(slug || '').toLowerCase();
    var map = {
      'yooadmin-dashboard': 'YOO_DASHBOARD',
      'yooadmin-settings': 'YOO_SETTINGS',
      'yooadmin-extensions': 'YOO_EXTENSIONS',
      'yooadmin-plugins': 'YOO_PLUGINS',
      'yooadmin-license': 'YOO_LICENSE',
      'yooadmin-admin-theme-settings': 'YOO_ADMIN_THEME_SETTINGS',
      'yooadmin-themes': 'YOO_THEMES',
      'yooadmin-theme-manager': 'YOO_THEME_MANAGER',
      'yooadmin-update-center': 'YOO_UPDATE_CENTER',
      'yooadmin-media': 'YOO_MEDIA',
      'yooadmin-users': 'YOO_USERS',
      'yooadmin-users-new': 'YOO_USERS_NEW',
      'yooadmin-posts': 'YOO_POSTS',
      'yooadmin-pages': 'YOO_PAGES',
      'yooadmin-categories': 'YOO_CATEGORIES',
      'yooadmin-tags': 'YOO_TAGS',
      'yooadmin-notifications': 'YOO_NOTIFICATIONS',
      'yooadmin-blocked-senders': 'YOO_BLOCKED_SENDERS',
      'yooadmin-enable-focus': 'YOO_ENABLE_FOCUS',
      'yooadmin-setup': 'YOO_SETUP'
    };
    var sk = map[k];
    if (sk && S[sk]) return S[sk];
    if (/^yooadmin-/.test(k)) return S.YOO_GENERIC;
    return '';
  }

  function resolvePopupItemDesc(href, labelText) {
    var phpDesc = lookupPhpPopupDesc(href);
    if (phpDesc) {
      return phpDesc;
    }

    var S = popupDescStrings();
    var u = String(href || '');
    var cleanLabel = String(labelText || '')
      .replace(/\s+/g, ' ')
      .trim();
    var url;
    var file = '';
    var params = null;
    try {
      url = new URL(u, window.location.origin);
      var parts = (url.pathname || '').split('/').filter(Boolean);
      file = parts.length ? parts[parts.length - 1].toLowerCase() : '';
      params = url.searchParams;
    } catch (e) {
      return defaultSectionDesc(S);
    }

    if (file === 'post-new.php') {
      var ptNew = params ? (params.get('post_type') || '').toLowerCase() : '';
      if (ptNew === 'page') return S.ADD_PAGE;
      if (ptNew && ptNew !== 'post') return defaultSectionDesc(S);
      return S.ADD_POST;
    }

    if (file === 'edit.php') {
      var pt = params ? (params.get('post_type') || '').toLowerCase() : '';
      if (pt === 'page') return S.ALL_PAGES;
      if (!pt || pt === 'post') return S.ALL_POSTS;
      return defaultSectionDesc(S);
    }

    if (file === 'edit-tags.php') {
      var tax = params ? (params.get('taxonomy') || '').toLowerCase() : '';
      if (tax === 'category') return S.CATEGORIES;
      if (tax === 'post_tag') return S.TAGS;
      return defaultSectionDesc(S);
    }

    if (file === 'upload.php') return S.MEDIA;
    if (file === 'edit-comments.php') return S.COMMENTS;
    if (file === 'users.php') return S.USERS;
    if (file === 'plugins.php') return S.PLUGINS;
    if (file === 'themes.php') return S.THEMES;
    if (file === 'tools.php' && params) {
      var toolsPage = (params.get('page') || '').toLowerCase();
      if (!toolsPage) {
        return S.TOOLS_HOME;
      }
      if (toolsPage === 'action-scheduler') {
        return S.ACTION_SCHEDULER;
      }
      if (toolsPage === 'wpseo_redirects_tools') {
        return S.YOAST_REDIRECTS;
      }
    }

    if (file === 'options-general.php') {
      if (params && params.get('page') === 'ai-wp-admin') {
        return 'Configure WordPress AI features and experiments.';
      }
      return S.SETTINGS_GENERAL;
    }
    if (file === 'options-writing.php') return S.SETTINGS_WRITING;
    if (file === 'options-reading.php') return S.SETTINGS_READING;
    if (file === 'options-discussion.php') return S.SETTINGS_DISCUSSION;
    if (file === 'options-media.php') return S.SETTINGS_MEDIA;
    if (file === 'options-permalink.php') return S.SETTINGS_PERMALINK;
    if (file === 'options-privacy.php' || file === 'privacy.php') return S.SETTINGS_PRIVACY;
    if (file === 'options-connectors.php') return 'Connect AI and third-party services for WordPress features.';
    if (file === 'customize.php') return S.CUSTOMIZER;
    if (file === 'nav-menus.php') return 'Build and assign navigation menus.';
    if (file === 'widgets.php') return 'Manage sidebar and footer widget areas.';
    if (file === 'site-editor.php') return 'Edit block templates and global styles.';
    if (file === 'import.php') return 'Bring content in from another system.';
    if (file === 'export.php') return 'Download an export of your content.';
    if (file === 'site-health.php') return 'Check and improve your site health.';
    if (file === 'network.php') return S.NETWORK_SETUP;
    if (file === 'user-new.php') return 'Add a new user account and assign a role.';
    if (file === 'profile.php') return 'Manage your profile and account details.';

    if ((file === 'admin.php' || file === 'index.php') && params) {
      var page = params.get('page');
      if (page) {
        var yd = yooadminPageDescription(page, S);
        if (yd) return yd;
      }
    }

    if (cleanLabel) {
      return 'Open ' + cleanLabel + ' in the admin.';
    }

    return defaultSectionDesc(S);
  }

  function setPopupDescHintAttrs(el) {
    if (!el) return;
    el.setAttribute('data-ysh-hub', '1');
    el.setAttribute('title', 'Alt-click to edit generic hint (saved in this browser)');
  }

  function attachPopupDescEditHandler() {
    var popup = document.getElementById('yp-popup');
    if (!popup) {
      window.setTimeout(attachPopupDescEditHandler, 120);
      return;
    }
    if (popup.__yshAltDescBound) return;
    popup.__yshAltDescBound = true;
    popup.addEventListener('click', function (e) {
      if (!e.altKey) return;
      if (!isStudioHubTheme()) return;
      var span = e.target.closest('.yp-icon-desc[data-ysh-hub]');
      if (!span || !popup.contains(span)) return;
      e.preventDefault();
      e.stopPropagation();
      var cur = span.textContent.trim();
      var next = window.prompt('Generic section hint (saved in this browser)', cur);
      if (next === null) return;
      next = String(next).trim();
      try {
        if (next) {
          localStorage.setItem(YSH_POPUP_DEFAULT_DESC_LS, next);
        } else {
          localStorage.removeItem(YSH_POPUP_DEFAULT_DESC_LS);
        }
      } catch (err) {}
      enhanceStudioHubPopupMenu();
    });
  }

  function enhanceStudioHubPopupMenu() {
    if (!isStudioHubTheme()) return;
    var popup = document.getElementById('yp-popup');
    if (!popup || !popup.classList.contains('yp-popup--studio-hub')) return;
    var root = document.getElementById('yp-popup-content');
    if (!root) return;

    var tiles = root.querySelectorAll('a.yp-icon-tile');
    if (!tiles.length) return;

    for (var i = 0; i < tiles.length; i++) {
      var tile = tiles[i];
      var href = tile.getAttribute('href') || '';
      var label = tile.querySelector(':scope > .yp-icon-label');
      if (!label) {
        label = tile.querySelector('.yp-icon-label');
      }
      if (!label) continue;
      var labelText = (label.textContent || '').replace(/\s+/g, ' ').trim();

      var wrap = tile.querySelector(':scope > .yp-icon-tile__text');
      if (wrap) {
        var dEx = wrap.querySelector('.yp-icon-desc');
        if (dEx) {
          dEx.textContent = resolvePopupItemDesc(href, labelText);
          setPopupDescHintAttrs(dEx);
        } else {
          var d0 = document.createElement('span');
          d0.className = 'yp-icon-desc';
          d0.textContent = resolvePopupItemDesc(href, labelText);
          setPopupDescHintAttrs(d0);
          wrap.appendChild(d0);
        }
        tile.classList.add('yp-icon-tile--hub-menu');
        continue;
      }

      var textWrap = document.createElement('span');
      textWrap.className = 'yp-icon-tile__text';
      label.parentNode.insertBefore(textWrap, label);
      textWrap.appendChild(label);

      var desc = document.createElement('span');
      desc.className = 'yp-icon-desc';
      desc.textContent = resolvePopupItemDesc(href, labelText);
      setPopupDescHintAttrs(desc);
      textWrap.appendChild(desc);

      tile.classList.add('yp-icon-tile--hub-menu');
    }
  }

  /** Keep pagination arrows inside the pages row (yp-popup.js may lift them to the outer wrapper). */
  function reparentStudioHubPopupNavArrows() {
    if (!isStudioHubTheme()) return;
    var popup = document.getElementById('yp-popup');
    if (!popup || !popup.classList.contains('yp-popup--studio-hub')) return;
    var pagesWrapper = popup.querySelector('.yp-popup-pages-wrapper');
    if (!pagesWrapper) return;

    var prevBtn = popup.querySelector('.yp-popup-nav-prev');
    var nextBtn = popup.querySelector('.yp-popup-nav-next');

    if (prevBtn && prevBtn.parentElement !== pagesWrapper) {
      pagesWrapper.insertBefore(prevBtn, pagesWrapper.firstChild);
    }
    if (nextBtn && nextBtn.parentElement !== pagesWrapper) {
      pagesWrapper.appendChild(nextBtn);
    }
  }

  function scheduleEnhancePopup() {
    if (!isStudioHubTheme()) return;
    clearTimeout(scheduleEnhancePopup._t);
    scheduleEnhancePopup._t = window.setTimeout(function () {
      requestAnimationFrame(function () {
        enhanceStudioHubPopupMenu();
        reparentStudioHubPopupNavArrows();
      });
    }, 60);
  }

  window.yshScheduleEnhancePopup = scheduleEnhancePopup;

  function wrapYpShowPopup() {
    var orig = window.ypShowPopup;
    if (typeof orig !== 'function' || orig.__yshStudioHubWrapped) return false;
    window.ypShowPopup = function (menuSlug, customTitle) {
      portalMediaLightboxesToBody();
      var args = arguments;
      var popup = document.getElementById('yp-popup');
      if (popup) {
        var box = popup.querySelector('.yp-popup-box');
        if (box) {
          box.style.removeProperty('--ysh-popup-loading-height');
          var previousHeight = parseFloat(popup.getAttribute('data-ysh-last-popup-height') || '0');
          box.style.setProperty(
            '--ysh-popup-loading-height',
            Math.max(previousHeight || 0, 170) + 'px'
          );
        }
        popup.querySelectorAll('.ysh-popup-loader').forEach(function (node) {
          if (!box || node.parentNode !== box) {
            node.parentNode.removeChild(node);
          }
        });
        var loader = box ? box.querySelector(':scope > .ysh-popup-loader') : null;
        if (!loader && box) {
          loader = document.createElement('div');
          loader.className = 'ysh-popup-loader';
          loader.setAttribute('role', 'status');
          loader.setAttribute('aria-live', 'polite');
          loader.innerHTML = '<span class="ysh-popup-loader__ring" aria-hidden="true"></span>';
          box.appendChild(loader);
        }
        popup.classList.add('is-ysh-popup-loading');
        popup.style.display = 'flex';
        document.documentElement.classList.add('yoo-popup-open');
        window.clearTimeout(popup.__yshPopupLoaderTimer);
        popup.__yshPopupLoaderTimer = window.setTimeout(function () {
          orig.apply(window, args);
          scheduleEnhancePopup();
          popup.__yshPopupLoaderTimer = window.setTimeout(function () {
            if (box) {
              popup.setAttribute(
                'data-ysh-last-popup-height',
                String(Math.round(box.scrollHeight || box.getBoundingClientRect().height || 0))
              );
              box.style.removeProperty('--ysh-popup-loading-height');
            }
            popup.classList.remove('is-ysh-popup-loading');
          }, 140);
        }, 160);
        return undefined;
      }
      var out = orig.apply(this, arguments);
      scheduleEnhancePopup();
      return out;
    };
    window.ypShowPopup.__yshStudioHubWrapped = true;
    return true;
  }

  function tryWrapPopupLoop() {
    if (wrapYpShowPopup()) return;
    window.setTimeout(tryWrapPopupLoop, 80);
  }

  function attachPopupContentObserver() {
    var content = document.getElementById('yp-popup-content');
    if (!content) {
      window.setTimeout(attachPopupContentObserver, 100);
      return;
    }
    if (content.__yshStudioHubMO) return;
    var mo = new MutationObserver(function () {
      if (!document.documentElement.classList.contains('yoo-popup-open')) return;
      scheduleEnhancePopup();
    });
    mo.observe(content, { childList: true, subtree: true });
    content.__yshStudioHubMO = true;
  }

  function initPopupEnhancements() {
    tryWrapPopupLoop();
    attachPopupContentObserver();
    attachPopupDescEditHandler();
  }

  var __yshWelcomeClockTimer = null;

  function pad2Clock(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function formatWelcomeTime12h(d) {
    var h24 = d.getHours();
    var h12 = h24 % 12;
    if (h12 === 0) {
      h12 = 12;
    }
    var suffix = h24 < 12 ? 'AM' : 'PM';
    return (
      pad2Clock(h12) +
      ':' +
      pad2Clock(d.getMinutes()) +
      ':' +
      pad2Clock(d.getSeconds()) +
      ' ' +
      suffix
    );
  }

  /** Calendar day key in the user's local timezone (same as Date display). */
  function ymdKey(d) {
    return d.getFullYear() + '-' + pad2Clock(d.getMonth() + 1) + '-' + pad2Clock(d.getDate());
  }

  /**
   * Format a date like WordPress `date_format` (common tokens only; literals passthrough).
   * Falls back to locale medium date when Intl is missing.
   */
  function formatWelcomeDateWpLike(d, locale, phpFmt) {
    var fmt = phpFmt && String(phpFmt).trim() ? String(phpFmt) : '';
    if (typeof Intl !== 'undefined' && !fmt) {
      try {
        return new Intl.DateTimeFormat(locale || undefined, { dateStyle: 'medium' }).format(d);
      } catch (e0) {
        /* fall through */
      }
    }
    if (typeof Intl !== 'undefined' && fmt) {
      try {
        var F = new Intl.DateTimeFormat(locale || undefined, { month: 'long' }).format(d);
        var M = new Intl.DateTimeFormat(locale || undefined, { month: 'short' }).format(d);
        var l = new Intl.DateTimeFormat(locale || undefined, { weekday: 'long' }).format(d);
        var D = new Intl.DateTimeFormat(locale || undefined, { weekday: 'short' }).format(d);
        var out = '';
        var esc = false;
        for (var i = 0; i < fmt.length; i++) {
          var c = fmt.charAt(i);
          if (esc) {
            out += c;
            esc = false;
            continue;
          }
          if (c === '\\' && i + 1 < fmt.length) {
            esc = true;
            continue;
          }
          switch (c) {
            case 'd':
              out += pad2Clock(d.getDate());
              break;
            case 'j':
              out += String(d.getDate());
              break;
            case 'm':
              out += pad2Clock(d.getMonth() + 1);
              break;
            case 'n':
              out += String(d.getMonth() + 1);
              break;
            case 'Y':
              out += String(d.getFullYear());
              break;
            case 'y':
              out += pad2Clock(d.getFullYear() % 100);
              break;
            case 'F':
              out += F;
              break;
            case 'M':
              out += M;
              break;
            case 'l':
              out += l;
              break;
            case 'S': {
              var day = d.getDate();
              var sfx = 'th';
              if (day % 10 === 1 && day % 100 !== 11) {
                sfx = 'st';
              } else if (day % 10 === 2 && day % 100 !== 12) {
                sfx = 'nd';
              } else if (day % 10 === 3 && day % 100 !== 13) {
                sfx = 'rd';
              }
              out += sfx;
              break;
            }
            case 'D':
              out += D;
              break;
            case 'g': {
              var h = d.getHours() % 12;
              out += String(h === 0 ? 12 : h);
              break;
            }
            case 'G':
              out += String(d.getHours());
              break;
            case 'h':
              out += pad2Clock((d.getHours() % 12) === 0 ? 12 : d.getHours() % 12);
              break;
            case 'H':
              out += pad2Clock(d.getHours());
              break;
            case 'i':
              out += pad2Clock(d.getMinutes());
              break;
            case 's':
              out += pad2Clock(d.getSeconds());
              break;
            case 'a':
              out += d.getHours() < 12 ? 'am' : 'pm';
              break;
            case 'A':
              out += d.getHours() < 12 ? 'AM' : 'PM';
              break;
            default:
              out += c;
          }
        }
        return out;
      } catch (e1) {
        /* fall through */
      }
    }
    try {
      return new Intl.DateTimeFormat(locale || undefined, { dateStyle: 'medium' }).format(d);
    } catch (e2) {
      return d.getFullYear() + '-' + pad2Clock(d.getMonth() + 1) + '-' + pad2Clock(d.getDate());
    }
  }

  function bindOneWelcomeClock(timeRoot) {
    if (!timeRoot || timeRoot.__yshClockBound) {
      return;
    }
    var timeEl = timeRoot.querySelector('.yp-studio-welcome-mock__datetime-time');
    var dateEl = timeRoot.querySelector('.yp-studio-welcome-mock__datetime-date');
    if (!timeEl) {
      return;
    }
    var iso = timeRoot.getAttribute('datetime');
    var serverMs = iso ? Date.parse(iso) : NaN;
    if (isNaN(serverMs)) {
      return;
    }
    timeRoot.__yshClockBound = true;
    var clientAt = Date.now();
    var locale = timeRoot.getAttribute('data-locale') || '';
    var phpDateFmt = timeRoot.getAttribute('data-wp-date-format') || '';
    var lastYmd = ymdKey(new Date(serverMs));

    function tick() {
      var now = new Date(serverMs + (Date.now() - clientAt));
      timeEl.textContent = formatWelcomeTime12h(now);
      if (dateEl) {
        var y = ymdKey(now);
        if (y !== lastYmd) {
          lastYmd = y;
          dateEl.textContent = formatWelcomeDateWpLike(now, locale, phpDateFmt);
        }
      }
    }

    timeRoot.__yshClockTick = tick;
    tick();
    return true;
  }

  function initStudioWelcomeClock() {
    if (!document.body || !document.body.classList.contains('yooadmin-theme-yooadmin-studio-hub')) {
      return;
    }
    var roots = document.querySelectorAll('.yp-studio-welcome-mock__datetime-inner[datetime]');
    if (!roots.length) {
      return;
    }
    for (var r = 0; r < roots.length; r++) {
      bindOneWelcomeClock(roots[r]);
    }
    if (__yshWelcomeClockTimer) {
      clearInterval(__yshWelcomeClockTimer);
    }
    __yshWelcomeClockTimer = setInterval(function () {
      var all = document.querySelectorAll('.yp-studio-welcome-mock__datetime-inner[datetime]');
      for (var i = 0; i < all.length; i++) {
        var root = all[i];
        if (!root.__yshClockBound) {
          bindOneWelcomeClock(root);
        }
        if (typeof root.__yshClockTick === 'function') {
          root.__yshClockTick();
        }
      }
    }, 1000);
  }

  /**
   * YOOMedia preview: fixed + backdrop-filter must cover the full viewport (incl. YOO header).
   * Inside #wpbody-content / .wrap, Studio Hub column + overflow:hidden clips the overlay.
   */
  var YSH_MEDIA_LIGHTBOX_IDS = [
    'yp-popup',
    'yoo-media-preview-modal',
    'yoo-image-lightbox',
    'yoo-media-dialog-delete',
    'yoo-media-dialog-alert',
    'yoo-media-dialog-confirm',
    'yp-notification-modal'
  ];

  function portalMediaLightboxesToBody() {
    if (!isStudioHubTheme() || !document.body) {
      return;
    }
    for (var i = 0; i < YSH_MEDIA_LIGHTBOX_IDS.length; i++) {
      var el = document.getElementById(YSH_MEDIA_LIGHTBOX_IDS[i]);
      if (!el || el.parentNode === document.body) {
        continue;
      }
      document.body.appendChild(el);
      if (el.id === 'yp-notification-modal') {
        el.classList.add('ysh-notification-modal--portaled');
      } else if (el.id === 'yp-popup') {
        el.classList.add('yp-popup--portaled');
      } else {
        el.classList.add('ysh-media-lightbox--portaled');
      }
    }
  }

  function initMediaLightboxPortal() {
    portalMediaLightboxesToBody();
    if (!isStudioHubTheme()) {
      return;
    }
    if (typeof MutationObserver === 'undefined') {
      return;
    }
    var wpbody = document.getElementById('wpbody-content');
    if (!wpbody || wpbody.__yshMediaLightboxMO) {
      return;
    }
    var mo = new MutationObserver(function () {
      portalMediaLightboxesToBody();
    });
    mo.observe(wpbody, { childList: true, subtree: true });
    wpbody.__yshMediaLightboxMO = true;
  }

  /**
   * wc-admin: sticky Woo bar must clear #yoo-admin-header + .yp-breadcrumbs-bar (siblings in wrapper).
   * yoo-spa-guard sets --yp-admin-header-h from #yoo-admin-header only; measure breadcrumbs here.
   */
  var YSH_MARKETPLACE_CHROME_SEL = [
    '.woocommerce-marketplace__header-container',
    '.woocommerce-marketplace__header',
    '.woocommerce-marketplace__content',
    '.woocommerce-marketplace__product-list',
    '.woocommerce-marketplace__extension-card',
    '.woocommerce-marketplace__product-card.components-card',
    '.woocommerce-marketplace__product-card__details',
    '.woocommerce-marketplace__product-card__content',
    '.woocommerce-marketplace__product-card--theme .components-card__body',
    '.woocommerce-marketplace__banner',
    '.woocommerce-marketplace__footer',
  ];

  var YSH_MARKETPLACE_SYNC_DELAYS = [0, 50, 150, 400, 800, 1500, 2500];

  var YSH_WC_ROUTE_CLASSES = [
    'ysh-wc-admin-is-home',
    'ysh-wc-admin-is-analytics',
    'ysh-wc-admin-is-extensions',
  ];

  var YSH_ANALYTICS_CHROME_SEL = [
    '.woocommerce-dashboard__store-performance .woocommerce-summary',
    '.woocommerce-dashboard__store-performance .woocommerce-summary__item',
    '.woocommerce-stats-overview__stats .woocommerce-summary',
    '.woocommerce-stats-overview__stats .woocommerce-summary__item',
    '.woocommerce-summary__item',
    '.woocommerce-leaderboard',
    '.woocommerce-leaderboard > div',
    '.woocommerce-leaderboard.components-card',
    '.woocommerce-leaderboard .components-card__body',
    '.woocommerce-leaderboard .components-card__header',
    '.woocommerce-leaderboard .woocommerce-table.is-empty',
    '.woocommerce-leaderboard .woocommerce-card',
    '.woocommerce-leaderboard .woocommerce-card__body',
    '.woocommerce-leaderboard .woocommerce-card__header',
    '.woocommerce-dashboard__dashboard-leaderboards .components-card',
    '.woocommerce-dashboard__dashboard-leaderboards .components-card__body',
    '.woocommerce-dashboard__dashboard-leaderboards .components-card__header',
    '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card',
    '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card__body',
    '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card__header',
    '.woocommerce-leaderboard.woocommerce-empty-content',
    '.woocommerce-empty-content',
    '.woocommerce-chart',
    '.woocommerce-chart .woocommerce-chart__header',
  ];

  var YSH_ANALYTICS_SYNC_DELAYS = [0, 50, 150, 400, 800, 1500, 2500, 4000];

  function getWcAdminPath() {
    try {
      var params = new URLSearchParams(window.location.search);
      var path = params.get('path') || '';
      return path.replace(/^\/+|\/+$/g, '');
    } catch (e) {
      return '';
    }
  }

  function isWcAdminAnalyticsRoute() {
    var path = getWcAdminPath();
    return path === 'analytics' || path.indexOf('analytics/') === 0;
  }

  function isWcAdminReportsShell() {
    var path = getWcAdminPath();
    return (
      path === 'analytics' ||
      path.indexOf('analytics/') === 0 ||
      path === 'customers'
    );
  }

  function syncWcAdminRouteBodyClass() {
    if (!document.body || !document.body.classList.contains('woocommerce_page_wc-admin')) {
      return;
    }

    var path = getWcAdminPath();
    document.documentElement.setAttribute('data-ysh-wc-path', path);

    var i;
    for (i = 0; i < YSH_WC_ROUTE_CLASSES.length; i++) {
      document.body.classList.remove(YSH_WC_ROUTE_CLASSES[i]);
    }

    if (path === '') {
      document.body.classList.add('ysh-wc-admin-is-home');
    } else if (isWcAdminReportsShell()) {
      document.body.classList.add('ysh-wc-admin-is-analytics');
    } else if (path === 'extensions' || path.indexOf('extensions/') === 0) {
      document.body.classList.add('ysh-wc-admin-is-extensions');
    }
  }

  function updateWooTableHorizontalNavState(table, prev, next) {
    if (!table || !prev || !next) {
      return;
    }
    var maxScroll = table.scrollWidth - table.clientWidth;
    if (maxScroll <= 2) {
      prev.style.display = 'none';
      next.style.display = 'none';
      table.classList.remove('ysh-wc-table-scroll-padded');
      return;
    }
    prev.style.display = '';
    next.style.display = '';
    table.classList.add('ysh-wc-table-scroll-padded');
    prev.disabled = table.scrollLeft <= 2;
    next.disabled = table.scrollLeft >= maxScroll - 2;
  }

  function scrollWooTableHorizontal(table, direction) {
    if (!table) {
      return;
    }
    var amount = Math.max(160, Math.round(table.clientWidth * 0.72));
    table.scrollBy({ left: direction * amount, behavior: 'smooth' });
  }

  function ensureWooTableHorizontalNav() {
    if (!document.body || !document.body.classList.contains('woocommerce_page_wc-admin')) {
      return;
    }
    if (!document.body.classList.contains('ysh-wc-admin-is-analytics')) {
      return;
    }

    var tables = document.querySelectorAll('.woocommerce-table__table');
    var t;
    for (t = 0; t < tables.length; t++) {
      var table = tables[t];
      if (table.closest('.woocommerce-marketplace__my-subscriptions')) {
        continue;
      }

      var host = table.closest('.components-card__body') || table.parentElement;
      if (!host) {
        continue;
      }

      host.classList.add('ysh-wc-table-scroll-host');

      var prev = host.querySelector('.ysh-wc-table-nav--prev');
      var next = host.querySelector('.ysh-wc-table-nav--next');

      if (!prev) {
        prev = document.createElement('button');
        prev.type = 'button';
        prev.className = 'ysh-wc-table-nav ysh-wc-table-nav--prev';
        prev.setAttribute('aria-label', 'Scroll table left');
        prev.innerHTML = '&#8249;';
        host.insertBefore(prev, table);
      }

      if (!next) {
        next = document.createElement('button');
        next.type = 'button';
        next.className = 'ysh-wc-table-nav ysh-wc-table-nav--next';
        next.setAttribute('aria-label', 'Scroll table right');
        next.innerHTML = '&#8250;';
        host.appendChild(next);
      }

      if (!host.dataset.yshTableNavBound) {
        host.dataset.yshTableNavBound = '1';
        prev.addEventListener('click', function () {
          scrollWooTableHorizontal(table, -1);
        });
        next.addEventListener('click', function () {
          scrollWooTableHorizontal(table, 1);
        });
        table.addEventListener(
          'scroll',
          function () {
            updateWooTableHorizontalNavState(table, prev, next);
          },
          { passive: true }
        );
        if (typeof ResizeObserver !== 'undefined') {
          var ro = new ResizeObserver(function () {
            updateWooTableHorizontalNavState(table, prev, next);
          });
          ro.observe(table);
          table.__yshTableNavRO = ro;
        } else {
          window.addEventListener('resize', function () {
            updateWooTableHorizontalNavState(table, prev, next);
          });
        }
      }

      updateWooTableHorizontalNavState(table, prev, next);
    }
  }

  function syncWooReportsFilterSelects() {
    var dark =
      document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') ===
      'dark';
    var sel =
      '.woocommerce-filters .components-select-control__input,' +
      '.woocommerce-filters .components-input-control__input,' +
      '.woocommerce-filters .components-input-control__container,' +
      '.woocommerce-filters .components-base-control__field,' +
      '.woocommerce-table .woocommerce-search .components-input-control__input,' +
      '.woocommerce-table .woocommerce-search .components-input-control__container';
    var nodes = document.querySelectorAll(sel);
    var i;
    for (i = 0; i < nodes.length; i++) {
      nodes[i].style.removeProperty('background');
      nodes[i].style.removeProperty('background-color');
      nodes[i].style.removeProperty('color');
      nodes[i].style.removeProperty('-webkit-text-fill-color');
      nodes[i].style.removeProperty('box-shadow');
      if (dark) {
        nodes[i].style.setProperty('background-color', '#22262e', 'important');
        nodes[i].style.setProperty('color', '#cfd6e0', 'important');
        nodes[i].style.setProperty('border-color', 'rgba(255,255,255,0.14)', 'important');
      }
    }
  }

  function syncWooReportsChrome() {
    ensureWooOverridesCascadeTail();
    ensureWooTableHorizontalNav();
    syncWooReportsFilterSelects();
  }

  function isDarkStudioMode() {
    return (
      document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') ===
      'dark'
    );
  }

  function syncWooAnalyticsSummaryText() {
    if (!isDarkStudioMode()) {
      return;
    }

    var labelSel =
      '.woocommerce-dashboard__store-performance .woocommerce-summary__item-label,' +
      '.woocommerce-stats-overview__stats .woocommerce-summary__item-label,' +
      '.woocommerce-summary__item-label';
    var valueSel =
      '.woocommerce-dashboard__store-performance .woocommerce-summary__item-value,' +
      '.woocommerce-stats-overview__stats .woocommerce-summary__item-value,' +
      '.woocommerce-summary__item-value';
    var prevSel =
      '.woocommerce-dashboard__store-performance .woocommerce-summary__item-prev-label,' +
      '.woocommerce-stats-overview__stats .woocommerce-summary__item-prev-label,' +
      '.woocommerce-summary__item-prev-label';
    var deltaSel =
      '.woocommerce-dashboard__store-performance .woocommerce-summary__item-delta,' +
      '.woocommerce-stats-overview__stats .woocommerce-summary__item-delta,' +
      '.woocommerce-summary__item-delta';

    document.querySelectorAll(labelSel).forEach(function (el) {
      el.style.removeProperty('color');
      el.style.removeProperty('-webkit-text-fill-color');
      el.style.setProperty('color', '#9aa5b1', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#9aa5b1', 'important');
    });
    document.querySelectorAll(valueSel).forEach(function (el) {
      el.style.removeProperty('color');
      el.style.removeProperty('-webkit-text-fill-color');
      el.style.setProperty('color', '#d8d3ce', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#d8d3ce', 'important');
    });
    document.querySelectorAll(prevSel).forEach(function (el) {
      el.style.removeProperty('color');
      el.style.removeProperty('-webkit-text-fill-color');
      el.style.setProperty('color', '#9aa5b1', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#9aa5b1', 'important');
    });
    document.querySelectorAll(deltaSel).forEach(function (el) {
      el.style.removeProperty('color');
      el.style.removeProperty('-webkit-text-fill-color');
      el.style.setProperty('color', '#cfd6e0', 'important');
      el.style.setProperty('-webkit-text-fill-color', '#cfd6e0', 'important');
    });

    document
      .querySelectorAll(
        '.woocommerce-dashboard__store-performance .woocommerce-summary__item .components-text,' +
          '.woocommerce-stats-overview__stats .woocommerce-summary__item .components-text,' +
          '.woocommerce-summary__item .components-text'
      )
      .forEach(function (el) {
        if (el.closest('.woocommerce-summary__item-delta')) {
          return;
        }
        el.style.removeProperty('color');
        el.style.removeProperty('-webkit-text-fill-color');
        if (el.closest('.woocommerce-summary__item-label, .woocommerce-summary__item-prev-label')) {
          el.style.setProperty('color', '#9aa5b1', 'important');
          el.style.setProperty('-webkit-text-fill-color', '#9aa5b1', 'important');
        } else if (el.closest('.woocommerce-summary__item-value')) {
          el.style.setProperty('color', '#d8d3ce', 'important');
          el.style.setProperty('-webkit-text-fill-color', '#d8d3ce', 'important');
        } else {
          el.style.setProperty('color', '#cfd6e0', 'important');
          el.style.setProperty('-webkit-text-fill-color', '#cfd6e0', 'important');
        }
      });
  }

  function syncWooAnalyticsLeaderboardSurfaces() {
    if (!isDarkStudioMode()) {
      return;
    }

    var surfaceSel =
      '.woocommerce-leaderboard,' +
      '.woocommerce-leaderboard > div,' +
      '.woocommerce-leaderboard.components-card,' +
      '.woocommerce-leaderboard .components-card__header,' +
      '.woocommerce-leaderboard .components-card__body,' +
      '.woocommerce-leaderboard .woocommerce-table.is-empty,' +
      '.woocommerce-leaderboard .woocommerce-card,' +
      '.woocommerce-leaderboard .woocommerce-card__header,' +
      '.woocommerce-leaderboard .woocommerce-card__body,' +
      '.woocommerce-leaderboard.woocommerce-empty-content,' +
      '.woocommerce-dashboard__dashboard-leaderboards .components-card,' +
      '.woocommerce-dashboard__dashboard-leaderboards .components-card__header,' +
      '.woocommerce-dashboard__dashboard-leaderboards .components-card__body,' +
      '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card,' +
      '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card__header,' +
      '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card__body,' +
      '.woocommerce-stats-overview__leaderboards .components-card,' +
      '.woocommerce-stats-overview__leaderboards .components-card__header,' +
      '.woocommerce-stats-overview__leaderboards .components-card__body,' +
      '.woocommerce-stats-overview__leaderboards .woocommerce-card,' +
      '.woocommerce-stats-overview__leaderboards .woocommerce-card__header,' +
      '.woocommerce-stats-overview__leaderboards .woocommerce-card__body';

    document.querySelectorAll(surfaceSel).forEach(function (el) {
      el.style.removeProperty('background');
      el.style.removeProperty('background-color');
      el.style.setProperty('background', '#1a1d23', 'important');
      el.style.setProperty('background-color', '#1a1d23', 'important');
      el.style.setProperty('border-color', 'rgba(255, 255, 255, 0.1)', 'important');
    });

  }

  function applyWooAnalyticsLeaderboardTextColor(el, color) {
    el.style.removeProperty('color');
    el.style.removeProperty('-webkit-text-fill-color');
    el.style.setProperty('color', color, 'important');
    el.style.setProperty('-webkit-text-fill-color', color, 'important');
  }

  function syncWooAnalyticsLeaderboardText() {
    if (!isWcAdminAnalyticsRoute()) {
      return;
    }
    if (document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') !== 'dark') {
      return;
    }

    var headingSel =
      '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-leaderboard :is(h2, h3),' +
      '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-section-header__title,' +
      '.woocommerce-stats-overview__leaderboards .woocommerce-section-header__title,' +
      '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-dashboard-section__title,' +
      '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-ellipsis-menu__title,' +
      '.woocommerce-stats-overview__leaderboards .woocommerce-dashboard-section__title,' +
      '.woocommerce-leaderboard .woocommerce-card__title,' +
      '.woocommerce-leaderboard .woocommerce-card__header :is(h2, h3, .components-text),' +
      '.woocommerce-leaderboard .components-card__header :is(h2, h3, .components-text),' +
      '.woocommerce-leaderboard.woocommerce-table .components-card__header :is(h2, h3, .components-text),' +
      '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-card__title,' +
      '.woocommerce-dashboard__dashboard-leaderboards .components-card__header :is(h2, h3, .components-text)';

    var mutedSel =
      '.woocommerce-leaderboard .woocommerce-table.is-empty,' +
      '.woocommerce-leaderboard .woocommerce-empty-content__message,' +
      '.woocommerce-leaderboard .woocommerce-table__empty-table,' +
      '.woocommerce-leaderboard .woocommerce-table__empty-item,' +
      '.woocommerce-dashboard__dashboard-leaderboards .woocommerce-empty-content__message,' +
      '.woocommerce-empty-content__message,' +
      '.woocommerce-leaderboard .woocommerce-table__head th,' +
      '.woocommerce-leaderboard .woocommerce-table__cell,' +
      '.woocommerce-leaderboard .woocommerce-table__cell a,' +
      '.woocommerce-leaderboard .woocommerce-table__cell .woocommerce-table__cell-content';

    document.querySelectorAll(headingSel).forEach(function (el) {
      applyWooAnalyticsLeaderboardTextColor(el, '#d8d3ce');
    });

    document.querySelectorAll(mutedSel).forEach(function (el) {
      applyWooAnalyticsLeaderboardTextColor(el, '#9aa5b1');
    });
  }

  function syncWooAnalyticsChrome() {
    if (!document.body || !document.body.classList.contains('woocommerce_page_wc-admin')) {
      return;
    }
    if (!isStudioHubTheme() || !document.body.classList.contains('yoo-focus')) {
      return;
    }
    syncWcAdminRouteBodyClass();
    if (!isWcAdminReportsShell()) {
      return;
    }

    syncWooReportsChrome();

    if (!isWcAdminAnalyticsRoute()) {
      return;
    }
    if (!YSH_ANALYTICS_CHROME_SEL || !YSH_ANALYTICS_CHROME_SEL.length) {
      return;
    }

    ensureWooOverridesCascadeTail();

    var i;
    for (i = 0; i < YSH_ANALYTICS_CHROME_SEL.length; i++) {
      var nodes = document.querySelectorAll(YSH_ANALYTICS_CHROME_SEL[i]);
      var n;
      for (n = 0; n < nodes.length; n++) {
        nodes[n].style.removeProperty('background');
        nodes[n].style.removeProperty('background-color');
      }
    }

    syncWooAnalyticsSummaryText();
    syncWooAnalyticsLeaderboardSurfaces();
    syncWooAnalyticsLeaderboardText();

    var selectSel =
      '.woocommerce-chart .components-select-control__input,' +
      '.woocommerce-chart .components-input-control__container,' +
      '.woocommerce-chart .components-input-control__input,' +
      '.woocommerce-chart .components-base-control__field';
    var selectNodes = document.querySelectorAll(selectSel);
    for (i = 0; i < selectNodes.length; i++) {
      selectNodes[i].style.removeProperty('background');
      selectNodes[i].style.removeProperty('background-color');
      selectNodes[i].style.removeProperty('color');
      selectNodes[i].style.removeProperty('-webkit-text-fill-color');
      selectNodes[i].style.removeProperty('box-shadow');
    }
  }

  function scheduleWooAnalyticsChromeSync() {
    if (!document.body || !document.body.classList.contains('woocommerce_page_wc-admin')) {
      return;
    }
    for (var d = 0; d < YSH_ANALYTICS_SYNC_DELAYS.length; d++) {
      (function (ms) {
        setTimeout(syncWooAnalyticsChrome, ms);
      })(YSH_ANALYTICS_SYNC_DELAYS[d]);
    }
  }

  function onWcAdminRouteChange() {
    syncWcAdminRouteBodyClass();
    ensureWooOverridesCascadeTail();
    syncWooMarketplaceChrome();
    scheduleWooAnalyticsChromeSync();
  }

  function initWcAdminRouteSync() {
    if (!isStudioHubTheme()) {
      return;
    }
    syncWcAdminRouteBodyClass();
    if (initWcAdminRouteSync.bound) {
      return;
    }
    initWcAdminRouteSync.bound = true;

    window.addEventListener('popstate', onWcAdminRouteChange);
    window.addEventListener('locationchange', onWcAdminRouteChange);
    document.addEventListener('ysh-studio-color-mode-changed', syncWooAnalyticsChrome);
    scheduleWooAnalyticsChromeSync();

    var content = document.querySelector('.woocommerce-layout__content');
    if (content && typeof MutationObserver !== 'undefined' && !content.__yshAnalyticsMO) {
      var analyticsMo = new MutationObserver(function () {
        if (isWcAdminReportsShell()) {
          scheduleWooAnalyticsChromeSync();
        }
      });
      analyticsMo.observe(content, { childList: true, subtree: true });
      content.__yshAnalyticsMO = true;
    }
  }

  window.yshSyncWooAnalyticsChrome = syncWooAnalyticsChrome;

  function syncWooMarketplaceNotices() {
    var nodes = document.querySelectorAll(
      '.woocommerce-marketplace__connect-notice, .woocommerce-marketplace__connect-notice .woocommerce-marketplace__notice, .woocommerce-marketplace__connect-notice .woocommerce-marketplace__notice-description, .woocommerce-marketplace__connect-notice .woocommerce-marketplace__notice-children, .woocommerce-marketplace__connect-notice .components-text, .woocommerce-marketplace__connect-notice span'
    );
    var i;
    for (i = 0; i < nodes.length; i++) {
      nodes[i].style.removeProperty('background');
      nodes[i].style.removeProperty('background-color');
      nodes[i].style.removeProperty('color');
      nodes[i].style.removeProperty('-webkit-text-fill-color');
    }
  }

  function isPluginsExtensionsPage() {
    try {
      var params = new URLSearchParams(window.location.search);
      var page = params.get('page') || '';
      return page === 'yooadmin-plugins' || page === 'yooadmin-extensions';
    } catch (e) {
      return false;
    }
  }

  function ensurePluginsExtDarkCascadeTail() {
    if (!isPluginsExtensionsPage()) {
      return;
    }
    var base =
      document.getElementById('yooadmin-studio-hub-plugins-ext-dark-css') ||
      document.getElementById('yooadmin-studio-hub-plugins-ext-cascade-tail');
    if (!base || !base.href) {
      return;
    }
    var tail = document.getElementById('yooadmin-studio-hub-plugins-ext-cascade-tail');
    var sheets = document.head.querySelectorAll('link[rel="stylesheet"]');
    if (tail && sheets.length && sheets[sheets.length - 1] === tail) {
      return;
    }
    if (!tail) {
      tail = document.createElement('link');
      tail.id = 'yooadmin-studio-hub-plugins-ext-cascade-tail';
      tail.rel = 'stylesheet';
      tail.href = base.href;
    }
    document.head.appendChild(tail);
  }

  function syncPluginsExtensionsDarkChrome() {
    if (!isPluginsExtensionsPage() || syncPluginsExtensionsDarkChrome.running) {
      return;
    }
    syncPluginsExtensionsDarkChrome.running = true;
    try {
      var dark =
        document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') === 'dark';
      if (!dark) {
        return;
      }

      var selects = document.querySelectorAll(
        'select#yoo-status-filter, select#yp-extensions-filter, select.yp-store-filter, select.yoo-status-filter'
      );
      var i;
      for (i = 0; i < selects.length; i++) {
        selects[i].style.removeProperty('background');
        selects[i].style.removeProperty('background-color');
        selects[i].style.removeProperty('background-image');
        selects[i].style.removeProperty('color');
        selects[i].style.removeProperty('border');
        selects[i].style.removeProperty('border-color');
      }

      var buttons = document.querySelectorAll(
        '.yp-ext-actions .button-activate, .yp-ext-actions .button-danger, .yp-ext-actions .button-secondary, .yp-ext-popup-footer .button, #yooadmin-extensions-refresh'
      );
      for (i = 0; i < buttons.length; i++) {
        buttons[i].style.removeProperty('background');
        buttons[i].style.removeProperty('background-color');
        buttons[i].style.removeProperty('color');
        buttons[i].style.removeProperty('border-color');
      }
    } finally {
      syncPluginsExtensionsDarkChrome.running = false;
    }
  }

  function schedulePluginsExtensionsDarkChromeSync() {
    if (!isPluginsExtensionsPage()) {
      return;
    }
    syncPluginsExtensionsDarkChrome();
    var delays = [0, 50, 150, 400, 800, 1500, 2500];
    for (var d = 0; d < delays.length; d++) {
      (function (ms) {
        setTimeout(syncPluginsExtensionsDarkChrome, ms);
      })(delays[d]);
    }
    if (!schedulePluginsExtensionsDarkChromeSync.loadBound) {
      schedulePluginsExtensionsDarkChromeSync.loadBound = true;
      window.addEventListener('load', syncPluginsExtensionsDarkChrome);
    }
  }

  function syncWooMarketplaceCategories() {
    var nodes = document.querySelectorAll(
      '.woocommerce-marketplace__category-item-button, .woocommerce-marketplace__category-dropdown-button, .woocommerce-marketplace__category-dropdown-item-button, .woocommerce-marketplace__category-navigation-button'
    );
    var icons = document.querySelectorAll(
      '.woocommerce-marketplace__category-dropdown-button .components-icon, .woocommerce-marketplace__category-dropdown-button svg, .woocommerce-marketplace__category-dropdown-button svg path'
    );
    var dark =
      document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') ===
      'dark';
    var i;
    for (i = 0; i < nodes.length; i++) {
      nodes[i].style.removeProperty('background');
      nodes[i].style.removeProperty('background-color');
      nodes[i].style.removeProperty('color');
      nodes[i].style.removeProperty('-webkit-text-fill-color');
    }
    for (i = 0; i < icons.length; i++) {
      icons[i].style.removeProperty('fill');
      icons[i].style.removeProperty('color');
      icons[i].style.removeProperty('stroke');
      if (dark) {
        icons[i].style.setProperty('fill', 'currentColor', 'important');
        icons[i].style.setProperty('color', '#cfd6e0', 'important');
      }
    }
  }

  function syncWooMarketplaceMySubscriptions() {
    var nodes = document.querySelectorAll(
      '.woocommerce-marketplace__my-subscriptions__account, .woocommerce-marketplace__my-subscriptions__account-header, .woocommerce-marketplace__my-subscriptions__account-content, .woocommerce-marketplace__my-subscriptions__heading, .woocommerce-marketplace__my-subscriptions__table, .woocommerce-marketplace__my-subscriptions .woocommerce-table__header, .woocommerce-marketplace__my-subscriptions .woocommerce-table__item, .woocommerce-marketplace__my-subscriptions .woocommerce-table__item span, .woocommerce-marketplace__my-subscriptions .woocommerce-table__item .components-text'
    );
    var i;
    for (i = 0; i < nodes.length; i++) {
      nodes[i].style.removeProperty('background');
      nodes[i].style.removeProperty('background-color');
      nodes[i].style.removeProperty('color');
      nodes[i].style.removeProperty('-webkit-text-fill-color');
    }
  }

  function syncWooMarketplaceHeaderText() {
    var header = document.querySelector('.woocommerce-marketplace__header');
    if (!header) {
      return;
    }
    var nodes = header.querySelectorAll(
      '.woocommerce-marketplace__header-title, .woocommerce-marketplace__tab-button, .woocommerce-marketplace__tab-button .components-text, .woocommerce-marketplace__tab-button span, .woocommerce-marketplace__tab-button a'
    );
    var i;
    for (i = 0; i < nodes.length; i++) {
      nodes[i].style.removeProperty('color');
      nodes[i].style.removeProperty('-webkit-text-fill-color');
    }
  }

  function syncWooMarketplaceSearch() {
    var search = document.querySelector('.woocommerce-marketplace__search');
    if (!search) {
      return;
    }
    var dark =
      document.documentElement.getAttribute('data-yooadmin-studio-color-mode-effective') ===
      'dark';
    var containers = search.querySelectorAll('.components-input-control__container');
    var inputs = search.querySelectorAll(
      '.components-input-control__input, .components-text-control__input, input[type="search"], input[type="text"]'
    );
    var i;
    for (i = 0; i < containers.length; i++) {
      containers[i].style.removeProperty('background');
      containers[i].style.removeProperty('background-color');
      containers[i].style.removeProperty('box-shadow');
    }
    for (i = 0; i < inputs.length; i++) {
      inputs[i].style.removeProperty('background');
      inputs[i].style.removeProperty('background-color');
      inputs[i].style.removeProperty('color');
      inputs[i].style.removeProperty('-webkit-text-fill-color');
      inputs[i].style.removeProperty('box-shadow');
      inputs[i].style.removeProperty('border');
      if (dark) {
        inputs[i].style.setProperty('color', '#cfd6e0', 'important');
        inputs[i].style.setProperty('-webkit-text-fill-color', '#cfd6e0', 'important');
      }
    }
  }

  var YSH_MARKETPLACE_TABS_NAV_MQ =
    typeof window.matchMedia === 'function'
      ? window.matchMedia('(max-width: 1024px)')
      : null;

  function isWooMarketplaceTabsCompact() {
    return YSH_MARKETPLACE_TABS_NAV_MQ ? YSH_MARKETPLACE_TABS_NAV_MQ.matches : false;
  }

  function updateWooMarketplaceMainTabsNavState(tabs, prev, next) {
    if (!tabs || !prev || !next) {
      return;
    }
    var maxScroll = tabs.scrollWidth - tabs.clientWidth;
    if (maxScroll <= 2) {
      prev.disabled = true;
      next.disabled = true;
      return;
    }
    prev.disabled = tabs.scrollLeft <= 2;
    next.disabled = tabs.scrollLeft >= maxScroll - 2;
  }

  function scrollWooMarketplaceMainTabs(tabs, direction) {
    if (!tabs) {
      return;
    }
    var amount = Math.max(120, Math.round(tabs.clientWidth * 0.72));
    tabs.scrollBy({ left: direction * amount, behavior: 'smooth' });
  }

  function scrollWooMarketplaceActiveTabIntoView(tabs) {
    if (!tabs) {
      return;
    }
    var active = tabs.querySelector('.woocommerce-marketplace__tab-button.is-active');
    if (!active || typeof active.scrollIntoView !== 'function') {
      return;
    }
    active.scrollIntoView({ inline: 'nearest', block: 'nearest', behavior: 'smooth' });
  }

  function ensureWooMarketplaceMainTabsNav() {
    var tabs = document.querySelector('.woocommerce-marketplace__tabs');
    if (!tabs) {
      return;
    }

    var host = document.querySelector('.woocommerce-marketplace__header-tabs') || tabs.parentElement;
    if (!host) {
      return;
    }

    var prev = host.querySelector('.ysh-marketplace-tabs-nav--prev');
    var next = host.querySelector('.ysh-marketplace-tabs-nav--next');
    var compact = isWooMarketplaceTabsCompact();

    if (!prev) {
      prev = document.createElement('button');
      prev.type = 'button';
      prev.className = 'ysh-marketplace-tabs-nav ysh-marketplace-tabs-nav--prev';
      prev.setAttribute('aria-label', 'Previous tabs');
      prev.innerHTML = '&#8249;';
      host.insertBefore(prev, tabs);
    }

    if (!next) {
      next = document.createElement('button');
      next.type = 'button';
      next.className = 'ysh-marketplace-tabs-nav ysh-marketplace-tabs-nav--next';
      next.setAttribute('aria-label', 'Next tabs');
      next.innerHTML = '&#8250;';
      host.appendChild(next);
    }

    if (!compact) {
      prev.style.display = 'none';
      next.style.display = 'none';
      tabs.style.removeProperty('overflow-x');
      tabs.style.removeProperty('overflow-y');
      tabs.style.removeProperty('max-width');
      return;
    }

    prev.style.display = '';
    next.style.display = '';
    tabs.style.setProperty('overflow-x', 'auto', 'important');
    tabs.style.setProperty('overflow-y', 'hidden', 'important');
    tabs.style.setProperty('max-width', '100%', 'important');

    if (!host.dataset.yshMpTabsNavBound) {
      host.dataset.yshMpTabsNavBound = '1';
      prev.addEventListener('click', function () {
        scrollWooMarketplaceMainTabs(tabs, -1);
      });
      next.addEventListener('click', function () {
        scrollWooMarketplaceMainTabs(tabs, 1);
      });
      tabs.addEventListener(
        'scroll',
        function () {
          updateWooMarketplaceMainTabsNavState(tabs, prev, next);
        },
        { passive: true }
      );
      if (YSH_MARKETPLACE_TABS_NAV_MQ && typeof YSH_MARKETPLACE_TABS_NAV_MQ.addEventListener === 'function') {
        YSH_MARKETPLACE_TABS_NAV_MQ.addEventListener('change', function () {
          ensureWooMarketplaceMainTabsNav();
        });
      } else {
        window.addEventListener('resize', function () {
          ensureWooMarketplaceMainTabsNav();
        });
      }
    }

    function refreshNav() {
      updateWooMarketplaceMainTabsNavState(tabs, prev, next);
      scrollWooMarketplaceActiveTabIntoView(tabs);
    }

    refreshNav();
    if (typeof window.requestAnimationFrame === 'function') {
      window.requestAnimationFrame(refreshNav);
    }
    setTimeout(refreshNav, 120);
  }

  function syncWooMarketplaceChrome() {
    if (!document.body || !document.body.classList.contains('woocommerce_page_wc-admin')) {
      return;
    }
    if (!isStudioHubTheme() || !document.body.classList.contains('yoo-focus')) {
      return;
    }
    if (!document.querySelector('.woocommerce-marketplace')) {
      return;
    }
    if (!YSH_MARKETPLACE_CHROME_SEL || !YSH_MARKETPLACE_CHROME_SEL.length) {
      return;
    }

    ensureWooOverridesCascadeTail();

    for (var i = 0; i < YSH_MARKETPLACE_CHROME_SEL.length; i++) {
      var nodes = document.querySelectorAll(YSH_MARKETPLACE_CHROME_SEL[i]);
      for (var n = 0; n < nodes.length; n++) {
        nodes[n].style.removeProperty('background');
        nodes[n].style.removeProperty('background-color');
      }
    }

    syncWooMarketplaceSearch();
    syncWooMarketplaceHeaderText();
    syncWooMarketplaceNotices();
    syncWooMarketplaceMySubscriptions();
    syncWooMarketplaceCategories();
    ensureWooMarketplaceMainTabsNav();
  }

  function scheduleWooMarketplaceChromeSync() {
    if (!document.body || !document.body.classList.contains('woocommerce_page_wc-admin')) {
      return;
    }
    for (var d = 0; d < YSH_MARKETPLACE_SYNC_DELAYS.length; d++) {
      (function (ms) {
        setTimeout(syncWooMarketplaceChrome, ms);
      })(YSH_MARKETPLACE_SYNC_DELAYS[d]);
    }
  }

  window.yshSyncWooMarketplaceChrome = syncWooMarketplaceChrome;

  function ensureWooOverridesCascadeTail() {
    if (
      !document.body ||
      (!document.body.classList.contains('woocommerce_page_wc-admin') &&
        !document.body.classList.contains('woocommerce_page_wc-settings'))
    ) {
      return;
    }
    if (!isStudioHubTheme()) {
      return;
    }
    var base =
      document.getElementById('yooadmin-studio-hub-woo') ||
      document.getElementById('yooadmin-studio-hub-woo-early');
    if (!base || !base.href) {
      return;
    }
    var tail = document.getElementById('yooadmin-studio-hub-woo-cascade-tail');
    var sheets = document.head.querySelectorAll('link[rel="stylesheet"]');
    if (tail && sheets.length && sheets[sheets.length - 1] === tail) {
      return;
    }
    if (!tail) {
      tail = document.createElement('link');
      tail.id = 'yooadmin-studio-hub-woo-cascade-tail';
      tail.rel = 'stylesheet';
      tail.href = base.href;
    }
    document.head.appendChild(tail);
  }

  function collapseEmptyWooJitm() {
    if (!document.body || !document.body.classList.contains('woocommerce_page_wc-admin')) {
      return;
    }
    if (!isStudioHubTheme()) {
      return;
    }
    var root =
      document.getElementById('jp-admin-notices') ||
      document.querySelector('.woocommerce-layout__jitm');
    if (!root) {
      return;
    }
    var hasJitm = root.querySelector(
      '.jitm-card, .jitm-banner, .jitm, [class*="jitm-"]'
    );
    var empty = !hasJitm && String(root.textContent || '').trim() === '';
    root.classList.toggle('ysh-jitm-empty', empty);
    if (empty) {
      root.setAttribute('hidden', 'hidden');
    } else {
      root.removeAttribute('hidden');
    }
  }

  function syncWooChromeOffsetVars() {
    if (!document.body || !document.body.classList.contains('woocommerce_page_wc-admin')) {
      return;
    }
    var root = document.documentElement;
    if (!root) {
      return;
    }
    if (typeof window.yooadminSyncSubsiteContextBarHeight === 'function') {
      window.yooadminSyncSubsiteContextBarHeight();
    }
    var wrapper = document.getElementById('yoo-admin-header-wrapper');
    var header = document.getElementById('yoo-admin-header');
    var bc = document.querySelector('.yp-breadcrumbs-bar');
    var chrome = document.querySelector('.yp-subsite-chrome');
    var headerPx = chrome && chrome.offsetHeight
      ? chrome.offsetHeight
      : (wrapper && wrapper.offsetHeight
        ? wrapper.offsetHeight
        : (header && header.offsetHeight ? header.offsetHeight : 64));
    var bcPx = bc && bc.offsetHeight ? bc.offsetHeight : 0;
    root.style.setProperty('--yp-admin-header-h', String(headerPx) + 'px');
    root.style.setProperty('--yp-breadcrumbs-h', String(bcPx) + 'px');
    root.style.setProperty('--yp-header-h', String(headerPx) + 'px');
    root.style.setProperty('--yp-bc-h', String(bcPx) + 'px');
    collapseEmptyWooJitm();
    syncWcAdminRouteBodyClass();
    ensureWooOverridesCascadeTail();
    syncWooMarketplaceChrome();
    syncWooAnalyticsChrome();
  }

  function initWooChromeOffsetVars() {
    if (!isStudioHubTheme()) {
      return;
    }
    syncWooChromeOffsetVars();
    if (initWooChromeOffsetVars.bound) {
      return;
    }
    initWooChromeOffsetVars.bound = true;
    window.addEventListener('resize', syncWooChromeOffsetVars);
    if (typeof MutationObserver === 'undefined') {
      return;
    }
    var wrapper = document.getElementById('yoo-admin-header-wrapper');
    if (!wrapper || wrapper.__yshWooChromeMO) {
      return;
    }
    var mo = new MutationObserver(syncWooChromeOffsetVars);
    mo.observe(wrapper, { childList: true, subtree: true, attributes: true });
    wrapper.__yshWooChromeMO = true;
    var jitm = document.getElementById('jp-admin-notices');
    if (jitm && !jitm.__yshJitmMO) {
      var jitmMo = new MutationObserver(collapseEmptyWooJitm);
      jitmMo.observe(jitm, { childList: true, subtree: true });
      jitm.__yshJitmMO = true;
    }
    var wpbody = document.getElementById('wpbody-content');
    if (wpbody && !wpbody.__yshJitmWatch) {
      var wpbodyMo = new MutationObserver(collapseEmptyWooJitm);
      wpbodyMo.observe(wpbody, { childList: true, subtree: true });
      wpbody.__yshJitmWatch = true;
    }
    if (!document.head.__yshWooCascadeMO) {
      var headMo = new MutationObserver(function () {
        ensureWooOverridesCascadeTail();
      });
      headMo.observe(document.head, { childList: true });
      document.head.__yshWooCascadeMO = true;
    }
    ensureWooOverridesCascadeTail();
    document.addEventListener('ysh-studio-color-mode-changed', syncWooMarketplaceChrome);
    scheduleWooMarketplaceChromeSync();
  }

  function initPluginsExtensionsDarkChrome() {
    if (!isPluginsExtensionsPage() || initPluginsExtensionsDarkChrome.bound) {
      return;
    }
    initPluginsExtensionsDarkChrome.bound = true;

    schedulePluginsExtensionsDarkChromeSync();
    document.addEventListener('ysh-studio-color-mode-changed', syncPluginsExtensionsDarkChrome);

    ensurePluginsExtDarkCascadeTail();
    if (typeof MutationObserver !== 'undefined' && document.head && !document.head.__yshPluginsExtCascadeMO) {
      var pluginsExtHeadMo = new MutationObserver(function () {
        ensurePluginsExtDarkCascadeTail();
      });
      pluginsExtHeadMo.observe(document.head, { childList: true });
      document.head.__yshPluginsExtCascadeMO = true;
    }

    var addonsRoot = document.getElementById('yooadmin-addons-root');
    if (addonsRoot && !addonsRoot.__yshPluginsExtMO) {
      var extMo = new MutationObserver(function () {
        syncPluginsExtensionsDarkChrome();
      });
      extMo.observe(addonsRoot, { childList: true, subtree: true });
      addonsRoot.__yshPluginsExtMO = true;
    }
    var wpResults = document.getElementById('wp-results');
    if (wpResults && !wpResults.__yshPluginsExtMO) {
      var pluginsMo = new MutationObserver(function () {
        syncPluginsExtensionsDarkChrome();
      });
      pluginsMo.observe(wpResults, { childList: true, subtree: true });
      wpResults.__yshPluginsExtMO = true;
    }
  }

  var YSH_WC_SETTINGS_LAYOUT_SKIP_TABS = {
    shipping: true,
    checkout: true,
    email: true,
    'site-visibility': true,
    'point-of-sale': true,
  };

  function getWcSettingsTabSlug() {
    try {
      var params = new URLSearchParams(window.location.search);
      return params.get('tab') || 'general';
    } catch (e) {
      return 'general';
    }
  }

  function shouldEnhanceWcSettingsClassicLayout() {
    if (!document.body || !isStudioHubTheme()) {
      return false;
    }
    if (!document.body.classList.contains('yoo-focus')) {
      return false;
    }
    if (!document.body.classList.contains('woocommerce_page_wc-settings')) {
      return false;
    }
    if (document.body.classList.contains('woocommerce-settings-payments-tab')) {
      return false;
    }
    return !YSH_WC_SETTINGS_LAYOUT_SKIP_TABS[getWcSettingsTabSlug()];
  }

  function shouldSkipWcSettingsLayoutNode(node) {
    if (!node || !node.matches) {
      return true;
    }
    if (
      node.matches(
        'nav.nav-tab-wrapper, ul.subsubsub, h1.screen-reader-text, .ysh-wc-settings-body, p.submit'
      )
    ) {
      return true;
    }
    if (node.matches('br.clear')) {
      return true;
    }
    if (node.matches('.notice:empty, .woocommerce-message:empty')) {
      return true;
    }
    return false;
  }

  function wcSettingsSectionHasContent(section) {
    if (!section || !section.children.length) {
      return false;
    }
    if (
      section.querySelector(
        '.form-table, table, h2, h3.wc-settings-sub-title, select, input:not([type="hidden"]), textarea, .button, .notice, .woocommerce-message, p.wc-settings-marketplace-link, img, [id$="_slotfill"], [id*="_slotfill"]'
      )
    ) {
      return true;
    }
    return String(section.textContent || '')
      .replace(/\s+/g, ' ')
      .trim().length > 0;
  }

  function enhanceWcSettingsClassicLayout() {
    if (typeof window.yshWcSettingsEnhanceLayout === 'function') {
      window.yshWcSettingsEnhanceLayout();
      return;
    }

    if (!shouldEnhanceWcSettingsClassicLayout()) {
      document.body.classList.remove('ysh-wc-settings-classic-layout');
      return;
    }

    var form = document.getElementById('mainform');
    if (!form) {
      return;
    }

    if (form.querySelector('.ysh-wc-settings-body')) {
      document.body.classList.add('ysh-wc-settings-classic-layout');
      return;
    }

    var contentNodes = [];
    for (var i = 0; i < form.children.length; i++) {
      var ch = form.children[i];
      if (!ch.matches) {
        continue;
      }
      if (shouldSkipWcSettingsLayoutNode(ch)) {
        continue;
      }
      contentNodes.push(ch);
    }

    if (!contentNodes.length) {
      return;
    }

    var body = document.createElement('div');
    body.className = 'ysh-wc-settings-body';

    var section = null;
    var misc = document.createElement('div');
    misc.className = 'ysh-wc-settings-section ysh-wc-settings-section--misc';

    for (var n = 0; n < contentNodes.length; n++) {
      var node = contentNodes[n];
      if (node.matches('h2, h3.wc-settings-sub-title')) {
        if (section) {
          body.appendChild(section);
        }
        section = document.createElement('div');
        section.className = 'ysh-wc-settings-section';
        section.appendChild(node);
      } else if (section) {
        section.appendChild(node);
      } else {
        misc.appendChild(node);
      }
    }

    if (section) {
      body.appendChild(section);
    }
    if (misc.children.length && wcSettingsSectionHasContent(misc)) {
      body.insertBefore(misc, body.firstChild);
    }

    if (!body.children.length) {
      return;
    }

    var wideSel =
      '.wp-list-table, table.wc-shipping-zones, #webhooks, .wc_webhooks, .wc-shipping-zone-methods, .wc-shipping-classes';
    var sections = body.querySelectorAll('.ysh-wc-settings-section');
    for (var s = 0; s < sections.length; s++) {
      if (sections[s].querySelector(wideSel)) {
        sections[s].classList.add('ysh-wc-settings-section--wide');
      }
    }

    var anchor = form.querySelector('ul.subsubsub') || form.querySelector('nav.nav-tab-wrapper');
    if (anchor) {
      anchor.parentNode.insertBefore(body, anchor.nextSibling);
    } else {
      form.insertBefore(body, form.firstChild);
    }

    document.body.classList.add('ysh-wc-settings-classic-layout');
    form.dataset.yshWcLayout = '1';
  }

  function initWcSettingsClassicLayout() {
    if (!isStudioHubTheme()) {
      return;
    }
    enhanceWcSettingsClassicLayout();
    if (document.body && document.body.classList.contains('woocommerce_page_wc-settings')) {
      ensureWooOverridesCascadeTail();
    }
    if (initWcSettingsClassicLayout.bound) {
      return;
    }
    initWcSettingsClassicLayout.bound = true;
    var form = document.getElementById('mainform');
    if (form && typeof MutationObserver !== 'undefined') {
      var mo = new MutationObserver(function () {
        if (form.dataset.yshWcLayout !== '1') {
          enhanceWcSettingsClassicLayout();
        }
      });
      mo.observe(form, { childList: true });
    }
  }

  function bootStudioHubClient() {
    initPopupEnhancements();
    initStudioWelcomeClock();
    initStudioAppearanceToggle();
    initMediaLightboxPortal();
    initWooChromeOffsetVars();
    initWcAdminRouteSync();
    initWcSettingsClassicLayout();
    initPluginsExtensionsDarkChrome();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootStudioHubClient);
  } else {
    bootStudioHubClient();
  }

  applyEffective();
})();
