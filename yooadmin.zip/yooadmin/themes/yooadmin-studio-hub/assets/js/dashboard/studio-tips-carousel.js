/**
 * Studio Hub — Tips carousel (one tip visible, per-slide dots, auto-rotate).
 */
(function () {
  'use strict';

  function parseMs(value, fallback) {
    var n = parseInt(value, 10);
    return n > 0 ? n : fallback;
  }

  function initCarousel(root) {
    if (!root || root.getAttribute('data-tips-bound') === '1') {
      return;
    }
    root.setAttribute('data-tips-bound', '1');

    var slides = Array.prototype.slice.call(root.querySelectorAll('.yp-studio-tip-slide'));
    if (!slides.length) {
      return;
    }

    var autoplayMs = parseMs(root.getAttribute('data-autoplay-ms'), 6500);
    var dots = Array.prototype.slice.call(root.querySelectorAll('.yp-studio-tip-dot'));
    var index = 0;
    var timer = null;
    var paused = false;

    function syncDots() {
      for (var d = 0; d < dots.length; d++) {
        var on = d === index;
        dots[d].classList.toggle('is-active', on);
        dots[d].setAttribute('aria-selected', on ? 'true' : 'false');
      }
    }

    function showSlide(nextIndex) {
      if (!slides.length) {
        return;
      }
      if (nextIndex < 0) {
        nextIndex = slides.length - 1;
      }
      if (nextIndex >= slides.length) {
        nextIndex = 0;
      }
      index = nextIndex;

      for (var s = 0; s < slides.length; s++) {
        var active = s === index;
        slides[s].classList.toggle('is-active', active);
        if (active) {
          slides[s].removeAttribute('hidden');
        } else {
          slides[s].setAttribute('hidden', 'hidden');
        }
      }
      syncDots();
    }

    function stopTimer() {
      if (timer) {
        clearInterval(timer);
        timer = null;
      }
    }

    function startTimer() {
      stopTimer();
      if (paused || slides.length < 2) {
        return;
      }
      timer = setInterval(function () {
        showSlide(index + 1);
      }, autoplayMs);
    }

    for (var i = 0; i < dots.length; i++) {
      (function (dot, slideIndex) {
        dot.addEventListener('click', function () {
          showSlide(slideIndex);
          startTimer();
        });
      })(dots[i], parseInt(dots[i].getAttribute('data-tip-index'), 10) || 0);
    }

    root.addEventListener('mouseenter', function () {
      paused = true;
      stopTimer();
    });
    root.addEventListener('mouseleave', function () {
      paused = false;
      startTimer();
    });
    root.addEventListener('focusin', function () {
      paused = true;
      stopTimer();
    });
    root.addEventListener('focusout', function (e) {
      if (!root.contains(e.relatedTarget)) {
        paused = false;
        startTimer();
      }
    });

    showSlide(0);
    startTimer();
  }

  function boot() {
    var nodes = document.querySelectorAll('[data-studio-tips-carousel="true"]');
    for (var i = 0; i < nodes.length; i++) {
      initCarousel(nodes[i]);
    }
  }

  window.yooadminStudioHubInitTipsCarousels = boot;
  document.addEventListener('yooadmin-studio-hub-widget-rendered', boot);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
