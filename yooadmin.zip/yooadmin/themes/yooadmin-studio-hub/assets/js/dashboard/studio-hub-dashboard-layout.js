/**
 * Studio Hub dashboard — layout edit (sections, cards, drop gaps).
 * Synced with .yp-icon-edit-mode (workspace Edit button).
 */
(function () {
  'use strict';

  if (window.__YOOStudioHubLayoutInit) {
    return;
  }
  window.__YOOStudioHubLayoutInit = true;

  var STORAGE_KEY = 'yooadmin_studio_hub_layout_v1';
  var LAYOUT_VERSION = 1;

  var root = document.querySelector('.yp-studio-hub--dashboard');
  if (!root) {
    return;
  }

  var layoutCfg = window.yooadminStudioHubLayout || {};
  var networkLayoutCfg = window.yooadminNetworkDashboardLayout || {};
  function isNetworkDashboard() {
    return !!(
      networkLayoutCfg.isNetworkDashboard ||
      (document.body && document.body.classList.contains('yp-network-dashboard-screen'))
    );
  }
  var layoutNonce = isNetworkDashboard()
    ? networkLayoutCfg.nonce ||
      (root.getAttribute('data-layout-nonce') || '')
    : layoutCfg.nonce || root.getAttribute('data-layout-nonce') || '';
  var widgetAjaxNonce =
    layoutCfg.nonce ||
    (isNetworkDashboard() ? '' : root.getAttribute('data-layout-nonce') || '');
  var layoutAjaxUrl =
    layoutCfg.ajaxUrl ||
    root.getAttribute('data-layout-ajax') ||
    window.ajaxurl ||
    '';
  var layoutRestUrl = layoutCfg.restUrl || '';
  var layoutRestNonce =
    layoutCfg.restNonce || (window.wpApiSettings && window.wpApiSettings.nonce) || '';
  var dashboardRedirectEnabled = !!layoutCfg.dashboardRedirectEnabled;
  var canManageSiteSettings = !!layoutCfg.canManageSiteSettings;
  var i18n = layoutCfg.i18n || {};
  function t(key, fallback) {
    return i18n[key] || fallback;
  }

  function resolveWidgetSectionTitle(widgetId, storedTitle) {
    if (widgetId === 'yooadmin_overview') {
      return t('yooadminOverview', 'YOOAdmin Overview');
    }
    if (widgetId === 'studio-login-security') {
      return t('loginSecurity', 'Login security');
    }
    if (storedTitle) {
      return storedTitle;
    }
    return t('addSectionCards', 'Dashboard card');
  }

  function syncLocalizedWidgetSectionTitles() {
    root.querySelectorAll('.yp-studio-widget-section[data-widget-id="yooadmin_overview"]').forEach(function (
      section
    ) {
      var title = resolveWidgetSectionTitle('yooadmin_overview', '');
      section.setAttribute('data-section-title', title);
      var label = section.querySelector('.yp-section-title-label');
      if (label) {
        label.textContent = title;
      }
      var input = section.querySelector('.yp-section-title-input');
      if (input) {
        input.value = title;
      }
    });
  }

  function setAsideSectionTitle(section, title) {
    if (!section || !title) {
      return;
    }
    section.setAttribute('data-section-title', title);
    var titleEl = section.querySelector('.yp-studio-aside-section__title, .yp-card-title.yp-section-title');
    if (!titleEl) {
      return;
    }
    var label = titleEl.querySelector(
      '.yp-studio-aside-section__title-label, .yp-studio-tips-section__title-text'
    );
    if (label) {
      label.textContent = title;
      return;
    }
    var icon = titleEl.querySelector('.dashicons');
    while (titleEl.firstChild) {
      titleEl.removeChild(titleEl.firstChild);
    }
    if (icon) {
      titleEl.appendChild(icon);
    }
    label = document.createElement('span');
    label.className = 'yp-studio-aside-section__title-label';
    label.textContent = title;
    titleEl.appendChild(label);
  }

  function syncLocalizedBuiltInSectionTitles() {
    var titleMap = {
      'studio-workspace-notes': t('workspaceNotes', 'Workspace Notes'),
      'studio-network-workspace-notes': t('workspaceNotes', 'Workspace Notes'),
      'studio-tips': t('tips', 'Tips'),
      'studio-network-tips': t('tips', 'Tips'),
      'studio-updates': t('updates', 'Updates'),
      'studio-activity': t('activity', 'Activity'),
    };
    Object.keys(titleMap).forEach(function (sectionId) {
      var section = root.querySelector('[data-section-id="' + sectionId + '"]');
      if (section) {
        setAsideSectionTitle(section, titleMap[sectionId]);
      }
    });
  }

  function syncLocalizedDashboardStrings() {
    syncLocalizedWidgetSectionTitles();
    syncLocalizedBuiltInSectionTitles();
  }

  var mainEl = root.querySelector('.yp-studio-hub__main');
  var asideEl = root.querySelector('.yp-studio-hub__aside');
  var layoutEl = root.querySelector('.yp-studio-hub__layout');
  var topSectionEl = root.querySelector('[data-yooadmin-top-section="true"]');
  if (!mainEl || !asideEl) {
    return;
  }

  var LOCKED_SECTION_IDS = {};
  var DEFAULT_OVERVIEW_WIDGET_SECTION_ID = 'widget-aside-yooadmin-overview';
  var DEFAULT_ASIDE_ORDER = [
    'studio-workspace-notes',
    'studio-updates',
    'studio-tips',
    'studio-activity',
  ];
  var DEFAULT_NETWORK_ASIDE_ORDER = ['network-overview', 'network-workspace-notes', 'network-tips'];
  var DEFAULT_HIDDEN_SECTIONS = [];
  var DEFAULT_REMOVED_BUILTIN_SECTIONS = isNetworkDashboard() ? [] : ['studio-activity'];
  var BUILTIN_CARD_IDS = isNetworkDashboard()
    ? {
        'studio-network-workspace-notes': true,
        'studio-network-tips': true,
      }
    : {
        'studio-workspace-notes': true,
        'studio-activity': true,
        'studio-tips': true,
        'studio-updates': true,
        'from-extensions': true,
      };

  /** Workspace cards that cannot be hidden (card-id keys from main-{slug}). */
  var LOCKED_HIDE_CARD_IDS = {
    'main-index.php': true,
    'main-yooadmin-dashboard': true,
  };

  /** Your workspace must always keep at least this many items (any cards — free reorder inside the section). */
  var WORKSPACE_MIN_ITEMS = 3;
  var WORKSPACE_MAIN_SECTION_ID = 'your-workspace';
  var NETWORK_WORKSPACE_MAIN_SECTION_ID = 'network-workspace';
  var NETWORK_MAIN_COLUMN_LOCKED_IDS = {
    'network-workspace': true,
    'network-sites': true,
  };

  var layoutEditOn = false;
  var draggingCard = null;
  var draggingSection = null;
  var dropSlot = null;
  var mainAddBtn = null;
  var asideAddBtn = null;
  var customSectionSeq = 0;
  var widgetSectionSeq = 0;
  var addSectionModalEl = null;
  var widgetCatalogCache = null;
  var pendingWidgetMeta = null;
  var refreshCatalogListCallback = null;
  var saveTimer = null;
  var dragRaf = 0;
  var pendingDrop = { grid: null, x: 0, y: 0 };
  var hiddenCardIds = {};
  var hiddenSectionIds = {};
  var removedBuiltInSectionIds = {};
  var removedBuiltInSectionCache = {};
  var removedWidgetIds = {};
  var HIDEABLE_ASIDE_SECTION_IDS = isNetworkDashboard()
    ? {
        'network-workspace-notes': true,
        'network-overview': true,
        'network-tips': true,
        'studio-network-workspace-notes': true,
        'studio-network-tips': true,
      }
    : {
        'studio-workspace-notes': true,
        'studio-activity': true,
        'studio-tips': true,
        'studio-updates': true,
      };
  var HIDEABLE_NETWORK_MAIN_SECTION_IDS = {
    'network-sites': true,
  };
  var defaultLayoutSnapshot = null;
  var sectionDropMarker = null;
  var sectionDropTarget = { column: null, beforeId: null };
  var lastCardDropKey = '';
  var dragFromWorkspace = false;
  var dragCardOrigin = null;
  var dragSectionOrigin = null;
  var workspaceToastTimer = null;
  var layoutSavedToastTimer = null;
  var layoutSavedToastHideTimer = null;
  var suppressLayoutSave = false;
  var pointerDrag = { active: false, pointerId: null };
  var sectionPointerDrag = { active: false, pointerId: null };
  var pendingSectionDrop = { x: 0, y: 0 };
  var ASIDE_ITEMS_PER_PAGE = 4;

  function readFactoryWidgetSectionsFromDom() {
    var attr = root.getAttribute('data-factory-widget-sections');
    if (!attr) {
      return null;
    }
    try {
      var sections = JSON.parse(attr);
      return sections && typeof sections === 'object' ? sections : null;
    } catch (e) {
      return null;
    }
  }

  function readFactoryAsideOrderFromDom() {
    var attr = root.getAttribute('data-factory-aside-order');
    if (!attr) {
      return null;
    }
    try {
      var order = JSON.parse(attr);
      return Array.isArray(order) ? order : null;
    } catch (e) {
      return null;
    }
  }

  function getDefaultWidgetSections() {
    var sections = {};
    var fromDom = readFactoryWidgetSectionsFromDom();
    if (fromDom) {
      Object.keys(fromDom).forEach(function (sectionId) {
        if (fromDom[sectionId] && typeof fromDom[sectionId] === 'object') {
          sections[sectionId] = fromDom[sectionId];
        }
      });
    }
    return sections;
  }

  function escapeHtml(str) {
    var d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
  }

  function readInitialLayoutFromDom() {
    var attr = root.getAttribute('data-initial-layout');
    if (!attr) {
      return null;
    }
    try {
      var data = JSON.parse(attr);
      return data && typeof data === 'object' ? data : null;
    } catch (e) {
      return null;
    }
  }

  /** Card order from PHP template (captured before SSR applies saved layout). */
  function readFactoryCardsFromDom() {
    var attr = root.getAttribute('data-factory-cards');
    if (!attr) {
      return null;
    }
    try {
      var cards = JSON.parse(attr);
      return cards && typeof cards === 'object' ? cards : null;
    } catch (e) {
      return null;
    }
  }

  function getFactoryCardsLayout() {
    var fromDom = readFactoryCardsFromDom();
    if (fromDom) {
      return fromDom;
    }
    if (defaultLayoutSnapshot && defaultLayoutSnapshot.cards) {
      return defaultLayoutSnapshot.cards;
    }
    return buildLayoutSnapshot().cards || {};
  }

  function canUseLayoutServer() {
    return !!(layoutAjaxUrl && layoutNonce);
  }

  function readStorage() {
    if (window.YOOStudioHubLayoutStorage) {
      return window.YOOStudioHubLayoutStorage.getSession();
    }
    return readInitialLayoutFromDom();
  }

  function stampLayoutSavedAt(data) {
    if (data && typeof data === 'object') {
      data.savedAt = Date.now();
    }
    return data;
  }

  function isHideableSectionId(id) {
    if (!id) {
      return false;
    }
    if (isNetworkDashboard() && id === NETWORK_WORKSPACE_MAIN_SECTION_ID) {
      return false;
    }
    if (isNetworkDashboard()) {
      return !!(
        HIDEABLE_ASIDE_SECTION_IDS[id] || HIDEABLE_NETWORK_MAIN_SECTION_IDS[id]
      );
    }
    return !!HIDEABLE_ASIDE_SECTION_IDS[id];
  }

  function clearAllSectionHiddenDomFlags() {
    root.querySelectorAll('.yp-dashboard-section[data-section-id]').forEach(function (section) {
      var id = getSectionId(section);
      if (!id || !isHideableSectionId(id)) {
        return;
      }
      section.removeAttribute('data-section-hidden');
      section.classList.remove('is-dashboard-section-hidden');
      section.removeAttribute('hidden');
      section.classList.remove('yp-layout-section--hidden');
      root.querySelectorAll('[data-network-section-visibility="' + id + '"]').forEach(function (btn) {
        btn.classList.remove('is-active');
        btn.setAttribute('aria-pressed', 'false');
      });
    });
    if (layoutEl) {
      layoutEl.classList.remove('yp-studio-hub__layout--aside-empty');
    }
    if (asideEl) {
      asideEl.classList.remove('yp-studio-hub__aside--empty');
      asideEl.removeAttribute('aria-hidden');
    }
  }

  /** Strip hide flags from every dashboard card (reset must not depend on hiddenCardIds alone). */
  function clearAllCardHiddenDomFlags() {
    root.querySelectorAll('[data-card-id]').forEach(function (card) {
      card.removeAttribute('data-hidden');
      card.classList.remove('is-dashboard-card-hidden');
      card.classList.remove('yp-ws-page-hidden');
      card.removeAttribute('hidden');
      card.removeAttribute('aria-disabled');
      if (card.style && card.style.display === 'none') {
        card.style.removeProperty('display');
      }
    });
  }

  function revealNetworkWorkspaceCards() {
    if (!isNetworkDashboard()) {
      return;
    }
    [NETWORK_WORKSPACE_MAIN_SECTION_ID, 'network-sites'].forEach(function (sectionId) {
      var section = root.querySelector('[data-section-id="' + sectionId + '"]');
      if (!section) {
        return;
      }
      section.removeAttribute('data-section-hidden');
      section.classList.remove('is-dashboard-section-hidden');
      section.removeAttribute('hidden');
      section.classList.remove('yp-layout-section--hidden');
      var grid = getSectionGrid(section);
      if (!grid) {
        return;
      }
      grid.querySelectorAll('[data-card-id]').forEach(function (card) {
        card.removeAttribute('data-hidden');
        card.classList.remove('is-dashboard-card-hidden');
        card.classList.remove('yp-ws-page-hidden');
        card.removeAttribute('hidden');
        card.removeAttribute('aria-disabled');
        if (card.style && card.style.display === 'none') {
          card.style.removeProperty('display');
        }
      });
    });
  }

  function flushVisibilityAfterReset() {
    hiddenCardIds = {};
    hiddenSectionIds = {};
    clearAllCardHiddenDomFlags();
    revealNetworkWorkspaceCards();
    clearAllSectionHiddenDomFlags();
    applyDefaultHiddenSections();
    applyDefaultRemovedBuiltInSections();
    applyAllHiddenStates();
    applyAllSectionHiddenStates();
    refreshSectionVisibility();
    syncLayoutColumns();
    syncLocalizedDashboardStrings();
    try {
      root.dispatchEvent(
        new CustomEvent('yooadmin-studio-hub-layout-reset', { bubbles: true })
      );
    } catch (e) {
      /* ignore */
    }
  }

  function layoutHasUserSectionVisibility(data) {
    return !!(data && data.hiddenSectionsExplicit && data.asideVisibilityTouched);
  }

  function mergeHiddenSectionsFromDom(options) {
    options = options || {};
    if (options.hiddenSectionsExplicit) {
      return;
    }
    root.querySelectorAll('.yp-dashboard-section[data-layout-section="true"]').forEach(function (section) {
      var id = getSectionId(section);
      if (!id || !isHideableSectionId(id)) {
        return;
      }
      if (section.getAttribute('data-section-hidden') === 'true') {
        hiddenSectionIds[id] = true;
      }
    });
  }

  function writeStorage(data, options) {
    options = options || {};
    if (suppressLayoutSave || !data || data.version !== LAYOUT_VERSION) {
      return Promise.resolve(false);
    }

    options.onResult = function (ok, opts) {
      notifyLayoutPersistResult(ok, opts);
    };

    if (window.YOOStudioHubLayoutCoordinator && typeof window.YOOStudioHubLayoutCoordinator.persist === 'function') {
      return window.YOOStudioHubLayoutCoordinator.persist(data, options);
    }

    if (window.YOOStudioHubLayoutStorage) {
      window.YOOStudioHubLayoutStorage.setSession(data);
      if (options.serverImmediate && window.YOOStudioHubLayoutStorage.saveToServer) {
        return window.YOOStudioHubLayoutStorage.saveToServer(data, options).then(function (ok) {
          notifyLayoutPersistResult(ok, options);
          return ok;
        });
      }
    }

    if (!options.silent && !options.serverImmediate) {
      queueLayoutSavedToast(true);
    }
    return Promise.resolve(true);
  }

  function saveLayoutDebounced() {
    if (suppressLayoutSave) {
      return;
    }
    if (saveTimer) {
      clearTimeout(saveTimer);
    }
    saveTimer = setTimeout(function () {
      saveTimer = null;
      writeStorage(serializeLayout());
    }, 100);
  }

  function saveLayoutNow(options) {
    options = options || {};
    if (suppressLayoutSave) {
      return;
    }
    if (saveTimer) {
      clearTimeout(saveTimer);
      saveTimer = null;
    }
    writeStorage(serializeLayout(), options.serverImmediate ? { serverImmediate: true } : {});
  }

  /** Fast path: section hide/show — skip heavy grid cleanup, save to DB immediately. */
  function saveSectionVisibilityNow() {
    if (suppressLayoutSave) {
      return;
    }
    if (saveTimer) {
      clearTimeout(saveTimer);
      saveTimer = null;
    }
    var data = readStorage();
    if (!data || data.version !== LAYOUT_VERSION) {
      data = serializeLayout({ skipCleanup: true });
    } else {
      data = Object.assign({}, data);
      data.hiddenSections = getHiddenSectionIdList();
      data.hiddenSectionsExplicit = true;
      data.asideVisibilityTouched = true;
      stampLayoutSavedAt(data);
    }
    writeStorage(data, { serverImmediate: true });
  }

  function flushLayoutOnUnload() {
    if (suppressLayoutSave) {
      return;
    }
    var data = serializeLayout({ skipCleanup: true });
    stampLayoutSavedAt(data);
    if (window.YOOStudioHubLayoutStorage) {
      window.YOOStudioHubLayoutStorage.setSession(data);
      if (window.YOOStudioHubLayoutStorage.saveToServer) {
        window.YOOStudioHubLayoutStorage.saveToServer(data, { keepalive: true, silent: true });
      }
    }
  }

  function nextCustomId(placement) {
    customSectionSeq += 1;
    return 'custom-' + placement + '-' + Date.now() + '-' + customSectionSeq;
  }

  function getLayoutSections(container) {
    return Array.prototype.slice.call(
      container.querySelectorAll(':scope > .yp-dashboard-section[data-layout-section="true"]')
    );
  }

  function isSectionLocked(section) {
    if (!section) {
      return true;
    }
    if (section.getAttribute('data-layout-locked') === 'true') {
      return true;
    }
    var id = getSectionId(section);
    return !!(id && LOCKED_SECTION_IDS[id]);
  }

  function isMovableSection(section) {
    return (
      section &&
      section.getAttribute('data-layout-section') === 'true' &&
      !isSectionLocked(section)
    );
  }

  function isLayoutEditActive() {
    return (
      layoutEditOn ||
      document.body.classList.contains('yp-icon-edit-mode') ||
      document.documentElement.classList.contains('yp-icon-edit-mode')
    );
  }

  function updateCardsDraggable() {
    root.querySelectorAll('[data-card-id][data-layout-bound="1"]').forEach(syncCardEditInteraction);
  }

  function ensureLayoutDragHandle(card) {
    if (!card) {
      return null;
    }
    var handle = card.querySelector('.yp-layout-card-drag-handle');
    if (!handle) {
      handle = document.createElement('span');
      handle.className = 'yp-layout-card-drag-handle';
      handle.setAttribute('aria-hidden', 'true');
      handle.innerHTML = '<span class="dashicons dashicons-move" aria-hidden="true"></span>';
      card.insertBefore(handle, card.firstChild);
    }
    if (handle.getAttribute('data-layout-handle-bound') !== '1') {
      handle.addEventListener('pointerdown', onDragHandlePointerDown);
      handle.addEventListener('pointermove', onDragHandlePointerMove);
      handle.addEventListener('pointerup', onDragHandlePointerUp);
      handle.addEventListener('pointercancel', onDragHandlePointerUp);
      handle.setAttribute('data-layout-handle-bound', '1');
    }
    return handle;
  }

  /** Suspend link navigation in edit mode; drag via handle (not the <a> — avoids broken HTML5 drag). */
  function syncCardEditInteraction(card) {
    if (!card) {
      return;
    }
    var handle = ensureLayoutDragHandle(card);
    var inEdit = isLayoutEditActive();
    card.setAttribute('draggable', 'false');
    if (isCardDragLocked(card)) {
      card.classList.remove('yp-layout-card--draggable');
      if (handle) {
        handle.hidden = true;
      }
      if (!inEdit) {
        var lockedSaved = card.getAttribute('data-ysh-layout-href');
        if (lockedSaved) {
          card.setAttribute('href', lockedSaved);
          card.removeAttribute('data-ysh-layout-href');
        }
      }
      return;
    }
    if (inEdit) {
      if (!card.hasAttribute('data-ysh-layout-href')) {
        var href = card.getAttribute('href');
        if (href && href !== '#') {
          card.setAttribute('data-ysh-layout-href', href);
        }
      }
      card.setAttribute('href', '#');
      card.classList.add('yp-layout-card--draggable');
      if (handle) {
        handle.hidden = false;
      }
    } else {
      var saved = card.getAttribute('data-ysh-layout-href');
      if (saved) {
        card.setAttribute('href', saved);
        card.removeAttribute('data-ysh-layout-href');
      }
      card.classList.remove('yp-layout-card--draggable');
      if (handle) {
        handle.hidden = true;
      }
    }
  }

  function getGridHitRect(grid) {
    if (!grid) {
      return null;
    }
    var rect = grid.getBoundingClientRect();
    if (rect.width >= 4 && rect.height >= 4) {
      return rect;
    }
    if (!isLayoutEditActive()) {
      return null;
    }
    var section = grid.closest('.yp-studio-custom-section.yp-studio-custom-section--empty');
    if (!section) {
      return null;
    }
    var sectionRect = section.getBoundingClientRect();
    var header = section.querySelector('.yp-section-header');
    var top = header ? header.getBoundingClientRect().bottom : sectionRect.top;
    var height = sectionRect.bottom - top;
    if (height < 4 || sectionRect.width < 4) {
      return null;
    }
    return {
      left: sectionRect.left,
      right: sectionRect.right,
      top: top,
      bottom: sectionRect.bottom,
      width: sectionRect.width,
      height: height,
    };
  }

  function findGridAtPoint(clientX, clientY) {
    var grids = getSortableGrids();
    for (var i = 0; i < grids.length; i++) {
      var grid = grids[i];
      if (grid.hidden || grid.getAttribute('hidden') === 'hidden') {
        continue;
      }
      var rect = getGridHitRect(grid);
      if (!rect) {
        continue;
      }
      if (
        clientX >= rect.left &&
        clientX <= rect.right &&
        clientY >= rect.top &&
        clientY <= rect.bottom
      ) {
        return grid;
      }
    }
    return null;
  }

  function unionCardRects(elements) {
    var top = Infinity;
    var bottom = -Infinity;
    for (var i = 0; i < elements.length; i++) {
      var r = elements[i].getBoundingClientRect();
      top = Math.min(top, r.top);
      bottom = Math.max(bottom, r.bottom);
    }
    return { top: top, bottom: bottom, height: bottom - top };
  }

  function groupCardsIntoRows(items) {
    if (!items.length) {
      return [];
    }
    var sorted = items.slice().sort(function (a, b) {
      var ra = a.getBoundingClientRect();
      var rb = b.getBoundingClientRect();
      if (Math.abs(ra.top - rb.top) > 12) {
        return ra.top - rb.top;
      }
      return ra.left - rb.left;
    });
    var rows = [];
    var current = [];
    var rowTop = null;
    sorted.forEach(function (item) {
      var top = item.getBoundingClientRect().top;
      if (rowTop === null || Math.abs(top - rowTop) <= 12) {
        current.push(item);
        if (rowTop === null) {
          rowTop = top;
        }
      } else {
        rows.push(current);
        current = [item];
        rowTop = top;
      }
    });
    if (current.length) {
      rows.push(current);
    }
    return rows;
  }

  function getMainColumnLockedSectionId() {
    return isNetworkDashboard() ? NETWORK_WORKSPACE_MAIN_SECTION_ID : WORKSPACE_MAIN_SECTION_ID;
  }

  function isMainColumnLockedSectionId(id) {
    if (!id) {
      return false;
    }
    if (isNetworkDashboard()) {
      return !!NETWORK_MAIN_COLUMN_LOCKED_IDS[id];
    }
    return id === WORKSPACE_MAIN_SECTION_ID;
  }

  function ensureMainColumnLockedSections() {
    if (!isNetworkDashboard()) {
      var lockedMain = root.querySelector(
        '[data-section-id="' + WORKSPACE_MAIN_SECTION_ID + '"]'
      );
      if (lockedMain && !mainEl.contains(lockedMain)) {
        insertMainSection(lockedMain);
      }
      return;
    }

    Object.keys(NETWORK_MAIN_COLUMN_LOCKED_IDS).forEach(function (sectionId) {
      var section = root.querySelector('[data-section-id="' + sectionId + '"]');
      if (section && !mainEl.contains(section)) {
        insertMainSection(section);
      }
    });
  }

  function getWorkspaceSection() {
    return root.querySelector('[data-section-id="your-workspace"]');
  }

  function getNetworkWorkspaceSection() {
    return root.querySelector('[data-section-id="' + NETWORK_WORKSPACE_MAIN_SECTION_ID + '"]');
  }

  function getWorkspaceCards() {
    var ws = getWorkspaceSection();
    var grid = getSectionGrid(ws);
    if (!grid) {
      return [];
    }
    return Array.prototype.filter.call(grid.children, function (node) {
      return isVisibleLayoutCard(node);
    });
  }

  function isVisibleLayoutCard(node) {
    return (
      node &&
      node.hasAttribute &&
      node.hasAttribute('data-card-id') &&
      node.getAttribute('data-card-id') !== '' &&
      !hiddenCardIds[node.getAttribute('data-card-id')] &&
      !node.classList.contains('is-dashboard-card-hidden') &&
      node.getAttribute('data-layout-drop-slot') !== '1'
    );
  }

  function isNetworkWorkspaceLayoutCard(node) {
    return isVisibleLayoutCard(node);
  }

  function getNetworkWorkspaceCards() {
    var ws = getNetworkWorkspaceSection();
    var grid = getSectionGrid(ws);
    if (!grid) {
      return [];
    }
    return Array.prototype.filter.call(grid.children, isNetworkWorkspaceLayoutCard);
  }

  function isCardDragLocked(/* card */) {
    return false;
  }

  function isWorkspaceGrid(grid) {
    if (!grid) {
      return false;
    }
    var ws = getWorkspaceSection();
    return !!(ws && getSectionGrid(ws) === grid);
  }

  function isNetworkWorkspaceGrid(grid) {
    if (!grid) {
      return false;
    }
    var ws = getNetworkWorkspaceSection();
    return !!(ws && getSectionGrid(ws) === grid);
  }

  function captureDragCardOrigin(card) {
    if (!card || !card.parentNode) {
      return null;
    }
    var beforeId = null;
    var next = card.nextElementSibling;
    while (next) {
      if (next.hasAttribute('data-card-id')) {
        beforeId = getCardId(next);
        break;
      }
      next = next.nextElementSibling;
    }
    return { parent: card.parentNode, beforeId: beforeId };
  }

  function restoreDragCardOrigin(card) {
    if (!card || !dragCardOrigin || !dragCardOrigin.parent) {
      return;
    }
    var parent = dragCardOrigin.parent;
    if (!parent.isConnected) {
      return;
    }
    if (dragCardOrigin.beforeId) {
      var before = parent.querySelector('[data-card-id="' + dragCardOrigin.beforeId + '"]');
      if (before && before.parentNode === parent) {
        parent.insertBefore(card, before);
        return;
      }
    }
    parent.appendChild(card);
  }

  function captureDragSectionOrigin(section) {
    if (!section || !section.parentNode) {
      return null;
    }
    var beforeId = null;
    var next = section.nextElementSibling;
    while (next) {
      if (next.classList && next.classList.contains('yp-dashboard-section')) {
        beforeId = getSectionId(next);
        break;
      }
      next = next.nextElementSibling;
    }
    return { parent: section.parentNode, beforeId: beforeId };
  }

  function restoreDragSectionOrigin(section) {
    if (!section || !dragSectionOrigin || !dragSectionOrigin.parent) {
      return;
    }
    var parent = dragSectionOrigin.parent;
    if (!parent.isConnected) {
      return;
    }
    if (dragSectionOrigin.beforeId) {
      var before = parent.querySelector('[data-section-id="' + dragSectionOrigin.beforeId + '"]');
      if (before && before.parentNode === parent) {
        parent.insertBefore(section, before);
        return;
      }
    }
    parent.appendChild(section);
  }


  function isWorkspaceMainSection(section) {
    return getSectionId(section) === WORKSPACE_MAIN_SECTION_ID;
  }

  function isMainColumnLockedSection(section) {
    return isMainColumnLockedSectionId(getSectionId(section));
  }

  function rejectWorkspaceAsideMove(section, notify) {
    return rejectMainColumnLockedAsideMove(section, notify);
  }

  function rejectMainColumnLockedAsideMove(section, notify) {
    if (!section || !isMainColumnLockedSection(section)) {
      return false;
    }
    if (notify) {
      restoreDragSectionOrigin(section);
      if (isNetworkDashboard()) {
        var lockedId = getSectionId(section);
        var message =
          lockedId === 'network-sites'
            ? t(
                'networkSitesAsideBlockedToast',
                'Sites must stay in the main column and cannot be moved to the right sidebar.'
              )
            : t(
                'networkWorkspaceAsideBlockedToast',
                'Network Workspace must stay in the main column and cannot be moved to the right sidebar.'
              );
        showWorkspaceToast(message);
      } else {
        showWorkspaceToast(
          t(
            'workspaceAsideBlockedToast',
            'Your workspace must stay in the main column and cannot be moved to the right sidebar.'
          )
        );
      }
    } else if (!mainEl.contains(section)) {
      insertMainSection(section);
    }
    section.setAttribute('data-custom-placement', 'main');
    return true;
  }

  function showLayoutSavedToast(type) {
    var message =
      type === 'error'
        ? t('layoutSaveFailed', 'Could not save layout. Please try again.')
        : t('layoutSaved', 'Layout saved.');
    if (!message) {
      return;
    }

    if (typeof window.yshShowStudioHubToast === 'function') {
      window.yshShowStudioHubToast(message, type === 'error' ? 'error' : 'success');
      return;
    }

    document.querySelectorAll('.yp-toast-message.ysh-layout-saved-toast').forEach(function (el) {
      if (el.parentNode) {
        el.parentNode.removeChild(el);
      }
    });
    if (layoutSavedToastTimer) {
      clearTimeout(layoutSavedToastTimer);
      layoutSavedToastTimer = null;
    }
    if (layoutSavedToastHideTimer) {
      clearTimeout(layoutSavedToastHideTimer);
      layoutSavedToastHideTimer = null;
    }

    var iconChar = type === 'error' ? '✕' : '✓';
    var toast = document.createElement('div');
    toast.className =
      'yp-toast-message ysh-layout-saved-toast yp-toast-' + (type === 'error' ? 'error' : 'success');
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');

    var icon = document.createElement('span');
    icon.className = 'yp-toast-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = iconChar;

    var text = document.createElement('span');
    text.className = 'yp-toast-text';
    text.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(text);
    document.body.appendChild(toast);

    requestAnimationFrame(function () {
      toast.classList.add('yp-toast-show');
    });

    layoutSavedToastHideTimer = setTimeout(function () {
      toast.classList.remove('yp-toast-show');
      layoutSavedToastTimer = setTimeout(function () {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 300);
    }, 3200);
  }

  function queueLayoutSavedToast(ok) {
    if (suppressLayoutSave) {
      return;
    }
    if (layoutSavedToastTimer) {
      clearTimeout(layoutSavedToastTimer);
    }
    layoutSavedToastTimer = setTimeout(function () {
      layoutSavedToastTimer = null;
      showLayoutSavedToast(ok ? 'success' : 'error');
    }, 120);
  }

  function notifyLayoutPersistResult(ok, options) {
    options = options || {};
    if (options.silent || options.keepalive || suppressLayoutSave) {
      return;
    }
    queueLayoutSavedToast(!!ok);
  }

  function showWorkspaceToast(message) {
    if (!message) {
      return;
    }
    var existing = document.querySelector('.ysh-layout-toast');
    if (existing && existing.parentNode) {
      existing.parentNode.removeChild(existing);
    }
    if (workspaceToastTimer) {
      clearTimeout(workspaceToastTimer);
      workspaceToastTimer = null;
    }

    var toast = document.createElement('div');
    toast.className = 'ysh-layout-toast';
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    toast.textContent = message;

    var host = root.closest('.yp-studio-hub') || root;
    host.appendChild(toast);
    requestAnimationFrame(function () {
      toast.classList.add('is-visible');
    });

    workspaceToastTimer = setTimeout(function () {
      toast.classList.remove('is-visible');
      setTimeout(function () {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 280);
    }, 4200);
  }

  function resolveDropGrid(grid) {
    if (!grid || !draggingCard || !dragFromWorkspace) {
      return grid;
    }
    if (isWorkspaceGrid(grid)) {
      return grid;
    }
    return grid;
  }

  function isWorkspaceDropInvalid(card) {
    if (!card || !dragFromWorkspace) {
      return false;
    }
    if (isNetworkDashboard()) {
      var nwGrid = getSectionGrid(getNetworkWorkspaceSection());
      if (!nwGrid || nwGrid.contains(card)) {
        return false;
      }
      return getNetworkWorkspaceCards().length < WORKSPACE_MIN_ITEMS;
    }
    var wsGrid = getSectionGrid(getWorkspaceSection());
    if (!wsGrid || wsGrid.contains(card)) {
      return false;
    }
    return getWorkspaceCards().length < WORKSPACE_MIN_ITEMS;
  }

  function getCardMenuSlug(card) {
    if (!card) {
      return '';
    }
    var slug = card.getAttribute('data-menu-slug') || '';
    if (slug) {
      return slug.toLowerCase();
    }
    var href = card.getAttribute('data-ysh-layout-href') || card.getAttribute('href') || '';
    if (!href || href === '#') {
      return '';
    }
    try {
      var u = new URL(href, window.location.origin);
      var page = u.searchParams.get('page');
      if (page) {
        return page.toLowerCase();
      }
      var path = u.pathname || '';
      var base = path.split('/').pop() || '';
      return base.toLowerCase();
    } catch (e) {
      return '';
    }
  }

  function getCardLabelNormalized(card) {
    if (!card) {
      return '';
    }
    var el = card.querySelector('.yp-icon-label');
    if (!el) {
      return '';
    }
    return el.textContent.replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function isCardHideLocked(card) {
    if (!card) {
      return false;
    }
    var id = getCardId(card);
    if (id && LOCKED_HIDE_CARD_IDS[id]) {
      return true;
    }

    var menuSlug = getCardMenuSlug(card);
    var href = (card.getAttribute('data-ysh-layout-href') || card.getAttribute('href') || '').toLowerCase();

    if (
      menuSlug === 'index.php' ||
      (href.indexOf('index.php') !== -1 && href.indexOf('page=') === -1)
    ) {
      return true;
    }

    if (
      menuSlug === 'yooadmin-plugins' ||
      href.indexOf('page=yooadmin-plugins') !== -1
    ) {
      return true;
    }

    if (menuSlug === 'yooadmin-dashboard' || href.indexOf('page=yooadmin-dashboard') !== -1) {
      return true;
    }

    var label = getCardLabelNormalized(card);
    if (label === 'dashboard') {
      return true;
    }
    if (label === 'yooadmin' || label.indexOf('yooadmin panel') === 0) {
      return true;
    }

    return false;
  }

  function getDropColumn(clientX, clientY) {
    var asideRect = asideEl.getBoundingClientRect();
    if (
      clientY >= asideRect.top &&
      clientY <= asideRect.bottom &&
      clientX >= asideRect.left &&
      clientX <= asideRect.right
    ) {
      return 'aside';
    }
    return 'main';
  }

  function getSectionInsertBefore(container, clientY) {
    var sections = getLayoutSections(container).filter(function (s) {
      return s !== draggingSection;
    });
    for (var i = 0; i < sections.length; i++) {
      var box = sections[i].getBoundingClientRect();
      if (clientY < box.top + box.height * 0.5) {
        return sections[i];
      }
    }
    return null;
  }

  function insertMainSection(section) {
    if (mainAddBtn && mainAddBtn.parentNode === mainEl) {
      mainEl.insertBefore(section, mainAddBtn);
    } else {
      mainEl.appendChild(section);
    }
    section.setAttribute('data-custom-placement', 'main');
  }

  function getFactoryAsideOrder() {
    var fromDom = readFactoryAsideOrderFromDom();
    if (fromDom && fromDom.length) {
      return fromDom.slice();
    }
    return (isNetworkDashboard() ? DEFAULT_NETWORK_ASIDE_ORDER : DEFAULT_ASIDE_ORDER).slice();
  }

  function getFactoryMainOrder() {
    return isNetworkDashboard()
      ? ['network-workspace', 'network-sites']
      : ['your-workspace', 'from-extensions'];
  }

  function getNetworkWorkspaceCardOrderFromDom() {
    return getNetworkWorkspaceCards()
      .map(function (card) {
        return getCardId(card);
      })
      .filter(Boolean);
  }

  /** Live aside order from DOM (SSR); never use for factory reset. */
  function getDefaultAsideOrder() {
    var list;
    if (window.__YOOStudioHubDefaultAsideOrder && window.__YOOStudioHubDefaultAsideOrder.length) {
      list = window.__YOOStudioHubDefaultAsideOrder.slice();
    } else if (asideEl) {
      var attr = asideEl.getAttribute('data-default-aside-order');
      if (attr) {
        list = attr
          .split(',')
          .map(function (s) {
            return s.trim();
          })
          .filter(Boolean);
      }
    }
    if (!list || !list.length) {
      return getFactoryAsideOrder();
    }
    return list;
  }

  function syncFactoryLayoutDomMeta(data) {
    if (asideEl) {
      asideEl.setAttribute('data-default-aside-order', getFactoryAsideOrder().join(','));
    }
    if (data && data.version === LAYOUT_VERSION) {
      try {
        root.setAttribute('data-initial-layout', JSON.stringify(data));
      } catch (e) {
        /* ignore */
      }
      if (window.YOOStudioHubLayoutStorage && window.YOOStudioHubLayoutStorage.setSession) {
        window.YOOStudioHubLayoutStorage.setSession(data);
      }
    }
  }

  function buildLayoutSnapshot() {
    var mainOrder = getLayoutSections(mainEl).map(getSectionId).filter(Boolean);
    var asideOrder = getLayoutSections(asideEl).map(getSectionId).filter(Boolean);
    var cards = {};
    var widgetSections = {};
    root.querySelectorAll('.yp-dashboard-section[data-section-id]').forEach(function (section) {
      var sid = getSectionId(section);
      var grid = getSectionGrid(section);
      if (!sid) {
        return;
      }
      if (grid) {
        cards[sid] = Array.prototype.map.call(grid.querySelectorAll('[data-card-id]'), function (c) {
          return getCardId(c);
        });
      }
      if (section.classList.contains('yp-studio-widget-section')) {
        widgetSections[sid] = {
          placement: asideEl.contains(section) ? 'aside' : 'main',
          widgetId: section.getAttribute('data-widget-id') || '',
          title: getSectionTitleText(section),
          icon: getSectionIcon(section) || getSectionDefaultIcon(section),
        };
      }
    });
    return {
      mainOrder: mainOrder,
      asideOrder: asideOrder,
      cards: cards,
      customSections: {},
      widgetSections: widgetSections,
      overviewDefaultWidgetAdded: true,
      removedBuiltInSections: [],
      hidden: [],
    };
  }

  function captureDefaultLayoutIfNeeded() {
    if (defaultLayoutSnapshot) {
      return;
    }
    defaultLayoutSnapshot = buildLayoutSnapshot();
    defaultLayoutSnapshot.mainOrder = getFactoryMainOrder();
    defaultLayoutSnapshot.asideOrder = getFactoryAsideOrder();
  }

  function ensureSectionDropMarker() {
    if (!sectionDropMarker) {
      sectionDropMarker = document.createElement('div');
      sectionDropMarker.className = 'yp-layout-section-drop-marker';
      sectionDropMarker.setAttribute('aria-hidden', 'true');
    }
    return sectionDropMarker;
  }

  function removeSectionDropMarker() {
    if (sectionDropMarker && sectionDropMarker.parentNode) {
      sectionDropMarker.parentNode.removeChild(sectionDropMarker);
    }
    sectionDropTarget = { column: null, beforeId: null };
  }

  function isWorkspaceAsideDropBlocked(column) {
    return !!(
      draggingSection &&
      isMainColumnLockedSection(draggingSection) &&
      column === 'aside'
    );
  }

  function updateSectionDropMarker(column, clientY) {
    var workspaceAsideBlocked = isWorkspaceAsideDropBlocked(column);

    mainEl.classList.toggle('yp-layout-column--drag-over', !workspaceAsideBlocked && column === 'main');
    asideEl.classList.toggle('yp-layout-column--drag-over', !workspaceAsideBlocked && column === 'aside');
    asideEl.classList.toggle('yp-layout-column--drop-blocked', workspaceAsideBlocked);

    if (workspaceAsideBlocked) {
      if (sectionDropMarker && sectionDropMarker.parentNode) {
        sectionDropMarker.parentNode.removeChild(sectionDropMarker);
      }
      sectionDropTarget = { column: null, beforeId: null };
      return;
    }

    var container = column === 'aside' ? asideEl : mainEl;
    var insertBefore = getSectionInsertBefore(container, clientY);
    var beforeId = insertBefore ? getSectionId(insertBefore) : null;
    if (sectionDropTarget.column === column && sectionDropTarget.beforeId === beforeId) {
      return;
    }
    sectionDropTarget.column = column;
    sectionDropTarget.beforeId = beforeId;

    var marker = ensureSectionDropMarker();
    if (insertBefore) {
      container.insertBefore(marker, insertBefore);
    } else if (container === asideEl) {
      if (asideAddBtn && asideAddBtn.parentNode === asideEl) {
        asideEl.insertBefore(marker, asideAddBtn);
      } else {
        asideEl.appendChild(marker);
      }
    } else if (mainAddBtn && mainAddBtn.parentNode === mainEl) {
      mainEl.insertBefore(marker, mainAddBtn);
    } else {
      mainEl.appendChild(marker);
    }

  }

  function commitSectionDrop() {
    if (!draggingSection) {
      return;
    }
    if (
      !sectionDropTarget.column &&
      sectionDropMarker &&
      sectionDropMarker.parentNode
    ) {
      var markerParent = sectionDropMarker.parentNode;
      sectionDropTarget.column = markerParent === asideEl ? 'aside' : 'main';
      var markerNext = sectionDropMarker.nextElementSibling;
      if (
        markerNext &&
        markerNext.classList &&
        markerNext.classList.contains('yp-dashboard-section')
      ) {
        sectionDropTarget.beforeId = getSectionId(markerNext);
      }
    }
    if (!sectionDropTarget.column && draggingSection) {
      sectionDropTarget.column = getDropColumn(pendingSectionDrop.x, pendingSectionDrop.y);
      var pendingContainer = sectionDropTarget.column === 'aside' ? asideEl : mainEl;
      var pendingBefore = getSectionInsertBefore(pendingContainer, pendingSectionDrop.y);
      sectionDropTarget.beforeId = pendingBefore ? getSectionId(pendingBefore) : null;
    }
    if (!sectionDropTarget.column) {
      return;
    }
    var container = sectionDropTarget.column === 'aside' ? asideEl : mainEl;
    if (container === asideEl && rejectWorkspaceAsideMove(draggingSection, true)) {
      removeSectionDropMarker();
      return;
    }
    var before = sectionDropTarget.beforeId
      ? root.querySelector('[data-section-id="' + sectionDropTarget.beforeId + '"]')
      : null;
    if (before && before.parentNode === container) {
      container.insertBefore(draggingSection, before);
    } else if (container === asideEl) {
      insertAsideSection(draggingSection);
    } else {
      insertMainSection(draggingSection);
    }
    draggingSection.setAttribute(
      'data-custom-placement',
      container === asideEl ? 'aside' : 'main'
    );
    if (isExtensionsSection(draggingSection)) {
      syncExtensionsAsidePlacement(draggingSection);
    }
    removeSectionDropMarker();
  }

  function placeSectionInContainer(section, container, clientY) {
    if (!section || !container || isSectionLocked(section)) {
      return;
    }
    if (container === asideEl && rejectWorkspaceAsideMove(section, false)) {
      return;
    }
    var sections = getLayoutSections(container).filter(function (s) {
      return s !== section;
    });
    var insertBefore = null;
    var best = Number.NEGATIVE_INFINITY;
    for (var i = 0; i < sections.length; i++) {
      var box = sections[i].getBoundingClientRect();
      var offset = clientY - box.top - box.height * 0.5;
      if (offset < 0 && offset > best) {
        best = offset;
        insertBefore = sections[i];
      }
    }
    if (insertBefore) {
      container.insertBefore(section, insertBefore);
    } else if (container === asideEl) {
      insertAsideSection(section);
    } else {
      insertMainSection(section);
    }
    if (container === asideEl) {
      section.setAttribute('data-custom-placement', 'aside');
      if (isExtensionsSection(section)) {
        syncExtensionsAsidePlacement(section);
      } else if (section.classList.contains('yp-studio-custom-section') && window.YOOAdminWorkspacePagination) {
        window.YOOAdminWorkspacePagination.ensureSection(section);
      }
      if (window.YOOAdminWorkspacePagination) {
        window.YOOAdminWorkspacePagination.refresh();
      }
    } else {
      section.setAttribute('data-custom-placement', 'main');
      section.classList.remove('yp-studio-custom-section--aside');
      if (isExtensionsSection(section)) {
        syncExtensionsAsidePlacement(section);
      } else if (
        isNetworkDashboard() &&
        section.classList.contains('yp-studio-custom-section') &&
        window.YOOAdminWorkspacePagination
      ) {
        window.YOOAdminWorkspacePagination.ensureSection(section);
        window.YOOAdminWorkspacePagination.syncSection(section);
      }
    }
  }

  function applySectionColumnPlacements(data) {
    var asideIds = (data.asideOrder || []).filter(function (id) {
      return id && !LOCKED_SECTION_IDS[id] && !isMainColumnLockedSectionId(id);
    });
    var asideIdSet = Object.create(null);
    asideIds.forEach(function (id) {
      asideIdSet[id] = true;
    });
    var mainIds = (data.mainOrder || []).filter(function (id) {
      return id && !asideIdSet[id];
    });

    asideIds.forEach(function (id) {
      var section = root.querySelector('[data-section-id="' + id + '"]');
      if (section && isMovableSection(section)) {
        placeSectionInContainer(section, asideEl, 99999);
      }
    });

    mainIds.forEach(function (id) {
      var section = root.querySelector('[data-section-id="' + id + '"]');
      if (!section) {
        return;
      }
      if (isSectionLocked(section)) {
        insertMainSection(section);
        return;
      }
      if (asideEl.contains(section) && !asideIdSet[id]) {
        placeSectionInContainer(section, mainEl, 99999);
      }
    });

    if (mainIds.length) {
      reorderChildren(mainEl, mainIds);
    }
    if (asideIds.length) {
      reorderChildren(asideEl, asideIds);
    }

    ensureMainColumnLockedSections();

    if (!isNetworkDashboard()) {
      var ext = root.querySelector('[data-section-id="from-extensions"]');
      if (ext) {
        syncExtensionsAsidePlacement(ext);
      }
    }
  }

  function getSortableGrids() {
    return Array.prototype.slice.call(
      root.querySelectorAll('.yp-cards-grid[data-sortable="true"]')
    );
  }

  function getSectionId(section) {
    return section ? section.getAttribute('data-section-id') || '' : '';
  }

  function getSectionGrid(section) {
    if (!section) {
      return null;
    }
    return (
      section.querySelector('.yp-cards-grid[data-sortable="true"]') ||
      section.querySelector('.yp-cards-grid')
    );
  }

  function getCardId(card) {
    return card ? card.getAttribute('data-card-id') || '' : '';
  }

  function isCardHidden(cardId) {
    return !!(cardId && hiddenCardIds[cardId]);
  }

  function countVisibleCards(section) {
    var grid = getSectionGrid(section);
    if (!grid) {
      return 0;
    }
    var total = 0;
    Array.prototype.forEach.call(grid.querySelectorAll('[data-card-id]'), function (card) {
      var id = getCardId(card);
      if (isCardHidden(id)) {
        return;
      }
      total += 1;
    });
    return total;
  }

  function countCards(section) {
    return countVisibleCards(section);
  }

  function applyDefaultHiddenSections() {
    DEFAULT_HIDDEN_SECTIONS.forEach(function (id) {
      if (HIDEABLE_ASIDE_SECTION_IDS[id] && !isRemovedBuiltInSectionId(id)) {
        hiddenSectionIds[id] = true;
      }
    });
  }

  function applyDefaultRemovedBuiltInSections() {
    DEFAULT_REMOVED_BUILTIN_SECTIONS.forEach(function (id) {
      if (!isBuiltInSectionId(id)) {
        return;
      }
      removedBuiltInSectionIds[id] = true;
      delete hiddenSectionIds[id];
    });
    applyRemovedBuiltInSectionsToDom();
  }

  function applyRemovedBuiltInSectionsToDom() {
    Object.keys(removedBuiltInSectionIds).forEach(function (id) {
      root.querySelectorAll('[data-section-id="' + id + '"]').forEach(function (section) {
        if (!section || !section.parentNode) {
          return;
        }
        removedBuiltInSectionCache[id] = section;
        section.parentNode.removeChild(section);
        delete hiddenSectionIds[id];
      });
    });
  }

  function applyHiddenSectionsFromData(data) {
    loadRemovedBuiltInSectionsFromData(data);
    loadRemovedWidgetIdsFromData(data);
    hiddenSectionIds = {};
    loadHiddenFromData(data);
    mergeHiddenSectionsFromDom({
      hiddenSectionsExplicit: layoutHasUserSectionVisibility(data),
    });
    applyAllHiddenStates();
    applyAllSectionHiddenStates();
    syncLayoutColumns();
  }

  function buildFactoryLayout() {
    captureDefaultLayoutIfNeeded();
    var cards = {};
    var sectionIcons = {};
    cards = getFactoryCardsLayout();
    if (defaultLayoutSnapshot) {
      sectionIcons = defaultLayoutSnapshot.sectionIcons || {};
    }
    return {
      version: LAYOUT_VERSION,
      asideOrder: getFactoryAsideOrder(),
      mainOrder: getFactoryMainOrder(),
      hidden: [],
      hiddenSections: DEFAULT_HIDDEN_SECTIONS.slice(),
      hiddenSectionsExplicit: false,
      overviewDefaultWidgetAdded: true,
      savedAt: Date.now(),
      customSections: {},
      widgetSections: getDefaultWidgetSections(),
      removedBuiltInSections: DEFAULT_REMOVED_BUILTIN_SECTIONS.slice(),
      removedWidgetIds: [],
      cards: cards,
      sectionIcons: sectionIcons,
    };
  }

  function finalizeLayoutSectionGrids() {
    root.querySelectorAll('[data-layout-loading]').forEach(function (el) {
      if (el.parentNode) {
        el.parentNode.removeChild(el);
      }
    });
    root.querySelectorAll('[data-layout-booting]').forEach(function (section) {
      section.classList.remove('yp-studio-layout-section--booting');
      section.removeAttribute('data-layout-booting');
    });
    root.querySelectorAll('.yp-cards-grid').forEach(function (grid) {
      if (grid.classList.contains('yp-studio-extensions-grid')) {
        return;
      }
      if (!grid.classList.contains('is-hydrated')) {
        grid.classList.add('is-hydrated');
      }
    });
    root.querySelectorAll('.yp-studio-custom-section').forEach(syncCustomSection);
  }

  function loadHiddenFromData(data) {
    hiddenCardIds = {};
    hiddenSectionIds = {};
    if (!data) {
      applyDefaultHiddenSections();
      applyDefaultRemovedBuiltInSections();
      return;
    }
    if (data.hidden && data.hidden.length) {
      data.hidden.forEach(function (id) {
        if (!id) {
          return;
        }
        var card = root.querySelector('[data-card-id="' + id + '"]');
        if (card && isCardHideLocked(card)) {
          return;
        }
        hiddenCardIds[id] = true;
      });
    }
    if (layoutHasUserSectionVisibility(data)) {
      if (data.hiddenSections && data.hiddenSections.length) {
        data.hiddenSections.forEach(function (id) {
          if (id && isHideableSectionId(id)) {
            hiddenSectionIds[id] = true;
          }
        });
      }
      return;
    }
    applyDefaultHiddenSections();
    if (data.hiddenSections && data.hiddenSections.length) {
      data.hiddenSections.forEach(function (id) {
        if (id && isHideableSectionId(id)) {
          hiddenSectionIds[id] = true;
        }
      });
    }
    if (isNetworkDashboard()) {
      delete hiddenSectionIds[NETWORK_WORKSPACE_MAIN_SECTION_ID];
    }
  }

  function getHiddenCardIdList() {
    return Object.keys(hiddenCardIds).filter(function (id) {
      var card = root.querySelector('[data-card-id="' + id + '"]');
      return !(card && isCardHideLocked(card));
    });
  }

  function getHiddenSectionIdList() {
    return Object.keys(hiddenSectionIds).filter(function (id) {
      if (isRemovedBuiltInSectionId(id)) {
        return false;
      }
      if (isNetworkDashboard()) {
        return !!(
          HIDEABLE_ASIDE_SECTION_IDS[id] || HIDEABLE_NETWORK_MAIN_SECTION_IDS[id]
        );
      }
      return !!HIDEABLE_ASIDE_SECTION_IDS[id];
    });
  }

  function isSectionHideAllowed(section) {
    if (!section) {
      return false;
    }
    if (isWidgetSection(section)) {
      return asideEl.contains(section) || mainEl.contains(section);
    }
    var id = getSectionId(section);
    if (!id) {
      return false;
    }
    if (isNetworkDashboard()) {
      return !!(
        HIDEABLE_ASIDE_SECTION_IDS[id] || HIDEABLE_NETWORK_MAIN_SECTION_IDS[id]
      );
    }
    if (id === 'from-extensions') {
      return true;
    }
    if (!asideEl || !asideEl.contains(section)) {
      return false;
    }
    return !!(id && HIDEABLE_ASIDE_SECTION_IDS[id]);
  }

  function isSectionHidden(sectionId) {
    return !!(sectionId && hiddenSectionIds[sectionId]);
  }

  function ensureSectionHeaderActions(section) {
    var header = getSectionHeaderEl(section);
    if (!header) {
      return null;
    }
    var actions = header.querySelector('.yp-card-header-actions');
    if (!actions) {
      actions = document.createElement('div');
      actions.className = 'yp-card-header-actions';
      header.appendChild(actions);
    }
    return actions;
  }

  function isPrimaryWorkspaceSection(section) {
    var id = getSectionId(section);
    return id === WORKSPACE_MAIN_SECTION_ID || id === NETWORK_WORKSPACE_MAIN_SECTION_ID;
  }

  function syncWorkspaceAddButton(section) {
    var btn = section ? section.querySelector('[data-studio-workspace-add-section]') : null;
    if (!btn) {
      return;
    }
    var show = isLayoutEditActive() && isPrimaryWorkspaceSection(section);
    btn.hidden = !show;
    btn.classList.toggle('is-visible', show);
    btn.setAttribute('aria-hidden', show ? 'false' : 'true');
  }

  function ensureWorkspaceAddButton(section) {
    if (!isPrimaryWorkspaceSection(section)) {
      return;
    }
    var actions = ensureSectionHeaderActions(section);
    if (!actions) {
      return;
    }
    var btn = actions.querySelector('[data-studio-workspace-add-section]');
    if (!btn) {
      btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'yp-workspace-add-section';
      btn.setAttribute('data-studio-workspace-add-section', 'main');
      btn.setAttribute(
        'aria-label',
        t('addWorkspaceSection', 'Add section or widget')
      );
      btn.setAttribute('title', t('addWorkspaceSection', 'Add section or widget'));
      btn.hidden = true;
      btn.innerHTML = '<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>';
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        openAddSectionModal('main');
      });
      actions.insertBefore(btn, actions.firstChild);
    }
    syncWorkspaceAddButton(section);
  }

  function syncWorkspaceAddButtons() {
    root
      .querySelectorAll(
        '[data-section-id="' +
          WORKSPACE_MAIN_SECTION_ID +
          '"], [data-section-id="' +
          NETWORK_WORKSPACE_MAIN_SECTION_ID +
          '"]'
      )
      .forEach(function (section) {
        ensureWorkspaceAddButton(section);
        syncWorkspaceAddButton(section);
      });
  }

  function applySectionHiddenState(section) {
    if (!section || !isSectionHideAllowed(section)) {
      return;
    }
    var id = getSectionId(section);
    var hidden = isSectionHidden(id);
    var inEdit = isLayoutEditActive();

    if (hidden && inEdit) {
      section.removeAttribute('data-section-hidden');
    } else if (hidden) {
      section.setAttribute('data-section-hidden', 'true');
    } else {
      section.removeAttribute('data-section-hidden');
    }

    section.classList.toggle('is-dashboard-section-hidden', hidden);

    var toggle = section.querySelector('.yp-section-visibility-toggle');
    if (toggle) {
      var icon = toggle.querySelector('.dashicons');
      if (icon) {
        icon.className =
          'dashicons ' + (hidden ? 'dashicons-visibility' : 'dashicons-hidden');
      }
      toggle.setAttribute(
        'aria-label',
        hidden ? t('showSection', 'Show section') : t('hideSection', 'Hide section')
      );
      toggle.setAttribute('aria-pressed', hidden ? 'true' : 'false');
      toggle.classList.toggle('is-active', hidden);
    }
  }

  function applyAllSectionHiddenStates() {
    root.querySelectorAll('.yp-dashboard-section[data-section-id]').forEach(function (section) {
      if (isSectionHideAllowed(section)) {
        applySectionHiddenState(section);
      }
    });
  }

  function toggleSectionVisibility(section) {
    if (!isSectionHideAllowed(section)) {
      return;
    }
    var id = getSectionId(section);
    if (!id) {
      return;
    }
    if (hiddenSectionIds[id]) {
      delete hiddenSectionIds[id];
    } else {
      hiddenSectionIds[id] = true;
    }
    root.querySelectorAll('[data-section-id="' + id + '"]').forEach(applySectionHiddenState);
    syncLayoutColumns();
    saveSectionVisibilityNow();
  }

  function ensureSectionVisibilityToggle(section) {
    if (!isSectionHideAllowed(section)) {
      return;
    }
    var actions = ensureSectionHeaderActions(section);
    if (!actions) {
      return;
    }
    var toggle = section.querySelector('.yp-section-visibility-toggle');
    if (!toggle) {
      toggle = document.createElement('span');
      toggle.className = 'yp-section-visibility-toggle';
      toggle.setAttribute('role', 'button');
      toggle.setAttribute('tabindex', '0');
      toggle.innerHTML = '<span class="dashicons dashicons-hidden" aria-hidden="true"></span>';
      actions.appendChild(toggle);
    } else if (toggle.parentNode !== actions) {
      actions.appendChild(toggle);
    }

    if (toggle.getAttribute('data-visibility-bound') !== '1') {
      toggle.setAttribute('data-visibility-bound', '1');
      toggle.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        toggleSectionVisibility(section);
      });
      toggle.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          e.stopPropagation();
          toggleSectionVisibility(section);
        }
      });
    }
    applySectionHiddenState(section);
  }

  function syncSectionVisibilityToggle(section) {
    if (!section) {
      return;
    }
    var toggle = section.querySelector('.yp-section-visibility-toggle');
    if (toggle) {
      var show = isLayoutEditActive() && isSectionHideAllowed(section);
      toggle.hidden = !show;
      toggle.setAttribute('aria-hidden', show ? 'false' : 'true');
    }
  }

  function applyCardHiddenState(card) {
    if (!card) {
      return;
    }
    var id = getCardId(card);
    var hidden = isCardHidden(id);
    if (isCardHideLocked(card)) {
      hidden = false;
      if (id && hiddenCardIds[id]) {
        delete hiddenCardIds[id];
      }
    }
    var inEdit =
      layoutEditOn ||
      document.body.classList.contains('yp-icon-edit-mode') ||
      document.documentElement.classList.contains('yp-icon-edit-mode');

    /* Avoid data-hidden in edit mode — yp-dashboard.css hides [data-hidden="true"] with display:none */
    if (hidden && inEdit) {
      card.removeAttribute('data-hidden');
    } else if (hidden) {
      card.setAttribute('data-hidden', 'true');
    } else {
      card.removeAttribute('data-hidden');
    }

    card.classList.toggle('is-dashboard-card-hidden', hidden);
    if (inEdit) {
      card.removeAttribute('aria-disabled');
    } else {
      card.setAttribute('aria-disabled', hidden ? 'true' : 'false');
    }

    syncCardEditInteraction(card);

    var toggle = card.querySelector('.yp-card-visibility-toggle');
    if (toggle) {
      var icon = toggle.querySelector('.dashicons');
      if (icon) {
        icon.className =
          'dashicons ' + (hidden ? 'dashicons-visibility' : 'dashicons-hidden');
      }
      toggle.setAttribute(
        'aria-label',
        hidden ? t('showCard', 'Show card') : t('hideCard', 'Hide card')
      );
      toggle.setAttribute('aria-pressed', hidden ? 'true' : 'false');
      toggle.classList.toggle('is-active', hidden);
    }
  }

  function applyAllHiddenStates() {
    root.querySelectorAll('[data-card-id]').forEach(applyCardHiddenState);
  }

  function toggleCardVisibility(card) {
    if (isCardHideLocked(card)) {
      return;
    }
    var id = getCardId(card);
    if (!id) {
      return;
    }
    if (!hiddenCardIds[id]) {
      var section = card.closest('.yp-dashboard-section[data-section-id]');
      if (
        section &&
        (isWorkspaceGrid(getSectionGrid(section)) || isNetworkWorkspaceGrid(getSectionGrid(section))) &&
        countVisibleCards(section) <= WORKSPACE_MIN_ITEMS
      ) {
        showWorkspaceToast(
          t(
            'workspaceMinItemsToast',
            'This section requires at least 3 items.'
          )
        );
        return;
      }
    }
    if (hiddenCardIds[id]) {
      delete hiddenCardIds[id];
    } else {
      hiddenCardIds[id] = true;
    }
    root.querySelectorAll('[data-card-id]').forEach(function (node) {
      if (getCardId(node) === id) {
        applyCardHiddenState(node);
      }
    });
    saveLayoutNow({ serverImmediate: true });
    refreshSectionVisibility();
  }

  function ensureCardEditActions(card) {
    var wrap = card.querySelector('.yp-studio-card-edit-actions');
    if (!wrap) {
      wrap = document.createElement('span');
      wrap.className = 'yp-studio-card-edit-actions';
      card.appendChild(wrap);
    }
    var iconEdit = card.querySelector('.yp-card-icon-edit');
    if (iconEdit && iconEdit.parentNode !== wrap) {
      wrap.appendChild(iconEdit);
    }
    return wrap;
  }

  function ensureVisibilityToggle(card) {
    if (isCardHideLocked(card)) {
      card.classList.add('yp-card-hide-locked');
      var lockedActions = ensureCardEditActions(card);
      var existing = card.querySelector('.yp-card-visibility-toggle');
      if (existing && existing.parentNode) {
        existing.parentNode.removeChild(existing);
      }
      if (lockedActions) {
        lockedActions.classList.add('yp-studio-card-edit-actions--locked');
      }
      return;
    }
    card.classList.remove('yp-card-hide-locked');
    var actions = ensureCardEditActions(card);
    actions.classList.remove('yp-studio-card-edit-actions--locked');
    var toggle = card.querySelector('.yp-card-visibility-toggle');
    if (!toggle) {
      toggle = document.createElement('span');
      toggle.className = 'yp-card-visibility-toggle';
      toggle.setAttribute('role', 'button');
      toggle.setAttribute('tabindex', '0');
      toggle.innerHTML = '<span class="dashicons dashicons-hidden" aria-hidden="true"></span>';
      actions.insertBefore(toggle, actions.firstChild);

      toggle.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        toggleCardVisibility(card);
      });
      toggle.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          e.stopPropagation();
          toggleCardVisibility(card);
        }
      });
    } else if (toggle.parentNode !== actions) {
      actions.insertBefore(toggle, actions.firstChild);
    }
    applyCardHiddenState(card);
  }

  function sectionHasWidgets(section) {
    var widgets = section.querySelector('.yp-studio-extensions-widgets');
    if (!widgets) {
      return false;
    }
    return widgets.children.length > 0 || (widgets.textContent || '').trim() !== '';
  }

  function sectionIsEmpty(section) {
    if (!section) {
      return true;
    }
    if (countCards(section) > 0) {
      return false;
    }
    return !sectionHasWidgets(section);
  }

  function isCustomSection(section) {
    return !!(section && section.classList.contains('yp-studio-custom-section'));
  }

  function isWidgetSection(section) {
    return !!(section && section.classList.contains('yp-studio-widget-section'));
  }

  function layoutRestBase() {
    return String(layoutRestUrl || '').replace(/\/$/, '');
  }

  function layoutRestRequest(path) {
    var base = layoutRestBase();
    if (!base || !layoutRestNonce) {
      return Promise.reject({ code: 'missing_layout_rest_config' });
    }
    return fetch(base + path, {
      method: 'GET',
      credentials: 'same-origin',
      headers: { 'X-WP-Nonce': layoutRestNonce },
    }).then(function (res) {
      if (!res.ok) {
        return res.json().then(function (body) {
          var err = new Error('rest_error');
          err.responseJSON = body;
          err.status = res.status;
          throw err;
        });
      }
      return res.json();
    });
  }

  function layoutAjaxPost(action, data) {
    var restBase = layoutRestBase();
    if (restBase && layoutRestNonce) {
      if (action === 'yooadmin_studio_hub_dashboard_widgets_catalog') {
        return layoutRestRequest('/studio-hub/widgets').then(function (body) {
          return { success: true, data: { widgets: body.widgets || [] } };
        });
      }
      if (action === 'yooadmin_studio_hub_render_dashboard_widget' && data && data.widget_id) {
        return layoutRestRequest(
          '/studio-hub/widgets/' + encodeURIComponent(data.widget_id) + '/render'
        ).then(function (body) {
          return {
            success: true,
            data: {
              html: typeof body.html === 'string' ? body.html : '',
              assets: body.assets && typeof body.assets === 'object' ? body.assets : null,
            },
          };
        });
      }
    }

    var payload = Object.assign(
      {
        action: action,
        nonce: widgetAjaxNonce || layoutNonce,
      },
      data || {}
    );

    if (!layoutAjaxUrl || !(widgetAjaxNonce || layoutNonce)) {
      return Promise.reject({ code: 'missing_layout_ajax_config' });
    }

    if (window.jQuery) {
      return window.jQuery.ajax({
        url: layoutAjaxUrl,
        method: 'POST',
        dataType: 'json',
        data: payload,
      });
    }

    return fetch(layoutAjaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: new URLSearchParams(payload).toString(),
    }).then(function (res) {
      return res.json();
    });
  }

  function dashboardRedirectHomeUrl(enabled) {
    if (enabled) {
      return layoutCfg.yooadminDashboardUrl || '';
    }

    return layoutCfg.wpDashboardUrl || '';
  }

  function syncDashboardRedirectHomeLinks(enabled, homeUrl) {
    var target = homeUrl || dashboardRedirectHomeUrl(enabled);
    if (!target) {
      return;
    }

    document
      .querySelectorAll('.yp-logo-link, .yp-breadcrumbs .yp-bc-item.is-home .yp-bc-link')
      .forEach(function (link) {
        link.setAttribute('href', target);
      });
  }

  function setDashboardRedirect(enabled) {
    return layoutAjaxPost('yooadmin_studio_hub_set_dashboard_redirect', {
      enabled: enabled ? '1' : '0',
    });
  }

  function parseAjaxResponseBody(xhr) {
    if (!xhr) {
      return null;
    }
    if (xhr.responseJSON && typeof xhr.responseJSON === 'object') {
      return xhr.responseJSON;
    }
    if (!xhr.responseText) {
      return null;
    }
    try {
      return JSON.parse(xhr.responseText);
    } catch (e) {
      return null;
    }
  }

  function widgetAjaxErrorMessage(res, xhr) {
    var parsed = res || parseAjaxResponseBody(xhr);
    if (parsed && parsed.data && parsed.data.message) {
      return parsed.data.message;
    }
    if (xhr && xhr.status === 0) {
      return t('widgetNetworkFailed', 'Network error while loading the widget.');
    }
    if (!layoutNonce) {
      return t('widgetNonceFailed', 'Session expired. Reload the page and try again.');
    }
    return t('widgetLoadFailed', 'Could not load widget.');
  }

  function removeAddSectionModal() {
    if (addSectionModalEl && addSectionModalEl.parentNode) {
      addSectionModalEl.parentNode.removeChild(addSectionModalEl);
    }
    addSectionModalEl = null;
    pendingWidgetMeta = null;
    refreshCatalogListCallback = null;
    document.body.classList.remove('yp-studio-add-section-open');
  }

  function cardMatchesDashboardScope(widget) {
    if (!widget) {
      return false;
    }
    var scopes = widget.scopes;
    var want = isNetworkDashboard() ? 'network' : 'site';
    if (!scopes || !scopes.length) {
      return want === 'site';
    }
    for (var si = 0; si < scopes.length; si++) {
      if (scopes[si] === want) {
        return true;
      }
    }
    return false;
  }

  function fetchWidgetCatalog(forceRefresh) {
    if (widgetCatalogCache && !forceRefresh) {
      return Promise.resolve(widgetCatalogCache);
    }
    return layoutAjaxPost('yooadmin_studio_hub_dashboard_widgets_catalog', {}).then(function (
      res
    ) {
      if (!res || !res.success || !res.data || !Array.isArray(res.data.widgets)) {
        return [];
      }
      widgetCatalogCache = res.data.widgets;
      return widgetCatalogCache;
    });
  }

  function nextWidgetSectionId(placement) {
    widgetSectionSeq += 1;
    return 'widget-' + placement + '-' + Date.now() + '-' + widgetSectionSeq;
  }

  function getCardIdFromSection(section) {
    if (!section) {
      return '';
    }
    var widgetId = section.getAttribute('data-widget-id') || '';
    if (widgetId) {
      return widgetId;
    }
    var sectionId = section.getAttribute('data-section-id') || '';
    return BUILTIN_CARD_IDS[sectionId] ? sectionId : '';
  }

  function isBuiltInSectionId(id) {
    return !!(id && id !== 'from-extensions' && BUILTIN_CARD_IDS[id]);
  }

  function isRemovedBuiltInSectionId(id) {
    return !!(id && removedBuiltInSectionIds[id]);
  }

  function loadRemovedBuiltInSectionsFromData(data) {
    removedBuiltInSectionIds = {};
    var ids = [];
    if (data && Array.isArray(data.removedBuiltInSections)) {
      ids = data.removedBuiltInSections.slice();
    } else if (!layoutHasUserSectionVisibility(data)) {
      ids = DEFAULT_REMOVED_BUILTIN_SECTIONS.slice();
    }
    ids.forEach(function (id) {
      if (isBuiltInSectionId(id)) {
        removedBuiltInSectionIds[id] = true;
      }
    });
    applyRemovedBuiltInSectionsToDom();
  }

  function getRemovedBuiltInSectionIdList() {
    return Object.keys(removedBuiltInSectionIds).filter(isBuiltInSectionId);
  }

  function loadRemovedWidgetIdsFromData(data) {
    removedWidgetIds = {};
    if (!data || !Array.isArray(data.removedWidgetIds)) {
      return;
    }
    data.removedWidgetIds.forEach(function (id) {
      if (id) {
        removedWidgetIds[id] = true;
      }
    });
  }

  function getRemovedWidgetIdList() {
    return Object.keys(removedWidgetIds);
  }

  function findSectionsForCardId(cardId) {
    var found = [];
    if (!cardId) {
      return found;
    }
    root.querySelectorAll('.yp-dashboard-section').forEach(function (section) {
      if (getCardIdFromSection(section) === cardId) {
        found.push(section);
      }
    });
    return found;
  }

  function isCardPresentOnDashboard(cardId) {
    return findSectionsForCardId(cardId).length > 0;
  }

  function removeCardFromDashboard(cardId) {
    if (!cardId) {
      return;
    }
    var sections = findSectionsForCardId(cardId);
    if (!sections.length) {
      return;
    }
    sections.forEach(function (section) {
      if (isWidgetSection(section)) {
        removeWidgetSection(section);
      } else if (isBuiltInSectionId(getSectionId(section))) {
        removeBuiltInSection(section);
      }
    });
    pinAddButtonsToColumnEnd();
    refreshSectionVisibility();
    syncLayoutColumns();
    saveLayoutNow();
    refreshAddSectionCatalogIfOpen();
  }

  function catalogToggleBuiltinCard(cardId) {
    if (!cardId) {
      return;
    }
    findSectionsForCardId(cardId).forEach(function (section) {
      if (isSectionHideAllowed(section)) {
        toggleSectionVisibility(section);
      }
    });
    refreshSectionVisibility();
    syncLayoutColumns();
    saveLayoutNow();
    refreshAddSectionCatalogIfOpen();
  }

  function refreshAddSectionCatalogIfOpen() {
    if (typeof refreshCatalogListCallback === 'function') {
      refreshCatalogListCallback();
    }
  }

  function widgetSectionLoadingMarkup() {
    return (
      '<div class="yp-studio-widget-section__loading" role="status" aria-live="polite">' +
      '<div class="yp-loading-spinner" aria-hidden="true"><div class="yp-spinner-circle"></div></div>' +
      '<span class="screen-reader-text">' +
      escapeHtml(t('widgetLoading', 'Loading widget…')) +
      '</span></div>'
    );
  }

  function buildWidgetSection(sectionId, placement, meta) {
    var widgetId = meta && meta.widgetId ? meta.widgetId : '';
    var title = resolveWidgetSectionTitle(widgetId, meta && meta.title ? meta.title : '');
    var icon = normalizeDashicon((meta && meta.icon) || 'dashicons-admin-generic');

    var section = document.createElement('div');
    section.className =
      'yp-card yp-card-full yp-dashboard-section yp-studio-surface-card yp-studio-widget-section';
    if (widgetId === 'studio-updates') {
      section.className += ' yp-studio-widget-section--studio-updates';
    }
    if (widgetId === 'studio-login-security') {
      section.className += ' yp-studio-widget-section--studio-login-security';
    }
    section.setAttribute('data-section-id', sectionId);
    section.setAttribute('data-layout-section', 'true');
    section.setAttribute('data-section-type', 'widget');
    section.setAttribute('data-widget-id', widgetId);
    section.setAttribute('data-collapsible', 'false');
    section.setAttribute('data-sortable', 'true');
    section.setAttribute('data-collapsed', 'false');
    section.setAttribute('data-custom-placement', placement);
    section.setAttribute('data-section-title', title);
    section.setAttribute('data-default-section-icon', icon);

    section.innerHTML =
      '<div class="yp-card-header yp-section-header yp-layout-section-handle">' +
      '<span class="yp-section-header__edit-controls">' +
      '<span class="yp-layout-section-drag-handle" aria-hidden="true">' +
      '<span class="dashicons dashicons-move" aria-hidden="true"></span></span>' +
      '</span>' +
      '<h2 class="yp-card-title yp-section-title">' +
      '<span class="yp-section-title-icon-wrap">' +
      '<span class="yp-section-title-icon dashicons ' +
      icon +
      '" aria-hidden="true"></span>' +
      '</span>' +
      '<span class="yp-section-title-label">' +
      escapeHtml(title) +
      '</span>' +
      '</h2>' +
      '<div class="yp-card-header-actions">' +
      '<button type="button" class="yp-layout-section-remove" aria-label="' +
      escapeHtml(t('removeSection', 'Remove section')) +
      '">' +
      '<span class="dashicons dashicons-trash" aria-hidden="true"></span>' +
      '</button>' +
      '</div>' +
      '</div>' +
      '<div class="yp-studio-widget-section__body" data-widget-body="true">' +
      widgetSectionLoadingMarkup() +
      '</div>';

    return section;
  }

  var injectedWidgetAssetKeys = {};
  var LOGIN_SECURITY_RING_MS = 1000;

  function animateLoginSecurityScoreWidget(root) {
    var scope = root && root.nodeType === 1 ? root : document;
    var widgets = scope.querySelectorAll('[data-studio-login-security-widget="true"]');
    if (
      !widgets.length &&
      scope.getAttribute &&
      scope.getAttribute('data-studio-login-security-widget') === 'true'
    ) {
      widgets = [scope];
    }

    Array.prototype.forEach.call(widgets, function (widget) {
      if (widget.getAttribute('data-security-score-animated') === '1') {
        return;
      }
      widget.setAttribute('data-security-score-animated', '1');

      var percent = parseInt(widget.getAttribute('data-score-percent'), 10);
      if (isNaN(percent)) {
        var valueProbe = widget.querySelector('[data-score-value]');
        percent = valueProbe ? parseInt(valueProbe.textContent, 10) || 0 : 0;
      }
      percent = Math.max(0, Math.min(100, percent));

      var circumference = parseInt(widget.getAttribute('data-ring-c'), 10) || 264;
      var bar = widget.querySelector('[data-ring-bar]');
      var value = widget.querySelector('[data-score-value]');
      var ring = widget.querySelector('[data-security-score-ring]');
      if (!bar || !value) {
        return;
      }

      var targetOffset = circumference - (percent / 100) * circumference;
      var prefersReducedMotion = false;
      try {
        prefersReducedMotion =
          window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      } catch (motionMqErr) {
        prefersReducedMotion = false;
      }

      if (prefersReducedMotion) {
        if (ring) {
          ring.classList.remove('is-animating');
        }
        bar.setAttribute('stroke-dashoffset', String(targetOffset));
        value.textContent = String(percent);
        return;
      }

      var startTs = null;

      function setOffset(offset) {
        bar.setAttribute('stroke-dashoffset', String(offset));
      }

      function finish() {
        if (ring) {
          ring.classList.remove('is-animating');
        }
        setOffset(targetOffset);
        value.textContent = String(percent);
      }

      function frame(ts) {
        if (!startTs) {
          startTs = ts;
        }
        var t = Math.min(1, (ts - startTs) / LOGIN_SECURITY_RING_MS);
        var eased = 1 - Math.pow(1 - t, 3);
        var current = Math.round(percent * eased);
        setOffset(circumference - (current / 100) * circumference);
        value.textContent = String(current);
        if (t < 1) {
          window.requestAnimationFrame(frame);
        } else {
          finish();
        }
      }

      if (ring) {
        ring.classList.add('is-animating');
      }
      setOffset(circumference);
      value.textContent = '0';
      window.requestAnimationFrame(frame);
    });
  }

  function injectWidgetAssetMarkup(markup, cacheKey, target) {
    if (!markup || !cacheKey || injectedWidgetAssetKeys[cacheKey]) {
      return;
    }
    var host = target === 'body' ? document.body : document.head;
    if (!host) {
      return;
    }
    var wrap = document.createElement('div');
    wrap.innerHTML = markup;
    var node;
    while ((node = wrap.firstChild)) {
      if (node.tagName === 'SCRIPT') {
        var script = document.createElement('script');
        if (node.src) {
          script.src = node.src;
        } else {
          script.textContent = node.textContent || '';
        }
        if (node.id) {
          script.id = node.id;
        }
        document.body.appendChild(script);
      } else {
        host.appendChild(node);
      }
    }
    injectedWidgetAssetKeys[cacheKey] = true;
  }

  function applyWidgetRenderPayload(body, widgetId, payload) {
    if (!body || !payload) {
      return;
    }
    var assets = payload.assets;
    if (assets) {
      if (assets.styles) {
        injectWidgetAssetMarkup(assets.styles, 'styles:' + widgetId, 'head');
      }
      if (assets.scripts) {
        injectWidgetAssetMarkup(assets.scripts, 'scripts:' + widgetId, 'body');
      }
    }
    if (typeof payload.html === 'string') {
      if (body.getAttribute('data-replace-widget-body') === 'true' && body.parentNode) {
        var parent = body.parentNode;
        var wrap = document.createElement('div');
        var firstInserted = null;
        wrap.innerHTML = payload.html;
        while (wrap.firstChild) {
          var node = wrap.firstChild;
          if (!firstInserted && node.nodeType === 1) {
            firstInserted = node;
          }
          parent.insertBefore(node, body);
        }
        parent.removeChild(body);
        body = firstInserted || parent;
      } else {
      body.innerHTML = payload.html;
      body.classList.add('is-loaded');
      }
      if (window.jQuery) {
        window.jQuery(document).trigger('postbox-added');
      }
      if (typeof window.yooadminStudioHubInitTipsCarousels === 'function') {
        window.yooadminStudioHubInitTipsCarousels();
      }
      if (typeof window.yooadminInitWorkspaceNotes === 'function') {
        window.yooadminInitWorkspaceNotes();
      }
      if (typeof window.yooadminStudioHubInitUpdatesWidget === 'function') {
        window.yooadminStudioHubInitUpdatesWidget();
      }
      if (widgetId === 'studio-login-security') {
        animateLoginSecurityScoreWidget(body);
      }
      if (
        widgetId === 'yooadmin_overview'
        && window.YOOAdminOverviewWidget
        && typeof window.YOOAdminOverviewWidget.init === 'function'
      ) {
        window.YOOAdminOverviewWidget.init(body);
      } else if (widgetId === 'yooadmin_overview') {
        try {
          document.dispatchEvent(new CustomEvent('yooadmin-overview-widget-loaded'));
        } catch (overviewInitErr) {
          /* ignore */
        }
      }
      try {
        document.dispatchEvent(
          new CustomEvent('yooadmin-studio-hub-widget-rendered', {
            detail: { widgetId: widgetId, body: body },
          })
        );
      } catch (e) {
        /* ignore */
      }
    }
  }

  function loadWidgetSectionBody(section) {
    if (!section) {
      return Promise.resolve();
    }
    var widgetId = section.getAttribute('data-widget-id') || '';
    var body = section.querySelector('[data-widget-body]');
    if (!widgetId || !body) {
      return Promise.resolve();
    }

    return layoutAjaxPost('yooadmin_studio_hub_render_dashboard_widget', {
      widget_id: widgetId,
    })
      .then(function (res) {
        if (res && res.success && res.data && typeof res.data.html === 'string') {
          applyWidgetRenderPayload(body, widgetId, res.data);
          return;
        }
        body.innerHTML =
          '<p class="yp-studio-widget-section__error">' +
          escapeHtml(widgetAjaxErrorMessage(res, null)) +
          '</p>';
      })
      .catch(function (xhr) {
        var err =
          xhr && xhr.code === 'missing_layout_ajax_config'
            ? t('widgetNonceFailed', 'Session expired. Reload the page and try again.')
            : widgetAjaxErrorMessage(null, xhr);
        body.innerHTML =
          '<p class="yp-studio-widget-section__error">' + escapeHtml(err) + '</p>';
      });
  }

  function insertWidgetSectionElement(section, placement) {
    if (placement === 'aside') {
      insertAsideSection(section);
    } else if (mainAddBtn && mainAddBtn.parentNode === mainEl) {
      mainEl.insertBefore(section, mainAddBtn);
    } else {
      mainEl.appendChild(section);
    }
  }

  function getBuiltInSectionConfig(cardId, meta) {
    var title = (meta && meta.title) || '';
    var icon = normalizeDashicon((meta && meta.icon) || '');
    var configs = {
      'studio-workspace-notes': {
        className:
          'yp-studio-aside-card yp-dashboard-section yp-studio-aside-layout-section yp-studio-workspace-notes-card',
        icon: icon || 'dashicons-book-alt',
        title: title || t('workspaceNotes', 'Workspace Notes'),
        titleTextClass: 'yp-studio-aside-section__title-label',
        extraAttrs: {
          'data-workspace-notes': 'true',
        },
      },
      'studio-tips': {
        className:
          'yp-studio-aside-card yp-studio-aside-card--tips yp-dashboard-section yp-studio-aside-layout-section',
        headerClass: 'yp-studio-tips-section__header',
        titleClass: 'yp-studio-tips-section__title',
        titleTextClass: 'yp-studio-tips-section__title-text yp-studio-aside-section__title-label',
        icon: icon || 'dashicons-lightbulb',
        title: title || t('tips', 'Tips'),
      },
      'studio-activity': {
        className: 'yp-studio-aside-card yp-dashboard-section yp-studio-aside-layout-section',
        icon: icon || 'dashicons-megaphone',
        title: title || t('activity', 'Activity'),
        titleTextClass: 'yp-studio-aside-section__title-label',
      },
      'studio-updates': {
        className:
          'yp-studio-aside-card yp-studio-aside-card--updates yp-dashboard-section yp-studio-aside-layout-section',
        icon: icon || 'dashicons-update',
        title: title || t('updates', 'Updates'),
        titleTextClass: 'yp-studio-aside-section__title-label',
      },
    };
    return configs[cardId] || null;
  }

  function buildBuiltInAsideSection(cardId, meta) {
    var cfg = getBuiltInSectionConfig(cardId, meta);
    if (!cfg) {
      return null;
    }
    var section = document.createElement('div');
    section.className = cfg.className;
    section.setAttribute('data-section-id', cardId);
    section.setAttribute('data-layout-section', 'true');
    section.setAttribute('data-collapsible', 'false');
    section.setAttribute('data-sortable', 'true');
    section.setAttribute('data-collapsed', 'false');
    section.setAttribute('data-custom-placement', 'aside');
    section.setAttribute('data-widget-id', cardId);
    section.setAttribute('data-native-builtin-section', 'true');
    Object.keys(cfg.extraAttrs || {}).forEach(function (key) {
      section.setAttribute(key, cfg.extraAttrs[key]);
    });

    var titleText = cfg.titleTextClass
      ? '<span class="' + escapeHtml(cfg.titleTextClass) + '">' + escapeHtml(cfg.title) + '</span>'
      : escapeHtml(cfg.title);

    section.innerHTML =
      '<div class="yp-card-header yp-section-header yp-layout-section-handle' +
      (cfg.headerClass ? ' ' + escapeHtml(cfg.headerClass) : '') +
      '">' +
      '<span class="yp-layout-section-drag-handle" aria-hidden="true">' +
      '<span class="dashicons dashicons-move" aria-hidden="true"></span>' +
      '</span>' +
      '<h2 class="yp-card-title yp-section-title yp-studio-aside-section__title' +
      (cfg.titleClass ? ' ' + escapeHtml(cfg.titleClass) : '') +
      '">' +
      '<span class="dashicons ' +
      escapeHtml(cfg.icon) +
      '" aria-hidden="true"></span>' +
      titleText +
      '</h2>' +
      '<div class="yp-card-header-actions">' +
      '<button type="button" class="yp-layout-section-remove" aria-label="' +
      escapeHtml(t('removeSection', 'Remove section')) +
      '" aria-hidden="true">' +
      '<span class="dashicons dashicons-trash" aria-hidden="true"></span>' +
      '</button>' +
      '</div>' +
      '</div>' +
      '<div class="yp-studio-native-builtin-loading" data-widget-body="true" data-replace-widget-body="true">' +
      widgetSectionLoadingMarkup() +
      '</div>';

    return section;
  }

  function addBuiltInSection(placement, meta) {
    var cardId = meta && meta.widgetId ? meta.widgetId : '';
    if (!isBuiltInSectionId(cardId)) {
      return false;
    }
    if (isCardPresentOnDashboard(cardId)) {
      showWorkspaceToast(
        t('cardAlreadyOnDashboard', 'This card is already on your dashboard.')
      );
      return true;
    }

    var section = removedBuiltInSectionCache[cardId] || buildBuiltInAsideSection(cardId, meta);
    if (!section) {
      return false;
    }
    delete removedBuiltInSectionCache[cardId];
    delete removedBuiltInSectionIds[cardId];
    delete hiddenSectionIds[cardId];
    section.removeAttribute('data-section-hidden');
    section.classList.remove('is-dashboard-section-hidden', 'yp-layout-section--hidden');
    section.removeAttribute('hidden');
    insertAsideSection(section);
    bindSection(section);
    if (section.querySelector('[data-widget-body]')) {
      loadWidgetSectionBody(section);
    }
    pinAddButtonsToColumnEnd();
    refreshSectionVisibility();
    updateAllSectionsDraggable();
    syncLayoutColumns();
    saveLayoutNow({ serverImmediate: true });
    refreshAddSectionCatalogIfOpen();
    return true;
  }

  function ensureFactoryBuiltInSections() {
    getFactoryAsideOrder().forEach(function (cardId) {
      if (!isBuiltInSectionId(cardId)) {
        return;
      }
      if (root.querySelector('[data-section-id="' + cardId + '"]')) {
        return;
      }
      addBuiltInSection('aside', { widgetId: cardId });
    });
  }

  function ensureDefaultWidgetSections() {
    var defaults = getDefaultWidgetSections();
    Object.keys(defaults).forEach(function (sectionId) {
      if (root.querySelector('[data-section-id="' + sectionId + '"]')) {
        return;
      }
      var meta = defaults[sectionId];
      if (meta && meta.widgetId && removedWidgetIds[meta.widgetId]) {
        return;
      }
      var section = buildWidgetSection(sectionId, meta.placement || 'aside', meta);
      insertWidgetSectionElement(section, meta.placement || 'aside');
      bindSection(section);
      loadWidgetSectionBody(section);
    });
  }

  function addWidgetSection(placement, meta) {
    if (!meta || !meta.widgetId) {
      return;
    }
    if (meta.widgetId) {
      delete removedWidgetIds[meta.widgetId];
    }
    if (isBuiltInSectionId(meta.widgetId) && addBuiltInSection(placement, meta)) {
      return;
    }
    if (isNetworkDashboard()) {
      var allowed = networkLayoutCfg.allowedCardIds;
      if (!Array.isArray(allowed) || allowed.indexOf(meta.widgetId) === -1) {
        showWorkspaceToast(
          t(
            'networkCardOnly',
            'Only network dashboard cards can be added here.'
          )
        );
        return;
      }
    }
    if (isCardPresentOnDashboard(meta.widgetId)) {
      showWorkspaceToast(
        t('cardAlreadyOnDashboard', 'This card is already on your dashboard.')
      );
      return;
    }
    var id = nextWidgetSectionId(placement === 'aside' ? 'aside' : 'main');
    var section = buildWidgetSection(id, placement, meta);
    insertWidgetSectionElement(section, placement);
    bindSection(section);
    loadWidgetSectionBody(section);
    pinAddButtonsToColumnEnd();
    refreshSectionVisibility();
    updateAllSectionsDraggable();
    saveLayoutNow();
    refreshAddSectionCatalogIfOpen();
  }

  function removeWidgetSection(section) {
    if (!section || !isWidgetSection(section)) {
      return;
    }
    var widgetId = section.getAttribute('data-widget-id') || '';
    if (widgetId) {
      removedWidgetIds[widgetId] = true;
    }
    if (section.parentNode) {
      section.parentNode.removeChild(section);
    }
    saveLayoutNow({ serverImmediate: true });
    refreshSectionVisibility();
  }

  function removeBuiltInSection(section) {
    var id = getSectionId(section);
    if (!isBuiltInSectionId(id)) {
      return;
    }
    removedBuiltInSectionIds[id] = true;
    delete hiddenSectionIds[id];
    if (section && section.parentNode) {
      removedBuiltInSectionCache[id] = section;
      section.parentNode.removeChild(section);
    }
    pinAddButtonsToColumnEnd();
    refreshSectionVisibility();
    syncLayoutColumns();
    saveLayoutNow({ serverImmediate: true });
    refreshAddSectionCatalogIfOpen();
  }

  function removeRemovableSection(section) {
    if (isCustomSection(section)) {
      removeCustomSection(section);
    } else if (isWidgetSection(section)) {
      removeWidgetSection(section);
    } else {
      removeBuiltInSection(section);
    }
  }

  function openAddSectionModal(defaultPlacement) {
    removeAddSectionModal();
    pendingWidgetMeta = null;
    document.body.classList.add('yp-studio-add-section-open');

    var html =
      '<div id="yp-studio-add-section-modal" class="yp-alert-modal yp-alert-modal--focus yp-studio-add-section-modal" role="dialog" aria-modal="true" aria-labelledby="yp-studio-add-section-title">' +
      '<div class="yp-alert-overlay" data-add-section-close></div>' +
      '<div class="yp-alert-content yp-studio-add-section-modal__content">' +
      '<div class="yp-alert-header">' +
      '<h2 id="yp-studio-add-section-title" class="yp-alert-title">' +
      escapeHtml(t('addSectionTitle', 'Add to dashboard')) +
      '</h2>' +
      '</div>' +
      '<div class="yp-alert-body yp-studio-add-section-modal__body">' +
      '<div class="yp-studio-add-section-modal__choices">' +
      '<button type="button" class="yp-studio-add-section-choice" data-add-section-choice="custom">' +
      '<span class="dashicons dashicons-screenoptions" aria-hidden="true"></span>' +
      '<span class="yp-studio-add-section-choice__text">' +
      '<strong>' +
      escapeHtml(t('addSectionCustom', 'Custom section')) +
      '</strong>' +
      '<span>' +
      escapeHtml(
        t(
          'addSectionCustomHint',
          'Empty section for your tiles. Drag cards from other sections.'
        )
      ) +
      '</span></span></button>' +
      '<button type="button" class="yp-studio-add-section-choice" data-add-section-choice="card">' +
      '<span class="dashicons dashicons-admin-plugins" aria-hidden="true"></span>' +
      '<span class="yp-studio-add-section-choice__text">' +
      '<strong>' +
      escapeHtml(t('addSectionCards', 'Dashboard card')) +
      '</strong>' +
      '<span>' +
      escapeHtml(
        t(
          'addSectionCardsHint',
          'Cards registered by plugins for YOOAdmin Studio Hub.'
        )
      ) +
      '</span></span></button>' +
      (isNetworkDashboard()
        ? ''
        : '<button type="button" class="yp-studio-add-section-choice" data-add-section-choice="legacy">' +
          '<span class="dashicons dashicons-wordpress" aria-hidden="true"></span>' +
          '<span class="yp-studio-add-section-choice__text">' +
          '<strong>' +
          escapeHtml(t('addSectionWidgets', 'WordPress widget')) +
          '</strong>' +
          '<span>' +
          escapeHtml(
            t(
              'addSectionWidgetsHint',
              'Classic WordPress dashboard widgets are not available in Studio Hub.'
            )
          ) +
          '</span></span></button>' +
          '<div class="yp-studio-add-section-modal__legacy-inline" data-add-section-legacy-inline data-yp-banner-ignore="1" role="note" hidden>' +
          '<div class="yp-studio-hub-info-notice__inner">' +
          '<span class="yp-studio-hub-info-notice__icon dashicons dashicons-info-outline" aria-hidden="true"></span>' +
          '<div class="yp-studio-hub-info-notice__content">' +
          '<p class="yp-studio-hub-info-notice__title">' +
          escapeHtml(t('legacyWidgetTitle', 'Classic WordPress dashboard widgets are not available in Studio Hub.')) +
          '</p>' +
          '<p class="yp-studio-hub-info-notice__text">' +
          escapeHtml(
            t(
              'legacyWidgetBody',
              'YOOAdmin dashboard cards provide a cleaner, more modern workspace experience built for Studio Hub.'
            )
          ) +
          '</p>' +
          '<p class="yp-studio-hub-info-notice__link"><a href="' +
          escapeHtml(t('developerDocsUrl', 'https://www.yooadmin.io/kb-category/for-developers/')) +
          '" target="_blank" rel="noopener noreferrer">' +
          escapeHtml(t('legacyWidgetDocLink', 'Developer guide on yooadmin.io')) +
          '</a></p>' +
          (canManageSiteSettings
            ? '<div class="yp-studio-dashboard-redirect-toggle" data-dashboard-redirect-control>' +
              '<label class="yp-studio-dashboard-redirect-toggle__label">' +
              '<span class="yp-studio-dashboard-redirect-toggle__text">' +
              escapeHtml(t('dashboardRedirectLabel', 'Dashboard Redirect')) +
              '</span>' +
              '<input type="checkbox" role="switch" data-dashboard-redirect-toggle ' +
              (dashboardRedirectEnabled ? 'checked ' : '') +
              'aria-label="' +
              escapeHtml(t('dashboardRedirectLabel', 'Dashboard Redirect')) +
              '" />' +
              '<span class="yp-studio-dashboard-redirect-toggle__switch" aria-hidden="true"></span>' +
              '</label>' +
              '<p class="yp-studio-dashboard-redirect-toggle__hint">' +
              escapeHtml(
                t(
                  'dashboardRedirectHint',
                  'Turn this off if you want the Home button to open the classic WordPress Dashboard.'
                )
              ) +
              '</p>' +
              '<p class="yp-studio-dashboard-redirect-toggle__status" data-dashboard-redirect-status aria-live="polite"></p>' +
              '</div>'
            : '') +
          '</div></div></div>') +
      '</div>' +
      '<div class="yp-studio-add-section-modal__panel" data-add-section-panel="card" hidden>' +
      '<input type="search" class="yp-studio-add-section-modal__search" data-widget-search placeholder="' +
      escapeHtml(t('widgetsSearch', 'Search widgets…')) +
      '" autocomplete="off" />' +
      '<div class="yp-studio-add-section-modal__widget-list" data-widget-list>' +
      '<p class="yp-studio-add-section-modal__loading">' +
      escapeHtml(t('widgetsLoading', 'Loading widgets…')) +
      '</p></div>' +
      '</div>' +
      '<div class="yp-studio-add-section-modal__panel" data-add-section-panel="place" hidden>' +
      '<p class="yp-alert-message yp-studio-add-section-modal__place-hint">' +
      escapeHtml(
        t(
          'placeWidgetHint',
          'Choose a column. The widget will use the full width of that column.'
        )
      ) +
      '</p>' +
      '</div>' +
      '</div>' +
      '<div class="yp-alert-footer">' +
      '<div class="yp-studio-add-section-modal__place-footer" data-add-section-place-footer hidden>' +
      '<button type="button" class="yp-alert-btn yp-alert-btn-primary yp-studio-add-section-place-btn" data-place-widget="main">' +
      escapeHtml(t('placeMain', 'Main column')) +
      '</button>' +
      '<button type="button" class="yp-alert-btn yp-alert-btn-secondary yp-studio-add-section-place-btn" data-place-widget="aside">' +
      escapeHtml(t('placeAside', 'Side column')) +
      '</button>' +
      '</div>' +
      '<button type="button" class="yp-alert-btn yp-alert-btn-secondary" data-add-section-close>' +
      escapeHtml(t('cancel', 'Cancel')) +
      '</button>' +
      '</div>' +
      '</div>' +
      '</div>';

    document.body.insertAdjacentHTML('beforeend', html);
    addSectionModalEl = document.getElementById('yp-studio-add-section-modal');
    if (!addSectionModalEl) {
      return;
    }

    var defaultPl = defaultPlacement === 'aside' ? 'aside' : 'main';

    addSectionModalEl.querySelectorAll('[data-add-section-close]').forEach(function (el) {
      el.addEventListener('click', removeAddSectionModal);
    });

    var cardPanel = addSectionModalEl.querySelector('[data-add-section-panel="card"]');
    var placePanel = addSectionModalEl.querySelector('[data-add-section-panel="place"]');
    var widgetList = addSectionModalEl.querySelector('[data-widget-list]');
    var searchInput = addSectionModalEl.querySelector('[data-widget-search]');
    var modalBody = addSectionModalEl.querySelector('.yp-studio-add-section-modal__body');
    var modalTitle = addSectionModalEl.querySelector('#yp-studio-add-section-title');
    var placeFooter = addSectionModalEl.querySelector('[data-add-section-place-footer]');
    var legacyChoice = addSectionModalEl.querySelector('[data-add-section-choice="legacy"]');

    function setAddSectionPanelHidden(panel, hidden) {
      if (!panel) {
        return;
      }
      if (hidden) {
        panel.setAttribute('hidden', '');
      } else {
        panel.removeAttribute('hidden');
      }
    }

    function clearAddSectionChoiceActive() {
      addSectionModalEl.querySelectorAll('[data-add-section-choice].is-active').forEach(function (el) {
        el.classList.remove('is-active');
        el.setAttribute('aria-pressed', 'false');
      });
    }

    function setPlaceFooterVisible(visible) {
      if (!placeFooter) {
        return;
      }
      if (visible) {
        placeFooter.removeAttribute('hidden');
      } else {
        placeFooter.setAttribute('hidden', '');
      }
    }

    function setAddSectionModalTitle(titleKey, fallback) {
      if (!modalTitle) {
        return;
      }
      modalTitle.textContent = t(titleKey, fallback);
    }

    function hideAllPanels() {
      setAddSectionPanelHidden(cardPanel, true);
      setAddSectionPanelHidden(placePanel, true);
      var legacyInlineNotice = addSectionModalEl.querySelector('[data-add-section-legacy-inline]');
      if (legacyInlineNotice) {
        legacyInlineNotice.setAttribute('hidden', '');
      }
      addSectionModalEl.classList.remove('yp-studio-add-section-modal--card-active');
      addSectionModalEl.classList.remove('yp-studio-add-section-modal--place-active');
      setPlaceFooterVisible(false);
      setAddSectionModalTitle('addSectionTitle', 'Add to dashboard');
      clearAddSectionChoiceActive();
    }

    function showCardPanel() {
      hideAllPanels();
      setAddSectionPanelHidden(cardPanel, false);
      addSectionModalEl.classList.add('yp-studio-add-section-modal--card-active');
      var cardChoice = addSectionModalEl.querySelector('[data-add-section-choice="card"]');
      if (cardChoice) {
        cardChoice.classList.add('is-active');
        cardChoice.setAttribute('aria-pressed', 'true');
      }
    }

    function showLegacyPanel() {
      hideAllPanels();
      var notice = addSectionModalEl.querySelector('[data-add-section-legacy-inline]');
      if (notice) {
        notice.hidden = false;
        notice.removeAttribute('hidden');
        notice.setAttribute('data-yp-banner-ignore', '1');
        notice.style.setProperty('display', 'block', 'important');
        notice.style.setProperty('visibility', 'visible', 'important');
        notice.style.setProperty('opacity', '1', 'important');
        notice.style.setProperty('height', 'auto', 'important');
        notice.querySelectorAll(
          [
            '.yp-studio-hub-info-notice__inner',
            '.yp-studio-hub-info-notice__content',
            '.yp-studio-hub-info-notice__title',
            '.yp-studio-hub-info-notice__text',
            '.yp-studio-hub-info-notice__link',
          ].join(', ')
        ).forEach(function (el) {
          var isInner = el.classList.contains('yp-studio-hub-info-notice__inner');
          el.style.setProperty('display', isInner ? 'flex' : 'block', 'important');
          el.style.setProperty('visibility', 'visible', 'important');
          el.style.setProperty('opacity', '1', 'important');
        });
      }
      if (legacyChoice) {
        legacyChoice.classList.add('is-active');
        legacyChoice.setAttribute('aria-pressed', 'true');
      }
    }

    if (legacyChoice) {
      legacyChoice.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        showLegacyPanel();
      });
    }

    var dashboardRedirectToggle = addSectionModalEl.querySelector('[data-dashboard-redirect-toggle]');
    var dashboardRedirectStatus = addSectionModalEl.querySelector('[data-dashboard-redirect-status]');
    if (dashboardRedirectToggle) {
      dashboardRedirectToggle.checked = dashboardRedirectEnabled;
      dashboardRedirectToggle.addEventListener('change', function () {
        var nextEnabled = !!dashboardRedirectToggle.checked;
        dashboardRedirectToggle.disabled = true;
        if (dashboardRedirectStatus) {
          dashboardRedirectStatus.textContent = t(
            'dashboardRedirectSaving',
            'Saving dashboard redirect…'
          );
        }

        setDashboardRedirect(nextEnabled)
          .then(function (res) {
            if (!res || !res.success) {
              throw res || new Error('dashboard_redirect_save_failed');
            }

            dashboardRedirectEnabled = nextEnabled;
            layoutCfg.dashboardRedirectEnabled = nextEnabled;
            syncDashboardRedirectHomeLinks(nextEnabled, res.data && res.data.homeUrl);
            if (dashboardRedirectStatus) {
              dashboardRedirectStatus.textContent = t(
                'dashboardRedirectSaved',
                'Dashboard redirect updated.'
              );
            }
            showWorkspaceToast(t('dashboardRedirectSaved', 'Dashboard redirect updated.'));
            dashboardRedirectToggle.disabled = false;
          })
          .catch(function () {
            dashboardRedirectToggle.checked = dashboardRedirectEnabled;
            if (dashboardRedirectStatus) {
              dashboardRedirectStatus.textContent = t(
                'dashboardRedirectSaveFailed',
                'Could not update dashboard redirect. Please try again.'
              );
            }
            showWorkspaceToast(
              t(
                'dashboardRedirectSaveFailed',
                'Could not update dashboard redirect. Please try again.'
              )
            );
            dashboardRedirectToggle.disabled = false;
          });
      });
    }

    function renderWidgetList(widgets, filter) {
      var q = (filter || '').toLowerCase().trim();
      var sorted = widgets.slice().sort(function (a, b) {
        var ab = a && a.builtin ? 1 : 0;
        var bb = b && b.builtin ? 1 : 0;
        if (ab !== bb) {
          return bb - ab;
        }
        var pa = parseInt(a && a.priority, 10);
        var pb = parseInt(b && b.priority, 10);
        if (!isNaN(pa) && !isNaN(pb) && pa !== pb) {
          return pa - pb;
        }
        return String(a && a.title ? a.title : a.id || '').localeCompare(
          String(b && b.title ? b.title : b.id || '')
        );
      });
      var items = sorted.filter(function (w) {
        if (!cardMatchesDashboardScope(w)) {
          return false;
        }
        if (!q) {
          return true;
        }
        return (
          String(w.title || '')
            .toLowerCase()
            .indexOf(q) !== -1 ||
          String(w.id || '')
            .toLowerCase()
            .indexOf(q) !== -1 ||
          String(w.description || '')
            .toLowerCase()
            .indexOf(q) !== -1
        );
      });
      if (isNetworkDashboard()) {
        var allowedIds = networkLayoutCfg.allowedCardIds;
        if (Array.isArray(allowedIds) && allowedIds.length) {
          items = items.filter(function (w) {
            return allowedIds.indexOf(w.id || '') !== -1;
          });
        }
      }
      if (!items.length) {
        widgetList.innerHTML =
          '<p class="yp-studio-add-section-modal__empty">' +
          escapeHtml(t('widgetsEmpty', 'No dashboard widgets available.')) +
          '</p>';
        return;
      }
      widgetList.innerHTML = items
        .map(function (w) {
          var cardId = w.id || '';
          var onDashboard = isCardPresentOnDashboard(cardId);
          var isBuiltin = !!(w.builtin || BUILTIN_CARD_IDS[cardId]);
          var addedLabel = isBuiltin
            ? t('cardInSidebar', 'In sidebar')
            : t('cardAlreadyAdded', 'Added');
          return (
            '<div class="yp-studio-add-section-catalog-item' +
            (onDashboard ? ' is-on-dashboard' : '') +
            (isBuiltin ? ' is-builtin' : '') +
            '" data-catalog-card-id="' +
            escapeHtml(cardId) +
            '">' +
            '<button type="button" class="yp-studio-add-section-widget" data-widget-id="' +
            escapeHtml(cardId) +
            '" data-widget-title="' +
            escapeHtml(w.title || cardId) +
            '" data-widget-icon="' +
            escapeHtml(w.icon || 'dashicons-admin-generic') +
            '"' +
            (onDashboard ? ' disabled aria-disabled="true"' : '') +
            '>' +
            '<span class="dashicons ' +
            escapeHtml(w.icon || 'dashicons-admin-generic') +
            '" aria-hidden="true"></span>' +
            '<span class="yp-studio-add-section-widget__label">' +
            '<strong>' +
            escapeHtml(w.title || cardId) +
            '</strong>' +
            (onDashboard
              ? '<span class="yp-studio-add-section-widget__badge yp-studio-add-section-widget__badge--added">' +
                escapeHtml(addedLabel) +
                '</span>'
              : isBuiltin
                ? '<span class="yp-studio-add-section-widget__badge">' +
                  escapeHtml(t('cardBuiltinIncluded', 'Included')) +
                  '</span>'
                : '') +
            (w.description
              ? '<span class="yp-studio-add-section-widget__desc">' +
                escapeHtml(w.description) +
                '</span>'
              : '') +
            '</span></button>' +
            (onDashboard
              ? '<button type="button" class="yp-studio-add-section-catalog-action yp-studio-add-section-catalog-action--remove" data-catalog-action="remove" data-remove-card-id="' +
                escapeHtml(cardId) +
                '" aria-label="' +
                escapeHtml(t('cardRemoveFromDashboard', 'Remove from dashboard')) +
                '" title="' +
                escapeHtml(t('cardRemove', 'Remove')) +
                '">' +
                '<span class="dashicons dashicons-trash" aria-hidden="true"></span></button>'
              : '') +
            '</div>'
          );
        })
        .join('');
      widgetList.querySelectorAll('.yp-studio-add-section-widget:not([disabled])').forEach(function (btn) {
        btn.addEventListener('click', function () {
          pendingWidgetMeta = {
            widgetId: btn.getAttribute('data-widget-id'),
            title: btn.getAttribute('data-widget-title'),
            icon: btn.getAttribute('data-widget-icon'),
          };
          hideAllPanels();
          setAddSectionPanelHidden(placePanel, false);
          addSectionModalEl.classList.add('yp-studio-add-section-modal--place-active');
          setPlaceFooterVisible(true);
          setAddSectionModalTitle('placeWidgetTitle', 'Place widget');
        });
      });
      widgetList.querySelectorAll('[data-remove-card-id]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          var cardId = btn.getAttribute('data-remove-card-id') || '';
          var action = btn.getAttribute('data-catalog-action') || 'remove';
          if (action === 'hide') {
            catalogToggleBuiltinCard(cardId);
            return;
          }
          removeCardFromDashboard(cardId);
        });
      });
    }

    refreshCatalogListCallback = function () {
      var cardPanel = addSectionModalEl.querySelector('[data-add-section-panel="card"]');
      if (!cardPanel || cardPanel.hasAttribute('hidden')) {
        return;
      }
      fetchWidgetCatalog().then(function (widgets) {
        renderWidgetList(widgets, searchInput ? searchInput.value : '');
      });
    };

    if (modalBody) {
      modalBody.addEventListener('click', function (e) {
        var choiceBtn = e.target.closest('[data-add-section-choice]');
        if (!choiceBtn || !modalBody.contains(choiceBtn)) {
          return;
        }
        var choice = choiceBtn.getAttribute('data-add-section-choice') || '';
        if (choice === 'custom') {
          removeAddSectionModal();
          addCustomSection(defaultPl);
          return;
        }
        if (choice === 'card') {
          showCardPanel();
          widgetCatalogCache = null;
          fetchWidgetCatalog(true).then(function (widgets) {
            renderWidgetList(widgets, searchInput ? searchInput.value : '');
          });
          return;
        }
        if (choice === 'legacy') {
          showLegacyPanel();
        }
      });
    }

    if (searchInput) {
      searchInput.addEventListener('input', function () {
        fetchWidgetCatalog().then(function (widgets) {
          renderWidgetList(widgets, searchInput.value);
        });
      });
    }

    addSectionModalEl.querySelectorAll('[data-place-widget]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (!pendingWidgetMeta) {
          return;
        }
        var pl = btn.getAttribute('data-place-widget') === 'aside' ? 'aside' : 'main';
        addWidgetSection(pl, pendingWidgetMeta);
        removeAddSectionModal();
      });
    });

    document.addEventListener(
      'keydown',
      function escModal(e) {
        if (e.key === 'Escape' && document.getElementById('yp-studio-add-section-modal')) {
          removeAddSectionModal();
          document.removeEventListener('keydown', escModal);
        }
      },
      { once: true }
    );
  }

  function shouldHideEmptySection(section) {
    if (getSectionId(section) === 'from-extensions') {
      if (extensionsSectionAwaitingHydration(section)) {
        return false;
      }
      return sectionIsEmpty(section);
    }
    return isCustomSection(section) && sectionIsEmpty(section);
  }

  function purgeEmptyCustomSectionsFromDom() {
    Array.prototype.slice
      .call(root.querySelectorAll('.yp-studio-custom-section'))
      .forEach(function (section) {
        if (sectionIsEmpty(section) && section.parentNode) {
          section.parentNode.removeChild(section);
        }
      });
  }

  function getSectionTitleText(section) {
    if (!section) {
      return '';
    }
    var input = section.querySelector('.yp-section-title-input');
    if (input && !input.hidden && section.classList.contains('yp-section-title--editing')) {
      return String(input.value || '').replace(/\s+/g, ' ').trim();
    }
    var stored = section.getAttribute('data-section-title');
    if (stored) {
      return String(stored).replace(/\s+/g, ' ').trim();
    }
    var label = section.querySelector('.yp-section-title-label');
    if (label) {
      return label.textContent.replace(/\s+/g, ' ').trim();
    }
    var titleEl = section.querySelector('.yp-section-title');
    return titleEl ? titleEl.textContent.replace(/\s+/g, ' ').trim() : '';
  }

  function setSectionTitleText(section, text) {
    if (!section) {
      return;
    }
    var value = String(text || '').replace(/\s+/g, ' ').trim() || t('customSection', 'Custom section');
    section.setAttribute('data-section-title', value);
    var label = section.querySelector('.yp-section-title-label');
    if (label) {
      label.textContent = value;
    }
    var input = section.querySelector('.yp-section-title-input');
    if (input) {
      input.value = value;
    }
  }

  function beginSectionTitleEdit(section, isNew) {
    if (!section || !isCustomSection(section) || !isLayoutEditActive()) {
      return;
    }
    var titleWrap = section.querySelector('.yp-section-title');
    var label = section.querySelector('.yp-section-title-label');
    var input = section.querySelector('.yp-section-title-input');
    if (!titleWrap || !label || !input) {
      return;
    }
    input.value = getSectionTitleText(section) || t('customSection', 'Custom section');
    titleWrap.classList.add('yp-section-title--editing');
    label.hidden = true;
    input.hidden = false;
    section.classList.add('yp-section-title--editing');
    window.requestAnimationFrame(function () {
      input.focus();
      if (isNew && typeof input.select === 'function') {
        input.select();
      }
    });
  }

  function commitSectionTitleEdit(section) {
    if (!section || !isCustomSection(section)) {
      return;
    }
    var titleWrap = section.querySelector('.yp-section-title');
    var label = section.querySelector('.yp-section-title-label');
    var input = section.querySelector('.yp-section-title-input');
    if (!titleWrap || !label || !input) {
      return;
    }
    var previous = getSectionTitleText(section);
    var next = String(input.value || '').replace(/\s+/g, ' ').trim();
    if (!next) {
      next = previous || t('customSection', 'Custom section');
    }
    setSectionTitleText(section, next);
    titleWrap.classList.remove('yp-section-title--editing');
    label.hidden = false;
    input.hidden = true;
    section.classList.remove('yp-section-title--editing');
    if (next !== previous) {
      saveLayoutNow();
    }
  }

  function normalizeDashicon(icon) {
    if (!icon || typeof icon !== 'string') {
      return '';
    }
    var value = icon.trim();
    if (!/^dashicons-[a-z0-9-]+$/.test(value)) {
      return '';
    }
    return value;
  }

  function getDashiconFromElement(el) {
    if (!el || !el.classList) {
      return '';
    }
    var list = Array.prototype.slice.call(el.classList);
    for (var i = 0; i < list.length; i++) {
      if (list[i].indexOf('dashicons-') === 0 && list[i] !== 'dashicons') {
        return list[i];
      }
    }
    return '';
  }

  function getSectionIconElement(section) {
    return section ? section.querySelector('.yp-section-title-icon') : null;
  }

  function getSectionDefaultIcon(section) {
    if (!section) {
      return 'dashicons-screenoptions';
    }
    var stored = section.getAttribute('data-default-section-icon');
    if (stored) {
      return normalizeDashicon(stored) || 'dashicons-screenoptions';
    }
    var iconEl = getSectionIconElement(section);
    var fromEl = getDashiconFromElement(iconEl);
    return fromEl || 'dashicons-screenoptions';
  }

  function getSectionIcon(section) {
    if (!section) {
      return '';
    }
    var override = normalizeDashicon(section.getAttribute('data-section-icon'));
    if (override) {
      return override;
    }
    return getDashiconFromElement(getSectionIconElement(section));
  }

  function setSectionIcon(section, iconClass) {
    if (!section) {
      return;
    }
    var iconEl = getSectionIconElement(section);
    if (!iconEl) {
      return;
    }
    var next =
      normalizeDashicon(iconClass) || getSectionDefaultIcon(section) || 'dashicons-screenoptions';
    Array.prototype.forEach.call(iconEl.classList, function (cls) {
      if (cls.indexOf('dashicons-') === 0) {
        iconEl.classList.remove(cls);
      }
    });
    if (!iconEl.classList.contains('dashicons')) {
      iconEl.classList.add('dashicons');
    }
    iconEl.classList.add(next);
    var defaultIcon = getSectionDefaultIcon(section);
    if (next && next !== defaultIcon) {
      section.setAttribute('data-section-icon', next);
    } else {
      section.removeAttribute('data-section-icon');
    }
  }

  function getSectionHeaderEl(section) {
    return section ? section.querySelector('.yp-layout-section-handle, .yp-section-header') : null;
  }

  function ensureSectionHeaderEditControls(section) {
    var header = getSectionHeaderEl(section);
    if (!header) {
      return null;
    }
    var controls = header.querySelector('.yp-section-header__edit-controls');
    if (!controls) {
      controls = document.createElement('span');
      controls.className = 'yp-section-header__edit-controls';
      header.insertBefore(controls, header.firstChild);
    }
    var dragHandle = header.querySelector('.yp-layout-section-drag-handle');
    if (dragHandle && dragHandle.parentNode !== controls) {
      controls.appendChild(dragHandle);
    }
    return controls;
  }

  function ensureSectionIconStructure(section) {
    if (!section || section.getAttribute('data-layout-section') !== 'true') {
      return;
    }
    var titleWrap = section.querySelector('.yp-section-title');
    if (!titleWrap) {
      return;
    }
    var iconEl = titleWrap.querySelector('.yp-section-title-icon');
    if (!iconEl) {
      iconEl = titleWrap.querySelector(':scope > .dashicons');
      if (!iconEl) {
        return;
      }
      iconEl.classList.add('yp-section-title-icon');
    }
    var wrap = titleWrap.querySelector('.yp-section-title-icon-wrap');
    if (!wrap) {
      wrap = document.createElement('span');
      wrap.className = 'yp-section-title-icon-wrap';
      titleWrap.insertBefore(wrap, titleWrap.firstChild);
      wrap.appendChild(iconEl);
    } else if (iconEl.parentNode !== wrap) {
      wrap.appendChild(iconEl);
    }
    var dashClass = getDashiconFromElement(iconEl);
    if (dashClass && !section.getAttribute('data-default-section-icon')) {
      section.setAttribute('data-default-section-icon', dashClass);
    }
    if (!section.getAttribute('data-default-section-icon')) {
      section.setAttribute('data-default-section-icon', 'dashicons-screenoptions');
    }
    var controls = ensureSectionHeaderEditControls(section);
    if (!controls) {
      return;
    }
    var editBtn = section.querySelector('.yp-section-icon-edit');
    if (!editBtn) {
      editBtn = document.createElement('span');
      editBtn.className = 'yp-section-icon-edit';
      editBtn.setAttribute('role', 'button');
      editBtn.tabIndex = 0;
      editBtn.setAttribute('aria-label', t('changeSectionIcon', 'Change section icon'));
      editBtn.innerHTML = '<span class="dashicons dashicons-edit" aria-hidden="true"></span>';
    }
    var iconEditTarget = ensureSectionHeaderActions(section) || controls;
    if (!iconEditTarget) {
      return;
    }
    if (editBtn.parentNode !== iconEditTarget) {
      var removeBtn = iconEditTarget.querySelector('.yp-layout-section-remove');
      if (removeBtn) {
        iconEditTarget.insertBefore(editBtn, removeBtn);
      } else {
        iconEditTarget.appendChild(editBtn);
      }
    }
  }

  function openSectionIconPicker(section) {
    if (!section || !isLayoutEditActive()) {
      return;
    }
    if (!window.YPCardIcons || typeof window.YPCardIcons.pickIcon !== 'function') {
      return;
    }
    ensureSectionIconStructure(section);
    var current = getSectionIcon(section) || getSectionDefaultIcon(section);
    window.YPCardIcons.pickIcon(current, function (icon) {
      if (icon) {
        setSectionIcon(section, icon);
      } else {
        setSectionIcon(section, getSectionDefaultIcon(section));
      }
      saveLayoutNow();
    });
  }

  function bindSectionIcon(section) {
    if (!section || section.getAttribute('data-layout-section') !== 'true') {
      return;
    }
    ensureSectionIconStructure(section);
    if (section.getAttribute('data-section-icon-bound') === '1') {
      syncSectionIconEdit(section);
      return;
    }
    var wrap = section.querySelector('.yp-section-title-icon-wrap');
    function handleOpen(e) {
      if (!isLayoutEditActive() || section.classList.contains('yp-section-title--editing')) {
        return;
      }
      e.preventDefault();
      e.stopPropagation();
      openSectionIconPicker(section);
    }
    var editBtn = section.querySelector('.yp-section-icon-edit');
    if (editBtn) {
      editBtn.addEventListener('click', handleOpen);
      editBtn.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          handleOpen(e);
        }
      });
    }
    if (wrap) {
      var iconEl = wrap.querySelector('.yp-section-title-icon');
      if (iconEl) {
        iconEl.addEventListener('click', handleOpen);
      }
    }
    section.setAttribute('data-section-icon-bound', '1');
    syncSectionIconEdit(section);
  }

  function syncSectionIconEdit(section) {
    if (!section) {
      return;
    }
    var show = isLayoutEditActive();
    var controls = section.querySelector('.yp-section-header__edit-controls');
    if (controls) {
      controls.classList.toggle('is-active', show);
    }
    var editBtn = section.querySelector('.yp-section-icon-edit');
    if (editBtn) {
      editBtn.hidden = !show;
      editBtn.setAttribute('aria-hidden', show ? 'false' : 'true');
    }
    var wrap = section.querySelector('.yp-section-title-icon-wrap');
    if (wrap) {
      wrap.classList.toggle('is-icon-editable', show);
      var iconEl = wrap.querySelector('.yp-section-title-icon');
      if (iconEl) {
        iconEl.classList.toggle('is-clickable', show);
      }
    }
  }

  function applySectionIcons(map) {
    if (!map || typeof map !== 'object') {
      return;
    }
    Object.keys(map).forEach(function (id) {
      var section = root.querySelector('[data-section-id="' + id + '"]');
      var icon = normalizeDashicon(map[id]);
      if (section && icon) {
        ensureSectionIconStructure(section);
        setSectionIcon(section, icon);
      }
    });
  }

  function resetSectionIconsToDefault() {
    root.querySelectorAll('.yp-dashboard-section[data-layout-section="true"]').forEach(function (section) {
      ensureSectionIconStructure(section);
      setSectionIcon(section, getSectionDefaultIcon(section));
    });
  }

  function cancelSectionTitleEdit(section) {
    if (!section || !isCustomSection(section)) {
      return;
    }
    var titleWrap = section.querySelector('.yp-section-title');
    var label = section.querySelector('.yp-section-title-label');
    var input = section.querySelector('.yp-section-title-input');
    if (!titleWrap || !label || !input) {
      return;
    }
    input.value = getSectionTitleText(section) || t('customSection', 'Custom section');
    titleWrap.classList.remove('yp-section-title--editing');
    label.hidden = false;
    input.hidden = true;
    section.classList.remove('yp-section-title--editing');
  }

  function ensureSectionTitleStructure(section) {
    if (!isCustomSection(section)) {
      return;
    }
    var titleWrap = section.querySelector('.yp-section-title');
    if (!titleWrap || titleWrap.querySelector('.yp-section-title-label')) {
      return;
    }
    var icon = titleWrap.querySelector('.dashicons');
    var raw = titleWrap.textContent.replace(/\s+/g, ' ').trim();
    var currentTitle =
      section.getAttribute('data-section-title') || raw || t('customSection', 'Custom section');
    titleWrap.textContent = '';
    if (icon) {
      titleWrap.appendChild(icon);
    } else {
      var iconEl = document.createElement('span');
      iconEl.className = 'dashicons dashicons-screenoptions';
      iconEl.setAttribute('aria-hidden', 'true');
      titleWrap.appendChild(iconEl);
    }
    var label = document.createElement('span');
    label.className = 'yp-section-title-label';
    label.textContent = currentTitle;
    titleWrap.appendChild(label);
    var input = document.createElement('input');
    input.type = 'text';
    input.className = 'yp-section-title-input';
    input.maxLength = 80;
    input.autocomplete = 'off';
    input.spellcheck = false;
    input.hidden = true;
    input.value = currentTitle;
    input.setAttribute('aria-label', t('sectionTitle', 'Section title'));
    titleWrap.appendChild(input);
    setSectionTitleText(section, currentTitle);
    ensureSectionIconStructure(section);
    syncSectionIconEdit(section);
  }

  function bindSectionTitle(section) {
    if (!isCustomSection(section)) {
      return;
    }
    ensureSectionTitleStructure(section);
    var titleWrap = section.querySelector('.yp-section-title');
    if (!titleWrap || titleWrap.getAttribute('data-title-bound') === '1') {
      return;
    }
    titleWrap.addEventListener('dblclick', function (e) {
      if (!isLayoutEditActive()) {
        return;
      }
      if (
        e.target.closest(
          '.yp-layout-section-drag-handle, .yp-section-title-input, .yp-section-title-icon-wrap, .yp-section-icon-edit, .yp-section-header__edit-controls'
        )
      ) {
        return;
      }
      e.preventDefault();
      e.stopPropagation();
      beginSectionTitleEdit(section, false);
    });
    var input = section.querySelector('.yp-section-title-input');
    if (input) {
      input.addEventListener('blur', function () {
        commitSectionTitleEdit(section);
      });
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          input.blur();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          cancelSectionTitleEdit(section);
        }
      });
      input.addEventListener('click', function (e) {
        e.stopPropagation();
      });
      input.addEventListener('pointerdown', function (e) {
        e.stopPropagation();
      });
    }
    titleWrap.setAttribute('data-title-bound', '1');
  }

  function syncSectionRemoveButton(section) {
    if (!isCustomSection(section) && !isWidgetSection(section) && !isSectionHideAllowed(section)) {
      return;
    }
    var btn = section.querySelector('.yp-layout-section-remove');
    if (!btn) {
      return;
    }
    var show = isLayoutEditActive();
    btn.classList.toggle('is-visible', show);
    btn.removeAttribute('hidden');
    btn.setAttribute('aria-hidden', show ? 'false' : 'true');
  }

  function ensureSectionDragHandle(section) {
    if (!section || isSectionLocked(section)) {
      return null;
    }
    var header = getSectionHeaderEl(section);
    if (!header) {
      return null;
    }
    var controls = ensureSectionHeaderEditControls(section);
    var handle = controls ? controls.querySelector('.yp-layout-section-drag-handle') : null;
    if (!handle) {
      handle = document.createElement('span');
      handle.className = 'yp-layout-section-drag-handle';
      handle.setAttribute('aria-hidden', 'true');
      handle.innerHTML = '<span class="dashicons dashicons-move" aria-hidden="true"></span>';
      if (controls) {
        controls.insertBefore(handle, controls.firstChild);
      } else {
        header.insertBefore(handle, header.firstChild);
      }
    }
    if (handle.getAttribute('data-section-handle-bound') !== '1') {
      handle.addEventListener('pointerdown', onSectionHandlePointerDown);
      handle.addEventListener('pointermove', onSectionHandlePointerMove);
      handle.addEventListener('pointerup', onSectionHandlePointerUp);
      handle.addEventListener('pointercancel', onSectionHandlePointerUp);
      handle.setAttribute('data-section-handle-bound', '1');
    }
    return handle;
  }

  function updateSectionDraggable(section) {
    if (!section) {
      return;
    }
    var header = section.querySelector('.yp-layout-section-handle, .yp-section-header');
    if (header) {
      header.setAttribute('draggable', 'false');
    }
    var canDrag = isLayoutEditActive() && isMovableSection(section);
    var dragHandle = ensureSectionDragHandle(section);
    if (dragHandle) {
      dragHandle.hidden = !canDrag;
    }
    syncSectionRemoveButton(section);
    syncSectionIconEdit(section);
    syncSectionVisibilityToggle(section);
    syncWorkspaceAddButton(section);
    var headerControls = section.querySelector('.yp-section-header__edit-controls');
    if (headerControls) {
      headerControls.classList.toggle('is-active', canDrag);
    }
  }

  function updateAllSectionsDraggable() {
    root
      .querySelectorAll('.yp-dashboard-section[data-layout-section="true"]')
      .forEach(updateSectionDraggable);
  }

  function syncCustomSection(section) {
    if (!isCustomSection(section)) {
      return;
    }
    var grid = getSectionGrid(section);
    if (!grid) {
      return;
    }
    grid.hidden = false;
    grid.removeAttribute('hidden');
    grid.style.display = '';
    grid.classList.add('is-hydrated');
    grid.classList.remove('is-grid-empty');
    var hasAnyCard = grid.querySelector('[data-card-id]') !== null;
    var booting =
      section.getAttribute('data-layout-booting') === 'true' ||
      section.classList.contains('yp-studio-layout-section--booting');
    section.classList.toggle('yp-studio-custom-section--empty', !hasAnyCard);
    var hint = grid.querySelector('[data-layout-empty-hint]');
    if (hint) {
      hint.hidden = booting || !isLayoutEditActive() || hasAnyCard;
    }
  }

  function createDropGap() {
    var gap = document.createElement('div');
    gap.className = 'yp-layout-drop-gap';
    gap.setAttribute('aria-hidden', 'true');
    return gap;
  }

  function ensureDropSlot() {
    if (!dropSlot) {
      dropSlot = createDropGap();
    }
    return dropSlot;
  }

  function clearDropActiveGrids() {
    root.querySelectorAll('.yp-cards-grid.yp-custom-grid--drop-active').forEach(function (grid) {
      grid.classList.remove('yp-custom-grid--drop-active');
    });
  }

  function removeDropSlot() {
    if (dropSlot && dropSlot.parentNode) {
      dropSlot.parentNode.removeChild(dropSlot);
    }
    clearDropActiveGrids();
  }

  function placeDropSlotInGrid(grid, before) {
    var slot = ensureDropSlot();
    var hint = grid.querySelector('[data-layout-empty-hint]');
    var hasCards = getGridCardItems(grid).length > 0;

    if (!hasCards && hint) {
      grid.insertBefore(slot, hint);
      grid.classList.add('yp-custom-grid--drop-active');
      return;
    }

    grid.classList.remove('yp-custom-grid--drop-active');
    if (before && before.parentNode === grid) {
      grid.insertBefore(slot, before);
    } else {
      grid.appendChild(slot);
    }
  }

  function cleanupGrid(grid) {
    if (!grid) {
      return;
    }
    grid.classList.remove('yp-custom-grid--drop-active');
    Array.prototype.forEach.call(
      grid.querySelectorAll('.yp-layout-drop-gap, .yp-layout-edit-slots, [data-layout-slot]'),
      function (node) {
        if (node.parentNode) {
          node.parentNode.removeChild(node);
        }
      }
    );
  }

  function cleanupAllGrids() {
    getSortableGrids().forEach(cleanupGrid);
    removeDropSlot();
  }

  function serializeLayout(options) {
    options = options || {};
    if (!options.skipCleanup) {
      cleanupAllGrids();
    }
    var asideOrder = getLayoutSections(asideEl).map(getSectionId).filter(Boolean);
    asideOrder = asideOrder.filter(function (id) {
      return id && !LOCKED_SECTION_IDS[id] && !isMainColumnLockedSectionId(id);
    });
    var asideIdSet = Object.create(null);
    asideOrder.forEach(function (id) {
      asideIdSet[id] = true;
    });
    var mainOrder = getLayoutSections(mainEl)
      .map(getSectionId)
      .filter(function (id) {
        return id && !asideIdSet[id];
      });
    if (isNetworkDashboard()) {
      Object.keys(NETWORK_MAIN_COLUMN_LOCKED_IDS).forEach(function (lockedId) {
        if (lockedId && mainOrder.indexOf(lockedId) === -1) {
          mainOrder.unshift(lockedId);
        }
      });
    }

    var previous = readStorage();
    var hiddenSections = getHiddenSectionIdList();
    if (
      !isNetworkDashboard()
      && !hiddenSections.length
      && !layoutHasUserSectionVisibility(previous)
      && !getRemovedBuiltInSectionIdList().length
    ) {
      hiddenSections = DEFAULT_HIDDEN_SECTIONS.filter(function (id) {
        return !isRemovedBuiltInSectionId(id);
      });
    }

    var data = {
      version: LAYOUT_VERSION,
      mainOrder: mainOrder,
      asideOrder: asideOrder,
      cards: {},
      customSections: {},
      widgetSections: {},
      sectionIcons: {},
      removedBuiltInSections: getRemovedBuiltInSectionIdList(),
      removedWidgetIds: getRemovedWidgetIdList(),
      hidden: getHiddenCardIdList(),
      hiddenSections: hiddenSections,
    };

    if (previous && previous.overviewDefaultWidgetAdded) {
      data.overviewDefaultWidgetAdded = true;
    }

    if (layoutHasUserSectionVisibility(previous)) {
      data.hiddenSectionsExplicit = true;
      data.asideVisibilityTouched = true;
    }

    root.querySelectorAll('.yp-dashboard-section[data-section-id]').forEach(function (section) {
      var id = getSectionId(section);
      if (!id) {
        return;
      }
      var grid = getSectionGrid(section);
      if (grid) {
        data.cards[id] = Array.prototype.map.call(
          grid.querySelectorAll('[data-card-id]'),
          function (c) {
            return c.getAttribute('data-card-id');
          }
        );
      }
      var icon = getSectionIcon(section);
      var defaultIcon = getSectionDefaultIcon(section);
      if (icon && icon !== defaultIcon) {
        data.sectionIcons[id] = icon;
      }
      if (section.classList.contains('yp-studio-custom-section')) {
        var titleText = getSectionTitleText(section);
        data.customSections[id] = {
          placement: asideEl.contains(section) ? 'aside' : 'main',
          title: titleText || t('customSection', 'Custom section'),
          icon: icon || defaultIcon,
        };
      }
      if (section.classList.contains('yp-studio-widget-section')) {
        data.widgetSections[id] = {
          placement: asideEl.contains(section) ? 'aside' : 'main',
          widgetId: section.getAttribute('data-widget-id') || '',
          title: getSectionTitleText(section),
          icon: icon || getSectionDefaultIcon(section),
        };
      }
    });

    if (window.YOOAdminWorkspacePagination && typeof window.YOOAdminWorkspacePagination.getCardPages === 'function') {
      var cardPages = window.YOOAdminWorkspacePagination.getCardPages();
      if (cardPages && Object.keys(cardPages).length) {
        data.cardPages = cardPages;
      }
    }

    return data;
  }

  function reorderChildren(container, orderIds) {
    if (!container || !orderIds || !orderIds.length) {
      return;
    }
    var map = {};
    getLayoutSections(container).forEach(function (section) {
      var id = getSectionId(section);
      if (id) {
        map[id] = section;
      }
    });
    orderIds.forEach(function (id) {
      if (map[id]) {
        container.appendChild(map[id]);
      }
    });
    pinAddButtonsToColumnEnd();
  }

  /** Move cards between sections and restore order from storage (per-section lists). */
  function applyCardsLayout(cardsBySection) {
    if (!cardsBySection || typeof cardsBySection !== 'object') {
      return;
    }

    var cardNodes = {};
    root.querySelectorAll('[data-card-id]').forEach(function (card) {
      var id = getCardId(card);
      if (id) {
        cardNodes[id] = card;
      }
    });

    Object.keys(cardsBySection).forEach(function (sectionId) {
      var section = root.querySelector('[data-section-id="' + sectionId + '"]');
      if (!section) {
        return;
      }
      var grid = getSectionGrid(section);
      if (!grid) {
        return;
      }
      var ids = cardsBySection[sectionId];
      if (!Array.isArray(ids)) {
        return;
      }
      ids.forEach(function (cid) {
        if (cardNodes[cid]) {
          var card = cardNodes[cid];
          var hint = grid.querySelector('[data-layout-empty-hint]');
          var loader = grid.querySelector('[data-layout-loading]');
          if (hint && hint.parentNode === grid) {
            grid.insertBefore(card, hint);
          } else if (loader && loader.parentNode === grid) {
            grid.insertBefore(card, loader.nextSibling);
          } else {
            grid.appendChild(card);
          }
        }
      });
    });
  }

  function customSectionLoadingMarkup() {
    return (
      '<div class="yp-studio-section-grid-loading yp-studio-section-loading" data-layout-loading aria-hidden="false">' +
      '<div class="yp-loading-spinner"><div class="yp-spinner-circle"></div></div></div>'
    );
  }

  function buildCustomSection(id, placement, title, icon, booting) {
    var isBooting = booting === true;
    var section = document.createElement('div');
    section.className =
      'yp-card yp-card-full yp-dashboard-section yp-studio-surface-card yp-studio-custom-section' +
      (isBooting ? ' yp-studio-layout-section--booting' : '');
    if (isBooting) {
      section.setAttribute('data-layout-booting', 'true');
    }
    section.setAttribute('data-section-id', id);
    section.setAttribute('data-layout-section', 'true');
    section.setAttribute('data-collapsible', 'true');
    section.setAttribute('data-sortable', 'true');
    section.setAttribute('data-collapsed', 'false');
    section.setAttribute('data-custom-placement', placement);

    var displayTitle = title || t('customSection', 'Custom section');
    var sectionIcon = normalizeDashicon(icon) || 'dashicons-screenoptions';
    section.setAttribute('data-section-title', displayTitle);
    section.setAttribute('data-default-section-icon', 'dashicons-screenoptions');
    var paginateSection = placement === 'aside';
    var gridClass =
      placement === 'aside'
        ? 'yp-icon-grid-boxes yp-cards-grid yp-studio-workspace-rows yp-studio-custom-grid yp-studio-aside-grid'
        : 'yp-icon-grid-boxes yp-cards-grid yp-studio-workspace-rows yp-studio-custom-grid';
    if (!isBooting) {
      gridClass += ' is-hydrated';
    }

    if (placement === 'aside') {
      section.classList.add('yp-studio-custom-section--aside');
    }

    section.innerHTML =
      '<div class="yp-card-header yp-section-header yp-layout-section-handle">' +
      '<span class="yp-section-header__edit-controls">' +
      '<span class="yp-layout-section-drag-handle" aria-hidden="true">' +
      '<span class="dashicons dashicons-move" aria-hidden="true"></span></span>' +
      '<span class="yp-section-icon-edit" role="button" tabindex="0" aria-label="' +
      escapeHtml(t('changeSectionIcon', 'Change section icon')) +
      '" hidden>' +
      '<span class="dashicons dashicons-edit" aria-hidden="true"></span></span>' +
      '</span>' +
      '<h2 class="yp-card-title yp-section-title">' +
      '<span class="yp-section-title-icon-wrap">' +
      '<span class="yp-section-title-icon dashicons ' +
      sectionIcon +
      '" aria-hidden="true"></span>' +
      '</span>' +
      '<span class="yp-section-title-label">' +
      escapeHtml(displayTitle) +
      '</span>' +
      '<input type="text" class="yp-section-title-input" maxlength="80" autocomplete="off" spellcheck="false" hidden ' +
      'value="' +
      escapeHtml(displayTitle) +
      '" aria-label="' +
      escapeHtml(t('sectionTitle', 'Section title')) +
      '" />' +
      '</h2>' +
      '<div class="yp-card-header-actions">' +
      '<button type="button" class="yp-layout-section-remove" aria-label="' +
      escapeHtml(t('removeSection', 'Remove section')) +
      '">' +
      '<span class="dashicons dashicons-trash" aria-hidden="true"></span>' +
      '</button>' +
      '</div>' +
      '</div>' +
      '<div class="' +
      gridClass +
      '" data-layout="grid" data-columns="auto" data-sortable="true"' +
      (paginateSection
        ? ' data-workspace-paginate="true" data-items-per-page="' + ASIDE_ITEMS_PER_PAGE + '"'
        : ' data-workspace-paginate="false"') +
      '>' +
      (isBooting ? customSectionLoadingMarkup() : '') +
      '<p class="yp-layout-empty-drop-hint" data-layout-empty-hint hidden>' +
      escapeHtml(
        t(
          'dropTilesHere',
          'Drag tiles here from another section (use the move handle on each tile).'
        )
      ) +
      '</p></div>' +
      (paginateSection
        ? '<div class="yp-studio-ws-pager-footer" data-ws-pager-footer hidden>' +
          '<nav class="yp-studio-ws-nav" data-ws-nav hidden aria-label="Section pages">' +
          '<button type="button" class="yp-studio-ws-nav__btn" data-ws-prev aria-label="Previous page">' +
          '<span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span></button>' +
          '<span class="yp-studio-ws-nav__label" data-ws-nav-label aria-live="polite"></span>' +
          '<button type="button" class="yp-studio-ws-nav__btn" data-ws-next aria-label="Next page">' +
          '<span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span></button>' +
          '</nav>' +
          '<div class="yp-studio-ws-dots" data-ws-dots hidden aria-hidden="true"></div>' +
          '</div>'
        : '');

    return section;
  }


  function insertAsideSection(section) {
    if (asideAddBtn && asideAddBtn.parentNode === asideEl) {
      asideEl.insertBefore(section, asideAddBtn);
    } else {
      asideEl.appendChild(section);
    }
  }

  function ensureCustomAndWidgetSections(data) {
    if (!data || data.version !== LAYOUT_VERSION) {
      return;
    }
    if (data.customSections) {
      Object.keys(data.customSections).forEach(function (id) {
        var existing = root.querySelector('[data-section-id="' + id + '"]');
        if (existing) {
          bindSection(existing);
          return;
        }
        var meta = data.customSections[id];
        if (!meta) {
          return;
        }
        var cardIds = (data.cards && data.cards[id]) || [];
        var placement = meta && meta.placement === 'aside' ? 'aside' : 'main';
        var section = buildCustomSection(id, placement, meta.title, meta && meta.icon, true);
        if (placement === 'aside') {
          insertAsideSection(section);
        } else if (mainAddBtn && mainAddBtn.parentNode === mainEl) {
          mainEl.insertBefore(section, mainAddBtn);
        } else {
          mainEl.appendChild(section);
        }
        bindSection(section);
      });
    }

    if (data.widgetSections) {
      Object.keys(data.widgetSections).forEach(function (id) {
        var existing = root.querySelector('[data-section-id="' + id + '"]');
        if (existing) {
          if (isWidgetSection(existing)) {
            loadWidgetSectionBody(existing);
            existing.removeAttribute('data-widget-ssr-pending');
          }
          return;
        }
        var meta = data.widgetSections[id];
        if (!meta || !meta.widgetId) {
          return;
        }
        if (removedWidgetIds[meta.widgetId]) {
          return;
        }
        var placement = meta.placement === 'aside' ? 'aside' : 'main';
        var section = buildWidgetSection(id, placement, meta);
        insertWidgetSectionElement(section, placement);
        bindSection(section);
        loadWidgetSectionBody(section);
      });
    }
  }

  function hydratePendingWidgets() {
    root.querySelectorAll('.yp-studio-widget-section[data-widget-ssr-pending="1"]').forEach(function (
      section
    ) {
      loadWidgetSectionBody(section);
      section.removeAttribute('data-widget-ssr-pending');
      bindSection(section);
    });
  }

  function applyCardOrderFromData(data) {
    if (data && data.cards) {
      applyCardsLayout(data.cards);
    }
  }

  function afterLayoutRestore(data) {
    if (data && data.sectionIcons) {
      applySectionIcons(data.sectionIcons);
    }
    cleanupAllGrids();
    applyAllHiddenStates();
    applyAllSectionHiddenStates();
    pinAddButtonsToColumnEnd();
    bindAllLayoutSections();
    refreshSectionVisibility();
    updateAllSectionsDraggable();
    if (window.YOOAdminWorkspacePagination) {
      window.YOOAdminWorkspacePagination.loadPages(data);
      window.YOOAdminWorkspacePagination.refresh();
    }
    if (typeof window.yooadminInitWorkspaceNotes === 'function') {
      window.yooadminInitWorkspaceNotes();
    }
    var ext = root.querySelector('[data-section-id="from-extensions"]');
    if (ext) {
      syncExtensionsAsidePlacement(ext);
    }
    syncLocalizedDashboardStrings();
  }

  function columnsNeedFix(data) {
    if (!data || data.version !== LAYOUT_VERSION) {
      return true;
    }
    if (!layoutStructureMatchesData(data)) {
      return true;
    }
    var ext = root.querySelector('[data-section-id="from-extensions"]');
    if (!ext) {
      return false;
    }
    var inAside = !!(asideEl && asideEl.contains(ext));
    var listedAside = (data.asideOrder || []).indexOf('from-extensions') !== -1;
    return inAside !== listedAside;
  }

  function setSuppressLayoutSave(on) {
    suppressLayoutSave = !!on;
  }

  function registerLayoutEditorApi() {
    window.YOOStudioHubLayoutEditor = {
      setSuppressLayoutSave: setSuppressLayoutSave,
      applyHiddenState: applyHiddenSectionsFromData,
      ensureCustomAndWidgetSections: ensureCustomAndWidgetSections,
      columnsNeedFix: columnsNeedFix,
      layoutStructureMatches: layoutStructureMatchesData,
      applyColumnPlacements: applySectionColumnPlacements,
      applyCardOrder: applyCardOrderFromData,
      finalizeGrids: finalizeLayoutSectionGrids,
      afterRestore: afterLayoutRestore,
      buildFactoryLayout: buildFactoryLayout,
      syncFactoryLayoutDomMeta: syncFactoryLayoutDomMeta,
      hydratePendingWidgets: hydratePendingWidgets,
      resetDomToFactory: function () {
        suppressLayoutSave = true;
        restoreDefaultLayoutInDom();
        suppressLayoutSave = false;
        applyHiddenSectionsFromData(buildFactoryLayout());
        flushVisibilityAfterReset();
      },
      flushVisibilityAfterReset: flushVisibilityAfterReset,
      rebindAllCards: rebindAllCards,
      updateCardsDraggable: updateCardsDraggable,
    };
  }

  function restoreDefaultLayoutInDom() {
    hiddenCardIds = {};
    hiddenSectionIds = {};
    removedBuiltInSectionIds = {};
    removedWidgetIds = {};
    clearAllSectionHiddenDomFlags();
    clearAllCardHiddenDomFlags();

    Array.prototype.slice
      .call(root.querySelectorAll('.yp-studio-custom-section'))
      .forEach(function (section) {
        removeCustomSection(section);
      });

    Array.prototype.slice
      .call(root.querySelectorAll('.yp-studio-widget-section'))
      .forEach(function (section) {
        removeWidgetSection(section);
      });

    ensureFactoryBuiltInSections();
    ensureDefaultWidgetSections();

    getFactoryMainOrder().forEach(function (sectionId) {
      var section = root.querySelector('[data-section-id="' + sectionId + '"]');
      if (section) {
        insertMainSection(section);
      }
    });

    if (defaultLayoutSnapshot) {
      var restoreLayout = Object.assign({}, defaultLayoutSnapshot, {
        asideOrder: getFactoryAsideOrder(),
        mainOrder: getFactoryMainOrder(),
      });
      applySectionColumnPlacements(restoreLayout);
      applyCardsLayout(getFactoryCardsLayout());
      if (defaultLayoutSnapshot.sectionIcons) {
        applySectionIcons(defaultLayoutSnapshot.sectionIcons);
      } else {
        resetSectionIconsToDefault();
      }
    } else {
      applySectionColumnPlacements({
        asideOrder: getFactoryAsideOrder(),
        mainOrder: getFactoryMainOrder(),
      });
      resetSectionIconsToDefault();
    }

    pinAddButtonsToColumnEnd();
    cleanupAllGrids();
    finalizeLayoutSectionGrids();
    applyDefaultHiddenSections();
    applyDefaultRemovedBuiltInSections();
    applyAllHiddenStates();
    applyAllSectionHiddenStates();
    refreshSectionVisibility();
    syncFactoryLayoutDomMeta(buildFactoryLayout());
    syncLocalizedDashboardStrings();
  }

  function resetDashboardAll() {
    if (window.YPCardIcons && typeof window.YPCardIcons.resetAll === 'function') {
      window.YPCardIcons.resetAll();
    }
    try {
      localStorage.removeItem('ypCardCustomIcons');
      localStorage.removeItem('ypCardIconEditMode');
      localStorage.removeItem('yooadmin_dashboard_layout');
      localStorage.removeItem('yooadmin_network_dashboard_layout_v1');
      localStorage.removeItem('yooadmin_studio_hub_layout_v1');
    } catch (e) {
      /* ignore */
    }
    if (window.YOOStudioHubLayoutStorage && window.YOOStudioHubLayoutStorage.clearSession) {
      window.YOOStudioHubLayoutStorage.clearSession();
    } else {
      try {
        localStorage.removeItem(STORAGE_KEY);
        localStorage.removeItem('yooadmin_network_dashboard_layout_v1');
      } catch (e2) {
        /* ignore */
      }
    }
    if (
      window.YOOStudioHubLayoutCoordinator &&
      typeof window.YOOStudioHubLayoutCoordinator.resetToFactory === 'function'
    ) {
      window.YOOStudioHubLayoutCoordinator.resetToFactory().then(function () {
        var factory = buildFactoryLayout();
        flushVisibilityAfterReset();
        rebindAllCards();
        afterLayoutRestore(factory);
        updateCardsDraggable();
        syncFactoryLayoutDomMeta(factory);
        var editOn = readIconEditOn();
        if (editOn !== layoutEditOn) {
          setLayoutEdit(editOn);
        } else {
          applyAllHiddenStates();
          applyAllSectionHiddenStates();
          refreshSectionVisibility();
        }
      });
      return;
    }
    hiddenCardIds = {};
    hiddenSectionIds = {};
    removedBuiltInSectionIds = {};
    var factory = buildFactoryLayout();
    suppressLayoutSave = true;
    restoreDefaultLayoutInDom();
    suppressLayoutSave = false;
    applyHiddenSectionsFromData(factory);
    writeStorage(factory, { serverImmediate: true });
    flushVisibilityAfterReset();
    rebindAllCards();
    afterLayoutRestore(factory);
    updateCardsDraggable();
    syncFactoryLayoutDomMeta(factory);
    var editOnFallback = readIconEditOn();
    if (editOnFallback !== layoutEditOn) {
      setLayoutEdit(editOnFallback);
    } else {
      applyAllHiddenStates();
      applyAllSectionHiddenStates();
      refreshSectionVisibility();
    }
  }

  function isExtensionsSection(section) {
    return getSectionId(section) === 'from-extensions';
  }

  function extensionsSectionAwaitingHydration(section) {
    if (!section || !isExtensionsSection(section)) {
      return false;
    }
    if (sectionIsEmpty(section)) {
      return false;
    }
    if (section.getAttribute('data-extensions-pending') === 'true') {
      return true;
    }
    var grid = getSectionGrid(section);
    if (!grid) {
      return false;
    }
    if (grid.classList.contains('is-hydrated')) {
      return false;
    }
    if (section.querySelector('.yp-extensions-grid-loading:not(.is-hidden)')) {
      return true;
    }
    return grid.querySelector('[data-card-id]') !== null;
  }

  function markExtensionsSectionsHydrated() {
    root.querySelectorAll('[data-section-id="from-extensions"]').forEach(function (section) {
      section.removeAttribute('data-extensions-pending');
      section.classList.add('yp-layout-section--hydrated');
    });
  }

  function syncExtensionsAsidePlacement(section) {
    if (!section || !isExtensionsSection(section)) {
      return;
    }
    var grid = getSectionGrid(section);
    if (!grid) {
      return;
    }
    var inAside = !!(asideEl && asideEl.contains(section));
    if (inAside) {
      section.setAttribute('data-custom-placement', 'aside');
      grid.setAttribute('data-workspace-paginate', 'true');
      if (!grid.getAttribute('data-items-per-page')) {
        grid.setAttribute('data-items-per-page', String(ASIDE_ITEMS_PER_PAGE));
      }
      if (window.YOOAdminWorkspacePagination) {
        window.YOOAdminWorkspacePagination.ensureSection(section);
      }
    } else {
      section.setAttribute('data-custom-placement', 'main');
      grid.removeAttribute('data-workspace-paginate');
      grid.removeAttribute('data-items-per-page');
      section.classList.remove('has-ws-pagination');
      section.removeAttribute('data-ws-pager-bound');
      var footer = section.querySelector('[data-ws-pager-footer]');
      if (footer && footer.parentNode) {
        footer.parentNode.removeChild(footer);
      }
      grid.querySelectorAll('[data-card-id]').forEach(function (card) {
        card.classList.remove('yp-ws-page-hidden');
        card.removeAttribute('hidden');
      });
    }
  }

  function syncExtensionsSection(section) {
    if (!section || !isExtensionsSection(section)) {
      return;
    }
    syncExtensionsAsidePlacement(section);
    var grid = getSectionGrid(section);
    if (!grid) {
      return;
    }
    var inAside = !!(asideEl && asideEl.contains(section));
    var awaitingHydration = extensionsSectionAwaitingHydration(section);
    var hasCardsInDom = grid.querySelector('[data-card-id]') !== null;
    var hasVisible = countVisibleCards(section) > 0;
    var lead = section.querySelector('.yp-studio-extensions-lead');
    if (lead) {
      lead.hidden = inAside || ((!hasVisible && !awaitingHydration) && !isLayoutEditActive());
    }
    if (isLayoutEditActive()) {
      grid.hidden = false;
      grid.removeAttribute('hidden');
      grid.style.display = '';
      grid.classList.toggle('is-grid-empty', !hasVisible && !hasCardsInDom);
      return;
    }
    if (awaitingHydration && hasCardsInDom) {
      grid.hidden = false;
      grid.removeAttribute('hidden');
      grid.style.display = '';
      grid.classList.remove('is-grid-empty');
      return;
    }
    grid.hidden = !hasVisible;
    grid.style.display = hasVisible ? '' : 'none';
    grid.classList.toggle('is-grid-empty', !hasVisible);
  }

  function isAsideSectionVisibleForLayout(section) {
    if (!section || !asideEl || !asideEl.contains(section)) {
      return false;
    }
    if (
      section.classList.contains('yp-layout-section--hidden') ||
      section.hasAttribute('hidden')
    ) {
      return false;
    }
    if (section.getAttribute('data-section-hidden') === 'true') {
      return false;
    }
    return true;
  }

  function asideHasVisibleSections() {
    return getLayoutSections(asideEl).some(isAsideSectionVisibleForLayout);
  }

  function syncLayoutColumns() {
    if (!layoutEl || !asideEl) {
      return;
    }
    var asideVisible = asideHasVisibleSections();
    /* Keep the aside column while editing so hidden/moved sections can be restored. */
    var collapseAside = !asideVisible && !isLayoutEditActive();
    layoutEl.classList.toggle('yp-studio-hub__layout--aside-empty', collapseAside);
    asideEl.classList.toggle('yp-studio-hub__aside--empty', collapseAside);
    if (collapseAside) {
      asideEl.setAttribute('aria-hidden', 'true');
    } else {
      asideEl.removeAttribute('aria-hidden');
    }
  }

  function refreshSectionVisibility() {
    root.querySelectorAll('.yp-dashboard-section[data-layout-section="true"]').forEach(function (section) {
      var empty = sectionIsEmpty(section);
      var hideWhenDone = shouldHideEmptySection(section);
      section.classList.toggle('yp-layout-section--empty', empty);
      syncExtensionsSection(section);
      syncCustomSection(section);
      if (isLayoutEditActive() || !hideWhenDone) {
        section.classList.remove('yp-layout-section--hidden');
        section.removeAttribute('hidden');
      } else {
        section.classList.add('yp-layout-section--hidden');
        section.setAttribute('hidden', 'hidden');
      }
    });
    syncLayoutColumns();
    if (window.YOOAdminWorkspacePagination) {
      window.YOOAdminWorkspacePagination.refresh();
    }
  }

  function createAddButton(placement) {
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'yp-studio-layout-add yp-studio-layout-add--' + placement;
    btn.setAttribute('data-studio-add-section', placement);
    btn.setAttribute(
      'aria-label',
      placement === 'aside' ? t('addAside', 'Add section on the right') : t('addBelow', 'Add section below')
    );
    btn.hidden = true;
    btn.innerHTML = '<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>';
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      openAddSectionModal(placement === 'aside' ? 'aside' : 'main');
    });
    return btn;
  }

  /** Keep “add section” controls last in each column (DOM end = bottom in LTR/RTL). */
  function pinAddButtonsToColumnEnd() {
    if (mainAddBtn && mainAddBtn.parentNode === mainEl) {
      mainEl.appendChild(mainAddBtn);
    }
    if (asideAddBtn && asideAddBtn.parentNode === asideEl) {
      asideEl.appendChild(asideAddBtn);
    }
  }

  function ensureAddButtons() {
    if (!mainAddBtn) {
      mainAddBtn = createAddButton('main');
      if (!mainAddBtn.parentNode) {
        mainEl.appendChild(mainAddBtn);
      }
    }
    if (!asideAddBtn) {
      asideAddBtn = createAddButton('aside');
      if (!asideAddBtn.parentNode) {
        asideEl.appendChild(asideAddBtn);
      }
    }
    pinAddButtonsToColumnEnd();
    mainAddBtn.hidden = !layoutEditOn;
    asideAddBtn.hidden = !layoutEditOn;
    mainAddBtn.classList.toggle('is-visible', layoutEditOn);
    asideAddBtn.classList.toggle('is-visible', layoutEditOn);
  }

  function addCustomSection(placement) {
    var id = nextCustomId(placement === 'aside' ? 'aside' : 'main');
    var section = buildCustomSection(id, placement, t('customSection', 'Custom section'));
    if (placement === 'aside') {
      insertAsideSection(section);
    } else if (mainAddBtn && mainAddBtn.parentNode === mainEl) {
      mainEl.insertBefore(section, mainAddBtn);
    } else {
      mainEl.appendChild(section);
    }
    bindSection(section);
    bindSectionTitle(section);
    var grid = getSectionGrid(section);
    bindGrid(grid);
    if (grid) {
      grid.hidden = false;
      grid.style.display = '';
    }
    syncCustomSection(section);
    beginSectionTitleEdit(section, true);
    pinAddButtonsToColumnEnd();
    refreshSectionVisibility();
    updateAllSectionsDraggable();
    saveLayoutNow();
  }

  function getPrimaryWorkspaceSectionId() {
    return isNetworkDashboard() ? NETWORK_WORKSPACE_MAIN_SECTION_ID : WORKSPACE_MAIN_SECTION_ID;
  }

  function findFactorySectionForCard(cardId, factoryCards) {
    if (!cardId || !factoryCards || typeof factoryCards !== 'object') {
      return '';
    }
    var keys = Object.keys(factoryCards);
    for (var i = 0; i < keys.length; i++) {
      var ids = factoryCards[keys[i]];
      if (Array.isArray(ids) && ids.indexOf(cardId) !== -1) {
        return keys[i];
      }
    }
    return '';
  }

  function insertCardIdInFactoryOrder(list, cardId, factoryOrder) {
    var out = (list || []).filter(function (id) {
      return id && id !== cardId;
    });
    if (!cardId) {
      return out;
    }
    if (!Array.isArray(factoryOrder) || !factoryOrder.length) {
      out.push(cardId);
      return out;
    }
    var targetIdx = factoryOrder.indexOf(cardId);
    if (targetIdx === -1) {
      out.push(cardId);
      return out;
    }
    var insertPos = out.length;
    for (var j = 0; j < out.length; j++) {
      var fi = factoryOrder.indexOf(out[j]);
      if (fi !== -1 && fi > targetIdx) {
        insertPos = j;
        break;
      }
    }
    out.splice(insertPos, 0, cardId);
    return out;
  }

  function restoreCardsFromCustomSection(section) {
    var sectionId = getSectionId(section);
    var factoryCards = getFactoryCardsLayout();
    var layout = serializeLayout({ skipCleanup: true });
    var cardsMap = layout && layout.cards ? Object.assign({}, layout.cards) : {};

    if (sectionId) {
      delete cardsMap[sectionId];
    }

    Array.prototype.forEach.call(section.querySelectorAll('[data-card-id]'), function (card) {
      var cardId = getCardId(card);
      if (!cardId) {
        return;
      }
      var homeId =
        findFactorySectionForCard(cardId, factoryCards) || getPrimaryWorkspaceSectionId();
      if (!root.querySelector('[data-section-id="' + homeId + '"]')) {
        homeId = getPrimaryWorkspaceSectionId();
      }
      cardsMap[homeId] = insertCardIdInFactoryOrder(
        cardsMap[homeId] || [],
        cardId,
        factoryCards[homeId] || []
      );
    });

    applyCardsLayout(cardsMap);
    return cardsMap;
  }

  function removeCustomSection(section) {
    if (!section || !section.classList.contains('yp-studio-custom-section')) {
      return;
    }

    restoreCardsFromCustomSection(section);

    if (section.parentNode) {
      section.parentNode.removeChild(section);
    }

    cleanupAllGrids();
    root.querySelectorAll('.yp-dashboard-section[data-section-id]').forEach(function (target) {
      if (isCustomSection(target)) {
        syncCustomSection(target);
      }
      if (isExtensionsSection(target)) {
        syncExtensionsAsidePlacement(target);
        syncExtensionsSection(target);
      }
    });
    if (window.YOOAdminWorkspacePagination) {
      window.YOOAdminWorkspacePagination.refresh();
    }
    rebindAllCards();
    updateAllSectionsDraggable();
    if (!suppressLayoutSave) {
      saveLayoutNow();
    }
    refreshSectionVisibility();
  }

  function getGridCardItems(grid) {
    return Array.prototype.filter.call(grid.children, function (child) {
      return (
        child !== draggingCard &&
        child !== dropSlot &&
        child.hasAttribute('data-card-id') &&
        !child.hidden &&
        !child.classList.contains('yp-ws-page-hidden')
      );
    });
  }

  /** Grid-aware insert (multi-column rows). */
  function getInsertBefore(grid, clientX, clientY) {
    var items = getGridCardItems(grid);
    if (!items.length) {
      return null;
    }

    for (var h = 0; h < items.length; h++) {
      var hit = items[h].getBoundingClientRect();
      if (
        clientX >= hit.left &&
        clientX <= hit.right &&
        clientY >= hit.top &&
        clientY <= hit.bottom
      ) {
        var afterX = clientX > hit.left + hit.width * 0.5;
        var afterY = clientY > hit.top + hit.height * 0.5;
        if (afterX || afterY) {
          var n = items[h].nextElementSibling;
          while (n && (!n.hasAttribute('data-card-id') || n === dropSlot)) {
            n = n.nextElementSibling;
          }
          return n || null;
        }
        return items[h];
      }
    }

    var rows = groupCardsIntoRows(items);
    var rowIndex = rows.length;

    for (var r = 0; r < rows.length; r++) {
      var rowBox = unionCardRects(rows[r]);
      if (clientY < rowBox.top + rowBox.height * 0.5) {
        rowIndex = r;
        break;
      }
      if (clientY <= rowBox.bottom) {
        rowIndex = r + 1;
        break;
      }
    }

    if (rowIndex >= rows.length) {
      return null;
    }

    var row = rows[rowIndex];
    for (var c = 0; c < row.length; c++) {
      var cell = row[c].getBoundingClientRect();
      if (clientX < cell.left + cell.width * 0.5) {
        return row[c];
      }
    }

    var lastInRow = row[row.length - 1];
    var next = lastInRow.nextElementSibling;
    while (next && (!next.hasAttribute('data-card-id') || next === dropSlot)) {
      next = next.nextElementSibling;
    }
    return next || null;
  }

  function applyDropPosition(grid, clientX, clientY) {
    if (!grid || !draggingCard) {
      return;
    }
    grid = resolveDropGrid(grid);
    if (!grid) {
      return;
    }
    var before = getInsertBefore(grid, clientX, clientY);
    var dropKey =
      getSectionId(grid.closest('.yp-dashboard-section')) +
      '|' +
      (before ? getCardId(before) : '@end');
    if (dropKey === lastCardDropKey && dropSlot && dropSlot.parentNode === grid) {
      return;
    }
    lastCardDropKey = dropKey;

    placeDropSlotInGrid(grid, before);
  }

  function finishCardDrag() {
    if (draggingCard && dropSlot && dropSlot.parentNode) {
      dropSlot.parentNode.insertBefore(draggingCard, dropSlot);
    }
    if (draggingCard && isWorkspaceDropInvalid(draggingCard)) {
      restoreDragCardOrigin(draggingCard);
      showWorkspaceToast(
        t(
          'workspaceMinItemsToast',
          'This section requires at least 3 items.'
        )
      );
    }
    dragFromWorkspace = false;
    dragCardOrigin = null;
    if (draggingCard) {
      draggingCard.classList.remove('is-dragging');
    }
    draggingCard = null;
    pointerDrag.active = false;
    pointerDrag.pointerId = null;
    if (dragRaf) {
      cancelAnimationFrame(dragRaf);
      dragRaf = 0;
    }
    removeDropSlot();
    lastCardDropKey = '';
    cleanupAllGrids();
    if (window.YOOAdminWorkspacePagination) {
      window.YOOAdminWorkspacePagination.handleDragEnd();
    }
    saveLayoutNow();
    refreshSectionVisibility();
  }

  function onDragHandlePointerDown(e) {
    if (!isLayoutEditActive() || e.button !== 0) {
      return;
    }
    var card = e.currentTarget.closest('[data-card-id]');
    if (!card) {
      return;
    }
    draggingCard = card;
    var startGrid = findGridAtPoint(e.clientX, e.clientY);
    var originGrid =
      card.closest('.yp-cards-grid[data-sortable="true"]') ||
      card.closest('.yp-cards-grid');
    dragCardOrigin = captureDragCardOrigin(card);
    dragFromWorkspace = isWorkspaceGrid(originGrid) || isNetworkWorkspaceGrid(originGrid);
    if (window.YOOAdminWorkspacePagination) {
      window.YOOAdminWorkspacePagination.handleDragStart(card);
    }
    lastCardDropKey = '';
    pointerDrag.active = true;
    pointerDrag.pointerId = e.pointerId;
    card.classList.add('is-dragging');
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch (err) {
      /* ignore */
    }
    e.preventDefault();
    e.stopPropagation();
    if (startGrid) {
      applyDropPosition(startGrid, e.clientX, e.clientY);
    }
  }

  function onDragHandlePointerMove(e) {
    if (!pointerDrag.active || e.pointerId !== pointerDrag.pointerId || !draggingCard) {
      return;
    }
    e.preventDefault();
    if (window.YOOAdminWorkspacePagination) {
      window.YOOAdminWorkspacePagination.handleDragMove(e.clientX, e.clientY);
    }
    var grid = resolveDropGrid(findGridAtPoint(e.clientX, e.clientY));
    if (!grid) {
      removeDropSlot();
      lastCardDropKey = '';
      return;
    }
    pendingDrop.grid = grid;
    pendingDrop.x = e.clientX;
    pendingDrop.y = e.clientY;
    if (dragRaf) {
      return;
    }
    dragRaf = requestAnimationFrame(function () {
      dragRaf = 0;
      if (pendingDrop.grid && draggingCard) {
        applyDropPosition(pendingDrop.grid, pendingDrop.x, pendingDrop.y);
      }
    });
  }

  function onDragHandlePointerUp(e) {
    if (!pointerDrag.active || e.pointerId !== pointerDrag.pointerId) {
      return;
    }
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch (err2) {
      /* ignore */
    }
    finishCardDrag();
  }

  function onGridDragEnter(e) {
    if (!isLayoutEditActive() || !draggingCard) {
      return;
    }
    e.preventDefault();
  }

  function onGridDragOver(e) {
    if (!isLayoutEditActive() || !draggingCard) {
      return;
    }
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'move';
    var hitGrid = e.currentTarget;
    pendingDrop.grid = hitGrid;
    pendingDrop.x = e.clientX;
    pendingDrop.y = e.clientY;
    if (dragRaf) {
      return;
    }
    dragRaf = requestAnimationFrame(function () {
      dragRaf = 0;
      if (pendingDrop.grid) {
        applyDropPosition(pendingDrop.grid, pendingDrop.x, pendingDrop.y);
      }
    });
  }

  function onGridDragLeave(e) {
    if (e.target === this && !this.contains(e.relatedTarget)) {
      this.classList.remove('is-drag-over');
    }
  }

  function onGridDrop(e) {
    if (!isLayoutEditActive() || !draggingCard) {
      return;
    }
    e.preventDefault();
    this.classList.remove('is-drag-over');

    var targetGrid = resolveDropGrid(this);
    if (dropSlot && dropSlot.parentNode === targetGrid) {
      targetGrid.insertBefore(draggingCard, dropSlot);
      removeDropSlot();
    } else if (targetGrid) {
      targetGrid.appendChild(draggingCard);
    }

    if (isWorkspaceDropInvalid(draggingCard)) {
      restoreDragCardOrigin(draggingCard);
      showWorkspaceToast(
        t(
          'workspaceMinItemsToast',
          'This section requires at least 3 items.'
        )
      );
    }

    cleanupGrid(targetGrid || this);
    dragFromWorkspace = false;
    dragCardOrigin = null;
    if (window.YOOAdminWorkspacePagination) {
      window.YOOAdminWorkspacePagination.handleDragEnd();
    }
    saveLayoutNow();
    refreshSectionVisibility();
  }

  function finishSectionDrag() {
    if (window.YOOStudioHubLayoutCoordinator) {
      window.YOOStudioHubLayoutCoordinator.markUserEditing(true);
    }
    var blockedAsideDrop =
      draggingSection &&
      isMainColumnLockedSection(draggingSection) &&
      getDropColumn(pendingSectionDrop.x, pendingSectionDrop.y) === 'aside';

    if (blockedAsideDrop) {
      rejectWorkspaceAsideMove(draggingSection, true);
    } else {
      commitSectionDrop();
    }
    if (draggingSection) {
      draggingSection.classList.remove('is-section-dragging');
    }
    draggingSection = null;
    sectionPointerDrag.active = false;
    sectionPointerDrag.pointerId = null;
    pendingSectionDrop.x = 0;
    pendingSectionDrop.y = 0;
    removeSectionDropMarker();
    mainEl.classList.remove('yp-layout-column--drag-over');
    asideEl.classList.remove('yp-layout-column--drag-over');
    asideEl.classList.remove('yp-layout-column--drop-blocked');
    pinAddButtonsToColumnEnd();
    dragSectionOrigin = null;
    var payload = serializeLayout({ skipCleanup: true });
    var coord = window.YOOStudioHubLayoutCoordinator;
    writeStorage(payload, { serverImmediate: true, bumpGeneration: true }).then(function () {
      if (coord) {
        coord.markUserEditing(false);
      }
      if (asideEl && payload && payload.asideOrder) {
        asideEl.setAttribute('data-default-aside-order', payload.asideOrder.join(','));
      }
      if (payload) {
        try {
          root.setAttribute('data-initial-layout', JSON.stringify(payload));
        } catch (e) {
          /* ignore */
        }
      }
      refreshSectionVisibility();
    });
  }

  function onSectionHandlePointerDown(e) {
    if (!isLayoutEditActive() || e.button !== 0) {
      return;
    }
    var section = e.currentTarget.closest('.yp-dashboard-section');
    if (!section || !isMovableSection(section)) {
      return;
    }
    draggingSection = section;
    dragSectionOrigin = captureDragSectionOrigin(section);
    sectionDropTarget = { column: null, beforeId: null };
    sectionPointerDrag.active = true;
    sectionPointerDrag.pointerId = e.pointerId;
    pendingSectionDrop.x = e.clientX;
    pendingSectionDrop.y = e.clientY;
    section.classList.add('is-section-dragging');
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch (err) {
      /* ignore */
    }
    e.preventDefault();
    e.stopPropagation();
    updateSectionDropMarker(getDropColumn(e.clientX, e.clientY), e.clientY);
  }

  function onSectionHandlePointerMove(e) {
    if (
      !sectionPointerDrag.active ||
      e.pointerId !== sectionPointerDrag.pointerId ||
      !draggingSection
    ) {
      return;
    }
    e.preventDefault();
    pendingSectionDrop.x = e.clientX;
    pendingSectionDrop.y = e.clientY;
    updateSectionDropMarker(getDropColumn(e.clientX, e.clientY), e.clientY);
  }

  function onSectionHandlePointerUp(e) {
    if (!sectionPointerDrag.active || e.pointerId !== sectionPointerDrag.pointerId) {
      return;
    }
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch (err2) {
      /* ignore */
    }
    finishSectionDrag();
  }

  function markCardNavigationLoading(card) {
    if (!card || card.classList.contains('is-card-navigation-loading')) {
      return;
    }
    card.classList.add('is-card-navigation-loading');
    card.setAttribute('aria-busy', 'true');
  }

  function clearCardNavigationLoading(card) {
    if (!card) {
      return;
    }
    card.classList.remove('is-card-navigation-loading');
    card.removeAttribute('aria-busy');
  }

  function clearAllCardNavigationLoading() {
    root.querySelectorAll('.is-card-navigation-loading').forEach(clearCardNavigationLoading);
  }

  function bindCard(card) {
    if (!card) {
      return;
    }
    ensureLayoutDragHandle(card);
    ensureVisibilityToggle(card);
    if (card.getAttribute('data-layout-bound') === '1') {
      syncCardEditInteraction(card);
      applyCardHiddenState(card);
      return;
    }
    card.addEventListener('click', function (evt) {
      if (!isLayoutEditActive()) {
        if (
          evt.defaultPrevented ||
          evt.button !== 0 ||
          evt.metaKey ||
          evt.ctrlKey ||
          evt.shiftKey ||
          evt.altKey ||
          evt.target.closest('.yp-card-visibility-toggle, .yp-card-icon-edit, .yp-layout-card-drag-handle')
        ) {
          return;
        }
        if (card.getAttribute('data-menu-slug')) {
          clearCardNavigationLoading(card);
          return;
        }
        var href = card.getAttribute('href') || '';
        var target = (card.getAttribute('target') || '').toLowerCase();
        if (!href || href === '#' || href.indexOf('javascript:') === 0 || target === '_blank') {
          return;
        }
        window.setTimeout(function () {
          if (
            evt.defaultPrevented ||
            document.documentElement.classList.contains('yoo-popup-open') ||
            document.body.classList.contains('yp-modal-open')
          ) {
            clearCardNavigationLoading(card);
            return;
          }
          markCardNavigationLoading(card);
        }, 0);
        return;
      }
      if (evt.target.closest('.yp-card-visibility-toggle, .yp-card-icon-edit')) {
        return;
      }
      evt.preventDefault();
      evt.stopPropagation();
    });
    card.setAttribute('data-layout-bound', '1');
    syncCardEditInteraction(card);
    applyCardHiddenState(card);
  }

  function bindGrid(grid) {
    if (!grid) {
      return;
    }
    if (grid.getAttribute('data-layout-grid-bound') !== '1') {
      grid.setAttribute('data-sortable', 'true');
      grid.addEventListener('dragenter', onGridDragEnter);
      grid.addEventListener('dragover', onGridDragOver);
      grid.addEventListener('dragleave', onGridDragLeave);
      grid.addEventListener('drop', onGridDrop);
      grid.setAttribute('data-layout-grid-bound', '1');
    }
    Array.prototype.forEach.call(grid.querySelectorAll('[data-card-id]'), bindCard);
  }

  function rebindAllCards() {
    root.querySelectorAll('[data-card-id]').forEach(bindCard);
    getSortableGrids().forEach(bindGrid);
    updateCardsDraggable();
  }

  function bindSection(section) {
    if (!section) {
      return;
    }
    var alreadyBound = section.getAttribute('data-layout-section-bound') === '1';
    if (isSectionLocked(section)) {
      section.classList.add('yp-layout-section--locked');
    } else {
      section.classList.remove('yp-layout-section--locked');
      ensureSectionDragHandle(section);
    }

    if (!alreadyBound) {
      var removeBtn = section.querySelector('.yp-layout-section-remove');
      if (removeBtn) {
        removeBtn.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          if (isLayoutEditActive()) {
            removeRemovableSection(section);
          }
        });
      }
      if (!isWidgetSection(section)) {
        bindSectionTitle(section);
        bindSectionIcon(section);
      }
      section.setAttribute('data-layout-section-bound', '1');
    }

    ensureSectionVisibilityToggle(section);
    ensureWorkspaceAddButton(section);
    if (!isWidgetSection(section)) {
      bindGrid(getSectionGrid(section));
      bindSectionIcon(section);
    }
    updateSectionDraggable(section);
    syncSectionVisibilityToggle(section);
    if (isNetworkDashboard() && window.YOOAdminWorkspacePagination) {
      var sid = getSectionId(section);
      if (
        sid === NETWORK_WORKSPACE_MAIN_SECTION_ID ||
        sid === 'network-sites' ||
        section.classList.contains('yp-studio-custom-section')
      ) {
        window.YOOAdminWorkspacePagination.ensureSection(section);
        window.YOOAdminWorkspacePagination.syncSection(section);
      }
    }
  }

  function bindAllLayoutSections() {
    root
      .querySelectorAll('.yp-dashboard-section[data-layout-section="true"]')
      .forEach(bindSection);
  }

  function bindContainers() {
    bindAllLayoutSections();

    if (topSectionEl) {
      topSectionEl.classList.add('yp-layout-block--locked');
    }

    root.querySelectorAll('[data-card-id]').forEach(bindCard);
    getSortableGrids().forEach(bindGrid);
  }

  function focusEditMode(toggleBtn) {
    if (toggleBtn && typeof toggleBtn.focus === 'function') {
      toggleBtn.focus({ preventScroll: true });
    }
  }

  function setLayoutEdit(on, toggleBtn) {
    var desired = !!on;
    if (desired === layoutEditOn) {
      return;
    }
    layoutEditOn = desired;
    document.body.classList.toggle('yp-layout-edit-mode', layoutEditOn);
    document.documentElement.classList.toggle('yp-layout-edit-mode', layoutEditOn);

    ensureAddButtons();
    syncWorkspaceAddButtons();

    if (layoutEditOn) {
      bindContainers();
      rebindAllCards();
      root.querySelectorAll('.yp-studio-custom-section').forEach(function (section) {
        bindSection(section);
        bindSectionTitle(section);
        bindGrid(getSectionGrid(section));
      });
      focusEditMode(toggleBtn || root.querySelector('[data-icon-edit-toggle="main-grid"]'));
    } else {
      root.querySelectorAll('.yp-studio-custom-section.yp-section-title--editing').forEach(function (section) {
        commitSectionTitleEdit(section);
      });
      removeDropSlot();
      purgeEmptyCustomSectionsFromDom();
      saveLayoutNow();
    }
    updateCardsDraggable();
    updateAllSectionsDraggable();
    applyAllHiddenStates();
    applyAllSectionHiddenStates();
    refreshSectionVisibility();
    if (window.YOOAdminWorkspacePagination) {
      window.YOOAdminWorkspacePagination.refresh();
    }
  }

  function readIconEditOn() {
    return (
      document.body.classList.contains('yp-icon-edit-mode') ||
      document.documentElement.classList.contains('yp-icon-edit-mode')
    );
  }

  function hookEditToggle() {
    root.addEventListener(
      'click',
      function (e) {
        var btn = e.target.closest('[data-icon-edit-toggle]');
        if (!btn || !root.contains(btn)) {
          return;
        }
        window.requestAnimationFrame(function () {
          setLayoutEdit(readIconEditOn(), btn);
        });
      },
      false
    );
  }

  function hookReset() {
    root.addEventListener(
      'click',
      function (e) {
        var btn = e.target.closest('[data-icon-edit-reset="main-grid"]');
        if (!btn || !root.contains(btn)) {
          return;
        }
        e.preventDefault();
        e.stopImmediatePropagation();
        resetDashboardAll();
      },
      true
    );
  }

  function layoutStructureMatchesData(data) {
    if (!layoutDomMatchesData(data)) {
      return false;
    }
    var ext = root.querySelector('[data-section-id="from-extensions"]');
    if (ext) {
      var extInAside = !!(asideEl && asideEl.contains(ext));
      var extListedAside = (data.asideOrder || []).indexOf('from-extensions') !== -1;
      var extListedMain = (data.mainOrder || []).indexOf('from-extensions') !== -1;
      if (extInAside !== extListedAside) {
        return false;
      }
      if (!extInAside && !extListedMain) {
        return false;
      }
    }
    var asideIds = getLayoutSections(asideEl).map(getSectionId).filter(Boolean);
    var expectedAside = (data.asideOrder || []).filter(function (id) {
      return id && asideIds.indexOf(id) !== -1;
    });
    if (expectedAside.length && JSON.stringify(asideIds) !== JSON.stringify(expectedAside)) {
      return false;
    }
    var mainIds = getLayoutSections(mainEl).map(getSectionId).filter(Boolean);
    var expectedMain = (data.mainOrder || []).filter(function (id) {
      return id && mainIds.indexOf(id) !== -1;
    });
    if (expectedMain.length && JSON.stringify(mainIds) !== JSON.stringify(expectedMain)) {
      return false;
    }
    return true;
  }

  function watchEditModeClass() {
    function syncFromDom() {
      var on = readIconEditOn();
      if (on !== layoutEditOn) {
        setLayoutEdit(on);
      } else {
        updateCardsDraggable();
        updateAllSectionsDraggable();
        applyAllSectionHiddenStates();
        syncWorkspaceAddButtons();
        syncLayoutColumns();
        refreshSectionVisibility();
        root
          .querySelectorAll('.yp-studio-aside-layout-section[data-section-id]')
          .forEach(syncSectionVisibilityToggle);
      }
    }
    var obs = new MutationObserver(syncFromDom);
    if (document.body) {
      obs.observe(document.body, { attributes: true, attributeFilter: ['class'] });
    }
    if (document.documentElement) {
      obs.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['class'],
      });
    }
  }

  function finishLayoutBoot() {
    if (root) {
      root.classList.remove('yp-studio-hub--layout-booting');
      root.removeAttribute('data-layout-ssr-pending');
    }
    document.body.classList.remove(
      'yoo-network-site-users-modal-open',
      'yp-modal-open'
    );
  }

  function init() {
    root.querySelectorAll('.yp-studio-extension-slots').forEach(function (el) {
      if (el.parentNode) {
        el.parentNode.removeChild(el);
      }
    });
    ensureAddButtons();
    captureDefaultLayoutIfNeeded();
    bindContainers();
    syncLocalizedDashboardStrings();
    hookEditToggle();
    hookReset();
    watchEditModeClass();
    var domLayout = readInitialLayoutFromDom();
    if (domLayout && domLayout.version === LAYOUT_VERSION) {
      applyHiddenSectionsFromData(domLayout);
    } else {
      applyDefaultHiddenSections();
      applyDefaultRemovedBuiltInSections();
      applyAllSectionHiddenStates();
      syncLayoutColumns();
    }
    var iconEditOn = readIconEditOn();
    setLayoutEdit(iconEditOn);
    if (!iconEditOn && window.YPCardIcons && typeof window.YPCardIcons.setEditMode === 'function') {
      window.YPCardIcons.setEditMode(false);
    }
    rebindAllCards();
    updateAllSectionsDraggable();
    refreshSectionVisibility();
    if (root.querySelector('[data-section-id="from-extensions"] .yp-studio-extensions-grid.is-hydrated')) {
      markExtensionsSectionsHydrated();
      refreshSectionVisibility();
    }
    window.addEventListener('beforeunload', flushLayoutOnUnload);
    window.addEventListener('pagehide', flushLayoutOnUnload);
    window.YOOStudioHubLayout = {
      resetAll: resetDashboardAll,
      save: saveLayoutNow,
      patchStorage: function (partial) {
        if (!partial || typeof partial !== 'object') {
          return;
        }
        var data = readStorage();
        if (!data || data.version !== LAYOUT_VERSION) {
          data = serializeLayout();
        } else {
          cleanupAllGrids();
        }
        Object.keys(partial).forEach(function (key) {
          data[key] = partial[key];
        });
        writeStorage(data);
      },
    };
    if (window.YOOAdminWorkspacePagination) {
      window.YOOAdminWorkspacePagination.refresh();
    }
  }

  function getExpectedHiddenForData(data) {
    if (!data) {
      return DEFAULT_HIDDEN_SECTIONS.slice();
    }
    if (layoutHasUserSectionVisibility(data)) {
      return (data.hiddenSections || []).slice();
    }
    if (!data.hiddenSections || !data.hiddenSections.length) {
      return DEFAULT_HIDDEN_SECTIONS.slice();
    }
    return data.hiddenSections.slice();
  }

  function layoutDomMatchesData(data) {
    if (!data || data.version !== LAYOUT_VERSION) {
      return false;
    }
    var expectedHidden = getExpectedHiddenForData(data).slice().sort();
    var domHidden = getHiddenSectionIdList().slice().sort();
    if (JSON.stringify(expectedHidden) !== JSON.stringify(domHidden)) {
      return false;
    }
    var collapseAside = !asideHasVisibleSections() && !isLayoutEditActive();
    if (layoutEl) {
      var hasEmptyClass = layoutEl.classList.contains('yp-studio-hub__layout--aside-empty');
      if (collapseAside !== hasEmptyClass) {
        return false;
      }
    }
    return true;
  }

  function boot() {
    registerLayoutEditorApi();
    init();
    finishLayoutBoot();
  }

  document.addEventListener('yooadmin-studio-hub-grids-ready', function () {
    markExtensionsSectionsHydrated();
    refreshSectionVisibility();
  });

  window.yooadminStudioHubInitLoginSecurityWidget = animateLoginSecurityScoreWidget;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
