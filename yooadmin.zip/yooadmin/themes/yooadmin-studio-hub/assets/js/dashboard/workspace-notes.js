/**
 * Studio Hub — Workspace Notes (aside panel).
 */
(function ($) {
  'use strict';

  function resolveCfg($root) {
    var cfg = $.extend(true, {}, window.yooadminWorkspaceNotes || {});
    if ($root && $root.length) {
      if (!cfg.ajaxUrl) {
        cfg.ajaxUrl = $root.attr('data-ws-ajax-url') || '';
      }
      if (!cfg.nonce) {
        cfg.nonce = $root.attr('data-ws-nonce') || '';
      }
    }
    return cfg;
  }

  function bindWorkspaceNotesPanel($root) {
    if (!$root.length || $root.attr('data-yp-ws-notes-bound') === '1') {
      return;
    }

    var cfg = resolveCfg($root);
    if (!cfg.ajaxUrl || !cfg.nonce) {
      return;
    }

    $root.attr('data-yp-ws-notes-bound', '1');

      var $notesCard = $root.closest('.yp-studio-workspace-notes-card');
      var i18n = cfg.i18n || {};
      var types = cfg.types || {};
      var $picker = $root.find('.yp-studio-workspace-notes__type-picker');
      var $typeTrigger = $picker.find('.yp-studio-workspace-notes__type-trigger');
      var $typeMenu = $picker.find('.yp-studio-workspace-notes__type-menu');
      var $typeLabel = $picker.find('.yp-studio-workspace-notes__type-trigger-label');
      var $typeIcon = $typeTrigger.find('.dashicons').first();
      var $addBtn = $root.find('.yp-studio-workspace-notes__add-btn');
      var $formWrap = $root.find('.yp-studio-workspace-notes__form-wrap');
      var $form = $root.find('.yp-studio-workspace-notes__form');
      var $listWrap = $root.find('.yp-studio-workspace-notes__list-wrap');
      var $list = $root.find('.yp-studio-workspace-notes__list');
      var $loadMoreBtn = $listWrap.find('.yp-studio-workspace-notes__load-more');
      var $dueRow = $root.find('.yp-studio-workspace-notes__due-row');
      var $remindRow = $root.find('.yp-studio-workspace-notes__remind-row');
      var $dueInput = $form.find('[name="due_at"]');
      var $remindInput = $form.find('[name="remind_at"]');
      var activeType = $root.attr('data-active-type') || 'todos';
      var busy = false;
      var NOTES_PAGE_SIZE = parseInt(cfg.pageSize, 10) || 3;
      var hasMoreNotes = $loadMoreBtn.length > 0 && !$loadMoreBtn.prop('hidden');

      function post(action, data) {
        return $.ajax({
          url: cfg.ajaxUrl,
          method: 'POST',
          dataType: 'json',
          timeout: 45000,
          data: $.extend(
            {
              action: action,
              nonce: cfg.nonce,
            },
            data || {}
          ),
        });
      }

      function escapeHtml(str) {
        return String(str || '')
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;');
      }

      function sprintf(template, value) {
        return String(template || '%s').replace('%s', value);
      }

      /** Site wall-clock string (Y-m-d\\TH:i) for datetime-local — digits match WordPress timezone. */
      function normalizeSiteNaive(inputVal) {
        if (!inputVal) {
          return '';
        }
        var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(String(inputVal).trim());
        if (!m) {
          return String(inputVal).trim();
        }
        return (
          m[1] +
          '-' +
          m[2] +
          '-' +
          m[3] +
          'T' +
          m[4] +
          ':' +
          m[5]
        );
      }

      /** datetime-local value → site wall-clock (server parses with wp_timezone()). */
      function inputToSiteNaive(inputVal) {
        return normalizeSiteNaive(inputVal);
      }

      function prefillDatetimeInput($input) {
        if (!$input.length || !cfg.nowLocal) {
          return;
        }
        $input.val(normalizeSiteNaive(cfg.nowLocal));
      }

      function typeDef(type) {
        return types[type] || {};
      }

      var DELETE_MODAL_ID = 'yp-ws-note-delete-modal';

      function showToast(message, type) {
        if (!message) {
          return;
        }
        type = type || 'success';
        if (type === 'warning') {
          type = 'info';
        }
        $('.yp-toast-message.yp-ws-notes-toast').remove();
        var iconChar = type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ';
        var $toast = $(
          '<div class="yp-toast-message yp-ws-notes-toast yp-toast-' +
            type +
            '">' +
            '<span class="yp-toast-icon" aria-hidden="true">' +
            iconChar +
            '</span>' +
            '<span class="yp-toast-text"></span>' +
            '</div>'
        );
        $toast.find('.yp-toast-text').text(message);
        $('body').append($toast);
        window.setTimeout(function () {
          $toast.addClass('yp-toast-show');
        }, 10);
        window.setTimeout(function () {
          $toast.removeClass('yp-toast-show');
          window.setTimeout(function () {
            $toast.remove();
          }, 300);
        }, 3200);
      }

      function ajaxErrorMessage(res) {
        if (res && res.responseJSON && res.responseJSON.data && res.responseJSON.data.message) {
          return res.responseJSON.data.message;
        }
        return i18n.errorGeneric || 'Something went wrong. Please try again.';
      }

      function removeDeleteModal() {
        var modal = document.getElementById(DELETE_MODAL_ID);
        if (modal && modal.parentNode) {
          modal.parentNode.removeChild(modal);
        }
        document.body.classList.remove('yp-alert-open');
      }

      function confirmDeleteModal(onConfirm) {
        removeDeleteModal();

        var title = i18n.deleteModalTitle || 'Delete note?';
        var message = i18n.deleteModalMessage || 'This note will be removed permanently.';
        var cancelLabel = i18n.cancel || 'Cancel';
        var deleteLabel = i18n.deleteConfirm || 'Delete';

        var html =
          '<div id="' +
          DELETE_MODAL_ID +
          '" class="yp-alert-modal" role="dialog" aria-modal="true" aria-labelledby="yp-ws-note-delete-title">' +
          '<div class="yp-alert-overlay" data-ws-note-delete-close></div>' +
          '<div class="yp-alert-content">' +
          '<div class="yp-alert-header">' +
          '<span class="yp-alert-icon warning dashicons dashicons-warning" aria-hidden="true"></span>' +
          '<h2 id="yp-ws-note-delete-title" class="yp-alert-title">' +
          escapeHtml(title) +
          '</h2>' +
          '</div>' +
          '<div class="yp-alert-body"><p class="yp-alert-message">' +
          escapeHtml(message) +
          '</p></div>' +
          '<div class="yp-alert-footer">' +
          '<button type="button" class="yp-alert-btn yp-alert-btn-secondary" data-ws-note-delete-close>' +
          escapeHtml(cancelLabel) +
          '</button>' +
          '<button type="button" class="yp-alert-btn yp-alert-btn-primary" data-ws-note-delete-confirm>' +
          escapeHtml(deleteLabel) +
          '</button>' +
          '</div>' +
          '</div>' +
          '</div>';

        document.body.insertAdjacentHTML('beforeend', html);
        document.body.classList.add('yp-alert-open');

        var modal = document.getElementById(DELETE_MODAL_ID);
        if (!modal) {
          return;
        }

        modal.querySelectorAll('[data-ws-note-delete-close]').forEach(function (el) {
          el.addEventListener('click', removeDeleteModal);
        });

        var confirmBtn = modal.querySelector('[data-ws-note-delete-confirm]');
        if (confirmBtn) {
          confirmBtn.addEventListener('click', function () {
            removeDeleteModal();
            if (typeof onConfirm === 'function') {
              onConfirm();
            }
          });
        }

        document.addEventListener(
          'keydown',
          function escHandler(e) {
            if (e.key === 'Escape' && document.getElementById(DELETE_MODAL_ID)) {
              removeDeleteModal();
              document.removeEventListener('keydown', escHandler);
            }
          },
          { once: true }
        );
      }

      function closeTypeMenu() {
        $typeMenu.prop('hidden', true);
        $typeTrigger.attr('aria-expanded', 'false');
        $notesCard.removeClass('is-type-menu-open');
      }

      function openTypeMenu() {
        $typeMenu.prop('hidden', false);
        $typeTrigger.attr('aria-expanded', 'true');
        $notesCard.addClass('is-type-menu-open');
      }

      function updateTypeTrigger(type) {
        var def = typeDef(type);
        $typeLabel.text(def.label || type);
        if (def.icon) {
          $typeIcon.attr('class', 'dashicons ' + def.icon);
        }
        $typeMenu.find('.yp-studio-workspace-notes__type-option').each(function () {
          var $opt = $(this);
          var on = $opt.data('note-type') === type;
          $opt.toggleClass('is-active', on);
          $opt.attr('aria-selected', on ? 'true' : 'false');
        });
      }

      function syncFormFields(prefillNow) {
        var $hints = $form.find('[data-ws-datetime-hint]');
        if (activeType === 'todos') {
          $dueRow.prop('hidden', false);
          $remindRow.prop('hidden', true);
          $remindInput.val('').prop('disabled', true);
          $dueInput.prop('disabled', false);
          $hints.prop('hidden', false);
          if (prefillNow && !$dueInput.val()) {
            prefillDatetimeInput($dueInput);
          }
        } else if (activeType === 'reminders') {
          $dueRow.prop('hidden', true);
          $dueInput.val('').prop('disabled', true);
          $remindRow.prop('hidden', false);
          $remindInput.prop('disabled', false);
          $hints.prop('hidden', false);
          if (prefillNow && !$remindInput.val()) {
            prefillDatetimeInput($remindInput);
          }
        } else {
          $dueRow.prop('hidden', true);
          $remindRow.prop('hidden', true);
          $dueInput.val('').prop('disabled', true);
          $remindInput.val('').prop('disabled', true);
          $hints.prop('hidden', true);
        }
      }

      function setAddFormOpen(open) {
        $formWrap.prop('hidden', !open);
        $addBtn.attr('aria-expanded', open ? 'true' : 'false');
        $root.toggleClass('is-add-open', open);
        if (open) {
          syncFormFields(true);
          $form.find('[name="title"]').trigger('focus');
        } else {
          $form[0].reset();
          syncFormFields(false);
        }
      }

      function metaHtml(note, type) {
        var done = !!note.is_done;
        var html = '';

        if (note.created_at_label) {
          html +=
            '<span class="yp-studio-workspace-notes__item-meta yp-studio-workspace-notes__item-meta--added">' +
            escapeHtml(sprintf(i18n.added || 'Added: %s', note.created_at_label)) +
            '</span>';
        }
        if (type === 'todos' && note.due_at_label && !done) {
          html +=
            '<span class="yp-studio-workspace-notes__item-meta yp-studio-workspace-notes__item-meta--due">' +
            escapeHtml(sprintf(i18n.due || 'Due: %s', note.due_at_label)) +
            '</span>';
        }
        if (type === 'todos' && note.completed_at_label && done) {
          html +=
            '<span class="yp-studio-workspace-notes__item-meta yp-studio-workspace-notes__item-meta--done">' +
            escapeHtml(sprintf(i18n.completed || 'Completed: %s', note.completed_at_label)) +
            '</span>';
        }
        if (type === 'reminders' && note.remind_at_label) {
          html +=
            '<span class="yp-studio-workspace-notes__item-meta yp-studio-workspace-notes__item-meta--remind">' +
            escapeHtml(sprintf(i18n.remind || 'Remind: %s', note.remind_at_label)) +
            '</span>';
        }
        return html;
      }

      function getLoadedCount() {
        return $list.find('.yp-studio-workspace-notes__item').length;
      }

      function ensureLoadMoreButton() {
        if (!$loadMoreBtn.length) {
          $loadMoreBtn = $(
            '<button type="button" class="yp-studio-workspace-notes__load-more">' +
              '<span class="yp-studio-workspace-notes__load-more-label"></span>' +
              '<span class="yp-studio-workspace-notes__load-more-spinner" aria-hidden="true" hidden>' +
              '<span class="yp-spinner-circle"></span>' +
              '</span>' +
              '</button>'
          );
          $listWrap.append($loadMoreBtn);
        }
        $loadMoreBtn.find('.yp-studio-workspace-notes__load-more-label').text(i18n.loadMore || 'Load more');
        return $loadMoreBtn;
      }

      function setLoadMoreLoading(loading) {
        var $btn = ensureLoadMoreButton();
        $btn.toggleClass('is-loading', !!loading);
        $btn.prop('disabled', !!loading);
        if (loading) {
          $btn.attr('aria-busy', 'true');
        } else {
          $btn.removeAttr('aria-busy');
        }
      }

      function setHasMore(hasMore) {
        hasMoreNotes = !!hasMore;
        var $btn = ensureLoadMoreButton();
        if (hasMoreNotes) {
          $btn.removeAttr('hidden');
        } else {
          $btn.attr('hidden', 'hidden');
        }
      }

      function buildNoteItemHtml(note, type) {
        var showCb = type === 'todos' || type === 'reminders';
        var done = !!note.is_done;
        var html =
          '<li class="yp-studio-workspace-notes__item' +
          (done ? ' is-done' : '') +
          '" data-note-id="' +
          note.id +
          '">';
        if (showCb) {
          html +=
            '<button type="button" class="yp-studio-workspace-notes__check" aria-label="' +
            escapeHtml(i18n.markDone || 'Mark done') +
            '" aria-pressed="' +
            (done ? 'true' : 'false') +
            '"></button>';
        }
        html += '<div class="yp-studio-workspace-notes__item-body">';
        html += '<span class="yp-studio-workspace-notes__item-title">' + escapeHtml(note.title) + '</span>';
        if (note.body) {
          html += '<span class="yp-studio-workspace-notes__item-desc">' + escapeHtml(note.body) + '</span>';
        }
        html += metaHtml(note, type);
        html += '</div>';
        html +=
          '<button type="button" class="yp-studio-workspace-notes__delete" aria-label="' +
          escapeHtml(i18n.deleteNote || 'Delete note') +
          '"><span class="dashicons dashicons-trash" aria-hidden="true"></span></button>';
        html += '</li>';
        return html;
      }

      function renderNotesHtml(notes, type, append) {
        var items = Array.isArray(notes) ? notes : [];
        if (!items.length && !append) {
          $list.html(
            '<li class="yp-studio-workspace-notes__empty">' +
              escapeHtml(i18n.empty || 'No notes yet.') +
              '</li>'
          );
          return;
        }

        var html = '';
        items.forEach(function (note) {
          html += buildNoteItemHtml(note, type);
        });

        if (append) {
          $list.append(html);
        } else {
          $list.html(html);
        }
      }

      function applyListPage(data, type, append) {
        if (data && data.types) {
          types = data.types;
        }
        if (data && data.active_type) {
          setActiveType(data.active_type);
          type = data.active_type;
        }

        renderNotesHtml(data && data.notes ? data.notes : [], type || activeType, append);
        setHasMore(data && data.has_more);
      }

      function fetchListPage(offset, limit) {
        return post('yooadmin_workspace_notes_list', {
          note_type: activeType,
          offset: offset,
          limit: limit || NOTES_PAGE_SIZE,
        });
      }

      function handleListResponse(res, append, options) {
        options = options || {};
        if (!res || !res.success) {
          if (options.showError) {
            showToast(
              (res && res.data && res.data.message) ||
                i18n.errorGeneric ||
                'Something went wrong. Please try again.',
              'error'
            );
          }
          return false;
        }

        var data = res.data || {};
        var notes = Array.isArray(data.notes) ? data.notes : [];

        if (append && !notes.length) {
          setHasMore(!!data.has_more);
          if (data.has_more) {
            showToast(
              i18n.errorGeneric || 'Something went wrong. Please try again.',
              'error'
            );
          }
          return true;
        }

        if (options.appendSingle) {
          if (notes.length) {
            $list.find('.yp-studio-workspace-notes__empty').remove();
            notes.forEach(function (note) {
              $list.append(buildNoteItemHtml(note, activeType));
            });
          }
          setHasMore(!!data.has_more);
          return true;
        }

        applyListPage(data, activeType, append);
        return true;
      }

      function loadNotesPage(offset, append) {
        if (busy) {
          return $.Deferred().reject().promise();
        }

        busy = true;
        if (append) {
          setLoadMoreLoading(true);
        }

        return fetchListPage(offset, NOTES_PAGE_SIZE)
          .done(function (res) {
            handleListResponse(res, append, { showError: append });
          })
          .fail(function (xhr) {
            if (append) {
              showToast(ajaxErrorMessage(xhr), 'error');
            }
          })
          .always(function () {
            busy = false;
            setLoadMoreLoading(false);
          });
      }

      function reloadFirstPage() {
        busy = false;
        return loadNotesPage(0, false);
      }

      function refillListAfterDelete() {
        var visible = getLoadedCount();

        if (visible === 0) {
          return fetchListPage(0, NOTES_PAGE_SIZE).done(function (res) {
            handleListResponse(res, false);
          });
        }

        if (!hasMoreNotes) {
          if (visible === 0) {
            renderNotesHtml([], activeType, false);
          }
          return;
        }

        return fetchListPage(visible, 1).done(function (res) {
          handleListResponse(res, false, { appendSingle: true });
        });
      }

      function setActiveType(type) {
        activeType = type;
        $root.attr('data-active-type', type);
        updateTypeTrigger(type);
        syncFormFields();
      }

      function updateItemFromNote($item, note, type) {
        var done = !!note.is_done;
        $item.toggleClass('is-done', done);
        $item.find('.yp-studio-workspace-notes__check').attr('aria-pressed', done ? 'true' : 'false');
        $item.find('.yp-studio-workspace-notes__item-meta').remove();
        var meta = metaHtml(note, type);
        if (meta) {
          $item.find('.yp-studio-workspace-notes__item-body').append(meta);
        }
      }

      function buildSavePayload() {
        var payload = {
          note_type: activeType,
          title: $.trim($form.find('[name="title"]').val()),
          body: $.trim($form.find('[name="body"]').val()),
        };
        if (activeType === 'todos') {
          payload.due_at = inputToSiteNaive($.trim($form.find('[name="due_at"]').val()));
        } else if (activeType === 'reminders') {
          payload.remind_at = inputToSiteNaive($.trim($form.find('[name="remind_at"]').val()));
        }
        return payload;
      }

      $typeTrigger.on('click', function (e) {
        e.stopPropagation();
        if ($typeMenu.prop('hidden')) {
          openTypeMenu();
        } else {
          closeTypeMenu();
        }
      });

      $typeMenu.on('click', '.yp-studio-workspace-notes__type-option', function () {
        if (busy) {
          return;
        }
        var type = $(this).data('note-type');
        if (!type || type === activeType) {
          closeTypeMenu();
          return;
        }
        busy = true;
        closeTypeMenu();
        setAddFormOpen(false);
        post('yooadmin_workspace_notes_set_type', { note_type: type })
          .done(function (res) {
            if (res && res.success) {
              applyListPage(res.data || {}, res.data.active_type || type, false);
            }
          })
          .always(function () {
            busy = false;
          });
      });

      $listWrap.on('click', '.yp-studio-workspace-notes__load-more', function () {
        if (busy || !hasMoreNotes) {
          return;
        }
        loadNotesPage(getLoadedCount(), true);
      });

      $addBtn.on('click', function () {
        var open = $formWrap.prop('hidden');
        setAddFormOpen(open);
        if (open) {
          closeTypeMenu();
        }
      });

      $form.on('click', '.yp-studio-workspace-notes__cancel', function () {
        setAddFormOpen(false);
      });

      $form.on('submit', function (e) {
        e.preventDefault();
        if (busy) {
          return;
        }
        var payload = buildSavePayload();
        if (!payload.title) {
          showToast(i18n.titleRequired || 'Title is required.', 'error');
          return;
        }
        if (activeType === 'todos' && !payload.due_at) {
          showToast(i18n.dueRequired || 'Due date is required.', 'error');
          return;
        }
        if (activeType === 'reminders' && !payload.remind_at) {
          showToast(i18n.remindRequired || 'Reminder time is required.', 'error');
          return;
        }
        busy = true;
        post('yooadmin_workspace_notes_save', payload)
          .done(function (res) {
            var ok = res && res.success && (!res.data || res.data.success !== false);
            if (ok) {
              setAddFormOpen(false);
              showToast(i18n.saved || 'Note saved.', 'success');
              return reloadFirstPage();
            }
            var msg =
              (res && res.data && res.data.message) ||
              (res && res.message) ||
              i18n.saveFailed ||
              'Could not save note.';
            showToast(msg, 'error');
          })
          .fail(function (xhr) {
            showToast(ajaxErrorMessage(xhr), 'error');
          })
          .always(function () {
            busy = false;
          });
      });

      $list.on('click', '.yp-studio-workspace-notes__check', function () {
        if (busy) {
          return;
        }
        var $btn = $(this);
        var $item = $btn.closest('.yp-studio-workspace-notes__item');
        var id = parseInt($item.attr('data-note-id'), 10);
        if (!id) {
          return;
        }
        busy = true;
        post('yooadmin_workspace_notes_toggle', { id: id })
          .done(function (res) {
            if (res && res.success && res.data && res.data.note) {
              updateItemFromNote($item, res.data.note, activeType);
              showToast(
                res.data.note.is_done
                  ? i18n.markedDone || 'Marked as done.'
                  : i18n.markedActive || 'Marked as active.',
                'success'
              );
            } else {
              reloadFirstPage();
            }
          })
          .fail(function (xhr) {
            showToast(ajaxErrorMessage(xhr), 'error');
          })
          .always(function () {
            busy = false;
          });
      });

      $list.on('click', '.yp-studio-workspace-notes__delete', function () {
        if (busy) {
          return;
        }
        var $item = $(this).closest('.yp-studio-workspace-notes__item');
        var id = parseInt($item.attr('data-note-id'), 10);
        if (!id) {
          return;
        }
        confirmDeleteModal(function () {
          busy = true;
          post('yooadmin_workspace_notes_delete', { id: id })
            .done(function (res) {
              if (res && res.success) {
                $item.remove();
                showToast(i18n.deleted || 'Note deleted.', 'success');
                refillListAfterDelete();
              } else {
                showToast(i18n.deleteFailed || 'Could not delete note.', 'error');
              }
            })
            .fail(function (xhr) {
              showToast(ajaxErrorMessage(xhr), 'error');
            })
            .always(function () {
              busy = false;
            });
        });
      });

      $(document).on('click', function (e) {
        if (!$picker.is(e.target) && !$picker.has(e.target).length) {
          closeTypeMenu();
        }
      });

      syncFormFields(false);
      updateTypeTrigger(activeType);
      setLoadMoreLoading(false);
      setHasMore(hasMoreNotes);
  }

  function bootWorkspaceNotes() {
    $('.yp-studio-workspace-notes').each(function () {
      bindWorkspaceNotesPanel($(this));
    });
  }

  bootWorkspaceNotes();
  document.addEventListener('yooadmin-studio-hub-widget-rendered', bootWorkspaceNotes);
  window.yooadminInitWorkspaceNotes = bootWorkspaceNotes;
})(jQuery);
