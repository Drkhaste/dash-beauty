(function ($) {
  'use strict';

  var cfg = window.yooadminStudioHubUpdates || {};
  var i18n = cfg.i18n || {};

  function text(key, fallback) {
    return i18n[key] || fallback;
  }

  function formatCount(n) {
    n = parseInt(n, 10);
    if (!isFinite(n) || n < 0) {
      n = 0;
    }
    return String(n);
  }

  function sprintf(template, value) {
    return String(template || '%s')
      .replace('%1$s', value)
      .replace('%s', value)
      .replace('%d', value);
  }

  function sprintfTwo(template, first, second) {
    return String(template || '%1$s %2$s')
      .replace('%1$s', first)
      .replace('%2$s', second);
  }

  function getTotal($card) {
    var total = parseInt($card.attr('data-total'), 10);
    if (!isFinite(total) || total < 0) {
      return 0;
    }
    return total;
  }

  function setTotal($card, total) {
    total = parseInt(total, 10);
    if (!isFinite(total) || total < 0) {
      total = 0;
    }
    $card.attr('data-total', String(total));
    return total;
  }

  function countUniqueItems($items) {
    var seen = {};
    var count = 0;

    $items.each(function () {
      var key = $(this).attr('data-update-key') || '';
      if (!key || seen[key]) {
        return;
      }
      seen[key] = true;
      count += 1;
    });

    return count;
  }

  function countUniqueCardItems($card) {
    return countUniqueItems($card.find('.yp-studio-updates-item'));
  }

  function countUniqueGroupItems($card, group) {
    return countUniqueItems(
      $card.find('.yp-studio-updates-item[data-update-group="' + group + '"]')
    );
  }

  function showToast(message, type) {
    if (typeof window.yshShowStudioHubToast === 'function') {
      window.yshShowStudioHubToast(message, type || 'success');
    }
  }

  function updateA11y(message, politeness) {
    if (window.wp && window.wp.a11y && window.wp.a11y.speak) {
      window.wp.a11y.speak(message, politeness);
    }
  }

  function itemInfo($card, key, $button) {
    var $item = $button.closest('.yp-studio-updates-item');
    if (!$item.length) {
      $item = $card
        .find('.yp-studio-updates-item[data-update-key="' + key + '"]')
        .first();
    }

    return {
      name:
        $button.attr('data-update-name') ||
        $item.attr('data-update-name') ||
        $.trim($item.find('.yp-studio-updates-item__title').first().text()) ||
        text('updated', 'Updated'),
      version:
        $button.attr('data-update-version') ||
        $item.attr('data-update-version') ||
        '',
    };
  }

  function successMessage(info) {
    if (info.version) {
      return sprintfTwo(
        text('updatedWithVersion', '%1$s updated to %2$s.'),
        info.name,
        info.version
      );
    }

    return sprintf(text('updatedWithoutVersion', '%s updated.'), info.name);
  }

  function getErrorMessage(response) {
    var raw = '';

    if (response && response.errorMessage) {
      raw = response.errorMessage;
    } else if (response && response.message) {
      raw = response.message;
    }

    if (raw) {
      if (
        /service unavailable/i.test(raw) ||
        /download failed/i.test(raw)
      ) {
        return text(
          'thirdPartyDownloadFailed',
          'The update package could not be downloaded from the vendor server (service unavailable). Open Updates in WordPress or update from the plugin or theme author site.'
        );
      }
      return raw;
    }
    if (response && response.responseJSON) {
      if (response.responseJSON.data) {
        return getErrorMessage(response.responseJSON.data);
      }
      if (response.responseJSON.message) {
        return response.responseJSON.message;
      }
    }
    if (response && typeof response.responseText === 'string') {
      if (response.responseText === '0' || response.responseText === '-1') {
        return text(
          'updateHandlerMissing',
          'Update handler is unavailable. Refresh the page and try again.'
        );
      }
      try {
        var parsed = JSON.parse(response.responseText);
        if (parsed) {
          return getErrorMessage(parsed.data || parsed);
        }
      } catch (parseError) {
        /* ignore non-JSON bodies */
      }
    }
    return text('errorGeneric', 'Could not update this item. Please try again.');
  }

  function directUpdateRequest($button) {
    var action = $button.attr('data-update-action') || '';
    var payload = {};

    if (action === 'update-plugin') {
      payload.plugin = $button.attr('data-plugin') || '';
      if (!payload.plugin) {
        return null;
      }
    } else if (action === 'update-theme') {
      payload.stylesheet = $button.attr('data-slug') || '';
      if (!payload.stylesheet) {
        return null;
      }
    } else if (action === 'update-translation') {
      payload.type = $button.attr('data-translation-type') || 'core';
      payload.slug = $button.attr('data-slug') || '';
      payload.language = $button.attr('data-language') || '';
      if (!payload.language) {
        return null;
      }
    } else {
      return null;
    }

    return {
      action: action,
      payload: payload,
    };
  }

  function collectDirectUpdateButtons($card) {
    var seen = {};
    var buttons = [];

    $card.find('.yp-studio-updates-action[data-update-action]').each(function () {
      var $button = $(this);
      var key = $button.attr('data-update-key') || '';

      if (!key || seen[key] || !directUpdateRequest($button)) {
        return;
      }

      seen[key] = true;
      buttons.push($button);
    });

    return buttons;
  }

  function directUpdateCount($card) {
    return collectDirectUpdateButtons($card).length;
  }

  function updateSummary($card) {
    var total = getTotal($card);
    var $summary = $card.find('.yp-studio-updates-summary').first();
    var $title = $card.find('[data-updates-summary-title]').first();
    var $copy = $card.find('[data-updates-summary-text]').first();
    var $icon = $summary.find('.yp-studio-updates-summary__icon .dashicons').first();

    if (total === 0) {
      $summary.removeClass('has-updates').addClass('is-clear');
      $icon.removeClass('dashicons-update').addClass('dashicons-yes-alt');
      $title.text(text('noUpdates', 'Everything is up to date'));
      $copy.text(
        text(
          'noUpdatesText',
          'No core, plugin, theme, or language updates are waiting right now.'
        )
      );
      $card.find('.yp-studio-updates-footer').remove();
      return;
    }

    $summary.addClass('has-updates').removeClass('is-clear');
    $icon.addClass('dashicons-update').removeClass('dashicons-yes-alt');
    $title.text(
      total === 1
        ? text('summaryOne', '1 update needs attention')
        : sprintf(text('summaryMany', '%s updates need attention'), formatCount(total))
    );
    $copy.text(
      text(
        'summaryGroupedBelow',
        'Core, plugins, themes, and language packs are grouped below.'
      )
    );
  }

  function updateGroupCounts($card) {
    var groups = {};

    $card.find('[data-update-group-count]').each(function () {
      var group = $(this).attr('data-update-group-count') || '';
      if (group) {
        groups[group] = true;
      }
    });

    Object.keys(groups).forEach(function (group) {
      var count = countUniqueGroupItems($card, group);
      $card.find('[data-update-group-count="' + group + '"]').each(function () {
        $(this).text(formatCount(count));
      });

      $card
        .find('.yp-studio-updates-tab[data-update-group="' + group + '"]')
        .toggleClass('has-updates', count > 0);

      var $section = $card.find(
        '.yp-studio-updates-group[data-update-group-section="' + group + '"]'
      );
      if ($section.length) {
        if (count > 0) {
          $section.removeAttr('hidden');
        } else {
          $section.attr('hidden', 'hidden');
        }
      }
    });
  }

  function refreshToggle($card) {
    var total = getTotal($card);
    var $toggle = $card.find('[data-updates-toggle]').first();
    var $compact = $card.find('[data-updates-compact]').first();
    var compactCount = $compact.length
      ? countUniqueItems($compact.find('.yp-studio-updates-item'))
      : 0;
    var hiddenCount = Math.max(total - compactCount, 0);
    var collapsedLabel;

    if (!$toggle.length) {
      return;
    }

    if (total === 0) {
      $toggle.closest('.yp-studio-updates-footer').remove();
      return;
    }

    if (hiddenCount === 0 && $toggle.attr('aria-expanded') !== 'true') {
      $toggle.closest('.yp-studio-updates-footer').remove();
      return;
    }

    collapsedLabel = sprintf(
      hiddenCount === 1
        ? text('viewAllSingular', 'View all updates (+%s more)')
        : text('viewAllPlural', 'View all updates (+%s more)'),
      formatCount(hiddenCount)
    );
    $toggle.attr('data-label-collapsed', collapsedLabel);

    if (
      $toggle.attr('aria-expanded') !== 'true' &&
      !$toggle.hasClass('is-loading')
    ) {
      $toggle
        .attr('aria-label', collapsedLabel)
        .find('[data-updates-toggle-label]')
        .first()
        .text(collapsedLabel);
    }
  }

  function compactItemKeys($compact) {
    var keys = {};

    $compact.find('.yp-studio-updates-item').each(function () {
      var key = $(this).attr('data-update-key') || '';
      if (key) {
        keys[key] = true;
      }
    });

    return keys;
  }

  function resetPromotedItem($item, bulkBusy) {
    var $action;

    $item.removeClass('is-updating is-updated is-error');
    $item.find('[data-update-status]').text('');
    $action = $item.find('.yp-studio-updates-action[data-update-action]');
    $action
      .prop('disabled', !!bulkBusy)
      .text(text('updateNow', 'Update'));
    if (bulkBusy) {
      $action.attr('aria-disabled', 'true');
    } else {
      $action.removeAttr('aria-disabled');
    }

    return $item;
  }

  function promoteCompactItems($card) {
    var $compact = $card.find('[data-updates-compact]').first();
    var total = countUniqueCardItems($card);
    var desired = Math.min(total, 4);
    var bulkBusy = $card.hasClass('is-bulk-updating');
    var keys;
    var compactCount;

    if (!$compact.length || desired <= 0) {
      return;
    }

    keys = compactItemKeys($compact);
    compactCount = Object.keys(keys).length;

    if (compactCount >= desired) {
      return;
    }

    $card
      .find('[data-updates-groups] .yp-studio-updates-item')
      .each(function () {
        var $source;
        var key;
        var $clone;

        if (compactCount >= desired) {
          return false;
        }

        $source = $(this);
        key = $source.attr('data-update-key') || '';
        if (!key || keys[key]) {
          return;
        }

        $clone = resetPromotedItem($source.clone(false, false), bulkBusy);
        $compact.append($clone);
        keys[key] = true;
        compactCount += 1;
      });
  }

  function refreshAfterRemoval($card) {
    promoteCompactItems($card);

    var total = setTotal($card, countUniqueCardItems($card));

    updateGroupCounts($card);
    updateSummary($card);
    refreshToggle($card);
    updateUpdateAllControl($card);

    if (total === 0) {
      $card
        .find(
          '.yp-studio-updates-tabs, .yp-studio-updates-list, .yp-studio-updates-groups'
        )
        .attr('hidden', 'hidden');
    }

    $card
      .removeClass('yp-studio-updates-is-empty')
      .removeAttr('hidden')
      .removeAttr('aria-hidden');
    $card
      .closest(
        '[data-section-id="studio-updates"], [data-widget-id="studio-updates"], .yp-studio-aside-card--updates'
      )
      .removeClass('yp-studio-updates-is-empty')
      .removeAttr('hidden')
      .removeAttr('aria-hidden');

    return total;
  }

  function removeUpdatedItems($card, key) {
    $card
      .find('.yp-studio-updates-item[data-update-key="' + key + '"]')
      .remove();

    return refreshAfterRemoval($card);
  }

  function successRemovalDelay(options) {
    return options && options.bulk ? 280 : 650;
  }

  function setKeyState($card, key, state, message) {
    var $items = $card.find(
      '.yp-studio-updates-item[data-update-key="' + key + '"]'
    );
    var $buttons = $card.find(
      '.yp-studio-updates-action[data-update-key="' + key + '"]'
    );

    $items
      .removeClass('is-updating is-updated is-error')
      .addClass(state ? 'is-' + state : '');
    $items.find('[data-update-status]').text(message || '');

    if (state === 'updated') {
      $items
        .find('.yp-studio-updates-item__icon .dashicons')
        .attr('class', 'dashicons dashicons-yes-alt');
    }

    if (state === 'updating') {
      $buttons
        .prop('disabled', true)
        .attr('aria-disabled', 'true')
        .text(text('updating', 'Updating...'));
    } else if (state === 'updated') {
      $buttons
        .prop('disabled', true)
        .attr('aria-disabled', 'true')
        .text(text('updated', 'Updated'));
    } else {
      var bulkBusy = $card.hasClass('is-bulk-updating');
      $buttons
        .prop('disabled', bulkBusy)
        .attr('aria-disabled', bulkBusy ? 'true' : null)
        .text(text('updateNow', 'Update'));
    }
  }

  function activatePlusProduct($button) {
    var plugin = $button.attr('data-plugin') || 'yooadmin-plus/yooadmin-plus.php';
    var slug = $button.attr('data-slug') || 'yooadmin-plus';
    var $row = $button.closest('.yp-studio-updates-product-row');
    var deferred = $.Deferred();

    $button
      .prop('disabled', true)
      .attr('aria-disabled', 'true')
      .attr('aria-busy', 'true')
      .text(text('activating', 'Activating...'));

    sendWpUpdate('activate-plugin', {
      plugin: plugin,
      slug: slug,
      name:
        $button.attr('data-name') ||
        $button.closest('.yp-studio-updates-product-row').find('.yp-studio-updates-product-row__title').first().text() ||
        'YOOAdmin Plus',
    })
      .done(function () {
        var message = text('plusActivated', 'YOOAdmin Plus activated.');
        showToast(message, 'success');
        updateA11y(message);
        refreshUpdatesWidget().always(function () {
          deferred.resolve();
        });
      })
      .fail(function (response) {
        var message = getErrorMessage(response);
        if (!message) {
          message = text('activateFailed', 'Could not activate YOOAdmin Plus. Please try again.');
        }
        $button
          .prop('disabled', false)
          .removeAttr('aria-disabled')
          .removeAttr('aria-busy')
          .text(text('activate', 'Activate'));
        showToast(message, 'error');
        updateA11y(message, 'assertive');
        deferred.reject({ message: message });
      });

    return deferred.promise();
  }

  function sendUcUpdate(action, data) {
    return $.ajax({
      url: cfg.ajaxUrl || window.ajaxurl || '',
      method: 'POST',
      dataType: 'json',
      data: $.extend(
        {
          action: action,
          nonce: cfg.ucNonce || '',
        },
        data || {}
      ),
    }).then(
      function (response) {
        if (response && response.success) {
          return response.data || {};
        }
        return $.Deferred().reject((response && response.data) || response).promise();
      },
      function (xhr) {
        return $.Deferred().reject(xhr).promise();
      }
    );
  }

  function sendTranslationUpdate(payload) {
    return sendUcUpdate('yooadmin_uc_update_translation', {
      type: payload.type || '',
      slug: payload.slug || '',
      language: payload.language || '',
    });
  }

  function sendWpUpdate(action, payload) {
    var nonce =
      cfg.nonce ||
      (window.wp && window.wp.updates && window.wp.updates.ajaxNonce) ||
      '';
    var filesystem =
      window.wp && window.wp.updates && window.wp.updates.filesystemCredentials
        ? window.wp.updates.filesystemCredentials
        : {};
    var ftp = filesystem.ftp || {};
    var ssh = filesystem.ssh || {};

    return $.ajax({
      url: cfg.ajaxUrl || window.ajaxurl || '',
      method: 'POST',
      dataType: 'json',
      data: $.extend(
        {
          action: action,
          _ajax_nonce: nonce,
          _fs_nonce: filesystem.fsNonce || '',
          username: ftp.username || '',
          password: ftp.password || '',
          hostname: ftp.hostname || ftp.host || '',
          connection_type: ftp.connectionType || '',
          public_key: ssh.publicKey || '',
          private_key: ssh.privateKey || '',
        },
        payload || {}
      ),
    }).then(
      function (response) {
        if (response && response.success) {
          return response.data || {};
        }
        return $.Deferred().reject((response && response.data) || response).promise();
      },
      function (xhr) {
        return $.Deferred().reject(xhr).promise();
      }
    );
  }

  function ensureToggleSpinner($button) {
    var $spinner = $button.find('.yp-studio-updates-view-all__spinner').first();
    var $icon;

    if ($spinner.length) {
      return $spinner;
    }

    $spinner = $(
      '<span class="yp-studio-updates-view-all__spinner yp-loading-spinner" aria-hidden="true" hidden><span class="yp-spinner-circle"></span></span>'
    );
    $icon = $button.children('.dashicons').last();

    if ($icon.length) {
      $spinner.insertBefore($icon);
    } else {
      $button.append($spinner);
    }

    return $spinner;
  }

  function setToggleLoading($button, loading) {
    var $spinner = ensureToggleSpinner($button);
    var $label = $button.find('[data-updates-toggle-label]').first();

    if (loading) {
      $button
        .addClass('is-loading')
        .prop('disabled', true)
        .attr('aria-disabled', 'true')
        .attr('aria-busy', 'true')
        .attr('aria-label', text('loadingUpdates', 'Loading updates...'));
      $label
        .addClass('screen-reader-text')
        .text(text('loadingUpdates', 'Loading updates...'));
      $spinner.removeAttr('hidden');
      return;
    }

    $button
      .removeClass('is-loading')
      .prop('disabled', false)
      .removeAttr('aria-disabled')
      .removeAttr('aria-busy')
      .attr('aria-label', $button.attr('data-label-collapsed') || '');
    $label.removeClass('screen-reader-text');
    $spinner.attr('hidden', 'hidden');
  }

  function setToggleButtonState($button, expanded) {
    $button.attr('aria-expanded', expanded ? 'true' : 'false');
    $button.attr(
      'aria-label',
      expanded
        ? $button.attr('data-label-expanded')
        : $button.attr('data-label-collapsed')
    );
    $button
      .find('[data-updates-toggle-label]')
      .text(
        expanded
          ? $button.attr('data-label-expanded')
          : $button.attr('data-label-collapsed')
      );
    $button.toggleClass('is-expanded', expanded);
  }

  function setToggleContent($card, expanded) {
    var $groups = $card.find('[data-updates-groups]').first();
    var $compact = $card.find('[data-updates-compact]').first();

    if (expanded) {
      $compact.attr('hidden', 'hidden');
      $groups.removeAttr('hidden');
    } else {
      $groups.attr('hidden', 'hidden');
      $compact.removeAttr('hidden');
    }
  }

  function setToggleLoadingContent($card) {
    $card
      .addClass('is-toggle-loading')
      .find('[data-updates-compact], [data-updates-groups]')
      .attr('hidden', 'hidden');
  }

  function setExpanded($card, $button, expanded) {
    setToggleButtonState($button, expanded);
    setToggleContent($card, expanded);
  }

  function runToggleWithLoading($card, $button, expanded) {
    setToggleLoadingContent($card);
    setToggleLoading($button, true);
    window.requestAnimationFrame(function () {
      window.setTimeout(function () {
        setToggleLoading($button, false);
        setToggleButtonState($button, expanded);
        window.requestAnimationFrame(function () {
          $card.removeClass('is-toggle-loading');
          setToggleContent($card, expanded);
        });
      }, 240);
    });
  }

  function setDirectButtonsDisabled($card, disabled) {
    $card.find('button.yp-studio-updates-action[data-update-action]').each(function () {
      var $button = $(this);
      $button.prop('disabled', disabled);
      if (disabled) {
        $button.attr('aria-disabled', 'true');
      } else {
        $button.removeAttr('aria-disabled');
      }
    });
  }

  function ensureUpdateAllControl($card) {
    var $section = $card
      .closest(
        '[data-section-id="studio-updates"], [data-widget-id="studio-updates"], .yp-studio-aside-card--updates'
      )
      .first();
    var $header = $section.children('.yp-card-header, .yp-section-header').first();
    var $actions = $header.find('> .yp-card-header-actions').first();
    var $button;

    if (!$section.length || !$header.length) {
      return $();
    }

    $button = $header.find('[data-updates-update-all]').first();
    if ($button.length) {
      return $button;
    }

    if (!$actions.length) {
      $actions = $('<div class="yp-card-header-actions"></div>');
      $header.append($actions);
    }

    $button = $(
      '<button type="button" class="yp-studio-updates-update-all" data-updates-update-all>' +
        '<span data-updates-update-all-label></span>' +
        '<span class="yp-studio-updates-update-all__spinner yp-loading-spinner" aria-hidden="true" hidden><span class="yp-spinner-circle"></span></span>' +
      '</button>'
    );
    $button
      .attr('aria-label', text('updateAll', 'Update all'))
      .find('[data-updates-update-all-label]')
      .text(text('updateAll', 'Update all'));
    $actions.prepend($button);

    return $button;
  }

  function setUpdateAllLoading($card, loading) {
    var $button = ensureUpdateAllControl($card);

    if (!$button.length) {
      return;
    }

    if (loading) {
      $button
        .addClass('is-loading')
        .prop('disabled', true)
        .attr('aria-disabled', 'true')
        .attr('aria-busy', 'true');
      $button
        .find('[data-updates-update-all-label]')
        .text(text('updatingAll', 'Updating all...'));
      $button
        .find('.yp-studio-updates-update-all__spinner')
        .removeAttr('hidden');
      return;
    }

    $button
      .removeClass('is-loading')
      .prop('disabled', false)
      .removeAttr('aria-disabled')
      .removeAttr('aria-busy');
    $button
      .find('[data-updates-update-all-label]')
      .text(text('updateAll', 'Update all'));
    $button
      .find('.yp-studio-updates-update-all__spinner')
      .attr('hidden', 'hidden');
  }

  function updateUpdateAllControl($card) {
    var $button = ensureUpdateAllControl($card);
    var count = directUpdateCount($card);

    if (!$button.length) {
      return;
    }

    if (count > 0 && getTotal($card) > 0) {
      $button.removeAttr('hidden');
    } else {
      $button.attr('hidden', 'hidden');
    }
  }

  function runDirectUpdate($card, $button, options) {
    var request = directUpdateRequest($button);
    var key = $button.attr('data-update-key') || '';
    var info = itemInfo($card, key, $button);
    var deferred = $.Deferred();

    options = options || {};

    if (!request || !key) {
      deferred.reject({
        message: text('errorGeneric', 'Could not update this item. Please try again.'),
      });
      return deferred.promise();
    }

    setKeyState($card, key, 'updating', text('updating', 'Updating...'));

    var requestPromise;

    if (request.action === 'update-translation') {
      requestPromise = sendTranslationUpdate(request.payload);
    } else if (request.action === 'update-plugin') {
      requestPromise = sendUcUpdate('yooadmin_uc_update_plugin', {
        plugin: request.payload.plugin,
      });
    } else if (request.action === 'update-theme') {
      requestPromise = sendUcUpdate('yooadmin_uc_update_theme', {
        stylesheet: request.payload.stylesheet,
      });
    } else {
      requestPromise = sendWpUpdate(request.action, request.payload);
    }

    requestPromise
      .done(function (response) {
        var message;

        if (response && response.newVersion && !info.version) {
          info.version = response.newVersion;
        }
        if (response && response.version && !info.version) {
          info.version = response.version;
        }
        message = successMessage(info);

        setKeyState($card, key, 'updated', text('updated', 'Updated'));

        if (!options.silent) {
          showToast(message, 'success');
          updateA11y(message);
        }

        window.setTimeout(function () {
          var remaining = removeUpdatedItems($card, key);

          deferred.resolve({
            message: message,
            remaining: remaining,
          });
        }, successRemovalDelay(options));
      })
      .fail(function (response) {
        var message = getErrorMessage(response);
        if (
          response &&
          response.errorCode === 'unable_to_connect_to_filesystem'
        ) {
          message = text(
            'filesystemRequired',
            'WordPress needs filesystem credentials. Open the updater to continue.'
          );
        }
        setKeyState($card, key, 'error', message);
        if (!options.silent) {
          updateA11y(message, 'assertive');
        }
        deferred.reject({
          message: message,
          response: response,
        });
      });

    return deferred.promise();
  }

  function runUpdateQueue($card, buttons) {
    var deferred = $.Deferred();
    var index = 0;
    var successes = 0;
    var failures = 0;

    function next() {
      if (index >= buttons.length) {
        deferred.resolve({
          successes: successes,
          failures: failures,
        });
        return;
      }

      runDirectUpdate($card, buttons[index], { silent: true, bulk: true })
        .done(function () {
          successes += 1;
        })
        .fail(function () {
          failures += 1;
        })
        .always(function () {
          index += 1;
          next();
        });
    }

    next();

    return deferred.promise();
  }

  function bindCard(root) {
    var $card = $(root);
    var $section = $card
      .closest(
        '[data-section-id="studio-updates"], [data-widget-id="studio-updates"], .yp-studio-aside-card--updates'
      )
      .first();
    if (!$card.length || $card.attr('data-updates-bound') === '1') {
      return;
    }
    $card.attr('data-updates-bound', '1');
    updateUpdateAllControl($card);

    $section.on('click', '[data-updates-update-all]', function () {
      var $button = $(this);
      var buttons;

      if ($button.prop('disabled') || $card.hasClass('is-bulk-updating')) {
        return;
      }

      buttons = collectDirectUpdateButtons($card);
      if (!buttons.length) {
        updateUpdateAllControl($card);
        return;
      }

      $card.addClass('is-bulk-updating');
      setUpdateAllLoading($card, true);
      setDirectButtonsDisabled($card, true);

      runUpdateQueue($card, buttons).done(function (summary) {
        var remaining = getTotal($card);
        var message;

        $card.removeClass('is-bulk-updating');
        setUpdateAllLoading($card, false);
        setDirectButtonsDisabled($card, false);
        updateUpdateAllControl($card);

        if (summary.failures > 0) {
          message = sprintf(
            summary.failures === 1
              ? text('updateAllFailedSingular', '%s update could not be completed.')
              : text('updateAllFailedPlural', '%s updates could not be completed.'),
            formatCount(summary.failures)
          );
          showToast(message, 'error');
          updateA11y(message, 'assertive');
          return;
        }

        if (summary.successes > 0) {
          message =
            remaining === 0
              ? text('allUpdatesCompleted', 'All available updates completed.')
              : text(
                  'allDirectUpdatesCompleted',
                  'Plugin, theme, and language updates completed. Open the updater for remaining core updates.'
                );
          showToast(message, 'success');
          updateA11y(message);
        }

      });
    });

    $card.on('click', '[data-updates-toggle]', function () {
      var $button = $(this);
      var expanded = $button.attr('aria-expanded') === 'true';
      var $groups = $card.find('[data-updates-groups]').first();
      var nextExpanded = !expanded;

      if ($button.hasClass('is-loading') || $button.prop('disabled')) {
        return;
      }

      if (nextExpanded && !$groups.length) {
        return;
      }

      runToggleWithLoading($card, $button, nextExpanded);
    });

    $card.on('click', '.yp-studio-updates-action[data-update-action]', function () {
      var $button = $(this);

      if ($button.prop('disabled') || $card.hasClass('is-bulk-updating')) {
        return;
      }

      runDirectUpdate($card, $button);
    });

    $card.on(
      'click',
      '.yp-studio-updates-product-row__cta[data-cta-action="activate-plugin"]',
      function (event) {
        var $button = $(this);

        event.preventDefault();

        if ($button.prop('disabled')) {
          return;
        }

        activatePlusProduct($button);
      }
    );

    updateSummary($card);
  }

  function getLayoutAjaxConfig() {
    var layout = window.yooadminStudioHubLayout || {};
    var root = document.querySelector('.yp-studio-hub--dashboard[data-layout-nonce]');

    return {
      ajaxUrl: layout.ajaxUrl || cfg.ajaxUrl || (root && root.getAttribute('data-layout-ajax')) || '',
      nonce:
        layout.nonce ||
        cfg.layoutNonce ||
        (root && root.getAttribute('data-layout-nonce')) ||
        '',
      restUrl: layout.restUrl || cfg.restUrl || '',
      restNonce:
        layout.restNonce ||
        cfg.restNonce ||
        (window.wpApiSettings && window.wpApiSettings.nonce) ||
        '',
    };
  }

  function extractUpdatesWidgetNode(html) {
    var wrap = document.createElement('div');
    wrap.innerHTML = html;
    return wrap.querySelector('[data-studio-updates-widget="true"]');
  }

  function fetchUpdatesWidgetHtml() {
    var layoutCfg = getLayoutAjaxConfig();
    var widgetId = cfg.widgetId || 'studio-updates';
    var deferred = $.Deferred();

    if (layoutCfg.restUrl && layoutCfg.restNonce) {
      $.ajax({
        url:
          String(layoutCfg.restUrl).replace(/\/$/, '') +
          '/studio-hub/widgets/' +
          encodeURIComponent(widgetId) +
          '/render',
        method: 'GET',
        dataType: 'json',
        headers: {
          'X-WP-Nonce': layoutCfg.restNonce,
        },
      })
        .done(function (body) {
          if (body && typeof body.html === 'string') {
            deferred.resolve(body.html);
            return;
          }
          deferred.reject();
        })
        .fail(function () {
          deferred.reject();
        });

      return deferred.promise();
    }

    if (!layoutCfg.ajaxUrl || !layoutCfg.nonce) {
      return deferred.reject().promise();
    }

    return $.ajax({
      url: layoutCfg.ajaxUrl,
      method: 'POST',
      dataType: 'json',
      data: {
        action: 'yooadmin_studio_hub_render_dashboard_widget',
        nonce: layoutCfg.nonce,
        widget_id: widgetId,
      },
    }).then(function (res) {
      if (res && res.success && res.data && typeof res.data.html === 'string') {
        return res.data.html;
      }
      return $.Deferred().reject().promise();
    });
  }

  function refreshUpdatesWidget() {
    var $cards = $('[data-studio-updates-widget="true"]');

    if (!$cards.length) {
      return $.Deferred().resolve().promise();
    }

    $cards.addClass('is-refreshing');

    return fetchUpdatesWidgetHtml()
      .done(function (html) {
        var freshNode = extractUpdatesWidgetNode(html);

        if (!freshNode) {
          return;
        }

        $cards.each(function () {
          $(this).replaceWith($(freshNode.cloneNode(true)));
        });

        boot();
      })
      .always(function () {
        $('[data-studio-updates-widget="true"]').removeClass('is-refreshing');
      });
  }

  function boot() {
    $('[data-studio-updates-widget="true"]').each(function () {
      bindCard(this);
    });
  }

  window.yooadminStudioHubInitUpdatesWidget = boot;
  window.yooadminStudioHubRefreshUpdatesWidget = refreshUpdatesWidget;
  document.addEventListener('yooadmin:license-status-changed', function () {
    refreshUpdatesWidget();
  });
  document.addEventListener('yooadmin-studio-hub-widget-rendered', boot);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(window.jQuery);
