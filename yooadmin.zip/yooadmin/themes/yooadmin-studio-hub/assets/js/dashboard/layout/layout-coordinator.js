/**
 * Studio Hub layout — boot uses server layout from SSR; JS only patches widgets/cards when needed.
 */
(function (window) {
  'use strict';

  var Storage = window.YOOStudioHubLayoutStorage;
  if (!Storage) {
    return;
  }

  var COORD = (window.YOOStudioHubLayoutCoordinator = window.YOOStudioHubLayoutCoordinator || {});
  var bootDone = false;
  var restoreGeneration = 0;
  var userEditing = false;
  var saveTimer = null;
  var SAVE_DELAY = 350;

  function editor() {
    return window.YOOStudioHubLayoutEditor;
  }

  function root() {
    return document.querySelector('.yp-studio-hub--dashboard');
  }

  function layoutTimestampsEqual(a, b) {
    if (!a || !b) {
      return false;
    }
    var ta = parseInt(a.savedAt, 10) || 0;
    var tb = parseInt(b.savedAt, 10) || 0;
    if (ta && tb) {
      return ta === tb;
    }
    return JSON.stringify(a) === JSON.stringify(b);
  }

  function ssrAlreadyApplied() {
    var el = root();
    return !!(el && el.getAttribute('data-layout-ssr-applied') === '1');
  }

  function hasWidgetSections(data) {
    return !!(data && data.widgetSections && Object.keys(data.widgetSections).length);
  }

  function needsDomRestore(data) {
    var Ed = editor();
    if (!Ed || !data) {
      return false;
    }
    if (!ssrAlreadyApplied()) {
      return true;
    }
    if (hasWidgetSections(data)) {
      return true;
    }
    if (typeof Ed.layoutStructureMatches === 'function' && !Ed.layoutStructureMatches(data)) {
      return true;
    }
    return typeof Ed.columnsNeedFix === 'function' && Ed.columnsNeedFix(data);
  }

  COORD.markUserEditing = function (editing) {
    userEditing = !!editing;
  };

  COORD.restore = function (data, options) {
    options = options || {};
    var Ed = editor();
    if (!Ed || !data || data.version !== Storage.LAYOUT_VERSION) {
      return false;
    }
    if (userEditing && options.allowWhileEditing !== true) {
      return false;
    }

    Storage.setSession(data);
    if (typeof Ed.setSuppressLayoutSave === 'function') {
      Ed.setSuppressLayoutSave(true);
    }
    try {
      Ed.applyHiddenState(data);
      Ed.ensureCustomAndWidgetSections(data);

      if (options.fixColumns !== false && Ed.columnsNeedFix(data)) {
        Ed.applyColumnPlacements(data);
      }

      Ed.applyCardOrder(data);
      Ed.finalizeGrids();
      Ed.afterRestore(data);
    } finally {
      if (typeof Ed.setSuppressLayoutSave === 'function') {
        Ed.setSuppressLayoutSave(false);
      }
    }
    return true;
  };

  COORD.applySsrLayout = function (data) {
    var Ed = editor();
    if (!Ed || !data || data.version !== Storage.LAYOUT_VERSION) {
      return;
    }
    Storage.setSession(data);
    if (typeof Ed.setSuppressLayoutSave === 'function') {
      Ed.setSuppressLayoutSave(true);
    }
    try {
      Ed.applyHiddenState(data);
      Ed.ensureCustomAndWidgetSections(data);
      if (typeof Ed.hydratePendingWidgets === 'function') {
        Ed.hydratePendingWidgets(data);
      }
      Ed.applyCardOrder(data);
      Ed.finalizeGrids();
      Ed.afterRestore(data);
    } finally {
      if (typeof Ed.setSuppressLayoutSave === 'function') {
        Ed.setSuppressLayoutSave(false);
      }
    }
  };

  COORD.persist = function (data, options) {
    options = options || {};
    if (!data || data.version !== Storage.LAYOUT_VERSION) {
      return Promise.resolve(false);
    }

    if (options.bumpGeneration) {
      restoreGeneration += 1;
    }

    Storage.setSession(data);

    if (options.serverImmediate) {
      if (saveTimer) {
        clearTimeout(saveTimer);
        saveTimer = null;
      }
      return Storage.saveToServer(data, options).then(function (ok) {
        if (typeof options.onResult === 'function') {
          options.onResult(ok, options);
        }
        return ok;
      });
    }

    if (saveTimer) {
      clearTimeout(saveTimer);
    }
    return new Promise(function (resolve) {
      saveTimer = setTimeout(function () {
        saveTimer = null;
        Storage.saveToServer(data, options).then(function (ok) {
          if (typeof options.onResult === 'function') {
            options.onResult(ok, options);
          }
          resolve(ok);
        });
      }, options.delay != null ? options.delay : SAVE_DELAY);
    });
  };

  COORD.boot = function () {
    if (bootDone || !root() || !editor()) {
      return;
    }
    bootDone = true;

    var dom = Storage.readFromDom();
    if (dom) {
      Storage.setSession(dom);
    }

    if (ssrAlreadyApplied() && dom) {
      editor().applyHiddenState(dom);
    }

    if (ssrAlreadyApplied() && typeof editor().finalizeGrids === 'function') {
      editor().finalizeGrids();
    }

    var gen = ++restoreGeneration;
    Storage.fetchFromServer().then(function (server) {
      if (gen !== restoreGeneration) {
        return;
      }

      var layout = Storage.resolveBootLayout(server);
      if (!layout) {
        return;
      }

      Storage.setSession(layout);
      var Ed = editor();
      if (!Ed) {
        return;
      }

      if (ssrAlreadyApplied() && dom && layoutTimestampsEqual(dom, layout) && !needsDomRestore(layout)) {
        COORD.applySsrLayout(layout);
        return;
      }

      if (ssrAlreadyApplied() && dom && layoutTimestampsEqual(dom, layout)) {
        COORD.applySsrLayout(layout);
        return;
      }

      COORD.restore(layout, {
        fixColumns: needsDomRestore(layout) || Ed.columnsNeedFix(layout),
      });
    });
  };

  COORD.resetToFactory = function () {
    var Ed = editor();
    if (!Ed) {
      return Promise.resolve();
    }

    restoreGeneration += 1;
    userEditing = false;
    if (saveTimer) {
      clearTimeout(saveTimer);
      saveTimer = null;
    }
    Storage.clearSession();

    return Storage.deleteFromServer().then(function () {
      var factory = Ed.buildFactoryLayout();
      Ed.resetDomToFactory();
      COORD.restore(factory, { fixColumns: true, allowWhileEditing: true });
      if (typeof Ed.syncFactoryLayoutDomMeta === 'function') {
        Ed.syncFactoryLayoutDomMeta(factory);
      }
      if (typeof Ed.flushVisibilityAfterReset === 'function') {
        Ed.flushVisibilityAfterReset();
      }
      if (typeof Ed.rebindAllCards === 'function') {
        Ed.rebindAllCards();
      }
      if (typeof Ed.updateCardsDraggable === 'function') {
        Ed.updateCardsDraggable();
      }
      var el = root();
      if (el) {
        el.setAttribute('data-layout-ssr-applied', '1');
        el.removeAttribute('data-layout-ssr-pending');
      }
      return COORD.persist(factory, {
        serverImmediate: true,
        allowWhileEditing: true,
      }).then(function (ok) {
        if (typeof Ed.flushVisibilityAfterReset === 'function') {
          Ed.flushVisibilityAfterReset();
        }
        return ok;
      });
    });
  };

  function tryBoot() {
    if (editor() && root()) {
      COORD.boot();
      return true;
    }
    return false;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      if (!tryBoot()) {
        var tries = 0;
        var iv = setInterval(function () {
          tries += 1;
          if (tryBoot() || tries > 40) {
            clearInterval(iv);
          }
        }, 50);
      }
    });
  } else if (!tryBoot()) {
    var tries = 0;
    var iv = setInterval(function () {
      tries += 1;
      if (tryBoot() || tries > 40) {
        clearInterval(iv);
      }
    }, 50);
  }
})(window);
