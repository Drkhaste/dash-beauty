/**
 * Studio Hub layout persistence.
 * Truth: server (user meta). Boot fallback: SSR data-initial-layout.
 * localStorage: mirror only after a successful server save (not a source of truth).
 */
(function (window) {
  'use strict';

  var NS = (window.YOOStudioHubLayoutStorage = window.YOOStudioHubLayoutStorage || {});

  NS.STORAGE_KEY = 'yooadmin_studio_hub_layout_v1';
  NS.NETWORK_STORAGE_KEY = 'yooadmin_network_dashboard_layout_v1';
  NS.LAYOUT_VERSION = 1;

  var session = null;

  function rootEl() {
    return document.querySelector('.yp-studio-hub--dashboard');
  }

  function cfg() {
    return window.yooadminStudioHubLayout || {};
  }

  function networkCfg() {
    return window.yooadminNetworkDashboardLayout || {};
  }

  function isNetworkDashboard() {
    var net = networkCfg();
    if (net.isNetworkDashboard) {
      return true;
    }
    return document.body && document.body.classList.contains('yp-network-dashboard-screen');
  }

  function activeStorageKey() {
    return isNetworkDashboard() ? NS.NETWORK_STORAGE_KEY : NS.STORAGE_KEY;
  }

  function serverAuth() {
    var root = rootEl();
    var net = networkCfg();
    if (isNetworkDashboard()) {
      return {
        ajaxUrl:
          net.ajaxUrl ||
          (root && root.getAttribute('data-layout-ajax')) ||
          window.ajaxurl ||
          '',
        nonce:
          net.nonce || (root && root.getAttribute('data-layout-nonce')) || '',
        actions: net.actions || {
          get: 'yooadmin_network_dashboard_get_layout',
          save: 'yooadmin_network_dashboard_save_layout',
          reset: 'yooadmin_network_dashboard_reset_layout',
        },
        useRest: false,
      };
    }

    var c = cfg();
    return {
      ajaxUrl:
        c.ajaxUrl ||
        (root && root.getAttribute('data-layout-ajax')) ||
        window.ajaxurl ||
        '',
      nonce: c.nonce || (root && root.getAttribute('data-layout-nonce')) || '',
      actions: {
        get: 'yooadmin_studio_hub_get_layout',
        save: 'yooadmin_studio_hub_save_layout',
      },
      useRest: !!(c.restUrl && (c.restNonce || (window.wpApiSettings && window.wpApiSettings.nonce))),
      restUrl: c.restUrl || '',
      restNonce: c.restNonce || (window.wpApiSettings && window.wpApiSettings.nonce) || '',
    };
  }

  NS.isNetworkDashboard = isNetworkDashboard;

  NS.canUseServer = function () {
    var auth = serverAuth();
    return !!(auth.ajaxUrl && auth.nonce);
  };

  NS.readFromDom = function () {
    var root = rootEl();
    if (!root) {
      return null;
    }
    var attr = root.getAttribute('data-initial-layout');
    if (!attr) {
      return null;
    }
    try {
      var data = JSON.parse(attr);
      return data && typeof data === 'object' && data.version === NS.LAYOUT_VERSION
        ? data
        : null;
    } catch (e) {
      return null;
    }
  };

  NS.syncDomAttr = function (data) {
    var root = rootEl();
    if (!root) {
      return;
    }
    if (data && data.version === NS.LAYOUT_VERSION) {
      try {
        root.setAttribute('data-initial-layout', JSON.stringify(data));
      } catch (e) {
        /* ignore */
      }
    } else {
      root.removeAttribute('data-initial-layout');
    }
  };

  /** Mirror for fast reload only — never read during boot. */
  NS.mirrorToLocal = function (data) {
    try {
      if (data && data.version === NS.LAYOUT_VERSION) {
        localStorage.setItem(activeStorageKey(), JSON.stringify(data));
      } else {
        localStorage.removeItem(activeStorageKey());
      }
    } catch (e) {
      /* ignore */
    }
  };

  NS.clearLocalMirror = function () {
    try {
      localStorage.removeItem(activeStorageKey());
    } catch (e) {
      /* ignore */
    }
  };

  NS.stampSavedAt = function (data) {
    if (data && typeof data === 'object') {
      data.savedAt = Date.now();
    }
    return data;
  };

  /** In-page session (edits + coordinator). Not localStorage. */
  NS.setSession = function (data) {
    session =
      data && typeof data === 'object' && data.version === NS.LAYOUT_VERSION
        ? NS.stampSavedAt(Object.assign({}, data))
        : null;
    NS.syncDomAttr(session);
    return session;
  };

  NS.getSession = function () {
    if (session) {
      return session;
    }
    var dom = NS.readFromDom();
    if (dom) {
      session = dom;
    }
    return session;
  };

  NS.clearSession = function () {
    session = null;
    NS.clearLocalMirror();
    NS.syncDomAttr(null);
  };

  /**
   * Boot resolution: server wins; if no server layout, use SSR snapshot.
   * localStorage is intentionally ignored.
   */
  NS.resolveBootLayout = function (server) {
    if (server && server.version === NS.LAYOUT_VERSION) {
      return server;
    }
    return NS.readFromDom();
  };

  NS.fetchFromServer = function () {
    if (!NS.canUseServer()) {
      return Promise.resolve(null);
    }
    var auth = serverAuth();
    if (auth.useRest) {
      return fetch(auth.restUrl.replace(/\/$/, '') + '/studio-hub/layout', {
        method: 'GET',
        credentials: 'same-origin',
        headers: { 'X-WP-Nonce': auth.restNonce },
      })
        .then(function (res) {
          return res.ok ? res.json() : null;
        })
        .then(function (body) {
          return body && body.layout ? body.layout : null;
        })
        .catch(function () {
          return NS.ajaxGet();
        });
    }
    return NS.ajaxGet();
  };

  NS.ajaxGet = function () {
    var auth = serverAuth();
    var body = new FormData();
    body.append('action', auth.actions.get);
    body.append('nonce', auth.nonce);
    return fetch(auth.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
      .then(function (res) {
        return res.json();
      })
      .then(function (res) {
        return res && res.success && res.data && res.data.layout ? res.data.layout : null;
      })
      .catch(function () {
        return null;
      });
  };

  NS.saveToServer = function (data, options) {
    options = options || {};
    if (!NS.canUseServer() || !data || data.version !== NS.LAYOUT_VERSION) {
      return Promise.resolve(false);
    }

    var payload = NS.stampSavedAt(Object.assign({}, data));
    var auth = serverAuth();
    var fetchOpts = {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': auth.restNonce,
      },
      body: JSON.stringify({ layout: payload }),
    };
    if (options.keepalive) {
      fetchOpts.keepalive = true;
    }

    function onOk(ok) {
      if (ok) {
        NS.setSession(payload);
        NS.mirrorToLocal(payload);
      }
      return ok;
    }

    if (auth.useRest) {
      return fetch(auth.restUrl.replace(/\/$/, '') + '/studio-hub/layout', fetchOpts)
        .then(function (res) {
          return onOk(res.ok);
        })
        .catch(function () {
          return NS.ajaxSave(payload).then(onOk);
        });
    }
    return NS.ajaxSave(payload).then(onOk);
  };

  NS.ajaxSave = function (data) {
    var auth = serverAuth();
    var body = new FormData();
    body.append('action', auth.actions.save);
    body.append('nonce', auth.nonce);
    body.append('layout', JSON.stringify(data));
    return fetch(auth.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
      .then(function (res) {
        return res.json();
      })
      .then(function (res) {
        return !!(res && res.success);
      })
      .catch(function () {
        return false;
      });
  };

  NS.deleteFromServer = function () {
    if (!NS.canUseServer()) {
      return Promise.resolve(false);
    }
    var auth = serverAuth();
    if (!auth.useRest) {
      if (isNetworkDashboard() && auth.actions && auth.actions.reset) {
        var body = new FormData();
        body.append('action', auth.actions.reset);
        body.append('nonce', auth.nonce);
        return fetch(auth.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
          .then(function (res) {
            return res.json();
          })
          .then(function (res) {
            return !!(res && res.success);
          })
          .catch(function () {
            return false;
          });
      }
      return Promise.resolve(false);
    }
    return fetch(auth.restUrl.replace(/\/$/, '') + '/studio-hub/layout', {
      method: 'DELETE',
      credentials: 'same-origin',
      headers: { 'X-WP-Nonce': auth.restNonce },
    })
      .then(function (res) {
        return res.ok;
      })
      .catch(function () {
        return false;
      });
  };

  // Legacy aliases used while trimming studio-hub-dashboard-layout.js
  NS.getCache = NS.getSession;
  NS.setCache = NS.setSession;
  NS.clearCache = NS.clearSession;
})(window);
