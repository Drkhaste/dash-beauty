(function () {
  'use strict';

  var RING_ANIM_MS = 1000;
  var INIT_ATTR = 'data-security-score-animated';

  function animateScoreRing(widget) {
    if (!widget) {
      return;
    }

    var percent = parseInt(widget.getAttribute('data-score-percent'), 10);
    if (isNaN(percent)) {
      var valueEl = widget.querySelector('[data-score-value]');
      percent = valueEl ? parseInt(valueEl.textContent, 10) || 0 : 0;
    }
    percent = Math.max(0, Math.min(100, percent));

    var circumference = parseInt(widget.getAttribute('data-ring-c'), 10) || 264;
    var bar = widget.querySelector('[data-ring-bar]');
    var value = widget.querySelector('[data-score-value]');
    var ring = widget.querySelector('[data-security-score-ring]');
    if (!bar || !value) {
      return;
    }

    var targetOffset = circumference - (percent / 100) * circumference;

    function setOffset(offset) {
      bar.setAttribute('stroke-dashoffset', String(offset));
    }

    var prefersReducedMotion = false;
    try {
      prefersReducedMotion =
        window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch (motionMqErr) {
      prefersReducedMotion = false;
    }

    if (prefersReducedMotion) {
      if (ring) {
        ring.classList.remove('is-animating');
      }
      setOffset(targetOffset);
      value.textContent = String(percent);
      return;
    }

    var startTs = null;

    function finish() {
      if (ring) {
        ring.classList.remove('is-animating');
      }
      setOffset(targetOffset);
      value.textContent = String(percent);
    }

    function frame(ts) {
      if (!startTs) {
        startTs = ts;
      }
      var t = Math.min(1, (ts - startTs) / RING_ANIM_MS);
      var eased = 1 - Math.pow(1 - t, 3);
      var current = Math.round(percent * eased);
      var offset = circumference - (current / 100) * circumference;
      setOffset(offset);
      value.textContent = String(current);
      if (t < 1) {
        window.requestAnimationFrame(frame);
      } else {
        finish();
      }
    }

    if (ring) {
      ring.classList.add('is-animating');
    }
    setOffset(circumference);
    value.textContent = '0';
    window.requestAnimationFrame(frame);
  }

  function boot(root) {
    var scope = root && root.nodeType === 1 ? root : document;
    var nodes = scope.querySelectorAll
      ? scope.querySelectorAll('[data-studio-login-security-widget="true"]')
      : [];

    if (
      scope.nodeType === 1 &&
      scope.getAttribute &&
      scope.getAttribute('data-studio-login-security-widget') === 'true'
    ) {
      nodes = Array.prototype.slice.call(nodes);
      nodes.push(scope);
    }

    Array.prototype.forEach.call(nodes, function (widget) {
      if (widget.getAttribute(INIT_ATTR) === '1') {
        return;
      }
      widget.setAttribute(INIT_ATTR, '1');
      animateScoreRing(widget);
    });
  }

  function onReady() {
    if (typeof window.yooadminStudioHubInitLoginSecurityWidget === 'function') {
      window.yooadminStudioHubInitLoginSecurityWidget(document);
      return;
    }
    boot(document);
  }

  if (typeof window.yooadminStudioHubInitLoginSecurityWidget !== 'function') {
    window.yooadminStudioHubInitLoginSecurityWidget = function (root) {
      boot(root || document);
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', onReady);
  } else {
    onReady();
  }

  document.addEventListener('yooadmin-studio-hub-widget-rendered', function (e) {
    var detail = e && e.detail ? e.detail : {};
    if (detail.widgetId && detail.widgetId !== 'studio-login-security') {
      return;
    }
    if (typeof window.yooadminStudioHubInitLoginSecurityWidget === 'function') {
      window.yooadminStudioHubInitLoginSecurityWidget(detail.body || document);
    } else {
      boot(detail.body || document);
    }
  });
})();
