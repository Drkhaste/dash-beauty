/**
 * Studio Hub — section tile/list pagination (4 per page, dots + drag page flip).
 * Aside sections only (custom, extensions, and network dashboard right column).
 */
(function () {
  'use strict';

  var DEFAULT_PER_PAGE = 4;
  var pageBySection = {};
  var dragCtx = null;
  var flipTimer = null;

  function getRoot() {
    return document.querySelector('.yp-studio-hub--dashboard');
  }

  function isNetworkDashboard() {
    return !!(
      document.body &&
      (document.body.classList.contains('yooadmin-network-dashboard') ||
        document.body.classList.contains('yp-network-dashboard-screen'))
    );
  }

  function isEditMode() {
    return (
      document.body.classList.contains('yp-layout-edit-mode') ||
      document.documentElement.classList.contains('yp-layout-edit-mode')
    );
  }

  function getSectionId(section) {
    return section ? section.getAttribute('data-section-id') || '' : '';
  }

  function getGrid(section) {
    if (!section) {
      return null;
    }
    return section.querySelector('[data-workspace-paginate="true"]');
  }

  function getMainEl() {
    var root = getRoot();
    return root ? root.querySelector('.yp-studio-hub__main') : null;
  }

  function getAsideEl() {
    var root = getRoot();
    return root ? root.querySelector('.yp-studio-hub__aside') : null;
  }

  function isAsideCustomSection(section) {
    if (!section || !section.classList.contains('yp-studio-custom-section')) {
      return false;
    }
    var aside = getAsideEl();
    return !!(aside && aside.contains(section));
  }

  function isExtensionsAsideSection(section) {
    if (!section || getSectionId(section) !== 'from-extensions') {
      return false;
    }
    var aside = getAsideEl();
    return !!(aside && aside.contains(section));
  }

  function isPaginatedAsideSection(section) {
    if (!section) {
      return false;
    }
    var aside = getAsideEl();
    if (!aside || !aside.contains(section)) {
      return false;
    }
    return isAsideCustomSection(section) || isExtensionsAsideSection(section);
  }

  function isPaginatedSection(section) {
    if (!section || !getGrid(section)) {
      return false;
    }
    return isPaginatedAsideSection(section);
  }

  function getCards(grid) {
    var selector = grid.getAttribute('data-paginate-item-selector') || '[data-card-id]';
    return Array.prototype.filter.call(grid.querySelectorAll(selector), function (card) {
      return !card.classList.contains('is-dragging');
    });
  }

  function getPerPage(grid) {
    return parseInt(grid.getAttribute('data-items-per-page') || String(DEFAULT_PER_PAGE), 10) || DEFAULT_PER_PAGE;
  }

  function getPageCount(cardCount, perPage) {
    if (cardCount <= 0) {
      return 1;
    }
    return Math.max(1, Math.ceil(cardCount / perPage));
  }

  function getPageIndex(sectionId) {
    var page = pageBySection[sectionId];
    return typeof page === 'number' && page >= 0 ? page : 0;
  }

  function setPageIndex(sectionId, index, skipPersist) {
    pageBySection[sectionId] = Math.max(0, index | 0);
    if (!skipPersist) {
      persistPages();
    }
  }

  function persistPages() {
    if (!window.YOOStudioHubLayout || typeof window.YOOStudioHubLayout.patchStorage !== 'function') {
      return;
    }
    window.YOOStudioHubLayout.patchStorage({ cardPages: pageBySection });
  }

  function hideSectionLoading(section) {
    if (!section) {
      return;
    }
    var grid =
      resolvePaginateGrid(section) ||
      getGrid(section) ||
      section.querySelector('.yp-studio-extensions-grid, .yp-studio-workspace-grid, .yp-cards-grid');
    var booting =
      section.getAttribute('data-layout-booting') === 'true' ||
      section.classList.contains('yp-studio-layout-section--booting');
    var hasCards = !!(grid && grid.querySelector('[data-card-id]'));
    if (grid && !grid.classList.contains('is-hydrated')) {
      if (!(booting && hasCards)) {
        return;
      }
      grid.classList.add('is-hydrated');
      section.classList.remove('yp-studio-layout-section--booting');
      section.removeAttribute('data-layout-booting');
    }
    section
      .querySelectorAll(
        '.yp-studio-section-loading, .yp-website-management-loading, .yp-network-sites-loading, .yp-studio-section-grid-loading, .yp-extensions-grid-loading'
      )
      .forEach(function (el) {
        el.classList.add('is-hidden');
        el.setAttribute('aria-hidden', 'true');
      });
    var sitesList = section.querySelector('.yp-network-sites-card__list');
    if (sitesList && !sitesList.classList.contains('is-hydrated')) {
      sitesList.classList.add('is-hydrated');
    }
  }

  function dismissNetworkSitesLoading() {
    if (!isNetworkDashboard()) {
      return;
    }
    var root = getRoot();
    if (!root) {
      return;
    }
    root.querySelectorAll('.yp-dashboard-section[data-section-id="network-sites"]').forEach(function (section) {
      hideSectionLoading(section);
    });
  }

  function pagerFooterHtml() {
    return (
      '<nav class="yp-studio-ws-nav" data-ws-nav hidden aria-label="Section pages">' +
      '<button type="button" class="yp-studio-ws-nav__btn" data-ws-prev aria-label="Previous page">' +
      '<span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span></button>' +
      '<span class="yp-studio-ws-nav__label" data-ws-nav-label aria-live="polite"></span>' +
      '<button type="button" class="yp-studio-ws-nav__btn" data-ws-next aria-label="Next page">' +
      '<span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span></button>' +
      '</nav>' +
      '<div class="yp-studio-ws-dots" data-ws-dots hidden aria-hidden="true"></div>'
    );
  }

  function resolvePaginateGrid(section) {
    var grid = getGrid(section);
    if (grid) {
      return grid;
    }
    if (!isPaginatedAsideSection(section)) {
      return null;
    }
    grid = section.querySelector('.yp-cards-grid') || section.querySelector('.yp-studio-workspace-rows');
    return grid;
  }

  function clearSectionPagination(section) {
    if (!section) {
      return;
    }
    section.classList.remove('has-ws-pagination');
    section.removeAttribute('data-ws-pager-bound');
    section.querySelectorAll('.yp-ws-page-hidden').forEach(function (el) {
      el.classList.remove('yp-ws-page-hidden');
      el.removeAttribute('hidden');
    });
    var grid = section.querySelector('[data-workspace-paginate="true"]');
    if (grid) {
      grid.removeAttribute('data-workspace-paginate');
      grid.removeAttribute('data-items-per-page');
      grid.removeAttribute('data-paginate-item-selector');
    }
    var footer = section.querySelector('[data-ws-pager-footer]');
    if (footer && footer.parentNode) {
      footer.parentNode.removeChild(footer);
    }
  }

  function ensurePagerDom(section) {
    if (!isPaginatedSection(section) && !isPaginatedAsideSection(section)) {
      return;
    }
    if (isAsideCustomSection(section)) {
      section.classList.add('yp-studio-custom-section--aside');
    }
    var grid = resolvePaginateGrid(section);
    if (!grid) {
      return;
    }
    grid.setAttribute('data-workspace-paginate', 'true');
    if (!grid.getAttribute('data-items-per-page')) {
      grid.setAttribute('data-items-per-page', String(DEFAULT_PER_PAGE));
    }

    var footer = section.querySelector('[data-ws-pager-footer]');
    if (!footer) {
      footer = document.createElement('div');
      footer.className = 'yp-studio-ws-pager-footer';
      footer.setAttribute('data-ws-pager-footer', '');
      footer.hidden = true;
      footer.innerHTML = pagerFooterHtml();
      var body = section.querySelector('.yp-studio-section-body');
      if (body) {
        body.appendChild(footer);
      } else {
        section.appendChild(footer);
      }
    }

    if (section.getAttribute('data-ws-pager-bound') === '1') {
      return;
    }
    section.setAttribute('data-ws-pager-bound', '1');

    var prev = section.querySelector('[data-ws-prev]');
    var next = section.querySelector('[data-ws-next]');
    if (prev) {
      prev.addEventListener('click', function (evt) {
        evt.preventDefault();
        var sid = getSectionId(section);
        setPageIndex(sid, getPageIndex(sid) - 1);
        syncSection(section);
      });
    }
    if (next) {
      next.addEventListener('click', function (evt) {
        evt.preventDefault();
        var sid = getSectionId(section);
        setPageIndex(sid, getPageIndex(sid) + 1);
        syncSection(section);
      });
    }
  }

  function renderDots(section, viewPages, currentPage) {
    var dotsEl = section.querySelector('[data-ws-dots]');
    if (!dotsEl) {
      return;
    }
    dotsEl.innerHTML = '';
    for (var p = 0; p < viewPages; p++) {
      (function (pageIndex) {
        var dot = document.createElement('button');
        dot.type = 'button';
        dot.className = 'yp-studio-ws-dots__dot' + (pageIndex === currentPage ? ' is-active' : '');
        dot.setAttribute('aria-label', 'Page ' + (pageIndex + 1));
        dot.setAttribute('aria-current', pageIndex === currentPage ? 'true' : 'false');
        dot.addEventListener('click', function (evt) {
          evt.preventDefault();
          setPageIndex(getSectionId(section), pageIndex);
          syncSection(section);
        });
        dotsEl.appendChild(dot);
      })(p);
    }
  }

  function syncSection(section) {
    if (!isPaginatedSection(section)) {
      return;
    }
    ensurePagerDom(section);

    var grid = getGrid(section);
    if (!grid) {
      return;
    }
    var cards = getCards(grid);
    var perPage = getPerPage(grid);
    var sid = getSectionId(section);
    var pages = getPageCount(cards.length, perPage);
    var page = getPageIndex(sid);
    if (page >= pages) {
      page = pages - 1;
    }
    if (page < 0) {
      page = 0;
    }
    setPageIndex(sid, page, true);

    var start = page * perPage;
    var end = start + perPage;
    var editing = isEditMode();

    cards.forEach(function (card, index) {
      var onPage = index >= start && index < end;
      var visible = onPage || (editing && card.classList.contains('is-dragging'));
      card.classList.toggle('yp-ws-page-hidden', !visible);
      if (visible) {
        card.removeAttribute('hidden');
      } else {
        card.setAttribute('hidden', 'hidden');
      }
    });

    var needsPagination = cards.length > perPage;
    section.classList.toggle('has-ws-pagination', needsPagination);

    var footer = section.querySelector('[data-ws-pager-footer]');
    var dotsEl = section.querySelector('[data-ws-dots]');
    var navEl = section.querySelector('[data-ws-nav]');
    var prev = section.querySelector('[data-ws-prev]');
    var next = section.querySelector('[data-ws-next]');
    var label = section.querySelector('[data-ws-nav-label]');

    if (footer) {
      footer.hidden = !needsPagination;
    }

    if (dotsEl) {
      if (needsPagination) {
        dotsEl.hidden = false;
        dotsEl.setAttribute('aria-hidden', 'false');
        renderDots(section, pages, page);
      } else {
        dotsEl.hidden = true;
        dotsEl.setAttribute('aria-hidden', 'true');
        dotsEl.innerHTML = '';
      }
    }

    if (navEl) {
      var needsNav = editing && pages > 1;
      navEl.hidden = !needsNav;
      navEl.setAttribute('aria-hidden', needsNav ? 'false' : 'true');
    }
    if (prev) {
      prev.disabled = page <= 0;
    }
    if (next) {
      next.disabled = page >= pages - 1;
    }
    if (label) {
      label.textContent = page + 1 + ' / ' + pages;
    }

    hideSectionLoading(section);
  }

  function refresh() {
    var root = getRoot();
    if (!root) {
      return;
    }

    var aside = getAsideEl();
    if (aside) {
      aside
        .querySelectorAll('.yp-studio-custom-section, [data-section-id="from-extensions"]')
        .forEach(function (section) {
          if (isPaginatedAsideSection(section)) {
            syncSection(section);
          }
        });
    }

    if (isNetworkDashboard()) {
      var main = getMainEl();
      if (main) {
        main.querySelectorAll('.yp-dashboard-section[data-layout-section="true"]').forEach(function (section) {
          clearSectionPagination(section);
          hideSectionLoading(section);
        });
      }
    }
  }

  function clearFlipTimer() {
    if (flipTimer) {
      clearTimeout(flipTimer);
      flipTimer = null;
    }
    if (dragCtx && dragCtx.section) {
      var prevBtn = dragCtx.section.querySelector('[data-ws-prev]');
      var nextBtn = dragCtx.section.querySelector('[data-ws-next]');
      if (prevBtn) {
        prevBtn.classList.remove('is-page-flip-active');
      }
      if (nextBtn) {
        nextBtn.classList.remove('is-page-flip-active');
      }
    }
  }

  function maybePageFlip(clientX, clientY) {
    if (!dragCtx || !dragCtx.section || !isEditMode()) {
      clearFlipTimer();
      return;
    }
    var section = dragCtx.section;
    var grid = getGrid(section);
    if (!grid) {
      return;
    }
    var cards = getCards(grid);
    var perPage = getPerPage(grid);
    var pages = getPageCount(cards.length, perPage);
    if (pages <= 1) {
      clearFlipTimer();
      return;
    }

    var sid = getSectionId(section);
    var currentPage = getPageIndex(sid);
    var gridRect = grid.getBoundingClientRect();
    var edge = 44;
    var flipPrev = clientX < gridRect.left + edge && currentPage > 0;
    var flipNext = clientX > gridRect.right - edge && currentPage < pages - 1;

    var prevBtn = section.querySelector('[data-ws-prev]');
    var nextBtn = section.querySelector('[data-ws-next]');
    if (!flipPrev && prevBtn) {
      var prevRect = prevBtn.getBoundingClientRect();
      flipPrev =
        currentPage > 0 &&
        clientX >= prevRect.left &&
        clientX <= prevRect.right &&
        clientY >= prevRect.top &&
        clientY <= prevRect.bottom;
    }
    if (!flipNext && nextBtn) {
      var nextRect = nextBtn.getBoundingClientRect();
      flipNext =
        currentPage < pages - 1 &&
        clientX >= nextRect.left &&
        clientX <= nextRect.right &&
        clientY >= nextRect.top &&
        clientY <= nextRect.bottom;
    }

    if (!flipPrev && !flipNext) {
      clearFlipTimer();
      return;
    }
    if (flipTimer) {
      return;
    }

    if (flipPrev && prevBtn) {
      prevBtn.classList.add('is-page-flip-active');
    }
    if (flipNext && nextBtn) {
      nextBtn.classList.add('is-page-flip-active');
    }

    flipTimer = setTimeout(function () {
      flipTimer = null;
      if (!dragCtx) {
        return;
      }
      if (flipPrev && currentPage > 0) {
        setPageIndex(sid, currentPage - 1);
      } else if (flipNext && currentPage < pages - 1) {
        setPageIndex(sid, currentPage + 1);
      } else {
        clearFlipTimer();
        return;
      }
      syncSection(section);
      clearFlipTimer();
    }, 380);
  }

  function handleDragStart(card) {
    if (!card || !isEditMode()) {
      dragCtx = null;
      return;
    }
    var section = card.closest('.yp-dashboard-section');
    if (!isPaginatedSection(section)) {
      dragCtx = null;
      return;
    }
    ensurePagerDom(section);
    if (!getGrid(section)) {
      dragCtx = null;
      return;
    }
    dragCtx = {
      section: section,
      card: card,
      lastX: 0,
      lastY: 0,
    };
  }

  function handleDragMove(clientX, clientY) {
    if (!dragCtx) {
      return;
    }
    dragCtx.lastX = clientX;
    dragCtx.lastY = clientY;
    maybePageFlip(clientX, clientY);
  }

  function handleDragEnd() {
    clearFlipTimer();
    var section = dragCtx ? dragCtx.section : null;
    dragCtx = null;
    if (section) {
      syncSection(section);
    } else {
      refresh();
    }
  }

  function loadPages(data) {
    pageBySection = {};
    if (!data || !data.cardPages || typeof data.cardPages !== 'object') {
      return;
    }
    Object.keys(data.cardPages).forEach(function (id) {
      pageBySection[id] = parseInt(data.cardPages[id], 10) || 0;
    });
  }

  function getCardPages() {
    return Object.assign({}, pageBySection);
  }

  window.YOOAdminWorkspacePagination = {
    refresh: refresh,
    loadPages: loadPages,
    getCardPages: getCardPages,
    ensureSection: ensurePagerDom,
    syncSection: syncSection,
    handleDragStart: handleDragStart,
    handleDragMove: handleDragMove,
    handleDragEnd: handleDragEnd,
  };

  function boot() {
    dismissNetworkSitesLoading();
    refresh();
  }

  document.addEventListener('yooadmin-studio-hub-grids-ready', boot);
  document.addEventListener('yooadmin-studio-hub-widget-rendered', boot);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
